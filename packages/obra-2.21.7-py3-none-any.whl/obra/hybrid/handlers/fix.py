"""Fix handler for Hybrid Orchestrator.

This module handles the FIX action from the server. It attempts to fix issues
found during review by deploying an implementation agent with specific fix instructions.

The fix process:
    1. Receive FixRequest with issues to fix and execution order
    2. For each issue in order:
       - Build fix prompt with issue details
       - Deploy implementation agent
       - Verify the fix
    3. Return FixResults to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
"""

import contextlib
import json
import logging
import shlex
import subprocess
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

from obra.api import APIClient
from obra.api.protocol import FixRequest
from obra.config import (
    DEFAULT_NETWORK_TIMEOUT,
    get_agent_execution_timeout,
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
)
from obra.config.loaders import (
    get_fix_batching_enabled,
    get_fix_batching_max_size,
    get_fix_batching_split_on_retry,
    get_fix_llm_suggestion_timeout,
    get_fix_llm_test_gap_timeout,
    get_fix_test_gap_inference_confidence_threshold,
    get_fix_test_gap_inference_enabled,
    get_fix_test_gap_inference_max_candidates,
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
    get_priority_order,
    get_timeout,
    get_verification_required,
    load_layered_config,
)
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display import console, print_error, print_info, print_warning
from obra.display.observability import (
    ObservabilityConfig,
    ProgressEmitter,
    VerbosityLevel,
)
from obra.hybrid.handlers.base import ObservabilityContextMixin
from obra.hybrid.install_target import InstallTargetManager
from obra.hybrid.prompt_enricher import PromptEnricher
from obra.llm.interactive_guard import (
    extract_interactive_failure,
    sanitize_interactive_line,
)
from obra.prompts.fix.context import (
    build_batch_fix_context,
    build_issue_specific_context,
    build_test_gap_batch_context,
    build_test_gap_inference_prompt,
    build_test_gap_issue_context,
)
from obra.prompts.fragments.recovery import build_interactive_recovery_banner
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.utils.file_tracker import FileSnapshot, FileStateTracker
from obra.utils.workspace_rollback import WorkspaceRollbackStore
from obra.validation.verification_tools import detect_installed_verification_categories

logger = logging.getLogger(__name__)

# Type alias for streaming callback
StreamCallback = Callable[[str, str], None] | None


@dataclass
class FileChangeSet:
    """Represents a set of file changes detected in the working directory."""

    added: set[str]
    modified: set[str]
    count: int


class FileChangeTracker:
    """Tracks file changes between polls using FileStateTracker.

    FIX-FILE-TRACKING-001: Uses hash-based file tracking instead of git status.
    Git doesn't track changes to untracked files, so files created in one fix
    cycle and modified in subsequent cycles were always showing as "added".
    Now properly detects modifications by comparing against initial snapshot.
    """

    def __init__(self, handler: "FixHandler") -> None:
        self._handler = handler
        self._file_tracker = handler._file_tracker
        # Capture initial state when tracker is created
        self._initial_snapshot = self._file_tracker.snapshot()
        # Track what we've already reported to avoid duplicates
        self._reported_added: set[str] = set()
        self._reported_modified: set[str] = set()

    def poll(self) -> FileChangeSet:
        """Poll for new file changes since last poll.

        Compares current state against initial snapshot (not git status).
        This correctly detects modifications to files that were created
        during the fix cycle but not yet committed to git.
        """
        # Get changes compared to initial state
        changes = self._file_tracker.diff(self._initial_snapshot)

        # Convert to sets for comparison
        current_added = set(changes.added)
        current_modified = set(changes.modified)

        # Filter infrastructure files
        current_added = self._handler._filter_infrastructure_files(current_added)
        current_modified = self._handler._filter_infrastructure_files(current_modified)

        # Find newly detected changes (not yet reported)
        new_added = current_added - self._reported_added
        new_modified = current_modified - self._reported_modified

        # Update what we've reported
        self._reported_added.update(new_added)
        self._reported_modified.update(new_modified)

        new_count = len(new_added) + len(new_modified)
        return FileChangeSet(added=new_added, modified=new_modified, count=new_count)

    def get_total_count(self) -> int:
        """Get total count of all tracked file changes.

        Returns the cumulative count of added + modified files detected
        since the tracker was initialized.
        """
        return len(self._reported_added) + len(self._reported_modified)


class HeartbeatThread(threading.Thread):
    """Background thread that emits heartbeat messages during long-running execution.

    Additionally, it emits liveness_check events via log_event callback.
    """

    def __init__(
        self,
        item_id: str,
        emitter: ProgressEmitter,
        file_tracker: FileChangeTracker,
        handler: "FixHandler",
        interval: int,
        initial_delay: int,
        stop_event: threading.Event,
        log_event: Callable[..., None] | None = None,
        session_id: str | None = None,
        trace_id: str | None = None,
    ) -> None:
        """Initialize HeartbeatThread.

        Args:
            item_id: ID of the plan item being executed
            emitter: ProgressEmitter for output
            file_tracker: FileChangeTracker for detecting file changes
            handler: FixHandler for line counting
            interval: Base interval between heartbeats (seconds)
            initial_delay: Delay before first heartbeat (seconds)
            stop_event: Event to signal thread should stop
            log_event: Optional callback for emitting liveness_check events
            session_id: Optional session ID for trace correlation
            trace_id: Optional trace ID for distributed tracing
        """
        super().__init__(daemon=True)
        self._item_id = item_id
        self._emitter = emitter
        self._file_tracker = file_tracker
        self._handler = handler
        self._interval = interval
        self._initial_delay = initial_delay
        self._stop_event = stop_event
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._start_time = time.time()
        self._alive_count = 0

    def run(self) -> None:
        """Main thread loop - emits heartbeats and file events until stopped.

        Every 180 seconds, emits liveness_check event via log_event callback.
        """
        self._stop_event.wait(self._initial_delay)

        # Track last liveness check time
        last_liveness_check = time.time()

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            file_count = self._get_file_count()

            # S4.T1: Get liveness indicators at DETAIL verbosity level
            liveness_indicators = None
            if self._emitter.config.verbosity >= VerbosityLevel.DETAIL:
                liveness_indicators = self._get_liveness_indicators()

            # Emit heartbeat with liveness indicators at DETAIL level
            self._emitter.item_heartbeat(self._item_id, elapsed, file_count, liveness_indicators)

            # S3.T1: Emit liveness_check event every LIVENESS_CHECK_INTERVAL_S
            current_time = time.time()
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                indicators = self._get_liveness_indicators()
                # Calculate status: "active" if any indicator is True, else "idle"
                status = "active" if any(indicators.values()) else "idle"
                self._alive_count += 1

                self._log_event(
                    "liveness_check",
                    status=status,
                    alive_count=self._alive_count,
                    indicators=indicators,
                    elapsed_seconds=elapsed,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
                last_liveness_check = current_time

            changes = self._file_tracker.poll()
            if changes.count > 0:
                for filepath in changes.added:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "new", line_count)
                for filepath in changes.modified:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "modified", line_count)
            self._stop_event.wait(self._interval)

    def _get_file_count(self) -> int:
        """Get current count of changed files.

        FIX-FILE-TRACKING-001: Uses FileChangeTracker instead of git commands.
        """
        return self._file_tracker.get_total_count()

    def _get_liveness_indicators(self) -> dict[str, bool]:
        """Get liveness indicators showing agent activity.

        Returns a dict with boolean indicators for:
        - files: Files being modified in workspace
        - log: Log files being written to
        - proc: Process is running
        - cpu: CPU activity (requires psutil, graceful degradation)
        - db: Database updates (placeholder for future implementation)

        Returns:
            Dict mapping indicator names to boolean active status
        """
        indicators = {
            "files": False,
            "log": False,
            "proc": True,  # If we're in heartbeat loop, process is running
            "cpu": False,  # Requires psutil, graceful degradation
            "db": False,  # Placeholder - would need StateManager integration
        }

        # Check if files have been modified
        file_count = self._get_file_count()
        indicators["files"] = file_count > 0

        # Check if log files have been written to recently
        # Look for .log or .jsonl files modified in the last interval
        try:
            working_dir = self._handler._working_dir
            current_time = time.time()
            log_activity = False

            # Check common log file patterns
            for pattern in ["*.log", "*.jsonl"]:
                for log_file in working_dir.glob(f"**/{pattern}"):
                    if log_file.is_file():
                        # Check if modified within last interval (+ some buffer)
                        mtime = log_file.stat().st_mtime
                        if current_time - mtime < (self._interval * 2):
                            log_activity = True
                            break
                if log_activity:
                    break

            indicators["log"] = log_activity
        except Exception:
            # If log checking fails, just report False
            pass

        # S3.T2: Check CPU activity via psutil (optional dependency)
        try:
            import psutil  # type: ignore[import-untyped]

            # Get CPU usage over a short interval
            # cpu_percent() with interval returns average CPU usage over that period
            # Using 0.1 seconds to avoid blocking the heartbeat thread
            cpu_percent = psutil.cpu_percent(interval=0.1)
            # Consider CPU active if usage is above 5% (low threshold for any activity)
            indicators["cpu"] = cpu_percent > 5.0
        except ImportError:
            # psutil not available - graceful degradation
            pass
        except Exception:
            # Any other error - graceful degradation
            pass

        return indicators

    def stop(self) -> None:
        """Signal the thread to stop and wait for it to exit."""
        self._stop_event.set()
        self.join(timeout=get_timeout("handler", "thread_join_s"))


class FixHandler(ObservabilityContextMixin):
    """Handler for FIX action.

    Attempts to fix issues found during review by deploying implementation
    agents with targeted fix instructions.

    ## Architecture Context (ADR-035)

    This handler implements the two-tier prompting architecture where:
    - **Server (Tier 1)**: Generates strategic base prompts with fix guidance
    - **Client (Tier 2)**: Enriches base prompts with local tactical context

    **Implementation Flow**:
    1. Server sends FixRequest with base_prompt containing fix instructions
    2. Client enriches base_prompt via PromptEnricher (adds file structure, git log)
    3. Client invokes implementation agent locally to apply fixes
    4. Client verifies fixes locally (tests, lint, security checks)
    5. Client reports fix results back to server for validation

    ## IP Protection

    Strategic fix patterns (security best practices, quality standards) stay on server.
    This protects Obra's proprietary fix guidance from client-side inspection.

    ## Privacy Protection

    Tactical context (code to fix, file contents, git messages) never sent to server.
    Only fix results (status, files modified, verification outcome) is transmitted.

    See: docs/decisions/ADR-035-unified-hybrid-architecture.md

    Example:
        >>> handler = FixHandler(Path("/path/to/project"))
        >>> request = FixRequest(
        ...     issues_to_fix=[{"id": "SEC-001", "description": "SQL injection"}],
        ...     execution_order=["SEC-001"]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["fix_results"])
    """

    DOC_FIX_TIMEOUT_S = 120
    _LOW_ATTRIBUTION_CONFIDENCE = {"low", "none", "unknown"}

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        session_id: str | None = None,
        log_file: Path | None = None,
        trace_id: str | None = None,
        log_event: Any | None = None,
        parent_span_id: str | None = None,
        observability_config: ObservabilityConfig | None = None,
        progress_emitter: ProgressEmitter | None = None,
        on_stream: StreamCallback = None,
        process_registry: Any | None = None,
    ) -> None:
        """Initialize FixHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: LLM configuration for agent deployment
            session_id: Optional session ID for trace correlation
            log_file: Optional log file path for event emission
            trace_id: Optional trace ID for distributed tracing
            log_event: Optional event logging callback
            parent_span_id: Optional parent span ID for tracing
            observability_config: Optional observability configuration for progress visibility
            progress_emitter: Optional progress emitter for heartbeat and file events
            on_stream: Optional callback for LLM streaming output (event_type, chunk)
            process_registry: Optional ProcessRegistry for subprocess lifecycle management
                             (FEAT-PROCESS-LIFECYCLE-001)
        """
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._session_id = session_id
        self._log_file = log_file
        self._trace_id = trace_id
        self._log_event = log_event
        self._parent_span_id = parent_span_id
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._on_stream = on_stream
        self._process_registry = process_registry
        self._file_tracker = FileStateTracker(working_dir)
        self._verification_tools: list[dict[str, Any]] | None = None
        self._last_verification_run_metadata: dict[str, Any] | None = None
        # Track repeated lint output to avoid noisy duplicate warnings
        self._last_lint_output: str | None = None
        self._last_lint_summary: str | None = None
        self._lint_repeat_count = 0
        # ISSUE-HYBRID-044: Track per-fingerprint fix attempts (canonical_id → failure count)
        self._fix_attempt_history: dict[str, int] = {}
        # FIX-HYBRID-048: Track cumulative failures per file path
        self._file_failure_history: dict[str, int] = {}
        self._install_target = InstallTargetManager()
        try:
            self._config, _, _ = load_layered_config(include_defaults=True)
        except Exception:
            self._config = {}
        self._log_decisions = bool(self._config.get("story0", {}).get("log_decisions", True))
        self._on_progress: Callable[[str, dict[str, Any]], None] | None = None

    def handle(self, request: FixRequest) -> dict[str, Any]:
        """Handle FIX action.

        Args:
            request: FixRequest from server with base_prompt

        Returns:
            Dict with fix_results list and item_id

        Raises:
            ValueError: If request.base_prompt is None (server must provide base_prompt)
        """
        # Trace incoming request data
        logger.debug(
            f"FixRequest received: issues_to_fix={len(request.issues_to_fix)}, "
            f"issue_details={len(request.issue_details)}, "
            f"base_prompt_len={len(request.base_prompt or '')}"
        )
        if self._progress_emitter:
            self._progress_emitter.fix_started(len(request.issues_to_fix))
        if self._log_event:
            self._log_event(
                "fix_started",
                item_id=request.item_id,
                issue_count=len(request.issues_to_fix),
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        if request.issue_details:
            for i, detail in enumerate(request.issue_details[:3]):  # Log first 3
                logger.debug(
                    f"issue_details[{i}]: id={detail.get('id')}, "
                    f"priority={detail.get('priority')}, file_path={detail.get('file_path')}"
                )
        else:
            logger.warning("FixRequest received with empty issue_details")

        if request.issues_to_fix and not request.issue_details:
            if self._attempt_issue_details_hydration(request):
                logger.info(
                    "Hydrated %s issue details from scorecard",
                    len(request.issue_details),
                )

        # ISSUE-SAAS-009: Normalize issues to dict format
        # Server may return issues as List[str] (blocking_issues) instead of List[Dict]
        # FIX-PRIORITY-LOSS-001: Use issue_details if present (preserves priority)
        issues = self._normalize_issues(request.issues_to_fix, request.issue_details)
        execution_order: list[str] | None = request.execution_order
        # ISSUE-SAAS-021: Track item_id for fix-review loop
        item_id = request.item_id

        if request.issues_to_fix and not request.issue_details:
            if all(isinstance(issue, dict) for issue in request.issues_to_fix):
                pass
            else:
                message = (
                    "Fix aborted: issue_details missing and could not be hydrated from scorecard. "
                    "Re-running review to regenerate issue details."
                )
                logger.warning(message)
                if self._progress_emitter:
                    self._progress_emitter.warning(message)
                failed_results = [
                    {
                        "issue_id": issue.get("id", "unknown"),
                        "status": "failed",
                        "summary": message,
                    }
                    for issue in issues
                ]
                return {
                    "fix_results": failed_results,
                    "fixed_count": 0,
                    "failed_count": len(failed_results),
                    "skipped_count": 0,
                    "item_id": item_id,
                }

        if not issues:
            logger.info("No issues to fix")
            return {
                "fix_results": [],
                "fixed_count": 0,
                "failed_count": 0,
                "skipped_count": 0,
                "item_id": item_id,  # ISSUE-SAAS-021
            }

        # S0.T7: Enforce verification tool availability before FIX (client-side fallback)
        # Note: Primary enforcement is server-side via session.verification_tools
        # This client-side check is a fallback for sessions without verification_tools persisted
        verification_required = get_verification_required()
        tools = self._load_verification_tools()
        if not tools:
            auto_install = (
                self._config.get("fix", {}).get("verification", {}).get("auto_install", True)
            )
            mode = self._config.get("automation_mode", "auto_safe")
            if auto_install:
                self._emit_progress("[FIX] Auto-install triggered: verification tools missing")
                installed_tools: list[str] = []
                for tool, ecosystem in [
                    ("pytest", "python"),
                    ("ruff", "python"),
                    ("mypy", "python"),
                ]:
                    if self._install_verification_tool(tool, ecosystem):
                        installed_tools.append(tool)
                if installed_tools:
                    # Bug fix: Register default tool commands directly instead of
                    # relying on discovery (which looks for project config files,
                    # not installed packages)
                    tools = self._get_default_verification_tools(installed_tools)
                    self._verification_tools = tools
                    if not tools:
                        # Fallback to discovery if defaults don't apply
                        tools = self._load_verification_tools()
            else:
                self._emit_progress(f"[FIX] Auto-install disabled (automation_mode={mode})")

            if not tools and verification_required and not auto_install:
                message = (
                    "FIX blocked: No verification tools available (fix.verification.required=true). "
                    "Configure tools via fix.verification.tools or enable discovery."
                )
                logger.warning(
                    "Verification tools required but not available - blocking FIX phase."
                )
                if self._progress_emitter:
                    self._progress_emitter.warning(message)
                failed_results = [
                    {
                        "issue_id": issue.get("id", "unknown"),
                        "status": "failed",
                        "summary": message,
                    }
                    for issue in issues
                ]
                return {
                    "fix_results": failed_results,
                    "fixed_count": 0,
                    "failed_count": len(failed_results),
                    "skipped_count": 0,
                    "item_id": item_id,
                }
            if not tools:
                logger.warning(
                    "No verification tools available but proceeding (auto-install attempted). "
                    "Fix results will not be verified."
                )

        # Validate base_prompt (server-side prompting required)
        if request.base_prompt is None:
            error_msg = "FixRequest.base_prompt is None. Server must provide base prompt (ADR-035)."
            logger.error(error_msg)
            raise ValueError(error_msg)

        all_fix_results: list[dict[str, Any]] = []
        total_fixed = 0
        total_failed = 0
        total_skipped = 0

        # Enrich base prompt with local tactical context (once per session)
        fix_history = request.fix_history or ""
        if fix_history:
            history_block = (
                "## Previous Attempts\n"
                f"{fix_history}\n\n"
                "Do not repeat approaches that failed previously.\n\n"
            )
            base_prompt = history_block + (request.base_prompt or "")
        else:
            base_prompt = request.base_prompt or ""
        enricher = PromptEnricher(self._working_dir)
        enriched_prompt = enricher.enrich(base_prompt)

        overall_before_state = self._capture_file_state()

        # FIX-LOOP-RESILIENCE-001: On retry, disable batching to isolate failures.
        # When fix_history is present, the server has already tried (and failed) with
        # batched fixes. Splitting into individual fixes prevents cross-contamination.
        is_retry = bool(fix_history)
        force_individual = is_retry and get_fix_batching_split_on_retry()

        pass_result = self._run_fix_pass(
            issues=issues,
            execution_order=execution_order,
            enriched_prompt=enriched_prompt,
            item_id=item_id,
            force_individual=force_individual,
        )
        all_fix_results.extend(pass_result["fix_results"])
        total_fixed += pass_result["fixed_count"]
        total_failed += pass_result["failed_count"]
        total_skipped += pass_result["skipped_count"]

        # FIX-HYBRID-042: Check scope and abort if hard cap exceeded
        if not self._check_fix_scope(overall_before_state):
            # Scope exceeded — changes reverted, mark all as failed
            total_fixed = 0
            total_failed = len(all_fix_results)
            total_skipped = 0
            for fr in all_fix_results:
                fr["status"] = "scope_exceeded"

        if self._progress_emitter:
            self._progress_emitter.fix_completed(
                fixed=total_fixed,
                failed=total_failed,
                skipped=total_skipped,
            )
        if self._log_event:
            self._log_event(
                "fix_completed",
                item_id=item_id,
                fixed=total_fixed,
                failed=total_failed,
                skipped=total_skipped,
                fixed_count=total_fixed,
                failed_count=total_failed,
                skipped_count=total_skipped,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

        return {
            "fix_results": all_fix_results,
            "fixed_count": total_fixed,
            "failed_count": total_failed,
            "skipped_count": total_skipped,
            "item_id": item_id,  # ISSUE-SAAS-021: Include for fix-review loop
        }

    def _emit_progress(self, message: str) -> None:
        if self._progress_emitter:
            self._progress_emitter.warning(message)
        else:
            print_info(message)

    def _emit_decision_event(self, event_type: str, data: dict[str, Any]) -> None:
        if not getattr(self, "_on_progress", None) or not self._log_decisions:
            return
        payload = {
            "type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "mode": data.get("mode", self._config.get("automation_mode", "auto_safe")),
            "ecosystem": data.get("ecosystem"),
            "packages": data.get("packages"),
            "target": data.get("target"),
            "reason": data.get("reason"),
        }
        with contextlib.suppress(Exception):
            if self._on_progress is not None:
                self._on_progress(event_type, payload)

    def _run_fix_pass(
        self,
        *,
        issues: list[dict[str, Any]],
        execution_order: list[str] | None,
        enriched_prompt: str,
        item_id: str | None,
        force_individual: bool = False,
    ) -> dict[str, Any]:
        """Run a single fix pass over the current issue list.

        Args:
            issues: List of issue dicts to fix
            execution_order: Optional ordering of issue IDs
            enriched_prompt: Enriched base prompt from server
            item_id: Plan item being fixed
            force_individual: When True, skip batching and fix each issue individually.
                Triggered on retry (FIX-LOOP-RESILIENCE-001) to isolate failures.
        """
        logger.info(f"Fixing {len(issues)} issues")
        print_info(f"Fixing {len(issues)} issues")

        issue_map = {issue.get("id", f"issue-{i}"): issue for i, issue in enumerate(issues)}

        ordered_ids = execution_order or self._order_by_priority(issues)
        self._print_issue_index(issues, ordered_ids)

        fix_results: list[dict[str, Any]] = []
        fixed_count = 0
        failed_count = 0
        skipped_count = 0

        issue_counter = 0

        if get_fix_batching_enabled() and not force_individual:
            max_batch = get_fix_batching_max_size()
            processed_issue_ids: set[str] = set()
            batches = self._group_issues_by_file(issues, ordered_ids)

            for batch_index, batch in enumerate(batches, start=1):
                if batch["file_path"] is None or len(batch["issues"]) == 1:
                    for issue in batch["issues"]:
                        issue_counter += 1
                        self._print_issue_progress(issue, issue_counter, len(issues))
                        # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
                        if self._should_skip_issue(issue):
                            result = self._build_skip_result(issue)
                        else:
                            result = self._fix_issue(issue, enriched_prompt)
                            if str(result.get("status", "")).lower() in {"failed", "inconclusive"}:
                                self._record_fix_failure(issue)
                        fix_results.append(result)
                        processed_issue_ids.add(issue.get("id", ""))

                        issue_id = issue.get("id")
                        fixed_delta, failed_delta, skipped_delta = self._emit_fix_result_line(
                            issue_id=issue_id,
                            result=result,
                            issue=issue,
                        )
                        fixed_count += fixed_delta
                        failed_count += failed_delta
                        skipped_count += skipped_delta
                elif len(batch["issues"]) > max_batch:
                    for i in range(0, len(batch["issues"]), max_batch):
                        sub_batch = {
                            "file_path": batch["file_path"],
                            "issues": batch["issues"][i : i + max_batch],
                        }
                        self._print_batch_progress(
                            sub_batch,
                            batch_index=batch_index,
                            total_batches=len(batches),
                        )
                        results = self._fix_batch(sub_batch, enriched_prompt)
                        fix_results.extend(results)

                        for result in results:
                            issue_id = result.get("issue_id")
                            processed_issue_ids.add(issue_id or "")
                            # ISSUE-HYBRID-044: Track batch failures
                            issue = issue_map.get(issue_id or "")
                            if issue and str(result.get("status", "")).lower() in {"failed", "inconclusive"}:
                                self._record_fix_failure(issue)
                            fixed_delta, failed_delta, skipped_delta = self._emit_fix_result_line(
                                issue_id=issue_id,
                                result=result,
                                issue=issue,
                            )
                            fixed_count += fixed_delta
                            failed_count += failed_delta
                            skipped_count += skipped_delta
                else:
                    self._print_batch_progress(
                        batch,
                        batch_index=batch_index,
                        total_batches=len(batches),
                    )
                    results = self._fix_batch(batch, enriched_prompt)
                    fix_results.extend(results)

                    for result in results:
                        issue_id = result.get("issue_id")
                        processed_issue_ids.add(issue_id or "")
                        # ISSUE-HYBRID-044: Track batch failures
                        issue = issue_map.get(issue_id or "")
                        if issue and str(result.get("status", "")).lower() in {"failed", "inconclusive"}:
                            self._record_fix_failure(issue)
                        fixed_delta, failed_delta, skipped_delta = self._emit_fix_result_line(
                            issue_id=issue_id,
                            result=result,
                            issue=issue,
                        )
                        fixed_count += fixed_delta
                        failed_count += failed_delta
                        skipped_count += skipped_delta
            for issue_id in ordered_ids:
                if issue_id in processed_issue_ids:
                    continue
                issue = issue_map.get(issue_id)
                if not issue:
                    logger.warning(f"Issue {issue_id} not found in issue map, skipping")
                    skipped_count += 1
                    continue

                issue_counter += 1
                self._print_issue_progress(issue, issue_counter, len(issues))
                # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
                if self._should_skip_issue(issue):
                    result = self._build_skip_result(issue)
                else:
                    result = self._fix_issue(issue, enriched_prompt)
                    if str(result.get("status", "")).lower() in {"failed", "inconclusive"}:
                        self._record_fix_failure(issue)
                fix_results.append(result)

                fixed_delta, failed_delta, skipped_delta = self._emit_fix_result_line(
                    issue_id=issue_id,
                    result=result,
                    issue=issue,
                )
                fixed_count += fixed_delta
                failed_count += failed_delta
                skipped_count += skipped_delta
        else:
            idx = 0
            while idx < len(ordered_ids):
                issue_id = ordered_ids[idx]
                issue = issue_map.get(issue_id)
                if not issue:
                    logger.warning(f"Issue {issue_id} not found in issue map, skipping")
                    skipped_count += 1
                    idx += 1
                    continue

                issue_counter += 1
                self._print_issue_progress(issue, issue_counter, len(issues))
                # ISSUE-HYBRID-044: Skip issues that exceeded max fix attempts
                if self._should_skip_issue(issue):
                    result = self._build_skip_result(issue)
                else:
                    result = self._fix_issue(issue, enriched_prompt)
                    if str(result.get("status", "")).lower() in {"failed", "inconclusive"}:
                        self._record_fix_failure(issue)
                fix_results.append(result)

                fixed_delta, failed_delta, skipped_delta = self._emit_fix_result_line(
                    issue_id=issue_id,
                    result=result,
                    issue=issue,
                )
                fixed_count += fixed_delta
                failed_count += failed_delta
                skipped_count += skipped_delta
                idx += 1

        logger.debug(
            "Fix complete: %s fixed, %s failed, %s skipped",
            fixed_count,
            failed_count,
            skipped_count,
        )
        if not self._progress_emitter:
            self._print_fix_summary(
                fixed_count=fixed_count,
                failed_count=failed_count,
                skipped_count=skipped_count,
            )

        return {
            "fix_results": fix_results,
            "fixed_count": fixed_count,
            "failed_count": failed_count,
            "skipped_count": skipped_count,
            "item_id": item_id,
        }

    @staticmethod
    def _resolve_fix_result_severity(
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> str:
        status = str(result.get("status", "failed")).strip().lower()
        if status == "failed":
            return "error"
        if status == "skipped":
            return "warning"
        if status == "inconclusive":
            priority = str(
                (issue or {}).get("priority") or (issue or {}).get("severity") or ""
            ).upper()
            return "warning" if priority in {"P0", "P1"} else "info"
        return "info"

    def _emit_fix_result_line(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        issue: dict[str, Any] | None = None,
    ) -> tuple[int, int, int]:
        status = str(result.get("status", "failed")).strip().lower()
        self._emit_fix_result_event(issue_id=issue_id, result=result, status=status)
        if status in {"fixed", "applied"}:
            print_info(f"  Fixed: {issue_id}")
            return 1, 0, 0

        if status == "skipped":
            print_warning(f"  Skipped: {issue_id}")
            return 0, 0, 1

        reason = self._format_failure_reason(result) or str(result.get("reason", "")).strip()
        detail = f" ({reason})" if reason else ""
        if status == "inconclusive":
            message = f"  Inconclusive: {issue_id}{detail}"
            severity = self._resolve_fix_result_severity(result, issue)
            if severity == "warning":
                print_warning(message)
            else:
                print_info(message)
            return 0, 0, 1

        print_error(f"  Failed: {issue_id}{detail}")
        return 0, 1, 0

    def _emit_fix_result_event(
        self,
        *,
        issue_id: str | None,
        result: dict[str, Any],
        status: str,
    ) -> None:
        """Emit a per-issue fix result event with compact verification context."""
        if not self._log_event:
            return

        verification = result.get("verification") if isinstance(result.get("verification"), dict) else {}
        verification_runs = (
            verification.get("verification_runs", {})
            if isinstance(verification, dict)
            else {}
        )
        failed_verification_runs: list[dict[str, Any]] = []
        if isinstance(verification_runs, dict):
            for check_name, run in verification_runs.items():
                if not isinstance(run, dict):
                    continue
                if str(run.get("execution_status", "")).lower() != "failed":
                    continue
                failed_verification_runs.append(
                    {
                        "check": check_name,
                        "tool": run.get("tool"),
                        "scope_type": run.get("scope_type"),
                        "attribution_confidence": run.get("attribution_confidence"),
                        "command": run.get("command"),
                    }
                )

        self._log_event(
            "fix_issue_result",
            issue_id=issue_id,
            canonical_id=result.get("canonical_id"),
            status=status,
            reason=result.get("reason"),
            verification_outcome=result.get("verification_outcome"),
            verification_reason_code=verification.get("verification_reason_code"),
            verification_scope=result.get("verification_scope"),
            attribution_confidence=result.get("attribution_confidence"),
            target_test_file_modified=verification.get("target_test_file_modified"),
            failed_verification_runs=failed_verification_runs,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

    # ------------------------------------------------------------------
    # ISSUE-HYBRID-044: Per-fingerprint fix attempt limit
    # FIX-HYBRID-048: File-level failure tracking
    # ------------------------------------------------------------------

    def _should_skip_issue(self, issue: dict[str, Any]) -> bool:
        """Check if an issue has exceeded max fix attempts.

        Checks both per-canonical-ID limit and per-file cumulative limit.
        The file-level check (FIX-HYBRID-048) catches re-fingerprinted
        variants of previously failed issues that get new canonical IDs.
        """
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        max_attempts = int(
            self._config.get("fix", {}).get("max_attempts_per_issue", 2)
        )
        if self._fix_attempt_history.get(canonical_id, 0) >= max_attempts:
            return True
        # FIX-HYBRID-048: File-level exhaustion — catches re-fingerprinted issues
        file_path = issue.get("file_path") or issue.get("file") or ""
        if file_path:
            max_file_failures = int(
                self._config.get("fix", {}).get("max_failures_per_file", 4)
            )
            if self._file_failure_history.get(file_path, 0) >= max_file_failures:
                return True
        return False

    def _record_fix_failure(self, issue: dict[str, Any]) -> None:
        """Increment failure counter for a canonical issue and its file."""
        canonical_id = issue.get("canonical_id") or issue.get("id", "unknown")
        self._fix_attempt_history[canonical_id] = (
            self._fix_attempt_history.get(canonical_id, 0) + 1
        )
        # FIX-HYBRID-048: Track file-level failures
        file_path = issue.get("file_path") or issue.get("file") or ""
        if file_path:
            self._file_failure_history[file_path] = (
                self._file_failure_history.get(file_path, 0) + 1
            )

    def _build_skip_result(self, issue: dict[str, Any]) -> dict[str, Any]:
        """Build a skip result for an issue that exceeded max attempts."""
        issue_id = issue.get("id", "unknown")
        canonical_id = issue.get("canonical_id") or issue_id
        description = issue.get("description", "")
        count = self._fix_attempt_history.get(canonical_id, 0)

        # Emit skip record for cleanup tracking
        create_skip_record(
            session_id=self._session_id or "",
            task_id=canonical_id,
            source=SkipSource.QUALITY_LOOP,
            reason=SkipReason.DIMINISHING_RETURNS,
            description=(
                f"Fix skipped after {count} consecutive failures: "
                f"{description[:120]}"
            ),
            source_context={
                "canonical_id": canonical_id,
                "attempt_count": count,
                "issue_id": issue_id,
            },
            base_dir=self._working_dir,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        logger.info(
            "ISSUE-HYBRID-044: Skipping %s after %d failed attempts",
            canonical_id,
            count,
        )

        return {
            "issue_id": issue_id,
            "canonical_id": canonical_id,
            "status": "skipped_max_attempts",
            "reason": "max_fix_attempts_exceeded",
            "files_modified": [],
            "verification": {},
            "verification_issues": [],
            "summary": (
                f"Skipped issue {issue_id}: exceeded {count} fix attempts"
            ),
        }

    def _normalize_issues(
        self,
        issues: list[Any],
        issue_details: list[dict[str, Any]] | None = None,
    ) -> list[dict[str, Any]]:
        """Normalize issues to dict format.

        ISSUE-SAAS-009: Server may return issues as List[str] (blocking_issues from
        QualityScorecard) instead of List[Dict[str, Any]]. This method normalizes
        both formats to a consistent dict structure.

        FIX-PRIORITY-LOSS-001: If issue_details is provided, use those directly
        as they preserve the original priority information from the coordinator.

        Args:
            issues: List of issues (strings or dicts) - may have lost priority info
            issue_details: Optional full issue dicts from coordinator with priority preserved

        Returns:
            List of normalized issue dicts with at least 'id' and 'description' keys
        """
        # FIX-PRIORITY-LOSS-001: Use issue_details if provided (preserves priority)
        if issue_details:
            logger.debug(f"Normalizing {len(issue_details)} issues from issue_details")
            normalized: list[dict[str, Any]] = []
            for i, detail in enumerate(issue_details):
                if isinstance(detail, dict):
                    logger.debug(
                        f"issue_details[{i}]: id={detail.get('id')}, keys={list(detail.keys())}"
                    )
                    # Ensure id exists
                    if "id" not in detail:
                        detail = dict(detail)
                        detail["id"] = f"issue-{i}"
                    normalized.append(detail)
                else:
                    logger.warning(f"Unexpected issue_details format at index {i}: {type(detail)}")
            if normalized:
                return normalized
            # Fall through to legacy normalization if issue_details was empty/invalid
        else:
            # Empty issue_details indicates potential data flow issue
            logger.warning(
                f"_normalize_issues: issue_details is empty, "
                f"falling back to legacy normalization ({len(issues)} items)"
            )

        # Legacy normalization: issues may be strings or dicts without full priority
        normalized = []
        for i, issue in enumerate(issues):
            if isinstance(issue, str):
                # String format: convert to dict with synthetic ID
                # Use the string itself as the ID (for execution_order matching)
                # and as the description
                normalized.append(
                    {
                        "id": issue,  # Use string value as ID for execution_order lookup
                        "description": issue,
                        "priority": "P2",  # Default priority for string issues
                    }
                )
            elif isinstance(issue, dict):
                # Dict format: ensure id exists
                if "id" not in issue:
                    issue = dict(issue)  # Copy to avoid mutating original
                    issue["id"] = f"issue-{i}"
                normalized.append(issue)
            else:
                # Unknown format: wrap in dict
                logger.warning(f"Unknown issue format at index {i}: {type(issue)}")
                normalized.append(
                    {
                        "id": f"issue-{i}",
                        "description": str(issue),
                        "priority": "P2",
                    }
                )
        return normalized

    def _attempt_issue_details_hydration(self, request: FixRequest) -> bool:
        if not self._session_id or not request.item_id:
            logger.warning("Cannot hydrate issue_details: session_id or item_id missing")
            return False

        try:
            client = APIClient.from_config()
            response = client.get_quality_scorecard(self._session_id, request.item_id)
            scorecard = response.get("scorecard", {})
        except Exception as e:
            logger.warning("Failed to fetch scorecard for issue_details hydration: %s", e)
            return False

        agent_reports = scorecard.get("agent_reports", [])
        if not isinstance(agent_reports, list):
            logger.warning("Unexpected scorecard agent_reports shape: %s", type(agent_reports))
            return False

        issue_details = self._extract_issue_details_from_reports(agent_reports)
        if not issue_details:
            return False

        target_ids = {
            issue.get("id") if isinstance(issue, dict) else issue for issue in request.issues_to_fix
        }
        target_ids = {issue_id for issue_id in target_ids if issue_id}
        if target_ids:
            issue_details = [detail for detail in issue_details if detail.get("id") in target_ids]

        if not issue_details:
            return False

        request.issue_details = issue_details
        return True

    @staticmethod
    def _extract_issue_details_from_reports(
        agent_reports: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        details: list[dict[str, Any]] = []
        for report in agent_reports:
            issues = report.get("issues", [])
            if not isinstance(issues, list):
                continue
            for issue in issues:
                if isinstance(issue, dict):
                    if "id" not in issue:
                        continue
                    details.append(issue)
        return details

    def _measure_diff_lines(self, files_modified: list[str]) -> int:
        """Measure actual lines changed (added + removed) via git diff.

        FIX-HYBRID-050: Uses diff-based metric instead of total file size.
        Falls back to file size measurement if git is unavailable.
        """
        try:
            result = subprocess.run(
                ["git", "diff", "--numstat", "--"] + files_modified,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
                timeout=10,
            )
            if result.returncode != 0:
                raise RuntimeError(result.stderr)
            diff_lines = 0
            for line in result.stdout.strip().splitlines():
                parts = line.split("\t")
                if len(parts) >= 2 and parts[0] != "-":
                    diff_lines += int(parts[0]) + int(parts[1])
            return diff_lines
        except Exception as exc:
            logger.debug("git diff unavailable, falling back to file size: %s", exc)
            total = 0
            for rel_path in files_modified:
                full_path = self._working_dir / rel_path
                try:
                    total += len(full_path.read_text(encoding="utf-8").splitlines())
                except Exception:
                    continue
            return total

    def _check_fix_scope(self, before_state: FileSnapshot) -> bool:
        """Check fix scope against config limits. Returns True if scope is acceptable.

        FIX-HYBRID-042: Enforces hard caps by reverting changes when exceeded.
        FIX-HYBRID-050: Uses diff-based line metric; warning threshold enforces.
        """
        files_modified = self._detect_modifications(before_state)
        if not files_modified:
            return True

        file_count = len(files_modified)
        diff_lines = self._measure_diff_lines(files_modified)

        # Load scope limits from config
        scope_cfg = self._config.get("fix", {}).get("verification", {}).get("scope", {})
        warn_diff_lines = int(scope_cfg.get("warn_diff_lines", 200))
        warn_files = int(scope_cfg.get("warn_files", 10))
        hard_cap_diff_lines = int(scope_cfg.get("hard_cap_diff_lines", 500))
        hard_cap_files = int(scope_cfg.get("hard_cap_files", 30))

        # Hard cap check — revert changes if exceeded
        if diff_lines > hard_cap_diff_lines or file_count > hard_cap_files:
            message = (
                f"Fix scope exceeded hard cap: {file_count} files, "
                f"{diff_lines} diff lines (caps: {hard_cap_files} files, "
                f"{hard_cap_diff_lines} diff lines). Reverting changes."
            )
            logger.warning(message)
            if self._progress_emitter:
                self._progress_emitter.warning(message)
            if self._log_event:
                self._log_event(
                    "fix_scope_exceeded",
                    file_count=file_count,
                    diff_lines=diff_lines,
                    hard_cap_diff_lines=hard_cap_diff_lines,
                    hard_cap_files=hard_cap_files,
                )
            self._revert_modifications(files_modified)
            return False

        # Warning check — enforces by reverting (FIX-HYBRID-050)
        if file_count > warn_files or diff_lines > warn_diff_lines:
            message = (
                f"Fix scope excessive: {file_count} files, "
                f"{diff_lines} diff lines changed (limits: {warn_files} files, "
                f"{warn_diff_lines} diff lines). Reverting changes."
            )
            logger.warning(message)
            if self._progress_emitter:
                self._progress_emitter.warning(message)
            if self._log_event:
                self._log_event(
                    "fix_scope_warning",
                    file_count=file_count,
                    diff_lines=diff_lines,
                    enforced=True,
                )
            self._revert_modifications(files_modified)
            return False
        return True

    def _revert_modifications(self, files_modified: list[str]) -> None:
        """Revert modified files using git checkout."""
        try:
            result = subprocess.run(
                ["git", "checkout", "--"] + files_modified,
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self._working_dir,
            )
            if result.returncode == 0:
                logger.info("Reverted %d files after scope exceeded", len(files_modified))
            else:
                logger.warning("git checkout failed: %s", result.stderr.strip())
        except Exception as exc:
            logger.warning("Could not revert files: %s", exc)

    def _order_by_priority(self, issues: list[dict[str, Any]]) -> list[str]:
        """Order issues by priority.

        Args:
            issues: List of issues (normalized to dict format)

        Returns:
            List of issue IDs in priority order (P0 first)
        """
        priority_order = get_priority_order()

        def get_priority_rank(issue: dict[str, Any]) -> int:
            priority = issue.get("priority", "P3")
            return priority_order.get(priority, 4)

        sorted_issues = sorted(issues, key=get_priority_rank)
        return [issue.get("id", f"issue-{i}") for i, issue in enumerate(sorted_issues)]

    def _group_issues_by_file(
        self,
        issues: list[dict[str, Any]],
        ordered_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Group issues by file path for batch fixing.

        Args:
            issues: List of issue dictionaries
            ordered_ids: List of issue IDs in priority order

        Returns:
            List of batch dicts: [{'file_path': str, 'issues': list[dict]}]
            Issues without file_path go into a None-keyed batch (processed individually)
        """
        from collections import defaultdict

        issue_map = {issue.get("id", f"issue-{i}"): issue for i, issue in enumerate(issues)}
        batches: dict[str | None, list] = defaultdict(list)

        for issue_id in ordered_ids:
            issue = issue_map.get(issue_id)
            if issue:
                if self._is_test_gap_issue(issue):
                    target_paths = self._get_test_gap_target_paths(issue)
                    file_path = target_paths[0] if target_paths else None
                else:
                    file_path = issue.get("file_path") or issue.get("file")
                batches[file_path].append(issue)

        return [{"file_path": fp, "issues": batch} for fp, batch in batches.items()]

    def _build_batch_prompt(
        self,
        batch: dict[str, Any],
        base_prompt: str,
    ) -> str:
        """Build prompt for fixing multiple issues in the same file.

        FIX-REVIEW-LOOP-002: Now includes actual file contents so the fix agent
        can see and edit the existing code instead of creating new files.

        Args:
            batch: Batch dict with 'file_path' and 'issues' keys
            base_prompt: Enriched base prompt from server

        Returns:
            Full prompt with batch context prepended
        """
        file_path = batch["file_path"]
        issues = batch["issues"]
        is_test_gap_batch = bool(issues) and all(self._is_test_gap_issue(issue) for issue in issues)

        if is_test_gap_batch:
            test_file_contents = None
            if file_path:
                test_file_contents = self._read_file_for_fix(file_path, None, context_lines=100)
                if not test_file_contents:
                    logger.warning(
                        f"Could not read test file {file_path} for batch fix context - "
                        "fix agent may create new file instead of editing"
                    )

            source_contexts: dict[str, str] = {}
            for issue in issues:
                source_path = issue.get("file_path") or issue.get("file")
                line_number = issue.get("line_number") or issue.get("line")
                if source_path:
                    source_contents = self._read_file_for_fix(source_path, line_number)
                    if source_contents:
                        source_contexts[issue.get("id", "")] = source_contents

            context = build_test_gap_batch_context(
                file_path or "unknown",
                issues,
                test_file_contents,
                source_contexts,
            )
            return context + base_prompt

        # FIX-REVIEW-LOOP-002: Read file contents for context
        file_contents = None
        if file_path:
            # Get all line numbers from issues to determine context range
            line_numbers = []
            for issue in issues:
                line_num = issue.get("line_number") or issue.get("line")
                if line_num:
                    with contextlib.suppress(ValueError, TypeError):
                        line_numbers.append(int(line_num))

            # If we have line numbers, focus around them; otherwise read full file
            target_line = min(line_numbers) if line_numbers else None
            file_contents = self._read_file_for_fix(file_path, target_line, context_lines=100)
            if not file_contents:
                logger.warning(
                    f"Could not read file {file_path} for batch fix context - "
                    "fix agent may create new file instead of editing"
                )

        # Build context via prompt library
        context = build_batch_fix_context(file_path, issues, file_contents)
        return context + base_prompt

    def _load_verification_tools(self) -> list[dict[str, Any]]:
        if self._verification_tools is not None:
            return self._verification_tools
        try:
            from obra.config.loaders import (
                get_verification_discovery_enabled,
                get_verification_force_refresh,
                load_layered_config,
            )
            from obra.hybrid.tooling_discovery import ToolingDiscovery

            config, _, _ = load_layered_config(include_defaults=True)
            tools = config.get("fix", {}).get("verification", {}).get("tools", [])
            if isinstance(tools, list) and tools:
                self._verification_tools = [
                    self._normalize_verification_tool(tool, default_source="config")
                    for tool in tools
                    if isinstance(tool, dict)
                ]
                return self._verification_tools

            if get_verification_discovery_enabled():
                discovery = ToolingDiscovery(self._working_dir, self._llm_config)
                tooling = discovery.discover(force_refresh=get_verification_force_refresh())
                self._verification_tools = self._convert_discovery_to_tools(tooling)
            else:
                self._verification_tools = []
            if not self._verification_tools:
                installed = detect_installed_verification_categories()
                if installed:
                    category_to_tool = {
                        "tests": "pytest",
                        "lint": "ruff",
                        "typecheck": "mypy",
                    }
                    tool_names = [
                        category_to_tool[category]
                        for category in installed
                        if category in category_to_tool
                    ]
                    if tool_names:
                        self._verification_tools = self._get_default_verification_tools(tool_names)
            self._verification_tools = [
                self._normalize_verification_tool(tool, default_source="auto")
                for tool in self._verification_tools
                if isinstance(tool, dict)
            ]
        except Exception as exc:
            logger.warning("Failed to load verification tools config: %s", exc)
            self._verification_tools = []
        return self._verification_tools

    def _get_default_verification_tools(self, installed_tools: list[str]) -> list[dict[str, Any]]:
        """Get default verification tool configs for installed packages.

        Used when auto-install succeeds but discovery doesn't find tool commands
        (e.g., new projects without pytest.ini or pyproject.toml [tool.pytest]).
        """
        # Default tool configs for Python verification tools
        defaults: dict[str, dict[str, Any]] = {
            "pytest": {
                "name": "tests",
                "category": "tests",
                "command": "pytest {files}",
                "parser": "llm",
                "patterns": ["test_*.py", "*_test.py"],
                "scope_type": "scoped",
                "target_files": ["test_*.py", "*_test.py"],
                "discovery_source": "fallback_default",
            },
            "ruff": {
                "name": "lint",
                "category": "lint",
                "command": "ruff check {files}",
                "parser": "llm",
                "patterns": ["*.py"],
                "scope_type": "scoped",
                "target_files": ["*.py"],
                "discovery_source": "fallback_default",
            },
            "mypy": {
                "name": "typecheck",
                "category": "typecheck",
                "command": "mypy {files}",
                "parser": "llm",
                "patterns": ["*.py"],
                "scope_type": "scoped",
                "target_files": ["*.py"],
                "discovery_source": "fallback_default",
            },
        }
        tools = []
        for tool_name in installed_tools:
            if tool_name in defaults:
                tools.append(defaults[tool_name])
        return tools

    def _install_verification_tool(self, tool: str, ecosystem: str) -> bool:
        auto_install = self._config.get("fix", {}).get("verification", {}).get("auto_install", True)
        mode = self._config.get("automation_mode", "auto_safe")
        if not auto_install:
            logger.info("[FIX] Auto-install disabled (automation_mode=%s)", mode)
            return False

        allowed, reason = self._should_install_tool(tool, "INFERRED", ecosystem)
        if not allowed:
            self._emit_progress(f"[FIX] Skipped: {tool} ({reason})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": self._config.get("automation_mode", "auto_safe"),
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": reason,
                },
            )
            return False

        in_allowlist = self._is_tool_allowed(tool, ecosystem)
        if mode != "auto_full" and not in_allowlist:
            reason = (
                f"{tool} not in allowlist. Hint: Add to inferred_install_allowlist."
                f"{ecosystem} or use auto_full mode."
            )
            self._emit_progress(f"[FIX] Skipped: {tool} ({reason})")
            self._emit_decision_event(
                "package_skipped",
                {
                    "mode": mode,
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": reason,
                },
            )
            return False

        preference = (
            self._config.get("story0", {})
            .get("package_manager_preference", {})
            .get(ecosystem, "auto")
        )
        target = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_target", "project_local")
        )

        manager = self._install_target.get_package_manager(ecosystem, preference, self._working_dir)
        env_path = None
        if ecosystem == "python":
            toolchains = self._install_target.detect_toolchain(self._working_dir)
            python_toolchain = toolchains.get("python")
            env_path = python_toolchain.env_path if python_toolchain else None
        env_info_str = f"env={env_path}" if env_path else "env=none"
        self._emit_progress(f"[FIX] Install target: {target} (manager={manager}, {env_info_str})")

        cmd = self._install_target.build_install_command(
            ecosystem,
            [tool],
            target,
            manager,
            env_path,
        )

        timeout_s = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_timeout_s", DEFAULT_NETWORK_TIMEOUT)
        )
        try:
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=self._working_dir,
            )
        except subprocess.TimeoutExpired:
            self._emit_progress(f"[FIX] Install timed out: {tool}")
            return False

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or "Unknown error"
            self._emit_progress(f"[FIX] Install failed: {tool}\n{detail}")
            return False

        self._emit_progress(
            f"[FIX] Installed: {tool} (ecosystem={ecosystem}, allowlist={in_allowlist})"
        )
        self._emit_decision_event(
            "package_installed",
            {
                "mode": mode,
                "ecosystem": ecosystem,
                "packages": [tool],
                "target": target,
                "reason": "",
            },
        )
        return True

    def _is_tool_allowed(self, tool: str, ecosystem: str) -> bool:
        allowlist = self._config.get("inferred_install_allowlist", {})
        if not isinstance(allowlist, dict) or not allowlist:
            return True
        entries = []
        entries.extend(allowlist.get("_common", []))
        entries.extend(allowlist.get(ecosystem, []))
        tool_lower = tool.lower()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if str(entry.get("name") or "").lower() == tool_lower:
                return True
        return False

    def _should_install_tool(self, tool: str, source: str, ecosystem: str) -> tuple[bool, str]:
        policy = (
            self._config.get("fix", {})
            .get("verification", {})
            .get("install_policy", "manifest_then_inferred")
        )
        normalized_source = source.upper()

        if normalized_source == "INFERRED":
            self._emit_decision_event(
                "policy_applied",
                {
                    "mode": self._config.get("automation_mode", "auto_safe"),
                    "ecosystem": ecosystem,
                    "packages": [tool],
                    "target": self._config.get("fix", {})
                    .get("verification", {})
                    .get("install_target", "project_local"),
                    "reason": f"policy={policy}",
                },
            )

        if policy == "manifest_only" and normalized_source != "MANIFEST":
            logger.warning("[FIX] Blocked by policy: %s does not allow inferred installs", policy)
            self._emit_progress(
                f"[FIX] Blocked by policy: {policy} does not allow inferred installs"
            )
            return (
                False,
                "blocked by manifest_only policy. Hint: Use automation_mode=auto_full "
                "to allow inferred installs.",
            )
        if policy not in (
            "manifest_only",
            "manifest_then_inferred",
            "manifest_or_inferred",
        ):
            return False, f"unsupported install policy: {policy}"

        if normalized_source == "INFERRED" and policy == "manifest_then_inferred":
            return True, ""

        return True, ""

    @staticmethod
    def _convert_discovery_to_tools(tooling: dict[str, Any]) -> list[dict[str, Any]]:
        if not tooling:
            return []
        tools: list[dict[str, Any]] = []
        verification = tooling.get("verification", {})
        test = verification.get("test", {})
        lint = verification.get("lint", {})
        typecheck = verification.get("typecheck", {})

        if isinstance(test, dict) and test.get("command"):
            tools.append(
                {
                    "name": "tests",
                    "category": "tests",
                    "command": test.get("command"),
                    "parser": "llm",
                    "patterns": test.get("patterns") or [],
                    "scope_type": test.get("scope_type"),
                    "target_files": test.get("target_files") or test.get("patterns") or [],
                    "discovery_source": test.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        if isinstance(lint, dict) and lint.get("command"):
            tools.append(
                {
                    "name": "lint",
                    "category": "lint",
                    "command": lint.get("command"),
                    "parser": "llm",
                    "patterns": lint.get("patterns") or [],
                    "scope_type": lint.get("scope_type"),
                    "target_files": lint.get("target_files") or lint.get("patterns") or [],
                    "discovery_source": lint.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        if isinstance(typecheck, dict) and typecheck.get("command"):
            tools.append(
                {
                    "name": "typecheck",
                    "category": "typecheck",
                    "command": typecheck.get("command"),
                    "parser": "llm",
                    "patterns": typecheck.get("patterns") or [],
                    "scope_type": typecheck.get("scope_type"),
                    "target_files": typecheck.get("target_files")
                    or typecheck.get("patterns")
                    or [],
                    "discovery_source": typecheck.get("discovery_source")
                    or tooling.get("_meta", {}).get("source")
                    or tooling.get("_meta", {}).get("discovery_method")
                    or "discovery",
                }
            )
        return tools

    @staticmethod
    def _coerce_string_list(value: Any) -> list[str]:
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list):
            return []
        normalized: list[str] = []
        for entry in value:
            if isinstance(entry, str):
                cleaned = entry.strip()
                if cleaned:
                    normalized.append(cleaned)
        return normalized

    @staticmethod
    def _infer_verification_scope_type(command: str) -> str:
        normalized = " ".join(command.strip().split())
        if not normalized:
            return "unscoped"
        if "{files}" in normalized or "{paths}" in normalized:
            return "scoped"

        repo_wide_tokens = {
            ".",
            "./",
            "./...",
            "...",
            "--all",
            "--all-files",
            "--all-targets",
        }
        parts = normalized.split()
        if any(token in repo_wide_tokens for token in parts):
            return "unscoped"
        return "unscoped"

    def _normalize_verification_tool(
        self,
        tool: dict[str, Any],
        *,
        default_source: str,
    ) -> dict[str, Any]:
        normalized = dict(tool)
        command = str(tool.get("command", "") or "").strip()
        scope_type = str(tool.get("scope_type", "") or "").strip().lower()
        if scope_type not in {"scoped", "unscoped"}:
            scope_type = self._infer_verification_scope_type(command)

        patterns = self._coerce_string_list(tool.get("patterns", []))
        target_files = self._coerce_string_list(
            tool.get("target_files", tool.get("targets", patterns))
        )
        discovery_source = str(tool.get("discovery_source") or default_source).strip()
        if not discovery_source:
            discovery_source = default_source

        normalized["command"] = command
        normalized["patterns"] = patterns
        normalized["target_files"] = target_files
        normalized["scope_type"] = scope_type
        normalized["discovery_source"] = discovery_source
        return normalized

    def _build_verification_run_metadata(
        self,
        tool: dict[str, Any],
        *,
        formatted_command: str,
        files: list[str],
    ) -> dict[str, Any]:
        normalized_tool = self._normalize_verification_tool(tool, default_source="runtime")
        scope_type = str(normalized_tool.get("scope_type") or "unscoped")
        discovery_source = str(normalized_tool.get("discovery_source", "runtime")).lower()
        low_certainty_source = discovery_source in {"fallback_default", "auto"}
        if scope_type == "scoped" and files and not low_certainty_source:
            attribution_confidence = "high"
        elif scope_type == "scoped":
            attribution_confidence = "medium"
        else:
            attribution_confidence = "low"

        return {
            "tool": str(normalized_tool.get("name", "") or "unknown"),
            "category": str(normalized_tool.get("category", "") or ""),
            "command": formatted_command or str(normalized_tool.get("command", "") or ""),
            "target_files": files or self._coerce_string_list(normalized_tool.get("target_files")),
            "scope_type": scope_type,
            "discovery_source": str(normalized_tool.get("discovery_source", "runtime")),
            "attribution_confidence": attribution_confidence,
        }

    def _get_verification_tools_for_category(self, category: str) -> list[dict[str, Any]]:
        tools = self._load_verification_tools()
        return [tool for tool in tools if tool.get("category") == category]

    def _run_verification_tool(
        self,
        tool: dict[str, Any],
        files: list[str] | None = None,
    ) -> tuple[bool | None, str, str, str]:
        command = tool.get("command")
        if not command:
            self._last_verification_run_metadata = self._build_verification_run_metadata(
                tool,
                formatted_command="",
                files=files or [],
            )
            self._last_verification_run_metadata["execution_status"] = "unavailable"
            return None, "", "", ""
        files = files or []
        files_arg = " ".join(files)

        # FIX-HYBRID-041: Guard against empty file targets for scoped commands.
        # When scope_type is "scoped" and files list is empty, the command
        # template (e.g., "pytest {files}") resolves to "pytest " which fails.
        scope_type = tool.get("scope_type", "unscoped")
        has_placeholders = "{files}" in command or "{paths}" in command
        if scope_type == "scoped" and has_placeholders and not files_arg.strip():
            logger.warning(
                "Skipping scoped verification %s: no target files provided",
                tool.get("name", "unknown"),
            )
            run_metadata = self._build_verification_run_metadata(
                tool, formatted_command="", files=files,
            )
            run_metadata["execution_status"] = "skipped_no_files"
            self._last_verification_run_metadata = run_metadata
            return None, "", tool.get("name", ""), tool.get("parser", "")

        formatted = command.format(files=files_arg, paths=files_arg)

        # FIX-HYBRID-039: Defense-in-depth — reject commands where placeholder
        # resolution produced a bare command with no actual targets.
        # e.g., "pytest {files}" → "pytest " when files is empty.
        formatted_stripped = formatted.strip()
        if has_placeholders and formatted_stripped == command.split("{")[0].strip():
            logger.warning(
                "Verification command '%s' resolved to bare command (no targets), skipping",
                formatted_stripped,
            )
            run_metadata = self._build_verification_run_metadata(
                tool, formatted_command=formatted, files=files,
            )
            run_metadata["execution_status"] = "skipped_empty_target"
            self._last_verification_run_metadata = run_metadata
            return None, "", tool.get("name", ""), tool.get("parser", "")

        run_metadata = self._build_verification_run_metadata(
            tool,
            formatted_command=formatted,
            files=files,
        )
        try:
            cmd = shlex.split(formatted)
        except ValueError as exc:
            logger.warning("Invalid verification command format: %s", exc)
            run_metadata["execution_status"] = "error"
            self._last_verification_run_metadata = run_metadata
            return None, "", "", ""

        timeout_s = tool.get("timeout_s", DEFAULT_NETWORK_TIMEOUT)
        logger.info("Running verification tool %s: %s", tool.get("name", "unknown"), formatted)
        try:
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout_s,
                cwd=self._working_dir,
            )
            output = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
            run_metadata["execution_status"] = "passed" if result.returncode == 0 else "failed"
            self._last_verification_run_metadata = run_metadata
            return (
                result.returncode == 0,
                output.strip(),
                tool.get("name", ""),
                tool.get("parser", ""),
            )
        except FileNotFoundError:
            logger.warning("Verification tool not found: %s", formatted)
            run_metadata["execution_status"] = "unavailable"
            self._last_verification_run_metadata = run_metadata
            return None, "", tool.get("name", ""), tool.get("parser", "")
        except subprocess.TimeoutExpired:
            logger.warning("Verification tool timed out: %s", formatted)
            run_metadata["execution_status"] = "timeout"
            self._last_verification_run_metadata = run_metadata
            return False, "", tool.get("name", ""), tool.get("parser", "")
        except Exception as exc:
            logger.warning("Verification tool error (%s): %s", formatted, exc)
            run_metadata["execution_status"] = "error"
            self._last_verification_run_metadata = run_metadata
            return False, "", tool.get("name", ""), tool.get("parser", "")

    def _resolve_issue_timeout(self, issue: dict[str, Any]) -> int:
        """Resolve timeout for an issue, with tighter limits for docs fixes."""
        base_timeout = get_agent_execution_timeout()
        if self._is_documentation_issue(issue):
            return min(base_timeout, self.DOC_FIX_TIMEOUT_S)
        return base_timeout

    def _is_documentation_issue(self, issue: dict[str, Any]) -> bool:
        """Check if the issue is documentation-related."""
        issue_id = str(issue.get("id", "")).upper()
        if issue_id.startswith("DOC-"):
            return True
        for key in ("category", "dimension", "type"):
            value = issue.get(key)
            if value and str(value).lower() in {"documentation", "docs", "doc"}:
                return True
        return False

    @staticmethod
    def _normalize_target_paths(target_paths: Any) -> list[str]:
        if not target_paths:
            return []
        if isinstance(target_paths, list):
            return [str(path).strip() for path in target_paths if str(path).strip()]
        if isinstance(target_paths, str):
            return [path.strip() for path in target_paths.split(",") if path.strip()]
        return []

    @staticmethod
    def _resolve_issue_intent(issue: dict[str, Any]) -> tuple[str, str, str]:
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        issue_kind = (issue.get("issue_kind") or metadata.get("issue_kind") or "defect").lower()
        resolution_path = (
            issue.get("resolution_path") or metadata.get("resolution_path") or "code_and_tests"
        ).lower()
        verification_scope = (
            issue.get("verification_scope") or metadata.get("verification_scope") or "auto"
        ).lower()
        return issue_kind, resolution_path, verification_scope

    @staticmethod
    def _build_promoted_defect_issue(
        issue: dict[str, Any],
        *,
        output: str,
    ) -> dict[str, Any]:
        issue_id = issue.get("id", "unknown")
        file_path = issue.get("file_path") or issue.get("file")
        line_number = issue.get("line_number") or issue.get("line")
        priority = issue.get("priority", "P1")
        description = (
            "Promotion: tests failed after coverage-gap fix. "
            "Update production code to satisfy the test expectations."
        )
        return {
            "id": f"{issue_id}-PROMO",
            "priority": priority,
            "description": description,
            "category": issue.get("category", "testing"),
            "file_path": file_path,
            "line_number": line_number,
            "issue_kind": "defect",
            "resolution_path": "code_and_tests",
            "verification_scope": "tests",
            "metadata": {
                "promoted_from": issue_id,
                "promotion_reason": "tests_failed",
                "promotion_output": output[:800],
                "promotion_attempted": True,
            },
        }

    def _is_test_gap_issue(self, issue: dict[str, Any]) -> bool:
        issue_type = str(issue.get("issue_type", "")).lower()
        if issue_type == "test_gap":
            return True
        issue_id = str(issue.get("id", "")).upper()
        if issue_id.startswith("TEST-"):
            return True
        category = str(issue.get("category") or issue.get("dimension") or "").lower()
        if category in {"testing", "test_coverage", "test_quality", "edge_cases"}:
            return True

        issue_kind, resolution_path, _verification_scope = self._resolve_issue_intent(issue)
        return issue_kind == "coverage_gap" and resolution_path == "tests_only"

    def _get_test_gap_target_paths(self, issue: dict[str, Any]) -> list[str]:
        target_paths = self._normalize_target_paths(issue.get("target_paths"))
        metadata = issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
        if not target_paths:
            target_paths = self._normalize_target_paths(metadata.get("target_paths"))
        target_test_file = issue.get("target_test_file") or metadata.get("target_test_file") or ""
        if target_test_file and target_test_file not in target_paths:
            target_paths.insert(0, target_test_file)
        return target_paths

    def _collect_test_gap_candidates(self, issue: dict[str, Any]) -> list[str]:
        max_candidates = get_fix_test_gap_inference_max_candidates()
        source_path = issue.get("file_path") or issue.get("file") or ""
        candidates: list[str] = []

        if source_path:
            candidates.extend(self._find_related_test_files([source_path]))

        if len(candidates) < max_candidates:
            test_roots = [
                self._working_dir / "tests",
                self._working_dir / "test",
                self._working_dir / "__tests__",
                self._working_dir / "spec",
                self._working_dir / "obra" / "tests",
            ]
            patterns = ["test_*.py", "*_test.py", "*.test.py", "*.spec.py"]
            for root in test_roots:
                if not root.exists():
                    continue
                for pattern in patterns:
                    for path in root.rglob(pattern):
                        rel_path = str(path.relative_to(self._working_dir))
                        if rel_path not in candidates:
                            candidates.append(rel_path)
                        if len(candidates) >= max_candidates:
                            break
                    if len(candidates) >= max_candidates:
                        break
                if len(candidates) >= max_candidates:
                    break

        return candidates[:max_candidates]

    def _infer_test_gap_target(
        self, issue: dict[str, Any]
    ) -> tuple[str | None, float | None, str | None]:
        if not self._llm_config:
            return None, None, "LLM config missing for test-gap inference"

        enabled = get_fix_test_gap_inference_enabled()
        if not enabled:
            return None, None, "Test-gap inference disabled by config"

        candidates = self._collect_test_gap_candidates(issue)
        prompt = build_test_gap_inference_prompt(issue, candidates)

        try:
            from obra.config.llm import DEFAULT_THINKING_LEVEL
            from obra.llm import LLMSubprocessConfig, run_llm_subprocess

            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            thinking_level = self._llm_config.get("thinking_level", DEFAULT_THINKING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")

            config = LLMSubprocessConfig(
                prompt=prompt,
                cwd=self._working_dir,
                provider=provider,
                model=model,
                thinking_level=thinking_level,
                auth_method=auth_method,
                timeout_s=get_fix_llm_test_gap_timeout(),
                skip_git_check=True,
                streaming=False,
                call_site="fix_test_gap_infer",
                run_id=self._session_id,
            )
            result = run_llm_subprocess(config)
            if not result.success:
                error_message = result.error or "LLM inference failed"
                if result.error_details and result.error_details.request_id:
                    if "request_id=" not in error_message:
                        error_message = (
                            f"{error_message} (request_id={result.error_details.request_id})"
                        )
                if result.retry_count and "retries=" not in error_message:
                    error_message = f"{error_message} (retries={result.retry_count})"
                return None, None, error_message

            response_text = result.output.strip()
            if response_text and provider in ("anthropic", "google"):
                try:
                    from obra.hybrid.json_utils import (
                        unwrap_claude_cli_json,
                        unwrap_gemini_cli_json,
                    )

                    data = json.loads(response_text)
                    if provider == "anthropic":
                        unwrapped, was_wrapped = unwrap_claude_cli_json(data)
                    else:
                        unwrapped, was_wrapped = unwrap_gemini_cli_json(data)
                    if was_wrapped:
                        response_text = (
                            unwrapped if isinstance(unwrapped, str) else json.dumps(unwrapped)
                        )
                except json.JSONDecodeError:
                    pass

            payload = json.loads(response_text)
            if not isinstance(payload, dict):
                return None, None, "Inference response was not JSON object"

            target = str(payload.get("target_test_file", "")).strip()
            confidence = payload.get("confidence")
            rationale = payload.get("rationale") or ""
            if not target:
                return None, None, "Inference returned empty target_test_file"
            try:
                confidence_val = float(confidence) if confidence is not None else None
            except (TypeError, ValueError):
                confidence_val = None
            return target, confidence_val, str(rationale)
        except Exception as exc:
            return None, None, f"Test-gap inference error: {exc}"

    def _ensure_test_gap_target(self, issue: dict[str, Any]) -> dict[str, Any]:
        target_paths = self._get_test_gap_target_paths(issue)
        if target_paths:
            issue["target_test_file"] = target_paths[0]
            issue["target_paths"] = target_paths
            return issue

        target, confidence, rationale = self._infer_test_gap_target(issue)
        threshold = get_fix_test_gap_inference_confidence_threshold()
        if target and confidence is not None and confidence >= threshold:
            issue["target_test_file"] = target
            issue["target_paths"] = [target]
            issue.setdefault("metadata", {})["inference_confidence"] = confidence
            issue["metadata"]["inference_rationale"] = rationale or ""
            return issue

        if confidence is None:
            reason = "Inference failed"
        else:
            reason = rationale or "Inference confidence below threshold"
        issue.setdefault("metadata", {})["inference_error"] = reason
        return issue

    def _build_patch_summary(self, files_modified: list[str]) -> dict[str, Any]:
        summary: dict[str, Any] = {
            "files": files_modified,
            "file_count": len(files_modified),
            "line_changes": [],
        }
        if not files_modified:
            return summary

        git_dir = self._working_dir / ".git"
        if not git_dir.exists():
            return summary

        try:
            cmd = ["git", "diff", "--numstat", "--", *files_modified]
            result = subprocess.run(
                cmd,
                check=False,
                capture_output=True,
                text=True,
                cwd=self._working_dir,
            )
            if result.returncode != 0:
                return summary
            for line in (result.stdout or "").splitlines():
                parts = line.split("\t")
                if len(parts) >= 3:
                    added, removed, path = parts[0], parts[1], parts[2]
                    line_changes = cast(list, summary["line_changes"])
                    line_changes.append({"path": path, "added": added, "removed": removed})
        except Exception as exc:
            logger.debug("Failed to build patch summary: %s", exc)
        return summary

    def _read_file_for_fix(
        self,
        file_path: str,
        line_number: int | str | None = None,
        context_lines: int = 50,
    ) -> str | None:
        """Read file contents for inclusion in fix prompt.

        FIX-REVIEW-LOOP-002: Critical fix - the fix agent needs to see the actual
        file contents to edit them. Without this, it creates new files instead of
        modifying existing ones.

        Args:
            file_path: Path to the file (relative to working_dir)
            line_number: Optional line number to focus around
            context_lines: Number of lines before/after to include (default 50)

        Returns:
            File contents with line numbers, or None if file cannot be read
        """
        try:
            # Resolve the file path relative to working directory
            full_path = self._working_dir / file_path
            if not full_path.exists():
                logger.warning(f"File not found for fix context: {full_path}")
                return None

            # Read file contents
            content = full_path.read_text(encoding="utf-8", errors="replace")
            lines = content.splitlines()

            # If line number is provided, focus around that area
            if line_number:
                try:
                    target_line = int(line_number)
                    start = max(0, target_line - context_lines - 1)
                    end = min(len(lines), target_line + context_lines)
                    lines = lines[start:end]
                    line_offset = start + 1
                except (ValueError, TypeError):
                    line_offset = 1
            else:
                # For full file, limit to first 200 lines + last 50 if file is long
                if len(lines) > 300:
                    head = lines[:200]
                    tail = lines[-50:]
                    lines = [
                        *head,
                        "",
                        f"... ({len(lines) - 250} lines omitted) ...",
                        "",
                        *tail,
                    ]
                line_offset = 1

            # Format with line numbers
            numbered_lines = []
            for i, line in enumerate(lines):
                if "lines omitted" in line:
                    numbered_lines.append(line)
                else:
                    line_num = line_offset + i
                    numbered_lines.append(f"{line_num:>4}: {line}")

            return "\n".join(numbered_lines)

        except Exception as e:
            logger.warning(f"Failed to read file {file_path} for fix context: {e}")
            return None

    def _build_issue_specific_prompt(
        self,
        issue: dict[str, Any],
        base_prompt: str,
    ) -> str:
        """Build a prompt with specific issue context prepended.

        FIX-REVIEW-LOOP-001: The fix loop was failing because issue details
        (description, failing scenario, suggested fix) were not being included
        in the prompt sent to the LLM. The LLM only saw generic "Fix issues:
        QUAL-001, QUAL-002..." without knowing what those issues were.

        FIX-REVIEW-LOOP-002: Now also includes actual file contents so the fix
        agent can see and edit the existing code instead of creating new files.

        This method constructs an issue-specific prompt by prepending the full
        issue context (description, file location, suggested fix) to the base
        prompt from the server.

        Args:
            issue: Issue dictionary with id, description, priority, etc.
            base_prompt: Enriched base prompt from server

        Returns:
            Full prompt with issue context prepended
        """
        issue_id = issue.get("id", "unknown")
        file_path = issue.get("file_path") or issue.get("file", "")
        line_number = issue.get("line_number") or issue.get("line", "")
        category = issue.get("category") or issue.get("dimension", "")

        logger.debug(
            f"Building prompt for {issue_id}: file={file_path}, line={line_number}, "
            f"category={category}"
        )

        if self._is_test_gap_issue(issue):
            issue = self._ensure_test_gap_target(issue)
            target_test_file = issue.get("target_test_file") or ""

            source_contents = None
            if file_path:
                source_contents = self._read_file_for_fix(file_path, line_number)
                if not source_contents:
                    logger.warning(f"Could not read source file {file_path} for test gap context")

            test_contents = None
            if target_test_file:
                test_contents = self._read_file_for_fix(target_test_file, None, context_lines=100)
                if not test_contents:
                    logger.warning(
                        f"Could not read test file {target_test_file} for test gap context"
                    )

            context = build_test_gap_issue_context(issue, source_contents, test_contents)
            return context + base_prompt

        # FIX-REVIEW-LOOP-002: Read file contents for context
        # This is CRITICAL - without file contents, the agent creates new files instead of editing
        file_contents = None
        if file_path:
            file_contents = self._read_file_for_fix(file_path, line_number)
            if not file_contents:
                logger.warning(
                    f"Could not read file {file_path} for fix context - "
                    "fix agent may create new file instead of editing"
                )

        # Build context via prompt library
        context = build_issue_specific_context(issue, file_contents)
        return context + base_prompt

    def _fix_issue(
        self,
        issue: dict[str, Any],
        enriched_prompt: str,
    ) -> dict[str, Any]:
        """Fix a single issue.

        Args:
            issue: Issue dictionary with id, description, suggestion, etc.
            enriched_prompt: Enriched fix prompt from server

        Returns:
            FixResult dictionary
        """
        issue_id = issue.get("id", "unknown")
        canonical_id = issue.get("canonical_id") or issue_id
        description = issue.get("description", "")

        logger.debug(
            f"Fixing issue {issue_id}: file={issue.get('file_path')}, "
            f"line={issue.get('line_number')}, keys={list(issue.keys())}"
        )

        logger.info(f"Fixing issue {issue_id}: {description[:50]}...")

        try:
            timeout_s = self._resolve_issue_timeout(issue)
            if self._is_documentation_issue(issue):
                logger.info(
                    "Using reduced timeout for documentation issue %s: %ss",
                    issue_id,
                    timeout_s,
                )

            if self._is_test_gap_issue(issue):
                issue = self._ensure_test_gap_target(issue)
                if not issue.get("target_test_file"):
                    error_message = issue.get("metadata", {}).get(
                        "inference_error",
                        "Missing target test file for test-gap issue",
                    )
                    return {
                        "issue_id": issue_id,
                        "canonical_id": canonical_id,
                        "status": "failed",
                        "reason": "target_test_file_missing",
                        "files_modified": [],
                        "verification": {
                            "error": error_message,
                            "test_gap_target_missing": True,
                        },
                        "verification_issues": [],
                        "summary": f"Failed to fix {issue_id}: {error_message}",
                    }

            # Capture file state before execution for modification detection
            before_state = self._capture_file_state()

            # FIX-REVIEW-LOOP-001: Build issue-specific prompt with full context
            # Previously, the enriched_prompt was used directly without issue details,
            # causing the LLM to not know what it needed to fix.
            issue_prompt = self._build_issue_specific_prompt(issue, enriched_prompt)

            # Deploy implementation agent to fix with issue-specific prompt
            result = self._deploy_agent(issue_prompt, timeout_s=timeout_s)

            # Detect actual file modifications during execution
            files_modified = self._detect_modifications(before_state)

            # Verify the fix (pass actual files_modified from tracker)
            # FIX-REVIEW-LOOP-003: Pass tracked files instead of relying on agent_result
            verification = self._verify_fix(issue, result, files_modified=files_modified)
            verification["patch_summary"] = self._build_patch_summary(files_modified)

            # Validate project boundary (post-execution safety net)
            boundary_check = self._validate_project_boundary(files_modified)
            verification["boundary_valid"] = not boundary_check["has_violations"]
            if boundary_check["has_violations"]:
                logger.warning(
                    f"Project boundary violation for issue {issue_id}: "
                    f"{boundary_check['violations']}"
                )
                verification["boundary_violations"] = boundary_check["violations"]

            # Determine status based on verification
            verification_outcome = str(
                verification.get("verification_outcome") or ""
            ).strip().lower()

            # BUG-SCHEMA-001: Use "applied" not "fixed" to match server schema.
            if verification_outcome == "passed" or verification.get("all_passed", False):
                status = "applied"
            elif verification_outcome == "inconclusive":
                status = "inconclusive"
            elif verification.get("partial", False):
                status = "applied"  # Partial fix still counts
            else:
                status = "failed"
            reason = (
                verification.get("verification_reason_code")
                or verification.get("failure_reason")
                or "verification_passed"
            )
            if status == "applied" and verification.get("partial", False):
                reason = "verification_partial"

            # BUG-SCHEMA-002: Add summary for orchestrator (orchestrator.py:791)
            status_phrase = (
                "Applied fix for"
                if status == "applied"
                else "Fix inconclusive for"
                if status == "inconclusive"
                else "Failed to fix"
            )
            summary = result.get(
                "summary",
                f"{status_phrase} issue {issue_id}",
            )

            return {
                "issue_id": issue_id,
                "canonical_id": canonical_id,
                "status": status,
                "reason": reason,
                "verification_outcome": verification.get("verification_outcome"),
                "verification_scope": verification.get("verification_scope"),
                "attribution_confidence": verification.get("attribution_confidence"),
                "files_modified": files_modified,
                "verification": verification,
                "verification_issues": verification.get("promoted_issues", []),
                "summary": summary,
            }

        except Exception as e:
            logger.exception(f"Failed to fix issue {issue_id}: {e}")
            return {
                "issue_id": issue_id,
                "canonical_id": canonical_id,
                "status": "failed",
                "reason": "handler_exception",
                "files_modified": [],
                "verification": {"error": str(e)},
                "verification_issues": [],
                "summary": f"Failed to fix issue {issue_id}: {e!s}",  # BUG-SCHEMA-002
            }

    def _fix_batch(
        self,
        batch: dict[str, Any],
        enriched_prompt: str,
    ) -> list[dict[str, Any]]:
        """Fix multiple issues in a single LLM call.

        Args:
            batch: Batch dict with 'file_path' and 'issues' keys
            enriched_prompt: Enriched base prompt from server

        Returns:
            List of FixResult dictionaries (one per issue)
        """
        issues = batch["issues"]
        file_path = batch["file_path"]

        logger.info(f"Batch fixing {len(issues)} issues in {file_path}")
        print_info(f"Batch fixing {len(issues)} issues in {file_path}")

        try:
            batch_prompt = self._build_batch_prompt(batch, enriched_prompt)
            before_state = self._capture_file_state()

            result = self._deploy_agent(batch_prompt)
            files_modified = self._detect_modifications(before_state)

            # Verify each issue individually (pass actual files_modified from tracker)
            # FIX-REVIEW-LOOP-003: Pass tracked files instead of relying on agent_result
            fix_results = []
            for issue in issues:
                verification = self._verify_fix(issue, result, files_modified=files_modified)
                verification["patch_summary"] = self._build_patch_summary(files_modified)
                verification_outcome = str(
                    verification.get("verification_outcome") or ""
                ).strip().lower()
                if verification_outcome == "passed" or verification.get("all_passed", False):
                    status = "applied"
                elif verification_outcome == "inconclusive":
                    status = "inconclusive"
                else:
                    status = "failed"
                reason = (
                    verification.get("verification_reason_code")
                    or verification.get("failure_reason")
                    or "verification_passed"
                )
                fix_results.append(
                    {
                        "issue_id": issue.get("id"),
                        "canonical_id": issue.get("canonical_id") or issue.get("id"),
                        "status": status,
                        "reason": reason,
                        "verification_outcome": verification.get("verification_outcome"),
                        "verification_scope": verification.get("verification_scope"),
                        "attribution_confidence": verification.get("attribution_confidence"),
                        "files_modified": files_modified,
                        "verification": verification,
                        "verification_issues": verification.get("promoted_issues", []),
                        "batch_id": f"{file_path}:{len(issues)}",
                    }
                )
            return fix_results

        except Exception as e:
            logger.exception(f"Batch fix failed for {file_path}: {e}")
            # Fallback: fix issues individually
            return [self._fix_issue(issue, enriched_prompt) for issue in issues]

    def _deploy_agent(self, prompt: str, *, timeout_s: int | None = None) -> dict[str, Any]:
        """Deploy implementation agent to apply fix via subprocess.

        Delegates to unified LLM subprocess runner for command building,
        execution, retry logic, and error handling.

        Args:
            prompt: Fix prompt
            timeout_s: Optional timeout override in seconds

        Returns:
            Agent result dictionary with status, summary, files_modified
        """
        from obra.llm.subprocess_runner import LLMSubprocessConfig, run_llm_subprocess

        logger.debug("Deploying implementation agent for fix")

        # Extract provider and model from config
        bypass_sandbox = False
        approval_mode: str | None = None
        from obra.config.llm import DEFAULT_THINKING_LEVEL

        if self._llm_config:
            provider = self._llm_config.get("provider", "anthropic")
            model = self._llm_config.get("model", "default")
            thinking_level = self._llm_config.get("thinking_level", DEFAULT_THINKING_LEVEL)
            auth_method = self._llm_config.get("auth_method", "oauth")
            # BUG-e100a87e: skip_git_check only applies to OpenAI Codex
            # For other providers, always False
            if provider == "openai":
                git_config: dict[str, Any] = self._llm_config.get("git", {})
                skip_git_check = git_config.get("skip_check", True)  # Default True for OpenAI
                # BUG-a377298b: Extract codex config to pass approval_mode
                # Without this, Codex may use approval_policy=never which forces read-only sandbox
                codex_config: dict[str, Any] = self._llm_config.get("codex", {})
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
            else:
                skip_git_check = False  # Not applicable to non-OpenAI providers
        else:
            # Fallback to defaults if no config
            provider = "anthropic"
            model = "default"
            thinking_level = DEFAULT_THINKING_LEVEL
            auth_method = "oauth"
            skip_git_check = False

        timeout_s = timeout_s or get_agent_execution_timeout()
        error_message: str | None = None

        # S3.T0/S3.T1: Set up heartbeat thread if progress emitter is available
        heartbeat_thread: HeartbeatThread | None = None
        stop_event: threading.Event | None = None

        if self._progress_emitter and self._observability_config:
            # Calculate scaled interval based on verbosity
            # QUIET (0): 3x base, PROGRESS (1): 1x base, DETAIL (2+): 0.5x base
            base_interval = get_heartbeat_interval()
            verbosity = self._observability_config.verbosity

            if verbosity == 0:  # QUIET
                scaled_interval = base_interval * 3
            elif verbosity == 1:  # PROGRESS
                scaled_interval = base_interval
            else:  # DETAIL (2+)
                scaled_interval = int(base_interval * 0.5)

            # Get initial delay
            initial_delay = get_heartbeat_initial_delay()

            # Create file change tracker
            file_tracker = FileChangeTracker(self)

            # Create and start heartbeat thread
            stop_event = threading.Event()
            item_id = "fix"
            # S3.T4: Pass log_event, session_id, trace_id to HeartbeatThread
            heartbeat_thread = HeartbeatThread(
                item_id=item_id,
                emitter=self._progress_emitter,
                file_tracker=file_tracker,
                handler=self,
                interval=scaled_interval,
                initial_delay=initial_delay,
                stop_event=stop_event,
                log_event=self._log_event,
                session_id=self._session_id,
                trace_id=self._trace_id,
            )
            heartbeat_thread.start()
            logger.debug(
                f"Started heartbeat thread: interval={scaled_interval}s, "
                f"initial_delay={initial_delay}s, verbosity={verbosity}"
            )

        rollback_enabled = get_interactive_guard_rollback_enabled()
        rollback_codes = get_interactive_guard_rollback_codes()
        retry_max = max(0, get_interactive_guard_retry_max())
        rollback_store = None
        rollback_snapshot = None

        if rollback_enabled:
            rollback_store = WorkspaceRollbackStore(
                self._working_dir,
                run_id=self._session_id or "fix",
            )
            rollback_snapshot = rollback_store.capture()

        try:
            # Adapter for on_stream callback: subprocess_runner expects (line),
            # but fix.py's self._on_stream expects (event_type, line)
            def stream_adapter(line: str) -> None:
                if self._on_stream:
                    self._on_stream("llm_streaming", line.rstrip("\n"))

            attempt = 0
            current_prompt = prompt
            last_error_message: str | None = None
            while True:
                # Build configuration for shared subprocess runner
                # FIX-BATCH-STALL-001: Disable stream idle timeout for fix operations.
                # When fixing multiple issues in a large file, the LLM may be silent for
                # extended periods during file editing. The overall timeout_s still applies.
                config = LLMSubprocessConfig(
                    prompt=current_prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    thinking_level=thinking_level,
                    auth_method=auth_method,
                    timeout_s=timeout_s,
                    stream_idle_timeout_s=0,  # Disable idle timeout for file editing
                    skip_git_check=skip_git_check,
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                    retry_enabled=True,
                    streaming=True,  # Fix handler always uses streaming
                    on_stream=stream_adapter if self._on_stream else None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="fix",
                    monitoring_context=None,  # Monitoring context not currently supported
                    session_id=self._session_id,
                    run_id=self._session_id,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                    mode="execute",  # ISSUE-EXEC-003: Execute mode - no --print, allows file writes
                )

                # Execute via shared subprocess runner
                result = run_llm_subprocess(config)

                # Check result
                if result.success:
                    return {
                        "status": "success",
                        "summary": "Fix applied successfully",
                        "files_modified": [],  # Would parse git diff in production
                    }
                # Execution failed
                error_message = result.error or "Unknown error"
                if result.error_details and result.error_details.request_id:
                    if "request_id=" not in error_message:
                        error_message = (
                            f"{error_message} (request_id={result.error_details.request_id})"
                        )
                if result.retry_count and "retries=" not in error_message:
                    error_message = f"{error_message} (retries={result.retry_count})"
                if last_error_message == error_message and attempt >= 1:
                    logger.warning(
                        "Stopping fix retry due to identical failure payload: %s",
                        error_message,
                    )
                    return {
                        "status": "failed",
                        "summary": f"Fix failed: {error_message}",
                        "files_modified": [],
                    }
                last_error_message = error_message
                matched_code, matched_line = self._match_rollback_code(
                    error_message,
                    rollback_codes,
                )
                interactive_failure = result.interactive_failure
                if not interactive_failure:
                    interactive_failure = extract_interactive_failure(error_message, None)
                sanitized_line = sanitize_interactive_line(
                    interactive_failure.line if interactive_failure else None
                )
                if interactive_failure:
                    message = "Interactive guard blocked an interactive prompt."
                    if sanitized_line:
                        message = f"{message} ({sanitized_line.line})"
                    if self._log_event:
                        self._log_event(
                            "interactive_guard_triggered",
                            code=interactive_failure.code,
                            pattern_id=interactive_failure.pattern_id,
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=interactive_failure.source,
                            handler="fix",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            rollback_enabled=rollback_enabled,
                            rollback_code_matched=bool(matched_code),
                            will_retry=bool(
                                matched_code and rollback_enabled and attempt < retry_max
                            ),
                            message=message,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                        )
                    logger.warning(
                        "Interactive guard triggered in fix: code=%s attempt=%d/%d line=%s",
                        interactive_failure.code,
                        attempt,
                        retry_max,
                        sanitized_line.line if sanitized_line else "",
                    )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(message)
                if rollback_enabled and rollback_store and rollback_snapshot and matched_code:
                    rollback_store.restore(rollback_snapshot)
                    if self._log_event:
                        changes = rollback_snapshot.changes
                        self._log_event(
                            "interactive_guard_rollback",
                            code=matched_code,
                            pattern_id=(
                                interactive_failure.pattern_id if interactive_failure else None
                            ),
                            matched_line=sanitized_line.line if sanitized_line else "",
                            line_redacted=(sanitized_line.redacted if sanitized_line else False),
                            line_truncated=(sanitized_line.truncated if sanitized_line else False),
                            source=(interactive_failure.source if interactive_failure else None),
                            handler="fix",
                            attempt=attempt,
                            attempt_number=attempt + 1,
                            retry_max=retry_max,
                            added_count=len(changes.added) if changes else 0,
                            modified_count=len(changes.modified) if changes else 0,
                            deleted_count=len(changes.deleted) if changes else 0,
                            session_id=self._session_id,
                            trace_id=self._trace_id,
                            message="Workspace rolled back after interactive prompt.",
                        )
                    if self._progress_emitter:
                        self._progress_emitter.interactive_guard_notice(
                            "Interactive guard triggered; workspace rolled back."
                        )
                    if attempt < retry_max:
                        recovery_banner = build_interactive_recovery_banner(
                            interactive_failure.line if interactive_failure else matched_line
                        )
                        current_prompt = f"{recovery_banner}\n\n{prompt}"
                        if self._log_event:
                            self._log_event(
                                "interactive_guard_retry",
                                code=matched_code,
                                pattern_id=(
                                    interactive_failure.pattern_id if interactive_failure else None
                                ),
                                matched_line=(sanitized_line.line if sanitized_line else ""),
                                line_redacted=(
                                    sanitized_line.redacted if sanitized_line else False
                                ),
                                line_truncated=(
                                    sanitized_line.truncated if sanitized_line else False
                                ),
                                source=(
                                    interactive_failure.source if interactive_failure else None
                                ),
                                handler="fix",
                                attempt=attempt + 1,
                                attempt_number=attempt + 2,
                                retry_max=retry_max,
                                session_id=self._session_id,
                                trace_id=self._trace_id,
                                message=f"Retrying after interactive guard ({attempt + 1}/{retry_max}).",
                            )
                        if self._progress_emitter:
                            self._progress_emitter.interactive_guard_notice(
                                f"Retrying after interactive guard ({attempt + 1}/{retry_max})."
                            )
                        attempt += 1
                        continue
                return {
                    "status": "failed",
                    "summary": f"Fix failed: {error_message}",
                    "files_modified": [],
                }

        except Exception as e:
            logger.exception(f"Fix agent deployment failed: {e}")
            error_message = str(e)
            return {
                "status": "failed",
                "summary": f"Deployment failed: {e!s}",
                "files_modified": [],
            }
        finally:
            # S3.T0: Stop heartbeat thread if it was started
            if heartbeat_thread and stop_event:
                logger.debug("Stopping heartbeat thread")
                heartbeat_thread.stop()

    def _match_rollback_code(
        self,
        error_message: str,
        rollback_codes: list[str],
    ) -> tuple[str | None, str | None]:
        """Extract rollback code and matched line from error message."""
        for code in rollback_codes:
            if error_message.startswith(code):
                remainder = error_message[len(code) :].lstrip(": ").strip()
                if not remainder:
                    return code, ""
                parts = remainder.split(":", 1)
                if len(parts) == 2:
                    return code, parts[1].strip()
                return code, remainder.strip()
        return None, None

    def _capture_verification_run(
        self,
        *,
        check: str,
        passed: bool | None,
        fallback_tool: str,
    ) -> dict[str, Any]:
        metadata = dict(self._last_verification_run_metadata or {})
        metadata.setdefault("tool", fallback_tool)
        metadata.setdefault("category", check)
        metadata.setdefault("command", "")
        metadata.setdefault("target_files", [])
        metadata.setdefault("scope_type", "unscoped")
        metadata.setdefault("discovery_source", "runtime")
        metadata.setdefault("attribution_confidence", "none")
        if passed is True:
            metadata["execution_status"] = "passed"
        elif passed is False:
            metadata["execution_status"] = "failed"
        else:
            metadata["execution_status"] = metadata.get("execution_status", "unavailable")
        return metadata

    def _classify_verification_outcome(
        self,
        *,
        verification: dict[str, Any],
        ran_tool_checks: bool,
    ) -> tuple[str, str, str, str]:
        verification_runs = verification.get("verification_runs", {})
        run_values = list(verification_runs.values()) if isinstance(verification_runs, dict) else []
        failed_runs = [
            run for run in run_values if str(run.get("execution_status", "")).lower() == "failed"
        ]
        attributable_failed_runs = [
            run
            for run in failed_runs
            if str(run.get("scope_type", "")).lower() == "scoped"
            and str(run.get("attribution_confidence", "")).lower() == "high"
        ]
        unscoped_failed_runs = [
            run for run in failed_runs if str(run.get("scope_type", "")).lower() != "scoped"
        ]

        if not verification.get("agent_succeeded"):
            return "failed", "agent_failed", "scoped", "high"

        if verification.get("target_test_file_modified") is False:
            return "failed", "target_file_unmodified", "scoped", "high"

        if attributable_failed_runs:
            return "failed", "scoped_verification_failed", "scoped", "high"

        if failed_runs:
            if unscoped_failed_runs:
                return "inconclusive", "unscoped_command", "unscoped", "low"
            return "inconclusive", "non_attributable_failure", "scoped", "low"

        if not ran_tool_checks:
            return "inconclusive", "no_verification_tools", "unscoped", "none"

        if verification.get("all_passed"):
            scoped_runs = [
                run for run in run_values if str(run.get("scope_type", "")).lower() == "scoped"
            ]
            if scoped_runs:
                return "passed", "verification_passed", "scoped", "high"
            return "passed", "verification_passed", "unscoped", "medium"

        return "inconclusive", "verification_inconclusive", "unscoped", "low"

    def _verify_fix(
        self,
        issue: dict[str, Any],
        agent_result: dict[str, Any],
        files_modified: list[str] | None = None,
    ) -> dict[str, Any]:
        """Verify that the fix resolved the issue.

        Args:
            issue: Original issue
            agent_result: Result from fix agent
            files_modified: Actual files modified during fix (from _detect_modifications)
                           If not provided, falls back to agent_result (legacy behavior)

        Returns:
            Verification results dictionary
        """
        # FIX-REVIEW-LOOP-003: Use actual files_modified from file tracker, not agent result
        # _deploy_agent always returns empty files_modified, so we need the actual tracked files
        actual_modified = (
            files_modified if files_modified is not None else agent_result.get("files_modified", [])
        )

        verification: dict[str, Any] = {
            "agent_succeeded": agent_result.get("status") == "success",
            "files_modified": bool(actual_modified),
            "verification_runs": {},
        }

        # TRIAGE-C1: Log verification details
        logger.info(f"Verifying fix for issue {issue.get('id')}")
        logger.info(f"Agent status: {agent_result.get('status')}")
        logger.info(f"Files modified: {actual_modified}")

        modified_files = actual_modified
        is_test_gap = self._is_test_gap_issue(issue)

        if is_test_gap and modified_files:
            target_paths = self._get_test_gap_target_paths(issue)
            if target_paths:
                target_file_touched = any(
                    any(path in f or f.endswith(path) or path.endswith(f) for path in target_paths)
                    for f in modified_files
                )
                verification["target_test_file_modified"] = target_file_touched
                if not target_file_touched:
                    logger.warning(
                        "Target test files %s not in modified files: %s",
                        target_paths,
                        modified_files,
                    )

        # Check verification based on issue category
        category = issue.get("category", "").lower()
        logger.info(f"Issue category: {category}")

        # FIX-VERIFICATION-003: Run ALL checks when category is unknown/empty
        # This ensures comprehensive verification instead of skipping
        checks_to_run = []
        if is_test_gap:
            checks_to_run = ["tests"]
        elif category == "security":
            checks_to_run = ["security"]
        elif category == "testing":
            checks_to_run = ["tests"]
        elif category == "code_quality":
            checks_to_run = ["lint"]
        else:
            # Unknown category - run all available checks
            logger.info("Unknown category - running all verification checks")
            checks_to_run = ["tests", "lint"]  # Skip security for perf (run on unknown)

        promoted_issues: list[dict[str, Any]] = []
        verification_runs: dict[str, dict[str, Any]] = {}
        # Run the verification checks
        for check in checks_to_run:
            if check == "security":
                result = self._run_security_check()
                security_scope = "scoped" if modified_files else "unscoped"
                verification_runs["security"] = {
                    "tool": "security_scan",
                    "category": "security",
                    "command": "security_scan",
                    "target_files": list(modified_files),
                    "scope_type": security_scope,
                    "discovery_source": "runtime",
                    "attribution_confidence": "high" if security_scope == "scoped" else "medium",
                    "execution_status": (
                        "passed" if result is True else "failed" if result is False else "unavailable"
                    ),
                }
                if result is not None:  # None means tool unavailable, skip
                    verification["security_check_passed"] = result
                    logger.info(f"Security check result: {result}")
            elif check == "tests":
                if is_test_gap:
                    metadata = (
                        issue.get("metadata", {}) if isinstance(issue.get("metadata"), dict) else {}
                    )
                    test_name = issue.get("test_name") or metadata.get("test_name")
                    target_test_file = issue.get("target_test_file")
                    if not target_test_file:
                        target_paths = self._get_test_gap_target_paths(issue)
                        target_test_file = target_paths[0] if target_paths else None
                    passed, output, tool_name, _parser = self._run_tests_for_target(
                        target_test_file,
                        test_name,
                    )
                else:
                    passed, output, tool_name, _parser = self._run_tests(
                        modified_files=modified_files
                    )
                tests_run = self._capture_verification_run(
                    check="tests",
                    passed=passed,
                    fallback_tool=tool_name or "tests",
                )
                if output:
                    tests_run["output_excerpt"] = output[:800]
                verification_runs["tests"] = tests_run
                if passed is not None:  # None means tool unavailable, skip
                    verification["tests_passed"] = passed
                    logger.info(f"Tests result: {passed}")
                    if passed is False and output:
                        verification.setdefault(
                            "last_tool_error",
                            {"tool": tool_name or "tests", "output": output[:800]},
                        )
                    if passed is False and is_test_gap:
                        issue_kind, resolution_path, _scope = self._resolve_issue_intent(issue)
                        issue_metadata = (
                            issue.get("metadata", {})
                            if isinstance(issue.get("metadata"), dict)
                            else {}
                        )
                        already_promoted = bool(
                            issue_metadata.get("promotion_attempted")
                            or issue_metadata.get("promoted_from")
                            or str(issue.get("id", "")).endswith("-PROMO")
                        )
                        if (
                            issue_kind == "coverage_gap"
                            and resolution_path == "tests_only"
                            and not already_promoted
                        ):
                            promoted_issues.append(
                                self._build_promoted_defect_issue(issue, output=output or "")
                            )
            elif check == "lint":
                # FIX-REVIEW-LOOP-003: Pass modified_files to lint only those files
                passed, output, tool_name, _parser = self._run_lint(
                    modified_files=modified_files
                )
                lint_run = self._capture_verification_run(
                    check="lint",
                    passed=passed,
                    fallback_tool=tool_name or "lint",
                )
                if output:
                    lint_run["output_excerpt"] = output[:800]
                verification_runs["lint"] = lint_run
                if passed is not None:  # None means tool unavailable, skip
                    verification["lint_passed"] = passed
                    logger.info(f"Lint result: {passed}")
                    if passed is False and output:
                        verification.setdefault(
                            "last_tool_error",
                            {"tool": tool_name or "lint", "output": output[:800]},
                        )
        verification["verification_runs"] = verification_runs
        # Determine overall result
        # FIX: files_modified is informational only - don't require it for success
        # The meaningful verification is: agent succeeded AND category-specific checks passed
        required_checks = ["agent_succeeded"]

        # Add all category checks that were actually run (not None/skipped)
        for check_key in ["tests_passed", "security_check_passed", "lint_passed"]:
            if check_key in verification:
                required_checks.append(check_key)

        if "target_test_file_modified" in verification:
            required_checks.append("target_test_file_modified")

        ran_tool_checks = any(
            key in verification for key in ["tests_passed", "security_check_passed", "lint_passed"]
        )
        if not ran_tool_checks:
            logger.warning(
                "No verification tools available - passing by default. "
                "Configure tools via fix.verification.tools or enable discovery."
            )
            if "target_test_file_modified" in verification:
                verification["all_passed"] = all(
                    verification.get(k, False) for k in required_checks
                )
            else:
                verification["all_passed"] = bool(verification.get("agent_succeeded"))
        else:
            verification["all_passed"] = all(verification.get(k, False) for k in required_checks)

        if not verification.get("all_passed"):
            if not verification.get("agent_succeeded"):
                verification["failure_reason"] = "agent_failed"
            elif verification.get("target_test_file_modified") is False:
                verification["failure_reason"] = "target_test_file_not_modified"
            elif verification.get("last_tool_error"):
                verification["failure_reason"] = "verification_failed"

        outcome, reason_code, scope_type, attribution_confidence = (
            self._classify_verification_outcome(
                verification=verification,
                ran_tool_checks=ran_tool_checks,
            )
        )
        verification["verification_outcome"] = outcome
        verification["verification_reason_code"] = reason_code
        verification["verification_scope"] = scope_type
        verification["attribution_confidence"] = attribution_confidence
        if outcome == "failed":
            verification["failure_reason"] = reason_code
        elif outcome == "inconclusive":
            verification["failure_reason"] = reason_code

        verification["new_issues"] = list(promoted_issues)
        if promoted_issues:
            verification["promoted_issues"] = promoted_issues

        logger.info(
            f"Verification complete: required_checks={required_checks}, "
            f"results={[verification.get(k) for k in required_checks]}, "
            f"all_passed={verification['all_passed']}"
        )
        return verification

    def _capture_file_state(self) -> FileSnapshot:
        """Capture current file state for diff detection.

        Uses FileStateTracker to create a snapshot of all files.
        ISSUE-REVIEW-AGENTS-002: Replaces git-based tracking.

        Returns:
            FileSnapshot with current state of all tracked files
        """
        return self._file_tracker.snapshot()

    def _detect_modifications(self, before_state: FileSnapshot) -> list[str]:
        """Detect files modified since before_state was captured.

        Uses FileStateTracker to compare current state against snapshot.
        ISSUE-REVIEW-AGENTS-002: Replaces git-based tracking.

        Args:
            before_state: FileSnapshot from _capture_file_state() before execution

        Returns:
            Sorted list of file paths that changed during execution
        """
        changes = self._file_tracker.diff(before_state)
        return changes.all_changed_files

    def _validate_project_boundary(self, files_modified: list[str]) -> dict[str, Any]:
        """Validate all modifications are within project directory.

        Post-execution safety net that checks if the fix agent modified any
        files outside the project working directory. This prevents filesystem
        escape while allowing modification of any file within the project.

        Args:
            files_modified: Files that were modified by the fix agent

        Returns:
            Dict with:
                - has_violations: True if any files are outside project boundary
                - violations: List of file paths that violated the boundary
        """
        if not files_modified:
            return {"has_violations": False, "violations": []}

        project_root = self._working_dir.resolve()
        violations: list[str] = []

        for file_path in files_modified:
            try:
                # Resolve the full path and check if it's under project root
                resolved = (project_root / file_path).resolve()
                resolved.relative_to(project_root)
            except ValueError:
                # File is outside project directory
                violations.append(file_path)
                logger.exception("Project boundary violation")

        if violations:
            logger.error(
                f"Fix agent modified {len(violations)} file(s) outside project: {violations}"
            )

        return {"has_violations": bool(violations), "violations": violations}

    def _run_security_check(self) -> bool | None:
        """Run security check to verify fix removed vulnerabilities.

        Uses SecurityAgent to scan for P0/P1 security issues (hardcoded credentials,
        SQL injection, command injection, etc.). This provides fast client-side
        verification before server-side re-review.

        Returns:
            True if no critical (P0/P1) security issues found
            False if critical issues found or check failed
            None if security tool not available (skip this check)

        Note:
            FIX-VERIFICATION-001: Execution errors are now treated as failures.
            Server-side re-review per ADR-031 provides authoritative validation.
        """
        try:
            from obra.agents.security import SecurityAgent

            logger.info("Running security verification scan")

            # Create security agent with current working directory
            agent = SecurityAgent(working_dir=self._working_dir)

            # Run analysis on all changed files (None = analyze all files)
            # Use short timeout since this is verification, not comprehensive audit
            result = agent.analyze(
                item_id="fix-verification",
                changed_files=None,
                timeout_ms=30000,  # 30 seconds - quick verification scan
            )

            # Check for critical security issues
            critical_issues = [
                issue for issue in result.issues if issue.priority.value in ["P0", "P1"]
            ]

            if critical_issues:
                logger.warning(
                    f"Security verification failed: {len(critical_issues)} critical issues found"
                )
                for issue in critical_issues[:3]:  # Log first 3 for debugging
                    logger.warning(
                        f"  - {issue.priority.value} {issue.title} in {issue.file_path or 'unknown'}"
                    )
                return False

            logger.info(
                f"Security verification passed: {len(result.issues)} total issues, "
                f"0 critical (P0/P1)"
            )
            return True

        except ImportError as e:
            # Tool not available - return None to indicate "skip this check"
            logger.warning(f"SecurityAgent not available - skipping security verification: {e}")
            return None
        except Exception as e:
            # FIX-VERIFICATION-001: Execution errors are failures
            logger.error(f"Security check failed with error: {e}", exc_info=True)
            return False

    def _run_tests(
        self,
        modified_files: list[str] | None = None,
    ) -> tuple[bool | None, str, str, str]:
        """Run tests to verify fix.

        FIX-TEST-TIMEOUT-001: Runs focused tests first, falls back to broader tests only if needed.
        This prevents long-running test suites from blocking fix verification.

        Args:
            modified_files: Optional list of files that were modified (for focused testing)

        Returns:
            Tuple: (passed | None, output, tool_name)
            passed: True if tests pass, False if tests fail, None if tests couldn't run
            output: stdout/stderr combined output (empty if unavailable)
            tool_name: name of tool used (empty if none)
        """
        # FIX-REVIEW-LOOP-004: Skip tests if no files were modified
        # This prevents "no changes needed" responses from failing due to
        # unrelated test failures when the fix agent correctly identifies
        # that issues are already resolved in the current file.
        if not modified_files:
            logger.info("No files modified - skipping test verification")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "skipped",
            }
            return True, "", "", ""

        tools = self._get_verification_tools_for_category("tests")
        if not tools:
            logger.info("No verification tools configured for tests - skipping")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        patterns = tool.get("patterns") if isinstance(tool, dict) else None
        focused_test_paths = self._find_related_test_files(modified_files, patterns=patterns)
        if focused_test_paths:
            return self._run_verification_tool(tool, files=focused_test_paths)
        logger.info("No focused test paths available - running full test command")
        return self._run_verification_tool(tool)

    def _run_tests_for_target(
        self,
        target_test_file: str | None,
        test_name: str | None,
    ) -> tuple[bool | None, str, str, str]:
        """Run tests targeting a specific test file or test name."""
        tools = self._get_verification_tools_for_category("tests")
        if not tools:
            logger.info("No verification tools configured for tests - skipping")
            self._last_verification_run_metadata = {
                "tool": "tests",
                "category": "tests",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        if target_test_file or test_name:
            if test_name and target_test_file:
                target = f"{target_test_file}::{test_name}"
            else:
                target = target_test_file or test_name or ""
            if target:
                return self._run_verification_tool(tool, files=[target])

        return self._run_verification_tool(tool)

    def _find_related_test_files(
        self,
        modified_files: list[str],
        patterns: list[str] | None = None,
    ) -> list[str]:
        """Find test files related to the modified files.

        Args:
            modified_files: List of file paths that were modified
            patterns: Optional list of glob patterns for test files

        Returns:
            List of test file paths that likely test the modified code
        """
        import fnmatch

        default_patterns = [
            "test_*",
            "*_test.*",
            "*.test.*",
            "*.spec.*",
        ]
        test_patterns = patterns or default_patterns
        test_files = []
        for filepath in modified_files:
            # Skip test files themselves
            path = Path(filepath)
            if any(fnmatch.fnmatch(path.name, pattern) for pattern in test_patterns):
                test_files.append(filepath)
                continue
            if any(part in {"tests", "test", "__tests__", "spec"} for part in path.parts):
                test_files.append(filepath)
                continue

            candidate_names = []
            for pattern in test_patterns:
                if "*" not in pattern:
                    continue
                candidate = pattern.replace("*", path.stem)
                candidate_names.append(candidate)

            candidate_paths = []
            for candidate in candidate_names:
                candidate_paths.extend(
                    [
                        path.parent / candidate,
                        path.parent / "tests" / candidate,
                        path.parent / "test" / candidate,
                        path.parent / "__tests__" / candidate,
                        path.parent / "spec" / candidate,
                        path.parent.parent / "tests" / candidate,
                    ]
                )

            for test_path in candidate_paths:
                full_path = self._working_dir / test_path
                if full_path.exists():
                    test_files.append(str(test_path))
                    logger.info(f"Found related test file: {test_path}")
                    break

        # FIX-HYBRID-051: Deduplicate by stem, preferring files in
        # recognized test directories over root-level LLM artifacts.
        # e.g. tests/test_game.py wins over test_game.py at project root.
        _test_dirs = {"tests", "test", "__tests__", "spec"}
        best_by_stem: dict[str, str] = {}
        for tf in test_files:
            tf_path = Path(tf)
            stem = tf_path.stem
            in_test_dir = any(part in _test_dirs for part in tf_path.parts)
            existing = best_by_stem.get(stem)
            if existing is None:
                best_by_stem[stem] = tf
            elif in_test_dir and not any(
                part in _test_dirs for part in Path(existing).parts
            ):
                best_by_stem[stem] = tf
        return list(best_by_stem.values())

    def _run_lint(
        self, modified_files: list[str] | None = None
    ) -> tuple[bool | None, str, str, str]:
        """Run linter to verify fix.

        FIX-REVIEW-LOOP-003: Only lint modified files to avoid pre-existing lint
        issues causing verification failures. This ensures the fix is judged on
        its own merit, not on unrelated issues in the codebase.

        Args:
            modified_files: List of files that were modified by the fix.
                           If provided, only lint these files.
                           If None or empty, skip lint (can't verify nothing).

        Returns:
            Tuple: (passed | None, output, tool_name)
            passed: True if lint passes, False if lint fails, None if linter not available
            output: stdout/stderr combined output (empty if unavailable)
            tool_name: name of tool used (empty if none)
        """
        # FIX-REVIEW-LOOP-003: Skip lint if no files were modified
        if not modified_files:
            logger.info("No files modified - skipping lint verification")
            self._last_verification_run_metadata = {
                "tool": "lint",
                "category": "lint",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "skipped",
            }
            return True, "", "", ""

        tools = self._get_verification_tools_for_category("lint")
        if not tools:
            logger.info("No verification tools configured for lint - skipping")
            self._last_verification_run_metadata = {
                "tool": "lint",
                "category": "lint",
                "command": "",
                "target_files": [],
                "scope_type": "unscoped",
                "discovery_source": "runtime",
                "attribution_confidence": "none",
                "execution_status": "unavailable",
            }
            return None, "", "", ""

        tool = tools[0]
        return self._run_verification_tool(tool, files=modified_files)

    @staticmethod
    def _is_infrastructure_file(path: str) -> bool:
        """Check if path is an infrastructure/artifact file, not a deliverable.

        BUG-a377298b: Expanded from just .obra/prompts/ to all .obra/ files.
        Infrastructure files should not count toward "files changed" metrics
        because they don't represent actual work product.

        Args:
            path: File path to check (relative to working directory)

        Returns:
            True if file is infrastructure (should be excluded from counts)
        """
        normalized = path.replace("\\", "/").lower()

        # All .obra/ directory contents are infrastructure
        if normalized.startswith(".obra/") or normalized == ".obra":
            return True

        # Legacy prompt file patterns
        if normalized.startswith(".obra-prompt-"):
            return True

        # Other common infrastructure patterns
        infrastructure_patterns = (
            ".git/",
            ".github/",
            ".vscode/",
            ".idea/",
            "__pycache__/",
            "node_modules/",
            "dist/",
            "build/",
            "vendor/",
            "target/",
            ".gradle/",
            ".cargo/",
            "bin/",
            "obj/",
            ".pytest_cache/",
            ".mypy_cache/",
            ".ruff_cache/",
        )
        return any(normalized.startswith(pattern) for pattern in infrastructure_patterns)

    def _filter_infrastructure_files(self, paths: set[str]) -> set[str]:
        """Filter out infrastructure files from a set of paths.

        Args:
            paths: Set of file paths

        Returns:
            Set of paths with infrastructure files removed
        """
        return {path for path in paths if not self._is_infrastructure_file(path)}

    def _print_issue_index(self, issues: list[dict[str, Any]], ordered_ids: list[str]) -> None:
        """Print a concise issue index for fix visibility."""
        if not issues:
            return
        issue_map = {issue.get("id", f"issue-{i}"): issue for i, issue in enumerate(issues)}
        print_info(f"Issue index ({len(issues)}):")
        for issue_id in ordered_ids:
            issue = issue_map.get(issue_id, {"id": issue_id})
            summary = self._format_issue_summary(issue)
            console.print(f"  - {summary}", style="dim")

    def _print_issue_progress(self, issue: dict[str, Any], index: int, total: int) -> None:
        """Print per-issue progress line with brief context."""
        summary = self._format_issue_summary(issue)
        print_info(f"Fixing issue {index}/{total}: {summary}")

    def _print_batch_progress(
        self,
        batch: dict[str, Any],
        *,
        batch_index: int,
        total_batches: int,
    ) -> None:
        """Print batch progress with issue IDs and file context."""
        file_path = batch.get("file_path") or "unknown"
        issues = batch.get("issues", [])
        issue_ids = [issue.get("id", "unknown") for issue in issues]
        issue_list = ", ".join(issue_ids)
        print_info(
            f"Fixing batch {batch_index}/{total_batches} in {file_path} "
            f"({len(issues)} issues: {issue_list})"
        )
        for issue in issues:
            summary = self._format_issue_summary(issue)
            console.print(f"  - {summary}", style="dim")

    @staticmethod
    def _format_issue_summary(issue: dict[str, Any]) -> str:
        """Format a concise issue summary for CLI output."""
        issue_id = issue.get("id", "unknown")
        priority = issue.get("priority") or issue.get("severity")
        id_part = f"{issue_id} ({priority})" if priority else issue_id
        file_path = issue.get("file_path") or issue.get("file")
        line_number = issue.get("line_number") or issue.get("line")
        location = ""
        if file_path and line_number:
            location = f"{file_path}:{line_number}"
        elif file_path:
            location = file_path
        description = (
            issue.get("description")
            or issue.get("title")
            or issue.get("summary")
            or issue.get("category")
            or ""
        )
        description = " ".join(str(description).split())
        if len(description) > 140:
            description = f"{description[:137]}..."
        if location and description:
            return f"{id_part} {location} - {description}"
        if location:
            return f"{id_part} {location}"
        if description:
            return f"{id_part} - {description}"
        return id_part

    @staticmethod
    def _summarize_lint_output(output: str) -> str | None:
        """Summarize lint output for short, user-friendly display."""
        if not output:
            return None
        for line in output.splitlines():
            stripped = line.strip()
            if stripped:
                if len(stripped) > 160:
                    return f"{stripped[:157]}..."
                return stripped
        return None

    @staticmethod
    def _format_failure_reason(result: dict[str, Any]) -> str | None:
        """Derive a concise failure reason from fix verification."""
        verification = result.get("verification") or {}
        if isinstance(verification, dict):
            reason_code = str(verification.get("verification_reason_code", "")).strip()
            if reason_code:
                return reason_code
            if verification.get("error"):
                return str(verification.get("error"))
            if verification.get("boundary_valid") is False:
                return "project boundary violation"
            if verification.get("lint_passed") is False:
                return "lint failed"
            if verification.get("tests_passed") is False:
                return "tests failed"
            if verification.get("security_check_passed") is False:
                return "security check failed"
        return None

    def _print_fix_summary(
        self,
        *,
        fixed_count: int,
        failed_count: int,
        skipped_count: int,
    ) -> None:
        """Print a concise fix summary with last known blocker if available."""
        detail = ""
        if failed_count and self._last_lint_summary:
            repeat_note = ""
            if self._lint_repeat_count:
                repeat_note = f" (repeated {self._lint_repeat_count + 1}x)"
            detail = f" Last blocker: lint {self._last_lint_summary}{repeat_note}."
        print_info(
            f"Fix summary: {fixed_count} fixed, {failed_count} failed, {skipped_count} skipped.{detail}"
        )

    def _get_validation_config(self) -> dict[str, Any]:
        """Load deliverable validation config from .obra/config.yaml.

        Returns:
            Dict with validation settings:
                - min_file_size: Minimum bytes for meaningful content (default: 10)
                - expected_extensions: Optional list of expected file extensions
        """
        defaults: dict[str, Any] = {
            "min_file_size": 10,
            "expected_extensions": None,
        }

        config_path = self._working_dir / ".obra" / "config.yaml"
        if not config_path.exists():
            return defaults

        try:
            import yaml

            with config_path.open(encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}

            validation = config.get("validation", {})
            if not isinstance(validation, dict):
                return defaults

            return {
                "min_file_size": validation.get("min_file_size", defaults["min_file_size"]),
                "expected_extensions": validation.get("expected_extensions"),
            }
        except Exception as e:
            logger.debug(f"Failed to load validation config: {e}")
            return defaults

    def _has_meaningful_content(self, filepath: str, min_size: int = 10) -> bool:
        """Check if a file has meaningful content (not empty or trivially small).

        Args:
            filepath: Relative path to file from working directory
            min_size: Minimum file size in bytes to be considered meaningful

        Returns:
            True if file exists and has at least min_size bytes
        """
        try:
            file_path = self._working_dir / filepath
            if not file_path.exists() or not file_path.is_file():
                return False
            return file_path.stat().st_size >= min_size
        except Exception as e:
            logger.debug(f"Failed to check file size for {filepath}: {e}")
            return False

    def _matches_expected_extensions(
        self, filepath: str, expected_extensions: list[str] | None
    ) -> bool:
        """Check if file matches expected extensions (if configured).

        Args:
            filepath: File path to check
            expected_extensions: List of expected extensions (e.g., [".py", ".ts"])
                               If None, any extension is valid.

        Returns:
            True if no expected_extensions configured, or file matches one
        """
        if not expected_extensions:
            return True

        normalized = filepath.lower()
        return any(normalized.endswith(ext.lower()) for ext in expected_extensions)

    def _validate_deliverables(self, paths: set[str]) -> tuple[set[str], list[str]]:
        """Validate that paths contain meaningful deliverables.

        Args:
            paths: Set of file paths (already filtered for infrastructure)

        Returns:
            Tuple of (valid_paths, validation_warnings)
        """
        config = self._get_validation_config()
        min_size = config["min_file_size"]
        expected_extensions = config["expected_extensions"]

        valid_paths: set[str] = set()
        warnings: list[str] = []
        empty_files: list[str] = []
        wrong_extension_files: list[str] = []

        for path in paths:
            if not self._has_meaningful_content(path, min_size):
                empty_files.append(path)
                continue

            if not self._matches_expected_extensions(path, expected_extensions):
                wrong_extension_files.append(path)
                continue

            valid_paths.add(path)

        if empty_files:
            warnings.append(
                f"{len(empty_files)} file(s) have no meaningful content (<{min_size} bytes): "
                f"{', '.join(empty_files[:3])}{'...' if len(empty_files) > 3 else ''}"
            )

        if wrong_extension_files and expected_extensions:
            warnings.append(
                f"{len(wrong_extension_files)} file(s) don't match expected extensions "
                f"{expected_extensions}: {', '.join(wrong_extension_files[:3])}"
                f"{'...' if len(wrong_extension_files) > 3 else ''}"
            )

        return valid_paths, warnings

    def _count_file_changes(self) -> int:
        """Count files in working directory using FileStateTracker.

        FIX-FILE-TRACKING-001: Uses git-independent file tracking.
        Respects IGNORE_DIRS patterns to exclude infrastructure files.

        Returns:
            Number of trackable files in working directory.
        """
        try:
            files = self._file_tracker.get_all_files()
            file_count = len(files)
            logger.debug(f"FileStateTracker found {file_count} files in {self._working_dir}")
            return file_count
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return 0

    def _get_file_changes(self) -> FileChangeSet:
        """Get file changes using FileStateTracker.

        FIX-FILE-TRACKING-001: Uses git-independent file tracking.
        Note: This method is kept for compatibility but FileChangeTracker.poll()
        is the primary mechanism for detecting file changes during execution.

        Returns:
            FileChangeSet with current file count (no baseline comparison here)
        """
        try:
            files = self._file_tracker.get_all_files()
            # Without a baseline, we can only return count - the FileChangeTracker
            # class handles proper added/modified tracking via its own baseline
            return FileChangeSet(added=set(), modified=set(), count=len(files))
        except OSError as e:
            logger.warning(f"File tracking failed: {e}")
            return FileChangeSet(added=set(), modified=set(), count=0)

    def _count_lines(self, filepath: str) -> int | None:
        """Count lines in a file, handling binary files gracefully."""
        try:
            file_path = self._working_dir / filepath
            with file_path.open(encoding="utf-8") as f:
                return sum(1 for _ in f)
        except UnicodeDecodeError:
            logger.debug(f"Binary file detected: {filepath}")
            return None
        except FileNotFoundError:
            logger.debug(f"File not found: {filepath}")
            return None
        except Exception as e:
            logger.debug(f"Failed to count lines in {filepath}: {e}")
            return None


__all__ = ["FixHandler"]
