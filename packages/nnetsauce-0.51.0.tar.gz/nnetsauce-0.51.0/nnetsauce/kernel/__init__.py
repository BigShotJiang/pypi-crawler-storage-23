from .kernel import KernelRidge

__all__ = ["KernelRidge"]
