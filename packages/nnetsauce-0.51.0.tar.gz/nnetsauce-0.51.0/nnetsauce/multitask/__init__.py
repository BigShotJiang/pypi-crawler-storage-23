from .multitaskClassifier import MultitaskClassifier
from .simplemultitaskClassifier import SimpleMultitaskClassifier

__all__ = ["MultitaskClassifier", "SimpleMultitaskClassifier"]
