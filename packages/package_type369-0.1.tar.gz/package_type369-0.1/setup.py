from setuptools import setup, find_packages

setup(
    name='package_type369',                    # Your package name
    version='0.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='Suraj Khanal',                   # Your name
    author_email='skhanal205@gmail.com',# Your email
    description='A brief description of your package',
    url='https://github.com/surajkhanal369/my_package', # Your project URL
)
