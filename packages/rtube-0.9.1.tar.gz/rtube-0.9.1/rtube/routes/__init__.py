from rtube.routes.videos import videos_bp as videos_bp
from rtube.routes.encoding import encoding_bp as encoding_bp
from rtube.routes.admin import admin_bp as admin_bp
from rtube.routes.playlists import playlists_bp as playlists_bp
