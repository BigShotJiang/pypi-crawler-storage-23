from rtube.__version__ import __version__ as __version__
from rtube.app import create_app

app = create_app()
