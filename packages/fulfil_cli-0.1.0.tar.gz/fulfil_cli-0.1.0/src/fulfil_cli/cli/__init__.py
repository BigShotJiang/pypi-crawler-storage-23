"""CLI entry point."""

from fulfil_cli.cli.app import app


def main() -> None:
    app()
