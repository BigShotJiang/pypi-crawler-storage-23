"""Fulfil CLI — primary interface for humans and AI agents."""

__version__ = "0.1.0"
