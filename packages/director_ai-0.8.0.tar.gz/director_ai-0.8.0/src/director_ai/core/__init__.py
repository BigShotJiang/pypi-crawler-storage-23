# ─────────────────────────────────────────────────────────────────────
# Director-Class AI — Core Package (Coherence Engine)
# (C) 1998-2026 Miroslav Sotek. All rights reserved.
# Contact: www.anulum.li | protoscience@anulum.li
# ORCID: https://orcid.org/0009-0009-3560-0851
# License: GNU AGPL v3 | Commercial licensing available
# ─────────────────────────────────────────────────────────────────────
"""
Coherence Engine — consumer-ready AI output verification.

Quick start::

    from director_ai.core import CoherenceAgent

    agent = CoherenceAgent()
    result = agent.process("What color is the sky?")
    print(result.output, result.coherence)
"""

from .actor import LLMGenerator, MockGenerator
from .agent import CoherenceAgent
from .async_streaming import AsyncStreamingKernel
from .batch import BatchProcessor, BatchResult
from .bridge import PhysicsBackedScorer
from .config import DirectorConfig
from .exceptions import (
    CoherenceError,
    DependencyError,
    DirectorAIError,
    GeneratorError,
    KernelHaltError,
    NumericalError,
    PhysicsError,
    ValidationError,
)
from .kernel import SafetyKernel
from .knowledge import SAMPLE_FACTS, GroundTruthStore
from .metrics import MetricsCollector, metrics
from .nli import NLIScorer
from .scorer import CoherenceScorer
from .streaming import StreamingKernel, StreamSession, TokenEvent
from .types import CoherenceScore, ReviewResult
from .vector_store import (
    ChromaBackend,
    InMemoryBackend,
    VectorBackend,
    VectorGroundTruthStore,
)

__all__ = [
    "CoherenceScore",
    "ReviewResult",
    "CoherenceScorer",
    "SafetyKernel",
    "MockGenerator",
    "LLMGenerator",
    "GroundTruthStore",
    "SAMPLE_FACTS",
    "CoherenceAgent",
    # v0.4.0 additions
    "NLIScorer",
    "VectorGroundTruthStore",
    "VectorBackend",
    "InMemoryBackend",
    "ChromaBackend",
    "StreamingKernel",
    "StreamSession",
    "TokenEvent",
    "PhysicsBackedScorer",
    # v0.5.0 additions
    "AsyncStreamingKernel",
    # v0.6.0 additions
    "DirectorConfig",
    "MetricsCollector",
    "metrics",
    "BatchProcessor",
    "BatchResult",
    # v0.7.1 additions
    "DirectorAIError",
    "CoherenceError",
    "GeneratorError",
    "KernelHaltError",
    "ValidationError",
    "DependencyError",
    "PhysicsError",
    "NumericalError",
]
