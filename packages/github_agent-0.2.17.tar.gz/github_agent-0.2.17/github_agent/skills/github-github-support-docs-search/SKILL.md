---
name: github-github-support-docs-search
description: "Search GitHub documentation to answer support questions. Triggers: Support Docs Agent."
tags: [github-support-docs-search]
---

### Overview
This skill handles operations related to the Support Docs Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Support Docs Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
