---
name: github-issue-opened
description: "Manage GitHub Issues (create, list, update, comment). Triggers: Issues Agent."
tags: [issue-opened]
---

### Overview
This skill handles operations related to the Issues Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Issues Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
