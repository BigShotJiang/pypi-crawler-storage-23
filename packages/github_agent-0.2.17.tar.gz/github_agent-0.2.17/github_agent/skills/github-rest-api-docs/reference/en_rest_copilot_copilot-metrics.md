[Skip to main content](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Copilot](https://docs.github.com/en/rest/copilot "Copilot")/
  * [Copilot metrics](https://docs.github.com/en/rest/copilot/copilot-metrics "Copilot metrics")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
      * [Get Copilot metrics for an organization](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization)
      * [Get Copilot metrics for a team](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team)
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Copilot](https://docs.github.com/en/rest/copilot "Copilot")/
  * [Copilot metrics](https://docs.github.com/en/rest/copilot/copilot-metrics "Copilot metrics")


# REST API endpoints for Copilot metrics
Use the REST API to view Copilot metrics.
These Copilot metrics endpoints will be closing down on April 2, 2026. We recommend using the **Copilot usage metrics** endpoints instead, which provide more depth and flexibility. For more details, see [the GitHub Blog](https://github.blog/changelog/2026-01-29-closing-down-notice-of-legacy-copilot-metrics-apis/).
You can use these endpoints to get a breakdown of aggregated metrics for various GitHub Copilot features. The API includes:
  * Data for the last 100 days
  * Numbers of active users and engaged users
  * Breakdowns by language and IDE
  * The option to view metrics for an enterprise, organization, or team


## [Get Copilot metrics for an organization](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization)
Use this endpoint to see a breakdown of aggregated metrics for various GitHub Copilot features. See the response schema tab for detailed metrics definitions.
This endpoint will only return results for a given day if the organization contained **five or more members with active Copilot licenses** on that day, as evaluated at the end of that day.
The response contains metrics for up to 100 days prior. Metrics are processed once per day for the previous day, and the response will only include data up until yesterday. In order for an end user to be counted towards these metrics, they must have telemetry enabled in their IDE.
To access this endpoint, the Copilot Metrics API access policy must be enabled for the organization. Only organization owners and owners and billing managers of the parent enterprise can view Copilot metrics.
OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot`, `read:org`, or `read:enterprise` scopes to use this endpoint.
### [Fine-grained access tokens for "Get Copilot metrics for an organization"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "GitHub Copilot Business" organization permissions (read)
  * "Administration" organization permissions (read)


### [Parameters for "Get Copilot metrics for an organization"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`since` string Show usage metrics since this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`). Maximum value is 100 days ago.
`until` string Show usage metrics until this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`) and should not preceed the `since` date if it is passed.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of days of metrics to display per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `100`
### [HTTP response status codes for "Get Copilot metrics for an organization"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
`422` | Copilot Usage Merics API setting is disabled at the organization or enterprise level.
`500` | Internal Error
### [Code samples for "Get Copilot metrics for an organization"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/copilot/metrics
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/copilot/metrics`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "date": "2024-06-24",     "total_active_users": 24,     "total_engaged_users": 20,     "copilot_ide_code_completions": {       "total_engaged_users": 20,       "languages": [         {           "name": "python",           "total_engaged_users": 10         },         {           "name": "ruby",           "total_engaged_users": 10         }       ],       "editors": [         {           "name": "vscode",           "total_engaged_users": 13,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_engaged_users": 13,               "languages": [                 {                   "name": "python",                   "total_engaged_users": 6,                   "total_code_suggestions": 249,                   "total_code_acceptances": 123,                   "total_code_lines_suggested": 225,                   "total_code_lines_accepted": 135                 },                 {                   "name": "ruby",                   "total_engaged_users": 7,                   "total_code_suggestions": 496,                   "total_code_acceptances": 253,                   "total_code_lines_suggested": 520,                   "total_code_lines_accepted": 270                 }               ]             }           ]         },         {           "name": "neovim",           "total_engaged_users": 7,           "models": [             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "languages": [                 {                   "name": "typescript",                   "total_engaged_users": 3,                   "total_code_suggestions": 112,                   "total_code_acceptances": 56,                   "total_code_lines_suggested": 143,                   "total_code_lines_accepted": 61                 },                 {                   "name": "go",                   "total_engaged_users": 4,                   "total_code_suggestions": 132,                   "total_code_acceptances": 67,                   "total_code_lines_suggested": 154,                   "total_code_lines_accepted": 72                 }               ]             }           ]         }       ]     },     "copilot_ide_chat": {       "total_engaged_users": 13,       "editors": [         {           "name": "vscode",           "total_engaged_users": 13,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_engaged_users": 12,               "total_chats": 45,               "total_chat_insertion_events": 12,               "total_chat_copy_events": 16             },             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "total_engaged_users": 1,               "total_chats": 10,               "total_chat_insertion_events": 11,               "total_chat_copy_events": 3             }           ]         }       ]     },     "copilot_dotcom_chat": {       "total_engaged_users": 14,       "models": [         {           "name": "default",           "is_custom_model": false,           "custom_model_training_date": null,           "total_engaged_users": 14,           "total_chats": 38         }       ]     },     "copilot_dotcom_pull_requests": {       "total_engaged_users": 12,       "repositories": [         {           "name": "demo/repo1",           "total_engaged_users": 8,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_pr_summaries_created": 6,               "total_engaged_users": 8             }           ]         },         {           "name": "demo/repo2",           "total_engaged_users": 4,           "models": [             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "total_pr_summaries_created": 10,               "total_engaged_users": 4             }           ]         }       ]     }   } ]`
## [Get Copilot metrics for a team](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team)
Use this endpoint to see a breakdown of aggregated metrics for various GitHub Copilot features. See the response schema tab for detailed metrics definitions.
This endpoint will only return results for a given day if the team had **five or more members with active Copilot licenses** on that day, as evaluated at the end of that day.
The response contains metrics for up to 100 days prior. Metrics are processed once per day for the previous day, and the response will only include data up until yesterday. In order for an end user to be counted towards these metrics, they must have telemetry enabled in their IDE.
To access this endpoint, the Copilot Metrics API access policy must be enabled for the organization containing the team within GitHub settings. Only organization owners for the organization that contains this team and owners and billing managers of the parent enterprise can view Copilot metrics for a team.
OAuth app tokens and personal access tokens (classic) need either the `manage_billing:copilot`, `read:org`, or `read:enterprise` scopes to use this endpoint.
### [Fine-grained access tokens for "Get Copilot metrics for a team"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "GitHub Copilot Business" organization permissions (read)
  * "Administration" organization permissions (read)


### [Parameters for "Get Copilot metrics for a team"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
Query parameters Name, Type, Description
---
`since` string Show usage metrics since this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`). Maximum value is 100 days ago.
`until` string Show usage metrics until this date. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format (`YYYY-MM-DDTHH:MM:SSZ`) and should not preceed the `since` date if it is passed.
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of days of metrics to display per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `100`
### [HTTP response status codes for "Get Copilot metrics for a team"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
`422` | Copilot Usage Merics API setting is disabled at the organization or enterprise level.
`500` | Internal Error
### [Code samples for "Get Copilot metrics for a team"](https://docs.github.com/en/rest/copilot/copilot-metrics?apiVersion=2022-11-28#get-copilot-metrics-for-a-team--code-samples)
#### Request example
get/orgs/{org}/team/{team_slug}/copilot/metrics
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/team/TEAM_SLUG/copilot/metrics`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "date": "2024-06-24",     "total_active_users": 24,     "total_engaged_users": 20,     "copilot_ide_code_completions": {       "total_engaged_users": 20,       "languages": [         {           "name": "python",           "total_engaged_users": 10         },         {           "name": "ruby",           "total_engaged_users": 10         }       ],       "editors": [         {           "name": "vscode",           "total_engaged_users": 13,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_engaged_users": 13,               "languages": [                 {                   "name": "python",                   "total_engaged_users": 6,                   "total_code_suggestions": 249,                   "total_code_acceptances": 123,                   "total_code_lines_suggested": 225,                   "total_code_lines_accepted": 135                 },                 {                   "name": "ruby",                   "total_engaged_users": 7,                   "total_code_suggestions": 496,                   "total_code_acceptances": 253,                   "total_code_lines_suggested": 520,                   "total_code_lines_accepted": 270                 }               ]             }           ]         },         {           "name": "neovim",           "total_engaged_users": 7,           "models": [             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "languages": [                 {                   "name": "typescript",                   "total_engaged_users": 3,                   "total_code_suggestions": 112,                   "total_code_acceptances": 56,                   "total_code_lines_suggested": 143,                   "total_code_lines_accepted": 61                 },                 {                   "name": "go",                   "total_engaged_users": 4,                   "total_code_suggestions": 132,                   "total_code_acceptances": 67,                   "total_code_lines_suggested": 154,                   "total_code_lines_accepted": 72                 }               ]             }           ]         }       ]     },     "copilot_ide_chat": {       "total_engaged_users": 13,       "editors": [         {           "name": "vscode",           "total_engaged_users": 13,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_engaged_users": 12,               "total_chats": 45,               "total_chat_insertion_events": 12,               "total_chat_copy_events": 16             },             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "total_engaged_users": 1,               "total_chats": 10,               "total_chat_insertion_events": 11,               "total_chat_copy_events": 3             }           ]         }       ]     },     "copilot_dotcom_chat": {       "total_engaged_users": 14,       "models": [         {           "name": "default",           "is_custom_model": false,           "custom_model_training_date": null,           "total_engaged_users": 14,           "total_chats": 38         }       ]     },     "copilot_dotcom_pull_requests": {       "total_engaged_users": 12,       "repositories": [         {           "name": "demo/repo1",           "total_engaged_users": 8,           "models": [             {               "name": "default",               "is_custom_model": false,               "custom_model_training_date": null,               "total_pr_summaries_created": 6,               "total_engaged_users": 8             }           ]         },         {           "name": "demo/repo2",           "total_engaged_users": 4,           "models": [             {               "name": "a-custom-model",               "is_custom_model": true,               "custom_model_training_date": "2024-02-01",               "total_pr_summaries_created": 10,               "total_engaged_users": 4             }           ]         }       ]     }   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/copilot/copilot-metrics.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for Copilot metrics - GitHub Docs
