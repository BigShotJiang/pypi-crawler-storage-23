[Skip to main content](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Releases](https://docs.github.com/en/rest/releases "Releases")/
  * [Releases](https://docs.github.com/en/rest/releases/releases "Releases")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
      * [List releases](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases)
      * [Create a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release)
      * [Generate release notes content for a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release)
      * [Get the latest release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release)
      * [Get a release by tag name](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name)
      * [Get a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release)
      * [Update a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release)
      * [Delete a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release)
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Releases](https://docs.github.com/en/rest/releases "Releases")/
  * [Releases](https://docs.github.com/en/rest/releases/releases "Releases")


# REST API endpoints for releases
Use the REST API to create, modify, and delete releases.
These endpoints replace the endpoints to manage downloads. You can retrieve the download count and browser download URL from these endpoints.
## [List releases](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases)
This returns a list of releases, which does not include regular Git tags that have not been associated with a release. To get a list of Git tags, use the [Repository Tags API](https://docs.github.com/rest/repos/repos#list-repository-tags).
Information about published releases are available to everyone. Only users with push access will receive listings for draft releases.
### [Fine-grained access tokens for "List releases"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List releases"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List releases"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List releases"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#list-releases--code-samples)
#### Request example
get/repos/{owner}/{repo}/releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",     "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",     "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",     "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",     "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",     "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",     "id": 1,     "node_id": "MDc6UmVsZWFzZTE=",     "tag_name": "v1.0.0",     "target_commitish": "master",     "name": "v1.0.0",     "body": "Description of the release",     "draft": false,     "prerelease": false,     "immutable": false,     "created_at": "2013-02-27T19:35:32Z",     "published_at": "2013-02-27T19:35:32Z",     "author": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "assets": [       {         "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",         "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",         "id": 1,         "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",         "name": "example.zip",         "label": "short description",         "state": "uploaded",         "content_type": "application/zip",         "size": 1024,         "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",         "download_count": 42,         "created_at": "2013-02-27T19:35:32Z",         "updated_at": "2013-02-27T19:35:32Z",         "uploader": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         }       }     ]   } ]`
## [Create a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release)
Users with push access to the repository can create a release.
This endpoint triggers [notifications](https://docs.github.com/github/managing-subscriptions-and-notifications-on-github/about-notifications). Creating content too quickly using this endpoint may result in secondary rate limiting. For more information, see "[Rate limits for the API](https://docs.github.com/rest/using-the-rest-api/rate-limits-for-the-rest-api#about-secondary-rate-limits)" and "[Best practices for using the REST API](https://docs.github.com/rest/guides/best-practices-for-using-the-rest-api)."
### [Fine-grained access tokens for "Create a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Contents" repository permissions (write)
  * "Contents" repository permissions (write) and "Workflows" repository permissions (write)


### [Parameters for "Create a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`tag_name` string Required The name of the tag.
`target_commitish` string Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch.
`name` string The name of the release.
`body` string Text describing the contents of the tag.
`draft` boolean `true` to create a draft (unpublished) release, `false` to create a published one. Default: `false`
`prerelease` boolean `true` to identify the release as a prerelease. `false` to identify the release as a full release. Default: `false`
`discussion_category_name` string If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)."
`generate_release_notes` boolean Whether to automatically generate the name and body for this release. If `name` is specified, the specified name will be used; otherwise, a name will be automatically generated. If `body` is specified, the body will be pre-pended to the automatically generated notes. Default: `false`
`make_latest` string Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. Default: `true` Can be one of: `true`, `false`, `legacy`
### [HTTP response status codes for "Create a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Not Found if the discussion category name is invalid
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#create-a-release--code-samples)
#### Request example
post/repos/{owner}/{repo}/releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases \   -d '{"tag_name":"v1.0.0","target_commitish":"master","name":"v1.0.0","body":"Description of the release","draft":false,"prerelease":false,"generate_release_notes":false}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",   "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",   "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",   "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",   "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",   "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",   "discussion_url": "https://github.com/octocat/Hello-World/discussions/90",   "id": 1,   "node_id": "MDc6UmVsZWFzZTE=",   "tag_name": "v1.0.0",   "target_commitish": "master",   "name": "v1.0.0",   "body": "Description of the release",   "draft": false,   "prerelease": false,   "immutable": false,   "created_at": "2013-02-27T19:35:32Z",   "published_at": "2013-02-27T19:35:32Z",   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "assets": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",       "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",       "id": 1,       "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",       "name": "example.zip",       "label": "short description",       "state": "uploaded",       "content_type": "application/zip",       "size": 1024,       "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",       "download_count": 42,       "created_at": "2013-02-27T19:35:32Z",       "updated_at": "2013-02-27T19:35:32Z",       "uploader": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     }   ] }`
## [Generate release notes content for a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release)
Generate a name and body describing a [release](https://docs.github.com/rest/releases/releases#get-a-release). The body content will be markdown formatted and contain information like the changes since last release and users who contributed. The generated release notes are not saved anywhere. They are intended to be generated and used when creating a new release.
### [Fine-grained access tokens for "Generate release notes content for a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Generate release notes content for a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`tag_name` string Required The tag name for the release. This can be an existing tag or a new one.
`target_commitish` string Specifies the commitish value that will be the target for the release's tag. Required if the supplied tag_name does not reference an existing tag. Ignored if the tag_name already exists.
`previous_tag_name` string The name of the previous tag to use as the starting point for the release notes. Use to manually specify the range for the set of changes considered as part this release.
`configuration_file_path` string Specifies a path to a file in the repository containing configuration settings used for generating the release notes. If unspecified, the configuration file located in the repository at '.github/release.yml' or '.github/release.yaml' will be used. If that is not present, the default configuration will be used.
### [HTTP response status codes for "Generate release notes content for a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release--status-codes)
Status code | Description
---|---
`200` | Name and body of generated release notes
`404` | Resource not found
### [Code samples for "Generate release notes content for a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#generate-release-notes-content-for-a-release--code-samples)
#### Request example
post/repos/{owner}/{repo}/releases/generate-notes
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/generate-notes \   -d '{"tag_name":"v1.0.0","target_commitish":"main","previous_tag_name":"v0.9.2","configuration_file_path":".github/custom_release_config.yml"}'`
Name and body of generated release notes
  * Example response
  * Response schema


`Status: 200`
`{   "name": "Release v1.0.0 is now available!",   "body": "##Changes in Release v1.0.0 ... ##Contributors @monalisa" }`
## [Get the latest release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release)
View the latest published full release for the repository.
The latest release is the most recent non-prerelease, non-draft release, sorted by the `created_at` attribute. The `created_at` attribute is the date of the commit used for the release, and not the date when the release was drafted or published.
### [Fine-grained access tokens for "Get the latest release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get the latest release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get the latest release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get the latest release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-the-latest-release--code-samples)
#### Request example
get/repos/{owner}/{repo}/releases/latest
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/latest`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",   "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",   "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",   "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",   "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",   "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",   "discussion_url": "https://github.com/octocat/Hello-World/discussions/90",   "id": 1,   "node_id": "MDc6UmVsZWFzZTE=",   "tag_name": "v1.0.0",   "target_commitish": "master",   "name": "v1.0.0",   "body": "Description of the release",   "draft": false,   "prerelease": false,   "immutable": false,   "created_at": "2013-02-27T19:35:32Z",   "published_at": "2013-02-27T19:35:32Z",   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "assets": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",       "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",       "id": 1,       "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",       "name": "example.zip",       "label": "short description",       "state": "uploaded",       "content_type": "application/zip",       "size": 1024,       "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",       "download_count": 42,       "created_at": "2013-02-27T19:35:32Z",       "updated_at": "2013-02-27T19:35:32Z",       "uploader": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     }   ] }`
## [Get a release by tag name](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name)
Get a published release with the specified tag.
### [Fine-grained access tokens for "Get a release by tag name"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a release by tag name"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`tag` string Required tag parameter
### [HTTP response status codes for "Get a release by tag name"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a release by tag name"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release-by-tag-name--code-samples)
#### Request example
get/repos/{owner}/{repo}/releases/tags/{tag}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/tags/TAG`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",   "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",   "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",   "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",   "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",   "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",   "discussion_url": "https://github.com/octocat/Hello-World/discussions/90",   "id": 1,   "node_id": "MDc6UmVsZWFzZTE=",   "tag_name": "v1.0.0",   "target_commitish": "master",   "name": "v1.0.0",   "body": "Description of the release",   "draft": false,   "prerelease": false,   "immutable": false,   "created_at": "2013-02-27T19:35:32Z",   "published_at": "2013-02-27T19:35:32Z",   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "assets": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",       "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",       "id": 1,       "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",       "name": "example.zip",       "label": "short description",       "state": "uploaded",       "content_type": "application/zip",       "size": 1024,       "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",       "download_count": 42,       "created_at": "2013-02-27T19:35:32Z",       "updated_at": "2013-02-27T19:35:32Z",       "uploader": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     }   ] }`
## [Get a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release)
Gets a public release with the specified release ID.
This returns an `upload_url` key corresponding to the endpoint for uploading release assets. This key is a hypermedia resource. For more information, see "[Getting started with the REST API](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia)."
### [Fine-grained access tokens for "Get a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`release_id` integer Required The unique identifier of the release.
### [HTTP response status codes for "Get a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release--status-codes)
Status code | Description
---|---
`200` | **Note:** This returns an `upload_url` key corresponding to the endpoint for uploading release assets. This key is a hypermedia resource. For more information, see "[Getting started with the REST API](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia)."
`401` | Unauthorized
### [Code samples for "Get a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#get-a-release--code-samples)
#### Request example
get/repos/{owner}/{repo}/releases/{release_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/RELEASE_ID`
**Note:** This returns an `upload_url` key corresponding to the endpoint for uploading release assets. This key is a hypermedia resource. For more information, see "[Getting started with the REST API](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#hypermedia)."
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",   "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",   "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",   "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",   "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",   "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",   "discussion_url": "https://github.com/octocat/Hello-World/discussions/90",   "id": 1,   "node_id": "MDc6UmVsZWFzZTE=",   "tag_name": "v1.0.0",   "target_commitish": "master",   "name": "v1.0.0",   "body": "Description of the release",   "draft": false,   "prerelease": false,   "immutable": false,   "created_at": "2013-02-27T19:35:32Z",   "published_at": "2013-02-27T19:35:32Z",   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "assets": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",       "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",       "id": 1,       "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",       "name": "example.zip",       "label": "short description",       "state": "uploaded",       "content_type": "application/zip",       "size": 1024,       "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",       "download_count": 42,       "created_at": "2013-02-27T19:35:32Z",       "updated_at": "2013-02-27T19:35:32Z",       "uploader": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     }   ] }`
## [Update a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release)
Users with push access to the repository can edit a release.
### [Fine-grained access tokens for "Update a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Update a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`release_id` integer Required The unique identifier of the release.
Body parameters Name, Type, Description
---
`tag_name` string The name of the tag.
`target_commitish` string Specifies the commitish value that determines where the Git tag is created from. Can be any branch or commit SHA. Unused if the Git tag already exists. Default: the repository's default branch.
`name` string The name of the release.
`body` string Text describing the contents of the tag.
`draft` boolean `true` makes the release a draft, and `false` publishes the release.
`prerelease` boolean `true` to identify the release as a prerelease, `false` to identify the release as a full release.
`make_latest` string Specifies whether this release should be set as the latest release for the repository. Drafts and prereleases cannot be set as latest. Defaults to `true` for newly published releases. `legacy` specifies that the latest release should be determined based on the release creation date and higher semantic version. Default: `true` Can be one of: `true`, `false`, `legacy`
`discussion_category_name` string If specified, a discussion of the specified category is created and linked to the release. The value must be a category that already exists in the repository. If there is already a discussion linked to the release, this parameter is ignored. For more information, see "[Managing categories for discussions in your repository](https://docs.github.com/discussions/managing-discussions-for-your-community/managing-categories-for-discussions-in-your-repository)."
### [HTTP response status codes for "Update a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Not Found if the discussion category name is invalid
### [Code samples for "Update a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#update-a-release--code-samples)
#### Request example
patch/repos/{owner}/{repo}/releases/{release_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/RELEASE_ID \   -d '{"tag_name":"v1.0.0","target_commitish":"master","name":"v1.0.0","body":"Description of the release","draft":false,"prerelease":false}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/releases/1",   "html_url": "https://github.com/octocat/Hello-World/releases/v1.0.0",   "assets_url": "https://api.github.com/repos/octocat/Hello-World/releases/1/assets",   "upload_url": "https://uploads.github.com/repos/octocat/Hello-World/releases/1/assets{?name,label}",   "tarball_url": "https://api.github.com/repos/octocat/Hello-World/tarball/v1.0.0",   "zipball_url": "https://api.github.com/repos/octocat/Hello-World/zipball/v1.0.0",   "discussion_url": "https://github.com/octocat/Hello-World/discussions/90",   "id": 1,   "node_id": "MDc6UmVsZWFzZTE=",   "tag_name": "v1.0.0",   "target_commitish": "master",   "name": "v1.0.0",   "body": "Description of the release",   "draft": false,   "prerelease": false,   "immutable": false,   "created_at": "2013-02-27T19:35:32Z",   "published_at": "2013-02-27T19:35:32Z",   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "assets": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/releases/assets/1",       "browser_download_url": "https://github.com/octocat/Hello-World/releases/download/v1.0.0/example.zip",       "id": 1,       "node_id": "MDEyOlJlbGVhc2VBc3NldDE=",       "name": "example.zip",       "label": "short description",       "state": "uploaded",       "content_type": "application/zip",       "size": 1024,       "digest": "sha256:2151b604e3429bff440b9fbc03eb3617bc2603cda96c95b9bb05277f9ddba255",       "download_count": 42,       "created_at": "2013-02-27T19:35:32Z",       "updated_at": "2013-02-27T19:35:32Z",       "uploader": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       }     }   ] }`
## [Delete a release](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release)
Users with push access to the repository can delete a release.
### [Fine-grained access tokens for "Delete a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Delete a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`release_id` integer Required The unique identifier of the release.
### [HTTP response status codes for "Delete a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete a release"](https://docs.github.com/en/rest/releases/releases?apiVersion=2022-11-28#delete-a-release--code-samples)
#### Request example
delete/repos/{owner}/{repo}/releases/{release_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/releases/RELEASE_ID`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/releases/releases.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for releases - GitHub Docs
