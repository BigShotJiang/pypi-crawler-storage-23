[Skip to main content](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Checks](https://docs.github.com/en/rest/checks "Checks")/
  * [Check suites](https://docs.github.com/en/rest/checks/suites "Check suites")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
      * [Create a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite)
      * [Update repository preferences for check suites](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites)
      * [Get a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite)
      * [Rerequest a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite)
      * [List check suites for a Git reference](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference)
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Checks](https://docs.github.com/en/rest/checks "Checks")/
  * [Check suites](https://docs.github.com/en/rest/checks/suites "Check suites")


# REST API endpoints for check suites
Use the REST API to manage check suites.
Write permission for the REST API to interact with checks is only available to GitHub Apps. OAuth apps and authenticated users can view check runs and check suites, but they are not able to create them. If you aren't building a GitHub App, you might be interested in using the REST API to interact with [commit statuses](https://docs.github.com/en/rest/commits#commit-statuses).
A GitHub App usually only receives one [`check_suite`](https://docs.github.com/en/webhooks-and-events/webhooks/webhook-events-and-payloads#check_suite) event per commit SHA, even if you push the commit SHA to more than one branch. To find out when a commit SHA is pushed to a branch, you can subscribe to branch [`create`](https://docs.github.com/en/webhooks-and-events/webhooks/webhook-events-and-payloads#create) events.
## [Create a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite)
Creates a check suite manually. By default, check suites are automatically created when you create a [check run](https://docs.github.com/rest/checks/runs). You only need to use this endpoint for manually creating check suites when you've disabled automatic creation using "[Update repository preferences for check suites](https://docs.github.com/rest/checks/suites#update-repository-preferences-for-check-suites)".
The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`.
OAuth apps and personal access tokens (classic) cannot use this endpoint.
### [Fine-grained access tokens for "Create a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Create a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`head_sha` string Required The sha of the head commit.
### [HTTP response status codes for "Create a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite--status-codes)
Status code | Description
---|---
`200` | Response when the suite already exists
`201` | Response when the suite was created
### [Code samples for "Create a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#create-a-check-suite--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 201
post/repos/{owner}/{repo}/check-suites
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-suites \   -d '{"head_sha":"d6fde92930d4715a2b49857d24b940956b26d2d3"}'`
Response when the suite already exists
  * Example response
  * Response schema


`Status: 200`
`{   "id": 5,   "node_id": "MDEwOkNoZWNrU3VpdGU1",   "head_branch": "master",   "head_sha": "d6fde92930d4715a2b49857d24b940956b26d2d3",   "status": "completed",   "conclusion": "neutral",   "url": "https://api.github.com/repos/github/hello-world/check-suites/5",   "before": "146e867f55c26428e5f9fade55a9bbf5e95a7912",   "after": "d6fde92930d4715a2b49857d24b940956b26d2d3",   "pull_requests": [],   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "app": {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   },   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "template_repository": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World-Template",       "full_name": "octocat/Hello-World-Template",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World-Template",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World-Template",       "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World-Template.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World-Template.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World-Template.git",       "mirror_url": "git:git.example.com/octocat/Hello-World-Template",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World-Template",       "homepage": "https://github.com",       "language": null,       "forks": 9,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "watchers": 80,       "size": 108,       "default_branch": "master",       "open_issues": 0,       "open_issues_count": 0,       "is_template": true,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://api.github.com/licenses/mit"       },       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0     },     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "delete_branch_on_merge": true,     "subscribers_count": 42,     "network_count": 0   },   "head_commit": {     "id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",     "tree_id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",     "message": "Merge pull request #6 from Spaceghost/patch-1\n\nNew line at end of file.",     "timestamp": "2016-10-10T00:00:00Z",     "author": {       "name": "The Octocat",       "email": "octocat@nowhere.com"     },     "committer": {       "name": "The Octocat",       "email": "octocat@nowhere.com"     }   },   "latest_check_runs_count": 1,   "check_runs_url": "https://api.github.com/repos/octocat/Hello-World/check-suites/5/check-runs" }`
## [Update repository preferences for check suites](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites)
Changes the default automatic flow when creating check suites. By default, a check suite is automatically created each time code is pushed to a repository. When you disable the automatic creation of check suites, you can manually [Create a check suite](https://docs.github.com/rest/checks/suites#create-a-check-suite). You must have admin permissions in the repository to set preferences for check suites.
### [Fine-grained access tokens for "Update repository preferences for check suites"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Update repository preferences for check suites"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`auto_trigger_checks` array of objects Enables or disables automatic creation of CheckSuite events upon pushes to the repository. Enabled by default.
Properties of `auto_trigger_checks` | Name, Type, Description
---
`app_id` integer Required The `id` of the GitHub App.
`setting` boolean Required Set to `true` to enable automatic creation of CheckSuite events upon pushes to the repository, or `false` to disable them. Default: `true`
### [HTTP response status codes for "Update repository preferences for check suites"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Update repository preferences for check suites"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#update-repository-preferences-for-check-suites--code-samples)
#### Request example
patch/repos/{owner}/{repo}/check-suites/preferences
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-suites/preferences \   -d '{"auto_trigger_checks":[{"app_id":4,"setting":false}]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "preferences": {     "auto_trigger_checks": [       {         "app_id": 2,         "setting": true       },       {         "app_id": 4,         "setting": false       }     ]   },   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "template_repository": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World-Template",       "full_name": "octocat/Hello-World-Template",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World-Template",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World-Template",       "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World-Template.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World-Template.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World-Template.git",       "mirror_url": "git:git.example.com/octocat/Hello-World-Template",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World-Template",       "homepage": "https://github.com",       "language": null,       "forks": 9,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "watchers": 80,       "size": 108,       "default_branch": "master",       "open_issues": 0,       "open_issues_count": 0,       "is_template": true,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://api.github.com/licenses/mit"       },       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0     }   } }`
## [Get a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite)
Gets a single check suite using its `id`.
The Checks API only looks for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "Get a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_suite_id` integer Required The unique identifier of the check suite.
### [HTTP response status codes for "Get a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#get-a-check-suite--code-samples)
#### Request example
get/repos/{owner}/{repo}/check-suites/{check_suite_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-suites/CHECK_SUITE_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 5,   "node_id": "MDEwOkNoZWNrU3VpdGU1",   "head_branch": "master",   "head_sha": "d6fde92930d4715a2b49857d24b940956b26d2d3",   "status": "completed",   "conclusion": "neutral",   "url": "https://api.github.com/repos/github/hello-world/check-suites/5",   "before": "146e867f55c26428e5f9fade55a9bbf5e95a7912",   "after": "d6fde92930d4715a2b49857d24b940956b26d2d3",   "pull_requests": [],   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "app": {     "id": 1,     "slug": "octoapp",     "node_id": "MDExOkludGVncmF0aW9uMQ==",     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "name": "Octocat App",     "description": "",     "external_url": "https://example.com",     "html_url": "https://github.com/apps/octoapp",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "permissions": {       "metadata": "read",       "contents": "read",       "issues": "write",       "single_file": "write"     },     "events": [       "push",       "pull_request"     ]   },   "repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "template_repository": {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World-Template",       "full_name": "octocat/Hello-World-Template",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World-Template",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World-Template",       "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World-Template.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World-Template.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World-Template.git",       "mirror_url": "git:git.example.com/octocat/Hello-World-Template",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World-Template",       "homepage": "https://github.com",       "language": null,       "forks": 9,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "watchers": 80,       "size": 108,       "default_branch": "master",       "open_issues": 0,       "open_issues_count": 0,       "is_template": true,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://api.github.com/licenses/mit"       },       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0     },     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "delete_branch_on_merge": true,     "subscribers_count": 42,     "network_count": 0   },   "head_commit": {     "id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",     "tree_id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",     "message": "Merge pull request #6 from Spaceghost/patch-1\n\nNew line at end of file.",     "timestamp": "2016-10-10T00:00:00Z",     "author": {       "name": "The Octocat",       "email": "octocat@nowhere.com"     },     "committer": {       "name": "The Octocat",       "email": "octocat@nowhere.com"     }   },   "latest_check_runs_count": 1,   "check_runs_url": "https://api.github.com/repos/octocat/Hello-World/check-suites/5/check-runs" }`
## [Rerequest a check suite](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite)
Triggers GitHub to rerequest an existing check suite, without pushing new code to a repository. This endpoint will trigger the [`check_suite` webhook](https://docs.github.com/webhooks/event-payloads/#check_suite) event with the action `rerequested`. When a check suite is `rerequested`, its `status` is reset to `queued` and the `conclusion` is cleared.
### [Fine-grained access tokens for "Rerequest a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (write)


### [Parameters for "Rerequest a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`check_suite_id` integer Required The unique identifier of the check suite.
### [HTTP response status codes for "Rerequest a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Rerequest a check suite"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#rerequest-a-check-suite--code-samples)
#### Request example
post/repos/{owner}/{repo}/check-suites/{check_suite_id}/rerequest
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/check-suites/CHECK_SUITE_ID/rerequest`
Response
  * Example response
  * Response schema


`Status: 201`
## [List check suites for a Git reference](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference)
Lists check suites for a commit `ref`. The `ref` can be a SHA, branch name, or a tag name.
The endpoints to manage checks only look for pushes in the repository where the check suite or check run were created. Pushes to a branch in a forked repository are not detected and return an empty `pull_requests` array and a `null` value for `head_branch`.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint on a private repository.
### [Fine-grained access tokens for "List check suites for a Git reference"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Checks" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List check suites for a Git reference"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ref` string Required The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
Query parameters Name, Type, Description
---
`app_id` integer Filters check suites by GitHub App `id`.
`check_name` string Returns check runs with the specified `name`.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List check suites for a Git reference"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List check suites for a Git reference"](https://docs.github.com/en/rest/checks/suites?apiVersion=2022-11-28#list-check-suites-for-a-git-reference--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits/{ref}/check-suites
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits/REF/check-suites`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 1,   "check_suites": [     {       "id": 5,       "node_id": "MDEwOkNoZWNrU3VpdGU1",       "head_branch": "master",       "head_sha": "d6fde92930d4715a2b49857d24b940956b26d2d3",       "status": "completed",       "conclusion": "neutral",       "url": "https://api.github.com/repos/github/hello-world/check-suites/5",       "before": "146e867f55c26428e5f9fade55a9bbf5e95a7912",       "after": "d6fde92930d4715a2b49857d24b940956b26d2d3",       "pull_requests": [],       "app": {         "id": 1,         "slug": "octoapp",         "node_id": "MDExOkludGVncmF0aW9uMQ==",         "owner": {           "login": "github",           "id": 1,           "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",           "url": "https://api.github.com/orgs/github",           "repos_url": "https://api.github.com/orgs/github/repos",           "events_url": "https://api.github.com/orgs/github/events",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": true         },         "name": "Octocat App",         "description": "",         "external_url": "https://example.com",         "html_url": "https://github.com/apps/octoapp",         "created_at": "2017-07-08T16:18:44-04:00",         "updated_at": "2017-07-08T16:18:44-04:00",         "permissions": {           "metadata": "read",           "contents": "read",           "issues": "write",           "single_file": "write"         },         "events": [           "push",           "pull_request"         ]       },       "repository": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "clone_url": "https://github.com/octocat/Hello-World.git",         "mirror_url": "git:git.example.com/octocat/Hello-World",         "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",         "svn_url": "https://svn.github.com/octocat/Hello-World",         "homepage": "https://github.com",         "language": null,         "forks_count": 9,         "stargazers_count": 80,         "watchers_count": 80,         "size": 108,         "default_branch": "master",         "open_issues_count": 0,         "is_template": true,         "topics": [           "octocat",           "atom",           "electron",           "api"         ],         "has_issues": true,         "has_projects": true,         "has_wiki": true,         "has_pages": false,         "has_downloads": true,         "archived": false,         "disabled": false,         "visibility": "public",         "pushed_at": "2011-01-26T19:06:43Z",         "created_at": "2011-01-26T19:01:12Z",         "updated_at": "2011-01-26T19:14:43Z",         "permissions": {           "admin": false,           "push": false,           "pull": true         },         "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",         "delete_branch_on_merge": true,         "subscribers_count": 42,         "network_count": 0       },       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "head_commit": {         "id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",         "tree_id": "7fd1a60b01f91b314f59955a4e4d4e80d8edf11d",         "message": "Merge pull request #6 from Spaceghost/patch-1\n\nNew line at end of file.",         "timestamp": "2016-10-10T00:00:00Z",         "author": {           "name": "The Octocat",           "email": "octocat@nowhere.com"         },         "committer": {           "name": "The Octocat",           "email": "octocat@nowhere.com"         }       },       "latest_check_runs_count": 1,       "check_runs_url": "https://api.github.com/repos/octocat/Hello-World/check-suites/5/check-runs"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/checks/suites.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for check suites - GitHub Docs
