[Skip to main content](https://docs.github.com/en/rest/actions?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")


# REST API endpoints for GitHub Actions
Use the REST API to interact with GitHub Actions for an organization or repository.
  * [REST API endpoints for GitHub Actions artifacts](https://docs.github.com/en/rest/actions/artifacts)
    * [List artifacts for a repository](https://docs.github.com/en/rest/actions/artifacts#list-artifacts-for-a-repository)
    * [Get an artifact](https://docs.github.com/en/rest/actions/artifacts#get-an-artifact)
    * [Delete an artifact](https://docs.github.com/en/rest/actions/artifacts#delete-an-artifact)
    * [Download an artifact](https://docs.github.com/en/rest/actions/artifacts#download-an-artifact)
    * [List workflow run artifacts](https://docs.github.com/en/rest/actions/artifacts#list-workflow-run-artifacts)
  * [REST API endpoints for GitHub Actions cache](https://docs.github.com/en/rest/actions/cache)
    * [Get GitHub Actions cache retention limit for an enterprise](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-retention-limit-for-an-enterprise)
    * [Set GitHub Actions cache retention limit for an enterprise](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-retention-limit-for-an-enterprise)
    * [Get GitHub Actions cache storage limit for an enterprise](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-storage-limit-for-an-enterprise)
    * [Set GitHub Actions cache storage limit for an enterprise](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-storage-limit-for-an-enterprise)
    * [Get GitHub Actions cache retention limit for an organization](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-retention-limit-for-an-organization)
    * [Set GitHub Actions cache retention limit for an organization](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-retention-limit-for-an-organization)
    * [Get GitHub Actions cache storage limit for an organization](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-storage-limit-for-an-organization)
    * [Set GitHub Actions cache storage limit for an organization](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-storage-limit-for-an-organization)
    * [Get GitHub Actions cache usage for an organization](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-usage-for-an-organization)
    * [List repositories with GitHub Actions cache usage for an organization](https://docs.github.com/en/rest/actions/cache#list-repositories-with-github-actions-cache-usage-for-an-organization)
    * [Get GitHub Actions cache retention limit for a repository](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-retention-limit-for-a-repository)
    * [Set GitHub Actions cache retention limit for a repository](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-retention-limit-for-a-repository)
    * [Get GitHub Actions cache storage limit for a repository](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-storage-limit-for-a-repository)
    * [Set GitHub Actions cache storage limit for a repository](https://docs.github.com/en/rest/actions/cache#set-github-actions-cache-storage-limit-for-a-repository)
    * [Get GitHub Actions cache usage for a repository](https://docs.github.com/en/rest/actions/cache#get-github-actions-cache-usage-for-a-repository)
    * [List GitHub Actions caches for a repository](https://docs.github.com/en/rest/actions/cache#list-github-actions-caches-for-a-repository)
    * [Delete GitHub Actions caches for a repository (using a cache key)](https://docs.github.com/en/rest/actions/cache#delete-github-actions-caches-for-a-repository-using-a-cache-key)
    * [Delete a GitHub Actions cache for a repository (using a cache ID)](https://docs.github.com/en/rest/actions/cache#delete-a-github-actions-cache-for-a-repository-using-a-cache-id)
  * [GitHub-hosted runners](https://docs.github.com/en/rest/actions/hosted-runners)
    * [List GitHub-hosted runners for an organization](https://docs.github.com/en/rest/actions/hosted-runners#list-github-hosted-runners-for-an-organization)
    * [Create a GitHub-hosted runner for an organization](https://docs.github.com/en/rest/actions/hosted-runners#create-a-github-hosted-runner-for-an-organization)
    * [List custom images for an organization](https://docs.github.com/en/rest/actions/hosted-runners#list-custom-images-for-an-organization)
    * [Get a custom image definition for GitHub Actions Hosted Runners](https://docs.github.com/en/rest/actions/hosted-runners#get-a-custom-image-definition-for-github-actions-hosted-runners)
    * [Delete a custom image from the organization](https://docs.github.com/en/rest/actions/hosted-runners#delete-a-custom-image-from-the-organization)
    * [List image versions of a custom image for an organization](https://docs.github.com/en/rest/actions/hosted-runners#list-image-versions-of-a-custom-image-for-an-organization)
    * [Get an image version of a custom image for GitHub Actions Hosted Runners](https://docs.github.com/en/rest/actions/hosted-runners#get-an-image-version-of-a-custom-image-for-github-actions-hosted-runners)
    * [Delete an image version of custom image from the organization](https://docs.github.com/en/rest/actions/hosted-runners#delete-an-image-version-of-custom-image-from-the-organization)
    * [Get GitHub-owned images for GitHub-hosted runners in an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-github-owned-images-for-github-hosted-runners-in-an-organization)
    * [Get partner images for GitHub-hosted runners in an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-partner-images-for-github-hosted-runners-in-an-organization)
    * [Get limits on GitHub-hosted runners for an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-limits-on-github-hosted-runners-for-an-organization)
    * [Get GitHub-hosted runners machine specs for an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-github-hosted-runners-machine-specs-for-an-organization)
    * [Get platforms for GitHub-hosted runners in an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-platforms-for-github-hosted-runners-in-an-organization)
    * [Get a GitHub-hosted runner for an organization](https://docs.github.com/en/rest/actions/hosted-runners#get-a-github-hosted-runner-for-an-organization)
    * [Update a GitHub-hosted runner for an organization](https://docs.github.com/en/rest/actions/hosted-runners#update-a-github-hosted-runner-for-an-organization)
    * [Delete a GitHub-hosted runner for an organization](https://docs.github.com/en/rest/actions/hosted-runners#delete-a-github-hosted-runner-for-an-organization)
  * [REST API endpoints for GitHub Actions OIDC](https://docs.github.com/en/rest/actions/oidc)
    * [Get the customization template for an OIDC subject claim for an organization](https://docs.github.com/en/rest/actions/oidc#get-the-customization-template-for-an-oidc-subject-claim-for-an-organization)
    * [Set the customization template for an OIDC subject claim for an organization](https://docs.github.com/en/rest/actions/oidc#set-the-customization-template-for-an-oidc-subject-claim-for-an-organization)
    * [Get the customization template for an OIDC subject claim for a repository](https://docs.github.com/en/rest/actions/oidc#get-the-customization-template-for-an-oidc-subject-claim-for-a-repository)
    * [Set the customization template for an OIDC subject claim for a repository](https://docs.github.com/en/rest/actions/oidc#set-the-customization-template-for-an-oidc-subject-claim-for-a-repository)
  * [REST API endpoints for GitHub Actions permissions](https://docs.github.com/en/rest/actions/permissions)
    * [Get GitHub Actions permissions for an organization](https://docs.github.com/en/rest/actions/permissions#get-github-actions-permissions-for-an-organization)
    * [Set GitHub Actions permissions for an organization](https://docs.github.com/en/rest/actions/permissions#set-github-actions-permissions-for-an-organization)
    * [Get artifact and log retention settings for an organization](https://docs.github.com/en/rest/actions/permissions#get-artifact-and-log-retention-settings-for-an-organization)
    * [Set artifact and log retention settings for an organization](https://docs.github.com/en/rest/actions/permissions#set-artifact-and-log-retention-settings-for-an-organization)
    * [Get fork PR contributor approval permissions for an organization](https://docs.github.com/en/rest/actions/permissions#get-fork-pr-contributor-approval-permissions-for-an-organization)
    * [Set fork PR contributor approval permissions for an organization](https://docs.github.com/en/rest/actions/permissions#set-fork-pr-contributor-approval-permissions-for-an-organization)
    * [Get private repo fork PR workflow settings for an organization](https://docs.github.com/en/rest/actions/permissions#get-private-repo-fork-pr-workflow-settings-for-an-organization)
    * [Set private repo fork PR workflow settings for an organization](https://docs.github.com/en/rest/actions/permissions#set-private-repo-fork-pr-workflow-settings-for-an-organization)
    * [List selected repositories enabled for GitHub Actions in an organization](https://docs.github.com/en/rest/actions/permissions#list-selected-repositories-enabled-for-github-actions-in-an-organization)
    * [Set selected repositories enabled for GitHub Actions in an organization](https://docs.github.com/en/rest/actions/permissions#set-selected-repositories-enabled-for-github-actions-in-an-organization)
    * [Enable a selected repository for GitHub Actions in an organization](https://docs.github.com/en/rest/actions/permissions#enable-a-selected-repository-for-github-actions-in-an-organization)
    * [Disable a selected repository for GitHub Actions in an organization](https://docs.github.com/en/rest/actions/permissions#disable-a-selected-repository-for-github-actions-in-an-organization)
    * [Get allowed actions and reusable workflows for an organization](https://docs.github.com/en/rest/actions/permissions#get-allowed-actions-and-reusable-workflows-for-an-organization)
    * [Set allowed actions and reusable workflows for an organization](https://docs.github.com/en/rest/actions/permissions#set-allowed-actions-and-reusable-workflows-for-an-organization)
    * [Get self-hosted runners settings for an organization](https://docs.github.com/en/rest/actions/permissions#get-self-hosted-runners-settings-for-an-organization)
    * [Set self-hosted runners settings for an organization](https://docs.github.com/en/rest/actions/permissions#set-self-hosted-runners-settings-for-an-organization)
    * [List repositories allowed to use self-hosted runners in an organization](https://docs.github.com/en/rest/actions/permissions#list-repositories-allowed-to-use-self-hosted-runners-in-an-organization)
    * [Set repositories allowed to use self-hosted runners in an organization](https://docs.github.com/en/rest/actions/permissions#set-repositories-allowed-to-use-self-hosted-runners-in-an-organization)
    * [Add a repository to the list of repositories allowed to use self-hosted runners in an organization](https://docs.github.com/en/rest/actions/permissions#add-a-repository-to-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization)
    * [Remove a repository from the list of repositories allowed to use self-hosted runners in an organization](https://docs.github.com/en/rest/actions/permissions#remove-a-repository-from-the-list-of-repositories-allowed-to-use-self-hosted-runners-in-an-organization)
    * [Get default workflow permissions for an organization](https://docs.github.com/en/rest/actions/permissions#get-default-workflow-permissions-for-an-organization)
    * [Set default workflow permissions for an organization](https://docs.github.com/en/rest/actions/permissions#set-default-workflow-permissions-for-an-organization)
    * [Get GitHub Actions permissions for a repository](https://docs.github.com/en/rest/actions/permissions#get-github-actions-permissions-for-a-repository)
    * [Set GitHub Actions permissions for a repository](https://docs.github.com/en/rest/actions/permissions#set-github-actions-permissions-for-a-repository)
    * [Get the level of access for workflows outside of the repository](https://docs.github.com/en/rest/actions/permissions#get-the-level-of-access-for-workflows-outside-of-the-repository)
    * [Set the level of access for workflows outside of the repository](https://docs.github.com/en/rest/actions/permissions#set-the-level-of-access-for-workflows-outside-of-the-repository)
    * [Get artifact and log retention settings for a repository](https://docs.github.com/en/rest/actions/permissions#get-artifact-and-log-retention-settings-for-a-repository)
    * [Set artifact and log retention settings for a repository](https://docs.github.com/en/rest/actions/permissions#set-artifact-and-log-retention-settings-for-a-repository)
    * [Get fork PR contributor approval permissions for a repository](https://docs.github.com/en/rest/actions/permissions#get-fork-pr-contributor-approval-permissions-for-a-repository)
    * [Set fork PR contributor approval permissions for a repository](https://docs.github.com/en/rest/actions/permissions#set-fork-pr-contributor-approval-permissions-for-a-repository)
    * [Get private repo fork PR workflow settings for a repository](https://docs.github.com/en/rest/actions/permissions#get-private-repo-fork-pr-workflow-settings-for-a-repository)
    * [Set private repo fork PR workflow settings for a repository](https://docs.github.com/en/rest/actions/permissions#set-private-repo-fork-pr-workflow-settings-for-a-repository)
    * [Get allowed actions and reusable workflows for a repository](https://docs.github.com/en/rest/actions/permissions#get-allowed-actions-and-reusable-workflows-for-a-repository)
    * [Set allowed actions and reusable workflows for a repository](https://docs.github.com/en/rest/actions/permissions#set-allowed-actions-and-reusable-workflows-for-a-repository)
    * [Get default workflow permissions for a repository](https://docs.github.com/en/rest/actions/permissions#get-default-workflow-permissions-for-a-repository)
    * [Set default workflow permissions for a repository](https://docs.github.com/en/rest/actions/permissions#set-default-workflow-permissions-for-a-repository)
  * [REST API endpoints for GitHub Actions Secrets](https://docs.github.com/en/rest/actions/secrets)
    * [List organization secrets](https://docs.github.com/en/rest/actions/secrets#list-organization-secrets)
    * [Get an organization public key](https://docs.github.com/en/rest/actions/secrets#get-an-organization-public-key)
    * [Get an organization secret](https://docs.github.com/en/rest/actions/secrets#get-an-organization-secret)
    * [Create or update an organization secret](https://docs.github.com/en/rest/actions/secrets#create-or-update-an-organization-secret)
    * [Delete an organization secret](https://docs.github.com/en/rest/actions/secrets#delete-an-organization-secret)
    * [List selected repositories for an organization secret](https://docs.github.com/en/rest/actions/secrets#list-selected-repositories-for-an-organization-secret)
    * [Set selected repositories for an organization secret](https://docs.github.com/en/rest/actions/secrets#set-selected-repositories-for-an-organization-secret)
    * [Add selected repository to an organization secret](https://docs.github.com/en/rest/actions/secrets#add-selected-repository-to-an-organization-secret)
    * [Remove selected repository from an organization secret](https://docs.github.com/en/rest/actions/secrets#remove-selected-repository-from-an-organization-secret)
    * [List repository organization secrets](https://docs.github.com/en/rest/actions/secrets#list-repository-organization-secrets)
    * [List repository secrets](https://docs.github.com/en/rest/actions/secrets#list-repository-secrets)
    * [Get a repository public key](https://docs.github.com/en/rest/actions/secrets#get-a-repository-public-key)
    * [Get a repository secret](https://docs.github.com/en/rest/actions/secrets#get-a-repository-secret)
    * [Create or update a repository secret](https://docs.github.com/en/rest/actions/secrets#create-or-update-a-repository-secret)
    * [Delete a repository secret](https://docs.github.com/en/rest/actions/secrets#delete-a-repository-secret)
    * [List environment secrets](https://docs.github.com/en/rest/actions/secrets#list-environment-secrets)
    * [Get an environment public key](https://docs.github.com/en/rest/actions/secrets#get-an-environment-public-key)
    * [Get an environment secret](https://docs.github.com/en/rest/actions/secrets#get-an-environment-secret)
    * [Create or update an environment secret](https://docs.github.com/en/rest/actions/secrets#create-or-update-an-environment-secret)
    * [Delete an environment secret](https://docs.github.com/en/rest/actions/secrets#delete-an-environment-secret)
  * [REST API endpoints for self-hosted runner groups](https://docs.github.com/en/rest/actions/self-hosted-runner-groups)
    * [List self-hosted runner groups for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-self-hosted-runner-groups-for-an-organization)
    * [Create a self-hosted runner group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#create-a-self-hosted-runner-group-for-an-organization)
    * [Get a self-hosted runner group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#get-a-self-hosted-runner-group-for-an-organization)
    * [Update a self-hosted runner group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#update-a-self-hosted-runner-group-for-an-organization)
    * [Delete a self-hosted runner group from an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#delete-a-self-hosted-runner-group-from-an-organization)
    * [List GitHub-hosted runners in a group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-github-hosted-runners-in-a-group-for-an-organization)
    * [List repository access to a self-hosted runner group in an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-repository-access-to-a-self-hosted-runner-group-in-an-organization)
    * [Set repository access for a self-hosted runner group in an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#set-repository-access-for-a-self-hosted-runner-group-in-an-organization)
    * [Add repository access to a self-hosted runner group in an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#add-repository-access-to-a-self-hosted-runner-group-in-an-organization)
    * [Remove repository access to a self-hosted runner group in an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#remove-repository-access-to-a-self-hosted-runner-group-in-an-organization)
    * [List self-hosted runners in a group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#list-self-hosted-runners-in-a-group-for-an-organization)
    * [Set self-hosted runners in a group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#set-self-hosted-runners-in-a-group-for-an-organization)
    * [Add a self-hosted runner to a group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#add-a-self-hosted-runner-to-a-group-for-an-organization)
    * [Remove a self-hosted runner from a group for an organization](https://docs.github.com/en/rest/actions/self-hosted-runner-groups#remove-a-self-hosted-runner-from-a-group-for-an-organization)
  * [REST API endpoints for self-hosted runners](https://docs.github.com/en/rest/actions/self-hosted-runners)
    * [List self-hosted runners for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#list-self-hosted-runners-for-an-organization)
    * [List runner applications for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#list-runner-applications-for-an-organization)
    * [Create configuration for a just-in-time runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#create-configuration-for-a-just-in-time-runner-for-an-organization)
    * [Create a registration token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-registration-token-for-an-organization)
    * [Create a remove token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-remove-token-for-an-organization)
    * [Get a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#get-a-self-hosted-runner-for-an-organization)
    * [Delete a self-hosted runner from an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#delete-a-self-hosted-runner-from-an-organization)
    * [List labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#list-labels-for-a-self-hosted-runner-for-an-organization)
    * [Add custom labels to a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#add-custom-labels-to-a-self-hosted-runner-for-an-organization)
    * [Set custom labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#set-custom-labels-for-a-self-hosted-runner-for-an-organization)
    * [Remove all custom labels from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization)
    * [Remove a custom label from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization)
    * [List self-hosted runners for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#list-self-hosted-runners-for-a-repository)
    * [List runner applications for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#list-runner-applications-for-a-repository)
    * [Create configuration for a just-in-time runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#create-configuration-for-a-just-in-time-runner-for-a-repository)
    * [Create a registration token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-registration-token-for-a-repository)
    * [Create a remove token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#create-a-remove-token-for-a-repository)
    * [Get a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#get-a-self-hosted-runner-for-a-repository)
    * [Delete a self-hosted runner from a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#delete-a-self-hosted-runner-from-a-repository)
    * [List labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#list-labels-for-a-self-hosted-runner-for-a-repository)
    * [Add custom labels to a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#add-custom-labels-to-a-self-hosted-runner-for-a-repository)
    * [Set custom labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#set-custom-labels-for-a-self-hosted-runner-for-a-repository)
    * [Remove all custom labels from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository)
    * [Remove a custom label from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository)
  * [REST API endpoints for GitHub Actions variables](https://docs.github.com/en/rest/actions/variables)
    * [List organization variables](https://docs.github.com/en/rest/actions/variables#list-organization-variables)
    * [Create an organization variable](https://docs.github.com/en/rest/actions/variables#create-an-organization-variable)
    * [Get an organization variable](https://docs.github.com/en/rest/actions/variables#get-an-organization-variable)
    * [Update an organization variable](https://docs.github.com/en/rest/actions/variables#update-an-organization-variable)
    * [Delete an organization variable](https://docs.github.com/en/rest/actions/variables#delete-an-organization-variable)
    * [List selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables#list-selected-repositories-for-an-organization-variable)
    * [Set selected repositories for an organization variable](https://docs.github.com/en/rest/actions/variables#set-selected-repositories-for-an-organization-variable)
    * [Add selected repository to an organization variable](https://docs.github.com/en/rest/actions/variables#add-selected-repository-to-an-organization-variable)
    * [Remove selected repository from an organization variable](https://docs.github.com/en/rest/actions/variables#remove-selected-repository-from-an-organization-variable)
    * [List repository organization variables](https://docs.github.com/en/rest/actions/variables#list-repository-organization-variables)
    * [List repository variables](https://docs.github.com/en/rest/actions/variables#list-repository-variables)
    * [Create a repository variable](https://docs.github.com/en/rest/actions/variables#create-a-repository-variable)
    * [Get a repository variable](https://docs.github.com/en/rest/actions/variables#get-a-repository-variable)
    * [Update a repository variable](https://docs.github.com/en/rest/actions/variables#update-a-repository-variable)
    * [Delete a repository variable](https://docs.github.com/en/rest/actions/variables#delete-a-repository-variable)
    * [List environment variables](https://docs.github.com/en/rest/actions/variables#list-environment-variables)
    * [Create an environment variable](https://docs.github.com/en/rest/actions/variables#create-an-environment-variable)
    * [Get an environment variable](https://docs.github.com/en/rest/actions/variables#get-an-environment-variable)
    * [Update an environment variable](https://docs.github.com/en/rest/actions/variables#update-an-environment-variable)
    * [Delete an environment variable](https://docs.github.com/en/rest/actions/variables#delete-an-environment-variable)
  * [REST API endpoints for workflow jobs](https://docs.github.com/en/rest/actions/workflow-jobs)
    * [Get a job for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs#get-a-job-for-a-workflow-run)
    * [Download job logs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs#download-job-logs-for-a-workflow-run)
    * [List jobs for a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-jobs#list-jobs-for-a-workflow-run-attempt)
    * [List jobs for a workflow run](https://docs.github.com/en/rest/actions/workflow-jobs#list-jobs-for-a-workflow-run)
  * [REST API endpoints for workflow runs](https://docs.github.com/en/rest/actions/workflow-runs)
    * [Re-run a job from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#re-run-a-job-from-a-workflow-run)
    * [List workflow runs for a repository](https://docs.github.com/en/rest/actions/workflow-runs#list-workflow-runs-for-a-repository)
    * [Get a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#get-a-workflow-run)
    * [Delete a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#delete-a-workflow-run)
    * [Get the review history for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#get-the-review-history-for-a-workflow-run)
    * [Approve a workflow run for a fork pull request](https://docs.github.com/en/rest/actions/workflow-runs#approve-a-workflow-run-for-a-fork-pull-request)
    * [Get a workflow run attempt](https://docs.github.com/en/rest/actions/workflow-runs#get-a-workflow-run-attempt)
    * [Download workflow run attempt logs](https://docs.github.com/en/rest/actions/workflow-runs#download-workflow-run-attempt-logs)
    * [Cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#cancel-a-workflow-run)
    * [Review custom deployment protection rules for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#review-custom-deployment-protection-rules-for-a-workflow-run)
    * [Force cancel a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#force-cancel-a-workflow-run)
    * [Download workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs#download-workflow-run-logs)
    * [Delete workflow run logs](https://docs.github.com/en/rest/actions/workflow-runs#delete-workflow-run-logs)
    * [Get pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#get-pending-deployments-for-a-workflow-run)
    * [Review pending deployments for a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#review-pending-deployments-for-a-workflow-run)
    * [Re-run a workflow](https://docs.github.com/en/rest/actions/workflow-runs#re-run-a-workflow)
    * [Re-run failed jobs from a workflow run](https://docs.github.com/en/rest/actions/workflow-runs#re-run-failed-jobs-from-a-workflow-run)
    * [Get workflow run usage](https://docs.github.com/en/rest/actions/workflow-runs#get-workflow-run-usage)
    * [List workflow runs for a workflow](https://docs.github.com/en/rest/actions/workflow-runs#list-workflow-runs-for-a-workflow)
  * [REST API endpoints for workflows](https://docs.github.com/en/rest/actions/workflows)
    * [List repository workflows](https://docs.github.com/en/rest/actions/workflows#list-repository-workflows)
    * [Get a workflow](https://docs.github.com/en/rest/actions/workflows#get-a-workflow)
    * [Disable a workflow](https://docs.github.com/en/rest/actions/workflows#disable-a-workflow)
    * [Create a workflow dispatch event](https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event)
    * [Enable a workflow](https://docs.github.com/en/rest/actions/workflows#enable-a-workflow)
    * [Get workflow usage](https://docs.github.com/en/rest/actions/workflows#get-workflow-usage)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Actions - GitHub Docs
