[Skip to main content](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Self-hosted runners](https://docs.github.com/en/rest/actions/self-hosted-runners "Self-hosted runners")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
      * [About self-hosted runners in GitHub Actions](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#about-self-hosted-runners-in-github-actions)
      * [List self-hosted runners for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization)
      * [List runner applications for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization)
      * [Create configuration for a just-in-time runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization)
      * [Create a registration token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization)
      * [Create a remove token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization)
      * [Get a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization)
      * [Delete a self-hosted runner from an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization)
      * [List labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization)
      * [Add custom labels to a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization)
      * [Set custom labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization)
      * [Remove all custom labels from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization)
      * [Remove a custom label from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization)
      * [List self-hosted runners for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository)
      * [List runner applications for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository)
      * [Create configuration for a just-in-time runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository)
      * [Create a registration token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository)
      * [Create a remove token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository)
      * [Get a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository)
      * [Delete a self-hosted runner from a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository)
      * [List labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository)
      * [Add custom labels to a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository)
      * [Set custom labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository)
      * [Remove all custom labels from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository)
      * [Remove a custom label from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository)
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Actions](https://docs.github.com/en/rest/actions "Actions")/
  * [Self-hosted runners](https://docs.github.com/en/rest/actions/self-hosted-runners "Self-hosted runners")


# REST API endpoints for self-hosted runners
Use the REST API to interact with self-hosted runners in GitHub Actions.
## [About self-hosted runners in GitHub Actions](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#about-self-hosted-runners-in-github-actions)
You can use the REST API to register, view, and delete self-hosted runners in GitHub Actions. Self-hosted runners allow you to host your own runners and customize the environment used to run jobs in your GitHub Actions workflows. For more information, see [Managing self-hosted runners](https://docs.github.com/en/actions/how-tos/managing-self-hosted-runners).
## [List self-hosted runners for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization)
Lists all self-hosted runners configured in an organization.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "List self-hosted runners for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (read)


### [Parameters for "List self-hosted runners for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`name` string The name of a self-hosted runner.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List self-hosted runners for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List self-hosted runners for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/actions/runners
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "runners": [     {       "id": 23,       "name": "linux_runner",       "os": "linux",       "status": "online",       "busy": true,       "ephemeral": false,       "labels": [         {           "id": 5,           "name": "self-hosted",           "type": "read-only"         },         {           "id": 7,           "name": "X64",           "type": "read-only"         },         {           "id": 11,           "name": "Linux",           "type": "read-only"         }       ]     },     {       "id": 24,       "name": "mac_runner",       "os": "macos",       "status": "offline",       "busy": false,       "ephemeral": false,       "labels": [         {           "id": 5,           "name": "self-hosted",           "type": "read-only"         },         {           "id": 7,           "name": "X64",           "type": "read-only"         },         {           "id": 20,           "name": "macOS",           "type": "read-only"         },         {           "id": 21,           "name": "no-gpu",           "type": "custom"         }       ]     }   ] }`
## [List runner applications for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization)
Lists binaries for the runner application that you can download and run.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "List runner applications for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (read)


### [Parameters for "List runner applications for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "List runner applications for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List runner applications for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/actions/runners/downloads
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/downloads`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "os": "osx",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-osx-x64-2.164.0.tar.gz",     "filename": "actions-runner-osx-x64-2.164.0.tar.gz"   },   {     "os": "linux",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-x64-2.164.0.tar.gz",     "filename": "actions-runner-linux-x64-2.164.0.tar.gz"   },   {     "os": "linux",     "architecture": "arm",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-arm-2.164.0.tar.gz",     "filename": "actions-runner-linux-arm-2.164.0.tar.gz"   },   {     "os": "win",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-win-x64-2.164.0.zip",     "filename": "actions-runner-win-x64-2.164.0.zip"   },   {     "os": "linux",     "architecture": "arm64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-arm64-2.164.0.tar.gz",     "filename": "actions-runner-linux-arm64-2.164.0.tar.gz"   } ]`
## [Create configuration for a just-in-time runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization)
Generates a configuration that can be passed to the runner application at startup.
The authenticated user must have admin access to the organization.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create configuration for a just-in-time runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Create configuration for a just-in-time runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the new runner.
`runner_group_id` integer Required The ID of the runner group to register the runner to.
`labels` array of strings Required The names of the custom labels to add to the runner. **Minimum items** : 1. **Maximum items** : 100.
`work_folder` string The working directory to be used for job execution, relative to the runner install directory. Default: `_work`
### [HTTP response status codes for "Create configuration for a just-in-time runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create configuration for a just-in-time runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/actions/runners/generate-jitconfig
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/generate-jitconfig \   -d '{"name":"New runner","runner_group_id":1,"labels":["self-hosted","X64","macOS","no-gpu"],"work_folder":"_work"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "runner": {     "id": 23,     "name": "New runner",     "os": "unknown",     "status": "offline",     "busy": false,     "labels": [       {         "id": 5,         "name": "self-hosted",         "type": "read-only"       },       {         "id": 7,         "name": "X64",         "type": "read-only"       },       {         "id": 20,         "name": "macOS",         "type": "read-only"       },       {         "id": 21,         "name": "no-gpu",         "type": "custom"       }     ]   },   "encoded_jit_config": "abc123" }`
## [Create a registration token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization)
Returns a token that you can pass to the `config` script. The token expires after one hour.
For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to configure your self-hosted runner:
```
./config.sh --url https://github.com/octo-org --token TOKEN

```

Authenticated users must have admin access to the organization to use this endpoint.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a registration token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Create a registration token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Create a registration token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a registration token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/actions/runners/registration-token
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/registration-token`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "token": "LLBF3JGZDX3P5PMEXLND6TS6FCWO6",   "expires_at": "2020-01-22T12:13:35.123-08:00" }`
## [Create a remove token for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization)
Returns a token that you can pass to the `config` script to remove a self-hosted runner from an organization. The token expires after one hour.
For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to remove your self-hosted runner from an organization:
```
./config.sh remove --token TOKEN

```

Authenticated users must have admin access to the organization to use this endpoint.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a remove token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Create a remove token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Create a remove token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a remove token for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/actions/runners/remove-token
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/remove-token`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "token": "AABF3JGZDX3P5PMEXLND6TS6FCWO6",   "expires_at": "2020-01-29T12:13:35.123-08:00" }`
## [Get a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization)
Gets a specific self-hosted runner configured in an organization.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Get a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (read)


### [Parameters for "Get a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Get a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/actions/runners/{runner_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 23,   "name": "MBP",   "os": "macos",   "status": "online",   "busy": true,   "ephemeral": false,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Delete a self-hosted runner from an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization)
Forces the removal of a self-hosted runner from an organization. You can use this endpoint to completely remove the runner when the machine you were using no longer exists.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth tokens and personal access tokens (classic) need the`admin:org` scope to use this endpoint. If the repository is private, OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a self-hosted runner from an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Delete a self-hosted runner from an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Delete a self-hosted runner from an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization--status-codes)
Status code | Description
---|---
`204` | No Content
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete a self-hosted runner from an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-an-organization--code-samples)
#### Request example
delete/orgs/{org}/actions/runners/{runner_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID`
Response
`Status: 204`
## [List labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization)
Lists all labels for a self-hosted runner configured in an organization.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "List labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (read)


### [Parameters for "List labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "List labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Add custom labels to a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization)
Adds custom labels to a self-hosted runner configured in an organization.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Add custom labels to a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Add custom labels to a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
Body parameters Name, Type, Description
---
`labels` array of strings Required The names of the custom labels to add to the runner.
### [HTTP response status codes for "Add custom labels to a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add custom labels to a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
post/orgs/{org}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID/labels \   -d '{"labels":["gpu","accelerated"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Set custom labels for a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization)
Remove all previous custom labels and set the new custom labels for a specific self-hosted runner configured in an organization.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Set custom labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Set custom labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
Body parameters Name, Type, Description
---
`labels` array of strings Required The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels.
### [HTTP response status codes for "Set custom labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set custom labels for a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
put/orgs/{org}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID/labels \   -d '{"labels":["gpu","accelerated"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Remove all custom labels from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization)
Remove all custom labels from a self-hosted runner configured in an organization. Returns the remaining read-only labels from the runner.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Remove all custom labels from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Remove all custom labels from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Remove all custom labels from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Remove all custom labels from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
delete/orgs/{org}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 3,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     }   ] }`
## [Remove a custom label from a self-hosted runner for an organization](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization)
Remove a custom label from a self-hosted runner configured in an organization. Returns the remaining labels from the runner.
This endpoint returns a `404 Not Found` status if the custom label is not present on the runner.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint. If the repository is private, the `repo` scope is also required.
### [Fine-grained access tokens for "Remove a custom label from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Self-hosted runners" organization permissions (write)


### [Parameters for "Remove a custom label from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
`name` string Required The name of a self-hosted runner's custom label.
### [HTTP response status codes for "Remove a custom label from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove a custom label from a self-hosted runner for an organization"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-an-organization--code-samples)
#### Request example
delete/orgs/{org}/actions/runners/{runner_id}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/actions/runners/RUNNER_ID/labels/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [List self-hosted runners for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository)
Lists all self-hosted runners configured in a repository.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List self-hosted runners for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "List self-hosted runners for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`name` string The name of a self-hosted runner.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List self-hosted runners for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List self-hosted runners for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-self-hosted-runners-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runners
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "runners": [     {       "id": 23,       "name": "linux_runner",       "os": "linux",       "status": "online",       "busy": true,       "ephemeral": false,       "labels": [         {           "id": 5,           "name": "self-hosted",           "type": "read-only"         },         {           "id": 7,           "name": "X64",           "type": "read-only"         },         {           "id": 11,           "name": "Linux",           "type": "read-only"         }       ]     },     {       "id": 24,       "name": "mac_runner",       "os": "macos",       "status": "offline",       "busy": false,       "ephemeral": false,       "labels": [         {           "id": 5,           "name": "self-hosted",           "type": "read-only"         },         {           "id": 7,           "name": "X64",           "type": "read-only"         },         {           "id": 20,           "name": "macOS",           "type": "read-only"         },         {           "id": 21,           "name": "no-gpu",           "type": "custom"         }       ]     }   ] }`
## [List runner applications for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository)
Lists binaries for the runner application that you can download and run.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List runner applications for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "List runner applications for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "List runner applications for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List runner applications for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-runner-applications-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runners/downloads
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/downloads`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "os": "osx",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-osx-x64-2.164.0.tar.gz",     "filename": "actions-runner-osx-x64-2.164.0.tar.gz"   },   {     "os": "linux",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-x64-2.164.0.tar.gz",     "filename": "actions-runner-linux-x64-2.164.0.tar.gz"   },   {     "os": "linux",     "architecture": "arm",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-arm-2.164.0.tar.gz",     "filename": "actions-runner-linux-arm-2.164.0.tar.gz"   },   {     "os": "win",     "architecture": "x64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-win-x64-2.164.0.zip",     "filename": "actions-runner-win-x64-2.164.0.zip"   },   {     "os": "linux",     "architecture": "arm64",     "download_url": "https://github.com/actions/runner/releases/download/v2.164.0/actions-runner-linux-arm64-2.164.0.tar.gz",     "filename": "actions-runner-linux-arm64-2.164.0.tar.gz"   } ]`
## [Create configuration for a just-in-time runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository)
Generates a configuration that can be passed to the runner application at startup.
The authenticated user must have admin access to the repository.
OAuth tokens and personal access tokens (classic) need the`repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create configuration for a just-in-time runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create configuration for a just-in-time runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the new runner.
`runner_group_id` integer Required The ID of the runner group to register the runner to.
`labels` array of strings Required The names of the custom labels to add to the runner. **Minimum items** : 1. **Maximum items** : 100.
`work_folder` string The working directory to be used for job execution, relative to the runner install directory. Default: `_work`
### [HTTP response status codes for "Create configuration for a just-in-time runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create configuration for a just-in-time runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-configuration-for-a-just-in-time-runner-for-a-repository--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runners/generate-jitconfig
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/generate-jitconfig \   -d '{"name":"New runner","runner_group_id":1,"labels":["self-hosted","X64","macOS","no-gpu"],"work_folder":"_work"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "runner": {     "id": 23,     "name": "New runner",     "os": "unknown",     "status": "offline",     "busy": false,     "labels": [       {         "id": 5,         "name": "self-hosted",         "type": "read-only"       },       {         "id": 7,         "name": "X64",         "type": "read-only"       },       {         "id": 20,         "name": "macOS",         "type": "read-only"       },       {         "id": 21,         "name": "no-gpu",         "type": "custom"       }     ]   },   "encoded_jit_config": "abc123" }`
## [Create a registration token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository)
Returns a token that you can pass to the `config` script. The token expires after one hour.
For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to configure your self-hosted runner:
```
./config.sh --url https://github.com/octo-org --token TOKEN

```

Authenticated users must have admin access to the repository to use this endpoint.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a registration token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create a registration token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Create a registration token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a registration token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-registration-token-for-a-repository--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runners/registration-token
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/registration-token`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "token": "LLBF3JGZDX3P5PMEXLND6TS6FCWO6",   "expires_at": "2020-01-22T12:13:35.123-08:00" }`
## [Create a remove token for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository)
Returns a token that you can pass to the `config` script to remove a self-hosted runner from an repository. The token expires after one hour.
For example, you can replace `TOKEN` in the following example with the registration token provided by this endpoint to remove your self-hosted runner from an organization:
```
./config.sh remove --token TOKEN

```

Authenticated users must have admin access to the repository to use this endpoint.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a remove token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create a remove token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Create a remove token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a remove token for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#create-a-remove-token-for-a-repository--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runners/remove-token
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/remove-token`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "token": "AABF3JGZDX3P5PMEXLND6TS6FCWO6",   "expires_at": "2020-01-29T12:13:35.123-08:00" }`
## [Get a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository)
Gets a specific self-hosted runner configured in a repository.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Get a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Get a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#get-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runners/{runner_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 23,   "name": "MBP",   "os": "macos",   "status": "online",   "busy": true,   "ephemeral": false,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Delete a self-hosted runner from a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository)
Forces the removal of a self-hosted runner from a repository. You can use this endpoint to completely remove the runner when the machine you were using no longer exists.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a self-hosted runner from a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete a self-hosted runner from a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Delete a self-hosted runner from a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository--status-codes)
Status code | Description
---|---
`204` | No Content
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete a self-hosted runner from a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#delete-a-self-hosted-runner-from-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/runners/{runner_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID`
Response
`Status: 204`
## [List labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository)
Lists all labels for a self-hosted runner configured in a repository.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "List labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "List labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#list-labels-for-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Add custom labels to a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository)
Adds custom labels to a self-hosted runner configured in a repository.
Authenticated users must have admin access to the organization to use this endpoint.
OAuth tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Add custom labels to a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Add custom labels to a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
Body parameters Name, Type, Description
---
`labels` array of strings Required The names of the custom labels to add to the runner.
### [HTTP response status codes for "Add custom labels to a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add custom labels to a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#add-custom-labels-to-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
post/repos/{owner}/{repo}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID/labels \   -d '{"labels":["gpu","accelerated"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Set custom labels for a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository)
Remove all previous custom labels and set the new custom labels for a specific self-hosted runner configured in a repository.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Set custom labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Set custom labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
Body parameters Name, Type, Description
---
`labels` array of strings Required The names of the custom labels to set for the runner. You can pass an empty array to remove all custom labels.
### [HTTP response status codes for "Set custom labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set custom labels for a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#set-custom-labels-for-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
put/repos/{owner}/{repo}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID/labels \   -d '{"labels":["gpu","accelerated"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## [Remove all custom labels from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository)
Remove all custom labels from a self-hosted runner configured in a repository. Returns the remaining read-only labels from the runner.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Remove all custom labels from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove all custom labels from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
### [HTTP response status codes for "Remove all custom labels from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Remove all custom labels from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-all-custom-labels-from-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/runners/{runner_id}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 3,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     }   ] }`
## [Remove a custom label from a self-hosted runner for a repository](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository)
Remove a custom label from a self-hosted runner configured in a repository. Returns the remaining labels from the runner.
This endpoint returns a `404 Not Found` status if the custom label is not present on the runner.
Authenticated users must have admin access to the repository to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Remove a custom label from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Remove a custom label from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`runner_id` integer Required Unique identifier of the self-hosted runner.
`name` string Required The name of a self-hosted runner's custom label.
### [HTTP response status codes for "Remove a custom label from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Remove a custom label from a self-hosted runner for a repository"](https://docs.github.com/en/rest/actions/self-hosted-runners?apiVersion=2022-11-28#remove-a-custom-label-from-a-self-hosted-runner-for-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}/actions/runners/{runner_id}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/actions/runners/RUNNER_ID/labels/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 4,   "labels": [     {       "id": 5,       "name": "self-hosted",       "type": "read-only"     },     {       "id": 7,       "name": "X64",       "type": "read-only"     },     {       "id": 20,       "name": "macOS",       "type": "read-only"     },     {       "id": 21,       "name": "no-gpu",       "type": "custom"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/actions/self-hosted-runners.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for self-hosted runners - GitHub Docs
