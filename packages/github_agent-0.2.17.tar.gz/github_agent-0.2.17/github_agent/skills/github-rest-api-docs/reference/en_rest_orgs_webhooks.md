[Skip to main content](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Webhooks](https://docs.github.com/en/rest/orgs/webhooks "Webhooks")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
      * [About organization webhooks](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#about-organization-webhooks)
      * [List organization webhooks](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks)
      * [Create an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook)
      * [Get an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook)
      * [Update an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook)
      * [Delete an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook)
      * [Get a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization)
      * [Update a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization)
      * [List deliveries for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook)
      * [Get a webhook delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook)
      * [Redeliver a delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook)
      * [Ping an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook)
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Webhooks](https://docs.github.com/en/rest/orgs/webhooks "Webhooks")


# REST API endpoints for organization webhooks
Use the REST API to interact with webhooks in an organization.
## [About organization webhooks](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#about-organization-webhooks)
Organization webhooks allow your server to receive HTTP `POST` payloads whenever certain events happen in an organization. For more information, see [Webhooks documentation](https://docs.github.com/en/webhooks).
## [List organization webhooks](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks)
List webhooks for an organization.
The authenticated user must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "List organization webhooks"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (read)


### [Parameters for "List organization webhooks"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organization webhooks"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List organization webhooks"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-organization-webhooks--code-samples)
#### Request example
get/orgs/{org}/hooks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "url": "https://api.github.com/orgs/octocat/hooks/1",     "ping_url": "https://api.github.com/orgs/octocat/hooks/1/pings",     "deliveries_url": "https://api.github.com/orgs/octocat/hooks/1/deliveries",     "name": "web",     "events": [       "push",       "pull_request"     ],     "active": true,     "config": {       "url": "http://example.com",       "content_type": "json"     },     "updated_at": "2011-09-06T20:39:23Z",     "created_at": "2011-09-06T17:26:27Z",     "type": "Organization"   } ]`
## [Create an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook)
Create a hook that posts payloads in JSON format.
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Create an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Create an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required Must be passed as "web".
`config` object Required Key/value pairs to provide settings for this webhook.
Properties of `config` | Name, Type, Description
---
`url` string Required The URL to which the payloads will be delivered.
`content_type` string The media type used to serialize the payloads. Supported values include `json` and `form`. The default is `form`.
`secret` string If provided, the `secret` will be used as the `key` to generate the HMAC hex digest value for [delivery signature headers](https://docs.github.com/webhooks/event-payloads/#delivery-headers).
`insecure_ssl` string or number Determines whether the SSL certificate of the host for `url` will be verified when delivering payloads. Supported values include `0` (verification is performed) and `1` (verification is not performed). The default is `0`. **We strongly recommend not setting this to`1` as you are subject to man-in-the-middle and other attacks.**
`username` string
`password` string
`events` array of strings Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. Set to `["*"]` to receive all possible events. Default: `["push"]`
`active` boolean Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. Default: `true`
### [HTTP response status codes for "Create an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#create-an-organization-webhook--code-samples)
#### Request example
post/orgs/{org}/hooks
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks \   -d '{"name":"web","active":true,"events":["push","pull_request"],"config":{"url":"http://example.com/webhook","content_type":"json"}}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1,   "url": "https://api.github.com/orgs/octocat/hooks/1",   "ping_url": "https://api.github.com/orgs/octocat/hooks/1/pings",   "deliveries_url": "https://api.github.com/orgs/octocat/hooks/1/deliveries",   "name": "web",   "events": [     "push",     "pull_request"   ],   "active": true,   "config": {     "url": "http://example.com",     "content_type": "json"   },   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "type": "Organization" }`
## [Get an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook)
Returns a webhook configured in an organization. To get only the webhook `config` properties, see "[Get a webhook configuration for an organization](https://docs.github.com/rest/orgs/webhooks#get-a-webhook-configuration-for-an-organization).
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Get an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (read)


### [Parameters for "Get an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### [HTTP response status codes for "Get an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-an-organization-webhook--code-samples)
#### Request example
get/orgs/{org}/hooks/{hook_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "url": "https://api.github.com/orgs/octocat/hooks/1",   "ping_url": "https://api.github.com/orgs/octocat/hooks/1/pings",   "deliveries_url": "https://api.github.com/orgs/octocat/hooks/1/deliveries",   "name": "web",   "events": [     "push",     "pull_request"   ],   "active": true,   "config": {     "url": "http://example.com",     "content_type": "json"   },   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "type": "Organization" }`
## [Update an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook)
Updates a webhook configured in an organization. When you update a webhook, the `secret` will be overwritten. If you previously had a `secret` set, you must provide the same `secret` or set a new `secret` or the secret will be removed. If you are only updating individual webhook `config` properties, use "[Update a webhook configuration for an organization](https://docs.github.com/rest/orgs/webhooks#update-a-webhook-configuration-for-an-organization)".
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Update an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Update an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
Body parameters Name, Type, Description
---
`config` object Key/value pairs to provide settings for this webhook.
Properties of `config` | Name, Type, Description
---
`url` string Required The URL to which the payloads will be delivered.
`content_type` string The media type used to serialize the payloads. Supported values include `json` and `form`. The default is `form`.
`secret` string If provided, the `secret` will be used as the `key` to generate the HMAC hex digest value for [delivery signature headers](https://docs.github.com/webhooks/event-payloads/#delivery-headers).
`insecure_ssl` string or number Determines whether the SSL certificate of the host for `url` will be verified when delivering payloads. Supported values include `0` (verification is performed) and `1` (verification is not performed). The default is `0`. **We strongly recommend not setting this to`1` as you are subject to man-in-the-middle and other attacks.**
`events` array of strings Determines what [events](https://docs.github.com/webhooks/event-payloads) the hook is triggered for. Default: `["push"]`
`active` boolean Determines if notifications are sent when the webhook is triggered. Set to `true` to send notifications. Default: `true`
`name` string
### [HTTP response status codes for "Update an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-an-organization-webhook--code-samples)
#### Request example
patch/orgs/{org}/hooks/{hook_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID \   -d '{"active":true,"events":["pull_request"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "url": "https://api.github.com/orgs/octocat/hooks/1",   "ping_url": "https://api.github.com/orgs/octocat/hooks/1/pings",   "deliveries_url": "https://api.github.com/repos/octocat/Hello-World/hooks/12345678/deliveries",   "name": "web",   "events": [     "pull_request"   ],   "active": true,   "config": {     "url": "http://example.com",     "content_type": "json"   },   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "type": "Organization" }`
## [Delete an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook)
Delete a webhook for an organization.
The authenticated user must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Delete an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Delete an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### [HTTP response status codes for "Delete an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#delete-an-organization-webhook--code-samples)
#### Request example
delete/orgs/{org}/hooks/{hook_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID`
Response
`Status: 204`
## [Get a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization)
Returns the webhook configuration for an organization. To get more information about the webhook, including the `active` state and `events`, use "[Get an organization webhook ](https://docs.github.com/rest/orgs/webhooks#get-an-organization-webhook)."
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Get a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (read)


### [Parameters for "Get a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### [HTTP response status codes for "Get a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/hooks/{hook_id}/config
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/config`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "content_type": "json",   "insecure_ssl": "0",   "secret": "********",   "url": "https://example.com/webhook" }`
## [Update a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization)
Updates the webhook configuration for an organization. To update more information about the webhook, including the `active` state and `events`, use "[Update an organization webhook ](https://docs.github.com/rest/orgs/webhooks#update-an-organization-webhook)."
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Update a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Update a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
Body parameters Name, Type, Description
---
`url` string The URL to which the payloads will be delivered.
`content_type` string The media type used to serialize the payloads. Supported values include `json` and `form`. The default is `form`.
`secret` string If provided, the `secret` will be used as the `key` to generate the HMAC hex digest value for [delivery signature headers](https://docs.github.com/webhooks/event-payloads/#delivery-headers).
`insecure_ssl` string or number Determines whether the SSL certificate of the host for `url` will be verified when delivering payloads. Supported values include `0` (verification is performed) and `1` (verification is not performed). The default is `0`. **We strongly recommend not setting this to`1` as you are subject to man-in-the-middle and other attacks.**
### [HTTP response status codes for "Update a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Update a webhook configuration for an organization"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-an-organization--code-samples)
#### Request example
patch/orgs/{org}/hooks/{hook_id}/config
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/config \   -d '{"url":"http://example.com/webhook","content_type":"json","insecure_ssl":"0","secret":"********"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "content_type": "json",   "insecure_ssl": "0",   "secret": "********",   "url": "https://example.com/webhook" }`
## [List deliveries for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook)
Returns a list of webhook deliveries for a webhook configured in an organization.
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "List deliveries for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (read)


### [Parameters for "List deliveries for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`cursor` string Used for pagination: the starting delivery from which the page of deliveries is fetched. Refer to the `link` header for the next and previous page cursors.
### [HTTP response status codes for "List deliveries for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List deliveries for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#list-deliveries-for-an-organization-webhook--code-samples)
#### Request example
get/orgs/{org}/hooks/{hook_id}/deliveries
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/deliveries`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 12345678,     "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",     "delivered_at": "2019-06-03T00:57:16Z",     "redelivery": false,     "duration": 0.27,     "status": "OK",     "status_code": 200,     "event": "issues",     "action": "opened",     "installation_id": 123,     "repository_id": 456,     "throttled_at": "2019-06-03T00:57:16Z"   },   {     "id": 123456789,     "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",     "delivered_at": "2019-06-04T00:57:16Z",     "redelivery": true,     "duration": 0.28,     "status": "OK",     "status_code": 200,     "event": "issues",     "action": "opened",     "installation_id": 123,     "repository_id": 456,     "throttled_at": null   } ]`
## [Get a webhook delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook)
Returns a delivery for a webhook configured in an organization.
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Get a webhook delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (read)


### [Parameters for "Get a webhook delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
`delivery_id` integer Required
### [HTTP response status codes for "Get a webhook delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Get a webhook delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#get-a-webhook-delivery-for-an-organization-webhook--code-samples)
#### Request example
get/orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/deliveries/DELIVERY_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 12345678,   "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",   "delivered_at": "2019-06-03T00:57:16Z",   "redelivery": false,   "duration": 0.27,   "status": "OK",   "status_code": 200,   "event": "issues",   "action": "opened",   "installation_id": 123,   "repository_id": 456,   "url": "https://www.example.com",   "throttled_at": "2019-06-03T00:57:16Z",   "request": {     "headers": {       "X-GitHub-Delivery": "0b989ba4-242f-11e5-81e1-c7b6966d2516",       "X-Hub-Signature-256": "sha256=6dcb09b5b57875f334f61aebed695e2e4193db5e",       "Accept": "*/*",       "X-GitHub-Hook-ID": "42",       "User-Agent": "GitHub-Hookshot/b8c71d8",       "X-GitHub-Event": "issues",       "X-GitHub-Hook-Installation-Target-ID": "123",       "X-GitHub-Hook-Installation-Target-Type": "repository",       "content-type": "application/json",       "X-Hub-Signature": "sha1=a84d88e7554fc1fa21bcbc4efae3c782a70d2b9d"     },     "payload": {       "action": "opened",       "issue": {         "body": "foo"       },       "repository": {         "id": 123       }     }   },   "response": {     "headers": {       "Content-Type": "text/html;charset=utf-8"     },     "payload": "ok"   } }`
## [Redeliver a delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook)
Redeliver a delivery for a webhook configured in an organization.
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Redeliver a delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Redeliver a delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
`delivery_id` integer Required
### [HTTP response status codes for "Redeliver a delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook--status-codes)
Status code | Description
---|---
`202` | Accepted
`400` | Bad Request
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Redeliver a delivery for an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#redeliver-a-delivery-for-an-organization-webhook--code-samples)
#### Request example
post/orgs/{org}/hooks/{hook_id}/deliveries/{delivery_id}/attempts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/deliveries/DELIVERY_ID/attempts`
Accepted
  * Example response
  * Response schema


`Status: 202`
## [Ping an organization webhook](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook)
This will trigger a [ping event](https://docs.github.com/webhooks/#ping-event) to be sent to the hook.
You must be an organization owner to use this endpoint.
OAuth app tokens and personal access tokens (classic) need `admin:org_hook` scope. OAuth apps cannot list, view, or edit webhooks that they did not create and users cannot list, view, or edit webhooks that were created by OAuth apps.
### [Fine-grained access tokens for "Ping an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Webhooks" organization permissions (write)


### [Parameters for "Ping an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`hook_id` integer Required The unique identifier of the hook. You can find this value in the `X-GitHub-Hook-ID` header of a webhook delivery.
### [HTTP response status codes for "Ping an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Ping an organization webhook"](https://docs.github.com/en/rest/orgs/webhooks?apiVersion=2022-11-28#ping-an-organization-webhook--code-samples)
#### Request example
post/orgs/{org}/hooks/{hook_id}/pings
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/hooks/HOOK_ID/pings`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/webhooks.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for organization webhooks - GitHub Docs
