[Skip to main content](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Classroom](https://docs.github.com/en/rest/classroom "Classroom")/
  * [Classroom](https://docs.github.com/en/rest/classroom/classroom "Classroom")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
      * [Get an assignment](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment)
      * [List accepted assignments for an assignment](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment)
      * [Get assignment grades](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades)
      * [List classrooms](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms)
      * [Get a classroom](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom)
      * [List assignments for a classroom](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom)
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Classroom](https://docs.github.com/en/rest/classroom "Classroom")/
  * [Classroom](https://docs.github.com/en/rest/classroom/classroom "Classroom")


# REST API endpoints for GitHub Classroom
Use the REST API to interact with GitHub Classroom.
## [Get an assignment](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment)
Gets a GitHub Classroom assignment. Assignment will only be returned if the current user is an administrator of the GitHub Classroom for the assignment.
### [Fine-grained access tokens for "Get an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`assignment_id` integer Required The unique identifier of the classroom assignment.
### [HTTP response status codes for "Get an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-an-assignment--code-samples)
#### Request example
get/assignments/{assignment_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/assignments/ASSIGNMENT_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": "12,",   "public_repo": "false,",   "title": "Intro to Binaries",   "type": "individual",   "invite_link": "https://classroom.github.com/a/Lx7jiUgx",   "invitations_enabled": "true,",   "slug": "intro-to-binaries",   "students_are_repo_admins": false,   "feedback_pull_requests_enabled": true,   "max_teams": 0,   "max_members": 0,   "editor": "codespaces",   "accepted": 100,   "submitted": 40,   "passing": 10,   "language": "ruby",   "deadline": "2011-01-26T19:06:43Z",   "stater_code_repository": {     "id": 1296269,     "full_name": "octocat/Hello-World",     "html_url": "https://github.com/octocat/Hello-World",     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "private": false,     "default_branch": "main"   },   "classroom": {     "id": 1296269,     "name": "Programming Elixir",     "archived": "false,",     "url": "https://classroom.github.com/classrooms/1-programming-elixir"   } }`
## [List accepted assignments for an assignment](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment)
Lists any assignment repositories that have been created by students accepting a GitHub Classroom assignment. Accepted assignments will only be returned if the current user is an administrator of the GitHub Classroom for the assignment.
### [Fine-grained access tokens for "List accepted assignments for an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List accepted assignments for an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`assignment_id` integer Required The unique identifier of the classroom assignment.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List accepted assignments for an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List accepted assignments for an assignment"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-accepted-assignments-for-an-assignment--code-samples)
#### Request example
get/assignments/{assignment_id}/accepted_assignments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/assignments/ASSIGNMENT_ID/accepted_assignments`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": "12,",   "submitted": "false,",   "passing": "false,",   "commit_count": 5,   "grade": "5/10",   "students": [     {       "id": 1,       "login": "octocat",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "html_url": "https://github.com/octocat"     }   ],   "repository": {     "id": 1296269,     "full_name": "octocat/Hello-World",     "html_url": "https://github.com/octocat/Hello-World",     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "private": false,     "default_branch": "main"   },   "assignment": {     "id": "12,",     "public_repo": "false,",     "title": "Intro to Binaries",     "type": "individual",     "invite_link": "https://classroom.github.com/a/Lx7jiUgx",     "invitations_enabled": "true,",     "slug": "intro-to-binaries",     "students_are_repo_admins": false,     "feedback_pull_requests_enabled": true,     "max_teams": 0,     "max_members": 0,     "editor": "codespaces",     "accepted": 100,     "submitted": 40,     "passing": 10,     "language": "ruby",     "classroom": {       "id": 1296269,       "name": "Programming Elixir",       "archived": "false,",       "url": "https://classroom.github.com/classrooms/1-programming-elixir"     }   } }`
## [Get assignment grades](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades)
Gets grades for a GitHub Classroom assignment. Grades will only be returned if the current user is an administrator of the GitHub Classroom for the assignment.
### [Fine-grained access tokens for "Get assignment grades"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get assignment grades"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`assignment_id` integer Required The unique identifier of the classroom assignment.
### [HTTP response status codes for "Get assignment grades"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get assignment grades"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-assignment-grades--code-samples)
#### Request example
get/assignments/{assignment_id}/grades
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/assignments/ASSIGNMENT_ID/grades`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "assignment_name": "Introduction to Strings",     "assignment_url": "https://classroom.github.com/classrooms/1337/assignments/1337",     "starter_code_url": "",     "github_username": "octocat",     "roster_identifier": "octocat@github.com",     "student_repository_name": "intro-to-strings-1337-octocat",     "student_repository_url": "https://github.com/timeforschool/intro-to-strings-1337-octocat",     "submission_timestamp": "2018-11-12 01:02",     "points_awarded": 10,     "points_available": 15,     "group_name": "octocat-and-friends"   },   {     "assignment_name": "Introduction to Strings",     "assignment_url": "https://classroom.github.com/classrooms/1337/assignments/1337",     "starter_code_url": "",     "github_username": "monalisa",     "roster_identifier": "monalisa@github.com",     "student_repository_name": "intro-to-strings-1337-monalisa",     "student_repository_url": "https://github.com/timeforschool/intro-to-strings-1337-monalisa",     "submission_timestamp": "2018-11-12 01:11",     "points_awarded": 15,     "points_available": 15,     "group_name": "monalisa-and-friends"   } ]`
## [List classrooms](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms)
Lists GitHub Classroom classrooms for the current user. Classrooms will only be returned if the current user is an administrator of one or more GitHub Classrooms.
### [Fine-grained access tokens for "List classrooms"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List classrooms"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List classrooms"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List classrooms"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-classrooms--code-samples)
#### Request example
get/classrooms
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/classrooms`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "name": "Programming Elixir",   "archived": "false,",   "url": "https://classroom.github.com/classrooms/1-programming-elixir" }`
## [Get a classroom](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom)
Gets a GitHub Classroom classroom for the current user. Classroom will only be returned if the current user is an administrator of the GitHub Classroom.
### [Fine-grained access tokens for "Get a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`classroom_id` integer Required The unique identifier of the classroom.
### [HTTP response status codes for "Get a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#get-a-classroom--code-samples)
#### Request example
get/classrooms/{classroom_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/classrooms/CLASSROOM_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "name": "Programming Elixir",   "archived": "false,",   "organization": {     "id": 1,     "login": "programming-elixir",     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "html_url": "https://github.com/programming-elixir",     "name": "Learn how to build fault tolerant applications",     "avatar_url": "https://avatars.githubusercontent.com/u/9919?v=4"   },   "url": "https://classroom.github.com/classrooms/1-programming-elixir" }`
## [List assignments for a classroom](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom)
Lists GitHub Classroom assignments for a classroom. Assignments will only be returned if the current user is an administrator of the GitHub Classroom.
### [Fine-grained access tokens for "List assignments for a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List assignments for a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`classroom_id` integer Required The unique identifier of the classroom.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List assignments for a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List assignments for a classroom"](https://docs.github.com/en/rest/classroom/classroom?apiVersion=2022-11-28#list-assignments-for-a-classroom--code-samples)
#### Request example
get/classrooms/{classroom_id}/assignments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/classrooms/CLASSROOM_ID/assignments`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": "12,",   "public_repo": "false,",   "title": "Intro to Binaries",   "type": "individual",   "invite_link": "https://classroom.github.com/a/Lx7jiUgx",   "invitations_enabled": "true,",   "slug": "intro-to-binaries",   "students_are_repo_admins": false,   "feedback_pull_requests_enabled": true,   "max_teams": 0,   "max_members": 0,   "editor": "codespaces",   "accepted": 100,   "submitted": 40,   "passing": 10,   "language": "ruby",   "deadline": "2020-01-11T11:59:22Z",   "classroom": {     "id": 1296269,     "name": "Programming Elixir",     "archived": "false,",     "url": "https://classroom.github.com/classrooms/1-programming-elixir"   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/classroom/classroom.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Classroom - GitHub Docs
