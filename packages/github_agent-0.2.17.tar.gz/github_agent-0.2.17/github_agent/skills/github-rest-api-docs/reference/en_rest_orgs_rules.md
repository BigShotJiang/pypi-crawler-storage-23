[Skip to main content](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Rules](https://docs.github.com/en/rest/orgs/rules "Rules")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
      * [Get all organization repository rulesets](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets)
      * [Create an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset)
      * [Get an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset)
      * [Update an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset)
      * [Delete an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset)
      * [Get organization ruleset history](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history)
      * [Get organization ruleset version](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version)
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Rules](https://docs.github.com/en/rest/orgs/rules "Rules")


# REST API endpoints for rules
Use the REST API to manage rulesets for organizations. Organization rulesets control how people can interact with selected branches and tags in repositories in an organization.
## [Get all organization repository rulesets](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets)
Get all the repository rulesets for an organization.
### [Fine-grained access tokens for "Get all organization repository rulesets"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Get all organization repository rulesets"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`targets` string A comma-separated list of rule targets to filter by. If provided, only rulesets that apply to the specified targets will be returned. For example, `branch,tag,push`.
### [HTTP response status codes for "Get all organization repository rulesets"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get all organization repository rulesets"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-all-organization-repository-rulesets--code-samples)
#### Request example
get/orgs/{org}/rulesets
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 21,     "name": "super cool ruleset",     "source_type": "Organization",     "source": "my-org",     "enforcement": "enabled",     "node_id": "RRS_lACkVXNlcgQB",     "_links": {       "self": {         "href": "https://api.github.com/orgs/my-org/rulesets/21"       },       "html": {         "href": "https://github.com/organizations/my-org/settings/rules/21"       }     },     "created_at": "2023-07-15T08:43:03Z",     "updated_at": "2023-08-23T16:29:47Z"   },   {     "id": 432,     "name": "Another ruleset",     "source_type": "Organization",     "source": "my-org",     "enforcement": "enabled",     "node_id": "RRS_lACkVXNlcgQQ",     "_links": {       "self": {         "href": "https://api.github.com/orgs/my-org/rulesets/432"       },       "html": {         "href": "https://github.com/organizations/my-org/settings/rules/432"       }     },     "created_at": "2023-08-15T08:43:03Z",     "updated_at": "2023-09-23T16:29:47Z"   } ]`
## [Create an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset)
Create a repository ruleset for an organization.
### [Fine-grained access tokens for "Create an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Create an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the ruleset.
`target` string The target of the ruleset Default: `branch` Can be one of: `branch`, `tag`, `push`, `repository`
`enforcement` string Required The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). Can be one of: `disabled`, `active`, `evaluate`
`bypass_actors` array of objects The actors that can bypass the rules in this ruleset
Properties of `bypass_actors` | Name, Type, Description
---
`actor_id` integer or null The ID of the actor that can bypass a ruleset. Required for `Integration`, `RepositoryRole`, and `Team` actor types. If `actor_type` is `OrganizationAdmin`, `actor_id` is ignored. If `actor_type` is `DeployKey`, this should be null. `OrganizationAdmin` is not applicable for personal repositories.
`actor_type` string Required The type of actor that can bypass a ruleset. Can be one of: `Integration`, `OrganizationAdmin`, `RepositoryRole`, `Team`, `DeployKey`
`bypass_mode` string When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. Default: `always` Can be one of: `always`, `pull_request`, `exempt`
`conditions` object Conditions for an organization ruleset. The branch and tag rulesets conditions object should contain both `repository_name` and `ref_name` properties, or both `repository_id` and `ref_name` properties, or both `repository_property` and `ref_name` properties. The push rulesets conditions object does not require the `ref_name` property. For repository policy rulesets, the conditions object should only contain the `repository_name`, the `repository_id`, or the `repository_property`.
Can be one of these objects: | Name, Type, Description
---
`repository_name_and_ref_name` object Conditions to target repositories by name and refs by name
Properties of `repository_name_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_name` object Required
Properties of `repository_name` | Name, Type, Description
---
`include` array of strings Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories.
`exclude` array of strings Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match.
`protected` boolean Whether renaming of target repositories is prevented.
`repository_id_and_ref_name` object Conditions to target repositories by id and refs by name
Properties of `repository_id_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_id` object Required
Properties of `repository_id` | Name, Type, Description
---
`repository_ids` array of integers The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass.
`repository_property_and_ref_name` object Conditions to target repositories by property and refs by name
Properties of `repository_property_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_property` object Required
Properties of `repository_property` | Name, Type, Description
---
`include` array of objects The repository properties and values to include. All of these properties must match for the condition to pass.
Properties of `include` | Name, Type, Description
---
`name` string Required The name of the repository property to target
`property_values` array of strings Required The values to match for the repository property
`source` string The source of the repository property. Defaults to 'custom' if not specified. Can be one of: `custom`, `system`
`exclude` array of objects The repository properties and values to exclude. The condition will not pass if any of these properties match.
Properties of `exclude` | Name, Type, Description
---
`name` string Required The name of the repository property to target
`property_values` array of strings Required The values to match for the repository property
`source` string The source of the repository property. Defaults to 'custom' if not specified. Can be one of: `custom`, `system`
`rules` array of objects An array of rules within the ruleset.
Can be one of these objects: | Name, Type, Description
---
`creation` object Only allow users with bypass permission to create matching refs.
Properties of `creation` | Name, Type, Description
---
`type` string Required Value: `creation`
`update` object Only allow users with bypass permission to update matching refs.
Properties of `update` | Name, Type, Description
---
`type` string Required Value: `update`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`update_allows_fetch_and_merge` boolean Required Branch can pull changes from its upstream repository
`deletion` object Only allow users with bypass permissions to delete matching refs.
Properties of `deletion` | Name, Type, Description
---
`type` string Required Value: `deletion`
`required_linear_history` object Prevent merge commits from being pushed to matching refs.
Properties of `required_linear_history` | Name, Type, Description
---
`type` string Required Value: `required_linear_history`
`required_deployments` object Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule.
Properties of `required_deployments` | Name, Type, Description
---
`type` string Required Value: `required_deployments`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`required_deployment_environments` array of strings Required The environments that must be successfully deployed to before branches can be merged.
`required_signatures` object Commits pushed to matching refs must have verified signatures.
Properties of `required_signatures` | Name, Type, Description
---
`type` string Required Value: `required_signatures`
`pull_request` object Require all commits be made to a non-target branch and submitted via a pull request before they can be merged.
Properties of `pull_request` | Name, Type, Description
---
`type` string Required Value: `pull_request`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`allowed_merge_methods` array of strings Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. Supported values are: `merge`, `squash`, `rebase`
`dismiss_stale_reviews_on_push` boolean Required New, reviewable commits pushed will dismiss previous pull request review approvals.
`require_code_owner_review` boolean Required Require an approving review in pull requests that modify files that have a designated code owner.
`require_last_push_approval` boolean Required Whether the most recent reviewable push must be approved by someone other than the person who pushed it.
`required_approving_review_count` integer Required The number of approving reviews that are required before a pull request can be merged.
`required_review_thread_resolution` boolean Required All conversations on code must be resolved before a pull request can be merged.
`required_reviewers` array of objects `required_reviewers` is in beta and subject to change. A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review.
Properties of `required_reviewers` | Name, Type, Description
---
`file_patterns` array of strings Required Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax.
`minimum_approvals` integer Required Minimum number of approvals required from the specified team. If set to zero, the team will be added to the pull request but approval is optional.
`reviewer` object Required A required reviewing team
Properties of `reviewer` | Name, Type, Description
---
`id` integer Required ID of the reviewer which must review changes to matching files.
`type` string Required The type of the reviewer Value: `Team`
`required_status_checks` object Choose which status checks must pass before the ref is updated. When enabled, commits must first be pushed to another ref where the checks pass.
Properties of `required_status_checks` | Name, Type, Description
---
`type` string Required Value: `required_status_checks`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`required_status_checks` array of objects Required Status checks that are required.
Properties of `required_status_checks` | Name, Type, Description
---
`context` string Required The status check context name that must be present on the commit.
`integration_id` integer The optional integration ID that this status check must originate from.
`strict_required_status_checks_policy` boolean Required Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled.
`non_fast_forward` object Prevent users with push access from force pushing to refs.
Properties of `non_fast_forward` | Name, Type, Description
---
`type` string Required Value: `non_fast_forward`
`commit_message_pattern` object Parameters to be used for the commit_message_pattern rule
Properties of `commit_message_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_message_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`commit_author_email_pattern` object Parameters to be used for the commit_author_email_pattern rule
Properties of `commit_author_email_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_author_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`committer_email_pattern` object Parameters to be used for the committer_email_pattern rule
Properties of `committer_email_pattern` | Name, Type, Description
---
`type` string Required Value: `committer_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`branch_name_pattern` object Parameters to be used for the branch_name_pattern rule
Properties of `branch_name_pattern` | Name, Type, Description
---
`type` string Required Value: `branch_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`tag_name_pattern` object Parameters to be used for the tag_name_pattern rule
Properties of `tag_name_pattern` | Name, Type, Description
---
`type` string Required Value: `tag_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`file_path_restriction` object Prevent commits that include changes in specified file and folder paths from being pushed to the commit graph. This includes absolute paths that contain file names.
Properties of `file_path_restriction` | Name, Type, Description
---
`type` string Required Value: `file_path_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_paths` array of strings Required The file paths that are restricted from being pushed to the commit graph.
`max_file_path_length` object Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph.
Properties of `max_file_path_length` | Name, Type, Description
---
`type` string Required Value: `max_file_path_length`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_path_length` integer Required The maximum amount of characters allowed in file paths.
`file_extension_restriction` object Prevent commits that include files with specified file extensions from being pushed to the commit graph.
Properties of `file_extension_restriction` | Name, Type, Description
---
`type` string Required Value: `file_extension_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_extensions` array of strings Required The file extensions that are restricted from being pushed to the commit graph.
`max_file_size` object Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph.
Properties of `max_file_size` | Name, Type, Description
---
`type` string Required Value: `max_file_size`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_size` integer Required The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS).
`workflows` object Require all changes made to a targeted branch to pass the specified workflows before they can be merged.
Properties of `workflows` | Name, Type, Description
---
`type` string Required Value: `workflows`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`workflows` array of objects Required Workflows that must pass for this rule to pass.
Properties of `workflows` | Name, Type, Description
---
`path` string Required The path to the workflow file
`ref` string The ref (branch or tag) of the workflow file to use
`repository_id` integer Required The ID of the repository where the workflow is defined
`sha` string The commit SHA of the workflow file to use
`code_scanning` object Choose which tools must provide code scanning results before the reference is updated. When configured, code scanning must be enabled and have results for both the commit and the reference being updated.
Properties of `code_scanning` | Name, Type, Description
---
`type` string Required Value: `code_scanning`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`code_scanning_tools` array of objects Required Tools that must provide code scanning results for this rule to pass.
Properties of `code_scanning_tools` | Name, Type, Description
---
`alerts_threshold` string Required The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `errors`, `errors_and_warnings`, `all`
`security_alerts_threshold` string Required The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `critical`, `high_or_higher`, `medium_or_higher`, `all`
`tool` string Required The name of a code scanning tool
`copilot_code_review` object Request Copilot code review for new pull requests automatically if the author has access to Copilot code review and their premium requests quota has not reached the limit.
Properties of `copilot_code_review` | Name, Type, Description
---
`type` string Required Value: `copilot_code_review`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`review_draft_pull_requests` boolean Copilot automatically reviews draft pull requests before they are marked as ready for review.
`review_on_push` boolean Copilot automatically reviews each new push to the pull request.
### [HTTP response status codes for "Create an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Create an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#create-an-organization-repository-ruleset--code-samples)
#### Request example
post/orgs/{org}/rulesets
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets \   -d '{"name":"super cool ruleset","target":"branch","enforcement":"active","bypass_actors":[{"actor_id":234,"actor_type":"Team","bypass_mode":"always"}],"conditions":{"ref_name":{"include":["refs/heads/main","refs/heads/master"],"exclude":["refs/heads/dev*"]},"repository_name":{"include":["important_repository","another_important_repository"],"exclude":["unimportant_repository"],"protected":true}},"rules":[{"type":"commit_author_email_pattern","parameters":{"operator":"contains","pattern":"github"}}]}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 21,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Organization",   "source": "my-org",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     },     "repository_name": {       "include": [         "important_repository",         "another_important_repository"       ],       "exclude": [         "unimportant_repository"       ],       "protected": true     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/orgs/my-org/rulesets/21"     },     "html": {       "href": "https://github.com/organizations/my-org/settings/rules/21"     }   },   "created_at": "2023-08-15T08:43:03Z",   "updated_at": "2023-09-23T16:29:47Z" }`
## [Get an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset)
Get a repository ruleset for an organization.
**Note:** To prevent leaking sensitive information, the `bypass_actors` property is only returned if the user making the API request has write access to the ruleset.
### [Fine-grained access tokens for "Get an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Get an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
### [HTTP response status codes for "Get an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-an-organization-repository-ruleset--code-samples)
#### Request example
get/orgs/{org}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets/RULESET_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 21,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Organization",   "source": "my-org",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     },     "repository_name": {       "include": [         "important_repository",         "another_important_repository"       ],       "exclude": [         "unimportant_repository"       ],       "protected": true     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/orgs/my-org/rulesets/21"     },     "html": {       "href": "https://github.com/organizations/my-org/settings/rules/21"     }   },   "created_at": "2023-08-15T08:43:03Z",   "updated_at": "2023-09-23T16:29:47Z" }`
## [Update an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset)
Update a ruleset for an organization.
### [Fine-grained access tokens for "Update an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Update an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
Body parameters Name, Type, Description
---
`name` string The name of the ruleset.
`target` string The target of the ruleset Can be one of: `branch`, `tag`, `push`, `repository`
`enforcement` string The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). Can be one of: `disabled`, `active`, `evaluate`
`bypass_actors` array of objects The actors that can bypass the rules in this ruleset
Properties of `bypass_actors` | Name, Type, Description
---
`actor_id` integer or null The ID of the actor that can bypass a ruleset. Required for `Integration`, `RepositoryRole`, and `Team` actor types. If `actor_type` is `OrganizationAdmin`, `actor_id` is ignored. If `actor_type` is `DeployKey`, this should be null. `OrganizationAdmin` is not applicable for personal repositories.
`actor_type` string Required The type of actor that can bypass a ruleset. Can be one of: `Integration`, `OrganizationAdmin`, `RepositoryRole`, `Team`, `DeployKey`
`bypass_mode` string When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. Default: `always` Can be one of: `always`, `pull_request`, `exempt`
`conditions` object Conditions for an organization ruleset. The branch and tag rulesets conditions object should contain both `repository_name` and `ref_name` properties, or both `repository_id` and `ref_name` properties, or both `repository_property` and `ref_name` properties. The push rulesets conditions object does not require the `ref_name` property. For repository policy rulesets, the conditions object should only contain the `repository_name`, the `repository_id`, or the `repository_property`.
Can be one of these objects: | Name, Type, Description
---
`repository_name_and_ref_name` object Conditions to target repositories by name and refs by name
Properties of `repository_name_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_name` object Required
Properties of `repository_name` | Name, Type, Description
---
`include` array of strings Array of repository names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~ALL` to include all repositories.
`exclude` array of strings Array of repository names or patterns to exclude. The condition will not pass if any of these patterns match.
`protected` boolean Whether renaming of target repositories is prevented.
`repository_id_and_ref_name` object Conditions to target repositories by id and refs by name
Properties of `repository_id_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_id` object Required
Properties of `repository_id` | Name, Type, Description
---
`repository_ids` array of integers The repository IDs that the ruleset applies to. One of these IDs must match for the condition to pass.
`repository_property_and_ref_name` object Conditions to target repositories by property and refs by name
Properties of `repository_property_and_ref_name` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`repository_property` object Required
Properties of `repository_property` | Name, Type, Description
---
`include` array of objects The repository properties and values to include. All of these properties must match for the condition to pass.
Properties of `include` | Name, Type, Description
---
`name` string Required The name of the repository property to target
`property_values` array of strings Required The values to match for the repository property
`source` string The source of the repository property. Defaults to 'custom' if not specified. Can be one of: `custom`, `system`
`exclude` array of objects The repository properties and values to exclude. The condition will not pass if any of these properties match.
Properties of `exclude` | Name, Type, Description
---
`name` string Required The name of the repository property to target
`property_values` array of strings Required The values to match for the repository property
`source` string The source of the repository property. Defaults to 'custom' if not specified. Can be one of: `custom`, `system`
`rules` array of objects An array of rules within the ruleset.
Can be one of these objects: | Name, Type, Description
---
`creation` object Only allow users with bypass permission to create matching refs.
Properties of `creation` | Name, Type, Description
---
`type` string Required Value: `creation`
`update` object Only allow users with bypass permission to update matching refs.
Properties of `update` | Name, Type, Description
---
`type` string Required Value: `update`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`update_allows_fetch_and_merge` boolean Required Branch can pull changes from its upstream repository
`deletion` object Only allow users with bypass permissions to delete matching refs.
Properties of `deletion` | Name, Type, Description
---
`type` string Required Value: `deletion`
`required_linear_history` object Prevent merge commits from being pushed to matching refs.
Properties of `required_linear_history` | Name, Type, Description
---
`type` string Required Value: `required_linear_history`
`required_deployments` object Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule.
Properties of `required_deployments` | Name, Type, Description
---
`type` string Required Value: `required_deployments`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`required_deployment_environments` array of strings Required The environments that must be successfully deployed to before branches can be merged.
`required_signatures` object Commits pushed to matching refs must have verified signatures.
Properties of `required_signatures` | Name, Type, Description
---
`type` string Required Value: `required_signatures`
`pull_request` object Require all commits be made to a non-target branch and submitted via a pull request before they can be merged.
Properties of `pull_request` | Name, Type, Description
---
`type` string Required Value: `pull_request`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`allowed_merge_methods` array of strings Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. Supported values are: `merge`, `squash`, `rebase`
`dismiss_stale_reviews_on_push` boolean Required New, reviewable commits pushed will dismiss previous pull request review approvals.
`require_code_owner_review` boolean Required Require an approving review in pull requests that modify files that have a designated code owner.
`require_last_push_approval` boolean Required Whether the most recent reviewable push must be approved by someone other than the person who pushed it.
`required_approving_review_count` integer Required The number of approving reviews that are required before a pull request can be merged.
`required_review_thread_resolution` boolean Required All conversations on code must be resolved before a pull request can be merged.
`required_reviewers` array of objects `required_reviewers` is in beta and subject to change. A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review.
Properties of `required_reviewers` | Name, Type, Description
---
`file_patterns` array of strings Required Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax.
`minimum_approvals` integer Required Minimum number of approvals required from the specified team. If set to zero, the team will be added to the pull request but approval is optional.
`reviewer` object Required A required reviewing team
Properties of `reviewer` | Name, Type, Description
---
`id` integer Required ID of the reviewer which must review changes to matching files.
`type` string Required The type of the reviewer Value: `Team`
`required_status_checks` object Choose which status checks must pass before the ref is updated. When enabled, commits must first be pushed to another ref where the checks pass.
Properties of `required_status_checks` | Name, Type, Description
---
`type` string Required Value: `required_status_checks`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`required_status_checks` array of objects Required Status checks that are required.
Properties of `required_status_checks` | Name, Type, Description
---
`context` string Required The status check context name that must be present on the commit.
`integration_id` integer The optional integration ID that this status check must originate from.
`strict_required_status_checks_policy` boolean Required Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled.
`non_fast_forward` object Prevent users with push access from force pushing to refs.
Properties of `non_fast_forward` | Name, Type, Description
---
`type` string Required Value: `non_fast_forward`
`commit_message_pattern` object Parameters to be used for the commit_message_pattern rule
Properties of `commit_message_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_message_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`commit_author_email_pattern` object Parameters to be used for the commit_author_email_pattern rule
Properties of `commit_author_email_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_author_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`committer_email_pattern` object Parameters to be used for the committer_email_pattern rule
Properties of `committer_email_pattern` | Name, Type, Description
---
`type` string Required Value: `committer_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`branch_name_pattern` object Parameters to be used for the branch_name_pattern rule
Properties of `branch_name_pattern` | Name, Type, Description
---
`type` string Required Value: `branch_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`tag_name_pattern` object Parameters to be used for the tag_name_pattern rule
Properties of `tag_name_pattern` | Name, Type, Description
---
`type` string Required Value: `tag_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`file_path_restriction` object Prevent commits that include changes in specified file and folder paths from being pushed to the commit graph. This includes absolute paths that contain file names.
Properties of `file_path_restriction` | Name, Type, Description
---
`type` string Required Value: `file_path_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_paths` array of strings Required The file paths that are restricted from being pushed to the commit graph.
`max_file_path_length` object Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph.
Properties of `max_file_path_length` | Name, Type, Description
---
`type` string Required Value: `max_file_path_length`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_path_length` integer Required The maximum amount of characters allowed in file paths.
`file_extension_restriction` object Prevent commits that include files with specified file extensions from being pushed to the commit graph.
Properties of `file_extension_restriction` | Name, Type, Description
---
`type` string Required Value: `file_extension_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_extensions` array of strings Required The file extensions that are restricted from being pushed to the commit graph.
`max_file_size` object Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph.
Properties of `max_file_size` | Name, Type, Description
---
`type` string Required Value: `max_file_size`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_size` integer Required The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS).
`workflows` object Require all changes made to a targeted branch to pass the specified workflows before they can be merged.
Properties of `workflows` | Name, Type, Description
---
`type` string Required Value: `workflows`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`workflows` array of objects Required Workflows that must pass for this rule to pass.
Properties of `workflows` | Name, Type, Description
---
`path` string Required The path to the workflow file
`ref` string The ref (branch or tag) of the workflow file to use
`repository_id` integer Required The ID of the repository where the workflow is defined
`sha` string The commit SHA of the workflow file to use
`code_scanning` object Choose which tools must provide code scanning results before the reference is updated. When configured, code scanning must be enabled and have results for both the commit and the reference being updated.
Properties of `code_scanning` | Name, Type, Description
---
`type` string Required Value: `code_scanning`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`code_scanning_tools` array of objects Required Tools that must provide code scanning results for this rule to pass.
Properties of `code_scanning_tools` | Name, Type, Description
---
`alerts_threshold` string Required The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `errors`, `errors_and_warnings`, `all`
`security_alerts_threshold` string Required The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `critical`, `high_or_higher`, `medium_or_higher`, `all`
`tool` string Required The name of a code scanning tool
`copilot_code_review` object Request Copilot code review for new pull requests automatically if the author has access to Copilot code review and their premium requests quota has not reached the limit.
Properties of `copilot_code_review` | Name, Type, Description
---
`type` string Required Value: `copilot_code_review`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`review_draft_pull_requests` boolean Copilot automatically reviews draft pull requests before they are marked as ready for review.
`review_on_push` boolean Copilot automatically reviews each new push to the pull request.
### [HTTP response status codes for "Update an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Update an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#update-an-organization-repository-ruleset--code-samples)
#### Request example
put/orgs/{org}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets/RULESET_ID \   -d '{"name":"super cool ruleset","target":"branch","enforcement":"active","bypass_actors":[{"actor_id":234,"actor_type":"Team","bypass_mode":"always"}],"conditions":{"ref_name":{"include":["refs/heads/main","refs/heads/master"],"exclude":["refs/heads/dev*"]},"repository_name":{"include":["important_repository","another_important_repository"],"exclude":["unimportant_repository"],"protected":true}},"rules":[{"type":"commit_author_email_pattern","parameters":{"operator":"contains","pattern":"github"}}]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 21,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Organization",   "source": "my-org",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     },     "repository_name": {       "include": [         "important_repository",         "another_important_repository"       ],       "exclude": [         "unimportant_repository"       ],       "protected": true     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/orgs/my-org/rulesets/21"     },     "html": {       "href": "https://github.com/organizations/my-org/settings/rules/21"     }   },   "created_at": "2023-08-15T08:43:03Z",   "updated_at": "2023-09-23T16:29:47Z" }`
## [Delete an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset)
Delete a ruleset for an organization.
### [Fine-grained access tokens for "Delete an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Delete an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
### [HTTP response status codes for "Delete an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Delete an organization repository ruleset"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#delete-an-organization-repository-ruleset--code-samples)
#### Request example
delete/orgs/{org}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets/RULESET_ID`
Response
`Status: 204`
## [Get organization ruleset history](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history)
Get the history of an organization ruleset.
### [Fine-grained access tokens for "Get organization ruleset history"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Get organization ruleset history"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "Get organization ruleset history"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get organization ruleset history"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-history--code-samples)
#### Request example
get/orgs/{org}/rulesets/{ruleset_id}/history
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets/RULESET_ID/history`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "version_id": 3,     "actor": {       "id": 1,       "type": "User"     },     "updated_at": "2024-10-23T16:29:47Z"   },   {     "version_id": 2,     "actor": {       "id": 2,       "type": "User"     },     "updated_at": "2024-09-23T16:29:47Z"   },   {     "version_id": 1,     "actor": {       "id": 1,       "type": "User"     },     "updated_at": "2024-08-23T16:29:47Z"   } ]`
## [Get organization ruleset version](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version)
Get a version of an organization ruleset.
### [Fine-grained access tokens for "Get organization ruleset version"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Get organization ruleset version"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
`version_id` integer Required The ID of the version
### [HTTP response status codes for "Get organization ruleset version"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get organization ruleset version"](https://docs.github.com/en/rest/orgs/rules?apiVersion=2022-11-28#get-organization-ruleset-version--code-samples)
#### Request example
get/orgs/{org}/rulesets/{ruleset_id}/history/{version_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/rulesets/RULESET_ID/history/VERSION_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "version_id": 3,   "actor": {     "id": 1,     "type": "User"   },   "updated_at": "2024-10-23T16:29:47Z",   "state": {     "id": 21,     "name": "super cool ruleset",     "target": "branch",     "source_type": "Organization",     "source": "my-org",     "enforcement": "active",     "bypass_actors": [       {         "actor_id": 234,         "actor_type": "Team",         "bypass_mode": "always"       }     ],     "conditions": {       "ref_name": {         "include": [           "refs/heads/main",           "refs/heads/master"         ],         "exclude": [           "refs/heads/dev*"         ]       },       "repository_name": {         "include": [           "important_repository",           "another_important_repository"         ],         "exclude": [           "unimportant_repository"         ],         "protected": true       }     },     "rules": [       {         "type": "commit_author_email_pattern",         "parameters": {           "operator": "contains",           "pattern": "github"         }       }     ]   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/rules.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for rules - GitHub Docs
