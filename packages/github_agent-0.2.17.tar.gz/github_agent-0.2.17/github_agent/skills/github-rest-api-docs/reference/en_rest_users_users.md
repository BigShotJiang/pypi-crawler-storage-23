[Skip to main content](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Users](https://docs.github.com/en/rest/users "Users")/
  * [Users](https://docs.github.com/en/rest/users/users "Users")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users
      * [Get the authenticated user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user)
      * [Update the authenticated user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user)
      * [Get a user using their ID](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id)
      * [List users](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users)
      * [Get a user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user)
      * [Get contextual information for a user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user)


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Users](https://docs.github.com/en/rest/users "Users")/
  * [Users](https://docs.github.com/en/rest/users/users "Users")


# REST API endpoints for users
Use the REST API to get public and private information about authenticated users.
## [Get the authenticated user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user)
OAuth app tokens and personal access tokens (classic) need the `user` scope in order for the response to include private profile information.
### [Fine-grained access tokens for "Get the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [HTTP response status codes for "Get the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
### [Code samples for "Get the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-the-authenticated-user--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 200
get/user
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user`
Response with public and private profile information
  * Example response
  * Response schema


`Status: 200`
`{   "login": "octocat",   "id": 1,   "node_id": "MDQ6VXNlcjE=",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "gravatar_id": "",   "url": "https://api.github.com/users/octocat",   "html_url": "https://github.com/octocat",   "followers_url": "https://api.github.com/users/octocat/followers",   "following_url": "https://api.github.com/users/octocat/following{/other_user}",   "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",   "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",   "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",   "organizations_url": "https://api.github.com/users/octocat/orgs",   "repos_url": "https://api.github.com/users/octocat/repos",   "events_url": "https://api.github.com/users/octocat/events{/privacy}",   "received_events_url": "https://api.github.com/users/octocat/received_events",   "type": "User",   "site_admin": false,   "name": "monalisa octocat",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "hireable": false,   "bio": "There once was...",   "twitter_username": "monatheoctocat",   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "created_at": "2008-01-14T04:33:35Z",   "updated_at": "2008-01-14T04:33:35Z",   "private_gists": 81,   "total_private_repos": 100,   "owned_private_repos": 100,   "disk_usage": 10000,   "collaborators": 8,   "two_factor_authentication": true,   "plan": {     "name": "Medium",     "space": 400,     "private_repos": 20,     "collaborators": 0   } }`
## [Update the authenticated user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user)
**Note:** If your email is set to private and you send an `email` parameter as part of this request to update your profile, your privacy settings are still enforced: the email address will not be displayed on your public profile or via the API.
### [Fine-grained access tokens for "Update the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Profile" user permissions (write)


### [Parameters for "Update the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Body parameters Name, Type, Description
---
`name` string The new name of the user.
`email` string The publicly visible email address of the user.
`blog` string The new blog URL of the user.
`twitter_username` string or null The new Twitter username of the user.
`company` string The new company of the user.
`location` string The new location of the user.
`hireable` boolean The new hiring availability of the user.
`bio` string The new short biography of the user.
### [HTTP response status codes for "Update the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update the authenticated user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#update-the-authenticated-user--code-samples)
#### Request example
patch/user
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user \   -d '{"blog":"https://github.com/blog","name":"monalisa octocat"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "login": "octocat",   "id": 1,   "node_id": "MDQ6VXNlcjE=",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "gravatar_id": "",   "url": "https://api.github.com/users/octocat",   "html_url": "https://github.com/octocat",   "followers_url": "https://api.github.com/users/octocat/followers",   "following_url": "https://api.github.com/users/octocat/following{/other_user}",   "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",   "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",   "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",   "organizations_url": "https://api.github.com/users/octocat/orgs",   "repos_url": "https://api.github.com/users/octocat/repos",   "events_url": "https://api.github.com/users/octocat/events{/privacy}",   "received_events_url": "https://api.github.com/users/octocat/received_events",   "type": "User",   "site_admin": false,   "name": "monalisa octocat",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "hireable": false,   "bio": "There once was...",   "twitter_username": "monatheoctocat",   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "created_at": "2008-01-14T04:33:35Z",   "updated_at": "2008-01-14T04:33:35Z",   "private_gists": 81,   "total_private_repos": 100,   "owned_private_repos": 100,   "disk_usage": 10000,   "collaborators": 8,   "two_factor_authentication": true,   "plan": {     "name": "Medium",     "space": 400,     "private_repos": 20,     "collaborators": 0   } }`
## [Get a user using their ID](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id)
Provides publicly available information about someone with a GitHub account. This method takes their durable user `ID` instead of their `login`, which can change over time.
If you are requesting information about an [Enterprise Managed User](https://docs.github.com/enterprise-cloud@latest/admin/managing-iam/understanding-iam-for-enterprises/about-enterprise-managed-users), or a GitHub App bot that is installed in an organization that uses Enterprise Managed Users, your requests must be authenticated as a user or GitHub App that has access to the organization to view that account's information. If you are not authorized, the request will return a `404 Not Found` status.
The `email` key in the following response is the publicly visible email address from your GitHub [profile page](https://github.com/settings/profile). When setting up your profile, you can select a primary email address to be public which provides an email entry for this endpoint. If you do not set a public email address for `email`, then it will have a value of `null`. You only see publicly visible email addresses when authenticated with GitHub. For more information, see [Authentication](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#authentication).
The Emails API enables you to list all of your email addresses, and toggle a primary email to be visible publicly. For more information, see [Emails API](https://docs.github.com/rest/users/emails).
### [Fine-grained access tokens for "Get a user using their ID"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get a user using their ID"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`account_id` integer Required account_id parameter
### [HTTP response status codes for "Get a user using their ID"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a user using their ID"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user-using-their-id--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 200
get/user/{account_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/ACCOUNT_ID`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "login": "octocat",   "id": 1,   "node_id": "MDQ6VXNlcjE=",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "gravatar_id": "",   "url": "https://api.github.com/users/octocat",   "html_url": "https://github.com/octocat",   "followers_url": "https://api.github.com/users/octocat/followers",   "following_url": "https://api.github.com/users/octocat/following{/other_user}",   "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",   "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",   "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",   "organizations_url": "https://api.github.com/users/octocat/orgs",   "repos_url": "https://api.github.com/users/octocat/repos",   "events_url": "https://api.github.com/users/octocat/events{/privacy}",   "received_events_url": "https://api.github.com/users/octocat/received_events",   "type": "User",   "site_admin": false,   "name": "monalisa octocat",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "hireable": false,   "bio": "There once was...",   "twitter_username": "monatheoctocat",   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "created_at": "2008-01-14T04:33:35Z",   "updated_at": "2008-01-14T04:33:35Z" }`
## [List users](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users)
Lists all users, in the order that they signed up on GitHub. This list includes personal user accounts and organization accounts.
Note: Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of users.
### [Fine-grained access tokens for "List users"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "List users"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` integer A user ID. Only return users with an ID greater than this ID.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "List users"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
### [Code samples for "List users"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#list-users--code-samples)
#### Request example
get/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## [Get a user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user)
Provides publicly available information about someone with a GitHub account.
If you are requesting information about an [Enterprise Managed User](https://docs.github.com/enterprise-cloud@latest/admin/managing-iam/understanding-iam-for-enterprises/about-enterprise-managed-users), or a GitHub App bot that is installed in an organization that uses Enterprise Managed Users, your requests must be authenticated as a user or GitHub App that has access to the organization to view that account's information. If you are not authorized, the request will return a `404 Not Found` status.
The `email` key in the following response is the publicly visible email address from your GitHub [profile page](https://github.com/settings/profile). When setting up your profile, you can select a primary email address to be public which provides an email entry for this endpoint. If you do not set a public email address for `email`, then it will have a value of `null`. You only see publicly visible email addresses when authenticated with GitHub. For more information, see [Authentication](https://docs.github.com/rest/guides/getting-started-with-the-rest-api#authentication).
The Emails API enables you to list all of your email addresses, and toggle a primary email to be visible publicly. For more information, see [Emails API](https://docs.github.com/rest/users/emails).
### [Fine-grained access tokens for "Get a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
### [HTTP response status codes for "Get a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-a-user--code-samples)
#### Request examples
Select the example typeExample 1: Status Code 200 Example 2: Status Code 200
get/users/{username}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "login": "octocat",   "id": 1,   "node_id": "MDQ6VXNlcjE=",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "gravatar_id": "",   "url": "https://api.github.com/users/octocat",   "html_url": "https://github.com/octocat",   "followers_url": "https://api.github.com/users/octocat/followers",   "following_url": "https://api.github.com/users/octocat/following{/other_user}",   "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",   "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",   "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",   "organizations_url": "https://api.github.com/users/octocat/orgs",   "repos_url": "https://api.github.com/users/octocat/repos",   "events_url": "https://api.github.com/users/octocat/events{/privacy}",   "received_events_url": "https://api.github.com/users/octocat/received_events",   "type": "User",   "site_admin": false,   "name": "monalisa octocat",   "company": "GitHub",   "blog": "https://github.com/blog",   "location": "San Francisco",   "email": "octocat@github.com",   "hireable": false,   "bio": "There once was...",   "twitter_username": "monatheoctocat",   "public_repos": 2,   "public_gists": 1,   "followers": 20,   "following": 0,   "created_at": "2008-01-14T04:33:35Z",   "updated_at": "2008-01-14T04:33:35Z" }`
## [Get contextual information for a user](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user)
Provides hovercard information. You can find out more about someone in relation to their pull requests, issues, repositories, and organizations.
The `subject_type` and `subject_id` parameters provide context for the person's hovercard, which returns more information than without the parameters. For example, if you wanted to find out more about `octocat` who owns the `Spoon-Knife` repository, you would use a `subject_type` value of `repository` and a `subject_id` value of `1300192` (the ID of the `Spoon-Knife` repository).
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get contextual information for a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get contextual information for a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`subject_type` string Identifies which additional information you'd like to receive about the person's hovercard. Can be `organization`, `repository`, `issue`, `pull_request`. **Required** when using `subject_id`. Can be one of: `organization`, `repository`, `issue`, `pull_request`
`subject_id` string Uses the ID for the `subject_type` you specified. **Required** when using `subject_type`.
### [HTTP response status codes for "Get contextual information for a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Get contextual information for a user"](https://docs.github.com/en/rest/users/users?apiVersion=2022-11-28#get-contextual-information-for-a-user--code-samples)
#### Request example
get/users/{username}/hovercard
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/hovercard`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "contexts": [     {       "message": "Owns this repository",       "octicon": "repo"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/users/users.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for users - GitHub Docs
