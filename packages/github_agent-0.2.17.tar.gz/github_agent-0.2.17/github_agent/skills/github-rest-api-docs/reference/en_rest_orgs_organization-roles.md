[Skip to main content](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Organization roles](https://docs.github.com/en/rest/orgs/organization-roles "Organization roles")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
      * [Get all organization roles for an organization](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization)
      * [Remove all organization roles for a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team)
      * [Assign an organization role to a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team)
      * [Remove an organization role from a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team)
      * [Remove all organization roles for a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user)
      * [Assign an organization role to a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user)
      * [Remove an organization role from a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user)
      * [Get an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role)
      * [List teams that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role)
      * [List users that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role)
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")/
  * [Organization roles](https://docs.github.com/en/rest/orgs/organization-roles "Organization roles")


# REST API endpoints for organization roles
Use the REST API to interact with organization roles.
## [Get all organization roles for an organization](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization)
Lists the organization roles available in this organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
To use this endpoint, the authenticated user must be one of:
  * An administrator for the organization.
  * A user, or a user on a team, with the fine-grained permissions of `read_organization_custom_org_role` in the organization.


OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get all organization roles for an organization"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Custom organization roles" organization permissions (read)


### [Parameters for "Get all organization roles for an organization"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get all organization roles for an organization"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization--status-codes)
Status code | Description
---|---
`200` | Response - list of organization roles
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Get all organization roles for an organization"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-all-organization-roles-for-an-organization--code-samples)
#### Request example
get/orgs/{org}/organization-roles
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles`
Response - list of organization roles
  * Example response
  * Response schema


`Status: 200`
`{   "total_count": 2,   "roles": [     {       "id": 8030,       "name": "Custom Role Manager",       "description": "Permissions to manage custom roles within an org",       "permissions": [         "write_organization_custom_repo_role",         "write_organization_custom_org_role",         "read_organization_custom_repo_role",         "read_organization_custom_org_role"       ],       "organization": {         "login": "github",         "id": 9919,         "node_id": "MDEyOk9yZ2FuaXphdGlvbjk5MTk=",         "avatar_url": "https://avatars.githubusercontent.com/u/9919?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/github",         "html_url": "https://github.com/github",         "followers_url": "https://api.github.com/users/github/followers",         "following_url": "https://api.github.com/users/github/following{/other_user}",         "gists_url": "https://api.github.com/users/github/gists{/gist_id}",         "starred_url": "https://api.github.com/users/github/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/github/subscriptions",         "organizations_url": "https://api.github.com/users/github/orgs",         "repos_url": "https://api.github.com/users/github/repos",         "events_url": "https://api.github.com/users/github/events{/privacy}",         "received_events_url": "https://api.github.com/users/github/received_events",         "type": "Organization",         "site_admin": false       },       "created_at": "2022-07-04T22:19:11Z",       "updated_at": "2022-07-04T22:20:11Z"     },     {       "id": 8031,       "name": "Auditor",       "description": "Permissions to read the organization audit log",       "permissions": [         "read_audit_logs"       ],       "organization": {         "login": "github",         "id": 9919,         "node_id": "MDEyOk9yZ2FuaXphdGlvbjk5MTk=",         "avatar_url": "https://avatars.githubusercontent.com/u/9919?v=4",         "gravatar_id": "",         "url": "https://api.github.com/users/github",         "html_url": "https://github.com/github",         "followers_url": "https://api.github.com/users/github/followers",         "following_url": "https://api.github.com/users/github/following{/other_user}",         "gists_url": "https://api.github.com/users/github/gists{/gist_id}",         "starred_url": "https://api.github.com/users/github/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/github/subscriptions",         "organizations_url": "https://api.github.com/users/github/orgs",         "repos_url": "https://api.github.com/users/github/repos",         "events_url": "https://api.github.com/users/github/events{/privacy}",         "received_events_url": "https://api.github.com/users/github/received_events",         "type": "Organization",         "site_admin": false       },       "created_at": "2022-07-04T22:19:11Z",       "updated_at": "2022-07-04T22:20:11Z"     }   ] }`
## [Remove all organization roles for a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team)
Removes all assigned organization roles from a team. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Remove all organization roles for a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Remove all organization roles for a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
### [HTTP response status codes for "Remove all organization roles for a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove all organization roles for a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-team--code-samples)
#### Request example
delete/orgs/{org}/organization-roles/teams/{team_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/teams/TEAM_SLUG`
Response
`Status: 204`
## [Assign an organization role to a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team)
Assigns an organization role to a team in an organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Assign an organization role to a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Assign an organization role to a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
`role_id` integer Required The unique identifier of the role.
### [HTTP response status codes for "Assign an organization role to a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Response if the organization, team or role does not exist.
`422` | Response if the organization roles feature is not enabled for the organization, or validation failed.
### [Code samples for "Assign an organization role to a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-team--code-samples)
#### Request example
put/orgs/{org}/organization-roles/teams/{team_slug}/{role_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/teams/TEAM_SLUG/ROLE_ID`
Response
`Status: 204`
## [Remove an organization role from a team](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team)
Removes an organization role from a team. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Remove an organization role from a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Remove an organization role from a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`team_slug` string Required The slug of the team name.
`role_id` integer Required The unique identifier of the role.
### [HTTP response status codes for "Remove an organization role from a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove an organization role from a team"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-team--code-samples)
#### Request example
delete/orgs/{org}/organization-roles/teams/{team_slug}/{role_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/teams/TEAM_SLUG/ROLE_ID`
Response
`Status: 204`
## [Remove all organization roles for a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user)
Revokes all assigned organization roles from a user. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Remove all organization roles for a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Remove all organization roles for a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`username` string Required The handle for the GitHub user account.
### [HTTP response status codes for "Remove all organization roles for a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove all organization roles for a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-all-organization-roles-for-a-user--code-samples)
#### Request example
delete/orgs/{org}/organization-roles/users/{username}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/users/USERNAME`
Response
`Status: 204`
## [Assign an organization role to a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user)
Assigns an organization role to a member of an organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Assign an organization role to a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Assign an organization role to a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`username` string Required The handle for the GitHub user account.
`role_id` integer Required The unique identifier of the role.
### [HTTP response status codes for "Assign an organization role to a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Response if the organization, user or role does not exist.
`422` | Response if the organization roles feature is not enabled enabled for the organization, the validation failed, or the user is not an organization member.
### [Code samples for "Assign an organization role to a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#assign-an-organization-role-to-a-user--code-samples)
#### Request example
put/orgs/{org}/organization-roles/users/{username}/{role_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/users/USERNAME/ROLE_ID`
Response
`Status: 204`
## [Remove an organization role from a user](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user)
Remove an organization role from a user. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
The authenticated user must be an administrator for the organization to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Remove an organization role from a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (write)


### [Parameters for "Remove an organization role from a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`username` string Required The handle for the GitHub user account.
`role_id` integer Required The unique identifier of the role.
### [HTTP response status codes for "Remove an organization role from a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Remove an organization role from a user"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#remove-an-organization-role-from-a-user--code-samples)
#### Request example
delete/orgs/{org}/organization-roles/users/{username}/{role_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/users/USERNAME/ROLE_ID`
Response
`Status: 204`
## [Get an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role)
Gets an organization role that is available to this organization. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
To use this endpoint, the authenticated user must be one of:
  * An administrator for the organization.
  * A user, or a user on a team, with the fine-grained permissions of `read_organization_custom_org_role` in the organization.


OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "Get an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Custom organization roles" organization permissions (read)


### [Parameters for "Get an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`role_id` integer Required The unique identifier of the role.
### [HTTP response status codes for "Get an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Get an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#get-an-organization-role--code-samples)
#### Request example
get/orgs/{org}/organization-roles/{role_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/ROLE_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 8030,   "name": "Custom Role Manager",   "description": "Permissions to manage custom roles within an org",   "permissions": [     "write_organization_custom_repo_role",     "write_organization_custom_org_role",     "read_organization_custom_repo_role",     "read_organization_custom_org_role"   ],   "organization": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization"   },   "created_at": "2022-07-04T22:19:11Z",   "updated_at": "2022-07-04T22:20:11Z" }`
## [List teams that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role)
Lists the teams that are assigned to an organization role. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
To use this endpoint, you must be an administrator for the organization.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "List teams that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List teams that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`role_id` integer Required The unique identifier of the role.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List teams that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role--status-codes)
Status code | Description
---|---
`200` | Response - List of assigned teams
`404` | Response if the organization or role does not exist.
`422` | Response if the organization roles feature is not enabled or validation failed.
### [Code samples for "List teams that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-teams-that-are-assigned-to-an-organization-role--code-samples)
#### Request example
get/orgs/{org}/organization-roles/{role_id}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/ROLE_ID/teams`
Response - List of assigned teams
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [List users that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role)
Lists organization members that are assigned to an organization role. For more information on organization roles, see "[Using organization roles](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/using-organization-roles)."
To use this endpoint, you must be an administrator for the organization.
OAuth app tokens and personal access tokens (classic) need the `admin:org` scope to use this endpoint.
### [Fine-grained access tokens for "List users that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Members" organization permissions (read)


### [Parameters for "List users that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`role_id` integer Required The unique identifier of the role.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List users that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role--status-codes)
Status code | Description
---|---
`200` | Response - List of assigned users
`404` | Response if the organization or role does not exist.
`422` | Response if the organization roles feature is not enabled or validation failed.
### [Code samples for "List users that are assigned to an organization role"](https://docs.github.com/en/rest/orgs/organization-roles?apiVersion=2022-11-28#list-users-that-are-assigned-to-an-organization-role--code-samples)
#### Request example
get/orgs/{org}/organization-roles/{role_id}/users
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/organization-roles/ROLE_ID/users`
Response - List of assigned users
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/organization-roles.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for organization roles - GitHub Docs
