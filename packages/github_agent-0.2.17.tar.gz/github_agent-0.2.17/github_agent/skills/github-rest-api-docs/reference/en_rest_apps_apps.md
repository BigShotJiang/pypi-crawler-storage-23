[Skip to main content](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [GitHub Apps](https://docs.github.com/en/rest/apps/apps "GitHub Apps")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
      * [About GitHub Apps](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#about-github-apps)
      * [Get the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-the-authenticated-app)
      * [Create a GitHub App from a manifest](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest)
      * [List installation requests for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app)
      * [List installations for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app)
      * [Get an installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app)
      * [Delete an installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app)
      * [Create an installation access token for an app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app)
      * [Suspend an app installation](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation)
      * [Unsuspend an app installation](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation)
      * [Create a scoped access token](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token)
      * [Get an app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app)
      * [Get an organization installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app)
      * [Get a repository installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app)
      * [Get a user installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app)
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [GitHub Apps](https://docs.github.com/en/rest/apps/apps "GitHub Apps")


# REST API endpoints for GitHub Apps
Use the REST API to interact with GitHub Apps
## [About GitHub Apps](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#about-github-apps)
If you are using your app with GitHub Actions and want to modify workflow files, you must authenticate on behalf of the user with an OAuth token that includes the `workflow` scope. The user must have admin or write permission to the repository that contains the workflow file. For more information, see [Scopes for OAuth apps](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps#available-scopes).
This page lists endpoints that you can access while authenticated as a GitHub App. For more information, see [Authenticating as a GitHub App](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/authenticating-as-a-github-app).
See [REST API endpoints for GitHub App installations](https://docs.github.com/en/rest/apps/installations) for a list of endpoints that require authentication as a GitHub App installation.
## [Get the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-the-authenticated-app)
Returns the GitHub App associated with the authentication credentials used. To see how many app installations are associated with this GitHub App, see the `installations_count` in the response. For more details about your app's installations, see the "[List installations for the authenticated app](https://docs.github.com/rest/apps/apps#list-installations-for-the-authenticated-app)" endpoint.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Get the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [HTTP response status codes for "Get the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-the-authenticated-app--code-samples)
#### Request example
get/app
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "slug": "octoapp",   "client_id": "Iv1.ab1112223334445c",   "node_id": "MDExOkludGVncmF0aW9uMQ==",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "name": "Octocat App",   "description": "",   "external_url": "https://example.com",   "html_url": "https://github.com/apps/octoapp",   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "permissions": {     "metadata": "read",     "contents": "read",     "issues": "write",     "single_file": "write"   },   "events": [     "push",     "pull_request"   ] }`
## [Create a GitHub App from a manifest](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest)
Use this endpoint to complete the handshake necessary when implementing the [GitHub App Manifest flow](https://docs.github.com/apps/building-github-apps/creating-github-apps-from-a-manifest/). When you create a GitHub App with the manifest flow, you receive a temporary `code` used to retrieve the GitHub App's `id`, `pem` (private key), and `webhook_secret`.
### [Fine-grained access tokens for "Create a GitHub App from a manifest"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Create a GitHub App from a manifest"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`code` string Required
### [HTTP response status codes for "Create a GitHub App from a manifest"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a GitHub App from a manifest"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-github-app-from-a-manifest--code-samples)
#### Request example
post/app-manifests/{code}/conversions
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app-manifests/CODE/conversions`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1,   "slug": "octoapp",   "node_id": "MDxOkludGVncmF0aW9uMQ==",   "owner": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": true   },   "name": "Octocat App",   "description": "",   "external_url": "https://example.com",   "html_url": "https://github.com/apps/octoapp",   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "permissions": {     "metadata": "read",     "contents": "read",     "issues": "write",     "single_file": "write"   },   "events": [     "push",     "pull_request"   ],   "client_id": "Iv1.8a61f9b3a7aba766",   "client_secret": "1726be1638095a19edd134c77bde3aa2ece1e5d8",   "webhook_secret": "e340154128314309424b7c8e90325147d99fdafa",   "pem": "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAuEPzOUE+kiEH1WLiMeBytTEF856j0hOVcSUSUkZxKvqczkWM\n9vo1gDyC7ZXhdH9fKh32aapba3RSsp4ke+giSmYTk2mGR538ShSDxh0OgpJmjiKP\nX0Bj4j5sFqfXuCtl9SkH4iueivv4R53ktqM+n6hk98l6hRwC39GVIblAh2lEM4L/\n6WvYwuQXPMM5OG2Ryh2tDZ1WS5RKfgq+9ksNJ5Q9UtqtqHkO+E63N5OK9sbzpUUm\noNaOl3udTlZD3A8iqwMPVxH4SxgATBPAc+bmjk6BMJ0qIzDcVGTrqrzUiywCTLma\nszdk8GjzXtPDmuBgNn+o6s02qVGpyydgEuqmTQIDAQABAoIBACL6AvkjQVVLn8kJ\ndBYznJJ4M8ECo+YEgaFwgAHODT0zRQCCgzd+Vxl4YwHmKV2Lr+y2s0drZt8GvYva\nKOK8NYYZyi15IlwFyRXmvvykF1UBpSXluYFDH7KaVroWMgRreHcIys5LqVSIb6Bo\ngDmK0yBLPp8qR29s2b7ScZRtLaqGJiX+j55rNzrZwxHkxFHyG9OG+u9IsBElcKCP\nkYCVE8ZdYexfnKOZbgn2kZB9qu0T/Mdvki8yk3I2bI6xYO24oQmhnT36qnqWoCBX\nNuCNsBQgpYZeZET8mEAUmo9d+ABmIHIvSs005agK8xRaP4+6jYgy6WwoejJRF5yd\nNBuF7aECgYEA50nZ4FiZYV0vcJDxFYeY3kYOvVuKn8OyW+2rg7JIQTremIjv8FkE\nZnwuF9ZRxgqLxUIfKKfzp/5l5LrycNoj2YKfHKnRejxRWXqG+ZETfxxlmlRns0QG\nJ4+BYL0CoanDSeA4fuyn4Bv7cy/03TDhfg/Uq0Aeg+hhcPE/vx3ebPsCgYEAy/Pv\neDLssOSdeyIxf0Brtocg6aPXIVaLdus+bXmLg77rJIFytAZmTTW8SkkSczWtucI3\nFI1I6sei/8FdPzAl62/JDdlf7Wd9K7JIotY4TzT7Tm7QU7xpfLLYIP1bOFjN81rk\n77oOD4LsXcosB/U6s1blPJMZ6AlO2EKs10UuR1cCgYBipzuJ2ADEaOz9RLWwi0AH\nPza2Sj+c2epQD9ZivD7Zo/Sid3ZwvGeGF13JyR7kLEdmAkgsHUdu1rI7mAolXMaB\n1pdrsHureeLxGbRM6za3tzMXWv1Il7FQWoPC8ZwXvMOR1VQDv4nzq7vbbA8z8c+c\n57+8tALQHOTDOgQIzwK61QKBgERGVc0EJy4Uag+VY8J4m1ZQKBluqo7TfP6DQ7O8\nM5MX73maB/7yAX8pVO39RjrhJlYACRZNMbK+v/ckEQYdJSSKmGCVe0JrGYDuPtic\nI9+IGfSorf7KHPoMmMN6bPYQ7Gjh7a++tgRFTMEc8956Hnt4xGahy9NcglNtBpVN\n6G8jAoGBAMCh028pdzJa/xeBHLLaVB2sc0Fe7993WlsPmnVE779dAz7qMscOtXJK\nfgtriltLSSD6rTA9hUAsL/X62rY0wdXuNdijjBb/qvrx7CAV6i37NK1CjABNjsfG\nZM372Ac6zc1EqSrid2IjET1YqyIW2KGLI1R2xbQc98UGlt48OdWu\n-----END RSA PRIVATE KEY-----\n" }`
## [List installation requests for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app)
Lists all the pending installation requests for the authenticated GitHub App.
### [Fine-grained access tokens for "List installation requests for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List installation requests for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List installation requests for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | List of integration installation requests
`304` | Not modified
`401` | Requires authentication
### [Code samples for "List installation requests for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installation-requests-for-the-authenticated-app--code-samples)
#### Request example
get/app/installation-requests
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installation-requests`
List of integration installation requests
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 25381,     "node_id": "MDEyOkludGVncmF0aW9uMTIzNDU2Nzg5MA==",     "account": {       "login": "octo-org",       "id": 6811672,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjY4MTE2NzI=",       "avatar_url": "https://avatars3.githubusercontent.com/u/6811672?v=4",       "gravatar_id": "",       "url": "https://api.github.com/users/octo-org",       "html_url": "https://github.com/octo-org",       "followers_url": "https://api.github.com/users/octo-org/followers",       "following_url": "https://api.github.com/users/octo-org/following{/other_user}",       "gists_url": "https://api.github.com/users/octo-org/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octo-org/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octo-org/subscriptions",       "organizations_url": "https://api.github.com/users/octo-org/orgs",       "repos_url": "https://api.github.com/users/octo-org/repos",       "events_url": "https://api.github.com/users/octo-org/events{/privacy}",       "received_events_url": "https://api.github.com/users/octo-org/received_events",       "type": "Organization",       "site_admin": false     },     "requester": {       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "created_at": "2022-07-08T16:18:44-04:00"   } ]`
## [List installations for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app)
The permissions the installation has are included under the `permissions` key.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "List installations for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List installations for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`outdated` string
### [HTTP response status codes for "List installations for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | The permissions the installation has are included under the `permissions` key.
### [Code samples for "List installations for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#list-installations-for-the-authenticated-app--code-samples)
#### Request example
get/app/installations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations`
The permissions the installation has are included under the `permissions` key.
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "account": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "access_tokens_url": "https://api.github.com/app/installations/1/access_tokens",     "repositories_url": "https://api.github.com/installation/repositories",     "html_url": "https://github.com/organizations/github/settings/installations/1",     "app_id": 1,     "target_id": 1,     "target_type": "Organization",     "permissions": {       "checks": "write",       "metadata": "read",       "contents": "read"     },     "events": [       "push",       "pull_request"     ],     "single_file_name": "config.yaml",     "has_multiple_single_files": true,     "single_file_paths": [       "config.yml",       ".github/issue_TEMPLATE.md"     ],     "repository_selection": "selected",     "created_at": "2017-07-08T16:18:44-04:00",     "updated_at": "2017-07-08T16:18:44-04:00",     "app_slug": "github-actions",     "suspended_at": null,     "suspended_by": null   } ]`
## [Get an installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app)
Enables an authenticated GitHub App to find an installation's information using the installation id.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Get an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`installation_id` integer Required The unique identifier of the installation.
### [HTTP response status codes for "Get an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-installation-for-the-authenticated-app--code-samples)
#### Request example
get/app/installations/{installation_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations/1`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "account": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "access_tokens_url": "https://api.github.com/app/installations/1/access_tokens",   "repositories_url": "https://api.github.com/installation/repositories",   "html_url": "https://github.com/organizations/github/settings/installations/1",   "app_id": 1,   "target_id": 1,   "target_type": "Organization",   "permissions": {     "checks": "write",     "metadata": "read",     "contents": "read"   },   "events": [     "push",     "pull_request"   ],   "single_file_name": "config.yaml",   "has_multiple_single_files": true,   "single_file_paths": [     "config.yml",     ".github/issue_TEMPLATE.md"   ],   "repository_selection": "selected",   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "app_slug": "github-actions",   "suspended_at": null,   "suspended_by": null }`
## [Delete an installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app)
Uninstalls a GitHub App on a user, organization, or enterprise account. If you prefer to temporarily suspend an app's access to your account's resources, then we recommend the "[Suspend an app installation](https://docs.github.com/rest/apps/apps#suspend-an-app-installation)" endpoint.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Delete an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Delete an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`installation_id` integer Required The unique identifier of the installation.
### [HTTP response status codes for "Delete an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete an installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#delete-an-installation-for-the-authenticated-app--code-samples)
#### Request example
delete/app/installations/{installation_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations/1`
Response
`Status: 204`
## [Create an installation access token for an app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app)
Creates an installation access token that enables a GitHub App to make authenticated API requests for the app's installation on an organization or individual account. Installation tokens expire one hour from the time you create them. Using an expired token produces a status code of `401 - Unauthorized`, and requires creating a new installation token. By default the installation token has access to all repositories that the installation can access.
Optionally, you can use the `repositories` or `repository_ids` body parameters to specify individual repositories that the installation access token can access. If you don't use `repositories` or `repository_ids` to grant access to specific repositories, the installation access token will have access to all repositories that the installation was granted access to. The installation access token cannot be granted access to repositories that the installation was not granted access to. Up to 500 repositories can be listed in this manner.
Optionally, use the `permissions` body parameter to specify the permissions that the installation access token should have. If `permissions` is not specified, the installation access token will have all of the permissions that were granted to the app. The installation access token cannot be granted permissions that the app was not granted.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Create an installation access token for an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Create an installation access token for an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`installation_id` integer Required The unique identifier of the installation.
Body parameters Name, Type, Description
---
`repositories` array of strings List of repository names that the token should have access to
`repository_ids` array of integers List of repository IDs that the token should have access to
`permissions` object The permissions granted to the user access token.
Properties of `permissions` | Name, Type, Description
---
`actions` string The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. Can be one of: `read`, `write`
`administration` string The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. Can be one of: `read`, `write`
`artifact_metadata` string The level of permission to grant the access token to create and retrieve build artifact metadata records. Can be one of: `read`, `write`
`attestations` string The level of permission to create and retrieve the access token for repository attestations. Can be one of: `read`, `write`
`checks` string The level of permission to grant the access token for checks on code. Can be one of: `read`, `write`
`codespaces` string The level of permission to grant the access token to create, edit, delete, and list Codespaces. Can be one of: `read`, `write`
`contents` string The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. Can be one of: `read`, `write`
`dependabot_secrets` string The level of permission to grant the access token to manage Dependabot secrets. Can be one of: `read`, `write`
`deployments` string The level of permission to grant the access token for deployments and deployment statuses. Can be one of: `read`, `write`
`discussions` string The level of permission to grant the access token for discussions and related comments and labels. Can be one of: `read`, `write`
`environments` string The level of permission to grant the access token for managing repository environments. Can be one of: `read`, `write`
`issues` string The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. Can be one of: `read`, `write`
`merge_queues` string The level of permission to grant the access token to manage the merge queues for a repository. Can be one of: `read`, `write`
`metadata` string The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. Can be one of: `read`, `write`
`packages` string The level of permission to grant the access token for packages published to GitHub Packages. Can be one of: `read`, `write`
`pages` string The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. Can be one of: `read`, `write`
`pull_requests` string The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. Can be one of: `read`, `write`
`repository_custom_properties` string The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. Can be one of: `read`, `write`
`repository_hooks` string The level of permission to grant the access token to manage the post-receive hooks for a repository. Can be one of: `read`, `write`
`repository_projects` string The level of permission to grant the access token to manage repository projects, columns, and cards. Can be one of: `read`, `write`, `admin`
`secret_scanning_alerts` string The level of permission to grant the access token to view and manage secret scanning alerts. Can be one of: `read`, `write`
`secrets` string The level of permission to grant the access token to manage repository secrets. Can be one of: `read`, `write`
`security_events` string The level of permission to grant the access token to view and manage security events like code scanning alerts. Can be one of: `read`, `write`
`single_file` string The level of permission to grant the access token to manage just a single file. Can be one of: `read`, `write`
`statuses` string The level of permission to grant the access token for commit statuses. Can be one of: `read`, `write`
`vulnerability_alerts` string The level of permission to grant the access token to manage Dependabot alerts. Can be one of: `read`, `write`
`workflows` string The level of permission to grant the access token to update GitHub Actions workflow files. Value: `write`
`custom_properties_for_organizations` string The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. Can be one of: `read`, `write`
`members` string The level of permission to grant the access token for organization teams and members. Can be one of: `read`, `write`
`organization_administration` string The level of permission to grant the access token to manage access to an organization. Can be one of: `read`, `write`
`organization_custom_roles` string The level of permission to grant the access token for custom repository roles management. Can be one of: `read`, `write`
`organization_custom_org_roles` string The level of permission to grant the access token for custom organization roles management. Can be one of: `read`, `write`
`organization_custom_properties` string The level of permission to grant the access token for repository custom properties management at the organization level. Can be one of: `read`, `write`, `admin`
`organization_copilot_seat_management` string The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. Value: `write`
`organization_announcement_banners` string The level of permission to grant the access token to view and manage announcement banners for an organization. Can be one of: `read`, `write`
`organization_events` string The level of permission to grant the access token to view events triggered by an activity in an organization. Value: `read`
`organization_hooks` string The level of permission to grant the access token to manage the post-receive hooks for an organization. Can be one of: `read`, `write`
`organization_personal_access_tokens` string The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. Can be one of: `read`, `write`
`organization_personal_access_token_requests` string The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. Can be one of: `read`, `write`
`organization_plan` string The level of permission to grant the access token for viewing an organization's plan. Value: `read`
`organization_projects` string The level of permission to grant the access token to manage organization projects and projects public preview (where available). Can be one of: `read`, `write`, `admin`
`organization_packages` string The level of permission to grant the access token for organization packages published to GitHub Packages. Can be one of: `read`, `write`
`organization_secrets` string The level of permission to grant the access token to manage organization secrets. Can be one of: `read`, `write`
`organization_self_hosted_runners` string The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. Can be one of: `read`, `write`
`organization_user_blocking` string The level of permission to grant the access token to view and manage users blocked by the organization. Can be one of: `read`, `write`
`email_addresses` string The level of permission to grant the access token to manage the email addresses belonging to a user. Can be one of: `read`, `write`
`followers` string The level of permission to grant the access token to manage the followers belonging to a user. Can be one of: `read`, `write`
`git_ssh_keys` string The level of permission to grant the access token to manage git SSH keys. Can be one of: `read`, `write`
`gpg_keys` string The level of permission to grant the access token to view and manage GPG keys belonging to a user. Can be one of: `read`, `write`
`interaction_limits` string The level of permission to grant the access token to view and manage interaction limits on a repository. Can be one of: `read`, `write`
`profile` string The level of permission to grant the access token to manage the profile settings belonging to a user. Value: `write`
`starring` string The level of permission to grant the access token to list and manage repositories a user is starring. Can be one of: `read`, `write`
`enterprise_custom_properties_for_organizations` string The level of permission to grant the access token for organization custom properties management at the enterprise level. Can be one of: `read`, `write`, `admin`
### [HTTP response status codes for "Create an installation access token for an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app--status-codes)
Status code | Description
---|---
`201` | Created
`401` | Requires authentication
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create an installation access token for an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-an-installation-access-token-for-an-app--code-samples)
#### Request example
post/app/installations/{installation_id}/access_tokens
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations/1/access_tokens \   -d '{"repositories":["Hello-World"],"permissions":{"issues":"write","contents":"read"}}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "token": "ghs_16C7e42F292c6912E7710c838347Ae178B4a",   "expires_at": "2016-07-11T22:14:10Z",   "permissions": {     "issues": "write",     "contents": "read"   },   "repository_selection": "selected",   "repositories": [     {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World.git",       "mirror_url": "git:git.example.com/octocat/Hello-World",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World",       "homepage": "https://github.com",       "language": null,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "size": 108,       "default_branch": "master",       "open_issues_count": 0,       "is_template": true,       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "template_repository": null,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://github.com/licenses/mit"       },       "forks": 1,       "open_issues": 1,       "watchers": 1     }   ] }`
## [Suspend an app installation](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation)
Suspends a GitHub App on a user, organization, or enterprise account, which blocks the app from accessing the account's resources. When a GitHub App is suspended, the app's access to the GitHub API or webhook events is blocked for that account.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Suspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Suspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`installation_id` integer Required The unique identifier of the installation.
### [HTTP response status codes for "Suspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Suspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#suspend-an-app-installation--code-samples)
#### Request example
put/app/installations/{installation_id}/suspended
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations/1/suspended`
Response
`Status: 204`
## [Unsuspend an app installation](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation)
Removes a GitHub App installation suspension.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Unsuspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Unsuspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`installation_id` integer Required The unique identifier of the installation.
### [HTTP response status codes for "Unsuspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Unsuspend an app installation"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#unsuspend-an-app-installation--code-samples)
#### Request example
delete/app/installations/{installation_id}/suspended
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/app/installations/1/suspended`
Response
`Status: 204`
## [Create a scoped access token](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token)
Use a non-scoped user access token to create a repository-scoped and/or permission-scoped user access token. You can specify which repositories the token can access and which permissions are granted to the token.
Invalid tokens will return `404 NOT FOUND`.
### [Basic authentication for "Create a scoped access token"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token--basic-authentication)
You must use [Basic Authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) to use this endpoint. Use the application's `client_id` as the username and the `client_secret` as the password.
### [Parameters for "Create a scoped access token"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`client_id` string Required The client ID of the GitHub app.
Body parameters Name, Type, Description
---
`access_token` string Required The access token used to authenticate to the GitHub API.
`target` string The name of the user or organization to scope the user access token to. **Required** unless `target_id` is specified.
`target_id` integer The ID of the user or organization to scope the user access token to. **Required** unless `target` is specified.
`repositories` array of strings The list of repository names to scope the user access token to. `repositories` may not be specified if `repository_ids` is specified.
`repository_ids` array of integers The list of repository IDs to scope the user access token to. `repository_ids` may not be specified if `repositories` is specified.
`permissions` object The permissions granted to the user access token.
Properties of `permissions` | Name, Type, Description
---
`actions` string The level of permission to grant the access token for GitHub Actions workflows, workflow runs, and artifacts. Can be one of: `read`, `write`
`administration` string The level of permission to grant the access token for repository creation, deletion, settings, teams, and collaborators creation. Can be one of: `read`, `write`
`artifact_metadata` string The level of permission to grant the access token to create and retrieve build artifact metadata records. Can be one of: `read`, `write`
`attestations` string The level of permission to create and retrieve the access token for repository attestations. Can be one of: `read`, `write`
`checks` string The level of permission to grant the access token for checks on code. Can be one of: `read`, `write`
`codespaces` string The level of permission to grant the access token to create, edit, delete, and list Codespaces. Can be one of: `read`, `write`
`contents` string The level of permission to grant the access token for repository contents, commits, branches, downloads, releases, and merges. Can be one of: `read`, `write`
`dependabot_secrets` string The level of permission to grant the access token to manage Dependabot secrets. Can be one of: `read`, `write`
`deployments` string The level of permission to grant the access token for deployments and deployment statuses. Can be one of: `read`, `write`
`discussions` string The level of permission to grant the access token for discussions and related comments and labels. Can be one of: `read`, `write`
`environments` string The level of permission to grant the access token for managing repository environments. Can be one of: `read`, `write`
`issues` string The level of permission to grant the access token for issues and related comments, assignees, labels, and milestones. Can be one of: `read`, `write`
`merge_queues` string The level of permission to grant the access token to manage the merge queues for a repository. Can be one of: `read`, `write`
`metadata` string The level of permission to grant the access token to search repositories, list collaborators, and access repository metadata. Can be one of: `read`, `write`
`packages` string The level of permission to grant the access token for packages published to GitHub Packages. Can be one of: `read`, `write`
`pages` string The level of permission to grant the access token to retrieve Pages statuses, configuration, and builds, as well as create new builds. Can be one of: `read`, `write`
`pull_requests` string The level of permission to grant the access token for pull requests and related comments, assignees, labels, milestones, and merges. Can be one of: `read`, `write`
`repository_custom_properties` string The level of permission to grant the access token to view and edit custom properties for a repository, when allowed by the property. Can be one of: `read`, `write`
`repository_hooks` string The level of permission to grant the access token to manage the post-receive hooks for a repository. Can be one of: `read`, `write`
`repository_projects` string The level of permission to grant the access token to manage repository projects, columns, and cards. Can be one of: `read`, `write`, `admin`
`secret_scanning_alerts` string The level of permission to grant the access token to view and manage secret scanning alerts. Can be one of: `read`, `write`
`secrets` string The level of permission to grant the access token to manage repository secrets. Can be one of: `read`, `write`
`security_events` string The level of permission to grant the access token to view and manage security events like code scanning alerts. Can be one of: `read`, `write`
`single_file` string The level of permission to grant the access token to manage just a single file. Can be one of: `read`, `write`
`statuses` string The level of permission to grant the access token for commit statuses. Can be one of: `read`, `write`
`vulnerability_alerts` string The level of permission to grant the access token to manage Dependabot alerts. Can be one of: `read`, `write`
`workflows` string The level of permission to grant the access token to update GitHub Actions workflow files. Value: `write`
`custom_properties_for_organizations` string The level of permission to grant the access token to view and edit custom properties for an organization, when allowed by the property. Can be one of: `read`, `write`
`members` string The level of permission to grant the access token for organization teams and members. Can be one of: `read`, `write`
`organization_administration` string The level of permission to grant the access token to manage access to an organization. Can be one of: `read`, `write`
`organization_custom_roles` string The level of permission to grant the access token for custom repository roles management. Can be one of: `read`, `write`
`organization_custom_org_roles` string The level of permission to grant the access token for custom organization roles management. Can be one of: `read`, `write`
`organization_custom_properties` string The level of permission to grant the access token for repository custom properties management at the organization level. Can be one of: `read`, `write`, `admin`
`organization_copilot_seat_management` string The level of permission to grant the access token for managing access to GitHub Copilot for members of an organization with a Copilot Business subscription. This property is in public preview and is subject to change. Value: `write`
`organization_announcement_banners` string The level of permission to grant the access token to view and manage announcement banners for an organization. Can be one of: `read`, `write`
`organization_events` string The level of permission to grant the access token to view events triggered by an activity in an organization. Value: `read`
`organization_hooks` string The level of permission to grant the access token to manage the post-receive hooks for an organization. Can be one of: `read`, `write`
`organization_personal_access_tokens` string The level of permission to grant the access token for viewing and managing fine-grained personal access token requests to an organization. Can be one of: `read`, `write`
`organization_personal_access_token_requests` string The level of permission to grant the access token for viewing and managing fine-grained personal access tokens that have been approved by an organization. Can be one of: `read`, `write`
`organization_plan` string The level of permission to grant the access token for viewing an organization's plan. Value: `read`
`organization_projects` string The level of permission to grant the access token to manage organization projects and projects public preview (where available). Can be one of: `read`, `write`, `admin`
`organization_packages` string The level of permission to grant the access token for organization packages published to GitHub Packages. Can be one of: `read`, `write`
`organization_secrets` string The level of permission to grant the access token to manage organization secrets. Can be one of: `read`, `write`
`organization_self_hosted_runners` string The level of permission to grant the access token to view and manage GitHub Actions self-hosted runners available to an organization. Can be one of: `read`, `write`
`organization_user_blocking` string The level of permission to grant the access token to view and manage users blocked by the organization. Can be one of: `read`, `write`
`email_addresses` string The level of permission to grant the access token to manage the email addresses belonging to a user. Can be one of: `read`, `write`
`followers` string The level of permission to grant the access token to manage the followers belonging to a user. Can be one of: `read`, `write`
`git_ssh_keys` string The level of permission to grant the access token to manage git SSH keys. Can be one of: `read`, `write`
`gpg_keys` string The level of permission to grant the access token to view and manage GPG keys belonging to a user. Can be one of: `read`, `write`
`interaction_limits` string The level of permission to grant the access token to view and manage interaction limits on a repository. Can be one of: `read`, `write`
`profile` string The level of permission to grant the access token to manage the profile settings belonging to a user. Value: `write`
`starring` string The level of permission to grant the access token to list and manage repositories a user is starring. Can be one of: `read`, `write`
`enterprise_custom_properties_for_organizations` string The level of permission to grant the access token for organization custom properties management at the enterprise level. Can be one of: `read`, `write`, `admin`
### [HTTP response status codes for "Create a scoped access token"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a scoped access token"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#create-a-scoped-access-token--code-samples)
#### Request example
post/applications/{client_id}/token/scoped
  * cURL
  * JavaScript


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -u "<YOUR_CLIENT_ID>:<YOUR_CLIENT_SECRET>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/applications/Iv1.8a61f9b3a7aba766/token/scoped \   -d '{"access_token":"e72e16c7e42f292c6912e7710c838347ae178b4a","target":"octocat","permissions":{"metadata":"read","issues":"write","contents":"read"}}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "url": "https://api.github.com/authorizations/1",   "scopes": [],   "token": "ghu_16C7e42F292c6912E7710c838347Ae178B4a",   "token_last_eight": "Ae178B4a",   "hashed_token": "25f94a2a5c7fbaf499c665bc73d67c1c87e496da8985131633ee0a95819db2e8",   "app": {     "url": "http://my-github-app.com",     "name": "my github app",     "client_id": "Iv1.8a61f9b3a7aba766"   },   "note": "optional note",   "note_url": "http://optional/note/url",   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "fingerprint": "jklmnop12345678",   "expires_at": "2011-09-08T17:26:27Z",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "installation": {     "permissions": {       "metadata": "read",       "issues": "write",       "contents": "read"     },     "repository_selection": "selected",     "single_file_name": ".github/workflow.yml",     "repositories_url": "https://api.github.com/user/repos",     "account": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "has_multiple_single_files": false,     "single_file_paths": []   } }`
## [Get an app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app)
The `:app_slug` is just the URL-friendly name of your GitHub App. You can find this on the settings page for your GitHub App (e.g., `https://github.com/settings/apps/:app_slug`).
### [Fine-grained access tokens for "Get an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`app_slug` string Required
### [HTTP response status codes for "Get an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get an app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-app--code-samples)
#### Request example
get/apps/{app_slug}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/apps/APP_SLUG`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "slug": "octoapp",   "client_id": "Iv1.ab1112223334445c",   "node_id": "MDExOkludGVncmF0aW9uMQ==",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "name": "Octocat App",   "description": "",   "external_url": "https://example.com",   "html_url": "https://github.com/apps/octoapp",   "created_at": "2017-07-08T16:18:44-04:00",   "updated_at": "2017-07-08T16:18:44-04:00",   "permissions": {     "metadata": "read",     "contents": "read",     "issues": "write",     "single_file": "write"   },   "events": [     "push",     "pull_request"   ] }`
## [Get an organization installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app)
Enables an authenticated GitHub App to find the organization's installation information.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Get an organization installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get an organization installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get an organization installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get an organization installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-an-organization-installation-for-the-authenticated-app--code-samples)
#### Request example
get/orgs/{org}/installation
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/installation`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "account": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "avatar_url": "https://github.com/images/error/hubot_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/orgs/github",     "html_url": "https://github.com/github",     "followers_url": "https://api.github.com/users/github/followers",     "following_url": "https://api.github.com/users/github/following{/other_user}",     "gists_url": "https://api.github.com/users/github/gists{/gist_id}",     "starred_url": "https://api.github.com/users/github/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/github/subscriptions",     "organizations_url": "https://api.github.com/users/github/orgs",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "received_events_url": "https://api.github.com/users/github/received_events",     "type": "Organization",     "site_admin": false   },   "repository_selection": "all",   "access_tokens_url": "https://api.github.com/app/installations/1/access_tokens",   "repositories_url": "https://api.github.com/installation/repositories",   "html_url": "https://github.com/organizations/github/settings/installations/1",   "app_id": 1,   "client_id": "Iv1.ab1112223334445c",   "target_id": 1,   "target_type": "Organization",   "permissions": {     "checks": "write",     "metadata": "read",     "contents": "read"   },   "events": [     "push",     "pull_request"   ],   "created_at": "2018-02-09T20:51:14Z",   "updated_at": "2018-02-09T20:51:14Z",   "single_file_name": "config.yml",   "has_multiple_single_files": true,   "single_file_paths": [     "config.yml",     ".github/issue_TEMPLATE.md"   ],   "app_slug": "github-actions",   "suspended_at": null,   "suspended_by": null }`
## [Get a repository installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app)
Enables an authenticated GitHub App to find the repository's installation information. The installation's account type will be either an organization or a user account, depending which account the repository belongs to.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Get a repository installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get a repository installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get a repository installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`404` | Resource not found
### [Code samples for "Get a repository installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-repository-installation-for-the-authenticated-app--code-samples)
#### Request example
get/repos/{owner}/{repo}/installation
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/installation`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "account": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "avatar_url": "https://github.com/images/error/hubot_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/orgs/github",     "html_url": "https://github.com/github",     "followers_url": "https://api.github.com/users/github/followers",     "following_url": "https://api.github.com/users/github/following{/other_user}",     "gists_url": "https://api.github.com/users/github/gists{/gist_id}",     "starred_url": "https://api.github.com/users/github/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/github/subscriptions",     "organizations_url": "https://api.github.com/users/github/orgs",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "received_events_url": "https://api.github.com/users/github/received_events",     "type": "Organization",     "site_admin": false   },   "repository_selection": "all",   "access_tokens_url": "https://api.github.com/app/installations/1/access_tokens",   "repositories_url": "https://api.github.com/installation/repositories",   "html_url": "https://github.com/organizations/github/settings/installations/1",   "app_id": 1,   "client_id": "Iv1.ab1112223334445c",   "target_id": 1,   "target_type": "Organization",   "permissions": {     "checks": "write",     "metadata": "read",     "contents": "read"   },   "events": [     "push",     "pull_request"   ],   "created_at": "2018-02-09T20:51:14Z",   "updated_at": "2018-02-09T20:51:14Z",   "single_file_name": "config.yml",   "has_multiple_single_files": true,   "single_file_paths": [     "config.yml",     ".github/issue_TEMPLATE.md"   ],   "app_slug": "github-actions",   "suspended_at": null,   "suspended_by": null }`
## [Get a user installation for the authenticated app](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app)
Enables an authenticated GitHub App to find the user’s installation information.
You must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint.
### [Fine-grained access tokens for "Get a user installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get a user installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
### [HTTP response status codes for "Get a user installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get a user installation for the authenticated app"](https://docs.github.com/en/rest/apps/apps?apiVersion=2022-11-28#get-a-user-installation-for-the-authenticated-app--code-samples)
#### Request example
get/users/{username}/installation
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/installation`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "account": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "avatar_url": "https://github.com/images/error/hubot_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/orgs/github",     "html_url": "https://github.com/github",     "followers_url": "https://api.github.com/users/github/followers",     "following_url": "https://api.github.com/users/github/following{/other_user}",     "gists_url": "https://api.github.com/users/github/gists{/gist_id}",     "starred_url": "https://api.github.com/users/github/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/github/subscriptions",     "organizations_url": "https://api.github.com/users/github/orgs",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "received_events_url": "https://api.github.com/users/github/received_events",     "type": "Organization",     "site_admin": false   },   "repository_selection": "all",   "access_tokens_url": "https://api.github.com/app/installations/1/access_tokens",   "repositories_url": "https://api.github.com/installation/repositories",   "html_url": "https://github.com/organizations/github/settings/installations/1",   "app_id": 1,   "client_id": "Iv1.ab1112223334445c",   "target_id": 1,   "target_type": "Organization",   "permissions": {     "checks": "write",     "metadata": "read",     "contents": "read"   },   "events": [     "push",     "pull_request"   ],   "created_at": "2018-02-09T20:51:14Z",   "updated_at": "2018-02-09T20:51:14Z",   "single_file_name": "config.yml",   "has_multiple_single_files": true,   "single_file_paths": [     "config.yml",     ".github/issue_TEMPLATE.md"   ],   "app_slug": "github-actions",   "suspended_at": null,   "suspended_by": null }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/apps/apps.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Apps - GitHub Docs
