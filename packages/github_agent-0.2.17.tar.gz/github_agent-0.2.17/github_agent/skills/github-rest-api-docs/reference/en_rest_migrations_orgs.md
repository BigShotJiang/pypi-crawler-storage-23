[Skip to main content](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Migrations](https://docs.github.com/en/rest/migrations "Migrations")/
  * [Organizations](https://docs.github.com/en/rest/migrations/orgs "Organizations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
      * [About organization migrations](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#about-organization-migrations)
      * [List organization migrations](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations)
      * [Start an organization migration](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration)
      * [Get an organization migration status](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status)
      * [Download an organization migration archive](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive)
      * [Delete an organization migration archive](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive)
      * [Unlock an organization repository](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository)
      * [List repositories in an organization migration](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration)
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Migrations](https://docs.github.com/en/rest/migrations "Migrations")/
  * [Organizations](https://docs.github.com/en/rest/migrations/orgs "Organizations")


# REST API endpoints for organization migrations
Use the REST API to export one or more repositories so you can move them to GitHub Enterprise Server.
## [About organization migrations](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#about-organization-migrations)
These endpoints are only available to authenticated organization owners. For more information, see [Roles in an organization](https://docs.github.com/en/organizations/managing-peoples-access-to-your-organization-with-roles/roles-in-an-organization#permission-levels-for-an-organization) and [Authenticating to the REST API](https://docs.github.com/en/rest/overview/authenticating-to-the-rest-api).
You can use these endpoints to export one or more repositories so you can move them to a GitHub Enterprise Server instance. For more information, see [Exporting migration data from GitHub.com](https://docs.github.com/en/migrations/using-ghe-migrator/exporting-migration-data-from-githubcom).
## [List organization migrations](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations)
Lists the most recent migrations, including both exports (which can be started through the REST API) and imports (which cannot be started using the REST API).
A list of `repositories` is only returned for export migrations.
### [Fine-grained access tokens for "List organization migrations"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List organization migrations"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`exclude` array Exclude attributes from the API response to improve performance
### [HTTP response status codes for "List organization migrations"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List organization migrations"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-organization-migrations--code-samples)
#### Request example
get/orgs/{org}/migrations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 79,     "owner": {       "login": "github",       "id": 1,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "repos_url": "https://api.github.com/orgs/github/repos",       "events_url": "https://api.github.com/orgs/github/events",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": true     },     "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",     "state": "pending",     "lock_repositories": true,     "exclude_attachments": false,     "exclude_releases": false,     "exclude_owner_projects": false,     "repositories": [       {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "clone_url": "https://github.com/octocat/Hello-World.git",         "mirror_url": "git:git.example.com/octocat/Hello-World",         "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",         "svn_url": "https://svn.github.com/octocat/Hello-World",         "homepage": "https://github.com",         "language": null,         "forks_count": 9,         "stargazers_count": 80,         "watchers_count": 80,         "size": 108,         "default_branch": "master",         "open_issues_count": 0,         "is_template": true,         "topics": [           "octocat",           "atom",           "electron",           "api"         ],         "has_issues": true,         "has_projects": true,         "has_wiki": true,         "has_pages": false,         "has_downloads": true,         "archived": false,         "disabled": false,         "visibility": "public",         "pushed_at": "2011-01-26T19:06:43Z",         "created_at": "2011-01-26T19:01:12Z",         "updated_at": "2011-01-26T19:14:43Z",         "permissions": {           "admin": false,           "push": false,           "pull": true         },         "allow_rebase_merge": true,         "template_repository": null,         "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",         "allow_squash_merge": true,         "allow_auto_merge": false,         "delete_branch_on_merge": true,         "allow_merge_commit": true,         "subscribers_count": 42,         "network_count": 0,         "license": {           "key": "mit",           "name": "MIT License",           "url": "https://api.github.com/licenses/mit",           "spdx_id": "MIT",           "node_id": "MDc6TGljZW5zZW1pdA==",           "html_url": "https://api.github.com/licenses/mit"         },         "forks": 1,         "open_issues": 1,         "watchers": 1       }     ],     "url": "https://api.github.com/orgs/octo-org/migrations/79",     "created_at": "2015-07-06T15:33:38-07:00",     "updated_at": "2015-07-06T15:33:38-07:00",     "node_id": "MDQ6VXNlcjE="   } ]`
## [Start an organization migration](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration)
Initiates the generation of a migration archive.
### [Fine-grained access tokens for "Start an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Start an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`repositories` array of strings Required A list of arrays indicating which repositories should be migrated.
`lock_repositories` boolean Indicates whether repositories should be locked (to prevent manipulation) while migrating data. Default: `false`
`exclude_metadata` boolean Indicates whether metadata should be excluded and only git source should be included for the migration. Default: `false`
`exclude_git_data` boolean Indicates whether the repository git data should be excluded from the migration. Default: `false`
`exclude_attachments` boolean Indicates whether attachments should be excluded from the migration (to reduce migration archive file size). Default: `false`
`exclude_releases` boolean Indicates whether releases should be excluded from the migration (to reduce migration archive file size). Default: `false`
`exclude_owner_projects` boolean Indicates whether projects owned by the organization or users should be excluded. from the migration. Default: `false`
`org_metadata_only` boolean Indicates whether this should only include organization metadata (repositories array should be empty and will ignore other flags). Default: `false`
`exclude` array of strings Exclude related items from being returned in the response in order to improve performance of the request. Supported values are: `repositories`
### [HTTP response status codes for "Start an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Start an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#start-an-organization-migration--code-samples)
#### Request example
post/orgs/{org}/migrations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations \   -d '{"repositories":["github/Hello-World"],"lock_repositories":true}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 79,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "owner": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": true   },   "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",   "state": "pending",   "lock_repositories": true,   "exclude_attachments": false,   "exclude_releases": false,   "exclude_owner_projects": false,   "repositories": [     {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World.git",       "mirror_url": "git:git.example.com/octocat/Hello-World",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World",       "homepage": "https://github.com",       "language": null,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "size": 108,       "default_branch": "master",       "open_issues_count": 0,       "is_template": true,       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "template_repository": null,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://api.github.com/licenses/mit"       },       "forks": 1,       "open_issues": 1,       "watchers": 1     }   ],   "url": "https://api.github.com/orgs/octo-org/migrations/79",   "created_at": "2015-07-06T15:33:38-07:00",   "updated_at": "2015-07-06T15:33:38-07:00" }`
## [Get an organization migration status](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status)
Fetches the status of a migration.
The `state` of a migration can be one of the following values:
  * `pending`, which means the migration hasn't started yet.
  * `exporting`, which means the migration is in progress.
  * `exported`, which means the migration finished successfully.
  * `failed`, which means the migration failed.


### [Fine-grained access tokens for "Get an organization migration status"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get an organization migration status"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`migration_id` integer Required The unique identifier of the migration.
Query parameters Name, Type, Description
---
`exclude` array Exclude attributes from the API response to improve performance
### [HTTP response status codes for "Get an organization migration status"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status--status-codes)
Status code | Description
---|---
`200` |
  * `pending`, which means the migration hasn't started yet.
  * `exporting`, which means the migration is in progress.
  * `exported`, which means the migration finished successfully.
  * `failed`, which means the migration failed.


`404` | Resource not found
### [Code samples for "Get an organization migration status"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#get-an-organization-migration-status--code-samples)
#### Request example
get/orgs/{org}/migrations/{migration_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations/MIGRATION_ID`
####
  * `pending`, which means the migration hasn't started yet.
  * `exporting`, which means the migration is in progress.
  * `exported`, which means the migration finished successfully.
  * `failed`, which means the migration failed.


  * Example response
  * Response schema


`Status: 200`
`{   "id": 79,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "owner": {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": true   },   "guid": "0b989ba4-242f-11e5-81e1-c7b6966d2516",   "state": "exported",   "lock_repositories": true,   "exclude_attachments": false,   "exclude_releases": false,   "exclude_owner_projects": false,   "repositories": [     {       "id": 1296269,       "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",       "name": "Hello-World",       "full_name": "octocat/Hello-World",       "owner": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "private": false,       "html_url": "https://github.com/octocat/Hello-World",       "description": "This your first repo!",       "fork": false,       "url": "https://api.github.com/repos/octocat/Hello-World",       "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",       "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",       "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",       "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",       "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",       "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",       "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",       "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",       "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",       "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",       "events_url": "https://api.github.com/repos/octocat/Hello-World/events",       "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",       "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",       "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",       "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",       "git_url": "git:github.com/octocat/Hello-World.git",       "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",       "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",       "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",       "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",       "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",       "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",       "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",       "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",       "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",       "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",       "ssh_url": "git@github.com:octocat/Hello-World.git",       "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",       "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",       "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",       "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",       "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",       "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",       "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",       "clone_url": "https://github.com/octocat/Hello-World.git",       "mirror_url": "git:git.example.com/octocat/Hello-World",       "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",       "svn_url": "https://svn.github.com/octocat/Hello-World",       "homepage": "https://github.com",       "language": null,       "forks_count": 9,       "stargazers_count": 80,       "watchers_count": 80,       "size": 108,       "default_branch": "master",       "open_issues_count": 0,       "is_template": true,       "topics": [         "octocat",         "atom",         "electron",         "api"       ],       "has_issues": true,       "has_projects": true,       "has_wiki": true,       "has_pages": false,       "has_downloads": true,       "archived": false,       "disabled": false,       "visibility": "public",       "pushed_at": "2011-01-26T19:06:43Z",       "created_at": "2011-01-26T19:01:12Z",       "updated_at": "2011-01-26T19:14:43Z",       "permissions": {         "admin": false,         "push": false,         "pull": true       },       "allow_rebase_merge": true,       "template_repository": null,       "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",       "allow_squash_merge": true,       "allow_auto_merge": false,       "delete_branch_on_merge": true,       "allow_merge_commit": true,       "subscribers_count": 42,       "network_count": 0,       "license": {         "key": "mit",         "name": "MIT License",         "url": "https://api.github.com/licenses/mit",         "spdx_id": "MIT",         "node_id": "MDc6TGljZW5zZW1pdA==",         "html_url": "https://api.github.com/licenses/mit"       },       "forks": 1,       "open_issues": 1,       "watchers": 1     }   ],   "url": "https://api.github.com/orgs/octo-org/migrations/79",   "created_at": "2015-07-06T15:33:38-07:00",   "updated_at": "2015-07-06T15:33:38-07:00" }`
## [Download an organization migration archive](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive)
Fetches the URL to a migration archive.
### [Fine-grained access tokens for "Download an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Download an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`migration_id` integer Required The unique identifier of the migration.
### [HTTP response status codes for "Download an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive--status-codes)
Status code | Description
---|---
`302` | Found
`404` | Resource not found
### [Code samples for "Download an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#download-an-organization-migration-archive--code-samples)
#### Request example
get/orgs/{org}/migrations/{migration_id}/archive
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations/MIGRATION_ID/archive`
Response
`Status: 302`
## [Delete an organization migration archive](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive)
Deletes a previous migration archive. Migration archives are automatically deleted after seven days.
### [Fine-grained access tokens for "Delete an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Delete an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`migration_id` integer Required The unique identifier of the migration.
### [HTTP response status codes for "Delete an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Delete an organization migration archive"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#delete-an-organization-migration-archive--code-samples)
#### Request example
delete/orgs/{org}/migrations/{migration_id}/archive
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations/MIGRATION_ID/archive`
Response
`Status: 204`
## [Unlock an organization repository](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository)
Unlocks a repository that was locked for migration. You should unlock each migrated repository and [delete them](https://docs.github.com/rest/repos/repos#delete-a-repository) when the migration is complete and you no longer need the source data.
### [Fine-grained access tokens for "Unlock an organization repository"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Unlock an organization repository"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`migration_id` integer Required The unique identifier of the migration.
`repo_name` string Required repo_name parameter
### [HTTP response status codes for "Unlock an organization repository"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
### [Code samples for "Unlock an organization repository"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#unlock-an-organization-repository--code-samples)
#### Request example
delete/orgs/{org}/migrations/{migration_id}/repos/{repo_name}/lock
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations/MIGRATION_ID/repos/REPO_NAME/lock`
Response
`Status: 204`
## [List repositories in an organization migration](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration)
List all the repositories for this organization migration.
### [Fine-grained access tokens for "List repositories in an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List repositories in an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
`migration_id` integer Required The unique identifier of the migration.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repositories in an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List repositories in an organization migration"](https://docs.github.com/en/rest/migrations/orgs?apiVersion=2022-11-28#list-repositories-in-an-organization-migration--code-samples)
#### Request example
get/orgs/{org}/migrations/{migration_id}/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/migrations/MIGRATION_ID/repositories`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "has_discussions": false,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/migrations/orgs.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for organization migrations - GitHub Docs
