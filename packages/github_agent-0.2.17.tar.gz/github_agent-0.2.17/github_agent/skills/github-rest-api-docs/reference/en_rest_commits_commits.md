[Skip to main content](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Commits](https://docs.github.com/en/rest/commits "Commits")/
  * [Commits](https://docs.github.com/en/rest/commits/commits "Commits")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
      * [List commits](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits)
      * [List branches for HEAD commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit)
      * [List pull requests associated with a commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit)
      * [Get a commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit)
      * [Compare two commits](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits)
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Commits](https://docs.github.com/en/rest/commits "Commits")/
  * [Commits](https://docs.github.com/en/rest/commits/commits "Commits")


# REST API endpoints for commits
Use the REST API to interact with commits.
## [List commits](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits)
**Signature verification object**
The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object:
Name | Type | Description
---|---|---
`verified` | `boolean` | Indicates whether GitHub considers the signature in this commit to be verified.
`reason` | `string` | The reason for verified value. Possible values and their meanings are enumerated in table below.
`signature` | `string` | The signature that was extracted from the commit.
`payload` | `string` | The value that was signed.
`verified_at` | `string` | The date the signature was verified by GitHub.
These are the possible values for `reason` in the `verification` object:
Value | Description
---|---
`expired_key` | The key that made the signature is expired.
`not_signing_key` | The "signing" flag is not among the usage flags in the GPG key that made the signature.
`gpgverify_error` | There was an error communicating with the signature verification service.
`gpgverify_unavailable` | The signature verification service is currently unavailable.
`unsigned` | The object does not include a signature.
`unknown_signature_type` | A non-PGP signature was found in the commit.
`no_user` | No user was associated with the `committer` email address in the commit.
`unverified_email` | The `committer` email address in the commit was associated with a user, but the email address is not verified on their account.
`bad_email` | The `committer` email address in the commit is not included in the identities of the PGP key that made the signature.
`unknown_key` | The key that made the signature has not been registered with any user's account.
`malformed_signature` | There was an error parsing the signature.
`invalid` | The signature could not be cryptographically verified using the key whose key-id was found in the signature.
`valid` | None of the above errors applied, so the signature is considered to be verified.
### [Fine-grained access tokens for "List commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`sha` string SHA or branch to start listing commits from. Default: the repository’s default branch (usually `main`).
`path` string Only commits containing this file path will be returned.
`author` string GitHub username or email address to use to filter by commit author.
`committer` string GitHub username or email address to use to filter by commit committer.
`since` string Only show results that were last updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
`until` string Only commits before this date will be returned. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`. Due to limitations of Git, timestamps must be between 1970-01-01 and 2099-12-31 (inclusive) or unexpected results may be returned.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`404` | Resource not found
`409` | Conflict
`500` | Internal Error
### [Code samples for "List commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-commits--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",     "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",     "html_url": "https://github.com/octocat/Hello-World/commit/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e/comments",     "commit": {       "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "author": {         "name": "Monalisa Octocat",         "email": "support@github.com",         "date": "2011-04-14T16:00:49Z"       },       "committer": {         "name": "Monalisa Octocat",         "email": "support@github.com",         "date": "2011-04-14T16:00:49Z"       },       "message": "Fix all the bugs",       "tree": {         "url": "https://api.github.com/repos/octocat/Hello-World/tree/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       },       "comment_count": 0,       "verification": {         "verified": false,         "reason": "unsigned",         "signature": null,         "payload": null,         "verified_at": null       }     },     "author": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "committer": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "parents": [       {         "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       }     ]   } ]`
## [List branches for HEAD commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit)
Protected branches are available in public repositories with GitHub Free and GitHub Free for organizations, and in public and private repositories with GitHub Pro, GitHub Team, GitHub Enterprise Cloud, and GitHub Enterprise Server. For more information, see [GitHub's products](https://docs.github.com/github/getting-started-with-github/githubs-products) in the GitHub Help documentation.
Returns all branches where the given commit SHA is the HEAD, or latest commit for the branch.
### [Fine-grained access tokens for "List branches for HEAD commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List branches for HEAD commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`commit_sha` string Required The SHA of the commit.
### [HTTP response status codes for "List branches for HEAD commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit--status-codes)
Status code | Description
---|---
`200` | OK
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List branches for HEAD commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-branches-for-head-commit--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits/{commit_sha}/branches-where-head
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits/COMMIT_SHA/branches-where-head`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "name": "branch_5",     "commit": {       "sha": "c5b97d5ae6c19d5c5df71a34c7fbeeda2479ccbc",       "url": "https://api.github.com/repos/octocat/Hello-World/commits/c5b97d5ae6c19d5c5df71a34c7fbeeda2479ccbc"     },     "protected": false   } ]`
## [List pull requests associated with a commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit)
Lists the merged pull request that introduced the commit to the repository. If the commit is not present in the default branch, it will return merged and open pull requests associated with the commit.
To list the open or merged pull requests associated with a branch, you can set the `commit_sha` parameter to the branch name.
### [Fine-grained access tokens for "List pull requests associated with a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pull requests" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List pull requests associated with a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`commit_sha` string Required The SHA of the commit.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List pull requests associated with a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit--status-codes)
Status code | Description
---|---
`200` | OK
`409` | Conflict
### [Code samples for "List pull requests associated with a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#list-pull-requests-associated-with-a-commit--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits/{commit_sha}/pulls
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits/COMMIT_SHA/pulls`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/repos/octocat/Hello-World/pulls/1347",     "id": 1,     "node_id": "MDExOlB1bGxSZXF1ZXN0MQ==",     "html_url": "https://github.com/octocat/Hello-World/pull/1347",     "diff_url": "https://github.com/octocat/Hello-World/pull/1347.diff",     "patch_url": "https://github.com/octocat/Hello-World/pull/1347.patch",     "issue_url": "https://api.github.com/repos/octocat/Hello-World/issues/1347",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/pulls/1347/commits",     "review_comments_url": "https://api.github.com/repos/octocat/Hello-World/pulls/1347/comments",     "review_comment_url": "https://api.github.com/repos/octocat/Hello-World/pulls/comments{/number}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/issues/1347/comments",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "number": 1347,     "state": "open",     "locked": true,     "title": "Amazing new feature",     "user": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "body": "Please pull these awesome changes in!",     "labels": [       {         "id": 208045946,         "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",         "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",         "name": "bug",         "description": "Something isn't working",         "color": "f29513",         "default": true       }     ],     "milestone": {       "url": "https://api.github.com/repos/octocat/Hello-World/milestones/1",       "html_url": "https://github.com/octocat/Hello-World/milestones/v1.0",       "labels_url": "https://api.github.com/repos/octocat/Hello-World/milestones/1/labels",       "id": 1002604,       "node_id": "MDk6TWlsZXN0b25lMTAwMjYwNA==",       "number": 1,       "state": "open",       "title": "v1.0",       "description": "Tracking milestone for version 1.0",       "creator": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "open_issues": 4,       "closed_issues": 8,       "created_at": "2011-04-10T20:09:31Z",       "updated_at": "2014-03-03T18:58:10Z",       "closed_at": "2013-02-12T13:22:01Z",       "due_on": "2012-10-09T23:39:01Z"     },     "active_lock_reason": "too heated",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:01:12Z",     "closed_at": "2011-01-26T19:01:12Z",     "merged_at": "2011-01-26T19:01:12Z",     "merge_commit_sha": "e5bd3914e2e596debea16f433f57875b5b90bcd6",     "assignee": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "assignees": [       {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       {         "login": "hubot",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/hubot_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/hubot",         "html_url": "https://github.com/hubot",         "followers_url": "https://api.github.com/users/hubot/followers",         "following_url": "https://api.github.com/users/hubot/following{/other_user}",         "gists_url": "https://api.github.com/users/hubot/gists{/gist_id}",         "starred_url": "https://api.github.com/users/hubot/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/hubot/subscriptions",         "organizations_url": "https://api.github.com/users/hubot/orgs",         "repos_url": "https://api.github.com/users/hubot/repos",         "events_url": "https://api.github.com/users/hubot/events{/privacy}",         "received_events_url": "https://api.github.com/users/hubot/received_events",         "type": "User",         "site_admin": true       }     ],     "requested_reviewers": [       {         "login": "other_user",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/other_user_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/other_user",         "html_url": "https://github.com/other_user",         "followers_url": "https://api.github.com/users/other_user/followers",         "following_url": "https://api.github.com/users/other_user/following{/other_user}",         "gists_url": "https://api.github.com/users/other_user/gists{/gist_id}",         "starred_url": "https://api.github.com/users/other_user/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/other_user/subscriptions",         "organizations_url": "https://api.github.com/users/other_user/orgs",         "repos_url": "https://api.github.com/users/other_user/repos",         "events_url": "https://api.github.com/users/other_user/events{/privacy}",         "received_events_url": "https://api.github.com/users/other_user/received_events",         "type": "User",         "site_admin": false       }     ],     "requested_teams": [       {         "id": 1,         "node_id": "MDQ6VGVhbTE=",         "url": "https://api.github.com/teams/1",         "html_url": "https://github.com/orgs/github/teams/justice-league",         "name": "Justice League",         "slug": "justice-league",         "description": "A great team.",         "privacy": "closed",         "permission": "admin",         "notification_setting": "notifications_enabled",         "members_url": "https://api.github.com/teams/1/members{/member}",         "repositories_url": "https://api.github.com/teams/1/repos",         "parent": null       }     ],     "head": {       "label": "octocat:new-topic",       "ref": "new-topic",       "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",       "user": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "repo": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "clone_url": "https://github.com/octocat/Hello-World.git",         "mirror_url": "git:git.example.com/octocat/Hello-World",         "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",         "svn_url": "https://svn.github.com/octocat/Hello-World",         "homepage": "https://github.com",         "language": null,         "forks_count": 9,         "stargazers_count": 80,         "watchers_count": 80,         "size": 108,         "default_branch": "master",         "open_issues_count": 0,         "is_template": true,         "topics": [           "octocat",           "atom",           "electron",           "api"         ],         "has_issues": true,         "has_projects": true,         "has_wiki": true,         "has_pages": false,         "has_downloads": true,         "archived": false,         "disabled": false,         "visibility": "public",         "pushed_at": "2011-01-26T19:06:43Z",         "created_at": "2011-01-26T19:01:12Z",         "updated_at": "2011-01-26T19:14:43Z",         "permissions": {           "admin": false,           "push": false,           "pull": true         },         "allow_rebase_merge": true,         "template_repository": null,         "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",         "allow_squash_merge": true,         "allow_auto_merge": false,         "delete_branch_on_merge": true,         "allow_merge_commit": true,         "subscribers_count": 42,         "network_count": 0,         "license": {           "key": "mit",           "name": "MIT License",           "url": "https://api.github.com/licenses/mit",           "spdx_id": "MIT",           "node_id": "MDc6TGljZW5zZW1pdA==",           "html_url": "https://github.com/licenses/mit"         },         "forks": 1,         "open_issues": 1,         "watchers": 1       }     },     "base": {       "label": "octocat:master",       "ref": "master",       "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",       "user": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "repo": {         "id": 1296269,         "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",         "name": "Hello-World",         "full_name": "octocat/Hello-World",         "owner": {           "login": "octocat",           "id": 1,           "node_id": "MDQ6VXNlcjE=",           "avatar_url": "https://github.com/images/error/octocat_happy.gif",           "gravatar_id": "",           "url": "https://api.github.com/users/octocat",           "html_url": "https://github.com/octocat",           "followers_url": "https://api.github.com/users/octocat/followers",           "following_url": "https://api.github.com/users/octocat/following{/other_user}",           "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",           "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",           "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",           "organizations_url": "https://api.github.com/users/octocat/orgs",           "repos_url": "https://api.github.com/users/octocat/repos",           "events_url": "https://api.github.com/users/octocat/events{/privacy}",           "received_events_url": "https://api.github.com/users/octocat/received_events",           "type": "User",           "site_admin": false         },         "private": false,         "html_url": "https://github.com/octocat/Hello-World",         "description": "This your first repo!",         "fork": false,         "url": "https://api.github.com/repos/octocat/Hello-World",         "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",         "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",         "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",         "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",         "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",         "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",         "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",         "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",         "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",         "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",         "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",         "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",         "events_url": "https://api.github.com/repos/octocat/Hello-World/events",         "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",         "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",         "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",         "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",         "git_url": "git:github.com/octocat/Hello-World.git",         "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",         "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",         "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",         "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",         "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",         "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",         "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",         "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",         "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",         "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",         "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",         "ssh_url": "git@github.com:octocat/Hello-World.git",         "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",         "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",         "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",         "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",         "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",         "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",         "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",         "clone_url": "https://github.com/octocat/Hello-World.git",         "mirror_url": "git:git.example.com/octocat/Hello-World",         "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",         "svn_url": "https://svn.github.com/octocat/Hello-World",         "homepage": "https://github.com",         "language": null,         "forks_count": 9,         "stargazers_count": 80,         "watchers_count": 80,         "size": 108,         "default_branch": "master",         "open_issues_count": 0,         "is_template": true,         "topics": [           "octocat",           "atom",           "electron",           "api"         ],         "has_issues": true,         "has_projects": true,         "has_wiki": true,         "has_pages": false,         "has_downloads": true,         "archived": false,         "disabled": false,         "visibility": "public",         "pushed_at": "2011-01-26T19:06:43Z",         "created_at": "2011-01-26T19:01:12Z",         "updated_at": "2011-01-26T19:14:43Z",         "permissions": {           "admin": false,           "push": false,           "pull": true         },         "allow_rebase_merge": true,         "template_repository": null,         "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",         "allow_squash_merge": true,         "allow_auto_merge": false,         "delete_branch_on_merge": true,         "allow_merge_commit": true,         "subscribers_count": 42,         "network_count": 0,         "license": {           "key": "mit",           "name": "MIT License",           "url": "https://api.github.com/licenses/mit",           "spdx_id": "MIT",           "node_id": "MDc6TGljZW5zZW1pdA==",           "html_url": "https://github.com/licenses/mit"         },         "forks": 1,         "open_issues": 1,         "watchers": 1       }     },     "_links": {       "self": {         "href": "https://api.github.com/repos/octocat/Hello-World/pulls/1347"       },       "html": {         "href": "https://github.com/octocat/Hello-World/pull/1347"       },       "issue": {         "href": "https://api.github.com/repos/octocat/Hello-World/issues/1347"       },       "comments": {         "href": "https://api.github.com/repos/octocat/Hello-World/issues/1347/comments"       },       "review_comments": {         "href": "https://api.github.com/repos/octocat/Hello-World/pulls/1347/comments"       },       "review_comment": {         "href": "https://api.github.com/repos/octocat/Hello-World/pulls/comments{/number}"       },       "commits": {         "href": "https://api.github.com/repos/octocat/Hello-World/pulls/1347/commits"       },       "statuses": {         "href": "https://api.github.com/repos/octocat/Hello-World/statuses/6dcb09b5b57875f334f61aebed695e2e4193db5e"       }     },     "author_association": "OWNER",     "auto_merge": null,     "draft": false   } ]`
## [Get a commit](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit)
Returns the contents of a single commit reference. You must have `read` access for the repository to use this endpoint.
If there are more than 300 files in the commit diff and the default JSON media type is requested, the response will include pagination link headers for the remaining files, up to a limit of 3000 files. Each page contains the static commit information, and the only changes are to the file listing.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)." Pagination query parameters are not supported for these media types.
  * **`application/vnd.github.diff`**: Returns the diff of the commit. Larger diffs may time out and return a 5xx status code.
  * **`application/vnd.github.patch`**: Returns the patch of the commit. Diffs with binary data will have no`patch` property. Larger diffs may time out and return a 5xx status code.
  * **`application/vnd.github.sha`**: Returns the commit's SHA-1 hash. You can use this endpoint to check if a remote reference's SHA-1 hash is the same as your local reference's SHA-1 hash by providing the local SHA-1 reference as the ETag.


**Signature verification object**
The response will include a `verification` object that describes the result of verifying the commit's signature. The following fields are included in the `verification` object:
Name | Type | Description
---|---|---
`verified` | `boolean` | Indicates whether GitHub considers the signature in this commit to be verified.
`reason` | `string` | The reason for verified value. Possible values and their meanings are enumerated in table below.
`signature` | `string` | The signature that was extracted from the commit.
`payload` | `string` | The value that was signed.
`verified_at` | `string` | The date the signature was verified by GitHub.
These are the possible values for `reason` in the `verification` object:
Value | Description
---|---
`expired_key` | The key that made the signature is expired.
`not_signing_key` | The "signing" flag is not among the usage flags in the GPG key that made the signature.
`gpgverify_error` | There was an error communicating with the signature verification service.
`gpgverify_unavailable` | The signature verification service is currently unavailable.
`unsigned` | The object does not include a signature.
`unknown_signature_type` | A non-PGP signature was found in the commit.
`no_user` | No user was associated with the `committer` email address in the commit.
`unverified_email` | The `committer` email address in the commit was associated with a user, but the email address is not verified on their account.
`bad_email` | The `committer` email address in the commit is not included in the identities of the PGP key that made the signature.
`unknown_key` | The key that made the signature has not been registered with any user's account.
`malformed_signature` | There was an error parsing the signature.
`invalid` | The signature could not be cryptographically verified using the key whose key-id was found in the signature.
`valid` | None of the above errors applied, so the signature is considered to be verified.
### [Fine-grained access tokens for "Get a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ref` string Required The commit reference. Can be a commit SHA, branch name (`heads/BRANCH_NAME`), or tag name (`tags/TAG_NAME`). For more information, see "[Git References](https://git-scm.com/book/en/v2/Git-Internals-Git-References)" in the Git documentation.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "Get a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Get a commit"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#get-a-commit--code-samples)
#### Request example
get/repos/{owner}/{repo}/commits/{ref}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/commits/REF`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",   "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",   "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",   "html_url": "https://github.com/octocat/Hello-World/commit/6dcb09b5b57875f334f61aebed695e2e4193db5e",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e/comments",   "commit": {     "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "author": {       "name": "Monalisa Octocat",       "email": "mona@github.com",       "date": "2011-04-14T16:00:49Z"     },     "committer": {       "name": "Monalisa Octocat",       "email": "mona@github.com",       "date": "2011-04-14T16:00:49Z"     },     "message": "Fix all the bugs",     "tree": {       "url": "https://api.github.com/repos/octocat/Hello-World/tree/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"     },     "comment_count": 0,     "verification": {       "verified": false,       "reason": "unsigned",       "signature": null,       "payload": null,       "verified_at": null     }   },   "author": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "committer": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "parents": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"     }   ],   "stats": {     "additions": 104,     "deletions": 4,     "total": 108   },   "files": [     {       "filename": "file1.txt",       "additions": 10,       "deletions": 2,       "changes": 12,       "status": "modified",       "raw_url": "https://github.com/octocat/Hello-World/raw/7ca483543807a51b6079e54ac4cc392bc29ae284/file1.txt",       "blob_url": "https://github.com/octocat/Hello-World/blob/7ca483543807a51b6079e54ac4cc392bc29ae284/file1.txt",       "patch": "@@ -29,7 +29,7 @@\n....."     }   ] }`
## [Compare two commits](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits)
Compares two commits against one another. You can compare refs (branches or tags) and commit SHAs in the same repository, or you can compare refs and commit SHAs that exist in different repositories within the same repository network, including fork branches. For more information about how to view a repository's network, see "[Understanding connections between repositories](https://docs.github.com/repositories/viewing-activity-and-data-for-your-repository/understanding-connections-between-repositories)."
This endpoint is equivalent to running the `git log BASE..HEAD` command, but it returns commits in a different order. The `git log BASE..HEAD` command returns commits in reverse chronological order, whereas the API returns commits in chronological order.
This endpoint supports the following custom media types. For more information, see "[Media types](https://docs.github.com/rest/using-the-rest-api/getting-started-with-the-rest-api#media-types)."
  * **`application/vnd.github.diff`**: Returns the diff of the commit.
  * **`application/vnd.github.patch`**: Returns the patch of the commit. Diffs with binary data will have no`patch` property.


The API response includes details about the files that were changed between the two commits. This includes the status of the change (if a file was added, removed, modified, or renamed), and details of the change itself. For example, files with a `renamed` status have a `previous_filename` field showing the previous filename of the file, and files with a `modified` status have a `patch` field showing the changes made to the file.
When calling this endpoint without any paging parameter (`per_page` or `page`), the returned list is limited to 250 commits, and the last commit in the list is the most recent of the entire comparison.
**Working with large comparisons**
To process a response with a large number of commits, use a query parameter (`per_page` or `page`) to paginate the results. When using pagination:
  * The list of changed files is only shown on the first page of results, and it includes up to 300 changed files for the entire comparison.
  * The results are returned in chronological order, but the last commit in the returned list may not be the most recent one in the entire set if there are more pages of results.


For more information on working with pagination, see "[Using pagination in the REST API](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api)."
**Signature verification object**
The response will include a `verification` object that describes the result of verifying the commit's signature. The `verification` object includes the following fields:
Name | Type | Description
---|---|---
`verified` | `boolean` | Indicates whether GitHub considers the signature in this commit to be verified.
`reason` | `string` | The reason for verified value. Possible values and their meanings are enumerated in table below.
`signature` | `string` | The signature that was extracted from the commit.
`payload` | `string` | The value that was signed.
`verified_at` | `string` | The date the signature was verified by GitHub.
These are the possible values for `reason` in the `verification` object:
Value | Description
---|---
`expired_key` | The key that made the signature is expired.
`not_signing_key` | The "signing" flag is not among the usage flags in the GPG key that made the signature.
`gpgverify_error` | There was an error communicating with the signature verification service.
`gpgverify_unavailable` | The signature verification service is currently unavailable.
`unsigned` | The object does not include a signature.
`unknown_signature_type` | A non-PGP signature was found in the commit.
`no_user` | No user was associated with the `committer` email address in the commit.
`unverified_email` | The `committer` email address in the commit was associated with a user, but the email address is not verified on their account.
`bad_email` | The `committer` email address in the commit is not included in the identities of the PGP key that made the signature.
`unknown_key` | The key that made the signature has not been registered with any user's account.
`malformed_signature` | There was an error parsing the signature.
`invalid` | The signature could not be cryptographically verified using the key whose key-id was found in the signature.
`valid` | None of the above errors applied, so the signature is considered to be verified.
### [Fine-grained access tokens for "Compare two commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Compare two commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`basehead` string Required The base branch and head branch to compare. This parameter expects the format `BASE...HEAD`. Both must be branch names in `repo`. To compare with a branch that exists in a different repository in the same network as `repo`, the `basehead` parameter expects the format `USERNAME:BASE...USERNAME:HEAD`.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "Compare two commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
`503` | Service unavailable
### [Code samples for "Compare two commits"](https://docs.github.com/en/rest/commits/commits?apiVersion=2022-11-28#compare-two-commits--code-samples)
#### Request example
get/repos/{owner}/{repo}/compare/{basehead}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/compare/BASEHEAD`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/octocat/Hello-World/compare/master...topic",   "html_url": "https://github.com/octocat/Hello-World/compare/master...topic",   "permalink_url": "https://github.com/octocat/Hello-World/compare/octocat:bbcd538c8e72b8c175046e27cc8f907076331401...octocat:0328041d1152db8ae77652d1618a02e57f745f17",   "diff_url": "https://github.com/octocat/Hello-World/compare/master...topic.diff",   "patch_url": "https://github.com/octocat/Hello-World/compare/master...topic.patch",   "base_commit": {     "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",     "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",     "html_url": "https://github.com/octocat/Hello-World/commit/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e/comments",     "commit": {       "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "author": {         "name": "Monalisa Octocat",         "email": "mona@github.com",         "date": "2011-04-14T16:00:49Z"       },       "committer": {         "name": "Monalisa Octocat",         "email": "mona@github.com",         "date": "2011-04-14T16:00:49Z"       },       "message": "Fix all the bugs",       "tree": {         "url": "https://api.github.com/repos/octocat/Hello-World/tree/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       },       "comment_count": 0,       "verification": {         "verified": false,         "reason": "unsigned",         "signature": null,         "payload": null,         "verified_at": null       }     },     "author": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "committer": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "parents": [       {         "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       }     ]   },   "merge_base_commit": {     "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",     "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",     "html_url": "https://github.com/octocat/Hello-World/commit/6dcb09b5b57875f334f61aebed695e2e4193db5e",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e/comments",     "commit": {       "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "author": {         "name": "Monalisa Octocat",         "email": "mona@github.com",         "date": "2011-04-14T16:00:49Z"       },       "committer": {         "name": "Monalisa Octocat",         "email": "mona@github.com",         "date": "2011-04-14T16:00:49Z"       },       "message": "Fix all the bugs",       "tree": {         "url": "https://api.github.com/repos/octocat/Hello-World/tree/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       },       "comment_count": 0,       "verification": {         "verified": false,         "reason": "unsigned",         "signature": null,         "payload": null,         "verified_at": null       }     },     "author": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "committer": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "parents": [       {         "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"       }     ]   },   "status": "behind",   "ahead_by": 1,   "behind_by": 2,   "total_commits": 1,   "commits": [     {       "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e",       "node_id": "MDY6Q29tbWl0NmRjYjA5YjViNTc4NzVmMzM0ZjYxYWViZWQ2OTVlMmU0MTkzZGI1ZQ==",       "html_url": "https://github.com/octocat/Hello-World/commit/6dcb09b5b57875f334f61aebed695e2e4193db5e",       "comments_url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e/comments",       "commit": {         "url": "https://api.github.com/repos/octocat/Hello-World/git/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",         "author": {           "name": "Monalisa Octocat",           "email": "mona@github.com",           "date": "2011-04-14T16:00:49Z"         },         "committer": {           "name": "Monalisa Octocat",           "email": "mona@github.com",           "date": "2011-04-14T16:00:49Z"         },         "message": "Fix all the bugs",         "tree": {           "url": "https://api.github.com/repos/octocat/Hello-World/tree/6dcb09b5b57875f334f61aebed695e2e4193db5e",           "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"         },         "comment_count": 0,         "verification": {           "verified": false,           "reason": "unsigned",           "signature": null,           "payload": null,           "verified_at": null         }       },       "author": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "committer": {         "login": "octocat",         "id": 1,         "node_id": "MDQ6VXNlcjE=",         "avatar_url": "https://github.com/images/error/octocat_happy.gif",         "gravatar_id": "",         "url": "https://api.github.com/users/octocat",         "html_url": "https://github.com/octocat",         "followers_url": "https://api.github.com/users/octocat/followers",         "following_url": "https://api.github.com/users/octocat/following{/other_user}",         "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",         "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",         "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",         "organizations_url": "https://api.github.com/users/octocat/orgs",         "repos_url": "https://api.github.com/users/octocat/repos",         "events_url": "https://api.github.com/users/octocat/events{/privacy}",         "received_events_url": "https://api.github.com/users/octocat/received_events",         "type": "User",         "site_admin": false       },       "parents": [         {           "url": "https://api.github.com/repos/octocat/Hello-World/commits/6dcb09b5b57875f334f61aebed695e2e4193db5e",           "sha": "6dcb09b5b57875f334f61aebed695e2e4193db5e"         }       ]     }   ],   "files": [     {       "sha": "bbcd538c8e72b8c175046e27cc8f907076331401",       "filename": "file1.txt",       "status": "added",       "additions": 103,       "deletions": 21,       "changes": 124,       "blob_url": "https://github.com/octocat/Hello-World/blob/6dcb09b5b57875f334f61aebed695e2e4193db5e/file1.txt",       "raw_url": "https://github.com/octocat/Hello-World/raw/6dcb09b5b57875f334f61aebed695e2e4193db5e/file1.txt",       "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/file1.txt?ref=6dcb09b5b57875f334f61aebed695e2e4193db5e",       "patch": "@@ -132,7 +132,7 @@ module Test @@ -1000,7 +1000,7 @@ module Test"     }   ] }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/commits/commits.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for commits - GitHub Docs
