[Skip to main content](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [OAuth authorizations](https://docs.github.com/en/rest/apps/oauth-applications "OAuth authorizations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
      * [About OAuth apps and OAuth authorizations of GitHub Apps](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#about-oauth-apps-and-oauth-authorizations-of-github-apps)
      * [Delete an app authorization](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization)
      * [Check a token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token)
      * [Reset a token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token)
      * [Delete an app token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token)
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [OAuth authorizations](https://docs.github.com/en/rest/apps/oauth-applications "OAuth authorizations")


# REST API endpoints for OAuth authorizations
Use the REST API to interact with OAuth apps and OAuth authorizations of GitHub Apps
## [About OAuth apps and OAuth authorizations of GitHub Apps](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#about-oauth-apps-and-oauth-authorizations-of-github-apps)
You can use these endpoints to manage the OAuth tokens that OAuth apps or GitHub Apps use to access people's accounts on GitHub.
Tokens for OAuth apps have the prefix `gho_`, while OAuth tokens for GitHub Apps, used for authenticating on behalf of the user, have the prefix `ghu_`. You can use the following endpoints for both types of OAuth tokens.
## [Delete an app authorization](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization)
OAuth and GitHub application owners can revoke a grant for their application and a specific user. You must provide a valid OAuth `access_token` as an input parameter and the grant for the token's owner will be deleted. Deleting an application's grant will also delete all OAuth tokens associated with the application for the user. Once deleted, the application will have no access to the user's account and will no longer be listed on [the application authorizations settings screen within GitHub](https://github.com/settings/applications#authorized).
### [Basic authentication for "Delete an app authorization"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization--basic-authentication)
You must use [Basic Authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) to use this endpoint. Use the application's `client_id` as the username and the `client_secret` as the password.
### [Parameters for "Delete an app authorization"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`client_id` string Required The client ID of the GitHub app.
Body parameters Name, Type, Description
---
`access_token` string Required The OAuth access token used to authenticate to the GitHub API.
### [HTTP response status codes for "Delete an app authorization"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization--status-codes)
Status code | Description
---|---
`204` | No Content
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete an app authorization"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-authorization--code-samples)
#### Request example
delete/applications/{client_id}/grant
  * cURL
  * JavaScript


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -u "<YOUR_CLIENT_ID>:<YOUR_CLIENT_SECRET>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/applications/Iv1.8a61f9b3a7aba766/grant \   -d '{"access_token":"e72e16c7e42f292c6912e7710c838347ae178b4a"}'`
Response
`Status: 204`
## [Check a token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token)
OAuth applications and GitHub applications with OAuth authorizations can use this API method for checking OAuth token validity without exceeding the normal rate limits for failed login attempts. Authentication works differently with this particular endpoint. Invalid tokens will return `404 NOT FOUND`.
### [Basic authentication for "Check a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token--basic-authentication)
You must use [Basic Authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) to use this endpoint. Use the application's `client_id` as the username and the `client_secret` as the password.
### [Parameters for "Check a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`client_id` string Required The client ID of the GitHub app.
Body parameters Name, Type, Description
---
`access_token` string Required The access_token of the OAuth or GitHub application.
### [HTTP response status codes for "Check a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Check a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#check-a-token--code-samples)
#### Request example
post/applications/{client_id}/token
  * cURL
  * JavaScript


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -u "<YOUR_CLIENT_ID>:<YOUR_CLIENT_SECRET>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/applications/Iv1.8a61f9b3a7aba766/token \   -d '{"access_token":"e72e16c7e42f292c6912e7710c838347ae178b4a"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "url": "https://api.github.com/authorizations/1",   "scopes": [     "public_repo",     "user"   ],   "token": "ghu_16C7e42F292c6912E7710c838347Ae178B4a",   "token_last_eight": "Ae178B4a",   "hashed_token": "25f94a2a5c7fbaf499c665bc73d67c1c87e496da8985131633ee0a95819db2e8",   "app": {     "url": "http://my-github-app.com",     "name": "my github app",     "client_id": "Iv1.8a61f9b3a7aba766"   },   "note": "optional note",   "note_url": "http://optional/note/url",   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "fingerprint": "jklmnop12345678",   "expires_at": "2011-09-08T17:26:27Z",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } }`
## [Reset a token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token)
OAuth applications and GitHub applications with OAuth authorizations can use this API method to reset a valid OAuth token without end-user involvement. Applications must save the "token" property in the response because changes take effect immediately. Invalid tokens will return `404 NOT FOUND`.
### [Basic authentication for "Reset a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token--basic-authentication)
You must use [Basic Authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) to use this endpoint. Use the application's `client_id` as the username and the `client_secret` as the password.
### [Parameters for "Reset a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`client_id` string Required The client ID of the GitHub app.
Body parameters Name, Type, Description
---
`access_token` string Required The access_token of the OAuth or GitHub application.
### [HTTP response status codes for "Reset a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Reset a token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#reset-a-token--code-samples)
#### Request example
patch/applications/{client_id}/token
  * cURL
  * JavaScript


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -u "<YOUR_CLIENT_ID>:<YOUR_CLIENT_SECRET>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/applications/Iv1.8a61f9b3a7aba766/token \   -d '{"access_token":"e72e16c7e42f292c6912e7710c838347ae178b4a"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1,   "url": "https://api.github.com/authorizations/1",   "scopes": [     "public_repo",     "user"   ],   "token": "ghu_16C7e42F292c6912E7710c838347Ae178B4a",   "token_last_eight": "Ae178B4a",   "hashed_token": "25f94a2a5c7fbaf499c665bc73d67c1c87e496da8985131633ee0a95819db2e8",   "app": {     "url": "http://my-github-app.com",     "name": "my github app",     "client_id": "Iv1.8a61f9b3a7aba766"   },   "note": "optional note",   "note_url": "http://optional/note/url",   "updated_at": "2011-09-06T20:39:23Z",   "created_at": "2011-09-06T17:26:27Z",   "fingerprint": "jklmnop12345678",   "expires_at": "2011-09-08T17:26:27Z",   "user": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   } }`
## [Delete an app token](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token)
OAuth or GitHub application owners can revoke a single token for an OAuth application or a GitHub application with an OAuth authorization.
### [Basic authentication for "Delete an app token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token--basic-authentication)
You must use [Basic Authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) to use this endpoint. Use the application's `client_id` as the username and the `client_secret` as the password.
### [Parameters for "Delete an app token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`client_id` string Required The client ID of the GitHub app.
Body parameters Name, Type, Description
---
`access_token` string Required The OAuth access token used to authenticate to the GitHub API.
### [HTTP response status codes for "Delete an app token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token--status-codes)
Status code | Description
---|---
`204` | No Content
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete an app token"](https://docs.github.com/en/rest/apps/oauth-applications?apiVersion=2022-11-28#delete-an-app-token--code-samples)
#### Request example
delete/applications/{client_id}/token
  * cURL
  * JavaScript


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -u "<YOUR_CLIENT_ID>:<YOUR_CLIENT_SECRET>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/applications/Iv1.8a61f9b3a7aba766/token \   -d '{"access_token":"e72e16c7e42f292c6912e7710c838347ae178b4a"}'`
Response
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/apps/oauth-applications.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for OAuth authorizations - GitHub Docs
