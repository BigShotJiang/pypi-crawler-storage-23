[Skip to main content](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams "Enterprise teams")/
  * [Enterprise team organizations](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations "Enterprise team organizations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
      * [About enterprise team organizations](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#about-enterprise-team-organizations)
      * [Get organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments)
      * [Add organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments)
      * [Remove organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments)
      * [Get organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment)
      * [Add an organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment)
      * [Delete an organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment)
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Enterprise teams](https://docs.github.com/en/rest/enterprise-teams "Enterprise teams")/
  * [Enterprise team organizations](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations "Enterprise team organizations")


# REST API endpoints for enterprise team organizations
Use the REST API to create and manage organization assignments for enterprise teams in your GitHub enterprise.
## [About enterprise team organizations](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#about-enterprise-team-organizations)
These endpoints are currently in public preview and subject to change.
This API documentation is for enterprises on GitHub Enterprise Cloud.
If your enterprise is Copilot Business for non-GHE, please refer to the early access documentation link that was previously shared to you.
These endpoints are only available to authenticated members of the enterprise team's enterprise with classic personal access tokens with the `read:enterprise` [scope](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps) for `GET` APIs and `admin:enterprise` for other APIs.
These endpoints are not compatible with fine-grained personal access tokens or GitHub App access tokens.
GitHub generates the enterprise team's `slug` from the team `name` and adds the `ent:` prefix.
## [Get organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments)
Get all organizations assigned to an enterprise team
### [Fine-grained access tokens for "Get organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (read)


### [Parameters for "Get organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "Get organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments--status-codes)
Status code | Description
---|---
`200` | An array of organizations the team is assigned to
### [Code samples for "Get organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignments--code-samples)
#### Request example
get/enterprises/{enterprise}/teams/{enterprise-team}/organizations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations`
An array of organizations the team is assigned to
  * Example response
  * Response schema


`Status: 200`
`{   "login": "github",   "id": 1,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "url": "https://api.github.com/orgs/github",   "repos_url": "https://api.github.com/orgs/github/repos",   "events_url": "https://api.github.com/orgs/github/events",   "hooks_url": "https://api.github.com/orgs/github/hooks",   "issues_url": "https://api.github.com/orgs/github/issues",   "members_url": "https://api.github.com/orgs/github/members{/member}",   "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "description": "A great organization" }`
## [Add organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments)
Assign an enterprise team to multiple organizations.
### [Fine-grained access tokens for "Add organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Add organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
Body parameters Name, Type, Description
---
`organization_slugs` array of strings Required Organization slug to assign the team to.
### [HTTP response status codes for "Add organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments--status-codes)
Status code | Description
---|---
`200` | Successfully assigned the enterprise team to organizations.
### [Code samples for "Add organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-organization-assignments--code-samples)
#### Request example
post/enterprises/{enterprise}/teams/{enterprise-team}/organizations/add
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations/add \   -d '{"organization_slugs":["github"]}'`
Successfully assigned the enterprise team to organizations.
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "github",     "id": 1,     "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",     "url": "https://api.github.com/orgs/github",     "repos_url": "https://api.github.com/orgs/github/repos",     "events_url": "https://api.github.com/orgs/github/events",     "hooks_url": "https://api.github.com/orgs/github/hooks",     "issues_url": "https://api.github.com/orgs/github/issues",     "members_url": "https://api.github.com/orgs/github/members{/member}",     "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "description": "A great organization"   } ]`
## [Remove organization assignments](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments)
Unassign an enterprise team from multiple organizations.
### [Fine-grained access tokens for "Remove organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Remove organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
Body parameters Name, Type, Description
---
`organization_slugs` array of strings Required Organization slug to unassign the team from.
### [HTTP response status codes for "Remove organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments--status-codes)
Status code | Description
---|---
`204` | Successfully unassigned the enterprise team from organizations.
### [Code samples for "Remove organization assignments"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#remove-organization-assignments--code-samples)
#### Request example
post/enterprises/{enterprise}/teams/{enterprise-team}/organizations/remove
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations/remove \   -d '{"organization_slugs":["github"]}'`
Successfully unassigned the enterprise team from organizations.
`Status: 204`
## [Get organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment)
Check if an enterprise team is assigned to an organization
### [Fine-grained access tokens for "Get organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (read)


### [Parameters for "Get organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Get organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment--status-codes)
Status code | Description
---|---
`200` | The team is assigned to the organization
`404` | The team is not assigned to the organization
### [Code samples for "Get organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#get-organization-assignment--code-samples)
#### Request example
get/enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations/ORG`
The team is assigned to the organization
  * Example response
  * Response schema


`Status: 200`
`{   "login": "github",   "id": 1,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "url": "https://api.github.com/orgs/github",   "repos_url": "https://api.github.com/orgs/github/repos",   "events_url": "https://api.github.com/orgs/github/events",   "hooks_url": "https://api.github.com/orgs/github/hooks",   "issues_url": "https://api.github.com/orgs/github/issues",   "members_url": "https://api.github.com/orgs/github/members{/member}",   "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "description": "A great organization" }`
## [Add an organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment)
Assign an enterprise team to an organization.
### [Fine-grained access tokens for "Add an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Add an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Add an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment--status-codes)
Status code | Description
---|---
`201` | Successfully assigned the enterprise team to the organization.
### [Code samples for "Add an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#add-an-organization-assignment--code-samples)
#### Request example
put/enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations/ORG`
Successfully assigned the enterprise team to the organization.
  * Example response
  * Response schema


`Status: 201`
`{   "login": "github",   "id": 1,   "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",   "url": "https://api.github.com/orgs/github",   "repos_url": "https://api.github.com/orgs/github/repos",   "events_url": "https://api.github.com/orgs/github/events",   "hooks_url": "https://api.github.com/orgs/github/hooks",   "issues_url": "https://api.github.com/orgs/github/issues",   "members_url": "https://api.github.com/orgs/github/members{/member}",   "public_members_url": "https://api.github.com/orgs/github/public_members{/member}",   "avatar_url": "https://github.com/images/error/octocat_happy.gif",   "description": "A great organization" }`
## [Delete an organization assignment](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment)
Unassign an enterprise team from an organization.
### [Fine-grained access tokens for "Delete an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Enterprise teams" enterprise permissions (write)


### [Parameters for "Delete an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`enterprise` string Required The slug version of the enterprise name.
`enterprise-team` string Required The slug version of the enterprise team name. You can also substitute this value with the enterprise team id.
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "Delete an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment--status-codes)
Status code | Description
---|---
`204` | Successfully unassigned the enterprise team from the organization.
### [Code samples for "Delete an organization assignment"](https://docs.github.com/en/rest/enterprise-teams/enterprise-team-organizations?apiVersion=2022-11-28#delete-an-organization-assignment--code-samples)
#### Request example
delete/enterprises/{enterprise}/teams/{enterprise-team}/organizations/{org}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/enterprises/ENTERPRISE/teams/ENTERPRISE-TEAM/organizations/ORG`
Successfully unassigned the enterprise team from the organization.
`Status: 204`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/enterprise-teams/enterprise-team-organizations.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for enterprise team organizations - GitHub Docs
