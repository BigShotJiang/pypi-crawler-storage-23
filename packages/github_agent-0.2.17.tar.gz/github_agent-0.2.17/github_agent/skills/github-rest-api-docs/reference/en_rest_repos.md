[Skip to main content](https://docs.github.com/en/rest/repos?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")


# REST API endpoints for repositories
Use the REST API to create, manage and control the workflow of public and private GitHub repositories.
  * [REST API endpoints for repositories](https://docs.github.com/en/rest/repos/repos)
    * [List organization repositories](https://docs.github.com/en/rest/repos/repos#list-organization-repositories)
    * [Create an organization repository](https://docs.github.com/en/rest/repos/repos#create-an-organization-repository)
    * [Get a repository](https://docs.github.com/en/rest/repos/repos#get-a-repository)
    * [Update a repository](https://docs.github.com/en/rest/repos/repos#update-a-repository)
    * [Delete a repository](https://docs.github.com/en/rest/repos/repos#delete-a-repository)
    * [List repository activities](https://docs.github.com/en/rest/repos/repos#list-repository-activities)
    * [Check if Dependabot security updates are enabled for a repository](https://docs.github.com/en/rest/repos/repos#check-if-dependabot-security-updates-are-enabled-for-a-repository)
    * [Enable Dependabot security updates](https://docs.github.com/en/rest/repos/repos#enable-dependabot-security-updates)
    * [Disable Dependabot security updates](https://docs.github.com/en/rest/repos/repos#disable-dependabot-security-updates)
    * [List CODEOWNERS errors](https://docs.github.com/en/rest/repos/repos#list-codeowners-errors)
    * [List repository contributors](https://docs.github.com/en/rest/repos/repos#list-repository-contributors)
    * [Create a repository dispatch event](https://docs.github.com/en/rest/repos/repos#create-a-repository-dispatch-event)
    * [Check if immutable releases are enabled for a repository](https://docs.github.com/en/rest/repos/repos#check-if-immutable-releases-are-enabled-for-a-repository)
    * [Enable immutable releases](https://docs.github.com/en/rest/repos/repos#enable-immutable-releases)
    * [Disable immutable releases](https://docs.github.com/en/rest/repos/repos#disable-immutable-releases)
    * [List repository languages](https://docs.github.com/en/rest/repos/repos#list-repository-languages)
    * [Check if private vulnerability reporting is enabled for a repository](https://docs.github.com/en/rest/repos/repos#check-if-private-vulnerability-reporting-is-enabled-for-a-repository)
    * [Enable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos#enable-private-vulnerability-reporting-for-a-repository)
    * [Disable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos#disable-private-vulnerability-reporting-for-a-repository)
    * [List repository tags](https://docs.github.com/en/rest/repos/repos#list-repository-tags)
    * [List repository teams](https://docs.github.com/en/rest/repos/repos#list-repository-teams)
    * [Get all repository topics](https://docs.github.com/en/rest/repos/repos#get-all-repository-topics)
    * [Replace all repository topics](https://docs.github.com/en/rest/repos/repos#replace-all-repository-topics)
    * [Transfer a repository](https://docs.github.com/en/rest/repos/repos#transfer-a-repository)
    * [Check if vulnerability alerts are enabled for a repository](https://docs.github.com/en/rest/repos/repos#check-if-vulnerability-alerts-are-enabled-for-a-repository)
    * [Enable vulnerability alerts](https://docs.github.com/en/rest/repos/repos#enable-vulnerability-alerts)
    * [Disable vulnerability alerts](https://docs.github.com/en/rest/repos/repos#disable-vulnerability-alerts)
    * [Create a repository using a template](https://docs.github.com/en/rest/repos/repos#create-a-repository-using-a-template)
    * [List public repositories](https://docs.github.com/en/rest/repos/repos#list-public-repositories)
    * [List repositories for the authenticated user](https://docs.github.com/en/rest/repos/repos#list-repositories-for-the-authenticated-user)
    * [Create a repository for the authenticated user](https://docs.github.com/en/rest/repos/repos#create-a-repository-for-the-authenticated-user)
    * [List repositories for a user](https://docs.github.com/en/rest/repos/repos#list-repositories-for-a-user)
  * [REST API endpoints for repository attestations](https://docs.github.com/en/rest/repos/attestations)
    * [Create an attestation](https://docs.github.com/en/rest/repos/attestations#create-an-attestation)
    * [List attestations](https://docs.github.com/en/rest/repos/attestations#list-attestations)
  * [REST API endpoints for repository autolinks](https://docs.github.com/en/rest/repos/autolinks)
    * [Get all autolinks of a repository](https://docs.github.com/en/rest/repos/autolinks#get-all-autolinks-of-a-repository)
    * [Create an autolink reference for a repository](https://docs.github.com/en/rest/repos/autolinks#create-an-autolink-reference-for-a-repository)
    * [Get an autolink reference of a repository](https://docs.github.com/en/rest/repos/autolinks#get-an-autolink-reference-of-a-repository)
    * [Delete an autolink reference from a repository](https://docs.github.com/en/rest/repos/autolinks#delete-an-autolink-reference-from-a-repository)
  * [REST API endpoints for repository contents](https://docs.github.com/en/rest/repos/contents)
    * [Get repository content](https://docs.github.com/en/rest/repos/contents#get-repository-content)
    * [Create or update file contents](https://docs.github.com/en/rest/repos/contents#create-or-update-file-contents)
    * [Delete a file](https://docs.github.com/en/rest/repos/contents#delete-a-file)
    * [Get a repository README](https://docs.github.com/en/rest/repos/contents#get-a-repository-readme)
    * [Get a repository README for a directory](https://docs.github.com/en/rest/repos/contents#get-a-repository-readme-for-a-directory)
    * [Download a repository archive (tar)](https://docs.github.com/en/rest/repos/contents#download-a-repository-archive-tar)
    * [Download a repository archive (zip)](https://docs.github.com/en/rest/repos/contents#download-a-repository-archive-zip)
  * [REST API endpoints for custom properties](https://docs.github.com/en/rest/repos/custom-properties)
    * [Get all custom property values for a repository](https://docs.github.com/en/rest/repos/custom-properties#get-all-custom-property-values-for-a-repository)
    * [Create or update custom property values for a repository](https://docs.github.com/en/rest/repos/custom-properties#create-or-update-custom-property-values-for-a-repository)
  * [REST API endpoints for forks](https://docs.github.com/en/rest/repos/forks)
    * [List forks](https://docs.github.com/en/rest/repos/forks#list-forks)
    * [Create a fork](https://docs.github.com/en/rest/repos/forks#create-a-fork)
  * [REST API endpoints for rule suites](https://docs.github.com/en/rest/repos/rule-suites)
    * [List repository rule suites](https://docs.github.com/en/rest/repos/rule-suites#list-repository-rule-suites)
    * [Get a repository rule suite](https://docs.github.com/en/rest/repos/rule-suites#get-a-repository-rule-suite)
  * [REST API endpoints for rules](https://docs.github.com/en/rest/repos/rules)
    * [Get rules for a branch](https://docs.github.com/en/rest/repos/rules#get-rules-for-a-branch)
    * [Get all repository rulesets](https://docs.github.com/en/rest/repos/rules#get-all-repository-rulesets)
    * [Create a repository ruleset](https://docs.github.com/en/rest/repos/rules#create-a-repository-ruleset)
    * [Get a repository ruleset](https://docs.github.com/en/rest/repos/rules#get-a-repository-ruleset)
    * [Update a repository ruleset](https://docs.github.com/en/rest/repos/rules#update-a-repository-ruleset)
    * [Delete a repository ruleset](https://docs.github.com/en/rest/repos/rules#delete-a-repository-ruleset)
    * [Get repository ruleset history](https://docs.github.com/en/rest/repos/rules#get-repository-ruleset-history)
    * [Get repository ruleset version](https://docs.github.com/en/rest/repos/rules#get-repository-ruleset-version)
  * [REST API endpoints for repository webhooks](https://docs.github.com/en/rest/repos/webhooks)
    * [List repository webhooks](https://docs.github.com/en/rest/repos/webhooks#list-repository-webhooks)
    * [Create a repository webhook](https://docs.github.com/en/rest/repos/webhooks#create-a-repository-webhook)
    * [Get a repository webhook](https://docs.github.com/en/rest/repos/webhooks#get-a-repository-webhook)
    * [Update a repository webhook](https://docs.github.com/en/rest/repos/webhooks#update-a-repository-webhook)
    * [Delete a repository webhook](https://docs.github.com/en/rest/repos/webhooks#delete-a-repository-webhook)
    * [Get a webhook configuration for a repository](https://docs.github.com/en/rest/repos/webhooks#get-a-webhook-configuration-for-a-repository)
    * [Update a webhook configuration for a repository](https://docs.github.com/en/rest/repos/webhooks#update-a-webhook-configuration-for-a-repository)
    * [List deliveries for a repository webhook](https://docs.github.com/en/rest/repos/webhooks#list-deliveries-for-a-repository-webhook)
    * [Get a delivery for a repository webhook](https://docs.github.com/en/rest/repos/webhooks#get-a-delivery-for-a-repository-webhook)
    * [Redeliver a delivery for a repository webhook](https://docs.github.com/en/rest/repos/webhooks#redeliver-a-delivery-for-a-repository-webhook)
    * [Ping a repository webhook](https://docs.github.com/en/rest/repos/webhooks#ping-a-repository-webhook)
    * [Test the push repository webhook](https://docs.github.com/en/rest/repos/webhooks#test-the-push-repository-webhook)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/repos/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for repositories - GitHub Docs
