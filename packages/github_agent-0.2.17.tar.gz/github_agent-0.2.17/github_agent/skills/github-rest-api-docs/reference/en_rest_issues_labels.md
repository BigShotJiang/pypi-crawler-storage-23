[Skip to main content](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Issues](https://docs.github.com/en/rest/issues "Issues")/
  * [Labels](https://docs.github.com/en/rest/issues/labels "Labels")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
      * [About labels](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#about-labels)
      * [List labels for an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue)
      * [Add labels to an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue)
      * [Set labels for an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue)
      * [Remove all labels from an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue)
      * [Remove a label from an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue)
      * [List labels for a repository](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository)
      * [Create a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label)
      * [Get a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label)
      * [Update a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label)
      * [Delete a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label)
      * [List labels for issues in a milestone](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone)
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Issues](https://docs.github.com/en/rest/issues "Issues")/
  * [Labels](https://docs.github.com/en/rest/issues/labels "Labels")


# REST API endpoints for labels
Use the REST API to manage labels for repositories, issues and pull requests.
## [About labels](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#about-labels)
You can use the REST API to manage labels for a repository and add or remove labels to issues and pull requests. Every pull request is an issue, but not every issue is a pull request. For this reason, "shared" actions for both features, like managing assignees, labels, and milestones, are provided within the Issues endpoints.
## [List labels for an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue)
Lists all labels for an issue.
### [Fine-grained access tokens for "List labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (read)
  * "Pull requests" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`issue_number` integer Required The number that identifies the issue.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`404` | Resource not found
`410` | Gone
### [Code samples for "List labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-an-issue--code-samples)
#### Request example
get/repos/{owner}/{repo}/issues/{issue_number}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/issues/ISSUE_NUMBER/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   },   {     "id": 208045947,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDc=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/enhancement",     "name": "enhancement",     "description": "New feature or request",     "color": "a2eeef",     "default": false   } ]`
## [Add labels to an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue)
Adds labels to an issue.
### [Fine-grained access tokens for "Add labels to an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Add labels to an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`issue_number` integer Required The number that identifies the issue.
Body parameters Name, Type, Description
---
`labels` array of strings The names of the labels to add to the issue's existing labels. You can also pass an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. To replace all of the labels for an issue, use "[Set labels for an issue](https://docs.github.com/rest/issues/labels#set-labels-for-an-issue)."
### [HTTP response status codes for "Add labels to an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`404` | Resource not found
`410` | Gone
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Add labels to an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#add-labels-to-an-issue--code-samples)
#### Request example
post/repos/{owner}/{repo}/issues/{issue_number}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/issues/ISSUE_NUMBER/labels \   -d '{"labels":["bug","enhancement"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   },   {     "id": 208045947,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDc=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/enhancement",     "name": "enhancement",     "description": "New feature or request",     "color": "a2eeef",     "default": false   } ]`
## [Set labels for an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue)
Removes any previous labels and sets the new labels for an issue.
### [Fine-grained access tokens for "Set labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Set labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`issue_number` integer Required The number that identifies the issue.
Body parameters Name, Type, Description
---
`labels` array of strings The names of the labels to set for the issue. The labels you set replace any existing labels. You can pass an empty array to remove all labels. Alternatively, you can pass a single label as a `string` or an `array` of labels directly, but GitHub recommends passing an object with the `labels` key. You can also add labels to the existing labels for an issue. For more information, see "[Add labels to an issue](https://docs.github.com/rest/issues/labels#add-labels-to-an-issue)."
### [HTTP response status codes for "Set labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`404` | Resource not found
`410` | Gone
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Set labels for an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#set-labels-for-an-issue--code-samples)
#### Request example
put/repos/{owner}/{repo}/issues/{issue_number}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/issues/ISSUE_NUMBER/labels \   -d '{"labels":["bug","enhancement"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   },   {     "id": 208045947,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDc=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/enhancement",     "name": "enhancement",     "description": "New feature or request",     "color": "a2eeef",     "default": false   } ]`
## [Remove all labels from an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue)
Removes all labels from an issue.
### [Fine-grained access tokens for "Remove all labels from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Remove all labels from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`issue_number` integer Required The number that identifies the issue.
### [HTTP response status codes for "Remove all labels from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue--status-codes)
Status code | Description
---|---
`204` | No Content
`301` | Moved permanently
`404` | Resource not found
`410` | Gone
### [Code samples for "Remove all labels from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-all-labels-from-an-issue--code-samples)
#### Request example
delete/repos/{owner}/{repo}/issues/{issue_number}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/issues/ISSUE_NUMBER/labels`
Response
`Status: 204`
## [Remove a label from an issue](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue)
Removes the specified label from the issue, and returns the remaining labels on the issue. This endpoint returns a `404 Not Found` status if the label does not exist.
### [Fine-grained access tokens for "Remove a label from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Remove a label from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`issue_number` integer Required The number that identifies the issue.
`name` string Required
### [HTTP response status codes for "Remove a label from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`404` | Resource not found
`410` | Gone
### [Code samples for "Remove a label from an issue"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#remove-a-label-from-an-issue--code-samples)
#### Request example
delete/repos/{owner}/{repo}/issues/{issue_number}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/issues/ISSUE_NUMBER/labels/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   } ]`
## [List labels for a repository](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository)
Lists all labels for a repository.
### [Fine-grained access tokens for "List labels for a repository"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (read)
  * "Pull requests" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List labels for a repository"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List labels for a repository"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List labels for a repository"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   },   {     "id": 208045947,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDc=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/enhancement",     "name": "enhancement",     "description": "New feature or request",     "color": "a2eeef",     "default": false   } ]`
## [Create a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label)
Creates a label for the specified repository with the given name and color. The name and color parameters are required. The color must be a valid [hexadecimal color code](http://www.color-hex.com/).
### [Fine-grained access tokens for "Create a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Create a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)."
`color` string The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`.
`description` string A short description of the label. Must be 100 characters or fewer.
### [HTTP response status codes for "Create a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#create-a-label--code-samples)
#### Request example
post/repos/{owner}/{repo}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/labels \   -d '{"name":"bug","description":"Something isn'\''t working","color":"f29513"}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 208045946,   "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",   "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",   "name": "bug",   "description": "Something isn't working",   "color": "f29513",   "default": true }`
## [Get a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label)
Gets a label using the given name.
### [Fine-grained access tokens for "Get a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (read)
  * "Pull requests" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required
### [HTTP response status codes for "Get a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#get-a-label--code-samples)
#### Request example
get/repos/{owner}/{repo}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/labels/NAME`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 208045946,   "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",   "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",   "name": "bug",   "description": "Something isn't working",   "color": "f29513",   "default": true }`
## [Update a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label)
Updates a label using the given label name.
### [Fine-grained access tokens for "Update a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Update a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required
Body parameters Name, Type, Description
---
`new_name` string The new name of the label. Emoji can be added to label names, using either native emoji or colon-style markup. For example, typing `:strawberry:` will render the emoji ![:strawberry:](https://github.githubassets.com/images/icons/emoji/unicode/1f353.png). For a full list of available emoji and codes, see "[Emoji cheat sheet](https://github.com/ikatyang/emoji-cheat-sheet)."
`color` string The [hexadecimal color code](http://www.color-hex.com/) for the label, without the leading `#`.
`description` string A short description of the label. Must be 100 characters or fewer.
### [HTTP response status codes for "Update a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Update a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#update-a-label--code-samples)
#### Request example
patch/repos/{owner}/{repo}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/labels/NAME \   -d '{"new_name":"bug :bug:","description":"Small bug fix required","color":"b01f26"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 208045946,   "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",   "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug%20:bug:",   "name": "bug :bug:",   "description": "Small bug fix required",   "color": "b01f26",   "default": true }`
## [Delete a label](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label)
Deletes a label using the given label name.
### [Fine-grained access tokens for "Delete a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (write)
  * "Pull requests" repository permissions (write)


### [Parameters for "Delete a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`name` string Required
### [HTTP response status codes for "Delete a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Delete a label"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#delete-a-label--code-samples)
#### Request example
delete/repos/{owner}/{repo}/labels/{name}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/labels/NAME`
Response
`Status: 204`
## [List labels for issues in a milestone](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone)
Lists labels for issues in a milestone.
### [Fine-grained access tokens for "List labels for issues in a milestone"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have at least one of the following permission sets:
  * "Issues" repository permissions (read)
  * "Pull requests" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List labels for issues in a milestone"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`milestone_number` integer Required The number that identifies the milestone.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List labels for issues in a milestone"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List labels for issues in a milestone"](https://docs.github.com/en/rest/issues/labels?apiVersion=2022-11-28#list-labels-for-issues-in-a-milestone--code-samples)
#### Request example
get/repos/{owner}/{repo}/milestones/{milestone_number}/labels
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/milestones/MILESTONE_NUMBER/labels`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 208045946,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDY=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/bug",     "name": "bug",     "description": "Something isn't working",     "color": "f29513",     "default": true   },   {     "id": 208045947,     "node_id": "MDU6TGFiZWwyMDgwNDU5NDc=",     "url": "https://api.github.com/repos/octocat/Hello-World/labels/enhancement",     "name": "enhancement",     "description": "New feature or request",     "color": "a2eeef",     "default": false   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/issues/labels.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for labels - GitHub Docs
