[Skip to main content](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")/
  * [Rules](https://docs.github.com/en/rest/repos/rules "Rules")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
      * [Get rules for a branch](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch)
      * [Get all repository rulesets](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets)
      * [Create a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset)
      * [Get a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset)
      * [Update a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset)
      * [Delete a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset)
      * [Get repository ruleset history](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history)
      * [Get repository ruleset version](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version)
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")/
  * [Rules](https://docs.github.com/en/rest/repos/rules "Rules")


# REST API endpoints for rules
Use the REST API to manage rulesets for repositories. Rulesets control how people can interact with selected branches and tags in a repository.
## [Get rules for a branch](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch)
Returns all active rules that apply to the specified branch. The branch does not need to exist; rules that would apply to a branch with that name will be returned. All active rules that apply will be returned, regardless of the level at which they are configured (e.g. repository or organization). Rules in rulesets with "evaluate" or "disabled" enforcement statuses are not returned.
### [Fine-grained access tokens for "Get rules for a branch"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get rules for a branch"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`branch` string Required The name of the branch. Cannot contain wildcard characters. To use wildcard characters in branch names, use [the GraphQL API](https://docs.github.com/graphql).
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "Get rules for a branch"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get rules for a branch"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-rules-for-a-branch--code-samples)
#### Request example
get/repos/{owner}/{repo}/rules/branches/{branch}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rules/branches/BRANCH`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "type": "commit_message_pattern",     "ruleset_source_type": "Repository",     "ruleset_source": "monalisa/my-repo",     "ruleset_id": 42,     "parameters": {       "operator": "starts_with",       "pattern": "issue"     }   },   {     "type": "commit_author_email_pattern",     "ruleset_source_type": "Organization",     "ruleset_source": "my-org",     "ruleset_id": 73,     "parameters": {       "operator": "contains",       "pattern": "github"     }   } ]`
## [Get all repository rulesets](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets)
Get all the rulesets for a repository.
### [Fine-grained access tokens for "Get all repository rulesets"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get all repository rulesets"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`includes_parents` boolean Include rulesets configured at higher levels that apply to this repository Default: `true`
`targets` string A comma-separated list of rule targets to filter by. If provided, only rulesets that apply to the specified targets will be returned. For example, `branch,tag,push`.
### [HTTP response status codes for "Get all repository rulesets"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get all repository rulesets"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-all-repository-rulesets--code-samples)
#### Request example
get/repos/{owner}/{repo}/rulesets
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 42,     "name": "super cool ruleset",     "source_type": "Repository",     "source": "monalisa/my-repo",     "enforcement": "enabled",     "node_id": "RRS_lACkVXNlcgQB",     "_links": {       "self": {         "href": "https://api.github.com/repos/monalisa/my-repo/rulesets/42"       },       "html": {         "href": "https://github.com/monalisa/my-repo/rules/42"       }     },     "created_at": "2023-07-15T08:43:03Z",     "updated_at": "2023-08-23T16:29:47Z"   },   {     "id": 314,     "name": "Another ruleset",     "source_type": "Repository",     "source": "monalisa/my-repo",     "enforcement": "enabled",     "node_id": "RRS_lACkVXNlcgQQ",     "_links": {       "self": {         "href": "https://api.github.com/repos/monalisa/my-repo/rulesets/314"       },       "html": {         "href": "https://github.com/monalisa/my-repo/rules/314"       }     },     "created_at": "2023-08-15T08:43:03Z",     "updated_at": "2023-09-23T16:29:47Z"   } ]`
## [Create a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset)
Create a ruleset for a repository.
### [Fine-grained access tokens for "Create a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the ruleset.
`target` string The target of the ruleset Default: `branch` Can be one of: `branch`, `tag`, `push`
`enforcement` string Required The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). Can be one of: `disabled`, `active`, `evaluate`
`bypass_actors` array of objects The actors that can bypass the rules in this ruleset
Properties of `bypass_actors` | Name, Type, Description
---
`actor_id` integer or null The ID of the actor that can bypass a ruleset. Required for `Integration`, `RepositoryRole`, and `Team` actor types. If `actor_type` is `OrganizationAdmin`, `actor_id` is ignored. If `actor_type` is `DeployKey`, this should be null. `OrganizationAdmin` is not applicable for personal repositories.
`actor_type` string Required The type of actor that can bypass a ruleset. Can be one of: `Integration`, `OrganizationAdmin`, `RepositoryRole`, `Team`, `DeployKey`
`bypass_mode` string When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. Default: `always` Can be one of: `always`, `pull_request`, `exempt`
`conditions` object Parameters for a repository ruleset ref name condition
Properties of `conditions` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`rules` array of objects An array of rules within the ruleset.
Can be one of these objects: | Name, Type, Description
---
`creation` object Only allow users with bypass permission to create matching refs.
Properties of `creation` | Name, Type, Description
---
`type` string Required Value: `creation`
`update` object Only allow users with bypass permission to update matching refs.
Properties of `update` | Name, Type, Description
---
`type` string Required Value: `update`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`update_allows_fetch_and_merge` boolean Required Branch can pull changes from its upstream repository
`deletion` object Only allow users with bypass permissions to delete matching refs.
Properties of `deletion` | Name, Type, Description
---
`type` string Required Value: `deletion`
`required_linear_history` object Prevent merge commits from being pushed to matching refs.
Properties of `required_linear_history` | Name, Type, Description
---
`type` string Required Value: `required_linear_history`
`merge_queue` object Merges must be performed via a merge queue.
Properties of `merge_queue` | Name, Type, Description
---
`type` string Required Value: `merge_queue`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`check_response_timeout_minutes` integer Required Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed
`grouping_strategy` string Required When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. Can be one of: `ALLGREEN`, `HEADGREEN`
`max_entries_to_build` integer Required Limit the number of queued pull requests requesting checks and workflow runs at the same time.
`max_entries_to_merge` integer Required The maximum number of PRs that will be merged together in a group.
`merge_method` string Required Method to use when merging changes from queued pull requests. Can be one of: `MERGE`, `SQUASH`, `REBASE`
`min_entries_to_merge` integer Required The minimum number of PRs that will be merged together in a group.
`min_entries_to_merge_wait_minutes` integer Required The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged.
`required_deployments` object Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule.
Properties of `required_deployments` | Name, Type, Description
---
`type` string Required Value: `required_deployments`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`required_deployment_environments` array of strings Required The environments that must be successfully deployed to before branches can be merged.
`required_signatures` object Commits pushed to matching refs must have verified signatures.
Properties of `required_signatures` | Name, Type, Description
---
`type` string Required Value: `required_signatures`
`pull_request` object Require all commits be made to a non-target branch and submitted via a pull request before they can be merged.
Properties of `pull_request` | Name, Type, Description
---
`type` string Required Value: `pull_request`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`allowed_merge_methods` array of strings Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. Supported values are: `merge`, `squash`, `rebase`
`dismiss_stale_reviews_on_push` boolean Required New, reviewable commits pushed will dismiss previous pull request review approvals.
`require_code_owner_review` boolean Required Require an approving review in pull requests that modify files that have a designated code owner.
`require_last_push_approval` boolean Required Whether the most recent reviewable push must be approved by someone other than the person who pushed it.
`required_approving_review_count` integer Required The number of approving reviews that are required before a pull request can be merged.
`required_review_thread_resolution` boolean Required All conversations on code must be resolved before a pull request can be merged.
`required_reviewers` array of objects `required_reviewers` is in beta and subject to change. A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review.
Properties of `required_reviewers` | Name, Type, Description
---
`file_patterns` array of strings Required Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax.
`minimum_approvals` integer Required Minimum number of approvals required from the specified team. If set to zero, the team will be added to the pull request but approval is optional.
`reviewer` object Required A required reviewing team
Properties of `reviewer` | Name, Type, Description
---
`id` integer Required ID of the reviewer which must review changes to matching files.
`type` string Required The type of the reviewer Value: `Team`
`required_status_checks` object Choose which status checks must pass before the ref is updated. When enabled, commits must first be pushed to another ref where the checks pass.
Properties of `required_status_checks` | Name, Type, Description
---
`type` string Required Value: `required_status_checks`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`required_status_checks` array of objects Required Status checks that are required.
Properties of `required_status_checks` | Name, Type, Description
---
`context` string Required The status check context name that must be present on the commit.
`integration_id` integer The optional integration ID that this status check must originate from.
`strict_required_status_checks_policy` boolean Required Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled.
`non_fast_forward` object Prevent users with push access from force pushing to refs.
Properties of `non_fast_forward` | Name, Type, Description
---
`type` string Required Value: `non_fast_forward`
`commit_message_pattern` object Parameters to be used for the commit_message_pattern rule
Properties of `commit_message_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_message_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`commit_author_email_pattern` object Parameters to be used for the commit_author_email_pattern rule
Properties of `commit_author_email_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_author_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`committer_email_pattern` object Parameters to be used for the committer_email_pattern rule
Properties of `committer_email_pattern` | Name, Type, Description
---
`type` string Required Value: `committer_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`branch_name_pattern` object Parameters to be used for the branch_name_pattern rule
Properties of `branch_name_pattern` | Name, Type, Description
---
`type` string Required Value: `branch_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`tag_name_pattern` object Parameters to be used for the tag_name_pattern rule
Properties of `tag_name_pattern` | Name, Type, Description
---
`type` string Required Value: `tag_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`file_path_restriction` object Prevent commits that include changes in specified file and folder paths from being pushed to the commit graph. This includes absolute paths that contain file names.
Properties of `file_path_restriction` | Name, Type, Description
---
`type` string Required Value: `file_path_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_paths` array of strings Required The file paths that are restricted from being pushed to the commit graph.
`max_file_path_length` object Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph.
Properties of `max_file_path_length` | Name, Type, Description
---
`type` string Required Value: `max_file_path_length`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_path_length` integer Required The maximum amount of characters allowed in file paths.
`file_extension_restriction` object Prevent commits that include files with specified file extensions from being pushed to the commit graph.
Properties of `file_extension_restriction` | Name, Type, Description
---
`type` string Required Value: `file_extension_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_extensions` array of strings Required The file extensions that are restricted from being pushed to the commit graph.
`max_file_size` object Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph.
Properties of `max_file_size` | Name, Type, Description
---
`type` string Required Value: `max_file_size`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_size` integer Required The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS).
`workflows` object Require all changes made to a targeted branch to pass the specified workflows before they can be merged.
Properties of `workflows` | Name, Type, Description
---
`type` string Required Value: `workflows`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`workflows` array of objects Required Workflows that must pass for this rule to pass.
Properties of `workflows` | Name, Type, Description
---
`path` string Required The path to the workflow file
`ref` string The ref (branch or tag) of the workflow file to use
`repository_id` integer Required The ID of the repository where the workflow is defined
`sha` string The commit SHA of the workflow file to use
`code_scanning` object Choose which tools must provide code scanning results before the reference is updated. When configured, code scanning must be enabled and have results for both the commit and the reference being updated.
Properties of `code_scanning` | Name, Type, Description
---
`type` string Required Value: `code_scanning`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`code_scanning_tools` array of objects Required Tools that must provide code scanning results for this rule to pass.
Properties of `code_scanning_tools` | Name, Type, Description
---
`alerts_threshold` string Required The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `errors`, `errors_and_warnings`, `all`
`security_alerts_threshold` string Required The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `critical`, `high_or_higher`, `medium_or_higher`, `all`
`tool` string Required The name of a code scanning tool
`copilot_code_review` object Request Copilot code review for new pull requests automatically if the author has access to Copilot code review and their premium requests quota has not reached the limit.
Properties of `copilot_code_review` | Name, Type, Description
---
`type` string Required Value: `copilot_code_review`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`review_draft_pull_requests` boolean Copilot automatically reviews draft pull requests before they are marked as ready for review.
`review_on_push` boolean Copilot automatically reviews each new push to the pull request.
### [HTTP response status codes for "Create a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset--status-codes)
Status code | Description
---|---
`201` | Created
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Create a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#create-a-repository-ruleset--code-samples)
#### Request example
post/repos/{owner}/{repo}/rulesets
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets \   -d '{"name":"super cool ruleset","target":"branch","enforcement":"active","bypass_actors":[{"actor_id":234,"actor_type":"Team","bypass_mode":"always"}],"conditions":{"ref_name":{"include":["refs/heads/main","refs/heads/master"],"exclude":["refs/heads/dev*"]}},"rules":[{"type":"commit_author_email_pattern","parameters":{"operator":"contains","pattern":"github"}}]}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 42,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Repository",   "source": "monalisa/my-repo",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/repos/monalisa/my-repo/rulesets/42"     },     "html": {       "href": "https://github.com/monalisa/my-repo/rules/42"     }   },   "created_at": "2023-07-15T08:43:03Z",   "updated_at": "2023-08-23T16:29:47Z" }`
## [Get a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset)
Get a ruleset for a repository.
**Note:** To prevent leaking sensitive information, the `bypass_actors` property is only returned if the user making the API request has write access to the ruleset.
### [Fine-grained access tokens for "Get a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
Query parameters Name, Type, Description
---
`includes_parents` boolean Include rulesets configured at higher levels that apply to this repository Default: `true`
### [HTTP response status codes for "Get a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-a-repository-ruleset--code-samples)
#### Request example
get/repos/{owner}/{repo}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets/RULESET_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 42,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Repository",   "source": "monalisa/my-repo",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/repos/monalisa/my-repo/rulesets/42"     },     "html": {       "href": "https://github.com/monalisa/my-repo/rules/42"     }   },   "created_at": "2023-07-15T08:43:03Z",   "updated_at": "2023-08-23T16:29:47Z" }`
## [Update a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset)
Update a ruleset for a repository.
### [Fine-grained access tokens for "Update a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
Body parameters Name, Type, Description
---
`name` string The name of the ruleset.
`target` string The target of the ruleset Can be one of: `branch`, `tag`, `push`
`enforcement` string The enforcement level of the ruleset. `evaluate` allows admins to test rules before enforcing them. Admins can view insights on the Rule Insights page (`evaluate` is only available with GitHub Enterprise). Can be one of: `disabled`, `active`, `evaluate`
`bypass_actors` array of objects The actors that can bypass the rules in this ruleset
Properties of `bypass_actors` | Name, Type, Description
---
`actor_id` integer or null The ID of the actor that can bypass a ruleset. Required for `Integration`, `RepositoryRole`, and `Team` actor types. If `actor_type` is `OrganizationAdmin`, `actor_id` is ignored. If `actor_type` is `DeployKey`, this should be null. `OrganizationAdmin` is not applicable for personal repositories.
`actor_type` string Required The type of actor that can bypass a ruleset. Can be one of: `Integration`, `OrganizationAdmin`, `RepositoryRole`, `Team`, `DeployKey`
`bypass_mode` string When the specified actor can bypass the ruleset. `pull_request` means that an actor can only bypass rules on pull requests. `pull_request` is not applicable for the `DeployKey` actor type. Also, `pull_request` is only applicable to branch rulesets. When `bypass_mode` is `exempt`, rules will not be run for that actor and a bypass audit entry will not be created. Default: `always` Can be one of: `always`, `pull_request`, `exempt`
`conditions` object Parameters for a repository ruleset ref name condition
Properties of `conditions` | Name, Type, Description
---
`ref_name` object
Properties of `ref_name` | Name, Type, Description
---
`include` array of strings Array of ref names or patterns to include. One of these patterns must match for the condition to pass. Also accepts `~DEFAULT_BRANCH` to include the default branch or `~ALL` to include all branches.
`exclude` array of strings Array of ref names or patterns to exclude. The condition will not pass if any of these patterns match.
`rules` array of objects An array of rules within the ruleset.
Can be one of these objects: | Name, Type, Description
---
`creation` object Only allow users with bypass permission to create matching refs.
Properties of `creation` | Name, Type, Description
---
`type` string Required Value: `creation`
`update` object Only allow users with bypass permission to update matching refs.
Properties of `update` | Name, Type, Description
---
`type` string Required Value: `update`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`update_allows_fetch_and_merge` boolean Required Branch can pull changes from its upstream repository
`deletion` object Only allow users with bypass permissions to delete matching refs.
Properties of `deletion` | Name, Type, Description
---
`type` string Required Value: `deletion`
`required_linear_history` object Prevent merge commits from being pushed to matching refs.
Properties of `required_linear_history` | Name, Type, Description
---
`type` string Required Value: `required_linear_history`
`merge_queue` object Merges must be performed via a merge queue.
Properties of `merge_queue` | Name, Type, Description
---
`type` string Required Value: `merge_queue`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`check_response_timeout_minutes` integer Required Maximum time for a required status check to report a conclusion. After this much time has elapsed, checks that have not reported a conclusion will be assumed to have failed
`grouping_strategy` string Required When set to ALLGREEN, the merge commit created by merge queue for each PR in the group must pass all required checks to merge. When set to HEADGREEN, only the commit at the head of the merge group, i.e. the commit containing changes from all of the PRs in the group, must pass its required checks to merge. Can be one of: `ALLGREEN`, `HEADGREEN`
`max_entries_to_build` integer Required Limit the number of queued pull requests requesting checks and workflow runs at the same time.
`max_entries_to_merge` integer Required The maximum number of PRs that will be merged together in a group.
`merge_method` string Required Method to use when merging changes from queued pull requests. Can be one of: `MERGE`, `SQUASH`, `REBASE`
`min_entries_to_merge` integer Required The minimum number of PRs that will be merged together in a group.
`min_entries_to_merge_wait_minutes` integer Required The time merge queue should wait after the first PR is added to the queue for the minimum group size to be met. After this time has elapsed, the minimum group size will be ignored and a smaller group will be merged.
`required_deployments` object Choose which environments must be successfully deployed to before refs can be pushed into a ref that matches this rule.
Properties of `required_deployments` | Name, Type, Description
---
`type` string Required Value: `required_deployments`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`required_deployment_environments` array of strings Required The environments that must be successfully deployed to before branches can be merged.
`required_signatures` object Commits pushed to matching refs must have verified signatures.
Properties of `required_signatures` | Name, Type, Description
---
`type` string Required Value: `required_signatures`
`pull_request` object Require all commits be made to a non-target branch and submitted via a pull request before they can be merged.
Properties of `pull_request` | Name, Type, Description
---
`type` string Required Value: `pull_request`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`allowed_merge_methods` array of strings Array of allowed merge methods. Allowed values include `merge`, `squash`, and `rebase`. At least one option must be enabled. Supported values are: `merge`, `squash`, `rebase`
`dismiss_stale_reviews_on_push` boolean Required New, reviewable commits pushed will dismiss previous pull request review approvals.
`require_code_owner_review` boolean Required Require an approving review in pull requests that modify files that have a designated code owner.
`require_last_push_approval` boolean Required Whether the most recent reviewable push must be approved by someone other than the person who pushed it.
`required_approving_review_count` integer Required The number of approving reviews that are required before a pull request can be merged.
`required_review_thread_resolution` boolean Required All conversations on code must be resolved before a pull request can be merged.
`required_reviewers` array of objects `required_reviewers` is in beta and subject to change. A collection of reviewers and associated file patterns. Each reviewer has a list of file patterns which determine the files that reviewer is required to review.
Properties of `required_reviewers` | Name, Type, Description
---
`file_patterns` array of strings Required Array of file patterns. Pull requests which change matching files must be approved by the specified team. File patterns use fnmatch syntax.
`minimum_approvals` integer Required Minimum number of approvals required from the specified team. If set to zero, the team will be added to the pull request but approval is optional.
`reviewer` object Required A required reviewing team
Properties of `reviewer` | Name, Type, Description
---
`id` integer Required ID of the reviewer which must review changes to matching files.
`type` string Required The type of the reviewer Value: `Team`
`required_status_checks` object Choose which status checks must pass before the ref is updated. When enabled, commits must first be pushed to another ref where the checks pass.
Properties of `required_status_checks` | Name, Type, Description
---
`type` string Required Value: `required_status_checks`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`required_status_checks` array of objects Required Status checks that are required.
Properties of `required_status_checks` | Name, Type, Description
---
`context` string Required The status check context name that must be present on the commit.
`integration_id` integer The optional integration ID that this status check must originate from.
`strict_required_status_checks_policy` boolean Required Whether pull requests targeting a matching branch must be tested with the latest code. This setting will not take effect unless at least one status check is enabled.
`non_fast_forward` object Prevent users with push access from force pushing to refs.
Properties of `non_fast_forward` | Name, Type, Description
---
`type` string Required Value: `non_fast_forward`
`commit_message_pattern` object Parameters to be used for the commit_message_pattern rule
Properties of `commit_message_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_message_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`commit_author_email_pattern` object Parameters to be used for the commit_author_email_pattern rule
Properties of `commit_author_email_pattern` | Name, Type, Description
---
`type` string Required Value: `commit_author_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`committer_email_pattern` object Parameters to be used for the committer_email_pattern rule
Properties of `committer_email_pattern` | Name, Type, Description
---
`type` string Required Value: `committer_email_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`branch_name_pattern` object Parameters to be used for the branch_name_pattern rule
Properties of `branch_name_pattern` | Name, Type, Description
---
`type` string Required Value: `branch_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`tag_name_pattern` object Parameters to be used for the tag_name_pattern rule
Properties of `tag_name_pattern` | Name, Type, Description
---
`type` string Required Value: `tag_name_pattern`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`name` string How this rule appears when configuring it.
`negate` boolean If true, the rule will fail if the pattern matches.
`operator` string Required The operator to use for matching. Can be one of: `starts_with`, `ends_with`, `contains`, `regex`
`pattern` string Required The pattern to match with.
`file_path_restriction` object Prevent commits that include changes in specified file and folder paths from being pushed to the commit graph. This includes absolute paths that contain file names.
Properties of `file_path_restriction` | Name, Type, Description
---
`type` string Required Value: `file_path_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_paths` array of strings Required The file paths that are restricted from being pushed to the commit graph.
`max_file_path_length` object Prevent commits that include file paths that exceed the specified character limit from being pushed to the commit graph.
Properties of `max_file_path_length` | Name, Type, Description
---
`type` string Required Value: `max_file_path_length`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_path_length` integer Required The maximum amount of characters allowed in file paths.
`file_extension_restriction` object Prevent commits that include files with specified file extensions from being pushed to the commit graph.
Properties of `file_extension_restriction` | Name, Type, Description
---
`type` string Required Value: `file_extension_restriction`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`restricted_file_extensions` array of strings Required The file extensions that are restricted from being pushed to the commit graph.
`max_file_size` object Prevent commits with individual files that exceed the specified limit from being pushed to the commit graph.
Properties of `max_file_size` | Name, Type, Description
---
`type` string Required Value: `max_file_size`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`max_file_size` integer Required The maximum file size allowed in megabytes. This limit does not apply to Git Large File Storage (Git LFS).
`workflows` object Require all changes made to a targeted branch to pass the specified workflows before they can be merged.
Properties of `workflows` | Name, Type, Description
---
`type` string Required Value: `workflows`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`do_not_enforce_on_create` boolean Allow repositories and branches to be created if a check would otherwise prohibit it.
`workflows` array of objects Required Workflows that must pass for this rule to pass.
Properties of `workflows` | Name, Type, Description
---
`path` string Required The path to the workflow file
`ref` string The ref (branch or tag) of the workflow file to use
`repository_id` integer Required The ID of the repository where the workflow is defined
`sha` string The commit SHA of the workflow file to use
`code_scanning` object Choose which tools must provide code scanning results before the reference is updated. When configured, code scanning must be enabled and have results for both the commit and the reference being updated.
Properties of `code_scanning` | Name, Type, Description
---
`type` string Required Value: `code_scanning`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`code_scanning_tools` array of objects Required Tools that must provide code scanning results for this rule to pass.
Properties of `code_scanning_tools` | Name, Type, Description
---
`alerts_threshold` string Required The severity level at which code scanning results that raise alerts block a reference update. For more information on alert severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `errors`, `errors_and_warnings`, `all`
`security_alerts_threshold` string Required The severity level at which code scanning results that raise security alerts block a reference update. For more information on security severity levels, see "[About code scanning alerts](https://docs.github.com/code-security/code-scanning/managing-code-scanning-alerts/about-code-scanning-alerts#about-alert-severity-and-security-severity-levels)." Can be one of: `none`, `critical`, `high_or_higher`, `medium_or_higher`, `all`
`tool` string Required The name of a code scanning tool
`copilot_code_review` object Request Copilot code review for new pull requests automatically if the author has access to Copilot code review and their premium requests quota has not reached the limit.
Properties of `copilot_code_review` | Name, Type, Description
---
`type` string Required Value: `copilot_code_review`
`parameters` object
Properties of `parameters` | Name, Type, Description
---
`review_draft_pull_requests` boolean Copilot automatically reviews draft pull requests before they are marked as ready for review.
`review_on_push` boolean Copilot automatically reviews each new push to the pull request.
### [HTTP response status codes for "Update a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Update a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#update-a-repository-ruleset--code-samples)
#### Request example
put/repos/{owner}/{repo}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets/RULESET_ID \   -d '{"name":"super cool ruleset","target":"branch","enforcement":"active","bypass_actors":[{"actor_id":234,"actor_type":"Team","bypass_mode":"always"}],"conditions":{"ref_name":{"include":["refs/heads/main","refs/heads/master"],"exclude":["refs/heads/dev*"]}},"rules":[{"type":"commit_author_email_pattern","parameters":{"operator":"contains","pattern":"github"}}]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 42,   "name": "super cool ruleset",   "target": "branch",   "source_type": "Repository",   "source": "monalisa/my-repo",   "enforcement": "active",   "bypass_actors": [     {       "actor_id": 234,       "actor_type": "Team",       "bypass_mode": "always"     }   ],   "conditions": {     "ref_name": {       "include": [         "refs/heads/main",         "refs/heads/master"       ],       "exclude": [         "refs/heads/dev*"       ]     }   },   "rules": [     {       "type": "commit_author_email_pattern",       "parameters": {         "operator": "contains",         "pattern": "github"       }     }   ],   "node_id": "RRS_lACkVXNlcgQB",   "_links": {     "self": {       "href": "https://api.github.com/repos/monalisa/my-repo/rulesets/42"     },     "html": {       "href": "https://github.com/monalisa/my-repo/rules/42"     }   },   "created_at": "2023-07-15T08:43:03Z",   "updated_at": "2023-08-23T16:29:47Z" }`
## [Delete a repository ruleset](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset)
Delete a ruleset for a repository.
### [Fine-grained access tokens for "Delete a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
### [HTTP response status codes for "Delete a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Delete a repository ruleset"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#delete-a-repository-ruleset--code-samples)
#### Request example
delete/repos/{owner}/{repo}/rulesets/{ruleset_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets/RULESET_ID`
Response
`Status: 204`
## [Get repository ruleset history](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history)
Get the history of a repository ruleset.
### [Fine-grained access tokens for "Get repository ruleset history"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Get repository ruleset history"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "Get repository ruleset history"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get repository ruleset history"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-history--code-samples)
#### Request example
get/repos/{owner}/{repo}/rulesets/{ruleset_id}/history
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets/RULESET_ID/history`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "version_id": 3,     "actor": {       "id": 1,       "type": "User"     },     "updated_at": "2024-10-23T16:29:47Z"   },   {     "version_id": 2,     "actor": {       "id": 2,       "type": "User"     },     "updated_at": "2024-09-23T16:29:47Z"   },   {     "version_id": 1,     "actor": {       "id": 1,       "type": "User"     },     "updated_at": "2024-08-23T16:29:47Z"   } ]`
## [Get repository ruleset version](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version)
Get a version of a repository ruleset.
### [Fine-grained access tokens for "Get repository ruleset version"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Get repository ruleset version"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`ruleset_id` integer Required The ID of the ruleset.
`version_id` integer Required The ID of the version
### [HTTP response status codes for "Get repository ruleset version"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`500` | Internal Error
### [Code samples for "Get repository ruleset version"](https://docs.github.com/en/rest/repos/rules?apiVersion=2022-11-28#get-repository-ruleset-version--code-samples)
#### Request example
get/repos/{owner}/{repo}/rulesets/{ruleset_id}/history/{version_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/rulesets/RULESET_ID/history/VERSION_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "version_id": 3,   "actor": {     "id": 1,     "type": "User"   },   "updated_at": "2024-10-23T16:29:47Z",   "state": {     "id": 42,     "name": "super cool ruleset",     "target": "branch",     "source_type": "Repository",     "source": "monalisa/my-repo",     "enforcement": "active",     "bypass_actors": [       {         "actor_id": 234,         "actor_type": "Team",         "bypass_mode": "always"       }     ],     "conditions": {       "ref_name": {         "include": [           "refs/heads/main",           "refs/heads/master"         ],         "exclude": [           "refs/heads/dev*"         ]       }     },     "rules": [       {         "type": "commit_author_email_pattern",         "parameters": {           "operator": "contains",           "pattern": "github"         }       }     ]   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/repos/rules.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for rules - GitHub Docs
