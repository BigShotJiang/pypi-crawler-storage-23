[Skip to main content](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")/
  * [Repositories](https://docs.github.com/en/rest/repos/repos "Repositories")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
      * [List organization repositories](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories)
      * [Create an organization repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository)
      * [Get a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository)
      * [Update a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository)
      * [Delete a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository)
      * [List repository activities](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities)
      * [Check if Dependabot security updates are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository)
      * [Enable Dependabot security updates](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates)
      * [Disable Dependabot security updates](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates)
      * [List CODEOWNERS errors](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors)
      * [List repository contributors](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors)
      * [Create a repository dispatch event](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event)
      * [Check if immutable releases are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository)
      * [Enable immutable releases](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases)
      * [Disable immutable releases](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases)
      * [List repository languages](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages)
      * [Check if private vulnerability reporting is enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository)
      * [Enable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository)
      * [Disable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository)
      * [List repository tags](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags)
      * [List repository teams](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams)
      * [Get all repository topics](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics)
      * [Replace all repository topics](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics)
      * [Transfer a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository)
      * [Check if vulnerability alerts are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository)
      * [Enable vulnerability alerts](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts)
      * [Disable vulnerability alerts](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts)
      * [Create a repository using a template](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template)
      * [List public repositories](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories)
      * [List repositories for the authenticated user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user)
      * [Create a repository for the authenticated user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user)
      * [List repositories for a user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user)
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Repositories](https://docs.github.com/en/rest/repos "Repositories")/
  * [Repositories](https://docs.github.com/en/rest/repos/repos "Repositories")


# REST API endpoints for repositories
Use the REST API to manage repositories on GitHub.
## [List organization repositories](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories)
Lists repositories for the specified organization.
In order to see the `security_and_analysis` block for a repository you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."
### [Fine-grained access tokens for "List organization repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List organization repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Query parameters Name, Type, Description
---
`type` string Specifies the types of repositories you want returned. Default: `all` Can be one of: `all`, `public`, `private`, `forks`, `sources`, `member`
`sort` string The property to sort the results by. Default: `created` Can be one of: `created`, `updated`, `pushed`, `full_name`
`direction` string The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List organization repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List organization repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-organization-repositories--code-samples)
#### Request example
get/orgs/{org}/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/repos`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "has_discussions": false,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } ]`
## [Create an organization repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository)
Creates a new repository in the specified organization. The authenticated user must be a member of the organization.
OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository.
### [Fine-grained access tokens for "Create an organization repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create an organization repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string Required The name of the repository.
`description` string A short description of the repository.
`homepage` string A URL with more information about the repository.
`private` boolean Whether the repository is private. Default: `false`
`visibility` string The visibility of the repository. Can be one of: `public`, `private`
`has_issues` boolean Either `true` to enable issues for this repository or `false` to disable them. Default: `true`
`has_projects` boolean Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. Default: `true`
`has_wiki` boolean Either `true` to enable the wiki for this repository or `false` to disable it. Default: `true`
`has_downloads` boolean Whether downloads are enabled. Default: `true`
`is_template` boolean Either `true` to make this repo available as a template repository or `false` to prevent it. Default: `false`
`team_id` integer The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization.
`auto_init` boolean Pass `true` to create an initial commit with empty README. Default: `false`
`gitignore_template` string Desired language or platform [.gitignore template](https://github.com/github/gitignore) to apply. Use the name of the template without the extension. For example, "Haskell".
`license_template` string Choose an [open source license template](https://choosealicense.com/) that best suits your needs, and then use the [license keyword](https://docs.github.com/articles/licensing-a-repository/#searching-github-by-license-type) as the `license_template` string. For example, "mit" or "mpl-2.0".
`allow_squash_merge` boolean Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. Default: `true`
`allow_merge_commit` boolean Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. Default: `true`
`allow_rebase_merge` boolean Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. Default: `true`
`allow_auto_merge` boolean Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. Default: `false`
`delete_branch_on_merge` boolean Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. **The authenticated user must be an organization owner to set this property to`true`.** Default: `false`
`use_squash_pr_title_as_default` boolean Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. Default: `false`
`squash_merge_commit_title` string Required when using `squash_merge_commit_message`. The default value for a squash merge commit title:
  * `PR_TITLE` - default to the pull request's title.
  * `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).

Can be one of: `PR_TITLE`, `COMMIT_OR_PR_TITLE`
`squash_merge_commit_message` string The default value for a squash merge commit message:
  * `PR_BODY` - default to the pull request's body.
  * `COMMIT_MESSAGES` - default to the branch's commit messages.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `COMMIT_MESSAGES`, `BLANK`
`merge_commit_title` string Required when using `merge_commit_message`. The default value for a merge commit title.
  * `PR_TITLE` - default to the pull request's title.
  * `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).

Can be one of: `PR_TITLE`, `MERGE_MESSAGE`
`merge_commit_message` string The default value for a merge commit message.
  * `PR_TITLE` - default to the pull request's title.
  * `PR_BODY` - default to the pull request's body.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `PR_TITLE`, `BLANK`
`custom_properties` object The custom properties for the new repository. The keys are the custom property names, and the values are the corresponding custom property values.
### [HTTP response status codes for "Create an organization repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository--status-codes)
Status code | Description
---|---
`201` | Created
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create an organization repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-an-organization-repository--code-samples)
#### Request example
post/orgs/{org}/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/repos \   -d '{"name":"Hello-World","description":"This is your first repository","homepage":"https://github.com","private":false,"has_issues":true,"has_projects":true,"has_wiki":true}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://github.com/licenses/mit"   },   "language": null,   "forks_count": 9,   "forks": 9,   "stargazers_count": 80,   "watchers_count": 80,   "watchers": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "open_issues": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "pull": true,     "push": false,     "admin": false   },   "allow_rebase_merge": true,   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0   },   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "allow_forking": true,   "web_commit_signoff_required": false,   "subscribers_count": 42,   "network_count": 0,   "organization": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "Organization",     "site_admin": false   },   "parent": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   },   "source": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   } }`
## [Get a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository)
The `parent` and `source` objects are present when the repository is a fork. `parent` is the repository this repository was forked from, `source` is the ultimate source for the network.
  * In order to see the `security_and_analysis` block for a repository you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)."
  * To view merge-related settings, you must have the `contents:read` and `contents:write` permissions.


### [Fine-grained access tokens for "Get a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`301` | Moved permanently
`403` | Forbidden
`404` | Resource not found
### [Code samples for "Get a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO`
Default response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "forks_count": 9,   "forks": 9,   "stargazers_count": 80,   "watchers_count": 80,   "watchers": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "open_issues": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "has_discussions": false,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "pull": true,     "push": false,     "admin": false   },   "allow_rebase_merge": true,   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0   },   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "allow_forking": true,   "subscribers_count": 42,   "network_count": 0,   "license": {     "key": "mit",     "name": "MIT License",     "spdx_id": "MIT",     "url": "https://api.github.com/licenses/mit",     "node_id": "MDc6TGljZW5zZW1pdA=="   },   "organization": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "Organization",     "site_admin": false   },   "parent": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   },   "source": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1,     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_bypass": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } }`
## [Update a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository)
**Note** : To edit a repository's topics, use the [Replace all repository topics](https://docs.github.com/rest/repos/repos#replace-all-repository-topics) endpoint.
### [Fine-grained access tokens for "Update a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Update a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`name` string The name of the repository.
`description` string A short description of the repository.
`homepage` string A URL with more information about the repository.
`private` boolean Either `true` to make the repository private or `false` to make it public. Default: `false`.
**Note** : You will get a `422` error if the organization restricts [changing repository visibility](https://docs.github.com/articles/repository-permission-levels-for-an-organization#changing-the-visibility-of-repositories) to organization owners and a non-owner tries to change the value of private. Default: `false`
`visibility` string The visibility of the repository. Can be one of: `public`, `private`
`security_and_analysis` object or null Specify which security and analysis features to enable or disable for the repository. To use this parameter, you must have admin permissions for the repository or be an owner or security manager for the organization that owns the repository. For more information, see "[Managing security managers in your organization](https://docs.github.com/organizations/managing-peoples-access-to-your-organization-with-roles/managing-security-managers-in-your-organization)." For example, to enable GitHub Advanced Security, use this data in the body of the `PATCH` request: `{ "security_and_analysis": {"advanced_security": { "status": "enabled" } } }`. You can check which security and analysis features are currently enabled by using a `GET /repos/{owner}/{repo}` request.
Properties of `security_and_analysis` | Name, Type, Description
---
`advanced_security` object Use the `status` property to enable or disable GitHub Advanced Security for this repository. For more information, see "[About GitHub Advanced Security](https://docs.github.com/github/getting-started-with-github/learning-about-github/about-github-advanced-security)." For standalone Code Scanning or Secret Protection products, this parameter cannot be used.
Properties of `advanced_security` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`code_security` object Use the `status` property to enable or disable GitHub Code Security for this repository.
Properties of `code_security` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning` object Use the `status` property to enable or disable secret scanning for this repository. For more information, see "[About secret scanning](https://docs.github.com/code-security/secret-security/about-secret-scanning)."
Properties of `secret_scanning` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_push_protection` object Use the `status` property to enable or disable secret scanning push protection for this repository. For more information, see "[Protecting pushes with secret scanning](https://docs.github.com/code-security/secret-scanning/protecting-pushes-with-secret-scanning)."
Properties of `secret_scanning_push_protection` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_ai_detection` object Use the `status` property to enable or disable secret scanning AI detection for this repository. For more information, see "[Responsible detection of generic secrets with AI](https://docs.github.com/code-security/secret-scanning/using-advanced-secret-scanning-and-push-protection-features/generic-secret-detection/responsible-ai-generic-secrets)."
Properties of `secret_scanning_ai_detection` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_non_provider_patterns` object Use the `status` property to enable or disable secret scanning non-provider patterns for this repository. For more information, see "[Supported secret scanning patterns](https://docs.github.com/code-security/secret-scanning/introduction/supported-secret-scanning-patterns#supported-secrets)."
Properties of `secret_scanning_non_provider_patterns` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_delegated_alert_dismissal` object Use the `status` property to enable or disable secret scanning delegated alert dismissal for this repository.
Properties of `secret_scanning_delegated_alert_dismissal` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_delegated_bypass` object Use the `status` property to enable or disable secret scanning delegated bypass for this repository.
Properties of `secret_scanning_delegated_bypass` | Name, Type, Description
---
`status` string Can be `enabled` or `disabled`.
`secret_scanning_delegated_bypass_options` object Feature options for secret scanning delegated bypass. This object is only honored when `security_and_analysis.secret_scanning_delegated_bypass.status` is set to `enabled`. You can send this object in the same request as `secret_scanning_delegated_bypass`, or update just the options in a separate request.
Properties of `secret_scanning_delegated_bypass_options` | Name, Type, Description
---
`reviewers` array of objects The bypass reviewers for secret scanning delegated bypass. If you omit this field, the existing set of reviewers is unchanged.
Properties of `reviewers` | Name, Type, Description
---
`reviewer_id` integer Required The ID of the team or role selected as a bypass reviewer
`reviewer_type` string Required The type of the bypass reviewer Can be one of: `TEAM`, `ROLE`
`has_issues` boolean Either `true` to enable issues for this repository or `false` to disable them. Default: `true`
`has_projects` boolean Either `true` to enable projects for this repository or `false` to disable them. **Note:** If you're creating a repository in an organization that has disabled repository projects, the default is `false`, and if you pass `true`, the API returns an error. Default: `true`
`has_wiki` boolean Either `true` to enable the wiki for this repository or `false` to disable it. Default: `true`
`is_template` boolean Either `true` to make this repo available as a template repository or `false` to prevent it. Default: `false`
`default_branch` string Updates the default branch for this repository.
`allow_squash_merge` boolean Either `true` to allow squash-merging pull requests, or `false` to prevent squash-merging. Default: `true`
`allow_merge_commit` boolean Either `true` to allow merging pull requests with a merge commit, or `false` to prevent merging pull requests with merge commits. Default: `true`
`allow_rebase_merge` boolean Either `true` to allow rebase-merging pull requests, or `false` to prevent rebase-merging. Default: `true`
`allow_auto_merge` boolean Either `true` to allow auto-merge on pull requests, or `false` to disallow auto-merge. Default: `false`
`delete_branch_on_merge` boolean Either `true` to allow automatically deleting head branches when pull requests are merged, or `false` to prevent automatic deletion. Default: `false`
`allow_update_branch` boolean Either `true` to always allow a pull request head branch that is behind its base branch to be updated even if it is not required to be up to date before merging, or false otherwise. Default: `false`
`use_squash_pr_title_as_default` boolean Either `true` to allow squash-merge commits to use pull request title, or `false` to use commit message. **This property is closing down. Please use `squash_merge_commit_title` instead. Default: `false`
`squash_merge_commit_title` string Required when using `squash_merge_commit_message`. The default value for a squash merge commit title:
  * `PR_TITLE` - default to the pull request's title.
  * `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).

Can be one of: `PR_TITLE`, `COMMIT_OR_PR_TITLE`
`squash_merge_commit_message` string The default value for a squash merge commit message:
  * `PR_BODY` - default to the pull request's body.
  * `COMMIT_MESSAGES` - default to the branch's commit messages.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `COMMIT_MESSAGES`, `BLANK`
`merge_commit_title` string Required when using `merge_commit_message`. The default value for a merge commit title.
  * `PR_TITLE` - default to the pull request's title.
  * `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).

Can be one of: `PR_TITLE`, `MERGE_MESSAGE`
`merge_commit_message` string The default value for a merge commit message.
  * `PR_TITLE` - default to the pull request's title.
  * `PR_BODY` - default to the pull request's body.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `PR_TITLE`, `BLANK`
`archived` boolean Whether to archive this repository. `false` will unarchive a previously archived repository. Default: `false`
`allow_forking` boolean Either `true` to allow private forks, or `false` to prevent private forks. Default: `false`
`web_commit_signoff_required` boolean Either `true` to require contributors to sign off on web-based commits, or `false` to not require contributors to sign off on web-based commits. Default: `false`
### [HTTP response status codes for "Update a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository--status-codes)
Status code | Description
---|---
`200` | OK
`307` | Temporary Redirect
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#update-a-repository--code-samples)
#### Request example
patch/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO \   -d '{"name":"Hello-World","description":"This is your first repository","homepage":"https://github.com","private":true,"has_issues":true,"has_projects":true,"has_wiki":true}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://github.com/licenses/mit"   },   "language": null,   "forks_count": 9,   "forks": 9,   "stargazers_count": 80,   "watchers_count": 80,   "watchers": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "open_issues": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "pull": true,     "push": false,     "admin": false   },   "allow_rebase_merge": true,   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0   },   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "allow_forking": true,   "web_commit_signoff_required": false,   "subscribers_count": 42,   "network_count": 0,   "organization": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "Organization",     "site_admin": false   },   "parent": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   },   "source": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   } }`
## [Delete a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository)
Deleting a repository requires admin access.
If an organization owner has configured the organization to prevent members from deleting organization-owned repositories, you will get a `403 Forbidden` response.
OAuth app tokens and personal access tokens (classic) need the `delete_repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Delete a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Delete a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository--status-codes)
Status code | Description
---|---
`204` | No Content
`307` | Temporary Redirect
`403` | If an organization owner has configured the organization to prevent members from deleting organization-owned repositories, a member will get this response:
`404` | Resource not found
`409` | Conflict
### [Code samples for "Delete a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#delete-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO`
Response
`Status: 204`
## [List repository activities](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities)
Lists a detailed history of changes to a repository, such as pushes, merges, force pushes, and branch changes, and associates these changes with commits and users.
For more information about viewing repository activity, see "[Viewing activity and data for your repository](https://docs.github.com/repositories/viewing-activity-and-data-for-your-repository)."
### [Fine-grained access tokens for "List repository activities"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository activities"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`direction` string The direction to sort the results by. Default: `desc` Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`before` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results before this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`after` string A cursor, as given in the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers). If specified, the query only searches for results after this cursor. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)."
`ref` string The Git reference for the activities you want to list. The `ref` for a branch can be formatted either as `refs/heads/BRANCH_NAME` or `BRANCH_NAME`, where `BRANCH_NAME` is the name of your branch.
`actor` string The GitHub username to use to filter by the actor who performed the activity.
`time_period` string The time period to filter by. For example, `day` will filter for activity that occurred in the past 24 hours, and `week` will filter for activity that occurred in the past 7 days (168 hours). Can be one of: `day`, `week`, `month`, `quarter`, `year`
`activity_type` string The activity type to filter by. For example, you can choose to filter by "force_push", to see all force pushes to the repository. Can be one of: `push`, `force_push`, `branch_creation`, `branch_deletion`, `pr_merge`, `merge_queue_merge`
### [HTTP response status codes for "List repository activities"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities--status-codes)
Status code | Description
---|---
`200` | OK
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List repository activities"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-activities--code-samples)
#### Request example
get/repos/{owner}/{repo}/activity
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/activity`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "before": "6dcb09b5b57875f334f61aebed695e2e4193db5e",     "after": "827efc6d56897b048c772eb4087f854f46256132",     "ref": "refs/heads/main",     "pushed_at": "2011-01-26T19:06:43Z",     "push_type": "normal",     "pusher": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     }   } ]`
## [Check if Dependabot security updates are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository)
Shows whether Dependabot security updates are enabled, disabled or paused for a repository. The authenticated user must have admin read access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)".
### [Fine-grained access tokens for "Check if Dependabot security updates are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Check if Dependabot security updates are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check if Dependabot security updates are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository--status-codes)
Status code | Description
---|---
`200` | Response if Dependabot is enabled
`404` | Not Found if Dependabot is not enabled for the repository
### [Code samples for "Check if Dependabot security updates are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-dependabot-security-updates-are-enabled-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/automated-security-fixes
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/automated-security-fixes`
Response if Dependabot is enabled
  * Example response
  * Response schema


`Status: 200`
`{   "enabled": true,   "paused": false }`
## [Enable Dependabot security updates](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates)
Enables Dependabot security updates for a repository. The authenticated user must have admin access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)".
### [Fine-grained access tokens for "Enable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Enable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Enable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Enable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-dependabot-security-updates--code-samples)
#### Request example
put/repos/{owner}/{repo}/automated-security-fixes
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/automated-security-fixes`
Response
`Status: 204`
## [Disable Dependabot security updates](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates)
Disables Dependabot security updates for a repository. The authenticated user must have admin access to the repository. For more information, see "[Configuring Dependabot security updates](https://docs.github.com/articles/configuring-automated-security-fixes)".
### [Fine-grained access tokens for "Disable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Disable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Disable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Disable Dependabot security updates"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-dependabot-security-updates--code-samples)
#### Request example
delete/repos/{owner}/{repo}/automated-security-fixes
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/automated-security-fixes`
Response
`Status: 204`
## [List CODEOWNERS errors](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors)
List any syntax errors that are detected in the CODEOWNERS file.
For more information about the correct CODEOWNERS syntax, see "[About code owners](https://docs.github.com/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners)."
### [Fine-grained access tokens for "List CODEOWNERS errors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List CODEOWNERS errors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`ref` string A branch, tag or commit name used to determine which version of the CODEOWNERS file to use. Default: the repository's default branch (e.g. `main`)
### [HTTP response status codes for "List CODEOWNERS errors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List CODEOWNERS errors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-codeowners-errors--code-samples)
#### Request example
get/repos/{owner}/{repo}/codeowners/errors
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/codeowners/errors`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "errors": [     {       "line": 3,       "column": 1,       "kind": "Invalid pattern",       "source": "***/*.rb @monalisa",       "suggestion": "Did you mean `**/*.rb`?",       "message": "Invalid pattern on line 3: Did you mean `**/*.rb`?\n\n  ***/*.rb @monalisa\n  ^",       "path": ".github/CODEOWNERS"     },     {       "line": 7,       "column": 7,       "kind": "Invalid owner",       "source": "*.txt docs@",       "suggestion": null,       "message": "Invalid owner on line 7:\n\n  *.txt docs@\n        ^",       "path": ".github/CODEOWNERS"     }   ] }`
## [List repository contributors](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors)
Lists contributors to the specified repository and sorts them by the number of commits per contributor in descending order. This endpoint may return information that is a few hours old because the GitHub REST API caches contributor data to improve performance.
GitHub identifies contributors by author email address. This endpoint groups contribution counts by GitHub user, which includes all associated email addresses. To improve performance, only the first 500 author email addresses in the repository link to GitHub users. The rest will appear as anonymous contributors without associated GitHub user information.
### [Fine-grained access tokens for "List repository contributors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository contributors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`anon` string Set to `1` or `true` to include anonymous contributors in results.
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository contributors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors--status-codes)
Status code | Description
---|---
`200` | If repository contains content
`204` | Response if repository is empty
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List repository contributors"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-contributors--code-samples)
#### Request example
get/repos/{owner}/{repo}/contributors
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/contributors`
If repository contains content
  * Example response
  * Response schema


`Status: 200`
`[   {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false,     "contributions": 32   } ]`
## [Create a repository dispatch event](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event)
You can use this endpoint to trigger a webhook event called `repository_dispatch` when you want activity that happens outside of GitHub to trigger a GitHub Actions workflow or GitHub App webhook. You must configure your GitHub Actions workflow or GitHub App to run when the `repository_dispatch` event occurs. For an example `repository_dispatch` webhook payload, see "[RepositoryDispatchEvent](https://docs.github.com/webhooks/event-payloads/#repository_dispatch)."
The `client_payload` parameter is available for any extra information that your workflow might need. This parameter is a JSON payload that will be passed on when the webhook event is dispatched. For example, the `client_payload` can include a message that a user would like to send using a GitHub Actions workflow. Or the `client_payload` can be used as a test to debug your workflow.
This input example shows how you can use the `client_payload` as a test to debug your workflow.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a repository dispatch event"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Contents" repository permissions (write)


### [Parameters for "Create a repository dispatch event"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`event_type` string Required A custom webhook event name. Must be 100 characters or fewer.
`client_payload` object JSON payload with extra information about the webhook event that your action or workflow may use. The maximum number of top-level properties is 10. The total size of the JSON payload must be less than 64KB.
### [HTTP response status codes for "Create a repository dispatch event"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a repository dispatch event"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-dispatch-event--code-samples)
#### Request example
post/repos/{owner}/{repo}/dispatches
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/dispatches \   -d '{"event_type":"on-demand-test","client_payload":{"unit":false,"integration":true}}'`
Response
`Status: 204`
## [Check if immutable releases are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository)
Shows whether immutable releases are enabled or disabled. Also identifies whether immutability is being enforced by the repository owner. The authenticated user must have admin read access to the repository.
### [Fine-grained access tokens for "Check if immutable releases are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Check if immutable releases are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check if immutable releases are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository--status-codes)
Status code | Description
---|---
`200` | Response if immutable releases are enabled
`404` | Not Found if immutable releases are not enabled for the repository
### [Code samples for "Check if immutable releases are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-immutable-releases-are-enabled-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/immutable-releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/immutable-releases`
Response if immutable releases are enabled
  * Example response
  * Response schema


`Status: 200`
`{   "enabled": true,   "enforced_by_owner": false }`
## [Enable immutable releases](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases)
Enables immutable releases for a repository. The authenticated user must have admin access to the repository.
### [Fine-grained access tokens for "Enable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Enable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Enable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`409` | Conflict
### [Code samples for "Enable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-immutable-releases--code-samples)
#### Request example
put/repos/{owner}/{repo}/immutable-releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/immutable-releases`
A header with no content is returned.
`Status: 204`
## [Disable immutable releases](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases)
Disables immutable releases for a repository. The authenticated user must have admin access to the repository.
### [Fine-grained access tokens for "Disable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Disable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Disable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`409` | Conflict
### [Code samples for "Disable immutable releases"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-immutable-releases--code-samples)
#### Request example
delete/repos/{owner}/{repo}/immutable-releases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/immutable-releases`
A header with no content is returned.
`Status: 204`
## [List repository languages](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages)
Lists languages for the specified repository. The value shown for each language is the number of bytes of code written in that language.
### [Fine-grained access tokens for "List repository languages"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository languages"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "List repository languages"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository languages"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-languages--code-samples)
#### Request example
get/repos/{owner}/{repo}/languages
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/languages`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "C": 78769,   "Python": 7769 }`
## [Check if private vulnerability reporting is enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository)
Returns a boolean indicating whether or not private vulnerability reporting is enabled for the repository. For more information, see "[Evaluating the security settings of a repository](https://docs.github.com/code-security/security-advisories/working-with-repository-security-advisories/evaluating-the-security-settings-of-a-repository)".
### [Fine-grained access tokens for "Check if private vulnerability reporting is enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Check if private vulnerability reporting is enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check if private vulnerability reporting is enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository--status-codes)
Status code | Description
---|---
`200` | Private vulnerability reporting status
`422` | Bad Request
### [Code samples for "Check if private vulnerability reporting is enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-private-vulnerability-reporting-is-enabled-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/private-vulnerability-reporting
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/private-vulnerability-reporting`
Private vulnerability reporting status
  * Example response
  * Response schema


`Status: 200`
`{   "enabled": true }`
## [Enable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository)
Enables private vulnerability reporting for a repository. The authenticated user must have admin access to the repository. For more information, see "[Privately reporting a security vulnerability](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability)."
### [Fine-grained access tokens for "Enable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Enable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Enable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`422` | Bad Request
### [Code samples for "Enable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-private-vulnerability-reporting-for-a-repository--code-samples)
#### Request example
put/repos/{owner}/{repo}/private-vulnerability-reporting
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/private-vulnerability-reporting`
A header with no content is returned.
`Status: 204`
## [Disable private vulnerability reporting for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository)
Disables private vulnerability reporting for a repository. The authenticated user must have admin access to the repository. For more information, see "[Privately reporting a security vulnerability](https://docs.github.com/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability)".
### [Fine-grained access tokens for "Disable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Disable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Disable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`422` | Bad Request
### [Code samples for "Disable private vulnerability reporting for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-private-vulnerability-reporting-for-a-repository--code-samples)
#### Request example
delete/repos/{owner}/{repo}/private-vulnerability-reporting
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/private-vulnerability-reporting`
A header with no content is returned.
`Status: 204`
## [List repository tags](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags)
### [Fine-grained access tokens for "List repository tags"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repository tags"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository tags"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repository tags"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-tags--code-samples)
#### Request example
get/repos/{owner}/{repo}/tags
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/tags`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "name": "v0.1",     "commit": {       "sha": "c5b97d5ae6c19d5c5df71a34c7fbeeda2479ccbc",       "url": "https://api.github.com/repos/octocat/Hello-World/commits/c5b97d5ae6c19d5c5df71a34c7fbeeda2479ccbc"     },     "zipball_url": "https://github.com/octocat/Hello-World/zipball/v0.1",     "tarball_url": "https://github.com/octocat/Hello-World/tarball/v0.1",     "node_id": "MDQ6VXNlcjE="   } ]`
## [List repository teams](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams)
Lists the teams that have access to the specified repository and that are also visible to the authenticated user.
For a public repository, a team is listed only if that team added the public repository explicitly.
OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to use this endpoint with a public repository, and `repo` scope to use this endpoint with a private repository.
### [Fine-grained access tokens for "List repository teams"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "List repository teams"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repository teams"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "List repository teams"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repository-teams--code-samples)
#### Request example
get/repos/{owner}/{repo}/teams
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/teams`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1,     "node_id": "MDQ6VGVhbTE=",     "url": "https://api.github.com/teams/1",     "html_url": "https://github.com/orgs/github/teams/justice-league",     "name": "Justice League",     "slug": "justice-league",     "description": "A great team.",     "privacy": "closed",     "notification_setting": "notifications_enabled",     "permission": "admin",     "members_url": "https://api.github.com/teams/1/members{/member}",     "repositories_url": "https://api.github.com/teams/1/repos",     "parent": null   } ]`
## [Get all repository topics](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics)
### [Fine-grained access tokens for "Get all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
### [HTTP response status codes for "Get all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#get-all-repository-topics--code-samples)
#### Request example
get/repos/{owner}/{repo}/topics
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/topics`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "names": [     "octocat",     "atom",     "electron",     "api"   ] }`
## [Replace all repository topics](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics)
### [Fine-grained access tokens for "Replace all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Replace all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`names` array of strings Required An array of topics to add to the repository. Pass one or more topics to _replace_ the set of existing topics. Send an empty array (`[]`) to clear all topics from the repository. **Note:** Topic `names` will be saved as lowercase.
### [HTTP response status codes for "Replace all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Replace all repository topics"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#replace-all-repository-topics--code-samples)
#### Request example
put/repos/{owner}/{repo}/topics
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/topics \   -d '{"names":["octocat","atom","electron","api"]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "names": [     "octocat",     "atom",     "electron",     "api"   ] }`
## [Transfer a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository)
A transfer request will need to be accepted by the new owner when transferring a personal repository to another user. The response will contain the original `owner`, and the transfer will continue asynchronously. For more details on the requirements to transfer personal and organization-owned repositories, see [about repository transfers](https://docs.github.com/articles/about-repository-transfers/).
### [Fine-grained access tokens for "Transfer a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Transfer a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`new_owner` string Required The username or organization name the repository will be transferred to.
`new_name` string The new name to be given to the repository.
`team_ids` array of integers ID of the team or teams to add to the repository. Teams can only be added to organization-owned repositories.
### [HTTP response status codes for "Transfer a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository--status-codes)
Status code | Description
---|---
`202` | Accepted
### [Code samples for "Transfer a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#transfer-a-repository--code-samples)
#### Request example
post/repos/{owner}/{repo}/transfer
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/transfer \   -d '{"new_owner":"github","team_ids":[12,345],"new_name":"octorepo"}'`
Response
  * Example response
  * Response schema


`Status: 202`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "language": null,   "forks_count": 9,   "stargazers_count": 80,   "watchers_count": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "admin": false,     "push": false,     "pull": true   },   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "allow_forking": true,     "subscribers_count": 42,     "network_count": 0   } }`
## [Check if vulnerability alerts are enabled for a repository](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository)
Shows whether dependency alerts are enabled or disabled for a repository. The authenticated user must have admin read access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)".
### [Fine-grained access tokens for "Check if vulnerability alerts are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (read)


### [Parameters for "Check if vulnerability alerts are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Check if vulnerability alerts are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository--status-codes)
Status code | Description
---|---
`204` | Response if repository is enabled with vulnerability alerts
`404` | Not Found if repository is not enabled with vulnerability alerts
### [Code samples for "Check if vulnerability alerts are enabled for a repository"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#check-if-vulnerability-alerts-are-enabled-for-a-repository--code-samples)
#### Request example
get/repos/{owner}/{repo}/vulnerability-alerts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/vulnerability-alerts`
Response if repository is enabled with vulnerability alerts
`Status: 204`
## [Enable vulnerability alerts](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts)
Enables dependency alerts and the dependency graph for a repository. The authenticated user must have admin access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)".
### [Fine-grained access tokens for "Enable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Enable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Enable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Enable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#enable-vulnerability-alerts--code-samples)
#### Request example
put/repos/{owner}/{repo}/vulnerability-alerts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/vulnerability-alerts`
Response
`Status: 204`
## [Disable vulnerability alerts](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts)
Disables dependency alerts and the dependency graph for a repository. The authenticated user must have admin access to the repository. For more information, see "[About security alerts for vulnerable dependencies](https://docs.github.com/articles/about-security-alerts-for-vulnerable-dependencies)".
### [Fine-grained access tokens for "Disable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Disable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Disable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts--status-codes)
Status code | Description
---|---
`204` | No Content
### [Code samples for "Disable vulnerability alerts"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#disable-vulnerability-alerts--code-samples)
#### Request example
delete/repos/{owner}/{repo}/vulnerability-alerts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/vulnerability-alerts`
Response
`Status: 204`
## [Create a repository using a template](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template)
Creates a new repository using a repository template. Use the `template_owner` and `template_repo` route parameters to specify the repository to use as the template. If the repository is not public, the authenticated user must own or be a member of an organization that owns the repository. To check if a repository is available to use as a template, get the repository's information using the [Get a repository](https://docs.github.com/rest/repos/repos#get-a-repository) endpoint and check that the `is_template` key is `true`.
OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository.
### [Fine-grained access tokens for "Create a repository using a template"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Contents" repository permissions (read)


### [Parameters for "Create a repository using a template"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`template_owner` string Required The account owner of the template repository. The name is not case sensitive.
`template_repo` string Required The name of the template repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`owner` string The organization or person who will own the new repository. To create a new repository in an organization, the authenticated user must be a member of the specified organization.
`name` string Required The name of the new repository.
`description` string A short description of the new repository.
`include_all_branches` boolean Set to `true` to include the directory structure and files from all branches in the template repository, and not just the default branch. Default: `false`. Default: `false`
`private` boolean Either `true` to create a new private repository or `false` to create a new public one. Default: `false`
### [HTTP response status codes for "Create a repository using a template"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Create a repository using a template"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-using-a-template--code-samples)
#### Request example
post/repos/{template_owner}/{template_repo}/generate
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/TEMPLATE_OWNER/TEMPLATE_REPO/generate \   -d '{"owner":"octocat","name":"Hello-World","description":"This is your first repository","include_all_branches":false,"private":false}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://github.com/licenses/mit"   },   "language": null,   "forks_count": 9,   "forks": 9,   "stargazers_count": 80,   "watchers_count": 80,   "watchers": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "open_issues": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "pull": true,     "push": false,     "admin": false   },   "allow_rebase_merge": true,   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0   },   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "allow_forking": true,   "web_commit_signoff_required": false,   "subscribers_count": 42,   "network_count": 0,   "organization": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "Organization",     "site_admin": false   },   "parent": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   },   "source": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   } }`
## [List public repositories](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories)
Lists all public repositories in the order that they were created.
Note:
  * For GitHub Enterprise Server, this endpoint will only list repositories available to all users on the enterprise.
  * Pagination is powered exclusively by the `since` parameter. Use the [Link header](https://docs.github.com/rest/guides/using-pagination-in-the-rest-api#using-link-headers) to get the URL for the next page of repositories.


### [Fine-grained access tokens for "List public repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List public repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`since` integer A repository ID. Only return repositories with an ID greater than this ID.
### [HTTP response status codes for "List public repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List public repositories"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-public-repositories--code-samples)
#### Request example
get/repositories
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repositories`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "hooks_url": "http://api.github.com/repos/octocat/Hello-World/hooks"   } ]`
## [List repositories for the authenticated user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user)
Lists repositories that the authenticated user has explicit permission (`:read`, `:write`, or `:admin`) to access.
The authenticated user has explicit permission to access repositories they own, repositories where they are a collaborator, and repositories that they can access through an organization membership.
### [Fine-grained access tokens for "List repositories for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repositories for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`visibility` string Limit results to repositories with the specified visibility. Default: `all` Can be one of: `all`, `public`, `private`
`affiliation` string Comma-separated list of values. Can include:
  * `owner`: Repositories that are owned by the authenticated user.
  * `collaborator`: Repositories that the user has been added to as a collaborator.
  * `organization_member`: Repositories that the user has access to through being a member of an organization. This includes every repository on every team that the user is on.

Default: `owner,collaborator,organization_member`
`type` string Limit results to repositories of the specified type. Will cause a `422` error if used in the same request as **visibility** or **affiliation**. Default: `all` Can be one of: `all`, `owner`, `public`, `private`, `member`
`sort` string The property to sort the results by. Default: `full_name` Can be one of: `created`, `updated`, `pushed`, `full_name`
`direction` string The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
`since` string Only show repositories updated after the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
`before` string Only show repositories updated before the given time. This is a timestamp in [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) format: `YYYY-MM-DDTHH:MM:SSZ`.
### [HTTP response status codes for "List repositories for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`403` | Forbidden
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List repositories for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-the-authenticated-user--code-samples)
#### Request example
get/user/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/repos`
Default response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "template_repository": null,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   } ]`
## [Create a repository for the authenticated user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user)
Creates a new repository for the authenticated user.
OAuth app tokens and personal access tokens (classic) need the `public_repo` or `repo` scope to create a public repository, and `repo` scope to create a private repository.
### [Fine-grained access tokens for "Create a repository for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write)


### [Parameters for "Create a repository for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Body parameters Name, Type, Description
---
`name` string Required The name of the repository.
`description` string A short description of the repository.
`homepage` string A URL with more information about the repository.
`private` boolean Whether the repository is private. Default: `false`
`has_issues` boolean Whether issues are enabled. Default: `true`
`has_projects` boolean Whether projects are enabled. Default: `true`
`has_wiki` boolean Whether the wiki is enabled. Default: `true`
`has_discussions` boolean Whether discussions are enabled. Default: `false`
`team_id` integer The id of the team that will be granted access to this repository. This is only valid when creating a repository in an organization.
`auto_init` boolean Whether the repository is initialized with a minimal README. Default: `false`
`gitignore_template` string The desired language or platform to apply to the .gitignore.
`license_template` string The license keyword of the open source license for this repository.
`allow_squash_merge` boolean Whether to allow squash merges for pull requests. Default: `true`
`allow_merge_commit` boolean Whether to allow merge commits for pull requests. Default: `true`
`allow_rebase_merge` boolean Whether to allow rebase merges for pull requests. Default: `true`
`allow_auto_merge` boolean Whether to allow Auto-merge to be used on pull requests. Default: `false`
`delete_branch_on_merge` boolean Whether to delete head branches when pull requests are merged Default: `false`
`squash_merge_commit_title` string Required when using `squash_merge_commit_message`. The default value for a squash merge commit title:
  * `PR_TITLE` - default to the pull request's title.
  * `COMMIT_OR_PR_TITLE` - default to the commit's title (if only one commit) or the pull request's title (when more than one commit).

Can be one of: `PR_TITLE`, `COMMIT_OR_PR_TITLE`
`squash_merge_commit_message` string The default value for a squash merge commit message:
  * `PR_BODY` - default to the pull request's body.
  * `COMMIT_MESSAGES` - default to the branch's commit messages.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `COMMIT_MESSAGES`, `BLANK`
`merge_commit_title` string Required when using `merge_commit_message`. The default value for a merge commit title.
  * `PR_TITLE` - default to the pull request's title.
  * `MERGE_MESSAGE` - default to the classic title for a merge message (e.g., Merge pull request #123 from branch-name).

Can be one of: `PR_TITLE`, `MERGE_MESSAGE`
`merge_commit_message` string The default value for a merge commit message.
  * `PR_TITLE` - default to the pull request's title.
  * `PR_BODY` - default to the pull request's body.
  * `BLANK` - default to a blank commit message.

Can be one of: `PR_BODY`, `PR_TITLE`, `BLANK`
`has_downloads` boolean Whether downloads are enabled. Default: `true`
`is_template` boolean Whether this repository acts as a template that can be used to generate new repositories. Default: `false`
### [HTTP response status codes for "Create a repository for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`201` | Created
`304` | Not modified
`400` | Bad Request
`401` | Requires authentication
`403` | Forbidden
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a repository for the authenticated user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#create-a-repository-for-the-authenticated-user--code-samples)
#### Request example
post/user/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/repos \   -d '{"name":"Hello-World","description":"This is your first repo!","homepage":"https://github.com","private":false,"is_template":true}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "id": 1296269,   "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",   "name": "Hello-World",   "full_name": "octocat/Hello-World",   "owner": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "private": false,   "html_url": "https://github.com/octocat/Hello-World",   "description": "This your first repo!",   "fork": false,   "url": "https://api.github.com/repos/octocat/Hello-World",   "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",   "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",   "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",   "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",   "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",   "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",   "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",   "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",   "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",   "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",   "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",   "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",   "events_url": "https://api.github.com/repos/octocat/Hello-World/events",   "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",   "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",   "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",   "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",   "git_url": "git:github.com/octocat/Hello-World.git",   "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",   "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",   "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",   "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",   "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",   "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",   "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",   "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",   "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",   "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",   "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",   "ssh_url": "git@github.com:octocat/Hello-World.git",   "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",   "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",   "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",   "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",   "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",   "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",   "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",   "clone_url": "https://github.com/octocat/Hello-World.git",   "mirror_url": "git:git.example.com/octocat/Hello-World",   "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",   "svn_url": "https://svn.github.com/octocat/Hello-World",   "homepage": "https://github.com",   "license": {     "key": "mit",     "name": "MIT License",     "url": "https://api.github.com/licenses/mit",     "spdx_id": "MIT",     "node_id": "MDc6TGljZW5zZW1pdA==",     "html_url": "https://github.com/licenses/mit"   },   "language": null,   "forks_count": 9,   "forks": 9,   "stargazers_count": 80,   "watchers_count": 80,   "watchers": 80,   "size": 108,   "default_branch": "master",   "open_issues_count": 0,   "open_issues": 0,   "is_template": false,   "topics": [     "octocat",     "atom",     "electron",     "api"   ],   "has_issues": true,   "has_projects": true,   "has_wiki": true,   "has_pages": false,   "has_downloads": true,   "archived": false,   "disabled": false,   "visibility": "public",   "pushed_at": "2011-01-26T19:06:43Z",   "created_at": "2011-01-26T19:01:12Z",   "updated_at": "2011-01-26T19:14:43Z",   "permissions": {     "pull": true,     "push": false,     "admin": false   },   "allow_rebase_merge": true,   "template_repository": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World-Template",     "full_name": "octocat/Hello-World-Template",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World-Template",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World-Template",     "archive_url": "https://api.github.com/repos/octocat/Hello-World-Template/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World-Template/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World-Template/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World-Template/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World-Template/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World-Template/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World-Template/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World-Template/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World-Template/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World-Template/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World-Template/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World-Template/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World-Template.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World-Template/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World-Template/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World-Template/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World-Template/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World-Template/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World-Template/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World-Template/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World-Template/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World-Template/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World-Template.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World-Template/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World-Template/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World-Template/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World-Template/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World-Template/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World-Template/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World-Template.git",     "mirror_url": "git:git.example.com/octocat/Hello-World-Template",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World-Template/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World-Template",     "homepage": "https://github.com",     "language": null,     "forks": 9,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "watchers": 80,     "size": 108,     "default_branch": "master",     "open_issues": 0,     "open_issues_count": 0,     "is_template": true,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0   },   "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",   "allow_squash_merge": true,   "allow_auto_merge": false,   "delete_branch_on_merge": true,   "allow_merge_commit": true,   "allow_forking": true,   "web_commit_signoff_required": false,   "subscribers_count": 42,   "network_count": 0,   "organization": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "Organization",     "site_admin": false   },   "parent": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   },   "source": {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": true,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "allow_rebase_merge": true,     "temp_clone_token": "ABTLWHOULUVAXGTRYU7OC2876QJ2O",     "allow_squash_merge": true,     "allow_auto_merge": false,     "delete_branch_on_merge": true,     "allow_merge_commit": true,     "subscribers_count": 42,     "network_count": 0,     "license": {       "key": "mit",       "name": "MIT License",       "url": "https://api.github.com/licenses/mit",       "spdx_id": "MIT",       "node_id": "MDc6TGljZW5zZW1pdA==",       "html_url": "https://api.github.com/licenses/mit"     },     "forks": 1,     "open_issues": 1,     "watchers": 1   } }`
## [List repositories for a user](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user)
Lists public repositories for the specified user.
### [Fine-grained access tokens for "List repositories for a user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Metadata" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List repositories for a user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`username` string Required The handle for the GitHub user account.
Query parameters Name, Type, Description
---
`type` string Limit results to repositories of the specified type. Default: `owner` Can be one of: `all`, `owner`, `member`
`sort` string The property to sort the results by. Default: `full_name` Can be one of: `created`, `updated`, `pushed`, `full_name`
`direction` string The order to sort by. Default: `asc` when using `full_name`, otherwise `desc`. Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List repositories for a user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List repositories for a user"](https://docs.github.com/en/rest/repos/repos?apiVersion=2022-11-28#list-repositories-for-a-user--code-samples)
#### Request example
get/users/{username}/repos
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/users/USERNAME/repos`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "id": 1296269,     "node_id": "MDEwOlJlcG9zaXRvcnkxMjk2MjY5",     "name": "Hello-World",     "full_name": "octocat/Hello-World",     "owner": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "private": false,     "html_url": "https://github.com/octocat/Hello-World",     "description": "This your first repo!",     "fork": false,     "url": "https://api.github.com/repos/octocat/Hello-World",     "archive_url": "https://api.github.com/repos/octocat/Hello-World/{archive_format}{/ref}",     "assignees_url": "https://api.github.com/repos/octocat/Hello-World/assignees{/user}",     "blobs_url": "https://api.github.com/repos/octocat/Hello-World/git/blobs{/sha}",     "branches_url": "https://api.github.com/repos/octocat/Hello-World/branches{/branch}",     "collaborators_url": "https://api.github.com/repos/octocat/Hello-World/collaborators{/collaborator}",     "comments_url": "https://api.github.com/repos/octocat/Hello-World/comments{/number}",     "commits_url": "https://api.github.com/repos/octocat/Hello-World/commits{/sha}",     "compare_url": "https://api.github.com/repos/octocat/Hello-World/compare/{base}...{head}",     "contents_url": "https://api.github.com/repos/octocat/Hello-World/contents/{+path}",     "contributors_url": "https://api.github.com/repos/octocat/Hello-World/contributors",     "deployments_url": "https://api.github.com/repos/octocat/Hello-World/deployments",     "downloads_url": "https://api.github.com/repos/octocat/Hello-World/downloads",     "events_url": "https://api.github.com/repos/octocat/Hello-World/events",     "forks_url": "https://api.github.com/repos/octocat/Hello-World/forks",     "git_commits_url": "https://api.github.com/repos/octocat/Hello-World/git/commits{/sha}",     "git_refs_url": "https://api.github.com/repos/octocat/Hello-World/git/refs{/sha}",     "git_tags_url": "https://api.github.com/repos/octocat/Hello-World/git/tags{/sha}",     "git_url": "git:github.com/octocat/Hello-World.git",     "issue_comment_url": "https://api.github.com/repos/octocat/Hello-World/issues/comments{/number}",     "issue_events_url": "https://api.github.com/repos/octocat/Hello-World/issues/events{/number}",     "issues_url": "https://api.github.com/repos/octocat/Hello-World/issues{/number}",     "keys_url": "https://api.github.com/repos/octocat/Hello-World/keys{/key_id}",     "labels_url": "https://api.github.com/repos/octocat/Hello-World/labels{/name}",     "languages_url": "https://api.github.com/repos/octocat/Hello-World/languages",     "merges_url": "https://api.github.com/repos/octocat/Hello-World/merges",     "milestones_url": "https://api.github.com/repos/octocat/Hello-World/milestones{/number}",     "notifications_url": "https://api.github.com/repos/octocat/Hello-World/notifications{?since,all,participating}",     "pulls_url": "https://api.github.com/repos/octocat/Hello-World/pulls{/number}",     "releases_url": "https://api.github.com/repos/octocat/Hello-World/releases{/id}",     "ssh_url": "git@github.com:octocat/Hello-World.git",     "stargazers_url": "https://api.github.com/repos/octocat/Hello-World/stargazers",     "statuses_url": "https://api.github.com/repos/octocat/Hello-World/statuses/{sha}",     "subscribers_url": "https://api.github.com/repos/octocat/Hello-World/subscribers",     "subscription_url": "https://api.github.com/repos/octocat/Hello-World/subscription",     "tags_url": "https://api.github.com/repos/octocat/Hello-World/tags",     "teams_url": "https://api.github.com/repos/octocat/Hello-World/teams",     "trees_url": "https://api.github.com/repos/octocat/Hello-World/git/trees{/sha}",     "clone_url": "https://github.com/octocat/Hello-World.git",     "mirror_url": "git:git.example.com/octocat/Hello-World",     "hooks_url": "https://api.github.com/repos/octocat/Hello-World/hooks",     "svn_url": "https://svn.github.com/octocat/Hello-World",     "homepage": "https://github.com",     "language": null,     "forks_count": 9,     "stargazers_count": 80,     "watchers_count": 80,     "size": 108,     "default_branch": "master",     "open_issues_count": 0,     "is_template": false,     "topics": [       "octocat",       "atom",       "electron",       "api"     ],     "has_issues": true,     "has_projects": true,     "has_wiki": true,     "has_pages": false,     "has_downloads": true,     "has_discussions": false,     "archived": false,     "disabled": false,     "visibility": "public",     "pushed_at": "2011-01-26T19:06:43Z",     "created_at": "2011-01-26T19:01:12Z",     "updated_at": "2011-01-26T19:14:43Z",     "permissions": {       "admin": false,       "push": false,       "pull": true     },     "security_and_analysis": {       "advanced_security": {         "status": "enabled"       },       "secret_scanning": {         "status": "enabled"       },       "secret_scanning_push_protection": {         "status": "disabled"       },       "secret_scanning_non_provider_patterns": {         "status": "disabled"       },       "secret_scanning_delegated_alert_dismissal": {         "status": "disabled"       }     }   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/repos/repos.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for repositories - GitHub Docs
