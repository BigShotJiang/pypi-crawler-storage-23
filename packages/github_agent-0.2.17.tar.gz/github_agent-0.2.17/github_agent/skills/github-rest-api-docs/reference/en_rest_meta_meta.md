[Skip to main content](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Meta](https://docs.github.com/en/rest/meta "Meta")/
  * [Meta](https://docs.github.com/en/rest/meta/meta "Meta")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
      * [GitHub API Root](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#github-api-root)
      * [Get GitHub meta information](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-github-meta-information)
      * [Get Octocat](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat)
      * [Get all API versions](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-all-api-versions)
      * [Get the Zen of GitHub](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-the-zen-of-github)
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Meta](https://docs.github.com/en/rest/meta "Meta")/
  * [Meta](https://docs.github.com/en/rest/meta/meta "Meta")


# REST API endpoints for meta data
Use the REST API to get meta information about GitHub, including the IP addresses of GitHub services.
## [GitHub API Root](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#github-api-root)
Get Hypermedia links to resources accessible in GitHub's REST API
### [Fine-grained access tokens for "GitHub API Root"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#github-api-root--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [HTTP response status codes for "GitHub API Root"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#github-api-root--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "GitHub API Root"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#github-api-root--code-samples)
#### Request example
get/
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "current_user_url": "https://api.github.com/user",   "current_user_authorizations_html_url": "https://github.com/settings/connections/applications{/client_id}",   "authorizations_url": "https://api.github.com/authorizations",   "code_search_url": "https://api.github.com/search/code?q={query}{&page,per_page,sort,order}",   "commit_search_url": "https://api.github.com/search/commits?q={query}{&page,per_page,sort,order}",   "emails_url": "https://api.github.com/user/emails",   "emojis_url": "https://api.github.com/emojis",   "events_url": "https://api.github.com/events",   "feeds_url": "https://api.github.com/feeds",   "followers_url": "https://api.github.com/user/followers",   "following_url": "https://api.github.com/user/following{/target}",   "gists_url": "https://api.github.com/gists{/gist_id}",   "hub_url": "https://api.github.com/hub",   "issue_search_url": "https://api.github.com/search/issues?q={query}{&page,per_page,sort,order}",   "issues_url": "https://api.github.com/issues",   "keys_url": "https://api.github.com/user/keys",   "label_search_url": "https://api.github.com/search/labels?q={query}&repository_id={repository_id}{&page,per_page}",   "notifications_url": "https://api.github.com/notifications",   "organization_url": "https://api.github.com/orgs/{org}",   "organization_repositories_url": "https://api.github.com/orgs/{org}/repos{?type,page,per_page,sort}",   "organization_teams_url": "https://api.github.com/orgs/{org}/teams",   "public_gists_url": "https://api.github.com/gists/public",   "rate_limit_url": "https://api.github.com/rate_limit",   "repository_url": "https://api.github.com/repos/{owner}/{repo}",   "repository_search_url": "https://api.github.com/search/repositories?q={query}{&page,per_page,sort,order}",   "current_user_repositories_url": "https://api.github.com/user/repos{?type,page,per_page,sort}",   "starred_url": "https://api.github.com/user/starred{/owner}{/repo}",   "starred_gists_url": "https://api.github.com/gists/starred",   "topic_search_url": "https://api.github.com/search/topics?q={query}{&page,per_page}",   "user_url": "https://api.github.com/users/{user}",   "user_organizations_url": "https://api.github.com/user/orgs",   "user_repositories_url": "https://api.github.com/users/{user}/repos{?type,page,per_page,sort}",   "user_search_url": "https://api.github.com/search/users?q={query}{&page,per_page,sort,order}" }`
## [Get GitHub meta information](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-github-meta-information)
Returns meta information about GitHub, including a list of GitHub's IP addresses. For more information, see "[About GitHub's IP addresses](https://docs.github.com/articles/about-github-s-ip-addresses/)."
The API's response also includes a list of GitHub's domain names.
The values shown in the documentation's response are example values. You must always query the API directly to get the latest values.
This endpoint returns both IPv4 and IPv6 addresses. However, not all features support IPv6. You should refer to the specific documentation for each feature to determine if IPv6 is supported.
### [Fine-grained access tokens for "Get GitHub meta information"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-github-meta-information--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [HTTP response status codes for "Get GitHub meta information"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-github-meta-information--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
### [Code samples for "Get GitHub meta information"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-github-meta-information--code-samples)
#### Request example
get/meta
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/meta`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "verifiable_password_authentication": true,   "ssh_key_fingerprints": {     "SHA256_RSA": 1234567890,     "SHA256_DSA": 1234567890,     "SHA256_ECDSA": 1234567890,     "SHA256_ED25519": 1234567890   },   "ssh_keys": [     "ssh-ed25519 ABCDEFGHIJKLMNOPQRSTUVWXYZ",     "ecdsa-sha2-nistp256 ABCDEFGHIJKLMNOPQRSTUVWXYZ",     "ssh-rsa ABCDEFGHIJKLMNOPQRSTUVWXYZ"   ],   "hooks": [     "192.0.2.1"   ],   "github_enterprise_importer": [     "192.0.2.1"   ],   "web": [     "192.0.2.1"   ],   "api": [     "192.0.2.1"   ],   "git": [     "192.0.2.1"   ],   "packages": [     "192.0.2.1"   ],   "pages": [     "192.0.2.1"   ],   "importer": [     "192.0.2.1"   ],   "actions": [     "192.0.2.1"   ],   "actions_macos": [     "192.0.2.1"   ],   "dependabot": [     "192.0.2.1"   ],   "copilot": [     "192.0.2.1"   ],   "domains": {     "website": [       "*.example.com"     ],     "codespaces": [       "*.example.com"     ],     "copilot": [       "*.example.com"     ],     "packages": [       "*.example.com"     ]   } }`
## [Get Octocat](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat)
Get the octocat as ASCII art
### [Fine-grained access tokens for "Get Octocat"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [Parameters for "Get Octocat"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`s` string The words to show in Octocat's speech bubble
### [HTTP response status codes for "Get Octocat"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get Octocat"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-octocat--code-samples)
#### Request example
get/octocat
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/octocat-stream" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/octocat`
Response
  * Example response
  * Response schema


`Status: 200`
`"               MMM.           .MMM\n               MMMMMMMMMMMMMMMMMMM\n               MMMMMMMMMMMMMMMMMMM      ___________________________________\n              MMMMMMMMMMMMMMMMMMMMM    |                                   |\n             MMMMMMMMMMMMMMMMMMMMMMM   | Avoid administrative distraction. |\n            MMMMMMMMMMMMMMMMMMMMMMMM   |_   _______________________________|\n            MMMM::- -:::::::- -::MMMM    |/\n             MM~:~ 00~:::::~ 00~:~MM\n        .. MMMMM::.00:::+:::.00::MMMMM ..\n              .MM::::: ._. :::::MM.\n                 MMMM;:::::;MMMM\n          -MM        MMMMMMM\n          ^  M+     MMMMMMMMM\n              MMMMMMM MM MM MM\n                   MM MM MM MM\n                   MM MM MM MM\n                .~~MM~MM~MM~MM~~.\n             ~~~~MM:~MM~~~MM~:MM~~~~\n            ~~~~~~==~==~~~==~==~~~~~~\n             ~~~~~~==~==~==~==~~~~~~\n                 :~==~==~==~==~~\n"`
## [Get all API versions](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-all-api-versions)
Get all supported GitHub API versions.
### [Fine-grained access tokens for "Get all API versions"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-all-api-versions--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [HTTP response status codes for "Get all API versions"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-all-api-versions--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get all API versions"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-all-api-versions--code-samples)
#### Request example
get/versions
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/versions`
Response
  * Example response
  * Response schema


`Status: 200`
`[   "2021-01-01",   "2021-06-01",   "2022-01-01" ]`
## [Get the Zen of GitHub](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-the-zen-of-github)
Get a random sentence from the Zen of GitHub
### [Fine-grained access tokens for "Get the Zen of GitHub"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-the-zen-of-github--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
This endpoint can be used without authentication if only public resources are requested.
### [HTTP response status codes for "Get the Zen of GitHub"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-the-zen-of-github--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get the Zen of GitHub"](https://docs.github.com/en/rest/meta/meta?apiVersion=2022-11-28#get-the-zen-of-github--code-samples)
#### Request example
get/zen
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: text/plain" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/zen`
Example response
  * Example response
  * Response schema


`Status: 200`
`"Responsive is better than fast"`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/meta/meta.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for meta data - GitHub Docs
