[Skip to main content](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Secret scanning](https://docs.github.com/en/rest/secret-scanning "Secret scanning")/
  * [Push protection](https://docs.github.com/en/rest/secret-scanning/push-protection "Push protection")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
      * [List organization pattern configurations](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations)
      * [Update organization pattern configurations](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations)
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Secret scanning](https://docs.github.com/en/rest/secret-scanning "Secret scanning")/
  * [Push protection](https://docs.github.com/en/rest/secret-scanning/push-protection "Push protection")


# REST API endpoints for secret scanning push protection
Use the REST API to manage secret scanning push protection.
## [List organization pattern configurations](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations)
Lists the secret scanning pattern configurations for an organization.
Personal access tokens (classic) need the `read:org` scope to use this endpoint.
### [Fine-grained access tokens for "List organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (read)


### [Parameters for "List organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
### [HTTP response status codes for "List organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations--status-codes)
Status code | Description
---|---
`200` | OK
`403` | Forbidden
`404` | Resource not found
### [Code samples for "List organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#list-organization-pattern-configurations--code-samples)
#### Request example
get/orgs/{org}/secret-scanning/pattern-configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/secret-scanning/pattern-configurations`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "pattern_config_version": "0ujsswThIGTUYm2K8FjOOfXtY1K",   "provider_pattern_overrides": [     {       "token_type": "GITHUB_PERSONAL_ACCESS_TOKEN",       "slug": "github_personal_access_token_legacy_v2",       "display_name": "GitHub Personal Access Token (Legacy v2)",       "alert_total": 15,       "alert_total_percentage": 36,       "false_positives": 2,       "false_positive_rate": 13,       "bypass_rate": 13,       "default_setting": "enabled",       "setting": "enabled",       "enterprise_setting": "enabled"     }   ],   "custom_pattern_overrides": [     {       "token_type": "cp_2",       "custom_pattern_version": "0ujsswThIGTUYm2K8FjOOfXtY1K",       "slug": "custom-api-key",       "display_name": "Custom API Key",       "alert_total": 15,       "alert_total_percentage": 36,       "false_positives": 3,       "false_positive_rate": 20,       "bypass_rate": 20,       "default_setting": "disabled",       "setting": "enabled"     }   ] }`
## [Update organization pattern configurations](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations)
Updates the secret scanning pattern configurations for an organization.
Personal access tokens (classic) need the `write:org` scope to use this endpoint.
### [Fine-grained access tokens for "Update organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" organization permissions (write)


### [Parameters for "Update organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`org` string Required The organization name. The name is not case sensitive.
Body parameters Name, Type, Description
---
`pattern_config_version` string or null The version of the entity. This is used to confirm you're updating the current version of the entity and mitigate unintentionally overriding someone else's update.
`provider_pattern_settings` array of objects Pattern settings for provider patterns.
Properties of `provider_pattern_settings` | Name, Type, Description
---
`token_type` string The ID of the pattern to configure.
`push_protection_setting` string Push protection setting to set for the pattern. Can be one of: `not-set`, `disabled`, `enabled`
`custom_pattern_settings` array of objects Pattern settings for custom patterns.
Properties of `custom_pattern_settings` | Name, Type, Description
---
`token_type` string The ID of the pattern to configure.
`custom_pattern_version` string or null The version of the entity. This is used to confirm you're updating the current version of the entity and mitigate unintentionally overriding someone else's update.
`push_protection_setting` string Push protection setting to set for the pattern. Can be one of: `disabled`, `enabled`
### [HTTP response status codes for "Update organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`403` | Forbidden
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update organization pattern configurations"](https://docs.github.com/en/rest/secret-scanning/push-protection?apiVersion=2022-11-28#update-organization-pattern-configurations--code-samples)
#### Request example
patch/orgs/{org}/secret-scanning/pattern-configurations
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PATCH \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/orgs/ORG/secret-scanning/pattern-configurations \   -d '{"pattern_config_version":"0ujsswThIGTUYm2K8FjOOfXtY1K","provider_pattern_settings":[{"token_type":"GITHUB_PERSONAL_ACCESS_TOKEN","push_protection_setting":"enabled"}],"custom_pattern_settings":[{"token_type":"cp_2","custom_pattern_version":"0ujsswThIGTUYm2K8FjOOfXtY1K","push_protection_setting":"enabled"}]}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "pattern_config_version": "0ujsswThIGTUYm2K8FjOOfXtY1K" }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/secret-scanning/push-protection.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for secret scanning push protection - GitHub Docs
