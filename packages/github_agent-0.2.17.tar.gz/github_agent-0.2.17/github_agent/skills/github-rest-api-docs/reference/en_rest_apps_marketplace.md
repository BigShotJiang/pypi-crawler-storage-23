[Skip to main content](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [Marketplace](https://docs.github.com/en/rest/apps/marketplace "Marketplace")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
      * [About GitHub Marketplace](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#about-github-marketplace)
      * [Get a subscription plan for an account](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account)
      * [List plans](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans)
      * [List accounts for a plan](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan)
      * [Get a subscription plan for an account (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed)
      * [List plans (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed)
      * [List accounts for a plan (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed)
      * [List subscriptions for the authenticated user](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user)
      * [List subscriptions for the authenticated user (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed)
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Apps](https://docs.github.com/en/rest/apps "Apps")/
  * [Marketplace](https://docs.github.com/en/rest/apps/marketplace "Marketplace")


# REST API endpoints for GitHub Marketplace
Use the REST API to interact with GitHub Marketplace
## [About GitHub Marketplace](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#about-github-marketplace)
For more information about GitHub Marketplace, see [GitHub Marketplace](https://docs.github.com/en/apps/publishing-apps-to-github-marketplace).
These endpoints allow you to see which customers are using a pricing plan, see a customer's purchases, and see if an account has an active subscription.
### [Testing with stubbed endpoints](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#testing-with-stubbed-endpoints)
You can [test your GitHub App](https://docs.github.com/en/apps/publishing-apps-to-github-marketplace/using-the-github-marketplace-api-in-your-app/testing-your-app) with **stubbed data**. Stubbed data is hard-coded, fake data that will not change based on actual subscriptions.
To test with stubbed data, use a stubbed endpoint in place of its production counterpart. This allows you to test whether the API logic succeeds before listing GitHub Apps on GitHub Marketplace.
Make sure to replace stubbed endpoints with production endpoints before deploying your GitHub App.
## [Get a subscription plan for an account](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account)
Shows whether the user or organization account actively subscribes to a plan listed by the authenticated GitHub App. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "Get a subscription plan for an account"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get a subscription plan for an account"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`account_id` integer Required account_id parameter
### [HTTP response status codes for "Get a subscription plan for an account"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
`404` | Not Found when the account has not purchased the listing
### [Code samples for "Get a subscription plan for an account"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account--code-samples)
#### Request example
get/marketplace_listing/accounts/{account_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/accounts/ACCOUNT_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/orgs/github",   "type": "Organization",   "id": 4,   "login": "github",   "organization_billing_email": "billing@github.com",   "email": "billing@github.com",   "marketplace_pending_change": {     "effective_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "id": 77,     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1111",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1111/accounts",       "id": 1111,       "number": 2,       "name": "Startup",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 699,       "yearly_price_in_cents": 7870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "state": "published",       "unit_name": null,       "bullets": [         "Up to 10 private repositories",         "3 concurrent builds"       ]     }   },   "marketplace_purchase": {     "billing_cycle": "monthly",     "next_billing_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "on_free_trial": true,     "free_trial_ends_on": "2017-11-11T00:00:00Z",     "updated_at": "2017-11-02T01:12:12Z",     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1313",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",       "id": 1313,       "number": 3,       "name": "Pro",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 1099,       "yearly_price_in_cents": 11870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "unit_name": null,       "state": "published",       "bullets": [         "Up to 25 private repositories",         "11 concurrent builds"       ]     }   } }`
## [List plans](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans)
Lists all plans that are part of your GitHub Marketplace listing.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "List plans"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List plans"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List plans"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
`404` | Resource not found
### [Code samples for "List plans"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans--code-samples)
#### Request example
get/marketplace_listing/plans
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/plans`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/marketplace_listing/plans/1313",     "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",     "id": 1313,     "number": 3,     "name": "Pro",     "description": "A professional-grade CI solution",     "monthly_price_in_cents": 1099,     "yearly_price_in_cents": 11870,     "price_model": "FLAT_RATE",     "has_free_trial": true,     "unit_name": null,     "state": "published",     "bullets": [       "Up to 25 private repositories",       "11 concurrent builds"     ]   } ]`
## [List accounts for a plan](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan)
Returns user and organization accounts associated with the specified plan, including free plans. For per-seat pricing, you see the list of accounts that have purchased the plan, including the number of seats purchased. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "List accounts for a plan"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List accounts for a plan"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`plan_id` integer Required The unique identifier of the plan.
Query parameters Name, Type, Description
---
`sort` string The property to sort the results by. Default: `created` Can be one of: `created`, `updated`
`direction` string To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List accounts for a plan"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "List accounts for a plan"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan--code-samples)
#### Request example
get/marketplace_listing/plans/{plan_id}/accounts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/plans/PLAN_ID/accounts`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/orgs/github",     "type": "Organization",     "id": 4,     "login": "github",     "organization_billing_email": "billing@github.com",     "marketplace_pending_change": {       "effective_date": "2017-11-11T00:00:00Z",       "unit_count": null,       "id": 77,       "plan": {         "url": "https://api.github.com/marketplace_listing/plans/1111",         "accounts_url": "https://api.github.com/marketplace_listing/plans/1111/accounts",         "id": 1111,         "number": 2,         "name": "Startup",         "description": "A professional-grade CI solution",         "monthly_price_in_cents": 699,         "yearly_price_in_cents": 7870,         "price_model": "FLAT_RATE",         "has_free_trial": true,         "state": "published",         "unit_name": null,         "bullets": [           "Up to 10 private repositories",           "3 concurrent builds"         ]       }     },     "marketplace_purchase": {       "billing_cycle": "monthly",       "next_billing_date": "2017-11-11T00:00:00Z",       "unit_count": null,       "on_free_trial": true,       "free_trial_ends_on": "2017-11-11T00:00:00Z",       "updated_at": "2017-11-02T01:12:12Z",       "plan": {         "url": "https://api.github.com/marketplace_listing/plans/1313",         "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",         "id": 1313,         "number": 3,         "name": "Pro",         "description": "A professional-grade CI solution",         "monthly_price_in_cents": 1099,         "yearly_price_in_cents": 11870,         "price_model": "FLAT_RATE",         "has_free_trial": true,         "unit_name": null,         "state": "published",         "bullets": [           "Up to 25 private repositories",           "11 concurrent builds"         ]       }     }   } ]`
## [Get a subscription plan for an account (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed)
Shows whether the user or organization account actively subscribes to a plan listed by the authenticated GitHub App. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "Get a subscription plan for an account (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "Get a subscription plan for an account (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`account_id` integer Required account_id parameter
### [HTTP response status codes for "Get a subscription plan for an account (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
`404` | Not Found when the account has not purchased the listing
### [Code samples for "Get a subscription plan for an account (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#get-a-subscription-plan-for-an-account-stubbed--code-samples)
#### Request example
get/marketplace_listing/stubbed/accounts/{account_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/stubbed/accounts/ACCOUNT_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/orgs/github",   "type": "Organization",   "id": 4,   "login": "github",   "organization_billing_email": "billing@github.com",   "email": "billing@github.com",   "marketplace_pending_change": {     "effective_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "id": 77,     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1111",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1111/accounts",       "id": 1111,       "number": 2,       "name": "Startup",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 699,       "yearly_price_in_cents": 7870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "state": "published",       "unit_name": null,       "bullets": [         "Up to 10 private repositories",         "3 concurrent builds"       ]     }   },   "marketplace_purchase": {     "billing_cycle": "monthly",     "next_billing_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "on_free_trial": true,     "free_trial_ends_on": "2017-11-11T00:00:00Z",     "updated_at": "2017-11-02T01:12:12Z",     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1313",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",       "id": 1313,       "number": 3,       "name": "Pro",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 1099,       "yearly_price_in_cents": 11870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "unit_name": null,       "state": "published",       "bullets": [         "Up to 25 private repositories",         "11 concurrent builds"       ]     }   } }`
## [List plans (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed)
Lists all plans that are part of your GitHub Marketplace listing.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "List plans (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List plans (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List plans (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
### [Code samples for "List plans (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-plans-stubbed--code-samples)
#### Request example
get/marketplace_listing/stubbed/plans
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/stubbed/plans`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/marketplace_listing/plans/1313",     "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",     "id": 1313,     "number": 3,     "name": "Pro",     "description": "A professional-grade CI solution",     "monthly_price_in_cents": 1099,     "yearly_price_in_cents": 11870,     "price_model": "FLAT_RATE",     "has_free_trial": true,     "unit_name": null,     "state": "published",     "bullets": [       "Up to 25 private repositories",       "11 concurrent builds"     ]   } ]`
## [List accounts for a plan (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed)
Returns repository and organization accounts associated with the specified plan, including free plans. For per-seat pricing, you see the list of accounts that have purchased the plan, including the number of seats purchased. When someone submits a plan change that won't be processed until the end of their billing cycle, you will also see the upcoming pending change.
GitHub Apps must use a [JWT](https://docs.github.com/apps/building-github-apps/authenticating-with-github-apps/#authenticating-as-a-github-app) to access this endpoint. OAuth apps must use [basic authentication](https://docs.github.com/rest/authentication/authenticating-to-the-rest-api#using-basic-authentication) with their client ID and client secret to access this endpoint.
### [Fine-grained access tokens for "List accounts for a plan (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed--fine-grained-access-tokens)
This endpoint does not work with GitHub App user access tokens, GitHub App installation access tokens, or fine-grained personal access tokens.
### [Parameters for "List accounts for a plan (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`plan_id` integer Required The unique identifier of the plan.
Query parameters Name, Type, Description
---
`sort` string The property to sort the results by. Default: `created` Can be one of: `created`, `updated`
`direction` string To return the oldest accounts first, set to `asc`. Ignored without the `sort` parameter. Can be one of: `asc`, `desc`
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List accounts for a plan (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed--status-codes)
Status code | Description
---|---
`200` | OK
`401` | Requires authentication
### [Code samples for "List accounts for a plan (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-accounts-for-a-plan-stubbed--code-samples)
#### Request example
get/marketplace_listing/stubbed/plans/{plan_id}/accounts
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/marketplace_listing/stubbed/plans/PLAN_ID/accounts`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/orgs/github",     "type": "Organization",     "id": 4,     "login": "github",     "organization_billing_email": "billing@github.com",     "marketplace_pending_change": {       "effective_date": "2017-11-11T00:00:00Z",       "unit_count": null,       "id": 77,       "plan": {         "url": "https://api.github.com/marketplace_listing/plans/1111",         "accounts_url": "https://api.github.com/marketplace_listing/plans/1111/accounts",         "id": 1111,         "number": 2,         "name": "Startup",         "description": "A professional-grade CI solution",         "monthly_price_in_cents": 699,         "yearly_price_in_cents": 7870,         "price_model": "FLAT_RATE",         "has_free_trial": true,         "state": "published",         "unit_name": null,         "bullets": [           "Up to 10 private repositories",           "3 concurrent builds"         ]       }     },     "marketplace_purchase": {       "billing_cycle": "monthly",       "next_billing_date": "2017-11-11T00:00:00Z",       "unit_count": null,       "on_free_trial": true,       "free_trial_ends_on": "2017-11-11T00:00:00Z",       "updated_at": "2017-11-02T01:12:12Z",       "plan": {         "url": "https://api.github.com/marketplace_listing/plans/1313",         "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",         "id": 1313,         "number": 3,         "name": "Pro",         "description": "A professional-grade CI solution",         "monthly_price_in_cents": 1099,         "yearly_price_in_cents": 11870,         "price_model": "FLAT_RATE",         "has_free_trial": true,         "unit_name": null,         "state": "published",         "bullets": [           "Up to 25 private repositories",           "11 concurrent builds"         ]       }     }   } ]`
## [List subscriptions for the authenticated user](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user)
Lists the active subscriptions for the authenticated user.
### [Fine-grained access tokens for "List subscriptions for the authenticated user"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List subscriptions for the authenticated user"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List subscriptions for the authenticated user"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
`404` | Resource not found
### [Code samples for "List subscriptions for the authenticated user"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user--code-samples)
#### Request example
get/user/marketplace_purchases
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/marketplace_purchases`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "billing_cycle": "monthly",     "next_billing_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "on_free_trial": true,     "free_trial_ends_on": "2017-11-11T00:00:00Z",     "updated_at": "2017-11-02T01:12:12Z",     "account": {       "login": "github",       "id": 4,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "email": null,       "organization_billing_email": "billing@github.com",       "type": "Organization"     },     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1313",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",       "id": 1313,       "number": 3,       "name": "Pro",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 1099,       "yearly_price_in_cents": 11870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "unit_name": null,       "state": "published",       "bullets": [         "Up to 25 private repositories",         "11 concurrent builds"       ]     }   } ]`
## [List subscriptions for the authenticated user (stubbed)](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed)
Lists the active subscriptions for the authenticated user.
### [Fine-grained access tokens for "List subscriptions for the authenticated user (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token does not require any permissions.
### [Parameters for "List subscriptions for the authenticated user (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List subscriptions for the authenticated user (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed--status-codes)
Status code | Description
---|---
`200` | OK
`304` | Not modified
`401` | Requires authentication
### [Code samples for "List subscriptions for the authenticated user (stubbed)"](https://docs.github.com/en/rest/apps/marketplace?apiVersion=2022-11-28#list-subscriptions-for-the-authenticated-user-stubbed--code-samples)
#### Request example
get/user/marketplace_purchases/stubbed
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/user/marketplace_purchases/stubbed`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "billing_cycle": "monthly",     "next_billing_date": "2017-11-11T00:00:00Z",     "unit_count": null,     "on_free_trial": true,     "free_trial_ends_on": "2017-11-11T00:00:00Z",     "updated_at": "2017-11-02T01:12:12Z",     "account": {       "login": "github",       "id": 4,       "node_id": "MDEyOk9yZ2FuaXphdGlvbjE=",       "url": "https://api.github.com/orgs/github",       "email": null,       "organization_billing_email": "billing@github.com",       "type": "Organization"     },     "plan": {       "url": "https://api.github.com/marketplace_listing/plans/1313",       "accounts_url": "https://api.github.com/marketplace_listing/plans/1313/accounts",       "id": 1313,       "number": 3,       "name": "Pro",       "description": "A professional-grade CI solution",       "monthly_price_in_cents": 1099,       "yearly_price_in_cents": 11870,       "price_model": "FLAT_RATE",       "has_free_trial": true,       "unit_name": null,       "state": "published",       "bullets": [         "Up to 25 private repositories",         "11 concurrent builds"       ]     }   } ]`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/apps/marketplace.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Marketplace - GitHub Docs
