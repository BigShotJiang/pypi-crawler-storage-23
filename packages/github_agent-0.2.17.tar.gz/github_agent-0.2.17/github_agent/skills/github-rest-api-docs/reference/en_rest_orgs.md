[Skip to main content](https://docs.github.com/en/rest/orgs?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Organizations](https://docs.github.com/en/rest/orgs "Organizations")


# REST API endpoints for organizations
Use the REST API to control and manage all your GitHub organizations.
  * [REST API endpoints for organizations](https://docs.github.com/en/rest/orgs/orgs)
    * [List organizations](https://docs.github.com/en/rest/orgs/orgs#list-organizations)
    * [Get an organization](https://docs.github.com/en/rest/orgs/orgs#get-an-organization)
    * [Update an organization](https://docs.github.com/en/rest/orgs/orgs#update-an-organization)
    * [Delete an organization](https://docs.github.com/en/rest/orgs/orgs#delete-an-organization)
    * [List app installations for an organization](https://docs.github.com/en/rest/orgs/orgs#list-app-installations-for-an-organization)
    * [Get immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs#get-immutable-releases-settings-for-an-organization)
    * [Set immutable releases settings for an organization](https://docs.github.com/en/rest/orgs/orgs#set-immutable-releases-settings-for-an-organization)
    * [List selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs#list-selected-repositories-for-immutable-releases-enforcement)
    * [Set selected repositories for immutable releases enforcement](https://docs.github.com/en/rest/orgs/orgs#set-selected-repositories-for-immutable-releases-enforcement)
    * [Enable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs#enable-a-selected-repository-for-immutable-releases-in-an-organization)
    * [Disable a selected repository for immutable releases in an organization](https://docs.github.com/en/rest/orgs/orgs#disable-a-selected-repository-for-immutable-releases-in-an-organization)
    * [Enable or disable a security feature for an organization](https://docs.github.com/en/rest/orgs/orgs#enable-or-disable-a-security-feature-for-an-organization)
    * [List organizations for the authenticated user](https://docs.github.com/en/rest/orgs/orgs#list-organizations-for-the-authenticated-user)
    * [List organizations for a user](https://docs.github.com/en/rest/orgs/orgs#list-organizations-for-a-user)
  * [REST API endpoints for API Insights](https://docs.github.com/en/rest/orgs/api-insights)
    * [Get route stats by actor](https://docs.github.com/en/rest/orgs/api-insights#get-route-stats-by-actor)
    * [Get subject stats](https://docs.github.com/en/rest/orgs/api-insights#get-subject-stats)
    * [Get summary stats](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats)
    * [Get summary stats by user](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats-by-user)
    * [Get summary stats by actor](https://docs.github.com/en/rest/orgs/api-insights#get-summary-stats-by-actor)
    * [Get time stats](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats)
    * [Get time stats by user](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats-by-user)
    * [Get time stats by actor](https://docs.github.com/en/rest/orgs/api-insights#get-time-stats-by-actor)
    * [Get user stats](https://docs.github.com/en/rest/orgs/api-insights#get-user-stats)
  * [REST API endpoints for artifact metadata](https://docs.github.com/en/rest/orgs/artifact-metadata)
    * [Create an artifact deployment record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-an-artifact-deployment-record)
    * [Set cluster deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata#set-cluster-deployment-records)
    * [Create artifact metadata storage record](https://docs.github.com/en/rest/orgs/artifact-metadata#create-artifact-metadata-storage-record)
    * [List artifact deployment records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-deployment-records)
    * [List artifact storage records](https://docs.github.com/en/rest/orgs/artifact-metadata#list-artifact-storage-records)
  * [REST API endpoints for artifact attestations](https://docs.github.com/en/rest/orgs/attestations)
    * [List attestations by bulk subject digests](https://docs.github.com/en/rest/orgs/attestations#list-attestations-by-bulk-subject-digests)
    * [Delete attestations in bulk](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-in-bulk)
    * [Delete attestations by subject digest](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-by-subject-digest)
    * [List attestation repositories](https://docs.github.com/en/rest/orgs/attestations#list-attestation-repositories)
    * [Delete attestations by ID](https://docs.github.com/en/rest/orgs/attestations#delete-attestations-by-id)
    * [List attestations](https://docs.github.com/en/rest/orgs/attestations#list-attestations)
  * [REST API endpoints for blocking users](https://docs.github.com/en/rest/orgs/blocking)
    * [List users blocked by an organization](https://docs.github.com/en/rest/orgs/blocking#list-users-blocked-by-an-organization)
    * [Check if a user is blocked by an organization](https://docs.github.com/en/rest/orgs/blocking#check-if-a-user-is-blocked-by-an-organization)
    * [Block a user from an organization](https://docs.github.com/en/rest/orgs/blocking#block-a-user-from-an-organization)
    * [Unblock a user from an organization](https://docs.github.com/en/rest/orgs/blocking#unblock-a-user-from-an-organization)
  * [REST API endpoints for custom properties](https://docs.github.com/en/rest/orgs/custom-properties)
    * [Get all custom properties for an organization](https://docs.github.com/en/rest/orgs/custom-properties#get-all-custom-properties-for-an-organization)
    * [Create or update custom properties for an organization](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-custom-properties-for-an-organization)
    * [Get a custom property for an organization](https://docs.github.com/en/rest/orgs/custom-properties#get-a-custom-property-for-an-organization)
    * [Create or update a custom property for an organization](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-a-custom-property-for-an-organization)
    * [Remove a custom property for an organization](https://docs.github.com/en/rest/orgs/custom-properties#remove-a-custom-property-for-an-organization)
    * [List custom property values for organization repositories](https://docs.github.com/en/rest/orgs/custom-properties#list-custom-property-values-for-organization-repositories)
    * [Create or update custom property values for organization repositories](https://docs.github.com/en/rest/orgs/custom-properties#create-or-update-custom-property-values-for-organization-repositories)
  * [REST API endpoints for issue types](https://docs.github.com/en/rest/orgs/issue-types)
    * [List issue types for an organization](https://docs.github.com/en/rest/orgs/issue-types#list-issue-types-for-an-organization)
    * [Create issue type for an organization](https://docs.github.com/en/rest/orgs/issue-types#create-issue-type-for-an-organization)
    * [Update issue type for an organization](https://docs.github.com/en/rest/orgs/issue-types#update-issue-type-for-an-organization)
    * [Delete issue type for an organization](https://docs.github.com/en/rest/orgs/issue-types#delete-issue-type-for-an-organization)
  * [REST API endpoints for organization members](https://docs.github.com/en/rest/orgs/members)
    * [List failed organization invitations](https://docs.github.com/en/rest/orgs/members#list-failed-organization-invitations)
    * [List pending organization invitations](https://docs.github.com/en/rest/orgs/members#list-pending-organization-invitations)
    * [Create an organization invitation](https://docs.github.com/en/rest/orgs/members#create-an-organization-invitation)
    * [Cancel an organization invitation](https://docs.github.com/en/rest/orgs/members#cancel-an-organization-invitation)
    * [List organization invitation teams](https://docs.github.com/en/rest/orgs/members#list-organization-invitation-teams)
    * [List organization members](https://docs.github.com/en/rest/orgs/members#list-organization-members)
    * [Check organization membership for a user](https://docs.github.com/en/rest/orgs/members#check-organization-membership-for-a-user)
    * [Remove an organization member](https://docs.github.com/en/rest/orgs/members#remove-an-organization-member)
    * [Get organization membership for a user](https://docs.github.com/en/rest/orgs/members#get-organization-membership-for-a-user)
    * [Set organization membership for a user](https://docs.github.com/en/rest/orgs/members#set-organization-membership-for-a-user)
    * [Remove organization membership for a user](https://docs.github.com/en/rest/orgs/members#remove-organization-membership-for-a-user)
    * [List public organization members](https://docs.github.com/en/rest/orgs/members#list-public-organization-members)
    * [Check public organization membership for a user](https://docs.github.com/en/rest/orgs/members#check-public-organization-membership-for-a-user)
    * [Set public organization membership for the authenticated user](https://docs.github.com/en/rest/orgs/members#set-public-organization-membership-for-the-authenticated-user)
    * [Remove public organization membership for the authenticated user](https://docs.github.com/en/rest/orgs/members#remove-public-organization-membership-for-the-authenticated-user)
    * [List organization memberships for the authenticated user](https://docs.github.com/en/rest/orgs/members#list-organization-memberships-for-the-authenticated-user)
    * [Get an organization membership for the authenticated user](https://docs.github.com/en/rest/orgs/members#get-an-organization-membership-for-the-authenticated-user)
    * [Update an organization membership for the authenticated user](https://docs.github.com/en/rest/orgs/members#update-an-organization-membership-for-the-authenticated-user)
  * [REST API endpoints for network configurations](https://docs.github.com/en/rest/orgs/network-configurations)
    * [List hosted compute network configurations for an organization](https://docs.github.com/en/rest/orgs/network-configurations#list-hosted-compute-network-configurations-for-an-organization)
    * [Create a hosted compute network configuration for an organization](https://docs.github.com/en/rest/orgs/network-configurations#create-a-hosted-compute-network-configuration-for-an-organization)
    * [Get a hosted compute network configuration for an organization](https://docs.github.com/en/rest/orgs/network-configurations#get-a-hosted-compute-network-configuration-for-an-organization)
    * [Update a hosted compute network configuration for an organization](https://docs.github.com/en/rest/orgs/network-configurations#update-a-hosted-compute-network-configuration-for-an-organization)
    * [Delete a hosted compute network configuration from an organization](https://docs.github.com/en/rest/orgs/network-configurations#delete-a-hosted-compute-network-configuration-from-an-organization)
    * [Get a hosted compute network settings resource for an organization](https://docs.github.com/en/rest/orgs/network-configurations#get-a-hosted-compute-network-settings-resource-for-an-organization)
  * [REST API endpoints for organization roles](https://docs.github.com/en/rest/orgs/organization-roles)
    * [Get all organization roles for an organization](https://docs.github.com/en/rest/orgs/organization-roles#get-all-organization-roles-for-an-organization)
    * [Remove all organization roles for a team](https://docs.github.com/en/rest/orgs/organization-roles#remove-all-organization-roles-for-a-team)
    * [Assign an organization role to a team](https://docs.github.com/en/rest/orgs/organization-roles#assign-an-organization-role-to-a-team)
    * [Remove an organization role from a team](https://docs.github.com/en/rest/orgs/organization-roles#remove-an-organization-role-from-a-team)
    * [Remove all organization roles for a user](https://docs.github.com/en/rest/orgs/organization-roles#remove-all-organization-roles-for-a-user)
    * [Assign an organization role to a user](https://docs.github.com/en/rest/orgs/organization-roles#assign-an-organization-role-to-a-user)
    * [Remove an organization role from a user](https://docs.github.com/en/rest/orgs/organization-roles#remove-an-organization-role-from-a-user)
    * [Get an organization role](https://docs.github.com/en/rest/orgs/organization-roles#get-an-organization-role)
    * [List teams that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles#list-teams-that-are-assigned-to-an-organization-role)
    * [List users that are assigned to an organization role](https://docs.github.com/en/rest/orgs/organization-roles#list-users-that-are-assigned-to-an-organization-role)
  * [REST API endpoints for outside collaborators](https://docs.github.com/en/rest/orgs/outside-collaborators)
    * [List outside collaborators for an organization](https://docs.github.com/en/rest/orgs/outside-collaborators#list-outside-collaborators-for-an-organization)
    * [Convert an organization member to outside collaborator](https://docs.github.com/en/rest/orgs/outside-collaborators#convert-an-organization-member-to-outside-collaborator)
    * [Remove outside collaborator from an organization](https://docs.github.com/en/rest/orgs/outside-collaborators#remove-outside-collaborator-from-an-organization)
  * [REST API endpoints for personal access tokens](https://docs.github.com/en/rest/orgs/personal-access-tokens)
    * [List requests to access organization resources with fine-grained personal access tokens](https://docs.github.com/en/rest/orgs/personal-access-tokens#list-requests-to-access-organization-resources-with-fine-grained-personal-access-tokens)
    * [Review requests to access organization resources with fine-grained personal access tokens](https://docs.github.com/en/rest/orgs/personal-access-tokens#review-requests-to-access-organization-resources-with-fine-grained-personal-access-tokens)
    * [Review a request to access organization resources with a fine-grained personal access token](https://docs.github.com/en/rest/orgs/personal-access-tokens#review-a-request-to-access-organization-resources-with-a-fine-grained-personal-access-token)
    * [List repositories requested to be accessed by a fine-grained personal access token](https://docs.github.com/en/rest/orgs/personal-access-tokens#list-repositories-requested-to-be-accessed-by-a-fine-grained-personal-access-token)
    * [List fine-grained personal access tokens with access to organization resources](https://docs.github.com/en/rest/orgs/personal-access-tokens#list-fine-grained-personal-access-tokens-with-access-to-organization-resources)
    * [Update the access to organization resources via fine-grained personal access tokens](https://docs.github.com/en/rest/orgs/personal-access-tokens#update-the-access-to-organization-resources-via-fine-grained-personal-access-tokens)
    * [Update the access a fine-grained personal access token has to organization resources](https://docs.github.com/en/rest/orgs/personal-access-tokens#update-the-access-a-fine-grained-personal-access-token-has-to-organization-resources)
    * [List repositories a fine-grained personal access token has access to](https://docs.github.com/en/rest/orgs/personal-access-tokens#list-repositories-a-fine-grained-personal-access-token-has-access-to)
  * [REST API endpoints for rule suites](https://docs.github.com/en/rest/orgs/rule-suites)
    * [List organization rule suites](https://docs.github.com/en/rest/orgs/rule-suites#list-organization-rule-suites)
    * [Get an organization rule suite](https://docs.github.com/en/rest/orgs/rule-suites#get-an-organization-rule-suite)
  * [REST API endpoints for rules](https://docs.github.com/en/rest/orgs/rules)
    * [Get all organization repository rulesets](https://docs.github.com/en/rest/orgs/rules#get-all-organization-repository-rulesets)
    * [Create an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules#create-an-organization-repository-ruleset)
    * [Get an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules#get-an-organization-repository-ruleset)
    * [Update an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules#update-an-organization-repository-ruleset)
    * [Delete an organization repository ruleset](https://docs.github.com/en/rest/orgs/rules#delete-an-organization-repository-ruleset)
    * [Get organization ruleset history](https://docs.github.com/en/rest/orgs/rules#get-organization-ruleset-history)
    * [Get organization ruleset version](https://docs.github.com/en/rest/orgs/rules#get-organization-ruleset-version)
  * [REST API endpoints for security managers](https://docs.github.com/en/rest/orgs/security-managers)
    * [List security manager teams](https://docs.github.com/en/rest/orgs/security-managers#list-security-manager-teams)
    * [Add a security manager team](https://docs.github.com/en/rest/orgs/security-managers#add-a-security-manager-team)
    * [Remove a security manager team](https://docs.github.com/en/rest/orgs/security-managers#remove-a-security-manager-team)
  * [REST API endpoints for organization webhooks](https://docs.github.com/en/rest/orgs/webhooks)
    * [List organization webhooks](https://docs.github.com/en/rest/orgs/webhooks#list-organization-webhooks)
    * [Create an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#create-an-organization-webhook)
    * [Get an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#get-an-organization-webhook)
    * [Update an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#update-an-organization-webhook)
    * [Delete an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#delete-an-organization-webhook)
    * [Get a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks#get-a-webhook-configuration-for-an-organization)
    * [Update a webhook configuration for an organization](https://docs.github.com/en/rest/orgs/webhooks#update-a-webhook-configuration-for-an-organization)
    * [List deliveries for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#list-deliveries-for-an-organization-webhook)
    * [Get a webhook delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#get-a-webhook-delivery-for-an-organization-webhook)
    * [Redeliver a delivery for an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#redeliver-a-delivery-for-an-organization-webhook)
    * [Ping an organization webhook](https://docs.github.com/en/rest/orgs/webhooks#ping-an-organization-webhook)


## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/orgs/index.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for organizations - GitHub Docs
