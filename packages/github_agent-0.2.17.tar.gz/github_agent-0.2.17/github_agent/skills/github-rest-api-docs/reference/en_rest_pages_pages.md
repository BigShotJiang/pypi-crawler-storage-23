[Skip to main content](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#main-content)
[GitHub Docs](https://docs.github.com/en)
Version: Free, Pro, & Team
Search or ask Copilot
Search or askCopilot
Select language: current language is English
[Sign up](https://github.com/signup?ref_cta=Sign+up&ref_loc=docs+header&ref_page=docs)
Search or ask Copilot
Search or askCopilot
Open menu
Open Sidebar
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Pages](https://docs.github.com/en/rest/pages "Pages")/
  * [Pages](https://docs.github.com/en/rest/pages/pages "Pages")


[](https://docs.github.com/en)
## [REST API](https://docs.github.com/en/rest)
API Version: 2022-11-28 (latest)
  * [Quickstart](https://docs.github.com/en/rest/quickstart)
  * About the REST API
    * [About the REST API](https://docs.github.com/en/rest/about-the-rest-api/about-the-rest-api)
    * [Comparing GitHub's APIs](https://docs.github.com/en/rest/about-the-rest-api/comparing-githubs-rest-api-and-graphql-api)
    * [API Versions](https://docs.github.com/en/rest/about-the-rest-api/api-versions)
    * [Breaking changes](https://docs.github.com/en/rest/about-the-rest-api/breaking-changes)
    * [OpenAPI description](https://docs.github.com/en/rest/about-the-rest-api/about-the-openapi-description-for-the-rest-api)
  * Using the REST API
    * [Getting started](https://docs.github.com/en/rest/using-the-rest-api/getting-started-with-the-rest-api)
    * [Rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api)
    * [Pagination](https://docs.github.com/en/rest/using-the-rest-api/using-pagination-in-the-rest-api)
    * [Libraries](https://docs.github.com/en/rest/using-the-rest-api/libraries-for-the-rest-api)
    * [Best practices](https://docs.github.com/en/rest/using-the-rest-api/best-practices-for-using-the-rest-api)
    * [Troubleshooting](https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api)
    * [Timezones](https://docs.github.com/en/rest/using-the-rest-api/timezones-and-the-rest-api)
    * [CORS and JSONP](https://docs.github.com/en/rest/using-the-rest-api/using-cors-and-jsonp-to-make-cross-origin-requests)
    * [Issue event types](https://docs.github.com/en/rest/using-the-rest-api/issue-event-types)
    * [GitHub event types](https://docs.github.com/en/rest/using-the-rest-api/github-event-types)
  * Authentication
    * [Authenticating](https://docs.github.com/en/rest/authentication/authenticating-to-the-rest-api)
    * [Keeping API credentials secure](https://docs.github.com/en/rest/authentication/keeping-your-api-credentials-secure)
    * [Endpoints for GitHub App installation tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-installation-access-tokens)
    * [Endpoints for GitHub App user tokens](https://docs.github.com/en/rest/authentication/endpoints-available-for-github-app-user-access-tokens)
    * [Endpoints for fine-grained PATs](https://docs.github.com/en/rest/authentication/endpoints-available-for-fine-grained-personal-access-tokens)
    * [Permissions for GitHub Apps](https://docs.github.com/en/rest/authentication/permissions-required-for-github-apps)
    * [Permissions for fine-grained PATs](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
  * Guides
    * [Script with JavaScript](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-javascript)
    * [Script with Ruby](https://docs.github.com/en/rest/guides/scripting-with-the-rest-api-and-ruby)
    * [Discover resources for a user](https://docs.github.com/en/rest/guides/discovering-resources-for-a-user)
    * [Delivering deployments](https://docs.github.com/en/rest/guides/delivering-deployments)
    * [Rendering data as graphs](https://docs.github.com/en/rest/guides/rendering-data-as-graphs)
    * [Working with comments](https://docs.github.com/en/rest/guides/working-with-comments)
    * [Building a CI server](https://docs.github.com/en/rest/guides/building-a-ci-server)
    * [Get started - Git database](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database)
    * [Get started - Checks](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-checks)
    * [Encrypt secrets](https://docs.github.com/en/rest/guides/encrypting-secrets-for-the-rest-api)


* * *
  * Actions
    * Artifacts
    * Cache
    * GitHub-hosted runners
    * OIDC
    * Permissions
    * Secrets
    * Self-hosted runner groups
    * Self-hosted runners
    * Variables
    * Workflow jobs
    * Workflow runs
    * Workflows
  * Activity
    * Events
    * Feeds
    * Notifications
    * Starring
    * Watching
  * Apps
    * GitHub Apps
    * Installations
    * Marketplace
    * OAuth authorizations
    * Webhooks
  * Billing
    * Budgets
    * Billing usage
  * Branches
    * Branches
    * Protected branches
  * Campaigns
    * Security campaigns
  * Checks
    * Check runs
    * Check suites
  * Classroom
    * Classroom
  * Code scanning
    * Code scanning
  * Code security settings
    * Configurations
  * Codes of conduct
    * Codes of conduct
  * Codespaces
    * Codespaces
    * Organizations
    * Organization secrets
    * Machines
    * Repository secrets
    * User secrets
  * Collaborators
    * Collaborators
    * Invitations
  * Commits
    * Commits
    * Commit comments
    * Commit statuses
  * Copilot
    * Copilot metrics
    * Copilot user management
  * Credentials
    * Revocation
  * Dependabot
    * Alerts
    * Repository access
    * Secrets
  * Dependency graph
    * Dependency review
    * Dependency submission
    * Software bill of materials (SBOM)
  * Deploy keys
    * Deploy keys
  * Deployments
    * Deployment branch policies
    * Deployments
    * Environments
    * Protection rules
    * Deployment statuses
  * Emojis
    * Emojis
  * Enterprise teams
    * Enterprise team members
    * Enterprise team organizations
    * Enterprise teams
  * Gists
    * Gists
    * Comments
  * Git database
    * Blobs
    * Commits
    * References
    * Tags
    * Trees
  * Gitignore
    * Gitignore
  * Interactions
    * Organization
    * Repository
    * User
  * Issues
    * Assignees
    * Comments
    * Events
    * Issues
    * Issue dependencies
    * Labels
    * Milestones
    * Sub-issues
    * Timeline
  * Licenses
    * Licenses
  * Markdown
    * Markdown
  * Meta
    * Meta
  * Metrics
    * Community
    * Statistics
    * Traffic
  * Migrations
    * Organizations
    * Source endpoints
    * Users
  * Models
    * Catalog
    * Embeddings
    * Inference
  * Organizations
    * API Insights
    * Artifact metadata
    * Artifact attestations
    * Blocking users
    * Custom properties
    * Issue types
    * Members
    * Network configurations
    * Organization roles
    * Organizations
    * Outside collaborators
    * Personal access tokens
    * Rule suites
    * Rules
    * Security managers
    * Webhooks
  * Packages
    * Packages
  * Pages
    * Pages
      * [Get a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site)
      * [Create a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site)
      * [Update information about a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site)
      * [Delete a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site)
      * [List GitHub Pages builds](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds)
      * [Request a GitHub Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build)
      * [Get latest Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build)
      * [Get GitHub Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build)
      * [Create a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment)
      * [Get the status of a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment)
      * [Cancel a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment)
      * [Get a DNS health check for GitHub Pages](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages)
  * Private registries
    * Organization configurations
  * Projects
    * Draft Project items
    * Project fields
    * Project items
    * Projects
    * Project views
  * Pull requests
    * Pull requests
    * Review comments
    * Review requests
    * Reviews
  * Rate limit
    * Rate limit
  * Reactions
    * Reactions
  * Releases
    * Releases
    * Release assets
  * Repositories
    * Attestations
    * Autolinks
    * Contents
    * Custom properties
    * Forks
    * Repositories
    * Rule suites
    * Rules
    * Webhooks
  * Search
    * Search
  * Secret scanning
    * Push protection
    * Secret scanning
  * Security advisories
    * Global security advisories
    * Repository security advisories
  * Teams
    * Members
    * Teams
  * Users
    * Attestations
    * Blocking users
    * Emails
    * Followers
    * GPG keys
    * Git SSH keys
    * Social accounts
    * SSH signing keys
    * Users


The REST API is now versioned. For more information, see "[About API versioning](https://docs.github.com/rest/overview/api-versions)."
  * [REST API](https://docs.github.com/en/rest "REST API")/
  * [Pages](https://docs.github.com/en/rest/pages "Pages")/
  * [Pages](https://docs.github.com/en/rest/pages/pages "Pages")


# REST API endpoints for GitHub Pages
Use the REST API to interact with GitHub Pages sites and builds.
## [Get a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site)
Gets information about a GitHub Pages site.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-github-pages-site--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/github/developer.github.com/pages",   "status": "built",   "cname": "developer.github.com",   "custom_404": false,   "html_url": "https://developer.github.com",   "source": {     "branch": "master",     "path": "/"   },   "public": true,   "pending_domain_unverified_at": "2024-04-30T19:33:31Z",   "protected_domain_state": "verified",   "https_certificate": {     "state": "approved",     "description": "Certificate is approved",     "domains": [       "developer.github.com"     ],     "expires_at": "2021-05-22"   },   "https_enforced": true }`
## [Create a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site)
Configures a GitHub Pages site. For more information, see "[About GitHub Pages](https://docs.github.com/github/working-with-github-pages/about-github-pages)."
The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Create a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write) and "Administration" repository permissions (write)


### [Parameters for "Create a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`build_type` string The process in which the Page will be built. Possible values are `"legacy"` and `"workflow"`. Can be one of: `legacy`, `workflow`
`source` object The source branch and directory used to publish your Pages site.
Properties of `source` | Name, Type, Description
---
`branch` string Required The repository branch used to publish your site's source files.
`path` string The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. Default: `/` Default: `/` Can be one of: `/`, `/docs`
### [HTTP response status codes for "Create a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site--status-codes)
Status code | Description
---|---
`201` | Created
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-site--code-samples)
#### Request example
post/repos/{owner}/{repo}/pages
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages \   -d '{"source":{"branch":"main","path":"/docs"}}'`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "url": "https://api.github.com/repos/github/developer.github.com/pages",   "status": "built",   "cname": "developer.github.com",   "custom_404": false,   "html_url": "https://developer.github.com",   "source": {     "branch": "master",     "path": "/"   },   "public": true,   "pending_domain_unverified_at": "2024-04-30T19:33:31Z",   "protected_domain_state": "verified",   "https_certificate": {     "state": "approved",     "description": "Certificate is approved",     "domains": [       "developer.github.com"     ],     "expires_at": "2021-05-22"   },   "https_enforced": true }`
## [Update information about a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site)
Updates information for a GitHub Pages site. For more information, see "[About GitHub Pages](https://docs.github.com/github/working-with-github-pages/about-github-pages).
The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Update information about a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write) and "Administration" repository permissions (write)


### [Parameters for "Update information about a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`cname` string or null Specify a custom domain for the repository. Sending a `null` value will remove the custom domain. For more about custom domains, see "[Using a custom domain with GitHub Pages](https://docs.github.com/pages/configuring-a-custom-domain-for-your-github-pages-site)."
`https_enforced` boolean Specify whether HTTPS should be enforced for the repository.
`build_type` string The process by which the GitHub Pages site will be built. `workflow` means that the site is built by a custom GitHub Actions workflow. `legacy` means that the site is built by GitHub when changes are pushed to a specific branch. Can be one of: `legacy`, `workflow`
`source` object Update the source for the repository. Must include the branch name and path.
Properties of `source` | Name, Type, Description
---
`branch` string Required The repository branch used to publish your site's source files.
`path` string Required The repository directory that includes the source files for the Pages site. Allowed paths are `/` or `/docs`. Can be one of: `/`, `/docs`
### [HTTP response status codes for "Update information about a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site--status-codes)
Status code | Description
---|---
`204` | No Content
`400` | Bad Request
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Update information about a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#update-information-about-a-github-pages-site--code-samples)
#### Request example
put/repos/{owner}/{repo}/pages
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X PUT \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages \   -d '{"cname":"octocatblog.com","source":{"branch":"main","path":"/"}}'`
Response
`Status: 204`
## [Delete a GitHub Pages site](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site)
Deletes a GitHub Pages site. For more information, see "[About GitHub Pages](https://docs.github.com/github/working-with-github-pages/about-github-pages).
The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Delete a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write) and "Administration" repository permissions (write)


### [Parameters for "Delete a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Delete a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site--status-codes)
Status code | Description
---|---
`204` | No Content
`404` | Resource not found
`409` | Conflict
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Delete a GitHub Pages site"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#delete-a-github-pages-site--code-samples)
#### Request example
delete/repos/{owner}/{repo}/pages
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X DELETE \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages`
Response
`Status: 204`
## [List GitHub Pages builds](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds)
Lists builts of a GitHub Pages site.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "List GitHub Pages builds"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "List GitHub Pages builds"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Query parameters Name, Type, Description
---
`per_page` integer The number of results per page (max 100). For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `30`
`page` integer The page number of the results to fetch. For more information, see "[Using pagination in the REST API](https://docs.github.com/rest/using-the-rest-api/using-pagination-in-the-rest-api)." Default: `1`
### [HTTP response status codes for "List GitHub Pages builds"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "List GitHub Pages builds"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#list-github-pages-builds--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages/builds
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/builds`
Response
  * Example response
  * Response schema


`Status: 200`
`[   {     "url": "https://api.github.com/repos/github/developer.github.com/pages/builds/5472601",     "status": "built",     "error": {       "message": null     },     "pusher": {       "login": "octocat",       "id": 1,       "node_id": "MDQ6VXNlcjE=",       "avatar_url": "https://github.com/images/error/octocat_happy.gif",       "gravatar_id": "",       "url": "https://api.github.com/users/octocat",       "html_url": "https://github.com/octocat",       "followers_url": "https://api.github.com/users/octocat/followers",       "following_url": "https://api.github.com/users/octocat/following{/other_user}",       "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",       "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",       "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",       "organizations_url": "https://api.github.com/users/octocat/orgs",       "repos_url": "https://api.github.com/users/octocat/repos",       "events_url": "https://api.github.com/users/octocat/events{/privacy}",       "received_events_url": "https://api.github.com/users/octocat/received_events",       "type": "User",       "site_admin": false     },     "commit": "351391cdcb88ffae71ec3028c91f375a8036a26b",     "duration": 2104,     "created_at": "2014-02-10T19:00:49Z",     "updated_at": "2014-02-10T19:00:51Z"   } ]`
## [Request a GitHub Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build)
You can request that your site be built from the latest revision on the default branch. This has the same effect as pushing a commit to your default branch, but does not require an additional commit. Manually triggering page builds can be helpful when diagnosing build warnings and failures.
Build requests are limited to one concurrent build per repository and one concurrent build per requester. If you request a build while another is still in progress, the second request will be queued until the first completes.
### [Fine-grained access tokens for "Request a GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write)


### [Parameters for "Request a GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Request a GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build--status-codes)
Status code | Description
---|---
`201` | Created
### [Code samples for "Request a GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#request-a-github-pages-build--code-samples)
#### Request example
post/repos/{owner}/{repo}/pages/builds
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/builds`
Response
  * Example response
  * Response schema


`Status: 201`
`{   "url": "https://api.github.com/repos/github/developer.github.com/pages/builds/latest",   "status": "queued" }`
## [Get latest Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build)
Gets information about the single most recent build of a GitHub Pages site.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get latest Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get latest Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get latest Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get latest Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-latest-pages-build--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages/builds/latest
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/builds/latest`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/github/developer.github.com/pages/builds/5472601",   "status": "built",   "error": {     "message": null   },   "pusher": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "commit": "351391cdcb88ffae71ec3028c91f375a8036a26b",   "duration": 2104,   "created_at": "2014-02-10T19:00:49Z",   "updated_at": "2014-02-10T19:00:51Z" }`
## [Get GitHub Pages build](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build)
Gets information about a GitHub Pages build.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`build_id` integer Required
### [HTTP response status codes for "Get GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build--status-codes)
Status code | Description
---|---
`200` | OK
### [Code samples for "Get GitHub Pages build"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-github-pages-build--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages/builds/{build_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/builds/BUILD_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "url": "https://api.github.com/repos/github/developer.github.com/pages/builds/5472601",   "status": "built",   "error": {     "message": null   },   "pusher": {     "login": "octocat",     "id": 1,     "node_id": "MDQ6VXNlcjE=",     "avatar_url": "https://github.com/images/error/octocat_happy.gif",     "gravatar_id": "",     "url": "https://api.github.com/users/octocat",     "html_url": "https://github.com/octocat",     "followers_url": "https://api.github.com/users/octocat/followers",     "following_url": "https://api.github.com/users/octocat/following{/other_user}",     "gists_url": "https://api.github.com/users/octocat/gists{/gist_id}",     "starred_url": "https://api.github.com/users/octocat/starred{/owner}{/repo}",     "subscriptions_url": "https://api.github.com/users/octocat/subscriptions",     "organizations_url": "https://api.github.com/users/octocat/orgs",     "repos_url": "https://api.github.com/users/octocat/repos",     "events_url": "https://api.github.com/users/octocat/events{/privacy}",     "received_events_url": "https://api.github.com/users/octocat/received_events",     "type": "User",     "site_admin": false   },   "commit": "351391cdcb88ffae71ec3028c91f375a8036a26b",   "duration": 2104,   "created_at": "2014-02-10T19:00:49Z",   "updated_at": "2014-02-10T19:00:51Z" }`
## [Create a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment)
Create a GitHub Pages deployment for a repository.
The authenticated user must have write permission to the repository.
### [Fine-grained access tokens for "Create a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write)


### [Parameters for "Create a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
Body parameters Name, Type, Description
---
`artifact_id` number The ID of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required.
`artifact_url` string The URL of an artifact that contains the .zip or .tar of static assets to deploy. The artifact belongs to the repository. Either `artifact_id` or `artifact_url` are required.
`environment` string The target environment for this GitHub Pages deployment. Default: `github-pages`
`pages_build_version` string Required A unique string that represents the version of the build for this deployment. Default: `GITHUB_SHA`
`oidc_token` string Required The OIDC token issued by GitHub Actions certifying the origin of the deployment.
### [HTTP response status codes for "Create a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment--status-codes)
Status code | Description
---|---
`200` | OK
`400` | Bad Request
`404` | Resource not found
`422` | Validation failed, or the endpoint has been spammed.
### [Code samples for "Create a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#create-a-github-pages-deployment--code-samples)
#### Request example
post/repos/{owner}/{repo}/pages/deployments
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/deployments \   -d '{"artifact_url":"https://downloadcontent/","environment":"github-pages","pages_build_version":"4fd754f7e594640989b406850d0bc8f06a121251","oidc_token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlV2R1h4SUhlY0JFc1JCdEttemUxUEhfUERiVSIsImtpZCI6IjUyRjE5N0M0ODFERTcwMTEyQzQ0MUI0QTlCMzdCNTNDN0ZDRjBEQjUifQ.eyJqdGkiOiJhMWIwNGNjNy0zNzZiLTQ1N2QtOTMzNS05NTY5YmVjZDExYTIiLCJzdWIiOiJyZXBvOnBhcGVyLXNwYS9taW55aTplbnZpcm9ubWVudDpQcm9kdWN0aW9uIiwiYXVkIjoiaHR0cHM6Ly9naXRodWIuY29tL3BhcGVyLXNwYSIsInJlZiI6InJlZnMvaGVhZHMvbWFpbiIsInNoYSI6ImEyODU1MWJmODdiZDk3NTFiMzdiMmM0YjM3M2MxZjU3NjFmYWM2MjYiLCJyZXBvc2l0b3J5IjoicGFwZXItc3BhL21pbnlpIiwicmVwb3NpdG9yeV9vd25lciI6InBhcGVyLXNwYSIsInJ1bl9pZCI6IjE1NDY0NTkzNjQiLCJydW5fbnVtYmVyIjoiMzQiLCJydW5fYXR0ZW1wdCI6IjYiLCJhY3RvciI6IllpTXlzdHkiLCJ3b3JrZmxvdyI6IkNJIiwiaGVhZF9yZWYiOiIiLCJiYXNlX3JlZiI6IiIsImV2ZW50X25hbWUiOiJwdXNoIiwicmVmX3R5cGUiOiJicmFuY2giLCJlbnZpcm9ubWVudCI6IlByb2R1Y3Rpb24iLCJqb2Jfd29ya2Zsb3dfcmVmIjoicGFwZXItc3BhL21pbnlpLy5naXRodWIvd29ya2Zsb3dzL2JsYW5rLnltbEByZWZzL2hlYWRzL21haW4iLCJpc3MiOiJodHRwczovL3Rva2VuLmFjdGlvbnMuZ2l0aHVidXNlcmNvbnRlbnQuY29tIiwibmJmIjoxNjM5MDAwODU2LCJleHAiOjE2MzkwMDE3NTYsImlhdCI6MTYzOTAwMTQ1Nn0.VP8WictbQECKozE2SgvKb2FqJ9hisWsoMkYRTqfBrQfZTCXi5IcFEdgDMB2X7a99C2DeUuTvHh9RMKXLL2a0zg3-Sd7YrO7a2ll2kNlnvyIypcN6AeIc7BxHsTTnZN9Ud_xmEsTrSRGOEKmzCFkULQ6N4zlVD0sidypmXlMemmWEcv_ZHqhioEI_VMp5vwXQurketWH7qX4oDgG4okyYtPrv5RQHbfQcVo9izaPJ_jnsDd0CBA0QOx9InjPidtIkMYQLyUgJy33HLJy86EFNUnAf8UhBQuQi5mAsEpEzBBuKpG3PDiPtYCHOk64JZkZGd5mR888a5sbHRiaF8hm8YA"}'`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "id": "4fd754f7e594640989b406850d0bc8f06a121251",   "status_url": "https://api.github.com/repos/github/developer.github.com/pages/deployments/4fd754f7e594640989b406850d0bc8f06a121251/status",   "page_url": "developer.github.com" }`
## [Get the status of a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment)
Gets the current status of a GitHub Pages deployment.
The authenticated user must have read permission for the GitHub Pages site.
### [Fine-grained access tokens for "Get the status of a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (read)


This endpoint can be used without authentication or the aforementioned permissions if only public resources are requested.
### [Parameters for "Get the status of a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`pages_deployment_id` Required The ID of the Pages deployment. You can also give the commit SHA of the deployment.
### [HTTP response status codes for "Get the status of a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment--status-codes)
Status code | Description
---|---
`200` | OK
`404` | Resource not found
### [Code samples for "Get the status of a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-the-status-of-a-github-pages-deployment--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages/deployments/{pages_deployment_id}
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/deployments/PAGES_DEPLOYMENT_ID`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "status": "succeed" }`
## [Cancel a GitHub Pages deployment](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment)
Cancels a GitHub Pages deployment.
The authenticated user must have write permissions for the GitHub Pages site.
### [Fine-grained access tokens for "Cancel a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Pages" repository permissions (write)


### [Parameters for "Cancel a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
`pages_deployment_id` Required The ID of the Pages deployment. You can also give the commit SHA of the deployment.
### [HTTP response status codes for "Cancel a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment--status-codes)
Status code | Description
---|---
`204` | A header with no content is returned.
`404` | Resource not found
### [Code samples for "Cancel a GitHub Pages deployment"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#cancel-a-github-pages-deployment--code-samples)
#### Request example
post/repos/{owner}/{repo}/pages/deployments/{pages_deployment_id}/cancel
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -X POST \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/deployments/PAGES_DEPLOYMENT_ID/cancel`
A header with no content is returned.
`Status: 204`
## [Get a DNS health check for GitHub Pages](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages)
Gets a health check of the DNS settings for the `CNAME` record configured for a repository's GitHub Pages.
The first request to this endpoint returns a `202 Accepted` status and starts an asynchronous background task to get the results for the domain. After the background task completes, subsequent requests to this endpoint return a `200 OK` status with the health check results in the response.
The authenticated user must be a repository administrator, maintainer, or have the 'manage GitHub Pages settings' permission to use this endpoint.
OAuth app tokens and personal access tokens (classic) need the `repo` scope to use this endpoint.
### [Fine-grained access tokens for "Get a DNS health check for GitHub Pages"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages--fine-grained-access-tokens)
This endpoint works with the following fine-grained token types:
  * [GitHub App user access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-a-user-access-token-for-a-github-app)
  * [GitHub App installation access tokens](https://docs.github.com/en/apps/creating-github-apps/authenticating-with-a-github-app/generating-an-installation-access-token-for-a-github-app)
  * [Fine-grained personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)


The fine-grained token must have the following permission set:
  * "Administration" repository permissions (write) and "Pages" repository permissions (write)


### [Parameters for "Get a DNS health check for GitHub Pages"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages--parameters)
Headers Name, Type, Description
---
`accept` string Setting to `application/vnd.github+json` is recommended.
Path parameters Name, Type, Description
---
`owner` string Required The account owner of the repository. The name is not case sensitive.
`repo` string Required The name of the repository without the `.git` extension. The name is not case sensitive.
### [HTTP response status codes for "Get a DNS health check for GitHub Pages"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages--status-codes)
Status code | Description
---|---
`200` | OK
`202` | Empty response
`400` | Custom domains are not available for GitHub Pages
`404` | Resource not found
`422` | There isn't a CNAME for this page
### [Code samples for "Get a DNS health check for GitHub Pages"](https://docs.github.com/en/rest/pages/pages?apiVersion=2022-11-28#get-a-dns-health-check-for-github-pages--code-samples)
#### Request example
get/repos/{owner}/{repo}/pages/health
  * cURL
  * JavaScript
  * GitHub CLI


Copy to clipboard curl request example
`curl -L \   -H "Accept: application/vnd.github+json" \   -H "Authorization: Bearer <YOUR-TOKEN>" \   -H "X-GitHub-Api-Version: 2022-11-28" \   https://api.github.com/repos/OWNER/REPO/pages/health`
Response
  * Example response
  * Response schema


`Status: 200`
`{   "domain": {     "host": "example.com",     "uri": "http://example.com/",     "nameservers": "default",     "dns_resolves": true,     "is_proxied": false,     "is_cloudflare_ip": false,     "is_fastly_ip": false,     "is_old_ip_address": false,     "is_a_record": true,     "has_cname_record": false,     "has_mx_records_present": false,     "is_valid_domain": true,     "is_apex_domain": true,     "should_be_a_record": true,     "is_cname_to_github_user_domain": false,     "is_cname_to_pages_dot_github_dot_com": false,     "is_cname_to_fastly": false,     "is_pointed_to_github_pages_ip": true,     "is_non_github_pages_ip_present": false,     "is_pages_domain": false,     "is_served_by_pages": true,     "is_valid": true,     "reason": null,     "responds_to_https": true,     "enforces_https": true,     "https_error": null,     "is_https_eligible": true,     "caa_error": null   },   "alt_domain": {     "host": "www.example.com",     "uri": "http://www.example.com/",     "nameservers": "default",     "dns_resolves": true,     "is_proxied": false,     "is_cloudflare_ip": false,     "is_fastly_ip": false,     "is_old_ip_address": false,     "is_a_record": true,     "has_cname_record": false,     "has_mx_records_present": false,     "is_valid_domain": true,     "is_apex_domain": true,     "should_be_a_record": true,     "is_cname_to_github_user_domain": false,     "is_cname_to_pages_dot_github_dot_com": false,     "is_cname_to_fastly": false,     "is_pointed_to_github_pages_ip": true,     "is_non_github_pages_ip_present": false,     "is_pages_domain": false,     "is_served_by_pages": true,     "is_valid": true,     "reason": null,     "responds_to_https": true,     "enforces_https": true,     "https_error": null,     "is_https_eligible": true,     "caa_error": null   } }`
## Help and support
### Did you find what you needed?
YesNo
[Privacy policy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
### Help us make these docs great!
All GitHub docs are open source. See something that's wrong or unclear? Submit a pull request.
[](https://github.com/github/docs/blob/main/content/rest/pages/pages.md)
[Learn how to contribute](https://docs.github.com/contributing)
### Still need help?
[](https://github.com/orgs/community/discussions)
[](https://support.github.com)
## Legal
  * © 2026 GitHub, Inc.
  * [Terms](https://docs.github.com/en/site-policy/github-terms/github-terms-of-service)
  * [Privacy](https://docs.github.com/en/site-policy/privacy-policies/github-privacy-statement)
  * [Status](https://www.githubstatus.com/)
  * [Pricing](https://github.com/pricing)
  * [Expert services](https://services.github.com)
  * [Blog](https://github.blog)


REST API endpoints for GitHub Pages - GitHub Docs
