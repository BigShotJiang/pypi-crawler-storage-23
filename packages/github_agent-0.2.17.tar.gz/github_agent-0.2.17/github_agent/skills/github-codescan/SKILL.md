---
name: github-codescan
description: "Manage code security tools and scans. Triggers: Code Security Agent."
tags: [codescan]
---

### Overview
This skill handles operations related to the Code Security Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Code Security Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
