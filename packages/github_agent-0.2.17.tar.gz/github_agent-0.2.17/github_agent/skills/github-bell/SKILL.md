---
name: github-bell
description: "Manage and check GitHub notifications. Triggers: Notifications Agent."
tags: [bell]
---

### Overview
This skill handles operations related to the Notifications Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Notifications Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
