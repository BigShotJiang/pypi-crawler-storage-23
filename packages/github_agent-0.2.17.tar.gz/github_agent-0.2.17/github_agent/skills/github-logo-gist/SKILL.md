---
name: github-logo-gist
description: "Manage GitHub Gists. Triggers: Gists Agent."
tags: [logo-gist]
---

### Overview
This skill handles operations related to the Gists Agent.

### Available Tools
Refer to the GitHub Agent documentation for available tools for this agent.
This skill is a placeholder for the specialized agent capabilities.

### Usage Instructions
1. This skill is used by the Gists Agent to perform specialized tasks.

### Error Handling
- Refer to standard GitHub API error handling.
