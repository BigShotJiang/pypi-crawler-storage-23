# Changelog

## 0.1.0 (2026-02-28)

- Initial release
- 10 MCP tools for Excel automation via xlwings COM
- Sessionless design -- no session ID management
- Supports DRM-protected files through live Excel process control
