"""MCP server for Excel automation via xlwings COM."""

__version__ = "0.2.0"
