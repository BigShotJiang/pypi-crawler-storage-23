from airtest_pro.utils.version import __version__
