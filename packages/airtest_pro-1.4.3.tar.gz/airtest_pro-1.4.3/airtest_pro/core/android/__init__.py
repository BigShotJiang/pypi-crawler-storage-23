"""
This package provide Android Device Class.
"""
from airtest_pro.core.android.android import Android
