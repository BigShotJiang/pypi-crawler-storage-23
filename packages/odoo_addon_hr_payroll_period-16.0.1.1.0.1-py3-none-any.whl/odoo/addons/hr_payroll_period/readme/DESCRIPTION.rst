Adds the concept of period in the human resources management.

The objective of the module is to create periods of time to
be used in the human resources management flows such as
specific payroll period of time or timesheet periods.

Regarding to payrolls, it adds the date of payment on the
payslip and payslip batch. This date is automatically filled
when selecting a period. It also adds a sequence on the payslip
batch name and the company on the payslip batch.
