from .ocr import CaptchaOCR


__all__ = ['CaptchaOCR']
