n = int(input())
if n**2 > 2**n:
    print("Yes")
else:
    print("No")
