S = input() + input()

if S == ".#.#" or S == "#.#.":
    print("No")
else:
    print("Yes")
