A = ["RGB", "GBR", "BRG"]

S = input()
T = input()
print("Yes" if (S in A) == (T in A) else "No")
