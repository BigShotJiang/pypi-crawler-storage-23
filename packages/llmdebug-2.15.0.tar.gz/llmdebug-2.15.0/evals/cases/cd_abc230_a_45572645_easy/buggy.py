N = int(input())

print(f"AGC{N + 1}" if N > 41 else f"AGC{N}")
