s = input()
if s[-2:] == "er":
    print("er")
elif s[-2:] == "ist":
    print("ist")
