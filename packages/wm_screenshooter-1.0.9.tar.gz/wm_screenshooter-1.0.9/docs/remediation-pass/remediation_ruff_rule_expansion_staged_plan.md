# Ruff Rule Expansion Plan (Staged)

## Purpose

Define a safe, staged expansion of Ruff lint coverage beyond the current baseline.

This plan is mandatory for any future Ruff hardening work in this repository.

## Current Baseline

Current enabled Ruff lint families in `pyproject.toml`:

- `E`, `F`, `B`, `I`, `N`, `UP`, `PL`, `RUF`

Current suppression posture:

- No `# noqa` in `src/`
- No Ruff per-file ignore exceptions in `pyproject.toml`

## Candidate Rule Families

### 1) `S` (security checks)

- **Why add:** catches risky code patterns early (`subprocess` usage, temp-file safety, weak crypto usage,
  insecure defaults).
- **Expected value:** high for a CLI tool handling filesystem/network/S3 workflows.
- **Potential impact:** low to medium; some findings may require explicit secure alternatives.

### 2) `ANN` (type annotation linting)

- **Why add:** improves API clarity and long-term refactor safety.
- **Expected value:** high for maintainability and tooling support.
- **Potential impact:** medium to high; likely many annotation additions in legacy/internal code.

### 3) `C90` (cyclomatic complexity)

- **Why add:** enforces maintainable complexity ceilings and prevents future branch-heavy regressions.
- **Expected value:** medium.
- **Potential impact:** medium; requires function decomposition in complex flows.

### 4) `SIM` (simplify)

- **Why add:** encourages simpler, easier-to-read Python idioms.
- **Expected value:** medium.
- **Potential impact:** low to medium; mostly small rewrites.

### 5) `ARG` (unused arguments)

- **Why add:** helps keep interfaces clean and intentional.
- **Expected value:** medium.
- **Potential impact:** low to medium; callback/protocol signatures may need explicit handling.

### 6) `D` (docstring style)

- **Why add:** standardizes documentation quality and consistency.
- **Expected value:** medium.
- **Potential impact:** medium to high if applied globally at once.

## Rule Families Deferred (For Now)

- `T20` (print checks): likely noisy in a terminal-first CLI/TUI app.
- `ERA` (commented-out code): lower priority hygiene rule.
- Any broad family not reviewed for false-positive rate in this codebase.

## Non-Negotiable Rollout Rules

1. Expand Ruff in stages only; no all-at-once rule enablement.
2. Do not introduce `# noqa` or per-file ignores to bypass rollout findings.
3. If a rule causes high-noise/low-value output, mark stage `blocked` and re-scope.
4. Each stage must capture before/after error counts and exact verification commands.
5. Manual behavior checks are required for modules touched by refactors.

## Required Stage/Pass Template

Each stage entry must include:

- **Goal**
- **In scope**
- **Out of scope**
- **Changes made** (file-by-file)
- **Verification run** (exact commands + result)
- **Manual behavior checks**
- **Outcome** (`done`, `blocked`, or `rolled back`)

Each pass within a stage must include:

- **Pass ID** (e.g., Stage 1 Pass A)
- **Ruff delta** (errors before -> errors after)
- **Suppression delta** (`# noqa` count and any ignore entries)

## Recommended Staged Rollout

### Stage 0 - Baseline Snapshot

- Capture baseline findings and lock current suppression posture.

Commands:

- `uv run ruff check src/`
- `rg "# noqa" src/`

### Stage 1 - Security First (`S`)

- Add `S` to `select`.
- Resolve findings in focused passes by module risk:
  - Pass A: subprocess and shell usage
  - Pass B: filesystem/temp-file handling
  - Pass C: network/credentials and crypto-adjacent usage

Completion evidence:

- `uv run ruff check src/` passes with `S` enabled
- no new suppressions

### Stage 2 - Type Annotation Coverage (`ANN`)

- Enable `ANN` in scoped passes:
  - Pass A: public interfaces and entry points
  - Pass B: core modules (`backup`, `screenshot`, `settings`)
  - Pass C: remaining internals

Completion evidence:

- `uv run ruff check src/` passes with `ANN` enabled
- no new suppressions

### Stage 3 - Complexity Guardrail (`C90`)

- Enable complexity checks with an agreed threshold.
- Refactor only functions above threshold; preserve behavior.

Completion evidence:

- complexity violations resolved
- manual parity checks completed for touched workflows

### Stage 4 - Readability Cleanup (`SIM`, `ARG`)

- Enable lower-risk readability rules in separate passes.
- Prefer small, behavior-preserving changes.

Completion evidence:

- no net increase in technical risk
- lint passes with newly enabled rules

### Stage 5 - Documentation Rules Pilot (`D`, optional)

- Pilot on a limited module set first (not repository-wide).
- Decide go/no-go based on signal-to-noise and maintenance burden.

Completion evidence:

- explicit decision recorded: adopt, narrow, or defer

### Stage 6 - Final Sweep and Lock-In

- Re-run full lint and suppression inventory.
- Record final enabled rule set and rationale.

Commands:

- `uv run ruff check src/`
- `rg "# noqa" src/`

## Progress Tracker

- Stage 0 - Baseline Snapshot: `not started`
- Stage 1 - Security First (`S`): `not started`
- Stage 2 - Type Annotation Coverage (`ANN`): `not started`
- Stage 3 - Complexity Guardrail (`C90`): `not started`
- Stage 4 - Readability Cleanup (`SIM`, `ARG`): `not started`
- Stage 5 - Documentation Rules Pilot (`D`, optional): `not started`
- Stage 6 - Final Sweep and Lock-In: `not started`
