# CHANGELOG

Below is a list of changes to the ScreenShooter application. Please refer to the associated [GitLab issue](https://gitlab.com/workmaster/screenshooter/issues) for more details on the changes.

For more information on future changes please refer to the [ROADMAP](ROADMAP.md).

## v1.0.9 (2026-02-20)

- #87 fix small text bugs in help manual and status bar duplication
- #86 fix ruff linting error suppression in backup and screenshot modules
- #84 add scripts directory for adhoc removal of partial backups from S3/R2.
- #84 add ability to resume backup uploading to S3/R2.
- #84 add ability to upload encrypted backup to S3/R2.
- #85 fix bug with version check causing upgrade check to display on every run.

## v1.0.8 (2026-02-19)

- #83 add ability to snippet capture using specific section of screen.
- #82 fix bug with client cli project active status was determined by the file system instead of the db.
- #82 fix bug with project unarchive function not updating the filesystem metadata file
- #81 fix bug with client cli back function which bought back to main menu instead of going back one step.
- #76 add new report generation flow for all sending active projects or all projects worked on in a single day.
- #76 added preview to notes input for email sending.

## v1.0.7 (2026-02-16)

- #80 make report client selection default to active clients and add toggle to show archived clients.
- #79 make codebase follow ruff linting best practices.
- #77 remove support for Python 3.9 ensure compatibility with Python 3.10+ by updating minimum version of Pydantic to 2.12.0
- #78 fix error in report generation flow pressing back at email prompt would cause the program to exit.

## v1.0.6 (2025-12-11)

- #70: Added settings.log and logic to ensure settings are saved correctly without issue
- #71: Moved database and logs to ~/.config/screenshooter instead of being in the screenshots directory.
- #70 added `screenshooter open` commands for logs and config directories.
- #65: Added pause functionality to db and added countdown confirmation before pausing. Also adjusted user-facing text.
- #65: Fixed bug where captions would cause session fail because of non-existent session.json key.
- #65: Fixed bug where manual mode would take screenshot in end if switched to timer mode.
- #72: Captions now appear below screenshots in reports.
- #73: Organised reports based on database data to show sessions in chronological order.
- #69: updated project, client and session meta files with new structure to accommodate archive functionality
- #75: Add ability to archive/rename projects from the client management menu.
- #74: Add to PyPi and updated licence info.

## v1.0.5 (2025-12-01)

- #60: Added MSS to enable cross-platform support (Windows and Linux work but are under beta testing).
- #61: Fix backup settings bug where changed settings were not being used in the backup process
- #61: Set default data source to database.
- #62: Fixed screenshot countdown setting not being used and added timer setting as the top / default option in the session start flow.
- #63: No longer show post-session flow if email not enabled
- #64: Updated/Refactored Upgrade Check to display release notes (now will show first 5 lines of the release notes).
- #66: Implement Client Archive Logic
- #67: Make it so that the clients and projects lookup via slug/directory instead of name.
- #68: Make log_file use client.json and new project.json to list clients and projects.

## v1.0.4 (2025-11-28)

- #59: Fixed 'l' not available in timed mode.
- #59: Remove duplicate messages in-session.
- #56: Fix email send bug when using BCC / CC recipient types.
- #58: Fix prompt response overlap issues (new line added for confirmation prompts).
- #57: Slugify client and project names to ensure they are safe for filesystem use.

## v1.0.3 (2025-11-24)

- #52: Added command 'r' (archive last action) and 'e' (list last 5 actions) to archive/unarchive actions from the database.
- #52: Added command 'l' to open the current session log in TextEdit.
- #53: Fixed Bug where single sessions would not generate a report.
- #54: Reworked Settings menu, added Database and Upgrade options.
- #46: Added Backup functionality to backup settings, database, and screenshots directory

## v1.0.2 (2025-11-21)

- #44: Added SQLite database integration with gradual plan to replace the legacy log and json file based system as the source of truth.
  - Added db management in CLI `screenshooter db ...` commands.
  - Added migration system to handle database schema changes (db migrate schema)
  - Added db status command to show basic stats.
  - Added db reset command to reset/delete the database.
  - Added db verify-screenshots command to verify the integrity of the screenshots in the database.
- #45: Added ability to archive projects (archive of clients, sessions and notes coming soon).
- #43: Began proper versioning of the ScreenShooter application.
- #43: Removal of excess ScreenShooter sub-module commands from the CLI to simplify the interface - now only `screenshooter` is available.
- #48: Add Ability to for clients and generate reports from the database if enabled.
- #49: Added pagination to all CLIs for project and client selection.
- #49: Added ability to view archived projects in the client CLI. (No action currently implemented when archived projects are selected).
- #50: Added upgrade check functionality to notify users of new versions of ScreenShooter.
  - Runs on startup (cached for 7 days) or manually with `screenshooter settings upgrade-check`
  - Includes skipping and pinning versions.
- #51: Added database file creation on startup if not present with included migration of existing data from log and json files to the database.

## v1.0.1 (2025-11-18)

- Final release of the legacy log and json file based system.

## v1.0.0

- Initial release of ScreenShooter written in Bash:
