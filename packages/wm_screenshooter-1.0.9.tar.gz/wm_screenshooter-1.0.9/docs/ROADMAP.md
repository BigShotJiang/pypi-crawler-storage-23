# ScreenShooter Project Roadmap

Below is a list of features and improvements that are planned for the ScreenShooter application. Please refer to the issues on the project's GitLab for details on current planned features and implementation progress.

## Current Features In Active Development

- Implementing testing framework and adding tests for the application.

## Planned Features in Future Releases

- Tutorial Documentation mode for creating step-by-step guides for clients.
- Add more Ruff linting rules per the [Ruff Rule Expansion Plan](remediation-pass/remediation_ruff_rule_expansion_staged_plan.md).

## Known Issues

Any known issues with the application will be listed here. If not critical the issue will have an associated release version number where it will be fixed.
