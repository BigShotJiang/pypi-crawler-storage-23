"""ScreenShooter Mac modules."""

# Export report components from reports package
from screenshooter.modules.reports import (
    ClientInfo,
    MultiSessionReport,
    ReportGenerator,
    SessionLog,
    generate_multi_session_pdf,
    generate_single_session_pdf,
    interactive_report_generation,
    send_email,
)
from screenshooter.modules.reports import (
    main as report_main,
)

# Export S3 storage components from s3 package
from screenshooter.modules.s3 import (
    S3Helper,
    generate_custom_link,
    get_s3_settings,
    is_s3_enabled,
)
from screenshooter.modules.s3 import (
    main as s3_main,
)

# Export settings models from settings package (avoid importing CLI)
from screenshooter.modules.settings import (
    AppSettings,
    SettingsManager,
)

# Export settings helper functions
from screenshooter.modules.settings.settings_helper import (
    are_notifications_enabled,
    get_default_screenshot_format,
    get_default_screenshot_mode,
    get_default_screenshot_timer,
    get_email_settings,
    get_screenshots_dir,
    get_settings,
    is_auto_organize_enabled,
    reload_settings,
)

__all__ = [
    "AppSettings",
    "ClientInfo",
    "MultiSessionReport",
    "ReportGenerator",
    "S3Helper",
    "SessionLog",
    "SettingsManager",
    "are_notifications_enabled",
    "generate_custom_link",
    "generate_multi_session_pdf",
    "generate_single_session_pdf",
    "get_default_screenshot_format",
    "get_default_screenshot_mode",
    "get_default_screenshot_timer",
    "get_email_settings",
    "get_s3_settings",
    "get_screenshots_dir",
    "get_settings",
    "interactive_report_generation",
    "is_auto_organize_enabled",
    "is_s3_enabled",
    "reload_settings",
    "report_main",
    "s3_main",
    "send_email",
]

# Note: To use the report functionality, import directly from screenshooter.modules.reports
# Note: To use the settings functionality, import directly from screenshooter.modules.settings
# Note: To use the S3 functionality, import directly from screenshooter.modules.s3
