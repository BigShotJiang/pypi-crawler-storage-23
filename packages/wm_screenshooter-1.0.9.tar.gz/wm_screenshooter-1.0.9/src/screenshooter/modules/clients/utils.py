#!/usr/bin/env python3
"""Client utility functions for ScreenShooter Mac."""

import re
from pathlib import Path

from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.settings.settings_helper import get_screenshots_dir


def slugify_name(name: str) -> str:
    """Create a filesystem-safe slug from a display name.

    This is used for client and project directory names so that display names
    (which may contain spaces and special characters) remain user-friendly
    while the underlying directories stay stable and safe.
    """
    text = name.strip()
    if not text:
        return "unnamed"

    # Normalize whitespace to single underscores
    text = re.sub(r"\s+", "_", text)
    # Remove characters that are problematic for filesystem paths
    text = re.sub(r"[^A-Za-z0-9_.-]", "", text)
    # Avoid empty result
    return text or "unnamed"


def get_clients_base_dir() -> Path:
    """Get the base directory for all clients."""
    return Path(get_screenshots_dir())


def get_client_dir(directory_name: str) -> Path:
    """Get the directory path for a specific client."""
    return get_clients_base_dir() / directory_name


def get_client_info_path(directory_name: str) -> Path:
    """Get the path to a client's info file."""
    return get_client_dir(directory_name) / "client_info.json"


def get_client_project_path(directory_name: str, project_name: str) -> Path:
    """Get the path to a client's project directory."""
    return get_client_dir(directory_name) / project_name


def get_client_project_sessions_path(directory_name: str, project_name: str) -> Path:
    """Get the path to a client's project sessions directory."""
    return get_client_project_path(directory_name, project_name) / "sessions"


def get_client_project_reports_path(directory_name: str, project_name: str) -> Path:
    """Get the path to a client's project reports directory."""
    return get_client_project_path(directory_name, project_name) / "reports"


def save_client_info(client_info: ClientInfo) -> None:
    """Save client information to file."""
    client_info_path = get_client_info_path(client_info.directory_name)
    client_info_path.parent.mkdir(parents=True, exist_ok=True)
    client_info_path.write_text(client_info.model_dump_json(indent=2))


def load_client_info(directory_name: str) -> ClientInfo | None:
    """Load client information from file."""
    client_info_path = get_client_info_path(directory_name)
    if not client_info_path.exists():
        return None

    try:
        return ClientInfo.model_validate_json(client_info_path.read_text())
    except Exception:
        return None
