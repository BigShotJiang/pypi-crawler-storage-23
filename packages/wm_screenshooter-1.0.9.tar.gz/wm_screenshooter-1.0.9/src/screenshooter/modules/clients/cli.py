#!/usr/bin/env python3
"""Client CLI functionality for ScreenShooter Mac."""

import json
import shutil
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from rich.console import Console

from screenshooter.modules.clients.manager import ClientManager
from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.database import DatabaseOperations
from screenshooter.modules.settings.settings_helper import should_use_database

# Initialize rich console
console = Console()


@dataclass
class ProjectActionContext:
    """Shared context for project rename/archive actions."""

    manager: Any
    client_directory: str
    project_dir: str
    project_entry: dict
    db_ops: Any
    client_db_id: int | None


@dataclass
class ClientProjectsContext:
    """Context for listing and managing a client's projects."""

    manager: Any
    directory_name: str
    db_ops: Any
    client_db_id: int | None


@dataclass
class ProjectBrowserPromptContext:
    """Prompt context for project browser options."""

    page_items: list[dict]
    start_idx: int
    end_idx: int
    page: int
    total_pages: int
    view_archived: bool
    has_projects: bool
    has_archived: bool


def _prompt_ask_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default on one line, input on a clean `> ` line below."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        extra = f" [{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        # Disable rich markup so literal square brackets for choices render correctly
        console.print(f"{prompt_text}{extra}:", markup=False)
    else:
        # Show default value even when there are no choices
        extra = ""
        if default is not None:
            extra = f" ({default})"
        console.print(f"{prompt_text}{extra}:", markup=False)

    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            if raw in [str(c) for c in choices]:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: "
                f"{', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, **kwargs: Any) -> bool:
    """Yes/No confirm with indicator on question line and `> ` for input."""
    default = kwargs.get("default", False)
    indicator = "[Y/n]" if default else "[y/N]"
    default_choice = "y" if default else "n"
    console.print(f"{prompt_text} {indicator} ({default_choice}):", markup=False)
    default_choice = "y" if default else "n"

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            raw = default_choice
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


def _prompt_pdf_password_if_needed(pdf_security: str) -> str:
    """Prompt for PDF password when password security is enabled."""
    if pdf_security != "password":
        return ""

    while True:
        pdf_password = _prompt_ask_on_new_line("Enter PDF password", password=True)
        if not pdf_password:
            console.print(
                "[bold yellow]Password cannot be empty for password security.[/bold yellow]"
            )
            continue

        confirm_password = _prompt_ask_on_new_line("Confirm PDF password", password=True)
        if pdf_password == confirm_password:
            return pdf_password
        console.print("[bold red]Passwords do not match. Please try again.[/bold red]")


def _collect_new_client_details() -> dict[str, str]:
    """Collect additional client fields and preference values for a new client."""
    console.print("\n[bold]Additional Client Information[/bold]")
    console.print("==========================")
    company_name = _prompt_ask_on_new_line("Company name", default="")
    contact_name = _prompt_ask_on_new_line("Contact name", default="")
    contact_email = _prompt_ask_on_new_line("Contact email", default="")

    console.print("\n[bold]Preferences[/bold]")
    console.print("===========")
    screenshot_delivery = _prompt_ask_on_new_line(
        "Screenshot delivery method",
        choices=["local", "email", "cloud"],
        default="local",
    )
    notification_preferences = _prompt_ask_on_new_line(
        "Notification preferences",
        choices=["all", "important", "none"],
        default="all",
    )
    reporting_frequency = _prompt_ask_on_new_line(
        "Reporting frequency",
        choices=["daily", "weekly", "monthly", "none"],
        default="none",
    )
    pdf_security = _prompt_ask_on_new_line(
        "PDF security",
        choices=["none", "password"],
        default="none",
    )
    pdf_password = _prompt_pdf_password_if_needed(pdf_security)
    page_size = _prompt_ask_on_new_line("PDF page size", choices=["A4", "letter"], default="A4")

    return {
        "company_name": company_name,
        "contact_name": contact_name,
        "contact_email": contact_email,
        "screenshot_delivery": screenshot_delivery,
        "notification_preferences": notification_preferences,
        "reporting_frequency": reporting_frequency,
        "pdf_security": pdf_security,
        "pdf_password": pdf_password,
        "page_size": page_size,
    }


def _apply_new_client_details(client_info: ClientInfo, details: dict[str, str]) -> None:
    """Apply collected details to a ClientInfo instance."""
    client_info.company_name = details["company_name"]
    client_info.contact_name = details["contact_name"]
    client_info.contact_email = details["contact_email"]
    client_info.preferences["screenshot_delivery"] = details["screenshot_delivery"]
    client_info.preferences["notification_preferences"] = details["notification_preferences"]
    client_info.preferences["reporting_frequency"] = details["reporting_frequency"]
    client_info.preferences["pdf_security"] = details["pdf_security"]
    client_info.pdf_password = details["pdf_password"]
    client_info.preferences["page_size"] = details["page_size"]


def _create_new_client_record(manager, client_name: str, directory_name: str) -> ClientInfo:
    """Create and persist a new client with interactive details."""
    client_info = ClientInfo(client_name=client_name, directory_name=directory_name)
    details = _collect_new_client_details()
    _apply_new_client_details(client_info, details)
    manager.save_client_info(client_info)
    return client_info


def _collect_existing_client_preferences(client_info: ClientInfo) -> dict[str, str]:
    """Collect editable preference values for an existing client."""
    console.print("\n[bold]Preferences[/bold]")
    console.print("===========")
    screenshot_delivery = _prompt_ask_on_new_line(
        "Screenshot delivery method",
        choices=["local", "email", "cloud"],
        default=client_info.preferences.get("screenshot_delivery", "local"),
    )
    notification_preferences = _prompt_ask_on_new_line(
        "Notification preferences",
        choices=["all", "important", "none"],
        default=client_info.preferences.get("notification_preferences", "all"),
    )
    reporting_frequency = _prompt_ask_on_new_line(
        "Reporting frequency",
        choices=["daily", "weekly", "monthly", "none"],
        default=client_info.preferences.get("reporting_frequency", "none"),
    )
    pdf_security = _prompt_ask_on_new_line(
        "PDF security",
        choices=["none", "password"],
        default=client_info.preferences.get("pdf_security", "none"),
    )
    page_size = _prompt_ask_on_new_line(
        "PDF page size",
        choices=["A4", "letter"],
        default=client_info.preferences.get("page_size", "A4"),
    )
    return {
        "screenshot_delivery": screenshot_delivery,
        "notification_preferences": notification_preferences,
        "reporting_frequency": reporting_frequency,
        "pdf_security": pdf_security,
        "pdf_password": _prompt_pdf_password_if_needed(pdf_security),
        "page_size": page_size,
    }


def _handle_client_directory_change(manager, directory_name: str, new_directory_name: str) -> str:
    """Rename/merge client directory and return final directory name."""
    old_client_dir = manager.base_dir / directory_name
    new_client_dir = manager.base_dir / new_directory_name

    if new_client_dir.exists() and (new_client_dir / "client_info.json").exists():
        console.print(
            "[bold red]A client directory with the name "
            f"'{new_directory_name}' already exists![/bold red]"
        )
        if not _confirm_on_new_line(
            "Do you want to continue with the directory change? This will merge the directories."
        ):
            console.print(
                "[yellow]Directory name change cancelled. Keeping other updates.[/yellow]"
            )
            return directory_name

    try:
        new_client_dir.mkdir(parents=True, exist_ok=True)
        for item in old_client_dir.glob("*"):
            if item.name == "client_info.json":
                continue
            if item.is_dir():
                _copy_directory_contents(item, new_client_dir / item.name)
            else:
                shutil.copy2(item, new_client_dir / item.name)

        shutil.rmtree(old_client_dir)
        console.print(
            "[bold green]Directory renamed successfully from "
            f"'{directory_name}' to '{new_directory_name}'.[/bold green]"
        )
        return new_directory_name
    except Exception as e:
        console.print(f"[bold red]Error during directory name change: {e}[/bold red]")
        console.print("[yellow]Continuing with other updates...[/yellow]")
        return directory_name


def _copy_directory_contents(source_dir, target_dir) -> None:
    """Copy directory contents, merging into existing target when needed."""
    if target_dir.exists():
        for sub_item in source_dir.glob("**/*"):
            if not sub_item.is_file():
                continue
            rel_path = sub_item.relative_to(source_dir)
            target_path = target_dir / rel_path
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(sub_item, target_path)
        return
    shutil.copytree(source_dir, target_dir)


def _resolve_client_directory_name(manager, client_name_or_directory: str) -> str | None:
    """Resolve client directory name from display or directory identifier."""
    directory_name = manager.get_directory_from_client_name(client_name_or_directory)
    if directory_name:
        return directory_name
    if manager.client_exists(client_name_or_directory):
        return client_name_or_directory
    return None


def _is_client_archived_status(manager, directory_name: str, client_identifier: str) -> bool:
    """Determine archived status for a client using DB or filesystem."""
    db_mode_requested = should_use_database()
    try:
        if db_mode_requested:
            db_ops = DatabaseOperations()
            db_client = db_ops.get_client_by_directory(directory_name)
            if not db_client:
                db_client = db_ops.get_client_by_name(client_identifier)
            if not db_client:
                console.print(
                    "[yellow]Database mode is enabled, but this client is missing in the database."
                    " Using filesystem metadata for archive status.[/yellow]"
                )
            return bool(db_client and db_client.archived_at)

        console.print(
            "[yellow]Database mode is disabled in settings. "
            "Using filesystem metadata for archive status.[/yellow]"
        )
        client_info_file = manager.get_client_info_path(directory_name)
        if client_info_file.exists():
            data = json.loads(client_info_file.read_text())
            return bool(data.get("archived_at") or data.get("archived", False))
    except Exception as exc:
        if db_mode_requested:
            console.print(f"[yellow]Database unavailable ({exc}).[/yellow]")
            console.print(
                "[yellow]Using filesystem metadata for archive status.[/yellow]"
            )
        return False
    return False


def _show_manage_client_options(is_archived: bool) -> list[str]:
    """Render manage-client options and return valid choice list."""
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit client information")
    console.print("p: List projects")
    if is_archived:
        console.print("u: Unarchive client")
        choices = ["e", "p", "u", "b"]
    else:
        console.print("a: Archive client")
        choices = ["e", "p", "a", "b"]
    console.print("b: Go back")
    return choices


def _handle_client_archive_action(manager, directory_name: str, *, unarchive: bool) -> None:
    """Handle archive/unarchive confirmation and action."""
    client_info = manager.load_client_info_from_directory(directory_name)
    action_word = "unarchive" if unarchive else "archive"
    action_past = "unarchived" if unarchive else "archived"
    flow_desc = (
        "This will make it available in the main screenshot flow."
        if unarchive
        else "This will hide it from the main screenshot flow."
    )
    if not _confirm_on_new_line(
        f"Are you sure you want to {action_word} client '{client_info.client_name}'? {flow_desc}"
    ):
        console.print(f"[yellow]{action_word.title()} cancelled.[/yellow]")
        return

    success = (
        manager.unarchive_client(directory_name)
        if unarchive
        else manager.archive_client(directory_name)
    )
    if success:
        console.print(
            f"[bold green]Client '{client_info.client_name}' has been {action_past}.[/bold green]"
        )
        if unarchive:
            console.print("[yellow]It will now appear in the main client list.[/yellow]")
        else:
            console.print(
                "[yellow]You can access it via 'List all clients' in the "
                "client management menu.[/yellow]"
            )
        return
    console.print(
        f"[bold red]Failed to {action_word} client '{client_info.client_name}'.[/bold red]"
    )


def edit_client_info_interactive(manager, directory_name: str) -> str:
    """Interactive editor for client information."""
    client_info = manager.load_client_info_from_directory(directory_name)

    console.print("\n[bold]Edit Client Information[/bold]")
    console.print("=======================")

    # Ask for client display name with the current name as default
    new_client_name = _prompt_ask_on_new_line(
        "Client name (display name)", default=client_info.client_name
    )

    # Ask if user wants to change directory name (optional)
    change_directory = False
    new_directory_name = directory_name

    if _confirm_on_new_line(
        "Would you like to change the directory name? (Advanced)", default=False
    ):
        new_directory_name = _prompt_ask_on_new_line(
            "Directory name", default=client_info.directory_name
        )
        if new_directory_name != directory_name:
            change_directory = True

    # Display current values and get new ones
    company_name = _prompt_ask_on_new_line("Company name", default=client_info.company_name)
    contact_name = _prompt_ask_on_new_line("Contact name", default=client_info.contact_name)
    contact_email = _prompt_ask_on_new_line("Contact email", default=client_info.contact_email)

    preferences = _collect_existing_client_preferences(client_info)

    # Handle directory name change if requested
    if change_directory:
        new_directory_name = _handle_client_directory_change(
            manager,
            directory_name,
            new_directory_name,
        )

    # Update client info object
    client_info.client_name = new_client_name
    client_info.directory_name = new_directory_name
    client_info.company_name = company_name
    client_info.contact_name = contact_name
    client_info.contact_email = contact_email
    client_info.preferences["screenshot_delivery"] = preferences["screenshot_delivery"]
    client_info.preferences["notification_preferences"] = preferences["notification_preferences"]
    client_info.preferences["reporting_frequency"] = preferences["reporting_frequency"]
    client_info.preferences["pdf_security"] = preferences["pdf_security"]
    client_info.pdf_password = preferences["pdf_password"]
    client_info.preferences["page_size"] = preferences["page_size"]

    # Save the updated info
    manager.save_client_info(client_info)

    # Return the new directory name for the caller
    return new_directory_name


def create_new_client_for_screenshot() -> str | None:
    """Create a new client interactively and return the client name for screenshot module.

    Returns:
        str: The client name if successful, None if cancelled
    """
    manager = ClientManager()

    console.print("[bold]Create New Client[/bold]")
    console.print("=================")
    console.print("(Leave blank and press Enter to cancel)")

    client_name = _prompt_ask_on_new_line("Client name (display name)", default="")
    if not client_name:
        console.print("[yellow]Client creation cancelled.[/yellow]")
        return None

    # Use a safe slug of the client name as the initial directory name
    directory_name = slugify_name(client_name)

    # Advanced option for custom directory name
    if _confirm_on_new_line(
        "Would you like to use a custom directory name? (Advanced)", default=False
    ):
        directory_name = _prompt_ask_on_new_line("Directory name", default=directory_name)

    # Check if client already exists
    if manager.client_exists(directory_name):
        if not _confirm_on_new_line(
            f"Client directory '{directory_name}' already exists. Would you like to edit it?"
        ):
            return None

        # Display existing client info
        manager.display_client_info(directory_name)

        # Ask if they want to update this client's information
        if _confirm_on_new_line("Would you like to update this client's information?"):
            # Edit existing client
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name

        # For existing clients, just return the client name after any editing
        client_info = manager.load_client_info_from_directory(directory_name)
        return client_info.client_name
    client_info = _create_new_client_record(manager, client_name, directory_name)
    manager.display_client_info(directory_name)
    return client_info.directory_name


def create_new_client() -> None:
    """Create a new client interactively."""
    manager = ClientManager()

    console.print("[bold]Create New Client[/bold]")
    console.print("=================")
    console.print("(Leave blank and press Enter to cancel)")

    client_name = _prompt_ask_on_new_line("Client name (display name)", default="")
    if not client_name:
        console.print("[yellow]Client creation cancelled.[/yellow]")
        return

    # Use a safe slug of the client name as the initial directory name
    directory_name = slugify_name(client_name)

    # Advanced option for custom directory name
    if _confirm_on_new_line(
        "Would you like to use a custom directory name? (Advanced)", default=False
    ):
        directory_name = _prompt_ask_on_new_line("Directory name", default=directory_name)

    # Check if client already exists
    if manager.client_exists(directory_name):
        if not _confirm_on_new_line(
            f"Client directory '{directory_name}' already exists. Would you like to edit it?"
        ):
            return

        # Display existing client info
        manager.display_client_info(directory_name)

        # Ask if they want to update this client's information
        if _confirm_on_new_line("Would you like to update this client's information?"):
            # Edit existing client
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name
    else:
        _create_new_client_record(manager, client_name, directory_name)

    # Display final client info
    manager.display_client_info(directory_name)

    # After creating/viewing, offer options
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit client information")
    console.print("p: List projects")
    console.print("b: Go back")

    choice = _prompt_ask_on_new_line(
        "\nWhat would you like to do?", choices=["e", "p", "b"], default="b"
    )

    if choice == "e":
        # Get the possibly new directory name after editing
        new_directory_name = edit_client_info_interactive(manager, directory_name)
        # Use the new directory if it was changed
        if new_directory_name and new_directory_name != directory_name:
            directory_name = new_directory_name
        manager.display_client_info(directory_name)
        # After editing, give option to go back or do something else
        manage_client(directory_name)
    elif choice == "p":
        list_client_projects(directory_name)


def manage_client(client_name_or_directory: str) -> None:
    """Manage an existing client."""
    manager = ClientManager()
    try:
        directory_name = _resolve_client_directory_name(manager, client_name_or_directory)
        if not directory_name:
            console.print(f"[bold red]Client '{client_name_or_directory}' not found.[/bold red]")
            if not _confirm_on_new_line("Would you like to create this client?"):
                return
            client_info = ClientInfo(
                client_name=client_name_or_directory,
                directory_name=slugify_name(client_name_or_directory),
            )
            manager.save_client_info(client_info)
            new_directory_name = edit_client_info_interactive(manager, client_name_or_directory)
            directory_name = (
                new_directory_name
                if new_directory_name and new_directory_name != client_name_or_directory
                else client_name_or_directory
            )
    except Exception as e:
        console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    while True:
        manager.display_client_info(directory_name)
        is_archived = _is_client_archived_status(manager, directory_name, client_name_or_directory)
        choices = _show_manage_client_options(is_archived)
        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=choices, default="e"
        )

        if choice == "b":
            return
        if choice == "e":
            new_directory_name = edit_client_info_interactive(manager, directory_name)
            if new_directory_name and new_directory_name != directory_name:
                directory_name = new_directory_name
            continue
        if choice == "p":
            list_client_projects(directory_name)
            continue
        if choice == "a":
            _handle_client_archive_action(manager, directory_name, unarchive=False)
            continue
        if choice == "u":
            _handle_client_archive_action(manager, directory_name, unarchive=True)
            continue


def _paginate_items(items: list[str], page: int, page_size: int) -> tuple[int, int, int, list[str]]:
    """Return pagination metadata and page slice."""
    total_items = len(items)
    total_pages = (total_items + page_size - 1) // page_size if total_items else 1
    page = min(max(page, 0), max(total_pages - 1, 0))
    start_idx = page * page_size
    end_idx = min(start_idx + page_size, total_items)
    return page, start_idx, end_idx, items[start_idx:end_idx]


def _render_client_page(
    manager, directory_names: list[str], page: int, page_size: int
) -> tuple[int, int, int, int, list[str]]:
    """Render a page of clients and return pagination values."""
    page, start_idx, end_idx, page_items = _paginate_items(directory_names, page, page_size)
    total_pages = (len(directory_names) + page_size - 1) // page_size if directory_names else 1

    if total_pages > 1:
        console.print(f"\n[bold]Available Clients (Page {page + 1}/{total_pages}):[/bold]")
    else:
        console.print("\n[bold]Available Clients:[/bold]")
    console.print("==================")

    for i, directory_name in enumerate(page_items):
        client_info = manager.load_client_info_from_directory(directory_name)
        display_idx = start_idx + i + 1
        is_archived = _is_client_archived_status(manager, directory_name, client_info.client_name)
        archive_suffix = " [dim](Archived)[/dim]" if is_archived else ""
        console.print(
            f"{display_idx}. [bold]{client_info.client_name}[/bold] ({client_info.company_name})"
            f"{archive_suffix}"
        )

    return total_pages, page, start_idx, end_idx, page_items


def _prompt_list_clients_action(
    *,
    start_idx: int,
    end_idx: int,
    page_items: list[str],
    page: int,
    total_pages: int,
) -> str:
    """Prompt for list-all-clients action and return chosen command."""
    console.print("\n[bold]Options:[/bold]")
    console.print(f"{start_idx + 1}-{end_idx}: Select client")
    console.print("c: Create new client")
    console.print("b: Go back to client menu")

    extra_options: list[str] = []
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_options.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_options.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + ["c", "b"] + extra_options
    return _prompt_ask_on_new_line("\nWhat would you like to do?", choices=choices, default="b")


def _resolve_project_id_for_entry(db_ops, client_db_id, project_entry: dict) -> int | None:
    """Resolve and cache project ID on a project entry."""
    project_id = project_entry.get("project_id")
    if project_id:
        return project_id
    if not (db_ops and client_db_id):
        return None
    try:
        db_project = db_ops.get_project_by_directory(
            client_db_id, project_entry.get("directory_name")
        )
        if db_project and db_project.id:
            project_entry["project_id"] = db_project.id
            return db_project.id
    except Exception:
        return None
    return None


def _render_project_detail_options(archived: bool) -> list[str]:
    """Render project detail options and return allowed choices."""
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit project name")
    if archived:
        console.print("u: Unarchive project")
        choices = ["e", "u", "b"]
    else:
        console.print("a: Archive project")
        choices = ["e", "a", "b"]
    console.print("b: Go back")
    return choices


def _rename_project(context: ProjectActionContext, display_name: str) -> tuple[str, bool]:
    """Prompt and apply a project rename operation."""
    new_name = _prompt_ask_on_new_line("New project name", default=display_name)
    if not new_name:
        console.print("[yellow]Project name cannot be empty.[/yellow]")
        return display_name, False
    if new_name == display_name:
        console.print("[yellow]No changes made to the project name.[/yellow]")
        return display_name, False

    fs_success = context.manager.update_project_display_name(
        context.client_directory,
        context.project_dir,
        new_name,
    )
    db_success = True
    project_id = _resolve_project_id_for_entry(
        context.db_ops,
        context.client_db_id,
        context.project_entry,
    )
    if context.db_ops and project_id:
        try:
            db_success = context.db_ops.update_project_name(project_id, new_name)
        except Exception as exc:
            console.print(f"[red]Failed to update project name in database: {exc}[/red]")
            db_success = False

    context.manager.append_project_log(
        context.client_directory,
        context.project_dir,
        f"Project renamed: {display_name} -> {new_name}",
    )
    if fs_success or db_success:
        console.print(f"[green]Project name updated to '{new_name}'.[/green]")
        context.project_entry["display_name"] = new_name
        return new_name, True
    console.print("[red]Failed to update project name.[/red]")
    return display_name, False


def _toggle_project_archive(
    context: ProjectActionContext,
    display_name: str,
    archived: bool,
) -> tuple[bool, bool]:
    """Archive or unarchive a project based on current state."""
    to_archived = not archived
    verb = "Archive" if to_archived else "Unarchive"
    msg = (
        f"{verb} project '{display_name}'? This will mark it as completed."
        if to_archived
        else f"{verb} project '{display_name}'? This will make it active."
    )
    if not _confirm_on_new_line(msg):
        console.print(f"[yellow]{verb} cancelled.[/yellow]")
        return archived, False

    fs_success = context.manager.update_project_archive_status(
        context.client_directory,
        context.project_dir,
        archived=to_archived,
    )
    db_success = True
    project_id = _resolve_project_id_for_entry(
        context.db_ops,
        context.client_db_id,
        context.project_entry,
    )
    if context.db_ops and project_id:
        try:
            if to_archived:
                db_success = context.db_ops.archive_project(project_id)
            else:
                db_success = context.db_ops.unarchive_project(project_id)
        except Exception as exc:
            op = "archive" if to_archived else "unarchive"
            console.print(f"[red]Failed to {op} project in database: {exc}[/red]")
            db_success = False

    context.manager.append_project_log(
        context.client_directory,
        context.project_dir,
        f"Project {display_name} {'archived' if to_archived else 'unarchived'}",
    )

    if fs_success or db_success:
        context.project_entry["archived"] = to_archived
        console.print(
            "[green]Project "
            f"'{display_name}' {'archived' if to_archived else 'unarchived'}.[/green]"
        )
        return to_archived, True

    console.print(f"[red]Failed to {'archive' if to_archived else 'unarchive'} project.[/red]")
    return archived, False


def _resolve_archived_client_directory(manager, client_name: str) -> str | None:
    """Resolve directory name for an archived client display name."""
    try:
        directory_name = manager.get_directory_from_client_name(client_name)
        if directory_name:
            return directory_name
        if manager.client_exists(client_name):
            return client_name
    except Exception as e:
        console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
    return None


def _handle_unarchive_client_choice(
    manager, archived_clients: list[str], selected_idx: int
) -> bool:
    """Handle unarchive action for selected archived client index."""
    if not 0 <= selected_idx < len(archived_clients):
        console.print("[red]Invalid selection.[/red]")
        return False

    selected_client_name = archived_clients[selected_idx]
    directory_name = _resolve_archived_client_directory(manager, selected_client_name)
    if not directory_name:
        console.print(f"[red]Could not find directory for client '{selected_client_name}'.[/red]")
        return False

    if not _confirm_on_new_line(
        "Unarchive client "
        f"'{selected_client_name}' and make it available in the main screenshot flow?"
    ):
        console.print("[yellow]Unarchive cancelled.[/yellow]")
        return False

    success = manager.unarchive_client(directory_name)
    if success:
        console.print(
            f"[bold green]Client '{selected_client_name}' has been unarchived.[/bold green]"
        )
        console.print("[yellow]It will now appear in the main client list.[/yellow]")
        return True

    console.print(f"[bold red]Failed to unarchive client '{selected_client_name}'.[/bold red]")
    return False


def list_all_clients() -> None:
    """List all clients with basic information and provide options."""
    manager = ClientManager()
    try:
        directory_names = manager.list_clients(
            include_archived=True
        )  # Include all clients to show archive status
    except Exception as e:
        console.print(f"[bold red]Error accessing client data: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return

    if not directory_names:
        console.print("[yellow]No clients found.[/yellow]")
        if _confirm_on_new_line("Would you like to create a new client?"):
            create_new_client()
        return

    page_size = 10
    page = 0

    while True:
        total_pages, page, start_idx, end_idx, page_items = _render_client_page(
            manager,
            directory_names,
            page,
            page_size,
        )
        choice = _prompt_list_clients_action(
            start_idx=start_idx,
            end_idx=end_idx,
            page_items=page_items,
            page=page,
            total_pages=total_pages,
        )

        if choice == "c":
            create_new_client()
            directory_names = manager.list_clients()
        elif choice == "b":
            return
        elif choice == "n":
            page += 1
        elif choice == "p":
            page -= 1
        else:
            selected_dir = directory_names[int(choice) - 1]
            manage_client(selected_dir)


def list_client_projects(directory_name: str) -> None:
    """List all projects for a specific client and provide options."""
    context = _resolve_client_projects_context(directory_name)
    if not context:
        return

    projects, archived_projects = _fetch_projects_for_client_context(context)
    _show_client_projects_header(context)
    if _handle_empty_client_projects(context, projects, archived_projects):
        return
    _run_client_projects_browser(context, projects, archived_projects)


def project_detail_view(
    *,
    manager,
    client_directory: str,
    project_entry: dict,
    db_ops=None,
    client_db_id=None,
) -> bool:
    """Show project details and allow rename/archive actions.

    Returns:
        True if project state changed, False otherwise.
    """
    changed = False
    project_dir = str(project_entry.get("directory_name") or "")
    if not project_dir:
        console.print("[red]Invalid project entry: missing directory name.[/red]")
        return changed
    metadata = manager.load_project_metadata(client_directory, project_dir)

    # Keep display name in sync with metadata when available
    display_name = str(metadata.project_name or project_entry.get("display_name") or project_dir)
    project_entry["display_name"] = display_name
    # Trust browser/list state first (DB-backed when enabled); filesystem metadata can be stale.
    archived = bool(project_entry.get("archived"))
    action_context = ProjectActionContext(
        manager=manager,
        client_directory=client_directory,
        project_dir=project_dir,
        project_entry=project_entry,
        db_ops=db_ops,
        client_db_id=client_db_id,
    )

    while True:
        console.print("\n[bold]Project Details[/bold]")
        console.print("------------------")
        console.print(f"Project: [bold]{display_name}[/bold]")
        console.print(f"Directory: {metadata.directory_name}")
        console.print(f"Started: {metadata.started_at}")
        console.print(f"Last Updated: {metadata.last_updated}")
        console.print(f"Finished: {metadata.finished_at}")
        archived_at_label = (
            metadata.archived_at if archived and metadata.archived_at else "Archived"
        )
        console.print(f"Archived At: {archived_at_label if archived else 'Active'}")
        choices = _render_project_detail_options(archived)

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do?", choices=choices, default="b"
        )

        if choice == "b":
            return changed
        if choice == "e":
            display_name, op_changed = _rename_project(action_context, str(display_name))
            if op_changed:
                metadata = manager.load_project_metadata(client_directory, project_dir)
                changed = True
            continue

        if choice in {"a", "u"}:
            archived, op_changed = _toggle_project_archive(
                action_context,
                str(display_name),
                archived,
            )
            if op_changed:
                metadata = manager.load_project_metadata(client_directory, project_dir)
                changed = True
            continue

        console.print("[red]Invalid selection.[/red]")


def interactive_client_management() -> None:
    """Interactive client management menu."""
    options = ["Manage active clients", "List all clients", "Create new client", "Exit"]

    while True:
        console.print("[bold]Client Management[/bold]")
        console.print("=================")
        console.print("(Enter 'b' at any prompt to go back to the previous menu)")
        console.print("\nOptions:")
        for i, option in enumerate(options, 1):
            console.print(f"{i}. {option}")

        choice = _prompt_ask_on_new_line(
            "\nWhat would you like to do? (or 'b' to go back)",
            choices=[str(i) for i in range(1, len(options) + 1)] + ["b"],
            default="1",
        )

        if choice == "b":
            console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
            return
        if choice == "1":
            # Manage active clients - similar to old "Manage existing client"
            manager = ClientManager()
            directory_names = manager.list_clients(include_archived=False)

            if not directory_names:
                console.print("[yellow]No active clients found.[/yellow]")
                if _confirm_on_new_line("Would you like to create a new client?"):
                    create_new_client()
                continue

            # Allow selection from list with clear labeling
            console.print("\n[bold]Active Clients:[/bold]")
            for i, directory in enumerate(directory_names, 1):
                client_info = manager.load_client_info_from_directory(directory)
                console.print(f"{i}. {client_info.client_name}")

            client_idx = _prompt_ask_on_new_line(
                "\nEnter client number to manage (or 'b' to go back)",
                choices=[str(i) for i in range(1, len(directory_names) + 1)] + ["b"],
                default="1",
            )
            if client_idx == "b":
                continue

            selected_dir = directory_names[int(client_idx) - 1]
            manage_client(selected_dir)
            continue
        if choice == "2":
            list_all_clients()
            continue
        if choice == "3":
            create_new_client()
            continue
        if choice == "4":
            console.print("Exiting client management.")
            return


def manage_archived_clients() -> None:
    """Manage archived clients."""
    manager = ClientManager()
    archived_clients = manager.list_archived_clients()

    if not archived_clients:
        console.print("[yellow]No archived clients found.[/yellow]")
        _prompt_ask_on_new_line("Press Enter to continue...", choices=[""], default="")
        return

    # Pagination for archived clients
    page_size = 10
    page = 0

    while True:
        total_pages, page, start_idx, end_idx, page_items = _render_archived_clients_page(
            archived_clients,
            page,
            page_size,
        )

        choice = _prompt_archived_clients_action(start_idx, end_idx, page_items, page, total_pages)

        if choice == "b":
            return
        if choice == "n":
            page += 1
            continue
        if choice == "p":
            page -= 1
            continue

        if isinstance(choice, str) and choice.isdigit():
            selected_idx = int(choice) - 1
            changed = _handle_unarchive_client_choice(manager, archived_clients, selected_idx)
            if changed:
                archived_clients = manager.list_archived_clients()
                if not archived_clients:
                    console.print("[yellow]No archived clients found.[/yellow]")
                    return
                total_pages = (len(archived_clients) + page_size - 1) // page_size
                if page >= total_pages > 0:
                    page = total_pages - 1
            continue

        console.print("[red]Invalid selection.[/red]")


def _render_archived_clients_page(
    archived_clients: list[str],
    page: int,
    page_size: int,
) -> tuple[int, int, int, int, list[str]]:
    """Render one archived-clients page and return pagination values."""
    total_pages = (len(archived_clients) + page_size - 1) // page_size
    if page >= total_pages:
        page = total_pages - 1
    page = max(page, 0)

    start_idx = page * page_size
    end_idx = min(start_idx + page_size, len(archived_clients))
    page_items = archived_clients[start_idx:end_idx]

    console.print(f"\n[bold]Archived Clients (Page {page + 1}/{total_pages}):[/bold]")
    console.print("[dim]These clients are hidden from the main screenshot flow.[/dim]")

    for i, client_name in enumerate(page_items):
        display_idx = start_idx + i + 1
        console.print(f"{display_idx}. {client_name} [dim](Archived)[/dim]")

    return total_pages, page, start_idx, end_idx, page_items


def _prompt_archived_clients_action(
    start_idx: int,
    end_idx: int,
    page_items: list[str],
    page: int,
    total_pages: int,
) -> str:
    """Prompt archived clients action and return choice."""
    console.print("\n[bold]Options:[/bold]")
    console.print(f"{start_idx + 1}-{end_idx}: Select client to unarchive")
    console.print("b: Go back")

    extra_options = []
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_options.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_options.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + ["b"] + extra_options
    default_choice = "1" if page_items else "b"
    return _prompt_ask_on_new_line(
        "Select a client to unarchive or go back",
        choices=choices,
        default=default_choice,
    )


def _ensure_client_exists_for_projects(manager, directory_name: str) -> str | None:
    """Ensure target client exists; optionally create/edit when missing."""
    try:
        client_exists = manager.client_exists(directory_name)
    except Exception as e:
        console.print(f"[bold red]Error checking client existence: {e}[/bold red]")
        console.print(
            "[yellow]Please check your database configuration or data source settings.[/yellow]"
        )
        return None

    if client_exists:
        return directory_name

    console.print(f"[bold red]Client directory '{directory_name}' not found.[/bold red]")
    if not _confirm_on_new_line("Would you like to create this client?"):
        return None

    client_name = _prompt_ask_on_new_line("Client name (display name)", default=directory_name)
    client_info = ClientInfo(client_name=client_name, directory_name=directory_name)
    manager.save_client_info(client_info)
    new_directory_name = edit_client_info_interactive(manager, directory_name)
    if new_directory_name and new_directory_name != directory_name:
        return new_directory_name
    return None


def _resolve_client_projects_context(directory_name: str):
    """Build client-projects context with optional database linkage."""
    manager = ClientManager()
    existing_directory = _ensure_client_exists_for_projects(manager, directory_name)
    if not existing_directory:
        return None

    db_ops = None
    client_db_id = None
    db_mode_requested = should_use_database()
    try:
        if db_mode_requested:
            db_ops = DatabaseOperations()
            db_client = db_ops.get_client_by_directory(
                existing_directory
            ) or db_ops.get_client_by_name(existing_directory)
            client_db_id = db_client.id if db_client else None
            if not client_db_id:
                console.print(
                    "[yellow]Database mode is enabled, but this client has no database record."
                    " Using filesystem project metadata.[/yellow]"
                )
        else:
            console.print(
                "[yellow]Database mode is disabled in settings. "
                "Using filesystem project metadata.[/yellow]"
            )
    except Exception as e:
        console.print(f"[bold red]Error accessing project data: {e}[/bold red]")
        console.print("[yellow]Using filesystem project metadata instead.[/yellow]")
        db_ops = None
        client_db_id = None

    return ClientProjectsContext(
        manager=manager,
        directory_name=existing_directory,
        db_ops=db_ops,
        client_db_id=client_db_id,
    )


def _format_archived_timestamp(value: Any) -> str:
    """Convert DB archived timestamp to project.json timestamp format."""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d_%H-%M-%S")

    text = str(value).strip()
    if not text:
        return ""
    sanitized = text.split(".")[0].replace("T", " ").replace(" ", "_")
    return sanitized.replace(":", "-")


def _reconcile_project_archive_state_from_db(context: ClientProjectsContext, project: Any) -> None:
    """Keep project.json archive fields aligned with DB project state."""
    project_dir = str(getattr(project, "directory_name", "") or "")
    if not project_dir:
        return

    metadata = context.manager.load_project_metadata(context.directory_name, project_dir)
    db_archived = bool(getattr(project, "archived_at", None))
    desired_archived_at = _format_archived_timestamp(getattr(project, "archived_at", None))

    should_save = False
    if db_archived:
        if metadata.archived_at != desired_archived_at:
            metadata.archived_at = desired_archived_at
            should_save = True
        if not metadata.finished_at:
            metadata.finished_at = desired_archived_at
            should_save = True
    else:
        if metadata.archived_at:
            metadata.archived_at = ""
            should_save = True
        if metadata.finished_at:
            metadata.finished_at = ""
            should_save = True

    if should_save:
        if not metadata.client_name:
            metadata.client_name = context.directory_name
        if not metadata.directory_name:
            metadata.directory_name = project_dir
        context.manager.save_project_metadata(metadata)


def _fetch_projects_for_client_context(
    context: ClientProjectsContext,
) -> tuple[list[dict], list[dict]]:
    """Fetch active and archived project entries for a client context."""
    projects_list: list[dict] = []
    archived_list: list[dict] = []

    if context.db_ops and context.client_db_id:
        try:
            db_active = context.db_ops.list_projects(context.client_db_id, active_only=True)
            db_archived = context.db_ops.list_archived_projects(context.client_db_id)
            for project in db_active:
                _reconcile_project_archive_state_from_db(context, project)
                projects_list.append(
                    {
                        "display_name": project.name,
                        "directory_name": project.directory_name,
                        "archived": False,
                        "project_id": project.id,
                    }
                )
            for project in db_archived:
                _reconcile_project_archive_state_from_db(context, project)
                archived_list.append(
                    {
                        "display_name": project.name,
                        "directory_name": project.directory_name,
                        "archived": True,
                        "project_id": project.id,
                    }
                )
            return projects_list, archived_list
        except Exception as exc:
            console.print(f"[bold red]Error accessing project data: {exc}[/bold red]")
            console.print(
                "[yellow]Please check your database configuration or data source settings.[/yellow]"
            )
            return [], []

    client_dir = context.manager.base_dir / context.directory_name
    if not client_dir.exists():
        return [], []

    for project_dir in sorted(client_dir.iterdir()):
        if not project_dir.is_dir():
            continue
        project_file = project_dir / "project.json"
        if not project_file.exists():
            continue
        try:
            data = json.loads(project_file.read_text())
            display_name = data.get("project_name", project_dir.name)
            is_archived = bool(data.get("archived_at") or data.get("archived", False))
            entry = {
                "display_name": display_name,
                "directory_name": project_dir.name,
                "archived": is_archived,
                "project_id": None,
            }
            if is_archived:
                archived_list.append(entry)
            else:
                projects_list.append(entry)
        except (OSError, json.JSONDecodeError):
            continue

    return projects_list, archived_list


def _show_client_projects_header(context: ClientProjectsContext) -> None:
    """Show selected client summary header for project listing."""
    client_info = context.manager.load_client_info_from_directory(context.directory_name)
    console.print(f"\n[bold]Client:[/bold] {client_info.client_name}")
    console.print(f"[bold]Directory:[/bold] {client_info.directory_name}")
    console.print(f"[bold]Company:[/bold] {client_info.company_name}")


def _handle_empty_client_projects(
    context: ClientProjectsContext,
    projects: list[dict],
    archived_projects: list[dict],
) -> bool:
    """Handle UI flow when a client has no projects."""
    if projects or archived_projects:
        return False

    console.print("[yellow]No projects found for this client.[/yellow]")
    console.print("\n[bold]Options:[/bold]")
    console.print("e: Edit client")
    console.print("b: Go back")
    choice = _prompt_ask_on_new_line(
        "\nWhat would you like to do?", choices=["e", "b"], default="b"
    )
    if choice == "e":
        manage_client(context.directory_name)
    return True


def _render_projects_browser_page(
    projects: list[dict],
    archived_projects: list[dict],
    *,
    view_archived: bool,
    page: int,
    page_size: int,
) -> tuple[list[dict], int, int, int, int]:
    """Render current project browser page and return page metadata."""
    current_list = archived_projects if view_archived else projects
    total_items = len(current_list)
    total_pages = (total_items + page_size - 1) // page_size if total_items else 1
    page = min(max(page, 0), max(total_pages - 1, 0))
    start_idx = page * page_size
    end_idx = min(start_idx + page_size, total_items)
    page_items = current_list[start_idx:end_idx]

    heading = "Archived Projects" if view_archived else "Active Projects"
    if total_pages > 1:
        console.print(f"\n[bold]{heading} (Page {page + 1}/{total_pages}):[/bold]")
    else:
        console.print(f"\n[bold]{heading}:[/bold]")
    console.print("==================")
    if not page_items:
        console.print("[dim]No projects to display.[/dim]")
    for i, project in enumerate(page_items):
        display_idx = start_idx + i + 1
        suffix = " [dim](Archived)[/dim]" if project.get("archived") else ""
        console.print(f"{display_idx}. [bold]{project.get('display_name')}[/bold]{suffix}")
    return page_items, page, start_idx, end_idx, total_pages


def _prompt_projects_browser_choice(
    prompt_context: ProjectBrowserPromptContext,
) -> str:
    """Prompt project-browser action choice."""
    page_items = prompt_context.page_items
    start_idx = prompt_context.start_idx
    end_idx = prompt_context.end_idx
    page = prompt_context.page
    total_pages = prompt_context.total_pages
    view_archived = prompt_context.view_archived
    has_projects = prompt_context.has_projects
    has_archived = prompt_context.has_archived

    console.print("\n[bold]Options:[/bold]")
    if page_items:
        console.print(f"{start_idx + 1}-{end_idx}: Select project")
    if not view_archived and has_archived:
        console.print("a: Show archived projects")
    if view_archived and has_projects:
        console.print("v: Show active projects")
    console.print("e: Edit client")
    console.print("b: Go back")

    extra_options: list[str] = []
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_options.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_options.append("p")

    choices = ["e", "b", *extra_options]
    if not view_archived and has_archived:
        choices.append("a")
    if view_archived and has_projects:
        choices.append("v")
    if page_items:
        choices.extend([str(start_idx + i + 1) for i in range(len(page_items))])
    return _prompt_ask_on_new_line("\nWhat would you like to do?", choices=choices, default="b")


def _run_client_projects_browser(
    context: ClientProjectsContext,
    projects: list[dict],
    archived_projects: list[dict],
) -> None:
    """Run interactive browser for a client's active/archived projects."""
    page = 0
    view_archived = False
    page_size = 10

    while True:
        page_items, page, start_idx, end_idx, total_pages = _render_projects_browser_page(
            projects,
            archived_projects,
            view_archived=view_archived,
            page=page,
            page_size=page_size,
        )
        choice = _prompt_projects_browser_choice(
            ProjectBrowserPromptContext(
                page_items=page_items,
                start_idx=start_idx,
                end_idx=end_idx,
                page=page,
                total_pages=total_pages,
                view_archived=view_archived,
                has_projects=bool(projects),
                has_archived=bool(archived_projects),
            )
        )

        if choice == "e":
            manage_client(context.directory_name)
            continue
        if choice == "b":
            return
        if choice == "n":
            page += 1
            continue
        if choice == "p":
            page -= 1
            continue
        if choice == "a" and not view_archived:
            view_archived = True
            page = 0
            continue
        if choice == "v" and view_archived:
            view_archived = False
            page = 0
            continue
        if not isinstance(choice, str) or not choice.isdigit():
            console.print("[red]Invalid selection.[/red]")
            continue

        idx = int(choice) - 1
        current_list = archived_projects if view_archived else projects
        if not 0 <= idx < len(current_list):
            console.print("[red]Invalid selection.[/red]")
            continue
        selected_project = current_list[idx]
        changed = project_detail_view(
            manager=context.manager,
            client_directory=context.directory_name,
            project_entry=selected_project,
            db_ops=context.db_ops,
            client_db_id=context.client_db_id,
        )
        if changed:
            projects, archived_projects = _fetch_projects_for_client_context(context)
            page = 0
