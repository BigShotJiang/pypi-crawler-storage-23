#!/usr/bin/env python3
"""Command-line interface for report generation."""

import logging
import platform
import re
import subprocess
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

import click
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from screenshooter.modules.clients.manager import ClientManager
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.database import DatabaseOperations
from screenshooter.modules.reports.pdf import (
    ReportGenerator,
    generate_multi_session_pdf,
    generate_single_session_pdf,
)
from screenshooter.modules.reports.report_email import (
    BatchEmailProjectReport,
    send_batch_email,
    send_email,
)
from screenshooter.modules.settings.settings_helper import (
    get_email_settings,
    get_pdf_optimization_settings,
    get_screenshots_dir,
    reload_settings,
    should_optimize_pdf,
    should_use_database,
)

# Initialize rich console
console = Console()

PAGE_SIZE = 10
STEP_SELECT_CLIENT = 1
STEP_SELECT_PROJECT = 2
STEP_SELECT_REPORT_TYPE = 3
STEP_SELECT_SPECIFICS = 4
STEP_PDF_SETTINGS = 5


def _prompt_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default on one line, input on a clean `> ` line below."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")

    prompt_text = prompt_text.strip()

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        # Escape opening bracket to prevent rich from interpreting it as a style tag
        extra = f" \\[{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        console.print(f"{prompt_text}{extra}:")
    else:
        console.print(f"{prompt_text}:")

    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            if raw in [str(c) for c in choices]:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: "
                f"{', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, **kwargs: Any) -> bool:
    """Yes/No confirm with indicator on question line and `> ` for input."""
    default = kwargs.get("default", False)
    indicator = "[Y/n]" if default else "[y/N]"
    console.print(f"{prompt_text} {indicator}:")
    default_choice = "y" if default else "n"

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            raw = default_choice
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


# Notes parsing (mirrors post_session flow) ----------------------------------
def _parse_notes_lines(note_line: str) -> list[str]:
    """Parse notes text into ordered lines with explicit bullets.

    - '/n', '\n', and '<br>' create new lines
    - '/b' starts a bullet item; multiple '/b' create multiple bullets
    - A plain '-' does not create a bullet
    """
    if not note_line:
        return []
    normalized = note_line.replace("<br>", "\n").replace("/n", "\n").replace("\\n", "\n")
    result_lines: list[str] = []
    for raw_line in normalized.splitlines():
        segment = raw_line.strip()
        if not segment:
            continue
        parts = segment.split("/b")
        head_text = parts[0].strip()
        if head_text:
            result_lines.append(head_text)
        for bullet_text in parts[1:]:
            cleaned = bullet_text.strip()
            if cleaned:
                result_lines.append(f"- {cleaned}")
    return result_lines


# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("report_cli")

# Sentinel value for 'back' option - Consider moving to a shared utils module
BACK_OPTION = object()
ALL_PROJECTS_OPTION = object()


@dataclass
class PageState:
    """Pagination state container."""

    start_idx: int
    page: int
    total_pages: int


@dataclass
class ProjectPageContext:
    """Context for rendering and prompting project pages."""

    current_list: list[str]
    archived_projects: list[str]
    viewing_all: bool


@dataclass
class ClientPageContext:
    """Context for rendering and prompting client pages."""

    current_list: list[str]
    archived_clients: list[str]
    viewing_all: bool


@dataclass
class ReportSelectionContext:
    """Collected report selection inputs before generation."""

    base_dir: Path
    client_name: str
    project_name: str
    report_type: str
    session_date: str | None
    specific_date: str | None
    date_range: tuple[str, str] | None
    output_dir: str | Path | None
    pagesize: str | None


@dataclass
class BatchReportSelectionContext:
    """Collected inputs for all-project batch generation."""

    base_dir: Path
    client_name: str
    project_names: list[str]
    batch_scope: str
    report_type: str
    specific_date: str | None
    date_range: tuple[str, str] | None
    output_dir: str | Path | None
    pagesize: str | None


@dataclass
class ReportSpecificsContext:
    """State used while collecting report-type-specific inputs."""

    project_dir: Path
    client_name: str
    project_name: str
    report_type: str
    session_date: str | None
    specific_date: str | None
    date_range: tuple[str, str] | None
    current_step: int


@dataclass
class InteractiveSetupState:
    """State for multi-step interactive report setup."""

    client_name: str | None = None
    project_name: str | None = None
    report_type: str | None = None
    all_projects_mode: bool = False
    all_projects_scope: str | None = None
    all_project_names: list[str] | None = None
    session_date: str | None = None
    specific_date: str | None = None
    date_range: tuple[str, str] | None = None


@dataclass
class EmailConfig:
    """Resolved SMTP and recipient settings for email delivery."""

    sender: str
    password: str
    smtp: str
    port: int
    sender_name: str
    username: str
    security: str
    recipients: list[str]
    recipient_type: str
    debug_enabled: bool = False


@dataclass
class GeneratedProjectReport:
    """Generated report metadata used for batch post-processing."""

    project_name: str
    pdf_file_path: Path
    generator: ReportGenerator
    context: ReportSelectionContext
    report_meta: dict[str, Any] | None


def _prepare_cli_report_context(cli_args: dict[str, Any]) -> ReportSelectionContext | int:
    """Collect and validate report context from command-line args."""
    client_name = cli_args.get("client")
    project_name = cli_args.get("project")
    session_date = cli_args.get("session")
    base_dir = Path(cli_args.get("dir")) if cli_args.get("dir") else Path(get_screenshots_dir())
    report_type = cli_args.get("report_type") or "session"
    specific_date = cli_args.get("date")
    date_range = None
    if cli_args.get("start_date") and cli_args.get("end_date"):
        date_range = (cli_args.get("start_date"), cli_args.get("end_date"))

    if not base_dir.exists():
        console.print(f"[bold red]Screenshots directory not found: {base_dir}[/bold red]")
        return 1
    if not client_name or not project_name:
        console.print(
            "[bold red]Client and project names are required for command line mode.[/bold red]"
        )
        return 1

    client_dir = _resolve_client_dir(base_dir, client_name)
    project_dir = _resolve_project_dir(base_dir, client_name, project_name)
    if not (client_dir.exists() and (client_dir / "client_info.json").exists()):
        console.print(
            f"[bold red]Client '{client_name}' not found or missing client_info.json.[/bold red]"
        )
        return 1
    if not (project_dir.exists() and (project_dir / "sessions").exists()):
        console.print(
            f"[bold red]Project '{project_name}' not found or has no sessions.[/bold red]"
        )
        return 1

    if report_type == "session" and not session_date:
        sessions = _load_sessions(project_dir, client_name, project_name)
        if not sessions:
            console.print(f"[bold red]No sessions found for project '{project_name}'.[/bold red]")
            return 1
        session_date = sessions[0]
        console.print(f"[green]Using most recent session: {session_date}[/green]")

    return ReportSelectionContext(
        base_dir=base_dir,
        client_name=client_name,
        project_name=project_name,
        report_type=report_type,
        session_date=session_date,
        specific_date=specific_date,
        date_range=date_range,
        output_dir=cli_args.get("output"),
        pagesize=cli_args.get("pagesize"),
    )


def _prepare_interactive_report_context(
) -> ReportSelectionContext | BatchReportSelectionContext | int:
    """Collect report context from interactive prompts."""
    console.print("(Enter 'b' at any prompt to go back to the previous step)")
    base_dir = Path(get_screenshots_dir())
    if not base_dir.exists():
        console.print(f"[bold red]Screenshots directory not found: {base_dir}[/bold red]")
        return 1

    state = InteractiveSetupState()
    step = STEP_SELECT_CLIENT
    while step <= STEP_PDF_SETTINGS:
        step, should_exit = _advance_interactive_setup_step(step, state, base_dir)
        if should_exit or step is None:
            return 1

    validation_error = _validate_interactive_setup_state(state)
    if validation_error:
        console.print(validation_error)
        return 1

    if state.all_projects_mode:
        return BatchReportSelectionContext(
            base_dir=base_dir,
            client_name=state.client_name or "",
            project_names=state.all_project_names or [],
            batch_scope=state.all_projects_scope or "",
            report_type=state.report_type or "day",
            specific_date=state.specific_date,
            date_range=state.date_range,
            output_dir=None,
            pagesize=None,
        )

    return ReportSelectionContext(
        base_dir=base_dir,
        client_name=state.client_name or "",
        project_name=state.project_name or "",
        report_type=state.report_type or "session",
        session_date=state.session_date,
        specific_date=state.specific_date,
        date_range=state.date_range,
        output_dir=None,
        pagesize=None,
    )


def _advance_interactive_setup_step(
    step: int,
    state: InteractiveSetupState,
    base_dir: Path,
) -> tuple[int | None, bool]:
    """Advance one interactive setup step."""
    if step == STEP_SELECT_CLIENT:
        return _run_client_selection_step(step, state, base_dir)
    if step == STEP_SELECT_PROJECT:
        return _run_project_selection_step(step, state, base_dir)
    if step == STEP_SELECT_REPORT_TYPE:
        return _run_report_type_selection_step(step, state)
    if step == STEP_SELECT_SPECIFICS:
        return _run_report_specifics_step(step, state, base_dir)
    if step == STEP_PDF_SETTINGS:
        return _run_pdf_settings_step(step)
    return None, True


def _run_client_selection_step(
    step: int,
    state: InteractiveSetupState,
    base_dir: Path,
) -> tuple[int | None, bool]:
    """Run client selection setup step."""
    result = _select_client_report(base_dir)
    if result is BACK_OPTION:
        console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
        return None, True
    if isinstance(result, str):
        state.client_name = result
        return step + 1, False
    return None, True


def _run_project_selection_step(
    step: int,
    state: InteractiveSetupState,
    base_dir: Path,
) -> tuple[int | None, bool]:
    """Run project selection setup step."""
    if not state.client_name:
        console.print("[red]Error: Client not selected.[/red]")
        return STEP_SELECT_CLIENT, False

    next_step: int | None = None
    should_exit = True
    result = _select_project_report(state.client_name, base_dir)
    if result is BACK_OPTION:
        next_step = step - 1
        should_exit = False
    elif result is ALL_PROJECTS_OPTION:
        projects, archived_projects = _load_report_projects(state.client_name, base_dir)
        if projects is None or archived_projects is None:
            return None, True
        if not projects:
            console.print(
                "[bold yellow]No active projects available for batch reports.[/bold yellow]"
            )
            return step, False
        state.all_projects_mode = True
        state.all_project_names = projects
        state.project_name = None
        next_step = step + 1
        should_exit = False
    elif isinstance(result, str):
        state.project_name = result
        state.all_projects_mode = False
        state.all_projects_scope = None
        state.all_project_names = None
        state.session_date = None
        state.specific_date = None
        state.date_range = None
        next_step = step + 1
        should_exit = False

    return next_step, should_exit


def _run_report_type_selection_step(
    step: int,
    state: InteractiveSetupState,
) -> tuple[int | None, bool]:
    """Run report type selection setup step."""
    if state.all_projects_mode:
        scope_result = _select_all_projects_scope()
        if scope_result is BACK_OPTION:
            return step - 1, False

        state.all_projects_scope = scope_result
        state.report_type = "day" if scope_result == "today" else "project"
        state.session_date = None
        state.specific_date = date.today().isoformat() if scope_result == "today" else None
        state.date_range = None
        return step + 1, False

    result = _select_report_type()
    if result is BACK_OPTION:
        return step - 1, False
    if isinstance(result, str):
        state.report_type = result
        return step + 1, False
    return step, False


def _run_report_specifics_step(
    step: int,
    state: InteractiveSetupState,
    base_dir: Path,
) -> tuple[int | None, bool]:
    """Run report-specific inputs setup step."""
    if state.all_projects_mode:
        return step + 1, False

    if not state.client_name or not state.project_name or not state.report_type:
        console.print("[red]Error: Client/Project/Report Type not selected.[/red]")
        return STEP_SELECT_CLIENT, False

    project_dir = _resolve_project_dir(base_dir, state.client_name, state.project_name)
    specifics_context = ReportSpecificsContext(
        project_dir=project_dir,
        client_name=state.client_name,
        project_name=state.project_name,
        report_type=state.report_type,
        session_date=state.session_date,
        specific_date=state.specific_date,
        date_range=state.date_range,
        current_step=step,
    )
    next_step, next_session_date, next_specific_date, next_date_range = (
        _handle_report_specifics_step(specifics_context)
    )
    state.session_date = next_session_date
    state.specific_date = next_specific_date
    state.date_range = next_date_range
    if next_step is None:
        return None, True
    return next_step, False


def _run_pdf_settings_step(step: int) -> tuple[int | None, bool]:
    """Run PDF settings setup step."""
    next_step = _handle_pdf_settings_step(step)
    if next_step is None:
        return None, True
    return next_step, False


def _validate_interactive_setup_state(state: InteractiveSetupState) -> str | None:
    """Validate final interactive setup state."""
    if state.all_projects_mode:
        return _validate_all_projects_setup_state(state)
    return _validate_single_project_setup_state(state)


def _validate_all_projects_setup_state(state: InteractiveSetupState) -> str | None:
    """Validate final interactive state for all-project batch mode."""
    if not state.client_name or not state.report_type or not state.all_projects_scope:
        return "[bold red]Setup incomplete for all-project report generation.[/bold red]"
    if not state.all_project_names:
        return "[bold red]No active projects selected for batch report generation.[/bold red]"
    if state.report_type == "day" and not state.specific_date:
        return "[bold red]Date not selected for all-project daily reports.[/bold red]"
    return None


def _validate_single_project_setup_state(state: InteractiveSetupState) -> str | None:
    """Validate final interactive state for single-project mode."""
    if not state.client_name or not state.project_name or not state.report_type:
        return "[bold red]Setup incomplete. Exiting report generation.[/bold red]"
    if state.report_type == "session" and not state.session_date:
        return "[bold red]Session date not selected. Exiting.[/bold red]"
    if state.report_type == "day" and not state.specific_date:
        return "[bold red]Specific date not selected for daily report. Exiting.[/bold red]"
    return None


def _handle_report_specifics_step(
    context: ReportSpecificsContext,
) -> tuple[int | None, str | None, str | None, tuple[str, str] | None]:
    """Handle report-type-specific selection step."""
    next_step: int | None = None
    next_session_date = context.session_date
    next_specific_date = context.specific_date
    next_date_range = context.date_range

    if context.report_type == "session":
        result = _select_session(context.project_dir, context.client_name, context.project_name)
        if result is BACK_OPTION:
            next_step = context.current_step - 1
        elif isinstance(result, str):
            next_step = context.current_step + 1
            next_session_date = result
    elif context.report_type == "day":
        result = _select_day(context.project_dir, context.client_name, context.project_name)
        if result is BACK_OPTION:
            next_step = context.current_step - 1
        elif isinstance(result, str):
            next_step = context.current_step + 1
            next_specific_date = result
    else:
        result = _select_date_range(context.project_dir, context.client_name, context.project_name)
        if result is BACK_OPTION:
            next_step = context.current_step - 1
        elif isinstance(result, tuple):
            next_step = context.current_step + 1
            next_date_range = result
        else:
            next_step = context.current_step + 1
            next_date_range = None

    return next_step, next_session_date, next_specific_date, next_date_range


def _handle_pdf_settings_step(current_step: int) -> int | None:
    """Handle PDF optimization settings step."""
    console.print("\n[bold]PDF Optimization[/bold]")
    pdf_settings = get_pdf_optimization_settings()
    console.print(
        f"[dim]Default settings: Quality={pdf_settings['image_quality']}, "
        f"Max dimension={pdf_settings['max_dimension']}px, "
        f"Format={pdf_settings['image_format']}[/dim]"
    )
    use_default_settings = _prompt_with_back(
        "Use default PDF optimization settings?",
        choices=["y", "n"],
        default="y",
    )
    if use_default_settings is BACK_OPTION:
        return current_step - 1
    if use_default_settings == "n":
        console.print("[yellow]Custom optimization not implemented yet, using defaults.[/yellow]")
    return current_step + 1


def _resolve_client_dir(base_dir: Path, client_name: str) -> Path:
    """Resolve the filesystem directory for a client for reports."""
    # Try database first
    if should_use_database():
        try:
            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and getattr(client, "directory_name", None):
                return base_dir / client.directory_name
        except Exception:
            pass

    # Try filesystem via ClientManager
    try:
        manager = ClientManager(str(base_dir))
        client_info = manager.load_client_info(client_name)
        if getattr(client_info, "directory_name", None):
            return base_dir / client_info.directory_name
    except Exception:
        pass

    # Fallback to slug or raw name
    slug = slugify_name(client_name)
    return base_dir / (slug or client_name)


def _resolve_project_dir(base_dir: Path, client_name: str, project_name: str) -> Path:
    """Resolve the filesystem directory for a project within a client for reports."""
    client_dir = _resolve_client_dir(base_dir, client_name)

    # Try database first
    if should_use_database():
        try:
            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and getattr(client, "id", None):
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and getattr(project, "directory_name", None):
                    return client_dir / project.directory_name
        except Exception:
            pass

    # Prefer slugged directory if it already exists
    slug = slugify_name(project_name)
    slug_dir = client_dir / slug
    if slug_dir.exists():
        return slug_dir

    # Legacy fallback: raw project name
    return client_dir / project_name


def _prompt_with_back(
    prompt_text: str, choices: list[str], default: str | None = None, show_choices: bool = True
) -> str | object:
    """Prompt helper that adds a 'b' for back, with clean spacing around the back hint."""
    base_choices = [str(c) for c in choices]
    valid_choices = [*base_choices, "b"]

    while True:
        response = _prompt_on_new_line(
            f"{prompt_text} (or 'b' to go back)",
            choices=valid_choices,
            default=default,
        )
        if response.lower() == "b":
            return BACK_OPTION
        if response in base_choices:
            return response


def _select_client_report(base_dir: Path) -> str | object | None:
    """Handle interactive client selection for reports."""
    console.print("\n[bold]Client Selection[/bold]")

    clients, archived_clients = _load_report_clients(base_dir)
    if clients is None or archived_clients is None:
        return None
    if not clients and not archived_clients:
        console.print("[bold yellow]No active or archived clients found.[/bold yellow]")
        return None

    viewing_all = False
    current_list = clients
    page = 0
    while True:
        page_items, page_state = _paginate_values(current_list, page)
        context = ClientPageContext(
            current_list=current_list,
            archived_clients=archived_clients,
            viewing_all=viewing_all,
        )
        _print_client_page(context, page_items, page_state)
        choice = _prompt_client_page_choice(
            context=context,
            page_items=page_items,
            state=page_state,
        )
        selected, page_delta, should_exit, viewing_all, current_list = _resolve_client_page_choice(
            choice=choice,
            current_list=current_list,
            clients=clients,
            archived_clients=archived_clients,
            viewing_all=viewing_all,
        )
        if should_exit:
            return selected
        page += page_delta


def _load_report_clients(base_dir: Path) -> tuple[list[str] | None, list[str] | None]:
    """Load active and archived clients from DB first, then optionally filesystem."""
    clients: list[str] = []
    archived_clients: list[str] = []
    db_checked = False
    if should_use_database():
        db_checked = True
        try:
            db_ops = DatabaseOperations()
            db_clients = db_ops.list_clients(active_only=True)
            clients = sorted([client.name for client in db_clients if client.name])
            db_archived = db_ops.list_archived_clients()
            archived_clients = sorted([client.name for client in db_archived if client.name])
        except Exception as e:
            logger.warning(f"Failed to get clients from database: {e}")

    if clients or archived_clients:
        return clients, archived_clients
    if db_checked:
        console.print(
            "[yellow]No active or archived clients found in database "
            "(or database unavailable).[/yellow]"
        )
        if not _confirm_on_new_line(
            "Would you like to check the filesystem for clients?", default=True
        ):
            return None, None

    try:
        manager = ClientManager(str(base_dir))
        clients = sorted([name for name in manager.list_clients(include_archived=False) if name])
        archived_clients = sorted([name for name in manager.list_archived_clients() if name])
    except Exception as e:
        logger.warning(f"Failed to get clients from filesystem fallback: {e}")
        return None, None
    if clients or archived_clients:
        return clients, archived_clients

    console.print(
        "[bold yellow]No active or archived clients found in filesystem or database.[/bold yellow]"
    )
    return None, None


def _print_client_page(
    context: ClientPageContext,
    page_items: list[str],
    state: PageState,
) -> None:
    """Render client selection page."""
    heading = "Available Clients" if context.viewing_all else "Available Active Clients"
    if state.total_pages > 1:
        console.print(f"\n[bold]{heading} (Page {state.page + 1}/{state.total_pages}):[/bold]")
    else:
        console.print(f"\n[bold]{heading}:[/bold]")

    if not context.current_list and not context.viewing_all:
        console.print("[dim]No active clients.[/dim]")
    elif not context.current_list and context.viewing_all:
        console.print("[dim]No clients found.[/dim]")

    archived_set = set(context.archived_clients)
    for index, client in enumerate(page_items):
        display_idx = state.start_idx + index + 1
        suffix = (
            " [dim](Archived)[/dim]" if context.viewing_all and client in archived_set else ""
        )
        console.print(f"{display_idx}. {client}{suffix}")


def _prompt_client_page_choice(
    *,
    context: ClientPageContext,
    page_items: list[str],
    state: PageState,
) -> str | object:
    """Prompt for client page selection."""
    choices = [str(state.start_idx + i + 1) for i in range(len(page_items))]
    extra_options: list[str] = []
    if state.page < state.total_pages - 1:
        console.print("n. Next Page")
        extra_options.append("n")
    if state.page > 0:
        console.print("p. Previous Page")
        extra_options.append("p")
    if not context.viewing_all and context.archived_clients:
        console.print(f"a. Show archived clients ({len(context.archived_clients)})")
        extra_options.append("a")
    if context.viewing_all and context.archived_clients:
        console.print("v. Show active clients only")
        extra_options.append("v")

    default_choice = choices[0] if choices else ("a" if "a" in extra_options else "b")
    return _prompt_with_back(
        "Select client number",
        choices=choices + extra_options,
        default=default_choice,
    )


def _resolve_client_page_choice(
    *,
    choice: str | object,
    current_list: list[str],
    clients: list[str],
    archived_clients: list[str],
    viewing_all: bool,
) -> tuple[str | object | None, int, bool, bool, list[str]]:
    """Resolve client-page selection action."""
    selected: str | object | None = None
    page_delta = 0
    should_exit = False
    next_viewing_all = viewing_all
    next_current_list = current_list

    if choice is BACK_OPTION:
        selected = BACK_OPTION
        should_exit = True
    elif choice == "n":
        page_delta = 1
    elif choice == "p":
        page_delta = -1
    elif choice == "a":
        next_viewing_all = True
        next_current_list = clients + archived_clients
    elif choice == "v":
        next_viewing_all = False
        next_current_list = clients
    elif isinstance(choice, str) and choice.isdigit():
        selected = current_list[int(choice) - 1]
        should_exit = True
    else:
        should_exit = True

    return selected, page_delta, should_exit, next_viewing_all, next_current_list


def _select_name_from_paginated_list(
    title: str,
    prompt_text: str,
    values: list[str],
) -> str | object | None:
    """Select one item from a paginated list with back support."""
    if not values:
        return None

    page = 0
    while True:
        page_items, state = _paginate_values(values, page)
        _print_paginated_values(title, page_items, state)
        choice = _prompt_paginated_choice(page_items, state, prompt_text)
        selected, page_delta, should_exit = _resolve_paginated_choice(choice, values)
        if should_exit:
            return selected
        page += page_delta


def _paginate_values(
    values: list[str],
    page: int,
) -> tuple[list[str], PageState]:
    """Compute paginated values and metadata."""
    total_items = len(values)
    total_pages = (total_items + PAGE_SIZE - 1) // PAGE_SIZE if total_items else 1
    page = min(max(page, 0), total_pages - 1)
    start_idx = page * PAGE_SIZE
    end_idx = min(start_idx + PAGE_SIZE, total_items)
    return values[start_idx:end_idx], PageState(
        start_idx=start_idx, page=page, total_pages=total_pages
    )


def _print_paginated_values(
    title: str,
    page_items: list[str],
    state: PageState,
) -> None:
    """Render paginated values and heading."""
    if state.total_pages > 1:
        console.print(f"\n[bold]{title} (Page {state.page + 1}/{state.total_pages}):[/bold]")
    else:
        console.print(f"\n[bold]{title}:[/bold]")
    for index, value in enumerate(page_items):
        display_idx = state.start_idx + index + 1
        console.print(f"{display_idx}. {value}")


def _prompt_paginated_choice(
    page_items: list[str],
    state: PageState,
    prompt_text: str,
) -> str | object:
    """Prompt for paginated selection and navigation."""
    choices = [str(state.start_idx + i + 1) for i in range(len(page_items))]
    extra_options: list[str] = []
    if state.page < state.total_pages - 1:
        console.print("n. Next Page")
        extra_options.append("n")
    if state.page > 0:
        console.print("p. Previous Page")
        extra_options.append("p")

    default_choice = choices[0] if choices else None
    return _prompt_with_back(prompt_text, choices=choices + extra_options, default=default_choice)


def _resolve_paginated_choice(
    choice: str | object,
    values: list[str],
) -> tuple[str | object | None, int, bool]:
    """Resolve paginated selection choice."""
    if choice is BACK_OPTION:
        return BACK_OPTION, 0, True
    if choice == "n":
        return None, 1, False
    if choice == "p":
        return None, -1, False
    if isinstance(choice, str) and choice.isdigit():
        return values[int(choice) - 1], 0, True
    return None, 0, True


def _select_project_report(client_name: str, base_dir: Path) -> str | object | None:
    """Handle interactive project selection for reports."""
    console.print("\n[bold]Project Selection[/bold]")

    projects, archived_projects = _load_report_projects(client_name, base_dir)
    if projects is None or archived_projects is None:
        return None
    if not projects and not archived_projects:
        console.print(
            f"[bold yellow]No projects with session data found for client '{client_name}'."
            "[/bold yellow]"
        )
        return None

    viewing_all = False
    current_list = projects
    page = 0
    while True:
        page_items, page_state = _paginate_values(current_list, page)
        context = ProjectPageContext(
            current_list=current_list,
            archived_projects=archived_projects,
            viewing_all=viewing_all,
        )
        _print_project_page(context, page_items, page_state)
        choice = _prompt_project_page_choice(
            context=context,
            page_items=page_items,
            state=page_state,
        )
        selected, page_delta, should_exit, viewing_all, current_list = _resolve_project_page_choice(
            choice=choice,
            current_list=current_list,
            projects=projects,
            archived_projects=archived_projects,
            viewing_all=viewing_all,
        )
        if should_exit:
            return selected
        page += page_delta


def _load_report_projects(
    client_name: str, base_dir: Path
) -> tuple[list[str] | None, list[str] | None]:
    """Load active and archived projects for report selection."""
    projects: list[str] = []
    archived_projects: list[str] = []
    db_checked = False
    if should_use_database():
        db_checked = True
        try:
            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                db_projects = db_ops.list_projects(client.id)
                projects = sorted([project.name for project in db_projects if project.name])
                db_archived = db_ops.list_archived_projects(client.id)
                archived_projects = sorted(
                    [project.name for project in db_archived if project.name]
                )
        except Exception as e:
            logger.warning(f"Failed to get projects from database: {e}")

    if projects or archived_projects:
        return projects, archived_projects
    if db_checked:
        console.print(
            "[yellow]No active or archived projects found in database "
            "(or database unavailable).[/yellow]"
        )
        if not _confirm_on_new_line(
            "Would you like to check the filesystem for projects?", default=True
        ):
            return None, None

    client_dir = _resolve_client_dir(base_dir, client_name)
    if client_dir.exists():
        projects = [
            directory.name
            for directory in client_dir.iterdir()
            if directory.is_dir() and (directory / "sessions").exists()
        ]
    return projects, archived_projects


def _print_project_page(
    context: ProjectPageContext,
    page_items: list[str],
    state: PageState,
) -> None:
    """Render project selection page."""
    heading = "Available Projects" if context.viewing_all else "Available Active Projects"
    if state.total_pages > 1:
        console.print(
            f"\n[bold]{heading} (Page {state.page + 1}/{state.total_pages}):[/bold]"
        )
    else:
        console.print(f"\n[bold]{heading}:[/bold]")

    if not context.current_list and not context.viewing_all:
        console.print("[dim]No active projects.[/dim]")
    elif not context.current_list and context.viewing_all:
        console.print("[dim]No projects found.[/dim]")

    for index, project in enumerate(page_items):
        display_idx = state.start_idx + index + 1
        suffix = (
            " [dim](Archived)[/dim]"
            if context.viewing_all and project in context.archived_projects
            else ""
        )
        console.print(f"{display_idx}. {project}{suffix}")


def _prompt_project_page_choice(
    *,
    context: ProjectPageContext,
    page_items: list[str],
    state: PageState,
) -> str | object:
    """Prompt for project page selection."""
    choices = [str(state.start_idx + i + 1) for i in range(len(page_items))]
    extra_options: list[str] = []
    console.print("a. All active projects")
    extra_options.append("a")
    if state.page < state.total_pages - 1:
        console.print("n. Next Page")
        extra_options.append("n")
    if state.page > 0:
        console.print("p. Previous Page")
        extra_options.append("p")
    if not context.viewing_all and context.archived_projects:
        console.print(f"r. Show archived projects ({len(context.archived_projects)})")
        extra_options.append("r")
    if context.viewing_all and context.archived_projects:
        console.print("v. Show active projects only")
        extra_options.append("v")

    default_choice = choices[0] if choices else ("r" if "r" in extra_options else "a")
    return _prompt_with_back(
        "Select project number", choices=choices + extra_options, default=default_choice
    )


def _resolve_project_page_choice(
    *,
    choice: str | object,
    current_list: list[str],
    projects: list[str],
    archived_projects: list[str],
    viewing_all: bool,
) -> tuple[str | object | None, int, bool, bool, list[str]]:
    """Resolve project-page selection action."""
    selected: str | object | None = None
    page_delta = 0
    should_exit = False
    next_viewing_all = viewing_all
    next_current_list = current_list

    if choice is BACK_OPTION:
        selected = BACK_OPTION
        should_exit = True
    elif choice == "a":
        selected = ALL_PROJECTS_OPTION
        should_exit = True
    elif choice == "n":
        page_delta = 1
    elif choice == "p":
        page_delta = -1
    elif choice == "r":
        next_viewing_all = True
        next_current_list = projects + archived_projects
    elif choice == "v":
        next_viewing_all = False
        next_current_list = projects
    elif isinstance(choice, str) and choice.isdigit():
        selected = current_list[int(choice) - 1]
        should_exit = True
    else:
        should_exit = True

    return selected, page_delta, should_exit, next_viewing_all, next_current_list


def _select_report_type() -> str | object:
    """Handle interactive selection of report type."""
    console.print("\n[bold]Report Type Selection[/bold]")
    report_type_map = {
        "1": ("Session Report (single session)", "session"),
        "2": ("Daily Report (all sessions from a specific day)", "day"),
        "3": ("Project Report (all sessions from the project)", "project"),
    }
    for key, (label, _) in report_type_map.items():
        console.print(f"{key}. {label}")

    choice = _prompt_with_back(
        "Select report type", choices=list(report_type_map.keys()), default="1"
    )
    if choice is BACK_OPTION:
        return BACK_OPTION  # Go back to project selection
    return report_type_map[choice][1]  # Return 'session', 'day', or 'project'


def _select_all_projects_scope() -> str | object:
    """Handle interactive scope selection for all-project batch reports."""
    console.print("\n[bold]All Projects Scope[/bold]")
    scope_map = {
        "1": ("Today (daily report for each active project)", "today"),
        "2": ("Whole project workflow (full project report for each active project)", "whole"),
    }
    for key, (label, _) in scope_map.items():
        console.print(f"{key}. {label}")

    choice = _prompt_with_back(
        "Select all-project scope",
        choices=list(scope_map.keys()),
        default="1",
    )
    if choice is BACK_OPTION:
        return BACK_OPTION
    return scope_map[choice][1]


def _select_session(
    project_dir: Path, client_name: str | None = None, project_name: str | None = None
) -> str | object | None:
    """Handle interactive selection of a specific session."""
    console.print("\n[bold]Session Selection[/bold]")

    sessions = _load_sessions(project_dir, client_name, project_name)
    if sessions is None:
        return None
    return _select_most_recent_or_list(
        values=sessions,
        item_label="session",
        list_title="Available Sessions",
        select_prompt="Select session number",
    )


def _select_day(
    project_dir: Path, client_name: str | None = None, project_name: str | None = None
) -> str | object | None:
    """Handle interactive selection of a specific day."""
    console.print("\n[bold]Date Selection for Daily Report[/bold]")

    dates = _load_project_dates(project_dir, client_name, project_name, reverse=True)
    if dates is None:
        return None
    return _select_most_recent_or_list(
        values=dates,
        item_label="date",
        list_title="Available Dates",
        select_prompt="Select date number",
    )


def _select_date_range(
    project_dir: Path, client_name: str | None = None, project_name: str | None = None
) -> tuple[str, str] | object | None:
    """Handle interactive selection of a date range for project reports."""
    console.print("\n[bold]Date Range Selection for Project Report[/bold]")

    dates = _load_project_dates(project_dir, client_name, project_name, reverse=False)
    if dates is None:
        return None

    console.print(f"Project contains sessions from {dates[0]} to {dates[-1]}")
    use_range_choice = _prompt_with_back("Specify a date range?", choices=["y", "n"], default="n")

    if use_range_choice is BACK_OPTION:
        return BACK_OPTION  # Go back to report type selection
    if use_range_choice == "n":
        return None  # Indicate use full range

    # Select Start Date
    console.print("\n[bold]Select Start Date:[/bold]")
    for i, date_value in enumerate(dates, 1):
        console.print(f"{i}. {date_value}")
    start_choice = _prompt_with_back(
        "Select start date number",
        choices=[str(i) for i in range(1, len(dates) + 1)],
        default="1",
    )
    if start_choice is BACK_OPTION:
        # If user wants to go back from start date selection, go back to the 'specify range?'
        # question.
        # This requires restructuring the loop or returning a specific signal.
        # For simplicity, let's assume back from here goes back to report type selection.
        return BACK_OPTION

    start_date = dates[int(start_choice) - 1]

    # Select End Date
    later_dates = [d for d in dates if d >= start_date]
    console.print("\n[bold]Select End Date:[/bold]")
    for i, date_value in enumerate(later_dates, 1):
        console.print(f"{i}. {date_value}")
    end_choice = _prompt_with_back(
        "Select end date number",
        choices=[str(i) for i in range(1, len(later_dates) + 1)],
        default=str(len(later_dates)),
    )
    if end_choice is BACK_OPTION:
        # Back from end date selection should ideally go back to start date selection.
        # Again, for simplicity, let's route back to report type. Requires loop restructure for
        # finer control.
        return BACK_OPTION

    end_date = later_dates[int(end_choice) - 1]
    return (start_date, end_date)


def _load_sessions(
    project_dir: Path,
    client_name: str | None,
    project_name: str | None,
) -> list[str] | None:
    """Load sessions from database first, then optionally filesystem."""
    sessions: list[str] = []
    db_checked = False
    if should_use_database() and client_name and project_name:
        db_checked = True
        try:
            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and project.id:
                    db_sessions = db_ops.list_sessions(project.id)
                    sessions = sorted(
                        [session.name for session in db_sessions if session.name], reverse=True
                    )
        except Exception as e:
            logger.warning(f"Failed to get sessions from database: {e}")

    if sessions:
        return sessions
    if db_checked:
        console.print("[yellow]No sessions found in database (or database unavailable).[/yellow]")
        if not _confirm_on_new_line(
            "Would you like to check the filesystem for sessions?", default=True
        ):
            return None

    sessions_dir = project_dir / "sessions"
    if sessions_dir.exists():
        sessions = sorted(
            [directory.name for directory in sessions_dir.iterdir() if directory.is_dir()],
            reverse=True,
        )
    if sessions:
        return sessions

    console.print("[bold yellow]No sessions found.[/bold yellow]")
    return None


def _load_project_dates(
    project_dir: Path,
    client_name: str | None,
    project_name: str | None,
    *,
    reverse: bool,
) -> list[str] | None:
    """Load session dates from database first, then optionally filesystem."""
    dates: set[str] = set()
    db_checked = False
    if should_use_database() and client_name and project_name:
        db_checked = True
        try:
            db_ops = DatabaseOperations()
            client = db_ops.get_client_by_name(client_name) or db_ops.get_client_by_directory(
                client_name
            )
            if client and client.id:
                project = db_ops.get_project_by_name(client.id, project_name)
                if project and project.id:
                    db_sessions = db_ops.list_sessions(project.id)
                    for session in db_sessions:
                        if session.start_time:
                            dates.add(session.start_time.strftime("%Y-%m-%d"))
        except Exception as e:
            logger.warning(f"Failed to get dates from database: {e}")

    if not dates:
        if db_checked:
            console.print("[yellow]No dates found in database (or database unavailable).[/yellow]")
            if not _confirm_on_new_line(
                "Would you like to check the filesystem for dates?", default=True
            ):
                return None
        dates.update(_extract_dates_from_sessions_dir(project_dir / "sessions"))

    sorted_dates = sorted(list(dates), reverse=reverse)
    if sorted_dates:
        return sorted_dates

    console.print("[bold yellow]No sessions with valid dates found.[/bold yellow]")
    return None


def _extract_dates_from_sessions_dir(sessions_dir: Path) -> set[str]:
    """Extract yyyy-mm-dd prefixes from session folder names."""
    dates: set[str] = set()
    if not sessions_dir.exists():
        return dates
    for session in sessions_dir.iterdir():
        if not session.is_dir():
            continue
        date_match = re.match(r"(\d{4}-\d{2}-\d{2})_.*", session.name)
        if date_match:
            dates.add(date_match.group(1))
    return dates


def _select_most_recent_or_list(
    *,
    values: list[str],
    item_label: str,
    list_title: str,
    select_prompt: str,
) -> str | object:
    """Offer most-recent choice, then full list selection."""
    console.print(f"Most recent {item_label}: {values[0]}")
    use_recent_choice = _prompt_with_back(
        f"Use the most recent {item_label}?",
        choices=["y", "n"],
        default="y",
    )
    if use_recent_choice is BACK_OPTION:
        return BACK_OPTION
    if use_recent_choice == "y":
        return values[0]

    console.print(f"\n{list_title}:")
    for index, value in enumerate(values, 1):
        console.print(f"{index}. {value}")

    choice = _prompt_with_back(
        select_prompt,
        choices=[str(i) for i in range(1, len(values) + 1)],
        default="1",
    )
    if choice is BACK_OPTION:
        return BACK_OPTION
    return values[int(choice) - 1]


def _resolve_report_context(
    use_command_line: bool,
    cli_args: dict[str, Any] | None,
) -> ReportSelectionContext | BatchReportSelectionContext | int:
    """Resolve report context for command-line or interactive mode."""
    if use_command_line and cli_args:
        return _prepare_cli_report_context(cli_args)
    return _prepare_interactive_report_context()


def _resolve_output_dir(context: ReportSelectionContext) -> Path:
    """Resolve output directory for generated reports."""
    if context.output_dir:
        return Path(context.output_dir)
    project_dir = _resolve_project_dir(context.base_dir, context.client_name, context.project_name)
    output_dir = project_dir / "reports"
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def _build_optimization_params(
    use_command_line: bool,
    cli_args: dict[str, Any] | None,
) -> dict[str, Any]:
    """Build PDF optimization parameters from settings and CLI overrides."""
    if not should_optimize_pdf():
        return {}

    pdf_settings = get_pdf_optimization_settings()
    if not use_command_line or not cli_args:
        return {
            "quality": pdf_settings["image_quality"],
            "dpi": 150,
            "format": pdf_settings["image_format"],
            "max_dimension": pdf_settings["max_dimension"],
            "use_thumbnails": pdf_settings["use_thumbnails"],
            "thumbnail_size": pdf_settings["thumbnail_size"],
            "compress": pdf_settings["compress_pdf"],
        }

    return {
        "quality": cli_args.get("image_quality") or pdf_settings["image_quality"],
        "dpi": cli_args.get("image_dpi") or 150,
        "format": cli_args.get("image_format") or pdf_settings["image_format"],
        "max_dimension": cli_args.get("max_dimension") or pdf_settings["max_dimension"],
        "use_thumbnails": cli_args.get("thumbnails")
        if cli_args.get("thumbnails") is not None
        else pdf_settings["use_thumbnails"],
        "thumbnail_size": cli_args.get("thumbnail_size") or pdf_settings["thumbnail_size"],
        "compress": not cli_args.get("no_compression")
        if cli_args.get("no_compression") is not None
        else pdf_settings["compress_pdf"],
    }


def _create_report_generator(
    context: ReportSelectionContext,
    output_dir: Path,
    optimization_params: dict[str, Any],
    debug_enabled: bool,
) -> ReportGenerator:
    """Create a configured report generator instance."""
    return ReportGenerator(
        screenshots_dir=str(context.base_dir),
        client_name=context.client_name,
        project_name=context.project_name,
        session_date=context.session_date if context.report_type == "session" else None,
        output_dir=str(output_dir),
        page_size=context.pagesize,
        image_quality=optimization_params.get("quality", 85),
        image_dpi=optimization_params.get("dpi", 150),
        image_format=optimization_params.get("format", "JPEG"),
        max_dimension=optimization_params.get("max_dimension", 1500),
        use_thumbnails=optimization_params.get("use_thumbnails", False),
        thumbnail_size=optimization_params.get("thumbnail_size", 800),
        compress_pdf=optimization_params.get("compress", True),
        report_type=context.report_type,
        specific_date=context.specific_date if context.report_type == "day" else None,
        date_range=context.date_range if context.report_type == "project" else None,
        debug=debug_enabled,
    )


def _generate_pdf_report(
    generator: ReportGenerator,
    context: ReportSelectionContext,
) -> Path | None:
    """Generate PDF for selected report type."""
    if context.report_type == "session" and not context.session_date:
        console.print("[bold red]Error: Session date is missing for session report.[/bold red]")
        return None

    console.print("Loading client and session data...")
    generator.load_client_info()
    if context.report_type == "session":
        generator.load_session()
        return _generate_pdf_with_progress(generate_single_session_pdf, generator)

    generator.setup_multi_session_report()
    return _generate_pdf_with_progress(generate_multi_session_pdf, generator)


def _generate_pdf_with_progress(
    generator_fn: Any,
    generator: ReportGenerator,
) -> Path:
    """Run PDF generation with spinner progress."""
    console.print("[bold]Generating PDF report...[/bold]")
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Processing...", total=None)
        return generator_fn(generator)


def _open_pdf_file(pdf_file_path: Path) -> None:
    """Open generated PDF in the default OS application."""
    system = platform.system()
    file_path_str = str(pdf_file_path)
    if system == "Darwin":
        subprocess.run(["open", file_path_str], check=False)
        return
    if system == "Linux":
        subprocess.run(["xdg-open", file_path_str], check=False)
        return
    if system == "Windows":
        subprocess.Popen(["start", "", file_path_str], shell=True)
        return
    console.print(f"[yellow]Unsupported platform for opening files: {system}[/yellow]")


def _prompt_open_pdf(pdf_file_path: Path) -> None:
    """Prompt to open PDF and handle errors."""
    open_choice = _prompt_with_back(
        "\nWould you like to open the PDF?", choices=["y", "n"], default="y"
    )
    if open_choice is BACK_OPTION:
        console.print("[yellow]Not opening PDF.[/yellow]")
        return
    if open_choice != "y":
        return
    try:
        _open_pdf_file(pdf_file_path)
    except Exception as e:
        console.print(f"[red]Failed to open PDF: {e}[/red]")


def _prompt_notes_and_parse(
    generator: ReportGenerator, *, suppress_errors: bool
) -> list[str] | None:
    """Prompt for optional email notes with preview and confirmation."""
    notes_input = ""
    prompt_text = "Add notes (use /n, \\n or <br> for new lines; use /b for bullets)"
    while True:
        if suppress_errors:
            try:
                notes_input = _prompt_on_new_line(prompt_text, default=notes_input)
            except Exception:
                return None
        else:
            notes_input = _prompt_on_new_line(prompt_text, default=notes_input)

        parsed_notes = _parse_notes_lines(notes_input) if notes_input else None
        if parsed_notes:
            console.print("[dim]Current notes preview:[/dim]")
            for line in parsed_notes:
                console.print(f"[dim]{line}[/dim]")
        else:
            console.print("[dim]No notes will be included.[/dim]")

        action = _prompt_on_new_line(
            "Use these notes? (y=yes, e=edit, c=clear)",
            choices=["y", "e", "c"],
            default="y",
        )
        if action == "y":
            if notes_input:
                try:
                    generator.log_entry(
                        f"Report email notes (raw input): {notes_input}",
                        terminal_message="",
                    )
                except Exception:
                    pass
            return parsed_notes
        if action == "c":
            return None


def _extract_hours_minutes(duration_text: str) -> tuple[int, int]:
    """Extract hour/minute values from session duration text."""
    hours_match = re.search(r"(\d+) hour", duration_text)
    minutes_match = re.search(r"(\d+) minute", duration_text)
    hours = int(hours_match.group(1)) if hours_match else 0
    minutes = int(minutes_match.group(1)) if minutes_match else 0
    return hours, minutes


def _build_report_meta(
    generator: ReportGenerator, context: ReportSelectionContext
) -> dict[str, Any] | None:
    """Build report metadata for email templates."""
    try:
        if context.report_type == "session" and generator.session_log:
            duration_text = generator.session_log.session_duration or ""
            hours, minutes = _extract_hours_minutes(duration_text)
            start_raw = generator.session_log.session_start or ""
            end_raw = generator.session_log.session_end or ""
            date_only = start_raw.split(" ")[0] if start_raw else (context.session_date or "")
            return {
                "date": date_only,
                "start_time": start_raw.split(" ")[1][:5] if start_raw else "",
                "end_time": end_raw.split(" ")[1][:5] if end_raw else "",
                "hours": hours,
                "minutes": minutes,
            }

        if context.report_type not in {"day", "project"} or not generator.multi_sessions:
            return None

        stats = generator.multi_sessions.get_combined_stats()
        total_seconds = (
            int(stats["total_duration"].total_seconds()) if stats.get("total_duration") else 0
        )
        report_meta: dict[str, Any] = {
            "date": context.specific_date or "",
            "session_count": stats.get("total_sessions", 0),
            "hours": total_seconds // 3600,
            "minutes": (total_seconds % 3600) // 60,
        }
        if context.report_type == "project":
            _add_project_date_range_meta(report_meta, context.date_range, stats)
        return report_meta
    except Exception:
        return None


def _add_project_date_range_meta(
    report_meta: dict[str, Any],
    date_range: tuple[str, str] | None,
    stats: dict[str, Any],
) -> None:
    """Populate project report date-range metadata."""
    if date_range:
        report_meta["range_start"] = date_range[0]
        report_meta["range_end"] = date_range[1]
        return

    range_start = stats.get("earliest_session_str") or ""
    range_end = stats.get("latest_session_str") or ""
    if range_start:
        report_meta["range_start"] = range_start.split(" ")[0]
    if range_end:
        report_meta["range_end"] = range_end.split(" ")[0]


def _build_cli_email_config(
    cli_args: dict[str, Any], email_settings: dict[str, Any]
) -> EmailConfig:
    """Resolve CLI email config using flags with settings fallback."""
    sender = cli_args.get("sender") or ""
    password = cli_args.get("password") or ""
    smtp = cli_args.get("smtp") or ""
    sender_name = cli_args.get("sender_name") or ""
    username = cli_args.get("username") or sender
    security = cli_args.get("security") or "TLS"
    recipient_type = cli_args.get("recipient_type") or "TO"
    port = cli_args.get("port") or 587
    recipients = (
        [email.strip() for email in cli_args.get("recipients").split(",")]
        if cli_args.get("recipients")
        else []
    )

    use_settings_fallback = not all([sender, password, smtp])
    settings_enabled = bool(email_settings and email_settings.get("enabled", False))
    if use_settings_fallback and settings_enabled:
        sender = sender or email_settings.get("sender_email", "")
        password = password or email_settings.get("password", "")
        smtp = smtp or email_settings.get("smtp_server", "")
        port = port or email_settings.get("smtp_port", 587)
        sender_name = sender_name or email_settings.get("sender_name", "")
        username = username or email_settings.get("username", sender)
        security = security or email_settings.get("connection_security", "TLS")

    return EmailConfig(
        sender=sender,
        password=password,
        smtp=smtp,
        port=port,
        sender_name=sender_name,
        username=username,
        security=security,
        recipients=recipients,
        recipient_type=recipient_type,
        debug_enabled=bool(cli_args.get("debug", False)),
    )


def _build_interactive_email_config(email_settings: dict[str, Any]) -> EmailConfig:
    """Resolve interactive email config from app settings."""
    sender = email_settings.get("sender_email", "")
    return EmailConfig(
        sender=sender,
        password=email_settings.get("password", ""),
        smtp=email_settings.get("smtp_server", ""),
        port=email_settings.get("smtp_port", 587),
        sender_name=email_settings.get("sender_name", ""),
        username=email_settings.get("username", sender),
        security=email_settings.get("connection_security", "TLS"),
        recipients=email_settings.get("default_recipients", []) or [],
        recipient_type=email_settings.get("recipient_type", "TO") or "TO",
        debug_enabled=False,
    )


def _build_email_session_date(context: ReportSelectionContext) -> str:
    """Resolve session-date field for email template."""
    return (
        context.session_date
        or context.specific_date
        or (context.date_range[0] if context.date_range else "")
    )


def _send_report_email(
    pdf_file_path: Path,
    generator: ReportGenerator,
    context: ReportSelectionContext,
    config: EmailConfig,
    extra_lines: list[str] | None,
) -> bool:
    """Send report email with resolved settings and metadata."""
    return send_email(
        pdf_file=pdf_file_path,
        client_info=generator.client_info.dict() if generator.client_info else {},
        project_name=context.project_name,
        session_date=_build_email_session_date(context),
        sender_email=config.sender,
        password=config.password,
        smtp_server=config.smtp,
        smtp_port=config.port,
        sender_name=config.sender_name,
        username=config.username,
        connection_security=config.security,
        recipients=config.recipients,
        recipient_type=config.recipient_type,
        debug=config.debug_enabled,
        report_type=context.report_type,
        extra_body_lines=extra_lines,
        report_meta=_build_report_meta(generator, context),
    )


def _print_email_result(success: bool, generator: ReportGenerator, recipients: list[str]) -> None:
    """Print email success/failure and recipient list."""
    if not success:
        console.print("[red]Failed to send email. Please check your settings.[/red]")
        return

    console.print("[green]Email sent successfully![/green]")
    recipients_to_show: list[str] = []
    if generator.client_info and generator.client_info.contact_email:
        recipients_to_show.append(generator.client_info.contact_email)
    if recipients:
        recipients_to_show.extend(recipients)
    if recipients_to_show:
        console.print(f"Email sent to {', '.join(recipients_to_show)}")


def _run_cli_email_flow(
    pdf_file_path: Path,
    generator: ReportGenerator,
    context: ReportSelectionContext,
    cli_args: dict[str, Any],
) -> None:
    """Handle command-line email send flow."""
    reload_settings()
    email_settings = get_email_settings()
    config = _build_cli_email_config(cli_args, email_settings)
    extra_lines = _prompt_notes_and_parse(generator, suppress_errors=True)
    success = _send_report_email(
        pdf_file_path,
        generator,
        context,
        config,
        extra_lines,
    )
    _print_email_result(success, generator, config.recipients)


def _show_interactive_email_recipient_info(
    generator: ReportGenerator,
    config: EmailConfig,
) -> None:
    """Print recipient context for interactive email flow."""
    if generator.client_info and generator.client_info.contact_email:
        console.print(
            f"[bold]Primary recipient:[/bold] {generator.client_info.contact_email} "
            "(from client settings)"
        )
    else:
        console.print("[yellow]Warning: No client email found in client settings.[/yellow]")
    if config.recipients:
        console.print(
            f"[green]Automatically including default recipients as {config.recipient_type}[/green]"
        )


def _prompt_interactive_email_choice(pdf_file_path: Path) -> str:
    """Prompt interactive email choice with back-to-open behavior."""
    while True:
        email_choice = _prompt_with_back(
            "\nWould you like to email this report?",
            choices=["y", "n"],
            default="n",
        )
        if email_choice is not BACK_OPTION:
            return email_choice
        _prompt_open_pdf(pdf_file_path)


def _run_interactive_email_flow(
    pdf_file_path: Path,
    generator: ReportGenerator,
    context: ReportSelectionContext,
) -> None:
    """Handle interactive email send flow."""
    email_choice = _prompt_interactive_email_choice(pdf_file_path)
    if email_choice != "y":
        return

    reload_settings()
    email_settings = get_email_settings()
    if not email_settings.get("enabled", False):
        console.print(
            "[yellow]Email settings not configured. Please configure email settings first.[/yellow]"
        )
        return

    console.print("[green]Using email settings from application configuration.[/green]")
    config = _build_interactive_email_config(email_settings)
    _show_interactive_email_recipient_info(generator, config)
    extra_lines = _prompt_notes_and_parse(generator, suppress_errors=False)
    success = _send_report_email(
        pdf_file_path,
        generator,
        context,
        config,
        extra_lines,
    )
    _print_email_result(success, generator, config.recipients)


def _build_batch_project_context(
    batch_context: BatchReportSelectionContext,
    project_name: str,
) -> ReportSelectionContext:
    """Build a per-project context from a batch selection context."""
    return ReportSelectionContext(
        base_dir=batch_context.base_dir,
        client_name=batch_context.client_name,
        project_name=project_name,
        report_type=batch_context.report_type,
        session_date=None,
        specific_date=batch_context.specific_date,
        date_range=batch_context.date_range,
        output_dir=batch_context.output_dir,
        pagesize=batch_context.pagesize,
    )


def _generate_batch_reports(
    batch_context: BatchReportSelectionContext,
    optimization_params: dict[str, Any],
    debug_enabled: bool,
) -> tuple[list[GeneratedProjectReport], list[tuple[str, str]]]:
    """Generate one report per project for an all-project batch run."""
    generated_reports: list[GeneratedProjectReport] = []
    failed_reports: list[tuple[str, str]] = []

    for project_name in batch_context.project_names:
        project_context = _build_batch_project_context(batch_context, project_name)
        try:
            output_dir = _resolve_output_dir(project_context)
            generator = _create_report_generator(
                project_context,
                output_dir,
                optimization_params,
                debug_enabled=debug_enabled,
            )
            pdf_file_path = _generate_pdf_report(generator, project_context)
            if not pdf_file_path:
                failed_reports.append((project_name, "Failed to generate PDF report."))
                continue
            generated_reports.append(
                GeneratedProjectReport(
                    project_name=project_name,
                    pdf_file_path=pdf_file_path,
                    generator=generator,
                    context=project_context,
                    report_meta=_build_report_meta(generator, project_context),
                )
            )
        except Exception as exc:
            logger.error(
                "Batch report generation failed for project '%s': %s",
                project_name,
                exc,
                exc_info=True,
            )
            failed_reports.append((project_name, str(exc)))

    return generated_reports, failed_reports


def _print_batch_generation_summary(
    generated_reports: list[GeneratedProjectReport],
    failed_reports: list[tuple[str, str]],
) -> None:
    """Print all-project batch generation results."""
    console.print(
        f"\n[bold]Batch generation summary:[/bold] "
        f"{len(generated_reports)} succeeded, {len(failed_reports)} failed."
    )
    if generated_reports:
        console.print("[green]Generated reports:[/green]")
        for report in generated_reports:
            console.print(f"- {report.project_name}: {report.pdf_file_path}")
    if failed_reports:
        console.print("[yellow]Projects with generation failures:[/yellow]")
        for project_name, error in failed_reports:
            console.print(f"- {project_name}: {error}")


def _run_batch_email_flow(generated_reports: list[GeneratedProjectReport]) -> None:
    """Offer and execute a single bulk-send action for generated batch reports."""
    if not generated_reports:
        return

    email_choice = _prompt_with_back(
        "\nWould you like to email all generated reports?",
        choices=["y", "n"],
        default="n",
    )
    if email_choice is BACK_OPTION or email_choice != "y":
        return

    reload_settings()
    email_settings = get_email_settings()
    if not email_settings.get("enabled", False):
        console.print(
            "[yellow]Email settings not configured. Please configure email settings first.[/yellow]"
        )
        return

    console.print("[green]Using email settings from application configuration.[/green]")
    config = _build_interactive_email_config(email_settings)
    _show_interactive_email_recipient_info(generated_reports[0].generator, config)
    batch_items = _build_batch_email_items(generated_reports)
    success = send_batch_email(
        client_info=generated_reports[0].generator.client_info.dict()
        if generated_reports[0].generator.client_info
        else {},
        reports=batch_items,
        sender_email=config.sender,
        password=config.password,
        smtp_server=config.smtp,
        smtp_port=config.port,
        sender_name=config.sender_name,
        username=config.username,
        connection_security=config.security,
        recipients=config.recipients,
        recipient_type=config.recipient_type,
        debug=config.debug_enabled,
    )
    if success:
        console.print("[green]Batch email sent successfully![/green]")
    else:
        console.print("[red]Failed to send batch email. Please check your settings.[/red]")


def _build_batch_email_items(
    generated_reports: list[GeneratedProjectReport],
) -> list[BatchEmailProjectReport]:
    """Build batch-email payload and prompt per-project notes."""
    batch_items: list[BatchEmailProjectReport] = []
    for report in generated_reports:
        notes_lines = _prompt_project_notes_lines(report.project_name)
        batch_items.append(
            BatchEmailProjectReport(
                pdf_file=report.pdf_file_path,
                project_name=report.project_name,
                report_type=report.context.report_type,
                session_date=_build_email_session_date(report.context),
                report_meta=report.report_meta,
                notes_lines=notes_lines,
            )
        )
    return batch_items


def _prompt_project_notes_lines(project_name: str) -> list[str] | None:
    """Prompt notes for one project with review/edit/clear choices."""
    console.print(f"\n[bold]Optional notes for {project_name}[/bold]")
    notes_input = ""
    while True:
        notes_input = _prompt_on_new_line(
            "Add notes for this project (use /n, \\n or <br>; use /b for bullets)",
            default=notes_input,
        )
        parsed_notes = _parse_notes_lines(notes_input) if notes_input else None

        if parsed_notes is not None:
            console.print("[dim]Current notes preview:[/dim]")
            for line in parsed_notes:
                console.print(f"[dim]{line}[/dim]")
        else:
            console.print("[dim]No notes will be included for this project.[/dim]")

        action = _prompt_on_new_line(
            "Use these notes? (y=yes, e=edit, c=clear)",
            choices=["y", "e", "c"],
            default="y",
        )
        if action == "y":
            return parsed_notes
        if action == "c":
            return None


def _prompt_open_batch_pdfs(generated_reports: list[GeneratedProjectReport]) -> None:
    """Prompt once and open all generated batch PDFs."""
    if not generated_reports:
        return
    open_choice = _prompt_with_back(
        "\nWould you like to open all generated PDFs?",
        choices=["y", "n"],
        default="n",
    )
    if open_choice is BACK_OPTION or open_choice != "y":
        return
    for report in generated_reports:
        try:
            _open_pdf_file(report.pdf_file_path)
        except Exception as e:
            console.print(f"[red]Failed to open PDF for {report.project_name}: {e}[/red]")


def _run_batch_report_generation_flow(
    batch_context: BatchReportSelectionContext,
    optimization_params: dict[str, Any],
    debug_enabled: bool,
    use_command_line: bool,
) -> int:
    """Run interactive all-project batch generation flow."""
    scope_label = (
        "today (daily reports)"
        if batch_context.batch_scope == "today"
        else "whole project workflow"
    )
    console.print(
        f"\n[bold]Generating reports for all active projects ({scope_label})...[/bold]"
    )
    generated_reports, failed_reports = _generate_batch_reports(
        batch_context,
        optimization_params,
        debug_enabled,
    )
    _print_batch_generation_summary(generated_reports, failed_reports)
    if not generated_reports:
        console.print("[bold red]No reports were generated successfully.[/bold red]")
        return 1
    if not use_command_line:
        _prompt_open_batch_pdfs(generated_reports)
        _run_batch_email_flow(generated_reports)
    return _finalize_interactive_run(use_command_line)


def _finalize_interactive_run(use_command_line: bool) -> int:
    """Finalize interactive mode by asking whether to return to menu."""
    if use_command_line:
        return 0
    console.print("\n[bold]Report generation complete![/bold]")
    return_choice = _prompt_with_back(
        "Would you like to return to the main menu?",
        choices=["y", "n"],
        default="y",
    )
    if return_choice is BACK_OPTION:
        console.print("[yellow]Exiting ScreenShooter. Goodbye![/yellow]")
        return 0
    if return_choice == "n":
        console.print("\nExiting ScreenShooter. Goodbye!")
        return 0
    return 1


def interactive_report_generation(
    use_command_line: bool = False,
    cli_args: dict[str, Any] | None = None,
) -> int:
    """Interactive report generation interface with back functionality."""
    console.print("[bold]PDF Report Generator Setup[/bold]")
    console.print("==========================")

    context = _resolve_report_context(use_command_line, cli_args)
    if isinstance(context, int):
        return context

    try:
        optimization_params = _build_optimization_params(use_command_line, cli_args)
        debug_enabled = bool(cli_args.get("debug") if cli_args else False)

        if isinstance(context, BatchReportSelectionContext):
            return _run_batch_report_generation_flow(
                batch_context=context,
                optimization_params=optimization_params,
                debug_enabled=debug_enabled,
                use_command_line=use_command_line,
            )

        output_dir = _resolve_output_dir(context)
        generator = _create_report_generator(
            context,
            output_dir,
            optimization_params,
            debug_enabled=debug_enabled,
        )
        pdf_file_path = _generate_pdf_report(generator, context)
        if not pdf_file_path:
            console.print("[bold red]Failed to generate PDF report.[/bold red]")
            return 1

        console.print(
            f"[bold green]PDF report generated successfully:[/bold green]\n{pdf_file_path}"
        )
        if not use_command_line:
            _prompt_open_pdf(pdf_file_path)

        if use_command_line and cli_args and cli_args.get("email"):
            _run_cli_email_flow(pdf_file_path, generator, context, cli_args)
        elif not use_command_line:
            _run_interactive_email_flow(pdf_file_path, generator, context)

        return _finalize_interactive_run(use_command_line)
    except Exception as e:
        logger.error(f"Error generating report: {e}", exc_info=True)
        console.print(f"[bold red]An error occurred during report generation: {e}[/bold red]")
        return 1


@click.command()
@click.option("--dir", help="Path to screenshots directory (default: use from settings)")
@click.option("--client", help="Client name")
@click.option("--project", help="Project name")
@click.option(
    "--session",
    help="Session date (format: YYYY-MM-DD_HH-MM-SS), uses most recent if not specified",
)
@click.option("--output", help="Output directory for the PDF report")
@click.option(
    "--pagesize",
    type=click.Choice(["A4", "letter"]),
    help="PDF page size (overrides client preference)",
)
@click.option(
    "--report-type",
    type=click.Choice(["session", "day", "project"]),
    default="session",
    help="Report type: single session, day-based, or project-based",
)
@click.option("--date", help="Specific date for day reports (format: YYYY-MM-DD)")
@click.option("--start-date", help="Start date for project reports (format: YYYY-MM-DD)")
@click.option("--end-date", help="End date for project reports (format: YYYY-MM-DD)")
@click.option("--email", is_flag=True, help="Send PDF report by email")
@click.option("--sender", help="Sender email address")
@click.option("--sender-name", help="Sender display name")
@click.option("--username", help="SMTP username (if different from sender email)")
@click.option("--password", help="Sender email password")
@click.option("--smtp", help="SMTP server address")
@click.option("--port", type=int, default=587, help="SMTP server port")
@click.option(
    "--security",
    type=click.Choice(["TLS", "SSL", "None"]),
    default="TLS",
    help="Connection security",
)
@click.option("--recipients", help="Additional recipients (comma-separated)")
@click.option(
    "--recipient-type",
    type=click.Choice(["TO", "CC", "BCC"]),
    default="TO",
    help="Type for additional recipients",
)
@click.option("--image-quality", type=int, help="Image quality (1-100, lower = smaller file)")
@click.option("--image-dpi", type=int, default=150, help="Image DPI resolution")
@click.option(
    "--image-format", type=click.Choice(["JPEG", "PNG", "WebP"]), help="Image format in PDF"
)
@click.option("--max-dimension", type=int, help="Maximum image dimension (width or height)")
@click.option("--thumbnails", is_flag=True, help="Use thumbnails instead of full-size images")
@click.option("--thumbnail-size", type=int, help="Thumbnail size when --thumbnails is used")
@click.option("--no-compression", is_flag=True, help="Disable PDF compression")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def main(**cli_args: Any):
    """Generate PDF reports from screenshot sessions."""
    client = cli_args.get("client")
    project = cli_args.get("project")
    if not any([client, project]):  # If no options are provided, use interactive mode
        return interactive_report_generation()

    # Use command line mode, but leverage the same interactive function code
    return interactive_report_generation(use_command_line=True, cli_args=cli_args)


if __name__ == "__main__":
    import sys

    sys.exit(main())
