#!/usr/bin/env python3
"""Utility functions for PDF generation, re-exporting from report_pdf_helper."""

import json
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_utils")


def _load_existing_relocations(relocation_log_path, report_generator):
    """Load relocation records from disk when present."""
    if not relocation_log_path.exists():
        return []

    try:
        with open(relocation_log_path) as f:
            return json.load(f)
    except Exception as e:
        report_generator.log_entry(f"Error reading existing relocation log: {e}", level="warning")
        return []


def _build_existing_lookup(existing_relocations):
    """Build lookup table keyed by original path."""
    lookup = {}
    for entry in existing_relocations:
        orig_path = entry.get("original_path")
        if orig_path:
            lookup[orig_path] = entry
    return lookup


def _merge_relocations(existing_relocations, existing_lookup, relocation_log):
    """Merge relocation entries and return merged/new/updated lists."""
    merged_relocations = existing_relocations.copy()
    new_relocations = []
    updated_relocations = []

    for entry in relocation_log:
        if entry.get("from_cache"):
            continue

        orig_path = entry.get("original_path")
        if orig_path in existing_lookup:
            existing_entry = existing_lookup[orig_path]
            if existing_entry.get("found_path") != entry.get("found_path"):
                for key, value in entry.items():
                    existing_entry[key] = value
                updated_relocations.append(entry)
            continue

        merged_relocations.append(entry)
        new_relocations.append(entry)

    return merged_relocations, new_relocations, updated_relocations


def _log_relocation_changes(report_generator, new_relocations, updated_relocations):
    """Log relocation updates when file data changed."""
    if new_relocations and updated_relocations:
        new_count = len(new_relocations)
        updated_count = len(updated_relocations)
        report_generator.log_entry(
            f"Found {new_count} new relocated images and updated {updated_count} entries",
            f"[yellow]Found {new_count} new relocated images and updated "
            f"{updated_count} existing entries[/yellow]",
            level="info",
        )
        return

    if new_relocations:
        new_count = len(new_relocations)
        report_generator.log_entry(
            f"Found {new_count} new relocated images",
            f"[yellow]Found {new_count} new relocated images[/yellow]",
            level="info",
        )
        return

    updated_count = len(updated_relocations)
    report_generator.log_entry(
        f"Updated {updated_count} existing relocation entries",
        f"[yellow]Updated {updated_count} existing relocation entries[/yellow]",
        level="info",
    )


def _log_relocation_cache_usage(report_generator, relocation_log):
    """Log cache usage when relocation file is unchanged."""
    from_cache_count = sum(1 for r in relocation_log if r.get("from_cache", False))
    if from_cache_count > 0:
        report_generator.log_entry(
            f"Used existing image relocation data for {from_cache_count} images",
            f"[blue]Used existing image relocation data for {from_cache_count} images[/blue]",
            level="info",
        )
        return

    report_generator.log_entry(
        "No image relocations were needed",
        "[green]No image relocations were needed[/green]",
        level="info",
    )


def handle_image_relocations(report_generator, relocation_log):
    """Handle image relocations by smartly merging with existing data and updating logs.

    Args:
        report_generator: The ReportGenerator instance
        relocation_log: List of relocation information entries

    Returns:
        bool: True if changes were saved to the relocation log, False if only cached data was used
    """
    relocation_log_path = report_generator.project_dir / "image_relocation_log.json"
    existing_relocations = _load_existing_relocations(relocation_log_path, report_generator)
    existing_lookup = _build_existing_lookup(existing_relocations)
    merged_relocations, new_relocations, updated_relocations = _merge_relocations(
        existing_relocations,
        existing_lookup,
        relocation_log,
    )

    # Only write to file if there are changes
    if new_relocations or updated_relocations:
        with open(relocation_log_path, "w") as f:
            json.dump(merged_relocations, f, indent=4)

        _log_relocation_changes(report_generator, new_relocations, updated_relocations)
        return True

    _log_relocation_cache_usage(report_generator, relocation_log)
    return False
