#!/usr/bin/env python3
"""Multi-session report handling for ScreenShooter Mac."""

import logging
import re
import traceback
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from screenshooter.modules.reports.pdf.models import SessionLog

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("multi_session_report")


class MultiSessionReport:
    """Class to handle multiple screenshot sessions for day or project based reports.

    This class loads and organizes multiple session logs for generating comprehensive reports
    across days or for an entire project.
    """

    def __init__(
        self,
        client_name: str,
        project_name: str,
        sessions_dir: Path,
        report_type: str = "day",  # "day" or "project"
        **options: object,
    ) -> None:
        specific_date = options.get("specific_date")
        date_range = options.get("date_range")
        debug = bool(options.get("debug", False))
        self.client_name = client_name
        self.project_name = project_name
        self.sessions_dir = sessions_dir
        self.report_type = report_type
        self.specific_date = specific_date if isinstance(specific_date, str) else None
        self.date_range = date_range if isinstance(date_range, tuple) else None
        self.debug = debug

        # Initialize logger
        self.logger = logging.getLogger("multi_session_report")
        if debug:
            self.logger.setLevel(logging.DEBUG)

        # Data structures to organize sessions
        self.sessions_by_day = defaultdict(
            list
        )  # Dict mapping YYYY-MM-DD to list of session directories
        self.session_logs = {}  # Dict mapping session_name to SessionLog object

        # Statistics
        self.total_screenshots = 0
        self.total_notes = 0
        self.total_duration = timedelta()
        self.earliest_session = None
        self.latest_session = None

        self.logger.debug(f"Initialized MultiSessionReport for {client_name}/{project_name}")

    def load_session_logs(self) -> None:
        """Load all relevant session logs based on report type and date criteria."""
        self.logger.debug(f"Loading session logs for {self.report_type} report")
        self._ensure_sessions_dir_exists()
        session_dirs = self._list_session_dirs()
        self._collect_sessions_by_day(session_dirs)
        self._load_grouped_session_logs()
        self.logger.debug(
            f"Loaded {len(self.session_logs)} session logs across {len(self.sessions_by_day)} days"
        )

    def _ensure_sessions_dir_exists(self) -> None:
        """Validate session directory exists before scanning."""
        if not self.sessions_dir.exists():
            self.logger.error(f"Sessions directory not found: {self.sessions_dir}")
            raise FileNotFoundError(f"Sessions directory not found: {self.sessions_dir}")

    def _list_session_dirs(self) -> list[Path]:
        """List candidate session directories."""
        session_dirs = [d for d in self.sessions_dir.iterdir() if d.is_dir()]
        self.logger.debug(f"Found {len(session_dirs)} total session directories")
        return session_dirs

    def _collect_sessions_by_day(self, session_dirs: list[Path]) -> None:
        """Group filtered sessions by day and sort them chronologically."""
        if self.report_type == "day":
            self._collect_day_report_sessions(session_dirs)
        elif self.report_type == "project":
            self._collect_project_report_sessions(session_dirs)
        self._sort_grouped_sessions()

    def _collect_day_report_sessions(self, session_dirs: list[Path]) -> None:
        """Collect sessions for a single day report."""
        target_date = self.specific_date or datetime.now().strftime("%Y-%m-%d")
        self.logger.debug(f"Filtering sessions for date: {target_date}")
        for session_dir in session_dirs:
            session_date = self._extract_session_date(session_dir)
            if session_date == target_date:
                self.sessions_by_day[target_date].append(session_dir)

    def _collect_project_report_sessions(self, session_dirs: list[Path]) -> None:
        """Collect sessions for a project report, optionally by date range."""
        start_date, end_date = self._resolve_date_range()
        for session_dir in session_dirs:
            self._append_project_session_if_valid(session_dir, start_date, end_date)

    def _resolve_date_range(self) -> tuple[str | None, str | None]:
        """Resolve and log active date range filter."""
        if not self.date_range:
            return None, None

        start_date, end_date = self.date_range
        self.logger.debug(f"Filtering sessions for date range: {start_date} to {end_date}")
        return start_date, end_date

    def _append_project_session_if_valid(
        self,
        session_dir: Path,
        start_date: str | None,
        end_date: str | None,
    ) -> None:
        """Append project session when directory parses and date matches range."""
        try:
            session_date = self._extract_session_date(session_dir)
            if not self._is_date_in_range(session_date, start_date, end_date):
                return
            self.sessions_by_day[session_date].append(session_dir)
        except Exception as e:
            self.logger.warning(f"Error processing session directory {session_dir.name}: {e}")

    def _extract_session_date(self, session_dir: Path) -> str:
        """Extract YYYY-MM-DD date token from a session directory name."""
        return session_dir.name.split("_", 1)[0]

    def _is_date_in_range(
        self,
        session_date: str,
        start_date: str | None,
        end_date: str | None,
    ) -> bool:
        """Check whether a session date passes optional range bounds."""
        if start_date and session_date < start_date:
            return False
        if end_date and session_date > end_date:
            return False
        return True

    def _sort_grouped_sessions(self) -> None:
        """Sort grouped sessions chronologically within each day bucket."""
        for day, sessions in self.sessions_by_day.items():
            self.sessions_by_day[day] = sorted(sessions, key=lambda d: d.name)

    def _load_grouped_session_logs(self) -> None:
        """Load all grouped session logs and aggregate report statistics."""
        for sessions in self.sessions_by_day.values():
            for session_dir in sessions:
                self._load_single_session_log(session_dir)

    def _load_single_session_log(self, session_dir: Path) -> None:
        """Load one session.log file and accumulate statistics."""
        session_name = session_dir.name
        log_file = session_dir / "session.log"
        if not log_file.exists():
            self.logger.warning(f"Session log file not found: {log_file}")
            return

        try:
            session_log = SessionLog(log_file)
            self.session_logs[session_name] = session_log
            self._update_aggregate_stats(session_log)
        except Exception as e:
            self.logger.error(f"Error loading session log {log_file}: {e}")
            if self.debug:
                self.logger.debug(traceback.format_exc())

    def _update_aggregate_stats(self, session_log: SessionLog) -> None:
        """Update aggregate counters and boundaries from one session log."""
        self.total_screenshots += len(session_log.screenshots)
        self.total_notes += self._count_session_notes(session_log)
        self._add_session_duration(session_log)
        self._update_session_boundaries(session_log)

    def _count_session_notes(self, session_log: SessionLog) -> int:
        """Count all note-like entities included in report totals."""
        note_count = len(session_log.notes)
        note_count += len(getattr(session_log, "captions", {}))
        note_count += len(getattr(session_log, "set_captions", {}))
        if session_log.session_note:
            note_count += 1
        note_count += sum(
            1
            for event in getattr(session_log, "chronological_events", [])
            if event.get("type") == "caption"
        )
        return note_count

    def _add_session_duration(self, session_log: SessionLog) -> None:
        """Parse and add session duration when present."""
        if not session_log.session_duration:
            return

        try:
            self.total_duration += self._parse_duration_string(session_log.session_duration)
        except Exception as e:
            if self.debug:
                self.logger.debug(f"Failed to parse duration '{session_log.session_duration}': {e}")

    def _parse_duration_string(self, session_duration: str) -> timedelta:
        """Parse textual duration into timedelta."""
        hour_match = re.search(r"(\d+) hour", session_duration)
        minute_match = re.search(r"(\d+) minute", session_duration)
        second_match = re.search(r"(\d+) second", session_duration)
        hours = int(hour_match.group(1)) if hour_match else 0
        minutes = int(minute_match.group(1)) if minute_match else 0
        seconds = int(second_match.group(1)) if second_match else 0
        return timedelta(hours=hours, minutes=minutes, seconds=seconds)

    def _update_session_boundaries(self, session_log: SessionLog) -> None:
        """Update earliest and latest known session timestamps."""
        self._update_earliest_session(session_log.session_start)
        self._update_latest_session(session_log.session_end)

    def _update_earliest_session(self, session_start: str | None) -> None:
        """Update earliest session boundary when applicable."""
        if not session_start:
            return

        session_datetime = datetime.strptime(session_start, "%Y-%m-%d %H:%M:%S")
        if not self.earliest_session or session_datetime < self.earliest_session:
            self.earliest_session = session_datetime

    def _update_latest_session(self, session_end: str | None) -> None:
        """Update latest session boundary when applicable."""
        if not session_end:
            return

        session_end_datetime = datetime.strptime(session_end, "%Y-%m-%d %H:%M:%S")
        if not self.latest_session or session_end_datetime > self.latest_session:
            self.latest_session = session_end_datetime

    def get_combined_stats(self) -> dict[str, Any]:
        """Get combined statistics for all loaded sessions."""
        # Format timestamps for display
        earliest_session_str = ""
        latest_session_str = ""

        if self.earliest_session:
            earliest_session_str = self.earliest_session.strftime("%Y-%m-%d %H:%M:%S")

        if self.latest_session:
            latest_session_str = self.latest_session.strftime("%Y-%m-%d %H:%M:%S")

        # Format total duration
        total_seconds = self.total_duration.total_seconds()
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        formatted_total_duration = ""
        if hours > 0:
            formatted_total_duration += f"{int(hours)} hour{'s' if hours != 1 else ''} "
        if minutes > 0:
            formatted_total_duration += f"{int(minutes)} minute{'s' if minutes != 1 else ''} "
        if seconds > 0 or (hours == 0 and minutes == 0):
            formatted_total_duration += f"{int(seconds)} second{'s' if seconds != 1 else ''}"

        # Return combined stats
        return {
            "total_sessions": len(self.session_logs),
            "days_covered": len(self.sessions_by_day),
            "total_screenshots": self.total_screenshots,
            "total_notes": self.total_notes,
            "total_duration": self.total_duration,
            "formatted_total_duration": formatted_total_duration,
            "earliest_session": self.earliest_session,
            "latest_session": self.latest_session,
            "earliest_session_str": earliest_session_str,
            "latest_session_str": latest_session_str,
        }
