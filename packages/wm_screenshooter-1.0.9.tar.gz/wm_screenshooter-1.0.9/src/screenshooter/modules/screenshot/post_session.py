#!/usr/bin/env python3
"""Post-session report prompting and email flow for ScreenShooter Mac."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from screenshooter.modules.reports.pdf.generation import (
    generate_multi_session_pdf,
    generate_single_session_pdf,
)
from screenshooter.modules.reports.pdf.generator import ReportGenerator
from screenshooter.modules.reports.report_email import send_email
from screenshooter.modules.screenshot.config import ScreenshooterConfig
from screenshooter.modules.settings.settings_helper import get_email_settings, reload_settings

from .utils import get_text_input

console = Console()
MIN_SESSIONS_FOR_DAY_REPORT = 2


@dataclass(slots=True)
class EmailReportRequest:
    """Metadata for sending a generated report email."""

    project_name: str
    date_str: str
    report_type: str = "session"
    extra_lines: list[str] | None = None
    report_meta: dict[str, Any] | None = None


def _confirm_on_new_line(prompt_text: str, *, default: bool = False) -> bool:
    """Print confirm question and collect y/n input on a new line with '>'."""
    # Build indicator: [y/n] (default)
    default_char = "y" if default else "n"
    # Escape [y/n] to prevent rich from interpreting it as a style tag
    console.print(f"{prompt_text} \\[y/n] ({default_char}):")

    while True:
        answer = get_text_input("> ").strip().lower()
        if answer == "":
            return default
        if answer in ["y", "yes"]:
            return True
        if answer in ["n", "no"]:
            return False
        console.print("[red]Invalid input. Please enter 'y' or 'n'.[/red]")


def _parse_notes_lines(note_line: str) -> list[str]:
    """Parse notes text into ordered lines with explicit bullets.

    Behavior:
    - Newlines: '/n', '\\n', and '<br>' are treated as line breaks.
    - Bullets: '/b' tokens start a bullet item. Multiple '/b' tokens on the same
      line create multiple bullets in order. A '/n' ends the current line; if the
      next token is '/b' it continues bullets on the next line.
    - The plain '-' character no longer creates bullets and is preserved.
    """
    if not note_line:
        return []

    normalized = note_line.replace("<br>", "\n").replace("/n", "\n").replace("\\n", "\n")

    result_lines: list[str] = []
    for raw_line in normalized.splitlines():
        segment = raw_line.strip()
        if not segment:
            continue

        # Split on '/b' to find explicit bullet tokens while preserving text before/after
        parts = segment.split("/b")
        head_text = parts[0].strip()
        if head_text:
            result_lines.append(head_text)

        # Remaining parts are bullet texts
        for bullet_text in parts[1:]:
            cleaned = bullet_text.strip()
            if cleaned:
                result_lines.append(f"- {cleaned}")

    return result_lines


def _send_email_with_settings(
    pdf_path: Path,
    client_info_dict: dict[str, Any],
    request: EmailReportRequest,
) -> bool:
    email_settings = get_email_settings()
    if not email_settings.get("enabled", False):
        console.print("[yellow]Email is disabled in settings. Skipping send.[/yellow]")
        return False

    sender = email_settings.get("sender_email") or ""
    password = email_settings.get("password") or ""
    smtp_server = email_settings.get("smtp_server") or ""
    smtp_port = int(email_settings.get("smtp_port", 587) or 587)
    sender_name = email_settings.get("sender_name") or ""
    username = email_settings.get("username") or sender
    security = email_settings.get("connection_security", "TLS") or "TLS"
    recipient_type = email_settings.get("recipient_type", "TO") or "TO"

    recipients: list[str] = []
    if email_settings.get("always_include_defaults", True):
        defaults = email_settings.get("default_recipients") or []
        recipients.extend([r for r in defaults if r])

    if not sender or not password or not smtp_server:
        console.print("[red]Email settings incomplete (sender/password/smtp). Skipping send.[/red]")
        return False

    return send_email(
        pdf_file=pdf_path,
        client_info=client_info_dict,
        project_name=request.project_name,
        session_date=request.date_str,
        sender_email=sender,
        password=password,
        smtp_server=smtp_server,
        smtp_port=smtp_port,
        sender_name=sender_name,
        username=username,
        connection_security=security,
        recipients=recipients or None,
        recipient_type=recipient_type,
        debug=False,
        report_type=request.report_type,
        extra_body_lines=request.extra_lines,
        report_meta=request.report_meta,
    )


def _ask_return_to_main_menu() -> int:
    """Ask whether to return to the main menu after post-session tasks.

    Returns:
        1 if the user wants to return to the main menu, 0 to exit the app.
    """
    try:
        console.print("\n[bold]Post-session tasks complete.[/bold]")
        go_to_menu = _confirm_on_new_line(
            "Would you like to return to the main menu?", default=True
        )
        return 1 if go_to_menu else 0
    except Exception:
        # On any unexpected error, fall back to returning to the menu
        return 1


def _record_session_completion_metadata(config: ScreenshooterConfig) -> None:
    """Best-effort persistence of end-of-session metadata."""
    try:
        config.set_session_finish_time()
    except Exception as e:
        console.print(f"[yellow]Could not record session finish time: {e}[/yellow]")
    try:
        config.update_project_metadata_last_updated()
    except Exception as e:
        console.print(f"[yellow]Could not update project metadata: {e}[/yellow]")


def _is_email_enabled_for_post_session() -> bool:
    """Return whether email is enabled for post-session flows."""
    reload_settings()
    email_settings = get_email_settings()
    if email_settings.get("enabled", False):
        return True
    console.print(
        "[yellow]Email is disabled in settings. Skipping post-session report flow.[/yellow]"
    )
    return False


def _collect_today_session_dirs(sessions_dir: Path, today_str: str) -> list[Path]:
    """Collect today's session directories for day report eligibility."""
    try:
        if not sessions_dir.exists():
            return []
        return [
            directory
            for directory in sessions_dir.iterdir()
            if directory.is_dir() and directory.name.startswith(today_str)
        ]
    except Exception:
        return []


def _prompt_report_notes(
    prompt_text: str,
) -> tuple[str, list[str] | None]:
    """Prompt for optional report notes with preview and confirmation."""
    notes_input = ""
    while True:
        console.print(prompt_text)
        if notes_input:
            console.print(f"[dim]Previous notes: {notes_input}[/dim]")
        notes_input = get_text_input("> ").strip()
        extra_lines = _parse_notes_lines(notes_input) if notes_input else None

        if extra_lines:
            console.print("[dim]Current notes preview:[/dim]")
            for line in extra_lines:
                console.print(f"[dim]{line}[/dim]")
        else:
            console.print("[dim]No notes will be included.[/dim]")

        console.print("Use these notes? [y/e/c] (y):")
        while True:
            action = get_text_input("> ").strip().lower()
            if action == "":
                action = "y"
            if action in {"y", "e", "c"}:
                break
            console.print("[red]Invalid input. Please enter 'y', 'e', or 'c'.[/red]")

        if action == "y":
            return notes_input, extra_lines
        if action == "c":
            return "", None


def _generate_day_report_pdf(generator: ReportGenerator) -> Path:
    """Generate day report PDF with progress UI."""
    console.print("[bold]Generating day PDF report...[/bold]")
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        _ = progress.add_task("Processing...", total=None)
        return generate_multi_session_pdf(generator)


def _generate_session_report_pdf(generator: ReportGenerator) -> Path:
    """Generate session report PDF with progress UI."""
    console.print("[bold]Generating session PDF report...[/bold]")
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        _ = progress.add_task("Processing...", total=None)
        return generate_single_session_pdf(generator)


def _build_day_report_meta(generator: ReportGenerator, today_str: str) -> dict[str, Any] | None:
    """Build day-report email metadata."""
    try:
        if not generator.multi_sessions:
            return None
        stats = generator.multi_sessions.get_combined_stats()
        total_seconds = (
            int(stats["total_duration"].total_seconds()) if stats.get("total_duration") else 0
        )
        return {
            "date": today_str,
            "session_count": stats.get("total_sessions", 0),
            "hours": total_seconds // 3600,
            "minutes": (total_seconds % 3600) // 60,
        }
    except Exception:
        return None


def _build_session_report_meta(
    generator: ReportGenerator,
    fallback_date: str,
) -> dict[str, Any] | None:
    """Build session-report email metadata."""
    try:
        hours = 0
        minutes = 0
        if generator.session_log and generator.session_log.session_duration:
            duration = generator.session_log.session_duration
            h_match = re.search(r"(\d+) hour", duration)
            m_match = re.search(r"(\d+) minute", duration)
            hours = int(h_match.group(1)) if h_match else 0
            minutes = int(m_match.group(1)) if m_match else 0

        start_raw = generator.session_log.session_start if generator.session_log else None
        end_raw = generator.session_log.session_end if generator.session_log else None
        start_time = ""
        end_time = ""
        date_only = ""
        if start_raw:
            try:
                start_time = start_raw.split(" ")[1][:5]
                date_only = start_raw.split(" ")[0]
            except Exception:
                pass
        if end_raw:
            try:
                end_time = end_raw.split(" ")[1][:5]
            except Exception:
                pass

        return {
            "date": date_only or fallback_date,
            "start_time": start_time,
            "end_time": end_time,
            "hours": hours,
            "minutes": minutes,
        }
    except Exception:
        return None


def _append_day_report_markers_to_logs(
    session_dirs_today: list[Path],
    today_str: str,
    notes_input: str,
) -> None:
    """Append day-report sent markers to today's session logs."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for session_dir in session_dirs_today:
        try:
            session_log_file = session_dir / "session.log"
            with open(session_log_file, "a") as file_obj:
                file_obj.write(f"[{timestamp}] Day report sent for {today_str}\n")
                if notes_input:
                    file_obj.write(f"[{timestamp}] Day report notes (raw input): {notes_input}\n")
        except Exception:
            pass


def _maybe_send_day_report(
    *,
    client: str,
    project: str,
    today_str: str,
    session_dirs_today: list[Path],
) -> bool:
    """Prompt and optionally send day report. Returns True when handled."""
    if len(session_dirs_today) < MIN_SESSIONS_FOR_DAY_REPORT:
        return False

    send_day = _confirm_on_new_line(
        f"You have multiple sessions today. Send the day report for {today_str}?",
        default=True,
    )
    if not send_day:
        return False

    generator = ReportGenerator(
        client_name=client,
        project_name=project,
        report_type="day",
        specific_date=today_str,
    )
    generator.load_client_info()
    generator.setup_multi_session_report()

    notes_input, extra_lines = _prompt_report_notes(
        "Add notes (use /n, \\n or <br> for new lines; use /b for bullets):"
    )
    if notes_input:
        try:
            generator.log_entry(
                f"Day report notes (raw input): {notes_input}",
                terminal_message="",
            )
        except Exception:
            pass

    day_pdf = _generate_day_report_pdf(generator)
    generator.log_entry(
        f"User chose to send Day report ({today_str}).",
        f"[green]Preparing to send day report for {today_str}[/green]",
    )
    generator.log_entry(f"Day report generated at {day_pdf}", terminal_message="")

    success = _send_email_with_settings(
        pdf_path=day_pdf,
        client_info_dict=generator.client_info.dict() if generator.client_info else {},
        request=EmailReportRequest(
            project_name=project,
            date_str=today_str,
            report_type="day",
            extra_lines=extra_lines,
            report_meta=_build_day_report_meta(generator, today_str),
        ),
    )
    if success:
        console.print("[green]Day report email sent successfully.[/green]")
        generator.log_entry("Day report email sent successfully.", terminal_message="")
        _append_day_report_markers_to_logs(session_dirs_today, today_str, notes_input)
    else:
        console.print("[red]Failed to send day report email.[/red]")
        generator.log_entry(
            "Failed to send day report email.",
            level="error",
            terminal_message="",
        )
    return True


def _maybe_send_session_report(
    *,
    config: ScreenshooterConfig,
    client: str,
    project: str,
) -> None:
    """Prompt and optionally send session report."""
    send_session = _confirm_on_new_line("Send this session's report?", default=False)
    if not send_session:
        return

    generator = ReportGenerator(
        client_name=client,
        project_name=project,
        report_type="session",
        session_date=config.session_start_time,
    )
    generator.load_client_info()
    generator.load_session()
    session_pdf = _generate_session_report_pdf(generator)

    generator.log_entry(
        f"User chose to send Session report ({config.session_start_time}).",
        f"[green]Preparing to send session report for {config.session_start_time}[/green]",
    )
    generator.log_entry(f"Session report generated at {session_pdf}", terminal_message="")

    success = _send_email_with_settings(
        pdf_path=session_pdf,
        client_info_dict=generator.client_info.dict() if generator.client_info else {},
        request=EmailReportRequest(
            project_name=project,
            date_str=config.session_start_time,
            report_type="session",
            report_meta=_build_session_report_meta(generator, str(config.session_start_time)),
        ),
    )
    if success:
        console.print("[green]Session report email sent successfully.[/green]")
        generator.log_entry("Session report email sent successfully.", terminal_message="")
    else:
        console.print("[red]Failed to send session report email.[/red]")
        generator.log_entry(
            "Failed to send session report email.",
            level="error",
            terminal_message="",
        )


def post_session_report_flow(config: ScreenshooterConfig) -> int:
    """Run end-of-session prompts to optionally send day and/or session reports."""
    _record_session_completion_metadata(config)
    if not _is_email_enabled_for_post_session():
        return _ask_return_to_main_menu()

    try:
        client = config.client_name
        project = config.project_name
        project_dir = Path(config.project_dir)
        sessions_dir = project_dir / "sessions"
        today_str = datetime.now().strftime("%Y-%m-%d")

        session_dirs_today = _collect_today_session_dirs(sessions_dir, today_str)
        day_report_handled = _maybe_send_day_report(
            client=client,
            project=project,
            today_str=today_str,
            session_dirs_today=session_dirs_today,
        )
        if day_report_handled:
            # After sending (or attempting) day report, do not prompt for session report
            return _ask_return_to_main_menu()

        _maybe_send_session_report(
            config=config,
            client=client,
            project=project,
        )

    except Exception as e:
        console.print(f"[yellow]Post-session report flow error: {e}[/yellow]")
        # On error, still ask about returning to the main menu
        return _ask_return_to_main_menu()

    # Normal completion of post-session flow
    return _ask_return_to_main_menu()
