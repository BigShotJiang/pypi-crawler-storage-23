#!/usr/bin/env python3
"""Interactive UI functionality for the screenshot module."""

import json
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from rich.console import Console
from rich.prompt import Prompt

from screenshooter.modules.clients.cli import create_new_client_for_screenshot
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.database import DatabaseOperations
from screenshooter.modules.settings.settings_helper import (
    get_default_screenshot_timer,
    get_screenshots_dir,
    should_use_database,
)

from .utils import BACK_OPTION, get_connected_displays, get_text_input

# Initialize rich console
console = Console()

PAGINATION_PAGE_SIZE = 10
DEFAULT_TIMER_15_MINUTES = 15
DEFAULT_TIMER_30_MINUTES = 30
DEFAULT_TIMER_60_MINUTES = 60
STEP_SELECT_CLIENT = 1
STEP_SELECT_PROJECT = 2
STEP_SELECT_MODE = 3
STEP_SELECT_TIMER = 4


@dataclass
class ClientChoiceContext:
    """Context for resolving client-selection choices."""

    clients: list[tuple[str, str]]
    db_operations: DatabaseOperations | None
    use_database: bool
    base_dir: Path


@dataclass
class ProjectChoiceContext:
    """Context for resolving project-selection choices."""

    projects: list[tuple[str, str]]
    archived_projects: list[tuple[str, str, int | None]]
    client_dir_name: str
    db_operations: DatabaseOperations | None
    base_dir: Path
    use_database: bool


@dataclass
class ArchivedProjectContext:
    """Context for archived-project unarchive actions."""

    client_dir_name: str
    db_operations: DatabaseOperations | None
    base_dir: Path | None


def _prompt_with_back(
    prompt_text: str, choices: list[str], default: str | None = None, show_choices: bool = True
) -> str | object:
    """Wrapper for adding a 'b' for back option, using input() to allow backspace."""
    valid_choices = [*choices, "b"]
    while True:
        # Build and display the full prompt with choices and optional default
        choices_str = "/".join(valid_choices)
        # Colorize bracketed choices in purple
        colored_choices = f"\033[95m[{choices_str}]\033[0m"
        # Default is plain text and include a leading space
        default_text = f"({default})" if default is not None else ""
        # Build prompt with single space between choices and default
        prompt_str = f"{prompt_text} (or 'b' to go back) {colored_choices} {default_text}:"
        # Print the full prompt on its own line, then read the response on a new line
        print(prompt_str)
        # Use input-based prompt for proper backspace handling
        response = get_text_input("> ").strip()
        # If the user pressed Enter with no input and a default is provided, use it
        if response == "" and default is not None:
            response = default
        # Handle back navigation
        if response.lower() == "b":
            return BACK_OPTION
        # Validate the numeric choice
        if response in choices:
            return response
        # On invalid entry, show error and repeat the full prompt
        console.print(
            f"[red]Invalid choice: {response}. Please enter one of: {', '.join(choices)}[/red]"
        )


def _select_client_interactive(base_dir: Path) -> str | object | None:
    """Handle interactive client selection."""
    console.print("\n[bold]Client Selection[/bold]")
    try:
        clients, use_database, db_operations = _load_client_choices(base_dir)
    except Exception as e:
        return _handle_client_selection_load_error(e)

    if not clients:
        console.print("[yellow]No clients found. Creating a new client.[/yellow]")
        return _create_client_for_screenshot()

    page = 0
    while True:
        page_items, start_idx, end_idx, page, total_pages = _paginate_named_items(clients, page)
        _print_named_items("Available Clients", page_items, start_idx, page, total_pages)
        has_archived = _has_archived_clients(use_database, db_operations, base_dir)
        choice = _prompt_client_choice(
            page_state=(start_idx, end_idx, page, total_pages),
            page_items=page_items,
            has_archived=has_archived,
        )
        context = ClientChoiceContext(
            clients=clients,
            db_operations=db_operations,
            use_database=use_database,
            base_dir=base_dir,
        )
        result, page_delta, should_exit = _resolve_client_choice(
            choice=choice,
            context=context,
        )
        if should_exit:
            return result
        page += page_delta


def _load_client_choices(
    base_dir: Path,
) -> tuple[list[tuple[str, str]], bool, DatabaseOperations | None]:
    """Load client list from database or filesystem."""
    use_database = should_use_database()
    if use_database:
        db_operations = DatabaseOperations()
        db_clients = db_operations.list_clients(active_only=True)
        clients = [(client.name, client.directory_name) for client in db_clients if client.name]
        return clients, True, db_operations

    clients: list[tuple[str, str]] = []
    for directory in base_dir.iterdir():
        if not directory.is_dir() or not (directory / "client_info.json").exists():
            continue
        try:
            with open(directory / "client_info.json") as file:
                client_info = json.load(file)
            if client_info.get("archived", False):
                continue
            display_name = client_info.get("client_name", directory.name)
            directory_name = client_info.get("directory_name", directory.name)
            clients.append((display_name, directory_name))
        except (OSError, json.JSONDecodeError):
            clients.append((directory.name, directory.name))
    return clients, False, None


def _handle_client_selection_load_error(error: Exception) -> object | None:
    """Prompt for recovery when client loading fails."""
    console.print(f"[bold red]Database error: {error}[/bold red]")
    console.print("Please check your database configuration.")
    choice = _prompt_with_back(
        "Would you like to return to main menu?",
        choices=["y", "n"],
        default="y",
    )
    return BACK_OPTION if choice == "y" else None


def _create_client_for_screenshot() -> str | None:
    """Run screenshot client-creation workflow."""
    return create_new_client_for_screenshot() or None


def _paginate_named_items(
    items: list[tuple[str, str]],
    page: int,
) -> tuple[list[tuple[str, str]], int, int, int, int]:
    """Return paginated named items and page metadata."""
    total_items = len(items)
    total_pages = (
        (total_items + PAGINATION_PAGE_SIZE - 1) // PAGINATION_PAGE_SIZE if total_items else 1
    )
    page = min(max(page, 0), total_pages - 1)
    start_idx = page * PAGINATION_PAGE_SIZE
    end_idx = min(start_idx + PAGINATION_PAGE_SIZE, total_items)
    return items[start_idx:end_idx], start_idx, end_idx, page, total_pages


def _print_named_items(
    title: str,
    page_items: list[tuple[str, str]],
    start_idx: int,
    page: int,
    total_pages: int,
) -> None:
    """Print paginated item list."""
    if total_pages > 1:
        console.print(f"\n[bold]{title} (Page {page + 1}/{total_pages}):[/bold]")
    else:
        console.print(f"\n[bold]{title}:[/bold]")
    for index, item in enumerate(page_items):
        display_idx = start_idx + index + 1
        display_name, _ = item
        console.print(f"{display_idx}. {display_name}")


def _has_archived_clients(
    use_database: bool,
    db_operations: DatabaseOperations | None,
    base_dir: Path,
) -> bool:
    """Return True when archived clients are available."""
    if use_database and db_operations is not None:
        try:
            return bool(db_operations.list_archived_clients())
        except Exception:
            return False

    for directory in base_dir.iterdir():
        if not directory.is_dir() or not (directory / "client_info.json").exists():
            continue
        try:
            with open(directory / "client_info.json") as file:
                if json.load(file).get("archived", False):
                    return True
        except (OSError, json.JSONDecodeError):
            continue
    return False


def _prompt_client_choice(
    page_state: tuple[int, int, int, int],
    page_items: list[tuple[str, str]],
    has_archived: bool,
) -> str | object:
    """Prompt for client selection options."""
    start_idx, end_idx, page, total_pages = page_state
    console.print("\n[bold]Options:[/bold]")
    console.print(f"{start_idx + 1}-{end_idx}: Select client")
    console.print("c: Create new client")

    extra_options: list[str] = []
    if has_archived:
        console.print("a: Manage archived clients")
        extra_options.append("a")
    console.print("b: Go back")
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_options.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_options.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + ["c"] + extra_options
    return _prompt_with_back(
        "Select a client or create a new one",
        choices=choices,
        default="1" if page_items else "c",
    )


def _resolve_client_choice(
    *,
    choice: str | object,
    context: ClientChoiceContext,
) -> tuple[str | object | None, int, bool]:
    """Resolve client selection choice.

    Returns (result, page_delta, should_exit).
    """
    result: str | object | None = None
    page_delta = 0
    should_exit = False

    if choice is BACK_OPTION:
        result = BACK_OPTION
        should_exit = True
    elif choice == "n":
        page_delta = 1
    elif choice == "p":
        page_delta = -1
    elif choice == "a":
        result = _manage_archived_clients(
            context.db_operations if context.use_database else None,
            context.base_dir if not context.use_database else None,
        )
        if result is BACK_OPTION or isinstance(result, str):
            should_exit = True
        else:
            result = None
    elif choice == "c":
        created = _create_client_for_screenshot()
        result = created
        should_exit = True
    elif isinstance(choice, str) and choice.isdigit():
        _, directory_name = context.clients[int(choice) - 1]
        result = directory_name
        should_exit = True
    else:
        should_exit = True

    return result, page_delta, should_exit


def _manage_archived_clients(
    db_operations: DatabaseOperations | None, base_dir: Path | None = None
) -> str | object | None:
    """Handle archived client management."""
    console.print("\n[bold]Manage Archived Clients[/bold]")

    try:
        archived_clients = _load_archived_clients(db_operations, base_dir)
        if not archived_clients:
            console.print("[yellow]No archived clients found.[/yellow]")
            _prompt_with_back("Press Enter to continue...", choices=[""])
            return BACK_OPTION

        page = 0
        total_pages = (len(archived_clients) + PAGINATION_PAGE_SIZE - 1) // PAGINATION_PAGE_SIZE

        while True:
            page_items, start_idx, end_idx, page, total_pages = _paginate_archived_clients(
                archived_clients,
                page,
                total_pages,
            )
            choice = _prompt_archived_client_choice(
                start_idx=start_idx,
                end_idx=end_idx,
                page_items=page_items,
                page=page,
                total_pages=total_pages,
            )
            selected, page_delta, should_exit = _resolve_archived_client_choice(
                choice=choice,
                archived_clients=archived_clients,
                db_operations=db_operations,
                base_dir=base_dir,
            )
            if should_exit:
                return selected
            page += page_delta

    except Exception as e:
        console.print(f"[red]Error managing archived clients: {e}[/red]")
        return BACK_OPTION


def _load_archived_clients(
    db_operations: DatabaseOperations | None,
    base_dir: Path | None,
) -> list[Any]:
    """Load archived clients from the active data source."""
    if db_operations:
        return db_operations.list_archived_clients()

    archived_clients: list[Any] = []
    if not base_dir:
        return archived_clients
    for directory in base_dir.iterdir():
        if not directory.is_dir() or not (directory / "client_info.json").exists():
            continue
        try:
            with open(directory / "client_info.json") as file:
                client_info = json.load(file)
            if client_info.get("archived", False):
                archived_clients.append(
                    SimpleNamespace(
                        name=client_info.get("client_name", directory.name),
                        directory_name=directory.name,
                        id=None,
                    )
                )
        except (OSError, json.JSONDecodeError):
            continue
    return archived_clients


def _paginate_archived_clients(
    archived_clients: list[Any],
    page: int,
    total_pages: int,
) -> tuple[list[Any], int, int, int, int]:
    """Return paginated archived clients and metadata."""
    page = min(max(page, 0), total_pages - 1)
    start_idx = page * PAGINATION_PAGE_SIZE
    end_idx = min(start_idx + PAGINATION_PAGE_SIZE, len(archived_clients))
    page_items = archived_clients[start_idx:end_idx]

    console.print(f"\n[bold]Archived Clients (Page {page + 1}/{total_pages}):[/bold]")
    for index, client in enumerate(page_items):
        display_idx = start_idx + index + 1
        console.print(f"{display_idx}. {client.name} [dim](Archived)[/dim]")
    return page_items, start_idx, end_idx, page, total_pages


def _prompt_archived_client_choice(
    *,
    start_idx: int,
    end_idx: int,
    page_items: list[Any],
    page: int,
    total_pages: int,
) -> str | object:
    """Prompt for archived client action."""
    console.print("\n[bold]Options:[/bold]")
    console.print(f"{start_idx + 1}-{end_idx}: Select client to unarchive")
    console.print("b: Go back")
    extra_options: list[str] = []
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_options.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_options.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_options
    return _prompt_with_back(
        "Select a client to unarchive or go back",
        choices=choices,
        default="1" if page_items else "b",
    )


def _resolve_archived_client_choice(
    *,
    choice: str | object,
    archived_clients: list[Any],
    db_operations: DatabaseOperations | None,
    base_dir: Path | None,
) -> tuple[str | object | None, int, bool]:
    """Resolve archived-client menu action."""
    if choice is BACK_OPTION:
        return BACK_OPTION, 0, True
    if choice == "n":
        return None, 1, False
    if choice == "p":
        return None, -1, False
    if not (isinstance(choice, str) and choice.isdigit()):
        return None, 0, False

    selected_idx = int(choice) - 1
    if not (0 <= selected_idx < len(archived_clients)):
        console.print("[red]Invalid selection.[/red]")
        return None, 0, False
    return _confirm_and_unarchive_client(
        selected_client=archived_clients[selected_idx],
        db_operations=db_operations,
        base_dir=base_dir,
    )


def _confirm_and_unarchive_client(
    *,
    selected_client: Any,
    db_operations: DatabaseOperations | None,
    base_dir: Path | None,
) -> tuple[str | object | None, int, bool]:
    """Confirm and perform client unarchive operation."""
    confirm = _prompt_with_back(
        f"Unarchive client '{selected_client.name}' and continue?",
        choices=["y", "n"],
        default="y",
    )
    if confirm is BACK_OPTION:
        return BACK_OPTION, 0, True
    if confirm != "y":
        console.print("[yellow]Unarchive cancelled.[/yellow]")
        return None, 0, False

    success = _unarchive_client(selected_client, db_operations, base_dir)
    if success:
        console.print(f"[green]Client '{selected_client.name}' has been unarchived.[/green]")
        return selected_client.directory_name, 0, True
    console.print(f"[red]Failed to unarchive client '{selected_client.name}'.[/red]")
    return None, 0, False


def _unarchive_client(
    selected_client: Any,
    db_operations: DatabaseOperations | None,
    base_dir: Path | None,
) -> bool:
    """Unarchive a single client in database or filesystem mode."""
    if db_operations and selected_client.id is not None:
        return db_operations.unarchive_client(int(selected_client.id))

    if not base_dir or not selected_client.directory_name:
        return False
    client_dir = base_dir / selected_client.directory_name
    info_file = client_dir / "client_info.json"
    if not info_file.exists():
        return False
    try:
        with open(info_file) as file:
            client_info = json.load(file)
        client_info["archived"] = False
        with open(info_file, "w") as file:
            json.dump(client_info, file, indent=2)
        return True
    except (OSError, json.JSONDecodeError):
        console.print(f"[red]Failed to update {info_file}[/red]")
        return False


def _manage_archived_projects(
    client_dir_name: str,
    db_operations: DatabaseOperations | None,
    base_dir: Path | None = None,
) -> str | object | None:
    """Handle archived project management."""
    console.print("\n[bold]Manage Archived Projects[/bold]")
    try:
        archived_projects = _load_archived_projects(client_dir_name, db_operations, base_dir)
        if archived_projects is BACK_OPTION:
            return BACK_OPTION
        if not archived_projects:
            console.print("[yellow]No archived projects found.[/yellow]")
            return BACK_OPTION

        page = 0
        while True:
            page_items, start_idx, end_idx, page, total_pages = _paginate_archived_projects(
                archived_projects,
                page,
            )
            choice = _prompt_archived_project_choice(
                start_idx=start_idx,
                end_idx=end_idx,
                page_items=page_items,
                page=page,
                total_pages=total_pages,
            )
            context = ArchivedProjectContext(
                client_dir_name=client_dir_name,
                db_operations=db_operations,
                base_dir=base_dir,
            )
            selected, page_delta, should_exit = _resolve_archived_project_choice(
                choice=choice,
                archived_projects=archived_projects,
                context=context,
            )
            if should_exit:
                return selected
            page += page_delta

    except Exception as e:
        console.print(f"[red]Error managing archived projects: {e}[/red]")
        return BACK_OPTION


def _load_archived_projects(
    client_dir_name: str,
    db_operations: DatabaseOperations | None,
    base_dir: Path | None,
) -> list[tuple[str, str, int | None]] | object:
    """Load archived projects from database or filesystem."""
    if db_operations:
        client = db_operations.get_client_by_directory(client_dir_name)
        if not client:
            console.print("[red]Client not found in database.[/red]")
            return BACK_OPTION
        if client.id is None:
            console.print("[red]Client ID not found.[/red]")
            return BACK_OPTION
        return [
            (project.name or project.directory_name, project.directory_name, project.id)
            for project in db_operations.list_archived_projects(client.id)
        ]

    archived_projects: list[tuple[str, str, int | None]] = []
    if not base_dir:
        return archived_projects
    client_dir = base_dir / client_dir_name
    if not client_dir.exists():
        return archived_projects
    for directory in client_dir.iterdir():
        if not directory.is_dir() or not (directory / "project.json").exists():
            continue
        try:
            with open(directory / "project.json") as file:
                project_info = json.load(file)
            is_archived = bool(
                project_info.get("archived_at") or project_info.get("archived", False)
            )
            if is_archived:
                archived_projects.append(
                    (project_info.get("project_name", directory.name), directory.name, None)
                )
        except (OSError, json.JSONDecodeError):
            continue
    return archived_projects


def _paginate_archived_projects(
    archived_projects: list[tuple[str, str, int | None]],
    page: int,
) -> tuple[list[tuple[str, str, int | None]], int, int, int, int]:
    """Paginate archived projects and render page heading/list."""
    total_items = len(archived_projects)
    if total_items == 0:
        console.print("[yellow]No more archived projects.[/yellow]")
        return [], 0, 0, 0, 1

    total_pages = (total_items + PAGINATION_PAGE_SIZE - 1) // PAGINATION_PAGE_SIZE
    page = min(max(page, 0), total_pages - 1)
    start_idx = page * PAGINATION_PAGE_SIZE
    end_idx = min(start_idx + PAGINATION_PAGE_SIZE, total_items)
    page_items = archived_projects[start_idx:end_idx]

    if total_pages > 1:
        console.print(f"\n[bold]Archived Projects (Page {page + 1}/{total_pages}):[/bold]")
    else:
        console.print("\n[bold]Archived Projects:[/bold]")
    for index, project in enumerate(page_items):
        display_idx = start_idx + index + 1
        console.print(f"{display_idx}. {project[0]} [dim](Archived)[/dim]")
    return page_items, start_idx, end_idx, page, total_pages


def _prompt_archived_project_choice(
    *,
    start_idx: int,
    end_idx: int,
    page_items: list[tuple[str, str, int | None]],
    page: int,
    total_pages: int,
) -> str | object:
    """Prompt for archived-project action."""
    console.print("\n[bold]Options:[/bold]")
    console.print(f"{start_idx + 1}-{end_idx}: Select project to unarchive")
    console.print("b: Go back")

    extra_choices: list[str] = []
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_choices.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_choices.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_choices
    return _prompt_with_back(
        "Select a project to unarchive",
        choices=choices,
        default="b",
    )


def _resolve_archived_project_choice(
    *,
    choice: str | object,
    archived_projects: list[tuple[str, str, int | None]],
    context: ArchivedProjectContext,
) -> tuple[str | object | None, int, bool]:
    """Resolve archived-project menu action."""
    if choice is BACK_OPTION or choice == "b":
        return BACK_OPTION, 0, True
    if choice == "n":
        return None, 1, False
    if choice == "p":
        return None, -1, False
    if not (isinstance(choice, str) and choice.isdigit()):
        return None, 0, False

    idx = int(choice) - 1
    if not (0 <= idx < len(archived_projects)):
        console.print("[red]Invalid selection.[/red]")
        return None, 0, False
    return _confirm_and_unarchive_project(archived_projects[idx], context)


def _confirm_and_unarchive_project(
    selected_project: tuple[str, str, int | None],
    context: ArchivedProjectContext,
) -> tuple[str | object | None, int, bool]:
    """Confirm and run project unarchive operation."""
    selected_name, selected_dir_name, selected_id = selected_project
    console.print(f"\n[yellow]Selected project: {selected_name}[/yellow]")
    confirm = _prompt_with_back(
        f"Unarchive project '{selected_name}'?",
        choices=["y", "n"],
        default="n",
    )
    if confirm is BACK_OPTION:
        return None, 0, False
    if not (isinstance(confirm, str) and confirm.lower() == "y"):
        console.print("[yellow]Unarchive cancelled.[/yellow]")
        return None, 0, False

    if _unarchive_project(selected_dir_name, selected_id, context):
        console.print(f"[green]Project '{selected_name}' has been unarchived.[/green]")
        return selected_dir_name, 0, True
    console.print(f"[red]Failed to unarchive project '{selected_name}'.[/red]")
    return None, 0, False


def _unarchive_project(
    selected_dir_name: str,
    selected_id: int | None,
    context: ArchivedProjectContext,
) -> bool:
    """Unarchive a project in database or filesystem mode."""
    if context.db_operations and selected_id is not None:
        db_success = context.db_operations.unarchive_project(selected_id)
        if not db_success:
            return False
        # Keep filesystem metadata aligned with DB unarchive state.
        _sync_project_file_archive_state(
            base_dir=context.base_dir,
            client_dir_name=context.client_dir_name,
            project_dir_name=selected_dir_name,
            archived=False,
        )
        return True
    return _sync_project_file_archive_state(
        base_dir=context.base_dir,
        client_dir_name=context.client_dir_name,
        project_dir_name=selected_dir_name,
        archived=False,
    )


def _sync_project_file_archive_state(
    *,
    base_dir: Path | None,
    client_dir_name: str,
    project_dir_name: str,
    archived: bool,
) -> bool:
    """Sync archived fields in project.json for a project."""
    if not base_dir:
        return False
    client_dir = base_dir / client_dir_name
    project_dir = client_dir / project_dir_name
    project_file = project_dir / "project.json"
    if not project_file.exists():
        return False
    try:
        with open(project_file) as file:
            project_info = json.load(file)
        if archived:
            # Keep a single marker field in legacy filesystem mode.
            project_info["archived_at"] = project_info.get("archived_at") or ""
        else:
            project_info["archived_at"] = ""
        project_info.pop("archived", None)
        with open(project_file, "w") as file:
            json.dump(project_info, file, indent=2)
        return True
    except (OSError, json.JSONDecodeError):
        console.print(f"[red]Failed to update {project_file}[/red]")
        return False


def _select_project_interactive(client_dir_name: str, base_dir: Path) -> str | object | None:
    """Handle interactive project selection."""
    console.print("\n[bold]Project Selection[/bold]")
    result = _load_project_choices(client_dir_name, base_dir)
    if isinstance(result, tuple):
        projects, archived_projects, db_operations, use_database = result
    else:
        return result

    if not projects and not archived_projects:
        return _prompt_new_project_name()

    page = 0
    while True:
        page_items, start_idx, end_idx, page, total_pages = _paginate_named_items(projects, page)
        _print_named_items("Available Projects", page_items, start_idx, page, total_pages)
        if not page_items:
            console.print("[dim]No active projects.[/dim]")
        choice = _prompt_project_choice(
            page_state=(start_idx, end_idx, page, total_pages),
            page_items=page_items,
            has_archived=bool(archived_projects),
        )
        context = ProjectChoiceContext(
            projects=projects,
            archived_projects=archived_projects,
            client_dir_name=client_dir_name,
            db_operations=db_operations,
            base_dir=base_dir,
            use_database=use_database,
        )
        selected, page_delta, should_exit = _resolve_project_choice(
            choice=choice,
            context=context,
        )
        if should_exit:
            return selected
        page += page_delta


def _load_project_choices(
    client_dir_name: str,
    base_dir: Path,
) -> (
    tuple[list[tuple[str, str]], list[tuple[str, str, int | None]], DatabaseOperations | None, bool]
    | object
    | None
):
    """Load active and archived projects for interactive selection."""
    projects: list[tuple[str, str]] = []
    archived_projects: list[tuple[str, str, int | None]] = []
    use_database = should_use_database()

    if use_database:
        try:
            db_operations = DatabaseOperations()
            client = db_operations.get_client_by_directory(client_dir_name)
            if not client or not client.id:
                console.print(f"[red]Client '{client_dir_name}' not found in database.[/red]")
                return BACK_OPTION
            db_projects = db_operations.list_projects(client.id, active_only=True)
            projects = [(project.name, project.directory_name) for project in db_projects]
            db_archived = db_operations.list_archived_projects(client.id)
            archived_projects = [
                (project.name, project.directory_name, project.id) for project in db_archived
            ]
            return projects, archived_projects, db_operations, True
        except Exception as e:
            console.print(f"[bold red]Database error: {e}[/bold red]")
            console.print("Please check your database configuration.")
            choice = _prompt_with_back(
                "Would you like to return to client selection?",
                choices=["y", "n"],
                default="y",
            )
            return BACK_OPTION if choice == "y" else None

    client_dir = base_dir / client_dir_name
    if client_dir.exists():
        for directory in client_dir.iterdir():
            if not directory.is_dir() or not (directory / "project.json").exists():
                continue
            try:
                with open(directory / "project.json") as file:
                    project_info = json.load(file)
                display_name = project_info.get("project_name", directory.name)
                directory_name = project_info.get("directory_name", directory.name)
                if project_info.get("archived_at") or project_info.get("archived", False):
                    archived_projects.append((display_name, directory_name, None))
                else:
                    projects.append((display_name, directory_name))
            except (OSError, json.JSONDecodeError):
                projects.append((directory.name, directory.name))

    return projects, archived_projects, None, False


def _prompt_new_project_name() -> str | None:
    """Prompt for project creation when no projects exist."""
    console.print("[yellow]No projects found for this client. Creating a new project.[/yellow]")
    project_name = Prompt.ask("Enter project name")
    return project_name or None


def _prompt_project_choice(
    page_state: tuple[int, int, int, int],
    page_items: list[tuple[str, str]],
    has_archived: bool,
) -> str | object:
    """Prompt for project selection options."""
    start_idx, end_idx, page, total_pages = page_state
    console.print("\n[bold]Options:[/bold]")
    if page_items:
        console.print(f"{start_idx + 1}-{end_idx}: Select project")
    console.print("c: Create new project")
    if has_archived:
        console.print("a: Manage archived projects")
    console.print("b: Back to client selection")

    extra_choices = ["c"]
    if has_archived:
        extra_choices.append("a")
    if page < total_pages - 1:
        console.print("n: Next Page")
        extra_choices.append("n")
    if page > 0:
        console.print("p: Previous Page")
        extra_choices.append("p")

    choices = [str(start_idx + i + 1) for i in range(len(page_items))] + extra_choices
    return _prompt_with_back(
        "Select a project or create a new one",
        choices=choices,
        default="1" if page_items else "c",
    )


def _resolve_project_choice(
    *,
    choice: str | object,
    context: ProjectChoiceContext,
) -> tuple[str | object | None, int, bool]:
    """Resolve project-selection choice.

    Returns (result, page_delta, should_exit).
    """
    result: str | object | None = None
    page_delta = 0
    should_exit = False

    if choice is BACK_OPTION or choice == "b":
        result = BACK_OPTION
        should_exit = True
    elif choice == "n":
        page_delta = 1
    elif choice == "p":
        page_delta = -1
    elif choice == "c":
        project_name = Prompt.ask("Enter new project name")
        result = slugify_name(project_name) if project_name else None
        should_exit = True
    elif choice == "a" and context.archived_projects:
        result = _manage_archived_projects(
            context.client_dir_name,
            context.db_operations if context.use_database else None,
            context.base_dir,
        )
        if isinstance(result, str):
            should_exit = True
        else:
            result = None
    elif isinstance(choice, str) and choice.isdigit():
        _, directory_name = context.projects[int(choice) - 1]
        result = directory_name
        should_exit = True
    else:
        should_exit = True

    return result, page_delta, should_exit


def _select_mode_interactive() -> str | object | None:
    """Handle interactive screenshot mode selection."""
    console.print("\n[bold]Screenshot Mode[/bold]")
    displays = get_connected_displays()
    mode_options = {"1": "all", "2": "window"}
    option_labels = ["1. All displays", "2. Window"]
    idx = 3
    for d in displays:
        mode_options[str(idx)] = f"display{d}"
        option_labels.append(f"{idx}. Display {d}")
        idx += 1
    mode_options[str(idx)] = "custom"
    option_labels.append(f"{idx}. Custom (choose displays)")

    for label in option_labels:
        console.print(label)

    choices = [str(i) for i in range(1, idx + 1)]
    mode_choice = _prompt_with_back("Select screenshot mode", choices=choices, default="1")

    if mode_choice is BACK_OPTION:
        return BACK_OPTION  # Signal to go back

    if not isinstance(mode_choice, str):
        console.print("[red]Invalid choice type. Please try again.[/red]")
        return None

    mode = mode_options[mode_choice]

    if mode == "custom":
        while True:
            # Allow 'b' to cancel custom selection and return to mode selection?
            # For simplicity now, we assume once you start custom, you finish or restart.
            # Adding 'back' here would require returning BACK_OPTION from this inner loop too.
            custom_input = Prompt.ask(
                f"Enter display numbers separated by space or comma (available: "
                f"{' '.join(str(d) for d in displays)})"
            )
            # if custom_input.lower() == 'b': return BACK_OPTION # Requires handling in the caller

            parts = [p for p in custom_input.replace(",", " ").split() if p.isdigit()]
            chosen = [int(p) for p in parts]
            if all(d in displays for d in chosen) and chosen:
                return f"custom:{','.join(str(d) for d in chosen)}"
            else:
                console.print(
                    f"[red]Invalid selection. Please choose from: "
                    f"{' '.join(str(d) for d in displays)}[/red]"
                )
    else:
        return mode


def _select_timer_interactive() -> int | str | object | None:
    """Handle interactive timer selection."""
    console.print("\n[bold]Timer Settings:[/bold]")

    timer_options_map = _build_timer_options_map(get_default_screenshot_timer())
    for key, (label, _) in timer_options_map.items():
        console.print(f"{key}. {label}")

    timer_choice = _prompt_with_back(
        "Select timer setting",
        choices=list(timer_options_map.keys()),
        default="1",
    )

    if timer_choice is BACK_OPTION:
        return BACK_OPTION  # Signal to go back

    if not isinstance(timer_choice, str):
        console.print("[red]Invalid choice type. Please try again.[/red]")
        return None

    _, timer_value = timer_options_map[timer_choice]
    if timer_value == "custom":
        return _prompt_custom_timer_interval()
    return timer_value


def _build_timer_options_map(default_timer: int | str) -> dict[str, tuple[str, int | str]]:
    """Build timer option menu entries with default timer first."""
    standard_options: list[tuple[str, int | str]] = [
        ("Every 15 minutes", 15),
        ("Every 30 minutes", 30),
        ("Every 1 hour", 60),
        ("Custom interval", "custom"),
        ("Manual mode (no automatic screenshots)", "manual"),
    ]
    options: dict[str, tuple[str, int | str]] = {"1": _default_timer_option(default_timer)}
    option_number = 2
    for label, value in standard_options:
        if value == default_timer:
            continue
        options[str(option_number)] = (label, value)
        option_number += 1
    return options


def _default_timer_option(default_timer: int | str) -> tuple[str, int | str]:
    """Return label/value tuple for default timer option."""
    if default_timer == "manual":
        return "Default (Manual mode)", "manual"
    if default_timer == DEFAULT_TIMER_15_MINUTES:
        return "Default (Every 15 minutes)", DEFAULT_TIMER_15_MINUTES
    if default_timer == DEFAULT_TIMER_30_MINUTES:
        return "Default (Every 30 minutes)", DEFAULT_TIMER_30_MINUTES
    if default_timer == DEFAULT_TIMER_60_MINUTES:
        return "Default (Every 1 hour)", DEFAULT_TIMER_60_MINUTES
    return f"Default (Every {default_timer} minutes)", default_timer


def _prompt_custom_timer_interval() -> int:
    """Prompt for a positive integer minute interval."""
    while True:
        custom_input = Prompt.ask("Enter custom interval in minutes", default="10")
        if custom_input.isdigit() and int(custom_input) > 0:
            return int(custom_input)
        console.print("[red]Invalid input. Please enter a positive integer.[/red]")


def interactive_project_selection() -> dict[str, Any] | None:
    """Interactive project selection mode with back functionality."""
    console.print("[bold]Screenshot Capture Session Setup[/bold]")
    console.print("=================================")
    console.print("(Enter 'b' at any prompt to go back to the previous step)")

    base_dir = Path(get_screenshots_dir())
    if not base_dir.exists():
        base_dir.mkdir(parents=True, exist_ok=True)

    client_dir_name: str | None = None
    project_name: str | None = None
    mode: str | None = None
    timer: int | str | None = None

    step = STEP_SELECT_CLIENT
    max_steps = STEP_SELECT_TIMER
    client_creation_attempts = 0
    max_client_creation_attempts = 3

    while step <= max_steps:
        result = _run_interactive_setup_step(step, base_dir, client_dir_name)
        next_step, should_exit, client_creation_attempts = _advance_setup_state(
            step=step,
            result=result,
            client_creation_attempts=client_creation_attempts,
            max_client_creation_attempts=max_client_creation_attempts,
        )
        if should_exit:
            return None
        if next_step is None:
            console.print(f"[yellow]Retrying step {step}...[/yellow]")
            continue

        if step == STEP_SELECT_CLIENT and isinstance(result, str):
            client_dir_name = result
        elif step == STEP_SELECT_PROJECT and isinstance(result, str):
            project_name = result
        elif step == STEP_SELECT_MODE and isinstance(result, str):
            mode = result
        elif step == STEP_SELECT_TIMER and (
            isinstance(result, int) or (isinstance(result, str) and result == "manual")
        ):
            timer = result
        step = next_step

    if client_dir_name and project_name and mode is not None and timer is not None:
        return {"client": client_dir_name, "project": project_name, "mode": mode, "timer": timer}

    console.print("[red]Setup incomplete. Exiting interactive setup.[/red]")
    return None


def _run_interactive_setup_step(
    step: int,
    base_dir: Path,
    client_dir_name: str | None,
) -> str | int | object | None:
    """Run one interactive setup step and return selection."""
    if step == STEP_SELECT_CLIENT:
        return _select_client_interactive(base_dir)
    if step == STEP_SELECT_PROJECT:
        if not client_dir_name:
            console.print(
                "[red]Error: Client directory name not set. Returning to client selection.[/red]"
            )
            return BACK_OPTION
        return _select_project_interactive(client_dir_name, base_dir)
    if step == STEP_SELECT_MODE:
        return _select_mode_interactive()
    return _select_timer_interactive()


def _advance_setup_state(
    *,
    step: int,
    result: str | int | object | None,
    client_creation_attempts: int,
    max_client_creation_attempts: int,
) -> tuple[int | None, bool, int]:
    """Compute step transition for interactive setup."""
    if step == STEP_SELECT_CLIENT and result is BACK_OPTION:
        console.print("[yellow]Cancelled. Returning to main menu.[/yellow]")
        return None, True, client_creation_attempts

    if step == STEP_SELECT_CLIENT and result is None:
        attempts = client_creation_attempts + 1
        if attempts >= max_client_creation_attempts:
            console.print(
                "[bold red]Maximum client creation attempts reached. Exiting setup.[/bold red]"
            )
            return None, True, attempts
        return None, False, attempts

    if result is BACK_OPTION:
        return max(step - 1, STEP_SELECT_CLIENT), False, client_creation_attempts
    if result is None:
        return None, False, client_creation_attempts

    attempts = 0 if step == STEP_SELECT_CLIENT else client_creation_attempts
    return step + 1, False, attempts
