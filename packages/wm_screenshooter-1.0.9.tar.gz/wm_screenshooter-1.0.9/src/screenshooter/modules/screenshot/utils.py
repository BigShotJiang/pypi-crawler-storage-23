#!/usr/bin/env python3
"""Utility functions for the screenshot module."""

import importlib
import platform
import sys
import time
from typing import Any

# Platform-specific imports for keyboard input
if platform.system() == "Windows":
    import msvcrt
else:
    import select
    import termios
    import tty


# Sentinel value for 'back' option in interactive prompts
BACK_OPTION = object()
KEY_POLL_TIMEOUT_SECONDS = 0.1
CTRL_C_ASCII = 3


def get_key() -> str | None:
    """Get a single keypress from the user with a timeout.

    Works cross-platform on Windows, macOS, and Linux.
    """
    if platform.system() == "Windows":
        return _get_key_windows()
    else:
        return _get_key_unix()


def ensure_terminal_cooked_mode() -> None:
    """Restore canonical terminal mode on Unix-like systems.

    This is a safety helper for cases where a prior process crashed while the
    terminal was in raw mode.
    """
    if platform.system() == "Windows":
        return

    if not sys.stdin.isatty():
        return

    try:
        fd = sys.stdin.fileno()
        attrs = termios.tcgetattr(fd)
        attrs[3] = attrs[3] | termios.ICANON | termios.ECHO
        termios.tcsetattr(fd, termios.TCSADRAIN, attrs)
    except Exception:
        pass


def _get_key_windows() -> str | None:
    """Get a single keypress on Windows."""
    try:
        # Check if a key is available (non-blocking)
        start = time.time()
        while time.time() - start < KEY_POLL_TIMEOUT_SECONDS:
            if msvcrt.kbhit():
                ch = msvcrt.getch()
                # Handle special keys
                if ch == b"\x03":  # Ctrl+C
                    return "ctrl+c"
                try:
                    return ch.decode("utf-8").lower()
                except UnicodeDecodeError:
                    return None
            time.sleep(0.01)
        return None
    except Exception:
        return None


def _get_key_unix() -> str | None:
    """Get a single keypress on Unix-like systems (macOS, Linux)."""
    fd: int | None = None
    old_settings: list[Any] | None = None
    try:
        # Save terminal settings
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        # Set terminal to raw mode
        tty.setraw(fd)

        # Use select to check if input is available (with timeout of 0.1 seconds)
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)

        if rlist:
            # Input is available, read it
            ch = sys.stdin.read(1)
            if not ch:
                return None

            key = ch.lower()

            # Check for Ctrl+C (ASCII value 3) and handle it specially
            if ord(ch) == CTRL_C_ASCII:  # Ctrl+C pressed
                return "ctrl+c"

            # Flush any remaining input to prevent key repeat issues
            termios.tcflush(fd, termios.TCIFLUSH)
        else:
            # No input available
            key = None

        return key
    except Exception:
        # If anything goes wrong, return None
        return None
    finally:
        if fd is not None and old_settings is not None:
            try:
                # Always restore cooked/echo mode, even on exceptions.
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            except Exception:
                pass


def get_text_input(prompt: str) -> str:
    """Get free-form text input with robust backspace/line-editing support.

    Works cross-platform on Windows, macOS, and Linux.
    Ensures the terminal is in canonical (cooked) mode with echo enabled while
    reading, regardless of any prior raw mode usage elsewhere.
    """
    try:
        importlib.import_module("readline")
    except ImportError:
        pass

    if platform.system() == "Windows":
        # Windows doesn't need special terminal mode handling
        return input(prompt)

    fd = None
    old_settings = None
    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        cooked = termios.tcgetattr(fd)
        # Enable canonical input (ICANON) and echo (ECHO)
        cooked[3] = cooked[3] | termios.ICANON | termios.ECHO
        termios.tcsetattr(fd, termios.TCSADRAIN, cooked)
        return input(prompt)
    finally:
        if fd is not None and old_settings is not None:
            try:
                termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            except Exception:
                pass


def get_connected_displays() -> list[int]:
    """Return a list of connected display numbers (1-based).

    Uses mss for cross-platform monitor detection.
    """
    try:
        mss = importlib.import_module("mss")

        with mss.mss() as sct:
            # mss.monitors[0] is the "all monitors" virtual screen
            # mss.monitors[1:] are individual monitors
            num_monitors = len(sct.monitors) - 1
            return list(range(1, num_monitors + 1)) if num_monitors > 0 else [1]
    except Exception:
        return [1]  # Fallback to at least one display


def create_slash_command_system(commands: dict[str, dict[str, Any]]) -> None:
    """Create a simpler slash command system that doesn't interfere with input visibility.

    Args:
        commands: Dictionary mapping command names to dictionaries with
            'description' and 'handler' keys

    Returns:
        A function that handles command input and processing
    """

    def process_commands() -> str | None:
        """Process slash commands, returning the command name if valid.

        Returns:
            The command name (without slash) or None if no command/invalid
        """
        key = get_key()
        if not key:
            return None

        if key == "ctrl+c":
            return "ctrl+c"

        # Return the key directly for command handlers to process
        return key

    return process_commands
