#!/usr/bin/env python3
"""Project and session models for ScreenShooter."""

from datetime import datetime

from pydantic import BaseModel, Field


class ProjectInfo(BaseModel):
    """Project information model."""

    project_name: str
    directory_name: str  # Filesystem directory name
    client_name: str  # Associated client name
    active: bool = True
    archived_at: str = ""  # Empty string means not archived
    created_at: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    updated_at: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


class SessionInfo(BaseModel):
    """Session information model for JSON files (basic info only, no notes/captions)."""

    session_name: str
    session_start_time: str
    session_finish_time: str = ""
    client_name: str
    project_name: str
    timer: str
    archived_at: str = ""
    last_updated: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
