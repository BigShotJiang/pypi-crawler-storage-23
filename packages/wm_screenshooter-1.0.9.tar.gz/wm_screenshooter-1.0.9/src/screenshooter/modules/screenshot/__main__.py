#!/usr/bin/env python3
"""Main entry point for running the screenshot module directly."""

import sys

from .main import main

if __name__ == "__main__":
    sys.exit(main())
