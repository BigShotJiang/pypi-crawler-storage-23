#!/usr/bin/env python3
"""Backup functionality for ScreenShooter Mac.

This module provides helpers and a CLI entry point for creating backups of:

- settings.json
- the SQLite database (screenshooter.db)
- the full screenshots directory (including the database), plus settings.json

Backups are created as ZIP archives and can be optionally password protected.
"""

import json
import logging
import math
import os
import zipfile
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import boto3
import click
import pyzipper
from botocore.exceptions import BotoCoreError, ClientError
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TransferSpeedColumn,
)

from screenshooter.modules.database import get_default_database_path
from screenshooter.modules.s3 import get_s3_settings, is_s3_enabled
from screenshooter.modules.s3 import log_entry as log_s3_event
from screenshooter.modules.settings.logging_utils import GENERAL_LOG_FILE, LOGS_DIR
from screenshooter.modules.settings.models import AppSettings, BackupSettings, SettingsManager
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

logger = logging.getLogger(__name__)
console = Console()
backup_logger = logging.getLogger("screenshooter.backup")

BACKUP_TYPES = ("settings", "db", "all")
SUMMARY_KEY_MIN_PARTS = 2
PROJECT_PATH_MIN_PARTS = 2
BACKUP_UPLOAD_STATE_FILE = Path.home() / ".config" / "screenshooter" / "backup_upload_state.json"
MULTIPART_PART_SIZE_BYTES = 8 * 1024 * 1024
ZipArchive = zipfile.ZipFile | pyzipper.AESZipFile


def _configure_backup_logger() -> None:
    """Configure backup logger output files."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    backup_logger.setLevel(logging.INFO)
    backup_logger.propagate = False

    target_files = [LOGS_DIR / "backup.log", GENERAL_LOG_FILE]
    attached_paths = {
        Path(handler.baseFilename).expanduser().resolve()
        for handler in backup_logger.handlers
        if isinstance(handler, logging.FileHandler)
    }
    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for target in target_files:
        normalized = target.expanduser().resolve()
        if normalized in attached_paths:
            continue
        file_handler = logging.FileHandler(normalized, encoding="utf-8")
        file_handler.setFormatter(formatter)
        backup_logger.addHandler(file_handler)


def _backup_log(event: str, details: dict[str, Any], *, include_s3_log: bool = False) -> None:
    """Write structured backup event logs."""
    _configure_backup_logger()
    message = f"{event} | {json.dumps(details, sort_keys=True, default=str)}"
    backup_logger.info(message)
    if include_s3_log:
        log_s3_event(f"BACKUP {message}")


class BackupError(Exception):
    """Custom exception for backup-related errors."""


@dataclass(frozen=True)
class BackupPayloadContext:
    """Context required to write backup payload into a ZIP archive."""

    backup_type: str
    settings_file: Path
    db_path: Path
    screenshots_dir: Path
    output_base_dir: Path
    verbosity: str


@dataclass(frozen=True)
class BackupRuntimeContext:
    """Resolved runtime context for backup orchestration."""

    backup_type: str
    settings_file: Path
    backup_settings: BackupSettings
    effective_verbosity: str
    output_base_dir: Path
    zip_path: Path
    password: bytes | None
    backup_s3_enabled: bool
    effective_bucket: str
    backup_prefix: str
    payload_context: BackupPayloadContext
    output_dir_override_used: bool
    verbosity_override_used: bool


def _state_file_path() -> Path:
    """Return backup upload state file path and ensure parent directory exists."""
    BACKUP_UPLOAD_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    return BACKUP_UPLOAD_STATE_FILE


def _load_backup_upload_state() -> dict[str, Any] | None:
    """Load backup upload state from disk."""
    path = _state_file_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _save_backup_upload_state(state: dict[str, Any]) -> None:
    """Persist backup upload state atomically."""
    path = _state_file_path()
    temp_path = path.with_suffix(".tmp")
    temp_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    temp_path.replace(path)


def _clear_backup_upload_state() -> None:
    """Remove backup upload state file if present."""
    path = _state_file_path()
    if path.exists():
        path.unlink()


def get_paused_backup_upload_state() -> dict[str, Any] | None:
    """Return resumable backup upload state if present."""
    state = _load_backup_upload_state()
    if state is None:
        return None
    status = str(state.get("status", "")).strip().lower()
    if status in {"in_progress", "paused"}:
        return state
    return None


def get_paused_backup_upload_status_text() -> str | None:
    """Build a concise status line for paused upload prompts."""
    state = get_paused_backup_upload_state()
    if state is None:
        return None
    key = str(state.get("object_key", "")).strip() or "(unknown key)"
    file_path = str(state.get("file_path", "")).strip() or "(unknown file)"
    uploaded_parts = len(state.get("parts", []))
    total_parts = int(state.get("total_parts", 0) or 0)
    return (
        f"Paused upload found: key={key}, parts={uploaded_parts}/{total_parts}, "
        f"file={Path(file_path).name}"
    )


def handle_paused_backup_upload_interactive(
    prompt_choice: Callable[[str, list[str], str], str],
    *,
    console_instance: Console | None = None,
) -> bool:
    """Handle paused backup upload interactively.

    Returns:
        True when a paused upload was resumed and completed.
        False when no paused upload exists, resume was skipped, or resume failed.
    """
    state = get_paused_backup_upload_state()
    if state is None:
        return False

    active_console = console_instance or console
    status_text = get_paused_backup_upload_status_text() or "Paused backup upload found."
    active_console.print(f"[yellow]{status_text}[/yellow]")
    resume_choice = prompt_choice(
        "Would you like to continue this paused backup upload first?",
        ["y", "n"],
        "y",
    )

    if resume_choice == "n":
        _, message = discard_paused_backup_upload()
        active_console.print(f"[dim]{message}[/dim]")
        return False

    total_size = int(state.get("file_size") or 0)
    uploaded_bytes = sum(int(part.get("size", 0)) for part in state.get("parts", []))

    if total_size <= 0:
        resumed, message = resume_paused_backup_upload()
    else:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeElapsedColumn(),
            console=active_console,
        ) as progress:
            task_id = progress.add_task(
                "Resuming paused backup upload...",
                total=total_size,
                completed=min(uploaded_bytes, total_size),
            )

            def _on_resume_progress(bytes_amount: int) -> None:
                progress.update(task_id, advance=bytes_amount)

            resumed, message = resume_paused_backup_upload(_on_resume_progress)
            if resumed:
                progress.update(task_id, completed=total_size)

    if resumed:
        active_console.print(f"[green]{message}[/green]")
        return True

    active_console.print(f"[yellow]{message}[/yellow]")
    return False


def _get_settings_and_file() -> tuple[AppSettings, Path]:
    """Load application settings and return them with their file path."""
    manager = SettingsManager()
    settings = manager.load_settings()
    return settings, manager.settings_file


def _resolve_output_directory(backup_settings: BackupSettings, output_dir: str | None) -> Path:
    """Resolve the output directory for backups.

    Preference order:
    1. CLI-provided output directory
    2. Configured backup_directory in settings
    3. Default to <screenshots_dir>/backups
    """
    if output_dir:
        target_dir = Path(output_dir).expanduser()
    elif backup_settings.backup_directory:
        target_dir = Path(backup_settings.backup_directory).expanduser()
    else:
        target_dir = Path(get_screenshots_dir()) / "backups"

    target_dir.mkdir(parents=True, exist_ok=True)
    return target_dir


def _add_file_to_zip(zip_file: ZipArchive, source: Path, arcname: str, verbosity: str) -> None:
    """Add a single file to the given ZIP archive."""
    if not source.exists():
        raise BackupError(f"Source file not found: {source}")
    if verbosity == "full":
        # Lightweight progress indicator so user can see per-file activity
        console.print(f"[dim]Adding to backup:[/dim] {arcname}")
    zip_file.write(source, arcname=arcname)


def _summarize_path_for_backup_log(arcname_path: Path) -> str:
    """Summarize path at project/category level for backup logging."""
    parts = arcname_path.parts
    if len(parts) >= PROJECT_PATH_MIN_PARTS:
        client = parts[0]
        project = parts[1]
        nested = parts[2:]
        if "reports" in nested:
            return f"{client}/{project}/reports"
        if "sessions" in nested:
            return f"{client}/{project}/screenshots"
        return f"{client}/{project}/project"
    if len(parts) == 1:
        return parts[0]
    return str(arcname_path)


def _add_directory_to_zip(
    zip_file: ZipArchive,
    root_dir: Path,
    exclude_dir: Path | None,
    verbosity: str,
) -> set[str]:
    """Recursively add a directory to the ZIP archive.

    Args:
        zip_file: Open pyzipper AESZipFile instance.
        root_dir: Root directory to add.
        exclude_dir: Optional directory to exclude (e.g., the backup directory itself).
    """
    root_dir = root_dir.resolve()
    exclude_dir = exclude_dir.resolve() if exclude_dir else None

    seen_summaries: set[str] = set()
    log_summaries: set[str] = set()

    for dirpath, _, filenames in os.walk(root_dir):
        current_dir = Path(dirpath).resolve()
        if exclude_dir and str(current_dir).startswith(str(exclude_dir)):
            continue

        for filename in filenames:
            file_path = current_dir / filename
            if exclude_dir and str(file_path).startswith(str(exclude_dir)):
                continue

            # Store paths relative to the screenshots root directory
            arcname_path = file_path.relative_to(root_dir)
            arcname = str(arcname_path)
            log_summaries.add(_summarize_path_for_backup_log(arcname_path))

            if verbosity == "summary":
                # Show a single line per client/project pair (or top-level path if shallower)
                parts = arcname_path.parts
                if len(parts) >= SUMMARY_KEY_MIN_PARTS:
                    summary_key = f"{parts[0]}/{parts[1]}"
                elif parts:
                    summary_key = parts[0]
                else:
                    summary_key = arcname

                if summary_key not in seen_summaries:
                    console.print(f"[dim]Adding to backup (client/project):[/dim] {summary_key}")
                    seen_summaries.add(summary_key)

                _add_file_to_zip(zip_file, file_path, arcname=arcname, verbosity="off")
            else:
                _add_file_to_zip(zip_file, file_path, arcname=arcname, verbosity=verbosity)

    return log_summaries


def _resolve_settings_sources(settings: AppSettings | None) -> tuple[AppSettings, Path]:
    """Resolve settings object and its source file path."""
    if settings is None:
        return _get_settings_and_file()

    manager = SettingsManager()
    return settings, manager.settings_file


def _resolve_backup_verbosity(backup_settings: BackupSettings, verbosity: str | None) -> str:
    """Resolve effective verbosity using CLI override, settings, then default."""
    effective_verbosity = (
        verbosity or getattr(backup_settings, "verbosity", "full") or "full"
    ).lower()
    if effective_verbosity not in ("off", "summary", "full"):
        return "full"
    return effective_verbosity


def _build_backup_password(backup_settings: BackupSettings) -> bytes | None:
    """Encode configured backup password when encryption is enabled."""
    if backup_settings.password_enabled and backup_settings.password:
        return backup_settings.password.encode("utf-8")
    return None


def _is_backup_s3_upload_enabled(backup_settings: BackupSettings) -> bool:
    """Return True when backup S3 upload is enabled in backup settings."""
    return bool(getattr(backup_settings, "upload_to_s3_enabled", False))


def _validate_remote_backup_password_requirement(
    backup_settings: BackupSettings, password: bytes | None
) -> None:
    """Validate that remote backup uploads are always password-protected."""
    if _is_backup_s3_upload_enabled(backup_settings) and not password:
        raise BackupError(
            "S3 backup upload requires backup password protection. "
            "Enable backup password protection and set a password in Backup Settings."
        )


def _create_s3_client_from_settings() -> tuple[Any | None, str | None]:
    """Create an S3 client from app settings."""
    if not is_s3_enabled():
        return None, "S3/R2 is disabled in global settings."

    s3_settings = get_s3_settings()
    endpoint_url = str(s3_settings.get("endpoint_url") or "")
    access_key_id = str(s3_settings.get("access_key_id") or "")
    secret_access_key = str(s3_settings.get("secret_access_key") or "")
    region = str(s3_settings.get("region") or "auto")

    missing_fields = [
        name
        for name, value in {
            "endpoint_url": endpoint_url,
            "access_key_id": access_key_id,
            "secret_access_key": secret_access_key,
        }.items()
        if not value
    ]
    if missing_fields:
        missing = ", ".join(missing_fields)
        return (
            None,
            f"S3 backup upload skipped because required S3 setting(s) are missing: {missing}.",
        )

    client = boto3.client(
        "s3",
        endpoint_url=endpoint_url,
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        region_name=region,
    )
    return client, None


def _build_backup_object_key(zip_path: Path, backup_settings: BackupSettings) -> str:
    """Build backup object key using backup prefix settings."""
    backup_prefix = (
        str(getattr(backup_settings, "s3_path_prefix", "backups") or "").strip().strip("/")
    )
    if backup_prefix:
        return f"{backup_prefix}/{zip_path.name}"
    return zip_path.name


def _list_uploaded_parts(
    s3_client: Any,
    bucket_name: str,
    object_key: str,
    upload_id: str,
) -> list[dict[str, Any]]:
    """List uploaded parts for an in-progress multipart upload."""
    parts: list[dict[str, Any]] = []
    paginator = s3_client.get_paginator("list_parts")
    for page in paginator.paginate(Bucket=bucket_name, Key=object_key, UploadId=upload_id):
        for part in page.get("Parts", []):
            part_number = int(part.get("PartNumber"))
            etag = str(part.get("ETag", ""))
            size = int(part.get("Size", 0))
            parts.append({"part_number": part_number, "etag": etag, "size": size})
    return sorted(parts, key=lambda item: int(item["part_number"]))


def _abort_remote_multipart_upload(
    s3_client: Any,
    bucket_name: str,
    object_key: str,
    upload_id: str,
) -> tuple[bool, str]:
    """Abort multipart upload on remote bucket."""
    try:
        s3_client.abort_multipart_upload(
            Bucket=bucket_name,
            Key=object_key,
            UploadId=upload_id,
        )
        return True, "Remote multipart upload aborted."
    except (ClientError, BotoCoreError) as exc:
        return False, f"Could not abort remote multipart upload: {exc}"


def discard_paused_backup_upload() -> tuple[bool, str]:
    """Delete local paused state and attempt remote multipart abort."""
    state = get_paused_backup_upload_state()
    if state is None:
        return True, "No paused backup upload state found."

    bucket_name = str(state.get("bucket_name") or "")
    object_key = str(state.get("object_key") or "")
    upload_id = str(state.get("upload_id") or "")
    messages: list[str] = []

    client, client_error = _create_s3_client_from_settings()
    if client is None:
        messages.append(client_error or "S3 client unavailable; skipped remote abort.")
    elif bucket_name and object_key and upload_id:
        ok, message = _abort_remote_multipart_upload(client, bucket_name, object_key, upload_id)
        messages.append(message)
        if not ok:
            logger.warning(message)
    else:
        messages.append("State missing remote upload identifiers; skipped remote abort.")

    _clear_backup_upload_state()
    messages.append("Local paused backup upload state cleared.")
    _backup_log(
        "backup_upload_discarded",
        {
            "bucket_name": bucket_name,
            "object_key": object_key,
            "upload_id": upload_id,
            "message": " ".join(messages),
        },
        include_s3_log=True,
    )
    return True, " ".join(messages)


@dataclass(frozen=True)
class MultipartUploadRequest:
    """Inputs for multipart backup upload orchestration."""

    s3_client: Any
    zip_path: Path
    bucket_name: str
    object_key: str
    backup_type: str
    state: dict[str, Any] | None = None
    progress_callback: Callable[[int], None] | None = None


@dataclass(frozen=True)
class MultipartFileContext:
    """Derived file metadata for multipart upload flow."""

    file_size: int
    file_mtime: float
    part_size: int
    total_parts: int


def _resolve_multipart_file_context(
    zip_path: Path,
    state: dict[str, Any] | None,
) -> MultipartFileContext:
    """Resolve file metadata and multipart sizing from persisted state."""
    file_size = zip_path.stat().st_size
    file_mtime = zip_path.stat().st_mtime
    part_size = int((state or {}).get("part_size") or MULTIPART_PART_SIZE_BYTES)
    total_parts = max(1, math.ceil(file_size / part_size))
    return MultipartFileContext(
        file_size=file_size,
        file_mtime=file_mtime,
        part_size=part_size,
        total_parts=total_parts,
    )


def _init_or_restore_multipart_upload(
    request: MultipartUploadRequest,
) -> tuple[str, list[dict[str, Any]]]:
    """Restore uploaded parts for resumable upload or create a new multipart upload."""
    upload_id = str((request.state or {}).get("upload_id") or "")
    parts: list[dict[str, Any]] = []
    if upload_id:
        try:
            parts = _list_uploaded_parts(
                request.s3_client,
                request.bucket_name,
                request.object_key,
                upload_id,
            )
        except (ClientError, BotoCoreError):
            upload_id = ""
            parts = []

    if upload_id:
        return upload_id, parts

    response = request.s3_client.create_multipart_upload(
        Bucket=request.bucket_name,
        Key=request.object_key,
        Metadata={"backup_type": request.backup_type, "encrypted": "true"},
    )
    upload_id = str(response["UploadId"])
    _backup_log(
        "backup_upload_multipart_created",
        {
            "bucket_name": request.bucket_name,
            "object_key": request.object_key,
            "upload_id": upload_id,
            "backup_type": request.backup_type,
        },
        include_s3_log=True,
    )
    return upload_id, parts


def _build_upload_state(
    request: MultipartUploadRequest,
    file_context: MultipartFileContext,
    upload_id: str,
    parts: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build persisted multipart upload state payload."""
    return {
        "version": 1,
        "status": "in_progress",
        "backup_type": request.backup_type,
        "file_path": str(request.zip_path),
        "file_size": file_context.file_size,
        "file_mtime": file_context.file_mtime,
        "bucket_name": request.bucket_name,
        "object_key": request.object_key,
        "upload_id": upload_id,
        "part_size": file_context.part_size,
        "total_parts": file_context.total_parts,
        "parts": parts,
        "updated_at": datetime.now().isoformat(),
    }


def _mark_upload_paused(upload_state: dict[str, Any], details: dict[str, Any]) -> None:
    """Persist paused multipart upload state and emit pause logs."""
    upload_state["status"] = "paused"
    upload_state["updated_at"] = datetime.now().isoformat()
    _save_backup_upload_state(upload_state)
    _backup_log("backup_upload_paused", details, include_s3_log=True)


def _upload_missing_parts(
    request: MultipartUploadRequest,
    file_context: MultipartFileContext,
    upload_id: str,
    upload_state: dict[str, Any],
    uploaded_part_map: dict[int, dict[str, Any]],
) -> str | None:
    """Upload pending multipart parts and persist state after each successful part."""
    try:
        with open(request.zip_path, "rb") as source_file:
            for part_number in range(1, file_context.total_parts + 1):
                if part_number in uploaded_part_map:
                    continue

                offset = (part_number - 1) * file_context.part_size
                source_file.seek(offset)
                payload = source_file.read(file_context.part_size)
                if not payload:
                    break

                response = request.s3_client.upload_part(
                    Bucket=request.bucket_name,
                    Key=request.object_key,
                    PartNumber=part_number,
                    UploadId=upload_id,
                    Body=payload,
                )
                uploaded_part_map[part_number] = {
                    "part_number": part_number,
                    "etag": str(response["ETag"]),
                    "size": len(payload),
                }
                upload_state["parts"] = sorted(
                    uploaded_part_map.values(),
                    key=lambda item: int(item["part_number"]),
                )
                upload_state["updated_at"] = datetime.now().isoformat()
                _save_backup_upload_state(upload_state)
                if request.progress_callback is not None:
                    request.progress_callback(len(payload))
    except (KeyboardInterrupt, SystemExit):
        _mark_upload_paused(
            upload_state,
            {
                "bucket_name": request.bucket_name,
                "object_key": request.object_key,
                "upload_id": upload_id,
                "reason": "keyboard_interrupt",
                "uploaded_parts": len(upload_state.get("parts", [])),
                "total_parts": file_context.total_parts,
            },
        )
        return "Backup upload paused. Run `screenshooter backup` to resume."
    except (ClientError, BotoCoreError, OSError) as exc:
        _mark_upload_paused(
            upload_state,
            {
                "bucket_name": request.bucket_name,
                "object_key": request.object_key,
                "upload_id": upload_id,
                "reason": "error",
                "error": str(exc),
                "uploaded_parts": len(upload_state.get("parts", [])),
                "total_parts": file_context.total_parts,
            },
        )
        return f"S3 backup upload paused after error: {exc}"
    return None


def _build_completed_parts(uploaded_part_map: dict[int, dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert persisted uploaded parts into complete request payload."""
    return [
        {"PartNumber": int(part["part_number"]), "ETag": str(part["etag"])}
        for part in sorted(uploaded_part_map.values(), key=lambda item: int(item["part_number"]))
    ]


def _complete_multipart_upload(
    request: MultipartUploadRequest,
    upload_id: str,
    upload_state: dict[str, Any],
    completed_parts: list[dict[str, Any]],
    total_parts: int,
) -> str | None:
    """Complete multipart upload or pause state when completion preconditions fail."""
    if len(completed_parts) != total_parts:
        _mark_upload_paused(
            upload_state,
            {
                "bucket_name": request.bucket_name,
                "object_key": request.object_key,
                "upload_id": upload_id,
                "reason": "incomplete_parts",
                "uploaded_parts": len(completed_parts),
                "total_parts": total_parts,
            },
        )
        return "S3 backup upload paused because not all parts were uploaded."

    try:
        request.s3_client.complete_multipart_upload(
            Bucket=request.bucket_name,
            Key=request.object_key,
            UploadId=upload_id,
            MultipartUpload={"Parts": completed_parts},
        )
    except (ClientError, BotoCoreError) as exc:
        _mark_upload_paused(
            upload_state,
            {
                "bucket_name": request.bucket_name,
                "object_key": request.object_key,
                "upload_id": upload_id,
                "reason": "complete_failed",
                "error": str(exc),
            },
        )
        return f"S3 backup upload paused before completion: {exc}"

    return None


def _upload_backup_multipart_with_state(request: MultipartUploadRequest) -> tuple[str | None, str]:
    """Upload backup via multipart upload with resumable local state."""
    file_context = _resolve_multipart_file_context(request.zip_path, request.state)
    upload_id, parts = _init_or_restore_multipart_upload(request)
    upload_state = _build_upload_state(request, file_context, upload_id, parts)
    _save_backup_upload_state(upload_state)

    uploaded_part_map = {int(part["part_number"]): part for part in parts}
    pause_message = _upload_missing_parts(
        request,
        file_context,
        upload_id,
        upload_state,
        uploaded_part_map,
    )
    if pause_message:
        return None, pause_message

    completed_parts = _build_completed_parts(uploaded_part_map)
    completion_error = _complete_multipart_upload(
        request,
        upload_id,
        upload_state,
        completed_parts,
        file_context.total_parts,
    )
    if completion_error:
        return None, completion_error

    _clear_backup_upload_state()
    _backup_log(
        "backup_upload_completed",
        {
            "bucket_name": request.bucket_name,
            "object_key": request.object_key,
            "upload_id": upload_id,
            "total_parts": file_context.total_parts,
        },
        include_s3_log=True,
    )
    return request.object_key, ""


def _validate_paused_file_matches(state: dict[str, Any]) -> tuple[Path | None, str | None]:
    """Validate paused upload file exists and still matches persisted size."""
    file_path = Path(str(state.get("file_path") or "")).expanduser()
    if not file_path.exists():
        return None, f"Paused upload file no longer exists: {file_path}"

    expected_size = int(state.get("file_size") or 0)
    if expected_size and file_path.stat().st_size != expected_size:
        return None, "Paused upload file has changed size and cannot be safely resumed."

    return file_path, None


def _validate_paused_remote_fields(state: dict[str, Any]) -> tuple[str | None, str, str, str]:
    """Validate paused upload state includes required remote identifiers."""
    bucket_name = str(state.get("bucket_name") or "")
    object_key = str(state.get("object_key") or "")
    backup_type = str(state.get("backup_type") or "all")
    if not bucket_name or not object_key:
        return "Paused upload state is missing bucket/key information.", "", "", backup_type
    return None, bucket_name, object_key, backup_type


def resume_paused_backup_upload(
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[bool, str]:
    """Resume paused backup upload if resumable state exists."""
    resumed = False
    message = "No paused backup upload state found."
    state = get_paused_backup_upload_state()
    if state is not None:
        file_path, file_error = _validate_paused_file_matches(state)
        if file_error:
            message = file_error
        else:
            client, client_error = _create_s3_client_from_settings()
            if client is None:
                message = client_error or "S3 client unavailable."
            else:
                remote_error, bucket_name, object_key, backup_type = _validate_paused_remote_fields(
                    state
                )
                if remote_error:
                    message = remote_error
                elif file_path is not None:
                    object_name, upload_message = _upload_backup_multipart_with_state(
                        MultipartUploadRequest(
                            s3_client=client,
                            zip_path=file_path,
                            bucket_name=bucket_name,
                            object_key=object_key,
                            backup_type=backup_type,
                            state=state,
                            progress_callback=progress_callback,
                        )
                    )
                    if object_name:
                        _backup_log(
                            "backup_upload_resumed",
                            {
                                "bucket_name": bucket_name,
                                "object_key": object_key,
                                "file_path": str(file_path),
                            },
                            include_s3_log=True,
                        )
                        resumed = True
                        message = f"Resumed backup upload completed: {object_name}"
                    else:
                        message = upload_message

    return resumed, message


def _upload_backup_to_s3(
    zip_path: Path,
    backup_settings: BackupSettings,
    backup_type: str,
    progress_callback: Callable[[int], None] | None = None,
) -> tuple[str | None, str]:
    """Upload backup ZIP to S3 using backup-specific bucket/prefix preferences."""
    s3_settings = get_s3_settings()
    configured_bucket = str(s3_settings.get("bucket_name") or "")
    backup_bucket_override = str(getattr(backup_settings, "s3_bucket_name", "") or "").strip()
    bucket_name = backup_bucket_override or configured_bucket
    if not bucket_name:
        return None, "S3 backup upload skipped because bucket name is not configured."

    existing_state = get_paused_backup_upload_state()
    if existing_state is not None:
        existing_file = str(existing_state.get("file_path") or "")
        if existing_file and Path(existing_file).expanduser() != zip_path:
            return (
                None,
                "S3 backup upload skipped because another paused backup upload exists. "
                "Run `screenshooter backup` to resume or discard it first.",
            )

    client, client_error = _create_s3_client_from_settings()
    if client is None:
        return None, client_error or "S3 backup upload client unavailable."

    object_key = _build_backup_object_key(zip_path, backup_settings)
    return _upload_backup_multipart_with_state(
        MultipartUploadRequest(
            s3_client=client,
            zip_path=zip_path,
            bucket_name=bucket_name,
            object_key=object_key,
            backup_type=backup_type,
            progress_callback=progress_callback,
        )
    )


def _ensure_database_exists(db_path: Path) -> None:
    """Ensure database exists for db-only backups."""
    if db_path.exists():
        return
    raise BackupError(
        f"Database file not found at {db_path}. Have you initialized the database yet?"
    )


def _resolve_excluded_backup_dir(output_base_dir: Path, screenshots_dir: Path) -> Path | None:
    """Exclude output directory when it sits inside screenshots tree."""
    try:
        output_base_dir.relative_to(screenshots_dir)
        return output_base_dir
    except ValueError:
        return None


def _add_all_backup_payload(zip_file: ZipArchive, context: BackupPayloadContext) -> set[str]:
    """Write full backup payload (screenshots tree, optional DB, optional settings)."""
    backup_dir_inside_root = _resolve_excluded_backup_dir(
        context.output_base_dir,
        context.screenshots_dir,
    )

    summaries = _add_directory_to_zip(
        zip_file,
        context.screenshots_dir,
        exclude_dir=backup_dir_inside_root,
        verbosity=context.verbosity,
    )

    if context.db_path.exists():
        _add_file_to_zip(
            zip_file,
            context.db_path,
            arcname="screenshooter.db",
            verbosity=context.verbosity,
        )
        summaries.add("database/screenshooter.db")

    if context.settings_file.exists():
        _add_file_to_zip(
            zip_file,
            context.settings_file,
            arcname="settings.json",
            verbosity=context.verbosity,
        )
        summaries.add("config/settings.json")

    return summaries


def _add_backup_payload(zip_file: ZipArchive, context: BackupPayloadContext) -> set[str]:
    """Write selected backup payload to archive."""
    if context.backup_type == "settings":
        _add_file_to_zip(
            zip_file,
            context.settings_file,
            arcname="settings.json",
            verbosity=context.verbosity,
        )
        return {"config/settings.json"}

    if context.backup_type == "db":
        _ensure_database_exists(context.db_path)
        _add_file_to_zip(
            zip_file,
            context.db_path,
            arcname="screenshooter.db",
            verbosity=context.verbosity,
        )
        return {"database/screenshooter.db"}

    return _add_all_backup_payload(zip_file, context)


def _resolve_backup_runtime_context(
    backup_type: str,
    output_dir: str | None,
    verbosity: str | None,
    settings: AppSettings | None,
) -> BackupRuntimeContext:
    """Resolve backup runtime settings, paths, and payload context."""
    if backup_type not in BACKUP_TYPES:
        raise BackupError(f"Invalid backup type '{backup_type}'. Must be one of {BACKUP_TYPES}.")

    app_settings, settings_file = _resolve_settings_sources(settings)
    backup_settings = getattr(app_settings, "backup", BackupSettings())
    effective_verbosity = _resolve_backup_verbosity(backup_settings, verbosity)
    output_base_dir = _resolve_output_directory(backup_settings, output_dir)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = output_base_dir / f"screenshooter_backup_{backup_type}_{timestamp}.zip"

    password = _build_backup_password(backup_settings)
    _validate_remote_backup_password_requirement(backup_settings, password)
    backup_s3_enabled = _is_backup_s3_upload_enabled(backup_settings)
    s3_settings = get_s3_settings()
    configured_bucket = str(s3_settings.get("bucket_name") or "")
    backup_bucket_override = str(getattr(backup_settings, "s3_bucket_name", "") or "").strip()
    backup_prefix = str(getattr(backup_settings, "s3_path_prefix", "backups") or "backups").strip()

    payload_context = BackupPayloadContext(
        backup_type=backup_type,
        settings_file=settings_file,
        db_path=get_default_database_path().expanduser().resolve(),
        screenshots_dir=Path(get_screenshots_dir()).resolve(),
        output_base_dir=output_base_dir,
        verbosity=effective_verbosity,
    )
    return BackupRuntimeContext(
        backup_type=backup_type,
        settings_file=settings_file,
        backup_settings=backup_settings,
        effective_verbosity=effective_verbosity,
        output_base_dir=output_base_dir,
        zip_path=zip_path,
        password=password,
        backup_s3_enabled=backup_s3_enabled,
        effective_bucket=backup_bucket_override or configured_bucket,
        backup_prefix=backup_prefix,
        payload_context=payload_context,
        output_dir_override_used=bool(output_dir),
        verbosity_override_used=bool(verbosity),
    )


def _log_backup_start(context: BackupRuntimeContext) -> None:
    """Emit structured backup-start log entry."""
    _backup_log(
        "backup_started",
        {
            "backup_type": context.backup_type,
            "output_dir_effective": str(context.output_base_dir),
            "output_dir_override_used": context.output_dir_override_used,
            "verbosity_effective": context.effective_verbosity,
            "verbosity_override_used": context.verbosity_override_used,
            "password_protection_enabled": bool(context.password),
            "s3_upload_enabled": context.backup_s3_enabled,
            "s3_bucket_effective": context.effective_bucket,
            "s3_prefix_effective": context.backup_prefix or "backups",
            "settings_file": str(context.settings_file),
        },
    )


def _log_backup_failure(context: BackupRuntimeContext, exc: OSError) -> None:
    """Emit structured backup-failed log entry."""
    _backup_log(
        "backup_failed",
        {
            "backup_type": context.backup_type,
            "output_zip_path": str(context.zip_path),
            "error": str(exc),
        },
    )


def _create_backup_archive(context: BackupRuntimeContext) -> set[str]:
    """Create backup archive and return high-level payload scope entries."""
    payload_scope_entries: set[str] = set()
    try:
        console.print("[bold]Creating backup...[/bold]")
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Creating backup...", total=None)

            if context.password:
                with pyzipper.AESZipFile(
                    context.zip_path,
                    "w",
                    compression=pyzipper.ZIP_DEFLATED,
                    encryption=pyzipper.WZ_AES,
                ) as zip_file:
                    zip_file.setpassword(context.password)
                    payload_scope_entries = _add_backup_payload(zip_file, context.payload_context)
            else:
                with zipfile.ZipFile(
                    context.zip_path,
                    "w",
                    compression=zipfile.ZIP_DEFLATED,
                ) as zip_file:
                    payload_scope_entries = _add_backup_payload(zip_file, context.payload_context)
    except OSError as exc:
        logger.error("Backup failed due to file system error: %s", exc)
        _log_backup_failure(context, exc)
        raise BackupError(f"Backup failed due to file system error: {exc}") from exc

    return payload_scope_entries


def _upload_backup_with_progress(
    zip_path: Path,
    backup_settings: BackupSettings,
    backup_type: str,
) -> tuple[str | None, str | None]:
    """Upload backup and show progress bars for known-size and unknown-size payloads."""
    console.print("[bold]Uploading backup to S3/R2...[/bold]")
    upload_size = zip_path.stat().st_size if zip_path.exists() else None
    if upload_size is not None and upload_size > 0:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task_id = progress.add_task("Uploading backup to S3/R2...", total=upload_size)

            def _on_upload_progress(bytes_amount: int) -> None:
                progress.update(task_id, advance=bytes_amount)

            uploaded_object, warning_message = _upload_backup_to_s3(
                zip_path,
                backup_settings,
                backup_type,
                progress_callback=_on_upload_progress,
            )
            if uploaded_object:
                progress.update(task_id, completed=upload_size)
            return uploaded_object, warning_message

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Uploading backup to S3/R2...", total=None)
        return _upload_backup_to_s3(zip_path, backup_settings, backup_type)


def _maybe_upload_backup_to_s3(context: BackupRuntimeContext) -> tuple[str | None, str | None]:
    """Upload backup when S3 upload is enabled and report user-facing warnings."""
    if not context.backup_s3_enabled:
        return None, None

    uploaded_object, warning_message = _upload_backup_with_progress(
        context.zip_path,
        context.backup_settings,
        context.backup_type,
    )
    if uploaded_object:
        console.print(f"[green]Backup uploaded to S3/R2:[/green] {uploaded_object}")
    elif warning_message:
        logger.warning(warning_message)
        console.print(f"[yellow]{warning_message}[/yellow]")
    return uploaded_object, warning_message


def _log_backup_completion(
    context: BackupRuntimeContext,
    payload_scope_entries: set[str],
    uploaded_object: str | None,
    warning_message: str | None,
) -> None:
    """Emit structured backup-completed log entry."""
    _backup_log(
        "backup_completed",
        {
            "backup_type": context.backup_type,
            "zip_path": str(context.zip_path),
            "zip_size_bytes": context.zip_path.stat().st_size
            if context.zip_path.exists()
            else None,
            "settings_used": {
                "output_dir_effective": str(context.output_base_dir),
                "verbosity_effective": context.effective_verbosity,
                "password_protection_enabled": bool(context.password),
                "s3_upload_enabled": context.backup_s3_enabled,
                "s3_bucket_effective": context.effective_bucket,
                "s3_prefix_effective": context.backup_prefix or "backups",
            },
            "backed_up_scope": sorted(payload_scope_entries),
            "s3_upload": {
                "uploaded": bool(uploaded_object),
                "object_key": uploaded_object,
                "message": warning_message,
            },
        },
        include_s3_log=context.backup_s3_enabled,
    )


def perform_backup(
    backup_type: str,
    output_dir: str | None = None,
    verbosity: str | None = None,
    settings: AppSettings | None = None,
) -> Path:
    """Perform a backup of the requested type.

    Args:
        backup_type: One of "settings", "db", or "all".
        output_dir: Optional directory in which to write the backup ZIP.

    Returns:
        Path to the created ZIP file.

    Raises:
        BackupError: If backup_type is invalid or a required source file is missing.
    """
    backup_type = backup_type.lower()
    context = _resolve_backup_runtime_context(backup_type, output_dir, verbosity, settings)
    _log_backup_start(context)
    payload_scope_entries = _create_backup_archive(context)
    uploaded_object, warning_message = _maybe_upload_backup_to_s3(context)
    _log_backup_completion(context, payload_scope_entries, uploaded_object, warning_message)
    return context.zip_path


@click.command()
@click.argument("backup_type", type=click.Choice(BACKUP_TYPES))
@click.option(
    "--outputdir",
    "output_dir",
    type=click.Path(file_okay=False, dir_okay=True, path_type=str),
    help="Directory to write the backup ZIP file to.",
)
@click.option(
    "--verbosity",
    type=click.Choice(["off", "summary", "full"]),
    help="Backup output verbosity (default from settings).",
)
def main(backup_type: str, output_dir: str | None, verbosity: str | None) -> None:
    """CLI entry point for the backup module.

    Typically invoked via the main `screenshooter` CLI, but can be run directly for testing:

    python -m screenshooter.modules.backup.main settings --outputdir /path/to/dir
    """
    try:
        zip_path = perform_backup(backup_type, output_dir, verbosity=verbosity)
        console.print(f"[green]Backup completed successfully:[/green] {zip_path}")
    except BackupError as exc:
        console.print(f"[bold red]Backup failed:[/bold red] {exc}")
        raise SystemExit(1) from exc


if __name__ == "__main__":
    main()
