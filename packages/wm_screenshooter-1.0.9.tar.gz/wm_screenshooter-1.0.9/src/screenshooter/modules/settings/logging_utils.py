#!/usr/bin/env python3
"""Logging helpers for settings-related operations.

Provides dual logging to a dedicated settings log and a general screenshooter log,
plus an optional terminal message for user-facing notifications.
"""

import logging
import os
from pathlib import Path

LOGS_DIR = Path(os.path.expanduser("~/.config/screenshooter/logs"))
GENERAL_LOG_FILE = LOGS_DIR / "screenshooter.log"
SETTINGS_LOG_FILE = LOGS_DIR / "settings.log"
DATABASE_LOG_FILE = LOGS_DIR / "database.log"


def _ensure_logs_dir() -> None:
    """Ensure the logs directory exists."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)


def _attach_file_handler(logger: logging.Logger, file_path: Path) -> None:
    """Attach a FileHandler to logger if not already present for the path."""
    normalized = file_path.expanduser().resolve()

    for handler in logger.handlers:
        if isinstance(handler, logging.FileHandler):
            existing = Path(handler.baseFilename).expanduser().resolve()
            if existing == normalized:
                return

    # Ensure parent dir exists in case caller bypassed _ensure_logs_dir
    normalized.parent.mkdir(parents=True, exist_ok=True)

    handler = logging.FileHandler(normalized, encoding="utf-8")
    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)


def get_settings_logger(name: str = "screenshooter.settings") -> logging.Logger:
    """Get a logger configured for settings operations.

    Logs are written to both settings.log and the general screenshooter.log.
    """
    _ensure_logs_dir()

    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False  # Avoid duplicate handlers upstream

    _attach_file_handler(logger, SETTINGS_LOG_FILE)
    _attach_file_handler(logger, GENERAL_LOG_FILE)

    return logger


def get_database_log_file() -> Path:
    """Return the database log file path, ensuring it exists inside the logs directory."""
    _ensure_logs_dir()
    DATABASE_LOG_FILE.touch(exist_ok=True)
    return DATABASE_LOG_FILE


def log_settings_event(
    message: str,
    *,
    level: int = logging.INFO,
    terminal_message: str | None = None,
    logger: logging.Logger | None = None,
) -> None:
    """Log a settings event with optional terminal-facing message.

    Args:
        message: Detailed log message written to file.
        level: Logging level to use.
        terminal_message: Optional concise message to print to stdout.
        logger: Optional preconfigured logger; defaults to settings logger.
    """
    active_logger = logger or get_settings_logger()
    active_logger.log(level, message)

    if terminal_message:
        print(terminal_message)
