#!/usr/bin/env python3
"""S3/R2 storage module direct execution entry point."""

from screenshooter.modules.s3.main import main

if __name__ == "__main__":
    main()
