#!/usr/bin/env python3
"""Database connection and initialization for ScreenShooter Mac.

Provides SQLite database management including connection handling,
table creation, and database initialization.
"""

import importlib
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from screenshooter.modules.settings.logging_utils import get_database_log_file
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

CONFIG_DIR = Path.home() / ".config" / "screenshooter"
DEFAULT_DB_FILENAME = "screenshooter.db"
LEGACY_DB_FILENAME = ".screenshooter.db"


def get_default_database_path() -> Path:
    """Return the default database path in the central config directory."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR / DEFAULT_DB_FILENAME


def get_legacy_database_path() -> Path:
    """Return the legacy database path inside the screenshots directory."""
    return Path(get_screenshots_dir()) / LEGACY_DB_FILENAME


class DatabaseManager:
    """Manages SQLite database connection and initialization."""

    def __init__(self, db_path: str | None = None):
        """Initialize database manager.

        Args:
            db_path: Optional custom database path. If not provided,
                     uses base_directory from settings.
        """
        self.db_path = Path(db_path) if db_path is not None else get_default_database_path()
        if db_path is None:
            self._migrate_legacy_database()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._connection: sqlite3.Connection | None = None

    def _log_database_event(self, message: str) -> None:
        """Write an event to the database log file."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_file = get_database_log_file()
        with open(log_file, "a", encoding="utf-8") as log_handle:
            log_handle.write(f"[{timestamp}] {message}\n")

    def _migrate_legacy_database(self) -> None:
        """Move the database from the legacy screenshots path into the config directory."""
        legacy_path = get_legacy_database_path()
        if self.db_path.exists():
            return
        if not legacy_path.exists():
            return

        moved_files: list[str] = []
        skipped_files: list[str] = []

        for suffix in ("", "-wal", "-shm"):
            source = Path(f"{legacy_path}{suffix}")
            if not source.exists():
                continue

            destination = Path(f"{self.db_path}{suffix}")
            if destination.exists():
                skipped_files.append(str(source))
                continue

            try:
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(source), destination)
                moved_files.append(f"{source} -> {destination}")
            except OSError as exc:
                self._log_database_event(
                    f"Failed to move legacy database file {source} to {destination}: {exc}"
                )

        if moved_files:
            self._log_database_event(
                "Moved database from legacy screenshots directory to config directory: "
                f"{'; '.join(moved_files)}"
            )

        if skipped_files:
            self._log_database_event(
                "Skipped moving legacy database files because the destination already exists: "
                f"{', '.join(skipped_files)}"
            )

    def get_connection(self) -> sqlite3.Connection:
        """Get database connection, creating if needed."""
        if self._connection is None:
            self._connection = sqlite3.connect(
                self.db_path, detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
            )
            self._connection.row_factory = sqlite3.Row
            # Enable foreign key constraints
            self._connection.execute("PRAGMA foreign_keys = ON")
            # Set WAL mode for better concurrency
            self._connection.execute("PRAGMA journal_mode = WAL")
        return self._connection

    def close(self) -> None:
        """Close database connection."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    def initialize_database(self) -> None:
        """Initialize database using migration system."""
        try:
            migration_runner_module = importlib.import_module(
                "screenshooter.modules.database.migration_runner"
            )
            migration_runner_cls = migration_runner_module.MigrationRunner
            # Use migration runner to handle database initialization
            # Use quiet mode so initialization doesn't spam the TUI
            migration_runner = migration_runner_cls(self, quiet=True)
            migration_runner.migrate_to_latest()
        except ImportError:
            # Fallback to legacy initialization if migration system not available
            self._legacy_initialize_database()

    def _legacy_initialize_database(self) -> None:
        """Legacy database initialization for backward compatibility."""
        conn = self.get_connection()
        cursor = conn.cursor()

        # Create clients table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                directory_name TEXT NOT NULL UNIQUE,
                company_name TEXT DEFAULT '',
                contact_name TEXT DEFAULT '',
                contact_email TEXT DEFAULT '',
                pdf_password TEXT DEFAULT '',
                preferences TEXT DEFAULT '{}',
                archived_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Create projects table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                directory_name TEXT NOT NULL,
                archived_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients (id) ON DELETE CASCADE,
                UNIQUE(client_id, directory_name)
            )
        """)

        # Create sessions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                start_time TIMESTAMP NOT NULL,
                end_time TIMESTAMP,
                duration_seconds INTEGER,
                timer_mode TEXT,
                archived_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
            )
        """)

        # Create screenshots table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS screenshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                set_id INTEGER NOT NULL,
                file_path TEXT NOT NULL,
                timestamp TIMESTAMP NOT NULL,
                display_mode TEXT,
                suffix TEXT,
                archived_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE
            )
        """)

        # Create notes table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                content TEXT NOT NULL,
                note_type TEXT DEFAULT 'note',
                timestamp TIMESTAMP NOT NULL,
                archived_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (session_id) REFERENCES sessions (id) ON DELETE CASCADE
            )
        """)

        # Create indexes for better query performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_clients_name ON clients (name)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_clients_directory ON clients (directory_name)"
        )
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_projects_client_id ON projects (client_id)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_projects_directory "
            "ON projects (client_id, directory_name)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_sessions_project_id ON sessions (project_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_sessions_start_time ON sessions (start_time)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_screenshots_session_id ON screenshots (session_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_screenshots_timestamp ON screenshots (timestamp)"
        )
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notes_session_id ON notes (session_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notes_timestamp ON notes (timestamp)")
        # No separate captions table; captions are stored in ``notes`` with
        # ``note_type = 'caption'`` for simplicity.

        conn.commit()

    def execute_query(self, query: str, params: tuple = ()) -> sqlite3.Cursor:
        """Execute a database query.

        Args:
            query: SQL query string
            params: Query parameters

        Returns:
            Database cursor
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(query, params)
        return cursor

    def execute_many(self, query: str, params_list: list) -> sqlite3.Cursor:
        """Execute a database query multiple times.

        Args:
            query: SQL query string
            params_list: List of parameter tuples

        Returns:
            Database cursor
        """
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.executemany(query, params_list)
        return cursor

    def commit(self) -> None:
        """Commit current transaction."""
        conn = self.get_connection()
        conn.commit()

    def rollback(self) -> None:
        """Rollback current transaction."""
        conn = self.get_connection()
        conn.rollback()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()


# Database manager cache
_DB_MANAGER_CACHE: dict[str, DatabaseManager | None] = {"instance": None}


def get_database_manager() -> DatabaseManager:
    """Get global database manager instance."""
    db_manager = _DB_MANAGER_CACHE["instance"]
    if db_manager is None:
        db_manager = DatabaseManager()
        db_manager.initialize_database()
        _DB_MANAGER_CACHE["instance"] = db_manager
    return db_manager
