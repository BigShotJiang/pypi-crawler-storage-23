#!/usr/bin/env python3
"""Database models for ScreenShooter Mac.

Pydantic models that represent database entities for clients, projects,
sessions, screenshots, notes, and captions.
"""

import json
from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class DatabaseClient(BaseModel):
    """Database model for client information."""

    id: int | None = None
    name: str
    directory_name: str
    company_name: str = ""
    contact_name: str = ""
    contact_email: str = ""
    pdf_password: str = ""
    preferences: dict[str, str] = Field(default_factory=dict)
    # Timestamp when the client was archived; NULL means active
    archived_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @field_validator("preferences", mode="before")
    @classmethod
    def parse_preferences(cls, v) -> dict[str, str]:
        """Parse preferences from JSON string if needed."""
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return {}
        return v or {}


class DatabaseProject(BaseModel):
    """Database model for project information."""

    id: int | None = None
    client_id: int
    name: str
    directory_name: str
    active: bool = True
    # Timestamp when the project was archived; NULL means active
    archived_at: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class DatabaseNoteType(str):
    """Enumeration for note types."""

    NOTE = "note"
    CAPTION = "caption"
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    PAUSE = "pause"
    RESUME = "resume"


class DatabaseSession(BaseModel):
    """Database model for session information."""

    id: int | None = None
    project_id: int
    name: str
    start_time: datetime
    end_time: datetime | None = None
    duration_seconds: int | None = None
    timer_mode: str | None = None
    created_at: datetime | None = None
    active: bool = True  # For soft delete/archive functionality
    # Timestamp when the session was archived; NULL means active
    archived_at: datetime | None = None


class DatabaseScreenshot(BaseModel):
    """Database model for screenshot information."""

    id: int | None = None
    session_id: int
    set_id: int
    file_path: str
    timestamp: datetime
    display_mode: str | None = None
    suffix: str | None = None
    active: bool = True
    # Timestamp when the screenshot was archived; NULL means active
    archived_at: datetime | None = None
    created_at: datetime | None = None


class DatabaseNote(BaseModel):
    """Database model for note information."""

    id: int | None = None
    session_id: int
    content: str
    note_type: str = DatabaseNoteType.NOTE
    timestamp: datetime
    active: bool = True
    # Timestamp when the note was archived; NULL means active
    archived_at: datetime | None = None
    created_at: datetime | None = None
