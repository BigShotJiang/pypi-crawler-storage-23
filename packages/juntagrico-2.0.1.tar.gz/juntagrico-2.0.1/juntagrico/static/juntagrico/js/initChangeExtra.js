$(function () {
    $("input[type='number']").inputSpinner();
});