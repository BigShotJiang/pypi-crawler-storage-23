import datetime
from functools import cached_property

from django.contrib import admin
from django.db import models
from django.db.models import Max
from django.utils.translation import gettext_lazy as _, gettext
from polymorphic.managers import PolymorphicManager

from juntagrico.config import Config
from juntagrico.dao.sharedao import ShareDao
from juntagrico.entity import notifiable, JuntagricoBaseModel, SimpleStateModel
from juntagrico.entity.billing import Billable
from juntagrico.entity.depot import Depot
from juntagrico.lifecycle.sub import check_sub_consistency
from juntagrico.lifecycle.subpart import check_sub_part_consistency
from juntagrico.queryset.subscription import SubscriptionQuerySet, SubscriptionPartQuerySet
from juntagrico.signals import depot_change_confirmed
from juntagrico.util.models import q_activated, q_canceled, q_deactivated, q_deactivation_planned, q_isactive
from juntagrico.util.temporal import start_of_next_business_year


class Subscription(Billable, SimpleStateModel):
    '''
    One Subscription that may be shared among several people.
    '''
    depot = models.ForeignKey(
        Depot, on_delete=models.PROTECT, related_name='subscription_set')
    future_depot = models.ForeignKey(
        Depot, on_delete=models.PROTECT, related_name='future_subscription_set', null=True, blank=True,
        verbose_name=_('Zukünftiges {}').format(Config.vocabulary('depot')),
        help_text='Nur setzen, wenn {} geändert werden soll'.format(Config.vocabulary('depot')))
    primary_member = models.ForeignKey('Member', related_name='subscription_primary', null=True, blank=True,
                                       on_delete=models.PROTECT,
                                       verbose_name=_('Haupt-{}-BezieherIn').format(Config.vocabulary('subscription')))
    nickname = models.CharField(_('Spitzname'), max_length=30, blank=True,
                                help_text=_('Ersetzt die Mit-{}-BezieherInnen auf der {}-Liste.'.format(
                                    Config.vocabulary('subscription'), Config.vocabulary('depot'))))
    start_date = models.DateField(
        _('Gewünschtes Startdatum'), null=False, default=start_of_next_business_year)
    end_date = models.DateField(
        _('Gewünschtes Enddatum'), null=True, blank=True)
    notes = models.TextField(
        _('Notizen'), blank=True,
        help_text=_('Notizen für Administration. Nicht sichtbar für {}'.format(Config.vocabulary('member'))))

    types = models.ManyToManyField('SubscriptionType', through='SubscriptionPart', related_name='subscriptions')

    objects = PolymorphicManager.from_queryset(SubscriptionQuerySet)()

    def __str__(self):
        return gettext('Abo ({1}) {0}').format(self.size, self.id)

    @staticmethod
    def get_part_overview(parts):
        # building multi-dimensional dictionary [category_name][bundle_long_name][(type_name, type_long_name)] -> amount
        result = {}
        for part in parts.all():
            category_name = part.type.bundle.category.name
            category = result.get(category_name, {})
            bundle_name = part.type.bundle.long_name
            bundle = category.get(bundle_name, {})
            type_name = (part.type.name, part.type.long_name)
            bundle[type_name] = 1 + bundle.get(type_name, 0)
            category[bundle_name] = bundle
            result[category_name] = category
        return result

    @property
    def part_overview(self):
        return Subscription.get_part_overview(self.active_parts)

    @property
    def future_part_overview(self):
        return Subscription.get_part_overview(self.future_parts)

    @property
    def active_parts(self):
        return self.parts.filter(q_isactive())

    @property
    def future_parts(self):
        return self.parts.filter(~q_canceled() & ~q_deactivated())

    @property
    def active_and_future_parts(self):
        return self.parts.filter(~q_deactivated())

    @cached_property
    def content(self):
        """
        :return: list of parts annotated with bundle_name, category_name and amount
        """
        return self.types.with_active_or_future_parts().annotate_content()

    def content_strings(self, sformat=None):
        """
        :param sformat: format string. defaults to SUB_OVERVIEW_FORMAT.format
        :return: list of formated strings describing each type and amount in this subscription
        """
        sformat = sformat or Config.sub_overview_format('format')
        return [sformat.format(
            category=t.category_name,
            bundle=t.bundle_name,
            type=t.name,
            amount=t.amount,
        ) for t in self.content]

    @property
    def size(self):
        """
        for backwards compatibility.
        :return: content_strings concatenated with SUB_OVERVIEW_FORMAT.delimiter
        """
        delimiter = Config.sub_overview_format('delimiter')
        return delimiter.join(self.content_strings())

    @property
    def types_changed(self):
        return self.parts.filter(~q_activated() | (q_canceled() & ~q_deactivation_planned())).filter(type__is_extra=False).count()

    @staticmethod
    def calc_subscription_amount(parts, bundle):
        return parts.filter(type__bundle=bundle).count()

    def subscription_amount(self, bundle):
        return self.calc_subscription_amount(self.active_parts, bundle)

    def subscription_amount_future(self, bundle):
        return self.calc_subscription_amount(self.future_parts, bundle)

    @property
    def price(self):
        result = 0
        for part in self.active_parts.all():
            result += part.type.price
        return result

    @property
    def all_shares(self):
        return ShareDao.all_shares_subscription(self).count()

    @property
    def paid_shares(self):
        return ShareDao.paid_shares(self).count()

    @property
    def share_overflow(self):
        return self.all_shares - self.required_shares

    @property
    def required_shares(self):
        result = 0
        for part in self.future_parts.all():
            result += part.type.shares
        return result

    def co_members(self, of_member=None):
        of_member = of_member or self.primary_member
        if of_member is None:
            return self.current_members
        return self.current_members.exclude(pk=of_member.pk)

    @property
    def future_members(self):
        if hasattr(self, 'override_future_members'):
            return self.override_future_members
        return set(self.members.joining())

    @property
    def current_members(self):
        if self.waiting:
            return self.members.active()
        elif self.inactive:
            return self.members.all()
        else:
            return self.members.joined().active()

    @admin.display(description=primary_member.verbose_name)
    def primary_member_nullsave(self):
        member = self.primary_member
        return str(member) if member is not None else ''

    @property
    def extra_subscriptions(self):
        return self.active_parts.filter(type__is_extra=True)

    @property
    def future_extra_subscriptions(self):
        return self.future_parts.filter(type__is_extra=True)

    @property
    def active_and_future_extra_subscriptions(self):
        return self.active_and_future_parts.filter(type__is_extra=True)

    @property
    def extrasubscriptions_changed(self):
        return self.parts.filter(~q_activated() | (q_canceled() & ~q_deactivation_planned())).filter(type__is_extra=True).count()

    def extra_subscription_amount(self, extra_sub_type):
        return self.extra_subscriptions.filter(type=extra_sub_type).count()

    @staticmethod
    def next_size_change_date():
        return start_of_next_business_year()

    def activate_future_depot(self):
        if self.future_depot is not None:
            self.depot = self.future_depot
            self.future_depot = None
            self.save()
            depot_change_confirmed.send(Subscription, instance=self)

    def clean(self):
        check_sub_consistency(self)

    @notifiable
    class Meta:
        verbose_name = Config.vocabulary('subscription')
        verbose_name_plural = Config.vocabulary('subscription_pl')
        permissions = (
            ('can_filter_subscriptions', _('Benutzer kann {0} filtern').format(Config.vocabulary('subscription'))),
            ('can_change_deactivated_subscriptions', _('Benutzer kann deaktivierte {0} ändern').format(Config.vocabulary('subscription'))),
            ('notified_on_depot_change', _('Wird bei {0}-Änderung informiert').format(Config.vocabulary('depot'))),
        )


class SubscriptionPart(JuntagricoBaseModel, SimpleStateModel):
    subscription = models.ForeignKey('Subscription', related_name='parts', on_delete=models.CASCADE,
                                     verbose_name=Config.vocabulary('subscription'))
    type = models.ForeignKey('SubscriptionType', related_name='subscription_parts', on_delete=models.PROTECT,
                             verbose_name=_('{0}-Typ').format(Config.vocabulary('subscription')))

    objects = SubscriptionPartQuerySet.as_manager()

    def __str__(self):
        try:
            return Config.sub_overview_format('part_format').format(
                category=self.type.bundle.get_category_name(),
                bundle=self.type.bundle.long_name,
                type=self.type.name,
                type_long=self.type.long_name,
                price=self.type.price
            )
        except KeyError as k:
            return gettext('Fehler in der Einstellung SUB_OVERVIEW_FORMAT.part_format. {k} kann nicht aufgelöst werden.').format(k=k)

    @property
    def can_cancel(self):
        return self.cancellation_date is None and self.subscription.future_parts.count() > 1

    def cancel(self, date=None):
        super().cancel(date)
        # if last part was canceled, also cancel subscription
        if not self.subscription.canceled and not self.subscription.parts.not_canceled().exists():
            self.subscription.cancel(date)

    def deactivate(self, date=None):
        super().deactivate(date)
        # if last part is deactivated, also deactivate subscription
        if self.subscription.deactivation_date is None and not self.subscription.parts.filter(deactivation_date=None).exists():
            self.subscription.deactivate(self.subscription.parts.aggregate(Max('deactivation_date'))['deactivation_date__max'])

    @property
    def is_extra(self):
        return self.type.is_extra

    @property
    def is_trial(self):
        return self.type.trial_days > 0

    @cached_property
    def remaining_trial_days(self):
        """
        The end of the trial period is the deactivation_date, if set, otherwise it is activation_date + trial_days.
        :return: remaining days of trial if is a trial and has started, otherwise None
        """
        if self.is_trial and self.activation_date is not None:
            today = datetime.date.today()
            end = self.end_of_trial_date
            return (end - today).days

    @cached_property
    def end_of_trial_date(self):
        if self.is_trial and self.activation_date is not None:
            return self.deactivation_date or (self.activation_date + datetime.timedelta(days=self.type.trial_days))

    def follow_up_parts(self):
        """
        :return: non-trial parts from the same subscription that are waiting or active after this part.
        """
        return self.subscription.parts.non_trial().waiting(self.activation_date)

    def clean(self):
        check_sub_part_consistency(self)

    @notifiable
    class Meta:
        verbose_name = _('{} Bestandteil').format(Config.vocabulary('subscription'))
        verbose_name_plural = _('{} Bestandteile').format(Config.vocabulary('subscription'))
