import datetime
from datetime import date

from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import ValidationError
from django.db.models import Count, Sum, F
from django.http import Http404
from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.module_loading import import_string
from django.utils.translation import gettext as _
from django.views import View
from django.views.generic import FormView
from django.views.generic.edit import ModelFormMixin

from juntagrico.config import Config
from juntagrico.dao.depotdao import DepotDao
from juntagrico.entity.depot import Depot
from juntagrico.entity.member import Member
from juntagrico.entity.share import Share
from juntagrico.entity.subs import Subscription
from juntagrico.forms import RegisterMemberForm, EditMemberForm, AddCoMemberForm, NicknameForm, SubscriptionPartChangeForm
from juntagrico.mailer import membernotification, adminnotification
from juntagrico.signals import depot_changed, share_canceled
from juntagrico.util import return_to_previous_location
from juntagrico.util.management import cancel_sub
from juntagrico.util.management import create_or_update_co_member, create_share
from juntagrico.util.pdf import render_to_pdf_http
from juntagrico.util.temporal import end_of_next_business_year, end_of_business_year, \
    cancelation_date, next_membership_end_date
from juntagrico.view_decorators import primary_member_of_subscription, primary_member_of_subscription_of_part, \
    using_change_date


@primary_member_of_subscription
def depot_change(request, subscription_id):
    '''
    change a depot
    '''
    member = request.user.member
    subscription = get_object_or_404(Subscription, id=subscription_id)
    saved = False
    if request.method == 'POST':
        if subscription.waiting:
            old_depot = subscription.depot
            subscription.depot = get_object_or_404(
                Depot, id=int(request.POST.get('depot')))
            depot_changed.send(Subscription, subscription=subscription, member=member, old_depot=old_depot,
                               new_depot=subscription.depot, immediate=True)
        else:
            subscription.future_depot = get_object_or_404(
                Depot, id=int(request.POST.get('depot')))
            depot_changed.send(Subscription, subscription=subscription, member=member, old_depot=subscription.depot,
                               new_depot=subscription.future_depot, immediate=False)
        subscription.save()
        saved = True
    depots = DepotDao.all_visible_depots_with_map_info()
    counts = subscription.active_and_future_parts.values('type').annotate(count=Count('type'))
    renderdict = {
        'subscription': subscription,
        'subscription_count': {item['type']: item['count'] for item in counts},
        'saved': saved,
        'member': member,
        'depots': depots,
    }
    return render(request, 'depot_change.html', renderdict)


@primary_member_of_subscription
def primary_change(request, subscription_id):
    '''
    change primary member
    '''
    subscription = get_object_or_404(Subscription, id=subscription_id)
    if request.method == 'POST':
        new_primary = get_object_or_404(Member, id=int(request.POST.get('primary')))
        subscription.primary_member = new_primary
        subscription.save()
        return redirect('subscription-single', subscription_id=subscription.id)
    if Config.enable_shares():
        co_members = [m for m in subscription.co_members() if m.is_cooperation_member]
    else:
        co_members = subscription.co_members()
    renderdict = {
        'subscription': subscription,
        'co_members': co_members,
        'has_comembers': len(co_members) > 0
    }
    return render(request, 'pm_change.html', renderdict)


@primary_member_of_subscription_of_part
def part_change(request, part,
                form_class=SubscriptionPartChangeForm,
                template_name='juntagrico/my/subscription/part/change.html'):
    """
    change part of a subscription
    """
    if request.method == 'POST':
        form = form_class(part, request.POST)
        if form.is_valid():
            form.save()
            return redirect(reverse('size-change', args=[part.subscription.id]))
    else:
        form = form_class(part)
    return render(request, template_name, {
        'form': form,
    })


class SignupView(View):
    def __init__(self):
        super().__init__()
        self.signup_manager = None

    def setup(self, request, *args, **kwargs):
        super().setup(request, *args, **kwargs)
        self.signup_manager = import_string(Config.signup_manager())(request)

    def dispatch(self, request, *args, **kwargs):
        # make sure signup process is followed
        next_page = self.signup_manager.get_next_page()
        if next_page != request.resolver_match.url_name:
            return redirect(next_page)
        return super().dispatch(request, *args, **kwargs)


class MemberSignupView(SignupView, FormView):
    template_name = 'juntagrico/signup/member.html'

    def setup(self, request, *args, **kwargs):
        super().setup(request, *args, **kwargs)
        if Config.enable_registration() is False:
            raise Http404
        # logout if existing user is logged in
        if request.user.is_authenticated:
            logout(request)
            self.signup_manager.clear()

    def get_form_class(self):
        return EditMemberForm if self.signup_manager.get('main_member') else RegisterMemberForm

    def get_form_kwargs(self):
        form_kwargs = super().get_form_kwargs()
        if 'data' not in form_kwargs:
            form_kwargs['data'] = self.signup_manager.get('main_member')
        return form_kwargs

    def form_valid(self, form):
        self.signup_manager.set('main_member', form.cleaned_data)
        return redirect(self.signup_manager.get_next_page())


def confirm(request, member_hash):
    """
    Confirm mail address from link with hash after signup or if user that has been added as a co_subscription member
    """
    renderdict = {'error_message': _('Ungültiger Link.')}
    for member in Member.objects.filter(confirmed=False):
        if member_hash == member.get_hash():
            member.confirmed = True
            member.save()
            renderdict = {}
            break
    return render(request, 'mail_confirmation.html', renderdict)


class AddCoMemberView(FormView, ModelFormMixin):
    template_name = 'add_member.html'
    form_class = AddCoMemberForm

    def __init__(self):
        super().__init__()
        self.object = None
        self.subscription = None

    def get_context_data(self, **kwargs):
        return super().get_context_data(
            **{},
            **kwargs
        )

    def get_form_kwargs(self):
        form_kwargs = super().get_form_kwargs()
        form_kwargs['existing_emails'] = self.subscription.current_members.values_list('email', flat=True)
        return form_kwargs

    def get_initial(self):
        # use address from main member as default
        mm = self.request.user.member
        return {
            'addr_street': mm.addr_street,
            'addr_zipcode': mm.addr_zipcode,
            'addr_location': mm.addr_location
        }

    @method_decorator(primary_member_of_subscription)
    def dispatch(self, request, subscription_id, *args, **kwargs):
        self.subscription = get_object_or_404(Subscription, id=subscription_id)
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        # add existing member
        co_member = getattr(form, 'existing_member', None)
        shares = 0
        # or create new member and order shares for them
        if co_member is None:
            shares = form.cleaned_data.get('shares', 0)
            co_member = form.instance
        create_or_update_co_member(co_member, self.subscription, shares)
        return self._done()

    def _done(self):
        return redirect('subscription-single', subscription_id=self.subscription.id)


def error_page(request, error_message):
    renderdict = {'error_message': error_message}
    return render(request, 'error.html', renderdict)


@permission_required('juntagrico.is_operations_group')
@using_change_date
def activate_subscription(request, change_date, subscription_id):
    subscription = get_object_or_404(Subscription, id=subscription_id)
    try:
        subscription.activate(change_date)
    except ValidationError as e:
        return error_page(request, e.message)
    return return_to_previous_location(request)


@permission_required('juntagrico.is_operations_group')
@using_change_date
def deactivate_subscription(request, change_date, subscription_id):
    subscription = get_object_or_404(Subscription, id=subscription_id)
    try:
        subscription.deactivate(change_date)
    except ValidationError as e:
        return error_page(request, e.message)
    return return_to_previous_location(request)


@primary_member_of_subscription_of_part
def cancel_part(request, part):
    part.cancel()
    adminnotification.subpart_canceled(part)
    return return_to_previous_location(request)


@primary_member_of_subscription
def cancel_subscription(request, subscription_id):
    subscription = get_object_or_404(Subscription, id=subscription_id)
    end_date = end_of_business_year() if datetime.date.today() <= cancelation_date() else end_of_next_business_year()
    if request.method == 'POST':
        cancel_sub(subscription, request.POST.get('end_date'), request.POST.get('message'))
        return redirect('subscription-landing')
    renderdict = {
        'end_date': end_date,
    }
    return render(request, 'cancelsubscription.html', renderdict)


@login_required
def leave_subscription(request, subscription_id):
    member = request.user.member
    subscription = Subscription.objects.filter(subscriptionmembership__member=member).get(id=subscription_id)
    share_error = Config.enable_shares() and subscription.share_overflow - member.usable_shares_count < 0
    primary = subscription.primary_member.id == member.id
    has_min_shares = not Config.enable_shares() or member.is_cooperation_member
    can_leave = has_min_shares and not share_error and not primary
    if not can_leave:
        return redirect('subscription-landing')
    if request.method == 'POST':
        member.leave_subscription(subscription)
        primary_member = subscription.primary_member
        membernotification.co_member_left_subscription(primary_member, member, request.POST.get('message'))
        return redirect('home')
    return render(request, 'leavesubscription.html', {})


@primary_member_of_subscription
def change_nickname(request, subscription_id):
    subscription = get_object_or_404(Subscription, id=subscription_id)
    if request.method == 'POST':
        form = NicknameForm(request.POST)
        if form.is_valid():
            subscription.nickname = form.cleaned_data['nickname']
            subscription.save()
            return redirect('subscription-single', subscription_id=subscription_id)
    else:
        form = NicknameForm()
    renderdict = {
        'form': form,
    }
    return render(request, 'change_nickname.html', renderdict)


@login_required
def manage_shares(request):
    if request.method == 'POST':
        try:
            ordered_shares = int(request.POST.get('shares'))
            shareerror = ordered_shares < 1
        except ValueError:
            shareerror = True
        if not shareerror:
            create_share(request.user.member, ordered_shares)
            return redirect(reverse('manage-shares'))
    else:
        shareerror = False
    member = request.user.member
    shares = member.share_set.order_by(F('cancelled_date').asc(nulls_first=True), F('paid_date').desc(nulls_last=True))

    active_share_years = member.active_share_years
    current_year = datetime.date.today().year
    if active_share_years and current_year in active_share_years:
        active_share_years.remove(current_year)
    renderdict = {
        'shares': shares.all(),
        'shareerror': shareerror,
        'required': member.required_shares_count,
        'ibanempty': not member.iban,
        'next_membership_end_date': next_membership_end_date(),
        'certificate_years': active_share_years,
    }
    return render(request, 'manage_shares.html', renderdict)


@login_required
def share_certificate(request):
    year = int(request.GET['year'])
    member = request.user.member
    active_share_years = member.active_share_years
    if year >= datetime.date.today().year or year not in active_share_years:
        return error_page(request, _('{share}-Bescheinigungen können nur für vergangene Jahre ausgestellt werden.').format(share=Config.vocabulary('share')))
    shares_date = date(year, 12, 31)
    shares = member.active_shares_for_date(date=shares_date).values('value').annotate(count=Count('value')).annotate(total=Sum('value')).order_by('value')
    shares_total = 0
    for share in shares:
        shares_total = shares_total + share['total']
    renderdict = {
        'member': member,
        'cert_date': datetime.date.today(),
        'shares_date': shares_date,
        'shares': shares,
        'shares_total': shares_total,
    }
    return render_to_pdf_http('exports/share_certificate.html', renderdict, _('Bescheinigung') + str(year) + '.pdf')


@login_required
def cancel_share(request, share_id):
    member = request.user.member
    if member.cancellable_shares_count > 0:
        share = get_object_or_404(Share, id=share_id, member=member)
        share.cancelled_date = datetime.date.today()
        share.termination_date = next_membership_end_date()
        share.save()
        share_canceled.send(sender=Share, instance=share)
    return return_to_previous_location(request)
