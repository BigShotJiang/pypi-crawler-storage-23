"""PhoenixGitHub — AI agent that picks up GitHub issues and creates PRs."""

__version__ = "0.1.0"
