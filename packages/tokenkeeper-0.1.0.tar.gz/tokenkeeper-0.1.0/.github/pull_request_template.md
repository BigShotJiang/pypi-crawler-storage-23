## Summary

<!-- What does this PR do and why? -->

## Checklist

- [ ] Tests pass (`uv run pytest tests/ -m "not ollama"`)
- [ ] New tests added for new functionality
- [ ] Documentation updated (if applicable)
- [ ] CHANGELOG.md updated under "Unreleased"
- [ ] No breaking changes (or documented in PR description)
