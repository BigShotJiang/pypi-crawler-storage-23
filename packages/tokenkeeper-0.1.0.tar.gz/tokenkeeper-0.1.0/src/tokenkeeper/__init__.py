"""TokenKeeper - Local RAG system as MCP server for Claude Code."""

__version__ = "0.1.0"
