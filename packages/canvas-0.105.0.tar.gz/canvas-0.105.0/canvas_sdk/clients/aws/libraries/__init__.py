from canvas_sdk.clients.aws.libraries.s3 import S3

__all__ = __exports__ = ("S3",)
