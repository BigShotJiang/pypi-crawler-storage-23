[![Rust](https://github.com/NNPDF/pineappl/workflows/Rust/badge.svg)](https://github.com/NNPDF/pineappl/actions?query=workflow%3ARust)
[![crates.io](https://img.shields.io/crates/v/pineappl.svg)](https://crates.io/crates/pineappl_cli)

# PineAPPL CLI

This is the command-line interface (CLI) to
[`pineappl`](https://crates.io/crates/pineappl).

# Installation

Run `cargo install pineappl_cli` to install the `pineappl` binary.
