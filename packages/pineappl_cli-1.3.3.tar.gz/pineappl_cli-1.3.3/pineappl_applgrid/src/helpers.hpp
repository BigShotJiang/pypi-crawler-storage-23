#ifndef CALCULATION_HPP
#define CALCULATION_HPP

#include <appl_grid/appl_grid.h>

// hack to make declaration of `CALCULATION` in Rust an element of the class `grid`
using grid_CALCULATION = appl::grid::CALCULATION;

// enable passing void pointers
using c_void = void;

#endif
