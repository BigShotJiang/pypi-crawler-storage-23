# Summary

[Introduction](index.md)

# Getting Started

- [Setup with Claude Code](setup.md)
- [How It Works](how-it-works.md)

# Commands

- [Overview](commands/overview.md)
- [inspect](commands/inspect.md)
- [find](commands/find.md)
- [refs](commands/refs.md)
- [members](commands/members.md)
- [list](commands/list.md)
- [daemon](commands/daemon.md)

# Reference

- [Performance](performance.md)
- [Troubleshooting](troubleshooting.md)
