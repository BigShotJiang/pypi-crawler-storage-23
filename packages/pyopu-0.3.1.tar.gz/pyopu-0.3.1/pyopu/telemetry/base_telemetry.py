from abc import ABC, abstractmethod

class BaseTelemetry(ABC):
    @abstractmethod
    def attach(self, subject):
        pass

    @abstractmethod
    def reset(self):
        pass

    def update(self, *args, **kwargs):
        pass
        
    @abstractmethod
    def get_data(self):
        pass

class Observable:
    def __init__(self):
        self._telemetries = []

    def attach_telemetry(self, telemetry: BaseTelemetry):
        self._telemetries.append(telemetry)
        telemetry.attach(self)

    def notify_telemetries(self, *args, **kwargs):
        for telemetry in self._telemetries:
            telemetry.update(*args, **kwargs)

    def reset_telemetries(self):
        for telemetry in self._telemetries:
            telemetry.reset()
