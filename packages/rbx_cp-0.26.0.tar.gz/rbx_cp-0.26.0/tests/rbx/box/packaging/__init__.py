"""Tests for rbx packaging functionality."""
