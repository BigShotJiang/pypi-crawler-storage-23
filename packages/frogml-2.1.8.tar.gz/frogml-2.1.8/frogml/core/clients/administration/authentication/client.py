from dependency_injector.wiring import Provide

from frogml._proto.qwak.administration.v0.authentication.authentication_service_pb2 import (
    AuthenticateRequest,
)
from frogml._proto.qwak.administration.v0.authentication.authentication_service_pb2 import (
    QwakApiKeyMethod,
)
from frogml._proto.qwak.administration.v0.authentication.authentication_service_pb2_grpc import (
    AuthenticationServiceStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AuthenticationClient:
    """
    Used for interacting with Frogml's Authentication service
    """

    def __init__(
        self, grpc_channel=Provide[FrogmlContainer.unauthenticated_core_grpc_channel]
    ):
        self._authentication_service = AuthenticationServiceStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to login",
        operation="Login",
    )
    def authenticate(self, api_key=None):
        request = AuthenticateRequest(
            qwak_api_key_method=QwakApiKeyMethod(qwak_api_key=api_key)
        )
        return self._authentication_service.Authenticate(request)
