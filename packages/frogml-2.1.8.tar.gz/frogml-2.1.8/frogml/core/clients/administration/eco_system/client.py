from typing import Optional

from dependency_injector.wiring import Provide

from frogml._proto.qwak.ecosystem.v0.ecosystem_pb2 import (
    AuthenticatedUserContext,
    EnvironmentDetails,
    UserContextAccountDetails,
    UserContextEnvironmentDetails,
)
from frogml._proto.qwak.ecosystem.v0.ecosystem_runtime_service_pb2 import (
    GetAuthenticatedUserContextRequest,
    GetCloudCredentialsRequest,
    GetCloudCredentialsResponse,
)
from frogml._proto.qwak.ecosystem.v0.ecosystem_runtime_service_pb2_grpc import (
    QwakEcosystemRuntimeStub,
)

from frogml.core.exceptions import FrogmlNotFoundException
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class FrogMLSuggestionException:
    pass


class EcosystemClient:
    """
    Used for interacting with Frogml's Ecosystem
    """

    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._ecosystem_service = QwakEcosystemRuntimeStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to get cloud credentials",
        operation="Get Cloud Credentials",
    )
    def get_cloud_credentials(
        self, request: GetCloudCredentialsRequest
    ) -> GetCloudCredentialsResponse:
        return self._ecosystem_service.GetCloudCredentials(request)

    @grpc_try_catch_wrapper(
        error_message="Failed to get user context",
        operation="Get User Context",
    )
    def get_authenticated_user_context(self) -> AuthenticatedUserContext:
        return self._ecosystem_service.GetAuthenticatedUserContext(
            GetAuthenticatedUserContextRequest()
        ).authenticated_user_context

    def get_account_details(self) -> UserContextAccountDetails:
        return self.get_authenticated_user_context().user.account_details

    def translate_environments_names_to_ids(
        self,
        environments_names: list[str],
    ) -> list[str]:
        names_to_selected_environments = self.get_environments_names_to_details(
            environments_names
        )

        return [
            names_to_selected_environments[env_name].id
            for env_name in environments_names
        ]

    def get_environments_names_to_details(
        self,
        environments_names: list[str],
    ) -> dict[str, UserContextEnvironmentDetails]:
        account_details = self.get_account_details()

        if not environments_names:
            environment = account_details.environment_by_id[
                account_details.default_environment_id
            ]
            return {environment.name: environment}

        environments_names_set = set(environments_names)

        selected_environments = self.get_envs_by_names(
            account_details, environments_names_set
        )
        if len(selected_environments) != len(environments_names):
            available_environments_names = set(
                self.get_available_envs_names(account_details)
            )
            missing_envs = environments_names_set - available_environments_names

            raise FrogmlNotFoundException(
                error_message=f"The following environments were not found: {','.join(missing_envs)},"
                f" Available environments are: {','.join(available_environments_names)}",
                operation="Get Environments",
            )

        return {env.name: env for env in selected_environments}

    def get_environments(self) -> dict[str, UserContextEnvironmentDetails]:
        account = self.get_account_details()

        return account.environment_by_id

    def get_environment_configuration(
        self, environment_name: Optional[str] = None
    ) -> EnvironmentDetails:
        account_details = self.get_account_details()
        if environment_name:
            matching_envs = self.get_envs_by_names(account_details, {environment_name})
            if not matching_envs:
                available_environments_names = self.get_available_envs_names(
                    account_details
                )
                raise FrogmlNotFoundException(
                    error_message=f"Environment with name {environment_name} was not found. Available "
                    f"environments are: {', '.join(available_environments_names)}",
                    operation="Get Environment Configuration",
                )
            return matching_envs[0].configuration

        else:
            return account_details.environment_by_id[
                account_details.default_environment_id
            ]

    def get_environment_model_api(self, environment_name: Optional[str] = None) -> str:
        return self.get_environment_configuration(environment_name).model_api_url

    @staticmethod
    def get_available_envs_names(
        account_details: UserContextAccountDetails,
    ) -> list[str]:
        available_environments_names = list(
            map(
                lambda env: env.name,
                dict(account_details.environment_by_id).values(),
            )
        )
        return available_environments_names

    @staticmethod
    def get_envs_by_names(
        account_details: UserContextAccountDetails, environment_names: set[str]
    ) -> list[UserContextEnvironmentDetails]:
        matching_envs = list(
            filter(
                lambda env: env.name in environment_names,
                dict(account_details.environment_by_id).values(),
            )
        )
        return matching_envs
