# Product Overview

fastapi-eventbus is an open-source Python library that provides a high-availability, event-driven pub/sub extension for FastAPI.

It lets developers publish and subscribe to events within FastAPI applications using pluggable backends (in-memory sync, Redis, Kafka). The library integrates with FastAPI's dependency injection and lifespan system, and includes retry/dead-letter-queue support and health checks.

The project is in early alpha (0.1.0) and targets Python 3.10+.
