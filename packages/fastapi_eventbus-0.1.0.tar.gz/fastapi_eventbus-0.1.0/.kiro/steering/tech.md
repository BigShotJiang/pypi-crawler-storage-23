# Tech Stack & Build

## Language & Runtime
- Python >= 3.10
- Fully typed (PEP 561 `py.typed` marker, mypy strict mode)

## Core Dependencies
- fastapi >= 0.100.0
- pydantic >= 2.0
- pydantic-settings >= 2.0

## Optional Backend Dependencies
- `redis[hiredis] >= 5.0` — Redis backend
- `aiokafka >= 0.9` — Kafka backend
- Install groups: `redis`, `kafka`, `all`

## Build System
- Hatchling (PEP 517/518)
- Source layout: `src/fastapi_eventbus/`

## Dev Tools
- Linter/formatter: ruff (line-length 100, target py310, rule sets: E, F, I, N, UP, B, SIM, ASYNC)
- Type checker: mypy (strict mode, python_version 3.10)
- Testing: pytest + pytest-asyncio (asyncio_mode = "auto"), pytest-cov, httpx for HTTP testing

## Common Commands
```bash
# Install with all optional deps for development
pip install -e ".[all,dev]"

# Run tests
pytest

# Lint
ruff check .

# Format
ruff format .

# Type check
mypy src/
```
