# Project Structure

Uses `src/` layout with the package at `src/fastapi_eventbus/`.

```
src/fastapi_eventbus/
├── __init__.py          # Public API surface
├── typing.py            # Shared type aliases and TypeVars
├── py.typed             # PEP 561 typed marker
├── core/                # Abstractions: BaseEvent, Publisher, Subscriber, Handler protocol, exceptions
├── backends/            # Pluggable backend implementations (sync, redis, kafka)
│                        # Registered via entry_points in pyproject.toml
├── middleware/          # FastAPI middleware for request-scoped event tracking
├── ext/                 # FastAPI integration: app extension, dependency injection, lifespan
├── registry/            # Handler registry and @on_event decorators
├── retry/               # Retry strategies (exponential backoff) and dead-letter queue
├── config/              # Pydantic Settings based configuration
└── health/              # Backend health checks

tests/
├── unit/                # Unit tests
└── integration/         # Integration tests (Redis, Kafka)
```

## Conventions
- Package uses underscores (`fastapi_eventbus`), distribution uses hyphens (`fastapi-eventbus`).
- Backends are discovered via `fastapi_eventbus.backends` entry point group.
- All event models extend Pydantic `BaseModel`.
- Async-first design; handlers can be sync or async (`HandlerFn` type alias).
- Type aliases live in `typing.py` at the package root.
