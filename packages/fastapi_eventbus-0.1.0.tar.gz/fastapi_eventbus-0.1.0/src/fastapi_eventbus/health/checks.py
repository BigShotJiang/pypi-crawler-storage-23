"""Backend health checks."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from enum import Enum

from fastapi_eventbus.backends.base import Backend

logger = logging.getLogger(__name__)


class HealthStatus(str, Enum):
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"


@dataclass
class HealthResult:
    backend: str
    status: HealthStatus
    detail: str = ""


class HealthChecker:
    """Runs health checks against one or more backends."""

    def __init__(self, backends: list[Backend], timeout: float = 5.0) -> None:
        self._backends = backends
        self._timeout = timeout

    async def check(self) -> list[HealthResult]:
        results: list[HealthResult] = []
        for backend in self._backends:
            try:
                ok = await asyncio.wait_for(backend.health_check(), timeout=self._timeout)
                results.append(
                    HealthResult(
                        backend=backend.name,
                        status=HealthStatus.HEALTHY if ok else HealthStatus.UNHEALTHY,
                    )
                )
            except asyncio.TimeoutError:
                results.append(
                    HealthResult(
                        backend=backend.name,
                        status=HealthStatus.UNHEALTHY,
                        detail="Health check timed out",
                    )
                )
            except Exception as exc:
                results.append(
                    HealthResult(
                        backend=backend.name,
                        status=HealthStatus.UNHEALTHY,
                        detail=str(exc),
                    )
                )
        return results

    async def is_healthy(self) -> bool:
        results = await self.check()
        return all(r.status == HealthStatus.HEALTHY for r in results)
