"""Handler protocol definition."""

from __future__ import annotations

import asyncio
import logging
from typing import Protocol, runtime_checkable

from fastapi_eventbus.core.event import BaseEvent

logger = logging.getLogger(__name__)


@runtime_checkable
class EventHandler(Protocol):
    """Protocol that all event handlers must satisfy."""

    async def handle(self, event: BaseEvent) -> None:
        """Process an incoming event."""
        ...


class FunctionHandler:
    """Wraps a plain sync/async function as an EventHandler."""

    __slots__ = ("_fn", "_is_async")

    def __init__(self, fn: object) -> None:
        self._fn = fn
        self._is_async = asyncio.iscoroutinefunction(fn)

    async def handle(self, event: BaseEvent) -> None:
        if self._is_async:
            await self._fn(event)  # type: ignore[misc]
        else:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._fn, event)  # type: ignore[arg-type]

    def __repr__(self) -> str:
        name = getattr(self._fn, "__qualname__", repr(self._fn))
        return f"FunctionHandler({name})"
