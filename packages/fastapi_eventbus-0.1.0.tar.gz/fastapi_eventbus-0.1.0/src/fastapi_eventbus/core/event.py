"""Base event data model."""

from __future__ import annotations

import uuid
import sys
from datetime import datetime, timezone

if sys.version_info >= (3, 11):
    from datetime import UTC
else:
    UTC = timezone.utc

from pydantic import BaseModel, Field


class BaseEvent(BaseModel):
    """Base class for all events.

    All custom events should inherit from this class.

    Example::

        class UserCreated(BaseEvent):
            topic: str = "user.created"
            user_id: int
            username: str
    """

    event_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    topic: str = "default"
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, str] = Field(default_factory=dict)

    model_config = {"frozen": True}

    def to_dict(self) -> dict[str, object]:
        """Serialize event to dict for transport."""
        return self.model_dump(mode="json")

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> BaseEvent:
        """Deserialize event from dict."""
        return cls.model_validate(data)
