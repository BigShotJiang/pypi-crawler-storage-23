"""Core abstractions for fastapi-eventbus."""

from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.core.exceptions import (
    BackendError,
    EventBusError,
    HandlerError,
    PublishError,
    RetryExhaustedError,
    SubscribeError,
)
from fastapi_eventbus.core.handler import EventHandler
from fastapi_eventbus.core.publisher import EventPublisher
from fastapi_eventbus.core.subscriber import EventSubscriber

__all__ = [
    "BaseEvent",
    "BackendError",
    "EventBusError",
    "EventHandler",
    "EventPublisher",
    "EventSubscriber",
    "HandlerError",
    "PublishError",
    "RetryExhaustedError",
    "SubscribeError",
]
