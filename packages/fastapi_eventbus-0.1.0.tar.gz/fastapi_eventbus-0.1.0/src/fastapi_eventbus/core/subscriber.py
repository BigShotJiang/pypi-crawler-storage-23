"""EventSubscriber abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from fastapi_eventbus.core.event import BaseEvent


class EventSubscriber(ABC):
    """Abstract subscriber — backends implement this to receive events."""

    @abstractmethod
    async def subscribe(self, topic: str) -> None:
        """Subscribe to a topic."""

    @abstractmethod
    async def unsubscribe(self, topic: str) -> None:
        """Unsubscribe from a topic."""

    @abstractmethod
    def listen(self) -> AsyncIterator[BaseEvent]:
        """Yield events as they arrive. Must be an async generator."""
        ...

    @abstractmethod
    async def close(self) -> None:
        """Clean up subscriber resources."""
