"""EventPublisher abstract base class."""

from __future__ import annotations

from abc import ABC, abstractmethod

from fastapi_eventbus.core.event import BaseEvent


class EventPublisher(ABC):
    """Abstract publisher — backends implement this to send events."""

    @abstractmethod
    async def publish(self, event: BaseEvent) -> None:
        """Publish a single event."""

    async def publish_many(self, events: list[BaseEvent]) -> None:
        """Publish multiple events. Override for batch-optimized backends."""
        for event in events:
            await self.publish(event)
