"""Custom exceptions for fastapi-eventbus."""


class EventBusError(Exception):
    """Base exception for all eventbus errors."""


class PublishError(EventBusError):
    """Raised when event publishing fails."""


class SubscribeError(EventBusError):
    """Raised when event subscription fails."""


class HandlerError(EventBusError):
    """Raised when an event handler fails."""

    def __init__(self, message: str, original: Exception | None = None) -> None:
        super().__init__(message)
        self.original = original


class BackendError(EventBusError):
    """Raised when a backend operation fails."""

    def __init__(self, message: str, backend: str = "unknown") -> None:
        super().__init__(message)
        self.backend = backend


class RetryExhaustedError(EventBusError):
    """Raised when all retry attempts are exhausted."""

    def __init__(self, message: str, attempts: int = 0) -> None:
        super().__init__(message)
        self.attempts = attempts
