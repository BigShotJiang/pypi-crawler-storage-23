"""Pluggable tracing for event publish/dispatch operations.

Provides a lightweight span-based tracing protocol that can be adapted
to OpenTelemetry, Jaeger, Zipkin, or any custom tracing backend.
"""

from __future__ import annotations

import logging
import time
import uuid
from contextvars import ContextVar
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol, runtime_checkable

from fastapi_eventbus.middleware.event_middleware import correlation_id_var

logger = logging.getLogger(__name__)

# Current active span
_current_span: ContextVar[EventSpan | None] = ContextVar("current_span", default=None)


class SpanStatus(str, Enum):
    OK = "ok"
    ERROR = "error"


@dataclass
class EventSpan:
    """Lightweight span representing a traced operation."""

    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    trace_id: str = ""
    parent_span_id: str = ""
    operation: str = ""
    topic: str = ""
    event_id: str = ""
    status: SpanStatus = SpanStatus.OK
    start_time: float = field(default_factory=time.monotonic)
    end_time: float = 0.0
    attributes: dict[str, str] = field(default_factory=dict)
    error_message: str = ""

    @property
    def duration(self) -> float:
        if self.end_time:
            return self.end_time - self.start_time
        return time.monotonic() - self.start_time

    def finish(self, status: SpanStatus = SpanStatus.OK, error: str = "") -> None:
        self.end_time = time.monotonic()
        self.status = status
        if error:
            self.error_message = error

    def to_dict(self) -> dict[str, object]:
        return {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "operation": self.operation,
            "topic": self.topic,
            "event_id": self.event_id,
            "status": self.status.value,
            "duration_ms": round(self.duration * 1000, 2),
            "attributes": self.attributes,
            "error_message": self.error_message,
        }


@runtime_checkable
class EventTracer(Protocol):
    """Protocol for tracing event operations.

    Implement this to bridge to OpenTelemetry, Jaeger, etc.
    """

    def start_span(
        self,
        operation: str,
        topic: str = "",
        event_id: str = "",
        parent_span: EventSpan | None = None,
    ) -> EventSpan:
        """Create and start a new span."""
        ...

    def finish_span(self, span: EventSpan) -> None:
        """Finish and export a span."""
        ...


class NoopTracer:
    """Default no-op tracer — zero overhead when tracing is disabled."""

    def start_span(
        self,
        operation: str,
        topic: str = "",
        event_id: str = "",
        parent_span: EventSpan | None = None,
    ) -> EventSpan:
        return EventSpan(operation=operation, topic=topic, event_id=event_id)

    def finish_span(self, span: EventSpan) -> None:
        pass


class LoggingTracer:
    """Tracer that logs spans — useful for development and debugging."""

    def __init__(self, log_level: int = logging.DEBUG) -> None:
        self._log_level = log_level
        self._spans: list[EventSpan] = []

    def start_span(
        self,
        operation: str,
        topic: str = "",
        event_id: str = "",
        parent_span: EventSpan | None = None,
    ) -> EventSpan:
        trace_id = correlation_id_var.get() or uuid.uuid4().hex[:16]
        span = EventSpan(
            trace_id=trace_id,
            parent_span_id=parent_span.span_id if parent_span else "",
            operation=operation,
            topic=topic,
            event_id=event_id,
        )
        _current_span.set(span)
        logger.log(self._log_level, "SPAN START %s [%s] topic=%s event=%s",
                    operation, span.span_id, topic, event_id)
        return span

    def finish_span(self, span: EventSpan) -> None:
        if not span.end_time:
            span.finish()
        self._spans.append(span)
        _current_span.set(None)
        logger.log(
            self._log_level,
            "SPAN END %s [%s] status=%s duration=%.2fms",
            span.operation,
            span.span_id,
            span.status.value,
            span.duration * 1000,
        )

    @property
    def spans(self) -> list[EventSpan]:
        return list(self._spans)

    def clear(self) -> None:
        self._spans.clear()


def get_current_span() -> EventSpan | None:
    """Get the current active span from context."""
    return _current_span.get()
