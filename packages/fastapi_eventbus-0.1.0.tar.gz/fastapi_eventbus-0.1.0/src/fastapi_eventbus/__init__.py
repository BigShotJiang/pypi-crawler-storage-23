"""fastapi-eventbus — High-availability event-driven extension for FastAPI."""

from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.core.exceptions import (
    BackendError,
    EventBusError,
    HandlerError,
    PublishError,
    RetryExhaustedError,
    SubscribeError,
)
from fastapi_eventbus.core.handler import EventHandler, FunctionHandler
from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.ext.depends import get_event_bus
from fastapi_eventbus.ext.lifespan import create_lifespan, eventbus_lifespan
from fastapi_eventbus.metrics.collector import (
    InMemoryMetricsCollector,
    MetricsCollector,
    NoopMetricsCollector,
)
from fastapi_eventbus.middleware.event_middleware import (
    EventBusMiddleware,
    get_correlation_id,
)
from fastapi_eventbus.registry.decorators import on_event
from fastapi_eventbus.retry.strategies import RetryPolicy
from fastapi_eventbus.tracing.tracer import (
    EventSpan,
    EventTracer,
    LoggingTracer,
    NoopTracer,
    SpanStatus,
    get_current_span,
)

__all__ = [
    "BackendError",
    "BaseEvent",
    "EventBus",
    "EventBusError",
    "EventBusMiddleware",
    "EventHandler",
    "EventSpan",
    "EventTracer",
    "FunctionHandler",
    "HandlerError",
    "InMemoryMetricsCollector",
    "LoggingTracer",
    "MetricsCollector",
    "NoopMetricsCollector",
    "NoopTracer",
    "PublishError",
    "RetryExhaustedError",
    "RetryPolicy",
    "SpanStatus",
    "SubscribeError",
    "create_lifespan",
    "eventbus_lifespan",
    "get_correlation_id",
    "get_current_span",
    "get_event_bus",
    "on_event",
]

__version__ = "0.1.0"
