"""Pluggable metrics collector protocol and implementations."""

from __future__ import annotations

import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@runtime_checkable
class MetricsCollector(Protocol):
    """Protocol for metrics collection.

    Implement this to integrate with Prometheus, StatsD, Datadog, etc.
    """

    def inc_published(self, topic: str) -> None:
        """Increment published event counter."""
        ...

    def inc_dispatched(self, topic: str) -> None:
        """Increment successfully dispatched event counter."""
        ...

    def inc_dispatch_error(self, topic: str) -> None:
        """Increment dispatch error counter."""
        ...

    def inc_retry(self, topic: str, attempt: int) -> None:
        """Increment retry counter."""
        ...

    def inc_dlq(self, topic: str) -> None:
        """Increment dead-letter queue counter."""
        ...

    def observe_dispatch_duration(self, topic: str, duration: float) -> None:
        """Record dispatch duration in seconds."""
        ...

    def observe_publish_duration(self, topic: str, duration: float) -> None:
        """Record publish duration in seconds."""
        ...


class NoopMetricsCollector:
    """Default no-op collector — zero overhead when metrics are disabled."""

    def inc_published(self, topic: str) -> None:
        pass

    def inc_dispatched(self, topic: str) -> None:
        pass

    def inc_dispatch_error(self, topic: str) -> None:
        pass

    def inc_retry(self, topic: str, attempt: int) -> None:
        pass

    def inc_dlq(self, topic: str) -> None:
        pass

    def observe_dispatch_duration(self, topic: str, duration: float) -> None:
        pass

    def observe_publish_duration(self, topic: str, duration: float) -> None:
        pass


@dataclass
class InMemoryMetricsCollector:
    """In-memory metrics collector for testing and debugging.

    Stores all counters and durations in plain dicts.
    """

    published: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    dispatched: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    dispatch_errors: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    retries: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    dlq_count: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    dispatch_durations: dict[str, list[float]] = field(
        default_factory=lambda: defaultdict(list)
    )
    publish_durations: dict[str, list[float]] = field(
        default_factory=lambda: defaultdict(list)
    )

    def inc_published(self, topic: str) -> None:
        self.published[topic] += 1

    def inc_dispatched(self, topic: str) -> None:
        self.dispatched[topic] += 1

    def inc_dispatch_error(self, topic: str) -> None:
        self.dispatch_errors[topic] += 1

    def inc_retry(self, topic: str, attempt: int) -> None:
        self.retries[topic] += 1

    def inc_dlq(self, topic: str) -> None:
        self.dlq_count[topic] += 1

    def observe_dispatch_duration(self, topic: str, duration: float) -> None:
        self.dispatch_durations[topic].append(duration)

    def observe_publish_duration(self, topic: str, duration: float) -> None:
        self.publish_durations[topic].append(duration)

    def snapshot(self) -> dict[str, object]:
        """Return a snapshot of all metrics as a plain dict."""
        return {
            "published": dict(self.published),
            "dispatched": dict(self.dispatched),
            "dispatch_errors": dict(self.dispatch_errors),
            "retries": dict(self.retries),
            "dlq_count": dict(self.dlq_count),
        }

    def reset(self) -> None:
        """Clear all metrics."""
        for d in (
            self.published,
            self.dispatched,
            self.dispatch_errors,
            self.retries,
            self.dlq_count,
            self.dispatch_durations,
            self.publish_durations,
        ):
            d.clear()


@contextmanager
def track_duration():
    """Context manager that yields a callable returning elapsed seconds."""
    start = time.monotonic()
    elapsed = [0.0]

    def get_elapsed() -> float:
        return elapsed[0]

    try:
        yield get_elapsed
    finally:
        elapsed[0] = time.monotonic() - start
