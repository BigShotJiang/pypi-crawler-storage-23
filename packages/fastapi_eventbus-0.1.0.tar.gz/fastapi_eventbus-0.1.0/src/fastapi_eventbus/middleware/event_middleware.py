"""Request-scoped event tracking middleware."""

from __future__ import annotations

import uuid
from contextvars import ContextVar
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

# Context variable holding the current request's correlation ID
correlation_id_var: ContextVar[str] = ContextVar("correlation_id", default="")

# Context variable holding events collected during a request
request_events_var: ContextVar[list[Any]] = ContextVar("request_events")


class EventBusMiddleware(BaseHTTPMiddleware):
    """Middleware that sets up per-request event tracking context.

    - Generates a correlation ID for each request.
    - Provides a request-scoped event collector.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        cid = request.headers.get("X-Correlation-ID", uuid.uuid4().hex)
        token_cid = correlation_id_var.set(cid)
        token_events = request_events_var.set([])
        try:
            response = await call_next(request)
            response.headers["X-Correlation-ID"] = cid
            return response
        finally:
            correlation_id_var.reset(token_cid)
            request_events_var.reset(token_events)


def get_correlation_id() -> str:
    """Get the current request's correlation ID."""
    return correlation_id_var.get()
