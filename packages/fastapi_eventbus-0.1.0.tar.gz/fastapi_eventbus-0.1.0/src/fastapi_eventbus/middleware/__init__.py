"""FastAPI middleware."""

from fastapi_eventbus.middleware.event_middleware import EventBusMiddleware

__all__ = ["EventBusMiddleware"]
