"""Pydantic Settings for eventbus configuration."""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings

from fastapi_eventbus.config.defaults import (
    DEFAULT_BACKEND,
    DEFAULT_DLQ_ENABLED,
    DEFAULT_DLQ_TOPIC_SUFFIX,
    DEFAULT_KAFKA_BOOTSTRAP_SERVERS,
    DEFAULT_KAFKA_GROUP_ID,
    DEFAULT_MAX_RETRIES,
    DEFAULT_REDIS_MAX_CONNECTIONS,
    DEFAULT_REDIS_URL,
    DEFAULT_RETRY_BACKOFF_FACTOR,
    DEFAULT_RETRY_DELAY,
    DEFAULT_RETRY_MAX_DELAY,
)


class EventBusSettings(BaseSettings):
    """Central configuration — reads from env vars with EVENTBUS_ prefix."""

    model_config = {"env_prefix": "EVENTBUS_"}

    # General
    backend: str = Field(default=DEFAULT_BACKEND, description="Backend type: sync | redis | kafka")

    # Retry
    max_retries: int = DEFAULT_MAX_RETRIES
    retry_delay: float = DEFAULT_RETRY_DELAY
    retry_backoff_factor: float = DEFAULT_RETRY_BACKOFF_FACTOR
    retry_max_delay: float = DEFAULT_RETRY_MAX_DELAY

    # DLQ
    dlq_enabled: bool = DEFAULT_DLQ_ENABLED
    dlq_topic_suffix: str = DEFAULT_DLQ_TOPIC_SUFFIX

    # Redis
    redis_url: str = DEFAULT_REDIS_URL
    redis_max_connections: int = DEFAULT_REDIS_MAX_CONNECTIONS

    # Kafka
    kafka_bootstrap_servers: str = DEFAULT_KAFKA_BOOTSTRAP_SERVERS
    kafka_group_id: str = DEFAULT_KAFKA_GROUP_ID
