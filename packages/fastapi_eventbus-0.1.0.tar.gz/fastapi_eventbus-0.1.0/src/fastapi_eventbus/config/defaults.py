"""Default configuration values."""

from __future__ import annotations

# Backend
DEFAULT_BACKEND = "sync"

# Retry
DEFAULT_MAX_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0  # seconds
DEFAULT_RETRY_BACKOFF_FACTOR = 2.0
DEFAULT_RETRY_MAX_DELAY = 60.0  # seconds

# DLQ
DEFAULT_DLQ_ENABLED = False
DEFAULT_DLQ_TOPIC_SUFFIX = ".dlq"

# Health
DEFAULT_HEALTH_TIMEOUT = 5.0  # seconds

# Redis
DEFAULT_REDIS_URL = "redis://localhost:6379/0"
DEFAULT_REDIS_MAX_CONNECTIONS = 10

# Kafka
DEFAULT_KAFKA_BOOTSTRAP_SERVERS = "localhost:9092"
DEFAULT_KAFKA_GROUP_ID = "fastapi-eventbus"
