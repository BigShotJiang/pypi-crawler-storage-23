"""Configuration management."""

from fastapi_eventbus.config.settings import EventBusSettings

__all__ = ["EventBusSettings"]
