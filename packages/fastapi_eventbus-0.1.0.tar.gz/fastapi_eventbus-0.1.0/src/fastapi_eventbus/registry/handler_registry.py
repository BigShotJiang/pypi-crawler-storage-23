"""Handler registry — maps topics to handlers."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict

from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.core.exceptions import HandlerError
from fastapi_eventbus.core.handler import EventHandler, FunctionHandler
from fastapi_eventbus.typing import HandlerFn

logger = logging.getLogger(__name__)


class HandlerRegistry:
    """Thread-safe registry mapping topics → list of handlers."""

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def register(self, topic: str, handler: EventHandler | HandlerFn) -> None:
        """Register a handler for a topic."""
        h = handler if isinstance(handler, EventHandler) else FunctionHandler(handler)
        async with self._lock:
            self._handlers[topic].append(h)
        logger.debug("Registered handler %r for topic %s", h, topic)

    async def unregister(self, topic: str, handler: EventHandler) -> None:
        """Remove a specific handler from a topic."""
        async with self._lock:
            handlers = self._handlers.get(topic, [])
            self._handlers[topic] = [h for h in handlers if h is not handler]

    def get_handlers(self, topic: str) -> list[EventHandler]:
        """Return all handlers for a topic."""
        return list(self._handlers.get(topic, []))

    @property
    def topics(self) -> list[str]:
        """Return all registered topics."""
        return list(self._handlers.keys())

    async def dispatch(self, event: BaseEvent) -> list[Exception]:
        """Dispatch event to all handlers. Returns list of errors (empty = success)."""
        handlers = self.get_handlers(event.topic)
        if not handlers:
            logger.warning("No handlers for topic %s", event.topic)
            return []

        errors: list[Exception] = []
        for handler in handlers:
            try:
                await handler.handle(event)
            except Exception as exc:
                err = HandlerError(
                    f"Handler {handler!r} failed for event {event.event_id}: {exc}",
                    original=exc,
                )
                errors.append(err)
                logger.error(str(err))
        return errors

    def clear(self) -> None:
        """Remove all handlers."""
        self._handlers.clear()
