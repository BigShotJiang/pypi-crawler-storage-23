"""Handler registry and decorators."""

from fastapi_eventbus.registry.decorators import on_event
from fastapi_eventbus.registry.handler_registry import HandlerRegistry

__all__ = ["HandlerRegistry", "on_event"]
