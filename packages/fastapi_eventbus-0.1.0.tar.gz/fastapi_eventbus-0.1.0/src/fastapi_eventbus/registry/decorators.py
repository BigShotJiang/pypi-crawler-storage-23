"""Decorators for registering event handlers."""

from __future__ import annotations

from typing import TypeVar, overload

from fastapi_eventbus.typing import HandlerFn

F = TypeVar("F", bound=HandlerFn)

# Module-level list of pending registrations (topic, handler).
# These are flushed into the HandlerRegistry during app startup.
_pending_registrations: list[tuple[str, HandlerFn]] = []


@overload
def on_event(topic: str) -> ...: ...


@overload
def on_event(topic: str, /) -> ...: ...


def on_event(topic: str):  # type: ignore[no-untyped-def]
    """Decorator to register a function as an event handler.

    Usage::

        @on_event("user.created")
        async def handle_user_created(event: BaseEvent) -> None:
            print(event)
    """

    def decorator(fn: F) -> F:
        _pending_registrations.append((topic, fn))
        return fn

    return decorator


def get_pending_registrations() -> list[tuple[str, HandlerFn]]:
    """Return and clear all pending registrations."""
    regs = list(_pending_registrations)
    _pending_registrations.clear()
    return regs
