"""Kafka backend using aiokafka with rebalance handling."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.core.exceptions import BackendError

if TYPE_CHECKING:
    from aiokafka import AIOKafkaConsumer, AIOKafkaProducer, TopicPartition

logger = logging.getLogger(__name__)


class RebalanceListener:
    """Handles Kafka consumer group rebalance events.

    On revoke: commits current offsets and pauses processing.
    On assign: resumes processing on newly assigned partitions.
    """

    def __init__(self, consumer: AIOKafkaConsumer) -> None:
        self._consumer = consumer
        self._rebalancing = asyncio.Event()
        self._rebalancing.set()  # not rebalancing initially
        self._revoked_partitions: set[TopicPartition] = set()
        self._assigned_partitions: set[TopicPartition] = set()

    @property
    def is_rebalancing(self) -> bool:
        return not self._rebalancing.is_set()

    async def wait_ready(self) -> None:
        """Block until rebalance is complete."""
        await self._rebalancing.wait()

    def on_partitions_revoked(self, revoked: set[TopicPartition]) -> None:
        """Called before rebalance — commit offsets, pause processing."""
        self._rebalancing.clear()
        self._revoked_partitions = set(revoked)
        logger.info(
            "Partitions revoked: %s",
            [f"{tp.topic}-{tp.partition}" for tp in revoked],
        )

    def on_partitions_assigned(self, assigned: set[TopicPartition]) -> None:
        """Called after rebalance — resume processing on new partitions."""
        self._assigned_partitions = set(assigned)
        self._rebalancing.set()
        logger.info(
            "Partitions assigned: %s",
            [f"{tp.topic}-{tp.partition}" for tp in assigned],
        )


class KafkaBackend(Backend):
    """Kafka-based backend with rebalance-safe consumer.

    Features:
    - Rebalance listener that pauses event processing during rebalance
    - Manual offset commit after successful dispatch
    - Configurable auto_offset_reset and session_timeout
    - Batch publish support
    """

    def __init__(
        self,
        bootstrap_servers: str = "localhost:9092",
        group_id: str = "fastapi-eventbus",
        auto_offset_reset: str = "earliest",
        session_timeout_ms: int = 30_000,
        heartbeat_interval_ms: int = 10_000,
        max_poll_interval_ms: int = 300_000,
        enable_auto_commit: bool = False,
        **kwargs: Any,
    ) -> None:
        self._bootstrap_servers = bootstrap_servers
        self._group_id = group_id
        self._auto_offset_reset = auto_offset_reset
        self._session_timeout_ms = session_timeout_ms
        self._heartbeat_interval_ms = heartbeat_interval_ms
        self._max_poll_interval_ms = max_poll_interval_ms
        self._enable_auto_commit = enable_auto_commit
        self._kwargs = kwargs
        self._producer: AIOKafkaProducer | None = None
        self._consumer: AIOKafkaConsumer | None = None
        self._rebalance_listener: RebalanceListener | None = None
        self._subscriptions: set[str] = set()
        self._started = False

    @property
    def name(self) -> str:
        return "kafka"

    async def connect(self) -> None:
        try:
            from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
        except ImportError as exc:
            raise BackendError(
                "aiokafka package is required: pip install fastapi-eventbus[kafka]",
                backend="kafka",
            ) from exc

        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode(),
            **{k: v for k, v in self._kwargs.items() if k.startswith("producer_")},
        )
        await self._producer.start()

        self._consumer = AIOKafkaConsumer(
            bootstrap_servers=self._bootstrap_servers,
            group_id=self._group_id,
            auto_offset_reset=self._auto_offset_reset,
            session_timeout_ms=self._session_timeout_ms,
            heartbeat_interval_ms=self._heartbeat_interval_ms,
            max_poll_interval_ms=self._max_poll_interval_ms,
            enable_auto_commit=self._enable_auto_commit,
            value_deserializer=lambda v: json.loads(v.decode()),
        )
        self._rebalance_listener = RebalanceListener(self._consumer)
        logger.info("KafkaBackend connected to %s (group=%s)", self._bootstrap_servers, self._group_id)

    async def disconnect(self) -> None:
        if self._consumer and self._started:
            try:
                await self._consumer.commit()
            except Exception:
                logger.warning("Failed to commit offsets on disconnect", exc_info=True)
            await self._consumer.stop()
        if self._producer:
            await self._producer.stop()
        self._subscriptions.clear()
        self._started = False
        logger.info("KafkaBackend disconnected")

    async def publish(self, event: BaseEvent) -> None:
        if not self._producer:
            raise BackendError("Not connected", backend="kafka")
        await self._producer.send_and_wait(event.topic, event.to_dict())
        logger.debug("Published event %s to Kafka topic %s", event.event_id, event.topic)

    async def publish_many(self, events: list[BaseEvent]) -> None:
        """Batch publish — sends all then awaits flush."""
        if not self._producer:
            raise BackendError("Not connected", backend="kafka")
        for event in events:
            await self._producer.send(event.topic, event.to_dict())
        await self._producer.flush()

    async def subscribe(self, topic: str) -> None:
        self._subscriptions.add(topic)
        if self._consumer and self._rebalance_listener:
            self._consumer.subscribe(
                list(self._subscriptions),
                listener=self._rebalance_listener,
            )

    async def unsubscribe(self, topic: str) -> None:
        self._subscriptions.discard(topic)
        if self._consumer and self._subscriptions and self._rebalance_listener:
            self._consumer.subscribe(
                list(self._subscriptions),
                listener=self._rebalance_listener,
            )
        elif self._consumer:
            self._consumer.unsubscribe()

    async def listen(self) -> AsyncIterator[BaseEvent]:  # type: ignore[override]
        """Consume messages with rebalance-safe processing.

        - Waits for rebalance to complete before yielding events
        - Commits offsets after each successfully yielded event
        - Handles consumer errors gracefully with backoff
        """
        if not self._consumer:
            raise BackendError("Not connected", backend="kafka")

        if not self._started:
            await self._consumer.start()
            self._started = True

        while True:
            try:
                # Wait if a rebalance is in progress
                if self._rebalance_listener:
                    await self._rebalance_listener.wait_ready()

                async for msg in self._consumer:
                    # Pause during rebalance
                    if self._rebalance_listener and self._rebalance_listener.is_rebalancing:
                        await self._rebalance_listener.wait_ready()
                        continue

                    try:
                        event = BaseEvent.from_dict(msg.value)
                        yield event

                        # Commit offset after successful processing
                        if not self._enable_auto_commit:
                            from aiokafka import TopicPartition

                            tp = TopicPartition(msg.topic, msg.partition)
                            await self._consumer.commit({tp: msg.offset + 1})
                    except Exception:
                        logger.exception(
                            "Error processing message from %s-%d offset %d",
                            msg.topic,
                            msg.partition,
                            msg.offset,
                        )
                        raise

            except asyncio.CancelledError:
                return
            except Exception:
                logger.exception("Kafka consumer error, reconnecting in 5s")
                await asyncio.sleep(5)

    async def commit_offsets(self) -> None:
        """Manually commit current offsets."""
        if self._consumer and self._started:
            await self._consumer.commit()

    async def health_check(self) -> bool:
        if not self._producer:
            return False
        try:
            await self._producer.partitions_for("__consumer_offsets")
            return True
        except Exception:
            return False
