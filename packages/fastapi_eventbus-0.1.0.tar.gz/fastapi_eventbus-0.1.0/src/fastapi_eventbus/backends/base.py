"""Backend abstract base class combining publisher + subscriber."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator

from fastapi_eventbus.core.event import BaseEvent


class Backend(ABC):
    """Unified backend interface for publish/subscribe + lifecycle."""

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the backend."""

    @abstractmethod
    async def disconnect(self) -> None:
        """Gracefully close the backend connection."""

    @abstractmethod
    async def publish(self, event: BaseEvent) -> None:
        """Publish an event to its topic."""

    async def publish_many(self, events: list[BaseEvent]) -> None:
        """Publish multiple events. Override for batch optimization."""
        for event in events:
            await self.publish(event)

    @abstractmethod
    async def subscribe(self, topic: str) -> None:
        """Subscribe to a topic."""

    @abstractmethod
    async def unsubscribe(self, topic: str) -> None:
        """Unsubscribe from a topic."""

    @abstractmethod
    def listen(self) -> AsyncIterator[BaseEvent]:
        """Yield events as they arrive."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the backend is healthy."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Backend identifier string."""
