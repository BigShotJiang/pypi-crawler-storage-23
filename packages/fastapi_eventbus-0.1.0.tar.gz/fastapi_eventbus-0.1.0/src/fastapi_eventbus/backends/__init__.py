"""Pluggable backend implementations."""

from fastapi_eventbus.backends.base import Backend

__all__ = ["Backend"]
