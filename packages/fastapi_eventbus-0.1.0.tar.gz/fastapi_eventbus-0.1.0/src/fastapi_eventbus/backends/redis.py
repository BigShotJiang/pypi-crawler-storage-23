"""Redis pub/sub backend."""

from __future__ import annotations

import json
import logging
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.core.exceptions import BackendError

if TYPE_CHECKING:
    from redis.asyncio import Redis

logger = logging.getLogger(__name__)


class RedisBackend(Backend):
    """Redis-based pub/sub backend using redis.asyncio."""

    def __init__(self, url: str = "redis://localhost:6379/0", **kwargs: Any) -> None:
        self._url = url
        self._kwargs = kwargs
        self._client: Redis | None = None  # type: ignore[type-arg]
        self._pubsub: Any = None
        self._subscriptions: set[str] = set()

    @property
    def name(self) -> str:
        return "redis"

    async def connect(self) -> None:
        try:
            from redis.asyncio import Redis as AsyncRedis
        except ImportError as exc:
            raise BackendError(
                "redis package is required: pip install fastapi-eventbus[redis]",
                backend="redis",
            ) from exc
        self._client = AsyncRedis.from_url(self._url, **self._kwargs)
        self._pubsub = self._client.pubsub()
        logger.info("RedisBackend connected to %s", self._url)

    async def disconnect(self) -> None:
        if self._pubsub:
            await self._pubsub.unsubscribe()
            await self._pubsub.close()
        if self._client:
            await self._client.close()
        self._subscriptions.clear()
        logger.info("RedisBackend disconnected")

    async def publish(self, event: BaseEvent) -> None:
        if not self._client:
            raise BackendError("Not connected", backend="redis")
        payload = json.dumps(event.to_dict())
        await self._client.publish(event.topic, payload)
        logger.debug("Published event %s to Redis topic %s", event.event_id, event.topic)

    async def subscribe(self, topic: str) -> None:
        if not self._pubsub:
            raise BackendError("Not connected", backend="redis")
        await self._pubsub.subscribe(topic)
        self._subscriptions.add(topic)

    async def unsubscribe(self, topic: str) -> None:
        if not self._pubsub:
            return
        await self._pubsub.unsubscribe(topic)
        self._subscriptions.discard(topic)

    async def listen(self) -> AsyncIterator[BaseEvent]:  # type: ignore[override]
        if not self._pubsub:
            raise BackendError("Not connected", backend="redis")
        async for message in self._pubsub.listen():
            if message["type"] == "message":
                data = json.loads(message["data"])
                yield BaseEvent.from_dict(data)

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            return bool(await self._client.ping())
        except Exception:
            return False
