"""In-memory synchronous backend — great for dev/testing."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from collections.abc import AsyncIterator

from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.core.event import BaseEvent

logger = logging.getLogger(__name__)


class SyncBackend(Backend):
    """In-memory pub/sub using asyncio.Queue per topic."""

    def __init__(self) -> None:
        self._queues: dict[str, asyncio.Queue[BaseEvent]] = defaultdict(asyncio.Queue)
        self._subscriptions: set[str] = set()
        self._connected = False

    @property
    def name(self) -> str:
        return "sync"

    async def connect(self) -> None:
        self._connected = True
        logger.info("SyncBackend connected (in-memory)")

    async def disconnect(self) -> None:
        self._queues.clear()
        self._subscriptions.clear()
        self._connected = False
        logger.info("SyncBackend disconnected")

    async def publish(self, event: BaseEvent) -> None:
        topic = event.topic
        if topic in self._subscriptions:
            await self._queues[topic].put(event)
            logger.debug("Published event %s to topic %s", event.event_id, topic)

    async def subscribe(self, topic: str) -> None:
        self._subscriptions.add(topic)
        logger.debug("Subscribed to topic %s", topic)

    async def unsubscribe(self, topic: str) -> None:
        self._subscriptions.discard(topic)
        self._queues.pop(topic, None)
        logger.debug("Unsubscribed from topic %s", topic)

    async def listen(self) -> AsyncIterator[BaseEvent]:  # type: ignore[override]
        """Round-robin listen across all subscribed topics."""
        while self._connected:
            yielded = False
            for topic in list(self._subscriptions):
                q = self._queues.get(topic)
                if q and not q.empty():
                    event = q.get_nowait()
                    yield event
                    yielded = True
            if not yielded:
                await asyncio.sleep(0.01)

    async def health_check(self) -> bool:
        return self._connected
