"""Lifespan management for EventBus integration with FastAPI."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from fastapi import FastAPI

if TYPE_CHECKING:
    from fastapi_eventbus.ext.app import EventBus


def create_lifespan(bus: EventBus) -> object:
    """Create a FastAPI lifespan context manager that manages the EventBus.

    Usage::

        bus = EventBus()
        app = FastAPI(lifespan=create_lifespan(bus))

    Or compose with your own lifespan::

        @asynccontextmanager
        async def lifespan(app: FastAPI):
            async with eventbus_lifespan(bus, app):
                yield
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        app.state.event_bus = bus
        await bus.start()
        try:
            yield
        finally:
            await bus.stop()

    return lifespan


@asynccontextmanager
async def eventbus_lifespan(bus: EventBus, app: FastAPI) -> AsyncIterator[None]:
    """Composable async context manager for use inside custom lifespans."""
    app.state.event_bus = bus
    await bus.start()
    try:
        yield
    finally:
        await bus.stop()
