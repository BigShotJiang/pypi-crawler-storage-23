"""FastAPI dependency injection components."""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

if TYPE_CHECKING:
    from fastapi_eventbus.ext.app import EventBus


def get_event_bus(request: Request) -> EventBus:
    """FastAPI dependency — retrieve the EventBus from app state.

    Usage::

        @app.post("/users")
        async def create_user(bus: EventBus = Depends(get_event_bus)):
            await bus.publish(UserCreated(user_id=1))
    """
    bus: EventBus | None = getattr(request.app.state, "event_bus", None)
    if bus is None:
        raise RuntimeError(
            "EventBus not found on app.state. "
            "Did you use EventBus.lifespan or manually set app.state.event_bus?"
        )
    return bus
