"""FastAPI extension integration."""

from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.ext.depends import get_event_bus
from fastapi_eventbus.ext.lifespan import create_lifespan, eventbus_lifespan

__all__ = ["EventBus", "create_lifespan", "eventbus_lifespan", "get_event_bus"]
