"""EventBus — the main application extension."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.backends.sync import SyncBackend
from fastapi_eventbus.config.settings import EventBusSettings
from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.health.checks import HealthChecker
from fastapi_eventbus.metrics.collector import MetricsCollector, NoopMetricsCollector
from fastapi_eventbus.registry.decorators import get_pending_registrations
from fastapi_eventbus.registry.handler_registry import HandlerRegistry
from fastapi_eventbus.retry.dlq import DeadLetterQueue, FailedEvent
from fastapi_eventbus.retry.strategies import RetryPolicy
from fastapi_eventbus.tracing.tracer import EventTracer, NoopTracer, SpanStatus

logger = logging.getLogger(__name__)


class EventBus:
    """Central event bus — wire this into your FastAPI app.

    Example::

        bus = EventBus()
        app = FastAPI(lifespan=create_lifespan(bus))

    With metrics and tracing::

        from fastapi_eventbus.metrics import InMemoryMetricsCollector
        from fastapi_eventbus.tracing import LoggingTracer

        bus = EventBus(
            metrics=InMemoryMetricsCollector(),
            tracer=LoggingTracer(),
        )
    """

    def __init__(
        self,
        backend: Backend | None = None,
        settings: EventBusSettings | None = None,
        retry_policy: RetryPolicy | None = None,
        metrics: MetricsCollector | None = None,
        tracer: EventTracer | None = None,
    ) -> None:
        self.settings = settings or EventBusSettings()
        self.backend = backend or self._create_default_backend()
        self.registry = HandlerRegistry()
        self.retry_policy = retry_policy or RetryPolicy(
            max_retries=self.settings.max_retries,
            delay=self.settings.retry_delay,
            backoff_factor=self.settings.retry_backoff_factor,
            max_delay=self.settings.retry_max_delay,
        )
        self.dlq = DeadLetterQueue(
            backend=self.backend if self.settings.dlq_enabled else None,
            topic_suffix=self.settings.dlq_topic_suffix,
        )
        self.health = HealthChecker([self.backend])
        self.metrics: MetricsCollector = metrics or NoopMetricsCollector()
        self.tracer: EventTracer = tracer or NoopTracer()
        self._listener_task: asyncio.Task[Any] | None = None

    def _create_default_backend(self) -> Backend:
        name = self.settings.backend
        if name == "sync":
            return SyncBackend()
        if name == "redis":
            from fastapi_eventbus.backends.redis import RedisBackend

            return RedisBackend(
                url=self.settings.redis_url,
                max_connections=self.settings.redis_max_connections,
            )
        if name == "kafka":
            from fastapi_eventbus.backends.kafka import KafkaBackend

            return KafkaBackend(
                bootstrap_servers=self.settings.kafka_bootstrap_servers,
                group_id=self.settings.kafka_group_id,
            )
        raise ValueError(f"Unknown backend: {name}")

    async def start(self) -> None:
        """Connect backend, flush pending registrations, start listener."""
        await self.backend.connect()

        # Flush decorator-based registrations
        for topic, handler in get_pending_registrations():
            await self.registry.register(topic, handler)

        # Subscribe backend to all registered topics
        for topic in self.registry.topics:
            await self.backend.subscribe(topic)

        # Start background listener
        self._listener_task = asyncio.create_task(self._listen_loop(), name="eventbus-listener")
        logger.info("EventBus started with backend=%s", self.backend.name)

    async def stop(self) -> None:
        """Stop listener and disconnect backend."""
        if self._listener_task and not self._listener_task.done():
            self._listener_task.cancel()
            try:
                await self._listener_task
            except asyncio.CancelledError:
                pass
        await self.backend.disconnect()
        logger.info("EventBus stopped")

    async def publish(self, event: BaseEvent) -> None:
        """Publish an event through the backend with metrics and tracing."""
        span = self.tracer.start_span("publish", topic=event.topic, event_id=event.event_id)
        start = time.monotonic()
        try:
            await self.backend.publish(event)
            self.metrics.inc_published(event.topic)
            span.finish(SpanStatus.OK)
        except Exception as exc:
            span.finish(SpanStatus.ERROR, error=str(exc))
            raise
        finally:
            self.metrics.observe_publish_duration(event.topic, time.monotonic() - start)
            self.tracer.finish_span(span)

    async def publish_many(self, events: list[BaseEvent]) -> None:
        """Publish multiple events."""
        for event in events:
            await self.publish(event)

    async def subscribe(self, topic: str) -> None:
        """Dynamically subscribe to a new topic at runtime."""
        await self.backend.subscribe(topic)

    async def _listen_loop(self) -> None:
        """Background task: consume events and dispatch to handlers."""
        try:
            async for event in self.backend.listen():
                await self._dispatch_with_retry(event)
        except asyncio.CancelledError:
            return
        except Exception:
            logger.exception("Listener loop crashed")

    async def _dispatch_with_retry(self, event: BaseEvent) -> None:
        """Dispatch with retry, metrics, and tracing; send to DLQ on exhaustion."""
        span = self.tracer.start_span("dispatch", topic=event.topic, event_id=event.event_id)
        start = time.monotonic()
        attempt = 0

        try:
            last_exc: Exception | None = None
            for attempt in range(self.retry_policy.max_retries + 1):
                try:
                    errors = await self.registry.dispatch(event)
                    if errors:
                        # At least one handler failed — treat as partial failure
                        for err in errors:
                            self.metrics.inc_dispatch_error(event.topic)
                        raise errors[0]
                    # All handlers succeeded
                    self.metrics.inc_dispatched(event.topic)
                    span.finish(SpanStatus.OK)
                    return
                except Exception as exc:
                    last_exc = exc
                    if attempt < self.retry_policy.max_retries:
                        self.metrics.inc_retry(event.topic, attempt + 1)
                        wait = self.retry_policy.get_delay(attempt)
                        logger.warning(
                            "Dispatch attempt %d/%d for event %s failed (%s), retrying in %.2fs",
                            attempt + 1,
                            self.retry_policy.max_retries + 1,
                            event.event_id,
                            exc,
                            wait,
                        )
                        await asyncio.sleep(wait)

            # All retries exhausted
            self.metrics.inc_dlq(event.topic)
            span.finish(SpanStatus.ERROR, error=str(last_exc))
            await self.dlq.enqueue(
                FailedEvent(event=event, error=last_exc or Exception("unknown"), attempts=attempt + 1)
            )

        except Exception as exc:
            span.finish(SpanStatus.ERROR, error=str(exc))
            self.metrics.inc_dlq(event.topic)
            await self.dlq.enqueue(
                FailedEvent(event=event, error=exc, attempts=attempt + 1)
            )
        finally:
            self.metrics.observe_dispatch_duration(event.topic, time.monotonic() - start)
            self.tracer.finish_span(span)
