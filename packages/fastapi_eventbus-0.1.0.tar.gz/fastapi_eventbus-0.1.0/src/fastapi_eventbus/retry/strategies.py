"""Retry strategies with exponential backoff."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from fastapi_eventbus.config.defaults import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_BACKOFF_FACTOR,
    DEFAULT_RETRY_DELAY,
    DEFAULT_RETRY_MAX_DELAY,
)
from fastapi_eventbus.core.exceptions import RetryExhaustedError

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    """Configurable retry policy with exponential backoff."""

    max_retries: int = DEFAULT_MAX_RETRIES
    delay: float = DEFAULT_RETRY_DELAY
    backoff_factor: float = DEFAULT_RETRY_BACKOFF_FACTOR
    max_delay: float = DEFAULT_RETRY_MAX_DELAY
    retryable_exceptions: tuple[type[Exception], ...] = field(default=(Exception,))

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for a given attempt number (0-indexed)."""
        d = self.delay * (self.backoff_factor ** attempt)
        return min(d, self.max_delay)

    async def execute(self, coro_factory, *args, **kwargs):  # type: ignore[no-untyped-def]
        """Execute an async callable with retry logic.

        ``coro_factory`` is called each attempt to produce a fresh coroutine.
        """
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                return await coro_factory(*args, **kwargs)
            except self.retryable_exceptions as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    wait = self.get_delay(attempt)
                    logger.warning(
                        "Attempt %d/%d failed (%s), retrying in %.2fs",
                        attempt + 1,
                        self.max_retries + 1,
                        exc,
                        wait,
                    )
                    await asyncio.sleep(wait)

        raise RetryExhaustedError(
            f"All {self.max_retries + 1} attempts failed: {last_exc}",
            attempts=self.max_retries + 1,
        )
