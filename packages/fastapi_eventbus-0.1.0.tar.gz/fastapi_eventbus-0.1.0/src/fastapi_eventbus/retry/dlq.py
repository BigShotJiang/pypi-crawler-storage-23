"""Dead-letter queue for failed events."""

from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field

from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.core.event import BaseEvent

logger = logging.getLogger(__name__)


@dataclass
class FailedEvent:
    """Wrapper for an event that failed processing."""

    event: BaseEvent
    error: Exception
    attempts: int = 0


class DeadLetterQueue:
    """Stores events that exhausted all retry attempts.

    Supports both in-memory storage and backend-backed persistence.
    """

    def __init__(
        self,
        backend: Backend | None = None,
        topic_suffix: str = ".dlq",
        max_memory_size: int = 10_000,
    ) -> None:
        self._backend = backend
        self._topic_suffix = topic_suffix
        self._memory: deque[FailedEvent] = deque(maxlen=max_memory_size)

    async def enqueue(self, failed: FailedEvent) -> None:
        """Send a failed event to the DLQ."""
        self._memory.append(failed)
        logger.warning(
            "Event %s moved to DLQ after %d attempts: %s",
            failed.event.event_id,
            failed.attempts,
            failed.error,
        )
        if self._backend:
            dlq_topic = failed.event.topic + self._topic_suffix
            await self._backend.publish(failed.event)
            logger.debug("Persisted DLQ event to topic %s", dlq_topic)

    def peek(self, limit: int = 10) -> list[FailedEvent]:
        """Return up to ``limit`` most recent failed events."""
        return list(self._memory)[-limit:]

    def size(self) -> int:
        return len(self._memory)

    def clear(self) -> None:
        self._memory.clear()
