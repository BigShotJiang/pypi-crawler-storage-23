"""Type definitions for fastapi-eventbus."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any, TypeAlias, TypeVar

from pydantic import BaseModel

# Generic event type variable
E = TypeVar("E", bound=BaseModel)

# Handler callable types
AsyncHandlerFn: TypeAlias = Callable[..., Awaitable[Any]]
SyncHandlerFn: TypeAlias = Callable[..., Any]
HandlerFn: TypeAlias = AsyncHandlerFn | SyncHandlerFn

# Metadata dict
EventMeta: TypeAlias = dict[str, Any]

# Topic string
Topic: TypeAlias = str
