"""Kafka 后端示例 — 含 Rebalance 处理、Metrics、Tracing"""

from fastapi import Depends, FastAPI

from fastapi_eventbus import (
    BaseEvent,
    EventBus,
    EventBusMiddleware,
    InMemoryMetricsCollector,
    LoggingTracer,
    RetryPolicy,
    create_lifespan,
    get_event_bus,
    on_event,
)
from fastapi_eventbus.backends.kafka import KafkaBackend
from fastapi_eventbus.config import EventBusSettings


# ── 事件 ──────────────────────────────────────────────────


class InventoryUpdated(BaseEvent):
    topic: str = "inventory.updated"
    sku: str
    quantity: int


class ShipmentCreated(BaseEvent):
    topic: str = "shipment.created"
    shipment_id: str
    destination: str


# ── 处理器 ────────────────────────────────────────────────


@on_event("inventory.updated")
async def handle_inventory(event: BaseEvent) -> None:
    print(f"[Kafka] 库存更新: {event.event_id}")


@on_event("shipment.created")
async def handle_shipment(event: BaseEvent) -> None:
    print(f"[Kafka] 发货单创建: {event.event_id}")


# ── 应用配置 ──────────────────────────────────────────────

settings = EventBusSettings()

backend = KafkaBackend(
    bootstrap_servers=settings.kafka_bootstrap_servers,
    group_id=settings.kafka_group_id,
    auto_offset_reset="earliest",
    enable_auto_commit=False,
)

metrics = InMemoryMetricsCollector()
tracer = LoggingTracer()

bus = EventBus(
    backend=backend,
    settings=settings,
    retry_policy=RetryPolicy(max_retries=3, delay=1.0),
    metrics=metrics,
    tracer=tracer,
)

app = FastAPI(title="EventBus Kafka Example", lifespan=create_lifespan(bus))
app.add_middleware(EventBusMiddleware)


# ── 路由 ──────────────────────────────────────────────────


@app.post("/publish")
async def publish(bus: EventBus = Depends(get_event_bus)):
    event = InventoryUpdated(sku="SKU-001", quantity=50)
    await bus.publish(event)
    return {"event_id": event.event_id}


@app.post("/publish-batch")
async def publish_batch(bus: EventBus = Depends(get_event_bus)):
    events = [
        InventoryUpdated(sku=f"SKU-{i:03d}", quantity=i * 10)
        for i in range(10)
    ]
    await bus.publish_many(events)
    return {"count": len(events)}


@app.get("/metrics")
async def show_metrics():
    return metrics.snapshot()


@app.get("/health")
async def health(bus: EventBus = Depends(get_event_bus)):
    results = await bus.health.check()
    return [
        {"backend": r.backend, "status": r.status.value, "detail": r.detail}
        for r in results
    ]
