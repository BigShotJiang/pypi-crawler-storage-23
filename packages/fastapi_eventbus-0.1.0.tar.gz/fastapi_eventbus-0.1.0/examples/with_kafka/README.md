# Kafka 后端示例

## 前置条件

```bash
# 使用 docker-compose 启动 Kafka
docker-compose up -d
```

或者手动启动：

```bash
docker run -d --name kafka \
  -p 9092:9092 \
  -e KAFKA_CFG_NODE_ID=0 \
  -e KAFKA_CFG_PROCESS_ROLES=controller,broker \
  -e KAFKA_CFG_LISTENERS=PLAINTEXT://:9092,CONTROLLER://:9093 \
  -e KAFKA_CFG_ADVERTISED_LISTENERS=PLAINTEXT://localhost:9092 \
  -e KAFKA_CFG_CONTROLLER_QUORUM_VOTERS=0@localhost:9093 \
  -e KAFKA_CFG_CONTROLLER_LISTENER_NAMES=CONTROLLER \
  bitnami/kafka:latest
```

## 运行

```bash
cd examples/with_kafka
pip install fastapi-eventbus[kafka] uvicorn

export EVENTBUS_BACKEND=kafka
export EVENTBUS_KAFKA_BOOTSTRAP_SERVERS=localhost:9092
export EVENTBUS_KAFKA_GROUP_ID=demo-service

uvicorn main:app --reload
```

## 测试

```bash
# 发布事件
curl -X POST http://localhost:8000/publish

# 批量发布
curl -X POST http://localhost:8000/publish-batch

# 健康检查
curl http://localhost:8000/health

# 查看 metrics
curl http://localhost:8000/metrics
```
