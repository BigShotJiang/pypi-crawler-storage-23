"""基础用法示例 — 内存后端 + Metrics + Tracing"""

from fastapi import Depends, FastAPI

from fastapi_eventbus import (
    BaseEvent,
    EventBus,
    EventBusMiddleware,
    InMemoryMetricsCollector,
    LoggingTracer,
    create_lifespan,
    get_correlation_id,
    get_event_bus,
    on_event,
)


# ── 定义事件 ──────────────────────────────────────────────


class UserCreated(BaseEvent):
    topic: str = "user.created"
    user_id: int
    username: str


class OrderPlaced(BaseEvent):
    topic: str = "order.placed"
    order_id: int
    amount: float


# ── 注册处理器 ────────────────────────────────────────────


@on_event("user.created")
async def log_user(event: BaseEvent) -> None:
    print(f"[handler] 新用户注册: {event.event_id}")


@on_event("order.placed")
async def log_order(event: BaseEvent) -> None:
    print(f"[handler] 新订单: {event.event_id}")


# ── 创建应用 ──────────────────────────────────────────────

metrics = InMemoryMetricsCollector()
tracer = LoggingTracer()
bus = EventBus(metrics=metrics, tracer=tracer)

app = FastAPI(title="EventBus Basic Example", lifespan=create_lifespan(bus))
app.add_middleware(EventBusMiddleware)


# ── 路由 ──────────────────────────────────────────────────


@app.post("/users")
async def create_user(bus: EventBus = Depends(get_event_bus)):
    event = UserCreated(user_id=1, username="alice")
    await bus.publish(event)
    return {"user_id": 1, "correlation_id": get_correlation_id()}


@app.post("/orders")
async def place_order(bus: EventBus = Depends(get_event_bus)):
    event = OrderPlaced(order_id=42, amount=99.9)
    await bus.publish(event)
    return {"order_id": 42}


@app.get("/metrics")
async def show_metrics():
    return metrics.snapshot()


@app.get("/traces")
async def show_traces():
    return [s.to_dict() for s in tracer.spans[-20:]]


@app.get("/health")
async def health(bus: EventBus = Depends(get_event_bus)):
    results = await bus.health.check()
    return [{"backend": r.backend, "status": r.status.value} for r in results]
