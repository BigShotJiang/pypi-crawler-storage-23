# 基础用法示例

使用内存后端，展示核心功能。

## 运行

```bash
cd examples/basic_usage
pip install fastapi-eventbus uvicorn
uvicorn main:app --reload
```

## 测试

```bash
# 创建用户
curl -X POST http://localhost:8000/users

# 下单
curl -X POST http://localhost:8000/orders

# 查看 metrics
curl http://localhost:8000/metrics

# 查看 traces
curl http://localhost:8000/traces

# 健康检查
curl http://localhost:8000/health
```
