# Redis 后端示例

## 前置条件

```bash
# 启动 Redis
docker run -d --name redis -p 6379:6379 redis:7-alpine
```

## 运行

```bash
cd examples/with_redis
pip install fastapi-eventbus[redis] uvicorn

export EVENTBUS_BACKEND=redis
export EVENTBUS_REDIS_URL=redis://localhost:6379/0

uvicorn main:app --reload
```

## 测试

```bash
curl -X POST http://localhost:8000/publish
curl http://localhost:8000/health
```
