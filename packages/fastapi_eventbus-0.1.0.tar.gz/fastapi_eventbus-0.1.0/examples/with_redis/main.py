"""Redis 后端示例"""

from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI

from fastapi_eventbus import (
    BaseEvent,
    EventBus,
    EventBusMiddleware,
    eventbus_lifespan,
    get_event_bus,
    on_event,
)
from fastapi_eventbus.backends.redis import RedisBackend
from fastapi_eventbus.config import EventBusSettings


# ── 事件 ──────────────────────────────────────────────────


class PaymentReceived(BaseEvent):
    topic: str = "payment.received"
    payment_id: str
    amount: float


# ── 处理器 ────────────────────────────────────────────────


@on_event("payment.received")
async def process_payment(event: BaseEvent) -> None:
    print(f"[Redis] 处理支付: {event.event_id}")


# ── 应用 ──────────────────────────────────────────────────

settings = EventBusSettings()  # 从环境变量读取
backend = RedisBackend(url=settings.redis_url)
bus = EventBus(backend=backend, settings=settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """组合 lifespan 示例"""
    print("应用启动...")
    async with eventbus_lifespan(bus, app):
        yield
    print("应用关闭...")


app = FastAPI(title="EventBus Redis Example", lifespan=lifespan)
app.add_middleware(EventBusMiddleware)


@app.post("/publish")
async def publish(bus: EventBus = Depends(get_event_bus)):
    event = PaymentReceived(payment_id="pay_001", amount=100.0)
    await bus.publish(event)
    return {"status": "published", "event_id": event.event_id}


@app.get("/health")
async def health(bus: EventBus = Depends(get_event_bus)):
    results = await bus.health.check()
    return [{"backend": r.backend, "status": r.status.value, "detail": r.detail} for r in results]
