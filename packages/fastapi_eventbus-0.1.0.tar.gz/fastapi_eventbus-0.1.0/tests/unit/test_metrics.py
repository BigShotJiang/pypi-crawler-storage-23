"""Tests for metrics collection."""

import asyncio

from fastapi_eventbus.backends.sync import SyncBackend
from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.metrics.collector import InMemoryMetricsCollector


class TestMetrics:
    async def test_publish_increments_counter(self) -> None:
        metrics = InMemoryMetricsCollector()
        bus = EventBus(backend=SyncBackend(), metrics=metrics)
        await bus.start()

        event = BaseEvent(topic="test.metrics")
        await bus.publish(event)

        assert metrics.published["test.metrics"] == 1
        assert len(metrics.publish_durations["test.metrics"]) == 1
        await bus.stop()

    async def test_dispatch_increments_counter(self) -> None:
        metrics = InMemoryMetricsCollector()
        bus = EventBus(backend=SyncBackend(), metrics=metrics)

        received: list[str] = []

        async def handler(event: BaseEvent) -> None:
            received.append(event.event_id)

        await bus.registry.register("test.dispatch", handler)
        await bus.start()

        event = BaseEvent(topic="test.dispatch")
        await bus.publish(event)
        await asyncio.sleep(0.1)

        assert metrics.dispatched["test.dispatch"] == 1
        assert len(metrics.dispatch_durations["test.dispatch"]) == 1
        await bus.stop()

    async def test_dispatch_error_increments_error_counter(self) -> None:
        metrics = InMemoryMetricsCollector()
        from fastapi_eventbus.retry.strategies import RetryPolicy
        bus = EventBus(
            backend=SyncBackend(),
            metrics=metrics,
            retry_policy=RetryPolicy(max_retries=0, delay=0),
        )

        async def bad_handler(event: BaseEvent) -> None:
            raise ValueError("boom")

        await bus.registry.register("test.error", bad_handler)
        await bus.start()

        event = BaseEvent(topic="test.error")
        await bus.publish(event)
        await asyncio.sleep(0.1)

        assert metrics.dispatch_errors["test.error"] >= 1
        assert metrics.dlq_count["test.error"] == 1
        await bus.stop()

    def test_snapshot_and_reset(self) -> None:
        metrics = InMemoryMetricsCollector()
        metrics.inc_published("a")
        metrics.inc_published("a")
        metrics.inc_dispatched("b")

        snap = metrics.snapshot()
        assert snap["published"] == {"a": 2}
        assert snap["dispatched"] == {"b": 1}

        metrics.reset()
        assert metrics.snapshot() == {
            "published": {},
            "dispatched": {},
            "dispatch_errors": {},
            "retries": {},
            "dlq_count": {},
        }
