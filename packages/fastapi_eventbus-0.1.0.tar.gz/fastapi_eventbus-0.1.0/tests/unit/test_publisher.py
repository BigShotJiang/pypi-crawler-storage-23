"""Tests for EventBus publish/dispatch flow."""

import pytest

from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.registry.handler_registry import HandlerRegistry


class TestEventBusPublish:
    async def test_publish_and_dispatch(self, event_bus: EventBus) -> None:
        received: list[BaseEvent] = []

        async def handler(event: BaseEvent) -> None:
            received.append(event)

        await event_bus.registry.register("test.topic", handler)
        await event_bus.start()

        event = BaseEvent(topic="test.topic")
        await event_bus.publish(event)

        # Give the listener loop a moment to process
        import asyncio
        await asyncio.sleep(0.1)

        assert len(received) == 1
        assert received[0].event_id == event.event_id
        await event_bus.stop()


class TestHandlerRegistry:
    async def test_register_and_dispatch(self, registry: HandlerRegistry) -> None:
        results: list[str] = []

        async def handler(event: BaseEvent) -> None:
            results.append(event.event_id)

        await registry.register("topic.a", handler)
        event = BaseEvent(topic="topic.a")
        errors = await registry.dispatch(event)

        assert errors == []
        assert results == [event.event_id]

    async def test_dispatch_no_handlers(self, registry: HandlerRegistry) -> None:
        event = BaseEvent(topic="no.handlers")
        errors = await registry.dispatch(event)
        assert errors == []

    async def test_handler_error_captured(self, registry: HandlerRegistry) -> None:
        async def bad_handler(event: BaseEvent) -> None:
            raise ValueError("boom")

        await registry.register("topic.b", bad_handler)
        errors = await registry.dispatch(BaseEvent(topic="topic.b"))
        assert len(errors) == 1
