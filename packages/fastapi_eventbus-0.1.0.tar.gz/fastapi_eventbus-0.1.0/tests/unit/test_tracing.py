"""Tests for tracing."""

import asyncio

from fastapi_eventbus.backends.sync import SyncBackend
from fastapi_eventbus.core.event import BaseEvent
from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.tracing.tracer import LoggingTracer, SpanStatus


class TestTracing:
    async def test_publish_creates_span(self) -> None:
        tracer = LoggingTracer()
        bus = EventBus(backend=SyncBackend(), tracer=tracer)
        await bus.start()

        event = BaseEvent(topic="test.trace")
        await bus.publish(event)

        assert len(tracer.spans) == 1
        span = tracer.spans[0]
        assert span.operation == "publish"
        assert span.topic == "test.trace"
        assert span.event_id == event.event_id
        assert span.status == SpanStatus.OK
        assert span.duration > 0
        await bus.stop()

    async def test_dispatch_creates_span(self) -> None:
        tracer = LoggingTracer()
        bus = EventBus(backend=SyncBackend(), tracer=tracer)

        async def handler(event: BaseEvent) -> None:
            pass

        await bus.registry.register("test.trace2", handler)
        await bus.start()

        event = BaseEvent(topic="test.trace2")
        await bus.publish(event)
        await asyncio.sleep(0.1)

        # Should have publish span + dispatch span
        ops = [s.operation for s in tracer.spans]
        assert "publish" in ops
        assert "dispatch" in ops

        dispatch_span = next(s for s in tracer.spans if s.operation == "dispatch")
        assert dispatch_span.status == SpanStatus.OK
        await bus.stop()

    async def test_error_span_status(self) -> None:
        tracer = LoggingTracer()
        from fastapi_eventbus.retry.strategies import RetryPolicy
        bus = EventBus(
            backend=SyncBackend(),
            tracer=tracer,
            retry_policy=RetryPolicy(max_retries=0, delay=0),
        )

        async def bad_handler(event: BaseEvent) -> None:
            raise RuntimeError("fail")

        await bus.registry.register("test.err", bad_handler)
        await bus.start()

        await bus.publish(BaseEvent(topic="test.err"))
        await asyncio.sleep(0.1)

        dispatch_span = next(s for s in tracer.spans if s.operation == "dispatch")
        assert dispatch_span.status == SpanStatus.ERROR
        assert "fail" in dispatch_span.error_message
        await bus.stop()

    def test_span_to_dict(self) -> None:
        tracer = LoggingTracer()
        span = tracer.start_span("test_op", topic="t", event_id="e123")
        span.finish()
        tracer.finish_span(span)

        d = span.to_dict()
        assert d["operation"] == "test_op"
        assert d["topic"] == "t"
        assert d["event_id"] == "e123"
        assert d["status"] == "ok"
        assert isinstance(d["duration_ms"], float)
