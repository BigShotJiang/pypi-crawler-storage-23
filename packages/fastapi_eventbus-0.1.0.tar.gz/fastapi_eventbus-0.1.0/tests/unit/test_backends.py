"""Tests for SyncBackend."""

import pytest

from fastapi_eventbus.backends.sync import SyncBackend
from fastapi_eventbus.core.event import BaseEvent


class TestSyncBackend:
    @pytest.fixture(autouse=True)
    def setup(self, sync_backend: SyncBackend) -> None:
        self.backend = sync_backend

    async def test_connect_disconnect(self) -> None:
        await self.backend.connect()
        assert await self.backend.health_check() is True
        await self.backend.disconnect()
        assert await self.backend.health_check() is False

    async def test_publish_subscribe(self) -> None:
        await self.backend.connect()
        await self.backend.subscribe("test.topic")

        event = BaseEvent(topic="test.topic")
        await self.backend.publish(event)

        received: list[BaseEvent] = []
        async for e in self.backend.listen():
            received.append(e)
            break  # just get one

        assert len(received) == 1
        assert received[0].event_id == event.event_id
        await self.backend.disconnect()

    async def test_unsubscribed_topic_not_queued(self) -> None:
        await self.backend.connect()
        event = BaseEvent(topic="unsubscribed")
        await self.backend.publish(event)
        # Queue should be empty since we never subscribed
        assert self.backend._queues.get("unsubscribed") is None or \
            self.backend._queues["unsubscribed"].empty()
        await self.backend.disconnect()
