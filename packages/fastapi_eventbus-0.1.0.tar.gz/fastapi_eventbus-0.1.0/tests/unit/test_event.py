"""Tests for BaseEvent model."""

from fastapi_eventbus.core.event import BaseEvent


class TestBaseEvent:
    def test_default_fields(self) -> None:
        event = BaseEvent()
        assert event.topic == "default"
        assert event.event_id
        assert event.timestamp
        assert event.metadata == {}

    def test_custom_event(self) -> None:
        class OrderPlaced(BaseEvent):
            topic: str = "order.placed"
            order_id: int = 0

        event = OrderPlaced(order_id=42)
        assert event.topic == "order.placed"
        assert event.order_id == 42

    def test_serialization_roundtrip(self) -> None:
        event = BaseEvent(topic="test.topic")
        data = event.to_dict()
        restored = BaseEvent.from_dict(data)
        assert restored.event_id == event.event_id
        assert restored.topic == event.topic

    def test_frozen(self) -> None:
        event = BaseEvent()
        try:
            event.topic = "changed"  # type: ignore[misc]
            assert False, "Should have raised"
        except Exception:
            pass
