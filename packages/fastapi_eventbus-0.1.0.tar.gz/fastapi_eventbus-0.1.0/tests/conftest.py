"""Shared test fixtures."""

import pytest

from fastapi_eventbus.backends.sync import SyncBackend
from fastapi_eventbus.ext.app import EventBus
from fastapi_eventbus.registry.handler_registry import HandlerRegistry


@pytest.fixture
def sync_backend() -> SyncBackend:
    return SyncBackend()


@pytest.fixture
def registry() -> HandlerRegistry:
    return HandlerRegistry()


@pytest.fixture
def event_bus(sync_backend: SyncBackend) -> EventBus:
    return EventBus(backend=sync_backend)
