# Changelog

## 0.1.0 (2025-02-27)

### Added
- Core abstractions: `BaseEvent`, `EventPublisher`, `EventSubscriber`, `EventHandler`
- Pluggable backends: `SyncBackend`, `RedisBackend`, `KafkaBackend`
- `EventBus` application extension with FastAPI lifespan integration
- `@on_event` decorator for handler registration
- `HandlerRegistry` with async dispatch
- `RetryPolicy` with exponential backoff
- `DeadLetterQueue` for failed events
- `EventBusMiddleware` with correlation ID tracking
- `HealthChecker` for backend health monitoring
- FastAPI dependency injection via `get_event_bus`
- Pydantic Settings configuration with `EVENTBUS_` env prefix
- PEP 561 type marker
- Kafka `RebalanceListener` for safe consumer group rebalance handling
- Manual offset commit after successful message processing
- Kafka consumer auto-reconnect with backoff on errors
- Kafka batch publish via `publish_many()`
- `MetricsCollector` protocol with `NoopMetricsCollector` and `InMemoryMetricsCollector`
- Automatic metrics for publish/dispatch/error/retry/DLQ counters and durations
- `EventTracer` protocol with `NoopTracer` and `LoggingTracer`
- Automatic span creation for publish and dispatch operations
- Correlation ID integration between middleware and tracing
- Full documentation: quickstart, backends guide, observability guide, API reference
- Example apps: basic usage, Redis backend, Kafka backend
