# 快速开始

## 安装

```bash
pip install fastapi-eventbus
```

## 最小示例

```python
from fastapi import FastAPI, Depends
from fastapi_eventbus import (
    BaseEvent, EventBus, create_lifespan, get_event_bus, on_event,
)


# 定义事件
class OrderPlaced(BaseEvent):
    topic: str = "order.placed"
    order_id: int
    amount: float


# 注册处理器
@on_event("order.placed")
async def notify_warehouse(event: BaseEvent) -> None:
    print(f"通知仓库发货: 订单 {event.event_id}")


@on_event("order.placed")
async def send_confirmation(event: BaseEvent) -> None:
    print(f"发送确认邮件: 订单 {event.event_id}")


# 创建应用
bus = EventBus()
app = FastAPI(lifespan=create_lifespan(bus))


@app.post("/orders")
async def place_order(bus: EventBus = Depends(get_event_bus)):
    event = OrderPlaced(order_id=42, amount=99.9)
    await bus.publish(event)
    return {"order_id": 42, "status": "placed"}
```

## 运行

```bash
uvicorn main:app --reload
```

```bash
curl -X POST http://localhost:8000/orders
```

控制台输出：
```
通知仓库发货: 订单 abc123...
发送确认邮件: 订单 abc123...
```

## 工作原理

1. `EventBus` 在应用启动时连接后端、注册所有 `@on_event` 处理器、启动后台监听
2. `publish()` 将事件发送到后端
3. 后台监听循环从后端接收事件，分发给所有匹配 topic 的处理器
4. 处理失败时自动重试，重试耗尽后进入死信队列
5. 应用关闭时自动断开后端连接

## 下一步

- [后端指南](backends.md) — 切换到 Redis 或 Kafka
- [可观测性](observability.md) — 添加 Metrics 和 Tracing
