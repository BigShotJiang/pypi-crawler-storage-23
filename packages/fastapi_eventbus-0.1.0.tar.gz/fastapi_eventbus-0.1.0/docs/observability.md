# Metrics 与 Tracing

fastapi-eventbus 内置可插拔的可观测性支持，默认零开销。

## Metrics

### 概念

Metrics 采集通过 `MetricsCollector` 协议实现。EventBus 在以下时机自动调用：

| 时机 | 方法 | 说明 |
|---|---|---|
| 事件发布成功 | `inc_published(topic)` | 按 topic 计数 |
| 事件分发成功 | `inc_dispatched(topic)` | 所有 handler 成功 |
| Handler 执行失败 | `inc_dispatch_error(topic)` | 每个失败的 handler 计一次 |
| 触发重试 | `inc_retry(topic, attempt)` | 含重试序号 |
| 进入死信队列 | `inc_dlq(topic)` | 重试耗尽 |
| 发布耗时 | `observe_publish_duration(topic, seconds)` | 浮点秒数 |
| 分发耗时 | `observe_dispatch_duration(topic, seconds)` | 含重试时间 |

### 内置实现

**NoopMetricsCollector**（默认）：什么都不做，零开销。

**InMemoryMetricsCollector**：内存存储，适合测试和调试。

```python
from fastapi_eventbus import EventBus, InMemoryMetricsCollector

metrics = InMemoryMetricsCollector()
bus = EventBus(metrics=metrics)

# ... 使用后 ...

# 查看快照
print(metrics.snapshot())

# 查看发布耗时分布
print(metrics.publish_durations["user.created"])

# 重置
metrics.reset()
```

### 对接 Prometheus

```python
from prometheus_client import Counter, Histogram

class PrometheusCollector:
    def __init__(self):
        self._published = Counter(
            "eventbus_events_published_total",
            "Total events published",
            ["topic"],
        )
        self._dispatched = Counter(
            "eventbus_events_dispatched_total",
            "Total events dispatched",
            ["topic"],
        )
        self._errors = Counter(
            "eventbus_dispatch_errors_total",
            "Total dispatch errors",
            ["topic"],
        )
        self._retries = Counter(
            "eventbus_retries_total",
            "Total retry attempts",
            ["topic"],
        )
        self._dlq = Counter(
            "eventbus_dlq_total",
            "Total events sent to DLQ",
            ["topic"],
        )
        self._pub_duration = Histogram(
            "eventbus_publish_duration_seconds",
            "Event publish duration",
            ["topic"],
        )
        self._disp_duration = Histogram(
            "eventbus_dispatch_duration_seconds",
            "Event dispatch duration",
            ["topic"],
        )

    def inc_published(self, topic: str) -> None:
        self._published.labels(topic=topic).inc()

    def inc_dispatched(self, topic: str) -> None:
        self._dispatched.labels(topic=topic).inc()

    def inc_dispatch_error(self, topic: str) -> None:
        self._errors.labels(topic=topic).inc()

    def inc_retry(self, topic: str, attempt: int) -> None:
        self._retries.labels(topic=topic).inc()

    def inc_dlq(self, topic: str) -> None:
        self._dlq.labels(topic=topic).inc()

    def observe_publish_duration(self, topic: str, duration: float) -> None:
        self._pub_duration.labels(topic=topic).observe(duration)

    def observe_dispatch_duration(self, topic: str, duration: float) -> None:
        self._disp_duration.labels(topic=topic).observe(duration)
```

## Tracing

### 概念

Tracing 通过 `EventTracer` 协议实现。EventBus 自动为每次 `publish` 和 `dispatch` 创建 span：

- `publish` span：从调用 `publish()` 到后端确认
- `dispatch` span：从收到事件到所有 handler 完成（含重试）

每个 span 包含：
- `span_id`：唯一标识
- `trace_id`：自动关联中间件的 Correlation ID
- `operation`：`publish` 或 `dispatch`
- `topic`：事件 topic
- `event_id`：事件 ID
- `status`：`ok` 或 `error`
- `duration`：耗时
- `error_message`：错误信息（如有）

### 内置实现

**NoopTracer**（默认）：什么都不做。

**LoggingTracer**：输出 span 日志，适合开发调试。

```python
from fastapi_eventbus import EventBus, LoggingTracer

tracer = LoggingTracer()
bus = EventBus(tracer=tracer)

# 日志输出示例：
# DEBUG SPAN START publish [a1b2c3d4] topic=user.created event=xxx
# DEBUG SPAN END publish [a1b2c3d4] status=ok duration=1.23ms

# 编程访问
for span in tracer.spans:
    print(span.to_dict())
```

### 对接 OpenTelemetry

```python
from opentelemetry import trace
from fastapi_eventbus import EventSpan

otel_tracer = trace.get_tracer("fastapi-eventbus")

class OTelTracer:
    def __init__(self):
        self._spans: dict[str, trace.Span] = {}

    def start_span(self, operation, topic="", event_id="", parent_span=None):
        otel_span = otel_tracer.start_span(
            f"eventbus.{operation}",
            attributes={
                "eventbus.topic": topic,
                "eventbus.event_id": event_id,
            },
        )
        span = EventSpan(operation=operation, topic=topic, event_id=event_id)
        self._spans[span.span_id] = otel_span
        return span

    def finish_span(self, span):
        otel_span = self._spans.pop(span.span_id, None)
        if otel_span:
            if span.status.value == "error":
                otel_span.set_status(
                    trace.StatusCode.ERROR, span.error_message
                )
            otel_span.end()
```

### Correlation ID 集成

`EventBusMiddleware` 为每个 HTTP 请求生成 Correlation ID。
`LoggingTracer` 自动将其作为 span 的 `trace_id`，实现请求级追踪链路：

```
HTTP Request (cid=abc123)
  └─ publish span (trace_id=abc123)
  └─ dispatch span (trace_id=abc123)
       └─ handler execution
```

## 同时使用 Metrics + Tracing

```python
from fastapi_eventbus import EventBus, InMemoryMetricsCollector, LoggingTracer

bus = EventBus(
    metrics=InMemoryMetricsCollector(),
    tracer=LoggingTracer(),
)
```

两者完全独立，可以任意组合。
