# 后端指南

fastapi-eventbus 支持三种后端，通过配置或代码切换。

## 内存同步后端（SyncBackend）

默认后端，零外部依赖，基于 `asyncio.Queue` 实现。

适用场景：
- 本地开发
- 单元测试
- 单进程应用

```python
from fastapi_eventbus import EventBus

bus = EventBus()  # 默认 backend="sync"
```

特点：
- 事件仅在当前进程内传递
- 无持久化，进程重启后事件丢失
- 零网络开销

## Redis 后端（RedisBackend）

基于 Redis Pub/Sub，适合多进程/多实例部署。

```bash
pip install fastapi-eventbus[redis]
```

### 环境变量配置

```bash
export EVENTBUS_BACKEND=redis
export EVENTBUS_REDIS_URL=redis://localhost:6379/0
export EVENTBUS_REDIS_MAX_CONNECTIONS=10
```

### 代码配置

```python
from fastapi_eventbus.backends.redis import RedisBackend
from fastapi_eventbus import EventBus

backend = RedisBackend(url="redis://my-redis:6379/0")
bus = EventBus(backend=backend)
```

特点：
- 基于 `redis.asyncio`，全异步
- 支持 hiredis 加速（自动安装）
- 多实例广播：所有订阅者都会收到事件
- 健康检查通过 `PING` 命令

注意事项：
- Redis Pub/Sub 是 fire-and-forget，离线期间的消息会丢失
- 如需持久化，考虑 Redis Streams（未来版本支持）

## Kafka 后端（KafkaBackend）

基于 aiokafka，适合高吞吐、持久化场景。

```bash
pip install fastapi-eventbus[kafka]
```

### 环境变量配置

```bash
export EVENTBUS_BACKEND=kafka
export EVENTBUS_KAFKA_BOOTSTRAP_SERVERS=localhost:9092
export EVENTBUS_KAFKA_GROUP_ID=my-service
```

### 代码配置

```python
from fastapi_eventbus.backends.kafka import KafkaBackend
from fastapi_eventbus import EventBus

backend = KafkaBackend(
    bootstrap_servers="broker1:9092,broker2:9092",
    group_id="order-service",
    auto_offset_reset="earliest",
    session_timeout_ms=30000,
    heartbeat_interval_ms=10000,
    max_poll_interval_ms=300000,
    enable_auto_commit=False,
)
bus = EventBus(backend=backend)
```

### Rebalance 处理

Kafka consumer group 在以下情况会触发 rebalance：
- 新 consumer 加入 group
- 现有 consumer 离开或崩溃
- Topic 的 partition 数量变化

fastapi-eventbus 的 Kafka 后端内置了 `RebalanceListener`：

1. **Revoke 阶段**：暂停事件处理，等待当前消息处理完成
2. **Assign 阶段**：恢复事件处理，开始消费新分配的 partition

这保证了 rebalance 期间不会出现重复处理或消息丢失。

### Offset 提交策略

默认关闭 auto commit（`enable_auto_commit=False`），采用手动提交：

- 每条消息处理成功后立即提交该 partition 的 offset
- 保证 at-least-once 语义
- 处理失败的消息不会被跳过

如果你的场景可以容忍少量重复，可以开启 auto commit：

```python
backend = KafkaBackend(enable_auto_commit=True)
```

### 异常恢复

Consumer 遇到异常时会自动重连：
- 等待 5 秒后重新开始消费
- 不会导致整个应用崩溃
- 重连期间的消息不会丢失（Kafka 会保留）

### 批量发布

```python
events = [OrderPlaced(order_id=i, amount=10.0) for i in range(100)]
await bus.publish_many(events)  # 使用 batch send + flush
```

## 自定义后端

实现 `Backend` 抽象基类即可：

```python
from fastapi_eventbus.backends.base import Backend
from fastapi_eventbus.core.event import BaseEvent
from collections.abc import AsyncIterator

class MyBackend(Backend):
    @property
    def name(self) -> str:
        return "my-backend"

    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def publish(self, event: BaseEvent) -> None: ...
    async def subscribe(self, topic: str) -> None: ...
    async def unsubscribe(self, topic: str) -> None: ...
    async def listen(self) -> AsyncIterator[BaseEvent]: ...
    async def health_check(self) -> bool: ...

bus = EventBus(backend=MyBackend())
```
