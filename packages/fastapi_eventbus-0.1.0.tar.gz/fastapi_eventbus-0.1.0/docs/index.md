# fastapi-eventbus 文档

欢迎使用 fastapi-eventbus —— 一个为 FastAPI 设计的高可用事件驱动 pub/sub 扩展库。

## 概述

fastapi-eventbus 让你在 FastAPI 应用中轻松实现事件驱动架构：

- 定义事件模型（基于 Pydantic）
- 用装饰器注册事件处理器
- 通过可插拔后端发布和订阅事件
- 自动重试失败的处理、死信队列兜底
- 内置 Metrics 和 Tracing 支持

## 文档目录

- [快速开始](quickstart.md) — 5 分钟上手
- [后端指南](backends.md) — Sync / Redis / Kafka 后端详解
- [Metrics 与 Tracing](observability.md) — 可观测性集成
- [API 参考](api/README.md) — 核心类和接口

## 系统要求

- Python >= 3.10
- FastAPI >= 0.100.0
- Pydantic >= 2.0
