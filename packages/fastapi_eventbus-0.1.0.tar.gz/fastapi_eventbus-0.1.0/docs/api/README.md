# API 参考

## 核心类

### `BaseEvent`

所有事件的基类，继承自 `pydantic.BaseModel`。

```python
class BaseEvent(BaseModel):
    event_id: str       # 自动生成的 UUID hex
    topic: str          # 事件 topic，默认 "default"
    timestamp: datetime  # 自动生成的 UTC 时间戳
    metadata: dict      # 自定义元数据

    def to_dict() -> dict          # 序列化
    def from_dict(data) -> BaseEvent  # 反序列化
```

### `EventBus`

中央事件总线，管理后端、注册表、重试、DLQ、Metrics、Tracing。

```python
class EventBus:
    def __init__(
        backend: Backend | None = None,
        settings: EventBusSettings | None = None,
        retry_policy: RetryPolicy | None = None,
        metrics: MetricsCollector | None = None,
        tracer: EventTracer | None = None,
    )

    async def start() -> None          # 连接后端，启动监听
    async def stop() -> None           # 停止监听，断开后端
    async def publish(event) -> None   # 发布事件
    async def publish_many(events) -> None  # 批量发布
    async def subscribe(topic) -> None # 动态订阅

    # 属性
    backend: Backend
    registry: HandlerRegistry
    retry_policy: RetryPolicy
    dlq: DeadLetterQueue
    health: HealthChecker
    metrics: MetricsCollector
    tracer: EventTracer
    settings: EventBusSettings
```

### `HandlerRegistry`

Handler 注册表。

```python
class HandlerRegistry:
    async def register(topic, handler) -> None
    async def unregister(topic, handler) -> None
    async def dispatch(event) -> list[Exception]
    def get_handlers(topic) -> list[EventHandler]
    def topics -> list[str]
    def clear() -> None
```

## 装饰器

### `@on_event(topic)`

注册函数为事件处理器。支持 async 和 sync 函数。

```python
@on_event("user.created")
async def handler(event: BaseEvent) -> None: ...
```

## 依赖注入

### `get_event_bus(request) -> EventBus`

FastAPI 依赖，从 `app.state` 获取 EventBus 实例。

```python
@app.post("/")
async def endpoint(bus: EventBus = Depends(get_event_bus)): ...
```

## 生命周期

### `create_lifespan(bus) -> lifespan`

创建 FastAPI lifespan context manager。

### `eventbus_lifespan(bus, app)`

可组合的 async context manager，用于自定义 lifespan。

## 后端

### `Backend`（抽象基类）

```python
class Backend(ABC):
    async def connect() -> None
    async def disconnect() -> None
    async def publish(event) -> None
    async def publish_many(events) -> None
    async def subscribe(topic) -> None
    async def unsubscribe(topic) -> None
    def listen() -> AsyncIterator[BaseEvent]
    async def health_check() -> bool
    name: str  # property
```

### `SyncBackend` / `RedisBackend` / `KafkaBackend`

三个内置实现，详见 [后端指南](../backends.md)。

## 配置

### `EventBusSettings`

基于 Pydantic Settings，支持环境变量（前缀 `EVENTBUS_`）。

详见 README 配置表。

## 重试

### `RetryPolicy`

```python
@dataclass
class RetryPolicy:
    max_retries: int = 3
    delay: float = 1.0
    backoff_factor: float = 2.0
    max_delay: float = 60.0
    retryable_exceptions: tuple = (Exception,)

    def get_delay(attempt) -> float
    async def execute(coro_factory, *args, **kwargs)
```

### `DeadLetterQueue`

```python
class DeadLetterQueue:
    async def enqueue(failed: FailedEvent) -> None
    def peek(limit=10) -> list[FailedEvent]
    def size() -> int
    def clear() -> None
```

## Metrics

### `MetricsCollector`（Protocol）

```python
class MetricsCollector(Protocol):
    def inc_published(topic) -> None
    def inc_dispatched(topic) -> None
    def inc_dispatch_error(topic) -> None
    def inc_retry(topic, attempt) -> None
    def inc_dlq(topic) -> None
    def observe_dispatch_duration(topic, duration) -> None
    def observe_publish_duration(topic, duration) -> None
```

内置：`NoopMetricsCollector`、`InMemoryMetricsCollector`

## Tracing

### `EventTracer`（Protocol）

```python
class EventTracer(Protocol):
    def start_span(operation, topic, event_id, parent_span) -> EventSpan
    def finish_span(span) -> None
```

内置：`NoopTracer`、`LoggingTracer`

### `EventSpan`

```python
@dataclass
class EventSpan:
    span_id: str
    trace_id: str
    parent_span_id: str
    operation: str
    topic: str
    event_id: str
    status: SpanStatus  # ok | error
    duration: float     # property, seconds
    attributes: dict
    error_message: str
```

## 中间件

### `EventBusMiddleware`

请求级 Correlation ID 追踪。

### `get_correlation_id() -> str`

获取当前请求的 Correlation ID。

## 健康检查

### `HealthChecker`

```python
class HealthChecker:
    async def check() -> list[HealthResult]
    async def is_healthy() -> bool
```

### `HealthResult`

```python
@dataclass
class HealthResult:
    backend: str
    status: HealthStatus  # healthy | unhealthy | degraded
    detail: str
```
