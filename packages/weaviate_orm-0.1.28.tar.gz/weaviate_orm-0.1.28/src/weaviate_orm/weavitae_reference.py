from __future__ import annotations
from typing import Callable, Type, Optional, Union, List, TYPE_CHECKING, Any
from uuid import UUID

from weaviate.classes.config import DataType, Property as weaviateProperty, Tokenization, ReferenceProperty as weaviateReferenceProperty
from weaviate.collections import Collection
from weaviate.util import _WeaviateUUIDInt
if TYPE_CHECKING:
    from .weaviate_base import Base_Model


class Reference_Type:
    
    """
    Enum of the possible reference types.

    Attributes:
        SINGLE: A single reference.
        MULTIPLE: A list of references.
    """

    ONEWAY = "oneway"
    TWOWAY = "twoway"

    SINGLE = "single"
    LIST = "list"


class Reference:

    """
    Declares a reference field to another Weaviate class/collection.

    Attributes:
        target_collection (Base_Model): The target Weaviate collection.
        description (str): A human-readable description of the reference field.
        required (bool): Whether the reference field is required.
        auto_loading (bool): Whether to automatically load the referenced entity when accessed.
    """

    def __init__(
        self,
        target_collection_name: str,
        description: str = "",
        way_type: str = Reference_Type.ONEWAY,
        reference_type = Reference_Type.SINGLE,
        required: bool = False,
        auto_loading: bool = False,
        skip_validation: bool = False,
        inherited: bool = False
    ):
        """
        Initialize the reference field descriptor.

        Args:
            target_collection_name (str): Name of the target collection.
            description (str): A human-readable description of the reference field.
            way_type (str, optional): The way type of the reference. Defaults to Reference_Type.ONEWAY.
            reference_type (str, optional): The type of the reference. Defaults to Reference_Type.SINGLE. 
                Can be Reference_Type.SINGLE or Reference_Type.LIST.
            required (bool, optional): Whether the reference field is required. Defaults to False.
            auto_loading (bool, optional): Whether to automatically load the referenced entity when accessed. 
                Defaults to False. If false, the field will return the UUID of the referenced entity.
            skip_validation (bool, optional): Whether to skip validation of the reference field. Defaults to False.
            inherited (bool, optional): Whether the reference is inherited from a parent class. Defaults to False.
        """

        self.target_collection_name = target_collection_name

        self.description = description
        self.required = required
        self.auto_loading = auto_loading
        self.way_type = way_type
        self.reference_type = reference_type
        self.skip_validation = skip_validation
        self.inherited = inherited
        self.name: Optional[str] = None  # Assigned by __set_name__

    def __set_name__(self, owner, name):
        """
        Called automatically when the descriptor is assigned to a class attribute.
        """
        self.name = name
        self._owner = owner

    def __get__(self, instance, owner):

        """
        Access the value stored on the instance. If accessed from the class (instance is None)

        Args:
            instance: The instance of the class.
            owner: The class itself.

        Returns:
            Union[Base_Model, UUID]: The referenced entity or its UUID.

        Raises:
            ValueError: If the reference field is required but not set.
        """

        # Get handle_required_strict from the owner class, default to True if not set
        owner = getattr(self, "_owner", None)
        handle_required_strict = True
        if owner and hasattr(owner, "_handle_required_strict"):
            handle_required_strict = getattr(owner, "_handle_required_strict")

        # If accessed on the class itself, return the descriptor instance
        if instance is None:
            return self
        
        val = instance.__dict__.get(self.name)

        # If not set
        if val is None:
            if self.required and handle_required_strict:
                raise ValueError(f"Reference field '{self.name}' is required but not set.")
            return None
        
        # For polymorphic references, val is a tuple (uuid, type_name) or list of tuples
        # For monomorphic, val is uuid or list of uuids
        # Handle the value (auto-loading, list handling, etc.)
        value = self._handling_lists(instance, val)

        return value

    def __set__(self, instance, value):
        """
        Handle writing to the reference field with optional validation.
        For PolymorphicParent references, the parent entry will be created
        during save, not during assignment.

        Args:
            instance: The instance of the class.
            value: The value to set.

        Raises:
            ValueError: If the field is set with an invalid value.
        """

        value = self._handling_lists(instance, value)
        
        # Validate the value
        if not self._validate(value):
            raise ValueError(f"Invalid value ({value}) for reference field '{self.name}'")
        
        # Store the final value in the instance
        instance.__dict__[self.name] = value

    def _get_target_collection(self, owner) -> Collection:
        """
        Get the target collection from weaviate.

        Args:
            owner: The class that owns the reference field.

        Returns:
            Collection: The target collection.
        """

        collection = None

        with owner._engine.client as client:
            collection = client.collections.get(self.target_collection_name)

        return collection
    
    def _get_target_class(self, collection_name: Optional[str] = None) -> Type['Base_Model']:
        """
        Get the target class from the engine's model registry.
        Works for both polymorphic and monomorphic references.

        Args:
            collection_name (Optional[str]): Specific collection name to look up.
                If None, uses self.target_collection_name for monomorphic
                or self.target_collection_name for polymorphic.

        Returns:
            Type['Base_Model']: The target model class.

        Raises:
            ValueError: If the target class is not found in the engine.
        """

        owner = getattr(self, "_owner", None)
        if not owner or not hasattr(owner, "_engine"):
            raise ValueError("Cannot determine target class without engine.")

        target_name = collection_name or self.target_collection_name
        
        # Handle both dict-based _models (new) and list-based _models (legacy)
        models = owner._engine._models
        if isinstance(models, dict):
            collection_classes = models
        else:
            # Legacy: list of models
            collection_classes = {model.__name__: model for model in models}

        if target_name in collection_classes:
            return collection_classes[target_name]
        
        raise ValueError(f"Target class '{target_name}' not found in the engine. Do you have a model for it?")
    
    def _target_is_polymorphic_parent(self) -> bool:
        """
        Check if the reference target is a PolymorphicParent class.
        
        Returns:
            bool: True if target uses PolymorphicParent mixin, False otherwise.
        """
        try:
            target_class = self._get_target_class()
            return getattr(target_class, '_is_polymorphic_parent', False)
        except (ValueError, AttributeError):
            return False

    def _validate(self, value) -> bool:
        """
        Validate the value of the reference field. If not required, None is allowed.
        For polymorphic references, accepts any subclass instance or UUID.

        Args:
            value: The value to validate.

        Returns:
            bool: True if the value is valid, False otherwise

        Raises:
            ValueError: If the value is invalid.
        """

        if self.skip_validation:
            return True

        # None is okay if not required
        if value is None:
            if self.required:
                raise ValueError(f"Reference field '{self.name}' is required, but got None.")
            
            return True
        
        # For monomorphic references, use the exact target class
        target_class = self._get_target_class()
        
        # Check if target is a polymorphic parent - if so, accept parent OR any registered child
        acceptable_classes = [target_class]
        if self._target_is_polymorphic_parent():
            # For polymorphic parents, also accept child classes
            polymorphic_children = getattr(target_class, '_polymorphic_children', [])
            owner = getattr(self, "_owner", None)
            if owner and hasattr(owner, "_engine"):
                for child_name in polymorphic_children:
                    try:
                        child_class = self._get_target_class(collection_name=child_name)
                        acceptable_classes.append(child_class)
                    except ValueError:
                        pass  # Child class not registered, skip

        # Otherwise, must be either a UUID or an acceptable class instance
        if self.reference_type == Reference_Type.SINGLE:
            if not (isinstance(value, UUID) or any(isinstance(value, cls) for cls in acceptable_classes)):
                return False
        elif self.reference_type == Reference_Type.LIST:
            if not isinstance(value, list):
                return False
            for v in value:
                if not (isinstance(v, UUID) or any(isinstance(v, cls) for cls in acceptable_classes)):
                    return False

        # If it's an instance, ensure it's valid (UUIDs are always considered valid)
        if isinstance(value, UUID):
            return True
        elif isinstance(value, list):
            return all(
                isinstance(v, UUID) or 
                (not hasattr(v, 'is_valid') or v.is_valid)
                for v in value
            )
        elif any(isinstance(value, cls) for cls in acceptable_classes):
            return not hasattr(value, 'is_valid') or value.is_valid
        
        return False
        
    def _get_weaviate_reference(self) -> weaviateReferenceProperty:

        """
        Get the Weaviate reference property configuration.

        Returns:
            weaviateReferenceProperty: The Weaviate reference property configuration.

        Raises:
            ValueError: If the reference field name is not set.
        """

        if self.name is None:
            raise ValueError("Reference field name is not set; cannot create Weaviate reference property from not assigned reference field")
        
        ref = weaviateReferenceProperty(
            name=self.name,
            description=self.description,
            target_collection=self.target_collection_name,
        )

        return ref

    def _handle_weaviate_uuid(self, input_value) -> Union[UUID, Any]:
        """
        Handle the Weaviate UUID type. Convert it to a UUID object.
        For polymorphic refs, input_value may be (object_or_uuid, type_name) tuple,
        in which case we extract and convert the first element if needed.

        Args:
            input_value: A value, possibly wrapped as (value, type_name) tuple.

        Returns:
            Union[UUID, Any]: The handled value (UUID or object), or None.
        """
        # If it's a tuple (object_or_uuid, type_name), extract the first element
        if isinstance(input_value, tuple) and len(input_value) == 2 and isinstance(input_value[1], str):
            actual_value = input_value[0]
        else:
            actual_value = input_value
        
        # Convert Weaviate UUID to standard UUID
        if isinstance(actual_value, _WeaviateUUIDInt):
            actual_value = UUID(str(actual_value.hex))
        
        return actual_value

    def _handle_auto_loading(self, input_value, target_class=None) -> Union[UUID, Any]:
        """
        Handle the auto_loading of the reference field.
        For polymorphic references, uses the type discriminator to load from the correct collection.
        For monomorphic references, loads from the configured target collection.

        Args:
            input_value: The value to handle. For polymorphic: (object_or_uuid, type_name) tuple. For monomorphic: UUID or object.
            target_class (Optional): The target class to load the reference from. 
                If not provided, will be looked up from the engine.

        Returns:
            Union[UUID, Any]: The handled value. Object instance if auto_loading or if value is already an object, otherwise the UUID.        
        """

        # Handle Weaviate UUID conversion and polymorphic wrapping
        # For polymorphic references: only treat as (object_or_uuid, type_name) tuple if second element is a string (type name)
        if isinstance(input_value, tuple) and len(input_value) == 2 and isinstance(input_value[1], str):
            # Polymorphic reference: (object_or_uuid, type_name)
            value, type_name = input_value
            
            # If it's already an object instance, return it directly
            if not isinstance(value, (UUID, _WeaviateUUIDInt)):
                return value
            
            # Convert Weaviate UUID if needed
            value = self._handle_weaviate_uuid(value)
            
            if self.auto_loading:
                # Get the concrete class using type_name from engine
                try:
                    concrete_class = self._get_target_class(collection_name=type_name)
                    loaded = concrete_class.get(value)
                    # If auto-loading fails (object not in database yet), return the UUID
                    return loaded if loaded is not None else value
                except ValueError:
                    raise ValueError(f"Type '{type_name}' not found in engine models. Cannot auto-load.")
            else:
                return value
        else:
            # Monomorphic reference: just UUID or object
            value = self._handle_weaviate_uuid(input_value)

            # If it's already an object instance, return it directly
            if not isinstance(value, (UUID, _WeaviateUUIDInt)):
                return value

            if self.auto_loading:
                # Get target_class if not provided
                if target_class is None:
                    target_class = self._get_target_class()
                
                loaded = target_class.get(value)
                # If auto-loading fails (object not in database yet), return the UUID
                return loaded if loaded is not None else value

            return value

    def _handling_lists(self, instance, input_value):
        """
        Handle the input value for the reference field. Processes both monomorphic (UUID) 
        and polymorphic ((uuid, type) tuples) values.
        
        Ensures correct reference type (SINGLE vs LIST), handles auto-loading, and 
        unwraps polymorphic values to return UUIDs when appropriate.

        Args:
            instance: The instance of the class.
            input_value: The value to handle (UUID, object, or tuple for polymorphic).

        Raises:
            ValueError: If the reference field is a single reference but multiple values are provided.
        """

        if isinstance(input_value, list) and self.reference_type == Reference_Type.SINGLE:
            if len(input_value) > 1:
                raise ValueError(f"Reference field '{self.name}' is a single reference but got multiple values: {input_value}")
            elif len(input_value) == 1 and input_value[0] is not None:
                value = input_value[0]
            elif len(input_value) == 1 and input_value[0] is None:
                value = None
            elif len(input_value) == 0:
                value = None
        else:
            value = input_value

        # Provide target_class for auto_loading
        target_class = None
        if self.auto_loading:
            target_class = self._get_target_class()

        if value == [] or value is None:
            value = None

        elif isinstance(value, list):
            # Handle the list of references
            for i, v in enumerate(value):
                # Handle UUID and auto_loading
                value[i] = self._handle_auto_loading(v, target_class=target_class)
        else:
            # Handle single reference
            value = self._handle_auto_loading(value, target_class=target_class)

        return value
    
