"""
Tests for dict-based shared strings support in SheetCell.

This test module verifies that SheetCell works with dict-based shared strings (Map equivalent).
"""

import pytest
from rowsncolumns_spreadsheet import SheetCell, CellInterface


class TestDictBasedSharedStrings:
    """Test SheetCell with dict-based shared strings (Map equivalent)."""

    def test_dict_shared_strings_with_string_index(self):
        """Test dict-based shared strings with string key."""
        shared_strings = {"0": "Hello", "1": "World"}
        cell = SheetCell(cell_data={"ss": "1"}, shared_strings=shared_strings)

        assert cell.shared_string_index == "1"
        assert cell.get_user_entered_value() == "World"
        assert cell.get_effective_value() == "World"
        assert cell.formatted_value == "World"

    def test_dict_shared_strings_with_int_index(self):
        """Test dict-based shared strings with int index (auto-converted to string)."""
        shared_strings = {"0": "Hello", "1": "World"}
        cell = SheetCell(cell_data={"ss": 1}, shared_strings=shared_strings)

        assert cell.shared_string_index == "1"
        assert cell.get_user_entered_value() == "World"
        assert cell.get_effective_value() == "World"

    def test_dict_shared_strings_preserves_reference(self):
        """Test that dict-based shared strings preserve ss reference in cell_data."""
        shared_strings = {"foo": "Bar"}
        cell = SheetCell(cell_data={"ss": "foo"}, shared_strings=shared_strings)

        cell_data = cell.get_cell_data()
        assert cell_data is not None
        assert cell_data.get("ss") == "foo"
        assert cell_data.get("ue") is None
        assert cell_data.get("ev") is None

    def test_dict_shared_strings_clears_on_change(self):
        """Test that changing value clears shared string reference."""
        shared_strings = {"0": "Hello"}
        cell = SheetCell(cell_data={"ss": "0"}, shared_strings=shared_strings)

        cell.set_user_entered_value("New text")
        cell_data = cell.get_cell_data()

        assert cell_data is not None
        assert cell_data.get("ss") is None
        assert cell_data.get("ue", {}).get("sv") == "New text"

    def test_dict_shared_strings_omits_formatted_value(self):
        """Test that formatted value is omitted when using dict-based shared strings."""
        shared_strings = {"key1": "Value"}
        cell = SheetCell(cell_data={"ss": "key1"}, shared_strings=shared_strings)
        cell.formatted_value = "should not serialize"

        cell_data = cell.get_cell_data()
        assert cell_data is not None
        assert cell_data.get("ss") == "key1"
        assert "fv" not in cell_data

    def test_dict_shared_strings_missing_key(self):
        """Test behavior when dict key doesn't exist."""
        shared_strings = {"0": "Hello"}
        cell = SheetCell(cell_data={"ss": "999"}, shared_strings=shared_strings)

        assert cell.get_user_entered_value() is None
        assert cell.get_effective_value() is None

    def test_numeric_string_keys_in_dict(self):
        """Test dict with numeric string keys."""
        shared_strings = {"0": "First", "10": "Second", "100": "Third"}
        cell = SheetCell(cell_data={"ss": "10"}, shared_strings=shared_strings)

        assert cell.get_effective_value() == "Second"

    def test_int_key_auto_converted_to_string(self):
        """Test that int keys are auto-converted to strings."""
        shared_strings = {"0": "First", "1": "Second"}
        cell = SheetCell(cell_data={"ss": 1}, shared_strings=shared_strings)

        # Index should be stored as string
        assert cell.shared_string_index == "1"
        assert cell.get_effective_value() == "Second"

    def test_float_index_converted_to_string(self):
        """Test that float index is converted to string."""
        shared_strings = {"0.0": "Hi"}
        cell = SheetCell(cell_data={"ss": 0.0}, shared_strings=shared_strings)

        assert cell.shared_string_index == "0.0"
        assert cell.get_effective_value() == "Hi"

    def test_empty_shared_strings(self):
        """Test behavior with empty shared strings dict."""
        cell = SheetCell(cell_data={"ss": "0"}, shared_strings={})
        assert cell.get_effective_value() is None

    def test_none_shared_strings(self):
        """Test behavior with None shared strings."""
        cell = SheetCell(cell_data={"ss": "0"}, shared_strings=None)
        assert cell.get_effective_value() is None

    def test_custom_string_keys(self):
        """Test dict with custom non-numeric string keys."""
        shared_strings = {"greeting": "Hello", "farewell": "Goodbye"}
        cell = SheetCell(cell_data={"ss": "greeting"}, shared_strings=shared_strings)

        assert cell.shared_string_index == "greeting"
        assert cell.get_effective_value() == "Hello"
