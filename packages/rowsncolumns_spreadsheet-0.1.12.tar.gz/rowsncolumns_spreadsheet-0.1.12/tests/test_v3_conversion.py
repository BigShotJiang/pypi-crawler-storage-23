"""Tests for V3 data structure conversion utilities."""

import pytest
from rowsncolumns_spreadsheet.yjs.v3_conversion import (
    create_cell_key_v3,
    parse_cell_key_v3,
    create_cell_data_v3,
    sheet_data_v2_to_v3,
)


class TestCreateCellKeyV3:
    """Tests for create_cell_key_v3 function."""

    def test_simple_cell(self):
        """Test creating key for cell A1."""
        assert create_cell_key_v3(1, 1, 1) == "1!A1"

    def test_different_sheet(self):
        """Test creating key with different sheet ID."""
        assert create_cell_key_v3(5, 1, 1) == "5!A1"

    def test_multi_digit_row(self):
        """Test creating key with multi-digit row."""
        assert create_cell_key_v3(1, 100, 1) == "1!A100"

    def test_multi_letter_column(self):
        """Test creating key with multi-letter column (AA)."""
        assert create_cell_key_v3(1, 1, 27) == "1!AA1"

    def test_column_z(self):
        """Test creating key for column Z."""
        assert create_cell_key_v3(1, 1, 26) == "1!Z1"

    def test_large_column(self):
        """Test creating key for large column numbers."""
        # AB = 28
        assert create_cell_key_v3(1, 1, 28) == "1!AB1"


class TestParseCellKeyV3:
    """Tests for parse_cell_key_v3 function."""

    def test_simple_cell(self):
        """Test parsing key for cell A1."""
        result = parse_cell_key_v3("1!A1")
        assert result == {
            "sheetId": 1,
            "address": "A1",
            "rowIndex": 1,
            "columnIndex": 1,
        }

    def test_different_sheet(self):
        """Test parsing key with different sheet ID."""
        result = parse_cell_key_v3("5!B2")
        assert result["sheetId"] == 5
        assert result["rowIndex"] == 2
        assert result["columnIndex"] == 2

    def test_multi_letter_column(self):
        """Test parsing key with multi-letter column."""
        result = parse_cell_key_v3("1!AA1")
        assert result["columnIndex"] == 27  # AA = 27

    def test_case_insensitive(self):
        """Test that parsing is case insensitive."""
        result = parse_cell_key_v3("1!aa1")
        assert result["address"] == "AA1"
        assert result["columnIndex"] == 27

    def test_invalid_key(self):
        """Test parsing invalid key."""
        assert parse_cell_key_v3("invalid") is None
        assert parse_cell_key_v3("1A1") is None
        assert parse_cell_key_v3("!A1") is None


class TestCreateCellDataV3:
    """Tests for create_cell_data_v3 function."""

    def test_creates_correct_structure(self):
        """Test that CellDataV3 structure is correct with flattened position."""
        value = {"ue": {"sv": "Hello"}}
        result = create_cell_data_v3(value, 1, 2, 3)
        assert result == {
            "value": {"ue": {"sv": "Hello"}},
            "sId": 1,
            "r": 2,
            "c": 3,
        }


class TestSheetDataV2ToV3:
    """Tests for sheet_data_v2_to_v3 function."""

    def test_empty_data(self):
        """Test converting empty sheet data."""
        result = sheet_data_v2_to_v3({})
        assert result == {}

    def test_single_cell(self):
        """Test converting single cell.

        V2 uses sparse arrays where index matches row/column number.
        """
        # Create sparse array with cell at index 1,1 (row 1, column 1 = A1)
        v2_data = {
            1: [None, {"values": [None, {"ue": {"sv": "Hello"}}]}]
        }
        result = sheet_data_v2_to_v3(v2_data)
        assert "1!A1" in result
        assert result["1!A1"]["value"] == {"ue": {"sv": "Hello"}}
        assert result["1!A1"]["sId"] == 1
        assert result["1!A1"]["r"] == 1
        assert result["1!A1"]["c"] == 1

    def test_sparse_data(self):
        """Test converting sparse data (cells with nulls in between).

        V2 uses sparse arrays where index matches row/column number.
        """
        # Create sparse array: row 1 has cell at column 3 (C1), row 3 has cell at column 1 (A3)
        v2_data = {
            1: [
                None,  # index 0 (unused)
                {"values": [None, None, None, {"ue": {"sv": "C1"}}]},  # row 1, column 3
                None,  # row 2 is empty
                {"values": [None, {"ue": {"sv": "A3"}}]},  # row 3, column 1
            ]
        }
        result = sheet_data_v2_to_v3(v2_data)
        # Should only have 2 cells
        assert len(result) == 2
        assert "1!C1" in result
        assert "1!A3" in result
        # Null cells should not be in the result
        assert "1!A1" not in result
        assert "1!B1" not in result

    def test_multiple_sheets(self):
        """Test converting data from multiple sheets.

        V2 uses sparse arrays where index matches row/column number.
        """
        v2_data = {
            1: [None, {"values": [None, {"ue": {"sv": "Sheet1"}}]}],
            2: [None, {"values": [None, {"ue": {"sv": "Sheet2"}}]}],
        }
        result = sheet_data_v2_to_v3(v2_data)
        assert "1!A1" in result
        assert "2!A1" in result
        assert result["1!A1"]["value"]["ue"]["sv"] == "Sheet1"
        assert result["2!A1"]["value"]["ue"]["sv"] == "Sheet2"
