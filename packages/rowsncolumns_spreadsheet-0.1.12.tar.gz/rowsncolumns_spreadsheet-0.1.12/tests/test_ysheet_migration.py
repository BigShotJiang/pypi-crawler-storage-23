"""
Tests for YSheet shared strings migration from array to map.
"""

import pytest
from pycrdt import Doc, Array, Map


class YSheet:
    """
    Collaborative spreadsheet with Y-CRDT integration.
    """

    def __init__(self, doc: Doc):
        self._doc = doc

    @property
    def doc(self) -> Doc:
        """Collaborative document."""
        return self._doc

    @property
    def shared_strings(self) -> dict[str, str]:
        """
        Shared strings as a dictionary with string keys.

        Handles migration from legacy array format to map format:
        - If sharedStringsMap exists and has data, return it
        - Otherwise, if sharedStrings array exists, convert to dict
        - Return empty dict if neither exists

        Note: doc.get("key", type=Map) creates an empty Map if key doesn't exist,
        so we check if the resulting dict has any entries.
        """
        # Try to get Map-based shared strings (new format)
        # Note: This creates an empty Map if it doesn't exist
        shared_strings_map = self._doc.get("sharedStringsMap", type=Map)

        # Convert to dict - empty Map becomes empty dict {}
        map_dict = dict(shared_strings_map)

        # Check if map has any data (empty dict is falsy in Python)
        if map_dict:
            return map_dict

        # Fall back to array-based shared strings (legacy format)
        shared_strings_array = self._doc.get("sharedStrings", type=Array)
        array_list = list(shared_strings_array)

        if array_list:
            # Convert array to dict with string keys for backward compatibility
            return {str(i): value for i, value in enumerate(array_list)}

        # Return empty dict if neither exists
        return {}


class TestYSheetMigration:
    """Test YSheet shared strings migration."""

    def test_returns_map_when_map_has_data(self):
        """Should return map data when sharedStringsMap exists."""
        doc = Doc()
        y_sheet = YSheet(doc)

        # Setup map-based shared strings
        shared_strings_map = doc.get("sharedStringsMap", type=Map)
        with doc.transaction():
            shared_strings_map["0"] = "Hello"
            shared_strings_map["1"] = "World"

        result = y_sheet.shared_strings

        assert result == {"0": "Hello", "1": "World"}
        assert isinstance(result, dict)
        assert all(isinstance(k, str) for k in result.keys())

    def test_migrates_array_to_dict_when_map_is_empty(self):
        """Should convert array to dict when map is empty."""
        doc = Doc()
        y_sheet = YSheet(doc)

        # Setup legacy array-based shared strings
        shared_strings_array = doc.get("sharedStrings", type=Array)
        with doc.transaction():
            shared_strings_array.extend(["Hello", "World", "Test"])

        result = y_sheet.shared_strings

        assert result == {"0": "Hello", "1": "World", "2": "Test"}
        assert isinstance(result, dict)
        assert all(isinstance(k, str) for k in result.keys())

    def test_returns_empty_dict_when_both_empty(self):
        """Should return empty dict when neither array nor map has data."""
        doc = Doc()
        y_sheet = YSheet(doc)

        result = y_sheet.shared_strings

        assert result == {}
        assert isinstance(result, dict)

    def test_prefers_map_over_array_when_both_exist(self):
        """Should use map data when both array and map exist."""
        doc = Doc()
        y_sheet = YSheet(doc)

        # Setup both array and map
        shared_strings_array = doc.get("sharedStrings", type=Array)
        shared_strings_map = doc.get("sharedStringsMap", type=Map)

        with doc.transaction():
            shared_strings_array.extend(["Old1", "Old2"])
            shared_strings_map["0"] = "New1"
            shared_strings_map["1"] = "New2"

        result = y_sheet.shared_strings

        # Should use map data, not array
        assert result == {"0": "New1", "1": "New2"}

    def test_handles_large_array_migration(self):
        """Should correctly migrate large arrays."""
        doc = Doc()
        y_sheet = YSheet(doc)

        # Create array with 100 entries
        shared_strings_array = doc.get("sharedStrings", type=Array)
        test_data = [f"String_{i}" for i in range(100)]

        with doc.transaction():
            shared_strings_array.extend(test_data)

        result = y_sheet.shared_strings

        assert len(result) == 100
        for i in range(100):
            assert result[str(i)] == f"String_{i}"

    def test_string_keys_are_strings_not_ints(self):
        """Should use string keys, not integer keys."""
        doc = Doc()
        y_sheet = YSheet(doc)

        shared_strings_array = doc.get("sharedStrings", type=Array)
        with doc.transaction():
            shared_strings_array.extend(["A", "B", "C"])

        result = y_sheet.shared_strings

        # Verify all keys are strings
        assert list(result.keys()) == ["0", "1", "2"]
        assert all(isinstance(k, str) for k in result.keys())

    def test_handles_custom_string_keys_in_map(self):
        """Should handle non-numeric string keys in map."""
        doc = Doc()
        y_sheet = YSheet(doc)

        shared_strings_map = doc.get("sharedStringsMap", type=Map)
        with doc.transaction():
            shared_strings_map["greeting"] = "Hello"
            shared_strings_map["farewell"] = "Goodbye"

        result = y_sheet.shared_strings

        assert result == {"greeting": "Hello", "farewell": "Goodbye"}

    def test_doc_get_creates_empty_map_if_not_exists(self):
        """Verify that doc.get creates empty Map when key doesn't exist."""
        doc = Doc()
        y_sheet = YSheet(doc)

        # Get shared strings when nothing exists in doc
        result = y_sheet.shared_strings

        # Should return empty dict, not None
        assert result == {}
        assert isinstance(result, dict)

        # Verify the Map was created in doc (pycrdt behavior)
        shared_strings_map = doc.get("sharedStringsMap", type=Map)
        assert isinstance(shared_strings_map, Map)
        assert len(dict(shared_strings_map)) == 0

    def test_empty_dict_is_falsy_in_python(self):
        """Verify Python's truthy/falsy behavior with empty dict."""
        doc = Doc()

        # Create empty map
        empty_map = doc.get("sharedStringsMap", type=Map)
        empty_dict = dict(empty_map)

        # Verify empty dict is falsy
        assert empty_dict == {}
        assert not empty_dict  # Empty dict is falsy
        assert bool(empty_dict) is False

        # Add data and verify it becomes truthy
        with doc.transaction():
            empty_map["0"] = "Value"

        non_empty_dict = dict(empty_map)
        assert non_empty_dict == {"0": "Value"}
        assert non_empty_dict  # Non-empty dict is truthy
        assert bool(non_empty_dict) is True

    def test_integration_with_sheet_cell(self):
        """Should work correctly with SheetCell."""
        from rowsncolumns_spreadsheet import SheetCell

        doc = Doc()
        y_sheet = YSheet(doc)

        # Setup shared strings in map
        shared_strings_map = doc.get("sharedStringsMap", type=Map)
        with doc.transaction():
            shared_strings_map["0"] = "Test Value"

        # Get shared strings from YSheet
        shared_strings = y_sheet.shared_strings

        # Use with SheetCell
        cell = SheetCell(
            cell_data={"ss": "0"},
            shared_strings=shared_strings
        )

        assert cell.get_effective_value() == "Test Value"
