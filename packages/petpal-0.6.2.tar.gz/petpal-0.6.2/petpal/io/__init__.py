from . import table
from . import image

def main():
    print("PETPAL - Load and Save Module")


if __name__ == "__main__":
    main()