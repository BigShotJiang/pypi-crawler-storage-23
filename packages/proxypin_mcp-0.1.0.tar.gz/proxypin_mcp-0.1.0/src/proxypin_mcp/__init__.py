"""ProxyPin MCP Server - Expose HTTP capture data to AI development tools."""

from .server import main, mcp

__version__ = "0.1.0"
__all__ = ["mcp", "main"]
