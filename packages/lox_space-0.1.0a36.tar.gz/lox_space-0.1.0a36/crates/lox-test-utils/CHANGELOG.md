# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0-alpha.4](https://github.com/lox-space/lox/compare/lox-test-utils-v0.1.0-alpha.3...lox-test-utils-v0.1.0-alpha.4) - 2026-03-02

### Other

- updated the following local packages: lox-derive

## [0.1.0-alpha.3](https://github.com/lox-space/lox/compare/lox-test-utils-v0.1.0-alpha.2...lox-test-utils-v0.1.0-alpha.3) - 2026-02-25

### Other

- update Cargo.toml dependencies

## [0.1.0-alpha.2](https://github.com/lox-space/lox/compare/lox-test-utils-v0.1.0-alpha.1...lox-test-utils-v0.1.0-alpha.2) - 2026-02-22

### Other

- *(lox-frames)* rewrite frame transforms

## [0.1.0-alpha.1](https://github.com/lox-space/lox/compare/lox-test-utils-v0.1.0-alpha.0...lox-test-utils-v0.1.0-alpha.1) - 2025-10-29

### Added

- *(lox-units)* add Keplerian elements
- *(lox-test-utils)* add ApproxEq derive macro
- *(lox-test-utils)* add ApproxEq trait

### Other

- add 3rd-party data licenses
- update SPDX headers and add helper script
- make Lox REUSE-compliant
- *(lox-test-util)* optimise and add docs
- get rid of float_eq and lox_math::is_close
