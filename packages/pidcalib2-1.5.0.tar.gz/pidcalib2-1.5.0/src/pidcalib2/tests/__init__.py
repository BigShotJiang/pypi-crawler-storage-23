"""A suite of pytest tests for the pidcalib2 package."""
