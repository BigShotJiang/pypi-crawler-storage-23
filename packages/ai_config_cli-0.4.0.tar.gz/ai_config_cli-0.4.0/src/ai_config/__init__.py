"""ai-config: Declarative plugin manager for AI coding tools."""

__version__ = "0.1.0"
