"""Adapters for different AI tool targets."""
