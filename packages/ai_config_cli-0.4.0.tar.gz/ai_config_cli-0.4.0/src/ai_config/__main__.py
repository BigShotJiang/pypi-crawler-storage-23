"""Entry point for python -m ai_config."""

from ai_config.cli import main

if __name__ == "__main__":
    main()
