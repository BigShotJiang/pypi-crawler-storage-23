# Changelog

## 0.1.0
- Initial release with pricing fetch, cache, normalization, API, and CLI.
