[^1][^1]

[^c9][^c9]

---

[^1]: Same footnote text
[^c9]: Shared comment
