"""Backward-compatible schema exports."""

from ..surfaces.web.schemas import *  # noqa: F401,F403
