"""Backward-compatible settings routes."""

from ..surfaces.web.routes.settings import *  # noqa: F401,F403
