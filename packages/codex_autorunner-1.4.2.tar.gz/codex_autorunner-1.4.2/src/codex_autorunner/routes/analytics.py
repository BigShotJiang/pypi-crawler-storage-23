"""Backward-compatible analytics routes."""

from ..surfaces.web.routes.analytics import *  # noqa: F401,F403
