"""Backward-compatible base routes."""

from ..surfaces.web.routes.base import *  # noqa: F401,F403
