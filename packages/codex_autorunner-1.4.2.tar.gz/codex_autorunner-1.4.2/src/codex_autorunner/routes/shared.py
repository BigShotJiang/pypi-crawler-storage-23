"""Backward-compatible shared route utilities."""

from ..surfaces.web.routes.shared import *  # noqa: F401,F403
