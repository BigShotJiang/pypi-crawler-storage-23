"""Tutorial project templates for educational game projects."""
