README_TEXT = "# {name}\n\nProject initialized by `sparkstart`."

NEW_TOKEN_URL = (
    "https://github.com/settings/tokens/new?description=sparkstart:{name}&scopes=repo,delete_repo,user"
)
