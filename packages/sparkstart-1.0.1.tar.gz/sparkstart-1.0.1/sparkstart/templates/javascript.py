import textwrap

GITIGNORE_JAVASCRIPT = textwrap.dedent("""
    node_modules/
    .DS_Store
    .projinit.env
""").strip()
