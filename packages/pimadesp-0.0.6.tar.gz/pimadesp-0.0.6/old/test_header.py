from playwright.sync_api import Page, expect


def test_header_menu_items_have_dropdown_icons(page: Page):
    """Test that header menu items with children have dropdown icons."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Find the header
    header = page.locator("app-header mat-toolbar")
    expect(header).to_be_visible()

    # Find all nav-link buttons (items with children/dropdowns)
    menu_buttons = header.locator("nav.nav-links button.nav-link")

    # Should have 2 menu items based on sitemap: Features and User interface
    expect(menu_buttons).to_have_count(2)

    # Each menu button should have a dropdown icon
    for i in range(menu_buttons.count()):
        button = menu_buttons.nth(i)
        dropdown_icon = button.locator("mat-icon.dropdown-icon")
        expect(dropdown_icon).to_be_visible()
        expect(dropdown_icon).to_have_text("arrow_drop_down")


def test_features_menu_opens_and_shows_children(page: Page):
    """Test that clicking Features opens a menu with Overview and children."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Find the Features button
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")
    expect(features_button).to_be_visible()

    # Click the Features button
    features_button.click()

    # Wait a bit for the menu animation
    page.wait_for_timeout(500)

    # Try different selectors for the menu
    # Angular Material menus render in a CDK overlay
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Get all menu items
    menu_items = menu.locator("a.menu-item")

    # Should have 3 items: Overview, Accessibility, Internationalization
    expect(menu_items).to_have_count(3)

    # Verify the menu items
    expect(menu_items.nth(0)).to_have_text("Overview")
    expect(menu_items.nth(1)).to_have_text("Accessibility")
    expect(menu_items.nth(2)).to_have_text("Internationalization")


def test_user_interface_menu_opens_and_shows_children(page: Page):
    """Test that clicking User interface opens a menu with all UI children."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Find the User interface button
    header = page.locator("app-header mat-toolbar")
    ui_button = header.locator("button.nav-link:has-text('User interface')")
    expect(ui_button).to_be_visible()

    # Click the User interface button
    ui_button.click()

    # Wait for the menu to appear
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Get all menu items
    menu_items = menu.locator("a.menu-item")

    # Should have 6 items: Overview + 5 children (Footer, Header, Navigation, Search, ToC)
    expect(menu_items).to_have_count(6)

    # Verify Overview is first
    expect(menu_items.nth(0)).to_have_text("Overview")


def test_menu_overview_navigates_to_parent_page(page: Page):
    """Test that clicking Overview in the menu navigates to the parent page."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Get initial URL
    initial_url = page.url

    # Open the Features menu
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")
    features_button.click()

    # Wait for the menu to appear
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Wait a moment for menu to be fully rendered
    page.wait_for_timeout(300)

    # Click on Overview - use force to bypass backdrop
    overview_link = menu.locator("a.menu-item:has-text('Overview')").first
    overview_link.click(force=True)

    # Wait for Angular to process the navigation
    page.wait_for_timeout(1500)

    # The URL should have changed and contain features
    final_url = page.url
    assert final_url != initial_url, f"URL should have changed from {initial_url} to include features"
    assert "features" in final_url, f"Expected URL to contain 'features', got: {final_url}"


def test_menu_child_item_navigates_to_child_page(page: Page):
    """Test that clicking a child item in the menu navigates to that page."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Open the Features menu
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")
    features_button.click()

    # Wait for the menu to appear
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Click on Accessibility - use force to bypass backdrop
    accessibility_link = menu.locator("a.menu-item:has-text('Accessibility')").first
    accessibility_link.click(force=True)

    # Should navigate to features/accessibility/index.html
    # Wait a bit for navigation
    page.wait_for_timeout(1000)

    # The URL should contain accessibility
    assert "accessibility" in page.url, f"Expected URL to contain 'accessibility', got: {page.url}"


def test_menu_closes_after_clicking_item(page: Page):
    """Test that the menu closes after clicking a menu item."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Open the Features menu
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")
    features_button.click()

    # Wait for the menu to appear
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Click on a menu item
    overview_link = menu.locator("a.menu-item:has-text('Overview')").first
    overview_link.click()

    # Wait a bit
    page.wait_for_timeout(300)

    # Menu should be hidden
    expect(menu).not_to_be_visible()


def test_menu_closes_when_clicking_outside(page: Page):
    """Test that the menu closes when clicking outside of it."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Open the Features menu
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")
    features_button.click()

    # Wait for the menu to appear
    menu = page.locator(".cdk-overlay-pane .mat-mdc-menu-panel")
    expect(menu).to_be_visible(timeout=2000)

    # Click the backdrop to close the menu
    backdrop = page.locator(".cdk-overlay-backdrop")
    backdrop.click()

    # Wait a bit
    page.wait_for_timeout(300)

    # Menu should be hidden
    expect(menu).not_to_be_visible()


def test_menu_button_has_proper_styling(page: Page):
    """Test that menu buttons have proper styling matching nav-links."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-header", timeout=5000)

    # Find a menu button
    header = page.locator("app-header mat-toolbar")
    features_button = header.locator("button.nav-link:has-text('Features')")

    # Check that it has the nav-link class (among others)
    class_attr = features_button.get_attribute("class")
    assert "nav-link" in class_attr, f"Expected 'nav-link' to be in class attribute, got: {class_attr}"

    # Check that it's visible and has text
    expect(features_button).to_be_visible()
    expect(features_button).to_contain_text("Features")
