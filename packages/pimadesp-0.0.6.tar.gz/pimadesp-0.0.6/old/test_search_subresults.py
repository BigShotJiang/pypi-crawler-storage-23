from playwright.sync_api import Page, expect


# def test_todo_search_subresults(page: Page):
#     """Test that searching for TODO generates subresults for each section."""
#     base_url = "http://0.0.0.0:8080"
# 
#     # Set up console log collection
#     console_logs = []
#     page.on("console", lambda msg: console_logs.append(f"{msg.type}: {msg.text}"))
# 
#     page.goto(f"{base_url}/")
# 
#     # Wait for the page and Angular app to load
#     page.wait_for_load_state("networkidle")
#     page.wait_for_selector("app-root app-header", timeout=10000)
# 
#     # Wait for pagefind to be ready
#     page.wait_for_function("() => window.pagefind !== undefined", timeout=10000)
# 
#     # Click the search button in the header
#     search_button = page.get_by_role("button", name="Search")
#     expect(search_button).to_be_visible(timeout=5000)
#     search_button.click()
# 
#     # Wait for search overlay to open
#     search_input = page.locator("app-search input[matInput]")
#     expect(search_input).to_be_visible(timeout=5000)
# 
#     # Search for 'TODO'
#     search_input.fill("TODO")
# 
#     # Wait a bit for debounced search to complete
#     page.wait_for_timeout(1000)
# 
#     # Get the search results - check different possible selectors
#     result_items = page.locator(".result-item, .sub-result-item").all()
# 
#     print(f"\n=== Search Results ===")
#     print(f"Number of result items: {len(result_items)}")
# 
#     # Check for result groups (pages with subresults)
#     result_groups = page.locator(".result-group").all()
#     print(f"Number of result groups: {len(result_groups)}")
# 
#     # Get all mat-list-items
#     list_items = page.locator("mat-list-item").all()
#     print(f"Number of mat-list-items: {len(list_items)}")
# 
#     # Print page structure
#     print(f"\n=== Search Container HTML ===")
#     search_view = page.locator(".search-view").first
#     if search_view.count() > 0:
#         html = search_view.inner_html()
#         # Print first 2000 chars
#         print(html[:2000])
# 
#     # Print relevant console logs
#     print(f"\n=== Console Logs ===")
#     for log in console_logs:
#         if 'Search' in log or 'sub_result' in log.lower() or 'Result' in log:
#             print(log)
# 
#     # Assertions
#     assert len(result_items) > 0 or len(list_items) > 0, "Expected at least one search result for TODO"
# 
#     # The "Search" page should appear with subresults if it has sections with "TODO"
#     print(f"\n=== Expected Behavior ===")
#     print("The search/index.html and search/configuration.html pages may contain search results.")
#     print("\nPagefind should show result groups with sub-results if applicable.")
