from playwright.sync_api import Page, expect


# def test_section_ids_preserved_after_angular_bootstrap(page: Page):
#     """Section IDs from static HTML should survive Angular's innerHTML rendering."""
#     page.goto("http://0.0.0.0:8080/contributors/page-toc.html")
#     # Wait for Angular to bootstrap and replace the static content
#     page.wait_for_selector("app-root mat-toolbar")
#     # The content has sections with IDs like "what-it-renders", "styling", etc.
#     # These IDs must be preserved so that hash links (#what-it-renders) work.
#     section = page.locator("section[id='what-it-renders']")
#     expect(section).to_have_count(1)
# 
# 
# def test_section_ids_preserved_after_spa_navigation(page: Page):
#     """Section IDs should be present after SPA-navigating to a new page."""
#     page.goto("http://0.0.0.0:8080/contributors/page-toc.html")
#     page.wait_for_selector("app-root mat-toolbar")
#     # SPA-navigate to a different page that also has sections
#     page.locator("a", has_text="Overview").first.click()
#     page.wait_for_url("**/contributors/overview.html")
#     # The new page's section IDs should be in the DOM
#     section = page.locator("section[id]")
#     expect(section.first).to_be_attached()
# 
# 
# def test_mobile_toc_section_navigation(page: Page):
#     """Clicking a section link from mobile ToC should scroll to that section."""
#     # Set mobile viewport
#     page.set_viewport_size({"width": 375, "height": 667})
#     page.goto("http://0.0.0.0:8080/contributors/page-toc.html")
#     page.wait_for_selector("app-root mat-toolbar")
# 
#     # On mobile, the ToC appears as a FAB button
#     toc_fab = page.locator("button[aria-label='Table of contents']")
#     expect(toc_fab).to_be_visible()
# 
#     # Click the FAB to open the mobile ToC modal
#     toc_fab.click()
# 
#     # Wait for the ToC modal to appear
#     page.wait_for_selector(".toc-view")
# 
#     # Click on a section link (e.g., "Styling")
#     page.locator(".toc-view a", has_text="Styling").click()
# 
#     # The modal should close
#     expect(page.locator(".toc-view")).not_to_be_visible()
# 
#     # The URL should update with the hash
#     page.wait_for_url("**/contributors/page-toc.html#styling")
# 
#     # The target section should be scrolled into view (we can check if it's in viewport)
#     styling_section = page.locator("section[id='styling']")
#     expect(styling_section).to_be_in_viewport()
