from playwright.sync_api import Page, expect


# def test_toc_component_on_index_desktop(page: Page):
#     """Test that the TOC component appears on the index page (desktop view)."""
#     page.goto("http://0.0.0.0:8080/")
# 
#     # Wait for Angular to bootstrap
#     page.wait_for_selector("app-root app-header", timeout=5000)
# 
#     # The TOC component should be visible in desktop view
#     toc = page.locator("app-toc nav.toc")
#     expect(toc).to_be_visible()
# 
#     # Should have the "On this page" heading
#     toc_heading = toc.locator("h3.toc-heading")
#     expect(toc_heading).to_have_text("On this page")
# 
#     # Should have a TOC list
#     toc_list = toc.locator("ul.toc-list")
#     expect(toc_list).to_be_visible()
# 
#     # Should have at least one section link (Home)
#     toc_links = toc_list.locator("li a")
#     expect(toc_links).to_have_count(1)
# 
# 
# def test_toc_component_on_index_mobile(page: Page):
#     """Test that the TOC FAB appears on the index page (mobile view)."""
#     # Set mobile viewport
#     page.set_viewport_size({"width": 375, "height": 667})
#     page.goto("http://0.0.0.0:8080/")
# 
#     # Wait for Angular to bootstrap
#     page.wait_for_selector("app-root app-header", timeout=5000)
# 
#     # The desktop TOC should not be visible
#     desktop_toc = page.locator("app-toc nav.toc")
#     expect(desktop_toc).not_to_be_visible()
# 
#     # The TOC FAB button should be visible
#     toc_fab = page.locator("app-toc button[aria-label='Table of contents']")
#     expect(toc_fab).to_be_visible()
# 
#     # Verify it has the correct icon
#     toc_icon = toc_fab.locator("mat-icon")
#     expect(toc_icon).to_have_text("toc")
# 
# 
# def test_toc_sections_on_search_page(page: Page):
#     """Test that the TOC displays correct sections on the search page."""
#     page.goto("http://0.0.0.0:8080/search/index.html")
# 
#     # Wait for Angular to bootstrap
#     page.wait_for_selector("app-root app-header", timeout=5000)
# 
#     # The TOC component should be visible
#     toc = page.locator("app-toc nav.toc")
#     expect(toc).to_be_visible()
# 
#     # Get all TOC links (including nested ones)
#     toc_links = toc.locator("ul.toc-list a")
# 
#     # Should have 5 sections: Providers (with nested Pagefind, Sphinx, Custom) and Analytics
#     expect(toc_links).to_have_count(5)
# 
#     # Verify the section titles
#     expect(toc_links.nth(0)).to_have_text("Providers")
#     expect(toc_links.nth(1)).to_have_text("Pagefind")
#     expect(toc_links.nth(2)).to_have_text("Sphinx")
#     expect(toc_links.nth(3)).to_have_text("Custom")
#     expect(toc_links.nth(4)).to_have_text("Analytics")
# 
#     # Verify the section links point to the correct IDs
#     expect(toc_links.nth(0)).to_have_attribute("href", "#providers")
#     expect(toc_links.nth(1)).to_have_attribute("href", "#pagefind")
#     expect(toc_links.nth(2)).to_have_attribute("href", "#sphinx")
#     expect(toc_links.nth(3)).to_have_attribute("href", "#custom")
#     expect(toc_links.nth(4)).to_have_attribute("href", "#analytics")
# 
# 
# def test_toc_section_click_scrolls_to_target(page: Page):
#     """Test that clicking a TOC section link scrolls to the target section."""
#     page.goto("http://0.0.0.0:8080/search/index.html")
# 
#     # Wait for Angular to bootstrap
#     page.wait_for_selector("app-root app-header", timeout=5000)
# 
#     # Click on the "Providers" section in the TOC
#     toc = page.locator("app-toc nav.toc")
#     providers_link = toc.locator("a[href='#providers']")
#     providers_link.click()
# 
#     # The URL should update with the hash
#     expect(page).to_have_url("http://0.0.0.0:8080/search/index.html#providers")
# 
#     # The target section should be scrolled into view
#     providers_section = page.locator("section[id='providers']")
#     expect(providers_section).to_be_in_viewport()
# 
# 
# 
# 
# def test_section_nav_on_index_page(page: Page):
#     """Test that the section nav on index page shows Home and Search."""
#     page.goto("http://0.0.0.0:8080/")
# 
#     # Wait for Angular to bootstrap
#     page.wait_for_selector("app-root app-header", timeout=5000)
# 
#     # Find the section nav component
#     section_nav = page.locator("app-nav nav.section-nav")
#     expect(section_nav).to_be_visible()
# 
#     # Get all nav items (links and labels)
#     nav_items = section_nav.locator("ul.nav-list li a, ul.nav-list li span.nav-label")
# 
#     # Should have exactly 2 items: Home and Search >
#     expect(nav_items).to_have_count(2)
# 
#     # Verify the items
#     expect(nav_items.nth(0)).to_have_text("Home")
#     expect(nav_items.nth(1)).to_have_text("Search >")
