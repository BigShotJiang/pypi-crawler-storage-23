from playwright.sync_api import Page, expect


def test_nav_component_home_to_user_interface(page: Page):
    """Test navigating from home page to user interface index using the nav component."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")
    expect(nav).to_be_visible()

    # Find the "User interface >" link in the nav (expandable item)
    ui_link = nav.locator("a:has-text('User interface')")
    expect(ui_link).to_be_visible()

    # Click the User interface link to expand it
    ui_link.click()

    # Wait for nav to update
    page.wait_for_timeout(500)

    # Now click the Overview link to navigate to the page
    overview_link = nav.locator("a:has-text('Overview')")
    expect(overview_link).to_be_visible()
    overview_link.click()

    # Wait for navigation
    page.wait_for_timeout(1000)

    # Should navigate to ui/index.html
    expect(page).to_have_url("http://0.0.0.0:8080/ui/index.html")


def test_nav_component_shows_expandable_indicator(page: Page):
    """Test that nav items with children show the ">" indicator."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")

    # The "User interface >" link should exist (with the > suffix)
    ui_link = nav.locator("a", has_text="User interface >")
    expect(ui_link).to_be_visible()

    # The "Features >" link should also exist
    features_link = nav.locator("a", has_text="Features >")
    expect(features_link).to_be_visible()


def test_nav_component_expandable_updates_secnav(page: Page):
    """Test that clicking an expandable nav item updates the section nav without changing the page."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Get the initial URL
    initial_url = page.url

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")

    # Click the "User interface >" link (expandable)
    ui_link = nav.locator("a:has-text('User interface')")
    ui_link.click()

    # Wait a moment
    page.wait_for_timeout(500)

    # URL should not have changed (expandable items don't navigate)
    assert page.url == initial_url, f"URL should not change for expandable items, but changed from {initial_url} to {page.url}"

    # The nav should now show the User interface section
    # Should have a back link to Home
    back_link = nav.locator("a:has-text('‹ Home')")
    expect(back_link).to_be_visible()

    # Should have "USER INTERFACE" label
    label = nav.locator("span.nav-label:has-text('User interface')")
    expect(label).to_be_visible()

    # Should have Overview link
    overview_link = nav.locator("a:has-text('Overview')")
    expect(overview_link).to_be_visible()


def test_nav_component_back_link_returns_to_root(page: Page):
    """Test that clicking the back link in nav returns to root navigation."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")

    # Click the "User interface >" link to expand
    ui_link = nav.locator("a:has-text('User interface')")
    ui_link.click()
    page.wait_for_timeout(500)

    # Should now show back link
    back_link = nav.locator(".nav-parent a:has-text('‹ Home')")
    expect(back_link).to_be_visible()

    # Click the back link
    back_link.click()
    page.wait_for_timeout(500)

    # Should be back to root nav view
    # Should see "User interface >" again
    ui_link_again = nav.locator("a:has-text('User interface')")
    expect(ui_link_again).to_be_visible()

    # Should not see the back link anymore
    expect(back_link).not_to_be_visible()


def test_nav_component_overview_link_navigates(page: Page):
    """Test that clicking Overview link navigates to the parent page."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")

    # Click to expand User interface section
    ui_link = nav.locator("a:has-text('User interface')")
    ui_link.click()
    page.wait_for_timeout(500)

    # Click the Overview link
    overview_link = nav.locator("a:has-text('Overview')")
    overview_link.click()

    # Wait for navigation
    page.wait_for_timeout(1000)

    # Should navigate to ui/index.html
    expect(page).to_have_url("http://0.0.0.0:8080/ui/index.html")


def test_nav_component_child_item_navigation(page: Page):
    """Test navigating to a child item within a section."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-nav", timeout=5000)

    # Find the nav component
    nav = page.locator("app-nav nav.section-nav")

    # Expand User interface section
    ui_link = nav.locator("a:has-text('User interface')")
    ui_link.click()
    page.wait_for_timeout(500)

    # Click on a child item, e.g., "Navigation"
    nav_link = nav.locator("a:has-text('Navigation')")
    expect(nav_link).to_be_visible()
    nav_link.click()

    # Wait for navigation
    page.wait_for_timeout(1000)

    # Should navigate to ui/nav/index.html
    expect(page).to_have_url("http://0.0.0.0:8080/ui/nav/index.html")
