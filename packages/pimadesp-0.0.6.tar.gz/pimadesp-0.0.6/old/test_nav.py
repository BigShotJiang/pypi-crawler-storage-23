from playwright.sync_api import Page, expect


# def test_footer_link_navigation(page: Page):
#     page.goto("http://0.0.0.0:8080")
#     page.locator("footer a[href$='search/index.html']").first.click()
#     expect(page).to_have_url("http://0.0.0.0:8080/search/index.html")
