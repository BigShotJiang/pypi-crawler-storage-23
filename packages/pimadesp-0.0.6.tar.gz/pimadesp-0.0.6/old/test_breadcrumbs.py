from playwright.sync_api import Page, expect


def test_breadcrumbs_appear_on_nested_page(page: Page):
    """Test that breadcrumbs appear on a nested page."""
    page.goto("http://0.0.0.0:8080/topics/header/index.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    # Find the breadcrumbs
    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs")
    expect(breadcrumbs).to_be_visible()

    # Should have breadcrumb items
    breadcrumb_links = breadcrumbs.locator("ol li")
    expect(breadcrumb_links).to_have_count(3)  # Home > Topics > Header


def test_breadcrumbs_correct_trail_for_deeply_nested_page(page: Page):
    """Test that breadcrumbs show the correct trail for a deeply nested page."""
    page.goto("http://0.0.0.0:8080/topics/header/index.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs ol")

    # Check the breadcrumb items
    items = breadcrumbs.locator("li")

    # First item should be "Home" and be a link
    first_item = items.nth(0)
    home_link = first_item.locator("a")
    expect(home_link).to_have_text("Home")

    # Second item should be "Topics" and be a link
    second_item = items.nth(1)
    topics_link = second_item.locator("a")
    expect(topics_link).to_have_text("Topics")

    # Third item should be "Header (UI component)" and NOT be a link (current page)
    third_item = items.nth(2)
    current_span = third_item.locator("span.current")
    expect(current_span).to_have_text("Header (UI component)")


def test_breadcrumbs_not_shown_on_root_page(page: Page):
    """Test that breadcrumbs are not shown on the root page."""
    page.goto("http://0.0.0.0:8080/")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root", timeout=5000)

    # Breadcrumbs should not be visible (only 1 item = current page)
    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs")
    expect(breadcrumbs).not_to_be_visible()


def test_breadcrumbs_navigation_works(page: Page):
    """Test that clicking a breadcrumb link navigates to that page."""
    page.goto("http://0.0.0.0:8080/topics/header/index.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    # Click on "Topics" breadcrumb
    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs")
    topics_link = breadcrumbs.locator("a:has-text('Topics')")
    topics_link.click()

    # Wait for navigation
    page.wait_for_timeout(1000)

    # Should navigate to topics page
    assert "topics/index.html" in page.url or page.url.endswith("/topics/"), \
        f"Expected URL to contain 'topics', got: {page.url}"


def test_breadcrumbs_home_link_works(page: Page):
    """Test that clicking the Home breadcrumb navigates to the home page."""
    page.goto("http://0.0.0.0:8080/topics/header/index.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    # Click on "Home" breadcrumb
    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs")
    home_link = breadcrumbs.locator("a:has-text('Home')")
    home_link.click()

    # Wait for navigation
    page.wait_for_timeout(1000)

    # Should navigate to home page
    assert page.url == "http://0.0.0.0:8080/" or page.url.endswith("index.html"), \
        f"Expected URL to be root or index.html, got: {page.url}"


def test_breadcrumbs_have_separators(page: Page):
    """Test that breadcrumbs have separators between items."""
    page.goto("http://0.0.0.0:8080/topics/header/index.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs")

    # Should have separators (/) between items
    separators = breadcrumbs.locator("span.separator")
    # Should have 2 separators for 3 items (Home / Topics / Header)
    expect(separators).to_have_count(2)

    # Each separator should contain "/"
    for i in range(2):
        expect(separators.nth(i)).to_have_text("/")


def test_breadcrumbs_architecture_page(page: Page):
    """Test breadcrumbs on the contribute/architecture page."""
    page.goto("http://0.0.0.0:8080/contribute/architecture.html")

    # Wait for Angular to bootstrap
    page.wait_for_selector("app-root app-breadcrumbs", timeout=5000)

    breadcrumbs = page.locator("app-breadcrumbs nav.breadcrumbs ol")

    # Should have 3 items: Home > Contribute > Architecture
    items = breadcrumbs.locator("li")
    expect(items).to_have_count(3)

    # Verify trail
    home_link = items.nth(0).locator("a")
    expect(home_link).to_have_text("Home")

    contribute_link = items.nth(1).locator("a")
    expect(contribute_link).to_have_text("Contribute")

    current = items.nth(2).locator("span.current")
    expect(current).to_have_text("Architecture")
