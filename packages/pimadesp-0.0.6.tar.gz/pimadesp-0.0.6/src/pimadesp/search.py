import logging
from pathlib import Path
from html.parser import HTMLParser

logger = logging.getLogger(__name__)


class SectionIDTransformer(HTMLParser):
    """Transforms HTML to add section IDs to their first heading element.

    Pagefind requires IDs on heading elements (h1-h6) to generate subresults,
    but Sphinx puts IDs on section elements. This transformer copies section IDs
    to their corresponding headings.
    """

    def __init__(self):
        super().__init__()
        self.output = []
        self.current_section_id = None
        self.pending_heading_id = None

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)

        # Track section IDs
        if tag == 'section' and 'id' in attrs_dict:
            self.pending_heading_id = attrs_dict['id']

        # Add section ID to the first heading within that section
        if tag in ('h1', 'h2', 'h3', 'h4', 'h5', 'h6') and self.pending_heading_id:
            # Add the ID to this heading if it doesn't already have one
            if 'id' not in attrs_dict:
                attrs_dict['id'] = self.pending_heading_id
                attrs = list(attrs_dict.items())
            self.pending_heading_id = None

        # Add data-pagefind-ignore to headerlink anchors
        if tag == 'a' and attrs_dict.get('class') == 'headerlink':
            attrs_dict['data-pagefind-ignore'] = ''
            attrs = list(attrs_dict.items())

        # Reconstruct the tag
        attrs_str = ''.join(f' {k}="{v}"' for k, v in attrs)
        self.output.append(f'<{tag}{attrs_str}>')

    def handle_endtag(self, tag):
        self.output.append(f'</{tag}>')

    def handle_data(self, data):
        self.output.append(data)

    def handle_startendtag(self, tag, attrs):
        attrs_str = ''.join(f' {k}="{v}"' for k, v in attrs)
        self.output.append(f'<{tag}{attrs_str}/>')

    def get_output(self):
        return ''.join(self.output)


def transform_html_for_pagefind(html_content: str) -> str:
    """Transform HTML to make it compatible with pagefind subresults."""
    parser = SectionIDTransformer()
    parser.feed(html_content)
    return parser.get_output()

def run_pagefind_indexing(app, exception):
    """Index content fragments with pagefind after build completes."""
    if exception:
        return

    # Check if pagefind is the configured search provider
    search_provider = app.config.html_theme_options.get('search_provider', 'pagefind')
    if search_provider != 'pagefind':
        return

    try:
        import asyncio
        from pagefind.index import PagefindIndex, IndexConfig
    except ImportError:
        logger.warning(
            "pagefind is configured as search provider but not installed. "
            "Search will not be available. "
            "Install with: pip install 'pagefind[extended]'"
        )
        return

    async def index():
        outdir = Path(app.outdir)
        if not outdir.exists():
            logger.warning(f"Output directory not found: {outdir}")
            return

        output_path = Path(app.outdir) / 'pagefind'

        # Get language from Sphinx config, default to 'en'
        language = app.config.language or 'en'

        config = IndexConfig(
            output_path=str(output_path),
            force_language=language,
            root_selector="app-root"  # Target the Angular app content area where sections are
        )

        async with PagefindIndex(config=config) as idx:
            # Find all HTML files, excluding the _content directory
            for html_file in outdir.rglob("*.html"):
                # Skip files in the _content directory
                if "_content" in html_file.parts:
                    continue
                content = html_file.read_text(encoding='utf-8')
                # Transform HTML to add section IDs to headings for proper subresult detection
                transformed_content = transform_html_for_pagefind(content)
                await idx.add_html_file(
                    content=transformed_content,
                    source_path=str(html_file.relative_to(outdir)),
                    url=str(html_file.relative_to(outdir))
                )

        logger.info(f"Pagefind indexing complete (language: {language})")

    import threading

    def run_in_thread():
        asyncio.run(index())

    try:
        thread = threading.Thread(target=run_in_thread)
        thread.start()
        thread.join()
    except Exception as e:
        logger.error(f"Pagefind indexing failed: {e}", exc_info=True)

def inject_search_config(app, pagename, templatename, context, doctree):
    """Inject search provider configuration into template context."""
    theme_options = app.config.html_theme_options
    search_provider = theme_options.get('search_provider', 'pagefind')

    context['search_provider'] = search_provider
    context['search_enabled'] = search_provider is not None
