import json
import logging
from pathlib import Path
from xml.etree import ElementTree as ET

from pimadesp import angular_build, search

logger = logging.getLogger(__name__)

def compute_sitemap(app):
    """Build sitemap tree from toctree structure."""
    from sphinx import addnodes
    env = app.builder.env
    master = env.config.master_doc

    def get_children(pagename):
        toc = env.tocs.get(pagename)
        if toc is None:
            return []
        children = []
        for toctree_node in toc.findall(addnodes.toctree):
            for title, ref in toctree_node['entries']:
                is_self = ref == 'self'
                if is_self:
                    ref = pagename
                if title is None:
                    title = env.titles[ref].astext() if ref in env.titles else ref
                path = app.builder.get_target_uri(ref)
                entry = {
                    'title': title,
                    'path': path,
                    'children': [] if is_self else get_children(ref),
                }
                children.append(entry)
        return children

    return get_children(master)

def normalize_path(path):
    import re
    path = re.sub(r'\.html$', '', path)
    path = re.sub(r'/index$', '', path)
    path = re.sub(r'/$', '', path)
    return path


def extract_sections(doctree):
    """Extract section hierarchy from doctree, excluding the H1 (page title)."""
    from docutils import nodes
    sections = []

    for section in doctree.findall(nodes.section):
        ids = section.get('ids', [])
        if not ids:
            continue

        title_node = section[0] if section.children else None
        if not isinstance(title_node, nodes.title):
            continue

        # Determine heading level by counting parent sections
        level = 2
        parent = section.parent
        while parent:
            if isinstance(parent, nodes.section):
                level += 1
            parent = parent.parent

        # Skip level 2 (H1) sections - these are page titles
        if level == 2:
            continue

        sections.append({
            'id': ids[0],
            'title': title_node.astext(),
            'level': level
        })

    return sections

def write_page_sitemap_data(app, doctree, docname):
    """Write per-page sitemap data after doctree resolution."""
    sections = extract_sections(doctree)

    env = app.builder.env

    page_data = {
        'docname': docname,
        'path': app.builder.get_target_uri(docname),
        'title': env.titles[docname].astext() if docname in env.titles else docname,
        'sections': sections
    }

    # Write immediately (parallel-safe - each page writes its own file)
    sitemap_dir = Path(app.outdir) / '_sitemap' / 'pages'
    sitemap_dir.mkdir(exist_ok=True, parents=True)

    page_file = sitemap_dir / f'{docname}.json'
    page_file.parent.mkdir(exist_ok=True, parents=True)
    page_file.write_text(json.dumps(page_data), encoding='utf-8')

def strip_toc_title(toc_html):
    """Remove the H1 (document title) from the ToC, keeping only H2+ entries."""
    if not toc_html or not toc_html.strip():
        return toc_html
    try:
        root = ET.fromstring(toc_html)
        first_li = root.find('li')
        if first_li is not None:
            nested_ul = first_li.find('ul')
            if nested_ul is not None:
                return ET.tostring(nested_ul, encoding='unicode', method='html')
        return toc_html
    except ET.ParseError:
        return toc_html

def write_content_fragment(app, pagename, templatename, context, doctree):
    """Write only content and ToC fragments."""
    outdir = Path(app.outdir)

    # Write content fragment
    content_dir = outdir / '_content'
    content_dir.mkdir(exist_ok=True)
    content_file = content_dir / f'{pagename}.html'
    content_file.parent.mkdir(exist_ok=True, parents=True)
    content_file.write_text(context.get('body', ''), encoding='utf-8')

    # Write ToC fragment
    toc_dir = outdir / '_toc'
    toc_dir.mkdir(exist_ok=True)
    toc = strip_toc_title(context.get('toc', ''))
    context['toc'] = toc
    toc_file = toc_dir / f'{pagename}.html'
    toc_file.parent.mkdir(exist_ok=True, parents=True)
    toc_file.write_text(toc, encoding='utf-8')

    # For SSR template: compute sitemap from toctree
    sitemap = compute_sitemap(app)
    context['sitemap_json'] = json.dumps(sitemap)

    # Set root page for Angular app
    env = app.builder.env
    master = env.config.master_doc
    master_title = env.titles[master].astext() if master in env.titles else 'Home'
    master_path = app.builder.get_target_uri(master)
    root_page = {'title': master_title, 'path': master_path}
    context['root_page_json'] = json.dumps(root_page)

def build_comprehensive_sitemap(app, exception):
    """Collect all per-page data and build comprehensive sitemap."""
    if exception:
        return

    sitemap_dir = Path(app.outdir) / '_sitemap'
    pages_dir = sitemap_dir / 'pages'

    # Read all per-page JSON files
    pages = {}
    if pages_dir.exists():
        for page_file in pages_dir.glob('**/*.json'):
            docname = str(page_file.relative_to(pages_dir)).replace('.json', '')
            page_data = json.loads(page_file.read_text(encoding='utf-8'))
            pages[docname] = page_data

    # Build tree from toctree
    tree = compute_sitemap(app)

    # Get root page
    env = app.builder.env
    master = env.config.master_doc
    root_page = {
        'title': pages.get(master, {}).get('title', 'Home'),
        'path': pages.get(master, {}).get('path', 'index.html')
    }

    # Write comprehensive sitemap
    comprehensive = {
        'version': '1.0',
        'rootPage': root_page,
        'pages': pages,
        'tree': tree
    }

    (sitemap_dir / 'index.json').write_text(json.dumps(comprehensive), encoding='utf-8')

def setup(app):
    app.add_html_theme('pimadesp', Path(__file__).resolve().parent)

    # Connect event handlers
    app.connect('builder-inited', angular_build.build)
    app.connect('doctree-resolved', write_page_sitemap_data)
    app.connect('html-page-context', write_content_fragment)
    app.connect('html-page-context', search.inject_search_config)
    app.connect('build-finished', build_comprehensive_sitemap)
    app.connect('build-finished', angular_build.copy_to_static)
    app.connect('build-finished', search.run_pagefind_indexing)
    return {"parallel_read_safe": True, "parallel_write_safe": True}
