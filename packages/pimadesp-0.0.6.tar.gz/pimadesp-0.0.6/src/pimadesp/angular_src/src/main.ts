import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

const staticBody = document.getElementById('static-body');
const staticToc = document.getElementById('static-toc');
const staticSitemap = document.getElementById('static-sitemap');
const staticRootPage = document.getElementById('static-root-page');

if (staticBody && staticBody.innerHTML.trim()) {
  (window as any).__STATIC__ = {
    body: staticBody.innerHTML,
    toc: staticToc ? staticToc.innerHTML : '',
    sitemap: staticSitemap ? staticSitemap.textContent : '[]',
    rootPage: staticRootPage ? staticRootPage.textContent : null,
    path: window.location.pathname,
  };
}

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
