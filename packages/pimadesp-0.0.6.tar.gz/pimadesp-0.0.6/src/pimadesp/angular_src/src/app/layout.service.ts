import { Injectable, signal, Signal, WritableSignal, DestroyRef, inject } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class LayoutService {
  private mobileQuery = window.matchMedia('(max-width: 768px)');
  private _isMobile: WritableSignal<boolean> = signal(this.mobileQuery.matches);
  isMobile: Signal<boolean> = this._isMobile.asReadonly();
  sidenavOpen: WritableSignal<boolean> = signal(false);
  searchActive: WritableSignal<boolean> = signal(false);
  tocActive: WritableSignal<boolean> = signal(false);

  private destroyRef = inject(DestroyRef);

  constructor() {
    const handler = (e: MediaQueryListEvent) => this._isMobile.set(e.matches);
    this.mobileQuery.addEventListener('change', handler);
    this.destroyRef.onDestroy(() => this.mobileQuery.removeEventListener('change', handler));
  }

  toggleSidenav() {
    this.sidenavOpen.update(open => !open);
  }

  closeSidenav() {
    this.sidenavOpen.set(false);
  }

  openSearch() {
    this.searchActive.set(true);
  }

  closeSearch() {
    this.searchActive.set(false);
  }

  openToc() {
    this.tocActive.set(true);
  }

  closeToc() {
    this.tocActive.set(false);
  }
}
