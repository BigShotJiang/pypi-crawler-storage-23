import { Component, inject, computed } from '@angular/core';
import { ContentService, SitemapEntry } from './content.service';

interface BreadcrumbItem {
  title: string;
  path: string;
}

@Component({
  selector: 'app-breadcrumbs',
  imports: [],
  template: `
    @if (breadcrumbs().length > 1) {
      <nav class="breadcrumbs" aria-label="Breadcrumb">
        <ol>
          @for (item of breadcrumbs(); track item.path; let isLast = $last) {
            <li>
              @if (!isLast) {
                <a [href]="contentService.basePath + item.path" (click)="navigate($event, item.path)">{{ item.title }}</a>
                <span class="separator">/</span>
              } @else {
                <span class="current">{{ item.title }}</span>
              }
            </li>
          }
        </ol>
      </nav>
    }
  `,
  styleUrl: './breadcrumbs.component.scss'
})
export class BreadcrumbsComponent {
  contentService = inject(ContentService);

  breadcrumbs = computed(() => {
    const currentPath = this.contentService.currentPath();
    const sitemap = this.contentService.sitemap();
    const rootPage = this.contentService.rootPage();

    if (!currentPath || !sitemap.length) {
      return [];
    }

    // Build breadcrumb trail
    const trail = this.findBreadcrumbTrail(sitemap, currentPath, rootPage);
    return trail;
  });

  private findBreadcrumbTrail(
    entries: SitemapEntry[],
    targetPath: string,
    rootPage: {title: string, path: string} | null,
    parentTrail: BreadcrumbItem[] = []
  ): BreadcrumbItem[] {
    const normalizedTarget = this.normalizePath(targetPath);

    for (const entry of entries) {
      const normalizedEntry = this.normalizePath(entry.path);

      if (normalizedEntry === normalizedTarget) {
        // Found the target - build complete trail
        const trail: BreadcrumbItem[] = [];

        // Add root page if we're not on it
        if (rootPage && normalizedTarget !== this.normalizePath(rootPage.path)) {
          trail.push({ title: rootPage.title, path: rootPage.path });
        }

        // Add parent trail
        trail.push(...parentTrail);

        // Add current page
        trail.push({ title: entry.title, path: entry.path });

        return trail;
      }

      // Search in children
      if (entry.children && entry.children.length > 0) {
        const newParentTrail = [...parentTrail];

        // Add current entry to parent trail if we're not on root
        if (rootPage && normalizedEntry !== this.normalizePath(rootPage.path)) {
          newParentTrail.push({ title: entry.title, path: entry.path });
        } else if (!rootPage) {
          newParentTrail.push({ title: entry.title, path: entry.path });
        }

        const result = this.findBreadcrumbTrail(entry.children, targetPath, rootPage, newParentTrail);
        if (result.length > 0) {
          return result;
        }
      }
    }

    return [];
  }

  private normalizePath(path: string): string {
    return path
      .replace(/\.html$/, '')
      .replace(/\/index$/, '')
      .replace(/\/$/, '')
      .replace(/^\//, '');
  }

  navigate(event: Event, path: string): void {
    event.preventDefault();
    this.contentService.loadPage(path);
    history.pushState(null, '', this.contentService.basePath + path);
  }
}
