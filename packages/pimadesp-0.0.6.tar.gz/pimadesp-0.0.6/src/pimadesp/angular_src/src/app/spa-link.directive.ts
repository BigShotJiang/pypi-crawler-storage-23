import { Directive, HostListener, inject } from '@angular/core';
import { ContentService } from './content.service';

@Directive({
  selector: '[appSpaContent]',
  standalone: true
})
export class SpaLinkDirective {
  private contentService = inject(ContentService);

  @HostListener('click', ['$event'])
  async onClick(event: MouseEvent): Promise<void> {
    const target = event.target as HTMLElement;
    const anchor = target.closest('a');

    if (!anchor) return;

    const href = anchor.getAttribute('href');
    if (!href) return;

    if (this.isInternalLink(href)) {
      event.preventDefault();

      const newPath = this.resolvePath(href);
      history.pushState({}, '', newPath);

      const hashIndex = newPath.indexOf('#');
      const pathWithoutHash = hashIndex !== -1 ? newPath.substring(0, hashIndex) : newPath;
      await this.contentService.loadPage(pathWithoutHash);

      this.handleScroll(href);
    }
  }

  private isInternalLink(href: string): boolean {
    if (href.startsWith('http://') || href.startsWith('https://')) {
      return new URL(href).origin === window.location.origin;
    }
    if (href.startsWith('#')) return false;
    if (href.startsWith('mailto:') || href.startsWith('tel:')) return false;
    return true;
  }

  private resolvePath(href: string): string {
    if (href.startsWith('/')) {
      return href;
    }
    const base = window.location.pathname.split('/').slice(0, -1).join('/');
    return `${base}/${href}`.replace(/\/+/g, '/');
  }

  private handleScroll(href: string): void {
    const hashIndex = href.indexOf('#');
    if (hashIndex !== -1) {
      const anchor = href.substring(hashIndex + 1);
      requestAnimationFrame(() => {
        document.getElementById(anchor)?.scrollIntoView();
      });
    } else {
      window.scrollTo(0, 0);
    }
  }
}
