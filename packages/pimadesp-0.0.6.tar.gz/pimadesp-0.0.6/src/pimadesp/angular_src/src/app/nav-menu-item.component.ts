import { Component, Input, inject } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { ContentService, SitemapEntry } from './content.service';

@Component({
  selector: 'app-nav-menu-item',
  standalone: true,
  imports: [MatMenuModule, MatIconModule],
  template: `
    <button
      class="nav-link menu-trigger"
      [matMenuTriggerFor]="menu"
      [attr.aria-label]="'Open ' + item.title + ' menu'"
    >
      {{ item.title }}
      <mat-icon class="dropdown-icon">arrow_drop_down</mat-icon>
    </button>
    <mat-menu #menu="matMenu">
      <a
        mat-menu-item
        class="menu-item"
        (click)="navigate($event, item)"
        [href]="contentService.basePath + item.path"
      >Overview</a>
      @for (child of item.children; track child.path) {
        <a
          mat-menu-item
          class="menu-item"
          (click)="navigate($event, child)"
          [href]="contentService.basePath + child.path"
        >{{ child.title }}</a>
      }
    </mat-menu>
  `,
  styleUrl: './nav-menu-item.component.scss'
})
export class NavMenuItemComponent {
  @Input({ required: true }) item!: SitemapEntry;
  @Input({ required: true }) navigate!: (event: Event, item: SitemapEntry) => void;

  contentService = inject(ContentService);
}
