import { Injectable, inject, NgZone } from '@angular/core';
import { ContentService } from './content.service';

@Injectable({ providedIn: 'root' })
export class SpaNavigationService {
  private contentService = inject(ContentService);
  private ngZone = inject(NgZone);

  initialize(): void {
    // Handle browser back/forward
    window.addEventListener('popstate', () => {
      this.ngZone.run(async () => {
        await this.contentService.loadPage(window.location.pathname);
        this.scrollToHash();
      });
    });

    // Load initial page content only if not already populated from static data
    if (!this.contentService.content()) {
      this.contentService.loadPage(window.location.pathname).then(() => {
        this.scrollToHash();
      });
    } else {
      this.scrollToHash();
    }
  }

  private scrollToHash(): void {
    const hash = window.location.hash;
    if (hash) {
      requestAnimationFrame(() => {
        document.querySelector(hash)?.scrollIntoView();
      });
    }
  }
}
