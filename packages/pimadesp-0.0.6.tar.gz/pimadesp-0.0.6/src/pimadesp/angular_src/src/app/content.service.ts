import { Injectable, signal, computed } from '@angular/core';

export interface Section {
  id: string;
  title: string;
  level: number;
}

export interface SitemapEntry {
  title: string;
  path: string;
  children: SitemapEntry[];
  sections?: Section[];
}

export interface PageData {
  docname: string;
  path: string;
  title: string;
  sections: Section[];
}

export interface ComprehensiveSitemap {
  version: string;
  rootPage: {title: string, path: string};
  pages: {[docname: string]: PageData};
  tree: SitemapEntry[];
}

export interface SecnavItem {
  title: string;
  path: string;
  type?: 'link' | 'label' | 'expandable';
  has_children?: boolean;
}

export interface SecnavData {
  parent: {title: string, path: string} | null;
  items: SecnavItem[];
}

@Injectable({ providedIn: 'root' })
export class ContentService {
  content = signal<string>('');
  toc = signal<string>('');
  private comprehensiveSitemap = signal<ComprehensiveSitemap | null>(null);
  loading = signal<boolean>(false);
  currentPath = signal<string>('');
  basePath: string;
  secnavContext = signal<string>(''); // Path of the section being viewed in secnav

  sitemap = computed(() => this.comprehensiveSitemap()?.tree || []);

  rootPage = computed(() => this.comprehensiveSitemap()?.rootPage || null);

  secnav = computed<SecnavData>(() => {
    const sitemap = this.sitemap();
    const context = this.secnavContext() || this.currentPath();
    const empty: SecnavData = {parent: null, items: []};
    if (!sitemap.length || !context) return empty;
    return this.findSecnav(sitemap, context, null, sitemap, this.rootPage());
  });

  currentSections = computed<Section[]>(() => {
    const comprehensive = this.comprehensiveSitemap();
    const path = this.currentPath();
    if (!comprehensive || !path) return [];

    const docname = this.pathToDocname(path);
    return comprehensive.pages[docname]?.sections || [];
  });

  constructor() {
    const contentRoot = document.documentElement.dataset['content_root'] || './';
    this.basePath = new URL(contentRoot, window.location.href).pathname;
    const staticData = (window as any).__STATIC__;
    if (staticData) {
      this.content.set(staticData.body);
      this.toc.set(staticData.toc);
      this.currentPath.set(staticData.path);
    }
    // Always load comprehensive sitemap to get page metadata
    this.loadSitemap();
  }

  private async loadSitemap(): Promise<void> {
    try {
      const response = await fetch(`${this.basePath}_sitemap/index.json`);
      if (response.ok) {
        this.comprehensiveSitemap.set(await response.json());
      }
    } catch (error) {
      console.error('Failed to load sitemap:', error);
    }
  }

  private normalizeForComparison(path: string): string {
    let normalized = path.replace(/\.html$/, '').replace(/\/index$/, '').replace(/\/$/, '');
    // Remove leading slash for consistent comparison
    normalized = normalized.replace(/^\//, '');
    // Treat 'index' as root
    if (normalized === 'index') {
      normalized = '';
    }
    return normalized;
  }

  private pathToDocname(path: string): string {
    let docname = path
      .replace(/\.html$/, '')
      .replace(/\/index$/, '')
      .replace(/^\//, '');
    // Root page is stored as 'index', not empty string
    if (docname === '' || docname === 'index') {
      return 'index';
    }
    return docname;
  }

  private findSecnav(
    entries: SitemapEntry[],
    path: string,
    parent: SitemapEntry | null,
    rootEntries: SitemapEntry[],
    rootPage: {title: string, path: string} | null = null,
    isTopLevel: boolean = true,  // Track if this is the top-level call
  ): SecnavData {
    // For root page, show root title + top-level items with ">" suffix for expandable items
    const isRoot = rootPage && this.normalizeForComparison(path) === this.normalizeForComparison(rootPage.path);
    if (isRoot) {
      const items: SecnavItem[] = [{title: rootPage.title, path: rootPage.path, type: 'link'}];
      for (const e of rootEntries) {
        // Skip the root page itself if it appears in rootEntries
        if (this.normalizeForComparison(e.path) === this.normalizeForComparison(rootPage.path)) {
          continue;
        }
        const suffix = e.children.length ? ' >' : '';
        items.push({
          title: e.title + suffix,
          path: e.path,
          type: e.children.length ? 'expandable' : 'link',
          has_children: e.children.length > 0
        });
      }
      return {parent: null, items};
    }

    const normalized = this.normalizeForComparison(path);
    for (const entry of entries) {
      if (this.normalizeForComparison(entry.path) === normalized) {
        if (entry.children.length) {
          // Show: back link, section label, "Overview" link, children
          // Back link goes to root for top-level sections
          const effectiveParent = rootPage;
          const items: SecnavItem[] = [
            {title: entry.title, path: entry.path, type: 'label'},
            {title: 'Overview', path: entry.path, type: 'link'}
          ];
          for (const c of entry.children) {
            const suffix = c.children.length ? ' >' : '';
            items.push({
              title: c.title + suffix,
              path: c.path,
              type: c.children.length ? 'expandable' : 'link',
              has_children: c.children.length > 0
            });
          }
          return {
            parent: effectiveParent ? {title: effectiveParent.title, path: effectiveParent.path} : null,
            items,
          };
        }
        if (parent) {
          // Child page within a section - show parent's items
          // Check if parent is a top-level section by comparing with root_entries
          const parentIsTopLevel = rootEntries.some(e =>
            this.normalizeForComparison(e.path) === this.normalizeForComparison(parent.path)
          );
          const effectiveParent = parentIsTopLevel ? rootPage : {title: parent.title, path: parent.path};
          const items: SecnavItem[] = [
            {title: parent.title, path: parent.path, type: 'label'},
            {title: 'Overview', path: parent.path, type: 'link'}
          ];
          for (const c of parent.children) {
            const suffix = c.children.length ? ' >' : '';
            items.push({
              title: c.title + suffix,
              path: c.path,
              type: c.children.length ? 'expandable' : 'link',
              has_children: c.children.length > 0
            });
          }
          return {
            parent: effectiveParent ? {title: effectiveParent.title, path: effectiveParent.path} : null,
            items,
          };
        }
        // Top-level item without children
        const items: SecnavItem[] = [{title: rootPage?.title || '', path: rootPage?.path || '', type: 'link'}];
        for (const e of rootEntries) {
          // Skip the root page itself if it appears in rootEntries
          if (rootPage && this.normalizeForComparison(e.path) === this.normalizeForComparison(rootPage.path)) {
            continue;
          }
          const suffix = e.children.length ? ' >' : '';
          items.push({
            title: e.title + suffix,
            path: e.path,
            type: e.children.length ? 'expandable' : 'link',
            has_children: e.children.length > 0
          });
        }
        return {parent: null, items};
      }
      if (entry.children.length) {
        const result = this.findSecnav(entry.children, path, entry, rootEntries, rootPage, false);
        if (result.items.length) return result;
      }
    }

    // Fallback - only return root items if this is the top-level call
    if (!isTopLevel) {
      // If we're in a recursive call and didn't find a match, return empty so the loop continues
      return {parent: null, items: []};
    }

    // Top-level fallback: show root items
    const items: SecnavItem[] = [{title: rootPage?.title || '', path: rootPage?.path || '', type: 'link'}];
    for (const e of rootEntries) {
      // Skip the root page itself if it appears in rootEntries
      if (rootPage && this.normalizeForComparison(e.path) === this.normalizeForComparison(rootPage.path)) {
        continue;
      }
      const suffix = e.children.length ? ' >' : '';
      items.push({
        title: e.title + suffix,
        path: e.path,
        type: e.children.length ? 'expandable' : 'link',
        has_children: e.children.length > 0
      });
    }
    return {parent: null, items};
  }


  async loadPage(path: string): Promise<void> {
    this.loading.set(true);
    this.currentPath.set(path);
    this.secnavContext.set(''); // Reset secnav context when loading a new page

    // Metadata comes from comprehensive sitemap (no separate fetch)

    try {
      const url = this.normalizePath(path);
      const tocUrl = url.replace('_content/', '_toc/');
      const [response, tocResponse] = await Promise.all([
        fetch(url),
        fetch(tocUrl),
      ]);

      if (!response.ok) {
        throw new Error(`Failed to fetch ${url}`);
      }

      const content = await response.text();
      this.content.set(content);
      this.toc.set(tocResponse.ok ? await tocResponse.text() : '');
    } catch (error) {
      console.error('Error loading page:', error);
      this.content.set('<p>Error loading page content.</p>');
      this.toc.set('');
    } finally {
      this.loading.set(false);
    }
  }

  private normalizePath(path: string): string {
    if (path.startsWith(this.basePath)) {
      path = path.slice(this.basePath.length);
    }
    if (path === '' || path === '/') {
      return `${this.basePath}_content/index.html`;
    }
    if (!path.endsWith('.html')) {
      path = path.endsWith('/') ? `${path}index.html` : `${path}.html`;
    }
    return `${this.basePath}_content/${path}`;
  }
}
