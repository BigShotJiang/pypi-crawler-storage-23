import { Component, inject, HostListener } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatIconButton } from '@angular/material/button';
import { ContentService } from './content.service';
import { LayoutService } from './layout.service';
import { SafeHtmlPipe } from './safe-html.pipe';

@Component({
  selector: 'app-outline-view',
  standalone: true,
  imports: [MatIconModule, MatIconButton],
  template: `
    <div class="outline-view">
      <div class="outline-header">
        <h3 class="outline-heading">On this page</h3>
        <button mat-icon-button (click)="close()" aria-label="Close table of contents">
          <mat-icon>close</mat-icon>
        </button>
      </div>
      <nav (click)="onLinkClick($event)">
        @if (contentService.currentSections().length) {
          <ul class="outline-list">
            @for (section of contentService.currentSections(); track section.id) {
              <li [class]="'outline-level-' + section.level">
                <a [href]="'#' + section.id">{{ section.title }}</a>
              </li>
            }
          </ul>
        }
      </nav>
    </div>
  `,
  styleUrl: './outline-view.component.scss'
})
export class OutlineViewComponent {
  contentService = inject(ContentService);
  private layoutService = inject(LayoutService);

  @HostListener('document:keydown.escape')
  onEscape() {
    this.close();
  }

  close() {
    this.layoutService.closeToc();
  }

  onLinkClick(event: Event) {
    const target = event.target as HTMLElement;
    const anchor = target.closest('a');
    if (!anchor) return;
    const href = anchor.getAttribute('href');
    if (href?.startsWith('#')) {
      event.preventDefault();
      this.close();
      requestAnimationFrame(() => {
        const el = document.querySelector(href);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
          history.replaceState(null, '', href);
        }
      });
    }
  }
}
