import { Component, inject, computed } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatIconButton } from '@angular/material/button';
import { ContentService, SitemapEntry } from './content.service';
import { ThemeService } from './theme.service';
import { LayoutService } from './layout.service';
import { NavMenuItemComponent } from './nav-menu-item.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatToolbarModule, MatIconModule, MatIconButton, NavMenuItemComponent],
  template: `
    <mat-toolbar color="primary">
      @if (layoutService.isMobile()) {
        <button mat-icon-button class="hamburger" (click)="layoutService.toggleSidenav()" [attr.aria-label]="layoutService.sidenavOpen() ? 'Close navigation' : 'Open navigation'">
          <mat-icon>{{ layoutService.sidenavOpen() ? 'close' : 'menu' }}</mat-icon>
        </button>
      }
      <a class="site-title" [href]="homeHref" (click)="navigateHome($event)">{{ projectName }}</a>
      <nav class="nav-links">
        @for (link of tabs(); track link.path) {
          @if (link.children && link.children.length > 0) {
            <app-nav-menu-item [item]="link" [navigate]="navigate.bind(this)" />
          } @else {
            <a
              class="nav-link"
              (click)="navigate($event, link)"
              [href]="contentService.basePath + link.path"
            >{{ link.title }}</a>
          }
        }
      </nav>
      <span class="spacer"></span>
      <button mat-icon-button (click)="toggleSearch()" [attr.aria-label]="layoutService.searchActive() ? 'Close search' : 'Search'" class="search-toggle">
        <mat-icon>{{ layoutService.searchActive() ? 'close' : 'search' }}</mat-icon>
      </button>
      <button mat-icon-button class="theme-toggle" (click)="themeService.toggle()" aria-label="Toggle theme">
        <mat-icon>{{ themeService.theme() === 'dark' ? 'light_mode' : 'dark_mode' }}</mat-icon>
      </button>
    </mat-toolbar>
  `,
  styleUrl: './header.component.scss'
})
export class HeaderComponent {
  contentService = inject(ContentService);
  themeService = inject(ThemeService);
  layoutService = inject(LayoutService);
  tabs = computed(() => this.contentService.sitemap());

  homeHref: string;
  projectName: string;

  constructor() {
    const contentRoot = document.documentElement.dataset['content_root'] || './';
    this.homeHref = new URL(contentRoot, window.location.href).pathname;

    // Get project name from app-root data attribute
    const appRoot = document.querySelector('app-root');
    this.projectName = appRoot?.getAttribute('data-project') || 'Documentation';
  }

  isActive(tab: SitemapEntry): boolean {
    const current = this.contentService.currentPath();
    const tabPath = tab.path.replace(/\.html$/, '').replace(/\/index$/, '/').replace(/\/$/, '');
    const normalizedCurrent = current.replace(/\.html$/, '').replace(/\/index$/, '/').replace(/\/$/, '');
    if (tabPath === 'index' || tabPath === '') {
      return normalizedCurrent === '' || normalizedCurrent === 'index';
    }
    return normalizedCurrent.startsWith(tabPath);
  }

  navigateHome(event: Event) {
    event.preventDefault();
    this.contentService.loadPage('index.html');
    history.pushState(null, '', this.homeHref);
  }

  navigate(event: Event, item: SitemapEntry) {
    event.preventDefault();
    this.contentService.loadPage(item.path);
    history.pushState(null, '', this.contentService.basePath + item.path);
  }

  toggleSearch() {
    if (this.layoutService.searchActive()) {
      this.layoutService.closeSearch();
    } else {
      this.layoutService.openSearch();
    }
  }
}
