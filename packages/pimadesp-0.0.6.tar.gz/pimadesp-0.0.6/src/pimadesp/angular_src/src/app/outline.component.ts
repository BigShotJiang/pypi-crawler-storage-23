import { Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ContentService } from './content.service';
import { LayoutService } from './layout.service';
import { SafeHtmlPipe } from './safe-html.pipe';

@Component({
  selector: 'app-outline',
  standalone: true,
  imports: [MatIconModule, MatButtonModule],
  template: `
    @if (contentService.currentSections().length) {
      @if (layoutService.isMobile()) {
        <button mat-mini-fab class="outline-fab" (click)="layoutService.openToc()" aria-label="Table of contents">
          <mat-icon>toc</mat-icon>
        </button>
      } @else {
        <nav class="outline">
          <h3 class="outline-heading">On this page</h3>
          <ul class="outline-list">
            @for (section of contentService.currentSections(); track section.id) {
              <li [class]="'outline-level-' + section.level">
                <a [href]="'#' + section.id">{{ section.title }}</a>
              </li>
            }
          </ul>
        </nav>
      }
    }
  `,
  styleUrl: './outline.component.scss'
})
export class OutlineComponent {
  contentService = inject(ContentService);
  layoutService = inject(LayoutService);
}
