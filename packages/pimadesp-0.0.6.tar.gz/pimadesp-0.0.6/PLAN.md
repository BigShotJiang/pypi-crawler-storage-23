# Plan: Provide `ng` binary to Sphinx build

The Sphinx theme calls `npx ng build` internally. It accepts an
`html_theme_options['ng_dir']` path that it prepends when invoking `npx`/`ng`.
The goal is to make the `ng` binary available to Sphinx via Bazel.

## Steps

### 1. `docs/sphinx/pnpm-workspace.yaml` (new file)
Create a pnpm workspace rooted at this package, separate from `pw_web`.

```yaml
packages:
  - '.'
```

### 2. `docs/sphinx/package.json`
Remove the `"packageManager": "npm@11.6.2"` field — incompatible with pnpm.

### 3. Generate lock file
```sh
cd docs/sphinx && pnpm install
```
This produces `docs/sphinx/pnpm-lock.yaml`.

### 4. `MODULE.bazel`
Register a second npm workspace for docs (separate from the existing `pw_web`
one named `"npm"`):

```python
npm.npm_translate_lock(
    name = "docs_npm",
    data = ["//docs/sphinx:package.json"],
    pnpm_lock = "//docs/sphinx:pnpm-lock.yaml",
)
use_repo(npm, "docs_npm")
```

### 5. `docs/sphinx/BUILD.bazel`
Add npm linking and an `ng` binary target:

```python
load("@aspect_bazel_lib//lib:directory_path.bzl", "directory_path")
load("@aspect_rules_js//js:defs.bzl", "js_binary")
load("@docs_npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")

directory_path(
    name = "ng_entry_point",
    directory = ":node_modules/@angular/cli/dir",
    path = "bin/ng.js",
    target_compatible_with = incompatible_with_mcu(),
)

js_binary(
    name = "ng_bin",
    entry_point = ":ng_entry_point",
    target_compatible_with = incompatible_with_mcu(),
)
```

Add `ng_bin` as a `data` dep on the existing `sphinx_build_binary` so it ends
up in the sphinx py_binary's runfiles:

```python
sphinx_build_binary(
    name = "sphinx_build",
    data = [":ng_bin"],
    ...
)
```

### 6. `docs/sphinx/conf.py`
Look up `ng_bin` via the runfiles API and pass its directory to the theme:

```python
if is_bazel_build:
    from python.runfiles import runfiles as _runfiles
    _r = _runfiles.Create()
    _ng = _r.Rlocation("_main/docs/sphinx/ng_bin")
    if _ng:
        html_theme_options["ng_dir"] = os.path.dirname(_ng)
```

## Notes

- `ng_bin` is a `js_binary` wrapper script that shells out to node, so its
  directory also contains `node` and `npx`.
- `angular.json` is bundled inside the theme — no need to provide it here.
- `docs/sphinx` is intentionally a separate pnpm workspace from `pw_web`.
