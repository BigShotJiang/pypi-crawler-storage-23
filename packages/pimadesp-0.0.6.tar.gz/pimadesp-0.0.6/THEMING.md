# Theming

## Goal

Theme users should have an easy, intuitive API for customizing the colors,
fonts, etc. of the theme.

## Requirements

It must follow Angular's theming recommendations:
https://raw.githubusercontent.com/angular/components/refs/heads/main/guides/theming.md

## Design

It seems like we'll need to fundamentally change the build workflow. The Sphinx
project at `src/pimedesp` will need to get the theme customizations from the
theme user, and then the theme will need to build Angular itself, making sure
that the user's customizations are applied during the build.

On the plus side, it seems like we'll no longer need to commit the generated
`src/pimadesp/static/main.js` and `src/pimadesp/static/angular.css` files
into the Git repo anymore

## Verification

The project in the `docs` directory is an example of a theme user. This will
be customer 0 of the new theming API. Update the docs project to use the
theming API to change some colors and fonts

## Testing

Create a new test file at `tests/test_theming.py` and create unit or integration
tests as needed. 

## Debugging

Create temporary tests in `tests/test_debug.py` as needed

## Documentation

Create a new how-to guide at `docs/theming/customize.rst`. This guide should
show theme users how to use the theming API within their own project
