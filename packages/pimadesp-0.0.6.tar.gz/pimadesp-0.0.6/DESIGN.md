# Theming design

## User API

Theme users place a `_theme.scss` file in their Sphinx project root (the
same directory as `conf.py`). This file uses Angular Material's Sass API
directly:

```scss
@use '@angular/material' as mat;

html {
  color-scheme: dark;
  @include mat.theme((
    color: (primary: mat.$violet-palette, theme-type: dark),
    typography: 'Inter',
    density: 0,
  ));
}

html.light {
  color-scheme: light;
  @include mat.theme((
    color: (primary: mat.$violet-palette, theme-type: light),
  ));
}

@media (prefers-color-scheme: light) {
  html:not(.dark):not(.light) {
    color-scheme: light;
    @include mat.theme((
      color: (primary: mat.$violet-palette, theme-type: light),
    ));
  }
}
```

The three blocks correspond to the three color-scheme states the Angular app
can be in: dark (default), explicit light (`.light` class set by
`ThemeService`), and system-preference light (no class set).

If `_theme.scss` is absent, pimadesp's built-in default is used (azure
palette, no custom typography).

To load a web font, use `app.add_css_file()` in `conf.py`:

```python
def setup(app):
    app.add_css_file("https://fonts.googleapis.com/css2?family=Inter:...")
```

Font name is set via `typography:` inside `mat.theme()` in `_theme.scss`.
Font file loading is a separate concern handled by standard Sphinx utilities.

## Implementation

### Component styles

Users can also customize individual components by placing `_<name>.scss`
partials in their Sphinx project root:

```
_header.scss        → app-header
_footer.scss        → app-footer
_nav.scss           → app-nav
_nav-view.scss      → app-nav-view
_nav-menu-item.scss → app-nav-menu-item
_outline.scss       → app-outline
_outline-view.scss  → app-outline-view
_search.scss        → app-search
_breadcrumbs.scss   → app-breadcrumbs
_app.scss           → app-root
```

Each component's stylesheet is structured as two `@use` declarations:

```scss
// header.component.scss
@use 'header-defaults';  // built-in defaults
@use 'user-header';      // user overrides — appears last, wins cascade
```

Because `@use` order determines CSS output order and all rules in a component
stylesheet share the same Angular encapsulation attribute selector (equal
specificity), user rules override defaults through cascade without needing
`!important`. `angular_build.py` writes the user's partial content (or an
empty string) to `_user-<name>.scss` before every Angular build.

### Angular styles

`angular_src/src/styles.scss` delegates all theme token generation to the
theme partial and contains only structural base styles:

```scss
@use 'user-theme';

html, body {
  margin: 0;
  padding: 0;
  height: 100%;
  font-family: var(--mat-sys-body-large-font, Roboto, sans-serif);
}

body {
  background-color: var(--mat-sys-surface);
  color: var(--mat-sys-on-surface);
}
```

`angular_src/src/_user-theme.scss` is the file that actually gets compiled.
Before each Angular build, `angular_build.py` writes the user's `_theme.scss`
content (or the default) to this path.

### Build orchestration (`angular_build.py`)

Triggered by the Sphinx `builder-inited` event, before any pages are
processed:

1. Look for `_theme.scss` in `app.confdir`. If present, read it; otherwise
   read the pimadesp default `_user-theme.scss`.
2. MD5-hash the content to produce a 12-character `theme_hash`.
3. Check `.pimadesp-cache/<theme_hash>/` in the confdir for `angular.css`
   and `main.js`. If both exist, skip the build.
4. On a cache miss:
   - Write the theme content to `angular_src/src/_user-theme.scss`
   - Run `npm install --ci` if `node_modules/` is absent
   - Run `npx ng build`
   - Copy `dist/browser/styles.css` → cache as `angular.css`
   - Copy `dist/browser/main.js` → cache as `main.js`
5. Store the cached file paths on the `app` object for the next step.

At `build-finished`, `copy_to_static()` copies both cached files to
`outdir/_static/` where `layout.html` references them.

### Why content-hash caching

The cache key is the MD5 of the theme partial's text, not a combination of
named options. This means:

- Any edit to `_theme.scss` automatically produces a new hash and triggers a
  rebuild.
- Two projects with identical `_theme.scss` content share the same cache
  entry.
- Deleting `.pimadesp-cache/` forces a full rebuild.

### Why `mat.theme()` instead of CSS variable overrides

Angular Material discourages directly setting `--mat-sys-*` CSS variables
because the names can change across versions and no validation is performed.
`mat.theme()` is the official API: it generates the complete tonal palette
(all color roles for both light and dark) from a single palette choice, with
correct contrast ratios guaranteed by the Material Design 3 color system.
