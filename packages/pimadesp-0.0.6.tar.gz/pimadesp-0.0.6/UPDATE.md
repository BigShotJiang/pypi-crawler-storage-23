# Plan: Provide Angular node_modules to Sphinx build via Bazel

The Sphinx theme compiles an Angular app at build time. To do this it needs:
1. The full `node_modules` tree (Angular, TypeScript, etc.)
2. A writable workspace to write user theme partials into before building

In a normal (non-Bazel) build the theme installs its own node_modules via
`npm install --ci`. Under Bazel we skip that and instead supply a pre-built
`node_modules` directory via a theme option.

## Theme changes needed (pimadesp)

### New theme option: `node_modules_dir`

`html_theme_options['node_modules_dir']` — an absolute path to a `node_modules`
directory that contains the full Angular dependency tree (all of the packages in
`angular_src/package.json`). When this option is present the theme:

1. Skips `_ensure_node_modules()` entirely.
2. Copies `ANGULAR_SRC` to a writable temp directory (to avoid writing into
   Bazel's read-only runfiles tree — see note below).
3. Creates a `node_modules` symlink inside the temp dir pointing to the supplied
   path.
4. Writes user theme partials into the temp dir (not into `ANGULAR_SRC`).
5. Runs the Angular build from the temp dir, invoking node directly:
   ```
   node <node_modules_dir>/@angular/cli/bin/ng.js build
   ```
   This bypasses `npx` entirely (avoids the `npx` local-package lookup that
   would fail without a pre-installed `node_modules/.bin/ng`).
6. Copies build output from `<temp_dir>/dist/browser/` to the cache as usual.

> **Why a writable temp dir?**  In a Bazel build, `Path(__file__).parent` (i.e.
> `ANGULAR_SRC`) lives inside the runfiles tree and is read-only.  The theme
> currently writes `_user-theme.scss` and other partials directly into that
> directory before building.  Under Bazel we must copy the Angular source tree
> to a temp location first.

## Bazel changes (docs/sphinx in the consuming repo)

### 1. `docs/sphinx/package.json` (new file or reuse angular_src's)

Must list **all** of `angular_src/package.json`'s dependencies and
devDependencies, because `ng build` needs the full transitive closure at
compile time.  Copy them verbatim and drop `"packageManager": "npm@..."` (pnpm
incompatible):

```json
{
  "name": "docs-angular",
  "version": "0.0.0",
  "private": true,
  "dependencies": {
    "@angular/animations": "^21.1.3",
    "@angular/cdk": "^21.1.3",
    "@angular/common": "^21.1.0",
    "@angular/compiler": "^21.1.0",
    "@angular/core": "^21.1.0",
    "@angular/forms": "^21.1.0",
    "@angular/material": "^21.1.3",
    "@angular/platform-browser": "^21.1.0",
    "@angular/router": "^21.1.0",
    "rxjs": "~7.8.0",
    "tslib": "^2.3.0"
  },
  "devDependencies": {
    "@angular/build": "^21.1.3",
    "@angular/cli": "^21.1.3",
    "@angular/compiler-cli": "^21.1.0",
    "typescript": "~5.9.2"
  }
}
```

(Drop `jsdom` and `vitest` — those are only needed for Angular unit tests, not
the docs build.)

### 2. `docs/sphinx/pnpm-workspace.yaml` (new file)

```yaml
packages:
  - '.'
```

### 3. Generate lock file

```sh
cd docs/sphinx && pnpm install
```

Produces `docs/sphinx/pnpm-lock.yaml`.

### 4. `MODULE.bazel`

Register a second npm workspace for docs:

```python
npm.npm_translate_lock(
    name = "docs_npm",
    data = ["//docs/sphinx:package.json"],
    pnpm_lock = "//docs/sphinx:pnpm-lock.yaml",
)
use_repo(npm, "docs_npm")
```

### 5. `docs/sphinx/BUILD.bazel`

Link npm packages and expose the node_modules directory:

```python
load("@docs_npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

Add `:node_modules` as a `data` dep on the `sphinx_build_binary` target so the
entire node_modules tree lands in the py_binary's runfiles:

```python
sphinx_build_binary(
    name = "sphinx_build",
    data = [":node_modules"],
    ...
)
```

### 6. `docs/sphinx/conf.py`

Locate the node_modules directory via the runfiles API and pass it to the theme.
Use a known file inside node_modules as the anchor (directory Rlocation is
unreliable across runfiles implementations):

```python
if is_bazel_build:
    from python.runfiles import runfiles as _runfiles
    _r = _runfiles.Create()
    # Anchor on a known file; walk up to node_modules/
    _ng_js = _r.Rlocation(
        "_main/docs/sphinx/node_modules/@angular/cli/bin/ng.js"
    )
    if _ng_js:
        import os as _os
        # ng.js is at <node_modules>/@angular/cli/bin/ng.js — four levels up
        _node_modules = _os.path.dirname(
            _os.path.dirname(_os.path.dirname(_os.path.dirname(_ng_js)))
        )
        html_theme_options["node_modules_dir"] = _node_modules
```

## Summary of what the theme must support

| Change | Location |
|---|---|
| Respect `node_modules_dir` option | `angular_build.py` |
| Skip `_ensure_node_modules()` when option is set | `angular_build.py` |
| Copy `ANGULAR_SRC` to writable temp dir when option is set | `angular_build.py` |
| Symlink `<temp>/node_modules` → `node_modules_dir` | `angular_build.py` |
| Write theme partials to temp dir (not `ANGULAR_SRC`) | `angular_build.py` |
| Invoke `node <node_modules_dir>/@angular/cli/bin/ng.js build` | `angular_build.py` |
| Declare `node_modules_dir` option in `theme.toml` | `theme.toml` |

## Notes

- The `node` binary must be on `PATH` at Sphinx build time. In a Bazel
  `py_binary`, this is typically satisfied by the hermetic toolchain or the host
  environment. If not, an additional `node_dir` option following the same pattern
  could be added later.
- The temp dir copy is cheap: `ANGULAR_SRC` is small (source files only, no
  node_modules). Use `shutil.copytree(..., ignore=shutil.ignore_patterns('node_modules', 'dist', '.angular'))`.
- The `node_modules` symlink avoids duplicating gigabytes of npm packages.
- Caching (the `theme_hash` mechanism) continues to work unchanged — the cache
  key depends only on theme partial content, not on the node_modules location.
