# Architecture

Pimadesp is a Sphinx HTML theme that turns static documentation into a modern SPA. It has two
distinct parts: a Python Sphinx extension that pre-processes content at build time, and an Angular
frontend that serves as the runtime shell.

## High-level data flow

```
Sphinx build
  → Python extension extracts content into HTML fragments + JSON metadata
  → Angular app shell (layout.html) is output as index.html
  → Pagefind indexes the built HTML

Browser loads index.html
  → Angular bootstraps on <app-root>
  → ContentService fetches _sitemap/index.json
  → SpaNavigationService loads the initial page's fragments
  → SpaLinkDirective intercepts subsequent link clicks for client-side navigation
```

## Directory structure

```
src/pimadesp/          Python Sphinx extension (the theme package consumers install)
  __init__.py          Sphinx event hooks and content extraction
  search.py            Pagefind indexing integration
  layout.html          Jinja2 template: the one HTML page output by the theme
  theme.toml           Sphinx theme metadata
  static/              Built Angular app (committed; consumers don't build Angular)
    dist/              Angular build artifacts
    main.js            Angular bootstrap (legacy artifact, actual app is in dist/)
    pimadesp.css       Base theme styles
    angular.css        Angular component styles

src/angular/           Angular 21 source
  src/app/             All components, services, directives, pipes

tests/                 Pytest + Playwright E2E tests

docs/                  Documentation for this theme (dogfoods pimadesp)
```

## Fragment-based content architecture

This is the central design decision. The Sphinx extension does NOT produce full navigable HTML
pages. Instead, each page is split into three outputs:

- `_content/<docname>.html` — the page body HTML fragment
- `_toc/<docname>.html` — the page's local table of contents HTML fragment
- `_sitemap/index.json` — one aggregated JSON file with the full nav tree and per-page metadata

The Angular shell fetches these fragments on demand and injects them into the DOM. This means:
- Only `index.html` (the Angular shell) is a real page
- `_content/` and `_toc/` entries are not valid standalone HTML
- Adding a new "page-level" data type means: extract it in `__init__.py`, write it to a new
  `_<type>/` directory, add a fetch in `ContentService`, and expose it via a signal

## Python extension: event hooks

The extension connects to four Sphinx events in `setup()`:

| Event | Handler | What it does |
|---|---|---|
| `doctree-resolved` | `write_page_sitemap_data` | Writes per-page metadata JSON to `_sitemap/<docname>.json` |
| `html-page-context` | `write_content_fragment` + `inject_search_config` | Writes `_content/` and `_toc/` fragments; injects search config into template context |
| `html-page-context` | `inject_search_config` | Sets `pagefind_enabled` in template context |
| `build-finished` | `build_comprehensive_sitemap` | Aggregates per-page JSON into `_sitemap/index.json`; runs Pagefind indexing |

The two-phase sitemap strategy (per-page files → aggregated index) is what makes parallel builds
safe. Each page writes its own file independently; aggregation happens after all parallel workers
finish. `setup()` returns `{"parallel_read_safe": True, "parallel_write_safe": True}`.

## Angular: state management

All runtime state lives in `ContentService` as Angular signals. There is no NgRx, no Redux, no
router state — just signals and computed signals.

```
ContentService
  content: signal<string>          current page body HTML
  toc: signal<string>              current page TOC HTML
  loading: signal<boolean>
  currentPath: signal<string>
  comprehensiveSitemap: signal<ComprehensiveSitemap | null>

  sitemap: computed             SitemapEntry[] tree from comprehensiveSitemap
  rootPage: computed            root page {title, path}
  currentSections: computed     Section[] for the current page (used by OutlineComponent)
  secnav: computed              section nav context {parent, items[]} for NavComponent
```

`secnav` (section navigation) is the complex one. It walks the sitemap tree to find which subtree
the current page belongs to, then returns the siblings and parent as nav items. This is how the
left sidebar knows what to show.

Other services:

- `LayoutService` — tracks `isMobile` (768px breakpoint), `sidenavOpen`, `searchActive`, `tocActive`
- `ThemeService` — dark/light toggle; persists to localStorage; applies CSS class to `<html>`
- `SearchService` — wraps Pagefind; async init with 5s retry loop; exposes `search()` method
- `SpaNavigationService` — sets up `popstate` listener; triggers initial page load

## Angular: component tree

```
App (root)
├── HeaderComponent
│   └── NavMenuItemComponent     (dropdown menus in header nav)
├── NavComponent                 (left sidebar, desktop)
├── BreadcrumbsComponent
├── main content area            (SafeHtmlPipe + SpaLinkDirective applied here)
├── OutlineComponent             (right sidebar, desktop)
├── FooterComponent
├── SearchComponent              (full-screen overlay)
├── NavViewComponent             (full-screen mobile nav)
└── OutlineViewComponent         (full-screen mobile TOC)
```

Mobile vs desktop is purely conditional rendering based on `LayoutService.isMobile`. The three-
column desktop layout (nav | content | outline) collapses to single column on mobile, where nav
and TOC are shown as full-screen modals.

## SPA navigation

Angular Router is intentionally not used. Navigation works via:

1. `SpaLinkDirective` — attached to the main content area, intercepts clicks on `<a>` tags that
   point to internal paths, calls `ContentService.loadPage()` and `history.pushState()`
2. `SpaNavigationService` — listens for `popstate` (back/forward) and calls `loadPage()`
3. `ContentService.loadPage(path)` — fetches `_content/<path>.html` and `_toc/<path>.html`,
   updates signals

If you add a new navigable route that doesn't map to a content fragment (e.g., a settings page),
you would need to handle it in `loadPage()` as a special case before the fetch.

## Search (Pagefind)

Pagefind is optional (`html_theme_options = {'search_provider': 'pagefind'}`). The integration has
two sides:

**Build time** (`search.py`): After the Sphinx build, `run_pagefind_indexing()` runs Pagefind's
indexer over the built HTML in a thread. `SectionIDTransformer` first rewrites heading elements to
carry section IDs (Pagefind uses these for sub-result anchors).

**Runtime** (`SearchService`): On init, polls `window.pagefind` until it appears (up to 5s). The
`pagefind/` directory is loaded as a module; `bundlePath` is passed from the template via a
`<script>` tag that `inject_search_config()` writes into `layout.html`'s context.

## Build pipeline

The Angular app is pre-built and its output is committed to `src/pimadesp/static/dist/`. Consumers
install the Python package and never touch Angular. The development workflow (in `dev.fish`) is:

1. `npm run build` in `src/angular/` — produces `dist/`
2. Copy `dist/` output into `src/pimadesp/static/dist/`
3. `sphinx-build` the docs to verify integration

When working on Angular, you edit in `src/angular/`, build, copy, then test with Sphinx.

## Theming

CSS theming uses Angular Material 3 design tokens (CSS custom properties). The prebuilt theme
`azure-blue.css` is loaded via `angular.json`. Dark/light mode is applied by `ThemeService`
toggling `.dark` / `.light` on `<html>`, which flips Material's color scheme. Custom overrides
live in `pimadesp.css` and `angular.css`.

`theme.toml` sets `inherit = "basic"` (Sphinx's built-in basic theme) and disables sidebars
(`sidebars = []`) since Angular handles navigation entirely.

## Testing

Tests are in `tests/` and use pytest + Playwright for E2E browser tests.

`conftest.py` provides a `live_server` fixture that:
1. Accepts a path to a built Sphinx output directory
2. Allocates a free port and starts Python's `http.server`
3. Returns the base URL for Playwright to navigate to

Tests build minimal Sphinx projects inline (temp directories), run `sphinx-build`, start the HTTP
server, and drive Chromium via Playwright. This means tests are slow but test the full stack.

Unit tests for the Python extraction logic (e.g., `extract_sections`, `compute_sitemap`) would go
in `test_html.py` style without Playwright.

## Key files for common tasks

| Task | Files to touch |
|---|---|
| Add new page metadata | `__init__.py` (extract + write), `content.service.ts` (fetch + signal) |
| Add a new component | `src/angular/src/app/<name>.component.ts`, import in `app.ts` |
| Change nav behavior | `content.service.ts` (`findSecnav`), `nav.component.ts` |
| Change search behavior | `search.py`, `search.service.ts`, `search.component.ts` |
| Add a theme option | `__init__.py` (`setup()`), `layout.html` (if needed in template) |
| Change responsive breakpoint | `layout.service.ts` (media query string) |
| Change theming/colors | `pimadesp.css`, `angular.css`, `angular.json` (prebuilt theme) |
| Add E2E test | `tests/test_*.py` using `live_server` fixture from `conftest.py` |
