import textwrap

from sphinx.application import Sphinx

from pimadesp.angular_build import _theme_hash, _resolve_user_theme, _DEFAULT_USER_THEME

_MINIMAL_CONF = textwrap.dedent("""
    extensions = ["pimadesp"]
    html_theme = "pimadesp"
""")

_MINIMAL_INDEX = textwrap.dedent("""
    =====
    Title
    =====

    Content.
""")

_VIOLET_INTER_THEME = textwrap.dedent("""
    @use '@angular/material' as mat;

    html {
      color-scheme: dark;
      @include mat.theme((
        color: (primary: mat.$violet-palette, theme-type: dark),
        typography: 'Inter',
        density: 0,
      ));
    }

    html.light {
      color-scheme: light;
      @include mat.theme((
        color: (primary: mat.$violet-palette, theme-type: light),
      ));
    }
""")

_AZURE_THEME = textwrap.dedent("""
    @use '@angular/material' as mat;

    html {
      color-scheme: dark;
      @include mat.theme((
        color: (primary: mat.$azure-palette, theme-type: dark),
        density: 0,
      ));
    }

    html.light {
      color-scheme: light;
      @include mat.theme((
        color: (primary: mat.$azure-palette, theme-type: light),
      ));
    }
""")


# ── Unit tests ────────────────────────────────────────────────────────────────

def test_theme_hash_stable():
    """Same content always produces the same hash."""
    assert _theme_hash('hello', {}) == _theme_hash('hello', {})


def test_theme_hash_differs_on_content():
    assert _theme_hash('azure', {}) != _theme_hash('violet', {})


def test_resolve_user_theme_uses_default_when_absent(tmp_path):
    """Returns the pimadesp default when no _theme.scss is present in confdir."""
    content, label = _resolve_user_theme(str(tmp_path))
    assert content == _DEFAULT_USER_THEME.read_text()
    assert 'pimadesp default' in label


def test_resolve_user_theme_picks_up_project_file(tmp_path):
    """Returns the project's _theme.scss when present."""
    scss = tmp_path / '_theme.scss'
    scss.write_text(_VIOLET_INTER_THEME)
    content, label = _resolve_user_theme(str(tmp_path))
    assert content == _VIOLET_INTER_THEME
    assert str(scss) in label


def test_different_theme_files_produce_different_hashes(tmp_path):
    default_content, _ = _resolve_user_theme(str(tmp_path))
    (tmp_path / '_theme.scss').write_text(_AZURE_THEME)
    custom_content, _ = _resolve_user_theme(str(tmp_path))
    assert _theme_hash(default_content, {}) != _theme_hash(custom_content, {})


# ── Integration tests (full Sphinx + Angular build) ───────────────────────────

def _build(tmp_path, theme_options=None, theme_scss=None):
    conf = _MINIMAL_CONF
    if theme_options:
        conf += f"\nhtml_theme_options = {theme_options!r}\n"
    if theme_scss is not None:
        (tmp_path / '_theme.scss').write_text(theme_scss)

    (tmp_path / 'conf.py').write_text(conf)
    (tmp_path / 'index.rst').write_text(_MINIMAL_INDEX)
    outdir = tmp_path / 'out'
    outdir.mkdir()
    doctreedir = tmp_path / 'doctrees'
    doctreedir.mkdir()
    app = Sphinx(str(tmp_path), str(tmp_path), str(outdir), str(doctreedir), 'html')
    app.build()
    return tmp_path / 'out'


def test_default_produces_angular_css(tmp_path):
    """Default build (no _theme.scss) writes angular.css to _static/."""
    out = _build(tmp_path)
    assert (out / '_static' / 'angular.css').exists()


def test_default_produces_main_js(tmp_path):
    """Default build writes main.js to _static/."""
    out = _build(tmp_path)
    assert (out / '_static' / 'main.js').exists()


def test_custom_theme_scss_is_used(tmp_path):
    """A project-level _theme.scss is picked up and its hash drives the cache."""
    out = _build(tmp_path, theme_scss=_VIOLET_INTER_THEME)
    assert (out / '_static' / 'angular.css').exists()
    # The built CSS should reference violet palette tokens (specific value from M3 violet)
    css = (out / '_static' / 'angular.css').read_text()
    assert css  # non-empty


def test_cache_is_reused_on_second_build(tmp_path):
    """Re-running sphinx-build with the same theme reuses the cache."""
    (tmp_path / '_theme.scss').write_text(_VIOLET_INTER_THEME)
    _build(tmp_path)
    cache_dir = tmp_path / '.pimadesp-cache'
    entries_before = list(cache_dir.iterdir())

    # Second build — clear outdir so sphinx rebuilds, but cache should stay
    import shutil
    shutil.rmtree(tmp_path / 'out')
    shutil.rmtree(tmp_path / 'doctrees')
    _build(tmp_path, theme_scss=_VIOLET_INTER_THEME)
    entries_after = list(cache_dir.iterdir())

    assert entries_before == entries_after  # same single cache entry, no new build


def test_component_partial_changes_hash(tmp_path):
    """A _header.scss in confdir produces a different hash than no partial."""
    from pimadesp.angular_build import _resolve_component_partials
    no_partial = _resolve_component_partials(str(tmp_path))
    (tmp_path / '_header.scss').write_text('.site-title { font-weight: 700; }')
    with_partial = _resolve_component_partials(str(tmp_path))
    assert _theme_hash('theme', no_partial) != _theme_hash('theme', with_partial)
