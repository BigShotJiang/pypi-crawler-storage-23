import pathlib
import socket
import subprocess
import time

import pytest


@pytest.fixture(scope="session")
def live_server(tmp_path_factory):
    procs = []
    cache = {}

    def _make_server(outdir):
        outdir = pathlib.Path(outdir)
        if outdir in cache:
            return cache[outdir]

        with socket.socket() as s:
            s.bind(("", 0))
            port = s.getsockname()[1]

        proc = subprocess.Popen(
            ["python", "-m", "http.server", str(port), "--directory", str(outdir)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        procs.append(proc)
        time.sleep(1)

        url = f"http://localhost:{port}"
        cache[outdir] = url
        return url

    yield _make_server

    for proc in procs:
        proc.terminate()
        proc.wait()
