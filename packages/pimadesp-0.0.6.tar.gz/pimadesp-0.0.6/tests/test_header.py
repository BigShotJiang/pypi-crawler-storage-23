import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_navigation(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        .. toctree::

           branch/index
    """))
    (srcdir / "branch").mkdir()
    (srcdir / "branch/index.rst").write_text(textwrap.dedent("""
        ======
        branch
        ======

        .. toctree::

           leaf
    """))
    (srcdir / "branch/leaf.rst").write_text(textwrap.dedent("""
        ====
        leaf
        ====
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)
    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.locator("button[aria-label='Open branch menu']").click()
    page.get_by_role("menuitem", name="Overview").click()
    expect(page.locator("h1")).to_contain_text("branch")
    page.locator("button[aria-label='Open branch menu']").click()
    page.get_by_role("menuitem", name="leaf").click()
    expect(page.locator("h1")).to_contain_text("leaf")
