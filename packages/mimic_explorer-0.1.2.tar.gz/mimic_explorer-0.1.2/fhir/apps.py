from django.apps import AppConfig


class FhirConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fhir'
    label = 'fhir_app'
