"""
版本号单一来源

发布时仅修改本文件中的 __version__。
"""

from __future__ import annotations

__version__ = "1.2.5"
