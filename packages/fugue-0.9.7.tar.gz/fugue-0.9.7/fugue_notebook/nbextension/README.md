# Fugue Notebook Extension

-   Add `%%fsql` magic to run Fugue SQL
-   Add Fugue SQL highlight in code cells for `%%fsql`
