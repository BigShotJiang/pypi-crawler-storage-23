# flake8: noqa
from fugue.extensions.processor.convert import (
    _to_processor,
    parse_processor,
    processor,
    register_processor,
)
from fugue.extensions.processor.processor import Processor
