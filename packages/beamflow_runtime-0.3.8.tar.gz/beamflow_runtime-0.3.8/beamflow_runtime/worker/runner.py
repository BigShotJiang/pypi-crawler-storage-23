import logging
import asyncio
from beamflow_lib.config.runtime_config import RuntimeConfig, BackendType
from beamflow_lib.queue.consumer import TaskConsumer

logger = logging.getLogger(__name__)

def build_worker_consumer(config: RuntimeConfig) -> TaskConsumer:
    """
    Build the appropriate TaskConsumer for the given configuration.
    """
    if config.backend.type == BackendType.DRAMATIQ:
        from .backends.dramatiq.dramatiq_consumer import DramatiqConsumer
        return DramatiqConsumer(config)
    elif config.backend.type == BackendType.MANAGED:
        from .backends.managed.managed_consumer import ManagedConsumer
        return ManagedConsumer(config)
    elif config.backend.type == BackendType.ASYNC:
        raise ValueError(
            "BackendType.ASYNC is for in-process execution and does not support "
            "a standalone worker process."
        )
    else:
        raise ValueError(f"Unsupported backend: {config.backend.type}")

async def run_worker(config: RuntimeConfig):
    """
    Unified entry point to start a worker process.
    """
    consumer = build_worker_consumer(config)
    
    logger.info(f"Starting worker with backend: {config.backend.type}")

    # Print registered tasks and consumers
    try:
        from beamflow_lib.queue.backend import get_backend
        from beamflow_lib.pipelines.consumer import get_registered_consumers
        
        logger.info("--- Registered Worker Endpoints ---")
        
        if config.backend.type == BackendType.DRAMATIQ:
            import dramatiq
            backend = get_backend()
            actors = dramatiq.get_broker().get_declared_actors()
            scheduled_jobs = backend.get_scheduled_jobs()
            sched_map = {job.scheduled_job_id: job.schedule for job in scheduled_jobs}
            
            job_count = len(list(actors))
            logger.info(f"Registered Tasks: ({job_count})")
            for actor in actors:
                underlying_fn = getattr(actor, 'fn', getattr(actor, '__call__', actor))
                fn_name = getattr(actor, 'actor_name', getattr(underlying_fn, '__name__', str(actor)))
                fn_mod = getattr(underlying_fn, '__module__', '')
                full_id = f"{fn_mod}.{getattr(underlying_fn, '__name__', fn_name)}"
                
                # Fetch schedule if exists
                schedule = sched_map.get(full_id)
                if not schedule:
                    for sid, sval in sched_map.items():
                        if fn_name in sid or sid.replace("scheduled:","") in full_id:
                            schedule = sval
                            break
                            
                sched_str = f" [Schedule: {schedule}]" if schedule else ""
                logger.info(f" - {fn_name}{sched_str}")
        
        feed_consumers = get_registered_consumers()
        if feed_consumers:
            logger.info(f"Registered Feed Consumers: ({len(feed_consumers)})")
            for fc in feed_consumers:
                batch_info = f" (Batching enabled, max: {fc.max_batch_size})" if fc.batch else ""
                logger.info(f" - Feed: {fc.feed_id} -> {fc.subscription_name}{batch_info}")
                
        logger.info("-----------------------------------")
    except Exception as e:
        logger.warning(f"Could not print tasks/consumers on startup: {e}")

    await consumer.start()
    
    # If the consumer didn't block (like Dramatiq), we wait here
    try:
        while True:
            await asyncio.sleep(3600)
    except asyncio.CancelledError:
        logger.info("Worker runner cancelled, stopping consumer...")
        await consumer.stop()
    except KeyboardInterrupt:
        logger.info("Interrupted, stopping consumer...")
        await consumer.stop()
