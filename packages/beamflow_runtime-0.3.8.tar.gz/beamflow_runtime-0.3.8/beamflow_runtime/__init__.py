"""
Framework Runtime - Pure glue around beamflow_lib.

This package provides:
- Ingress API helpers (FastAPI router generation from webhook registry)
- Worker bootstrap (Dramatiq broker configuration with context middleware)
- Queue backends (Dramatiq implementation moved from beamflow_lib)

Usage for Ingress API:
    from beamflow_runtime.ingress.app import create_fastapi_app
    from beamflow_lib.config.loader import load_runtime_config
    
    config = load_runtime_config("/path/to/config")
    app = create_fastapi_app(config)

Usage for Worker:
    from beamflow_runtime.worker.entrypoint import configure_worker_process
    from beamflow_lib.config.loader import load_runtime_config
    
    config = load_runtime_config("/path/to/config")
    runtime = configure_worker_process(config)
"""

# Main exports
from .wiring.runtime import Runtime, initialize_runtime, build_worker_runtime
from .ingress.app import create_fastapi_app
from .ingress.router import build_webhook_router
from .worker.runner import run_worker, build_worker_consumer

__all__ = [
    "Runtime",
    "initialize_runtime",
    
    "build_worker_runtime",
    "create_fastapi_app",
    "build_webhook_router",
    "run_worker",
    "build_worker_consumer",
]
