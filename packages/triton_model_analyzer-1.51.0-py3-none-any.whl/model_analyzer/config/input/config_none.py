#!/usr/bin/env python3

# Copyright 2021-2023, NVIDIA CORPORATION & AFFILIATES. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from model_analyzer.constants import CONFIG_PARSER_FAILURE

from .config_status import ConfigStatus
from .config_value import ConfigValue


class ConfigNone(ConfigValue):
    """
    A wrapper class for the primitive datatypes.
    """

    def __init__(
        self,
        preprocess=None,
        required=False,
        validator=None,
        output_mapper=None,
        name=None,
    ):
        """
        Parameters
        ----------
        preprocess : callable
            Function be called before setting new values.
        required : bool
            Whether a given config is required or not.
        validator : callable or None
            A validator for the value of the field.
        output_mapper: callable or None
            This callable unifies the output value of this field.
        name : str
            Fully qualified name for this field.
        """

        super().__init__(preprocess, required, validator, output_mapper, name)

        self._type = self._cli_type = type(None)
        self._value = None

    def set_value(self, value):
        """
        Set the value for this field.

        value : object
            The value for this field.
        """

        if value is None:
            return super().set_value(value)
        else:
            return ConfigStatus(
                CONFIG_PARSER_FAILURE,
                f'Value "{value}" for field "{self.name()}" should be None',
                self,
            )
