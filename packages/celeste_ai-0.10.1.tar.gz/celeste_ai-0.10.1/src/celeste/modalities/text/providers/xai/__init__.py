"""xAI provider for text modality."""

from .client import XAITextClient
from .models import MODELS

__all__ = ["MODELS", "XAITextClient"]
