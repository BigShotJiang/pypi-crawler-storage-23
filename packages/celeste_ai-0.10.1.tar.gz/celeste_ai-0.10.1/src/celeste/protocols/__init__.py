"""Protocol implementations for cross-provider API specifications."""
