"""Tests for celeste.utils module."""
