# Tasks: ci-hardening

## Test-first tasks
- [x] Add local validation for commitlint config presence.

## Implementation tasks
- [x] Add `.commitlintrc.yml`.
- [x] Add `.github/workflows/commitlint.yml`.
- [x] Update README with required CI checks.
