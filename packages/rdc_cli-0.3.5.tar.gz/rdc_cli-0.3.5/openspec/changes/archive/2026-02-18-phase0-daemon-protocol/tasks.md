# Tasks: phase0-daemon-protocol

## Test-first tasks
- [x] Add protocol unit tests.

## Implementation tasks
- [x] Add `src/rdc/protocol.py`.
- [x] Export helpers for `ping` / `shutdown` messages.
