# Tasks: AUR PKGBUILD

- [x] Research renderdoc cmake build options and dependencies
- [x] Write PKGBUILD with renderdoc Python module compilation
- [x] Add shell completion generation and installation
- [ ] Run namcap lint on PKGBUILD
- [ ] Test makepkg -s in clean environment
