# CLI Reference

::: mkdocs-click
    :module: rdc.cli
    :command: main
    :prog_name: rdc
    :style: table
    :depth: 1
