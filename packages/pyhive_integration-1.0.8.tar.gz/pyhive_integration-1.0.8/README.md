
![CodeQL](https://github.com/Pyhive/Pyhiveapi/workflows/CodeQL/badge.svg) ![Python Linting](https://github.com/Pyhive/Pyhiveapi/workflows/Python%20package/badge.svg)

# Important
The package name had to be changed and going forward the Pyhiveapi package should no longer be used. all the same code has been moved into a new package called [pyhive-integration](https://pypi.org/project/pyhive-integration/). Nothing changes in how the package functions its just a rename.

# Introduction
This is a library which interfaces with the Hive smart home platform. 
This library is built mainly to integrate with the Home Assistant platform,
but it can also be used independently (See examples below.)

NOTE:
This integration can only be used with the hive owner account guest accounts are currently not supported.


## Examples
Here are examples and documentation on how to use the library independently.

https://pyhass.github.io/pyhiveapi.docs/  [WIP]


