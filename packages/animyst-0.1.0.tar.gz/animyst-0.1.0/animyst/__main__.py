"""ANIMYST CLI entry point."""

from animyst.app import main

if __name__ == "__main__":
    main()
