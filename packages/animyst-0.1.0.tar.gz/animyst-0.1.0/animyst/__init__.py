"""ANIMYST — Breathe Life Into Code."""

__version__ = "0.1.0"
