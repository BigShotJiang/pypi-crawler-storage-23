# Riser Corporation SDK 🤖

Professional AI Assistant SDK that lets developers integrate voice, automation, and AI intelligence into their apps.

## 📦 Installation

```bash
pip install riser_corporation
# For voice support
pip install "riser_corporation[voice]"
```

## 🚀 Quick Start

```python
from riser_corporation.riser import riser

bot = riser.init(
    api_key="YOUR_KEY",
    ai_name="Jarvis",
    system_prompt="You are a futuristic assistant"
)

bot.speak("Hello boss")
bot.ask("Who created you?")
```

## 💻 CLI Usage

```bash
riser speak "Hello world"
```

## ✨ Features
* Custom AI name
* Custom system prompt
* User API key support
* Voice output
* Automation commands
* Easy SDK integration

## 👨‍💻 Developer Section
Build the package:
```bash
python -m build
```
Upload to PyPI:
```bash
twine upload dist/*
```

## 📜 License
MIT License
