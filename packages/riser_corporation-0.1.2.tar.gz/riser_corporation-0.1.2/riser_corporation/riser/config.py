from dotenv import load_dotenv
load_dotenv()

import os
import sys
from pathlib import Path

class Config:
    def __init__(self, api_key=None, ai_name="Riser", system_prompt="You are AI", prefixes=None, language="en-IN"):
        self.api_key = api_key or os.getenv("RISER_API_KEY") or os.getenv("OPENROUTER_API_KEY")
        self.ai_name = ai_name
        self.system_prompt = system_prompt
        self.prefixes = prefixes or {}
        self.language = language

        if not self.api_key:
            print("[WARNING] API key missing. Set RISER_API_KEY or OPENROUTER_API_KEY in .env")
