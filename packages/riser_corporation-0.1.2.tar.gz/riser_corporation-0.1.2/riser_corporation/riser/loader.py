import importlib.util
import sys
from pathlib import Path

def load_core(api_key=None, ai_name="AI", system_prompt="You are a helpful assistant.", log_callback=None, prefixes=None, language="en-IN"):
    core_path = Path(__file__).parent.parent / "core" / "main.py"

    spec = importlib.util.spec_from_file_location("core_engine", core_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["core_engine"] = module
    spec.loader.exec_module(module)

    if not hasattr(module, "Jarvis"):
        raise RuntimeError("Core must contain Jarvis class")

    obj = module.Jarvis(api_key=api_key, ai_name=ai_name, system_prompt=system_prompt, log_callback=log_callback, prefixes=prefixes, language=language)

    if not hasattr(obj, "speak"):
        raise RuntimeError("Jarvis class must implement speak()")

    return obj
