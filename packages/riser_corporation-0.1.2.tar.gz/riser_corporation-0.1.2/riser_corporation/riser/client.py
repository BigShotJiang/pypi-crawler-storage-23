import sys
import asyncio
from .loader import load_core
from .config import Config

class RiserClient:
    def __init__(self, config: Config, log_callback=None):
        self.config = config
        try:
            self.core = load_core(
                api_key=self.config.api_key,
                ai_name=self.config.ai_name,
                system_prompt=self.config.system_prompt,
                log_callback=log_callback,
                prefixes=self.config.prefixes,
                language=self.config.language
            )
        except Exception as e:
            print(f"[ERROR] Failed to load core engine: {e}")
            self.core = None

    def speak(self, text):
        if self.core and hasattr(self.core, 'speak'):
            # Check if speak is async
            import inspect
            if inspect.iscoroutinefunction(self.core.speak):
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        return asyncio.create_task(self.core.speak(text))
                    else:
                        return loop.run_until_complete(self.core.speak(text))
                except RuntimeError:
                    return asyncio.run(self.core.speak(text))
            else:
                return self.core.speak(text)
        else:
            print(f"Bot (Silent): {text}")

    def ask(self, text):
        if self.core and hasattr(self.core, 'get_ai_response'):
            prompt = self.config.system_prompt + "\nUser: " + text
            return self.core.get_ai_response(prompt)
        return "Core not loaded."

    def start(self):
        if self.core and hasattr(self.core, 'main_loop'):
            try:
                asyncio.run(self.core.main_loop())
            except KeyboardInterrupt:
                pass
        else:
            print("Core engine main loop not found.")

def main():
    if len(sys.argv) < 2:
        print("Usage: riser speak <text> | riser start | riser init")
        return

    cmd = sys.argv[1]
    
    if cmd == "init":
        with open("main.py", "w") as f:
            f.write("""import asyncio
from riser_corporation import riser

def my_custom_ui(message, msg_type):
    \"\"\"User can design their own terminal UI here\"\"\"
    colors = {
        "user": "\\033[94m",      # Blue
        "assistant": "\\033[92m", # Green
        "system": "\\033[93m",    # Yellow
        "error": "\\033[91m",     # Red
        "live": "\\033[90m"       # Grey
    }
    reset = "\\033[0m"
    color = colors.get(msg_type, reset)
    print(f"{color}{message}{reset}")

def run_my_ai():
    # 1. Customize Terminal Labels (Prefixes)
    my_labels = {
        "assistant": "[ENTER YOUR ASSISTANT NAME]:",
        "user": "[ENTER YOUR NAME]:",
        "system": "[CORE]:",
        "live": "Listening... (Press Ctrl+C to stop)"
    }

    # 2. Initialize AI Assistant
    bot = riser.init(
        api_key="ENTER YOUR API KEY HERE",
        ai_name="ENTER YOUR ASSISTANT NAME", 
        system_prompt="ENTER YOUR SYSTEM PROMPT HERE",
        log_callback=my_custom_ui, 
        prefixes=my_labels          
    )

    # 3. Start Assistant
    try:
        bot.start() 
    except KeyboardInterrupt:
        print("\\nTurning off. Goodbye!")

if __name__ == "__main__":
    run_my_ai()
""")
        print("[SUCCESS]: Created 'main.py' with the full recommended boilerplate. You can now edit and run it!")
        return

    cfg = Config()
    client = RiserClient(cfg)

    if cmd == "speak":
        text = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Hello"
        client.speak(text)
    elif cmd == "start":
        client.start()
    else:
        print(f"Unknown command: {cmd}")

if __name__ == "__main__":
    main()
