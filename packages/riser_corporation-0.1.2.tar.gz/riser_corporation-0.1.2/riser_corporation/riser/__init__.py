from .client import RiserClient
from .config import Config

# Direct function rakho, class ki zaroorat nahi hai agar sirf init hi karna hai
def init(api_key=None, ai_name="Riser", system_prompt="You are AI", log_callback=None, prefixes=None, language="en-IN"):
    """
    Initialize the Riser AI Assistant.
    
    COMPLETE BOILERPLATE CODE (Copy and Paste):
    ------------------------------------------
    import asyncio
    from riser_corporation import riser

    def my_custom_ui(message, msg_type):
        \"\"\"User can design their own terminal UI here\"\"\"
        colors = {
            "user": "\\033[94m",      # Blue
            "assistant": "\\033[92m", # Green
            "system": "\\033[93m",    # Yellow
            "error": "\\033[91m",     # Red
            "live": "\\033[90m"       # Grey
        }
        reset = "\\033[0m"
        color = colors.get(msg_type, reset)
        print(f"{color}{message}{reset}")

    def run_my_ai():
        # 1. Customize Terminal Labels (Prefixes)
        my_labels = {
            "assistant": "[ENTER YOUR ASSISTANT NAME]:",
            "user": "[ENTER YOUR NAME]:",
            "system": "[CORE]:",
            "live": "Listening... (Press Ctrl+C to stop)"
        }

        # 2. Initialize AI Assistant
        bot = riser.init(
            api_key="ENTER YOUR API KEY HERE",
            ai_name="ENTER YOUR ASSISTANT NAME", 
            system_prompt="ENTER YOUR SYSTEM PROMPT HERE",
            log_callback=my_custom_ui, 
            prefixes=my_labels          
        )

        # 3. Start Assistant
        try:
            bot.start() 
        except KeyboardInterrupt:
            print("\\nTurning off. Goodbye!")

    if __name__ == "__main__":
        run_my_ai()
    ------------------------------------------
    """
    cfg = Config(api_key, ai_name, system_prompt, prefixes=prefixes, language=language)
    return RiserClient(cfg, log_callback=log_callback)
