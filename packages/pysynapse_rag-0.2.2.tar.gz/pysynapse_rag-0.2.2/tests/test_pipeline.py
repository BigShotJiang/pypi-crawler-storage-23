"""
Integration tests for the full Pipeline using lightweight mocks.
Does not use real embedding models or ChromaDB to stay fast.
"""
import tempfile
from pathlib import Path
from collections.abc import AsyncGenerator

import pytest

from pysynapse.core.document import Document
from pysynapse.core.exceptions import EmbedderError
from pysynapse.pipeline.pipeline import Pipeline
from pysynapse.processors.chunker import RecursiveCharacterChunker


class FakeEmbedder:
    """Fake embedder: returns zero vectors."""

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.0] * 8 for _ in texts]

    async def embed_one(self, text: str) -> list[float]:
        return [0.0] * 8


class FakeStore:
    """Fake store: keeps documents in memory."""

    def __init__(self):
        self.documents: list[Document] = []
        self.embeddings: list[list[float]] = []

    async def add(self, documents, embeddings):
        self.documents.extend(documents)
        self.embeddings.extend(embeddings)

    async def search(self, query_embedding, k=5):
        return self.documents[:k]


class FakeTxtConnector:
    """Fake connector."""

    def __init__(self, texts: list[str]):
        self.texts = texts

    async def load(self) -> AsyncGenerator[Document, None]:
        for text in self.texts:
            yield Document(text=text, metadata={"source": "fake"})


@pytest.mark.asyncio
async def test_pipeline_run_returns_chunk_count():
    texts = ["A short text.", "Another text."]
    connector = FakeTxtConnector(texts)
    embedder = FakeEmbedder()
    store = FakeStore()
    chunker = RecursiveCharacterChunker(chunk_size=512, chunk_overlap=0)

    pipeline = Pipeline(connector=connector, embedder=embedder, store=store, chunker=chunker)
    count = await pipeline.run()

    assert count == 2
    assert len(store.documents) == 2


@pytest.mark.asyncio
async def test_pipeline_search_returns_documents():
    connector = FakeTxtConnector(["Test document for search."])
    embedder = FakeEmbedder()
    store = FakeStore()

    pipeline = Pipeline(connector=connector, embedder=embedder, store=store)
    await pipeline.run()

    results = await pipeline.search("test", k=1)
    assert len(results) >= 1


@pytest.mark.asyncio
async def test_pipeline_with_real_txt_connector():
    with tempfile.NamedTemporaryFile(
        suffix=".txt", mode="w", delete=False, encoding="utf-8"
    ) as f:
        f.write("This is a test document for pysynapse.\n\nIt contains multiple paragraphs.")
        tmp_path = Path(f.name)

    try:
        from pysynapse.connectors.document.txt import TxtConnector

        connector = TxtConnector(tmp_path)
        embedder = FakeEmbedder()
        store = FakeStore()

        pipeline = Pipeline(
            connector=connector,
            embedder=embedder,
            store=store,
            chunker=RecursiveCharacterChunker(chunk_size=50, chunk_overlap=0),
        )
        count = await pipeline.run()
        assert count >= 1
        assert len(store.documents) == count
    finally:
        tmp_path.unlink()


# ------------------------------------------------------------------ #
# Feature: progress callbacks                                          #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_on_progress_called_after_each_batch():
    texts = [f"Document number {i}." for i in range(5)]
    connector = FakeTxtConnector(texts)
    embedder = FakeEmbedder()
    store = FakeStore()

    progress_values: list[int] = []
    pipeline = Pipeline(
        connector=connector,
        embedder=embedder,
        store=store,
        batch_size=2,
        on_progress=lambda total: progress_values.append(total),
    )
    count = await pipeline.run()

    assert count == 5
    assert len(progress_values) >= 1
    # Values should be strictly increasing
    assert progress_values == sorted(progress_values)
    assert progress_values[-1] == count


# ------------------------------------------------------------------ #
# Feature: retry logic                                                 #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_retry_succeeds_after_transient_failure():
    """Embedder fails twice then succeeds — pipeline should complete."""
    call_count = 0

    class FlakyEmbedder:
        async def embed(self, texts):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise EmbedderError("transient failure")
            return [[0.0] * 8 for _ in texts]

        async def embed_one(self, text):
            return (await self.embed([text]))[0]

    connector = FakeTxtConnector(["Some text."])
    store = FakeStore()
    pipeline = Pipeline(
        connector=connector,
        embedder=FlakyEmbedder(),
        store=store,
        max_retries=3,
        retry_delay=0.0,  # no real delay in tests
    )
    count = await pipeline.run()
    assert count == 1


@pytest.mark.asyncio
async def test_retry_raises_after_max_retries_exceeded():
    """Embedder always fails — pipeline should raise EmbedderError."""

    class AlwaysFailEmbedder:
        async def embed(self, texts):
            raise EmbedderError("always fails")

        async def embed_one(self, text):
            raise EmbedderError("always fails")

    connector = FakeTxtConnector(["Some text."])
    store = FakeStore()
    pipeline = Pipeline(
        connector=connector,
        embedder=AlwaysFailEmbedder(),
        store=store,
        max_retries=2,
        retry_delay=0.0,
    )
    with pytest.raises(EmbedderError):
        await pipeline.run()


# ------------------------------------------------------------------ #
# Feature: context manager                                             #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_context_manager_closes_store():
    """store.close() must be called when exiting the context manager."""

    class CloseableStore(FakeStore):
        def __init__(self):
            super().__init__()
            self.closed = False

        def close(self):
            self.closed = True

    connector = FakeTxtConnector(["Hello world."])
    store = CloseableStore()

    async with Pipeline(connector=connector, embedder=FakeEmbedder(), store=store) as pipeline:
        await pipeline.run()

    assert store.closed


@pytest.mark.asyncio
async def test_context_manager_works_without_close_method():
    """Pipeline.__aexit__ must not crash if store has no close()."""
    connector = FakeTxtConnector(["Hello."])
    store = FakeStore()  # no close() method

    async with Pipeline(connector=connector, embedder=FakeEmbedder(), store=store) as pipeline:
        count = await pipeline.run()

    assert count == 1


# ------------------------------------------------------------------ #
# Feature: hybrid search (BM25 + vector)                              #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_hybrid_search_returns_k_results():
    pytest.importorskip("rank_bm25")

    texts = [
        "Python is a programming language.",
        "ChromaDB is a vector database.",
        "RAG combines retrieval and generation.",
        "Async programming is efficient.",
        "Machine learning powers AI systems.",
    ]
    connector = FakeTxtConnector(texts)
    store = FakeStore()
    pipeline = Pipeline(connector=connector, embedder=FakeEmbedder(), store=store)
    await pipeline.run()

    results = await pipeline.hybrid_search("Python programming", k=3)
    assert len(results) == 3


@pytest.mark.asyncio
async def test_hybrid_search_requires_run_first():
    pytest.importorskip("rank_bm25")

    connector = FakeTxtConnector(["Some doc."])
    store = FakeStore()
    pipeline = Pipeline(connector=connector, embedder=FakeEmbedder(), store=store)

    with pytest.raises(RuntimeError, match="run()"):
        await pipeline.hybrid_search("query")


# ------------------------------------------------------------------ #
# Feature: sync API                                                    #
# ------------------------------------------------------------------ #

def test_run_sync_returns_chunk_count():
    texts = ["A sync text.", "Another sync text."]
    connector = FakeTxtConnector(texts)
    store = FakeStore()

    pipeline = Pipeline(connector=connector, embedder=FakeEmbedder(), store=store)
    count = pipeline.run_sync()

    assert count == 2
    assert len(store.documents) == 2


def test_search_sync_returns_results():
    connector = FakeTxtConnector(["Sync search document."])
    store = FakeStore()

    pipeline = Pipeline(connector=connector, embedder=FakeEmbedder(), store=store)
    pipeline.run_sync()

    results = pipeline.search_sync("test", k=1)
    assert len(results) >= 1


def test_sync_context_manager_closes_store():
    class CloseableStore(FakeStore):
        def __init__(self):
            super().__init__()
            self.closed = False

        def close(self):
            self.closed = True

    connector = FakeTxtConnector(["Hello sync."])
    store = CloseableStore()

    with Pipeline(connector=connector, embedder=FakeEmbedder(), store=store) as pipeline:
        pipeline.run_sync()

    assert store.closed
