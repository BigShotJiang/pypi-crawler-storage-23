from collections.abc import AsyncGenerator
from typing import Any

from pydantic import BaseModel

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError, MissingDependencyError


class MongoDBConfig(BaseModel):
    uri: str
    database: str
    collection: str
    text_field: str
    metadata_fields: list[str] = []
    filter: dict[str, Any] = {}
    limit: int = 0  # 0 = no limit


class MongoDBConnector:
    """
    Async MongoDB connector via motor.

    Each document in the collection becomes a pysynapse Document.
    Requires: pip install pysynapse-rag[mongodb]
    """

    def __init__(self, config: MongoDBConfig) -> None:
        self.config = config
        try:
            import motor.motor_asyncio  # noqa: F401
        except ImportError as e:
            raise MissingDependencyError("motor", "mongodb") from e

    async def load(self) -> AsyncGenerator[Document, None]:
        import motor.motor_asyncio

        cfg = self.config
        client = motor.motor_asyncio.AsyncIOMotorClient(cfg.uri)
        try:
            collection = client[cfg.database][cfg.collection]

            # Projection: fetch only the needed fields
            projection: dict[str, int] = {"_id": 1, cfg.text_field: 1}
            for field in cfg.metadata_fields:
                projection[field] = 1

            cursor = collection.find(cfg.filter, projection)
            if cfg.limit:
                cursor = cursor.limit(cfg.limit)

            async for mongo_doc in cursor:
                text = str(mongo_doc.get(cfg.text_field, "") or "")
                if not text.strip():
                    continue

                meta: dict = {
                    "source": f"{cfg.database}.{cfg.collection}",
                    "mongo_id": str(mongo_doc.get("_id", "")),
                }
                for field in cfg.metadata_fields:
                    meta[field] = mongo_doc.get(field)

                yield Document(text=text, metadata=meta)
        except Exception as e:
            raise ConnectorError(
                f"MongoDB error on '{cfg.database}.{cfg.collection}': {e}"
            ) from e
        finally:
            client.close()
