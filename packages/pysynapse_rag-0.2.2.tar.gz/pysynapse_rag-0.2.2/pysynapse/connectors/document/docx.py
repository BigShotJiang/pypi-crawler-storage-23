import asyncio
from collections.abc import AsyncGenerator
from pathlib import Path

from pysynapse.connectors.document.base import BaseDocumentConnector
from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError, MissingDependencyError


class DocxConnector(BaseDocumentConnector):
    """
    Connector for Word documents (.docx).

    Requires: pip install pysynapse-rag[docx]
    """

    SUPPORTED_EXTENSIONS = frozenset({".docx"})

    def __init__(self, path: str | Path) -> None:
        super().__init__(path)
        try:
            import docx  # noqa: F401
        except ImportError as e:
            raise MissingDependencyError("python-docx", "docx") from e

    async def load(self) -> AsyncGenerator[Document, None]:
        loop = asyncio.get_event_loop()
        for file_path in self._iter_paths():
            try:
                doc = await loop.run_in_executor(None, self._read_docx, file_path)
            except Exception as e:
                raise ConnectorError(f"Error reading DOCX '{file_path}': {e}") from e
            if doc:
                yield doc

    def _read_docx(self, file_path: Path) -> Document | None:
        import docx

        doc = docx.Document(str(file_path))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = "\n\n".join(paragraphs)

        if not text.strip():
            return None

        core_props = doc.core_properties
        return Document(
            text=text,
            metadata={
                "source": str(file_path),
                "filename": file_path.name,
                "author": core_props.author or "",
                "title": core_props.title or "",
            },
        )
