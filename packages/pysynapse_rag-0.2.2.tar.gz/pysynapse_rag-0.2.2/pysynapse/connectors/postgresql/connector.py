from collections.abc import AsyncGenerator

from pydantic import BaseModel

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError, MissingDependencyError


class PostgreSQLConfig(BaseModel):
    dsn: str  # e.g. "postgresql://user:pass@localhost/mydb"
    table: str
    text_column: str
    metadata_columns: list[str] = []
    where_clause: str | None = None
    limit: int | None = None


class PostgreSQLConnector:
    """
    Async PostgreSQL connector via asyncpg.

    Each table row becomes a pysynapse Document.
    Requires: pip install pysynapse-rag[postgresql]
    """

    def __init__(self, config: PostgreSQLConfig) -> None:
        self.config = config
        try:
            import asyncpg  # noqa: F401
        except ImportError as e:
            raise MissingDependencyError("asyncpg", "postgresql") from e

    async def load(self) -> AsyncGenerator[Document, None]:
        import asyncpg

        cfg = self.config
        cols = [cfg.text_column] + cfg.metadata_columns
        cols_sql = ", ".join(f'"{c}"' for c in cols)
        query = f'SELECT {cols_sql} FROM "{cfg.table}"'
        if cfg.where_clause:
            query += f" WHERE {cfg.where_clause}"
        if cfg.limit:
            query += f" LIMIT {cfg.limit}"

        try:
            conn = await asyncpg.connect(cfg.dsn)
            try:
                async with conn.transaction():
                    async for row in conn.cursor(query):
                        row_dict = dict(row)
                        text = str(row_dict.pop(cfg.text_column, "") or "")
                        if not text.strip():
                            continue
                        meta = {
                            "source": cfg.dsn.split("@")[-1] if "@" in cfg.dsn else cfg.dsn,
                            "table": cfg.table,
                            **row_dict,
                        }
                        yield Document(text=text, metadata=meta)
            finally:
                await conn.close()
        except Exception as e:
            raise ConnectorError(f"PostgreSQL error on '{cfg.table}': {e}") from e
