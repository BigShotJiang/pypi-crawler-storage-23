# List all storage bins

List all storage binsAsk AI
