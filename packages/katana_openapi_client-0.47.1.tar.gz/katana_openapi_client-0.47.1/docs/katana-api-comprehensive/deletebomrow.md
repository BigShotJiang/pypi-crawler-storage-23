# Delete a BOM row

Delete a BOM rowAsk AI
