# Update a stock adjustment

Update a stock adjustmentAsk AI
