# Create a stocktake

Create a stocktakeAsk AI
