# The BOM row object

The BOM row objectAsk AI
