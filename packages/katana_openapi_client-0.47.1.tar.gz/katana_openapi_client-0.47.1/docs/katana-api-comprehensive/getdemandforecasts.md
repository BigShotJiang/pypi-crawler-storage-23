# List planned demand forecast for variant in location

List planned demand forecast for variant in locationAsk AI
