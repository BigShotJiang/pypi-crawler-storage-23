# Create a batch

posthttps://api.katanamrp.com/v1/batches
