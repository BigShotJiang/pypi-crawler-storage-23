# Update a price list customer

Update a price list customerAsk AI
