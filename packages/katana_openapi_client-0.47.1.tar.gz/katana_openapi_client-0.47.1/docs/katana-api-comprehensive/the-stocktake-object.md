# The stocktake object

The stocktake objectAsk AI
