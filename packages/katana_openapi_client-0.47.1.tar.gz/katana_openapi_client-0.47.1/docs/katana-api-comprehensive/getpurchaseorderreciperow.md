# Retrieve an outsourced purchase order recipe row

Retrieve an outsourced purchase order recipe rowAsk AI
