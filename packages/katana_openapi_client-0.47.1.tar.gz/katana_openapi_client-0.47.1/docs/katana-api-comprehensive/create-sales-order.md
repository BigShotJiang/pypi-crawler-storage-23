# Create a sales order

Create a sales orderAsk AI
