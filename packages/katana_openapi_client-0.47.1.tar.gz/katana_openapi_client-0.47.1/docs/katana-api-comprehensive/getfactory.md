# Retrieve the current factory

Retrieve the current factoryAsk AI
