# The customer object

The customer objectAsk AI
