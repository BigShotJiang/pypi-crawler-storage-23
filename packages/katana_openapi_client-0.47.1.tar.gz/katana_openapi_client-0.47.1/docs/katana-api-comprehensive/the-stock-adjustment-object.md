# The stock adjustment object

The stock adjustment objectAsk AI
