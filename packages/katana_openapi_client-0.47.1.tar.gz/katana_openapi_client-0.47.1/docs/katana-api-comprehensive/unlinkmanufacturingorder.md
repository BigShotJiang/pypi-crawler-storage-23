# Unlink a manufacturing order from sales order row

Unlink a manufacturing order from sales order rowAsk AI
