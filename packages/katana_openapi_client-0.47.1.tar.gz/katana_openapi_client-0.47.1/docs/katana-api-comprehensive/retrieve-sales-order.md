# Retrieve a sales order

Retrieve a sales orderAsk AI
