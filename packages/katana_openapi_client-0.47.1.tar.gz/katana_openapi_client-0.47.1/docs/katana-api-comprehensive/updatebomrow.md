# Update a BOM row

Update a BOM rowAsk AI
