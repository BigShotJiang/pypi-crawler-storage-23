# List all users

gethttps://api.katanamrp.com/v1/users
