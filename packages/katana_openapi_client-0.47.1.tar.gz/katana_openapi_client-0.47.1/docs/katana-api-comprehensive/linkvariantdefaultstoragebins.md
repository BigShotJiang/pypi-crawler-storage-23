# Link variant default storage bins

Link variant default storage binsAsk AI
