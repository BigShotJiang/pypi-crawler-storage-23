# Retrieve unassigned batch transactions for a sales return row

Retrieve unassigned batch transactions for a sales return rowAsk AI
