# The stocktake row object

The stocktake row objectAsk AI
