# Delete webhook

deletehttps://api.katanamrp.com/v1/webhooks/{id}
