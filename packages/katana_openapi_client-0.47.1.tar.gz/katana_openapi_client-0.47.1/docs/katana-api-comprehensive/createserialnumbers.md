# Assign serial numbers to a resource

Assign serial numbers to a resourceAsk AI
