# Update a manufacturing order recipe row

Update a manufacturing order recipe rowAsk AI
