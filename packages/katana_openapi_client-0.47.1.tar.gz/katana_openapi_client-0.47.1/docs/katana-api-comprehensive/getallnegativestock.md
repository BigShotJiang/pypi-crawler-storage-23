# List all variants with negative stock

List all variants with negative stockAsk AI
