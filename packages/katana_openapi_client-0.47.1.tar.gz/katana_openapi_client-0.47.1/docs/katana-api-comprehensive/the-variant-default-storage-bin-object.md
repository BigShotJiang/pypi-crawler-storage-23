# The variant default storage bin object

The variant default storage bin objectAsk AI
