# Delete a service

Delete a serviceAsk AI
