# The variant object

The variant objectAsk AI
