# Update a storage bin

Update a storage binAsk AI
