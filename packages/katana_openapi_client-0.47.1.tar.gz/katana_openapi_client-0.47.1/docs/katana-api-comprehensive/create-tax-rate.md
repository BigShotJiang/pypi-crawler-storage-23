# Create a tax rate

Create a tax rateAsk AI
