# Update a price list row

Update a price list rowAsk AI
