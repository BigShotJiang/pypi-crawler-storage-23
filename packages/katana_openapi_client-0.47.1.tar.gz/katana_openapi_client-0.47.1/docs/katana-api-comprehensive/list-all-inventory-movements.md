# List all inventory movements

List all inventory movementsAsk AI
