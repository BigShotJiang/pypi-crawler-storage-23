# The inventory object

The inventory objectAsk AI
