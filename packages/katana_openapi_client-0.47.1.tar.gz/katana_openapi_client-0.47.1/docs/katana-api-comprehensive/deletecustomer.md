# Delete a customer

Delete a customerAsk AI
