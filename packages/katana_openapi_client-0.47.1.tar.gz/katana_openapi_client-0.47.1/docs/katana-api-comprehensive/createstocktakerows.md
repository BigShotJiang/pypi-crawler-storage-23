# Create stocktake rows

Create stocktake rowsAsk AI
