# The sales order fulfillment object

The sales order fulfillment objectAsk AI
