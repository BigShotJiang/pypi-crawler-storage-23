# Create a customer

Create a customerAsk AI
