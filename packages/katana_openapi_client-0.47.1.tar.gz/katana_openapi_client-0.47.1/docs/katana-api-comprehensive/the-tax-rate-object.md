# The tax rate object

The tax rate objectAsk AI
