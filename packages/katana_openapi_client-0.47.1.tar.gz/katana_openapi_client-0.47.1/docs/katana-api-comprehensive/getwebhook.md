# Retrieve a webhook

Retrieve a webhookAsk AI
