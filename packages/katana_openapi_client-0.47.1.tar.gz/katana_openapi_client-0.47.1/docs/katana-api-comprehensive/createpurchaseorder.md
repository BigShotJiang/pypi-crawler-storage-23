# Create a purchase order

Create a purchase orderAsk AI
