# Retrieve a price list customer

Retrieve a price list customerAsk AI
