# List all stocktake rows

List all stocktake rowsAsk AI
