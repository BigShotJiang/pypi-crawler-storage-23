# Unassign serial numbers from a resource

Unassign serial numbers from a resourceAsk AI
