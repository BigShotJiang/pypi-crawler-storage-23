# Delete sales return row

Delete sales return rowAsk AI
