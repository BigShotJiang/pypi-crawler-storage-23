# Delete a stocktake row

Delete a stocktake rowAsk AI
