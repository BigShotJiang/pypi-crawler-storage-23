# Add planned demand forecast to variant.

Add planned demand forecast to variant.Ask AI
