# Create a BOM row

Create a BOM rowAsk AI
