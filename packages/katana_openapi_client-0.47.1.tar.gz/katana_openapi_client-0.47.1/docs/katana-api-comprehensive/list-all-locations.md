# List all locations

List all locationsAsk AI
