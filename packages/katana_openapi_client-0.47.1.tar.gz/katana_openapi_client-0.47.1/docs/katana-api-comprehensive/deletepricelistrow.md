# Delete price list row

Delete price list rowAsk AI
