# The storage bin object

The storage bin objectAsk AI
