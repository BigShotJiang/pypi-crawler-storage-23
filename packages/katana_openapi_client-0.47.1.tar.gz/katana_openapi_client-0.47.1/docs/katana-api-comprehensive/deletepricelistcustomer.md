# Delete a price list customer

Delete a price list customerAsk AI
