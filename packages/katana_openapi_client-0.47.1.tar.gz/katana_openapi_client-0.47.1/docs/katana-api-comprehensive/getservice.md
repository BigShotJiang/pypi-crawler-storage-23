# Retrieve a service

Retrieve a serviceAsk AI
