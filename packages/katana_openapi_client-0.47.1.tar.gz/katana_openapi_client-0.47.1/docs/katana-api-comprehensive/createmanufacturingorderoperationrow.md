# Create a manufacturing order operation row

Create a manufacturing order operation rowAsk AI
