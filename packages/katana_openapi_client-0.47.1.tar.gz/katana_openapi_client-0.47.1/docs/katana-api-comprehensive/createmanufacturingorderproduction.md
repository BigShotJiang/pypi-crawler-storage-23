# Create a manufacturing order production

Create a manufacturing order productionAsk AI
