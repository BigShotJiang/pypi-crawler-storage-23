# Delete a supplier

Delete a supplierAsk AI
