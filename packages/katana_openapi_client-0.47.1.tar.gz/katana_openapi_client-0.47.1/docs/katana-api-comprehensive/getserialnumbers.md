# Returns a list of serial numbers

Returns a list of serial numbersAsk AI
