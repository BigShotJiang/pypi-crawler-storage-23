# The sales return row object

The sales return row objectAsk AI
