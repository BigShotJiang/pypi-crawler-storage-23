# Deletes shipping fee, also removes it from attached sales order.

Deletes shipping fee, also removes it from attached sales order.Ask AI
