# Update a recipe row

Update a recipe rowAsk AI
