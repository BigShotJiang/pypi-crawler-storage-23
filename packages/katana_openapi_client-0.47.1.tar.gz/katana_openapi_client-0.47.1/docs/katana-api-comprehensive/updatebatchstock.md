# Update batch details

Update batch detailsAsk AI
