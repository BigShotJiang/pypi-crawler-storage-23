# Delete a stock adjustment

Delete a stock adjustmentAsk AI
