# Create a manufacturing order recipe row

Create a manufacturing order recipe rowAsk AI
