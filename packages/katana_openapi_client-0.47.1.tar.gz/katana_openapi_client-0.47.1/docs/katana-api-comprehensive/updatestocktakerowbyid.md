# Update a stocktake row

Update a stocktake rowAsk AI
