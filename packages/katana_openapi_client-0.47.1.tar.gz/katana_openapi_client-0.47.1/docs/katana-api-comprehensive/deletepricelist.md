# Delete a price list

Delete a price listAsk AI
