# Creates a sales order shipping fee and add it to sales order

Creates a sales order shipping fee and add it to sales orderAsk AI
