# Update a price list

Update a price listAsk AI
