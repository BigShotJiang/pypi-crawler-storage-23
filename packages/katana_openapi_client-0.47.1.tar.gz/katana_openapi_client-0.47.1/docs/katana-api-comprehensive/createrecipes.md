# Create recipes

postdeprecatedhttps://api.katanamrp.com/v1/recipes
