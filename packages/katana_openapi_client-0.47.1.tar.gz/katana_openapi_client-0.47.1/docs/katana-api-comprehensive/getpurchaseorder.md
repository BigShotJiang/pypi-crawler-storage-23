# Retrieve a purchase order

Retrieve a purchase orderAsk AI
