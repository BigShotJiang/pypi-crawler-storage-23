# Delete a variant

Delete a variantAsk AI
