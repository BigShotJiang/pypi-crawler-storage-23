# List current batch stock

List current batch stockAsk AI
