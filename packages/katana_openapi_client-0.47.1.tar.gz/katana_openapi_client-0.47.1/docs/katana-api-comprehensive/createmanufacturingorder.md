# Create a manufacturing order

Create a manufacturing orderAsk AI
