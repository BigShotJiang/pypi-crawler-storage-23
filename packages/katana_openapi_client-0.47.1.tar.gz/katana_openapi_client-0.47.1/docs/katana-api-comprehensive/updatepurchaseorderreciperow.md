# Update an outsourced purchase order recipe row

Update an outsourced purchase order recipe rowAsk AI
