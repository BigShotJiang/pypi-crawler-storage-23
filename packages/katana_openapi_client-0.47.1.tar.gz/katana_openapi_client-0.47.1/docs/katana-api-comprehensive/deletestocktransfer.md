# Delete a stock transfer

Delete a stock transferAsk AI
