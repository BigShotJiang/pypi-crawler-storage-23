# Delete sales order row

Delete sales order rowAsk AI
