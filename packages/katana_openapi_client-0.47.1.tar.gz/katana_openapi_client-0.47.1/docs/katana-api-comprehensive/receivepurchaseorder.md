# Receive a purchase order

Receive a purchase orderAsk AI
