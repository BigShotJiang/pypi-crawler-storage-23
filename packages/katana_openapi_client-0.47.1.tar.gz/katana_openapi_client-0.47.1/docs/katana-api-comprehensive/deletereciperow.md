# Delete a recipe row

Delete a recipe rowAsk AI
