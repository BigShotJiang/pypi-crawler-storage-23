# List current inventory

List current inventoryAsk AI
