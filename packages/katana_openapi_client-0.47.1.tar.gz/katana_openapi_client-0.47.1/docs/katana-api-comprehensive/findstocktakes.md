# List all stocktakes

List all stocktakesAsk AI
