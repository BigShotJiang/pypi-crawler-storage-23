# Delete a material

Delete a materialAsk AI
