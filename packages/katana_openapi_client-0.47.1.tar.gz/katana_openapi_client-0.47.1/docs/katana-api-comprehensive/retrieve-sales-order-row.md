# Retrieve a sales order row

Retrieve a sales order rowAsk AI
