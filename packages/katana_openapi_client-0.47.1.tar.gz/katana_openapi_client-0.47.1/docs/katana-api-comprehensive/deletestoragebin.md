# Delete a storage bin

Delete a storage binAsk AI
