# Retrieve a sales return row

Retrieve a sales return rowAsk AI
