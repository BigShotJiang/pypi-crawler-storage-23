# Create many BOM rows

Create many BOM rowsAsk AI
