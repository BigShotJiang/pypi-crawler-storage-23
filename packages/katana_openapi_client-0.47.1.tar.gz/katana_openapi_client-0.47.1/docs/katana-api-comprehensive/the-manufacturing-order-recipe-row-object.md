# The manufacturing order recipe row object

The manufacturing order recipe row objectAsk AI
