# The manufacturing order operation row object

The manufacturing order operation row objectAsk AI
