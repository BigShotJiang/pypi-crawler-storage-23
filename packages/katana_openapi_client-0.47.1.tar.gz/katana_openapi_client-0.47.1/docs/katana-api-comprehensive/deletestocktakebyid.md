# Delete a stocktake

Delete a stocktakeAsk AI
