# The recipe / BOM object

The recipe / BOM objectAsk AI
