# The manufacturing order object

The manufacturing order objectAsk AI
