# Create a stock adjustment

Create a stock adjustmentAsk AI
