# Update a stocktake

Update a stocktakeAsk AI
