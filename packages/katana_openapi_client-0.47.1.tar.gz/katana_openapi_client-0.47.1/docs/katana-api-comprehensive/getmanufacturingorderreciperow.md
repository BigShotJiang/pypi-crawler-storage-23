# Retrieve a manufacturing order recipe row

Retrieve a manufacturing order recipe rowAsk AI
