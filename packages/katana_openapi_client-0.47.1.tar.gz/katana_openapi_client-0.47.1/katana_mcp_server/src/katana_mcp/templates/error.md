# ❌ Error

**Operation**: {operation} **Error Type**: {error_type}

## Error Message

{error_message}

## Details

{error_details}

## What You Can Do

{suggested_actions}

______________________________________________________________________

**Status**: Operation failed - please review and try again
