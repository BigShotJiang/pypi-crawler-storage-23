# Purchase Order Verification - Partial Match

**Order ID**: {order_id}
**Verification Status**: Discrepancies found

## Summary

- **Overall Status**: {overall_status}
- **Message**: {message}

## Matches

{matches_text}

## Discrepancies

{discrepancies_text}

## Next Steps

{suggested_actions_text}

______________________________________________________________________

**Status**: Review required before receiving
