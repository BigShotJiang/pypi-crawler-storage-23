<!-- markdownlint-disable-next-line MD041 -->
--8<-- "README.md"
