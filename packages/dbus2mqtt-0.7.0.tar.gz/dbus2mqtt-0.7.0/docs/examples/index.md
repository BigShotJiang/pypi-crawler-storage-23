# Examples

Examples work better than large amounts of documentation and puzzling everything together. Feel free to use these examples as-is or adapt them to your own likening.

Each example comes with a dbus2mqtt configuration file and corresponding documentation.

* [MPRIS to Home Assistant Media Player integration](home_assistant_media_player.md)
* [BlueZ](bluez.md)
* [Publish dbus2mqtt internal state](dbus2mqtt_internal_state.md)
