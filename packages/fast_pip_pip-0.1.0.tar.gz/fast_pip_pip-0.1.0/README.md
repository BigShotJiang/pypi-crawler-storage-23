# FastAPI Clean Architecture Generator

Генератор проектов FastAPI с вашей архитектурой

## Установка

```bash
pip install -e .