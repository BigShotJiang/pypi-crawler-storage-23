# CRon 🎙️

Générateur automatique de comptes rendus de réunion.

## Installation

```bash
pip install -e .
# La commande cr est maintenant disponible partout.
```

## Usage

```bash
cr config           # config initiale (clés API) — à faire une seule fois
cr                  # enregistre le micro → transcrit → génère le CR
cr -f réunion.mp3  # depuis un fichier audio
cr -y              # mode non-interactif (zéro confirmations)
cr transcribe -f audio.mp3     # transcription seule
cr generate -f notes.txt       # génère un CR depuis un texte
cr --help
```

## Config

Stockée dans `~/.config/cron-cr/config.json`.
Fichier de suivi par défaut : `~/compte_rendus.md`.

## Whisper local (optionnel)

```bash
pip install openai-whisper torch
# puis dans cr config : whisper_mode = local
```
