"""
Pyodide Game Coordinator for Multiplayer Support

Coordinates client-side Pyodide games by:
- Generating shared RNG seeds for determinism
- Collecting and broadcasting player actions
- Verifying state synchronization across clients
- Assigning player IDs to symmetric peers
"""

from __future__ import annotations

import dataclasses
import logging
import random
import threading
import time
from typing import Any, Dict

import eventlet
import flask_socketio

logger = logging.getLogger(__name__)
# Add console handler to see pyodide_game_coordinator logs
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
    logger.addHandler(_handler)
    logger.setLevel(logging.INFO)


@dataclasses.dataclass
class PyodideGameState:
    """State for a single Pyodide multiplayer game."""

    game_id: str
    players: dict[str | int, str]  # player_id -> socket_id
    player_subjects: dict[str | int, str]  # player_id -> subject_id (participant name)
    frame_number: int
    is_active: bool
    rng_seed: int  # Shared seed for deterministic AI
    num_expected_players: int
    action_timeout_seconds: float
    created_at: float

    # Diagnostics for lag tracking
    last_action_times: dict[str | int, float] = dataclasses.field(default_factory=dict)
    action_delays: dict[str | int, list] = dataclasses.field(default_factory=dict)
    last_diagnostics_log: float = 0.0

    # WebRTC TURN configuration
    turn_username: str | None = None
    turn_credential: str | None = None
    force_turn_relay: bool = False

    # P2P validation state (Phase 19)
    p2p_validation_enabled: bool = True
    p2p_validation_timeout_s: float = 10.0
    p2p_validated_players: set = dataclasses.field(default_factory=set)

    # Scene metadata for client configuration
    scene_metadata: dict = dataclasses.field(default_factory=dict)
    validation_start_time: float | None = None

    # Mid-game reconnection state (Phase 20)
    reconnection_in_progress: bool = False
    reconnection_start_time: float | None = None
    reconnection_timeout_s: float = 5.0  # Configurable (RECON-04)
    reconnection_lost_players: set = dataclasses.field(default_factory=set)
    reconnection_recovered_players: set = dataclasses.field(default_factory=set)
    total_pause_duration_ms: float = 0.0

    # Track disconnected player ID (Phase 23)
    disconnected_player_id: str | int | None = None


class PyodideGameCoordinator:
    """
    Coordinates multiplayer Pyodide games.

    Key responsibilities:
    1. Generate and distribute shared RNG seeds
    2. Collect actions from all players each frame
    3. Broadcast actions when all received (or timeout)
    4. Verify state synchronization periodically
    5. Assign player IDs to symmetric peers
    """

    def __init__(self, socketio: flask_socketio.SocketIO, game_manager_getter: callable = None):
        self.socketio = socketio
        self.games: dict[str, PyodideGameState] = {}
        self.lock = threading.Lock()
        self.get_game_manager = game_manager_getter  # Returns GameManager for a game_id

        # Configuration
        self.action_timeout = 5.0  # Seconds to wait for actions
        self.max_games = 1000  # Prevent memory exhaustion

        # Statistics
        self.total_games_created = 0
        self.total_desyncs_detected = 0

        logger.info("PyodideGameCoordinator initialized")

    def create_game(
        self,
        game_id: str,
        num_players: int,
        # WebRTC TURN configuration
        turn_username: str | None = None,
        turn_credential: str | None = None,
        force_turn_relay: bool = False,
        # Scene metadata for client config
        scene_metadata: dict | None = None,
    ) -> PyodideGameState:
        """
        Initialize a new Pyodide multiplayer game.

        Args:
            game_id: Unique identifier for the game
            num_players: Expected number of human players

        Returns:
            PyodideGameState object

        Raises:
            ValueError: If max games exceeded
        """
        with self.lock:
            if len(self.games) >= self.max_games:
                raise ValueError(f"Maximum games ({self.max_games}) exceeded")

            # Generate seed using Python's random (server-side)
            rng_seed = random.randint(0, 2**32 - 1)

            game_state = PyodideGameState(
                game_id=game_id,
                players={},
                player_subjects={},  # player_id -> subject_id mapping
                frame_number=0,
                is_active=False,
                rng_seed=rng_seed,
                num_expected_players=num_players,
                action_timeout_seconds=self.action_timeout,
                created_at=time.time(),
                turn_username=turn_username,
                turn_credential=turn_credential,
                force_turn_relay=force_turn_relay,
                scene_metadata=scene_metadata or {},
            )

            self.games[game_id] = game_state
            self.total_games_created += 1

            logger.info(
                f"Created Pyodide game {game_id} for {num_players} players "
                f"with seed {rng_seed}"
            )

            return game_state

    def add_player(
        self,
        game_id: str,
        player_id: str | int,
        socket_id: str,
        subject_id: str | None = None
    ):
        """
        Add a player to the game.

        All players are symmetric peers - no host/client distinction.

        Args:
            game_id: Game identifier
            player_id: Player identifier (0, 1, 2, ...)
            socket_id: Player's socket connection ID
            subject_id: Subject/participant identifier (for data logging)
        """
        # Collect emit data while holding lock, emit outside to avoid deadlock
        emit_assigned_data = None
        start_game_data = None

        with self.lock:
            if game_id not in self.games:
                logger.error(f"Attempted to add player to non-existent game {game_id}")
                return

            game = self.games[game_id]
            game.players[player_id] = socket_id
            if subject_id is not None:
                game.player_subjects[player_id] = subject_id

            # Prepare player assignment data (emit later outside lock)
            emit_assigned_data = {
                'socket_id': socket_id,
                'payload': {
                    'player_id': player_id,
                    'game_id': game_id,
                    'game_seed': game.rng_seed,
                    'num_players': game.num_expected_players
                }
            }

            logger.info(
                f"Player {player_id} assigned to game {game_id} "
                f"(seed: {game.rng_seed})"
            )

            # Check if game is ready to start
            if len(game.players) == game.num_expected_players:
                start_game_data = self._prepare_start_game(game_id)

        # Emit OUTSIDE the lock to avoid eventlet deadlock
        if emit_assigned_data:
            self.socketio.emit('pyodide_player_assigned',
                         emit_assigned_data['payload'],
                         room=emit_assigned_data['socket_id'])

        if start_game_data:
            self._execute_start_game(start_game_data)

    def _prepare_start_game(self, game_id: str) -> dict:
        """Prepare game start data while holding lock. Returns data for later emit.

        Must be called while holding self.lock.
        """
        game = self.games[game_id]
        game.is_active = True

        # Transition ServerGame to PLAYING
        if self.get_game_manager:
            gm = self.get_game_manager(game_id)
            if gm:
                remote_game = gm.games.get(game_id)
                if remote_game:
                    from mug.server.remote_game import SessionState
                    remote_game.transition_to(SessionState.PLAYING)

        logger.info(
            f"Emitting pyodide_game_ready to room {game_id} with players {list(game.players.keys())}"
        )

        # Return data for emit outside lock
        return {
            'game_id': game_id,
            'emit_payload': {
                'game_id': game_id,
                'players': list(game.players.keys()),
                'player_subjects': dict(game.player_subjects),  # Copy to avoid concurrent modification
                # Include TURN config only if credentials are provided
                'turn_config': {
                    'username': game.turn_username,
                    'credential': game.turn_credential,
                    'force_relay': game.force_turn_relay,
                } if game.turn_username else None,
                # Include scene metadata for client configuration
                'scene_metadata': dict(game.scene_metadata) if game.scene_metadata else {},
            },
            'num_players': len(game.players),
        }

    def _execute_start_game(self, start_data: dict):
        """Execute game start emits and runner startup. Called outside lock."""
        game_id = start_data['game_id']

        # Emit game ready event
        self.socketio.emit('pyodide_game_ready', start_data['emit_payload'], room=game_id)

        logger.info(
            f"Game {game_id} started with {start_data['num_players']} players"
        )

    def receive_action(
        self,
        game_id: str,
        player_id: str | int,
        action: Any,
        frame_number: int,
        client_timestamp: float | None = None,
    ):
        """
        Receive action from a player and broadcast to others immediately.

        Action Queue approach: No waiting for all players. Each action is
        immediately relayed to other clients who queue it for their next step.

        Args:
            game_id: Game identifier
            player_id: Player who sent the action
            action: The action value (int, dict, etc.)
            frame_number: Frame number (for logging/debugging)
            client_timestamp: Client-side timestamp when action was sent (for lag tracking)
        """
        with self.lock:
            if game_id not in self.games:
                logger.warning(f"Action received for non-existent game {game_id}")
                return

            game = self.games[game_id]

            if not game.is_active:
                logger.warning(f"Action received for inactive game {game_id}")
                return

            # Track timing for diagnostics
            now = time.time()
            player_id_str = str(player_id)

            # Calculate inter-action delay for this player
            if player_id_str in game.last_action_times:
                delay = now - game.last_action_times[player_id_str]
                if player_id_str not in game.action_delays:
                    game.action_delays[player_id_str] = []
                game.action_delays[player_id_str].append(delay)
                # Keep only last 50 measurements
                if len(game.action_delays[player_id_str]) > 50:
                    game.action_delays[player_id_str].pop(0)

            game.last_action_times[player_id_str] = now

            # Log diagnostics periodically (every 5 seconds)
            if now - game.last_diagnostics_log > 5.0:
                self._log_game_diagnostics(game)
                game.last_diagnostics_log = now

            # Log frame info for debugging
            logger.debug(
                f"Game {game_id}: Received action {action} from player {player_id} "
                f"at frame {frame_number}"
            )

            # Broadcast to ALL OTHER players immediately (Action Queue approach)
            for other_player_id, socket_id in game.players.items():
                if other_player_id != player_id:
                    self.socketio.emit('pyodide_other_player_action', {
                        'player_id': player_id,
                        'action': action,
                        'frame_number': frame_number,
                        'timestamp': time.time()
                    }, room=socket_id)

            logger.debug(
                f"Game {game_id}: Relayed action from player {player_id} "
                f"to {len(game.players) - 1} other player(s)"
            )

    def remove_player(self, game_id: str, player_id: str | int, notify_others: bool = True, reason: str = 'partner_disconnected'):
        """
        Handle player disconnection.

        If all players disconnect, remove game.
        Notifies remaining players that the game has ended.

        Args:
            game_id: Game identifier
            player_id: Player who disconnected
            notify_others: Whether to notify remaining players (default True)
        """
        # Collect data while holding lock, then emit outside lock to avoid deadlock
        sockets_to_notify = []
        should_notify = False

        with self.lock:
            if game_id not in self.games:
                return

            game = self.games[game_id]

            if player_id not in game.players:
                return

            # Get remaining player sockets before removing the disconnected player
            remaining_player_sockets = [
                socket_id for pid, socket_id in game.players.items()
                if pid != player_id
            ]

            del game.players[player_id]

            logger.info(f"Player {player_id} disconnected from game {game_id}")

            # Determine if we should notify (collect data, don't emit yet)
            if notify_others and len(remaining_player_sockets) > 0:
                should_notify = True
                sockets_to_notify = remaining_player_sockets[:]  # Copy list
                logger.info(
                    f"Notifying {len(remaining_player_sockets)} remaining players "
                    f"about disconnection in game {game_id}"
                )

            # If no players left, remove game
            if len(game.players) == 0:
                del self.games[game_id]
                logger.info(f"Removed empty game {game_id}")
            # If there are remaining players, also remove the game since we ended it
            elif notify_others:
                del self.games[game_id]
                logger.info(f"Removed game {game_id} after player disconnection")

        # Emit OUTSIDE the lock to avoid eventlet deadlock
        if should_notify:
            for socket_id in sockets_to_notify:
                # Emit p2p_game_ended so client handles with proper overlay and completion code
                self.socketio.emit(
                    'p2p_game_ended',
                    {
                        'game_id': game_id,
                        'reason': reason,
                        'disconnected_player_id': player_id
                    },
                    room=socket_id
                )

    def _log_game_diagnostics(self, game: PyodideGameState):
        """
        Log diagnostics for a game to help identify lag sources.

        Tracks:
        - Inter-action delay per player (time between actions from same player)
        - Frame number disparity between server runner and clients
        """
        diagnostics = []

        # Calculate average inter-action delay per player
        for player_id, delays in game.action_delays.items():
            if delays:
                avg_delay = sum(delays) / len(delays)
                max_delay = max(delays)
                min_delay = min(delays)
                diagnostics.append(
                    f"Player {player_id}: avg={avg_delay*1000:.1f}ms, "
                    f"max={max_delay*1000:.1f}ms, min={min_delay*1000:.1f}ms"
                )

        if diagnostics:
            logger.info(
                f"[Diagnostics] Game {game.game_id} - " +
                " | ".join(diagnostics)
            )

        # Warn if there's significant disparity in action rates
        if len(game.action_delays) >= 2:
            avg_delays = {
                pid: sum(delays) / len(delays) if delays else 0
                for pid, delays in game.action_delays.items()
            }
            if avg_delays:
                min_avg = min(avg_delays.values())
                max_avg = max(avg_delays.values())
                if min_avg > 0 and max_avg / min_avg > 1.5:
                    logger.warning(
                        f"[Diagnostics] Game {game.game_id}: Action rate disparity detected! "
                        f"Fastest player: {min_avg*1000:.1f}ms avg, "
                        f"Slowest player: {max_avg*1000:.1f}ms avg. "
                        f"This may cause queue buildup and lag."
                    )

    def handle_webrtc_signal(
        self,
        game_id: str,
        target_player_id: str | int,
        signal_type: str,
        payload: Any,
        sender_socket_id: str,
    ):
        """
        Relay WebRTC signaling messages between peers.

        Routes SDP offers/answers and ICE candidates from one player to another
        without inspecting or modifying the payload.

        Args:
            game_id: Game identifier
            target_player_id: Player ID to receive the signal
            signal_type: Type of signal (offer, answer, ice-candidate)
            payload: The signaling payload (SDP or ICE candidate)
            sender_socket_id: Socket ID of the sender (for reverse lookup)
        """
        with self.lock:
            if game_id not in self.games:
                logger.warning(
                    f"WebRTC signal for unknown game {game_id}"
                )
                return

            game = self.games[game_id]

            # Find target player's socket
            target_socket = game.players.get(target_player_id)
            if target_socket is None:
                # Try with string/int conversion
                target_socket = game.players.get(str(target_player_id))
                if target_socket is None:
                    target_socket = game.players.get(int(target_player_id) if isinstance(target_player_id, str) and target_player_id.isdigit() else target_player_id)
                if target_socket is None:
                    logger.warning(
                        f"WebRTC signal for unknown player {target_player_id} in game {game_id}"
                    )
                    return

            # Find sender's player ID by reverse lookup
            sender_player_id = None
            for player_id, socket_id in game.players.items():
                if socket_id == sender_socket_id:
                    sender_player_id = player_id
                    break

            if sender_player_id is None:
                logger.warning(
                    f"WebRTC signal from unknown socket {sender_socket_id} in game {game_id}"
                )
                return

            # Relay the signal to target peer
            self.socketio.emit(
                'webrtc_signal',
                {
                    'type': signal_type,
                    'from_player_id': sender_player_id,
                    'game_id': game_id,
                    'payload': payload,
                },
                room=target_socket,
            )

            logger.debug(
                f"Relayed WebRTC {signal_type} from player {sender_player_id} "
                f"to player {target_player_id} in game {game_id}"
            )

    def handle_player_exclusion(
        self,
        game_id: str,
        excluded_player_id: str | int,
        reason: str,
        frame_number: int
    ):
        """
        Handle player exclusion from continuous monitoring.

        Notifies partner with clear message, triggers data export,
        and cleans up game state.

        Args:
            game_id: Game identifier
            excluded_player_id: ID of excluded player
            reason: Exclusion reason ('sustained_ping', 'tab_hidden')
            frame_number: Frame number when exclusion occurred
        """
        with self.lock:
            if game_id not in self.games:
                logger.warning(f"Exclusion for non-existent game {game_id}")
                return

            game = self.games[game_id]

            if excluded_player_id not in game.players:
                logger.warning(
                    f"Excluded player {excluded_player_id} not in game {game_id}"
                )
                return

            # Find partner socket(s) before any cleanup
            partner_sockets = [
                socket_id for pid, socket_id in game.players.items()
                if pid != excluded_player_id
            ]

            # Notify partner(s) with clear, non-alarming message
            for socket_id in partner_sockets:
                self.socketio.emit(
                    'partner_excluded',
                    {
                        'message': 'Your partner experienced a technical issue. The game has ended.',
                        'frame_number': frame_number,
                        'reason': 'partner_exclusion'
                    },
                    room=socket_id
                )

                # Trigger data export for partner before cleanup
                self.socketio.emit(
                    'trigger_data_export',
                    {
                        'is_partial': True,
                        'termination_reason': 'partner_exclusion',
                        'termination_frame': frame_number
                    },
                    room=socket_id
                )

            logger.info(
                f"Notified {len(partner_sockets)} partner(s) of exclusion "
                f"in game {game_id}"
            )

            # Brief delay to ensure messages are delivered
            eventlet.sleep(0.1)

            # Now clean up the game
            del self.games[game_id]
            logger.info(f"Cleaned up game {game_id} after player exclusion")

    def start_validation(self, game_id: str) -> bool:
        """Mark validation phase started for a game (Phase 19)."""
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                return False

            game.validation_start_time = time.time()
            game.p2p_validated_players = set()

            # Transition ServerGame to VALIDATING if we have access
            if self.get_game_manager:
                gm = self.get_game_manager(game_id)
                if gm:
                    remote_game = gm.games.get(game_id)
                    if remote_game:
                        from mug.server.remote_game import SessionState
                        remote_game.transition_to(SessionState.VALIDATING)

            logger.info(f"P2P validation started for game {game_id}")
            return True

    def record_validation_success(self, game_id: str, player_id: str | int) -> str | None:
        """
        Record that a player validated their P2P connection (Phase 19).

        Returns:
            'complete' if all players validated
            'waiting' if still waiting for other players
            None if game not found
        """
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                logger.warning(f"Validation success for non-existent game {game_id}")
                return None

            game.p2p_validated_players.add(str(player_id))
            logger.info(
                f"Player {player_id} validated P2P in game {game_id} "
                f"({len(game.p2p_validated_players)}/{game.num_expected_players})"
            )

            # Check if all players validated
            if len(game.p2p_validated_players) >= game.num_expected_players:
                return 'complete'
            return 'waiting'

    def handle_validation_failure(self, game_id: str, player_id: str | int, reason: str) -> list:
        """
        Handle P2P validation failure - prepare for re-pool (Phase 19).

        Returns list of socket_ids that need to be notified for re-pool.
        Game is NOT removed yet - caller should emit events first.
        """
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                logger.warning(f"Validation failure for non-existent game {game_id}")
                return []

            logger.warning(
                f"P2P validation failed for game {game_id}, "
                f"player {player_id}: {reason}"
            )

            # Return all player socket_ids for notification
            return list(game.players.values())

    def remove_game(self, game_id: str) -> None:
        """Remove a game from the coordinator (Phase 19)."""
        with self.lock:
            if game_id in self.games:
                del self.games[game_id]
                logger.info(f"Removed game {game_id} from coordinator")

    def get_stats(self) -> dict:
        """Get coordinator statistics for monitoring/debugging."""
        return {
            'active_games': len(self.games),
            'total_games_created': self.total_games_created,
            'total_desyncs_detected': self.total_desyncs_detected,
        }

    # ========== Mid-Game Reconnection Methods (Phase 20) ==========

    def handle_connection_lost(
        self, game_id: str, player_id: str | int, frame_number: int
    ) -> str | None:
        """
        Handle P2P connection loss from a client (Phase 20 - RECON-01, RECON-02).

        Args:
            game_id: Game identifier
            player_id: Player who detected the disconnection
            frame_number: Frame number when disconnection detected

        Returns:
            'pause' if this triggers bilateral pause
            'already_pausing' if reconnection already in progress
            None if game not found
        """
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                logger.warning(f"Connection lost for non-existent game {game_id}")
                return None

            game.reconnection_lost_players.add(str(player_id))

            # Track which player disconnected (Phase 23 - DATA-04)
            # The player who reports the loss DETECTED it, so the OTHER player disconnected
            if game.disconnected_player_id is None:
                for pid in game.players:
                    if str(pid) != str(player_id):
                        game.disconnected_player_id = pid
                        logger.info(f"Disconnected player identified: {pid}")
                        break

            if not game.reconnection_in_progress:
                game.reconnection_in_progress = True
                game.reconnection_start_time = time.time()
                game.reconnection_recovered_players = set()

                logger.info(
                    f"P2P reconnection started for game {game_id} "
                    f"(detected by player {player_id} at frame {frame_number})"
                )
                return 'pause'

            logger.debug(
                f"Player {player_id} also detected disconnection in game {game_id}"
            )
            return 'already_pausing'

    def handle_reconnection_success(
        self, game_id: str, player_id: str | int
    ) -> str | None:
        """
        Handle successful P2P reconnection from a client (Phase 20 - RECON-05).

        Returns:
            'resume' if all lost players have recovered
            'waiting' if still waiting for other players
            None if game not found
        """
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                logger.warning(f"Reconnection success for non-existent game {game_id}")
                return None

            if not game.reconnection_in_progress:
                logger.warning(
                    f"Reconnection success but no reconnection in progress for {game_id}"
                )
                return None

            game.reconnection_recovered_players.add(str(player_id))

            # Check if all lost players have recovered
            if game.reconnection_lost_players <= game.reconnection_recovered_players:
                # Calculate pause duration
                pause_duration = (time.time() - game.reconnection_start_time) * 1000
                game.total_pause_duration_ms += pause_duration

                logger.info(
                    f"All players reconnected in game {game_id} "
                    f"(pause duration: {pause_duration:.0f}ms)"
                )

                # Reset reconnection state
                game.reconnection_in_progress = False
                game.reconnection_start_time = None
                game.reconnection_lost_players = set()
                game.reconnection_recovered_players = set()

                return 'resume'

            logger.debug(
                f"Player {player_id} reconnected in game {game_id}, "
                f"waiting for {len(game.reconnection_lost_players - game.reconnection_recovered_players)} more"
            )
            return 'waiting'

    def handle_reconnection_timeout(self, game_id: str) -> dict | None:
        """
        Handle reconnection timeout - game ends (Phase 20 - RECON-06).

        Returns reconnection data for logging, or None if game not found.
        """
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                return None

            # Calculate final pause duration
            if game.reconnection_start_time:
                final_pause = (time.time() - game.reconnection_start_time) * 1000
                game.total_pause_duration_ms += final_pause

            logger.warning(
                f"Reconnection timeout for game {game_id} "
                f"(total pause: {game.total_pause_duration_ms:.0f}ms)"
            )

            return {
                'total_pause_duration_ms': game.total_pause_duration_ms,
                'lost_players': list(game.reconnection_lost_players),
                'recovered_players': list(game.reconnection_recovered_players)
            }

    def get_reconnection_data(self, game_id: str) -> dict | None:
        """Get reconnection data for a game (Phase 20 - LOG-03)."""
        with self.lock:
            game = self.games.get(game_id)
            if not game:
                return None

            return {
                'in_progress': game.reconnection_in_progress,
                'total_pause_duration_ms': game.total_pause_duration_ms
            }

    def get_disconnected_player_id(self, game_id: str) -> str | int | None:
        """Get the ID of the player who disconnected from a game (Phase 23 - DATA-04).

        Args:
            game_id: Game identifier

        Returns:
            Player ID of disconnected player, or None if unknown
        """
        with self.lock:
            if game_id not in self.games:
                return None
            return self.games[game_id].disconnected_player_id
