from __future__ import annotations

SubjectID = str
GameID = str
RoomID = int
SceneID = str
