"""
Network disruption tests - validate rollback and fast-forward mechanisms.

These tests use CDP and JavaScript event injection to simulate network disruptions
and verify that the game correctly handles:
- NET-02: Packet loss triggering rollback scenarios
- NET-03: Tab unfocus/refocus exercising fast-forward path

The tests validate that episodes complete successfully under disruption,
and that rollback/fast-forward events are observable in game state.

Key behaviors tested:
1. Packet loss causes late/lost inputs, triggering GGPO rollbacks
2. Tab backgrounding causes frame deficit, triggering fast-forward on refocus
3. Both disruption types complete episode without data corruption
"""
from __future__ import annotations

import time

import pytest

from tests.fixtures.export_helpers import (get_experiment_id,
                                           get_subject_ids_from_pages,
                                           run_comparison,
                                           wait_for_episode_with_parity,
                                           wait_for_export_files)
from tests.fixtures.game_helpers import (click_advance_button,
                                         click_start_button, get_game_state,
                                         get_scene_id,
                                         run_full_episode_flow_until_gameplay,
                                         wait_for_episode_complete,
                                         wait_for_game_canvas,
                                         wait_for_game_object,
                                         wait_for_socket_connected)
from tests.fixtures.input_helpers import (start_random_actions,
                                          stop_random_actions)
from tests.fixtures.network_helpers import (apply_latency, apply_packet_loss,
                                            get_fast_forward_state,
                                            get_rollback_stats,
                                            set_tab_visibility,
                                            wait_for_focus_manager_state)

# =============================================================================
# NET-02: Packet Loss Test
# =============================================================================

@pytest.mark.timeout(300)  # 5 minutes max
def test_packet_loss_triggers_rollback(flask_server, player_contexts):
    """
    NET-02: Test that episode completes under packet loss conditions.

    Strategy:
    1. Apply packet loss to player 2 (15% loss, 50ms base latency)
    2. Inject random inputs to create misprediction opportunities
    3. Verify episode completes despite packet loss disruption
    4. Log rollback statistics for observability

    Note: Phase 63 increased P2P input redundancy from 3 to 10 copies per
    packet, making rollbacks extremely rare under 15% loss (P(all lost) ~
    0.15^10 ~ 6e-9 per input). Zero rollbacks is the expected behavior.
    The primary validation is episode completion under disruption; rollback
    counting is observational only.
    """
    page1, page2 = player_contexts
    base_url = flask_server["url"]

    # Apply packet loss to player 2 BEFORE navigation
    cdp2 = apply_packet_loss(page2, packet_loss_percent=15, latency_ms=50)

    try:
        # Run through to gameplay (not full episode, we'll inject inputs first)
        run_full_episode_flow_until_gameplay(page1, page2, base_url)

        # Verify both players are in same game
        state1 = get_game_state(page1)
        state2 = get_game_state(page2)
        assert state1["gameId"] == state2["gameId"], "Players should be in same game"

        # Start random action injection to create misprediction opportunities
        # Without inputs, rollbacks won't occur (predicted Noop == actual Noop)
        interval1 = start_random_actions(page1, interval_ms=150)
        interval2 = start_random_actions(page2, interval_ms=200)

        try:
            # Wait for episode completion
            wait_for_episode_complete(page1, episode_num=1, timeout=180000)
            wait_for_episode_complete(page2, episode_num=1, timeout=180000)
        finally:
            stop_random_actions(page1, interval1)
            stop_random_actions(page2, interval2)

        # Get final states
        final_state1 = get_game_state(page1)
        final_state2 = get_game_state(page2)

        # Get rollback stats from both players
        stats1 = get_rollback_stats(page1)
        stats2 = get_rollback_stats(page2)

        # Check rollback stats (informational, not required)
        # Phase 63 increased P2P input redundancy from 3 to 10 copies per packet.
        # With 10 redundant copies and 15% packet loss, the probability of all
        # copies being lost is 0.15^10 ~ 6e-9, so rollbacks are extremely rare.
        # Zero rollbacks under 15% loss is the EXPECTED behavior with 10x redundancy.
        total_rollbacks = (stats1['rollbackCount'] or 0) + (stats2['rollbackCount'] or 0)

        # Log rollback statistics for visibility
        print(f"\n[Packet Loss 15%] Rollback statistics:")
        print(f"  Player 1: rollbacks={stats1['rollbackCount']}, maxFrames={stats1['maxRollbackFrames']}")
        print(f"  Player 2: rollbacks={stats2['rollbackCount']}, maxFrames={stats2['maxRollbackFrames']}")
        print(f"  Total rollbacks: {total_rollbacks}")
        if total_rollbacks == 0:
            print("  (Zero rollbacks expected with 10x input redundancy from Phase 63)")

        # Primary validation: episode completes under packet loss conditions
        assert final_state1['numEpisodes'] >= 1, "Player 1 should complete episode"
        assert final_state2['numEpisodes'] >= 1, "Player 2 should complete episode"

        # Verify they stayed in same game
        assert final_state1['gameId'] == final_state2['gameId'], "Players should be in same game"

        # Validate data parity
        scene_id = get_scene_id(page1)
        success, parity_msg = wait_for_episode_with_parity(
            page1, page2,
            experiment_id=get_experiment_id(),
            scene_id=scene_id,
            episode_num=0,
            episode_timeout_sec=10,  # Episode already complete
            export_timeout_sec=30,
            parity_row_tolerance=0,
            verbose=True,
        )
        assert success, f"Data parity failed under packet loss: {parity_msg}"

        print(f"  Episode completed: gameId={final_state1['gameId']}")

    finally:
        try:
            cdp2.detach()
        except Exception:
            pass


# =============================================================================
# NET-03: Tab Visibility Test
# =============================================================================

@pytest.mark.timeout(300)  # 5 minutes max
def test_tab_visibility_triggers_fast_forward(flask_server, player_contexts):
    """
    NET-03: Test that tab unfocus/refocus exercises fast-forward path.

    Strategy:
    1. Start game normally
    2. Let both players run for a few seconds
    3. Hide player 1's tab (simulated via JS)
    4. Wait 5 seconds while player 2 continues
    5. Show player 1's tab (should trigger fast-forward)
    6. Verify player 1 caught up (frame number jumped)
    7. Verify episode completes

    Note: Fast-forward processes buffered partner inputs and steps
    through frames rapidly without rendering to catch up.
    """
    page1, page2 = player_contexts
    base_url = flask_server["url"]

    # Navigate to game
    page1.goto(base_url)
    page2.goto(base_url)

    # Socket connect
    wait_for_socket_connected(page1, timeout=30000)
    wait_for_socket_connected(page2, timeout=30000)

    # Pass instructions
    click_advance_button(page1, timeout=60000)
    click_advance_button(page2, timeout=60000)

    # Start multiplayer (tutorial scene removed in commit 607b60a)
    click_start_button(page1, timeout=60000)
    click_start_button(page2, timeout=60000)

    # Wait for game to start
    wait_for_game_canvas(page1, timeout=120000)
    wait_for_game_canvas(page2, timeout=120000)
    wait_for_game_object(page1, timeout=60000)
    wait_for_game_object(page2, timeout=60000)

    # Override visibility for Playwright automation (essential for frames to advance)
    set_tab_visibility(page1, visible=True)
    set_tab_visibility(page2, visible=True)

    # Let game run for 3 seconds (build up some frames)
    time.sleep(3)

    # Record player 1's frame number before hiding
    state_before = get_fast_forward_state(page1)
    frame_before_hide = state_before['frameNumber']
    print(f"\n[Tab Visibility] Before hide: frame={frame_before_hide}")

    # Hide player 1's tab
    set_tab_visibility(page1, visible=False)
    wait_for_focus_manager_state(page1, backgrounded=True, timeout=5000)

    print(f"  Player 1 backgrounded, waiting 5 seconds...")

    # Wait 5 seconds while player 2 continues (player 2 advances frames)
    time.sleep(5)

    # Record player 2's frame number (they advanced while player 1 was hidden)
    state_p2_during = get_fast_forward_state(page2)
    print(f"  Player 2 frame during hide: {state_p2_during['frameNumber']}")

    # Show player 1's tab (triggers fast-forward)
    set_tab_visibility(page1, visible=True)
    wait_for_focus_manager_state(page1, backgrounded=False, timeout=5000)

    # Wait for fast-forward to complete (frame number should catch up)
    # Give it up to 30 seconds since fast-forward has safety limits
    page1.wait_for_function(
        f"""() => {{
            const game = window.game;
            return game &&
                   !game._pendingFastForward &&
                   game.frameNumber > {frame_before_hide + 20};  // Should have advanced significantly
        }}""",
        timeout=30000
    )

    # Get final state
    state_after = get_fast_forward_state(page1)
    frame_after_show = state_after['frameNumber']

    print(f"  After show: frame={frame_after_show}")
    print(f"  Frame jump: {frame_after_show - frame_before_hide} frames")

    # Verify fast-forward occurred (frame number jumped significantly)
    frame_jump = frame_after_show - frame_before_hide
    assert frame_jump > 30, (
        f"Expected significant frame jump after fast-forward, "
        f"but only got {frame_jump} frames (before={frame_before_hide}, after={frame_after_show})"
    )

    # Now complete the episode
    wait_for_episode_complete(page1, episode_num=1, timeout=180000)
    wait_for_episode_complete(page2, episode_num=1, timeout=180000)

    # Get final game states
    final_state1 = get_game_state(page1)
    final_state2 = get_game_state(page2)

    # Verify completion
    assert final_state1['numEpisodes'] >= 1, "Player 1 should complete episode"
    assert final_state2['numEpisodes'] >= 1, "Player 2 should complete episode"
    assert final_state1['gameId'] == final_state2['gameId'], "Players should be in same game"

    # Validate data parity
    scene_id = get_scene_id(page1)
    experiment_id = get_experiment_id()
    success, parity_msg = wait_for_episode_with_parity(
        page1, page2,
        experiment_id=experiment_id,
        scene_id=scene_id,
        episode_num=0,
        episode_timeout_sec=10,  # Episode already complete
        export_timeout_sec=30,
        parity_row_tolerance=0,
        verbose=True,
    )
    assert success, f"Data parity failed after tab visibility toggle: {parity_msg}"

    print(f"  Episode completed: gameId={final_state1['gameId']}")


# =============================================================================
# Active Input + Packet Loss Test (INPUT-05)
# =============================================================================

@pytest.mark.timeout(300)  # 5 minutes max
def test_active_input_with_packet_loss(flask_server, player_contexts):
    """
    Test data parity when both players actively input actions under packet loss.

    This is the most stress-testing scenario because:
    1. Packet loss causes rollbacks which re-predict actions
    2. With active inputs (not just Noop), rollback correction must handle
       real action values being overwritten and restored
    3. Both players are injecting different actions at different times

    Validates dual-buffer fixes from Phases 48-49:
    - Phase 48: isFocused column consistency (getFocusStatePerPlayer)
    - Phase 49: Episode boundary row parity (BOUND-02/03 guards)

    This validates that:
    - Rollback correctly restores actual action values
    - The dual-buffer data recording handles misprediction correction
    - Export parity is maintained despite frequent rollbacks

    Fixed in Phase 88: anchor-based input buffer pruning ensures confirmed
    inputs are available during rollback replay, preventing prediction
    fallback for frames between the anchor snapshot and confirmedFrame.

    Configuration:
    - Player 1: random actions every 150ms, no packet loss
    - Player 2: random actions every 200ms, 15% packet loss + 50ms latency
    """
    page1, page2 = player_contexts
    base_url = flask_server["url"]

    # Apply packet loss to player 2 BEFORE navigation
    cdp2 = apply_packet_loss(page2, packet_loss_percent=15, latency_ms=50)

    try:
        # Run through to gameplay
        run_full_episode_flow_until_gameplay(page1, page2, base_url)

        # Verify both players are in same game
        state1 = get_game_state(page1)
        state2 = get_game_state(page2)
        assert state1["gameId"] == state2["gameId"], "Players should be in same game"
        assert state1["playerId"] != state2["playerId"], "Players should have different IDs"

        # Start random action injection on both players
        interval1 = start_random_actions(page1, interval_ms=150)
        interval2 = start_random_actions(page2, interval_ms=200)

        print(f"\n[Active Input + 15% Packet Loss] Started random actions")

        try:
            # Wait for episode completion
            wait_for_episode_complete(page1, episode_num=1, timeout=180000)
            wait_for_episode_complete(page2, episode_num=1, timeout=180000)
        finally:
            stop_random_actions(page1, interval1)
            stop_random_actions(page2, interval2)

        # Verify rollbacks occurred (packet loss causes mispredictions)
        stats1 = get_rollback_stats(page1)
        stats2 = get_rollback_stats(page2)
        total_rollbacks = (stats1['rollbackCount'] or 0) + (stats2['rollbackCount'] or 0)

        print(f"  Rollback statistics:")
        print(f"    Player 1: rollbacks={stats1['rollbackCount']}, maxFrames={stats1['maxRollbackFrames']}")
        print(f"    Player 2: rollbacks={stats2['rollbackCount']}, maxFrames={stats2['maxRollbackFrames']}")
        print(f"    Total rollbacks: {total_rollbacks}")

        # Note: Rollbacks may not always occur with 15% packet loss - timing dependent.
        # The data parity check below is the primary validation.
        if total_rollbacks == 0:
            print("  WARNING: No rollbacks occurred despite packet loss (timing dependent)")
            print("  Proceeding with data parity check as primary validation")

        # Note: Action stats verification after episode completion is unreliable
        # because frameDataBuffer is cleared after export. The export comparison
        # below verifies that actions were correctly recorded despite packet loss.

        # Get final states
        final_state1 = get_game_state(page1)
        final_state2 = get_game_state(page2)

        # Verify completion
        assert final_state1["numEpisodes"] >= 1, "Player 1 should complete 1+ episodes"
        assert final_state2["numEpisodes"] >= 1, "Player 2 should complete 1+ episodes"

        # Extract identifiers for export files
        experiment_id = get_experiment_id()
        scene_id = get_scene_id(page1)
        assert scene_id, "Could not get scene ID from game"

        subject_ids = get_subject_ids_from_pages(page1, page2)

        # Wait for export files
        # Note: episode_num is 0-indexed in file names, so first episode is _ep0.csv
        try:
            file1, file2 = wait_for_export_files(
                experiment_id=experiment_id,
                scene_id=scene_id,
                subject_ids=subject_ids,
                episode_num=0,  # 0-indexed: first episode
                timeout_sec=30
            )
        except TimeoutError as e:
            pytest.fail(f"Export files not found: {e}")

        # Run comparison
        exit_code, output = run_comparison(file1, file2, verbose=True)

        print(f"\nComparison output:\n{output}")

        # Assert parity
        if exit_code != 0:
            pytest.fail(
                f"Data parity check failed with active inputs + packet loss "
                f"(exit code {exit_code}):\n{output}"
            )

        print(f"\n[Active Input + Packet Loss] Data parity verified despite {total_rollbacks} rollbacks")
        print(f"  Episodes completed: gameId={final_state1['gameId']}")

    finally:
        try:
            cdp2.detach()
        except Exception:
            pass


# =============================================================================
# Deep Rollback Stress Test (>5 seconds / >150 frames)
# =============================================================================

@pytest.mark.timeout(300)  # 5 minutes max
def test_deep_rollback_via_tab_hide(flask_server, player_contexts):
    """
    Stress test GGPO rollback with >150 frames depth (>5 seconds at 30 FPS).

    Validates anchor-based input buffer pruning by creating a scenario where
    Player 1 must rollback and replay 180+ frames of game history.

    Mechanism:
    1. Apply 300ms latency to Player 2 (delayed input delivery)
    2. Both players inject random actions (creates mispredictions)
    3. Hide Player 2's tab for 6 seconds (~180 frames at 30 FPS)
       - Player 2's game loop pauses (FocusManager backgrounded)
       - Player 2 stops sending inputs to Player 1
       - Player 1 continues, predicting Player 2's inputs for 180 frames
    4. Show Player 2's tab (triggers fast-forward + sends buffered inputs)
       - Player 2 catches up by processing 180 buffered frames
       - Player 2 sends all 180+ newly-generated inputs to Player 1
       - Player 1 receives inputs 6+ seconds late → deep rollback
    5. Verify rollback depth ≥150 frames and data parity passes

    Configuration:
    - Player 1: random actions every 150ms, no network disruption
    - Player 2: random actions every 200ms, 300ms latency, 6s tab hide
    """
    page1, page2 = player_contexts
    base_url = flask_server["url"]

    # Apply 300ms latency to player 2 BEFORE navigation
    cdp2 = apply_latency(page2, latency_ms=300)

    try:
        # Run through to gameplay
        run_full_episode_flow_until_gameplay(page1, page2, base_url)

        # Verify both players are in same game
        state1 = get_game_state(page1)
        state2 = get_game_state(page2)
        assert state1["gameId"] == state2["gameId"], "Players should be in same game"
        assert state1["playerId"] != state2["playerId"], "Players should have different IDs"

        # Start random action injection on both players
        interval1 = start_random_actions(page1, interval_ms=150)
        interval2 = start_random_actions(page2, interval_ms=200)

        print(f"\n[Deep Rollback] Started random actions, letting game run...")

        try:
            # Let game run for 3 seconds to build up state
            time.sleep(3)

            # Record Player 1's state before hiding Player 2
            state1_before = get_game_state(page1)
            stats1_before = get_rollback_stats(page1)
            print(f"  Before hide: P1 frame={state1_before['frameNumber']}, "
                  f"rollbacks={stats1_before['rollbackCount']}")

            # Hide Player 2's tab — FocusManager pauses, stops sending inputs
            print(f"  Hiding Player 2's tab for 6 seconds...")
            set_tab_visibility(page2, visible=False)
            wait_for_focus_manager_state(page2, backgrounded=True, timeout=5000)

            # Wait 6 seconds — Player 1 predicts Player 2's inputs for ~180 frames
            time.sleep(6)

            state1_during = get_game_state(page1)
            predicted_frames = state1_during['frameNumber'] - state1_before['frameNumber']
            print(f"  During hide: P1 frame={state1_during['frameNumber']} "
                  f"(predicted {predicted_frames} frames for P2)")

            # Show Player 2's tab — triggers fast-forward + sends buffered inputs
            print(f"  Showing Player 2's tab (triggers fast-forward + deep rollback)...")
            set_tab_visibility(page2, visible=True)
            wait_for_focus_manager_state(page2, backgrounded=False, timeout=5000)

            # Wait for Player 2 to fast-forward and catch up
            initial_p2_frame = get_game_state(page2)['frameNumber']
            page2.wait_for_function(
                f"""() => {{
                    const game = window.game;
                    return game &&
                           !game._pendingFastForward &&
                           game.frameNumber > {initial_p2_frame + 50};
                }}""",
                timeout=30000
            )

            state2_after = get_game_state(page2)
            print(f"  After fast-forward: P2 frame={state2_after['frameNumber']}")

            # Wait for Player 1's rollback to complete
            page1.wait_for_function(
                """() => {
                    const game = window.game;
                    return game && !game.rollbackInProgress;
                }""",
                timeout=30000
            )

            # Brief pause for rollback stats to settle
            time.sleep(1)

            # Verify deep rollback occurred
            stats1 = get_rollback_stats(page1)
            stats2 = get_rollback_stats(page2)

            print(f"\n  Rollback statistics:")
            print(f"    Player 1: rollbacks={stats1['rollbackCount']}, "
                  f"maxFrames={stats1['maxRollbackFrames']}")
            print(f"    Player 2: rollbacks={stats2['rollbackCount']}, "
                  f"maxFrames={stats2['maxRollbackFrames']}")

            max_depth = max(
                stats1['maxRollbackFrames'] or 0,
                stats2['maxRollbackFrames'] or 0
            )
            assert max_depth >= 150, (
                f"Expected deep rollback (>=150 frames / 5+ seconds) but max depth "
                f"was {max_depth} frames. P1={stats1['maxRollbackFrames']}, "
                f"P2={stats2['maxRollbackFrames']}"
            )

            # Wait for episode completion (extended timeout for rollback processing)
            wait_for_episode_complete(page1, episode_num=1, timeout=240000)
            wait_for_episode_complete(page2, episode_num=1, timeout=240000)

        finally:
            stop_random_actions(page1, interval1)
            stop_random_actions(page2, interval2)

        # Verify completion
        final_state1 = get_game_state(page1)
        final_state2 = get_game_state(page2)
        assert final_state1["numEpisodes"] >= 1, "Player 1 should complete 1+ episodes"
        assert final_state2["numEpisodes"] >= 1, "Player 2 should complete 1+ episodes"

        # Data parity check — the ultimate validation
        experiment_id = get_experiment_id()
        scene_id = get_scene_id(page1)
        assert scene_id, "Could not get scene ID from game"

        success, parity_msg = wait_for_episode_with_parity(
            page1, page2,
            experiment_id=experiment_id,
            scene_id=scene_id,
            episode_num=0,
            episode_timeout_sec=10,
            export_timeout_sec=30,
            parity_row_tolerance=0,
            verbose=True,
        )
        assert success, f"Data parity failed after deep rollback: {parity_msg}"

        print(f"\n[Deep Rollback] Data parity verified despite "
              f"{max_depth}-frame rollback")
        print(f"  Episode completed: gameId={final_state1['gameId']}")

    finally:
        try:
            cdp2.detach()
        except Exception:
            pass
