from looselips.bench import main

main()
