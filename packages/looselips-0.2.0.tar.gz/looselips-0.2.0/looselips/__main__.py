"""Allow running as ``python -m looselips``."""

from looselips.cli.app import main

main()
