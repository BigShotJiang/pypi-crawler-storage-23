__author__ = "Mohit Rajput"
__version__ = "0.1.1"

from snaplab.evaluation.api import evaluate

author = __author__
version = __version__