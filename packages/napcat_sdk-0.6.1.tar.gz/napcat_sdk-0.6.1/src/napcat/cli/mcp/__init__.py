"""
MCP (Model Context Protocol) 相关实现

包含用于 LLM 上下文交互的 MCP 服务器实现。
目前主要提供 NapCat 文档查询服务 (doc_server)。
"""
