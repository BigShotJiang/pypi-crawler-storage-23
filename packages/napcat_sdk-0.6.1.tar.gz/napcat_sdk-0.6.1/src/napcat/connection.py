"""
WebSocket 连接管理

Connection 类封装了底层的 WebSocket 连接，处理消息收发、请求响应匹配 (Echo 机制) 和事件分发。
采用双流设计：
1. event_stream: 仅包含 OneBot 事件，供 Python 客户端使用。
2. proxy_stream: 包含 OneBot 事件和外部 RPC 调用的响应，供 RPC 服务使用。
"""

import asyncio
import logging
import uuid
from asyncio import Future, Queue, Task
from collections.abc import AsyncGenerator
from types import TracebackType
from typing import Any, cast

import orjson
from websockets.asyncio.client import ClientConnection
from websockets.asyncio.server import ServerConnection

from .exceptions import NapCatStateError

logger = logging.getLogger("napcat.connection")
_STOP = object()


class Connection:
    def __init__(self, ws: ClientConnection | ServerConnection):
        self.ws = ws
        self._futures: dict[str, Future[dict[str, Any]]] = {}

        # event_queues: 仅存储 OneBot 事件 (给 Python Client 用)
        self._event_queues: set[Queue[dict[str, Any] | object]] = set()
        # proxy_queues: 存储 事件 + RPC 响应 (给 RPC Server 用)
        self._proxy_queues: set[Queue[dict[str, Any] | object]] = set()

        self._task: Task[None] | None = None
        self._closed = asyncio.Event()

    async def __aenter__(self):
        # 幂等保护：如果已经在运行，直接返回
        if self._task is not None and not self._task.done():
            return self
        # 重置 _closed 事件（支持重复进入）
        self._closed.clear()
        self._task = asyncio.create_task(self._loop())
        return self

    @property
    def is_running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ):
        await self.close()

    async def close(self):
        # 如果 _loop 从未启动，直接设置 _closed 并返回
        if self._task is None:
            self._closed.set()
            try:
                await self.ws.close()
            except Exception:
                pass
            return

        # 正常关闭路径
        if not self._task.done():
            self._task.cancel()
        try:
            await self.ws.close()
        except Exception:
            pass
        await self._closed.wait()

    async def send(self, data: dict[str, Any], timeout: float = 10.0) -> dict[str, Any]:
        """Python 内部调用：自动挂载 UUID echo 并等待结果。"""
        if not self._task or self._task.done():
            raise NapCatStateError("Connection closed")
        echo = f"py-{uuid.uuid4()}"
        data = data | {"echo": echo}
        fut: Future[dict[str, Any]] = asyncio.get_running_loop().create_future()
        self._futures[echo] = fut
        try:
            async with asyncio.timeout(timeout):
                await self.ws.send(orjson.dumps(data))
                return await fut
        finally:
            self._futures.pop(echo, None)

    async def send_raw(self, data: dict[str, Any] | str | bytes) -> None:
        """RPC 代理调用：透传数据，不修改 echo，不挂载 Future。"""
        if not self._task or self._task.done():
            raise NapCatStateError("Connection closed")
        if isinstance(data, dict):
            await self.ws.send(orjson.dumps(data))
        else:
            await self.ws.send(data)

    # === 数据流接口 ===

    async def events(self) -> AsyncGenerator[dict[str, Any], None]:
        """仅产出 OneBot 事件 (给 Python Client)，过滤所有 API 响应。"""
        q: Queue[dict[str, Any] | object] = Queue(maxsize=500)
        self._event_queues.add(q)
        try:
            while True:
                data = await q.get()
                if data is _STOP:
                    break
                if isinstance(data, dict):
                    yield data
        finally:
            self._event_queues.discard(q)

    async def proxy_stream(self) -> AsyncGenerator[dict[str, Any], None]:
        """产出 事件 + 外部 RPC 响应 (给 RPC Server)，过滤 Python 内部调用的响应。"""
        q: Queue[dict[str, Any] | object] = Queue(maxsize=1000)
        self._proxy_queues.add(q)
        try:
            while True:
                data = await q.get()
                if data is _STOP:
                    break
                if isinstance(data, dict):
                    yield data
        finally:
            self._proxy_queues.discard(q)

    async def _loop(self) -> None:
        cancelled = False
        try:
            async for msg in self.ws:
                try:
                    data = orjson.loads(msg)
                    if not isinstance(data, dict) or not data:
                        continue
                    data = cast(dict[str, Any], data)
                except orjson.JSONDecodeError:
                    continue

                echo = data.get("echo")

                if echo:
                    # A: Python 内部请求的响应 → Future 消费，不广播
                    if fut := self._futures.get(echo):
                        if not fut.done():
                            fut.set_result(data)
                        continue
                    # B: RPC 客户端请求的响应 → 仅发 proxy 队列
                    self._dispatch(self._proxy_queues, data)
                else:
                    # C: OneBot 事件 → 两边都发
                    self._dispatch(self._event_queues, data)
                    self._dispatch(self._proxy_queues, data)

        except asyncio.CancelledError:
            cancelled = True
        except Exception as e:
            logger.error("Connection loop error: %s", e)
        finally:
            await self._cleanup()
            if cancelled:
                raise asyncio.CancelledError()

    async def _cleanup(self):
        for f in self._futures.values():
            if not f.done():
                f.set_exception(NapCatStateError("Connection closed"))
        self._futures.clear()

        self._dispatch(self._event_queues, _STOP)
        self._dispatch(self._proxy_queues, _STOP)
        self._event_queues.clear()
        self._proxy_queues.clear()
        self._closed.set()

    def _dispatch(self, queues: set[Queue[dict[str, Any] | object]], item: dict[str, Any] | object) -> None:
        """向一组队列广播消息，满队列时丢弃最旧消息。"""
        for q in list(queues):
            if q.full():
                try:
                    q.get_nowait()
                    logger.debug("Queue full, dropped oldest message")
                except asyncio.QueueEmpty:
                    pass
            try:
                q.put_nowait(item)
            except Exception:
                pass
