# API v1 Pydantic schemas.
# Created: 2026-02-20
