# OAuth2/PKCE authorization server.
# Created: 2026-02-20
