#!/usr/bin/env python3
"""
Hardhat parser for extracting logic contracts from build artifacts.

This module parses Hardhat's compilation output to identify which contracts
contain actual bytecode (logic contracts) vs interfaces/abstract contracts.
"""

import json
import os
from pathlib import Path
from typing import Dict, List

from src.build_systems.hardhat import HardhatManager
from src.parsers.base import ContractExtractor
from src.setup.solidity_utils import DEPENDENCIES, find_all_library_files_and_names
from src.utils import logger


class HardhatContractExtractor(ContractExtractor):
    """Hardhat-specific contract extractor."""

    def __init__(self, project_root: Path):
        """
        Initialize Hardhat contract extractor.

        Args:
            project_root: Root directory of the project
        """
        super().__init__(project_root, HardhatManager)

    def extract_logic_contracts_impl(self, artifacts_dir: Path) -> Dict[str, List[str]]:
        """
        Extract logic contracts from Hardhat artifacts.

        Assumes that `npx hardhat compile` has already been run and the artifacts directory exists
        with the standard Hardhat structure:

        artifacts/
        ├── build-info/           # SKIP - comprehensive build data
        │   └── <hash>.json
        └── contracts/
            ├── Lock.sol/
            │   ├── Lock.json        # PARSE - main artifact
            │   └── Lock.dbg.json    # SKIP - debug metadata
            └── subfolder/
                └── FooFile.sol/
                    ├── Foo.json     # PARSE
                    └── Foo.dbg.json # SKIP

        A contract is considered a "logic contract" if:
        - It has a bytecode field in the JSON artifact
        - The bytecode starts with "0x"
        - The bytecode is not empty ("0x")

        Args:
            artifacts_dir: Path to Hardhat artifacts/contracts directory

        Returns:
            Dict mapping source file basename to list of contract names
        """
        logic_contracts: dict[str, list[str]] = {}
        library_files = find_all_library_files_and_names()
        library_files = {Path(file).stem: names for file, names in library_files.items()}

        # Recursively find all JSON files in artifacts/contracts/ using os.walk for performance
        skip_dirs = {"build-info"}
        for root, dirs, files in os.walk(artifacts_dir):
            # Prune directories we don't want to traverse into
            dirs[:] = [d for d in dirs if d not in skip_dirs and not (d.endswith(".t.sol") or d.endswith(".s.sol"))]

            for file_name in files:
                # Skip .dbg.json files (Hardhat debug metadata)
                if file_name.endswith(".dbg.json"):
                    continue

                # Only process .json files
                if not file_name.endswith(".json"):
                    continue

                json_file = Path(root) / file_name

                try:
                    # Parse the JSON artifact
                    with open(json_file, 'r') as f:
                        artifact = json.load(f)

                    # Verify this is a Hardhat artifact (format check)
                    artifact_format = artifact.get("_format")
                    if artifact_format != "hh-sol-artifact-1":
                        # Not a Hardhat artifact or wrong format, skip
                        continue

                    # Extract fields from Hardhat artifact (different from Foundry!)
                    contract_name = artifact.get("contractName")
                    source_name = artifact.get("sourceName")  # e.g., "contracts/Lock.sol"
                    bytecode = artifact.get("bytecode")  # Direct string, not bytecode.object

                    # Validate required fields
                    if not contract_name:
                        logger.log(f"No contractName in {json_file}, skipping", "WARNING", "Hardhat")
                        continue

                    if not source_name:
                        logger.log(f"No sourceName in {json_file}, skipping", "WARNING", "Hardhat")
                        continue

                    # Check if bytecode exists and is valid
                    if not bytecode:
                        continue

                    # Validate bytecode format (must be string starting with 0x)
                    if not isinstance(bytecode, str):
                        raise Exception(f"Invalid bytecode in {json_file}: expected string, got {type(bytecode)}")

                    if not bytecode.startswith("0x"):
                        raise Exception(
                            f"Invalid bytecode in {json_file}: bytecode must start with '0x' but got "
                            f"'{bytecode[:10]}...'"
                        )

                    # Check if bytecode is not empty (more than just "0x")
                    if bytecode == "0x":
                        continue

                    # Extract source file basename (without .sol extension)
                    source_basename = Path(source_name).stem

                    # Skip libraries
                    if source_basename in library_files and contract_name in library_files[source_basename]:
                        logger.log(f"Skipping library contract: {contract_name} in {source_name}", "DEBUG", "Hardhat")
                        continue
                    
                    # Skip contracts from dependency directories or test/script directories
                    if source_name:
                        # Check if source_name contains any dependency directory
                        is_dependency = any(dep in source_name for dep in DEPENDENCIES)
                        # Check if source_name is in test or script directories
                        is_test_or_script = "/test/" in source_name or "/script/" in source_name or source_name.startswith("test/") or source_name.startswith("script/")
                        if is_dependency or is_test_or_script:
                            continue
                    
                    # Add to logic contracts
                    if source_basename in logic_contracts:
                        logic_contracts[source_basename].append(contract_name)
                    else:
                        logic_contracts[source_basename] = [contract_name]

                except json.JSONDecodeError as e:
                    raise Exception(f"Failed to parse JSON file {json_file}: {e}")
                except KeyError as e:
                    raise Exception(f"Missing required field in {json_file}: {e}")
                except Exception as e:
                    # Re-raise any other exceptions as fatal errors
                    raise Exception(f"Error processing {json_file}: {e}")

        return logic_contracts
