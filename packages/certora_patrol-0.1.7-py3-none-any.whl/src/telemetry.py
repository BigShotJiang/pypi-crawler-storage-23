"""
Telemetry module for PreAudit beta.

Bundles run inputs/outputs and uploads them as GitHub release assets
to the private arotrec-labs/preaudit-telemetry repository.
"""

import json
import re
import subprocess
import tarfile
import tempfile
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from src.utils.logger import logger

GITHUB_REPO = "arotrec-labs/preaudit-telemetry"
_TELEMETRY_TOKEN = "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"

# Directories to exclude when bundling the full project (no-prover-runs fallback)
_PROJECT_EXCLUDE_DIRS = {"node_modules", ".git", "lib", "out", "cache", "artifacts", "__pycache__",
                         ".certora_internal", ".CertoraPatrolReports"}
_CERTORA_INTERNAL_EXCLUDE_DIRS = {"extracted_tars", "tarball_cache", "bulk_cache"}

# Pattern for timestamp-hex directories inside .certora_internal/
_TIMESTAMP_HEX_RE = re.compile(r"\d{2}_\d{2}_\d{2}_\d{2}_\d{2}_\d{2}_[0-9a-f]{10,}")


def _git_metadata(project_dir: Path) -> dict:
    """Collect git repository metadata. Individual failures yield 'unknown'."""
    info: dict[str, str | bool] = {}
    commands = {
        "git_remote": ["git", "remote", "get-url", "origin"],
        "git_commit": ["git", "rev-parse", "HEAD"],
        "git_branch": ["git", "rev-parse", "--abbrev-ref", "HEAD"],
    }
    for key, cmd in commands.items():
        try:
            result = subprocess.run(cmd, cwd=project_dir, capture_output=True, text=True, check=True)
            info[key] = result.stdout.strip()
        except Exception:
            info[key] = "unknown"

    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"], cwd=project_dir, capture_output=True, text=True, check=True
        )
        info["git_dirty"] = bool(result.stdout.strip())
    except Exception:
        info["git_dirty"] = True

    return info


def _prover_runs_executed(results_json: Path) -> bool:
    """Return True if the orchestrator results JSON contains at least one job URL."""
    try:
        data = json.loads(results_json.read_text())
        for cr in data.get("config_results", []):
            if cr.get("job_url"):
                return True
        return False
    except Exception:
        return False


def collect_metadata(project_dir: Path, args, results_json: Path | None, html_path: Path | None) -> dict:
    """Assemble telemetry metadata and write it to .certora_internal/telemetry_metadata.json."""
    git_info = _git_metadata(project_dir)
    has_prover_runs = _prover_runs_executed(results_json) if results_json else False

    metadata = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **git_info,
        "contract_arg": getattr(args, "contract", None),
        "cli_args": {key: str(val) for key, val in vars(args).items()},
        "prover_runs_executed": has_prover_runs,
        "reports_dir": str(results_json.parent) if results_json else "N/A",
        "html_report_exists": html_path is not None,
    }

    metadata_file = project_dir / ".certora_internal" / "telemetry_metadata.json"
    metadata_file.parent.mkdir(parents=True, exist_ok=True)
    metadata_file.write_text(json.dumps(metadata, indent=2))

    return metadata


def _certora_internal_filter(tarinfo: tarfile.TarInfo) -> tarfile.TarInfo | None:
    """Filter for .certora_internal/ entries: skip .zip files and timestamp-hex directories."""
    parts = Path(tarinfo.name).parts
    # Skip any .zip file anywhere inside .certora_internal
    if tarinfo.name.endswith(".zip"):
        return None
    # Skip excluded directories and timestamp-hex directories (and everything under them)
    for part in parts:
        if part in _CERTORA_INTERNAL_EXCLUDE_DIRS:
            return None
        if _TIMESTAMP_HEX_RE.fullmatch(part):
            return None
    return tarinfo


def create_telemetry_bundle(project_dir: Path, metadata: dict) -> Path:
    """Create a .tar.gz telemetry bundle in a temp directory."""
    repo_name = metadata.get("git_remote", "unknown").rstrip("/").split("/")[-1].removesuffix(".git")
    if repo_name == "unknown":
        repo_name = project_dir.name
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"preaudit_telemetry_{repo_name}_{timestamp}.tar.gz"
    bundle_path = Path(tempfile.mkdtemp()) / filename

    with tarfile.open(bundle_path, "w:gz") as tar:
        # 1. .certora_internal/ (filtered)
        ci_dir = project_dir / ".certora_internal"
        if ci_dir.is_dir():
            tar.add(str(ci_dir), arcname=".certora_internal", filter=_certora_internal_filter)

        # 2. certora/ — generated specs and configs
        certora_dir = project_dir / "certora"
        if certora_dir.is_dir():
            tar.add(str(certora_dir), arcname="certora")

        # 3. CertoraPatrolReports/
        reports_dir = project_dir / ".CertoraPatrolReports"
        if reports_dir.is_dir():
            tar.add(str(reports_dir), arcname=".CertoraPatrolReports")

        # 4. Full project if no prover runs were executed
        if not metadata.get("prover_runs_executed", True):

            def project_filter(tarinfo: tarfile.TarInfo) -> tarfile.TarInfo | None:
                top = Path(tarinfo.name).parts[0] if Path(tarinfo.name).parts else ""
                if top in _PROJECT_EXCLUDE_DIRS:
                    return None
                return tarinfo

            tar.add(str(project_dir), arcname="project_source", filter=project_filter)

    return bundle_path


def _upload_to_github(bundle_path: Path, metadata: dict) -> str | None:
    """Upload the telemetry bundle as a GitHub release asset. Returns the release URL or None."""
    token = _TELEMETRY_TOKEN
    if not token or token.startswith("<"):
        logger.debug("Telemetry: no valid GitHub token configured — skipping upload.")
        return None

    timestamp = metadata.get("timestamp", "unknown")
    repo_name = metadata.get("git_remote", "unknown").rstrip("/").split("/")[-1].removesuffix(".git")
    commit = metadata.get("git_commit", "unknown")[:8]
    tag = f"run-{timestamp.replace(':', '-')}"
    release_name = f"{repo_name}@{commit} {timestamp}"
    body = (
        f"**Contract:** {metadata.get('contract_arg', 'N/A')}\n"
        f"**Branch:** {metadata.get('git_branch', 'unknown')}\n"
        f"**Prover runs:** {metadata.get('prover_runs_executed', False)}\n"
    )

    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "preaudit-telemetry",
    }

    # Step 1: Create a release
    release_payload = json.dumps({
        "tag_name": tag,
        "name": release_name,
        "body": body,
        "draft": False,
        "prerelease": False,
    }).encode()

    req = urllib.request.Request(
        f"https://api.github.com/repos/{GITHUB_REPO}/releases",
        data=release_payload,
        headers={**headers, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            release_data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        logger.debug(f"Telemetry: failed to create GitHub release: {e.code} {e.read().decode()[:200]}")
        return None
    except Exception as e:
        logger.debug(f"Telemetry: failed to create GitHub release: {e}")
        return None

    upload_url = release_data["upload_url"].split("{")[0]  # strip {?name,label} template
    html_url = release_data.get("html_url", "")

    # Step 2: Upload the bundle as a release asset
    asset_name = bundle_path.name
    asset_data = bundle_path.read_bytes()
    upload_req = urllib.request.Request(
        f"{upload_url}?name={asset_name}",
        data=asset_data,
        headers={**headers, "Content-Type": "application/gzip"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(upload_req) as resp:
            resp.read()
    except urllib.error.HTTPError as e:
        logger.debug(f"Telemetry: failed to upload asset: {e.code} {e.read().decode()[:200]}")
        return html_url  # release was created, asset upload failed
    except Exception as e:
        logger.debug(f"Telemetry: failed to upload asset: {e}")
        return html_url

    return html_url


def upload_telemetry(project_dir: Path, args, results_json: Path | None, html_path: Path | None) -> None:
    """Top-level telemetry entry point. Bundles run data and uploads to GitHub. Never raises."""
    try:
        metadata = collect_metadata(project_dir, args, results_json, html_path)
        bundle_path = create_telemetry_bundle(project_dir, metadata)
        url = _upload_to_github(bundle_path, metadata)
        # Clean up temp bundle
        try:
            bundle_path.unlink()
            bundle_path.parent.rmdir()
        except OSError:
            pass
        if url:
            logger.debug(f"Telemetry uploaded: {url}")
        else:
            logger.debug("Telemetry bundle created (upload skipped or failed).")
    except Exception as e:
        logger.debug(f"Telemetry failed (non-fatal): {e}")
