from src.preaudit import main

main()
