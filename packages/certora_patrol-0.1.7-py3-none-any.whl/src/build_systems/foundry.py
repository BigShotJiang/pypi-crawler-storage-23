#!/usr/bin/env python3
"""
Foundry Manager - Manages Foundry project configuration, compilation, and artifacts.

Based on Brain's foundry parsing logic but enhanced for better error handling,
multi-profile support, and integrated compilation management.
"""

import sys
from typing import Dict, Any, List, Optional, Set, cast
from pathlib import Path
from dataclasses import dataclass

# Handle tomllib import for Python 3.11+ vs older versions
if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

from src.build_systems.base import BuildSystemConfig
from src.build_systems.manager import BuildSystemManager


@dataclass
class FoundryConfig(BuildSystemConfig):
    """Parsed foundry configuration with resolved settings."""

    # Foundry-specific fields (common fields inherited from BuildSystemConfig)
    out: Optional[str] = None
    libs: Optional[List[str]] = None

    # Remappings and dependencies
    remappings: Optional[List[str]] = None
    packages: Optional[List[str]] = None

    # Profile information
    profile: str = "default"

    def __post_init__(self):
        """Initialize default values for mutable fields."""
        # Call parent class initialization for common fields
        super().__post_init__()

        # Initialize Foundry-specific defaults
        if self.src is None:
            self.src = "src"
        if self.out is None:
            self.out = "out"
        if self.libs is None:
            self.libs = ["lib"]
        if self.remappings is None:
            self.remappings = []
        if self.packages is None:
            self.packages = []

    def to_certora_dict(
        self,
        convert_solc_to_certora_format: bool = True,
        include_packages: bool = True
    ) -> Dict[str, Any]:
        """
        Convert Foundry config to Certora format.

        Args:
            convert_solc_to_certora_format: Whether to convert "0.8.19" to "solc8.19" format
            include_packages: Whether to include packages/remappings

        Returns:
            Dictionary with Certora config format
        """
        # Apply common settings (solc, optimizer, via_ir) using base class helper
        result = self._apply_common_solc_settings(convert_solc_to_certora_format)

        # Apply packages (Foundry-specific)
        if include_packages and self.packages:
            result["packages"] = self._relativize_packages(self.packages)

        return result

    def get_artifact_directory(self) -> str:
        """Return Foundry artifact directory."""
        return self.out or "out"


class FoundryManager(BuildSystemManager):
    """
    Foundry project manager with support for configuration, compilation, and artifacts.

    Based on Brain's foundry parsing approach but enhanced for better modularity,
    error handling, and integrated compilation management.
    """

    def __init__(self, project_root: Path, scope):
        """
        Initialize foundry manager.

        Args:
            project_root: Root directory of the project
            scope: Centralized scope for consistent filtering
        """
        super().__init__(project_root, scope, "FoundryManager")

    def get_config_filenames(self) -> List[str]:
        """Return list of config filenames to search for."""
        return ["foundry.toml"]

    def parse_config(self, config_file: Path, profile: str | None = None) -> FoundryConfig:
        """
        Parse foundry.toml file and extract configuration for specified profile.

        Based on Brain's parse_foundry function but enhanced for profile support.

        Args:
            config_file: Path to foundry.toml file
            profile: Foundry profile to use (default: "default")

        Returns:
            FoundryConfig with parsed settings
        """
        if profile is None:
            profile = "default"

        try:
            with config_file.open("rb") as f:
                foundry_data = tomllib.load(f)

            self.log(f"Parsing foundry config from {config_file} (profile: {profile})")

            # Start with default profile settings
            config = self._extract_profile_config(foundry_data, "default")

            # Override with specific profile if different from default
            if profile != "default":
                # Check if profile exists either at top level or under "profile" section
                profile_exists = profile in foundry_data or (
                    foundry_data.get("profile", {}) and profile in foundry_data.get("profile", {})
                )
                if profile_exists:
                    profile_config = self._extract_profile_config(foundry_data, profile)
                    config = self._merge_configs(config, profile_config)

            # Set the profile name
            config.profile = profile

            # Resolve paths relative to foundry.toml location
            config = self._resolve_paths(config, config_file.parent)

            # Parse remappings and convert to packages format
            if config.remappings:
                config.packages = self._convert_remappings_to_packages(
                    config.remappings, config_file.parent
                )

            self.log(
                f"Parsed foundry config: solc={config.solc_version}, optimizer={config.optimizer}"
            )
            return config

        except Exception as e:
            self.log(f"Failed to parse foundry config {config_file}: {e}", "ERROR")
            # Return minimal config as fallback
            return FoundryConfig(profile=profile)

    def _extract_profile_config(self, foundry_data: Dict[str, Any], profile: str) -> FoundryConfig:
        """Extract configuration from a specific profile section."""
        profile_data = foundry_data.get(profile, {})

        # Handle nested profile structure
        if "profile" in foundry_data and profile in foundry_data["profile"]:
            profile_data.update(foundry_data["profile"][profile])

        # Extract compiler settings
        solc_version = self._extract_solc_version(profile_data)
        optimizer_settings = self._extract_optimizer_settings(profile_data)

        return FoundryConfig(
            solc_version=solc_version,
            optimizer=optimizer_settings["enabled"],
            optimizer_runs=optimizer_settings["runs"],
            via_ir=profile_data.get("via_ir"),  # Will be None if not specified
            src=profile_data.get("src"),  # Will be None if not specified
            out=profile_data.get("out"),  # Will be None if not specified
            libs=profile_data.get("libs"),  # Will be None if not specified
            remappings=profile_data.get("remappings", []),  # Always get remappings list
        )

    def _extract_solc_version(self, profile_data: Dict[str, Any]) -> Optional[str]:
        """Extract Solidity compiler version from various possible keys."""
        # Try different possible keys for solc version
        for key in ["solc", "solc_version", "solc-version"]:
            if key in profile_data:
                version = profile_data[key]
                if isinstance(version, str):
                    return version
        return None

    def _extract_optimizer_settings(self, profile_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimizer settings handling both boolean and object formats."""
        # Check if optimizer is explicitly set in this profile
        if "optimizer" not in profile_data:
            return {"enabled": None, "runs": profile_data.get("optimizer_runs", 200)}

        optimizer = profile_data["optimizer"]

        if isinstance(optimizer, bool):
            return {"enabled": optimizer, "runs": profile_data.get("optimizer_runs", 200)}
        elif isinstance(optimizer, dict):
            return {"enabled": optimizer.get("enabled", None), "runs": optimizer.get("runs", 200)}
        else:
            return {"enabled": None, "runs": 200}

    def _merge_configs(self, base: FoundryConfig, override: FoundryConfig) -> FoundryConfig:
        """Merge two configurations, with override taking precedence."""
        # For each field, use override value if it's not None, otherwise use base
        merged = FoundryConfig(
            solc_version=override.solc_version or base.solc_version,
            optimizer=override.optimizer if override.optimizer is not None else base.optimizer,
            optimizer_runs=override.optimizer_runs
            if override.optimizer_runs != 200
            else base.optimizer_runs,
            via_ir=override.via_ir if override.via_ir is not None else base.via_ir,
            src=override.src or base.src,
            out=override.out or base.out,
            libs=override.libs or base.libs,
            remappings=list(set((base.remappings or []) + (override.remappings or []))),  # Combine and dedupe
        )
        return merged

    def _resolve_paths(self, config: FoundryConfig, foundry_dir: Path) -> FoundryConfig:
        """Resolve relative paths in config to absolute paths."""
        # Convert relative paths to absolute
        if config.src and not Path(config.src).is_absolute():
            config.src = str(foundry_dir / config.src)
        if config.out and not Path(config.out).is_absolute():
            config.out = str(foundry_dir / config.out)

        # Resolve library paths
        resolved_libs = []
        if config.libs:
            for lib in config.libs:
                if not Path(lib).is_absolute():
                    resolved_libs.append(str(foundry_dir / lib))
                else:
                    resolved_libs.append(lib)
            config.libs = resolved_libs

        return config

    def _convert_remappings_to_packages(
        self, remappings: List[str], foundry_dir: Path
    ) -> List[str]:
        """
        Convert foundry remappings to Certora packages format.

        Based on Brain's parse_packages and parse_remappings_from_foundry functions.
        """
        packages = []

        for remapping in remappings:
            try:
                # Parse remapping format: "@openzeppelin/=lib/openzeppelin-contracts/"
                if "=" in remapping:
                    alias, path = remapping.split("=", 1)
                    alias = alias.strip()
                    path = path.strip()

                    # Resolve relative paths
                    if not Path(path).is_absolute():
                        path = str(foundry_dir / path)

                    # Convert to Certora package format
                    # if alias.startswith("@"):
                    #     # NPM-style package: @openzeppelin/contracts=lib/openzeppelin-contracts
                    #     package_name = alias[1:]  # Remove @
                    #     packages.append(f"{package_name}={path}")
                    # else:
                    #     # Simple alias: contracts=src/contracts
                    packages.append(f"{alias}={path}")

            except Exception as e:
                self.log(f"Failed to parse remapping '{remapping}': {e}", "WARNING")

        return packages

    def get_available_profiles(self, foundry_file: Path) -> List[str]:
        """Get list of available profiles in foundry.toml."""
        try:
            with foundry_file.open("rb") as f:
                foundry_data = tomllib.load(f)

            profiles = ["default"]  # Default profile always exists

            # Check for profile section
            if "profile" in foundry_data:
                profiles.extend(foundry_data["profile"].keys())

            # Check for top-level profile sections
            for key in foundry_data.keys():
                if key not in ["profile", "default"] and isinstance(foundry_data[key], dict):
                    # Could be a profile section
                    profiles.append(key)

            return list(set(profiles))  # Remove duplicates

        except Exception as e:
            self.log(f"Failed to get profiles from {foundry_file}: {e}", "ERROR")
            return ["default"]

    def auto_detect_config(self, profile: str | None = None) -> FoundryConfig:
        """
        Automatically find foundry.toml, verify single file, detect profile, and return config.

        Overrides base class to add Foundry-specific profile handling:
        - Uses base class to find and validate exactly one config file
        - If a profile is explicitly requested, uses that profile
        - If multiple profiles exist, automatically selects 'default' profile
        - If only one profile exists, uses that profile
        - If multiple profiles exist with no 'default', raises an error

        Args:
            profile: Optional profile name to override auto-detection

        Returns:
            FoundryConfig for the auto-detected foundry file and profile

        Raises:
            Exception: If there's not exactly one foundry.toml or profile cannot be determined
        """

        # Step 1: Get config file, delegating to base class for validation
        config_files = self.find_config_files()

        if len(config_files) != 1:
            # Let base class handle the error with proper message
            return cast(FoundryConfig, super().auto_detect_config(profile=profile))

        config_file = config_files[0]
        self.log(f"Auto-detected foundry file: {config_file}")

        # Step 2: Determine profile - use explicit request or auto-detect
        if profile:
            available = self.get_available_profiles(config_file)
            if profile not in available:
                self.log(f"Profile '{profile}' not found in {config_file}", "ERROR")
                self.log(f"Available profiles: {', '.join(sorted(available))}", "ERROR")
                raise Exception(f"Invalid profile '{profile}'")
            self.log(f"Using explicitly requested profile: {profile}")
        else:
            profiles = self.get_available_profiles(config_file)

            if len(profiles) > 1:
                if "default" in profiles:
                    profile = "default"
                    self.log(f"Multiple profiles found, using 'default' profile")
                else:
                    error_msg = f"Found {len(profiles)} profiles with no 'default' profile:\n"
                    for p in profiles:
                        error_msg += f"  - {p}\n"
                    error_msg += "\nPlease specify which profile to use or create a 'default' profile."
                    raise Exception(error_msg)
            else:
                profile = profiles[0]

            self.log(f"Auto-detected profile: {profile}")

        # Step 3: Parse and return config with profile
        config = self.parse_config(config_file, profile=profile)
        self.log(f"Successfully auto-detected Foundry configuration")
        return config

    def get_default_artifact_dir(self) -> str:
        """Return default Foundry artifact directory."""
        return "out"

    def get_build_command(self, profile: Optional[str] = None) -> str:
        """Return Foundry build command."""
        if profile and profile != "default":
            return f"FOUNDRY_PROFILE={profile} forge build"
        return "forge build"

    def filter_artifacts(self, artifacts_dir: Path) -> List[Path]:
        """
        Filter Foundry artifacts - all .json files except those in build-info/ directories.

        Args:
            artifacts_dir: Path to artifacts directory

        Returns:
            List of artifact file paths
        """
        return self._walk_and_filter_artifacts(
            artifacts_dir,
            skip_dirs={"build-info"},
            file_filter=lambda f: f.endswith(".json")
        )

