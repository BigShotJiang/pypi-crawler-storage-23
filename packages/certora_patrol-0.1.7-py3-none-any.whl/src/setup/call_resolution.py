#!/usr/bin/env python3
"""
Call Resolution Phase - Iterative linking and dispatching until convergence.

This phase implements the core iterative loop for resolving contract dependencies
and function calls.
"""

import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set

from src.utils.logger import logger
from src.utils.types import ContractHandle

# Add project root to path for imports (like setup_prover.py)
project_root = Path(__file__).parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.utils.contract_linker import ContractLinker
from src.utils.contract_dispatcher import ContractDispatcher, DispatchingResult
from src.utils.enhanced_config_manager import ConfigManager

# PreAudit imports
from src.utils.prover_runner import ProverRunner
from src.utils.scope import Scope


# Legacy classes removed - functionality moved to IterationResult and CallResolutionPhase fields


@dataclass
class LinkingResult:
    """Result from a linking iteration."""

    new_contracts_found: Set[str]
    links: List[str]
    errors: List[str]
    success: bool


@dataclass
class IterationResult:
    """Data changes from a complete iteration (linking + dispatching)."""

    # Core results from each phase
    linking_result: Optional[LinkingResult]
    dispatching_result: Optional[DispatchingResult]

    @property
    def success(self) -> bool:
        """Overall success status from both phases."""
        linking_success = self.linking_result.success if self.linking_result else False
        dispatching_success = self.dispatching_result.success if self.dispatching_result else False
        return linking_success and dispatching_success

    @property
    def added_links(self) -> List[str]:
        """Links added during linking phase."""
        return self.linking_result.links if self.linking_result else []

    @property
    def dispatchers_added(self) -> int:
        """Number of calls resolved during dispatching phase."""
        if self.dispatching_result:
            return self.dispatching_result.signatures_added
        return 0

class CallResolutionPhase:
    """
    1. Linking - resolve contract dependencies
    2. Verification - run prover to detect unresolved calls
    3. Dispatching - resolve function signatures
    4. Repeat
    """

    def __init__(
        self,
        scope: Scope,
        prover_runner: ProverRunner,
        config_manager: ConfigManager,
        config_file: Path,
        reports_dir: Path,
        extra_args: List[str],
        max_prover_invocations: int = 10,
    ):
        """
        Initialize call resolution phase for a specific contract.

        Args:
            scope: Centralized scope defining project boundaries
            prover_runner: Runner for prover execution (local or cloud)
            config_manager: Configuration manager for handling .conf files
            config_file: Path to the configuration file
            reports_dir: Directory where reports will be written
            extra_args: Extra arguments to pass to certoraRun
            max_prover_invocations: Maximum number of prover invocations for dispatching
        """
        self.scope = scope
        self.prover_runner = prover_runner
        self.config_manager = config_manager
        self.config_file = config_file
        self.reports_dir = reports_dir
        self.extra_args = extra_args

        # Extract contract name and spec file from config
        config_info = self.config_manager.extract_contract_and_spec_from_config(
            config_file, scope.project_root
        )
        if config_info is None:
            raise ValueError(f"Could not extract contract name and spec file from config: {config_file}")

        self.contract_name, self.spec_file = config_info

        # Initialize adapters
        self.contract_linker = ContractLinker(self.scope)
        self.contract_dispatcher = ContractDispatcher(
            self.scope, prover_runner, config_manager, extra_args
        )

        # Track contracts that have been processed for linking to avoid re-processing
        self.linking_processed_contracts: set[str] = set()

    async def execute(
        self,
        max_iterations: int = 10
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Execute the iterative call resolution process.

        Args:
            max_iterations: Maximum number of iterations to attempt

        Returns:
            Tuple of (linking_report_path, dispatching_report_path) or (None, None) if reports couldn't be generated
        """
        logger.info(f"Starting call resolution for {self.contract_name}")

        # Add -callResolutionOnly flag to config for verification phases
        await self._add_skip_formula_checking_flag()

        linking_report_path = None
        dispatching_report_path = None

        iteration = 1

        # Main iteration loop
        while iteration <= max_iterations:
            logger.info(
                f"Call resolution iteration {iteration} for {self.contract_name}"
            )

            # Execute one complete iteration
            iteration_start = time.time()
            iteration_result: IterationResult = await self._execute_iteration(iteration)
            iteration_duration = time.time() - iteration_start

            logger.info(
                f"Iteration {iteration} completed in "
                f"{iteration_duration:.2f}s for {self.contract_name}"
            )

            if not iteration_result.success:
                logger.error(f"Iteration {iteration} failed")
                break

            # TODO: The logic should be simplified to the following:
            # i] if there are no unresolved calls left, we are done
            # ii] if there are unresolved calls left but we added no dispatcher
            # entries, we are done
            # iii] otherwise, we continue
            if iteration_result.dispatching_result and iteration_result.dispatching_result.converged:
                logger.info(f"Call resolution converged after {iteration} iterations - no dispatcher entries added")
                break

            iteration += 1

        # Handle max iterations reached
        limit_reached = iteration > max_iterations
        if limit_reached:
            logger.warning(f"Call resolution reached max iterations ({max_iterations}) for {self.contract_name}")

        # Remove -skipFormulaChecking flag from config
        await self._remove_skip_formula_checking_flag()

        # Generate final linking report from cached decisions
        report_file = self.reports_dir / f"{self.contract_name}_linking_report.md"
        linking_report_path = self.contract_linker.generate_and_write_report(
            self.contract_name, report_file
        )

        # Generate final dispatching report from accumulated data
        dispatching_report_file = self.reports_dir / f"{self.contract_name}_dispatching_report.md"
        dispatching_report_path = self.contract_dispatcher.generate_and_write_report(
            contract_name=self.contract_name,
            report_file_path=dispatching_report_file,
            spec_file=self.spec_file,
            limit_reached=limit_reached
        )

        return linking_report_path, dispatching_report_path

    async def _add_skip_formula_checking_flag(self) -> None:
        """Add -callResolutionOnly flag to config for verification phases."""
        self.config_manager.update_config_with_prover_args(
            self.config_file,
            additional_args={"callResolutionOnly": "true"},
            _logger_context=self.contract_name,
        )
        logger.debug("Added -callResolutionOnly true flag to config")

    async def _remove_skip_formula_checking_flag(self) -> None:
        """Remove -callResolutionOnly flag from config."""
        self.config_manager.update_config_with_prover_args(
            self.config_file,
            remove_args=["-callResolutionOnly"],
            _logger_context=self.contract_name,
        )
        logger.debug("Removed -callResolutionOnly flag from config")

    async def _execute_linking_directly(self, contract_targets: set[str], config_file: Path):
        """Execute transitive linking using ContractLinker directly and update config files."""
        logger.info(f"Executing transitive linking for {contract_targets}")

        try:
            # Get available contracts from scope
            all_contracts = self.scope.get_available_contracts()

            # Check that all target contracts exist in scope
            missing_contracts = contract_targets - set(all_contracts.keys())
            if missing_contracts:
                return {
                    "success": False,
                    "error": f"Contracts {missing_contracts} not found in scope. Available contracts: {list(all_contracts.keys())}",
                    "new_contracts": set(),
                    "links": [],
                    "additional_files": [],
                }

            # Expand inheritance
            expanded_contracts = self.contract_linker.expand_inheritance(all_contracts)

            # Perform transitive linking: keep adding newly discovered contracts until no more are found
            all_links = []
            all_new_contracts = set()
            current_targets = contract_targets

            while current_targets:
                # Filter out contracts already processed for linking
                current_filtered_targets = current_targets - self.linking_processed_contracts

                if not current_filtered_targets:
                    # All current targets have been processed already
                    break

                logger.debug(f"Linking iteration for targets: {current_filtered_targets}")

                # Generate links for current filtered targets
                iteration_links = self.contract_linker.generate_links(expanded_contracts, current_filtered_targets)

                if iteration_links:
                    all_links.extend(iteration_links)

                    # Find newly discovered contracts from this iteration's links
                    newly_linked = self.contract_linker.get_linked_contracts(iteration_links)
                    logger.info(f"Linking iteration discovered {len(newly_linked)} contracts from links: {newly_linked}")

                    # Add processed contracts to global tracking
                    self.linking_processed_contracts.update(current_filtered_targets)

                    # Set up next iteration with newly discovered contracts
                    current_targets = newly_linked
                    all_new_contracts.update(newly_linked)
                else:
                    # No links generated, add processed contracts and we're done
                    self.linking_processed_contracts.update(current_filtered_targets)
                    break

            # Get additional source files for all links
            additional_files = self.contract_linker.get_additional_source_files(all_links)

            # Update configuration file with links if any were generated
            if all_links or additional_files:
                try:
                    self.config_manager.add_files_and_links_to_config(
                        config_file,
                        new_links=all_links if all_links else None,
                        new_contract_files=additional_files if additional_files else None
                    )
                    logger.info(f"Updated config file with {len(all_links or [])} links and {len(additional_files or [])} additional files")
                except Exception as e:
                    logger.error(f"Failed to update config file: {e}")

            # Generate comprehensive report
            report = self.contract_linker.generate_report()

            logger.info(f"Transitive linking completed for {contract_targets}: {len(all_links)} total links, {len(all_new_contracts)} new contracts")

            return {
                "success": True,
                "new_contracts": all_new_contracts,
                "links": all_links,
                "linking_report": report,
                "additional_files": additional_files,
            }

        except Exception as e:
            logger.error(f"Linking failed for {contract_targets}: {e}")
            return {
                "success": False,
                "error": str(e),
                "new_contracts": set(),
                "links": [],
                "additional_files": [],
            }

    async def _execute_iteration(self, iteration: int) -> IterationResult:
        """
        Execute one complete iteration with correct workflow:
        1. Linking - resolve contract dependencies
        2. Dispatching step - single call to ContractDispatcher which handles:
           a. Verification to detect unresolved calls
           b. Adding dispatcher entries for resolvable calls
           c. Re-verification to check progress
           d. Return convergence status

        Args:
            iteration: Current iteration number (for logging)

        Returns:
            IterationResult containing all data changes from this iteration
        """
        try:
            # Step 1: Linking phase
            logger.info(f"Starting iteration {iteration} - linking for {self.contract_name}")
            linking_result: LinkingResult = await self._execute_linking(iteration)
            logger.info(f"Iteration {iteration} - linking completed: success={linking_result.success}")

            if not linking_result.success:
                logger.error(f"Linking failed for {self.contract_name}")
                logger.error(f"Linking errors: {linking_result.errors}")
                return IterationResult(
                    linking_result=linking_result,
                    dispatching_result=None
                )

            # Step 2: Dispatching phase (includes verification + dispatcher + re-verification)
            logger.info(f"Iteration {iteration} - starting dispatching for {self.contract_name}")

            dispatching_result: DispatchingResult = await (
                self.contract_dispatcher.detectAndFixUnresolvedCallsStep(
                    config_file=self.config_file,
                    spec_file=self.spec_file,
                    contract_name=self.contract_name,
                    iteration=iteration,
                )
            )
            logger.info(f"Iteration {iteration} - dispatching completed: success={dispatching_result.success}")

            if not dispatching_result.success:
                error_msg = dispatching_result.error_message or "Dispatching step failed"
                logger.error(f"Dispatching failed for {self.contract_name}: {error_msg}")
                return IterationResult(
                    linking_result=linking_result,
                    dispatching_result=None
                )

            # Log convergence status
            if dispatching_result.converged:
                logger.info("Convergence achieved - no dispatcher entries added")
            else:
                logger.info(
                    f"Progress made - continuing iteration ({dispatching_result.unresolved_calls_before} calls, {dispatching_result.signatures_added} signatures added)"
                )

            # Return the data changes from this iteration
            return IterationResult(
                linking_result=linking_result,
                dispatching_result=dispatching_result
            )

        except Exception as e:
            logger.error(f"Iteration {iteration} for {self.contract_name} failed: {e}")
            return IterationResult(
                linking_result=None,
                dispatching_result=None
            )

    async def _execute_linking(self, iteration: int) -> LinkingResult:
        """
        Execute linking step with resume support and comprehensive reporting.

        This uses our new ContractLinker with caching for resume capability.
        """

        try:
            # Get contracts referenced in config file
            contracts_in_config: set[str] = {contract.contract_name for contract in self.config_manager.get_referenced_contracts(self.config_file)}

            # Contracts that need linking = contracts in config - already processed
            contracts_needing_linking: set[str] = contracts_in_config - self.linking_processed_contracts

            if not contracts_needing_linking:
                # No contracts need linking, return empty result
                logger.info("No contracts need linking - all have been processed")
                return LinkingResult(
                    new_contracts_found=set(),
                    links=[],
                    errors=[],
                    success=True,
                )

            logger.info(f"Contracts needing linking: {contracts_needing_linking} for {self.config_file}")

            # Execute new linking with comprehensive reporting
            result = await self._execute_linking_directly(
                contract_targets=contracts_needing_linking,
                config_file=self.config_file,
            )

            # Log linking statistics
            if result.get("linking_report"):
                report = result["linking_report"]
                logger.info(
                    f"Linking analysis for {self.contract_name}: "
                    f"{report.successful_links}/{report.total_state_variables} linked successfully, "
                    f"{report.ambiguous_links} ambiguous, {report.unresolved_links} unresolved"
                )

            # Check for errors in the result
            if result.get("error"):
                logger.error(
                    f"Linking returned error for {self.contract_name}: {result.get('error')}"
                )

            error = result.get("error")
            linking_result = LinkingResult(
                new_contracts_found=result.get("new_contracts", set()),
                links=result.get("links", []),
                errors=[str(error)] if error is not None else [],
                success=result.get("success", True),
            )

            return linking_result

        except Exception as e:
            logger.error(f"Linking failed with exception: {e}")
            import traceback

            logger.error(f"Linking traceback: {traceback.format_exc()}")
            return LinkingResult(
                new_contracts_found=set(),
                links=[],
                errors=[str(e)],
                success=False,
            )

