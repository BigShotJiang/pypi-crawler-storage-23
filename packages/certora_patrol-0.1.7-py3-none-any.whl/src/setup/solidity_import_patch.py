import argparse
import json
import os
import re
from pathlib import Path
from shutil import copyfile
from tqdm import tqdm # type: ignore[import-untyped]
from solidity_utils import DEPENDENCIES, find_all_solidity_files # type: ignore[import-not-found]

PATCH_FILE = ".certora_internal/import_patch.json"
KNOWN_IMPORT_ROOTS = ["contracts", "src"] + DEPENDENCIES

IMPORT_RE = re.compile(r'^\s*import\s+(?:\{[^}]+\}\s+from\s+)?["\'](.+?)["\']\s*;')

def extract_imports_multiline(lines):
    """
    Generator yielding (start_line, end_line, original_import_path) for each import statement.
    Handles multi-line structured imports like:
        import {
            A,
            B
        } from "./path.sol";
    """
    pattern = re.compile(r'^\s*import\b')
    path_pattern = re.compile(r'["\'](.+?)["\']')

    i = 0
    while i < len(lines):
        if not pattern.match(lines[i]):
            i += 1
            continue

        # Accumulate lines until semicolon
        start = i
        stmt = lines[i]
        i += 1
        while ";" not in stmt and i < len(lines):
            stmt += lines[i]
            i += 1

        # Extract import path from the full statement
        match = path_pattern.search(stmt)
        if match:
            yield start, i - 1, match.group(1)


def relative_to_project(abs_path, project_root):
    abs_path = Path(abs_path).resolve()
    project_root = Path(project_root).resolve()
    try:
        return str(abs_path.relative_to(project_root)).replace("\\", "/")
    except ValueError:
        raise Exception(f"{abs_path} is outside project root.")

def build_import_map(project_dir, all_sol_files):
    abs_imports = {}
    seen_targets = set()

    print("Building import map...")
    for file_path in tqdm(all_sol_files, desc="Analyzing imports", unit="file"):
        with open(file_path, "r") as f:
            lines = f.readlines()

        for start, end, original_import in extract_imports_multiline(lines):
            if not original_import.startswith("."):
                continue

            abs_target = (file_path.parent / original_import).resolve()
            abs_target_str = str(abs_target)

            if abs_target_str in seen_targets:
                continue
            seen_targets.add(abs_target_str)

            if not abs_target.is_file():
                # Use tqdm.write to not interfere with progress bar
                tqdm.write(f"[WARN] Skipping: '{original_import}' in {file_path} → file does not exist")
                continue

            # Try to create a canonical path within project, fallback to absolute path
            try:
                canonical_path = relative_to_project(abs_target, project_dir)
            except Exception:
                # Fallback to unique identifier using a prefix
                canonical_path = f"external/{abs_target.name}"
                # Less verbose output

            abs_imports[abs_target_str] = canonical_path

    return abs_imports


def make_absolute(import_path, current_file):
    if not import_path.startswith("."):
        return import_path  # already absolute

    current_dir = Path(current_file).parent
    abs_path = (current_dir / import_path).resolve()

    for root in KNOWN_IMPORT_ROOTS:
        try:
            root_idx = abs_path.parts.index(root)
            return "/".join(abs_path.parts[root_idx:])
        except ValueError:
            continue

    raise Exception(f"Cannot determine absolute import for: {import_path} in {current_file}")

def create_patch(project_dir):
    project_dir = Path(project_dir).resolve()
    print("Scanning for Solidity files...")
    # Change to project directory for find_all_solidity_files to work correctly
    original_cwd = os.getcwd()
    os.chdir(project_dir)
    try:
        all_sol_files = [Path(f) for f in find_all_solidity_files(
            include_test_files=False,
            include_dependencies=True,
            include_certora=False,
            verbose=False,
            log_func=lambda msg, level="INFO": None  # Suppress logs, we print our own
        )]
    finally:
        os.chdir(original_cwd)
    print(f"Found {len(all_sol_files)} Solidity files")

    import_map = build_import_map(project_dir, all_sol_files)

    patch_data = []

    for file_path in tqdm(all_sol_files, desc="Processing files", unit="file"):
        with open(file_path, "r") as f:
            lines = f.readlines()

        changes = []
        for i, line in enumerate(lines):
            match = IMPORT_RE.match(line)
            if not match:
                continue

            original_import = match.group(1)
            if original_import.startswith("."):
                abs_target = (file_path.parent / original_import).resolve()
                abs_target_str = str(abs_target)

                if abs_target_str not in import_map:
                    print(f"[WARN] Skipping unresolved import: {original_import} in {file_path}")
                    continue

                canonical_import = import_map[abs_target_str]
                if original_import.startswith("."):
                    # Removed verbose print to reduce noise with tqdm
                    changes.append({
                        "line": i,
                        "original": original_import,
                        "updated": canonical_import
                    })

        if changes:
            patch_data.append({
                "file": str(file_path),
                "changes": changes
            })

    # Ensure the directory exists
    Path(PATCH_FILE).parent.mkdir(parents=True, exist_ok=True)

    with open(PATCH_FILE, "w") as f:
        json.dump(patch_data, f, indent=2)
    print(f"✓ Patch created with {len(patch_data)} files modified: {PATCH_FILE}")


def apply_patch():
    if not os.path.exists(PATCH_FILE):
        raise Exception("Patch file not found.")

    with open(PATCH_FILE) as f:
        patch_data = json.load(f)

    print(f"Applying patch to {len(patch_data)} files...")
    backups = {}

    try:
        for entry in tqdm(patch_data, desc="Applying patches", unit="file"):
            file_path = entry["file"]
            try:
                with open(file_path, "r") as f:
                    lines = f.readlines()

                original_lines = lines[:]

                # Apply all changes to this file at once
                for change in entry["changes"]:
                    i = change["line"]
                    # Direct replacement is faster than regex for exact strings
                    lines[i] = lines[i].replace(change["original"], change["updated"])

                backups[file_path] = original_lines
                with open(file_path, "w") as f:
                    f.writelines(lines)
            except FileNotFoundError:
                tqdm.write(f"[WARN] File not found during patch application: {file_path}")
                continue
    except Exception as e:
        print(f"\nError: {e}. Reverting all changes...")
        for file_path, original in tqdm(backups.items(), desc="Reverting", unit="file"):
            with open(file_path, "w") as f:
                f.writelines(original)
        raise
    print("✓ Patch applied successfully.")

def revert_patch():
    if not os.path.exists(PATCH_FILE):
        raise Exception("Patch file not found.")

    with open(PATCH_FILE) as f:
        patch_data = json.load(f)

    print(f"Reverting patch from {len(patch_data)} files...")

    for entry in tqdm(patch_data, desc="Reverting patches", unit="file"):
        file_path = entry["file"]
        try:
            with open(file_path, "r") as f:
                lines = f.readlines()

            # Apply all reversions to this file at once
            for change in entry["changes"]:
                i = change["line"]
                # Direct replacement is faster than regex for exact strings
                lines[i] = lines[i].replace(change["updated"], change["original"])

            with open(file_path, "w") as f:
                f.writelines(lines)
        except FileNotFoundError:
            tqdm.write(f"[WARN] File not found during reversion: {file_path}")
            continue
    print("✓ Patch reverted successfully.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["create", "apply", "revert"])
    parser.add_argument("--project-dir", default=".")
    args = parser.parse_args()

    if args.command == "create":
        create_patch(args.project_dir)
    elif args.command == "apply":
        apply_patch()
    elif args.command == "revert":
        revert_patch()

