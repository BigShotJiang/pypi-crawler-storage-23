"""
AutoCVL integration module for PreAudit.

This module provides subprocess-based integration with AutoCVL for automatic
CVL specification generation. All AutoCVL code is isolated in this directory
to maintain modularity.
"""

from src.autocvl.runner import AutoCVLConfig, AutoCVLResult, AutoCVLRunner
from src.autocvl.config_builder import AutoCVLConfigBuilder

__all__ = [
    "AutoCVLConfig",
    "AutoCVLResult",
    "AutoCVLRunner",
    "AutoCVLConfigBuilder",
]
