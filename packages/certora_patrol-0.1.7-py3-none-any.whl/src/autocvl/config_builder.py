"""
AutoCVL configuration builder for PreAudit.

This module handles creating configuration files for AutoCVL's iterative mode
by extracting relevant parameters from PreAudit's base configuration.
"""

import json

import json5
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from src.utils.types import ContractHandle


class AutoCVLConfigBuilder:
    """
    Builds configuration files for AutoCVL from PreAudit base configs.

    Extracts compilation settings, prover parameters, and other relevant
    configuration from PreAudit's base-{ContractName}.conf files.
    """

    # Keys to extract from base config for AutoCVL
    COMPILATION_KEYS = [
        "files",
        "solc",
        "solc_optimize",
        "solc_via_ir",
        "packages",
        "compiler_map",
        "solc_via_ir_map",
        "solc_optimize_map",
    ]

    PROVER_KEYS = [
        "loop_iter",
        "optimistic_loop",
        "optimistic_hashing",
        "optimistic_fallback",
        "optimistic_summary_recursion",
        "summary_recursion_limit",
        "auto_dispatcher",
        "optimistic_contract_recursion",
        "contract_recursion_limit",
    ]

    def __init__(
        self,
        certora_dir: Path,
        log_func: Callable[[str, str], None],
    ):
        """
        Initialize config builder.

        Args:
            certora_dir: Path to certora/ directory for output
            log_func: Logging function (message, level)
        """
        self.certora_dir = certora_dir
        self.log = log_func

        # Create output directory for AutoCVL configs
        self.output_dir = certora_dir / "autocvl_confs"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _load_base_config(self, base_config_path: Path) -> Dict[str, Any]:
        """Load and parse base configuration file."""
        if not base_config_path.exists():
            raise FileNotFoundError(f"Base config not found: {base_config_path}")

        with open(base_config_path, "r") as f:
            content = f.read()

        # Use JSON5 which supports comments in config files
        return json5.loads(content)  # type: ignore[return-value]

    def _extract_config_values(
        self,
        base_config: Dict[str, Any],
        extra_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Extract relevant configuration values for AutoCVL.

        Args:
            base_config: Parsed base configuration
            extra_config: Additional config overrides

        Returns:
            Dict with extracted configuration
        """
        result: Dict[str, Any] = {}

        # Extract compilation settings
        for key in self.COMPILATION_KEYS:
            if key in base_config:
                result[key] = base_config[key]

        # Extract prover settings
        for key in self.PROVER_KEYS:
            if key in base_config:
                result[key] = base_config[key]

        # Apply extra config overrides
        if extra_config:
            result.update(extra_config)

        return result

    def build_conf(
        self,
        contract_handle: ContractHandle,
        base_config_path: Path,
        output_spec_name: str,
        extra_config: Optional[Dict[str, Any]] = None,
    ) -> Path:
        """
        Build AutoCVL configuration file from PreAudit base config.

        Args:
            contract_handle: Contract to generate config for
            base_config_path: Path to base-{ContractName}.conf
            output_spec_name: Name of output spec file (e.g., autocvl-Token.spec)
            extra_config: Additional config parameters

        Returns:
            Path to generated AutoCVL configuration file
        """
        contract_name = contract_handle.contract_name
        self.log(f"Building AutoCVL config for {contract_name}", "INFO")

        # Load base config
        base_config = self._load_base_config(base_config_path)

        # Extract relevant values
        autocvl_config = self._extract_config_values(base_config, extra_config)

        # Set verify target for AutoCVL
        # AutoCVL will write the spec to this location
        autocvl_config["verify"] = f"{contract_name}:{self.certora_dir / output_spec_name}"

        # Note: contract name is passed via --contract CLI argument, not in config file
        # certoraRun doesn't recognize "contract" as a valid attribute

        # Write configuration file
        output_path = self.output_dir / f"autocvl-{contract_name}.conf"

        with open(output_path, "w") as f:
            json.dump(autocvl_config, f, indent=2)

        self.log(f"Generated AutoCVL config: {output_path}", "DEBUG")
        return output_path

    def get_solc_settings(self, base_config_path: Path) -> Dict[str, Any]:
        """
        Extract solc-related settings from base config.

        Useful for single-pass mode which takes these as command-line args.

        Args:
            base_config_path: Path to base configuration

        Returns:
            Dict with solc, remappings, via_ir settings
        """
        base_config = self._load_base_config(base_config_path)

        result = {
            "solc": base_config.get("solc", "solc"),
            "via_ir": base_config.get("solc_via_ir", False),
            "remappings": [],
        }

        # Extract remappings from packages
        packages = base_config.get("packages", [])
        for pkg in packages:
            if "=" in pkg:
                result["remappings"].append(pkg)

        return result
