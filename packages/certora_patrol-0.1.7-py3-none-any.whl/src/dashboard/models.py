"""
Data models for the dashboard system.

Defines structures for rules, specs, confs, and scan snapshots.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from prover_output_utility.models import JobStatus  # type: ignore[import-untyped]


@dataclass
class RuleInfo:
    """
    Information about a single rule or invariant.

    Attributes:
        name: The rule/invariant name
        type: Either "rule" or "invariant"
        is_parametric: True if rule has method parameter
        spec_file: Path to the spec file where this rule is defined
        from_use: True if this rule was found via a 'use rule' statement
    """
    name: str
    type: str  # "rule" or "invariant"
    is_parametric: bool
    spec_file: Path
    from_use: bool = False

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "type": self.type,
            "is_parametric": self.is_parametric,
            "spec_file": str(self.spec_file),
            "from_use": self.from_use,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RuleInfo":
        """Create RuleInfo from dictionary."""
        return cls(
            name=data["name"],
            type=data["type"],
            is_parametric=data["is_parametric"],
            spec_file=Path(data["spec_file"]),
            from_use=data.get("from_use", False),
        )


@dataclass
class SpecInfo:
    """
    Information about a spec file.

    Attributes:
        path: Absolute path to the spec file
        hash: SHA256 hash of the spec file contents
        rules: List of RuleInfo for rules/invariants defined in this spec
        imported_specs: List of paths to specs imported by this spec
    """
    path: Path
    hash: str
    rules: List[RuleInfo] = field(default_factory=list)
    imported_specs: List[Path] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "path": str(self.path),
            "hash": self.hash,
            "rules": [rule.to_dict() for rule in self.rules],
            "imported_specs": [str(spec) for spec in self.imported_specs],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SpecInfo":
        """Create SpecInfo from dictionary."""
        return cls(
            path=Path(data["path"]),
            hash=data["hash"],
            rules=[RuleInfo.from_dict(r) for r in data.get("rules", [])],
            imported_specs=[Path(s) for s in data.get("imported_specs", [])],
        )


@dataclass
class ConfInfo:
    """
    Information about a configuration file.

    Attributes:
        conf_path: Absolute path to the conf file
        main_spec: Path to the main spec file from the verify field (None for Move confs)
        all_specs: List of all spec files (main + transitively imported)
        rules: List of all rule names that would be run with this conf
        main_contract: Main contract name from the verify field (part before ":")
        conf_type: Type of conf - "EVM" for Solidity/Vyper, "Move" for Move Prover, "Unknown" otherwise
    """
    conf_path: Path
    main_spec: Optional[Path]
    all_specs: List[Path] = field(default_factory=list)
    rules: List[str] = field(default_factory=list)
    main_contract: str = ""
    conf_type: str = "EVM"  # Default to EVM for backwards compatibility

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "conf_path": str(self.conf_path),
            "main_spec": str(self.main_spec) if self.main_spec else None,
            "all_specs": [str(spec) for spec in self.all_specs],
            "rules": self.rules,
            "main_contract": self.main_contract,
            "conf_type": self.conf_type,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ConfInfo":
        """Create ConfInfo from dictionary."""
        main_spec_str = data.get("main_spec")
        return cls(
            conf_path=Path(data["conf_path"]),
            main_spec=Path(main_spec_str) if main_spec_str else None,
            all_specs=[Path(s) for s in data.get("all_specs", [])],
            rules=data.get("rules", []),
            main_contract=data.get("main_contract", ""),
            conf_type=data.get("conf_type", "EVM"),
        )


@dataclass
class ScanSnapshot:
    """
    A complete snapshot of a project scan.

    Attributes:
        timestamp: Unix timestamp when scan was performed
        confs: List of ConfInfo objects for all conf files found
        specs: Dictionary mapping spec file paths to SpecInfo objects
    """
    timestamp: int
    confs: List[ConfInfo] = field(default_factory=list)
    specs: Dict[Path, SpecInfo] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "timestamp": self.timestamp,
            "confs": [conf.to_dict() for conf in self.confs],
            "specs": {str(path): spec.to_dict() for path, spec in self.specs.items()},
        }

    @classmethod
    def from_dict(cls, data: dict) -> "ScanSnapshot":
        """Create ScanSnapshot from dictionary."""
        return cls(
            timestamp=data["timestamp"],
            confs=[ConfInfo.from_dict(c) for c in data.get("confs", [])],
            specs={
                Path(path): SpecInfo.from_dict(spec)
                for path, spec in data.get("specs", {}).items()
            },
        )


@dataclass
class JobInfo:
    """
    Information about a Certora verification job.

    Attributes:
        job_id: The job identifier
        output_url: URL to the job output
        time: Unix timestamp when job was submitted
        notify_msg: Optional notification message
    """
    job_id: str
    output_url: str
    time: int
    notify_msg: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "job_id": self.job_id,
            "output_url": self.output_url,
            "time": self.time,
            "notify_msg": self.notify_msg,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "JobInfo":
        """Create JobInfo from dictionary."""
        return cls(
            job_id=data["job_id"],
            output_url=data["output_url"],
            time=data["time"],
            notify_msg=data.get("notify_msg"),
        )


@dataclass
class CexAnalysisInfo:
    """
    Information about a CEX analysis run.

    Attributes:
        job_id: Job identifier this analysis is for
        rule_name: Rule name
        method_name: Method name (for parametric rules)
        status: Status of the analysis (running, completed, failed)
        output_file: Path to the generated MD file
        timestamp: Timestamp of the scan snapshot when analysis was launched
                   (matches ScanSnapshot.timestamp for tracking freshness)
    """
    job_id: str
    rule_name: str
    method_name: Optional[str] = None
    status: str = "running"  # running, completed, failed
    output_file: Optional[str] = None
    timestamp: int = 0

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "job_id": self.job_id,
            "rule_name": self.rule_name,
            "method_name": self.method_name,
            "status": self.status,
            "output_file": self.output_file,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CexAnalysisInfo":
        """Create CexAnalysisInfo from dictionary."""
        return cls(
            job_id=data["job_id"],
            rule_name=data["rule_name"],
            method_name=data.get("method_name"),
            status=data.get("status", "running"),
            output_file=data.get("output_file"),
            timestamp=data.get("timestamp", 0),
        )


@dataclass
class TimeouterRunInfo:
    """
    Information about a timeouter run.

    Attributes:
        job_url: Original job URL that timed out
        job_id: Original job identifier
        rule_name: Rule name
        method_name: Method name
        group_id: Group ID for the portfolio runs
        group_url: URL to view all portfolio runs
        status: Status of the timeouter run (launching, running, completed, failed)
        timestamp: Unix timestamp when timeouter was launched
    """
    job_url: str
    job_id: str
    rule_name: str
    method_name: str
    group_id: Optional[str] = None
    group_url: Optional[str] = None
    status: str = "launching"  # launching, running, completed, failed
    timestamp: int = 0

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "job_url": self.job_url,
            "job_id": self.job_id,
            "rule_name": self.rule_name,
            "method_name": self.method_name,
            "group_id": self.group_id,
            "group_url": self.group_url,
            "status": self.status,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TimeouterRunInfo":
        """Create TimeouterRunInfo from dictionary."""
        return cls(
            job_url=data["job_url"],
            job_id=data["job_id"],
            rule_name=data["rule_name"],
            method_name=data["method_name"],
            group_id=data.get("group_id"),
            group_url=data.get("group_url"),
            status=data.get("status", "launching"),
            timestamp=data.get("timestamp", 0),
        )


@dataclass
class RuleStatus:
    """
    Verification status for a rule.

    Attributes:
        rule_name: Name of the rule
        overall_status: Overall status color (verified, timeout, violated, etc.)
        method_statuses: For parametric rules: dict of method -> status
        job_id: Job identifier where this status came from
        timestamp: Unix timestamp when job was run
        run_url: URL to the verification run
        job_status: Status of the job itself (JobStatus enum from ProverOutputUtility)
        spec_matches: Whether the spec file in the cloud run matches the local spec
        validation_warnings: List of validation warning messages
        spec_diff_equivalent: Whether the local spec AST matches the cloud run spec AST
                             (True if match, False if differ, None if unknown/not computed)
        has_ambiguous_conf: Whether multiple confs match this rule (by name and main contract)
        matched_main_contract: The main contract name used for conf matching
        run_provenance: Where the run came from ("local" or "remote")
        cloud_rule_name: Full cloud rule name (e.g., "0x0::bridge_rules::rule_name" for Move)
        ecosystem: Ecosystem type ("evm" or "move")
    """
    rule_name: str
    overall_status: str
    method_statuses: Dict[str, str] = field(default_factory=dict)
    job_id: str = ""
    timestamp: int = 0
    run_url: str = ""
    job_status: Optional[JobStatus] = None
    spec_matches: bool = True
    validation_warnings: List[str] = field(default_factory=list)
    spec_diff_equivalent: Optional[bool] = None
    has_ambiguous_conf: bool = False
    matched_main_contract: str = ""
    run_provenance: str = "local"
    cloud_rule_name: Optional[str] = None
    ecosystem: str = "evm"
    conf_path: Optional[str] = None  # Path to the conf this job ran with, None if no match

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "rule_name": self.rule_name,
            "overall_status": self.overall_status,
            "method_statuses": self.method_statuses,
            "job_id": self.job_id,
            "timestamp": self.timestamp,
            "run_url": self.run_url,
            "job_status": self.job_status.value if self.job_status else "",
            "spec_matches": self.spec_matches,
            "validation_warnings": self.validation_warnings,
            "spec_diff_equivalent": self.spec_diff_equivalent,
            "has_ambiguous_conf": self.has_ambiguous_conf,
            "matched_main_contract": self.matched_main_contract,
            "run_provenance": self.run_provenance,
            "cloud_rule_name": self.cloud_rule_name,
            "ecosystem": self.ecosystem,
            "conf_path": self.conf_path,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RuleStatus":
        """Create RuleStatus from dictionary."""
        from prover_output_utility.models import convert_job_status # type: ignore[import-untyped]

        job_status_raw = data.get("job_status", "")
        job_status = None
        if job_status_raw:
            if isinstance(job_status_raw, JobStatus):
                job_status = job_status_raw
            else:
                job_status = convert_job_status(job_status_raw)

        return cls(
            rule_name=data["rule_name"],
            overall_status=data["overall_status"],
            method_statuses=data.get("method_statuses", {}),
            job_id=data.get("job_id", ""),
            timestamp=data.get("timestamp", 0),
            run_url=data.get("run_url", ""),
            job_status=job_status,
            spec_matches=data.get("spec_matches", True),
            validation_warnings=data.get("validation_warnings", []),
            spec_diff_equivalent=data.get("spec_diff_equivalent"),
            has_ambiguous_conf=data.get("has_ambiguous_conf", False),
            matched_main_contract=data.get("matched_main_contract", ""),
            run_provenance=data.get("run_provenance", "local"),
            cloud_rule_name=data.get("cloud_rule_name"),
            ecosystem=data.get("ecosystem", "evm"),
            conf_path=data.get("conf_path"),
        )
