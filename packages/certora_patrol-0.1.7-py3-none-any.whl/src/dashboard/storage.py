"""
Storage module for persisting and retrieving scan data.

Handles reading/writing scan snapshots to the filesystem with timestamped
folders for historical tracking.
"""


import hashlib
import json
from pathlib import Path
from typing import Dict, Optional

from src.dashboard.constants import (
    DIR_CONF_DIFFS,
    DIR_SOURCE_DIFFS,
    DIR_SPEC_DIFFS,
    FILE_ALL_RULE_STATUSES,
    FILE_CONF_DIFF_INDEX,
    FILE_CONF_MAPPINGS,
    FILE_LATEST_SCAN,
    FILE_RULE_STATUSES,
    FILE_RULE_STATUSES_REMOTE,
    FILE_RULES_DATA,
    FILE_SCAN_METADATA,
    FILE_SELECTED_USER_RUNS,
    FILE_SPEC_DIFF_INDEX,
    MODE_REMOTE,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import ConfInfo, RuleInfo, RuleStatus, ScanSnapshot, SpecInfo
from src.utils.file_utils import atomic_write_json


def compute_file_hash(file_path: Path) -> str:
    """
    Compute SHA256 hash of a file's contents.

    Args:
        file_path: Path to the file to hash

    Returns:
        Hex digest of the SHA256 hash

    Raises:
        Exception if file cannot be read
    """
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        # Read file in chunks to handle large files
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


def collect_files_by_extension(
    base_path: Path,
    extensions: list[str],
    exclude_dirs: set[str] | None = None,
    exclude_prefixes: set[str] | None = None
) -> Dict[str, Path]:
    """
    Efficiently collect files with given extensions, skipping excluded directories.

    Uses manual directory walking to skip excluded directories entirely,
    avoiding traversal of large directories like node_modules.

    Args:
        base_path: Root directory to search
        extensions: List of file extensions to include (e.g., [".sol", ".vy"])
        exclude_dirs: Set of directory names to skip entirely (default: common build/cache dirs)
        exclude_prefixes: Set of directory name prefixes to skip (default: .pre_autofinders., .post_autofinders.)

    Returns:
        Dict mapping relative path (str) to absolute path (Path)
    """
    files: dict[str, Path] = {}

    if not base_path.exists():
        logger.log(
            f"Base path does not exist: {base_path}",
            "WARNING",
            "Storage"
        )
        return files

    # Default exclusions if not provided
    if exclude_dirs is None:
        exclude_dirs = {
            '.certora_internal',
            '.git',
            'node_modules',
            '.venv',
            'venv',
            '__pycache__',
            '.pytest_cache',
            'build',
            'dist',
            '.tox',
            '.mypy_cache',
        }

    if exclude_prefixes is None:
        exclude_prefixes = {'.pre_autofinders.', '.post_autofinders.'}

    # Convert extensions to set for O(1) lookup
    ext_set = set(extensions)

    def should_skip_dir(dir_name: str) -> bool:
        """Check if directory should be skipped entirely."""
        if dir_name in exclude_dirs:
            return True
        return any(dir_name.startswith(prefix) for prefix in exclude_prefixes)

    def walk_directory(current_path: Path, rel_parts: tuple = ()) -> None:
        """Recursively walk directory, skipping excluded dirs."""
        try:
            for item in current_path.iterdir():
                if item.is_dir():
                    # Skip excluded directories - don't recurse into them
                    if should_skip_dir(item.name):
                        continue
                    # Recurse into allowed directories
                    walk_directory(item, rel_parts + (item.name,))
                elif item.is_file():
                    # Check if file has desired extension
                    if item.suffix in ext_set:
                        rel_path = '/'.join(rel_parts + (item.name,)) if rel_parts else item.name
                        files[rel_path] = item
        except PermissionError:
            # Skip directories we don't have permission to read
            logger.log(
                f"Permission denied accessing {current_path}",
                "DEBUG",
                "Storage"
            )
        except Exception as e:
            # Log but don't fail on other errors
            logger.log(
                f"Error walking directory {current_path}: {e}",
                "DEBUG",
                "Storage"
            )

    walk_directory(base_path)
    return files


def compare_scan_results(
    new_specs: dict,
    new_confs: list,
    previous_snapshot: ScanSnapshot
) -> bool:
    """
    Compare new scan results with the previous snapshot to detect changes.

    Args:
        new_specs: Dictionary of Path -> SpecInfo from the new scan
        new_confs: List of ConfInfo from the new scan
        previous_snapshot: The previous ScanSnapshot to compare against

    Returns:
        True if the scan results are identical, False if anything changed

    Compares:
        1. Same set of spec file paths
        2. Same hash values for each spec file
        3. Same set of conf file paths
    """
    # Compare spec files
    new_spec_hashes = {str(path): spec.hash for path, spec in new_specs.items()}
    prev_spec_hashes = {str(path): spec.hash for path, spec in previous_snapshot.specs.items()}

    if new_spec_hashes != prev_spec_hashes:
        logger.log(
            "Scan results changed: spec file hashes differ",
            "INFO",
            "Storage"
        )
        return False

    # Compare conf file paths
    new_conf_paths = {str(conf.conf_path) for conf in new_confs}
    prev_conf_paths = {str(conf.conf_path) for conf in previous_snapshot.confs}

    if new_conf_paths != prev_conf_paths:
        logger.log(
            "Scan results changed: conf files differ",
            "INFO",
            "Storage"
        )
        return False

    logger.log(
        "Scan results unchanged",
        "INFO",
        "Storage"
    )
    return True


def save_scan_snapshot(snapshot: ScanSnapshot, dashboard_dir: Path, source_file_hashes: Optional[Dict[str, str]] = None) -> Path:
    """
    Save a scan snapshot to the dashboard directory.

    Creates a timestamped folder with the scan data and updates the
    latest_scan pointer.

    Args:
        snapshot: The ScanSnapshot to save
        dashboard_dir: Path to .certora_internal/local_dashboard
        source_file_hashes: Optional dict mapping source file paths to SHA256 hashes

    Returns:
        Path to the created timestamped folder

    Storage structure:
        {dashboard_dir}/
        ├── latest_scan              # Contains timestamp
        └── {timestamp}/
            ├── scan_metadata.json
            ├── rules_data.json
            └── conf_mappings.json
    """
    # Create dashboard directory if it doesn't exist
    dashboard_dir.mkdir(parents=True, exist_ok=True)

    # Create timestamped folder
    timestamp_dir = dashboard_dir / str(snapshot.timestamp)
    timestamp_dir.mkdir(parents=True, exist_ok=True)

    # Build scan_metadata.json
    spec_file_hashes = {
        str(path): spec.hash for path, spec in snapshot.specs.items()
    }
    scan_metadata = {
        "timestamp": snapshot.timestamp,
        "spec_file_hashes": spec_file_hashes,
    }

    # Add source file hashes if provided
    if source_file_hashes:
        scan_metadata["source_file_hashes"] = source_file_hashes

    # Build rules_data.json
    all_rules = []
    for spec_info in snapshot.specs.values():
        for rule in spec_info.rules:
            all_rules.append(rule.to_dict())
    rules_data = {"rules": all_rules}

    # Build conf_mappings.json
    confs_data = {"confs": [conf.to_dict() for conf in snapshot.confs]}

    # Write files
    try:
        with open(timestamp_dir / FILE_SCAN_METADATA, "w") as f:
            json.dump(scan_metadata, f, indent=2)

        with open(timestamp_dir / FILE_RULES_DATA, "w") as f:
            json.dump(rules_data, f, indent=2)

        with open(timestamp_dir / FILE_CONF_MAPPINGS, "w") as f:
            json.dump(confs_data, f, indent=2)

        # Update latest_scan pointer
        with open(dashboard_dir / FILE_LATEST_SCAN, "w") as f:
            f.write(str(snapshot.timestamp))

        logger.log(
            f"Saved scan snapshot to {timestamp_dir}",
            "INFO",
            "Storage"
        )

        return timestamp_dir

    except Exception as e:
        logger.log(
            f"Error saving scan snapshot: {e}",
            "ERROR",
            "Storage"
        )
        raise


def load_latest_scan(dashboard_dir: Path) -> Optional[ScanSnapshot]:
    """
    Load the latest scan snapshot from the dashboard directory.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        ScanSnapshot object, or None if no scan exists or error

    Reads the latest_scan file to get the timestamp, then loads the
    corresponding scan data.
    """
    latest_scan_file = dashboard_dir / FILE_LATEST_SCAN

    if not latest_scan_file.exists():
        logger.log(
            "No latest_scan file found",
            "INFO",
            "Storage"
        )
        return None

    try:
        # Read timestamp from latest_scan
        with open(latest_scan_file, "r") as f:
            timestamp_str = f.read().strip()
            timestamp = int(timestamp_str)

        # Load scan data from timestamped folder
        timestamp_dir = dashboard_dir / timestamp_str

        if not timestamp_dir.exists():
            logger.log(
                f"Scan folder {timestamp_dir} does not exist",
                "WARNING",
                "Storage"
            )
            return None

        # Load scan_metadata.json
        with open(timestamp_dir / FILE_SCAN_METADATA, "r") as f:
            scan_metadata = json.load(f)

        # Load rules_data.json
        with open(timestamp_dir / FILE_RULES_DATA, "r") as f:
            rules_data = json.load(f)

        # Load conf_mappings.json
        with open(timestamp_dir / FILE_CONF_MAPPINGS, "r") as f:
            confs_data = json.load(f)

        # Rebuild specs dictionary
        specs = {}
        # First, create SpecInfo objects with hashes but empty rules
        for spec_path_str, hash_value in scan_metadata["spec_file_hashes"].items():
            spec_path = Path(spec_path_str)
            specs[spec_path] = SpecInfo(
                path=spec_path,
                hash=hash_value,
                rules=[],
                imported_specs=[]
            )

        # Then, add rules to the appropriate specs
        for rule_dict in rules_data["rules"]:
            rule = RuleInfo.from_dict(rule_dict)
            if rule.spec_file in specs:
                specs[rule.spec_file].rules.append(rule)

        # Rebuild confs list
        confs = [ConfInfo.from_dict(conf_dict) for conf_dict in confs_data["confs"]]

        # Create and return snapshot
        snapshot = ScanSnapshot(
            timestamp=timestamp,
            confs=confs,
            specs=specs
        )

        logger.log(
            f"Loaded scan snapshot from {timestamp_dir}",
            "INFO",
            "Storage"
        )

        return snapshot

    except Exception as e:
        logger.log(
            f"Error loading scan snapshot: {e}",
            "ERROR",
            "Storage"
        )
        return None


def load_source_file_hashes(timestamp_dir: Path) -> Optional[Dict[str, str]]:
    """
    Load source file hashes from scan_metadata.json.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping relative path to SHA256 hash, or None if not available
    """
    metadata_file = timestamp_dir / FILE_SCAN_METADATA

    if not metadata_file.exists():
        return None

    try:
        with open(metadata_file, "r") as f:
            metadata = json.load(f)
            return metadata.get("source_file_hashes")
    except Exception as e:
        logger.log(
            f"Error loading source file hashes: {e}",
            "WARNING",
            "Storage"
        )
        return None


def save_rule_statuses(
    statuses: Dict[str, RuleStatus],
    dashboard_dir: Path,
    mode: str = "local"
) -> None:
    """
    Save rule statuses to the dashboard directory.

    Args:
        statuses: Dictionary of rule_name -> RuleStatus
        dashboard_dir: Path to .certora_internal/local_dashboard
        mode: "local" for local runs or "remote" for all runs

    Saves to {dashboard_dir}/rule_statuses.json or rule_statuses_remote.json
    This ensures statuses persist across scans.
    """
    try:
        dashboard_dir.mkdir(parents=True, exist_ok=True)

        # Convert statuses to dict format
        statuses_data = {
            rule_name: status.to_dict()
            for rule_name, status in statuses.items()
        }

        # Choose file based on mode
        filename = FILE_RULE_STATUSES_REMOTE if mode == MODE_REMOTE else FILE_RULE_STATUSES
        status_file = dashboard_dir / filename
        with open(status_file, "w") as f:
            json.dump(statuses_data, f, indent=2)

        logger.log(
            f"Saved {len(statuses)} rule statuses ({mode} mode)",
            "INFO",
            "Storage"
        )

    except Exception as e:
        logger.log(
            f"Error saving rule statuses: {e}",
            "ERROR",
            "Storage"
        )


def load_rule_statuses(dashboard_dir: Path, mode: str = "local") -> Dict[str, RuleStatus]:
    """
    Load rule statuses from the dashboard directory.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        mode: "local" for local runs or "remote" for all runs

    Returns:
        Dictionary of rule_name -> RuleStatus, or empty dict if not found

    Loads from {dashboard_dir}/rule_statuses.json or rule_statuses_remote.json
    """
    filename = FILE_RULE_STATUSES_REMOTE if mode == MODE_REMOTE else FILE_RULE_STATUSES
    statuses_file = dashboard_dir / filename

    if not statuses_file.exists():
        logger.log(
            f"No rule statuses file found ({mode} mode)",
            "INFO",
            "Storage"
        )
        return {}

    try:
        # Load statuses
        with open(statuses_file, "r") as f:
            statuses_data = json.load(f)

        # Convert to RuleStatus objects
        statuses = {
            rule_name: RuleStatus.from_dict(status_dict)
            for rule_name, status_dict in statuses_data.items()
        }

        logger.log(
            f"Loaded {len(statuses)} rule statuses ({mode} mode)",
            "INFO",
            "Storage"
        )

        return statuses

    except Exception as e:
        logger.log(
            f"Error loading rule statuses: {e}",
            "ERROR",
            "Storage"
        )
        return {}


def save_spec_diff_for_job(
    timestamp_dir: Path,
    job_id: str,
    job_url: str,
    computed_at: float,
    local_timestamp: str,
    rules_diff_data: Dict[str, Dict]
) -> bool:
    """
    Save spec diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        job_url: The URL of the cloud run
        computed_at: Unix timestamp of when diff was computed
        local_timestamp: The local snapshot timestamp
        rules_diff_data: Dict mapping rule_name -> diff result (with code snippets)

    Returns:
        True if saved successfully, False otherwise

    Saves to: {timestamp_dir}/spec_diffs/{job_id}.json
    """
    try:
        spec_diffs_dir = timestamp_dir / DIR_SPEC_DIFFS
        spec_diffs_dir.mkdir(parents=True, exist_ok=True)

        diff_file = spec_diffs_dir / f"{job_id}.json"

        diff_data = {
            "job_id": job_id,
            "job_url": job_url,
            "computed_at": computed_at,
            "local_timestamp": local_timestamp,
            "rules": rules_diff_data
        }

        # Use atomic write to prevent race conditions with concurrent reads
        atomic_write_json(diff_file, diff_data)

        logger.log(
            f"Saved spec diff for job {job_id} ({len(rules_diff_data)} rules)",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error saving spec diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return False


def load_spec_diff_for_job(timestamp_dir: Path, job_id: str) -> Optional[Dict]:
    """
    Load spec diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID to load

    Returns:
        Dict with job metadata and rules diff data, or None if not found

    Loads from: {timestamp_dir}/spec_diffs/{job_id}.json
    """
    try:
        diff_file = timestamp_dir / DIR_SPEC_DIFFS / f"{job_id}.json"

        if not diff_file.exists():
            logger.log(
                f"No spec diff found for job {job_id}",
                "INFO",
                "Storage"
            )
            return None

        with open(diff_file, 'r') as f:
            diff_data = json.load(f)

        logger.log(
            f"Loaded spec diff for job {job_id} ({len(diff_data.get('rules', {}))} rules)",
            "DEBUG",
            "Storage"
        )

        return diff_data

    except Exception as e:
        logger.log(
            f"Error loading spec diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return None


def load_spec_diff_index(timestamp_dir: Path) -> Dict:
    """
    Load the spec diff index that maps rules to their job IDs.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping rule_name -> {"non_equivalent": [...], "equivalent": [...]}
        Returns empty dict if index not found

    Loads from: {timestamp_dir}/spec_diffs/index.json

    Format:
    {
        "ruleName": {
            "non_equivalent": ["job_id_1", "job_id_2"],  # newest first
            "equivalent": ["job_id_3"]                     # newest first
        }
    }
    """
    try:
        index_file = timestamp_dir / DIR_SPEC_DIFFS / FILE_SPEC_DIFF_INDEX

        if not index_file.exists():
            logger.log(
                f"No spec diff index found at {index_file}",
                "INFO",
                "Storage"
            )
            return {}

        with open(index_file, 'r') as f:
            index_data = json.load(f)

        logger.log(
            f"Loaded spec diff index ({len(index_data)} rules)",
            "INFO",
            "Storage"
        )

        return index_data

    except Exception as e:
        logger.log(
            f"Error loading spec diff index: {e}",
            "ERROR",
            "Storage"
        )
        return {}


def update_spec_diff_index(
    timestamp_dir: Path,
    job_id: str,
    rules_equivalence: Dict[str, bool]
) -> bool:
    """
    Update the spec diff index with results from a new job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID being added
        rules_equivalence: Dict mapping rule_name -> equivalent (True/False)

    Returns:
        True if updated successfully, False otherwise

    Updates: {timestamp_dir}/spec_diffs/index.json

    For each rule:
    - Add job_id to "non_equivalent" or "equivalent" list
    - Maintain chronological order (newest first)
    - Create entry if rule doesn't exist in index
    """
    try:
        spec_diffs_dir = timestamp_dir / DIR_SPEC_DIFFS
        spec_diffs_dir.mkdir(parents=True, exist_ok=True)

        index_file = spec_diffs_dir / FILE_SPEC_DIFF_INDEX

        # Load existing index
        index_data = load_spec_diff_index(timestamp_dir)

        # Update index for each rule
        for rule_name, is_equivalent in rules_equivalence.items():
            if rule_name not in index_data:
                index_data[rule_name] = {
                    "non_equivalent": [],
                    "equivalent": []
                }

            # Add to appropriate list (at the beginning for newest first)
            if is_equivalent:
                if job_id not in index_data[rule_name]["equivalent"]:
                    index_data[rule_name]["equivalent"].insert(0, job_id)
            else:
                if job_id not in index_data[rule_name]["non_equivalent"]:
                    index_data[rule_name]["non_equivalent"].insert(0, job_id)

        # Save updated index
        with open(index_file, 'w') as f:
            json.dump(index_data, f, indent=2)

        logger.log(
            f"Updated spec diff index for job {job_id} ({len(rules_equivalence)} rules)",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error updating spec diff index: {e}",
            "ERROR",
            "Storage"
        )
        return False


def save_conf_diff_for_job(
    timestamp_dir: Path,
    job_id: str,
    job_url: str,
    computed_at: float,
    local_timestamp: str,
    diff_result: Dict
) -> bool:
    """
    Save conf diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        job_url: The URL of the cloud run
        computed_at: Unix timestamp of when diff was computed
        local_timestamp: The local snapshot timestamp
        diff_result: Dict with diff result (equivalent, reason, or diff_data)

    Returns:
        True if saved successfully, False otherwise

    Saves to: {timestamp_dir}/conf_diffs/{job_id}.json
    """
    try:
        conf_diffs_dir = timestamp_dir / DIR_CONF_DIFFS
        conf_diffs_dir.mkdir(parents=True, exist_ok=True)

        diff_file = conf_diffs_dir / f"{job_id}.json"

        diff_data = {
            "job_id": job_id,
            "job_url": job_url,
            "computed_at": computed_at,
            "local_timestamp": local_timestamp,
            **diff_result
        }

        # Use atomic write to prevent race conditions with concurrent reads
        atomic_write_json(diff_file, diff_data)

        logger.log(
            f"Saved conf diff for job {job_id}",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error saving conf diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return False


def load_conf_diff_for_job(timestamp_dir: Path, job_id: str) -> Optional[Dict]:
    """
    Load conf diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID to load

    Returns:
        Dict with job metadata and conf diff data, or None if not found

    Loads from: {timestamp_dir}/conf_diffs/{job_id}.json
    """
    try:
        diff_file = timestamp_dir / DIR_CONF_DIFFS / f"{job_id}.json"

        if not diff_file.exists():
            logger.log(
                f"No conf diff found for job {job_id}",
                "INFO",
                "Storage"
            )
            return None

        with open(diff_file, 'r') as f:
            diff_data = json.load(f)

        logger.log(
            f"Loaded conf diff for job {job_id}",
            "DEBUG",
            "Storage"
        )

        return diff_data

    except Exception as e:
        logger.log(
            f"Error loading conf diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return None


def load_conf_diff_index(timestamp_dir: Path) -> Dict[str, Dict]:
    """
    Load the conf diff index.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping job_id -> {equivalent: bool}, or empty dict if not found

    Loads from: {timestamp_dir}/conf_diffs/index.json
    """
    try:
        index_file = timestamp_dir / DIR_CONF_DIFFS / FILE_CONF_DIFF_INDEX

        if not index_file.exists():
            logger.log(
                "No conf diff index found",
                "INFO",
                "Storage"
            )
            return {}

        with open(index_file, 'r') as f:
            index_data = json.load(f)

        logger.log(
            f"Loaded conf diff index ({len(index_data)} jobs)",
            "INFO",
            "Storage"
        )

        return index_data

    except Exception as e:
        logger.log(
            f"Error loading conf diff index: {e}",
            "ERROR",
            "Storage"
        )
        return {}


def update_conf_diff_index(
    timestamp_dir: Path,
    job_id: str,
    is_equivalent: bool
) -> bool:
    """
    Update the conf diff index with result from a job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID being added
        is_equivalent: Whether the local and remote confs are equivalent

    Returns:
        True if updated successfully, False otherwise

    Updates: {timestamp_dir}/conf_diffs/index.json
    """
    try:
        conf_diffs_dir = timestamp_dir / DIR_CONF_DIFFS
        conf_diffs_dir.mkdir(parents=True, exist_ok=True)

        index_file = conf_diffs_dir / FILE_CONF_DIFF_INDEX

        # Load existing index
        index_data = load_conf_diff_index(timestamp_dir)

        # Update index for this job
        index_data[job_id] = {"equivalent": is_equivalent}

        # Save updated index
        with open(index_file, 'w') as f:
            json.dump(index_data, f, indent=2)

        logger.log(
            f"Updated conf diff index for job {job_id}",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error updating conf diff index: {e}",
            "ERROR",
            "Storage"
        )
        return False


def save_source_diff_for_job(
    timestamp_dir: Path,
    job_id: str,
    diff_result: Dict
) -> bool:
    """
    Save source diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        diff_result: Dict with diff result (equivalent, reason, file_diffs)

    Returns:
        True if saved successfully, False otherwise

    Saves to: {timestamp_dir}/source_diffs/{job_id}.json
    """
    try:
        source_diffs_dir = timestamp_dir / DIR_SOURCE_DIFFS
        source_diffs_dir.mkdir(parents=True, exist_ok=True)

        diff_file = source_diffs_dir / f"{job_id}.json"

        diff_data = {
            "job_id": job_id,
            **diff_result
        }

        # Use atomic write to prevent race conditions with concurrent reads
        atomic_write_json(diff_file, diff_data)

        logger.log(
            f"Saved source diff for job {job_id}",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error saving source diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return False


def load_source_diff_for_job(timestamp_dir: Path, job_id: str) -> Optional[Dict]:
    """
    Load source diff data for a specific job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID to load

    Returns:
        Dict with job metadata and source diff data, or None if not found

    Loads from: {timestamp_dir}/source_diffs/{job_id}.json
    """
    try:
        diff_file = timestamp_dir / DIR_SOURCE_DIFFS / f"{job_id}.json"

        if not diff_file.exists():
            logger.log(
                f"No source diff found for job {job_id}",
                "DEBUG",
                "Storage"
            )
            return None

        with open(diff_file, 'r') as f:
            diff_data = json.load(f)

        logger.log(
            f"Loaded source diff for job {job_id}",
            "DEBUG",
            "Storage"
        )

        return diff_data

    except Exception as e:
        logger.log(
            f"Error loading source diff for job {job_id}: {e}",
            "ERROR",
            "Storage"
        )
        return None


def update_source_diff_index(
    timestamp_dir: Path,
    job_id: str,
    is_equivalent: Optional[bool]
) -> bool:
    """
    Update the source diff index with result from a job.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory
        job_id: The job ID being added
        is_equivalent: Whether the local and remote sources are equivalent (None if couldn't compare)

    Returns:
        True if updated successfully, False otherwise

    Updates: {timestamp_dir}/source_diffs/index.json
    """
    try:
        source_diffs_dir = timestamp_dir / DIR_SOURCE_DIFFS
        source_diffs_dir.mkdir(parents=True, exist_ok=True)

        index_file = source_diffs_dir / "index.json"

        # Load existing index
        if index_file.exists():
            with open(index_file, 'r') as f:
                index_data = json.load(f)
        else:
            index_data = {}

        # Update index for this job
        index_data[job_id] = {"equivalent": is_equivalent}

        # Save updated index
        with open(index_file, 'w') as f:
            json.dump(index_data, f, indent=2)

        logger.log(
            f"Updated source diff index for job {job_id}",
            "INFO",
            "Storage"
        )

        return True

    except Exception as e:
        logger.log(
            f"Error updating source diff index: {e}",
            "ERROR",
            "Storage"
        )
        return False


def load_all_rule_statuses(dashboard_dir: Path) -> Dict[str, list]:
    """
    Load all rule statuses (history of all jobs) from the dashboard directory.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Dictionary of rule_name -> List[RuleStatus], sorted by timestamp (newest first)
        Returns empty dict if file not found

    Loads from {dashboard_dir}/all_rule_statuses.json

    Format:
    {
        "ruleName": [
            {RuleStatus dict for job1 (newest)},
            {RuleStatus dict for job2},
            ...
        ]
    }
    """
    statuses_file = dashboard_dir / FILE_ALL_RULE_STATUSES

    if not statuses_file.exists():
        logger.log(
            "No all_rule_statuses.json file found",
            "INFO",
            "Storage"
        )
        return {}

    try:
        with open(statuses_file, "r") as f:
            statuses_data = json.load(f)

        # Convert to RuleStatus objects
        all_statuses = {}
        for rule_name, status_list in statuses_data.items():
            all_statuses[rule_name] = [
                RuleStatus.from_dict(status_dict)
                for status_dict in status_list
            ]

        logger.log(
            f"Loaded all_rule_statuses for {len(all_statuses)} rules",
            "INFO",
            "Storage"
        )

        return all_statuses

    except Exception as e:
        logger.log(
            f"Error loading all_rule_statuses: {e}",
            "ERROR",
            "Storage"
        )
        return {}


def save_all_rule_statuses(
    all_statuses: Dict[str, list],
    dashboard_dir: Path
) -> None:
    """
    Save all rule statuses (history) to the dashboard directory.

    Args:
        all_statuses: Dictionary of rule_name -> List[RuleStatus]
        dashboard_dir: Path to .certora_internal/local_dashboard

    Saves to {dashboard_dir}/all_rule_statuses.json
    Each rule's list should be sorted by timestamp (newest first)
    """
    try:
        dashboard_dir.mkdir(parents=True, exist_ok=True)

        # Convert to dict format
        statuses_data = {}
        for rule_name, status_list in all_statuses.items():
            statuses_data[rule_name] = [
                status.to_dict() for status in status_list
            ]

        status_file = dashboard_dir / FILE_ALL_RULE_STATUSES
        atomic_write_json(status_file, statuses_data)

        total_jobs = sum(len(statuses) for statuses in all_statuses.values())
        logger.log(
            f"Saved all_rule_statuses for {len(all_statuses)} rules ({total_jobs} total jobs)",
            "INFO",
            "Storage"
        )

    except Exception as e:
        logger.log(
            f"Error saving all_rule_statuses: {e}",
            "ERROR",
            "Storage"
        )


def load_user_run_selections(dashboard_dir: Path) -> Dict[str, Dict[str, str]]:
    """
    Load user's selected runs for each rule/method.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Dictionary mapping rule_name -> {method_name -> job_id}
        Special key "_rule_level" for non-parametric rules
        Returns empty dict if file not found

    Format:
    {
        "ruleName": {
            "_rule_level": "job_id_for_rule",
            "methodName1": "job_id_for_method1"
        }
    }
    """
    selections_file = dashboard_dir / FILE_SELECTED_USER_RUNS

    if not selections_file.exists():
        logger.log(
            "No selected_user_runs.json file found",
            "INFO",
            "Storage"
        )
        return {}

    try:
        with open(selections_file, "r") as f:
            selections = json.load(f)

        logger.log(
            f"Loaded user run selections for {len(selections)} rules",
            "INFO",
            "Storage"
        )

        return selections

    except Exception as e:
        logger.log(
            f"Error loading user run selections: {e}",
            "ERROR",
            "Storage"
        )
        return {}


def save_user_run_selections(
    selections: Dict[str, Dict[str, str]],
    dashboard_dir: Path
) -> None:
    """
    Save user's selected runs for each rule/method.

    Args:
        selections: Dictionary mapping rule_name -> {method_name -> job_id}
        dashboard_dir: Path to .certora_internal/local_dashboard

    Saves to {dashboard_dir}/selected_user_runs.json
    """
    try:
        dashboard_dir.mkdir(parents=True, exist_ok=True)

        selections_file = dashboard_dir / FILE_SELECTED_USER_RUNS
        atomic_write_json(selections_file, selections)

        logger.log(
            f"Saved user run selections for {len(selections)} rules",
            "INFO",
            "Storage"
        )

    except Exception as e:
        logger.log(
            f"Error saving user run selections: {e}",
            "ERROR",
            "Storage"
        )
