"""
Dashboard module for tracking and visualizing Certora verification project status.

This module provides functionality to:
- Scan projects for conf files, spec files, and rules
- Track verification statuses from cloud runs
- Display interactive dashboard with rule statuses
"""
