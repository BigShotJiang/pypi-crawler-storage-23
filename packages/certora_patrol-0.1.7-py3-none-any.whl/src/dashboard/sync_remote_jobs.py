"""
Sync remote Certora jobs from the data API.

Fetches all verification jobs for the current project from the Certora data API
and stores them in .certora_internal/.certora_remote_jobs.json.

Supports incremental sync - only fetches jobs newer than the most recent existing job.
"""


import json
import re
import subprocess
import sys
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from src.dashboard.constants import (
    API_CERTORA_DATA_BASE,
    API_JOB_METADATA,
    CloudAPIEcosystem,
    DashboardEcosystem,
    DIR_CERTORA_INTERNAL,
    DIR_TMP,
    DOMAIN_PROVER_CERTORA,
    FILE_REMOTE_JOBS,
    normalize_to_dashboard_ecosystem,
    to_cloud_api_ecosystem,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.utils.certora_wget import download_with_auth, get_auth_cookies


def normalize_git_url(url: str) -> str:
    """
    Normalize git URL to common format for comparison.

    Converts both SSH and HTTPS URLs to format: domain/org/repo

    Examples:
        git@github.com:Certora/sui → github.com/Certora/sui
        https://github.com/Certora/sui.git → github.com/Certora/sui
        git@github.com:Certora/sui.git → github.com/Certora/sui

    Args:
        url: Git remote URL in any format

    Returns:
        Normalized URL string
    """
    # Remove .git suffix
    if url.endswith(".git"):
        url = url[:-4]

    # Convert SSH format (git@github.com:org/repo) to path format
    if url.startswith("git@"):
        # Extract domain and path
        match = re.match(r'git@([^:]+):(.+)', url)
        if match:
            domain = match.group(1)
            path = match.group(2)
            return f"{domain}/{path}"

    # Convert HTTPS format (https://github.com/org/repo)
    if url.startswith("https://") or url.startswith("http://"):
        # Remove protocol
        url = re.sub(r'^https?://', '', url)

    return url


def get_git_remote_origin(project_root: Path) -> Optional[str]:
    """
    Get the normalized git remote origin URL for the project.

    Args:
        project_root: Path to the project root directory

    Returns:
        Normalized origin URL, or None if not a git repo or no origin

    Example:
        For a repo with origin git@github.com:Certora/sui,
        returns "github.com/Certora/sui"
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode != 0:
            logger.log(
                f"Git remote get-url failed: {result.stderr}",
                "DEBUG",
                "RemoteJobsSync"
            )
            return None

        origin_url = result.stdout.strip()
        if not origin_url:
            return None

        normalized = normalize_git_url(origin_url)
        logger.log(
            f"Detected git origin: {origin_url} → {normalized}",
            "INFO",
            "RemoteJobsSync"
        )
        return normalized

    except subprocess.TimeoutExpired:
        logger.log(
            "Git command timed out",
            "WARNING",
            "RemoteJobsSync"
        )
        return None
    except Exception as e:
        logger.log(
            f"Error getting git remote: {e}",
            "WARNING",
            "RemoteJobsSync"
        )
        return None


def has_move_confs(project_root: Path) -> bool:
    """
    Check if the project has any Move configuration files.

    Args:
        project_root: Path to the project root directory

    Returns:
        True if any conf has conf_type == "Move", False otherwise
    """
    try:
        # Find latest snapshot
        local_dashboard_dir = project_root / DIR_CERTORA_INTERNAL / "local_dashboard"
        if not local_dashboard_dir.exists():
            return False

        latest_scan_path = local_dashboard_dir / "latest_scan"
        if not latest_scan_path.exists():
            return False

        with open(latest_scan_path, 'r') as f:
            latest_snapshot_name = f.read().strip()

        latest_snapshot = local_dashboard_dir / latest_snapshot_name
        if not latest_snapshot.exists():
            return False

        # Read conf_mappings.json
        conf_mappings_path = latest_snapshot / "conf_mappings.json"
        if not conf_mappings_path.exists():
            return False

        with open(conf_mappings_path, 'r') as f:
            conf_mappings_data = json.load(f)

        # Extract confs array
        if isinstance(conf_mappings_data, dict) and "confs" in conf_mappings_data:
            conf_mappings = conf_mappings_data["confs"]
        elif isinstance(conf_mappings_data, list):
            conf_mappings = conf_mappings_data
        else:
            return False

        # Check if any conf is Move type
        for conf_data in conf_mappings:
            if conf_data.get("conf_type") == "Move":
                logger.log(
                    f"Found Move conf: {conf_data.get('conf_path')}",
                    "INFO",
                    "RemoteJobsSync"
                )
                return True

        return False

    except Exception as e:
        logger.log(
            f"Error checking for Move confs: {e}",
            "WARNING",
            "RemoteJobsSync"
        )
        return False


def has_rust_confs(project_root: Path) -> bool:
    """
    Check if the project has any Rust configuration files.

    Args:
        project_root: Path to the project root directory

    Returns:
        True if any conf has conf_type == "Rust", False otherwise
    """
    try:
        # Find latest snapshot
        local_dashboard_dir = project_root / DIR_CERTORA_INTERNAL / "local_dashboard"
        if not local_dashboard_dir.exists():
            return False

        latest_scan_path = local_dashboard_dir / "latest_scan"
        if not latest_scan_path.exists():
            return False

        with open(latest_scan_path, 'r') as f:
            latest_snapshot_name = f.read().strip()

        latest_snapshot = local_dashboard_dir / latest_snapshot_name
        if not latest_snapshot.exists():
            return False

        # Read conf_mappings.json
        conf_mappings_path = latest_snapshot / "conf_mappings.json"
        if not conf_mappings_path.exists():
            return False

        with open(conf_mappings_path, 'r') as f:
            conf_mappings_data = json.load(f)

        # Extract confs array
        if isinstance(conf_mappings_data, dict) and "confs" in conf_mappings_data:
            conf_mappings = conf_mappings_data["confs"]
        elif isinstance(conf_mappings_data, list):
            conf_mappings = conf_mappings_data
        else:
            return False

        # Check if any conf is Rust type
        for conf_data in conf_mappings:
            if conf_data.get("conf_type") == "Rust":
                logger.log(
                    f"Found Rust conf: {conf_data.get('conf_path')}",
                    "INFO",
                    "RemoteJobsSync"
                )
                return True

        return False

    except Exception as e:
        logger.log(
            f"Error checking for Rust confs: {e}",
            "WARNING",
            "RemoteJobsSync"
        )
        return False


def fetch_job_metadata(job_id: str, tmp_dir: Path | None = None, auth_cookies: Optional[Dict] = None) -> Dict:
    """
    Fetch job metadata from the Certora API.

    Args:
        job_id: Job identifier (with or without hyphens)
        tmp_dir: DEPRECATED - no longer used, kept for backwards compatibility
        auth_cookies: DEPRECATED - ProverOutputAPI handles auth automatically

    Returns:
        Dictionary with job metadata including "main_spec" field,
        or empty dict on error

    API endpoint: https://data-api.certora.com/v1/domain/job-metadata/{job_id}
    """
    try:
        # Use _create_prover_api for serialized auth (prevents concurrent OAuth)
        from src.dashboard.cloud_sync import _create_prover_api

        prover_api = _create_prover_api()

        # Fetch metadata using custom endpoint
        # fetch_custom_endpoint requires the full URL
        metadata = prover_api.fetch_custom_endpoint(f"https://data-api.certora.com/v1/domain/job-metadata/{job_id}")

        return metadata

    except Exception as e:
        logger.log(
            f"Error fetching metadata for job {job_id}: {e}",
            "WARNING",
            "RemoteJobsSync"
        )
        return {}


def _fetch_and_filter_job(job: Dict, git_origin: str, tmp_dir: Path, auth_cookies: Optional[Dict] = None) -> Optional[Dict]:
    """
    DEPRECATED: Use API-level gitOrigin filtering via fetch_jobs_page() instead.

    This two-pass mechanism (fetch all ecosystem jobs → filter by metadata) is kept
    for backwards compatibility but should not be used for new code. The API now
    supports direct gitOrigin filtering which is significantly more efficient.

    Fetch metadata for a single job and check if it matches the git origin.

    Args:
        job: Job data from API
        git_origin: Normalized git origin to match against
        tmp_dir: Temporary directory for downloads (unused, kept for compatibility)
        auth_cookies: Pre-fetched auth cookies to reuse (avoids concurrent auth calls)

    Returns:
        The job dict if it matches the origin, None otherwise
    """
    try:
        job_id = job["id"]
        metadata = fetch_job_metadata(job_id, tmp_dir, auth_cookies=auth_cookies)

        # Extract origin from metadata
        job_origin = metadata.get("origin", "")
        if job_origin:
            job_origin_normalized = normalize_git_url(job_origin)
            if job_origin_normalized == git_origin:
                logger.log(
                    f"✓ Job {job_id} matches origin",
                    "DEBUG",
                    "RemoteJobsSync"
                )
                return job

        return None

    except Exception as e:
        # Continue on errors - just log and return None
        logger.log(
            f"Error processing job {job.get('id', 'unknown')}: {e}",
            "WARNING",
            "RemoteJobsSync"
        )
        return None


def get_project_name(project_root: Path) -> str:
    """
    Get the project name from package.json.

    Args:
        project_root: Path to the project root directory

    Returns:
        Project name from package.json

    Raises:
        FileNotFoundError: If package.json doesn't exist
        ValueError: If package.json has no "name" field
    """
    package_json_path = project_root / "package.json"

    if not package_json_path.exists():
        raise FileNotFoundError(f"package.json not found at {package_json_path}")

    with open(package_json_path, 'r') as f:
        package_data = json.load(f)

    if "name" not in package_data:
        raise ValueError(f"package.json has no 'name' field")

    return package_data["name"]


def get_main_contracts_from_snapshot(project_root: Path) -> List[str]:
    """
    Extract main contracts from the latest conf_mappings.json snapshot.

    Returns:
        List of unique main contract names from all confs

    Raises:
        FileNotFoundError: If no snapshots or conf_mappings.json found
        ValueError: If no main contracts found in snapshot
    """
    # Find latest snapshot directory using latest_scan
    local_dashboard_dir = project_root / DIR_CERTORA_INTERNAL / "local_dashboard"
    if not local_dashboard_dir.exists():
        raise FileNotFoundError(f"No local_dashboard directory at {local_dashboard_dir}")

    # Read latest_scan to get the exact folder name
    latest_scan_path = local_dashboard_dir / "latest_scan"
    if not latest_scan_path.exists():
        raise FileNotFoundError(f"No latest_scan file found at {latest_scan_path}")

    with open(latest_scan_path, 'r') as f:
        latest_snapshot_name = f.read().strip()

    latest_snapshot = local_dashboard_dir / latest_snapshot_name

    if not latest_snapshot.exists():
        raise FileNotFoundError(f"Latest snapshot directory not found: {latest_snapshot}")

    logger.log(
        f"Using snapshot: {latest_snapshot.name}",
        "INFO",
        "RemoteJobsSync"
    )

    # Read conf_mappings.json
    conf_mappings_path = latest_snapshot / "conf_mappings.json"
    if not conf_mappings_path.exists():
        raise FileNotFoundError(f"No conf_mappings.json in {latest_snapshot}")

    with open(conf_mappings_path, 'r') as f:
        conf_mappings_data = json.load(f)

        # Extract confs array - handle both dict with "confs" key and direct array
        if isinstance(conf_mappings_data, dict) and "confs" in conf_mappings_data:
            conf_mappings = conf_mappings_data["confs"]
        elif isinstance(conf_mappings_data, list):
            conf_mappings = conf_mappings_data
        else:
            raise ValueError(f"Unexpected conf_mappings structure in {conf_mappings_path}: expected dict with 'confs' key or array")

        # Extract main_contract from each conf
        contracts = []
        for conf_data in conf_mappings:
            if "main_contract" in conf_data and conf_data["main_contract"]:
                contracts.append(conf_data["main_contract"])

        if not contracts:
            raise ValueError(f"No main contracts found in {conf_mappings_path}")

    # Deduplicate and return
    unique_contracts = list(set(contracts))
    logger.log(
        f"Found {len(unique_contracts)} unique main contracts: {unique_contracts}",
        "INFO",
        "RemoteJobsSync"
    )

    return unique_contracts


def load_existing_jobs(project_root: Path) -> Tuple[List[Dict], Optional[int]]:
    """
    Load existing remote jobs from .certora_remote_jobs.json.

    Args:
        project_root: Path to the project root directory

    Returns:
        Tuple of (list of existing jobs, max timestamp or None)

    Raises:
        json.JSONDecodeError: If file exists but is malformed
    """
    jobs_file = project_root / DIR_CERTORA_INTERNAL / FILE_REMOTE_JOBS

    if not jobs_file.exists():
        logger.log(
            "No existing remote jobs file found",
            "INFO",
            "RemoteJobsSync"
        )
        return [], None

    with open(jobs_file, 'r') as f:
        existing_jobs = json.load(f)

    if not existing_jobs:
        return [], None

    # Find max timestamp
    max_timestamp = max(job["time"] for job in existing_jobs)

    logger.log(
        f"Loaded {len(existing_jobs)} existing jobs, max timestamp: {max_timestamp}",
        "INFO",
        "RemoteJobsSync"
    )

    return existing_jobs, max_timestamp


def unix_timestamp_to_iso(timestamp: int) -> str:
    """
    Convert unix timestamp to URL-encoded ISO 8601 format.

    Args:
        timestamp: Unix timestamp in seconds

    Returns:
        URL-encoded ISO 8601 string (e.g., "2025-09-01T19%3A35%3A24.587000Z")
    """
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
    iso_string = dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    # URL encode the colons
    return urllib.parse.quote(iso_string, safe='')


def iso_to_unix_timestamp(iso_string: str) -> int:
    """
    Convert ISO 8601 string to unix timestamp.

    Args:
        iso_string: ISO 8601 formatted string

    Returns:
        Unix timestamp in seconds
    """
    # Handle various ISO formats
    for fmt in [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S"
    ]:
        try:
            dt = datetime.strptime(iso_string, fmt)
            # Ensure timezone aware
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp())
        except ValueError:
            continue

    raise ValueError(f"Could not parse ISO timestamp: {iso_string}")


def fetch_jobs_page(
    page: int,
    page_size: int,
    created_after: str,
    tmp_dir: Path,
    protocol_name: Optional[str] = None,
    contracts: Optional[List[str]] = None,
    ecosystem: Optional[CloudAPIEcosystem] = None,
    git_origin: Optional[str] = None,
    all_users: bool = True
) -> Dict:
    """
    Fetch a single page of jobs from the Certora data API.

    Must provide exactly one of: protocol_name, contracts, or ecosystem.
    When ecosystem is provided, git_origin can also be passed for API-level filtering.

    Args:
        page: Page number (1-indexed)
        page_size: Number of items per page
        created_after: URL-encoded ISO timestamp for filtering
        tmp_dir: Directory to store temporary output files
        protocol_name: Name of the protocol to search for (optional)
        contracts: List of contract names to search for (optional)
        ecosystem: CloudAPIEcosystem to filter by (e.g., CloudAPIEcosystem.SUI) (optional)
        git_origin: Git origin URL for API-level filtering (only valid with ecosystem)
        all_users: Whether to fetch jobs from all users (default: True)

    Returns:
        Dictionary with 'items', 'total', 'limit', 'offset' fields

    Raises:
        ValueError: If not exactly one parameter provided, or git_origin without ecosystem
        RuntimeError: If download fails
        json.JSONDecodeError: If response is malformed
    """
    # Validation - exactly one parameter must be provided
    params_provided = sum([
        protocol_name is not None,
        contracts is not None,
        ecosystem is not None
    ])
    if params_provided != 1:
        raise ValueError("Must provide exactly one of: protocol_name, contracts, or ecosystem")

    # git_origin is only valid when ecosystem is provided
    if git_origin and not ecosystem:
        raise ValueError("git_origin parameter requires ecosystem to be specified")

    # Build API URL
    all_users_str = "true" if all_users else "false"
    url = (
        f"{API_CERTORA_DATA_BASE}"
        f"?currentPage={page}"
        f"&pageSize={page_size}"
        f"&sortOrder=desc"
        f"&allUsers={all_users_str}"
        f"&createdAfter={created_after}"
        f"&deleted=false"
    )

    # Add search parameter
    if ecosystem:
        url += f"&ecosystems={urllib.parse.quote(ecosystem.value)}"
        if git_origin:
            url += f"&gitOrigin={urllib.parse.quote(git_origin)}"
            logger.log(
                f"Fetching page {page} for ecosystem: {ecosystem.value} with gitOrigin filter",
                "INFO",
                "RemoteJobsSync"
            )
        else:
            logger.log(
                f"Fetching page {page} for ecosystem: {ecosystem.value}",
                "INFO",
                "RemoteJobsSync"
            )
    elif protocol_name:
        url += f"&text={urllib.parse.quote(protocol_name)}"
        logger.log(
            f"Fetching page {page} for protocol: {protocol_name}",
            "INFO",
            "RemoteJobsSync"
        )
    else:  # contracts
        if contracts:
            for contract in contracts:
                url += f"&contracts={urllib.parse.quote(contract)}"
            logger.log(
                f"Fetching page {page} for {len(contracts)} contracts",
                "INFO",
                "RemoteJobsSync"
            )

    # Output file in tmp directory
    output_file = tmp_dir / f"jobs_page_{page}.json"

    # Download using direct function call
    exit_code = download_with_auth(url, str(output_file))

    # Check for errors
    if exit_code != 0:
        logger.log(
            f"Download failed with exit code {exit_code}",
            "ERROR",
            "RemoteJobsSync"
        )
        raise RuntimeError(f"Failed to download page {page} from {url}")

    logger.log(
        f"Successfully fetched page {page}",
        "INFO",
        "RemoteJobsSync"
    )

    # Parse response
    with open(output_file, 'r') as f:
        response = json.load(f)

    return response


def convert_api_job_to_local_format(api_job: Dict) -> Dict:
    """
    Convert a job from API format to local format.

    API format:
    {
        "id": "92085942-e72d-4d0f-b13a-fe2f6aa934db",
        "output_url": "https://...",
        "msg": "...",
        "post_time": "2025-01-15T10:30:45.123456Z",
        "user_name": "60724",
        ...
    }

    Local format:
    {
        "anonymous_key": "",
        "domain": "https://prover.certora.com",
        "job_id": "92085942e72d4d0fb13afe2f6aa934db",
        "notify_msg": "...",
        "output_url": "https://...",
        "time": 1737801045,
        "user_id": "60724"
    }

    Args:
        api_job: Job data from API

    Returns:
        Job data in local format

    Raises:
        KeyError: If required fields are missing
    """
    # Remove hyphens from job ID
    job_id = api_job["id"].replace("-", "")

    # Convert post_time to unix timestamp
    time = iso_to_unix_timestamp(api_job["post_time"])

    return {
        "anonymous_key": "",
        "domain": DOMAIN_PROVER_CERTORA,
        "job_id": job_id,
        "notify_msg": api_job["msg"],
        "output_url": api_job["output_url"],
        "time": time,
        "user_id": api_job["user_name"]
    }


def sync_remote_jobs(
    project_root: Path,
    all_users: bool = True,
    lookback_days: int = 30
) -> None:
    """
    Sync remote Certora jobs for the current project.

    Fetches all jobs from the Certora data API that match the project name
    and stores them in .certora_internal/.certora_remote_jobs.json.

    Supports incremental sync - only fetches jobs newer than existing ones.

    Args:
        project_root: Path to the project root directory
        all_users: Whether to fetch jobs from all users (default: True)
        lookback_days: How many days to look back for jobs (default: 30)

    Raises:
        FileNotFoundError: If package.json not found
        ValueError: If package.json has no name field
        RuntimeError: If API fetch fails
        json.JSONDecodeError: If response is malformed
        KeyError: If required fields missing from API response
        IOError: If file operations fail
    """
    logger.log(
        "Starting remote jobs sync",
        "INFO",
        "RemoteJobsSync"
    )

    # Ensure tmp directory exists
    tmp_dir = project_root / DIR_CERTORA_INTERNAL / DIR_TMP
    tmp_dir.mkdir(parents=True, exist_ok=True)

    # Check if project has Move or Rust confs
    has_move = has_move_confs(project_root)
    has_rust = has_rust_confs(project_root)

    # Initialize search parameters
    protocol_name = None
    contracts = None
    ecosystem = None
    git_origin = None

    if has_move and has_rust:
        # Mixed Move + Rust project - not yet supported
        raise ValueError(
            "Cannot sync remote jobs for projects with both Move and Rust configurations.\n"
            "Solution: Projects with multiple ecosystems are not yet supported."
        )
    elif has_move:
        # Move project: use ecosystem-based search with git origin filtering
        git_origin = get_git_remote_origin(project_root)
        if not git_origin:
            raise ValueError(
                "Cannot sync remote jobs for Move project: git origin not found.\n"
                "Solution: Ensure the project is a git repository with a remote 'origin'."
            )

        ecosystem = CloudAPIEcosystem.SUI
        logger.log(
            f"✓ Move project detected, using ecosystem search: {ecosystem.value}",
            "INFO",
            "RemoteJobsSync"
        )
        logger.log(
            f"✓ Will filter by git origin: {git_origin}",
            "INFO",
            "RemoteJobsSync"
        )
    elif has_rust:
        # Rust/Solana project: use ecosystem-based search with git origin filtering
        git_origin = get_git_remote_origin(project_root)
        if not git_origin:
            raise ValueError(
                "Cannot sync remote jobs for Rust project: git origin not found.\n"
                "Solution: Ensure the project is a git repository with a remote 'origin'."
            )

        ecosystem = CloudAPIEcosystem.SOLANA
        logger.log(
            f"✓ Rust project detected, using ecosystem search: {ecosystem.value}",
            "INFO",
            "RemoteJobsSync"
        )
        logger.log(
            f"✓ Will filter by git origin: {git_origin}",
            "INFO",
            "RemoteJobsSync"
        )
    else:
        # EVM project: use protocol name or contracts
        try:
            protocol_name = get_project_name(project_root)
            logger.log(
                f"✓ Using protocol name for search: {protocol_name}",
                "INFO",
                "RemoteJobsSync"
            )
        except (FileNotFoundError, ValueError) as e:
            logger.log(
                f"Could not determine protocol name: {e}",
                "WARNING",
                "RemoteJobsSync"
            )

            # Fallback: get main contracts from snapshot
            try:
                contracts = get_main_contracts_from_snapshot(project_root)
                logger.log(
                    f"✓ Using contract-based search for {len(contracts)} contracts",
                    "INFO",
                    "RemoteJobsSync"
                )
            except (FileNotFoundError, ValueError) as e2:
                raise ValueError(
                    f"Cannot sync remote jobs: no protocol name and no main contracts available.\n"
                    f"  - Protocol name error: {e}\n"
                    f"  - Contracts error: {e2}\n"
                    f"Solution: Run a local scan first or add a package.json with a 'name' field."
                ) from e2

    # Load existing jobs
    existing_jobs, max_timestamp = load_existing_jobs(project_root)

    # Calculate createdAfter parameter
    if max_timestamp is not None:
        # Use max timestamp from existing jobs
        created_after = unix_timestamp_to_iso(max_timestamp)
        logger.log(
            f"Incremental sync: fetching jobs after {max_timestamp}",
            "INFO",
            "RemoteJobsSync"
        )
    else:
        # Use lookback_days parameter
        lookback_date = datetime.now(timezone.utc) - timedelta(days=lookback_days)
        created_after = unix_timestamp_to_iso(int(lookback_date.timestamp()))
        logger.log(
            f"Full sync: fetching jobs from last {lookback_days} days",
            "INFO",
            "RemoteJobsSync"
        )

    # Determine if we're using API-level git origin filtering
    use_api_git_origin_filter = ecosystem is not None and git_origin is not None
    if use_api_git_origin_filter:
        logger.log(
            f"Using API-level gitOrigin filtering (efficient server-side filtering)",
            "INFO",
            "RemoteJobsSync"
        )

    # Fetch first page to get total count
    page_size = 100  # API max
    first_page = fetch_jobs_page(
        page=1,
        page_size=page_size,
        created_after=created_after,
        tmp_dir=tmp_dir,
        protocol_name=protocol_name,
        contracts=contracts,
        ecosystem=ecosystem,
        git_origin=git_origin if use_api_git_origin_filter else None,
        all_users=all_users
    )

    total_jobs = first_page["total"]
    logger.log(
        f"Total jobs to fetch: {total_jobs}",
        "INFO",
        "RemoteJobsSync"
    )

    # Collect all jobs
    all_api_jobs = first_page["items"]

    # Fetch remaining pages if needed
    if total_jobs > page_size:
        num_pages = (total_jobs + page_size - 1) // page_size  # Ceiling division

        for page_num in range(2, num_pages + 1):
            page_data = fetch_jobs_page(
                page=page_num,
                page_size=page_size,
                created_after=created_after,
                tmp_dir=tmp_dir,
                protocol_name=protocol_name,
                contracts=contracts,
                ecosystem=ecosystem,
                git_origin=git_origin if use_api_git_origin_filter else None,
                all_users=all_users
            )
            all_api_jobs.extend(page_data["items"])

    logger.log(
        f"Fetched {len(all_api_jobs)} jobs from API",
        "INFO",
        "RemoteJobsSync"
    )

    # For Move and Rust projects, filter by git origin (only if not already filtered by API)
    if (has_move or has_rust) and git_origin and not use_api_git_origin_filter:
        # DEPRECATED: Two-pass filtering mechanism. Use API-level gitOrigin filtering instead.
        # This fallback is kept for backwards compatibility with older API versions.
        logger.log(
            f"Using deprecated two-pass filtering for {len(all_api_jobs)} jobs by git origin: {git_origin}",
            "WARNING",
            "RemoteJobsSync"
        )
        logger.log(
            "Consider upgrading to API-level gitOrigin filtering for better performance",
            "INFO",
            "RemoteJobsSync"
        )

        # Fetch auth cookies once before parallel processing to avoid concurrent auth calls
        try:
            auth_cookies = get_auth_cookies()
        except Exception as e:
            logger.log(
                f"Failed to get auth cookies: {e}",
                "ERROR",
                "RemoteJobsSync"
            )
            raise

        matched_jobs: list = []
        completed_count = 0
        total_jobs = len(all_api_jobs)

        # Parallelize the metadata fetching with 50 workers
        with ThreadPoolExecutor(max_workers=50) as executor:
            # Submit all jobs
            future_to_job = {
                executor.submit(_fetch_and_filter_job, job, git_origin, tmp_dir, auth_cookies): job
                for job in all_api_jobs
            }

            # Process results as they complete
            for future in as_completed(future_to_job):
                completed_count += 1

                # Log progress every 50 jobs
                if completed_count % 50 == 0:
                    logger.log(
                        f"Checked {completed_count}/{total_jobs} jobs, matched {len(matched_jobs)} so far",
                        "INFO",
                        "RemoteJobsSync"
                    )

                # Get the result (None if no match or error)
                result = future.result()
                if result is not None:
                    matched_jobs.append(result)

        logger.log(
            f"Filtered to {len(matched_jobs)} jobs matching git origin (from {len(all_api_jobs)} total)",
            "INFO",
            "RemoteJobsSync"
        )

        all_api_jobs = matched_jobs

    # Convert to local format
    new_jobs = [convert_api_job_to_local_format(job) for job in all_api_jobs]

    # Merge with existing jobs (deduplicate by job_id)
    jobs_by_id = {job["job_id"]: job for job in existing_jobs}
    for job in new_jobs:
        jobs_by_id[job["job_id"]] = job

    # Convert back to list and sort by time (descending)
    all_jobs = sorted(jobs_by_id.values(), key=lambda j: j["time"], reverse=True)

    logger.log(
        f"Total jobs after merge: {len(all_jobs)}",
        "INFO",
        "RemoteJobsSync"
    )

    # Save to file
    output_file = project_root / DIR_CERTORA_INTERNAL / FILE_REMOTE_JOBS
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, 'w') as f:
        json.dump(all_jobs, f, indent=2)

    logger.log(
        f"Successfully synced {len(all_jobs)} jobs to {output_file}",
        "INFO",
        "RemoteJobsSync"
    )

    # Clean up tmp files
    for tmp_file in tmp_dir.glob("jobs_page_*.json"):
        tmp_file.unlink()

    logger.log(
        "Remote jobs sync complete",
        "INFO",
        "RemoteJobsSync"
    )


if __name__ == "__main__":
    """Run sync for current directory."""
    project_root = Path.cwd() if len(sys.argv) < 2 else Path(sys.argv[1])
    sync_remote_jobs(project_root)
