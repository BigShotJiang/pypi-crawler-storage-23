"""
Spec diff management module for comparing local and remote CVL specs.

Handles comparison of ASTs between local specs and cloud run specs,
tracking whether verification results are based on current code.
"""


import json5
import re
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from src.dashboard.ast_manager import get_or_generate_remote_ast, load_asts_mapping
from src.dashboard.constants import DIR_EXTRACTED_TARS, FILE_SPEC_DIFFS
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import ConfInfo, RuleStatus, ScanSnapshot
from src.dashboard.storage import (
    load_spec_diff_for_job,
    save_spec_diff_for_job,
    update_spec_diff_index,
)
from src.dashboard.utils.spec_diff import compare_specs

# Global lock dictionary for preventing concurrent computation of the same job
_job_locks = {}
_job_locks_lock = threading.Lock()


def extract_code_snippet(base_path: Path, range_info: dict) -> Optional[str]:
    """
    Extract code snippet from file based on range info.

    Args:
        base_path: Base directory to resolve specFile from
        range_info: Dict with specFile, start, end

    Returns:
        Code snippet as string, or None if file not found
    """
    if not range_info:
        return None

    spec_file = range_info.get("specFile")
    if not spec_file:
        return None

    file_path = base_path / spec_file
    if not file_path.exists():
        # Sometimes the spec_file path intersects with base_path due to extraction issues
        # Try searching parent directories of base_path
        current = base_path
        found_path = None

        # Search up parent directories until we find it or reach filesystem root
        while True:
            parent = current.parent
            if parent == current:  # Reached filesystem root
                break

            candidate = parent / spec_file
            if candidate.exists():
                found_path = candidate
                logger.log(
                    f"Found spec file in parent directory: {found_path} (searched from {base_path})",
                    "DEBUG",
                    "SpecDiffManager"
                )
                break

            current = parent

        if not found_path:
            logger.log(
                f"Could not find spec file for snippet: {file_path} ({base_path}, {spec_file})",
                "WARNING",
                "SpecDiffManager"
            )
            return None

        file_path = found_path

    start_line = range_info.get("start", {}).get("line", 0)
    end_line = range_info.get("end", {}).get("line", start_line)

    try:
        with open(file_path, 'r') as f:
            lines = f.readlines()

        # Extract relevant lines (0-indexed)
        snippet_lines = lines[start_line:end_line + 1]
        return ''.join(snippet_lines).rstrip()
    except Exception as e:
        logger.log(
            f"Error reading snippet from {file_path}: {e}",
            "WARNING",
            "SpecDiffManager"
        )
        return None


def _extract_field_snippets(before: dict, after: dict, local_base: Path, remote_base: Path) -> Dict[str, Dict[str, Any]]:
    """
    Extract code snippets from specific nested fields that have range information.
    Filters out field snippets that differ only in whitespace.

    Args:
        before: Before object from diff
        after: After object from diff
        local_base: Base path for local (before) files
        remote_base: Base path for remote (after) files

    Returns:
        Dict mapping field names to {before_snippet, after_snippet}
        Only includes fields where snippets actually differ (not just whitespace)
    """
    field_snippets: Dict[str, Dict[str, Any]] = {}

    # Fields that commonly contain range information we want to extract
    interesting_fields = ['exp', 'methodParamFilters', 'axioms', 'preserved', 'block']

    for field_name in interesting_fields:
        before_field = before.get(field_name)
        after_field = after.get(field_name)

        # Only extract if both sides have the field
        if before_field is None or after_field is None:
            continue

        before_snippet: Optional[str] = None
        after_snippet: Optional[str] = None

        # Try to extract range from the field
        if isinstance(before_field, dict) and 'range' in before_field:
            before_snippet = extract_code_snippet(local_base, before_field['range'])

        if isinstance(after_field, dict) and 'range' in after_field:
            after_snippet = extract_code_snippet(remote_base, after_field['range'])

        # Only add if we got at least one snippet AND they differ (not just whitespace)
        if before_snippet or after_snippet:
            # If we have both snippets, check if they're equivalent ignoring whitespace
            if before_snippet and after_snippet:
                if not _snippets_equivalent_ignoring_whitespace(before_snippet, after_snippet):
                    # Actually different - include in result
                    field_snippets[field_name] = {
                        'before': before_snippet,
                        'after': after_snippet
                    }
                # else: whitespace-only difference, skip
            else:
                # One side missing - include anyway (field added/removed)
                field_snippets[field_name] = {
                    'before': before_snippet,
                    'after': after_snippet
                }

    return field_snippets


def _snippets_equivalent_ignoring_whitespace(snippet1: str, snippet2: str) -> bool:
    """
    Check if two code snippets are equivalent ignoring whitespace.

    Args:
        snippet1: First code snippet
        snippet2: Second code snippet

    Returns:
        True if snippets are equivalent when whitespace is normalized
    """
    # Both None or empty
    if not snippet1 and not snippet2:
        return True

    # One is None/empty, other is not
    if not snippet1 or not snippet2:
        return False

    # Normalize whitespace: collapse all whitespace to single spaces, trim
    norm1 = ' '.join(snippet1.split())
    norm2 = ' '.join(snippet2.split())

    return norm1 == norm2


def resolve_code_snippets(diff_data: dict, local_base: Path, remote_base: Path) -> dict:
    """
    Resolve code snippets for modified elements in diff data.

    Args:
        diff_data: The diff data containing modified elements
        local_base: Base path for local (before) files
        remote_base: Base path for remote (after) files

    Returns:
        Updated diff_data with code snippets added
    """
    if not diff_data:
        return diff_data

    logger.log(
        f"Resolving code snippets with local_base={local_base}, remote_base={remote_base}",
        "INFO",
        "SpecDiffManager"
    )

    # Process global elements
    global_elements = diff_data.get("global_elements", {})
    for category_name, category_data in global_elements.items():
        if not isinstance(category_data, dict):
            continue

        modified = category_data.get("modified", [])
        items_to_remove = []

        for item in modified:
            diff = item.get("diff", {})
            before = diff.get("before", {})
            after = diff.get("after", {})

            # Extract code snippets using range field
            before_range = before.get("range")
            after_range = after.get("range")

            logger.log(
                f"Processing modified item: {item.get('name', 'unknown')}, before_range={before_range}, after_range={after_range}",
                "INFO",
                "SpecDiffManager"
            )

            before_code = None
            after_code = None

            if before_range:
                before_code = extract_code_snippet(local_base, before_range)
            if after_range:
                after_code = extract_code_snippet(remote_base, after_range)

            # Check if snippets are equivalent ignoring whitespace
            if before_code and after_code and _snippets_equivalent_ignoring_whitespace(before_code, after_code):
                logger.log(
                    f"Snippets equivalent (whitespace only) for {item.get('name', 'unknown')}, removing from modified",
                    "INFO",
                    "SpecDiffManager"
                )
                items_to_remove.append(item)
                continue

            # Snippets differ or couldn't be extracted - keep in modified list
            if before_code:
                item["before_code"] = before_code
            if after_code:
                item["after_code"] = after_code

            # Extract field-level snippets
            field_snippets = _extract_field_snippets(before, after, local_base, remote_base)
            if field_snippets:
                item["field_snippets"] = field_snippets

            # If we have code snippets, remove verbose AST diff
            if before_code and after_code:
                if "diff" in item:
                    del item["diff"]

        # Remove whitespace-only diffs from modified list
        for item in items_to_remove:
            modified.remove(item)

    # Process rules
    rules = diff_data.get("rules", {})
    rules_modified = rules.get("modified", [])
    items_to_remove = []

    for item in rules_modified:
        diff = item.get("diff", {})
        before = diff.get("before", {})
        after = diff.get("after", {})

        before_range = before.get("range")
        after_range = after.get("range")

        before_code = None
        after_code = None

        if before_range:
            before_code = extract_code_snippet(local_base, before_range)
        if after_range:
            after_code = extract_code_snippet(remote_base, after_range)

        # Check if snippets are equivalent ignoring whitespace
        if before_code and after_code and _snippets_equivalent_ignoring_whitespace(before_code, after_code):
            logger.log(
                f"Rule snippets equivalent (whitespace only) for {item.get('displayName', 'unknown')}, removing from modified",
                "INFO",
                "SpecDiffManager"
            )
            items_to_remove.append(item)
            continue

        # Snippets differ or couldn't be extracted - keep in modified list
        if before_code:
            item["before_code"] = before_code
        if after_code:
            item["after_code"] = after_code

        # Extract field-level snippets
        field_snippets = _extract_field_snippets(before, after, local_base, remote_base)
        if field_snippets:
            item["field_snippets"] = field_snippets

        # If we have code snippets, remove verbose AST diff
        if before_code and after_code:
            if "diff" in item:
                del item["diff"]

    # Remove whitespace-only diffs from modified list
    for item in items_to_remove:
        rules_modified.remove(item)

    # Process invariants
    invariants = diff_data.get("invariants", {})
    invariants_modified = invariants.get("modified", [])
    items_to_remove = []

    for item in invariants_modified:
        diff = item.get("diff", {})
        before = diff.get("before", {})
        after = diff.get("after", {})

        before_range = before.get("range")
        after_range = after.get("range")

        before_code = None
        after_code = None

        if before_range:
            before_code = extract_code_snippet(local_base, before_range)
        if after_range:
            after_code = extract_code_snippet(remote_base, after_range)

        # Check if snippets are equivalent ignoring whitespace
        if before_code and after_code and _snippets_equivalent_ignoring_whitespace(before_code, after_code):
            logger.log(
                f"Invariant snippets equivalent (whitespace only) for {item.get('displayName', 'unknown')}, removing from modified",
                "INFO",
                "SpecDiffManager"
            )
            items_to_remove.append(item)
            continue

        # Snippets differ or couldn't be extracted - keep in modified list
        if before_code:
            item["before_code"] = before_code
        if after_code:
            item["after_code"] = after_code

        # Extract field-level snippets
        field_snippets = _extract_field_snippets(before, after, local_base, remote_base)
        if field_snippets:
            item["field_snippets"] = field_snippets

        # If we have code snippets, remove verbose AST diff
        if before_code and after_code:
            if "diff" in item:
                del item["diff"]

    # Remove whitespace-only diffs from modified list
    for item in items_to_remove:
        invariants_modified.remove(item)

    return diff_data


def _find_conf_for_rule(
    rule_name: str,
    main_contract: str,
    snapshot: ScanSnapshot,
    spec_file: str
) -> Tuple[Optional[ConfInfo], bool]:
    """
    Find the conf that contains a given rule, matching on rule name, main contract, and spec file.

    Args:
        rule_name: Name of the rule to find
        main_contract: Main contract name to match (from verify field)
        snapshot: Scan snapshot to search
        spec_file: Spec file name to match (from verify field after ":")

    Returns:
        Tuple of (ConfInfo, has_ambiguity):
            - (ConfInfo, False) if exactly one match found
            - (ConfInfo, True) if multiple matches found (returns first, logs warning)
            - (None, False) if no match found
    """
    # Find all confs containing this rule
    matching_confs = [conf for conf in snapshot.confs if rule_name in conf.rules]

    if not matching_confs:
        return (None, False)

    if len(matching_confs) > 1:
        logger.log(f"Multiple confs matching rule {rule_name}, searching by contract {main_contract} and spec {spec_file}", "INFO", "SpecDiffManager")
    # Try most specific match: rule name + main contract + spec file
    if main_contract and spec_file:
        # Convert spec_file to Path and resolve to absolute for comparison
        spec_file_path = Path(spec_file).resolve()

        confs_with_contract_and_spec = [
            conf for conf in matching_confs
            if conf.main_contract == main_contract
            and conf.main_spec
            and conf.main_spec.resolve() == spec_file_path
        ]

        if confs_with_contract_and_spec:
            if len(confs_with_contract_and_spec) == 1:
                return (confs_with_contract_and_spec[0], False)
            else:
                # Multiple confs match rule name, main contract, and spec file
                logger.log(
                    f"Multiple confs match rule '{rule_name}', contract '{main_contract}', and spec '{spec_file}': "
                    f"{[conf.conf_path.name for conf in confs_with_contract_and_spec]}. Using first match.",
                    "WARNING",
                    "SpecDiffManager"
                )
                return (confs_with_contract_and_spec[0], True)

    # Fall back to matching by main_contract only
    if main_contract:
        confs_with_contract = [
            conf for conf in matching_confs
            if conf.main_contract == main_contract
        ]

        if confs_with_contract:
            if len(confs_with_contract) == 1:
                return (confs_with_contract[0], False)
            else:
                # Multiple confs match both rule name and main contract
                logger.log(
                    f"Multiple confs match rule '{rule_name}' and main contract '{main_contract}': "
                    f"{[conf.conf_path.name for conf in confs_with_contract]}. Using first match.",
                    "WARNING",
                    "SpecDiffManager"
                )
                return (confs_with_contract[0], True)

    # Final fallback: no main_contract/spec_file or no match
    if len(matching_confs) == 1:
        return (matching_confs[0], False)
    else:
        # Multiple matches, ambiguous
        logger.log(
            f"Multiple confs match rule '{rule_name}' (no contract/spec filter): "
            f"{[conf.conf_path.name for conf in matching_confs]}. Using first match.",
            "WARNING",
            "SpecDiffManager"
        )
        return (matching_confs[0], True)


def compare_rule_specs(
    rule_name: str,
    conf_info: ConfInfo,
    rule_status: RuleStatus,
    asts_mapping: Dict[str, Dict],
    dashboard_path: Path,
    ast_timeout: int = 600
) -> Dict:
    """
    Compare local and remote specs for a single rule.

    Args:
        rule_name: Name of the rule
        conf_info: ConfInfo containing this rule
        rule_status: RuleStatus with cloud run information
        asts_mapping: Mapping from conf_path to AST info (from asts.json)
        dashboard_path: Path to the project root

    Returns:
        Dict with keys:
            - equivalent: bool or None (True/False if compared, None if couldn't compare)
            - reason: str explaining why comparison failed (if equivalent is None)
            - diff_data: full diff JSON from spec_diff (if equivalent is False)
    """
    conf_path_str = str(conf_info.conf_path)

    # Get local AST path
    if conf_path_str not in asts_mapping:
        logger.log(
            f"No AST mapping found for conf {conf_info.conf_path.name}",
            "WARNING",
            "SpecDiffManager"
        )
        return {
            "equivalent": None,
            "reason": "Local AST mapping not found"
        }

    ast_info = asts_mapping[conf_path_str]
    local_ast_path = ast_info.get("ast_path")

    if not local_ast_path:
        error = ast_info.get("error", "Unknown error")
        logger.log(
            f"Local AST generation failed for {conf_info.conf_path.name}: {error}",
            "WARNING",
            "SpecDiffManager"
        )
        return {
            "equivalent": None,
            "reason": f"Local AST generation failed: {error}"
        }

    # Resolve local AST path (it's relative to dashboard_dir)
    certora_internal_dir = dashboard_path / ".certora_internal"
    dashboard_dir = certora_internal_dir / "local_dashboard"
    local_ast_full_path = dashboard_dir / local_ast_path

    if not local_ast_full_path.exists():
        logger.log(
            f"Local AST file not found: {local_ast_full_path}",
            "WARNING",
            "SpecDiffManager"
        )
        return {
            "equivalent": None,
            "reason": "Local AST file not found"
        }

    # Get remote AST
    if not rule_status.job_id or not rule_status.run_url:
        return {
            "equivalent": None,
            "reason": "No remote job information"
        }

    remote_ast_path = get_or_generate_remote_ast(
        rule_status.job_id,
        rule_status.run_url,
        dashboard_path,
        ast_timeout=ast_timeout
    )

    if not remote_ast_path:
        return {
            "equivalent": None,
            "reason": "Remote AST generation failed"
        }

    # Compare the two ASTs
    logger.log(
        f"Comparing specs for rule {rule_name}",
        "INFO",
        "SpecDiffManager"
    )

    try:
        equivalent, diff_data = compare_specs(
            str(local_ast_full_path),
            str(remote_ast_path)
        )

        if equivalent:
            logger.log(
                f"Specs match for rule {rule_name}",
                "SUCCESS",
                "SpecDiffManager"
            )
            return {
                "equivalent": True
            }
        else:
            logger.log(
                f"Specs differ for rule {rule_name}",
                "WARNING",
                "SpecDiffManager"
            )

            # Resolve code snippets for modified elements
            # Local base is the project root (dashboard_path)
            local_base = dashboard_path

            # Remote base is the extracted tarball directory
            # Extract job_id from run_url to construct the path
            match = re.search(r'/output/(\d+)/([a-f0-9]+)', rule_status.run_url)
            if match:
                job_number = match.group(1)
                job_hash = match.group(2)
                job_id = f"{job_number}_{job_hash}"
                remote_base = certora_internal_dir / DIR_EXTRACTED_TARS / job_id / "inputs" / ".certora_sources"
            else:
                remote_base = None

            if remote_base and remote_base.exists():
                logger.log(
                    f"Resolving code snippets - local: {local_base}, remote: {remote_base}",
                    "INFO",
                    "SpecDiffManager"
                )
                if diff_data is not None:
                    diff_data = resolve_code_snippets(diff_data, local_base, remote_base)
            elif remote_base:
                logger.log(
                    f"Remote base does not exist: {remote_base}",
                    "WARNING",
                    "SpecDiffManager"
                )
            else:
                logger.log(
                    f"Could not construct remote base from URL: {rule_status.run_url}",
                    "WARNING",
                    "SpecDiffManager"
                )

            return {
                "equivalent": False,
                "diff_data": diff_data
            }

    except Exception as e:
        logger.log(
            f"Error comparing specs for rule {rule_name}: {e}",
            "ERROR",
            "SpecDiffManager"
        )
        return {
            "equivalent": None,
            "reason": f"Comparison error: {str(e)}"
        }


def compute_spec_diffs_for_job(
    job_id: str,
    job_url: str,
    rules_in_job: List[str],
    snapshot: ScanSnapshot,
    asts_mapping: Dict[str, Dict],
    timestamp_dir: Path,
    dashboard_path: Path,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    ast_timeout: int = 600
) -> Dict[str, Dict]:
    """
    Compute spec diffs for all rules in a specific job.

    Args:
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        job_url: The URL of the cloud run
        rules_in_job: List of rule names in this job
        snapshot: Current scan snapshot
        asts_mapping: Mapping of conf names to their AST paths
        timestamp_dir: Path to the timestamped snapshot directory
        dashboard_path: Path to the project root
        progress_callback: Optional callback function(processed_count, current_rule_name)

    Returns:
        Dict mapping rule_name -> diff_result (with code snippets included)

    Side Effects:
        - Generates remote ASTs as needed (which extracts tarball)
        - Resolves code snippets immediately (while tarball is available)
        - Saves to spec_diffs/{job_id}.json
        - Updates spec_diffs/index.json

    Thread Safety:
        Uses per-job locks to prevent concurrent computation of the same job.
        If another thread is already computing this job, waits for it to complete.
    """
    # Extract job_id from URL to ensure consistency with tarball extraction
    # The job_id parameter might only be the hash part, but tarballs are extracted
    # using the full {job_number}_{job_hash} format from the URL
    match = re.search(r'/output/(\d+)/([a-f0-9]+)', job_url)
    if match:
        job_number = match.group(1)
        job_hash = match.group(2)
        full_job_id = f"{job_number}_{job_hash}"
    else:
        # Fallback to provided job_id if URL doesn't match expected format
        full_job_id = job_id

    # Get or create a lock for this specific job
    with _job_locks_lock:
        if job_id not in _job_locks:
            _job_locks[job_id] = threading.Lock()
        job_lock = _job_locks[job_id]

    # Acquire the job-specific lock (will wait if another thread is computing)
    with job_lock:
        # Check if already computed while we were waiting
        existing_diff = load_spec_diff_for_job(timestamp_dir, job_id)
        if existing_diff is not None and "rules" in existing_diff:
            # Check if all requested rules are in the existing diff
            existing_rules = set(existing_diff["rules"].keys())
            requested_rules = set(rules_in_job)
            if requested_rules.issubset(existing_rules):
                logger.log(
                    f"Spec diff for job {job_id} already computed by another thread",
                    "INFO",
                    "SpecDiffManager"
                )
                # Return only the requested rules
                return {rule: existing_diff["rules"][rule] for rule in rules_in_job if rule in existing_diff["rules"]}

        logger.log(
            f"Computing spec diffs for job {job_id} ({len(rules_in_job)} rules)",
            "INFO",
            "SpecDiffManager"
        )

        return _compute_spec_diffs_for_job_impl(
            job_id, job_url, full_job_id, rules_in_job,
            snapshot, asts_mapping, timestamp_dir, dashboard_path, progress_callback,
            ast_timeout
        )


def _compute_spec_diffs_for_job_impl(
    job_id: str,
    job_url: str,
    full_job_id: str,
    rules_in_job: List[str],
    snapshot: ScanSnapshot,
    asts_mapping: Dict[str, Dict],
    timestamp_dir: Path,
    dashboard_path: Path,
    progress_callback: Optional[Callable[[int, str], None]] = None,
    ast_timeout: int = 600
) -> Dict[str, Dict]:
    """
    Internal implementation of spec diff computation (called with lock held).
    """
    rules_diff_data: dict[str, Any] = {}
    rules_equivalence: dict[str, bool | None] = {}

    certora_internal = dashboard_path / ".certora_internal"
    dashboard_dir = certora_internal / "local_dashboard"

    remote_base = certora_internal / DIR_EXTRACTED_TARS / full_job_id / "inputs" / ".certora_sources"

    # Extract tarball first to ensure run.conf is available
    # (This will extract the tarball if it hasn't been extracted yet)
    remote_ast_path = get_or_generate_remote_ast(
        job_id,
        job_url,
        dashboard_path,
        ast_timeout=ast_timeout
    )

    # Extract main contract and spec file from remote run.conf
    # (Now that tarball is extracted, run.conf should exist)
    remote_main_contract = ""
    remote_spec_file = ""
    run_conf_path = remote_base / "run.conf"
    if run_conf_path.exists():
        try:
            with run_conf_path.open("r") as rcf:
                run_conf_data = json5.load(rcf)
                verify_field = run_conf_data.get("verify", "")
                if ":" in verify_field:
                    parts = verify_field.split(":", 1)
                    remote_main_contract = parts[0]
                    remote_spec_file = parts[1]
        except Exception as e:
            logger.log(
                f"Error reading main contract and spec from remote run.conf: {e}",
                "WARNING",
                "SpecDiffManager"
            )
    else:
        logger.log(
            f"run.conf not found at {run_conf_path} after tarball extraction",
            "WARNING",
            "SpecDiffManager"
        )

    for idx, rule_name in enumerate(rules_in_job):
        # Find the conf containing this rule, matching on main contract and spec file
        conf_info, has_ambiguous_conf = _find_conf_for_rule(
            rule_name,
            remote_main_contract,
            snapshot,
            remote_spec_file
        )

        if not conf_info:
            logger.log(
                f"Could not find conf for rule {rule_name}",
                "WARNING",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": "Rule not found in current snapshot",
                "conf_path": None
            }
            rules_equivalence[rule_name] = None

            if progress_callback:
                progress_callback(idx + 1, rule_name)
            continue

        # Get local AST path for this conf
        conf_path_str = str(conf_info.conf_path)

        if conf_path_str not in asts_mapping:
            logger.log(
                f"No AST mapping found for conf {conf_info.conf_path.name}",
                "WARNING",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": "Local AST mapping not found",
                "conf_path": conf_path_str
            }
            rules_equivalence[rule_name] = None

            if progress_callback:
                progress_callback(idx + 1, rule_name)
            continue

        ast_info = asts_mapping[conf_path_str]
        local_ast_path = ast_info.get("ast_path")

        if not local_ast_path:
            error = ast_info.get("error", "Unknown error")
            logger.log(
                f"Local AST generation failed for {conf_info.conf_path.name}: {error}",
                "WARNING",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": f"Local AST generation failed: {error}",
                "conf_path": conf_path_str
            }
            rules_equivalence[rule_name] = None

            if progress_callback:
                progress_callback(idx + 1, rule_name)
            continue

        # Resolve local AST path
        local_ast_full_path = dashboard_dir / local_ast_path

        if not local_ast_full_path.exists():
            logger.log(
                f"Local AST file not found: {local_ast_full_path}",
                "WARNING",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": "Local AST file not found",
                "conf_path": conf_path_str
            }
            rules_equivalence[rule_name] = None

            if progress_callback:
                progress_callback(idx + 1, rule_name)
            continue

        # Use the already-extracted remote AST (extracted before the loop)
        if not remote_ast_path:
            logger.log(
                f"Remote AST generation failed for job {job_id}",
                "WARNING",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": "Remote AST generation failed",
                "conf_path": conf_path_str
            }
            rules_equivalence[rule_name] = None

            if progress_callback:
                progress_callback(idx + 1, rule_name)
            continue

        # Compare the two ASTs
        try:
            equivalent, diff_data = compare_specs(
                str(local_ast_full_path),
                str(remote_ast_path)
            )

            if equivalent:
                rules_diff_data[rule_name] = {
                    "equivalent": True,
                    "has_ambiguous_conf": has_ambiguous_conf,
                    "matched_main_contract": remote_main_contract,
                    "conf_path": conf_path_str
                }
                rules_equivalence[rule_name] = True
            else:
                # Resolve code snippets immediately while tarball is available
                local_base = dashboard_path

                if remote_base.exists():
                    logger.log(
                        f"Resolving code snippets for {rule_name}",
                        "INFO",
                        "SpecDiffManager"
                    )
                    if diff_data is not None:
                        diff_data = resolve_code_snippets(diff_data, local_base, remote_base)
                    else:
                        logger.log(f"Failed to fetch diff_data for {rule_name}", "ERROR", "SpecDiffManager")
                        rules_diff_data[rule_name] = {
                            "equivalent": None,
                            "reason": "Comparison returned no diff data",
                            "conf_path": conf_path_str
                        }
                        rules_equivalence[rule_name] = None
                else:
                    logger.log(
                        f"Remote base not found for snippets: {remote_base}",
                        "WARNING",
                        "SpecDiffManager"
                    )

                rules_diff_data[rule_name] = {
                    "equivalent": False,
                    "diff_data": diff_data,
                    "has_ambiguous_conf": has_ambiguous_conf,
                    "matched_main_contract": remote_main_contract,
                    "conf_path": conf_path_str
                }
                rules_equivalence[rule_name] = False

        except Exception as e:
            logger.log(
                f"Error comparing specs for rule {rule_name}: {e}",
                "ERROR",
                "SpecDiffManager"
            )
            rules_diff_data[rule_name] = {
                "equivalent": None,
                "reason": f"Comparison error: {str(e)}",
                "conf_path": conf_path_str
            }
            rules_equivalence[rule_name] = None

        if progress_callback:
            progress_callback(idx + 1, rule_name)

    # Save to spec_diffs/{job_id}.json
    import time
    computed_at = time.time()
    local_timestamp = timestamp_dir.name

    save_spec_diff_for_job(
        timestamp_dir,
        job_id,
        job_url,
        computed_at,
        local_timestamp,
        rules_diff_data
    )

    # Update index
    # Filter out None values for the index
    valid_equivalence = {k: v for k, v in rules_equivalence.items() if v is not None}
    update_spec_diff_index(timestamp_dir, job_id, valid_equivalence)

    logger.log(
        f"Completed spec diffs for job {job_id} ({len(rules_diff_data)} rules)",
        "SUCCESS",
        "SpecDiffManager"
    )

    return rules_diff_data


def compute_all_spec_diffs(
    snapshot: ScanSnapshot,
    rule_statuses: Dict[str, RuleStatus],
    timestamp_dir: Path,
    dashboard_path: Path,
    progress_callback: Optional[Callable[[int, str], None]] = None
) -> Dict[str, Dict]:
    """
    Compute spec diffs for all rules, grouped by job_id.

    Args:
        snapshot: Current scan snapshot
        rule_statuses: Dict of rule_name → RuleStatus
        timestamp_dir: Path to the timestamped snapshot directory
        dashboard_path: Path to the project root
        progress_callback: Optional callback function(processed_count, current_rule_name)
                          called after each rule's diff is computed

    Returns:
        Dict mapping rule_name → diff_result (for backward compatibility)

    Side Effects:
        - Groups rules by job_id
        - For each job_id, calls compute_spec_diffs_for_job()
        - Saves to spec_diffs/{job_id}.json for each job
        - Updates spec_diffs/index.json
    """
    logger.log(
        f"Computing spec diffs for {len(rule_statuses)} rules",
        "INFO",
        "SpecDiffManager"
    )

    # Load AST mappings
    asts_mapping = load_asts_mapping(timestamp_dir)

    if not asts_mapping:
        logger.log(
            "No AST mappings found - skipping spec diff computation",
            "WARNING",
            "SpecDiffManager"
        )
        return {}

    # Group rules by job_id
    from collections import defaultdict
    jobs_to_rules = defaultdict(list)
    job_urls = {}

    for rule_name, rule_status in rule_statuses.items():
        if not rule_status.job_id or not rule_status.run_url:
            logger.log(
                f"Rule {rule_name} has no job_id or run_url, skipping",
                "WARNING",
                "SpecDiffManager"
            )
            continue

        jobs_to_rules[rule_status.job_id].append(rule_name)
        job_urls[rule_status.job_id] = rule_status.run_url

    logger.log(
        f"Grouped {len(rule_statuses)} rules into {len(jobs_to_rules)} jobs",
        "INFO",
        "SpecDiffManager"
    )

    # Compute diffs for each job
    all_spec_diffs = {}
    processed_rules = 0

    for job_id, rules_in_job in jobs_to_rules.items():
        job_url = job_urls[job_id]

        logger.log(
            f"Processing job {job_id} with {len(rules_in_job)} rules",
            "INFO",
            "SpecDiffManager"
        )

        # Define a wrapper progress callback that tracks global progress
        def job_progress_callback(_processed_in_job: int, rule_name: str):
            nonlocal processed_rules
            processed_rules += 1
            if progress_callback:
                progress_callback(processed_rules, rule_name)

        # Compute diffs for this job
        job_diffs = compute_spec_diffs_for_job(
            job_id,
            job_url,
            rules_in_job,
            snapshot,
            asts_mapping,
            timestamp_dir,
            dashboard_path,
            job_progress_callback
        )

        # Merge into all_spec_diffs for backward compatibility
        all_spec_diffs.update(job_diffs)

    # Log summary
    equivalent_count = sum(1 for d in all_spec_diffs.values() if d.get("equivalent") is True)
    different_count = sum(1 for d in all_spec_diffs.values() if d.get("equivalent") is False)
    unknown_count = sum(1 for d in all_spec_diffs.values() if d.get("equivalent") is None)

    logger.log(
        f"Spec diff summary: {equivalent_count} matching, {different_count} differing, {unknown_count} unknown",
        "INFO",
        "SpecDiffManager"
    )

    return all_spec_diffs


def load_spec_diffs(timestamp_dir: Path) -> Dict[str, Dict]:
    """
    Load the spec_diffs.json from a timestamp directory.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping rule_name → diff_result, or empty dict if not found
    """
    spec_diffs_path = timestamp_dir / FILE_SPEC_DIFFS

    if not spec_diffs_path.exists():
        logger.log(
            f"No spec_diffs.json found at {spec_diffs_path}",
            "INFO",
            "SpecDiffManager"
        )
        return {}

    try:
        with open(spec_diffs_path, "r") as f:
            return json5.load(f)

    except Exception as e:
        logger.log(
            f"Failed to load spec_diffs.json: {e}",
            "ERROR",
            "SpecDiffManager"
        )
        return {}
