#!/usr/bin/env python3
"""
Utility for comparing CVL spec AST JSON files.

This module provides deep comparison of spec ASTs, ignoring scope, range, and sourceSegment fields
during comparison, and generating detailed diffs for each type of spec element.
The range and sourceSegment fields are preserved in the output for context.
"""


import json
import copy
from typing import Any, Dict, List, Tuple, Optional
from pathlib import Path


class SpecDiff:
    """Class for comparing two CVL spec AST JSON structures."""

    # Fields to ignore during comparison
    # counter: non-deterministic rule numbering
    # range: source location (line numbers)
    # sourceSegment: source location (similar to range)
    # scope: internal scope information
    # relevantFuncs: internal function tracking
    # canonicalId: ignored when 'name' field is present (handled in _remove_ignored_fields)
    IGNORE_FIELDS_COMPARISON = {'scope', 'range', 'sourceSegment', 'relevantFuncs', 'counter'}
    # Fields to ignore in output (scope only, keep range and sourceSegment for code snippets)
    IGNORE_FIELDS_OUTPUT = {'scope', 'relevantFuncs', 'counter'}

    def __init__(self, spec1: Dict[str, Any], spec2: Dict[str, Any],
                 instances1: Dict[str, str] | None = None, instances2: Dict[str, str] | None = None):
        """
        Initialize SpecDiff with two spec ASTs.

        Args:
            spec1: First spec AST (dict)
            spec2: Second spec AST (dict)
            instances1: Instance ID to name mapping for spec1 (optional)
            instances2: Instance ID to name mapping for spec2 (optional)
        """
        self.spec1 = spec1
        self.spec2 = spec2
        self.instances1 = instances1 or {}
        self.instances2 = instances2 or {}
        self.diff_result: Optional[Dict[str, Any]] = None

    @staticmethod
    def _load_instances(instances_list: List[Dict[str, str]], source_name: str) -> Dict[str, str]:
        """
        Load and validate instances list from AST JSON.

        The instances list contains mappings from non-deterministic instanceIds to
        human-readable names. This allows us to compare specs by name instead of
        comparing random hex IDs.

        Args:
            instances_list: List of dicts with 'first' (instanceId) and 'second' (name)
            source_name: Name of the source ('local' or 'remote') for logging

        Returns:
            Dict mapping instanceId -> name, or empty dict if validation fails
        """
        if not instances_list:
            return {}

        instance_map = {}
        seen_ids: dict[str, str] = {}  # Track instanceId -> name to detect duplicates

        for entry in instances_list:
            if not isinstance(entry, dict):
                continue

            instance_id = entry.get('first')
            name = entry.get('second')

            if not instance_id or not name:
                continue

            # Check for duplicate instanceIds with different names
            if instance_id in seen_ids:
                existing_name = seen_ids[instance_id]
                if existing_name != name:
                    # Log warning and return empty map (skip all conversion)
                    print(f"WARNING: Duplicate instanceId '{instance_id}' found in {source_name} AST "
                          f"with different names: '{existing_name}' vs '{name}'. "
                          f"Skipping instanceId conversion for {source_name} AST.")
                    return {}
            else:
                seen_ids[instance_id] = name
                instance_map[instance_id] = name

        return instance_map

    @staticmethod
    def _remove_ignored_fields(obj: Any, ignore_set: set | None = None, bound_vars_map: dict | None = None) -> Any:
        """
        Recursively remove ignored fields from an object and normalize bound variables.

        This implements alpha-equivalence for QuantifierExp by normalizing bound variable
        names to their original names. For example, if two quantifiers use different
        generated IDs (alpha_xyz vs alpha_abc) but the same originalName, they will be
        normalized to the same canonical name.

        Args:
            obj: Object to clean (dict, list, or primitive)
            ignore_set: Set of fields to ignore (defaults to IGNORE_FIELDS_OUTPUT)
            bound_vars_map: Mapping from bound variable IDs to canonical names (for alpha-equivalence)

        Returns:
            Cleaned copy of the object with normalized bound variables
        """
        if ignore_set is None:
            ignore_set = SpecDiff.IGNORE_FIELDS_OUTPUT

        if bound_vars_map is None:
            bound_vars_map = {}

        if isinstance(obj, dict):
            # Check if this is a QuantifierExp that introduces a bound variable
            obj_type = obj.get('type') or ''
            is_quantifier = 'QuantifierExp' in obj_type

            # For QuantifierExp, create a new binding scope
            if is_quantifier:
                # Get the bound variable identifiers
                var_id = obj.get('id')
                var_name = obj.get('qVarName')
                # Use originalName as the canonical name, fallback to id if not present
                canonical_name = obj.get('originalName', var_id)

                # Create a new scope with this binding
                new_bound_vars_map = bound_vars_map.copy()
                if var_id:
                    new_bound_vars_map[var_id] = canonical_name
                if var_name and var_name != var_id:
                    new_bound_vars_map[var_name] = canonical_name

                # Process the object with the new binding scope
                result = {}
                for k, v in obj.items():
                    if k not in ignore_set:
                        # Normalize id and qVarName to canonical name
                        if k in ('id', 'qVarName') and is_quantifier:
                            result[k] = canonical_name
                        else:
                            result[k] = SpecDiff._remove_ignored_fields(v, ignore_set, new_bound_vars_map)
                return result
            else:
                # Regular dict - just recurse
                result = {}
                for k, v in obj.items():
                    # Skip fields in ignore_set
                    if k in ignore_set:
                        continue
                    # Skip canonicalId if name field is present, or if it's in vmType
                    # vmType.canonicalId often differs only in file path, not actual type
                    if k == 'canonicalId' and ('name' in obj or obj.get('type') == 'VmType'):
                        continue
                    result[k] = SpecDiff._remove_ignored_fields(v, ignore_set, bound_vars_map)
                return result
        elif isinstance(obj, list):
            return [SpecDiff._remove_ignored_fields(item, ignore_set, bound_vars_map) for item in obj]
        elif isinstance(obj, str):
            # If this string matches a bound variable, replace with canonical name
            return bound_vars_map.get(obj, obj)
        else:
            return obj

    def _resolve_instance_ids(self, obj: Any, instances_map: Dict[str, str], parent_key: str | None = None) -> Any:
        """
        Recursively resolve instanceId and contractInstanceId fields in an object using the instances map.

        Args:
            obj: Object to process (dict, list, or primitive)
            instances_map: Mapping from instanceId hex values to human-readable names
            parent_key: The key name of the current value (for instanceId detection)

        Returns:
            Copy of the object with instanceIds resolved to names
        """
        if isinstance(obj, dict):
            result = {}
            for key, val in obj.items():
                # If this is an instanceId or contractInstanceId field, resolve it
                if (key == 'instanceId' or key == 'contractInstanceId') and isinstance(val, str) and val in instances_map:
                    result[key] = instances_map[val]
                else:
                    result[key] = self._resolve_instance_ids(val, instances_map, key)
            return result
        elif isinstance(obj, list):
            return [self._resolve_instance_ids(item, instances_map, parent_key) for item in obj]
        else:
            return obj

    def _deep_equals(self, obj1: Any, obj2: Any) -> bool:
        """
        Deep equality check ignoring scope, range, and sourceSegment fields, with instanceId resolution.

        Args:
            obj1: First object
            obj2: Second object

        Returns:
            True if objects are deeply equal (ignoring ignored fields and resolving instanceIds)
        """
        # First clean ignored fields
        cleaned1 = SpecDiff._remove_ignored_fields(obj1, SpecDiff.IGNORE_FIELDS_COMPARISON)
        cleaned2 = SpecDiff._remove_ignored_fields(obj2, SpecDiff.IGNORE_FIELDS_COMPARISON)

        # Then resolve instanceIds using respective instances maps
        resolved1 = self._resolve_instance_ids(cleaned1, self.instances1)
        resolved2 = self._resolve_instance_ids(cleaned2, self.instances2)

        return resolved1 == resolved2

    def _find_deepest_difference(
        self,
        obj1: Any,
        obj2: Any,
        path: str = "",
        ignore_fields: set | None = None,
        parent_key: str | None = None
    ) -> Optional[Tuple[str, Any, Any]]:
        """
        Find the deepest (most nested) difference between two objects,
        excluding paths that go through ignored fields.

        When comparing instanceId fields, resolves the hex IDs to human-readable
        names using the instances maps from both ASTs.

        Args:
            obj1: First object
            obj2: Second object
            path: Current path (for recursion)
            ignore_fields: Set of field names to skip in paths
            parent_key: The key name of the current value being compared (for instanceId detection)

        Returns:
            Tuple of (path, before_value, after_value) for deepest difference, or None if equal
        """
        if ignore_fields is None:
            ignore_fields = set()

        differences = []

        # Collect all differences recursively
        def collect_diffs(o1, o2, current_path, current_key=None):
            # Handle None cases
            if o1 is None and o2 is None:
                return
            if o1 is None or o2 is None:
                differences.append((current_path, o1, o2))
                return

            # If types differ, this is a difference
            if type(o1) != type(o2):
                differences.append((current_path, o1, o2))
                return

            # Handle dictionaries
            if isinstance(o1, dict) and isinstance(o2, dict):
                # Special case: if both dicts have a 'type' field with different values,
                # this is a type change and we should report it at this level
                if 'type' in o1 and 'type' in o2:
                    type1 = o1.get('type')
                    type2 = o2.get('type')
                    if type1 != type2:
                        # Types differ - report the whole dict as different
                        differences.append((current_path, o1, o2))
                        return

                all_keys = set(o1.keys()) | set(o2.keys())
                for key in all_keys:
                    # Skip ignored fields
                    if key in ignore_fields:
                        continue

                    # Skip canonicalId if name field is present in both objects
                    # (canonicalId is redundant when name exists)
                    if key == 'canonicalId' and 'name' in o1 and 'name' in o2:
                        continue

                    val1 = o1.get(key)
                    val2 = o2.get(key)
                    new_path = f"{current_path}.{key}" if current_path else key

                    # Special handling: if one value is None and the other is a dict,
                    # or if we're comparing complex nested structures (dicts),
                    # consider reporting at this level rather than drilling deeper
                    if (val1 is None and isinstance(val2, dict)) or \
                       (isinstance(val1, dict) and val2 is None):
                        # A field was added or removed (None <-> dict)
                        # Report at the parent level (current dict) not the child
                        differences.append((current_path, o1, o2))
                        return

                    collect_diffs(val1, val2, new_path, key)
                return

            # Handle lists
            if isinstance(o1, list) and isinstance(o2, list):
                max_len = max(len(o1), len(o2))
                for i in range(max_len):
                    val1 = o1[i] if i < len(o1) else None
                    val2 = o2[i] if i < len(o2) else None
                    new_path = f"{current_path}[{i}]"
                    collect_diffs(val1, val2, new_path, current_key)
                return

            # Primitive values - compare directly
            # Special case: if the current key is 'instanceId' or 'contractInstanceId', resolve to names
            if current_key == 'instanceId' or current_key == 'contractInstanceId':
                resolved_o1 = self.instances1.get(o1, o1) if isinstance(o1, str) else o1
                resolved_o2 = self.instances2.get(o2, o2) if isinstance(o2, str) else o2
                if resolved_o1 != resolved_o2:
                    differences.append((current_path, resolved_o1, resolved_o2))
            elif o1 != o2:
                differences.append((current_path, o1, o2))

        # Collect all differences
        collect_diffs(obj1, obj2, path, parent_key)

        if not differences:
            return None

        # Find the deepest difference (most dots + brackets)
        def path_depth(p):
            return p.count('.') + p.count('[')

        deepest = max(differences, key=lambda x: path_depth(x[0]))
        return deepest

    def _compute_deep_diff(self, obj1: Any, obj2: Any) -> Optional[Dict[str, Any]]:
        """
        Compute a deep diff between two objects.

        Args:
            obj1: First object
            obj2: Second object

        Returns:
            Dict describing the differences with 'before', 'after', and optionally
            'path', 'path_before', 'path_after' fields, or None if equal
        """
        if self._deep_equals(obj1, obj2):
            return None

        # Find the deepest difference (excluding ignored fields)
        # This will resolve instanceIds to names automatically
        deepest = self._find_deepest_difference(
            obj1,
            obj2,
            ignore_fields=SpecDiff.IGNORE_FIELDS_COMPARISON
        )

        # Build result with before/after
        result = {
            'before': SpecDiff._remove_ignored_fields(obj1, SpecDiff.IGNORE_FIELDS_OUTPUT),
            'after': SpecDiff._remove_ignored_fields(obj2, SpecDiff.IGNORE_FIELDS_OUTPUT)
        }

        # Add path information if found
        if deepest:
            path, before_val, after_val = deepest
            result['path'] = path
            result['path_before'] = before_val
            result['path_after'] = after_val

        return result

    @staticmethod
    def _is_invariant(rule: dict) -> bool:
        """
        Check if a rule is actually an invariant.

        Args:
            rule: Rule object from AST

        Returns:
            True if this is an invariant, False if it's a regular rule
        """
        rule_type = rule.get('ruleType', {})
        type_str = rule_type.get('type', '') if isinstance(rule_type, dict) else ''
        return 'InvariantCheck' in type_str

    def _compare_rules(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Compare rules between the two specs (excluding invariants).

        Returns:
            Dict with 'added', 'removed', and 'modified' lists
        """
        all_rules1 = self.spec1.get('rules', [])
        all_rules2 = self.spec2.get('rules', [])

        # Get invariant names from the 'invs' array to exclude them from rules
        invs1 = self.spec1.get('invs', [])
        invs2 = self.spec2.get('invs', [])

        # Build set of invariant names to exclude
        inv_names1 = set()
        for inv in invs1:
            # Try id field first, then uniqueRuleIdentifier.displayName
            name = inv.get('id')
            if not name and 'uniqueRuleIdentifier' in inv:
                name = inv['uniqueRuleIdentifier'].get('displayName')
            if name:
                inv_names1.add(name)

        inv_names2 = set()
        for inv in invs2:
            name = inv.get('id')
            if not name and 'uniqueRuleIdentifier' in inv:
                name = inv['uniqueRuleIdentifier'].get('displayName')
            if name:
                inv_names2.add(name)

        all_inv_names = inv_names1 | inv_names2

        # Filter out invariants - we only want actual rules here
        # Exclude both by type check AND by name (in case they appear in rules array)
        rules1 = [r for r in all_rules1
                  if not self._is_invariant(r)
                  and r.get('ruleIdentifier', {}).get('displayName') not in all_inv_names]
        rules2 = [r for r in all_rules2
                  if not self._is_invariant(r)
                  and r.get('ruleIdentifier', {}).get('displayName') not in all_inv_names]

        # Build maps by displayName
        rules1_map = {
            rule['ruleIdentifier']['displayName']: rule
            for rule in rules1
            if 'ruleIdentifier' in rule and 'displayName' in rule['ruleIdentifier']
        }
        rules2_map = {
            rule['ruleIdentifier']['displayName']: rule
            for rule in rules2
            if 'ruleIdentifier' in rule and 'displayName' in rule['ruleIdentifier']
        }

        # Validation: Check that all rules were processed
        # Rules without proper ruleIdentifier.displayName are silently dropped
        uncovered_rules1 = [
            rule for rule in rules1
            if not ('ruleIdentifier' in rule and 'displayName' in rule['ruleIdentifier'])
        ]
        uncovered_rules2 = [
            rule for rule in rules2
            if not ('ruleIdentifier' in rule and 'displayName' in rule['ruleIdentifier'])
        ]

        if uncovered_rules1 or uncovered_rules2:
            error_msg = "Found rules without ruleIdentifier.displayName:\n"
            if uncovered_rules1:
                error_msg += f"  Spec1: {len(uncovered_rules1)} rules missing ruleIdentifier.displayName\n"
                for i, rule in enumerate(uncovered_rules1[:3]):  # Show first 3
                    error_msg += f"    Rule {i+1}: {json.dumps(rule, indent=2)[:200]}...\n"
            if uncovered_rules2:
                error_msg += f"  Spec2: {len(uncovered_rules2)} rules missing ruleIdentifier.displayName\n"
                for i, rule in enumerate(uncovered_rules2[:3]):  # Show first 3
                    error_msg += f"    Rule {i+1}: {json.dumps(rule, indent=2)[:200]}...\n"
            raise ValueError(error_msg)

        added = []
        removed = []
        modified = []
        # Find added and modified
        for name, rule2 in rules2_map.items():
            if name not in rules1_map:
                added.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'content': self._remove_ignored_fields(rule2)
                })
            elif not self._deep_equals(rules1_map[name], rule2):
                diff = self._compute_deep_diff(rules1_map[name], rule2)
                modified.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'diff': diff
                })

        # Find removed
        for name, rule1 in rules1_map.items():
            if name not in rules2_map:
                removed.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'content': self._remove_ignored_fields(rule1)
                })

        return {
            'added': added,
            'removed': removed,
            'modified': modified
        }

    def _compare_invariants(self) -> Dict[str, List[Dict[str, Any]]]:
        """
        Compare invariants between the two specs.

        Invariants are read from the 'invs' array at the top level of the spec.
        They use 'id' or 'uniqueRuleIdentifier.displayName' for identification.

        Returns:
            Dict with 'added', 'removed', and 'modified' lists
        """
        # Read invariants from the 'invs' array
        invs1 = self.spec1.get('invs', [])
        invs2 = self.spec2.get('invs', [])

        # Build maps by name (try 'id' first, then 'uniqueRuleIdentifier.displayName')
        def get_inv_name(inv):
            name = inv.get('id')
            if not name and 'uniqueRuleIdentifier' in inv:
                name = inv['uniqueRuleIdentifier'].get('displayName')
            return name

        invs1_map = {
            get_inv_name(inv): inv
            for inv in invs1
            if get_inv_name(inv)
        }
        invs2_map = {
            get_inv_name(inv): inv
            for inv in invs2
            if get_inv_name(inv)
        }

        added = []
        removed = []
        modified = []

        # Find added and modified
        for name, inv2 in invs2_map.items():
            if name not in invs1_map:
                added.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'content': self._remove_ignored_fields(inv2)
                })
            elif not self._deep_equals(invs1_map[name], inv2):
                diff = self._compute_deep_diff(invs1_map[name], inv2)
                modified.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'diff': diff
                })

        # Find removed
        for name, inv1 in invs1_map.items():
            if name not in invs2_map:
                removed.append({
                    'id': name,  # Frontend looks for 'id' field
                    'displayName': name,
                    'content': self._remove_ignored_fields(inv1)
                })

        return {
            'added': added,
            'removed': removed,
            'modified': modified
        }

    def _compare_global_list(
        self,
        list1: List[Dict[str, Any]],
        list2: List[Dict[str, Any]],
        id_field: str
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Compare two lists of global elements by identifier.

        Args:
            list1: First list of elements
            list2: Second list of elements
            id_field: Field name to use as identifier

        Returns:
            Dict with 'added', 'removed', and 'modified' lists
        """
        # Build maps by identifier
        map1 = {
            elem[id_field]: elem
            for elem in list1
            if id_field in elem and elem[id_field] is not None
        }
        map2 = {
            elem[id_field]: elem
            for elem in list2
            if id_field in elem and elem[id_field] is not None
        }

        added = []
        removed = []
        modified = []

        # Find added and modified
        for elem_id, elem2 in map2.items():
            if elem_id not in map1:
                added.append({
                    'id': elem_id,
                    'content': self._remove_ignored_fields(elem2)
                })
            elif not self._deep_equals(map1[elem_id], elem2):
                diff = self._compute_deep_diff(map1[elem_id], elem2)
                modified.append({
                    'id': elem_id,
                    'diff': diff
                })

        # Find removed
        for elem_id, elem1 in map1.items():
            if elem_id not in map2:
                removed.append({
                    'id': elem_id,
                    'content': self._remove_ignored_fields(elem1)
                })

        return {
            'added': added,
            'removed': removed,
            'modified': modified
        }

    @staticmethod
    def _get_summary_key(summary: Dict[str, Any]) -> str:
        """
        Extract a unique key from a summary for comparison.

        Args:
            summary: Summary dict (pair structure with 'first' and 'second')

        Returns:
            String key representing the summary signature
        """
        # Summaries are stored as pairs (first: signature, second: expression)
        # Use the signature as the key
        if 'first' not in summary:
            raise ValueError("Summary missing 'first' field")

        first = summary['first']
        # Convert the signature to a JSON string for consistent hashing
        cleaned = SpecDiff._remove_ignored_fields(first, SpecDiff.IGNORE_FIELDS_COMPARISON)
        return json.dumps(cleaned, sort_keys=True)

    @staticmethod
    def _format_vmtype(vmtype: Dict[str, Any]) -> str:
        """
        Format a vmType object into a readable type string.

        Args:
            vmtype: vmType dict from a parameter

        Returns:
            Formatted type string (e.g., "uint256", "address", etc.)
        """
        if not vmtype or not isinstance(vmtype, dict):
            return "unknown"

        vmtype_type = vmtype.get('type', '')

        # Handle UIntK (e.g., uint8, uint256)
        if 'UIntK' in vmtype_type:
            bitwidth = vmtype.get('bitwidth', 256)
            return f"uint{bitwidth}"

        # Handle IntK (e.g., int8, int256)
        if 'IntK' in vmtype_type:
            bitwidth = vmtype.get('bitwidth', 256)
            return f"int{bitwidth}"

        # Handle BytesK (e.g., bytes1, bytes32)
        if 'BytesK' in vmtype_type:
            bitwidth = vmtype.get('bitwidth', 32)
            return f"bytes{bitwidth}"

        # Handle UserDefinedValueType
        if 'UserDefinedValueType' in vmtype_type:
            return vmtype.get('name', 'unknown')

        # Handle address type
        if 'address' in vmtype_type.lower():
            return 'address'

        # Handle struct types - extract the struct name from canonicalId
        if 'Struct' in vmtype_type:
            canonical_id = vmtype.get('canonicalId', '')
            if canonical_id:
                # canonicalId format: "contracts/path/File.sol|ContractName.StructName"
                # Extract just the struct name
                if '|' in canonical_id:
                    parts = canonical_id.split('|')[-1].split('.')
                    return parts[-1] if parts else canonical_id
            return 'struct'

        # For ReflectivePolymorphicSerializer types, extract the simple type name
        if 'ReflectivePolymorphicSerializer' in vmtype_type or '::' in vmtype_type:
            # Extract the last part after :: or $
            simple_type = vmtype_type.split('::')[-1].split('$')[-1]
            return simple_type if simple_type else vmtype_type

        # For any other type, return the type string itself
        return vmtype_type

    @staticmethod
    def _format_signature(signature: Dict[str, Any] | None) -> str:
        """
        Format a signature object into a readable string for display.

        Args:
            signature: Signature dict from a summary's 'first' field

        Returns:
            Formatted signature string (e.g., "Contract.method(uint256, address)")
        """
        if not signature or not isinstance(signature, dict):
            return "Unknown"

        sig_type = signature.get('type', '')

        # Get the nested signature object (contains functionName, params, etc.)
        sig_obj = signature.get('signature', {})
        if not isinstance(sig_obj, dict):
            sig_obj = {}

        # Extract host and method name based on signature type
        host = None
        method_name = None

        if 'InternalWildcard' in sig_type or 'ExternalWildcard' in sig_type:
            # Wildcards: host is '_', method from nested functionName
            host = '_'
            method_name = sig_obj.get('functionName', None)

        elif 'InternalExact' in sig_type:
            # InternalExact: try to get host from contractId
            host = sig_obj.get('contractId', 'unknown')
            qualified = sig_obj.get('qualifiedMethodName', {})
            if isinstance(qualified, dict):
                method_name = qualified.get('methodId', None)

        elif 'ExternalExact' in sig_type:
            # ExternalExact: host from qualifiedMethodName.host.name
            qualified = sig_obj.get('qualifiedMethodName', {})
            if isinstance(qualified, dict):
                host_obj = qualified.get('host', {})
                if isinstance(host_obj, dict):
                    host = host_obj.get('name', 'unknown')
                method_name = qualified.get('methodId', None)

        elif 'ExternalAnyInContract' in sig_type:
            # ExternalAnyInContract: host from top-level hostContract
            host = signature.get('hostContract', 'unknown')
            # No specific method name for AnyInContract

        elif 'ExternalUnresolved' in sig_type:
            # ExternalUnresolved: special host indicator
            host = 'unresolved external'
            # No specific method name for Unresolved

        # Extract parameters from nested signature object
        params = sig_obj.get('params', [])
        if params and isinstance(params, list):
            param_types = []
            for param in params:
                if isinstance(param, dict):
                    vmtype = param.get('vmType', {})
                    param_types.append(SpecDiff._format_vmtype(vmtype))
            params_str = f"({', '.join(param_types)})"
        else:
            params_str = ""

        # Build the final signature string
        parts = []
        if host:
            parts.append(host)
        if method_name:
            if parts:
                parts.append('.')
            parts.append(method_name)
            parts.append(params_str)
        elif not method_name and params_str:
            # Has params but no method (shouldn't happen, but handle gracefully)
            parts.append(params_str)

        result = ''.join(parts)
        return result if result else "Unknown"

    def _compare_summaries(
        self,
        list1: List[Dict[str, Any]],
        list2: List[Dict[str, Any]]
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Compare two lists of summaries (internal, external, or unresolved).

        Args:
            list1: First list of summaries
            list2: Second list of summaries

        Returns:
            Dict with 'added', 'removed', and 'modified' lists
        """
        # Build maps by signature key
        map1 = {}
        for summary in list1:
            try:
                key = self._get_summary_key(summary)
                map1[key] = summary
            except (KeyError, ValueError):
                # Skip malformed summaries
                continue

        map2 = {}
        for summary in list2:
            try:
                key = self._get_summary_key(summary)
                map2[key] = summary
            except (KeyError, ValueError):
                # Skip malformed summaries
                continue

        added = []
        removed = []
        modified = []

        # Find added and modified
        for key, summary2 in map2.items():
            if key not in map1:
                added.append({
                    'id': self._format_signature(summary2.get('first')),
                    'signature': self._remove_ignored_fields(summary2.get('first')),
                    'content': self._remove_ignored_fields(summary2)
                })
            elif not self._deep_equals(map1[key], summary2):
                diff = self._compute_deep_diff(map1[key], summary2)
                modified.append({
                    'id': self._format_signature(summary2.get('first')),
                    'signature': self._remove_ignored_fields(summary2.get('first')),
                    'diff': diff
                })

        # Find removed
        for key, summary1 in map1.items():
            if key not in map2:
                removed.append({
                    'id': self._format_signature(summary1.get('first')),
                    'signature': self._remove_ignored_fields(summary1.get('first')),
                    'content': self._remove_ignored_fields(summary1)
                })

        return {
            'added': added,
            'removed': removed,
            'modified': modified
        }

    def compare(self) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        Perform full comparison of the two specs.

        Returns:
            Tuple of (equivalent: bool, diff: Optional[Dict])
            If equivalent is True, diff will be None.
            Otherwise, diff contains the detailed differences.
        """
        # Compare rules
        rules_diff = self._compare_rules()

        # Compare invariants
        invs_diff = self._compare_invariants()

        # Compare subs (CVL functions)
        subs_diff = self._compare_global_list(
            self.spec1.get('subs', []),
            self.spec2.get('subs', []),
            'declarationId'
        )

        # Compare ghosts
        ghosts_diff = self._compare_global_list(
            self.spec1.get('ghosts', []),
            self.spec2.get('ghosts', []),
            'id'
        )

        # Compare definitions
        defs_diff = self._compare_global_list(
            self.spec1.get('definitions', []),
            self.spec2.get('definitions', []),
            'id'
        )

        # Compare hooks
        hooks_diff = self._compare_global_list(
            self.spec1.get('hooks', []),
            self.spec2.get('hooks', []),
            'id'
        )

        # Compare summaries
        internal_summ_diff = self._compare_summaries(
            self.spec1.get('internalSummaries', []),
            self.spec2.get('internalSummaries', [])
        )

        external_summ_diff = self._compare_summaries(
            self.spec1.get('externalSummaries', []),
            self.spec2.get('externalSummaries', [])
        )

        unresolved_summ_diff = self._compare_summaries(
            self.spec1.get('unresolvedSummaries', []),
            self.spec2.get('unresolvedSummaries', [])
        )

        # Check if anything differs
        has_diff = any([
            rules_diff['added'] or rules_diff['removed'] or rules_diff['modified'],
            invs_diff['added'] or invs_diff['removed'] or invs_diff['modified'],
            subs_diff['added'] or subs_diff['removed'] or subs_diff['modified'],
            ghosts_diff['added'] or ghosts_diff['removed'] or ghosts_diff['modified'],
            defs_diff['added'] or defs_diff['removed'] or defs_diff['modified'],
            hooks_diff['added'] or hooks_diff['removed'] or hooks_diff['modified'],
            internal_summ_diff['added'] or internal_summ_diff['removed'] or internal_summ_diff['modified'],
            external_summ_diff['added'] or external_summ_diff['removed'] or external_summ_diff['modified'],
            unresolved_summ_diff['added'] or unresolved_summ_diff['removed'] or unresolved_summ_diff['modified'],
        ])

        if not has_diff:
            self.diff_result = None
            return (True, None)

        # Build diff result
        self.diff_result = {
            'equivalent': False,
            'rules': rules_diff,
            'invariants': invs_diff,
            'global_elements': {
                'subs': subs_diff,
                'ghosts': ghosts_diff,
                'definitions': defs_diff,
                'hooks': hooks_diff,
                'internalSummaries': internal_summ_diff,
                'externalSummaries': external_summ_diff,
                'unresolvedSummaries': unresolved_summ_diff,
            }
        }

        return (False, self.diff_result)


def compare_specs(
    spec1_path: str,
    spec2_path: str
) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """
    Compare two CVL spec AST JSON files.

    Args:
        spec1_path: Path to first spec JSON file
        spec2_path: Path to second spec JSON file

    Returns:
        Tuple of (equivalent: bool, diff: Optional[Dict])

    Raises:
        FileNotFoundError: If either file doesn't exist
        json.JSONDecodeError: If either file is not valid JSON
    """
    # Load specs
    spec1_file = Path(spec1_path)
    spec2_file = Path(spec2_path)

    if not spec1_file.exists():
        raise FileNotFoundError(f"Spec file not found: {spec1_path}")
    if not spec2_file.exists():
        raise FileNotFoundError(f"Spec file not found: {spec2_path}")

    with open(spec1_file, 'r') as f:
        spec1 = json.load(f)

    with open(spec2_file, 'r') as f:
        spec2 = json.load(f)

    # Load and validate instances from both ASTs
    instances1 = SpecDiff._load_instances(spec1.get('instances', []), 'local')
    instances2 = SpecDiff._load_instances(spec2.get('instances', []), 'remote')

    # Create diff and compare
    diff = SpecDiff(spec1, spec2, instances1, instances2)
    return diff.compare()


def format_diff_human_readable(diff: Dict[str, Any]) -> str:
    """
    Format the diff output in a human-readable way.

    Args:
        diff: Diff dict from compare_specs

    Returns:
        Human-readable string representation
    """
    lines = []
    lines.append("=" * 80)
    lines.append("SPEC COMPARISON RESULT")
    lines.append("=" * 80)
    lines.append("")

    # Rules
    rules = diff.get('rules', {})
    if rules.get('added') or rules.get('removed') or rules.get('modified'):
        lines.append("RULES:")
        lines.append("-" * 80)

        if rules.get('added'):
            lines.append(f"  Added ({len(rules['added'])}):")
            for rule in rules['added']:
                lines.append(f"    - {rule['displayName']}")

        if rules.get('removed'):
            lines.append(f"  Removed ({len(rules['removed'])}):")
            for rule in rules['removed']:
                lines.append(f"    - {rule['displayName']}")

        if rules.get('modified'):
            lines.append(f"  Modified ({len(rules['modified'])}):")
            for rule in rules['modified']:
                lines.append(f"    - {rule['displayName']}")

        lines.append("")

    # Invariants
    invs = diff.get('invariants', {})
    if invs.get('added') or invs.get('removed') or invs.get('modified'):
        lines.append("INVARIANTS:")
        lines.append("-" * 80)

        if invs.get('added'):
            lines.append(f"  Added ({len(invs['added'])}):")
            for inv in invs['added']:
                lines.append(f"    - {inv['displayName']}")

        if invs.get('removed'):
            lines.append(f"  Removed ({len(invs['removed'])}):")
            for inv in invs['removed']:
                lines.append(f"    - {inv['displayName']}")

        if invs.get('modified'):
            lines.append(f"  Modified ({len(invs['modified'])}):")
            for inv in invs['modified']:
                lines.append(f"    - {inv['displayName']}")

        lines.append("")

    # Global elements
    global_elems = diff.get('global_elements', {})
    for elem_type in ['subs', 'ghosts', 'definitions', 'hooks',
                      'internalSummaries', 'externalSummaries', 'unresolvedSummaries']:
        elem_diff = global_elems.get(elem_type, {})
        if elem_diff.get('added') or elem_diff.get('removed') or elem_diff.get('modified'):
            lines.append(f"{elem_type.upper()}:")
            lines.append("-" * 80)

            if elem_diff.get('added'):
                lines.append(f"  Added ({len(elem_diff['added'])}):")
                for item in elem_diff['added']:
                    item_id = item.get('id') or item.get('signature', '<signature>')
                    lines.append(f"    - {item_id}")

            if elem_diff.get('removed'):
                lines.append(f"  Removed ({len(elem_diff['removed'])}):")
                for item in elem_diff['removed']:
                    item_id = item.get('id') or item.get('signature', '<signature>')
                    lines.append(f"    - {item_id}")

            if elem_diff.get('modified'):
                lines.append(f"  Modified ({len(elem_diff['modified'])}):")
                for item in elem_diff['modified']:
                    item_id = item.get('id') or item.get('signature', '<signature>')
                    lines.append(f"    - {item_id}")

            lines.append("")

    lines.append("=" * 80)
    return "\n".join(lines)


def main():
    """Command-line interface for spec comparison."""
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description='Compare two CVL spec AST JSON files'
    )
    parser.add_argument(
        'spec1',
        help='Path to first spec JSON file'
    )
    parser.add_argument(
        'spec2',
        help='Path to second spec JSON file'
    )
    parser.add_argument(
        '-o', '--output',
        help='Output file for diff JSON (default: stdout)',
        default=None
    )
    parser.add_argument(
        '-f', '--format',
        help='Output format: json or human (default: human)',
        choices=['json', 'human'],
        default='human'
    )

    args = parser.parse_args()

    try:
        equivalent, diff = compare_specs(args.spec1, args.spec2)

        if equivalent:
            print("Specs are equivalent (ignoring scope and range fields during comparison)")
            sys.exit(0)
        else:
            print("Specs differ")
            print()

            if args.format == 'json':
                output = json.dumps(diff, indent=2)
            else:
                assert diff is not None, "diff should never be None when equivalent is False"
                output = format_diff_human_readable(diff)

            if args.output:
                with open(args.output, 'w') as f:
                    f.write(output)
                print(f"Diff written to: {args.output}")
            else:
                print(output)

            sys.exit(1)

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
    except json.JSONDecodeError as e:
        print(f"Error parsing JSON: {e}", file=sys.stderr)
        sys.exit(2)
    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        raise


if __name__ == '__main__':
    main()
