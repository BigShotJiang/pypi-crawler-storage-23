"""
Cloud synchronization module for fetching verification job data.

Interfaces with .certora_recent_jobs.json and ProverOutputAPI to fetch
verification statuses for rules.
"""

import asyncio
import json
import re
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from prover_output_utility import ProverOutputAPI  # type: ignore[import-untyped]

# Lock to serialize ProverOutputAPI creation across threads.
# Prevents concurrent OAuth callback server conflicts when credentials expire.
# ProverOutputAPI internally uses cert-python-cli-login which starts a local
# HTTP server for OAuth callbacks - multiple threads racing to bind the same
# port causes "[Errno 98] Address already in use" errors.
_prover_api_lock = threading.Lock()


def _create_prover_api() -> ProverOutputAPI:
    """
    Create a ProverOutputAPI instance with serialized authentication.

    Uses a lock to prevent multiple threads from triggering concurrent
    OAuth flows, which would cause port conflicts.
    """
    with _prover_api_lock:
        return ProverOutputAPI()

from src.dashboard.constants import (
    DashboardEcosystem,
    DIR_CERTORA_INTERNAL,
    FILE_LAST_CLOUD_SYNC,
    FILE_LAST_CLOUD_SYNC_REMOTE,
    FILE_RECENT_JOBS,
    FILE_REMOTE_JOBS,
    MODE_REMOTE,
    PROGRESS_STATUS_COMPLETED,
    PROGRESS_STATUS_RUNNING,
    RUN_PROVENANCE_LOCAL,
    RUN_PROVENANCE_REMOTE,
    STATUS_PENDING,
    STATUS_VACUITY,
    TWO_HOURS_SECONDS,
)
from src.dashboard.ast_manager import generate_local_asts_for_snapshot, load_asts_mapping
from src.dashboard.conf_diff_manager import compute_conf_diff_for_job
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import JobInfo, RuleStatus, ScanSnapshot
from src.dashboard.progress_tracker import SyncProgress, clear_progress, load_progress, save_progress
from src.dashboard.source_diff_manager import compute_source_diff_for_job
from src.dashboard.spec_diff_manager import compute_all_spec_diffs, compute_spec_diffs_for_job
from src.dashboard.spec_validator import validate_all_statuses
from src.dashboard.status_processor import aggregate_method_statuses, compute_rule_color, map_prover_status_to_color
from src.dashboard.storage import load_all_rule_statuses, load_rule_statuses, save_all_rule_statuses, save_rule_statuses
from src.dashboard.sync_remote_jobs import fetch_job_metadata


def parse_move_rule_name(cloud_rule_name: str) -> Tuple[str, str, str, Optional[str]]:
    """
    Parse a Move cloud rule name into components.

    Move cloud rule format: {module}::{file}::{rule_name}[-{method}]

    Args:
        cloud_rule_name: Full cloud rule name

    Returns:
        Tuple of (module, file, rule_name, method_name)
        method_name is None for non-parametric rules

    Examples:
        "0x0::bridge_rules::send_token_burns_coin"
        -> ("0x0", "bridge_rules", "send_token_burns_coin", None)

        "0x0::bridge_rules::only_claiming_mints_tokens-0xb::bridge::claim_token"
        -> ("0x0", "bridge_rules", "only_claiming_mints_tokens", "0xb::bridge::claim_token")
    """
    # Split by ::
    parts = cloud_rule_name.split("::")
    if len(parts) < 3:
        # Malformed name, return as-is
        return ("", "", cloud_rule_name, None)

    module = parts[0]
    file = parts[1]

    # Everything after second :: could be rule_name or rule_name-method
    remainder = "::".join(parts[2:])

    # Check for hyphen indicating parametric rule (method)
    if "-" in remainder:
        # Split on first hyphen only (method name may contain hyphens)
        rule_name, method = remainder.split("-", 1)
        return (module, file, rule_name, method)
    else:
        # Non-parametric rule
        return (module, file, remainder, None)


def parse_rust_rule_name(cloud_rule_name: str) -> str:
    """
    Parse a Rust cloud rule name.

    Rust cloud rules are simply the function name marked with #[rule].
    No module/file prefix, no method suffix.

    Args:
        cloud_rule_name: Full cloud rule name

    Returns:
        The rule name (same as input for Rust)

    Examples:
        "rule_fee_sanity" -> "rule_fee_sanity"
        "rule_fee_assessed" -> "rule_fee_assessed"
    """
    return cloud_rule_name


def find_conf_by_spec(main_spec: str, snapshot: ScanSnapshot, cwd: Path) -> Optional[str]:
    """
    Find conf_path by matching main_spec from job metadata to snapshot confs.

    Args:
        main_spec: Spec file path from job metadata (e.g., "certora/spec/Spoke.spec")
        snapshot: Current scan snapshot
        cwd: Project root directory

    Returns:
        Absolute conf_path if found, None otherwise
    """
    if not main_spec:
        return None

    try:
        # Convert main_spec to absolute path for comparison
        spec_path = (cwd / main_spec).resolve()

        # Find conf where main_spec matches
        for conf_info in snapshot.confs:
            if conf_info.main_spec and conf_info.main_spec.resolve() == spec_path:
                return str(conf_info.conf_path)

        return None

    except Exception as e:
        logger.log(f"Error matching spec '{main_spec}' to conf: {e}", "WARNING", "CloudSync")
        return None


def find_conf_for_rust_job(
    metadata: Dict[str, Any],
    snapshot: ScanSnapshot,
    cwd: Path,
    job_id: Optional[str] = None
) -> Optional[str]:
    """
    Find conf_path for a Rust/Solana job using multi-level matching.

    RUST-ONLY: This function is specifically for Rust jobs where main_spec is null.
    Solidity and Move jobs use find_conf_by_spec() instead.

    Matching priority:
    1. cwd_relative - narrow to confs in that directory
    2. rule - match by explicit rule list (most precise!)
    3. msg - parse conf file, match msg field
    4. prover_args - last resort fallback

    Args:
        metadata: Full job metadata dict
        snapshot: Current scan snapshot
        cwd: Project working directory
        job_id: Job ID for logging purposes

    Returns:
        conf_path if found, None otherwise
    """
    cwd_relative = metadata.get("cwd_relative", "")
    conf_obj = metadata.get("conf", {})
    job_label = f"[job {job_id}] " if job_id else ""

    if not isinstance(conf_obj, dict):
        logger.log(f"{job_label}Rust conf matching: conf is not a dict, returning None", "DEBUG", "CloudSync")
        return None

    job_rules = conf_obj.get("rule", [])
    conf_msg = conf_obj.get("msg", "")
    job_prover_args = conf_obj.get("prover_args", [])

    # DEBUG: Log input metadata
    logger.log(
        f"{job_label}Rust conf matching inputs: cwd_relative='{cwd_relative}', "
        f"job_rules={job_rules}, conf_msg='{conf_msg}', "
        f"prover_args={job_prover_args[:3]}{'...' if len(job_prover_args) > 3 else ''}",
        "DEBUG",
        "CloudSync"
    )

    try:
        # Step 1: Narrow to confs in cwd_relative directory
        candidate_confs = []
        if cwd_relative:
            conf_dir = (cwd / cwd_relative).resolve()
            for conf_info in snapshot.confs:
                if conf_info.conf_type == "Rust" and conf_info.conf_path.parent.resolve() == conf_dir:
                    candidate_confs.append(conf_info)
            logger.log(
                f"{job_label}Rust conf matching: filtered by cwd_relative '{cwd_relative}' -> {len(candidate_confs)} candidates: "
                f"{[c.conf_path.name for c in candidate_confs]}",
                "DEBUG",
                "CloudSync"
            )
        else:
            # No cwd_relative, use all Rust confs
            candidate_confs = [c for c in snapshot.confs if c.conf_type == "Rust"]
            logger.log(
                f"{job_label}Rust conf matching: no cwd_relative, using all {len(candidate_confs)} Rust confs: "
                f"{[c.conf_path.name for c in candidate_confs]}",
                "DEBUG",
                "CloudSync"
            )

        if not candidate_confs:
            logger.log(f"{job_label}Rust conf matching: no candidates found, returning None", "DEBUG", "CloudSync")
            return None

        # If only one candidate, use it
        if len(candidate_confs) == 1:
            result = str(candidate_confs[0].conf_path)
            logger.log(
                f"{job_label}Rust conf matching: single candidate, returning '{candidate_confs[0].conf_path.name}'",
                "DEBUG",
                "CloudSync"
            )
            return result

        # Step 2: Try to match by rule field (most precise!)
        if job_rules:
            job_rules_set = set(job_rules)
            logger.log(f"{job_label}Rust conf matching: trying rule match with {len(job_rules)} rules: {job_rules}", "DEBUG", "CloudSync")
            for conf_info in candidate_confs:
                conf_rules_set = set(conf_info.rules)
                if job_rules_set == conf_rules_set:
                    result = str(conf_info.conf_path)
                    logger.log(
                        f"{job_label}Rust conf matching: RULE MATCH! job_rules == conf_rules for '{conf_info.conf_path.name}'",
                        "DEBUG",
                        "CloudSync"
                    )
                    return result
                else:
                    # Log the mismatch for debugging
                    logger.log(
                        f"{job_label}Rust conf matching: rule mismatch for '{conf_info.conf_path.name}': "
                        f"job_rules={job_rules_set}, conf_rules={conf_rules_set}",
                        "DEBUG",
                        "CloudSync"
                    )
            logger.log(f"{job_label}Rust conf matching: no rule match found", "DEBUG", "CloudSync")
        else:
            logger.log(f"{job_label}Rust conf matching: no job_rules in metadata, skipping rule match", "DEBUG", "CloudSync")

        # Step 3: Try to match by msg field (parse conf file)
        if conf_msg:
            logger.log(f"{job_label}Rust conf matching: trying msg match with '{conf_msg}'", "DEBUG", "CloudSync")
            for conf_info in candidate_confs:
                conf_file_msg = _read_conf_msg(conf_info.conf_path)
                if conf_file_msg == conf_msg:
                    result = str(conf_info.conf_path)
                    logger.log(
                        f"{job_label}Rust conf matching: MSG MATCH! '{conf_info.conf_path.name}'",
                        "DEBUG",
                        "CloudSync"
                    )
                    return result
            logger.log(f"{job_label}Rust conf matching: no msg match found", "DEBUG", "CloudSync")
        else:
            logger.log(f"{job_label}Rust conf matching: no conf_msg in metadata, skipping msg match", "DEBUG", "CloudSync")

        # Step 4: Fall back to prover_args (last resort)
        # Sort both lists before comparison in case order differs
        if job_prover_args:
            sorted_job_args = sorted(job_prover_args)
            logger.log(f"{job_label}Rust conf matching: trying prover_args match", "DEBUG", "CloudSync")
            for conf_info in candidate_confs:
                conf_prover_args = _read_conf_prover_args(conf_info.conf_path)
                if sorted(conf_prover_args) == sorted_job_args:
                    result = str(conf_info.conf_path)
                    logger.log(
                        f"{job_label}Rust conf matching: PROVER_ARGS MATCH! '{conf_info.conf_path.name}'",
                        "DEBUG",
                        "CloudSync"
                    )
                    return result
            logger.log(f"{job_label}Rust conf matching: no prover_args match found", "DEBUG", "CloudSync")
        else:
            logger.log(f"{job_label}Rust conf matching: no job_prover_args in metadata, skipping prover_args match", "DEBUG", "CloudSync")

        logger.log(
            f"{job_label}Rust conf matching: NO MATCH FOUND after all steps, returning None. "
            f"Candidates were: {[c.conf_path.name for c in candidate_confs]}",
            "WARNING",
            "CloudSync"
        )
        return None

    except Exception as e:
        logger.log(f"{job_label}Error in Rust conf matching: {e}", "WARNING", "CloudSync")
        return None


def _read_conf_prover_args(conf_path: Path) -> List[str]:
    """Read prover_args from a conf file."""
    try:
        with open(conf_path, 'r') as f:
            conf_data = json.load(f)
        return conf_data.get("prover_args", [])
    except Exception:
        return []


def _read_conf_msg(conf_path: Path) -> str:
    """Read msg from a conf file."""
    try:
        with open(conf_path, 'r') as f:
            conf_data = json.load(f)
        return conf_data.get("msg", "")
    except Exception:
        return ""


def filter_move_statuses(
    all_statuses_history: Dict[str, List[RuleStatus]],
    snapshot_rules: set
) -> Dict[str, List[RuleStatus]]:
    """
    Filter and process Move cloud statuses with smart parsing and parametric support.

    This function:
    1. Parses Move cloud rule names to extract rule name and method
    2. Groups methods by (rule_name, job_id) to preserve history
    3. Creates combined RuleStatus objects for parametric rules
    4. Maintains full history (one entry per job)

    Args:
        all_statuses_history: Dict mapping cloud rule names to list of statuses
        snapshot_rules: Set of local rule names from current scan

    Returns:
        Dict mapping local rule names to list of filtered/combined statuses
    """
    logger.log("Move confs detected, using smart parsing and method grouping", "INFO", "CloudSync")

    # Step 1: Parse all cloud rule names and group by local rule name
    move_rules: dict = {}  # local_rule_name -> { cloud_name -> status_list }

    for cloud_rule_name, status_list in all_statuses_history.items():
        # Parse the cloud rule name
        module, file, rule_name, method = parse_move_rule_name(cloud_rule_name)

        # Check if this rule_name matches any snapshot rule (exact match)
        if rule_name in snapshot_rules:
            if rule_name not in move_rules:
                move_rules[rule_name] = {}

            move_rules[rule_name][cloud_rule_name] = status_list
            logger.log(
                f"Matched cloud rule '{cloud_rule_name}' → local rule '{rule_name}' (method: {method or 'none'})",
                "DEBUG",
                "CloudSync"
            )

    # Step 2: Process each local rule to handle parametric rules
    filtered_statuses_history = {}

    for local_rule_name, cloud_rules in move_rules.items():
        # Group statuses by job_id to preserve history
        jobs_by_id: dict = {}  # job_id -> { method -> status }
        non_parametric_by_job = {}  # job_id -> status (for non-parametric rules)
        cloud_rule_names = {}  # job_id -> cloud_rule_name (track for each job)

        for cloud_name, status_list in cloud_rules.items():
            module, file, rule_name_part, method = parse_move_rule_name(cloud_name)

            for status in status_list:
                job_id = status.job_id

                if method:
                    # Parametric - group methods by job
                    if job_id not in jobs_by_id:
                        jobs_by_id[job_id] = {}
                    jobs_by_id[job_id][method] = status
                    # Store the cloud rule name base (without method) for this job
                    if job_id not in cloud_rule_names:
                        # Reconstruct base name: module::file::rule_name
                        cloud_rule_names[job_id] = f"{module}::{file}::{rule_name_part}"
                else:
                    # Non-parametric - one status per job
                    non_parametric_by_job[job_id] = status
                    # Store the full cloud rule name for this job
                    cloud_rule_names[job_id] = cloud_name

        # Create statuses for each job
        combined_statuses = []

        if jobs_by_id:
            # Parametric rule - create one combined status per job
            for job_id in sorted(jobs_by_id.keys(), key=lambda jid: jobs_by_id[jid][next(iter(jobs_by_id[jid]))].timestamp, reverse=True):
                method_statuses_dict = {}
                template_status = None

                # Collect method statuses for this job
                for method, status in jobs_by_id[job_id].items():
                    method_statuses_dict[method] = status.overall_status
                    if template_status is None:
                        template_status = status

                if template_status:
                    # Aggregate overall status from methods
                    overall = aggregate_method_statuses(method_statuses_dict, template_status.job_status)

                    # Get cloud rule name: prefer from tracking dict, fallback to existing value
                    cloud_rule_name = cloud_rule_names.get(job_id) or template_status.cloud_rule_name

                    # Create combined status for this job
                    combined_status = RuleStatus(
                        rule_name=local_rule_name,
                        overall_status=overall,
                        method_statuses=method_statuses_dict,
                        job_id=template_status.job_id,
                        timestamp=template_status.timestamp,
                        run_url=template_status.run_url,
                        job_status=template_status.job_status,
                        run_provenance=template_status.run_provenance,
                        cloud_rule_name=cloud_rule_name,
                        ecosystem=DashboardEcosystem.MOVE.value
                    )

                    combined_statuses.append(combined_status)

            filtered_statuses_history[local_rule_name] = combined_statuses

            logger.log(
                f"Created parametric rule '{local_rule_name}' with {len(jobs_by_id[next(iter(jobs_by_id))])} methods across {len(jobs_by_id)} jobs",
                "INFO",
                "CloudSync"
            )
        elif non_parametric_by_job:
            # Non-parametric rule - collect all jobs sorted by timestamp
            non_parametric_statuses = sorted(
                non_parametric_by_job.values(),
                key=lambda s: s.timestamp,
                reverse=True
            )

            # Update rule_name, cloud_rule_name, and ecosystem fields in statuses
            for status in non_parametric_statuses:
                status.rule_name = local_rule_name
                status.cloud_rule_name = cloud_rule_names.get(status.job_id)
                status.ecosystem = DashboardEcosystem.MOVE.value

            filtered_statuses_history[local_rule_name] = non_parametric_statuses

            logger.log(
                f"Matched non-parametric rule '{local_rule_name}' with {len(non_parametric_statuses)} jobs",
                "DEBUG",
                "CloudSync"
            )

    return filtered_statuses_history


def filter_rust_statuses(
    all_statuses_history: Dict[str, List[RuleStatus]],
    snapshot_rules: set
) -> Dict[str, List[RuleStatus]]:
    """
    Filter and process Rust cloud statuses with exact matching.

    Rust rules are non-parametric and use simple function names.

    Args:
        all_statuses_history: Dict mapping cloud rule names to list of statuses
        snapshot_rules: Set of local rule names from current scan

    Returns:
        Dict mapping local rule names to list of filtered statuses
    """
    logger.log("Rust confs detected, using exact name matching", "INFO", "CloudSync")

    filtered_statuses_history = {}

    for cloud_rule_name, status_list in all_statuses_history.items():
        # Parse the cloud rule name (returns same name for Rust)
        rule_name = parse_rust_rule_name(cloud_rule_name)

        # Check if this rule exists in snapshot (exact match)
        if rule_name in snapshot_rules:
            # Update ecosystem field on all statuses
            for status in status_list:
                status.rule_name = rule_name
                status.cloud_rule_name = cloud_rule_name
                status.ecosystem = DashboardEcosystem.RUST.value

            filtered_statuses_history[rule_name] = status_list
            logger.log(
                f"Matched Rust rule '{rule_name}' with {len(status_list)} jobs",
                "DEBUG",
                "CloudSync"
            )

    return filtered_statuses_history


def parse_recent_jobs(cwd: Path) -> List[JobInfo]:
    """
    Parse .certora_recent_jobs.json to extract job information.

    Args:
        cwd: Current working directory (project root)

    Returns:
        List of JobInfo objects, sorted by time (newest first)

    The file structure is:
    {
        "/path/to/project": [
            {
                "job_id": "...",
                "output_url": "...",
                "time": 123456789,
                "notify_msg": "...",
                ...
            },
            ...
        ],
        ...
    }
    """
    recent_jobs_file = cwd / DIR_CERTORA_INTERNAL / FILE_RECENT_JOBS

    if not recent_jobs_file.exists():
        logger.log(
            f"No recent jobs file found: {recent_jobs_file}",
            "INFO",
            "CloudSync"
        )
        return []

    try:
        with open(recent_jobs_file, "r") as f:
            data = json.load(f)

        # Get jobs for this CWD
        cwd_str = str(cwd.resolve())
        jobs_data = data.get(cwd_str, [])

        # Convert to JobInfo objects
        jobs = []
        for job_data in jobs_data:
            try:
                job = JobInfo(
                    job_id=job_data["job_id"],
                    output_url=job_data["output_url"],
                    time=job_data["time"],
                    notify_msg=job_data.get("notify_msg"),
                )
                jobs.append(job)
            except KeyError as e:
                logger.log(
                    f"Malformed job entry in recent_jobs.json: {e}",
                    "WARNING",
                    "CloudSync"
                )
                continue

        # Sort by time, newest first
        jobs.sort(key=lambda j: j.time, reverse=True)

        logger.log(
            f"Parsed {len(jobs)} jobs from recent_jobs.json",
            "INFO",
            "CloudSync"
        )

        return jobs

    except Exception as e:
        logger.log(
            f"Error parsing recent jobs file: {e}",
            "ERROR",
            "CloudSync"
        )
        return []


def parse_remote_jobs(cwd: Path) -> List[JobInfo]:
    """
    Parse .certora_remote_jobs.json to extract job information.

    Args:
        cwd: Current working directory (project root)

    Returns:
        List of JobInfo objects, sorted by time (newest first)

    The file structure is a flat array:
    [
        {
            "job_id": "...",
            "output_url": "...",
            "time": 123456789,
            "notify_msg": "...",
            ...
        },
        ...
    ]
    """
    remote_jobs_file = cwd / DIR_CERTORA_INTERNAL / FILE_REMOTE_JOBS

    if not remote_jobs_file.exists():
        logger.log(
            f"No remote jobs file found: {remote_jobs_file}",
            "INFO",
            "CloudSync"
        )
        return []

    try:
        with open(remote_jobs_file, "r") as f:
            jobs_data = json.load(f)

        # Convert to JobInfo objects
        jobs = []
        for job_data in jobs_data:
            try:
                job = JobInfo(
                    job_id=job_data["job_id"],
                    output_url=job_data["output_url"],
                    time=job_data["time"],
                    notify_msg=job_data.get("notify_msg"),
                )
                jobs.append(job)
            except KeyError as e:
                logger.log(
                    f"Malformed job entry in remote_jobs.json: {e}",
                    "WARNING",
                    "CloudSync"
                )
                continue

        # Sort by time, newest first
        jobs.sort(key=lambda j: j.time, reverse=True)

        logger.log(
            f"Parsed {len(jobs)} jobs from remote_jobs.json",
            "INFO",
            "CloudSync"
        )

        return jobs

    except Exception as e:
        logger.log(
            f"Error parsing remote jobs file: {e}",
            "ERROR",
            "CloudSync"
        )
        return []


async def fetch_rule_statuses_from_job_async(
    job_id: str,
    output_url: str,
    snapshot: Optional['ScanSnapshot'] = None,
    cwd: Optional[Path] = None
) -> tuple[Dict[str, RuleStatus], Optional[str]]:
    """
    Async wrapper for fetching rule statuses and metadata from a verification job.

    This runs synchronous API calls in a thread pool to avoid blocking.
    For Rust jobs, uses fetch_rule_statuses_from_rust_job() which uses ROOT node
    status as authoritative (ignores sub-checks like "satisfy reached").

    Args:
        job_id: The job identifier
        output_url: The output URL for the job
        snapshot: Current scan snapshot (for conf matching)
        cwd: Project root directory (for conf matching)

    Returns:
        Tuple of (rule_statuses dict, conf_path or None)
    """
    loop = asyncio.get_event_loop()

    # Fetch metadata first to determine if this is a Rust job
    metadata_result = await loop.run_in_executor(
        None,
        fetch_job_metadata,
        job_id
    )

    # Determine if this is a Rust job (main_spec is null for Rust)
    is_rust_job = False
    if snapshot and not isinstance(metadata_result, Exception):
        metadata: Dict[str, Any] = metadata_result  # type: ignore[assignment]
        main_spec = metadata.get("main_spec", "")
        if not main_spec:
            has_rust_confs = any(c.conf_type == "Rust" for c in snapshot.confs)
            if has_rust_confs:
                is_rust_job = True

    # Use appropriate fetch function based on job type
    if is_rust_job:
        job_statuses_result = await loop.run_in_executor(
            None,
            fetch_rule_statuses_from_rust_job,
            job_id,
            output_url
        )
    else:
        job_statuses_result = await loop.run_in_executor(
            None,
            fetch_rule_statuses_from_job,
            job_id,
            output_url
        )

    # Handle errors
    if isinstance(job_statuses_result, Exception):
        raise job_statuses_result

    job_statuses: Dict[str, RuleStatus] = job_statuses_result  # type: ignore[assignment]

    # Process metadata to get conf_path
    conf_path_for_job = None
    if snapshot and cwd and not isinstance(metadata_result, Exception):
        try:
            metadata = metadata_result  # type: ignore[assignment]
            main_spec = metadata.get("main_spec", "")

            # Solidity/Move: use main_spec matching (existing behavior)
            if main_spec:
                conf_path_for_job = find_conf_by_spec(main_spec, snapshot, cwd)
                if conf_path_for_job:
                    logger.log(
                        f"Job {job_id}: matched spec '{main_spec}' to conf {Path(conf_path_for_job).name}",
                        "DEBUG",
                        "CloudSync"
                    )

            # Rust: use Rust-specific matching (main_spec is null for Rust)
            if not conf_path_for_job and not main_spec:
                # Check if this is a Rust project (any Rust confs in snapshot)
                has_rust_confs = any(c.conf_type == "Rust" for c in snapshot.confs)
                if has_rust_confs:
                    conf_path_for_job = find_conf_for_rust_job(metadata, snapshot, cwd, job_id)
                    if conf_path_for_job:
                        logger.log(
                            f"Job {job_id}: Rust matching found conf {Path(conf_path_for_job).name}",
                            "DEBUG",
                            "CloudSync"
                        )

            if not conf_path_for_job:
                logger.log(
                    f"Job {job_id}: could not match to any conf",
                    "DEBUG",
                    "CloudSync"
                )
        except Exception as e:
            # Ignore metadata errors, just won't have conf_path
            logger.log(
                f"Error processing metadata for job {job_id}: {e}",
                "WARNING",
                "CloudSync"
            )

    return job_statuses, conf_path_for_job


def fetch_rule_statuses_from_job(job_id: str, output_url: str) -> Dict[str, RuleStatus]:
    """
    Fetch rule statuses from a verification job using ProverOutputAPI.

    Args:
        job_id: The job identifier
        output_url: The output URL for the job

    Returns:
        Dictionary mapping rule name -> RuleStatus

    This uses ProverOutputAPI.get_all_checks() to fetch verification results.
    For parametric rules, we aggregate results from all methods.
    """
    logger.log(f"Fetching rule statuses for job {job_id}", "INFO", "CloudSync")
    try:
        # Create API instance with serialized auth (prevents concurrent OAuth)
        prover_api = _create_prover_api()

        # Fetch job status to determine if job is still running
        logger.log(f"Fetching job status for {job_id}", "DEBUG", "CloudSync")
        job_status = prover_api.get_job_status(job_id)
        logger.log(f"Job {job_id} status: {job_status}", "INFO", "CloudSync")

        # Fetch all checks for this job
        logger.log(f"Calling get_all_checks for job {job_id}", "INFO", "CloudSync")
        all_checks = prover_api.get_all_checks(job_id)
        logger.log(f"Retrieved {len(all_checks)} checks for job {job_id}", "INFO", "CloudSync")

        # Process checks into rule statuses
        rule_statuses = {}
        rule_methods: dict = {}  # Track methods for each rule
        rule_all_statuses: dict = {}  # Track ALL check statuses for each rule (for aggregation)

        for check in all_checks:
            rule_name = check.rule_name
            status_str = check.status.value if hasattr(check.status, "value") else str(check.status)

            # Special case: METHOD_INSTANTIATION with UNKNOWN status = sanity failure
            # This happens when a method can't be instantiated for an invariant
            node_type = str(check.node_type) if hasattr(check, 'node_type') else ""
            if "METHOD_INSTANTIATION" in node_type and status_str.upper() == "UNKNOWN":
                status_color = STATUS_VACUITY  # Treat as vacuity/sanity failure
                logger.log(
                    f"Treating METHOD_INSTANTIATION UNKNOWN as vacuity for {rule_name}: {check.assert_message}",
                    "DEBUG",
                    "CloudSync"
                )
            else:
                # Map prover status to dashboard color
                status_color = map_prover_status_to_color(status_str)

            # Collect ALL statuses for this rule (for proper aggregation)
            if rule_name not in rule_all_statuses:
                rule_all_statuses[rule_name] = []
            rule_all_statuses[rule_name].append(status_color)

            # Check if this is a method-specific result
            # For parametric rules, assert_message contains method name
            assert_message = check.assert_message or ""
            method_name = None

            # Try to extract method name from assert message
            # This is a heuristic - adjust based on actual format.
            # We need to filter out "ASSERT_SUBRULE_AUTO_GEN" and "VIOLATED_ASSERT"
            if "method" in assert_message.lower() or "(" in assert_message and check.node_type not in ["ASSERT_SUBRULE_AUTO_GEN","VIOLATED_ASSERT"]:
                # Extract method name (this may need refinement)
                method_name = assert_message

            # Include INVARIANT_SUBCHECK as those were already filtered for the 'steps' by ProverOutputAPI
            if check.node_type == "INVARIANT_SUBCHECK":
                method_name = assert_message

            # Track rule and its methods
            if rule_name not in rule_methods:
                rule_methods[rule_name] = {}

            if method_name:
                rule_methods[rule_name][method_name] = status_color

        # Create RuleStatus objects
        for rule_name in rule_all_statuses:
            method_statuses = rule_methods.get(rule_name, {})
            all_statuses_for_rule = rule_all_statuses[rule_name]

            # If rule has methods, compute aggregate status from methods
            if method_statuses:
                # Parametric rule - use method statuses for aggregation
                overall_status = aggregate_method_statuses(method_statuses, job_status)

                rule_status = RuleStatus(
                    rule_name=rule_name,
                    overall_status=overall_status,
                    method_statuses=method_statuses,
                    job_id=job_id,
                    timestamp=0,  # Will be set from job time
                    run_url=output_url,
                    job_status=job_status,
                )
            else:
                # Non-parametric rule - aggregate ALL check statuses
                # This ensures violated status is not overwritten by later verified checks
                overall_status = compute_rule_color(all_statuses_for_rule, job_status)

                rule_status = RuleStatus(
                    rule_name=rule_name,
                    overall_status=overall_status,
                    method_statuses={},
                    job_id=job_id,
                    timestamp=0,
                    run_url=output_url,
                    job_status=job_status,
                )

            rule_statuses[rule_name] = rule_status

        logger.log(
            f"Fetched {len(rule_statuses)} rule statuses from job {job_id}",
            "INFO",
            "CloudSync"
        )

        return rule_statuses

    except Exception as e:
        logger.log(
            f"Error fetching rule statuses from job {job_id}, output_url {output_url}: {e}",
            "ERROR",
            "CloudSync"
        )
        return {}


def fetch_rule_statuses_from_rust_job(job_id: str, output_url: str) -> Dict[str, RuleStatus]:
    """
    Fetch rule statuses from a Rust/Solana verification job.

    RUST-ONLY: Uses ROOT node status as authoritative for each rule.
    For Rust, sub-checks like "satisfy reached" should be ignored when
    the ROOT node shows the actual rule result.

    Args:
        job_id: The job identifier
        output_url: The output URL for the job

    Returns:
        Dictionary mapping rule name -> RuleStatus
    """
    logger.log(f"Fetching Rust rule statuses for job {job_id}", "INFO", "CloudSync")
    try:
        prover_api = _create_prover_api()
        job_status = prover_api.get_job_status(job_id)
        all_checks = prover_api.get_all_checks(job_id)

        rule_statuses = {}
        rule_root_status: Dict[str, str] = {}  # rule_name -> status from ROOT node

        for check in all_checks:
            rule_name = check.rule_name
            status_str = check.status.value if hasattr(check.status, "value") else str(check.status)
            node_type = str(check.node_type) if hasattr(check, 'node_type') else ""

            status_color = map_prover_status_to_color(status_str)

            # ROOT node is the authoritative status for Rust rules
            if "ROOT" in node_type:
                rule_root_status[rule_name] = status_color

        # Create RuleStatus objects using ROOT status
        for rule_name, overall_status in rule_root_status.items():
            rule_status = RuleStatus(
                rule_name=rule_name,
                overall_status=overall_status,
                method_statuses={},
                job_id=job_id,
                timestamp=0,
                run_url=output_url,
                job_status=job_status,
            )
            rule_statuses[rule_name] = rule_status

        logger.log(f"Fetched {len(rule_statuses)} Rust rule statuses from job {job_id}", "INFO", "CloudSync")
        return rule_statuses

    except Exception as e:
        logger.log(f"Error fetching Rust rule statuses from job {job_id}: {e}", "ERROR", "CloudSync")
        return {}


def get_last_cloud_sync_timestamp(dashboard_dir: Path, mode: str = "local") -> int:
    """
    Get the timestamp of the last cloud sync.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        mode: "local" for local runs or "remote" for all runs

    Returns:
        Unix timestamp of last sync, or 0 if no sync has occurred
    """
    filename = FILE_LAST_CLOUD_SYNC_REMOTE if mode == MODE_REMOTE else FILE_LAST_CLOUD_SYNC
    last_sync_file = dashboard_dir / filename

    if not last_sync_file.exists():
        return 0

    try:
        with open(last_sync_file, "r") as f:
            return int(f.read().strip())
    except Exception as e:
        logger.log(
            f"Error reading last cloud sync timestamp ({mode}): {e}",
            "WARNING",
            "CloudSync"
        )
        return 0


def save_last_cloud_sync_timestamp(dashboard_dir: Path, timestamp: int, mode: str = "local"):
    """
    Save the timestamp of the last cloud sync.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        timestamp: Unix timestamp to save
        mode: "local" for local runs or "remote" for all runs
    """
    dashboard_dir.mkdir(parents=True, exist_ok=True)
    filename = FILE_LAST_CLOUD_SYNC_REMOTE if mode == MODE_REMOTE else FILE_LAST_CLOUD_SYNC
    last_sync_file = dashboard_dir / filename

    try:
        with open(last_sync_file, "w") as f:
            f.write(str(timestamp))
    except Exception as e:
        logger.log(
            f"Error saving last cloud sync timestamp ({mode}): {e}",
            "ERROR",
            "CloudSync"
        )


async def process_jobs_batch_async(
    jobs: List[JobInfo],
    all_statuses: Dict[str, List[RuleStatus]],
    max_concurrent: int = 10,
    mode: str = "local",
    snapshot: Optional[ScanSnapshot] = None,
    cwd: Optional[Path] = None
) -> Dict[str, List[RuleStatus]]:
    """
    Process multiple jobs concurrently using async/await.

    Args:
        jobs: List of jobs to process
        all_statuses: Existing statuses dictionary (rule_name -> List[RuleStatus])
        max_concurrent: Maximum number of concurrent job fetches (default: 10)
        mode: "local" or "remote" - sets run_provenance on statuses
        snapshot: Current scan snapshot (for conf matching)
        cwd: Project root directory (for conf matching)

    Returns:
        Updated statuses dictionary with new jobs appended to each rule's list
    """
    # Create tasks for all jobs with semaphore to limit concurrency
    semaphore = asyncio.Semaphore(max_concurrent)

    async def fetch_with_semaphore(job: JobInfo):
        async with semaphore:
            logger.log(f"Fetching statuses for job {job.job_id}", "DEBUG", "CloudSync")
            return await fetch_rule_statuses_from_job_async(job.job_id, job.output_url, snapshot, cwd)

    # Create all tasks
    tasks = [fetch_with_semaphore(job) for job in jobs]

    # Wait for all tasks to complete
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Determine run provenance based on mode
    run_provenance = RUN_PROVENANCE_REMOTE if mode == MODE_REMOTE else RUN_PROVENANCE_LOCAL

    # Process results
    for job, result in zip(jobs, results):
        if isinstance(result, Exception):
            logger.log(
                f"Error fetching job {job.job_id}: {result}",
                "ERROR",
                "CloudSync"
            )
            continue

        # Unpack the tuple (job_statuses, conf_path) - result should be a tuple
        if not isinstance(result, tuple) or len(result) != 2:
            logger.log(
                f"Unexpected result format for job {job.job_id}: {type(result)}",
                "ERROR",
                "CloudSync"
            )
            continue
        job_statuses_for_job, conf_path_for_job = result
        logger.log(
            f"Fetched {len(job_statuses_for_job)} rule statuses from job {job.job_id}",
            "INFO",
            "CloudSync"
        )

        # Update timestamp, run_provenance, conf_path, and add to all_statuses history
        for rule_name, status in job_statuses_for_job.items():
            status.timestamp = job.time
            status.run_provenance = run_provenance
            status.conf_path = conf_path_for_job

            # Initialize list for this rule if not present
            if rule_name not in all_statuses:
                all_statuses[rule_name] = []

            # Check if this job already exists in the history
            existing_job_ids = {s.job_id for s in all_statuses[rule_name]}

            if status.job_id not in existing_job_ids:
                # Add new job to the list
                all_statuses[rule_name].append(status)
                logger.log(f"Added job {job.job_id} for rule {rule_name}", "DEBUG", "CloudSync")
            else:
                # Update existing job (in case we're re-processing)
                for i, existing_status in enumerate(all_statuses[rule_name]):
                    if existing_status.job_id == status.job_id:
                        all_statuses[rule_name][i] = status
                        logger.log(f"Updated job {job.job_id} for rule {rule_name}", "DEBUG", "CloudSync")
                        break

            # Sort by timestamp (newest first)
            all_statuses[rule_name].sort(key=lambda s: s.timestamp, reverse=True)

    return all_statuses


def update_statuses_from_cloud(
    snapshot: ScanSnapshot,
    dashboard_dir: Path,
    cwd: Path,
    validate_specs: bool = True,
    mode: str = "local",
    save_every: int = 50,
    max_concurrent: int = 50
) -> Dict[str, RuleStatus]:
    """
    Update rule statuses from cloud verification jobs.

    Processes jobs from newest to oldest, updating statuses until we reach
    jobs older than the last sync. Optionally validates that spec files match.
    Saves incrementally every N jobs to avoid losing progress on timeout.

    Args:
        snapshot: Current scan snapshot
        dashboard_dir: Path to .certora_internal/local_dashboard
        cwd: Current working directory (project root)
        validate_specs: Whether to validate spec files (Step 5)
        mode: "local" for local runs or "remote" for all runs
        save_every: Save rule statuses every N jobs (default: 50)
        max_concurrent: Maximum number of concurrent job fetches (default: 10)

    Returns:
        Dictionary of rule_name -> RuleStatus (latest status) for backwards compatibility
        Also saves full history to all_rule_statuses.json
    """
    logger.log(f"Starting cloud status update ({mode} mode)", "INFO", "CloudSync")

    # Parse recent jobs - use appropriate jobs file based on mode
    if mode == MODE_REMOTE:
        logger.log(f"Parsing remote jobs from {cwd}", "INFO", "CloudSync")
        jobs = parse_remote_jobs(cwd)
    else:
        logger.log(f"Parsing recent jobs from {cwd}", "INFO", "CloudSync")
        jobs = parse_recent_jobs(cwd)

    logger.log(f"Found {len(jobs)} jobs ({mode} mode)", "INFO", "CloudSync")

    if not jobs:
        logger.log(f"No jobs found ({mode} mode)", "INFO", "CloudSync")
        clear_progress(dashboard_dir, mode)
        return {}

    # Get last sync timestamp for this mode
    last_sync_time = get_last_cloud_sync_timestamp(dashboard_dir, mode)
    logger.log(f"Last cloud sync timestamp ({mode}): {last_sync_time}", "INFO", "CloudSync")

    # Load existing ALL statuses (full history) to build upon them
    all_statuses_history = load_all_rule_statuses(dashboard_dir)
    total_existing_jobs = sum(len(statuses) for statuses in all_statuses_history.values())
    logger.log(f"Loaded history for {len(all_statuses_history)} rules ({total_existing_jobs} total jobs)", "INFO", "CloudSync")

    # Pre-warm authentication to trigger OAuth flow if needed (before threads).
    # This prevents concurrent threads from racing to start OAuth callback servers.
    logger.log("Pre-warming authentication...", "INFO", "CloudSync")
    try:
        warmup_api = _create_prover_api()
        # Make a lightweight call to validate auth is working
        if jobs:
            warmup_api.get_job_status(jobs[0].job_id)
        logger.log("Authentication validated successfully", "INFO", "CloudSync")
    except Exception as e:
        logger.log(f"Auth pre-warm failed: {e}", "WARNING", "CloudSync")
        # Continue anyway - individual workers will retry with serialized lock

    processed_jobs = 0
    newest_processed_time = last_sync_time

    # Count how many jobs we'll actually process (for progress tracking)
    # Include jobs that started within 2 hours before last sync (to catch long-running jobs)
    sync_window_start = last_sync_time - TWO_HOURS_SECONDS
    jobs_to_process = sum(1 for job in jobs if job.time > sync_window_start)

    # Initialize progress tracking
    progress = SyncProgress(
        total_jobs=jobs_to_process,
        processed_jobs=0,
        current_job_id=None,
        status=PROGRESS_STATUS_RUNNING,
        start_time=time.time()
    )
    save_progress(dashboard_dir, progress, mode)

    # Filter jobs to include new ones and recent ones (within 2 hours before last sync)
    new_jobs = [job for job in jobs if job.time > sync_window_start]

    logger.log(f"Processing {len(new_jobs)} new jobs (out of {len(jobs)} total) with max {max_concurrent} concurrent fetches", "INFO", "CloudSync")

    if not new_jobs:
        logger.log(f"No new jobs to process ({mode} mode)", "INFO", "CloudSync")
        clear_progress(dashboard_dir, mode)
        # Return latest status from history for backwards compatibility
        return {rule_name: statuses[0] for rule_name, statuses in all_statuses_history.items() if statuses}

    # Track newest processed job time
    if new_jobs:
        newest_processed_time = max(job.time for job in new_jobs)

    # Process jobs in batches to enable incremental saves
    batch_size = save_every
    total_batches = (len(new_jobs) + batch_size - 1) // batch_size

    for batch_idx in range(0, len(new_jobs), batch_size):
        batch = new_jobs[batch_idx:batch_idx + batch_size]
        batch_num = (batch_idx // batch_size) + 1

        logger.log(
            f"Processing batch {batch_num}/{total_batches} ({len(batch)} jobs)",
            "INFO",
            "CloudSync"
        )

        # Update progress for this batch
        progress.current_job_id = batch[0].job_id if batch else None
        save_progress(dashboard_dir, progress, mode)

        # Process this batch concurrently using async
        try:
            all_statuses_history = asyncio.run(
                process_jobs_batch_async(batch, all_statuses_history, max_concurrent, mode, snapshot, cwd)
            )
        except Exception as e:
            logger.log(
                f"Error processing batch {batch_num}: {e}",
                "ERROR",
                "CloudSync"
            )
            # Continue with next batch even if this one failed
            continue

        processed_jobs += len(batch)

        # Update progress after batch
        progress.processed_jobs = processed_jobs
        save_progress(dashboard_dir, progress, mode)

        # Incremental save after each batch - save FULL history
        logger.log(f"Incremental save after batch {batch_num}/{total_batches}", "INFO", "CloudSync")
        save_all_rule_statuses(all_statuses_history, dashboard_dir)

        # Save sync timestamp for jobs processed so far
        batch_newest_time = max(job.time for job in batch)
        save_last_cloud_sync_timestamp(dashboard_dir, batch_newest_time, mode)
        total_jobs_in_history = sum(len(statuses) for statuses in all_statuses_history.values())
        logger.log(
            f"Saved history for {len(all_statuses_history)} rules ({total_jobs_in_history} total jobs) and updated sync timestamp to {batch_newest_time}",
            "INFO",
            "CloudSync"
        )

    total_jobs_final = sum(len(statuses) for statuses in all_statuses_history.values())
    logger.log(f"Processed {processed_jobs} jobs, collected history for {len(all_statuses_history)} unique rules ({total_jobs_final} total jobs)", "INFO", "CloudSync")

    # Filter history to only include rules that exist in the current snapshot
    # This ensures we don't show statuses for rules that were deleted or from old specs
    snapshot_rules = set()
    has_move_confs = False
    has_rust_confs = False

    for conf in snapshot.confs:
        # Check if any conf is Move or Rust type
        if conf.conf_type == "Move":
            has_move_confs = True
        elif conf.conf_type == "Rust":
            has_rust_confs = True

        for rule_name in conf.rules:
            # conf.rules is a list of rule names (strings), not RuleInfo objects
            snapshot_rules.add(rule_name)

    logger.log(f"Current snapshot has {len(snapshot_rules)} unique rules", "INFO", "CloudSync")

    # Apply appropriate filtering based on conf types
    if has_move_confs:
        filtered_statuses_history = filter_move_statuses(all_statuses_history, snapshot_rules)
    elif has_rust_confs:
        filtered_statuses_history = filter_rust_statuses(all_statuses_history, snapshot_rules)
    else:
        # EVM project: exact matching
        filtered_statuses_history = {
            rule_name: status_list
            for rule_name, status_list in all_statuses_history.items()
            if rule_name in snapshot_rules
        }

    if len(filtered_statuses_history) != len(all_statuses_history):
        logger.log(
            f"Filtered cloud statuses: {len(all_statuses_history)} → {len(filtered_statuses_history)} rules (removed {len(all_statuses_history) - len(filtered_statuses_history)} rules not in current scan)",
            "INFO",
            "CloudSync"
        )

    all_statuses_history = filtered_statuses_history

    # Extract latest status for each rule (for backwards compatibility and validation)
    all_statuses = {
        rule_name: statuses[0]  # Already sorted by timestamp (newest first)
        for rule_name, statuses in all_statuses_history.items()
        if statuses
    }

    # Validate specs if requested (only on latest statuses)
    if validate_specs and all_statuses:
        logger.log("Starting spec validation", "INFO", "CloudSync")
        all_statuses = validate_all_statuses(all_statuses, snapshot)
        logger.log("Spec validation complete", "INFO", "CloudSync")

        # Update the latest status in history with validation results
        for rule_name, validated_status in all_statuses.items():
            if rule_name in all_statuses_history and all_statuses_history[rule_name]:
                all_statuses_history[rule_name][0] = validated_status

    # Generate local ASTs if not already done (for spec diff comparison)
    timestamp_dir = dashboard_dir / str(snapshot.timestamp)
    asts_mapping = load_asts_mapping(timestamp_dir)

    if not asts_mapping and all_statuses:
        logger.log("Generating local ASTs for spec diff comparison", "INFO", "CloudSync")
        try:
            generate_local_asts_for_snapshot(snapshot, cwd, snapshot.timestamp)
            logger.log("Local ASTs generated successfully", "SUCCESS", "CloudSync")
        except Exception as e:
            logger.log(f"Error generating local ASTs: {e}", "ERROR", "CloudSync")

    # Compute spec diffs between local and remote ASTs
    if all_statuses:
        logger.log("Computing spec diffs for updated rules", "INFO", "CloudSync")

        # Update progress to diff computation phase
        # Defensive: Check progress exists before updating
        if progress:
            progress.phase = "computing_diffs"
            progress.total_rules = len(all_statuses)
            progress.processed_rules = 0
            progress.current_rule = None
            save_progress(dashboard_dir, progress, mode)

        # Define progress callback for diff computation
        def diff_progress_callback(processed_count: int, rule_name: str):
            # Defensive: Check progress exists before updating
            if progress:
                progress.processed_rules = processed_count
                progress.current_rule = rule_name
                save_progress(dashboard_dir, progress, mode)

        # Compute spec, conf, and source diffs in parallel for all jobs
        try:
            logger.log("Computing spec, conf, and source diffs in parallel...", "INFO", "CloudSync")

            # Load AST mappings once for all spec diffs (already loaded above at line 864)
            # Reuse the asts_mapping from the outer scope
            if not asts_mapping:
                asts_mapping = load_asts_mapping(timestamp_dir)
            if not asts_mapping:
                logger.log("No AST mappings found - skipping spec diff computation", "WARNING", "CloudSync")

            # Group rules by job_id for spec diffs and collect job metadata
            jobs_to_rules = defaultdict(list)  # job_id -> [rule_names]
            unique_jobs = {}  # job_id -> (job_url, conf_path, conf_type)

            for rule_name, status in all_statuses.items():
                if status.job_id and status.run_url:
                    # Add rule to spec diff group
                    jobs_to_rules[status.job_id].append(rule_name)

                    # Find conf for conf/source diffs
                    if status.job_id not in unique_jobs:
                        conf_path = None
                        conf_type = "EVM"  # Default
                        for conf_info in snapshot.confs:
                            if rule_name in conf_info.rules:
                                conf_path = conf_info.conf_path
                                conf_type = conf_info.conf_type
                                break

                        if conf_path:
                            unique_jobs[status.job_id] = (status.run_url, conf_path, conf_type)

            logger.log(f"Computing diffs for {len(unique_jobs)} unique jobs in parallel...", "INFO", "CloudSync")

            # Update progress with total diff jobs
            try:
                # Load a fresh copy of progress to update diff tracking fields
                # Use a different variable name to avoid overwriting the main progress object
                loaded_progress = load_progress(dashboard_dir, mode)
                if loaded_progress:
                    loaded_progress.total_diff_jobs = len(unique_jobs)
                    loaded_progress.completed_spec_diffs = 0
                    loaded_progress.completed_conf_diffs = 0
                    loaded_progress.completed_source_diffs = 0
                    save_progress(dashboard_dir, loaded_progress, mode)
            except Exception:
                pass  # Non-critical

            # Use ThreadPoolExecutor for parallel diff computation
            # We'll use 3 workers per job (spec, conf, source) but limit total workers
            max_workers = min(len(unique_jobs) * 3, 12)  # Cap at 12 total workers

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = []
                all_spec_diffs = {}  # Collect spec diff results

                # Submit spec diff tasks (only if ASTs available)
                if asts_mapping:
                    for job_id, rules_in_job in jobs_to_rules.items():
                        if job_id in unique_jobs:  # Only if conf path was found
                            job_url = unique_jobs[job_id][0]
                            future = executor.submit(
                                compute_spec_diffs_for_job,
                                job_id,
                                job_url,
                                rules_in_job,
                                snapshot,
                                asts_mapping,
                                timestamp_dir,
                                cwd,
                                None  # No progress callback for parallel execution
                            )
                            futures.append(('spec', job_id, future))

                # Submit conf diff tasks
                for job_id, (job_url, conf_path, conf_type) in unique_jobs.items():
                    future = executor.submit(
                        compute_conf_diff_for_job,
                        job_id=job_id,
                        job_url=job_url,
                        local_conf_path=conf_path,
                        timestamp_dir=timestamp_dir,
                        dashboard_path=cwd
                    )
                    futures.append(('conf', job_id, future))

                # Submit source diff tasks
                for job_id, (job_url, conf_path, conf_type) in unique_jobs.items():
                    future = executor.submit(
                        compute_source_diff_for_job,
                        job_id=job_id,
                        job_url=job_url,
                        conf_type=conf_type,
                        local_project_root=cwd,
                        timestamp_dir=timestamp_dir,
                        dashboard_path=cwd
                    )
                    futures.append(('source', job_id, future))

                # Wait for completion and update progress
                spec_completed = 0
                conf_completed = 0
                source_completed = 0

                for diff_type, job_id, future in futures:
                    try:
                        result = future.result()  # Wait for completion and raise any exceptions

                        # Collect spec diff results
                        if diff_type == 'spec' and result:
                            all_spec_diffs.update(result)
                            spec_completed += 1
                        elif diff_type == 'conf':
                            conf_completed += 1
                        elif diff_type == 'source':
                            source_completed += 1

                        # Update progress file
                        try:
                            # Load a fresh copy of progress to update diff completion counts
                            # Use a different variable name to avoid overwriting the main progress object
                            loaded_progress = load_progress(dashboard_dir, mode)
                            if loaded_progress:
                                loaded_progress.completed_spec_diffs = spec_completed
                                loaded_progress.completed_conf_diffs = conf_completed
                                loaded_progress.completed_source_diffs = source_completed
                                save_progress(dashboard_dir, loaded_progress, mode)
                        except Exception:
                            pass  # Non-critical

                    except Exception as e:
                        logger.log(f"Error computing {diff_type} diff for job {job_id}: {e}", "WARNING", "CloudSync")

            # Update statuses with spec diff results
            for rule_name, status in all_statuses.items():
                if rule_name in all_spec_diffs:
                    diff_info = all_spec_diffs[rule_name]
                    status.spec_diff_equivalent = diff_info.get("equivalent")
                    status.has_ambiguous_conf = diff_info.get("has_ambiguous_conf", False)
                    status.matched_main_contract = diff_info.get("matched_main_contract", "")
                    # Only update conf_path if status doesn't already have one
                    # (preserves Rust matching from find_conf_for_rust_job)
                    if not status.conf_path and diff_info.get("conf_path"):
                        status.conf_path = diff_info.get("conf_path")

            # Update the latest status in history with diff results
            for rule_name, status in all_statuses.items():
                if rule_name in all_statuses_history and all_statuses_history[rule_name]:
                    all_statuses_history[rule_name][0] = status

            logger.log(f"All diffs computed: {spec_completed} spec diffs, {conf_completed} conf diffs, {source_completed} source diffs", "SUCCESS", "CloudSync")
        except Exception as e:
            logger.log(f"Error computing diffs: {e}", "ERROR", "CloudSync")

    # Final save of FULL history and update sync timestamp
    if processed_jobs > 0:
        save_all_rule_statuses(all_statuses_history, dashboard_dir)
        save_last_cloud_sync_timestamp(dashboard_dir, newest_processed_time, mode)
        total_final_jobs = sum(len(statuses) for statuses in all_statuses_history.values())
        logger.log(f"Final save: {len(all_statuses_history)} rules ({total_final_jobs} total jobs in history), sync timestamp updated to {newest_processed_time} ({mode})", "INFO", "CloudSync")

    # Mark progress as completed
    # Defensive: Ensure progress object exists before accessing it
    # This should always be true since we create it at line 866, but we guard against
    # any unexpected code paths or future modifications that might set it to None
    if progress:
        progress.status = PROGRESS_STATUS_COMPLETED
        progress.processed_jobs = processed_jobs
        save_progress(dashboard_dir, progress, mode)
    else:
        logger.log("Warning: progress object is None at completion, cannot update progress status", "WARNING", "CloudSync")

    logger.log(
        f"Cloud sync complete: {len(all_statuses)} rules updated",
        "INFO",
        "CloudSync"
    )

    return all_statuses
