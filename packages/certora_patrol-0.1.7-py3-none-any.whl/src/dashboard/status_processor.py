"""
Status processor for computing rule statuses and colors.

Handles aggregation of verification results and color mapping
according to the dashboard color scheme.
"""

from typing import Dict, List, Optional

from prover_output_utility.models import JobStatus # type: ignore[import-untyped]

from src.dashboard.constants import (
    STATUS_MIXED_ERROR,
    STATUS_PENDING,
    STATUS_RUNNING,
    STATUS_TIMEOUT,
    STATUS_UNKNOWN,
    STATUS_VACUITY,
    STATUS_VERIFIED,
    STATUS_VIOLATED,
)
from src.dashboard.logger import dashboard_logger as logger


def compute_rule_color(statuses: List[str], job_status: Optional[JobStatus] = None) -> str:
    """
    Compute the overall color for a rule based on subrule statuses.

    Color mapping:
    - Running: At least one rule is still running AND job status is RUNNING
    - Green (verified): All subrules verified
    - Yellow (timeout): Mix of verified + timeout
    - Red (violated): Violations present
    - Brown (vacuity): Sanity failures only
    - Dark red (mixed-error): Both violations AND vacuity
    - Grey (unknown): Unknown or error states

    Args:
        statuses: List of status strings from verification checks
        job_status: Optional JobStatus enum from ProverOutputUtility

    Returns:
        Color name string (verified, timeout, violated, vacuity, mixed-error, unknown, running, pending)
    """
    if not statuses:
        return STATUS_PENDING

    # Normalize statuses to lowercase for comparison
    statuses = [s.lower() if s else "" for s in statuses]

    # Count different status types
    has_verified = any(s in ["verified", "success"] for s in statuses)
    has_timeout = any("timeout" in s for s in statuses)
    has_violation = any(s in ["violated", "violation"] for s in statuses)
    has_vacuity = any(s in ["sanity", "sanity_fail", "sanity_failed"] for s in statuses)
    has_running = any(s == "running" for s in statuses)
    has_unknown = any(s in ["unknown", "error"] for s in statuses)

    # Running: at least one rule is still running AND job status is RUNNING
    # If job is not running or has failed/errored, treat running rules as unknown
    if has_running:
        if job_status:
            # Only show RUNNING if job is actively running
            if job_status == JobStatus.RUNNING:
                return STATUS_RUNNING
            # If job failed/errored/halted/canceled, treat running rules as unknown
            elif job_status in [JobStatus.FAILED, JobStatus.UNKNOWN, JobStatus.CANCELED, JobStatus.HALTED, JobStatus.SERVICE_UNAVAILABLE, JobStatus.UPLOAD_FAILED]:
                has_unknown = True
            else:
                # Job in other state (succeeded, queued, etc.) but rules show running - treat as unknown
                has_unknown = True
        else:
            # No job status available, treat running rules as unknown
            has_unknown = True

    # Dark red: both violations AND vacuity
    if has_violation and has_vacuity:
        return STATUS_MIXED_ERROR

    # Red: violations only
    if has_violation:
        return STATUS_VIOLATED

    # Brown: sanity failures only
    if has_vacuity:
        return STATUS_VACUITY

    # Yellow: mix of verified and timeout, OR timeout only
    if has_timeout:
        return STATUS_TIMEOUT

    # Green: all verified (and nothing else)
    # Only return verified if ALL statuses are verified/success
    if has_verified and not has_timeout and not has_violation and not has_vacuity and not has_unknown:
        return STATUS_VERIFIED

    # Grey: unknown or error states
    if has_unknown:
        return STATUS_UNKNOWN

    # Grey: other or unknown
    return STATUS_UNKNOWN


def aggregate_method_statuses(method_statuses: Dict[str, str], job_status: Optional[JobStatus] = None) -> str:
    """
    Aggregate method-level statuses for a parametric rule.

    Uses worst-status-wins logic: if any method has an error,
    the overall status reflects that error.

    Design choice: We filter out STATUS_NOT_RUN before aggregating. This is important
    for the "latest per method" view where methods can come from different jobs.
    A method showing "not_run" simply means it wasn't tested in a particular job,
    but we don't want that to affect the overall status computation.

    Edge case: If ALL methods are "not_run" (shouldn't normally happen), we return
    STATUS_NOT_RUN for the overall status.

    Args:
        method_statuses: Dictionary of method name -> status
        job_status: Optional JobStatus enum from ProverOutputUtility

    Returns:
        Aggregated status color
    """
    if not method_statuses:
        return STATUS_PENDING

    # Filter out "not_run" statuses before aggregating
    # These represent methods that exist in history but weren't tested in the selected job
    from src.dashboard.constants import STATUS_NOT_RUN
    active_statuses = [status for status in method_statuses.values() if status != STATUS_NOT_RUN]

    # Edge case: All methods are "not_run"
    if not active_statuses:
        return STATUS_NOT_RUN

    return compute_rule_color(active_statuses, job_status)


def map_prover_status_to_color(prover_status: str) -> str:
    """
    Map a ProverOutputAPI status string to a dashboard color.

    Args:
        prover_status: Status string from ProverOutputAPI

    Returns:
        Color name for the dashboard
    """
    if not prover_status:
        return STATUS_UNKNOWN

    status_lower = prover_status.lower()

    # Map common statuses
    if status_lower in ["verified", "success"]:
        return STATUS_VERIFIED
    elif "timeout" in status_lower:
        return STATUS_TIMEOUT
    elif status_lower in ["violated", "violation"]:
        return STATUS_VIOLATED
    elif status_lower in ["sanity", "sanity_fail", "sanity_failed"]:
        return STATUS_VACUITY
    elif status_lower == "running":
        return STATUS_RUNNING
    elif status_lower in ["unknown", "error"]:
        return STATUS_UNKNOWN  # Treat unknown and error as unknown, not violated
    else:
        logger.log(
            f"Unknown prover status encountered: {prover_status}",
            "WARNING",
            "StatusProcessor"
        )
        return STATUS_UNKNOWN


def format_status_for_display(status: str) -> str:
    """
    Format a status string for display in the UI.

    Args:
        status: Status color name

    Returns:
        Human-readable status string
    """
    display_map = {
        STATUS_VERIFIED: "Verified",
        STATUS_TIMEOUT: "Timeout",
        STATUS_VIOLATED: "Violated",
        STATUS_VACUITY: "Vacuity",
        STATUS_MIXED_ERROR: "Error",
        STATUS_UNKNOWN: "Unknown",
        STATUS_PENDING: "Pending",
        STATUS_RUNNING: "Running",
    }

    return display_map.get(status, status.capitalize())
