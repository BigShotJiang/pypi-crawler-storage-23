"""
Conf diff management module for comparing local and remote configuration files.

Handles comparison of conf files between local confs and cloud run confs,
tracking whether verification results were run with the same configuration.
"""

import re
import threading
import time
from pathlib import Path
from typing import Dict, Optional, Any

from src.dashboard.constants import DIR_CONF_DIFFS, DIR_EXTRACTED_TARS
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import ScanSnapshot
from src.dashboard.storage import (
    load_conf_diff_for_job,
    save_conf_diff_for_job,
    update_conf_diff_index,
)
from src.dashboard.utils.conf_diff import compare_confs

# Global lock dictionary for preventing concurrent computation of the same job
_job_locks = {}
_job_locks_lock = threading.Lock()


def compute_conf_diff_for_job(
    job_id: str,
    job_url: str,
    local_conf_path: Path,
    timestamp_dir: Path,
    dashboard_path: Path
) -> Dict[str, Any]:
    """
    Compute conf diff for a specific job.

    Args:
        job_id: The job ID (e.g., "60724_f7260fc26e764760a9534caa32691d94")
        job_url: The URL of the cloud run
        local_conf_path: Path to the local conf file
        timestamp_dir: Path to the timestamped snapshot directory
        dashboard_path: Path to the project root

    Returns:
        Dict with diff result:
            - equivalent: bool or None (True/False if compared, None if couldn't compare)
            - reason: str explaining why comparison failed (if equivalent is None)
            - diff_data: full diff JSON (if equivalent is False)

    Side Effects:
        - Saves to conf_diffs/{job_id}.json
        - Updates conf_diffs/index.json

    Thread Safety:
        Uses per-job locks to prevent concurrent computation of the same job.
        If another thread is already computing this job, waits for it to complete.
    """
    certora_internal = dashboard_path / ".certora_internal"

    # Extract job_id from URL to ensure consistency with tarball extraction
    # The full job ID is userId_jobHash (e.g., "1000000000_abc123...")
    match = re.search(r'/output/(\d+)/([a-f0-9]+)', job_url)
    if match:
        job_number = match.group(1)
        job_hash = match.group(2)
        full_job_id = f"{job_number}_{job_hash}"
    else:
        # Fallback to provided job_id if URL doesn't match expected format
        full_job_id = job_id

    # Get or create a lock for this specific job
    with _job_locks_lock:
        if full_job_id not in _job_locks:
            _job_locks[full_job_id] = threading.Lock()
        job_lock = _job_locks[full_job_id]

    # Acquire the job-specific lock (will wait if another thread is computing)
    with job_lock:
        # Check if already computed while we were waiting
        existing_diff = load_conf_diff_for_job(timestamp_dir, full_job_id)
        if existing_diff is not None:
            logger.log(
                f"Conf diff for job {job_id} already computed by another thread",
                "INFO",
                "ConfDiffManager"
            )
            return existing_diff

        logger.log(
            f"Computing conf diff for job {job_id}",
            "INFO",
            "ConfDiffManager"
        )

        return _compute_conf_diff_for_job_impl(
            job_id, job_url, full_job_id, local_conf_path,
            timestamp_dir, dashboard_path, certora_internal
        )


def _compute_conf_diff_for_job_impl(
    job_id: str,
    job_url: str,
    full_job_id: str,
    local_conf_path: Path,
    timestamp_dir: Path,
    dashboard_path: Path,
    certora_internal: Path
) -> Dict[str, Any]:
    """
    Internal implementation of conf diff computation (called with lock held).
    """

    # Get remote run.conf path
    remote_conf_path = (
        certora_internal / DIR_EXTRACTED_TARS / full_job_id / "inputs" / ".certora_sources" / "run.conf"
    )

    if not remote_conf_path.exists():
        logger.log(
            f"Remote run.conf not found for job {job_id}: {remote_conf_path}",
            "WARNING",
            "ConfDiffManager"
        )
        result = {
            "equivalent": None,
            "reason": "Remote run.conf not found (tarball not extracted)"
        }
    elif not local_conf_path.exists():
        logger.log(
            f"Local conf file not found: {local_conf_path}",
            "WARNING",
            "ConfDiffManager"
        )
        result = {
            "equivalent": None,
            "reason": f"Local conf file not found: {local_conf_path.name}"
        }
    else:
        # Compare the two confs
        try:
            equivalent, diff_data = compare_confs(
                str(local_conf_path),
                str(remote_conf_path)
            )

            if equivalent:
                logger.log(
                    f"Confs match for job {job_id}",
                    "SUCCESS",
                    "ConfDiffManager"
                )
                conf_result: Dict[str, Any] = {
                    "equivalent": True
                }
            else:
                logger.log(
                    f"Confs differ for job {job_id}",
                    "WARNING",
                    "ConfDiffManager"
                )
                conf_result = {
                    "equivalent": False,
                    "diff_data": diff_data
                }

        except Exception as e:
            logger.log(
                f"Error comparing confs for job {job_id}: {e}",
                "ERROR",
                "ConfDiffManager"
            )
            conf_result = {
                "equivalent": None,
                "reason": f"Comparison error: {str(e)}"
            }

    # Save to conf_diffs/{job_id}.json
    computed_at = time.time()
    local_timestamp = timestamp_dir.name

    save_conf_diff_for_job(
        timestamp_dir,
        full_job_id,
        job_url,
        computed_at,
        local_timestamp,
        conf_result
    )

    # Update index
    if conf_result.get("equivalent") is not None:
        equivalent_value = conf_result["equivalent"]
        if isinstance(equivalent_value, bool):
            update_conf_diff_index(timestamp_dir, full_job_id, equivalent_value)

    logger.log(
        f"Completed conf diff for job {job_id}",
        "SUCCESS",
        "ConfDiffManager"
    )

    return conf_result


def load_conf_diffs(timestamp_dir: Path) -> Dict[str, Dict]:
    """
    Load all conf diffs from a timestamp directory.

    Args:
        timestamp_dir: Path to the timestamped snapshot directory

    Returns:
        Dict mapping job_id → diff_result, or empty dict if not found
    """
    conf_diffs_dir = timestamp_dir / DIR_CONF_DIFFS

    if not conf_diffs_dir.exists():
        logger.log(
            f"No conf_diffs directory found at {conf_diffs_dir}",
            "INFO",
            "ConfDiffManager"
        )
        return {}

    # Load all conf diff files
    conf_diffs = {}
    for conf_diff_file in conf_diffs_dir.glob("*.json"):
        if conf_diff_file.name == "index.json":
            continue

        job_id = conf_diff_file.stem
        try:
            diff_data = load_conf_diff_for_job(timestamp_dir, job_id)
            if diff_data:
                conf_diffs[job_id] = diff_data
        except Exception as e:
            logger.log(
                f"Failed to load conf diff for job {job_id}: {e}",
                "WARNING",
                "ConfDiffManager"
            )

    return conf_diffs
