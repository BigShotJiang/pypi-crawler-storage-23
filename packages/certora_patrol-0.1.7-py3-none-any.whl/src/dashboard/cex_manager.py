"""
CEX analysis manager for tracking and managing counterexample analyses.

Handles launching cexanalyzer, tracking analysis state, and persisting results.
"""


import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Optional

from src.dashboard.constants import (
    DashboardEcosystem,
    DIR_CEX_ANALYSES,
    DIR_CERTORA_INTERNAL,
    DIR_EXTRACTED_TARS,
    FILE_CEX_ANALYSES,
    FILE_CEXANALYZER_LOG,
    FIVE_MINUTES_SECONDS,
    PROGRESS_STATUS_FAILED,
    PROGRESS_STATUS_RUNNING,
    to_aicomposer_ecosystem,
)
from src.dashboard.logger import dashboard_logger as logger
from src.dashboard.models import CexAnalysisInfo


def get_cex_analyses_file(dashboard_dir: Path) -> Path:
    """
    Get the path to the CEX analyses tracking file.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Path to cex_analyses.json
    """
    return dashboard_dir / FILE_CEX_ANALYSES


def load_cex_analyses(dashboard_dir: Path) -> Dict[str, CexAnalysisInfo]:
    """
    Load CEX analysis tracking data.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard

    Returns:
        Dictionary mapping analysis_key -> CexAnalysisInfo
    """
    analyses_file = get_cex_analyses_file(dashboard_dir)

    if not analyses_file.exists():
        return {}

    try:
        with open(analyses_file, "r") as f:
            data = json.load(f)

        analyses = {}
        for key, analysis_data in data.items():
            analyses[key] = CexAnalysisInfo.from_dict(analysis_data)

        return analyses

    except Exception as e:
        logger.log(
            f"Error loading CEX analyses: {e}",
            "ERROR",
            "CexManager"
        )
        return {}


def save_cex_analyses(analyses: Dict[str, CexAnalysisInfo], dashboard_dir: Path):
    """
    Save CEX analysis tracking data.

    Args:
        analyses: Dictionary mapping analysis_key -> CexAnalysisInfo
        dashboard_dir: Path to .certora_internal/local_dashboard
    """
    analyses_file = get_cex_analyses_file(dashboard_dir)

    try:
        data = {key: analysis.to_dict() for key, analysis in analyses.items()}

        with open(analyses_file, "w") as f:
            json.dump(data, f, indent=2)

    except Exception as e:
        logger.log(
            f"Error saving CEX analyses: {e}",
            "ERROR",
            "CexManager"
        )


def get_analysis_key(job_id: str, rule_name: str, method_name: Optional[str] = None) -> str:
    """
    Generate a unique key for an analysis.

    Args:
        job_id: Job identifier
        rule_name: Rule name
        method_name: Optional method name

    Returns:
        Unique key string
    """
    if method_name:
        return f"{job_id}:{rule_name}:{method_name}"
    return f"{job_id}:{rule_name}"


def launch_cex_analysis(
    job_id: str,
    rule_name: str,
    method_name: Optional[str],
    run_url: str,
    dashboard_dir: Path,
    project_root: Path,
    cloud_rule_name: Optional[str] = None,
    ecosystem: DashboardEcosystem | str = DashboardEcosystem.EVM
) -> tuple[CexAnalysisInfo, bool]:
    """
    Launch a CEX analysis and track its state.

    Args:
        job_id: Job identifier
        rule_name: Rule name
        method_name: Optional method name for parametric rules
        run_url: URL to the verification run output
        dashboard_dir: Path to .certora_internal/local_dashboard
        project_root: Project root directory
        cloud_rule_name: Optional full cloud rule name (for Move rules)
        ecosystem: DashboardEcosystem or string value (e.g., DashboardEcosystem.EVM, "evm", "move", "rust")

    Returns:
        Tuple of (CexAnalysisInfo, was_launched: bool)
        was_launched is False if analysis is already running
    """
    analysis_key = get_analysis_key(job_id, rule_name, method_name)

    # Load existing analyses
    analyses = load_cex_analyses(dashboard_dir)

    # Check if analysis is already running (but allow retry if stuck)
    if analysis_key in analyses:
        existing = analyses[analysis_key]
        if existing.status == PROGRESS_STATUS_RUNNING:
            # Check if it's been running for more than 5 minutes (stuck)
            current_time = int(time.time())
            running_time = current_time - existing.timestamp

            if running_time <= FIVE_MINUTES_SECONDS:
                # Still recent - don't allow duplicate launch
                logger.log(
                    f"CEX analysis already running for {analysis_key}, skipping launch",
                    "INFO",
                    "CexManager"
                )
                return existing, False
            else:
                # Stuck analysis - allow retry
                logger.log(
                    f"CEX analysis stuck for {analysis_key} (running {running_time}s), allowing retry",
                    "INFO",
                    "CexManager"
                )

    # Use current time when launching (not snapshot time!)
    # We want to track when THIS analysis was launched, not when the scan was done
    timestamp = int(time.time())

    # Generate output file path for the analysis
    # Store in .certora_internal/cex_analyses/
    cex_output_dir = project_root / DIR_CERTORA_INTERNAL / DIR_CEX_ANALYSES
    cex_output_dir.mkdir(parents=True, exist_ok=True)

    # Generate filename: job_id_rulename_methodname.md
    filename_parts = [job_id, rule_name]
    if method_name:
        # Sanitize method name for filename (remove special chars)
        safe_method = "".join(c if c.isalnum() or c in "-_" else "_" for c in method_name)
        filename_parts.append(safe_method[:50])  # Limit length
    output_filename = "_".join(filename_parts) + ".md"
    output_file_path = cex_output_dir / output_filename

    # Store relative path from project root for serving
    relative_output_path = str(output_file_path.relative_to(project_root))

    # Create analysis info
    analysis = CexAnalysisInfo(
        job_id=job_id,
        rule_name=rule_name,
        method_name=method_name,
        status=PROGRESS_STATUS_RUNNING,
        timestamp=timestamp,
        output_file=relative_output_path
    )

    # Save immediately
    analyses[analysis_key] = analysis
    save_cex_analyses(analyses, dashboard_dir)

    # Launch cexanalyzer in background
    try:
        # Get paths
        analyzer_path = Path(__file__).parent / "utils" / "analyze_violations.py"

        if not analyzer_path.exists():
            raise FileNotFoundError(f"CEX analyzer not found at {analyzer_path}")

        # Build command: python3 analyze_violations.py <url> --rule RULE_NAME [--method METHOD_NAME] --ecosystem ECOSYSTEM --output OUTPUT.md
        # the path to the tarball of the job being checked will be then job_id within this folder, which should have been download already.
        tar_out_path = project_root / DIR_CERTORA_INTERNAL / DIR_EXTRACTED_TARS

        # Normalize ecosystem to DashboardEcosystem (handles string inputs)
        if isinstance(ecosystem, str):
            from src.dashboard.constants import normalize_to_dashboard_ecosystem
            dashboard_eco = normalize_to_dashboard_ecosystem(ecosystem)
        else:
            dashboard_eco = ecosystem

        # Use cloud_rule_name for Move, or fall back to rule_name for EVM
        rule_arg = cloud_rule_name if cloud_rule_name and dashboard_eco == DashboardEcosystem.MOVE else rule_name

        # Convert to AIComposer ecosystem format
        aicomposer_eco = to_aicomposer_ecosystem(dashboard_eco)

        cmd = [
            sys.executable,
            str(analyzer_path),
            run_url,
            "--rule", rule_arg,
            "--ecosystem", aicomposer_eco.value,
            "--output-dir-parent", str(tar_out_path)
        ]
        if method_name:
            # Convert invariant base case constructor to simple method name
            if method_name == "Induction base: After the constructor":
                normalized_method = "constructor"
            else:
                normalized_method = method_name
            cmd.extend(["--method", normalized_method])
        cmd.extend(["--output", str(output_file_path)])

        # Open log file for cexanalyzer output
        log_file_path = project_root / DIR_CERTORA_INTERNAL / FILE_CEXANALYZER_LOG
        log_file_path.parent.mkdir(parents=True, exist_ok=True)

        # Write header to log file
        with open(log_file_path, "a") as log_file:
            log_file.write(f"\n{'='*80}\n")
            log_file.write(f"CEX Analysis started at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            log_file.write(f"Command: {' '.join(cmd)}\n")
            log_file.write(f"{'='*80}\n\n")

        # Launch with output redirected to log file
        # Open log file for subprocess and use with statement to ensure proper cleanup
        # Pass environment variables including ANTHROPIC_API_KEY
        env = os.environ.copy()

        with open(log_file_path, "a") as log_file:
            process = subprocess.Popen(
                cmd,
                cwd=str(project_root),
                stdout=log_file,
                stderr=subprocess.STDOUT,  # Merge stderr into stdout
                env=env,  # Pass environment variables to subprocess
                start_new_session=True
            )

        logger.log(
            f"Launched CEX analysis for {rule_name} ({analysis_key}), PID: {process.pid}, output -> {log_file_path}",
            "INFO",
            "CexManager"
        )

        # Give process a moment to start and check if it died immediately
        time.sleep(0.5)
        poll_result = process.poll()
        if poll_result is not None:
            # Process already exited
            logger.log(
                f"CEX analysis process exited immediately with code {poll_result}. Check {log_file_path} for errors.",
                "ERROR",
                "CexManager"
            )
            analysis.status = PROGRESS_STATUS_FAILED
            analyses[analysis_key] = analysis
            save_cex_analyses(analyses, dashboard_dir)

    except Exception as e:
        logger.log(
            f"Error launching CEX analysis: {e}",
            "ERROR",
            "CexManager"
        )
        analysis.status = PROGRESS_STATUS_FAILED
        analyses[analysis_key] = analysis
        save_cex_analyses(analyses, dashboard_dir)

    return analysis, True


def check_analysis_completion(dashboard_dir: Path, project_root: Path) -> Dict[str, CexAnalysisInfo]:
    """
    Check for completed analyses and update their status.

    Looks for generated MD files in the project to mark analyses as complete.

    Args:
        dashboard_dir: Path to .certora_internal/local_dashboard
        project_root: Project root directory

    Returns:
        Updated analyses dictionary
    """
    analyses = load_cex_analyses(dashboard_dir)
    updated = False

    # Look for CEX analysis output files
    # cexanalyzer typically generates files like: <rule_name>_analysis.md
    cex_output_dir = project_root / DIR_CERTORA_INTERNAL / DIR_CEX_ANALYSES

    if not cex_output_dir.exists():
        return analyses

    for analysis_key, analysis in analyses.items():
        if analysis.status != PROGRESS_STATUS_RUNNING:
            continue

        # Check if the expected output file exists
        if not analysis.output_file:
            logger.log(
                f"Analysis {analysis_key} has no output_file set, skipping",
                "WARNING",
                "CexManager"
            )
            continue

        output_file_path = project_root / analysis.output_file

        if output_file_path.exists():
            # Check if file was created/modified after analysis started
            file_mtime = output_file_path.stat().st_mtime
            if file_mtime >= analysis.timestamp:
                analysis.status = "completed"
                updated = True
                logger.log(
                    f"CEX analysis completed: {analysis_key} -> {output_file_path.name}",
                    "INFO",
                    "CexManager"
                )

    if updated:
        save_cex_analyses(analyses, dashboard_dir)

    return analyses


def should_reanalyze(
    analysis_key: str,
    current_job_id: str,
    current_timestamp: int,
    analyses: Dict[str, CexAnalysisInfo]
) -> bool:
    """
    Determine if a rule should be re-analyzed.

    Re-analysis is needed if:
    1. No analysis exists, OR
    2. The current job is newer than the analyzed job

    Args:
        analysis_key: Key for the analysis
        current_job_id: Current job ID for this rule
        current_timestamp: Timestamp of current job
        analyses: Dictionary of existing analyses

    Returns:
        True if should re-analyze
    """
    if analysis_key not in analyses:
        return True

    existing = analyses[analysis_key]

    # If job ID changed, check timestamps
    if existing.job_id != current_job_id:
        # Current job is newer
        return current_timestamp > existing.timestamp

    return False
