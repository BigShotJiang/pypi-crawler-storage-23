"""
Dashboard-specific logging utility.

This module provides a separate logger for dashboard components
that logs to dashboard.log instead of orchestrator.log.
"""

from src.utils.logger import Logger


class DashboardLogger(Logger):
    """Dashboard-specific logger that writes to dashboard.log."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            # Don't use parent's singleton - create our own
            cls._instance = object.__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        # Initialize with dashboard-specific log file
        self._initialized = True
        self.verbose = 1  # Set to verbose to capture all INFO messages
        self.muted = False  # When True, suppress all console output (file logging still works)
        self.use_colors = True
        self.use_emojis = True

        # Import what we need from parent
        import threading
        from collections import deque

        self._log_queue = deque()
        self._flush_lock = threading.Lock()

        # Set up file logging with dashboard-specific name
        # Force immediate flush to handle Flask auto-reload
        self._setup_file_logging(log_name="dashboard", force_flush=True)

        # Reuse color codes and emojis from parent
        self.color_codes = {
            "INFO": "\033[0m",
            "SUCCESS": "\033[92m",
            "WARNING": "\033[93m",
            "ERROR": "\033[91m",
            "DEBUG": "\033[94m",
            "CRITICAL": "\033[95m",
        }

        self.emojis = {
            "ERROR": "❌",
            "WARNING": "⚠️",
            "INFO": "ℹ️",
            "SUCCESS": "✅",
            "DEBUG": "🐛",
            "CRITICAL": "🔴"
        }


# Dashboard-specific logger instance
dashboard_logger = DashboardLogger()
