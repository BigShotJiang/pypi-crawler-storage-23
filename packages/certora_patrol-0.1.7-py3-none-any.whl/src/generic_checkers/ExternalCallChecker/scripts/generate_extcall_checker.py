#!/usr/bin/env python3
"""
Script to generate Certora External Call Checker configuration and spec files.
"""

import argparse
import json
import os
import shutil
import sys
from pathlib import Path

from src.parsers.orchestrator_argparse import parse_contract_files
from src.utils.logger import logger

def validate_args(args):
    """Validate command line arguments."""
    if not args.mode:
        logger.error("--simple or --advanced mode is required")
        sys.exit(1)

    # Either files or base_config must be provided
    if not args.files and not args.base_config:
        logger.error("Either files or --base-config must be provided")
        sys.exit(1)

    if args.files and args.base_config:
        logger.error("Cannot specify both files and --base-config")
        sys.exit(1)

    if args.base_config:
        if not os.path.exists(args.base_config):
            logger.error(f"Base config file {args.base_config} does not exist")
            sys.exit(1)

    if not args.contract:
        logger.error("Main contract name is required")
        sys.exit(1)

    if args.files:
        contracts = parse_contract_files(args.files)
        for handle in contracts:
            if not handle.source_file.endswith('.sol'):
                logger.error(f"{handle.source_file} is not a .sol file")
                sys.exit(1)
            if not os.path.exists(handle.source_file):
                logger.error(f"File {handle.source_file} does not exist")
                sys.exit(1)
        contract_names = [c.contract_name for c in contracts]
        if args.contract not in contract_names:
            logger.error(f"Main contract '{args.contract}' not found in provided files")
            logger.error(f"Available contracts: {', '.join(contract_names)}")
            sys.exit(1)

def process_templates(args):
    """Process template files and generate configuration."""
    script_dir = Path(__file__).parent
    project_dir = script_dir.parent

    # Use args.output_dir if provided, else default
    output_dir = getattr(args, 'output_dir', None) or Path("certora_extcall_checker")
    contract_suffix = getattr(args, 'contract_suffix', "") or ""

    # Create output directory if it doesn't exist (don't delete if exists - for per-contract accumulation)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Determine template files based on mode
    if args.mode == 'simple':
        conf_templates = [
            "ExtcallCheckerSimpleView.template.conf",
            "ExtcallCheckerSimpleNonview.template.conf"
        ]
        spec_template = project_dir / "specs" / "extcall_checker_simple.template.spec"
        # Template-generated spec is shared (imported by view/nonview), no suffix
        spec_output = output_dir / "extcall_checker_simple.spec"
        # View and nonview specs are main entry points, get suffix
        additional_specs = [
            "extcall_checker_simple_view.spec",
            "extcall_checker_simple_nonview.spec"
        ]
    else:  # advanced
        conf_templates = [
            "ExtcallCheckerAdvancedView.template.conf",
            "ExtcallCheckerAdvancedNonview.template.conf"
        ]
        spec_template = project_dir / "specs" / "extcall_checker_advanced.template.spec"
        # Template-generated spec is shared (imported by view/nonview), no suffix
        spec_output = output_dir / "extcall_checker_advanced.spec"
        # View and nonview specs are main entry points, get suffix
        additional_specs = [
            "extcall_checker_advanced_view.spec",
            "extcall_checker_advanced_nonview.spec"
        ]

    generated_conf_names = []

    # Process all conf files
    for conf_template_name in conf_templates:
        conf_template = project_dir / "confs" / conf_template_name

        with open(conf_template, 'r') as f:
            conf_content = f.read()

        # Replace placeholders
        if args.base_config:
            conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"override_base_config": "{args.base_config}"')
        elif args.files:
            files_json = json.dumps(args.files)
            conf_content = conf_content.replace('$BASE_CONFIG_OR_FILES$', f'"files": {files_json}')
        conf_content = conf_content.replace('$CONTRACT$', args.contract)
        conf_content = conf_content.replace('$CONTRACT_SUFFIX$', contract_suffix)

        # Write with suffix in filename
        base_name = conf_template_name.replace('.template.conf', '')
        conf_output_name = f"{base_name}{contract_suffix}.conf"
        conf_output = output_dir / conf_output_name
        with open(conf_output, 'w') as f:
            f.write(conf_content)

        generated_conf_names.append(conf_output_name)

    # Process main spec file (with $HOLD$ replacement)
    # Only write if it doesn't exist (shared across contracts)
    if not spec_output.exists():
        with open(spec_template, 'r') as f:
            spec_content = f.read()

        # Replace $HOLD$ based on check_non_zero_targets flag
        hold_value = "assert" if args.check_non_zero_targets else "require"
        spec_content = spec_content.replace('$HOLD$', hold_value)

        with open(spec_output, 'w') as f:
            f.write(spec_content)
        logger.info(f"Generated shared: {spec_output}")

    # Copy additional spec files (view and nonview) with suffix
    for spec_source_name in additional_specs:
        spec_source = project_dir / "specs" / spec_source_name
        spec_base = spec_source_name.replace('.spec', '')
        spec_dest = output_dir / f"{spec_base}{contract_suffix}.spec"
        shutil.copy(spec_source, spec_dest)

    # Create runner script
    runner_script = output_dir / "run_checker.sh"
    with open(runner_script, 'w') as f:
        f.write(f"#!/bin/bash\n")
        f.write(f"# Generated runner script for Certora External Call Checker\n")
        for conf_name in generated_conf_names:
            f.write(f"certoraRun certora_extcall_checker/{conf_name}\n")

    # Make runner script executable
    os.chmod(runner_script, 0o755)

    logger.info(f"Generated configuration in {output_dir}/")
    logger.info(f"Configurations generated:")
    for conf_name in generated_conf_names:
        logger.info(f"  - {conf_name}")
    logger.info(f"Specifications generated:")
    logger.info(f"  - {spec_output.name}")
    for spec_name in additional_specs:
        spec_base = spec_name.replace('.spec', '')
        logger.info(f"  - {spec_base}{contract_suffix}.spec")
    logger.info(f"Runner script: {runner_script}")
    logger.info(f"To run the checkers, execute:")
    for conf_name in generated_conf_names:
        logger.info(f"  certoraRun certora_extcall_checker/{conf_name}")
    logger.info(f"  or run: ./certora_extcall_checker/run_checker.sh")

def main():
    parser = argparse.ArgumentParser(
        description="Generate Certora External Call Checker configuration and spec files"
    )

    parser.add_argument(
        '--check-non-zero-targets',
        action='store_true',
        help='Assert that target > 0 in specs (default: use require)'
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument(
        '--simple',
        action='store_const',
        dest='mode',
        const='simple',
        help='Use simple external call checker'
    )
    mode_group.add_argument(
        '--advanced',
        action='store_const',
        dest='mode',
        const='advanced',
        help='Use advanced external call checker'
    )

    parser.add_argument(
        '--base-config',
        type=str,
        help='Path to base config file (mutually exclusive with files)'
    )

    parser.add_argument(
        'files',
        nargs='*',
        help='List of Solidity contract files (.sol) - required if --base-config not provided'
    )

    parser.add_argument(
        'contract',
        help='Name of the main contract (without .sol extension)'
    )

    args = parser.parse_args()

    validate_args(args)
    process_templates(args)

if __name__ == "__main__":
    main()
