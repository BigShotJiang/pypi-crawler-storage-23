"""
Multi-analysis reporting module for checker output processing.

This module provides the core analysis and aggregation functions used by src.preaudit
for processing verification job results and generating reports.
"""

import asyncio
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import List, Literal, Optional

from pydantic import BaseModel, Field
from tqdm import tqdm

# Default maximum number of parallel workers for AI analysis
# the limit is based on the postgres docker being limited to 50 connections and each analysis taking about 5
DEFAULT_MAX_WORKERS = 8

from .synthesize_analyses import (
    SynthesisResult,
    _format_synthesis_markdown,
    build_unanimous_synthesis,
    is_unanimous,
    score_to_classification,
    synthesize_analyses,
)

from .base.checker_type import CheckerType
from .base.models import IterationSidecarData
from .processor import CheckerOutputProcessor, DetectedChecker, RuleSourceKey, GroupedViolationData
from .retry_utils import is_fatal_api_error
from .token_usage import get_global_tracker, reset_global_tracker, TokenUsageStats
from .grouping_strategy import (
    get_grouping_category,
    GroupingCategory,
    DuplicateViolationError,
    SourceLocationExtractionError,
    CalltraceSourceExtractor,
    get_hook_type,
)

from src.utils.logger import logger
from src.utils.rag_config import get_default_rag_db

from .analyzer import AIViolationAnalyzer
from .calltrace_code_extractor import read_code_snippets
from .defect_aggregator import compute_confidence_score
from .fix_generator import FixGenerationResult, generate_fix_for_finding
from src.dashboard.constants import DIR_CERTORA_INTERNAL, DIR_TARBALL_CACHE
from src.dashboard.tarball_manager import download_tarball, extract_from_tarball

# Validation pass threshold
HIGH_CONFIDENCE_THRESHOLD = 80


class JudgementResult(BaseModel):
    """Result from AIComposer validation pass on high-confidence findings."""

    is_defect: Literal["YES", "NO"] = Field(description="Validation verdict: YES or NO")
    confidence: Literal["HIGH", "LOW"] = Field(description="Validation confidence: HIGH or LOW")
    reasoning: str = Field(description="Reasoning behind the validation verdict")
    recomputed_score: int = Field(ge=0, le=100, description="Score after adding judgement (2x weight)")
    recomputed_classification: str = Field(description="Classification based on recomputed score")
    classification_changed: bool = Field(description="True if recomputed differs from original")


class ImpactLikelihoodResult(BaseModel):
    """Impact and likelihood assessment for confirmed issues."""

    impact: Literal["low", "medium", "high"] = Field(description="Impact severity of the defect")
    likelihood: Literal["low", "medium", "high"] = Field(description="Likelihood of the defect being exploited or triggered")
    reasoning: str = Field(description="Brief reasoning for the impact and likelihood ratings")


def recompute_score_with_judgement(
    original_vote_counts: tuple[int, int, int, int],
    judgement_outcome: Literal["YH", "YL", "NL", "NH"],
) -> tuple[int, str, bool]:
    """
    Recompute confidence score adding judgement result with 2x weight.

    Args:
        original_vote_counts: Tuple of (n_yh, n_yl, n_nl, n_nh) from original iterations
        judgement_outcome: Outcome code from validation ("YH", "YL", "NL", "NH")

    Returns:
        Tuple of (recomputed_score, recomputed_classification, classification_changed)
    """
    n_yh, n_yl, n_nl, n_nh = original_vote_counts

    # Add judgement twice (2x weight)
    if judgement_outcome == "YH":
        n_yh += 2
    elif judgement_outcome == "YL":
        n_yl += 2
    elif judgement_outcome == "NL":
        n_nl += 2
    elif judgement_outcome == "NH":
        n_nh += 2

    recomputed_score = compute_confidence_score(n_yh, n_yl, n_nl, n_nh)
    recomputed_classification = score_to_classification(recomputed_score)
    original_classification = score_to_classification(
        compute_confidence_score(*original_vote_counts)
    )

    return recomputed_score, recomputed_classification, recomputed_classification != original_classification


def get_behavior_summary_from_iterations(iter_dir: Path) -> Optional[str]:
    """
    Extract behavior_summary from first iteration JSON.

    Args:
        iter_dir: Path to the directory containing iteration JSON files (run_*.json)

    Returns:
        The behavior_summary string if found, None otherwise
    """
    for iter_json in sorted(iter_dir.glob("run_*.json")):
        with open(iter_json) as f:
            data = json.load(f)
        if "behavior_summary" in data:
            return data["behavior_summary"]
    return None


# Validation prompt addendum
VALIDATION_PROMPT_ADDENDUM = """
NOTE: THIS INSTANCE WAS FOUND TO BE LIKELY TO BE A DEFECT IN A PREVIOUS PASS. BE JUDGEMENTAL. YOU DO NOT GET THE PREVIOUS PASS RESULTS AND TRY TO CONFIRM OR REFUTE IT BASED ON YOUR OWN INDEPENDENT RESEARCH
"""


def run_validation_for_entry(
    key: "RuleSourceKey",
    iter_dir: Path,
    vote_counts: tuple[int, int, int, int] | None,
    grouped_data: Optional["GroupedViolationData"],
    use_cache: bool,
    rag_db: str | None = None,
) -> Optional[JudgementResult]:
    """
    Run AIComposer validation for a high-confidence finding.

    Args:
        key: The RuleSourceKey identifying the rule and source location
        iter_dir: Path to the iteration directory containing run_*.json files
        vote_counts: Original vote counts (n_yh, n_yl, n_nl, n_nh)
        grouped_data: The original grouped violation data (for job_url)
        use_cache: Whether to use cache

    Returns:
        JudgementResult if validation succeeded, None otherwise
    """
    from jinja2 import Environment, FileSystemLoader
    from .cached_analysis import AICOMPOSER_MODEL, analyze_with_calltraces_cached
    from .analyzer import CheckerAnalysisArgs, IterationResult
    from .token_usage import AnalysisPhase

    # Get behavior summary from iteration data
    behavior_summary = get_behavior_summary_from_iterations(iter_dir)
    if not behavior_summary:
        logger.warning(f"No behavior_summary found for {key.rule_name}, skipping validation")
        return None

    if grouped_data is None:
        logger.warning(f"No grouped_data found for {key.rule_name}, skipping validation")
        return None

    job_url = grouped_data.job_url

    # Load Step 2 template
    prompts_dir = Path(__file__).parent.parent.parent.parent / "prompts"
    env = Environment(loader=FileSystemLoader(str(prompts_dir)))

    # Determine template name based on rule
    rule_name = key.rule_name
    template_base = _get_validation_template_base_name(rule_name, checker_type=grouped_data.checker_type)
    template_name = f"defect_analysis/{template_base}.j2"

    try:
        template = env.get_template(template_name)
    except Exception as e:
        logger.warning(f"Failed to load template {template_name} for {rule_name}: {e}")
        return None

    # Render with ecosystem params
    from analyzer.analysis import ecosystem_params  # type: ignore[import-not-found]
    params = dict(ecosystem_params.get("evm", ecosystem_params["evm"]))
    initial_prompt = template.render(**params)

    # Append validation note
    initial_prompt = initial_prompt + "\n\n" + VALIDATION_PROMPT_ADDENDUM

    # Build input messages (same as Step 2)
    input_messages = [
        f"Rule: {rule_name}",
        "## Behavior Description (from Step 1 analysis)",
        behavior_summary,
    ]

    # Create args
    # We need a dummy folder - use the tarball cache path
    from src.dashboard.constants import DIR_CERTORA_INTERNAL
    from src.dashboard.utils.analyze_violations import extract_job_id_from_url as extract_jid

    job_id = extract_jid(job_url)
    extracted_dir = Path(DIR_CERTORA_INTERNAL) / "extracted_tars" / job_id
    if not extracted_dir.exists():
        # Try to use a fallback - just use the iter_dir parent
        extracted_dir = iter_dir.parent

    resolved_rag_db = rag_db if rag_db is not None else get_default_rag_db()
    args = CheckerAnalysisArgs(
        folder=str(extracted_dir),
        rule=f"{rule_name}_validation",
        quiet=True,
        ecosystem="evm",
        rag_db=resolved_rag_db,
        recursion_limit=30,
    )

    # Run validation through cached analysis
    exit_code, analysis_text, source = analyze_with_calltraces_cached(
        input_messages=input_messages,
        initial_prompt=initial_prompt,
        args=args,
        job_url=job_url,
        rule_name=rule_name,
        phase=AnalysisPhase.VALIDATION,
        model_name=AICOMPOSER_MODEL,
        use_cache=use_cache,
        output_type=IterationResult,
    )

    if exit_code != 0:
        logger.warning(f"Validation failed for {rule_name}: {analysis_text}")
        return None

    # Parse result
    try:
        result = IterationResult.model_validate_json(analysis_text)
    except Exception as e:
        logger.warning(f"Failed to parse validation result for {rule_name}: {e}")
        return None

    # Compute judgement outcome
    judgement_outcome = result.to_outcome_code()

    # Recompute score with 2x weight for judgement
    if vote_counts is None:
        vote_counts = (0, 0, 0, 0)

    recomputed_score, recomputed_classification, classification_changed = recompute_score_with_judgement(
        vote_counts, judgement_outcome
    )

    return JudgementResult(
        is_defect=result.is_defect,
        confidence=result.confidence,
        reasoning=result.reasoning,
        recomputed_score=recomputed_score,
        recomputed_classification=recomputed_classification,
        classification_changed=classification_changed,
    )


# Impact/likelihood threshold: entries with effective score >= 60 (DEFINITE_ISSUE or LIKELY_ISSUE)
IMPACT_LIKELIHOOD_THRESHOLD = 60


def run_impact_likelihood_for_entry(
    key: "RuleSourceKey",
    iter_dir: Path,
    judgement_result: JudgementResult | None,
    grouped_data: Optional["GroupedViolationData"],
    use_cache: bool = True,
    rag_db: str | None = None,
) -> Optional[ImpactLikelihoodResult]:
    """
    Run impact/likelihood assessment for a confirmed issue.

    Args:
        key: The RuleSourceKey identifying the rule and source location
        iter_dir: Path to the iteration directory containing run_*.json files
        judgement_result: The validation judgement result (if available)
        grouped_data: The original grouped violation data (for job_url)
        use_cache: Whether to use cache

    Returns:
        ImpactLikelihoodResult if assessment succeeded, None otherwise
    """
    from jinja2 import Environment, FileSystemLoader
    from .cached_analysis import AICOMPOSER_MODEL, analyze_with_calltraces_cached
    from .analyzer import CheckerAnalysisArgs
    from .token_usage import AnalysisPhase

    rule_name = key.rule_name

    # Get behavior summary from iteration data
    behavior_summary = get_behavior_summary_from_iterations(iter_dir)
    if not behavior_summary:
        logger.warning(f"No behavior_summary found for {rule_name}, skipping impact/likelihood")
        return None

    if grouped_data is None:
        logger.warning(f"No grouped_data found for {rule_name}, skipping impact/likelihood")
        return None

    # Build input messages
    input_messages = [
        f"Rule: {rule_name}",
        "## Behavior Description",
        behavior_summary,
    ]

    # Collect iteration evaluations (reasoning from run_*.json sidecars)
    iteration_reasonings = []
    for iter_json in sorted(iter_dir.glob("run_*.json")):
        try:
            with open(iter_json) as f:
                data = json.load(f)
            reasoning = data.get("reasoning")
            if reasoning:
                iteration_reasonings.append(reasoning)
        except Exception:
            continue

    if iteration_reasonings:
        input_messages.append("## Iteration Evaluations")
        for i, r in enumerate(iteration_reasonings, 1):
            input_messages.append(f"### Evaluation {i}\n{r}")

    # Add judgement result if available
    if judgement_result:
        input_messages.append("## Validation Judgement")
        input_messages.append(
            f"is_defect: {judgement_result.is_defect}, "
            f"confidence: {judgement_result.confidence}, "
            f"reasoning: {judgement_result.reasoning}"
        )

    # Create args
    job_url = grouped_data.job_url
    from src.dashboard.utils.analyze_violations import extract_job_id_from_url as extract_jid

    job_id = extract_jid(job_url)
    extracted_dir = Path(DIR_CERTORA_INTERNAL) / "extracted_tars" / job_id
    if not extracted_dir.exists():
        extracted_dir = iter_dir.parent

    resolved_rag_db = rag_db if rag_db is not None else get_default_rag_db()
    args = CheckerAnalysisArgs(
        folder=str(extracted_dir),
        rule=f"{rule_name}_impact_likelihood",
        quiet=True,
        ecosystem="evm",
        rag_db=resolved_rag_db,
        recursion_limit=30,
    )

    # Load impact/likelihood prompt template
    prompts_dir = Path(__file__).parent.parent.parent.parent / "prompts"
    env = Environment(loader=FileSystemLoader(str(prompts_dir)))
    template = env.get_template("impact_likelihood/default.j2")
    initial_prompt = template.render()

    # Run impact/likelihood through cached analysis
    exit_code, analysis_text, source = analyze_with_calltraces_cached(
        input_messages=input_messages,
        initial_prompt=initial_prompt,
        args=args,
        job_url=job_url,
        rule_name=rule_name,
        phase=AnalysisPhase.IMPACT_LIKELIHOOD,
        model_name=AICOMPOSER_MODEL,
        use_cache=use_cache,
        output_type=ImpactLikelihoodResult,
    )

    if exit_code != 0:
        logger.warning(f"Impact/likelihood assessment failed for {rule_name}: {analysis_text}")
        return None

    # Parse result
    try:
        return ImpactLikelihoodResult.model_validate_json(analysis_text)
    except Exception as e:
        logger.warning(f"Failed to parse impact/likelihood result for {rule_name}: {e}")
        return None


def _get_validation_template_base_name(rule_name: str, checker_type: CheckerType | None = None) -> str:
    """
    Get the base template name for a rule (without directory or extension).
    Mirrors the logic in AIViolationAnalyzer._get_template_base_name.
    """
    if checker_type == CheckerType.AUTOCVL:
        return "autocvl"

    # Direct mappings for standard rules
    direct_mappings = {
        "privilegedOperation": "privilegedOperation",
        "safeCasting": "safeCasting",
        "viewReentrancy": "viewReentrancy",
        "stable_extcall_targets_and_selectors": "stable_extcall_targets_and_selectors",
        "msg_value_in_loop": "msg_value_in_loop",
        "nonGettersThatNeverRevert": "nonGettersThatNeverRevert",
        "detect_privileged_writes": "detect_privileged_writes",
        "detect_time_sensitive_writes": "detect_time_sensitive_writes",
        "failing_CALL_leads_to_revert": "failing_CALL_leads_to_revert",
    }

    if rule_name in direct_mappings:
        return direct_mappings[rule_name]

    # Pattern matching for auto-generated rules
    if rule_name.startswith("input_validation_"):
        return "input_validation"
    if rule_name.startswith("oneTimeFunction"):
        return "oneTimeFunction"
    if "SelfCalls" in rule_name or "selfCalls" in rule_name:
        return "selfCalls"

    # Default to rule_name itself
    return rule_name


def extract_job_id_from_url(url: str) -> str:
    """Extract job ID from Certora prover URL."""
    # URL format: https://prover.certora.com/output/<org_id>/<job_id>/...
    parts = url.rstrip('/').split('/')
    for i, part in enumerate(parts):
        if part == 'output' and i + 2 < len(parts):
            return parts[i + 2]
    return hashlib.sha256(url.encode()).hexdigest()[:12]


def _build_synthesis_from_single_analysis(analysis_file: Path) -> SynthesisResult:
    """
    Build a SynthesisResult from a single analysis file without LLM synthesis.
    Uses is_defect/confidence from the JSON sidecar written by run_single_analysis_for_group.
    Computes confidence_score using DefectAggregator.
    """
    # Read analysis content
    with open(analysis_file, 'r') as f:
        content = f.read()

    # Read outcome code from JSON sidecar
    json_sidecar = analysis_file.with_suffix(".json")
    confidence_score = 50
    if json_sidecar.exists():
        with open(json_sidecar, 'r') as f:
            data = json.load(f)
            outcome_code = data.get("outcome_code", "NL")

            # Compute confidence score from single outcome
            n_yh, n_yl, n_nl, n_nh = 0, 0, 0, 0
            if outcome_code == "YH":
                n_yh = 1
            elif outcome_code == "YL":
                n_yl = 1
            elif outcome_code == "NL":
                n_nl = 1
            elif outcome_code == "NH":
                n_nh = 1
            confidence_score = compute_confidence_score(n_yh, n_yl, n_nl, n_nh)

    # Convert score to classification
    classification = score_to_classification(confidence_score)

    return SynthesisResult(
        evidence_synthesis=content,
        consolidated_reasoning="Single iteration - no synthesis required.",
        recommended_action="Review the analysis above.",
        is_single_iteration=True,
        computed_confidence_score=confidence_score,
        computed_classification=classification,
    )


def run_single_analysis_for_group(
    iteration: int,
    total: int,
    grouped_data: GroupedViolationData,
    output_dir: Path,
    use_cache: bool,
    ext_logger=None,
    progress=None,
    rag_db: str | None = None,
) -> tuple[Path | None, str]:
    """
    Run AI analysis for a pre-grouped set of violations (single iteration).

    Uses the TWO-STEP flow:
    - Step 1: Calltrace analysis (cached once, no iteration_index)
    - Step 2: Defect analysis (YES/NO + HIGH/LOW, cached per iteration)

    Uses the checks and calltraces from GroupedViolationData directly,
    without re-fetching or re-filtering.

    Returns:
        Tuple of (output_file_path, rule_name) if successful, (None, rule_name) if failed.
    """
    output_file = output_dir / f"run_{iteration}.md"
    rule_name = grouped_data.rule_name

    try:
        # Build traces list from pre-grouped calltraces (each has xml and locations)
        traces = [{"type": "calltrace_xml", "xml": ct["xml"], "locations": ct["locations"]} for ct in grouped_data.calltraces]

        # Build violation info for logging
        method_names = sorted(set(c.method_only or c.method_name or "?" for c in grouped_data.checks))

        # Create AI analyzer and run two-step analysis
        analyzer = AIViolationAnalyzer(
            job_url=grouped_data.job_url,
            use_cache=use_cache,
            iteration_index=iteration,
            ext_logger=ext_logger,
            progress=progress,
            precomputed_snippets=grouped_data.precomputed_snippets,
            rag_db=rag_db,
            checker_type=grouped_data.checker_type,
        )

        # Use the new two-step analysis method
        ai_feedback, ai_confidence, defect_result = analyzer.analyze_violation_group_two_step(
            grouped_data.checks, rule_name, traces
        )

        raw_output = ai_feedback.raw_output if ai_feedback else ""

        # Write output file
        with open(output_file, 'w') as f:
            f.write(f"# Analysis Iteration {iteration}\n\n")
            f.write(f"**Job URL**: {grouped_data.job_url}\n")
            f.write(f"**Rule**: {rule_name}\n")
            f.write(f"**Source Location**: {grouped_data.source_location}\n")
            f.write(f"**Methods**: {', '.join(method_names)}\n")
            f.write(f"**Iteration**: {iteration}/{total}\n\n")
            if raw_output:
                f.write(raw_output)
                f.write("\n\n")

        # Write JSON sidecar with YES/NO + HIGH/LOW format (new two-step format)
        json_sidecar = output_dir / f"run_{iteration}.json"
        ai_analysis_success = bool(raw_output and raw_output.strip())

        # Build sidecar data with proper typing
        sidecar_data: IterationSidecarData = {
            "findings_metadata": [{
                "source_location": grouped_data.source_location,
                "violating_methods": list(method_names),
            }],
            "ai_analysis_success": ai_analysis_success,
        }

        if defect_result:
            # New two-step format: is_defect, confidence, outcome_code, reasoning
            sidecar_data["is_defect"] = defect_result.is_defect
            sidecar_data["confidence"] = defect_result.confidence
            sidecar_data["outcome_code"] = defect_result.to_outcome_code()
            sidecar_data["reasoning"] = defect_result.reasoning
            sidecar_data["recommendation"] = defect_result.recommendation

            # Use structured behavior_summary from FinalFeedback (no regex parsing needed)
            if ai_feedback and ai_feedback.behavior_summary:
                sidecar_data["behavior_summary"] = ai_feedback.behavior_summary
        else:
            # Fallback if defect analysis failed - treat as low confidence NO
            sidecar_data["is_defect"] = "NO"
            sidecar_data["confidence"] = "LOW"
            sidecar_data["outcome_code"] = "NL"

        # Keep legacy fields for backward compatibility
        sidecar_data["confidence_score"] = ai_confidence

        with open(json_sidecar, 'w') as f:
            json.dump(sidecar_data, f)

        return output_file, rule_name

    except Exception as e:
        if is_fatal_api_error(e):
            import traceback
            logger.log_or_write(f"  [Iteration {iteration}] Fatal error for {rule_name}:\n{traceback.format_exc()}", progress, "error")
            raise
        logger.log_or_write(f"  [Iteration {iteration}] Failed for {rule_name}: {e}", progress, "error")
        return None, rule_name


async def async_run_multi_analysis_for_group(
    grouped_data: GroupedViolationData,
    iterations: int,
    output_base_dir: Path,
    use_cache: bool,
    semaphore: asyncio.Semaphore,
    ext_logger=None,
    progress=None,
    rag_db: str | None = None,
) -> tuple[Path | None, RuleSourceKey]:
    """
    Run multi-analysis for a pre-grouped set of violations: N iterations + synthesis.
    Uses the checks and calltraces from GroupedViolationData directly.

    Returns:
        Tuple of (synthesis_file_path, RuleSourceKey) if successful, (None, key) if failed.
    """
    rule_name = grouped_data.rule_name
    key = RuleSourceKey(rule_name=rule_name, source_location=grouped_data.source_location)

    job_id = extract_job_id_from_url(grouped_data.job_url)
    # Include source location in the output directory name for uniqueness
    loc_hash = hashlib.md5(grouped_data.source_location.encode()).hexdigest()[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = output_base_dir / f"{job_id}_{rule_name}_{loc_hash}_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)

    method_names = sorted(set(c.method_only or c.method_name or "?" for c in grouped_data.checks))
    logger.log_or_write(
        f"  Multi-analysis for '{rule_name}' [{', '.join(method_names)}]: {iterations} iterations",
        progress
    )

    # Run iterations concurrently, each gated by shared semaphore
    async def run_iteration(i: int) -> tuple[Path | None, str]:
        async with semaphore:
            result = await asyncio.to_thread(
                run_single_analysis_for_group,
                i, iterations, grouped_data,
                output_dir, use_cache, ext_logger, progress, rag_db
            )
            if progress:
                progress.update(1)
            return result

    results = await asyncio.gather(
        *(run_iteration(i) for i in range(1, iterations + 1)),
        return_exceptions=True
    )

    # Collect results
    analysis_files = []
    failed_count = 0
    for result in results:
        if isinstance(result, BaseException):
            if isinstance(result, Exception) and is_fatal_api_error(result):
                raise result
            logger.log_or_write(f"  Iteration failed for '{rule_name}': {result}", progress, "error")
            failed_count += 1
            continue
        result_file, _ = result
        if result_file:
            analysis_files.append(result_file)
        else:
            failed_count += 1

    analysis_files.sort()

    # Auto-retry for single iteration mode if AI analysis failed
    if iterations == 1 and len(analysis_files) == 1:
        json_sidecar = analysis_files[0].with_suffix(".json")
        if json_sidecar.exists():
            with open(json_sidecar) as f:
                sidecar_data = json.load(f)
            ai_success = sidecar_data.get("ai_analysis_success", True)

            if not ai_success:
                logger.log_or_write(
                    f"  AI analysis produced no output for '{rule_name}', retrying...",
                    progress, "warning"
                )
                # Retry with cache disabled
                retry_result = await asyncio.to_thread(
                    run_single_analysis_for_group,
                    1,  # iteration
                    1,  # total
                    grouped_data,
                    output_dir,
                    False,  # use_cache=False for retry
                    ext_logger,
                    progress,
                    rag_db,
                )
                retry_file, _ = retry_result
                if retry_file:
                    # Check if retry succeeded
                    retry_sidecar = retry_file.with_suffix(".json")
                    if retry_sidecar.exists():
                        with open(retry_sidecar) as f:
                            retry_sidecar_data = json.load(f)
                        if retry_sidecar_data.get("ai_analysis_success", False):
                            logger.log_or_write(
                                f"  Retry succeeded for '{rule_name}'",
                                progress
                            )
                            analysis_files = [retry_file]
                        else:
                            logger.log_or_write(
                                f"  Retry also failed for '{rule_name}', using original",
                                progress, "warning"
                            )
                else:
                    logger.log_or_write(
                        f"  Retry failed for '{rule_name}', using original",
                        progress, "warning"
                    )

    if not analysis_files:
        logger.log_or_write(f"  All iterations failed for rule '{rule_name}'", progress, "warning")
        return None, key

    # Filter out failed analyses (ai_analysis_success=false) - don't count them in aggregation or synthesis
    successful_analysis_files = []
    for analysis_file in analysis_files:
        json_sidecar = analysis_file.with_suffix(".json")
        if json_sidecar.exists():
            with open(json_sidecar) as f:
                data = json.load(f)
            if data.get("ai_analysis_success", True):
                successful_analysis_files.append(analysis_file)
            else:
                failed_count += 1
        else:
            # No sidecar means we can't verify success, include it
            successful_analysis_files.append(analysis_file)

    analysis_files = successful_analysis_files

    if not analysis_files:
        logger.log_or_write(f"  All iterations failed for rule '{rule_name}'", progress, "warning")
        return None, key

    if failed_count > 0:
        logger.log_or_write(
            f"  {failed_count}/{iterations} iterations failed for '{rule_name}', "
            f"continuing with {len(analysis_files)} successful",
            progress, "warning"
        )

    # Compute aggregated confidence score from successful iteration outcomes only
    n_yh, n_yl, n_nl, n_nh = 0, 0, 0, 0
    for analysis_file in analysis_files:
        json_sidecar = analysis_file.with_suffix(".json")
        if json_sidecar.exists():
            with open(json_sidecar) as f:
                data = json.load(f)
            outcome = data.get("outcome_code", "NL")
            if outcome == "YH":
                n_yh += 1
            elif outcome == "YL":
                n_yl += 1
            elif outcome == "NL":
                n_nl += 1
            elif outcome == "NH":
                n_nh += 1

    computed_confidence_score = compute_confidence_score(n_yh, n_yl, n_nl, n_nh)

    # Prepare vote counts tuple for voting breakdown
    vote_counts = (n_yh, n_yl, n_nl, n_nh)

    # Run synthesis - skip LLM if only 1 analysis or if all iterations are unanimous
    synthesis_output = output_dir / "synthesis.md"
    try:
        if len(analysis_files) == 1:
            # Single iteration: no need for LLM synthesis, just wrap the analysis
            logger.log_or_write(f"  Single iteration - skipping LLM synthesis for '{rule_name}'", progress)
            result = _build_synthesis_from_single_analysis(analysis_files[0])

            # Write markdown output
            with open(synthesis_output, 'w') as f:
                f.write(_format_synthesis_markdown(result, vote_counts))

            # Write JSON sidecar
            json_output = synthesis_output.with_suffix(".json")
            with open(json_output, 'w') as f:
                f.write(result.model_dump_json(indent=2))
        elif is_unanimous(vote_counts):
            # All iterations agreed - no need for LLM synthesis
            logger.log_or_write(
                f"  All {len(analysis_files)} iterations unanimous - skipping LLM synthesis for '{rule_name}'",
                progress
            )
            result = build_unanimous_synthesis(
                analysis_files=analysis_files,
                vote_counts=vote_counts,
                computed_confidence_score=computed_confidence_score,
            )

            # Write markdown output
            with open(synthesis_output, 'w') as f:
                f.write(_format_synthesis_markdown(result, vote_counts))

            # Write JSON sidecar
            json_output = synthesis_output.with_suffix(".json")
            with open(json_output, 'w') as f:
                f.write(result.model_dump_json(indent=2))
        else:
            # Multiple iterations with disagreement: run LLM synthesis
            async with semaphore:
                await asyncio.to_thread(
                    synthesize_analyses,
                    analysis_files=analysis_files,
                    output_file=synthesis_output,
                    rule_name=rule_name,
                    num_analyses=len(analysis_files),
                    logger=logger,
                    use_cache=use_cache,
                    computed_confidence_score=computed_confidence_score,
                    vote_counts=vote_counts,
                )
        logger.log_or_write(f"  Synthesis complete: {synthesis_output!s}", progress)
        return synthesis_output, key
    except Exception as e:
        if is_fatal_api_error(e):
            raise
        logger.log_or_write(f"  Synthesis failed for '{rule_name}': {e}", progress, "error")
        return None, key


def _get_violated_rules_for_autocvl_job(
    processor: CheckerOutputProcessor,
    job_url: str,
    rule_filter: str | None = None,
) -> tuple[dict[RuleSourceKey, GroupedViolationData], dict[str, set[str]]]:
    """Handle autocvl jobs: bypass matcher loop, treat all violated rules as AUTOCVL.

    AutoCVL rules don't match any existing checker pattern. Instead of silently
    dropping them as unmatched, we group them under CheckerType.AUTOCVL so they
    flow through the analysis pipeline with generic autocvl prompt templates.

    All autocvl rules are treated as Category 1 (group by method name).
    """
    all_checks = processor.data_extractor.get_all_checks()
    violated_checks = processor.data_extractor.get_violated_checks()

    all_rule_names = {c.rule_name for c in all_checks}
    violated_rule_names = {c.rule_name for c in violated_checks}

    result: dict[RuleSourceKey, GroupedViolationData] = {}
    passing_rules: set[str] = set()

    for rule in sorted(all_rule_names):
        if rule in violated_rule_names:
            if rule_filter and rule != rule_filter:
                continue
            # Get violated checks for this rule
            checks = [c for c in violated_checks if c.rule_name == rule]
            # Group by method (Category 1 style)
            method_checks: dict[str, list] = {}
            for check in checks:
                method = check.method_only or check.method_name or "<unknown>"
                method_checks.setdefault(method, []).append(check)

            for method, checks_for_method in method_checks.items():
                key = RuleSourceKey(rule_name=rule, source_location=f"method:{method}")
                calltraces = []
                for check in checks_for_method:
                    ct = processor.trace_extractor.get_calltrace(check)
                    if ct:
                        calltraces.append(ct)
                result[key] = GroupedViolationData(
                    checks=checks_for_method,
                    calltraces=calltraces,
                    job_url=job_url,
                    rule_name=rule,
                    source_location=key.source_location,
                    checker_type=CheckerType.AUTOCVL,
                )
        else:
            # Check if all checks are VERIFIED
            checks = [c for c in all_checks if c.rule_name == rule]
            if checks and all(c.status.name == "VERIFIED" for c in checks):
                passing_rules.add(rule)

    passing_by_checker: dict[str, set[str]] = {}
    if passing_rules:
        passing_by_checker[CheckerType.AUTOCVL] = passing_rules

    return result, passing_by_checker


def get_violated_rules_for_job(
    job_url: str,
    use_cache: bool,
    checker_filter: str | None = None,
    rule_filter: str | None = None,
    is_autocvl: bool = False,
) -> tuple[dict[RuleSourceKey, GroupedViolationData], dict[str, set[str]]]:
    """
    Get violated rules for a job with rule-specific grouping, including pre-grouped data.

    Returns a tuple of:
    - dictionary mapping each RuleSourceKey to its GroupedViolationData
    - dictionary mapping checker_type to set of passing rule names

    The GroupedViolationData contains the checks and calltraces for that specific group.
    This allows analysis to use the pre-grouped data directly without re-filtering.

    Category 1 rules (default): Groups by method name, source_location="method:<method_name>"
    Category 2 rules: Groups by source location from calltrace extraction

    Args:
        job_url: URL of the prover job
        use_cache: Whether to use cached results
        checker_filter: If specified, only return rules from this checker type
        rule_filter: If specified, only return this specific rule
        is_autocvl: If True, treat all violated rules as autocvl (bypass matcher loop)

    May raise DuplicateViolationError or SourceLocationExtractionError for fatal conditions.
    """
    try:
        processor = CheckerOutputProcessor(
            job_url=job_url,
            skip_ai=True,  # We just need rule names and grouping, not AI analysis
            use_cache=use_cache,
            use_retry=True,
        )

        # For autocvl jobs, bypass the normal matcher loop: synthesize a single DetectedChecker
        # that claims ALL violated rules under CheckerType.AUTOCVL
        if is_autocvl:
            return _get_violated_rules_for_autocvl_job(processor, job_url, rule_filter)

        analysis = processor.analyze_job()

        result: dict[RuleSourceKey, GroupedViolationData] = {}
        passing_rules_by_checker: dict[str, set[str]] = {}

        for dc in analysis.detected_checkers:
            # Filter by checker type if specified
            if checker_filter and dc.checker_type != checker_filter:
                continue

            # Track passing rules (rules where ALL checks are VERIFIED, not just "not violated")
            for rule in dc.rule_names:
                if rule in dc.violated_rule_names:
                    continue  # Skip violated rules
                # Check if all checks for this rule are VERIFIED (not UNKNOWN or other statuses)
                checks = processor.data_extractor.get_checks_by_rule(rule)
                if checks and all(c.status.name == "VERIFIED" for c in checks):
                    if dc.checker_type not in passing_rules_by_checker:
                        passing_rules_by_checker[dc.checker_type] = set()
                    passing_rules_by_checker[dc.checker_type].add(rule)

            if not dc.has_violations:
                continue

            for rule in dc.violated_rule_names:
                # Filter by rule name if specified
                if rule_filter and rule != rule_filter:
                    continue
                category = get_grouping_category(rule)

                # Get all violated checks for this rule
                checks = processor.data_extractor.get_violated_checks_by_rule(rule)

                if category == GroupingCategory.RULE_ONLY:
                    # Category 3: Non-parametric rules - 1 violation per rule, no method grouping
                    key = RuleSourceKey(rule_name=rule, source_location=f"rule:{rule}")
                    # Collect all checks and calltraces for this rule
                    calltraces = []
                    for check in checks:
                        ct = processor.trace_extractor.get_calltrace(check)
                        if ct:
                            calltraces.append(ct)
                    result[key] = GroupedViolationData(
                        checks=checks,
                        calltraces=calltraces,
                        job_url=job_url,
                        rule_name=rule,
                        source_location=key.source_location,
                    )
                elif category == GroupingCategory.RULE_METHOD:
                    # Category 1: Group by method name
                    method_checks: dict[str, list] = {}
                    for check in checks:
                        method = check.method_only or check.method_name or "<unknown>"
                        if method in method_checks:
                            # Duplicate violation for same rule+method - this is a fatal error
                            raise DuplicateViolationError(
                                f"Multiple violations found for rule '{rule}' "
                                f"and method '{method}' in job {job_url}. "
                                f"Category 1 rules expect at most one violation per method."
                            )
                        method_checks[method] = [check]

                    # Create GroupedViolationData for each method
                    for method, checks_for_method in method_checks.items():
                        key = RuleSourceKey(rule_name=rule, source_location=f"method:{method}")
                        # Fetch calltraces for each check
                        calltraces = []
                        for check in checks_for_method:
                            ct = processor.trace_extractor.get_calltrace(check)
                            if ct:
                                calltraces.append(ct)
                        result[key] = GroupedViolationData(
                            checks=checks_for_method,
                            calltraces=calltraces,
                            job_url=job_url,
                            rule_name=rule,
                            source_location=key.source_location,
                        )
                else:
                    # Category 2: Group by source location from calltrace extraction
                    # For Category 2 rules, source locations MUST exist - crash if not
                    if rule not in dc.source_locations_by_rule:
                        raise SourceLocationExtractionError(
                            f"Category 2 rule '{rule}' has no source locations in job {job_url}. "
                            f"This should not happen - please investigate the calltrace extraction logic."
                        )
                    locs = dc.source_locations_by_rule[rule]
                    if not locs or locs == ["<unknown>:0-0"]:
                        raise SourceLocationExtractionError(
                            f"Category 2 rule '{rule}' has unknown source location in job {job_url}. "
                            f"The calltrace extraction failed to find a valid source location."
                        )

                    # Group checks by source location
                    # Note: For Category 2, multiple checks can have the same source location
                    loc_checks: dict[str, list] = {}
                    for check in checks:
                        # We need to extract source location from each check
                        # Use the first matching location from the rule's locations list
                        check_loc = _get_check_source_location(check, locs, processor)
                        if check_loc not in loc_checks:
                            loc_checks[check_loc] = []
                        loc_checks[check_loc].append(check)

                    # Create GroupedViolationData for each location
                    for loc, checks_for_loc in loc_checks.items():
                        key = RuleSourceKey(rule_name=rule, source_location=loc)
                        calltraces = []
                        for check in checks_for_loc:
                            ct = processor.trace_extractor.get_calltrace(check)
                            if ct:
                                calltraces.append(ct)
                        result[key] = GroupedViolationData(
                            checks=checks_for_loc,
                            calltraces=calltraces,
                            job_url=job_url,
                            rule_name=rule,
                            source_location=loc,
                        )

        return result, passing_rules_by_checker

    except (DuplicateViolationError, SourceLocationExtractionError):
        # These are fatal errors - propagate them
        raise
    except Exception as e:
        if is_fatal_api_error(e):
            raise
        logger.warning(f"Could not analyze job {job_url}: {e}")
        return {}, {}


def _get_check_source_location(check, locs: list[str], processor: CheckerOutputProcessor) -> str:
    """Extract source location for a check in Category 2 rules.

    For Category 2 rules, we need to map each check to its source location.
    This uses the calltrace extraction logic to find the correct location.
    If no specific location can be determined, uses the first location from locs.
    """
    # Try to get the source location from the check's calltrace
    # The location should match one of the pre-extracted locations in locs
    try:
        extractor = CalltraceSourceExtractor(processor.trace_extractor)
        hook_type = get_hook_type(check.rule_name) if hasattr(check, 'rule_name') else None
        if hook_type:
            source_loc = extractor.extract_hook_source_location(check, hook_type, check.rule_name)
            if source_loc:
                return source_loc.location_key
    except Exception as e:
        logger.debug(f"Failed to extract source location for check: {e}")
        pass
    # Fall back to the first location if extraction fails
    return locs[0] if locs else "<unknown>:0-0"


async def async_get_violated_rules_for_job(
    job_url: str,
    use_cache: bool,
    semaphore: asyncio.Semaphore,
    checker_filter: str | None = None,
    rule_filter: str | None = None,
    is_autocvl: bool = False,
) -> tuple[str, tuple[dict[RuleSourceKey, GroupedViolationData], dict[str, set[str]]]]:
    """
    Async wrapper to get violated rules for a job with pre-grouped data.
    Returns tuple of (job_url, (grouped_violations_dict, passing_rules_by_checker)).
    """
    async with semaphore:
        return job_url, await asyncio.to_thread(
            get_violated_rules_for_job, job_url, use_cache, checker_filter, rule_filter, is_autocvl
        )


def _get_rule_family(rule_name: str) -> str:
    """Extract rule family for grouping same-confidence findings from the same checker."""
    if rule_name.startswith("input_validation_"):
        return "input_validation"
    if rule_name.startswith("oneTimeFunction"):
        return "oneTimeFunction"
    if rule_name.startswith("detect_"):
        return "detect"
    return rule_name


class AggregatedReportRuleEntry(BaseModel):
    """A single rule entry in the aggregated report JSON."""

    rule_name: str
    rule_family: str
    job_urls: list[str] = Field(description="Job URLs where this rule was violated")
    synthesis: SynthesisResult
    formatted_markdown: str = Field(description="Pre-rendered markdown for this rule's synthesis")
    # Source location and contract/method info (new fields for enhanced HTML report)
    source_location: str = Field(default="", description="file:lines or '<unknown>'")
    contracts: list[str] = Field(default_factory=list, description="Unique contracts with violations")
    methods_by_contract: dict[str, list[str]] = Field(
        default_factory=dict, description="Contract name -> list of method names"
    )
    job_url_by_contract: dict[str, str] = Field(
        default_factory=dict, description="Contract name -> job URL for linking"
    )
    vote_counts: tuple[int, int, int, int] | None = Field(
        default=None, description="Vote counts (n_yh, n_yl, n_nl, n_nh) for voting breakdown"
    )
    judgement_result: JudgementResult | None = Field(
        default=None, description="AIComposer validation result for high-confidence findings (score >= 80)"
    )
    impact_likelihood: ImpactLikelihoodResult | None = Field(
        default=None, description="Impact/likelihood assessment for confirmed issues (score >= 60)"
    )
    fix_result: FixGenerationResult | None = Field(
        default=None, description="AI-generated fix patch for confirmed issues (score >= 60)"
    )


class TokenUsageJSON(BaseModel):
    """Token usage statistics for the report."""

    total_input_tokens: int = Field(default=0, description="Total input tokens consumed")
    total_output_tokens: int = Field(default=0, description="Total output tokens consumed")
    total_cache_creation_tokens: int = Field(default=0, description="Tokens used for prompt cache creation")
    total_cache_read_tokens: int = Field(default=0, description="Tokens read from prompt cache")
    total_tokens: int = Field(default=0, description="Total tokens (input + output)")
    api_calls: int = Field(default=0, description="Number of API calls made")
    analysis_cache_hits: int = Field(default=0, description="Number of analysis cache hits")
    analysis_cache_misses: int = Field(default=0, description="Number of analysis cache misses")
    calltrace_analysis_tokens: int = Field(default=0, description="Tokens used for calltrace analysis (Step 1)")
    defect_analysis_tokens: int = Field(default=0, description="Tokens used for defect analysis (Step 2)")
    synthesis_tokens: int = Field(default=0, description="Tokens used for synthesis")
    validation_tokens: int = Field(default=0, description="Tokens used for validation (Step 3.5)")
    impact_likelihood_tokens: int = Field(default=0, description="Tokens used for impact/likelihood (Step 3.6)")
    fix_generation_tokens: int = Field(default=0, description="Tokens used for fix generation (Step 3.7)")
    estimated_cost_usd: float = Field(default=0.0, description="Estimated cost in USD")
    aicomposer_tokens: int = Field(default=0, description="Total tokens from AIComposer calls")
    aicomposer_cost_usd: float = Field(default=0.0, description="Estimated cost from AIComposer calls")
    aicomposer_calls: int = Field(default=0, description="Number of AIComposer API calls")
    claude_agent_sdk_tokens: int = Field(default=0, description="Total tokens from Claude Agent SDK (fix generation)")
    claude_agent_sdk_cost_usd: float = Field(default=0.0, description="Estimated cost from Claude Agent SDK calls")
    claude_agent_sdk_calls: int = Field(default=0, description="Number of Claude Agent SDK calls")
    prover_compute_total_seconds: float = Field(default=0.0, description="Total prover compute time in seconds")
    prover_compute_minutes: int = Field(default=0, description="Total prover compute time rounded up to nearest minute")
    prover_compute_cost_usd: float = Field(default=0.0, description="Prover compute cost at $0.0255/min")
    prover_job_count: int = Field(default=0, description="Number of prover jobs with metadata")

    @classmethod
    def from_stats(cls, stats: TokenUsageStats) -> "TokenUsageJSON":
        """Create from TokenUsageStats."""
        return cls(**stats.to_dict())


class AggregatedReportJSON(BaseModel):
    """Top-level JSON schema for an aggregated multi-analysis report."""

    generated_at: str = Field(description="ISO-8601 timestamp")
    job_urls: list[str] = Field(description="All job URLs analyzed")
    total_rules_analyzed: int
    iterations_per_rule: int
    entries: list[AggregatedReportRuleEntry] = Field(
        description="Per-rule entries, sorted by confidence desc, rule_family, rule_name"
    )
    token_usage: TokenUsageJSON = Field(
        default_factory=TokenUsageJSON,
        description="Token usage statistics for this analysis run"
    )


def render_aggregated_markdown(report: AggregatedReportJSON) -> str:
    """Render an AggregatedReportJSON to markdown."""
    lines: list[str] = []

    # Header
    lines.append("# Aggregated Multi-Analysis Report\n")
    lines.append(f"**Generated**: {report.generated_at}")
    lines.append(f"**Jobs analyzed**: {len(report.job_urls)}")
    lines.append(f"**Rules analyzed**: {report.total_rules_analyzed}")
    lines.append(f"**Iterations per rule**: {report.iterations_per_rule}\n")

    # Token usage stats
    tu = report.token_usage
    lines.append(f"**Token Usage**: {tu.api_calls} API calls, {tu.analysis_cache_hits} cache hits, "
                 f"{tu.total_tokens:,} tokens, ${tu.estimated_cost_usd:.4f} est. cost\n")
    lines.append("---\n")

    # Table of Contents
    lines.append("## Table of Contents\n")
    for i, entry in enumerate(report.entries, 1):
        anchor = f"rule-{i}"
        # Include source location in ToC if available
        source_display = f" `{entry.source_location}`" if entry.source_location else ""
        # Include contracts as badges
        contracts_display = ""
        if entry.contracts:
            contracts_display = " [" + ", ".join(entry.contracts) + "]"
        lines.append(
            f"{i}. [{entry.rule_name}](#{anchor}){source_display}{contracts_display}"
            f" — {entry.synthesis.computed_classification} ({entry.synthesis.computed_confidence_score}/100)"
        )
    lines.append("\n---\n")

    # Findings in sorted order
    for i, entry in enumerate(report.entries, 1):
        anchor = f"rule-{i}"
        lines.append(f'<a id="{anchor}"></a>\n')
        lines.append(f"## Rule: {entry.rule_name}\n")
        # Add source location if available
        if entry.source_location:
            lines.append(f"**Source:** `{entry.source_location}`\n")
        # Add contracts and methods info
        if entry.methods_by_contract:
            methods_parts = []
            for contract, methods in entry.methods_by_contract.items():
                job_url = entry.job_url_by_contract.get(contract, "")
                job_link = f" [Job]({job_url})" if job_url else ""
                methods_parts.append(f"**{contract}**: {', '.join(methods)}{job_link}")
            lines.append("**Affected Methods:**\n")
            for part in methods_parts:
                lines.append(f"- {part}")
            lines.append("")
        lines.append(entry.formatted_markdown)
        lines.append("\n---\n")

    return "\n".join(lines)


def _fetch_prover_compute_costs(job_urls: list[str]) -> None:
    """Fetch job metadata for all jobs and record prover compute costs."""
    import isodate
    from src.dashboard.sync_remote_jobs import fetch_job_metadata

    seen_job_ids: set[str] = set()
    total_seconds = 0.0
    num_jobs = 0

    for url in job_urls:
        job_id = extract_job_id_from_url(url)
        if job_id in seen_job_ids:
            continue
        seen_job_ids.add(job_id)

        try:
            metadata = fetch_job_metadata(job_id)
            total_run_time = metadata.get("total_run_time") if metadata else None
            if total_run_time:
                duration = isodate.parse_duration(total_run_time)
                total_seconds += duration.total_seconds()
                num_jobs += 1
            else:
                logger.debug(f"No total_run_time in metadata for job {job_id}")
        except Exception as e:
            logger.warning(f"Failed to fetch metadata for job {job_id}: {e}")

    if num_jobs > 0:
        get_global_tracker().record_prover_compute(total_seconds, num_jobs)
        logger.info(f"Prover compute: {total_seconds:.0f}s across {num_jobs} jobs, "
                     f"${get_global_tracker().get_stats().prover_compute_cost_usd:.4f} estimated cost")
    else:
        logger.info("Prover compute: no job metadata with run times found")


def process_aggregated(job_urls: List[str], args, ext_logger=None, autocvl_job_urls: set[str] | None = None):
    """Process multiple job URLs and aggregate results using multi-analysis flow.

    Runs the multi-analysis flow:
    1. Collect all violated rules from all jobs
    2. Run N iterations + synthesis for each violated rule
    3. Aggregate all synthesis results into final report

    Args:
        job_urls: List of job URLs to analyze
        args: Arguments object with the following attributes:
            - output: Output file path
            - no_cache: Disable caching if True
            - max_workers: Max parallel workers for AI analysis
            - iterations: Number of analysis iterations per rule
            - checker: Filter to specific checker type
            - rule: Filter to specific rule name
            - max_concurrent_rules: Max concurrent API tasks
        ext_logger: External logger for progress updates
        autocvl_job_urls: Set of job URLs that are autocvl jobs (bypass matcher loop)
    """
    if autocvl_job_urls is None:
        autocvl_job_urls = set()
    # Reset token usage tracker at the start of each run
    reset_global_tracker()

    use_cache = not getattr(args, 'no_cache', False)
    iterations = getattr(args, 'iterations', 3)
    checker_filter = getattr(args, 'checker', None)
    rule_filter = getattr(args, 'rule', None)
    max_concurrent_rules = getattr(args, 'max_concurrent_rules', DEFAULT_MAX_WORKERS)
    rag_db: str = getattr(args, 'rag_db', None) or get_default_rag_db()

    msg = f"Running multi-analysis flow ({iterations} iterations per rule)"
    if checker_filter:
        msg += f" for checker '{checker_filter}'"
    if rule_filter:
        msg += f" for rule '{rule_filter}'"
    logger.info(msg)

    # Determine output directory
    if args.output:
        output_base = Path(args.output).parent
        output_file = Path(args.output)
    else:
        output_base = Path(".certora_internal/multi_analysis_aggregate")
        output_base.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = output_base / f"aggregated_{timestamp}.md"

    output_base.mkdir(parents=True, exist_ok=True)

    # Step 1: Collect all violated rules from all jobs with pre-grouped data
    logger.info("Step 1: Collecting violated rules from all jobs...")
    # RuleSourceKey -> GroupedViolationData (with pre-grouped checks and calltraces)
    all_grouped_data: dict[RuleSourceKey, GroupedViolationData] = {}
    # Track passing rules by checker type across all jobs
    all_passing_rules_by_checker: dict[str, set[str]] = {}

    async def collect_all_violated_rules():
        # Create custom thread pool to override Python's default limit of min(32, cpu_count + 4)
        # This allows asyncio.to_thread() to actually use max_concurrent_rules workers
        executor = ThreadPoolExecutor(max_workers=max_concurrent_rules)
        loop = asyncio.get_running_loop()
        loop.set_default_executor(executor)

        sem = asyncio.Semaphore(max_concurrent_rules)
        progress = tqdm(total=len(job_urls), desc="Analyzing Prover jobs", unit="job")

        async def fetch_and_track(job_url: str):
            result = await async_get_violated_rules_for_job(
                job_url, use_cache, sem, checker_filter, rule_filter,
                is_autocvl=(job_url in autocvl_job_urls),
            )
            progress.update(1)
            return result

        tasks = [fetch_and_track(url) for url in job_urls]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        progress.close()
        return results

    step1_results = asyncio.run(collect_all_violated_rules())

    ignore_calltrace_errors = getattr(args, 'ignore_calltrace_errors', False)

    # Process results - now returns (grouped_data, passing_rules_by_checker)
    for result in step1_results:
        if isinstance(result, BaseException):
            # Check for fatal grouping errors - propagate them
            if isinstance(result, SourceLocationExtractionError):
                if ignore_calltrace_errors:
                    logger.warning(f"Skipping job due to calltrace error (--ignore-calltrace-errors): {result}")
                    continue
                raise result
            if isinstance(result, DuplicateViolationError):
                raise result
            logger.warning(f"Failed to analyze job: {result}")
            continue
        job_url, (grouped_data, passing_rules) = result
        # Merge passing rules from this job
        for checker_type, rules in passing_rules.items():
            if checker_type not in all_passing_rules_by_checker:
                all_passing_rules_by_checker[checker_type] = set()
            all_passing_rules_by_checker[checker_type].update(rules)
        for key, data in grouped_data.items():
            # Skip deep sanity rules
            if "deep_sanity" in key.rule_name.lower():
                continue
            # Store the grouped data (first occurrence wins for now)
            if key not in all_grouped_data:
                all_grouped_data[key] = data

    if not all_grouped_data:
        logger.info("No violated rules found in any of the provided jobs.")
        return

    logger.info(f"Found {len(all_grouped_data)} unique violated rule+location pairs across {len(job_urls)} jobs")

    # Step 1.1: Fetch prover compute costs
    logger.info(f"Step 1.1: Fetching prover compute costs for {len(job_urls)} jobs...")
    _fetch_prover_compute_costs(job_urls)

    # Step 1.5: Pre-extract code snippets for prompt caching
    # This extracts snippets once per finding, computes hashes, and sorts findings
    # so those sharing the same source code are processed consecutively.
    # This maximizes Claude's API-level prompt cache hits.
    logger.info("\nStep 1.5: Pre-extracting code snippets for prompt caching...")

    def precompute_snippets_for_group(data: GroupedViolationData) -> str:
        """Extract code snippets and return the formatted markdown. Downloads report if needed."""
        tarball_cache_dir = Path(DIR_CERTORA_INTERNAL) / DIR_TARBALL_CACHE
        tarball_cache_dir.mkdir(parents=True, exist_ok=True)

        job_id = extract_job_id_from_url(data.job_url)
        tarball_path = download_tarball(job_id, data.job_url, tarball_cache_dir)
        if tarball_path is None:
            return ""  # Can't extract snippets

        extract_dir = extract_from_tarball(tarball_path, job_id, Path(DIR_CERTORA_INTERNAL), subpath="")
        if extract_dir is None:
            return ""

        # Extract locations from calltraces
        all_locations = []
        for ct in data.calltraces:
            locations = ct.get("locations", [])
            all_locations.extend(locations)

        if not all_locations:
            return ""

        # Read and format code snippets
        return read_code_snippets(all_locations, str(extract_dir)) or ""

    # Compute snippets for all findings and store in GroupedViolationData
    snippet_hashes: dict[RuleSourceKey, str] = {}
    for key, data in tqdm(all_grouped_data.items(), desc="Extracting signal snippets"):
        snippets = precompute_snippets_for_group(data)
        # Store precomputed snippets in the GroupedViolationData
        data.precomputed_snippets = snippets
        # Compute hash for sorting
        snippet_hashes[key] = hashlib.sha256(snippets.encode()).hexdigest()[:16] if snippets else ""

    # Sort findings by (rule_name, snippet_hash, source_location) to group by shared snippets
    # This maximizes cache hits when consecutive findings share the same source code
    sorted_keys = sorted(
        all_grouped_data.keys(),
        key=lambda k: (k.rule_name, snippet_hashes.get(k, ""), k.source_location)
    )
    sorted_grouped_data = {k: all_grouped_data[k] for k in sorted_keys}
    all_grouped_data = sorted_grouped_data

    # Log grouping stats
    non_empty_hashes = [h for h in snippet_hashes.values() if h]
    unique_hashes = len(set(non_empty_hashes))
    logger.info(f"Extracted snippets for {len(non_empty_hashes)}/{len(all_grouped_data)} findings")
    logger.info(f"Found {unique_hashes} unique snippet groups (potential cache optimization)")

    # Log rules that passed (no violations) grouped by checker type
    if all_passing_rules_by_checker:
        total_passed = sum(len(rules) for rules in all_passing_rules_by_checker.values())
        logger.info(f"Rules with no violations ({total_passed} total):")
        for checker_type in sorted(all_passing_rules_by_checker.keys()):
            for rule_name in sorted(all_passing_rules_by_checker[checker_type]):
                logger.info(f"  [PASSED] {checker_type}: {rule_name}")

    # Step 2: Run multi-analysis for each rule+source_location (parallel with shared semaphore)
    logger.info(f"\nStep 2: Running multi-analysis for {len(all_grouped_data)} rule+location pairs...")

    async def process_all_rules():
        # Create custom thread pool to override Python's default limit of min(32, cpu_count + 4)
        executor = ThreadPoolExecutor(max_workers=max_concurrent_rules)
        loop = asyncio.get_running_loop()
        loop.set_default_executor(executor)

        sem = asyncio.Semaphore(max_concurrent_rules)
        total_iterations = len(all_grouped_data) * iterations
        progress = tqdm(total=total_iterations, desc="Analyzing signals", unit="iter")

        async def analyze_and_track(key: RuleSourceKey, data: GroupedViolationData):
            result = await async_run_multi_analysis_for_group(
                grouped_data=data,
                iterations=iterations,
                output_base_dir=Path(".certora_internal") / "rule_analyses",
                use_cache=use_cache,
                semaphore=sem,
                ext_logger=ext_logger,
                progress=progress,
                rag_db=rag_db,
            )
            return result

        tasks = [
            analyze_and_track(key, data)
            for key, data in all_grouped_data.items()
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        progress.close()
        return results

    step2_results = asyncio.run(process_all_rules())

    # (synthesis_file, RuleSourceKey)
    synthesis_entries: list[tuple[Path, RuleSourceKey]] = []
    for result in step2_results:
        if isinstance(result, BaseException):
            if isinstance(result, Exception) and is_fatal_api_error(result):
                raise result
            logger.warning(f"Rule analysis failed: {result}")
            continue
        synthesis_file, key = result
        if synthesis_file:
            synthesis_entries.append((synthesis_file, key))

    if not synthesis_entries:
        logger.warning("All multi-analyses failed.")
        return

    # Step 3: Create aggregated report from all syntheses
    logger.info(f"\nStep 3: Creating aggregated report from {len(synthesis_entries)} syntheses...")

    # Load structured data for each entry, including findings metadata
    # type for entries: (RuleSourceKey, result, contracts, methods_by_contract, job_url_by_contract, vote_counts, iter_dir)
    entries: list[tuple[RuleSourceKey, SynthesisResult, list[str], dict[str, list[str]], dict[str, str], tuple[int, int, int, int] | None, Path]] = []
    for synthesis_file, key in synthesis_entries:
        json_file = synthesis_file.with_suffix(".json")
        if json_file.exists():
            result = SynthesisResult.model_validate_json(json_file.read_text())
        else:
            # Fallback: read markdown directly (no JSON sidecar available)
            logger.warning(f"No JSON sidecar for {key.rule_name}, falling back to markdown")
            with open(synthesis_file, 'r') as sf:
                md_content = sf.read()
            # Create a minimal SynthesisResult for sorting purposes
            result = SynthesisResult(
                evidence_synthesis=md_content,
                consolidated_reasoning="",
                recommended_action="",
                computed_confidence_score=50,
                computed_classification="UNCERTAIN",
            )

        # Load findings metadata from iteration JSON sidecars for contracts/methods
        contracts: set[str] = set()
        methods_by_contract: dict[str, list[str]] = {}
        job_url_by_contract: dict[str, str] = {}

        # Reconstruct vote_counts from iteration outcomes
        n_yh, n_yl, n_nl, n_nh = 0, 0, 0, 0

        # Find iteration JSON files in the synthesis directory
        iter_dir = synthesis_file.parent
        failed_json_files = []
        for iter_json in sorted(iter_dir.glob("run_*.json")):
            try:
                with open(iter_json) as f:
                    iter_data = json.load(f)

                # Count vote outcomes
                outcome = iter_data.get("outcome_code", "NL")
                if outcome == "YH":
                    n_yh += 1
                elif outcome == "YL":
                    n_yl += 1
                elif outcome == "NL":
                    n_nl += 1
                elif outcome == "NH":
                    n_nh += 1

                for fm in iter_data.get("findings_metadata", []):
                    # Merge contracts
                    for c in fm.get("contracts", []):
                        contracts.add(c)
                    # Merge methods_by_contract
                    for c, methods in fm.get("methods_by_contract", {}).items():
                        if c not in methods_by_contract:
                            methods_by_contract[c] = []
                        for m in methods:
                            if m not in methods_by_contract[c]:
                                methods_by_contract[c].append(m)
            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse iteration JSON {iter_json}: {e}")
                failed_json_files.append(str(iter_json))
            except Exception as e:
                logger.warning(f"Failed to read iteration metadata from {iter_json}: {e}")
                failed_json_files.append(str(iter_json))
        if failed_json_files:
            logger.warning(f"Skipped {len(failed_json_files)} iteration files with errors for {key.rule_name}")

        # Build vote_counts tuple (None if no iterations found)
        total_votes = n_yh + n_yl + n_nl + n_nh
        vote_counts: tuple[int, int, int, int] | None = (n_yh, n_yl, n_nl, n_nh) if total_votes > 0 else None

        # Build job_url_by_contract (first job URL for each contract)
        grouped = all_grouped_data.get(key)
        rule_job_url = grouped.job_url if grouped else ""
        for c in contracts:
            if c not in job_url_by_contract and rule_job_url:
                job_url_by_contract[c] = rule_job_url

        entries.append((
            key, result, list(contracts),
            methods_by_contract, job_url_by_contract, vote_counts, iter_dir
        ))

    # Step 3.5: Run AIComposer validation for high-confidence findings
    high_confidence_entries = [
        (key, result, vote_counts, iter_dir)
        for key, result, _, _, _, vote_counts, iter_dir in entries
        if result.computed_confidence_score >= HIGH_CONFIDENCE_THRESHOLD
    ]

    # Dictionary to store validation results by RuleSourceKey
    validation_results: dict[RuleSourceKey, JudgementResult] = {}

    if high_confidence_entries:
        logger.info(f"\nStep 3.5: Running AIComposer validation for {len(high_confidence_entries)} high-confidence findings...")

        async def run_validations():
            sem = asyncio.Semaphore(max_concurrent_rules)
            progress = tqdm(total=len(high_confidence_entries), desc="Validating", unit="finding")

            async def validate_one(key: RuleSourceKey, result: SynthesisResult, vote_counts_tuple: tuple[int, int, int, int] | None, iter_dir_path: Path):
                async with sem:
                    validation_result = await asyncio.to_thread(
                        run_validation_for_entry,
                        key,
                        iter_dir_path,
                        vote_counts_tuple,
                        all_grouped_data.get(key),
                        use_cache,
                        rag_db,
                    )
                    progress.update(1)
                    return key, validation_result

            tasks = [
                validate_one(key, result, vote_counts, iter_dir)
                for key, result, vote_counts, iter_dir in high_confidence_entries
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            progress.close()
            return results

        validation_run_results = asyncio.run(run_validations())

        for result in validation_run_results:
            if isinstance(result, BaseException):
                logger.warning(f"Validation failed: {result}")
                continue
            key, judgement = result
            if judgement is not None:
                validation_results[key] = judgement
                change_marker = " ⚠️ CLASSIFICATION CHANGED" if judgement.classification_changed else ""
                logger.info(
                    f"  Validated {key.rule_name}: {judgement.is_defect} ({judgement.confidence}) "
                    f"→ {judgement.recomputed_score}/100 ({judgement.recomputed_classification}){change_marker}"
                )

    # Sort: descending confidence (primary), then group by family, then alphabetical by rule_name
    # Use RECOMPUTED score when judgement exists, otherwise original score
    def get_effective_score(entry: tuple) -> int:
        key = entry[0]
        result = entry[1]
        judgement = validation_results.get(key)
        if judgement is not None:
            return judgement.recomputed_score
        return result.computed_confidence_score

    # Step 3.6: Run impact/likelihood assessment for confirmed issues (effective score >= 60)
    impact_likelihood_entries = [
        (key, iter_dir)
        for key, result, _, _, _, vote_counts, iter_dir in entries
        if get_effective_score((key, result, None, None, None, vote_counts, iter_dir)) >= IMPACT_LIKELIHOOD_THRESHOLD
    ]

    impact_likelihood_results: dict[RuleSourceKey, ImpactLikelihoodResult] = {}

    if impact_likelihood_entries:
        logger.info(
            f"\nStep 3.6: Running impact/likelihood assessment for {len(impact_likelihood_entries)} confirmed issues..."
        )

        async def run_impact_likelihood():
            sem = asyncio.Semaphore(max_concurrent_rules)
            progress = tqdm(total=len(impact_likelihood_entries), desc="Assessing impact/likelihood", unit="finding")

            async def assess_one(key: RuleSourceKey, iter_dir_path: Path):
                async with sem:
                    il_result = await asyncio.to_thread(
                        run_impact_likelihood_for_entry,
                        key,
                        iter_dir_path,
                        validation_results.get(key),
                        all_grouped_data.get(key),
                        use_cache,
                        rag_db,
                    )
                    progress.update(1)
                    return key, il_result

            tasks = [assess_one(key, iter_dir) for key, iter_dir in impact_likelihood_entries]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            progress.close()
            return results

        il_run_results = asyncio.run(run_impact_likelihood())

        for result in il_run_results:
            if isinstance(result, BaseException):
                logger.warning(f"Impact/likelihood assessment failed: {result}")
                continue
            key, il_result = result
            if il_result is not None:
                impact_likelihood_results[key] = il_result
                logger.info(f"  {key.rule_name}: impact={il_result.impact}, likelihood={il_result.likelihood}")

    # Step 3.7: Generate fixes for confirmed issues (effective score >= 60)
    FIX_GENERATION_THRESHOLD = 60

    fix_eligible_entries = [
        (key, result, contracts_list, methods_by_contract, vote_counts, iter_dir)
        for key, result, contracts_list, methods_by_contract, _, vote_counts, iter_dir in entries
        if get_effective_score((key, result, None, None, None, vote_counts, iter_dir)) >= FIX_GENERATION_THRESHOLD
    ]

    fix_generation_results: dict[RuleSourceKey, FixGenerationResult] = {}

    project_dir = getattr(args, "project_dir", None)
    logger.info(f"\nStep 3.7: {len(fix_eligible_entries)}/{len(entries)} entries eligible "
                f"(threshold={FIX_GENERATION_THRESHOLD}), project_dir={project_dir}")
    for key, result, _, _, _, iter_dir in fix_eligible_entries:
        score = get_effective_score((key, result, None, None, None, None, iter_dir))
        logger.info(f"  Eligible: {key.rule_name} @ {key.source_location} (score={score})")

    if fix_eligible_entries and project_dir:
        logger.info(f"Step 3.7: Generating fixes for {len(fix_eligible_entries)} findings...")

        async def run_fix_generation():
            sem = asyncio.Semaphore(max_concurrent_rules)
            progress = tqdm(total=len(fix_eligible_entries), desc="Generating fixes", unit="finding")

            async def generate_one(key, result, contracts_list, mbc, vote_counts, iter_dir):
                async with sem:
                    grouped = all_grouped_data.get(key)
                    fix_result = await generate_fix_for_finding(
                        project_dir=Path(project_dir),
                        rule_name=key.rule_name,
                        source_location=key.source_location,
                        contracts=contracts_list,
                        methods_by_contract=mbc,
                        synthesis=result,
                        judgement=validation_results.get(key),
                        impact_likelihood=impact_likelihood_results.get(key),
                        precomputed_snippets=grouped.precomputed_snippets if grouped else None,
                        iter_dir=iter_dir,
                    )
                    progress.update(1)
                    return key, fix_result

            tasks = [
                generate_one(k, r, cl, mbc, vc, d)
                for k, r, cl, mbc, vc, d in fix_eligible_entries
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            progress.close()
            return results

        fg_results = asyncio.run(run_fix_generation())
        n_success, n_failed, n_no_patch = 0, 0, 0
        for result in fg_results:
            if isinstance(result, BaseException):
                n_failed += 1
                logger.warning(f"Fix generation failed: {result}")
                continue
            key, fix_result = result
            if fix_result is not None:
                n_success += 1
                fix_generation_results[key] = fix_result
                logger.info(f"  {key.rule_name}: fix generated -> {fix_result.patch_file}")
            else:
                n_no_patch += 1
                logger.info(f"  {key.rule_name}: fix generation returned None (no patch extracted)")
        logger.info(f"Step 3.7 summary: {n_success} succeeded, {n_failed} failed, {n_no_patch} no patch extracted")
    elif not fix_eligible_entries:
        logger.info("Step 3.7: skipped — no eligible entries")
    else:
        logger.info("Step 3.7: skipped — project_dir not available")

    entries.sort(key=lambda e: (-get_effective_score(e), _get_rule_family(e[0].rule_name), e[0].rule_name))

    # Get token usage statistics
    token_stats = get_global_tracker().get_stats()

    # Build JSON intermediate representation
    report_json = AggregatedReportJSON(
        generated_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        job_urls=list(job_urls),
        total_rules_analyzed=len(entries),
        iterations_per_rule=iterations,
        entries=[
            AggregatedReportRuleEntry(
                rule_name=key.rule_name,
                rule_family=_get_rule_family(key.rule_name),
                job_urls=[all_grouped_data[key].job_url] if key in all_grouped_data else [],
                synthesis=result,
                formatted_markdown=_format_synthesis_markdown(result, vote_counts),
                # Use source_location from the key (already known from aggregation)
                source_location=key.source_location if not key.is_unknown_location else "",
                contracts=contracts_list,
                methods_by_contract=methods_by_contract,
                job_url_by_contract=job_url_by_contract,
                vote_counts=vote_counts,
                judgement_result=validation_results.get(key),
                impact_likelihood=impact_likelihood_results.get(key),
                fix_result=fix_generation_results.get(key),
            )
            for key, result, contracts_list, methods_by_contract, job_url_by_contract, vote_counts, _ in entries
        ],
        token_usage=TokenUsageJSON.from_stats(token_stats),
    )

    # Write JSON (primary artifact)
    json_output_file = output_file.with_suffix(".json")
    with open(json_output_file, 'w') as f:
        f.write(report_json.model_dump_json(indent=2))
    logger.info(f"Aggregated JSON report written to: {json_output_file!s}")

    # Write Markdown (derived from JSON)
    md_output_file = output_file.with_suffix(".md")
    with open(md_output_file, 'w') as f:
        f.write(render_aggregated_markdown(report_json))
    logger.info(f"Aggregated markdown report written to: {md_output_file!s}")

    # Write token usage stats file
    tracker = get_global_tracker()
    stats_file = tracker.write_stats_file(output_base, "token_usage_stats.json")
    logger.info(f"Token usage stats written to: {stats_file!s}")
    logger.info(
        f"Token usage summary: {token_stats.api_calls} API calls, "
        f"{token_stats.total_tokens:,} tokens, "
        f"${token_stats.estimated_cost_usd:.4f} estimated cost"
    )
