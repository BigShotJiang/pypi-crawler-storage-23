"""
Base module for checker output processing.

Contains shared models, interfaces, and base implementations.
"""

from .checker_type import CheckerType
from .interfaces import CheckerModule, RuleMatcher
from .models import (
    CheckerFinding,
    CheckerReport,
    ConfidenceLevel,
    DefectVerdict,
    FailureContext,
    FinalFeedback,
    SourceLocation,
)

__all__ = [
    # Enums
    "CheckerType",
    "DefectVerdict",
    "ConfidenceLevel",
    # Models
    "SourceLocation",
    "FailureContext",
    "FinalFeedback",
    "CheckerFinding",
    "CheckerReport",
    # Interfaces
    "RuleMatcher",
    "CheckerModule",
]
