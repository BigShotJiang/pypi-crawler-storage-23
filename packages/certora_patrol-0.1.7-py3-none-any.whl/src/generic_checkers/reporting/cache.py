"""
Analysis result caching system.

Caches AI analysis results to avoid redundant API calls and save costs.
Uses human-readable filenames that encode job_id and rule_name for easy querying.

Filename format: {job_id}_{rule_name}_{content_hash}.json
Where:
- job_id: First 12 chars of job ID (from URL)
- rule_name: Clean rule name (phase differentiation is in the content hash)
- content_hash: First 8 chars of SHA256(prompt_hash + messages_hash + model + iteration + phase)
"""

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.utils.logger import logger

# Cache key component lengths
JOB_ID_TRUNCATION_LENGTH = 12
HASH_TRUNCATION_LENGTH = 8


def _sanitize_for_filename(s: str) -> str:
    """Sanitize a string for use in a filename. Replace non-alphanumeric chars with underscores."""
    return re.sub(r'[^a-zA-Z0-9_]', '_', s)


class AnalysisCache:
    """
    Cache for AI analysis results using human-readable filenames.

    Filenames encode job_id and rule_name for easy querying via glob.
    No database required - file existence is the index.
    """

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize the analysis cache.

        Args:
            cache_dir: Directory for cache storage. Defaults to .certora_internal/analysis_cache
        """
        if cache_dir is None:
            cache_dir = Path(".certora_internal") / "analysis_cache"

        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.analyses_dir = self.cache_dir / "analyses"
        self.analyses_dir.mkdir(exist_ok=True)

    def _make_filename(self, job_id: str, rule_name: str, content_hash: str) -> str:
        """
        Build filename from components.

        Args:
            job_id: First 12 chars of job ID
            rule_name: Full rule name (will be sanitized)
            content_hash: First 8 chars of content hash

        Returns:
            Filename string (without directory)
        """
        safe_job_id = job_id[:JOB_ID_TRUNCATION_LENGTH]
        safe_rule_name = _sanitize_for_filename(rule_name)
        safe_hash = content_hash[:HASH_TRUNCATION_LENGTH]
        return f"{safe_job_id}_{safe_rule_name}_{safe_hash}.json"

    def _parse_filename(self, filename: str) -> Optional[Dict[str, str]]:
        """
        Parse a cache filename into components.

        Args:
            filename: Filename to parse

        Returns:
            Dict with job_id, rule_name, content_hash or None if invalid
        """
        if not filename.endswith('.json'):
            return None

        basename = filename[:-5]  # Strip .json
        parts = basename.rsplit('_', 1)
        if len(parts) != 2:
            return None

        content_hash = parts[1]
        prefix = parts[0]

        # First JOB_ID_TRUNCATION_LENGTH chars are job_id, rest is rule_name
        min_prefix_len = JOB_ID_TRUNCATION_LENGTH + 1  # job_id + underscore
        if len(prefix) < min_prefix_len:
            return None

        job_id = prefix[:JOB_ID_TRUNCATION_LENGTH]
        rule_name = prefix[min_prefix_len:] if len(prefix) > min_prefix_len else ""

        return {
            "job_id": job_id,
            "rule_name": rule_name,
            "content_hash": content_hash
        }

    def compute_content_hash(
        self,
        prompt_hash: str,
        messages_hash: str,
        model_name: str,
        iteration: Optional[int] = None,
        snippets_hash: Optional[str] = None,
        phase: Optional[str] = None,
    ) -> str:
        """
        Compute content hash from analysis inputs.

        Args:
            prompt_hash: Hash of the prompt template
            messages_hash: Hash of the input messages
            model_name: AI model name
            iteration: Optional iteration index
            snippets_hash: Optional hash of code snippets (for cache invalidation when source changes)
            phase: Optional analysis phase value (for differentiating phases with the same rule_name)

        Returns:
            First 8 chars of SHA256 hash
        """
        key_components = {
            "prompt_hash": prompt_hash,
            "messages_hash": messages_hash,
            "model": model_name,
            "iteration": iteration,
            "snippets_hash": snippets_hash,
            "phase": phase,
        }
        key_str = json.dumps(key_components, sort_keys=True)
        return hashlib.sha256(key_str.encode()).hexdigest()[:HASH_TRUNCATION_LENGTH]

    def get(self, job_id: str, rule_name: str, content_hash: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve a cached analysis result.

        Args:
            job_id: Job ID (first 12 chars used)
            rule_name: Rule name
            content_hash: Content hash (first 8 chars used)

        Returns:
            Cached result dict, or None if not found
        """
        filename = self._make_filename(job_id, rule_name, content_hash)
        file_path = self.analyses_dir / filename

        if not file_path.exists():
            return None

        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            logger.warning(f"Cache file corrupted, removing: {file_path} ({e})")
            try:
                file_path.unlink()
            except OSError:
                pass
            return None
        except OSError as e:
            logger.warning(f"Failed to read cache file {file_path}: {e}")
            return None

    def set(
        self,
        job_id: str,
        rule_name: str,
        content_hash: str,
        result: Dict[str, Any],
    ):
        """
        Store an analysis result in the cache.

        Args:
            job_id: Job ID (first 12 chars used)
            rule_name: Rule name
            content_hash: Content hash (first 8 chars used)
            result: Analysis result to cache
        """
        filename = self._make_filename(job_id, rule_name, content_hash)
        file_path = self.analyses_dir / filename

        try:
            # Add metadata to result
            result_with_meta = {
                **result,
                "_cache_meta": {
                    "job_id": job_id[:JOB_ID_TRUNCATION_LENGTH],
                    "rule_name": rule_name,
                    "content_hash": content_hash[:HASH_TRUNCATION_LENGTH],
                    "created_at": datetime.now().isoformat(),
                }
            }
            with open(file_path, 'w') as f:
                json.dump(result_with_meta, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to cache analysis result: {e}")

    def find_by_job(self, job_id: str) -> List[Path]:
        """
        Find all cache entries for a given job.

        Args:
            job_id: Job ID (first 12 chars used for matching)

        Returns:
            List of matching file paths
        """
        safe_job_id = job_id[:JOB_ID_TRUNCATION_LENGTH]
        pattern = f"{safe_job_id}_*.json"
        return sorted(self.analyses_dir.glob(pattern))

    def find_by_rule(self, rule_name: str) -> List[Path]:
        """
        Find all cache entries for a given rule name.

        Args:
            rule_name: Rule name to search for

        Returns:
            List of matching file paths
        """
        safe_rule_name = _sanitize_for_filename(rule_name)
        pattern = f"*_{safe_rule_name}_*.json"
        return sorted(self.analyses_dir.glob(pattern))

    def find_by_job_and_rule(self, job_id: str, rule_name: str) -> List[Path]:
        """
        Find all cache entries for a given job and rule.

        Args:
            job_id: Job ID (first 12 chars used for matching)
            rule_name: Rule name to search for

        Returns:
            List of matching file paths
        """
        safe_job_id = job_id[:JOB_ID_TRUNCATION_LENGTH]
        safe_rule_name = _sanitize_for_filename(rule_name)
        pattern = f"{safe_job_id}_{safe_rule_name}_*.json"
        return sorted(self.analyses_dir.glob(pattern))

    def clear(self):
        """Clear all cached analyses."""
        try:
            for file_path in self.analyses_dir.glob("*.json"):
                file_path.unlink()
        except Exception as e:
            logger.warning(f"Failed to clear cache: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics by parsing filenames."""
        try:
            files = list(self.analyses_dir.glob("*.json"))
            total_entries = len(files)

            # Count unique jobs and rules
            jobs = set()
            rules = set()

            for f in files:
                parsed = self._parse_filename(f.name)
                if parsed:
                    jobs.add(parsed["job_id"])
                    rules.add(parsed["rule_name"])

            return {
                "total_entries": total_entries,
                "unique_jobs": len(jobs),
                "unique_rules": len(rules),
                "cache_dir": str(self.cache_dir)
            }
        except Exception:
            return {"error": "Could not retrieve stats"}

    def get_file_path(self, job_id: str, rule_name: str, content_hash: str) -> Path:
        """
        Get the file path for a cache entry (whether it exists or not).

        Args:
            job_id: Job ID (first 12 chars used)
            rule_name: Rule name
            content_hash: Content hash (first 8 chars used)

        Returns:
            Path to the cache file
        """
        filename = self._make_filename(job_id, rule_name, content_hash)
        return self.analyses_dir / filename


# Global cache instance
_global_cache: Optional[AnalysisCache] = None


def get_global_cache() -> AnalysisCache:
    """Get the global cache instance (singleton)."""
    global _global_cache
    if _global_cache is None:
        _global_cache = AnalysisCache()
    return _global_cache
