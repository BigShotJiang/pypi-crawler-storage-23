"""
Privileged Operations Checker module.

Detects access control issues and identifies functions that should be privileged.
"""

from .checker import PrivilegedOperationsChecker
from .matcher import PrivilegedOperationsMatcher

__all__ = [
    "PrivilegedOperationsChecker",
    "PrivilegedOperationsMatcher",
]
