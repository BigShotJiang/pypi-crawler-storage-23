"""
Rule matcher for Privileged Operations Checker.

Identifies rules that detect access control issues.
"""

from typing import Dict, List, Optional

from ...base.checker_type import CheckerType
from ...base.interfaces import RuleMatcher


class PrivilegedOperationsMatcher(RuleMatcher):
    """Matcher for Privileged Operations Checker rules.

    Covers rules that detect access control issues:
    - privilegedOperation: Tests if a function can only be called by one address
    - detect_privileged_writes: Tests if storage writes are privileged (single-writer)
    - detect_time_sensitive_writes: Tests if writes depend on block timestamp/number
    """

    RULE_PATTERNS: List[str] = [
        "privilegedOperation",
        "detect_privileged_writes",
        "detect_time_sensitive_writes",
    ]

    ASSERT_PATTERNS: Dict[str, str] = {
        "not privileged operation": "not_privileged",
        "another address can call method": "not_privileged",
        "Write to storage slot is different": "non_privileged_write",
    }

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.PRIVILEGED_OPERATIONS

    @property
    def rule_patterns(self) -> List[str]:
        return self.RULE_PATTERNS

    def matches(self, rule_name: str) -> bool:
        return any(pattern in rule_name for pattern in self.RULE_PATTERNS)

    def extract_assert_type(self, assert_message: str) -> Optional[str]:
        if not assert_message:
            return None
        for pattern, assert_type in self.ASSERT_PATTERNS.items():
            if pattern in assert_message:
                return assert_type
        return None
