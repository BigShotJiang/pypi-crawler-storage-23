"""
Generic Checker module.

Handles generic verification rules that don't fit into specialized checker categories.
"""

from .checker import GenericChecker
from .matcher import GenericMatcher

__all__ = [
    "GenericChecker",
    "GenericMatcher",
]
