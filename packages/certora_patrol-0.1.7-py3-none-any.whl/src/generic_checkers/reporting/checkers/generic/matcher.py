"""
Rule matcher for Generic Checker rules.

Handles rules that don't fit into specialized checker categories.
"""

from typing import Dict, List, Optional

from ...base.checker_type import CheckerType
from ...base.interfaces import RuleMatcher


class GenericMatcher(RuleMatcher):
    """Matcher for Generic Checker rules.

    Handles rules that don't fit into specialized categories.
    Matches rules based on j2 template availability in prompts/ directory.
    """

    RULE_PATTERNS: List[str] = [
        # Rules with exact template name matches
        "failing_CALL_leads_to_revert",
        "nonGettersThatNeverRevert",
        "safeCasting",
        "msg_value_in_loop",
        "view_reentrancy",

        # Pattern matches (templates use snake_case, rules use camelCase)
        "oneTimeFunction",  # Matches oneTimeFunctionGlobalAnyInput, oneTimeFunctionPerUserSameInput, etc.
        "noSelfCalls",      # Template is self_calls, rule is noSelfCalls
    ]

    # Assert patterns map message substrings to assert types
    ASSERT_PATTERNS: Dict[str, str] = {
        # Add patterns as needed for generic rules
    }

    @property
    def checker_type(self) -> CheckerType:
        return CheckerType.GENERIC

    @property
    def rule_patterns(self) -> List[str]:
        return self.RULE_PATTERNS

    def matches(self, rule_name: str) -> bool:
        return any(pattern in rule_name for pattern in self.RULE_PATTERNS)

    def extract_assert_type(self, assert_message: str) -> Optional[str]:
        if not assert_message:
            return None
        for pattern, assert_type in self.ASSERT_PATTERNS.items():
            if pattern in assert_message:
                return assert_type
        return None
