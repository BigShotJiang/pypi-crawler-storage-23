"""
Checker modules for different verification rule types.

Each checker module provides:
- A RuleMatcher for identifying rules belonging to that checker
- A CheckerModule with extraction and formatting logic
- False alarm patterns for common non-issues
"""

from typing import Dict, List

from ..base.checker_type import CheckerType
from ..base.interfaces import CheckerModule, RuleMatcher
from .external_call import ExternalCallChecker
from .generic import GenericChecker
from .input_validation import InputValidationChecker
from .privileged_operations import PrivilegedOperationsChecker

# Registry of all available checker modules
ALL_CHECKERS: List[CheckerModule] = [
    ExternalCallChecker(),
    PrivilegedOperationsChecker(),
    InputValidationChecker(),
    GenericChecker(),
]

# Map of checker type to checker module
CHECKER_REGISTRY: Dict[CheckerType, CheckerModule] = {checker.checker_type: checker for checker in ALL_CHECKERS}


def get_checker(checker_type: CheckerType | str) -> CheckerModule:
    """Get checker module by type."""
    if isinstance(checker_type, str):
        checker_type = CheckerType(checker_type)
    if checker_type not in CHECKER_REGISTRY:
        raise ValueError(f"Unknown checker type: {checker_type}")
    return CHECKER_REGISTRY[checker_type]


def get_all_matchers() -> List[RuleMatcher]:
    """Get all rule matchers from registered checkers."""
    return [checker.matcher for checker in ALL_CHECKERS]


__all__ = [
    "ALL_CHECKERS",
    "CHECKER_REGISTRY",
    "get_checker",
    "get_all_matchers",
    "ExternalCallChecker",
    "PrivilegedOperationsChecker",
    "InputValidationChecker",
    "GenericChecker",
]
