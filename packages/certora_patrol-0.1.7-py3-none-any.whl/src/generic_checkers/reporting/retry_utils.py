"""
Retry logic for Claude API calls.

Handles transient failures, rate limiting, and overload with exponential backoff.
"""

import functools
import os
import random
import time
from typing import Any, Callable, Optional

from src.utils.logger import logger


# Configurable retry settings from environment
MAX_RETRIES = int(os.environ.get("CERTORA_MAX_RETRIES", "3"))
INITIAL_BACKOFF = float(os.environ.get("CERTORA_INITIAL_BACKOFF", "1.0"))
MAX_BACKOFF = float(os.environ.get("CERTORA_MAX_BACKOFF", "8.0"))


def is_fatal_api_error(exception: Exception) -> bool:
    """
    Determine if an exception is a fatal API error that should NOT be retried or swallowed.

    403 (Forbidden), 401 (Unauthorized), and similar auth errors indicate a configuration
    problem that won't resolve with retries. These must propagate immediately.

    Args:
        exception: The exception that was raised

    Returns:
        True if the error is fatal and must not be retried
    """
    error_msg = str(exception).lower()

    if "403" in error_msg or "forbidden" in error_msg:
        return True
    if "401" in error_msg or "unauthorized" in error_msg or "authentication" in error_msg:
        return True
    if "permission" in error_msg and "denied" in error_msg:
        return True

    return False


def should_retry_error(exception: Exception) -> bool:
    """
    Determine if an exception should trigger a retry.

    Args:
        exception: The exception that was raised

    Returns:
        True if the error is retryable
    """
    # Fatal errors must never be retried
    if is_fatal_api_error(exception):
        return False

    error_msg = str(exception).lower()

    # API rate limiting (429)
    if "429" in error_msg or "rate" in error_msg or "too many requests" in error_msg:
        return True

    # API overload (529, 503)
    if "529" in error_msg or "503" in error_msg or "overload" in error_msg:
        return True

    # Connection errors
    if any(keyword in error_msg for keyword in [
        "connection",
        "timeout",
        "timed out",
        "network",
        "unreachable",
        "refused"
    ]):
        return True

    # Anthropic-specific errors
    if "anthropic" in error_msg and any(keyword in error_msg for keyword in [
        "error",
        "failed",
        "unavailable"
    ]):
        return True

    return False


def calculate_backoff(attempt: int, base: float = INITIAL_BACKOFF, max_wait: float = MAX_BACKOFF) -> float:
    """
    Calculate exponential backoff with jitter.

    Args:
        attempt: Current attempt number (0-indexed)
        base: Base backoff time in seconds
        max_wait: Maximum wait time in seconds

    Returns:
        Wait time in seconds
    """
    # Exponential backoff: base * 2^attempt
    wait_time = base * (2 ** attempt)

    # Cap at max_wait
    wait_time = min(wait_time, max_wait)

    # Add jitter (±25%)
    jitter = wait_time * 0.25 * (2 * random.random() - 1)
    wait_time += jitter

    return max(0, wait_time)


def retry_on_api_errors(
    max_attempts: int = MAX_RETRIES,
    base_backoff: float = INITIAL_BACKOFF,
    max_backoff: float = MAX_BACKOFF,
    log_func: Optional[Callable[[str], None]] = None
) -> Callable:
    """
    Decorator that retries a function on API errors with exponential backoff.

    Args:
        max_attempts: Maximum number of retry attempts
        base_backoff: Initial backoff time in seconds
        max_backoff: Maximum backoff time in seconds
        log_func: Optional logging function for retry messages

    Returns:
        Decorated function that retries on API errors

    Example:
        @retry_on_api_errors(max_attempts=3)
        def call_api():
            return api.analyze(data)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_exception = None

            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)

                except Exception as e:
                    last_exception = e

                    # Check if we should retry
                    if not should_retry_error(e):
                        # Not a retryable error, fail immediately
                        raise

                    # Check if we have retries left
                    if attempt >= max_attempts - 1:
                        # Last attempt, raise the error
                        raise

                    # Calculate backoff
                    wait_time = calculate_backoff(attempt, base_backoff, max_backoff)

                    # Log retry attempt
                    msg = (
                        f"API error on attempt {attempt + 1}/{max_attempts}: {e}\n"
                        f"Retrying in {wait_time:.1f}s..."
                    )
                    if log_func:
                        log_func(msg)
                    else:
                        logger.debug(f"  {msg}")

                    # Wait before retry
                    time.sleep(wait_time)

            # Should never reach here, but just in case
            if last_exception:
                raise last_exception
            raise RuntimeError("Retry logic failed without raising exception")

        return wrapper
    return decorator
