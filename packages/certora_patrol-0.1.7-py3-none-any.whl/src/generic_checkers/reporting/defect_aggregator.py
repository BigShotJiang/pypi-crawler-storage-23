"""
Bayesian aggregation of LLM defect evaluations.

Aggregates YES/NO + HIGH/LOW responses from multiple iterations
into a posterior probability that a defect exists.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from .base.models import ConfidenceLevel, DefectVerdict


@dataclass
class DefectAggregator:
    """
    Aggregate up to N independent LLM evaluations into P(defect exists).

    You provide:
      - prior_no_defect: P(~D) prior
      - p_defect_given_outcome: mapping outcome -> P(D | outcome)

    Outcomes are:
      - "YH" = yes, high confidence
      - "YL" = yes, low confidence
      - "NL" = no,  low confidence
      - "NH" = no,  high confidence

    Usage:
        agg = DefectAggregator(
            prior_no_defect=0.95,
            p_defect_given_outcome={"YH": 0.3, "YL": 0.2, "NL": 0.025, "NH": 0.01},
        )
        p = agg.posterior_from_counts(n_yh=2, n_yl=0, n_nl=0, n_nh=1)
        print(p)
    """

    prior_no_defect: float = 0.95
    p_defect_given_outcome: Dict[str, float] = field(default_factory=lambda: {
        "YH": 0.3, "YL": 0.2, "NL": 0.025, "NH": 0.01
    })

    def __post_init__(self) -> None:
        if not (0.0 < self.prior_no_defect < 1.0):
            raise ValueError("prior_no_defect must be in (0,1).")

        required = {"YH", "YL", "NL", "NH"}
        missing = required - set(self.p_defect_given_outcome.keys())
        if missing:
            raise ValueError(f"Missing outcomes in p_defect_given_outcome: {sorted(missing)}")

        for k in required:
            p = self.p_defect_given_outcome[k]
            if not (0.0 < p < 1.0):
                raise ValueError(f"P(D|{k}) must be in (0,1); got {p} for {k}")

    @property
    def prior_defect(self) -> float:
        return 1.0 - self.prior_no_defect

    @property
    def prior_odds(self) -> float:
        # O0 = P(D)/P(~D)
        return self.prior_defect / self.prior_no_defect

    def outcome_odds(self, outcome: str) -> float:
        """Odds O(D|outcome) from P(D|outcome)."""
        p = self.p_defect_given_outcome[outcome]
        return p / (1.0 - p)

    def lr(self, outcome: str) -> float:
        """
        Likelihood ratio implied by your P(D|outcome) and your prior:
          LR(outcome) = O(D|outcome) / O(D)
        """
        return self.outcome_odds(outcome) / self.prior_odds

    def posterior_from_counts(self, n_yh: int, n_yl: int, n_nl: int, n_nh: int) -> float:
        """
        Compute posterior P(D | all outcomes) given counts of each outcome,
        assuming conditional independence between runs.

        Args:
            n_yh: Count of YES + HIGH confidence responses
            n_yl: Count of YES + LOW confidence responses
            n_nl: Count of NO + LOW confidence responses
            n_nh: Count of NO + HIGH confidence responses

        Returns:
            Posterior probability P(defect exists | all outcomes)
        """
        for name, n in [("n_yh", n_yh), ("n_yl", n_yl), ("n_nl", n_nl), ("n_nh", n_nh)]:
            if n < 0:
                raise ValueError(f"{name} must be >= 0; got {n}")

        # Posterior odds: O = O0 * Π LR(outcome)^count
        O = self.prior_odds
        O *= self.lr("YH") ** n_yh
        O *= self.lr("YL") ** n_yl
        O *= self.lr("NL") ** n_nl
        O *= self.lr("NH") ** n_nh

        # Convert odds to probability: p = O / (1+O)
        return O / (1.0 + O)

    def count_outcomes(self, results: List[Any]) -> Tuple[int, int, int, int]:
        """
        Count outcome codes from a list of IterationResult-like objects.

        Args:
            results: List of objects with is_defect (DefectVerdict or "YES"/"NO")
                     and confidence (ConfidenceLevel or "HIGH"/"LOW")

        Returns:
            Tuple of (n_yh, n_yl, n_nl, n_nh)
        """
        n_yh, n_yl, n_nl, n_nh = 0, 0, 0, 0
        for r in results:
            # Handle both enum and string values
            is_defect = getattr(r, 'is_defect', None)
            if is_defect is None and hasattr(r, 'get'):
                is_defect = r.get('is_defect')
            is_yes = is_defect == DefectVerdict.YES or is_defect == "YES"

            confidence = getattr(r, 'confidence', None)
            if confidence is None and hasattr(r, 'get'):
                confidence = r.get('confidence')
            is_high = confidence == ConfidenceLevel.HIGH or confidence == "HIGH"

            if is_yes:
                if is_high:
                    n_yh += 1
                else:
                    n_yl += 1
            else:
                if is_high:
                    n_nh += 1
                else:
                    n_nl += 1

        return n_yh, n_yl, n_nl, n_nh


# Default aggregator instance with calibrated parameters
DEFAULT_AGGREGATOR = DefectAggregator()


def compute_confidence_score(n_yh: int, n_yl: int, n_nl: int, n_nh: int) -> int:
    """
    Compute confidence score (0-100) from outcome counts using default aggregator.

    Args:
        n_yh: Count of YES + HIGH confidence responses
        n_yl: Count of YES + LOW confidence responses
        n_nl: Count of NO + LOW confidence responses
        n_nh: Count of NO + HIGH confidence responses

    Returns:
        Integer confidence score 0-100
    """
    posterior = DEFAULT_AGGREGATOR.posterior_from_counts(n_yh, n_yl, n_nl, n_nh)
    return int(posterior * 100)
