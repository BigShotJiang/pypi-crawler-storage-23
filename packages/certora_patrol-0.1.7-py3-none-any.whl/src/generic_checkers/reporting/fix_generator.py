"""
AI-powered fix generation for confirmed vulnerabilities.

Uses the Claude Agent SDK to explore the project source code, understand
the vulnerability in context, and generate a unified diff patch as a suggested fix.
"""

import asyncio
import re
from pathlib import Path

from pydantic import BaseModel, Field

from src.utils.logger import logger

from .synthesize_analyses import SynthesisResult


class FixGenerationResult(BaseModel):
    """Result from AI-generated fix for a confirmed vulnerability."""

    patch_content: str = Field(description="Unified diff content")
    patch_file: str = Field(description="Path to saved .patch file (relative to project)")
    explanation: str = Field(description="Brief explanation of the fix")
    model_used: str = Field(description="Model ID used for generation")
    total_cost_usd: float | None = Field(default=None, description="Total cost in USD reported by the agent SDK")


def _build_fix_prompt(
    rule_name: str,
    source_location: str,
    contracts: list[str],
    methods_by_contract: dict[str, list[str]],
    synthesis: SynthesisResult,
    judgement: object | None,
    impact_likelihood: object | None,
    precomputed_snippets: str | None,
) -> str:
    """Build the prompt for the fix generation agent."""
    parts: list[str] = []

    parts.append("You are a smart contract security expert. A formal verification tool has identified a vulnerability.")
    parts.append("Your task: explore the project source code, understand the vulnerability, and produce a fix.")
    parts.append("")

    parts.append(f"## Finding: {rule_name}")
    parts.append(f"**Source Location:** {source_location}")
    parts.append(f"**Classification:** {synthesis.computed_classification} ({synthesis.computed_confidence_score}/100)")
    parts.append("")

    if contracts:
        parts.append(f"**Affected Contracts:** {', '.join(contracts)}")
    if methods_by_contract:
        for contract, methods in methods_by_contract.items():
            parts.append(f"- **{contract}**: {', '.join(methods)}")
    parts.append("")

    parts.append("## Evidence Synthesis")
    parts.append(synthesis.evidence_synthesis)
    parts.append("")

    if synthesis.consolidated_reasoning:
        parts.append("## Consolidated Reasoning")
        parts.append(synthesis.consolidated_reasoning)
        parts.append("")

    if synthesis.recommended_action:
        parts.append("## Recommended Action")
        parts.append(synthesis.recommended_action)
        parts.append("")

    if judgement is not None:
        parts.append("## Validation Judgement")
        jr = judgement
        parts.append(f"Verdict: {jr.is_defect} ({jr.confidence} confidence)")  # type: ignore[union-attr]
        parts.append(f"Reasoning: {jr.reasoning}")  # type: ignore[union-attr]
        parts.append("")

    if impact_likelihood is not None:
        il = impact_likelihood
        parts.append("## Impact & Likelihood")
        parts.append(f"Impact: {il.impact}, Likelihood: {il.likelihood}")  # type: ignore[union-attr]
        parts.append(f"Reasoning: {il.reasoning}")  # type: ignore[union-attr]
        parts.append("")

    if precomputed_snippets:
        parts.append("## Relevant Code Snippets (from calltraces)")
        parts.append(precomputed_snippets)
        parts.append("")

    parts.append("## Instructions")
    parts.append(
        "1. Use the available tools (Read, Glob, Grep) to explore the project and understand the vulnerability."
    )
    parts.append("2. Identify the minimal code change needed to fix the vulnerability.")
    parts.append("3. Output your fix as a unified diff (patch format) that can be applied with `git apply`.")
    parts.append("4. Before the diff, provide a brief explanation of the fix (2-3 sentences).")
    parts.append("")
    parts.append("Format your final answer as:")
    parts.append("EXPLANATION: <your brief explanation>")
    parts.append("")
    parts.append("```diff")
    parts.append("<your unified diff here>")
    parts.append("```")

    return "\n".join(parts)


def _extract_patch_from_messages(messages: list) -> tuple[str, str]:
    """Extract the unified diff and explanation from agent messages.

    Returns (patch_content, explanation).
    """
    from claude_agent_sdk import AssistantMessage, TextBlock

    # Collect all text from assistant messages (use last one with diff content)
    all_text_blocks: list[str] = []
    for msg in messages:
        if isinstance(msg, AssistantMessage):
            for block in msg.content:
                if isinstance(block, TextBlock) and block.text.strip():
                    all_text_blocks.append(block.text)

    if not all_text_blocks:
        return "", ""

    # Search from the end for the diff block
    patch_content = ""
    explanation = ""

    for text in reversed(all_text_blocks):
        # Look for ```diff ... ``` block
        diff_match = re.search(r"```diff\s*\n(.*?)```", text, re.DOTALL)
        if diff_match:
            patch_content = diff_match.group(1).strip()
            # Look for explanation
            expl_match = re.search(r"EXPLANATION:\s*(.*?)(?:\n\n|```)", text, re.DOTALL)
            if expl_match:
                explanation = expl_match.group(1).strip()
            else:
                # Take text before the diff block as explanation
                before_diff = text[: diff_match.start()].strip()
                if before_diff:
                    # Take last paragraph
                    paragraphs = before_diff.split("\n\n")
                    explanation = paragraphs[-1].strip()
            break

    # Fallback: look for raw diff lines (--- / +++ / @@)
    if not patch_content:
        for text in reversed(all_text_blocks):
            lines = text.split("\n")
            diff_lines = []
            in_diff = False
            for line in lines:
                if line.startswith("---") or line.startswith("+++") or line.startswith("@@"):
                    in_diff = True
                if in_diff:
                    diff_lines.append(line)
                    if not line.strip() and diff_lines:
                        # End of diff hunk
                        pass
            if diff_lines:
                patch_content = "\n".join(diff_lines)
                break

    return patch_content, explanation


def _sanitize_filename(name: str) -> str:
    """Sanitize a rule name for use as a filename."""
    return re.sub(r"[^\w\-.]", "_", name)


async def generate_fix_for_finding(
    project_dir: Path,
    rule_name: str,
    source_location: str,
    contracts: list[str],
    methods_by_contract: dict[str, list[str]],
    synthesis: SynthesisResult,
    judgement: object | None,
    impact_likelihood: object | None,
    precomputed_snippets: str | None,
    iter_dir: Path,
) -> FixGenerationResult | None:
    """Generate an AI-powered fix for a confirmed vulnerability.

    Uses the Claude Agent SDK to explore the project, understand the vulnerability,
    and produce a unified diff patch.

    Args:
        project_dir: Path to the project root directory.
        rule_name: Name of the violated rule.
        source_location: Source location string (file:lines).
        contracts: List of affected contract names.
        methods_by_contract: Contract -> list of method names.
        synthesis: The synthesis result from multi-analysis.
        judgement: JudgementResult from validation pass (if available).
        impact_likelihood: ImpactLikelihoodResult (if available).
        precomputed_snippets: Pre-extracted code snippets from calltraces.
        iter_dir: Directory to save the .patch file.

    Returns:
        FixGenerationResult if a patch was generated, None otherwise.
    """
    from claude_agent_sdk import AssistantMessage, ClaudeAgentOptions, TextBlock, query

    model = "claude-sonnet-4-20250514"

    logger.info(f"[Fix generation] Starting for rule={rule_name}, source={source_location}, "
                f"project_dir={project_dir}, model={model}")

    prompt = _build_fix_prompt(
        rule_name=rule_name,
        source_location=source_location,
        contracts=contracts,
        methods_by_contract=methods_by_contract,
        synthesis=synthesis,
        judgement=judgement,
        impact_likelihood=impact_likelihood,
        precomputed_snippets=precomputed_snippets,
    )
    logger.info(f"[Fix generation] {rule_name}: prompt built ({len(prompt)} chars)")

    options = ClaudeAgentOptions(
        model=model,
        max_thinking_tokens=16000,
        allowed_tools=["Read", "Glob", "Grep"],
        max_turns=8,
        cwd=str(project_dir),
        permission_mode="bypassPermissions",
        max_buffer_size=10 * 1024 * 1024,  # 10 MB – default 1 MB is too small for large agent responses
    )

    messages: list = []
    logger.info(f"[Fix generation] {rule_name}: calling agent SDK...")
    try:
        async with asyncio.timeout(300):  # 5 min per finding
            async for message in query(prompt=prompt, options=options):
                messages.append(message)
    except TimeoutError:
        logger.warning(f"[Fix generation] {rule_name}: timed out after 5 minutes")
        return None
    except Exception as e:
        logger.warning(f"[Fix generation] {rule_name}: agent SDK exception ({type(e).__name__}): {e}")
        return None

    logger.info(f"[Fix generation] {rule_name}: agent returned {len(messages)} messages")

    # Extract usage from ResultMessage and record in global tracker
    from claude_agent_sdk import ResultMessage
    from .token_usage import AnalysisPhase, get_global_tracker

    result_message_cost: float | None = None
    for msg in messages:
        if isinstance(msg, ResultMessage) and msg.usage:
            tracker = get_global_tracker()
            tracker.record_api_usage(
                phase=AnalysisPhase.FIX_GENERATION,
                rule_name=rule_name,
                iteration_index=None,
                input_tokens=msg.usage.get("input_tokens", 0),
                output_tokens=msg.usage.get("output_tokens", 0),
                cache_creation_input_tokens=msg.usage.get("cache_creation_input_tokens", 0),
                cache_read_input_tokens=msg.usage.get("cache_read_input_tokens", 0),
                model=model,
                source="claude_agent_sdk",
            )
            result_message_cost = msg.total_cost_usd
            break

    # Log message types and text block count for diagnostics
    text_blocks: list[str] = []
    for msg in messages:
        if isinstance(msg, AssistantMessage):
            for block in msg.content:
                if isinstance(block, TextBlock) and block.text.strip():
                    text_blocks.append(block.text)
    logger.info(f"[Fix generation] {rule_name}: found {len(text_blocks)} text blocks in agent output")

    patch_content, explanation = _extract_patch_from_messages(messages)

    if not patch_content:
        # Log what the agent actually said so we can diagnose
        for i, text in enumerate(text_blocks):
            logger.info(f"[Fix generation] {rule_name}: text block {i}: {text}")
        logger.warning(f"[Fix generation] {rule_name}: no diff patch found in agent output")
        return None

    # Save patch file
    sanitized_name = _sanitize_filename(rule_name)
    patch_filename = f"{sanitized_name}.patch"
    patch_path = iter_dir / patch_filename
    patch_path.write_text(patch_content + "\n")

    patch_lines = patch_content.count("\n") + 1
    logger.info(f"[Fix generation] {rule_name}: patch saved to {patch_path} "
                f"({patch_lines} lines, {len(patch_content)} chars)")

    return FixGenerationResult(
        patch_content=patch_content,
        patch_file=str(patch_path),
        explanation=explanation or "Fix generated by AI analysis.",
        model_used=model,
        total_cost_usd=result_message_cost,
    )
