"""
Cached wrapper around analyze_with_calltraces for cost savings.

Provides a unified caching layer that can be used by both checker reporting
and standalone violation analysis flows.
"""

import hashlib
import os
import re
from dataclasses import replace
from typing import Any, List, Optional, Tuple

from pydantic import BaseModel

from src.utils.llm_debug import dump_llm_input, dump_llm_output
from src.utils.logger import logger

from .cache import AnalysisCache, get_global_cache
from .token_usage import AnalysisPhase, get_global_tracker

# AIComposer model used for pricing calculations
AICOMPOSER_MODEL = "claude-sonnet-4-5-20250929"

# Constants for recursion limit retry logic
RECURSION_LIMIT_INCREMENT = 30
MAX_RECURSION_RETRIES = 2

# Regex to match: "Recursion limit of X reached without hitting a stop condition"
RECURSION_LIMIT_ERROR_PATTERN = re.compile(r"Recursion limit of \d+ reached without hitting a stop condition")


def _is_recursion_limit_error(exception: Exception) -> bool:
    """Check if exception is a graph recursion limit error."""
    return RECURSION_LIMIT_ERROR_PATTERN.search(str(exception)) is not None


def _record_aicomposer_usage(
    usage_dict: dict[str, int],
    phase: AnalysisPhase,
    rule_name: str,
    iteration_index: int | None,
) -> None:
    """Feed AIComposer's accumulated token_usage dict into the global tracker."""
    if not usage_dict:
        return
    tracker = get_global_tracker()
    tracker.record_api_usage(
        phase=phase,
        rule_name=rule_name,
        iteration_index=iteration_index,
        input_tokens=usage_dict.get("input_tokens", 0),
        output_tokens=usage_dict.get("output_tokens", 0),
        cache_creation_input_tokens=usage_dict.get("cache_creation_input_tokens", 0),
        cache_read_input_tokens=usage_dict.get("cache_read_input_tokens", 0),
        model=AICOMPOSER_MODEL,
        source="aicomposer",
    )


def _extract_job_id(job_url: str) -> str:
    """Extract job ID from a Certora job URL."""
    if not job_url:
        return "unknown"
    return job_url.split("/")[-1] if "/" in job_url else job_url


def analyze_with_calltraces_cached(
    input_messages: List[str],
    initial_prompt: str,
    args: Any,
    job_url: str,
    rule_name: str,
    phase: AnalysisPhase,
    model_name: str = "claude-sonnet-4.5",
    use_cache: bool = True,
    cache: Optional[AnalysisCache] = None,
    iteration_index: Optional[int] = None,
    ext_logger=None,
    progress=None,
    output_type: Optional[type[BaseModel]] = None,
    violation_info: Optional[str] = None,
    code_snippets: Optional[str] = None,
) -> Tuple[int, str, str]:
    """
    Cached wrapper around analyze_with_calltraces.

    The new AIComposer API returns the result directly (str by default, or
    structured Pydantic model if output_type is provided).

    Args:
        input_messages: Messages to pass to analyzer
        initial_prompt: Initial prompt template
        args: AnalysisArgs instance
        job_url: Prover job URL (for cache key)
        rule_name: Clean rule name (for cache key and token tracking)
        phase: Analysis phase (for cache key differentiation and token tracking)
        model_name: AI model name (for cache key)
        use_cache: Whether to use caching
        cache: Optional cache instance (uses global if None)
        iteration_index: Optional iteration index for multi-analysis (included in cache key)
        ext_logger: Optional external logger for cache status messages
        progress: Optional tqdm progress bar for logging via tqdm.write()
        output_type: Optional Pydantic BaseModel type for structured output
        violation_info: Optional human-readable info about which violation(s) are being analyzed
        code_snippets: Optional code snippets to include (only used by simple analyzer, not AIComposer)

    Returns:
        Tuple of (exit_code, analysis_text, source_info)
        exit_code is 0 on success, non-zero on failure
        analysis_text is the result (JSON if output_type provided, plain text otherwise)
        source_info indicates cache file path or "api" as the source
    """
    # Extract job_id from URL
    job_id = _extract_job_id(job_url)

    # Compute hashes of inputs for cache key
    prompt_hash = hashlib.sha256(initial_prompt.encode()).hexdigest()[:16]
    messages_hash = hashlib.sha256("".join(input_messages).encode()).hexdigest()[:16]
    snippets_hash = hashlib.sha256((code_snippets or "").encode()).hexdigest()[:16]

    if not use_cache:
        return _call_analyzer(
            input_messages, initial_prompt, args,
            phase=phase, tracking_rule_name=rule_name,
            output_type=output_type, code_snippets=code_snippets, iteration_index=iteration_index,
        )

    # Caching enabled
    if cache is None:
        cache = get_global_cache()

    # Compute content hash (includes snippets_hash and phase for differentiation)
    content_hash = cache.compute_content_hash(
        prompt_hash, messages_hash, model_name, iteration_index, snippets_hash, phase=phase.value
    )

    # Get the cache file path for source_info
    cache_file = cache.get_file_path(job_id, rule_name, content_hash)

    # Check cache
    cached_result = cache.get(job_id, rule_name, content_hash)
    job_hash = job_id[:12]
    iteration_info = f" (iteration {iteration_index})" if iteration_index is not None else ""
    violation_str = f" [{violation_info}]" if violation_info else ""

    if cached_result is not None:
        msg = f"Cache HIT: {rule_name}{iteration_info}{violation_str} [job: {job_hash}...]"
        logger.log_or_write(msg, progress, level="INFO", component="AnalysisCache")
        # Track analysis cache hit
        tracker = get_global_tracker()
        tracker.record_cache_hit(phase=phase, rule_name=rule_name, iteration_index=iteration_index)
        return 0, cached_result["analysis_text"], str(cache_file)

    msg = f"Cache MISS: {rule_name}{iteration_info}{violation_str} [job: {job_hash}...] - calling API"
    logger.log_or_write(msg, progress, level="INFO", component="AnalysisCache")

    # Cache miss - call API
    exit_code, analysis_text, source_info = _call_analyzer(
        input_messages, initial_prompt, args,
        phase=phase, tracking_rule_name=rule_name,
        output_type=output_type, code_snippets=code_snippets, iteration_index=iteration_index,
    )

    # Store in cache if successful
    if exit_code == 0 and analysis_text:
        cache.set(
            job_id=job_id,
            rule_name=rule_name,
            content_hash=content_hash,
            result={"analysis_text": analysis_text},
        )

    return exit_code, analysis_text, str(cache_file)


def _use_aicomposer() -> bool:
    """Check if AIComposer should be used (default: False)."""
    return os.environ.get("USE_AICOMPOSER", "false").lower() == "true"


# Phases that always require AIComposer (structured output from agent graphs)
AICOMPOSER_ONLY_PHASES = {AnalysisPhase.VALIDATION, AnalysisPhase.IMPACT_LIKELIHOOD}


def _call_analyzer(
    input_messages: List[str],
    initial_prompt: str,
    args: Any,
    phase: AnalysisPhase,
    tracking_rule_name: str,
    output_type: Optional[type[BaseModel]] = None,
    code_snippets: Optional[str] = None,
    iteration_index: int | None = None,
) -> Tuple[int, str, str]:
    """
    Call the appropriate analyzer based on phase and USE_AICOMPOSER env var.

    Routing logic:
    - VALIDATION and IMPACT_LIKELIHOOD phases always use AIComposer
    - Other phases use simple_violation_analyzer when USE_AICOMPOSER=false (default)
    - When USE_AICOMPOSER=true, all phases use AIComposer

    Includes retry logic for graph recursion limit errors when using AIComposer -
    will retry up to MAX_RECURSION_RETRIES times, increasing recursion_limit by
    RECURSION_LIMIT_INCREMENT each time.

    Note: code_snippets are only included for the simple analyzer path, not AIComposer.
    """
    if phase not in AICOMPOSER_ONLY_PHASES and not _use_aicomposer():
        from .simple_violation_analyzer import simple_analyze

        # Pass code_snippets as separate parameter (enables user message caching)
        debug_prefix = dump_llm_input("simple_analyze", args, input_messages, initial_prompt, output_type)
        exit_code, analysis_text, source = simple_analyze(
            input_messages, initial_prompt, args,
            phase=phase, tracking_rule_name=tracking_rule_name,
            output_type=output_type, code_snippets=code_snippets, iteration_index=iteration_index,
        )
        dump_llm_output(debug_prefix, exit_code, analysis_text)
        return exit_code, analysis_text, source

    # AIComposer code path (always for VALIDATION/IMPACT_LIKELIHOOD, or when USE_AICOMPOSER=true)
    from analyzer.analysis import analyze_with_calltraces  # type: ignore[import-not-found]

    current_args = args
    retries = 0
    usage_dict: dict[str, int] = {}
    debug_prefix = dump_llm_input("analyze_with_calltraces", args, input_messages, initial_prompt, output_type)

    while True:
        try:
            if output_type is not None:
                # Structured output - pass the Pydantic model type
                result = analyze_with_calltraces(
                    input_messages, initial_prompt, current_args, output_type, token_usage=usage_dict
                )
                # Result is a Pydantic model, convert to JSON string
                analysis_text = result.model_dump_json(indent=2)
            else:
                # Default: returns str directly
                analysis_text = analyze_with_calltraces(
                    input_messages, initial_prompt, current_args, token_usage=usage_dict
                )

            _record_aicomposer_usage(
                usage_dict, phase=phase, rule_name=tracking_rule_name, iteration_index=iteration_index
            )
            dump_llm_output(debug_prefix, 0, analysis_text)
            return 0, analysis_text, "api"
        except Exception as e:
            if _is_recursion_limit_error(e) and retries < MAX_RECURSION_RETRIES:
                retries += 1
                new_limit = current_args.recursion_limit + RECURSION_LIMIT_INCREMENT
                logger.warning(
                    f"Recursion limit {current_args.recursion_limit} exceeded, "
                    f"retrying with limit {new_limit} (retry {retries}/{MAX_RECURSION_RETRIES})"
                )
                # Use dataclasses.replace() to create new args with increased limit
                current_args = replace(current_args, recursion_limit=new_limit)
                continue

            # Record partial token usage even on failure (multi-step graphs may have consumed tokens)
            _record_aicomposer_usage(
                usage_dict, phase=phase, rule_name=tracking_rule_name, iteration_index=iteration_index
            )
            logger.error(f"analyze_with_calltraces failed: {e}")
            error_msg = f"[API_ERROR] {type(e).__name__}: {e}"
            dump_llm_output(debug_prefix, 1, error_msg)
            return 1, error_msg, "api"
