"""
Calltrace scrubber for removing unnecessary metadata nodes.

Strips metadata keys from calltrace dicts before model validation and XML conversion,
reducing token consumption during AI analysis.

Based on AutoCVL's DELETEABLE_NODES approach (violation_analyzer/prover_utils.py).
"""

from typing import Any


# Metadata node keys to strip from calltraces before AI analysis.
# Based on AutoCVL's DELETEABLE_NODES but keeping jumpToDefinition
# (PreAudit uses it for source location extraction).
DEFAULT_DELETEABLE_NODES: list[str] = [
    # "values", # seems like it's better to keep it.
    "storageId",
    "truncatable",
    "tooltip",
    "changedSinceStart",
    "changedSincePreviousPrint",
]


def scrub_calltrace(tree: Any, nodes_to_delete: list[str] | None = None) -> Any:
    """
    Recursively remove specified metadata nodes from a calltrace tree structure.

    Args:
        tree: The nested calltrace structure (dict, list, or primitive).
        nodes_to_delete: Keys to strip. Defaults to DEFAULT_DELETEABLE_NODES.

    Returns:
        Cleaned structure with specified keys removed at all nesting levels.
    """
    if nodes_to_delete is None:
        nodes_to_delete = DEFAULT_DELETEABLE_NODES

    if isinstance(tree, dict):
        return {
            key: scrub_calltrace(value, nodes_to_delete)
            for key, value in tree.items()
            if key not in nodes_to_delete
        }
    elif isinstance(tree, list):
        return [scrub_calltrace(item, nodes_to_delete) for item in tree]
    else:
        return tree
