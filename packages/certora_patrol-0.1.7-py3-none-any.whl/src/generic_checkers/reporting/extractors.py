"""
Data extractors for checker output processing.

Contains components for extracting job data, source maps, and traces
from prover results.
"""

from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from composer.prover.results import CallTraceModel, calltrace_to_xml  # type: ignore[import-not-found]
from prover_output_utility import ProverOutputAPI  # type: ignore[import-untyped]
from prover_output_utility.models import CheckResult  # type: ignore[import-untyped]

from src.utils.logger import logger

from .base.models import SourceLocation
from .calltrace_code_extractor import CodeLocation, extract_locations_from_calltrace
from .calltrace_scrubber import scrub_calltrace
from .retry_utils import is_fatal_api_error


# Type alias for calltrace result
CalltraceResult = Dict[str, Any]  # {"xml": str, "locations": list[CodeLocation]}


class JobDataExtractor:
    """Extracts and manages data from a prover job."""

    def __init__(self, job_url: str):
        self.job_url = job_url
        self.job_id = self._extract_job_id(job_url)
        self.api = ProverOutputAPI()
        self._all_checks: Optional[List[CheckResult]] = None
        self._treeview_data: Optional[Dict[str, Any]] = None

    @staticmethod
    def _extract_job_id(url: str) -> str:
        """Extract job ID from Certora URL."""
        parsed = urlparse(url)
        path_parts = parsed.path.split('/')
        try:
            output_idx = path_parts.index('output')
            number = path_parts[output_idx + 1]
            hash_val = path_parts[output_idx + 2]
            return f"{number}_{hash_val}"
        except (IndexError, ValueError):
            raise ValueError(f"Invalid Certora URL format: {url}")

    @property
    def hash_part(self) -> str:
        """Get the hash part of the job ID."""
        return self.job_id.split('_')[1]

    def get_all_checks(self) -> List[CheckResult]:
        """Get all check results from the job."""
        if self._all_checks is None:
            self._all_checks = self.api.get_leaf_checks(self.job_url) or []
        return self._all_checks

    def get_violated_checks(self) -> List[CheckResult]:
        """Get only violated check results."""
        return [
            check for check in self.get_all_checks()
            if check.is_violated
        ]

    def get_checks_by_rule(self, rule_name: str) -> List[CheckResult]:
        """Get all checks for a specific rule."""
        return [
            check for check in self.get_all_checks()
            if check.rule_name == rule_name
        ]

    def get_violated_checks_by_rule(self, rule_name: str) -> List[CheckResult]:
        """Get violated checks for a specific rule."""
        return [
            check for check in self.get_violated_checks()
            if check.rule_name == rule_name
        ]


class SourceMapExtractor:
    """Extracts source map information from check results."""

    def __init__(self, api: ProverOutputAPI):
        self.api = api

    def extract_source_location(self, check: CheckResult) -> Optional[SourceLocation]:
        """Extract source location from a check result."""
        # Primary: Use source_location from check result
        if check.source_location:
            # Check if it's already a SourceLocation object from prover_output_utility
            if hasattr(check.source_location, 'file') and hasattr(check.source_location, 'line'):
                pou_loc = check.source_location
                # Ensure we have valid line numbers (default to 0 if None)
                start_line = pou_loc.line if pou_loc.line is not None else 0
                end_line = pou_loc.end_line if pou_loc.end_line is not None else start_line
                return SourceLocation(
                    file_path=pou_loc.file,
                    start_line=start_line,
                    end_line=end_line,
                    start_column=pou_loc.column,
                    end_column=pou_loc.end_column
                )
            # Otherwise parse as string
            elif isinstance(check.source_location, str):
                return self._parse_source_location_string(check.source_location)

        return None

    def _parse_source_location_string(self, location_str: str) -> Optional[SourceLocation]:
        """Parse a source location string like 'file.sol:10-15'."""
        if not location_str:
            return None

        try:
            # Handle format: "file.sol:10" or "file.sol:10-15" or "file.sol:10:5-15:20"
            if ':' not in location_str:
                return None

            parts = location_str.rsplit(':', 1)
            file_path = parts[0]
            line_info = parts[1]

            if '-' in line_info:
                # Range format
                start, end = line_info.split('-', 1)
                start_line = int(start.split(':')[0])
                end_line = int(end.split(':')[0])
            else:
                start_line = int(line_info.split(':')[0])
                end_line = start_line

            return SourceLocation(
                file_path=file_path,
                start_line=start_line,
                end_line=end_line
            )
        except (ValueError, IndexError):
            return None


class TraceExtractor:
    """Extracts and processes execution traces from check results."""

    def __init__(self, api: ProverOutputAPI, job_url: str, debug_recorder=None):
        self.api = api
        self.job_url = job_url
        self.debug_recorder = debug_recorder

    def get_traces_for_check(self, check: CheckResult) -> List[Dict[str, Any]]:
        """Get all traces for a specific check."""
        traces = []

        # Get trace from debug_trace_file (DAP format)
        if check.debug_trace_file:
            try:
                breadcrumbs = self.api.get_breadcrumbs(self.job_url, check.debug_trace_file)
                if breadcrumbs:
                    traces.append({
                        "type": "breadcrumbs",
                        "file": check.debug_trace_file,
                        "data": breadcrumbs
                    })
            except Exception as e:
                if is_fatal_api_error(e):
                    raise
                logger.warning(f"Breadcrumbs extraction failed for {check.debug_trace_file}: {e}")

        # Get traces from output files
        if check.output_files:
            for output_file in check.output_files:
                traces.append({
                    "type": "output",
                    "file": output_file,
                    "data": None  # Would need to fetch
                })

        return traces

    def extract_call_chain(self, check: CheckResult) -> Optional[List[str]]:
        """Extract the method call chain leading to the violation."""
        if not check.debug_trace_file:
            return None

        try:
            breadcrumb_info = self.api.get_breadcrumbs(self.job_url, check.debug_trace_file)
            if not breadcrumb_info or not breadcrumb_info.breadcrumbs:
                return None

            call_chain = []
            for crumb in breadcrumb_info.breadcrumbs:
                if crumb.get('type') in ['function_call', 'internal_function_call']:
                    details = crumb.get('details', {})
                    if isinstance(details, dict):
                        method = details.get('method')
                        if method:
                            call_chain.append(method)

            return call_chain if call_chain else None
        except Exception as e:
            if is_fatal_api_error(e):
                raise
            logger.warning(f"Call chain extraction failed for {check.debug_trace_file}: {e}")
            return None

    def get_calltrace(self, check: CheckResult) -> Optional[CalltraceResult]:
        """
        Fetch and convert calltrace to XML format, extracting source locations.

        Uses the ProverOutputAPI to get the calltrace from the first output file,
        then converts it to XML using AI Composer's calltrace_to_xml function.
        Also extracts jumpToDefinition locations for code snippet extraction.

        Returns:
            Dict with {"xml": str, "locations": list[CodeLocation]}, or None if unavailable.
        """
        if not check.output_files:
            return None

        try:
            # Get calltrace from the first output file
            output_file = check.output_files[0]
            calltrace = self.api.get_calltrace(self.job_url, output_file)

            # Extract the callTrace from trace_data
            if not hasattr(calltrace, 'trace_data') or not calltrace.trace_data:
                return None

            trace_data = calltrace.trace_data
            if not isinstance(trace_data, dict) or "callTrace" not in trace_data:
                return None

            # Scrub metadata nodes to reduce token consumption in AI analysis
            scrubbed_calltrace = scrub_calltrace(trace_data["callTrace"])

            # Extract jumpToDefinition locations before XML conversion
            locations = extract_locations_from_calltrace(scrubbed_calltrace)

            # Parse and convert to XML
            cex_node = CallTraceModel.model_validate(scrubbed_calltrace)
            xml_string = calltrace_to_xml(cex_node)

            # Wrap in counterexample tags
            xml_result = f"<counterexample>{xml_string}</counterexample>"

            # Record for debugging
            if self.debug_recorder:
                check_id = f"{check.rule_name}_{check.method_name}"
                self.debug_recorder.record_calltrace(check_id, calltrace, xml_result)

            return {"xml": xml_result, "locations": locations}

        except Exception as e:
            if is_fatal_api_error(e):
                raise
            logger.warning(f"Calltrace extraction failed for {check.rule_name}: {e}")
            return None
