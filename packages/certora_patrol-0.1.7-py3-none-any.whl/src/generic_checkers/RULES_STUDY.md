# PreAudit Rules Study: Comprehensive Security Analysis

## Executive Summary

This document provides a comprehensive security analysis of PreAudit's formal verification rules defined in the `generic_checkers` directory. Each rule is analyzed for:

1. **Threat coverage** - logical correctness, math precision, permission control, input validation, reentrancy, etc.
2. **Scope** - method-level, code snippet in context, or global property
3. **Violation causes** - invalid input, bad state, blockchain conditions, external contracts
4. **Worst-case scenarios** - impact/likelihood assessment with real-world examples
5. **Common false alarm patterns** - characterization based on real examples
6. **Mitigation recommendations** - how to handle violations

### Research Sources

This analysis draws from:
- Direct examination of CVL specification files
- Real-world smart contract hacks and post-mortems
- [OWASP Smart Contract Top 10 (2025)](https://owasp.org/www-project-smart-contract-top-10/)
- [Hacken - Top 10 Smart Contract Vulnerabilities](https://hacken.io/discover/smart-contract-vulnerabilities/)
- Industry research on formal verification false positives

### Financial Impact Context (2024 Data)

| Vulnerability Class | Losses (2024) | OWASP Rank |
|--------------------|---------------|------------|
| Access Control | $953.2M | SC01 |
| Logic Errors | $63.8M | SC03 |
| Reentrancy | $35.7M | SC05 |
| Flash Loan Attacks | $33.8M | SC07 |
| Input Validation | $14.6M | SC04 |
| Unchecked External Calls | $550.7K | SC06 |

---

## Table of Contents

1. [Methodology: Impact & Likelihood Assessment](#1-methodology-impact--likelihood-assessment)
2. [External Call Checker Rules](#2-external-call-checker-rules)
3. [Privileged Operations Rules](#3-privileged-operations-rules)
4. [Generic Rules - Revert Analysis](#4-generic-rules---revert-analysis)
5. [Generic Rules - Failing Calls](#5-generic-rules---failing-calls)
6. [Generic Rules - One-Time Functions](#6-generic-rules---one-time-functions)
7. [Generic Rules - Safe Casts](#7-generic-rules---safe-casts)
8. [Generic Rules - Self Calls](#8-generic-rules---self-calls)
9. [Generic Rules - Message Value in Loop](#9-generic-rules---message-value-in-loop)
10. [Generic Rules - View Reentrancy](#10-generic-rules---view-reentrancy)
11. [Input Validation Checker Rules](#11-input-validation-checker-rules)
12. [Summary Matrix](#12-summary-matrix)
13. [References](#13-references)

---

## 1. Methodology: Impact & Likelihood Assessment

This section provides a systematic framework for assessing the severity of rule violations detected by PreAudit. Understanding both **Impact** (the potential damage) and **Likelihood** (the probability of exploitation) enables prioritized remediation.

### Impact Categories

Impact measures the potential damage if a vulnerability is successfully exploited.

#### CRITICAL
- **Direct fund theft or permanent loss** - Complete protocol drainage possible
- **Complete ownership takeover** - Attacker gains full control of contract
- **Permanent state corruption** - Critical state variables corrupted, affecting all users
- **Examples:** Missing access control on `transferOwnership()`, arbitrary external call with user-controlled target

#### HIGH
- **Indirect fund theft** - Requires specific conditions but can drain significant funds
- **Partial ownership compromise** - Attacker gains elevated privileges
- **Critical state corruption** - Affects many users or core functionality
- **Examples:** Missing slippage protection (MEV extraction), re-initialization vulnerability

#### MEDIUM
- **Temporary DoS or availability issues** - Contract becomes unusable temporarily
- **State corruption affecting individual users** - User-level impact, not protocol-wide
- **Reversible damage** - Can be fixed without permanent loss
- **Examples:** Missing array length validation causing revert, getter functions that can revert

#### LOW
- **Minor state inconsistencies** - Edge cases with minimal impact
- **Informational issues** - Unexpected behavior without security impact
- **Gas inefficiencies** - Increased costs but no security risk
- **Examples:** Functions that never revert when they should, suboptimal implementations

#### INFORMATIONAL
- **No security impact** - Purely informational findings
- **Code quality issues** - Style, readability, best practices
- **Detection of patterns** - May or may not be issues depending on context
- **Examples:** Detection of idempotent functions, one-time callable patterns

---

### Likelihood Categories

Likelihood measures the probability that an attacker will successfully exploit the vulnerability.

#### VERY HIGH
- **Trivial exploitation** - No preconditions required, can be called by anyone
- **Very common vulnerable pattern** - Seen in majority of unaudited contracts
- **Publicly documented** - Attack vectors well-known, tools exist
- **Examples:** Public `selfdestruct()`, missing `msg.value` checks in loops

#### HIGH
- **Simple exploitation** - Minimal preconditions (e.g., specific input values)
- **Common vulnerable pattern** - Frequently seen in audits
- **Known in security community** - Documented in security resources
- **Examples:** Missing zero address checks on stored addresses, unchecked external call returns

#### MEDIUM
- **Moderate complexity** - Requires specific contract state or conditions
- **Occasionally seen pattern** - Not rare but not ubiquitous
- **Requires attacker sophistication** - Understanding of contract internals needed
- **Examples:** Reentrancy in specific function sequences, timestamp manipulation

#### LOW
- **Complex exploitation** - Multiple preconditions must align
- **Rare pattern** - Seldom seen in practice
- **Requires significant resources** - Validator/miner collusion, complex setups
- **Examples:** Read-only reentrancy in specific DeFi integrations, advanced MEV strategies

#### VERY LOW
- **Near-impossible exploitation** - Requires unrealistic conditions
- **Extremely rare or theoretical** - Never or almost never seen in practice
- **Requires prohibitive resources** - Nation-state level resources
- **Examples:** Time-travel attacks, hash collision attacks

---

### Risk Priority Matrix

Combine Impact and Likelihood to determine remediation priority:

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |
| **INFORMATIONAL**   | P3 | P4 | P4 | P4 | P4 |

**Priority Definitions:**
- **P0 (Critical):** Fix immediately before any deployment
- **P1 (High):** Fix before production deployment
- **P2 (Medium):** Fix in next development cycle
- **P3 (Low):** Fix when convenient, monitor in production
- **P4 (Informational):** Review and document; may not require changes

---

### Assessment Framework by Rule Category

Each rule category has specific factors that drive Impact and Likelihood assessments.

#### Category 1: Input Validation Rules

**Impact Factors:**
1. **Parameter Type:**
   - Address (used in calls/stored) → CRITICAL
   - Amount (in transfer/mint/fee functions) → HIGH to CRITICAL
   - Array index/length → MEDIUM to HIGH
   - Metadata/string → LOW to INFORMATIONAL

2. **Usage Context:**
   - Controls fund flow → CRITICAL
   - Affects access control → CRITICAL
   - Affects state integrity → HIGH
   - Purely informational → LOW

**Likelihood Factors:**
1. **Access Control:**
   - Public/external function → VERY HIGH to HIGH
   - Internal function → LOW
   - Privileged function → LOW to VERY LOW

2. **Validation Present:**
   - No validation → VERY HIGH to HIGH
   - Partial validation → MEDIUM
   - Modern Solidity provides implicit checks → LOW to VERY LOW

3. **Pattern Prevalence:**
   - Well-known attack (e.g., zero address) → HIGH
   - Common mistake → MEDIUM
   - Rare edge case → LOW

#### Category 2: Access Control Rules

**Impact Factors:**
1. **Protected Resource:**
   - Ownership transfer → CRITICAL
   - Fund management → CRITICAL
   - Critical state variables → HIGH
   - Configuration parameters → MEDIUM

2. **Blast Radius:**
   - Affects entire protocol → CRITICAL
   - Affects multiple users → HIGH
   - Affects single user → MEDIUM

**Likelihood Factors:**
1. **Current Protection:**
   - No access control → VERY HIGH
   - Weak access control (e.g., tx.origin) → HIGH
   - Role-based but misconfigured → MEDIUM
   - Proper but unverified → LOW

2. **Function Visibility:**
   - Public/external → Increase likelihood
   - Internal/private → Decrease likelihood

3. **Attack Sophistication:**
   - Straightforward call → HIGH
   - Requires state manipulation → MEDIUM
   - Requires complex setup → LOW

#### Category 3: Reentrancy Rules

**Impact Factors:**
1. **Vulnerable Operation:**
   - Fund transfer before state update → CRITICAL
   - Critical state manipulation → HIGH
   - Non-critical state → MEDIUM

2. **Attack Potential:**
   - Full fund drainage → CRITICAL
   - Partial fund theft → HIGH
   - State corruption → MEDIUM

**Likelihood Factors:**
1. **Reentrancy Type:**
   - Classic (single-function) → HIGH if CEI violated
   - Cross-function → MEDIUM
   - Read-only → LOW to MEDIUM
   - Cross-contract → LOW

2. **Protection Present:**
   - No guards, violates CEI → HIGH
   - Partial protection → MEDIUM
   - ReentrancyGuard present → VERY LOW

3. **Callback Availability:**
   - Direct to user-controlled address → HIGH
   - Through known interfaces → MEDIUM
   - Requires specific setup → LOW

#### Category 4: Arithmetic/Precision Rules

**Impact Factors:**
1. **Calculation Purpose:**
   - Fund calculations → CRITICAL to HIGH
   - Balance/supply tracking → HIGH
   - Fee calculations → MEDIUM to HIGH
   - Informational calculations → LOW

2. **Overflow/Underflow Impact:**
   - Enables theft → CRITICAL
   - Corrupts critical state → HIGH
   - Causes revert → LOW

**Likelihood Factors:**
1. **Solidity Version:**
   - Pre-0.8.0 (no auto checks) → HIGH to VERY HIGH
   - 0.8.0+ with unsafe casts → MEDIUM to HIGH
   - 0.8.0+ with safe patterns → LOW to VERY LOW

2. **Input Ranges:**
   - User-controlled large inputs → HIGH
   - Constrained inputs → MEDIUM
   - Administrative only → LOW

3. **Pattern Commonality:**
   - Unsafe downcasting → MEDIUM to HIGH
   - Complex calculations → MEDIUM
   - Simple operations → LOW

#### Category 5: Logical Correctness Rules

**Impact Factors:**
- **Highly Context-Dependent** - Must analyze specific function purpose
- Dead code in emergency functions → CRITICAL
- Functions that never revert → INFORMATIONAL to MEDIUM
- One-time functions → LOW to CRITICAL (depends on function)

**Likelihood Factors:**
- **Varies by Pattern**
- Always-reverting critical function → HIGH (if it affects operations)
- Informational findings → LOW
- Configuration issues → MEDIUM

---

### Using the Assessment Framework

**Step 1:** Identify the rule category
**Step 2:** Use the category-specific decision tree (provided in each rule section)
**Step 3:** Determine Impact level
**Step 4:** Determine Likelihood level
**Step 5:** Look up Priority in the Risk Matrix
**Step 6:** Consider context-specific factors that may adjust the assessment

**Example Workflow:**

```
Rule: inputValidation_transfer_address
Category: Input Validation
Parameter: address recipient
Function: transfer(address to, uint256 amount)

Impact Assessment:
- Parameter Type: address in transfer → Check usage
- Usage: Transfer recipient (user choice) → MEDIUM (user loses funds, not protocol)
- BUT IF: Stored address or called → CRITICAL

Likelihood Assessment:
- Access: Public function → HIGH
- Validation: None → HIGH
- Pattern: Common in ERC20 → HIGH (but often intentional)

Context Check:
- Is this ERC20 standard behavior? YES
- Should users control recipient? YES
→ This is likely a FALSE POSITIVE (intentional design)

Final Assessment: INFORMATIONAL (no fix needed, document intent)
```

---

## 2. External Call Checker Rules

**Source Files:**
- `ExternalCallChecker/specs/extcall_checker_simple.template.spec`
- `ExternalCallChecker/specs/extcall_checker_advanced.template.spec`
- View/non-view variants in the same directory

### Rule: `stable_extcall_targets_and_selectors`

#### CVL Code (Simple Version)

```cvl
persistent ghost mapping(uint => address) call_target;
persistent ghost mapping(uint => uint32) call_selector;
persistent ghost bool phase_one;

hook CALL(uint g, address target, uint v, uint aO, uint aL, uint rO, uint rL) uint rc {
    assert pc > 0;
    $HOLD$ target > 0, "$HOLD$ target contract is non-zero";
    if (phase_one) {
        if (call_target[pc] != 0) {
            assert call_target[pc] == target;
            assert call_selector[pc] == selector;
        } else {
            call_target[pc] = target;
            call_selector[pc] = selector;
        }
    } else {
        if ((call_target[pc] != 0 && check_id == stable_data_id()) || (check_id == stable_path_id())) {
            assert target == call_target[pc];
            assert selector == call_selector[pc];
        }
    }
}

rule stable_extcall_targets_and_selectors(method certoraF)
filtered { certoraF -> selected(certoraF) }
{
    check_id = stable_data_id();
    require forall uint i. call_target[i] == 0, "initializing call_target";
    require forall uint i. call_selector[i] == 0, "initializing call_selector";
    phase_one = true;
    storage init = lastStorage;

    env e1; calldataarg args1;
    env e2; calldataarg args2;

    certoraF(e1, args1);
    phase_one = false;
    certoraF(e2, args2) at init;
    assert true;
}
```

#### Rule Logic

The rule verifies that external CALL targets (addresses) and function selectors remain stable across different execution paths using a two-phase approach:

1. **Phase 1**: Records all external call targets and selectors at each program counter (PC)
2. **Phase 2**: Re-executes with different inputs/environment and asserts the same PCs produce the same targets/selectors

The **advanced version** handles patterns like `callOptionalReturn` by maintaining an indexed list of calls per PC.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Input Validation** | Primary | Detects when user-controlled inputs can influence call targets/selectors |
| **Permission Control** | Secondary | Identifies potential for unauthorized contract interactions |
| **Logical Correctness** | Secondary | Ensures deterministic external call behavior |
| **Reentrancy** | Not Covered | Does not track reentrancy patterns |

#### Scope Classification

**Type:** Method-level with path stability analysis

The rule tests individual functions (parametric over all non-filtered methods) but analyzes execution paths through the entire call graph. It's checking a property of each method's implementation rather than a global system invariant.

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes (Primary)** | The main threat - attackers passing malicious addresses or selector-influencing parameters |
| **Bad state integrity** | Possible | Corrupted state variables holding addresses could cause violations |
| **Blockchain environment conditions** | Unlikely | `msg.sender`, `block.timestamp` typically don't directly determine call targets |
| **Other contracts** | **Yes** | Return values from external calls could influence subsequent call targets |

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood (Least False Alarm):**

A function that takes an `address` parameter and calls it directly with a user-specified selector:

```solidity
function executeOnTarget(address target, bytes4 selector, bytes calldata data) external {
    (bool success,) = target.call(abi.encodePacked(selector, data));
    require(success);
}
```

This is a **critical vulnerability** pattern seen in:
- **Dexible Hack (Feb 2023, ~$2M)**: Attacker exploited a function allowing user-defined router contracts
- **Poly Network Hack (Aug 2021, $611M)**: Function selector collision combined with arbitrary contract calls

**Impact:** Critical - complete fund drainage possible
**Likelihood:** High when detected - attackers actively scan for such patterns
**False Alarm Risk:** Low - this pattern is inherently dangerous

#### Common False Alarm Patterns

1. **Token Interaction Libraries (e.g., SafeERC20)**
   - `callOptionalReturn` pattern makes multiple calls to same PC with different underlying token addresses
   - The simple version triggers false positives; advanced version handles this via indexed tracking

2. **Batch Operations**
   - Functions processing arrays of addresses (e.g., batch transfers)
   - Each element legitimately requires different call targets
   - *Note:* These typically should be flagged for review anyway

3. **Registry/Factory Patterns**
   - Contracts looking up addresses from mappings based on identifiers
   - The lookup is deterministic but varies by input
   - *Example:* `target = registeredTokens[tokenId]` - legitimate but flagged

4. **Diamond/Facet Patterns**
   - Proxy contracts routing to different implementations based on selectors
   - This is intentional behavior but may trigger the rule

5. **Callback Patterns**
   - Functions that call back to `msg.sender` or stored callback addresses
   - Legitimate patterns like `ICallback(msg.sender).onOperation()`

#### Mitigation Recommendations

When this rule detects a violation:

1. **Whitelist trusted targets** - Maintain an on-chain registry of approved addresses
2. **Validate addresses against registries** - Check targets against known-good contracts
3. **Lock selectors at compile time** - Avoid user-controlled function selectors
4. **Use typed interfaces** - Replace `address.call()` with explicit interface calls: `IERC20(target).transfer()`
5. **Implement approval flows** - Require governance/multisig approval for new call targets

By default, we assume the target callee cannot be the 0 address. If the user can make the target become 0, this could be an interesting behavior to consider if it does not revert.

#### Impact & Likelihood Assessment Framework

This rule falls under the **External Call Validation** category. Use the following decision trees to assess each violation systematically.

##### Impact Assessment Decision Tree

```
START: Rule violation detected - external call target/selector varies with input
│
├─→ [Q1] What can be called?
│   ├─→ Arbitrary contracts with arbitrary selectors
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Complete control bypass, fund drainage, system takeover
│   │       Examples: Poly Network ($611M), Dexible ($2M)
│   │
│   ├─→ Restricted contracts but arbitrary selectors
│   │   ├─→ [Q2] Are the contracts high-value/privileged?
│   │   │   ├─→ Yes → HIGH IMPACT
│   │   │   │   Justification: Can invoke unintended functions on critical contracts
│   │   │   └─→ No → MEDIUM IMPACT
│   │   │       Justification: Limited but still dangerous attack surface
│   │
│   └─→ Fixed selectors but variable targets
│       ├─→ [Q3] What function is being called?
│       │   ├─→ Fund transfer (transfer, approve, withdraw, etc.)
│       │   │   └─→ CRITICAL IMPACT
│       │   │       Justification: Direct fund loss vector
│       │   │
│       │   ├─→ State modification (setOwner, updateConfig, etc.)
│       │   │   └─→ HIGH IMPACT
│       │   │       Justification: System integrity compromise
│       │   │
│       │   ├─→ Read-only or low-privilege operations
│       │   │   └─→ MEDIUM IMPACT
│       │   │       Justification: Information leakage or DOS potential
│       │   │
│       │   └─→ Callback/notification functions
│       │       ├─→ [Q4] Can callback affect contract state?
│       │       │   ├─→ Yes → HIGH IMPACT (reentrancy risk)
│       │       │   └─→ No → LOW IMPACT (informational only)
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] How is the target/selector determined?
│   ├─→ Direct user input (function parameter)
│   │   └─→ VERY HIGH LIKELIHOOD
│   │       Justification: Trivial to exploit, no bypass needed
│   │
│   ├─→ User input affects lookup key (e.g., tokenId → address mapping)
│   │   ├─→ [Q2] Is the mapping/registry protected?
│   │   │   ├─→ No protections → HIGH LIKELIHOOD
│   │   │   │   Justification: Attacker can register malicious entries
│   │   │   │
│   │   │   ├─→ Registry has some validation → MEDIUM LIKELIHOOD
│   │   │   │   Justification: Depends on validation strength
│   │   │   │
│   │   │   └─→ Registry fully controlled by governance → LOW LIKELIHOOD
│   │   │       Justification: Requires governance compromise
│   │
│   ├─→ Derived from msg.sender (callback pattern)
│   │   ├─→ [Q3] Is there validation on msg.sender?
│   │   │   ├─→ No validation → HIGH LIKELIHOOD
│   │   │   │   Justification: Any attacker can trigger callback to malicious contract
│   │   │   │
│   │   │   └─→ Whitelist or access control → MEDIUM LIKELIHOOD
│   │   │       Justification: Attack requires compromising whitelisted address
│   │
│   └─→ Computed from blockchain state (block.timestamp, etc.)
│       └─→ VERY LOW LIKELIHOOD
│           Justification: Not directly controllable by attacker
│
├─→ [Q4] Are there any validation checks?
│   ├─→ No validation at all
│   │   └─→ Increase likelihood by 1 level
│   │
│   ├─→ Validation present but incomplete
│   │   └─→ Maintain current likelihood level
│   │
│   └─→ Comprehensive validation (whitelists, type checks, etc.)
│       ├─→ Is this a FALSE ALARM?
│       │   ├─→ Legitimate batch operation → FALSE ALARM (VERY LOW)
│       │   ├─→ Registry pattern with governance → FALSE ALARM (LOW)
│       │   ├─→ Diamond/proxy by design → FALSE ALARM (MEDIUM)
│       │   └─→ Token library (SafeERC20) → FALSE ALARM (use advanced version)
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

Combine Impact × Likelihood to determine priority:

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment Walkthrough

**Scenario:** `function executeOnTarget(address target, bytes4 selector, bytes calldata data) external`

**Impact Assessment:**
- Q1: What can be called? → Arbitrary contracts with arbitrary selectors
- **Result: CRITICAL IMPACT**

**Likelihood Assessment:**
- Q1: How is target/selector determined? → Direct user input
- Q4: Any validation? → No validation at all
- **Result: VERY HIGH LIKELIHOOD**

**Final Priority:** CRITICAL × VERY HIGH = **P0** (Immediate fix required)

**Scenario 2:** `function batchTransfer(address[] calldata recipients, uint256[] calldata amounts)`

**Impact Assessment:**
- Q1: What can be called? → Fixed selector (transfer) but variable targets
- Q3: What function? → Fund transfer
- **Result: CRITICAL IMPACT**

**Likelihood Assessment:**
- Q1: How determined? → Direct user input (recipients array)
- Q4: Validation? → None on recipient addresses
- **Result: VERY HIGH LIKELIHOOD**

**Final Priority:** CRITICAL × VERY HIGH = **P0**
**Note:** However, this is likely a **FALSE ALARM** if recipients are *intended* to be user-specified (like ERC20 transfer). Re-evaluate as **Batch Operation Pattern** → Impact remains CRITICAL but this is expected behavior requiring manual review.

---

## 3. Privileged Operations Rules

**Source Files:**
- `PrivilegedOperations/specs/privileged_operations.spec`
- `PrivilegedOperations/specs/privileged_writes.spec`

### Rule: `privilegedOperation`

#### CVL Code

```cvl
rule privilegedOperation(method certoraF, address privileged)
filtered {
    certoraF -> !certoraF.isView
}
{
    // ACCESS_CONTROL_SINGLE_OWNERSHIP_CHECK_PLACEHOLDER

    env e1;
    calldataarg arg;
    require e1.msg.sender == privileged, "we assume first call is the privileged one";

    storage initialStorage = lastStorage;
    certoraF(e1, arg); // privileged succeeds executing candidate privileged operation.

    env e2;
    calldataarg arg2;
    require e2.msg.sender != privileged, "we assume second call is from a different user";
    certoraF@withrevert(e2, arg2) at initialStorage; // unprivileged
    bool secondSucceeded = !lastReverted;

    // we will assert that second did not succeed. we will get a counterexample in
    // which first call to `f` must have succeeded.
    assert !secondSucceeded, "not privileged operation - another address can call method";
}
```

#### Rule Logic

Determines if a function is "privileged" (callable by only one address). Tests whether a second user with different `msg.sender` can successfully call the same function that a privileged user succeeded in calling.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Permission Control** | **Primary** | Direct access control verification |
| **Logical Correctness** | Secondary | Ensures authorization logic works as intended |
| **Input Validation** | Not Covered | Does not analyze input handling |

#### Scope Classification

**Type:** Method-level privilege detection

Tests each non-view function to determine its access control characteristics. This is a discovery rule - it identifies which functions have single-owner restrictions.

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | No | Rule tests address-based access control |
| **Bad state integrity** | Possible | Corrupted owner/admin state could cause unexpected access |
| **Blockchain environment conditions** | Unlikely | Access control rarely depends on block properties |
| **Other contracts** | **Yes** | External access control systems (e.g., AccessControl roles) may allow multiple addresses |

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood:**

A function intended to be admin-only but missing the modifier:

```solidity
function setFeeRecipient(address newRecipient) external {
    // Missing: require(msg.sender == owner)
    feeRecipient = newRecipient;
}
```

**Real-World Examples:**
- **KiloEx Hack (2024, ~$7M)**: Missing access controls on critical function
- **HospoWise Hack (2023)**: Public burn function allowed anyone to destroy token supply
- **Sonne Finance (May 2024, $20M)**: Governance manipulation via insufficient access controls

**Impact:** Critical - unauthorized state modification, fund theft
**Likelihood:** High - one of the most common vulnerability classes
**False Alarm Risk:** Low for functions that should be admin-only

#### Common False Alarm Patterns

1. **Intentionally Public State-Changing Functions**
   - `deposit()`, `withdraw()`, `transfer()` - anyone should call these
   - Rule correctly identifies them as "not privileged" which may seem like a failure
   - *Understanding:* This is informational, not a bug report

2. **Role-Based Access Control (RBAC)**
   - Functions protected by roles (e.g., MINTER_ROLE) allow multiple addresses
   - Rule reports "not privileged" because role holders != single address
   - *Example:* OpenZeppelin's AccessControl with multiple role members

3. **Timelock/Governance Functions**
   - Functions callable by timelock contract, which itself can be triggered by multiple proposers
   - Transitively non-privileged despite apparent restrictions

#### Mitigation Recommendations

When this rule identifies a function as not privileged that should be:

1. **Use OpenZeppelin AccessControl** - Implement role-based access with explicit role checks
2. **Apply `onlyOwner` modifier consistently** - Use Ownable pattern for single-owner functions
3. **Document intended access** - Comments help distinguish intentional vs accidental public access
4. **Implement two-step transfers** - For critical ownership changes, require pending + acceptance pattern
5. **Use access control libraries** - Don't roll your own access control logic

#### Impact & Likelihood Assessment Framework

This rule falls under the **Access Control Rules** category. Use the following decision trees to assess each violation systematically.

##### Impact Assessment Decision Tree

```
START: Rule violation detected - function not privileged (no single-owner access control)
│
├─→ [Q1] What does the function modify?
│   ├─→ Core protocol parameters (fees, addresses, settings)
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Complete protocol compromise possible
│   │       Examples: setFeeRecipient, updateOracle, changeOwner
│   │
│   ├─→ Token minting or supply control
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Infinite minting = total value destruction
│   │       Examples: mint, burn, setSupplyCap
│   │
│   ├─→ Fund movement or withdrawal
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Direct theft vector
│   │       Examples: withdraw, transferFunds, emergencyWithdraw
│   │
│   ├─→ Access control itself (roles, permissions)
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Privilege escalation vector
│   │       Examples: grantRole, addAdmin, transferOwnership
│   │
│   ├─→ Pause/unpause functionality
│   │   └─→ HIGH IMPACT
│   │       Justification: DOS or enabling attacks via unpause
│   │       Examples: pause, unpause, setEmergencyMode
│   │
│   ├─→ Configuration with financial impact
│   │   └─→ HIGH IMPACT
│   │       Justification: Economic manipulation
│   │       Examples: setInterestRate, updateLiquidationThreshold
│   │
│   ├─→ User-specific operations (balances, allowances)
│   │   └─→ LOW IMPACT (Likely FALSE ALARM)
│   │       Justification: Intended to be callable by any user
│   │       Examples: deposit, withdraw, approve, transfer
│   │
│   └─→ Read-only or trivial state
│       └─→ INFORMATIONAL IMPACT
│           Justification: No security implications
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW/INFORMATIONAL)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Is the function EXPECTED to be publicly callable?
│   ├─→ Yes (e.g., deposit, transfer, approve)
│   │   └─→ FALSE ALARM - VERY LOW LIKELIHOOD
│   │       Justification: This is intentional design, not a vulnerability
│   │
│   └─→ No - should be restricted
│       │
│       ├─→ [Q2] Is there ANY access control present?
│       │   ├─→ No access control at all
│       │   │   └─→ VERY HIGH LIKELIHOOD
│       │   │       Justification: Trivially exploitable, already public
│       │   │
│       │   ├─→ Role-based access control (multiple authorized addresses)
│       │   │   ├─→ [Q3] How many addresses have the role?
│       │   │   │   ├─→ Small set of trusted addresses (2-5)
│       │   │   │   │   └─→ LOW LIKELIHOOD
│       │   │   │   │       Justification: Requires compromise of trusted party
│       │   │   │   │
│       │   │   │   ├─→ Large set or dynamically granted roles
│       │   │   │   │   └─→ MEDIUM LIKELIHOOD
│       │   │   │   │       Justification: Larger attack surface
│       │   │   │   │
│       │   │   │   └─→ Public role granting (anyone can get role)
│       │   │   │       └─→ VERY HIGH LIKELIHOOD
│       │   │   │           Justification: Effectively no protection
│       │   │
│       │   └─→ Timelock/governance control
│       │       ├─→ [Q4] Is governance mechanism secure?
│       │       │   ├─→ Multisig or battle-tested DAO
│       │       │   │   └─→ LOW LIKELIHOOD
│       │       │   │       Justification: Requires governance attack
│       │       │   │
│       │       │   └─→ Weak governance (low quorum, short timelock)
│       │       │       └─→ MEDIUM LIKELIHOOD
│       │       │           Justification: Governance can be manipulated
│       │
│       └─→ [Q5] Is the function documented/commented?
│           ├─→ No documentation → Likely accidental omission
│           │   └─→ Increase likelihood by 1 level
│           │
│           └─→ Documented as "admin only" → Confirmed bug
│               └─→ Maintain current likelihood level
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment Walkthrough

**Scenario:** `function setFeeRecipient(address newRecipient) external { feeRecipient = newRecipient; }`

**Impact Assessment:**
- Q1: What does the function modify? → Core protocol parameters (fee recipient)
- **Result: CRITICAL IMPACT**

**Likelihood Assessment:**
- Q1: Expected to be public? → No
- Q2: Any access control? → None
- **Result: VERY HIGH LIKELIHOOD**

**Final Priority:** CRITICAL × VERY HIGH = **P0** (Critical vulnerability - immediate fix)

**Scenario 2:** `function deposit(uint256 amount) external { balances[msg.sender] += amount; }`

**Impact Assessment:**
- Q1: What does the function modify? → User-specific operations (balances)
- **Result: LOW IMPACT**

**Likelihood Assessment:**
- Q1: Expected to be public? → Yes
- **Result: VERY LOW LIKELIHOOD (FALSE ALARM)**

**Final Priority:** LOW × VERY LOW = P4 (Informational - working as intended)

---

### Rule: `detect_privileged_writes`

#### CVL Code

```cvl
persistent ghost mapping(uint => bool) is_written;
persistent ghost mapping(uint => uint) written_value;
persistent ghost bool phase_one;

hook ALL_SSTORE(uint loc, uint v) {
    if (phase_one) {
        is_written[loc] = true;
        written_value[loc] = v;
    } else {
        if (is_written[loc]) {
            assert written_value[loc] == v, "Write to storage slot is different";
        }
    }
}

rule detect_privileged_writes(method certoraF)
filtered {
    certoraF -> !certoraF.isView
}
{
    phase_one = true;
    init_ghost_maps();
    storage initialStorage = lastStorage;
    env e1; env e2;
    calldataarg args1; calldataarg args2;
    require e1.msg.sender != e2.msg.sender, "we assume two different users";
    require e1.block.timestamp == e2.block.timestamp, "same timestamp";
    require e1.block.number == e2.block.number, "same block number";
    certoraF(e1, args1); // first call
    phase_one = false;
    certoraF(e2, args2) at initialStorage; // second call
    assert true;
}
```

#### Rule Logic

Uses two-phase execution with different `msg.sender` values but same state. Tracks all SSTORE operations via hooks. If two different users can write different values to the same storage slot, the write is "not privileged."

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Permission Control** | **Primary** | Granular write-level access control analysis |
| **State Integrity** | Secondary | Identifies unprotected state mutations |
| **Logical Correctness** | Secondary | Ensures write operations follow intended patterns |

#### Scope Classification

**Type:** Storage-level privilege analysis

More granular than `privilegedOperation` - analyzes individual storage writes rather than function success/failure.

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood:**

An admin configuration variable writeable by any user:

```solidity
mapping(address => uint256) public userNonces;
uint256 public protocolFee; // Should be admin-only

function incrementNonce() external {
    userNonces[msg.sender]++; // Legitimate - user's own nonce
    protocolFee = userNonces[msg.sender]; // BUG: wrong variable!
}
```

**Impact:** High - protocol configuration hijacking
**Likelihood:** Medium - typically caught in testing
**False Alarm Risk:** Medium - see patterns below

#### Common False Alarm Patterns

1. **User Balance Updates**
   - Different users writing different balances to `balances[msg.sender]`
   - Legitimate - each user manages their own slot
   - *Pattern:* Writes to `mapping(address => ...)` keyed by `msg.sender`

2. **Nonce Increments**
   - User-specific nonces: `nonces[msg.sender]++`
   - Different users write different values to different slots

3. **Approval Patterns**
   - `allowances[msg.sender][spender] = amount`
   - User-controlled value legitimately varies by user

#### Mitigation Recommendations

1. **Separate user data from protocol parameters** - Use distinct storage patterns
2. **Use RBAC for sensitive storage** - Only specific roles can modify protocol state
3. **Implement storage access patterns** - Clear distinction between user-owned vs protocol-owned slots
4. **Add explicit checks** - `require(msg.sender == owner)` before sensitive writes

#### Impact & Likelihood Assessment Framework

This rule falls under the **Access Control Rules** category, at the storage-level granularity.

##### Impact Assessment Decision Tree

```
START: Rule violation detected - storage write not privileged (different users can write different values)
│
├─→ [Q1] What storage slot is being written?
│   ├─→ Protocol-critical parameters
│   │   ├─→ Owner/admin addresses
│   │   │   └─→ CRITICAL IMPACT
│   │   │       Justification: Complete privilege escalation
│   │   │
│   │   ├─→ Fee settings, oracle addresses, treasury
│   │   │   └─→ CRITICAL IMPACT
│   │   │       Justification: Protocol parameter hijacking
│   │   │
│   │   └─→ Pause/emergency flags
│   │       └─→ HIGH IMPACT
│   │           Justification: DOS or attack enablement
│   │
│   ├─→ User-specific data keyed by msg.sender
│   │   └─→ LOW IMPACT (Likely FALSE ALARM)
│   │       Justification: Legitimate pattern - users manage their own slots
│   │       Examples: balances[msg.sender], nonces[msg.sender]
│   │
│   ├─→ User-to-user mappings (approvals, delegations)
│   │   └─→ LOW IMPACT (Likely FALSE ALARM)
│   │       Justification: Users control their own approvals
│   │       Examples: allowances[msg.sender][spender]
│   │
│   └─→ Computed/derived slots
│       ├─→ [Q2] Does the slot affect protocol integrity?
│       │   ├─→ Yes → HIGH IMPACT
│       │   └─→ No → MEDIUM IMPACT
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Is this a user-keyed pattern (e.g., balances[msg.sender])?
│   ├─→ Yes
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │       Justification: Expected behavior, not a vulnerability
│   │
│   └─→ No - writes to shared/protocol slots
│       │
│       ├─→ [Q2] Are there access control checks before the write?
│       │   ├─→ No checks at all
│       │   │   └─→ VERY HIGH LIKELIHOOD
│       │   │       Justification: Already exploitable, public write access
│       │   │
│       │   ├─→ Partial checks (some paths protected, others not)
│       │   │   └─→ HIGH LIKELIHOOD
│       │   │       Justification: Bypass likely exists
│       │   │
│       │   └─→ Checks present but analysis shows multiple users can pass
│       │       ├─→ [Q3] Is multi-user write intentional (RBAC design)?
│       │       │   ├─→ Yes (e.g., multiple operators)
│       │       │   │   └─→ LOW LIKELIHOOD (Design choice)
│       │       │   │       Justification: Working as intended
│       │       │   │
│       │       │   └─→ No (should be single-owner)
│       │       │       └─→ MEDIUM LIKELIHOOD
│       │       │           Justification: Logic flaw in access control
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Example Assessment

**Scenario:** `function updateFee(uint256 newFee) external { protocolFee = newFee; }`

**Impact:** Q1 → Protocol-critical parameters (fee settings) = **CRITICAL IMPACT**
**Likelihood:** Q1 → Not user-keyed; Q2 → No checks = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0**

**Scenario 2:** `function deposit(uint256 amount) external { balances[msg.sender] += amount; }`

**Impact:** Q1 → User-specific data keyed by msg.sender = **LOW IMPACT (FALSE ALARM)**
**Likelihood:** Q1 → Yes, user-keyed pattern = **VERY LOW LIKELIHOOD (FALSE ALARM)**
**Final Priority:** LOW × VERY LOW = P4 (Working as intended)

---

### Rule: `detect_time_sensitive_writes`

#### CVL Code

```cvl
rule detect_time_sensitive_writes(method certoraF)
filtered {
    certoraF -> !certoraF.isView
}
{
    phase_one = true;
    init_ghost_maps();
    storage initialStorage = lastStorage;
    env e1; env e2;
    calldataarg args;
    require e1.msg.sender == e2.msg.sender, "same user";
    require e1.block.timestamp != e2.block.timestamp, "different timestamp";
    require e1.block.number != e2.block.number, "different block number";
    certoraF(e1, args); // first call
    phase_one = false;
    certoraF(e2, args) at initialStorage; // second call
    assert true;
}
```

#### Rule Logic

Similar two-phase execution but with same user, different `block.timestamp`/`block.number`. Identifies storage writes whose values depend on time.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Logical Correctness** | **Primary** | Identifies time-dependent state mutations |
| **Blockchain Environment** | **Primary** | Detects reliance on manipulable block properties |
| **MEV/Frontrunning** | Secondary | Time-dependent logic is MEV-vulnerable |

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood:**

Timestamp-based randomness or critical decisions:

```solidity
function lottery() external {
    winner = participants[block.timestamp % participants.length];
}
```

**Real-World Examples:**
- **GovernMental Ponzi**: Miners manipulated timestamps to win rewards
- **King of the Ether Throne**: Timestamp manipulation for throne claims
- **MEV extraction**: Validators can manipulate timestamps within ~15 second window

**Impact:** High for gambling/randomness; Medium for general time logic
**Likelihood:** Medium - requires miner/validator collusion or MEV
**False Alarm Risk:** High - see patterns below

#### Common False Alarm Patterns

1. **Reentrancy Guards**
   - Slot written twice per call (set + unset)
   - *Note:* Spec comments acknowledge this as known false positive

2. **Timestamp Recording**
   - `lastUpdateTime = block.timestamp` - intentional and safe

3. **Vesting/Unlock Schedules**
   - Legitimate time-based logic: `vestedAmount = (block.timestamp - startTime) * rate`

4. **Deadline Checks**
   - `require(block.timestamp < deadline)` - legitimate validation

#### Mitigation Recommendations

1. **Use block numbers instead of timestamps** for sequencing when possible
2. **Add buffer periods** - Don't make critical decisions on exact timestamps
3. **Use Chainlink VRF** for randomness instead of block properties
4. **Implement commit-reveal schemes** for MEV-sensitive operations
5. **Consider private transaction services** (Flashbots Protect) for sensitive transactions

#### Impact & Likelihood Assessment Framework

This rule falls under the **Logical Correctness Rules** category with blockchain environment considerations.

##### Impact Assessment Decision Tree

```
START: Rule violation detected - storage write value depends on block.timestamp or block.number
│
├─→ [Q1] What is the timestamp/block number used for?
│   ├─→ Randomness generation
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Miner/validator manipulation enables theft
│   │       Examples: Lottery selection, random rewards
│   │
│   ├─→ Critical financial decisions (liquidations, auction settlements)
│   │   └─→ HIGH IMPACT
│   │       Justification: MEV extraction, unfair advantages
│   │       Examples: Liquidation price calculations, auction timing
│   │
│   ├─→ Access control or permission changes
│   │   └─→ HIGH IMPACT
│   │       Justification: Timing attacks on privilege transitions
│   │       Examples: Time-locked admin transfers
│   │
│   ├─→ Recording timestamps (lastUpdateTime, createdAt)
│   │   └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │       Justification: Legitimate time tracking
│   │       Examples: lastUpdateTime = block.timestamp
│   │
│   ├─→ Vesting/unlock schedules
│   │   └─→ LOW IMPACT (Usually FALSE ALARM)
│   │       Justification: Legitimate time-based logic, ~15s manipulation minimal
│   │       Examples: vestedAmount calculations
│   │
│   ├─→ Deadline enforcement
│   │   └─→ LOW IMPACT (Usually FALSE ALARM)
│   │       Justification: Standard validation pattern
│   │       Examples: require(block.timestamp < deadline)
│   │
│   └─→ Reentrancy guard state
│       └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│           Justification: Known false positive, not a vulnerability
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW/INFORMATIONAL)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Is this a FALSE ALARM pattern?
│   ├─→ Timestamp recording only
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │
│   ├─→ Reentrancy guard
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │
│   ├─→ Vesting/deadline with reasonable tolerance
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │
│   └─→ No - potential vulnerability
│       │
│       ├─→ [Q2] How much manipulation is needed?
│       │   ├─→ Randomness (any manipulation matters)
│       │   │   └─→ VERY HIGH LIKELIHOOD
│       │   │       Justification: Validators can manipulate ±15s on Ethereum
│       │   │
│       │   ├─→ Critical decision within narrow window
│       │   │   └─→ HIGH LIKELIHOOD
│       │   │       Justification: MEV bots actively search for these
│       │   │
│       │   ├─→ Decision with >1 hour tolerance
│       │   │   └─→ MEDIUM LIKELIHOOD
│       │   │       Justification: Harder to exploit but possible
│       │   │
│       │   └─→ Decision with >24 hour tolerance
│       │       └─→ LOW LIKELIHOOD
│       │           Justification: 15s manipulation unlikely to matter
│       │
│       └─→ [Q3] What's the financial incentive?
│           ├─→ High value (>$100K potential gain)
│           │   └─→ Increase likelihood by 1 level
│           │
│           └─→ Low value or no direct financial gain
│               └─→ Maintain current likelihood
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Example Assessment

**Scenario:** `function lottery() external { winner = participants[block.timestamp % participants.length]; }`

**Impact:** Q1 → Randomness generation = **CRITICAL IMPACT**
**Likelihood:** Q1 → Not false alarm; Q2 → Randomness = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0**

**Scenario 2:** `function updatePrice() external { lastUpdateTime = block.timestamp; prices[asset] = fetchPrice(); }`

**Impact:** Q1 → Recording timestamps = **INFORMATIONAL IMPACT (FALSE ALARM)**
**Likelihood:** Q1 → Timestamp recording only = **VERY LOW LIKELIHOOD (FALSE ALARM)**
**Final Priority:** INFORMATIONAL × VERY LOW = P4 (Not a vulnerability)

**Scenario 3:** `function claimVested() external { uint256 vested = (block.timestamp - startTime) * rate; ... }`

**Impact:** Q1 → Vesting/unlock schedules = **LOW IMPACT**
**Likelihood:** Q1 → Vesting with reasonable tolerance; Q2 → >1 hour tolerance = **LOW LIKELIHOOD**
**Final Priority:** LOW × LOW = P4 (Minor concern, acceptable risk)

---

## 4. Generic Rules - Revert Analysis

**Source File:** `GenericRules/specs/reverts.spec`

### Rule: `nonGettersThatNeverRevert`

#### CVL Code

```cvl
rule nonGettersThatNeverRevert(method certoraF)
filtered { certoraF -> !certoraF.isView && !certoraF.isPayable }
{
    env e;
    calldataarg arg;
    certoraF@withrevert(e, arg);
    assert !lastReverted;
}
```

#### Rule Logic

For non-view, non-payable functions, checks if they can complete without reverting under any inputs/environment.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **DoS/Availability** | **Primary** | Functions that always succeed can't be DoS'd |
| **Logical Correctness** | Secondary | Identifies unexpected error paths |
| **Input Validation** | Secondary | Reverts often indicate validation logic |

#### Scope Classification

**Type:** Function-level availability analysis

#### Worst-Case Scenario Analysis

This rule is typically **expected to fail** - most functions have revert conditions. The interesting case is when it **passes** for sensitive functions:

```solidity
function withdrawAll() external {
    // BUG: Missing require(balance[msg.sender] > 0)
    payable(msg.sender).transfer(balance[msg.sender]);
    balance[msg.sender] = 0;
}
```

**Impact:** Low-Medium for most findings
**Likelihood:** N/A - informational rule
**False Alarm Risk:** Very High - by design, most functions revert

#### Common False Alarm Patterns

1. **Nearly All Functions** - By design, this rule fails on most functions
2. **Simple Setters Without Validation** - May be intentional

#### Mitigation Recommendations

This is an **informational rule**. When a function passes (never reverts):
- Verify this is intentional
- Add validation if missing: `require(amount > 0)`, `require(recipient != address(0))`

#### Impact & Likelihood Assessment Framework

This is an **informational rule** for logical correctness - it reports functions that CAN execute without reverting, which is usually expected behavior.

##### Impact Assessment Decision Tree

```
START: Rule passes - function can execute without reverting
│
├─→ [Q1] Does the function handle sensitive operations?
│   ├─→ Fund transfers/withdrawals
│   │   ├─→ [Q2] Are there validation checks (amount > 0, recipient != 0, etc.)?
│   │   │   ├─→ Yes, has validation → INFORMATIONAL IMPACT
│   │   │   │   Justification: Working as intended
│   │   │   │
│   │   │   └─→ No validation → MEDIUM IMPACT
│   │   │       Justification: Missing input validation on financial operation
│   │   │
│   │   └─→ State modifications (setters, configuration)
│   │       ├─→ [Q3] Is this expected to be permissive?
│   │       │   ├─→ Yes (e.g., user-controlled state) → INFORMATIONAL IMPACT
│   │       │   └─→ No (should have constraints) → LOW IMPACT
│   │       │       Justification: Missing sanity checks
│   │
│   └─→ Simple operations (getters, trivial setters)
│       └─→ INFORMATIONAL IMPACT
│           Justification: Expected behavior, no validation needed
│
└─→ OUTPUT: Impact Level (MEDIUM/LOW/INFORMATIONAL)
```

##### Assessment Guidance

**This rule is informational by design.** Most findings are NOT vulnerabilities. Focus on:
1. Functions handling value transfers without amount validation
2. Critical setters without sanity checks (e.g., fee > 100%)
3. Address parameters not checked for zero address

**Likelihood:** Not applicable - this is a code quality check, not a vulnerability detector

**Example Assessment:**

**Scenario:** `function setFee(uint256 newFee) external onlyOwner { protocolFee = newFee; }`

**Impact:** Q1 → State modifications; Q3 → Should have constraints (fee <= 100%) = **LOW IMPACT**
**Recommendation:** Add `require(newFee <= MAX_FEE, "Fee too high");`

**Scenario 2:** `function deposit(uint256 amount) external { balances[msg.sender] += amount; }`

**Impact:** Q1 → Fund transfers; Q2 → Has implied validation (amount must be transferred) = **INFORMATIONAL**
**Recommendation:** No action needed - working as intended

---

### Rule: `gettersThatNeverRevert`

#### CVL Code

```cvl
rule gettersThatNeverRevert(method certoraF)
filtered { certoraF -> certoraF.isView }
{
    env e;
    require e.msg.value == 0, "getters should not be payable";
    calldataarg arg;
    certoraF@withrevert(e, arg);
    assert !lastReverted, "getters should usually not revert";
}
```

#### Rule Logic

For view functions, checks if they complete without reverting. Getters should typically be robust.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **DoS/Availability** | **Primary** | Getters should be reliable |
| **Logical Correctness** | **Primary** | Division by zero, array bounds |
| **Math Precision** | Secondary | Overflow in view computations |

#### Worst-Case Scenario Analysis

A getter that reverts unexpectedly can break integrations:

```solidity
function getPrice() public view returns (uint256) {
    return totalValue / totalSupply; // Division by zero if supply is 0
}
```

**Real-World Impact:**
- **Oracle Integration Failures**: DeFi protocols depending on view functions that revert
- **UI Breakage**: Frontends failing to render due to reverting getters

**Impact:** Medium - breaks composability
**Likelihood:** Medium - often caught in testing
**False Alarm Risk:** Low - getters reverting is usually a bug

#### Mitigation Recommendations

1. **Handle edge cases** - Return default values for empty states
2. **Guard against division by zero** - `return totalSupply == 0 ? 0 : totalValue / totalSupply`
3. **Bound array access** - Check bounds before indexing
4. **Document revert conditions** - If intentional, make it clear

#### Impact & Likelihood Assessment Framework

This rule detects view functions that CAN revert - a reliability/composability issue.

##### Impact Assessment Decision Tree

```
START: Rule fails - view function can revert
│
├─→ [Q1] What causes the revert?
│   ├─→ Division by zero
│   │   ├─→ [Q2] Is this function used by external protocols?
│   │   │   ├─→ Yes (oracle, integration point) → HIGH IMPACT
│   │   │   │   Justification: Breaks downstream protocols
│   │   │   │
│   │   │   └─→ No (internal use only) → MEDIUM IMPACT
│   │   │       Justification: UI/internal breakage
│   │   │
│   │   ├─→ Array out of bounds
│   │   │   └─→ MEDIUM IMPACT
│   │   │       Justification: Poor UX, integration issues
│   │   │
│   │   ├─→ Intentional validation (require statements)
│   │   │   └─→ LOW IMPACT (Possibly FALSE ALARM)
│   │   │       Justification: May be intentional design
│   │   │       Examples: require(amount > 0) in a getter
│   │   │
│   │   └─→ External call to reverting contract
│   │       └─→ MEDIUM IMPACT
│   │           Justification: Dependency reliability issue
│
└─→ OUTPUT: Impact Level (HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation/occurrence likelihood
│
├─→ [Q1] What's the revert condition?
│   ├─→ Division by zero in critical path
│   │   ├─→ [Q2] Can totalSupply/denominator reach zero?
│   │   │   ├─→ Yes, in normal operations → HIGH LIKELIHOOD
│   │   │   │   Justification: Will occur during regular use
│   │   │   │
│   │   │   └─→ Only in edge cases/emergency → MEDIUM LIKELIHOOD
│   │   │       Justification: Rare but possible
│   │   │
│   │   ├─→ Array bounds with dynamic indices
│   │   │   └─→ MEDIUM LIKELIHOOD
│   │   │       Justification: Depends on usage patterns
│   │   │
│   │   └─→ Intentional require() statements
│   │       └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │           Justification: Working as designed
│
└─→ OUTPUT: Likelihood Level (HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|------|--------|-----|----------|
| **HIGH**            | **P0** | **P1** | P2 | P3 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 |

##### Example Assessment

**Scenario:** `function getPrice() public view returns (uint256) { return totalValue / totalSupply; }`

**Impact:** Q1 → Division by zero; Q2 → Yes, used as oracle = **HIGH IMPACT**
**Likelihood:** Q1 → Division by zero; Q2 → Yes, can reach zero = **HIGH LIKELIHOOD**
**Final Priority:** HIGH × HIGH = **P0** (Critical composability issue)

**Scenario 2:** `function getUser(uint256 index) public view returns (User memory) { require(index < users.length); return users[index]; }`

**Impact:** Q1 → Intentional validation = **LOW IMPACT (FALSE ALARM)**
**Likelihood:** Q1 → Intentional require() = **VERY LOW LIKELIHOOD (FALSE ALARM)**
**Final Priority:** LOW × VERY LOW = P4 (Working as intended)

---

### Rule: `alwaysRevert`

#### CVL Code

```cvl
rule alwaysRevert(method certoraF) {
    env e;
    calldataarg arg;
    certoraF@withrevert(e, arg);
    assert lastReverted, "function always reverts";
    satisfy lastReverted, "found a reverting path";
}
```

#### Rule Logic

Finds functions that revert on ALL execution paths. Combined with `satisfy lastReverted` to rule out sanity issues.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Logical Correctness** | **Primary** | Dead code / broken functions |
| **Configuration Issues** | **Primary** | Prover configuration problems |

#### Worst-Case Scenario Analysis

A critical function that's unreachable:

```solidity
function emergencyWithdraw() external onlyOwner {
    require(false); // BUG: Always reverts
    // ...
}
```

**Real-World Impact:**
- **Parity Wallet Freeze**: `selfdestruct` function made unreachable, freezing $280M

**Impact:** Critical if affecting fund recovery
**Likelihood:** Low - usually caught in testing
**False Alarm Risk:** Medium - Prover config issues can cause false detection

#### Common False Alarm Patterns

1. **Prover Configuration Issues** - Missing contract links, incorrect method summaries
2. **Intentionally Disabled Functions** - `revert("Deprecated")`
3. **Placeholder/Abstract Functions** - Base contract functions meant to be overridden

#### Mitigation Recommendations

1. **Review prover configuration** if unexpected
2. **Remove deprecated functions** entirely instead of reverting
3. **Test emergency functions** with real transactions on testnets

#### Impact & Likelihood Assessment Framework

This rule detects functions that ALWAYS revert - indicating dead code or configuration issues.

##### Impact Assessment Decision Tree

```
START: Rule passes - function always reverts on all paths
│
├─→ [Q1] What type of function is this?
│   ├─→ Emergency/recovery function (emergencyWithdraw, pause, etc.)
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Critical functionality inaccessible
│   │       Real-world example: Parity Wallet freeze ($280M)
│   │
│   ├─→ Core business logic (transfer, deposit, swap, etc.)
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Contract essentially broken/useless
│   │
│   ├─→ Admin/configuration function
│   │   └─→ HIGH IMPACT
│   │       Justification: Cannot manage contract
│   │
│   ├─→ Intentionally deprecated function with revert("Deprecated")
│   │   └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │       Justification: Working as intended
│   │       Recommendation: Remove function entirely
│   │
│   ├─→ Abstract/placeholder function (base contract)
│   │   └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │       Justification: Meant to be overridden in derived contracts
│   │
│   └─→ Utility function
│       └─→ MEDIUM IMPACT
│           Justification: Broken helper function
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/INFORMATIONAL)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate if this is a real issue
│
├─→ [Q1] Why does the function always revert?
│   ├─→ require(false) or unconditional revert
│   │   ├─→ [Q2] Is this intentional (deprecated/placeholder)?
│   │   │   ├─→ Yes → VERY LOW LIKELIHOOD (FALSE ALARM)
│   │   │   │   Justification: Design decision, not a bug
│   │   │   │
│   │   │   └─→ No → VERY HIGH LIKELIHOOD
│   │   │       Justification: Confirmed dead code bug
│   │   │
│   │   ├─→ Prover configuration issue (missing links, wrong summaries)
│   │   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │   │       Justification: Verification artifact, not code issue
│   │   │       Action: Fix prover config, re-run
│   │   │
│   │   ├─→ Impossible preconditions (require that can never be satisfied)
│   │   │   └─→ HIGH LIKELIHOOD
│   │   │       Justification: Logic bug
│   │   │
│   │   └─→ All paths lead to external calls that revert
│   │       └─→ MEDIUM LIKELIHOOD
│   │           Justification: Dependency issue or configuration problem
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **INFORMATIONAL**   | P3 | P4 | P4 | P4 | P4 |

##### Example Assessment

**Scenario:** `function emergencyWithdraw() external onlyOwner { require(false); ... }`

**Impact:** Q1 → Emergency/recovery function = **CRITICAL IMPACT**
**Likelihood:** Q1 → require(false); Q2 → No, not intentional = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0** (Immediate fix required)

**Scenario 2:** `function oldDeposit() external { revert("Deprecated - use deposit() instead"); }`

**Impact:** Q1 → Intentionally deprecated = **INFORMATIONAL IMPACT (FALSE ALARM)**
**Likelihood:** Q1 → Unconditional revert; Q2 → Yes, intentional = **VERY LOW LIKELIHOOD (FALSE ALARM)**
**Final Priority:** INFORMATIONAL × VERY LOW = P4 (Recommendation: remove function entirely)

---

## 5. Generic Rules - Failing Calls

**Source File:** `GenericRules/specs/failing_calls.spec`

### Rule: `failing_CALL_leads_to_revert`

#### CVL Code

```cvl
persistent ghost bool saw_failing_call;

hook CALL(uint g, address addr, uint value, uint argsOffset, uint argsLength,
          uint retOffset, uint retLength) uint rc {
    saw_failing_call = saw_failing_call || rc == 0;
}

rule failing_CALL_leads_to_revert(method certoraF) {
    saw_failing_call = false;
    env e;
    calldataarg arg;
    certoraF@withrevert(e, arg);
    bool reverted = lastReverted;
    assert saw_failing_call => reverted, "a failing CALL did not lead to a revert of caller";
}
```

#### Rule Logic

Uses CALL hook to track if any external call returns `rc == 0` (failure). Asserts that such failures cause the caller to revert.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Input Validation** | **Primary** | Unchecked return values |
| **Logical Correctness** | **Primary** | Silent failure handling |
| **State Integrity** | Secondary | Prevents partial updates |

This directly addresses **OWASP SC06:2025 - Unchecked External Calls** ($550.7K losses in 2024).

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes** | Inputs causing external calls to fail |
| **Bad state integrity** | **Yes** | Invalid addresses stored |
| **Blockchain environment conditions** | **Yes** | Gas limits, out-of-gas in subcall |
| **Other contracts** | **Yes (Primary)** | External contract intentionally reverting |

#### Worst-Case Scenario Analysis

The classic unchecked `send()` / `call()` pattern:

```solidity
function withdraw(uint amount) external {
    balance[msg.sender] -= amount;
    (bool success,) = msg.sender.call{value: amount}(""); // Return value ignored!
}
```

**Real-World Examples:**
- **King of the Ether**: Failed ETH transfers appeared successful, breaking game logic
- **Parity Multisig**: Unchecked return values contributed to hack complexity

**Impact:** Critical - fund loss, state inconsistency
**Likelihood:** High when pattern exists
**False Alarm Risk:** Low - ignoring call failures is almost always a bug

#### Common False Alarm Patterns

1. **Intentional Fire-and-Forget Calls** - Logging to external contracts where failure is acceptable
2. **Try/Catch Handling** - May appear unchecked at opcode level but is handled
3. **Fallback/Receive Calls** - Calls expected to potentially fail (probing)

#### Mitigation Recommendations

1. **Always check return values** - `require(success, "Transfer failed")`
2. **Use `transfer()` or SafeERC20** - These revert automatically on failure
3. **Implement withdrawal patterns** - Let users pull funds instead of push
4. **Use try/catch for expected failures** - Handle gracefully when appropriate

```solidity
// Good pattern
(bool success,) = recipient.call{value: amount}("");
require(success, "ETH transfer failed");

// Better pattern for tokens
IERC20(token).safeTransfer(recipient, amount);
```

#### Impact & Likelihood Assessment Framework

This rule detects unchecked external call return values - a classic security vulnerability.

##### Impact Assessment Decision Tree

```
START: Rule violation - external call failure not causing revert
│
├─→ [Q1] What type of external call failed?
│   ├─→ ETH transfer (call, send)
│   │   ├─→ [Q2] Does state update before the call?
│   │   │   ├─→ Yes (balance[user] -= amount; then call)
│   │   │   │   └─→ CRITICAL IMPACT
│   │   │   │       Justification: State inconsistency + fund loss
│   │   │   │       Example: Balance decremented but ETH not sent
│   │   │   │
│   │   │   └─→ No (call happens first)
│   │   │       └─→ HIGH IMPACT
│   │   │           Justification: Funds lost, user unaware
│   │   │
│   │   ├─→ ERC20 token transfer
│   │   │   └─→ HIGH IMPACT
│   │   │       Justification: Silent failure, tokens not transferred
│   │   │
│   │   ├─→ Callback/notification call
│   │   │   ├─→ [Q3] Is callback critical to protocol logic?
│   │   │   │   ├─→ Yes (affects state/accounting)
│   │   │   │   │   └─→ HIGH IMPACT
│   │   │   │   │       Justification: State inconsistency
│   │   │   │   │
│   │   │   │   └─→ No (informational/logging only)
│   │   │   │       └─→ LOW IMPACT (Possibly FALSE ALARM)
│   │   │   │           Justification: Fire-and-forget pattern may be intentional
│   │   │
│   │   └─→ External protocol interaction
│   │       └─→ MEDIUM IMPACT
│   │           Justification: Integration failure, partial state update
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] What causes the external call to fail?
│   ├─→ Recipient contract intentionally reverts
│   │   ├─→ [Q2] Is recipient user-controlled?
│   │   │   ├─→ Yes (e.g., msg.sender)
│   │   │   │   └─→ VERY HIGH LIKELIHOOD
│   │   │   │       Justification: Attacker deploys reverting contract
│   │   │   │
│   │   │   └─→ No (trusted/whitelisted addresses)
│   │   │       └─→ LOW LIKELIHOOD
│   │   │           Justification: Requires compromise of trusted contract
│   │   │
│   │   ├─→ Out of gas in subcall
│   │   │   └─→ MEDIUM LIKELIHOOD
│   │   │       Justification: Can be triggered with complex fallback functions
│   │   │
│   │   └─→ Recipient has no receive/fallback
│   │       └─→ HIGH LIKELIHOOD
│   │           Justification: EOAs accept ETH, but contracts may not
│   │
│   └─→ [Q3] Is there try/catch handling?
│       ├─→ Yes, but appears unchecked at opcode level
│       │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│       │       Justification: Actually handled, verification artifact
│       │
│       └─→ No try/catch
│           └─→ Maintain above likelihood assessment
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment

**Scenario:** `function withdraw(uint amount) external { balance[msg.sender] -= amount; msg.sender.call{value: amount}(""); }`

**Impact:** Q1 → ETH transfer; Q2 → Yes, state updates before call = **CRITICAL IMPACT**
**Likelihood:** Q1 → Recipient intentionally reverts; Q2 → Yes, user-controlled (msg.sender) = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0** (Critical vulnerability - reentrancy + unchecked return)

**Scenario 2:** `function notifyObserver() external { observerContract.call(data); /* continue regardless */ }`

**Impact:** Q1 → Callback/notification; Q3 → No, informational only = **LOW IMPACT (FALSE ALARM)**
**Likelihood:** Q3 → No try/catch but intentional fire-and-forget = **LOW LIKELIHOOD**
**Final Priority:** LOW × LOW = P4 (May be intentional pattern - verify with developers)

---

## 6. Generic Rules - One-Time Functions

**Source File:** `GenericRules/specs/one_time_functions.spec`

### Rules Overview

| Rule | Same User? | Same Input? |
|------|-----------|-------------|
| `oneTimeFunctionPerUserAnyInput` | Yes | No |
| `oneTimeFunctionPerUserSameInput` | Yes | Yes |
| `oneTimeFunctionGlobalAnyInput` | No | No |
| `oneTimeFunctionGlobalSameInput` | No | Yes |

#### CVL Code (Per-User, Any Input)

```cvl
rule oneTimeFunctionPerUserAnyInput(method certoraF) {
    env e1;
    calldataarg arg1;
    env e2;
    calldataarg arg2;

    require e1.msg.sender == e2.msg.sender, "per user one-time function check";
    timeProgresses(e1, e2);

    certoraF(e1, arg1); // first call, assume succeeds
    certoraF(e2, arg2); // second call, may revert
    satisfy true, "satisfy would be violated if it is a one-time function";
}

function timeProgresses(env e1, env e2) {
    require e1.block.timestamp <= e2.block.timestamp;
    require e1.block.number <= e2.block.number;
}
```

#### Rule Logic

Tests whether functions can be called successfully twice (with time progression). Uses `satisfy true` which fails if the second call always reverts - indicating a one-time function.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Logical Correctness** | **Primary** | Identifies initialization/claim functions |
| **Permission Control** | Secondary | One-time operations often control setup |
| **State Integrity** | Secondary | Prevents re-initialization attacks |

#### Worst-Case Scenario Analysis

Unprotected initializer that should be one-time:

```solidity
function initialize(address _owner) external {
    // BUG: Missing initialized check
    owner = _owner;
}
```

**Real-World Examples:**
- **Audius (July 2022)**: Re-invocable initialize function allowed attacker to claim ownership
- **Harvest Finance Bug Bounty**: Uninitialized proxy implementations could be taken over

**Impact:** Critical - complete protocol takeover
**Likelihood:** High for initializers
**False Alarm Risk:** Low for initializers; High for intentionally repeatable functions

#### Common False Alarm Patterns

1. **Intentionally One-Time Functions** - `claim()`, `initialize()`, `renounceOwnership()` - detection is intended
2. **Rate-Limited Functions** - Cooldown-based restrictions appear one-time within window
3. **Idempotent Operations** - `approve(spender, amount)` - same value doesn't revert
4. **State-Dependent Access** - Functions callable once per state transition

#### Mitigation Recommendations

1. **Use OpenZeppelin Initializable** - `initializer` modifier prevents re-initialization
2. **Implement explicit flags** - `require(!initialized); initialized = true;`
3. **Use constructors for proxies** - Initialize in `constructor` when possible
4. **Add access control** - `require(msg.sender == deployer)` for initialization

```solidity
// OpenZeppelin pattern
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";

contract MyContract is Initializable {
    function initialize(address _owner) external initializer {
        owner = _owner;
    }
}
```

#### Impact & Likelihood Assessment Framework

These rules detect initialization/setup functions that can be called multiple times - a critical vulnerability in upgradeable contracts.

##### Impact Assessment Decision Tree

```
START: Rule fails - function can be called multiple times
│
├─→ [Q1] What does the function initialize/configure?
│   ├─→ Contract ownership or critical roles
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Takeover vulnerability - attacker can become owner
│   │       Example: initialize() setting owner variable
│   │
│   ├─→ Protocol parameters (fees, addresses, thresholds)
│   │   └─→ HIGH IMPACT
│   │       Justification: Protocol hijacking
│   │       Example: Setting treasury address or fee recipient
│   │
│   ├─→ Token parameters (name, symbol, supply)
│   │   └─→ HIGH IMPACT
│   │       Justification: Token integrity compromise
│   │
│   ├─→ User-specific state (per-user initialization)
│   │   └─→ LOW IMPACT (Likely FALSE ALARM)
│   │       Justification: May be intentionally callable multiple times
│   │       Example: User profile setup
│   │
│   └─→ Informational/metadata state
│       └─→ LOW IMPACT
│           Justification: Limited security impact
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Is there ANY protection against re-initialization?
│   ├─→ No protection at all (no modifier, no checks)
│   │   └─→ VERY HIGH LIKELIHOOD
│   │       Justification: Trivially exploitable, already public
│   │
│   ├─→ Custom check without proper state variable
│   │   ├─→ [Q2] Is the check robust?
│   │   │   ├─→ No (e.g., require(owner == address(0)))
│   │   │   │   └─→ HIGH LIKELIHOOD
│   │   │   │       Justification: Check can be bypassed (owner reset)
│   │   │   │
│   │   │   └─→ Yes (e.g., dedicated initialized flag)
│   │   │       └─→ LOW LIKELIHOOD (Possibly FALSE ALARM)
│   │   │           Justification: Rule may be imprecise
│   │   │
│   │   ├─→ OpenZeppelin Initializable modifier present
│   │   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │   │       Justification: Protected by battle-tested library
│   │   │       Note: Verify modifier is correctly applied
│   │   │
│   │   └─→ Access control present (onlyOwner, etc.)
│   │       ├─→ [Q3] Does access control prevent re-init by owner?
│   │       │   ├─→ No → MEDIUM LIKELIHOOD
│   │       │   │   Justification: Owner can re-initialize (may be intentional)
│   │       │   │
│   │       │   └─→ Yes → LOW LIKELIHOOD
│   │       │       Justification: Limited attack surface
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment

**Scenario:** `function initialize(address _owner) external { owner = _owner; }`

**Impact:** Q1 → Contract ownership = **CRITICAL IMPACT**
**Likelihood:** Q1 → No protection at all = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0** (Critical vulnerability - immediate fix)

**Scenario 2:** `function initialize(address _owner) external initializer { owner = _owner; }`

**Impact:** Q1 → Contract ownership = **CRITICAL IMPACT**
**Likelihood:** Q1 → OpenZeppelin Initializable modifier = **VERY LOW LIKELIHOOD (FALSE ALARM)**
**Final Priority:** CRITICAL × VERY LOW = P3 (Verify modifier is correctly applied, likely protected)

**Scenario 3:** `function setupUserProfile(string memory name) external { userProfiles[msg.sender].name = name; }`

**Impact:** Q1 → User-specific state = **LOW IMPACT (FALSE ALARM)**
**Likelihood:** Intentionally callable multiple times = **LOW LIKELIHOOD**
**Final Priority:** LOW × LOW = P4 (Working as intended)

---

## 7. Generic Rules - Safe Casts

**Source File:** `GenericRules/specs/safe_casts.spec`

### Rule: `safeCasting` (builtin)

#### CVL Code

```cvl
use builtin rule safeCasting;
```

#### Rule Logic

Uses Certora's builtin `safeCasting` rule to verify type conversions don't lose precision.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Math Precision** | **Primary** | Integer overflow/underflow in casts |
| **Logical Correctness** | Secondary | Ensures data integrity across type boundaries |

This addresses **OWASP SC08:2025 - Integer Overflow and Underflow**.

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes (Primary)** | User provides large values cast to smaller types |
| **Bad state integrity** | **Yes** | Accumulated state exceeds type bounds |
| **Blockchain environment conditions** | Unlikely | Block numbers/timestamps rarely cause cast issues |
| **Other contracts** | **Yes** | External returns cast unsafely |

#### Worst-Case Scenario Analysis

Downcasting large uint256 to uint128/uint64/uint8:

```solidity
function recordBalance(uint256 amount) external {
    uint128 stored = uint128(amount); // Silently truncates if amount > 2^128
    balances[msg.sender] = stored;
}
```

**Real-World Examples:**
- **Poolz Finance (March 2023, $390K)**: Integer overflow in LockedControl contract
- **Cetus DEX (May 2025, $223M)**: Missed overflow check in core logic
- **Balancer (Nov 2025, $128M)**: Logic and precision flaws

**Impact:** Critical - fund theft, accounting errors
**Likelihood:** High in pre-0.8 Solidity; Medium in 0.8+ without SafeCast
**False Alarm Risk:** Low - unsafe casts are almost always bugs

#### Common False Alarm Patterns

1. **Intentional Wrapping (Rare)** - Should use `unchecked` block explicitly
2. **Known-Safe Ranges** - Requires domain knowledge to verify safety
3. **Timestamp/Block Number Casts** - `uint64(block.timestamp)` overflow in year 2554

#### Mitigation Recommendations

1. **Use OpenZeppelin SafeCast** - All conversions revert on overflow

```solidity
import "@openzeppelin/contracts/utils/math/SafeCast.sol";

using SafeCast for uint256;

function recordBalance(uint256 amount) external {
    uint128 stored = amount.toUint128(); // Reverts if overflow
    balances[msg.sender] = stored;
}
```

2. **Validate before casting** - `require(amount <= type(uint128).max)`
3. **Use appropriately sized types** - Don't downcast unless necessary
4. **Document assumptions** - If a value is known-bounded, explain why

#### Impact & Likelihood Assessment Framework

This rule detects unsafe type downcasting that may lose precision or cause overflow.

##### Impact Assessment Decision Tree

```
START: Rule violation - unsafe downcast detected
│
├─→ [Q1] What is being downcast?
│   ├─→ Financial amounts (balances, prices, values)
│   │   ├─→ [Q2] What's the downcast target type?
│   │   │   ├─→ Very restrictive (uint8, int8)
│   │   │   │   └─→ CRITICAL IMPACT
│   │   │   │       Justification: High probability of overflow, fund loss
│   │   │   │       Example: uint256 balance → uint8 (max 255)
│   │   │   │
│   │   │   ├─→ Moderately restrictive (uint64, uint128)
│   │   │   │   └─→ HIGH IMPACT
│   │   │   │       Justification: Can overflow with large amounts
│   │   │   │       Example: uint256 → uint128 in DeFi protocols
│   │   │   │
│   │   │   └─→ Large type (uint128 → uint64 for timestamps)
│   │   │       └─→ MEDIUM IMPACT
│   │   │           Justification: Edge case overflow risk
│   │   │
│   │   ├─→ Array indices or counters
│   │   │   └─→ MEDIUM IMPACT
│   │   │       Justification: Can cause incorrect iteration or access
│   │   │
│   │   ├─→ Timestamps or block numbers
│   │   │   ├─→ [Q3] Target type < uint40?
│   │   │   │   ├─→ Yes → HIGH IMPACT
│   │   │   │   │   Justification: Will overflow in foreseeable future
│   │   │   │   │
│   │   │   │   └─→ No (uint40+) → LOW IMPACT
│   │   │   │       Justification: Safe for centuries (uint40 good until year 36812)
│   │   │
│   │   └─→ Informational data (IDs, flags)
│   │       └─→ LOW IMPACT
│   │           Justification: Limited security implications
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate overflow likelihood
│
├─→ [Q1] Is the value bounded before casting?
│   ├─→ No validation at all
│   │   ├─→ [Q2] Is the input user-controlled?
│   │   │   ├─→ Yes → VERY HIGH LIKELIHOOD
│   │   │   │   Justification: Attacker can supply max uint256
│   │   │   │
│   │   │   └─→ No (derived from contract state)
│   │   │       ├─→ [Q3] Can state values grow unbounded?
│   │   │       │   ├─→ Yes (accumulating balances/sums) → HIGH LIKELIHOOD
│   │   │       │   └─→ No (inherently bounded) → MEDIUM LIKELIHOOD
│   │   │
│   │   ├─→ Validation present but insufficient
│   │   │   └─→ MEDIUM LIKELIHOOD
│   │   │       Justification: Partial protection
│   │   │
│   │   └─→ Comprehensive validation (require checks or SafeCast library)
│   │       └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │           Justification: Protected against overflow
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment

**Scenario:** `function deposit(uint256 amount) external { uint128 stored = uint128(amount); balances[msg.sender] = stored; }`

**Impact:** Q1 → Financial amounts; Q2 → uint128 = **HIGH IMPACT**
**Likelihood:** Q1 → No validation; Q2 → Yes, user-controlled = **VERY HIGH LIKELIHOOD**
**Final Priority:** HIGH × VERY HIGH = **P0** (Critical - can deposit 2^256-1, only store 2^128-1)

**Scenario 2:** `function updateTimestamp() external { lastUpdate = uint40(block.timestamp); }`

**Impact:** Q1 → Timestamps; Q3 → uint40 = **LOW IMPACT**
**Likelihood:** Q1 → No validation but inherently bounded = **MEDIUM LIKELIHOOD**
**Final Priority:** LOW × MEDIUM = P4 (Safe until year 36812)

---

## 8. Generic Rules - Self Calls

**Source File:** `GenericRules/specs/self_calls.spec`

### Rule: `noSelfCalls`

#### CVL Code

```cvl
persistent ghost bool callMade;
persistent ghost bool delegatecallMade;

hook CALL(uint g, address addr, uint value, uint argsOffset, uint argsLength,
          uint retOffset, uint retLength) uint rc {
    if (addr == executingContract) {
        callMade = true;
    }
}

hook DELEGATECALL(uint g, address addr, uint argsOffset, uint argsLength,
                  uint retOffset, uint retLength) uint rc {
    if (addr == executingContract) {
        delegatecallMade = true;
    }
}

rule noSelfCalls(method certoraF) {
    env e;
    calldataarg args;

    callMade = false;
    delegatecallMade = false;

    certoraF(e, args);

    assert !callMade && !delegatecallMade, "self call detected";
}
```

#### Rule Logic

Uses CALL and DELEGATECALL hooks to detect if a contract ever calls itself (where `addr == executingContract`).

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Reentrancy** | **Primary** | Self-calls are a reentrancy vector |
| **Logical Correctness** | Secondary | Unexpected recursion |
| **Permission Control** | Secondary | Self-calls may bypass `msg.sender` checks |

#### Scope Classification

**Type:** Self-call detection

Enables safe assumption that `e.msg.sender != currentContract` in other specs.

#### Worst-Case Scenario Analysis

Self-call enabling reentrancy:

```solidity
function callback(bytes calldata data) external {
    // Attacker can call back into this contract
    (bool success,) = address(this).call(data);
}
```

**Real-World Examples:**
- **Penpie (Sept 2024, $27M)**: Reentrancy via callback mechanisms
- **Curve Finance (July 2023, $70M)**: Reentrancy via compiler bug

**Impact:** High - enables reentrancy attacks
**Likelihood:** Medium when self-call exists
**False Alarm Risk:** Medium - some self-calls are legitimate

#### Common False Alarm Patterns

1. **Intentional Internal Routing** - Contracts routing through `address(this).call()` for gas
2. **Proxy Patterns** - Proxies delegating to themselves for certain selectors
3. **Batch Operations** - `multicall` patterns: `address(this).call(calls[i])`

#### Mitigation Recommendations

1. **Implement ReentrancyGuard** - OpenZeppelin's `nonReentrant` modifier

```solidity
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract MyContract is ReentrancyGuard {
    function sensitiveFunction() external nonReentrant {
        // Protected from reentrancy
    }
}
```

2. **Follow Checks-Effects-Interactions (CEI) pattern**
   - Check conditions
   - Update state
   - Then make external calls

3. **Avoid self-calls when possible** - Use internal functions instead
4. **If multicall is needed** - Implement with proper reentrancy protection

#### Impact & Likelihood Assessment Framework

This rule detects contracts calling themselves via external calls - a reentrancy risk pattern.

##### Impact Assessment Decision Tree

```
START: Rule violation - contract makes external call to itself
│
├─→ [Q1] What happens during the self-call?
│   ├─→ State modifications with reentrancy potential
│   │   └─→ HIGH IMPACT
│   │       Justification: Reentrancy vulnerability
│   │       Example: Multicall function calling other functions
│   │
│   ├─→ Read-only operations (view functions)
│   │   └─→ LOW IMPACT
│   │       Justification: No state inconsistency risk
│   │
│   └─→ Intentional multicall/batch pattern
│       ├─→ [Q2] Is there reentrancy protection?
│       │   ├─→ Yes (nonReentrant modifier) → LOW IMPACT
│       │   │   Justification: Protected design pattern
│       │   │
│       │   └─→ No protection → HIGH IMPACT
│       │       Justification: Vulnerable to reentrancy
│
└─→ OUTPUT: Impact Level (HIGH/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Is this an intentional multicall pattern?
│   ├─→ Yes (documented multicall functionality)
│   │   ├─→ [Q2] Reentrancy guards present?
│   │   │   ├─→ Yes → VERY LOW LIKELIHOOD (FALSE ALARM)
│   │   │   │   Justification: Working as designed with protections
│   │   │   │
│   │   │   └─→ No → HIGH LIKELIHOOD
│   │   │       Justification: Known pattern but vulnerable
│   │   │
│   │   └─→ No - unintentional self-call
│   │       └─→ MEDIUM LIKELIHOOD
│   │           Justification: Logic error, exploitability depends on context
│
└─→ OUTPUT: Likelihood Level (HIGH/MEDIUM/LOW/VERY LOW)
```

##### Example Assessment

**Scenario:** `function multicall(bytes[] calldata data) external { for(uint i=0; i<data.length; i++) { address(this).call(data[i]); } }`

**Impact:** Q1 → State modifications with reentrancy potential = **HIGH IMPACT**
**Likelihood:** Q1 → Yes, intentional multicall; Q2 → No guards = **HIGH LIKELIHOOD**
**Final Priority:** HIGH × HIGH = **P1** (Add nonReentrant modifier)

---

## 9. Generic Rules - Message Value in Loop

**Source File:** `GenericRules/specs/msg_value_in_loop.spec`

### Rule: `msgValueInLoopRule` (builtin)

#### CVL Code

```cvl
use builtin rule msgValueInLoopRule;
```

#### Rule Logic

Uses Certora's builtin `msgValueInLoopRule` to detect functions that access `msg.value` or make delegate calls inside loops. The rule identifies patterns where the same `msg.value` can be reused across multiple loop iterations, which is a critical vulnerability enabling fund drainage.

The rule recursively checks all function calls in the call tree - if any function in the chain exhibits this pattern, the rule fails.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Logical Correctness** | **Primary** | Detects msg.value reuse in loops |
| **Input Validation** | **Primary** | Prevents exploitation via array manipulation |
| **Reentrancy** | Secondary | Delegatecall in loops can enable reentrancy |
| **Fund Theft** | **Primary** | Direct path to contract drainage |

This directly addresses a critical vulnerability class responsible for multi-million dollar losses.

#### Scope Classification

**Type:** Code pattern detection at opcode level

Analyzes execution paths to detect any loop containing either:
1. Access to `msg.value`
2. Execution of `DELEGATECALL` instruction

The check is transitive - functions that call vulnerable functions are also flagged.

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes (Primary)** | Attacker controls loop iterations, recipient arrays, amount arrays |
| **Bad state integrity** | Unlikely | Vulnerability is in code structure, not state |
| **Blockchain environment conditions** | No | Independent of blockchain state |
| **Other contracts** | **Yes** | Delegatecall to external contracts in loops |

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood (Least False Alarm):**

A batch payment function that reuses `msg.value` across multiple recipients:

```solidity
function batchTransfer(address[] calldata recipients, uint256[] calldata amounts)
    external
    payable
{
    for (uint i = 0; i < recipients.length; i++) {
        // BUG: msg.value is reused in each iteration!
        require(msg.value >= amounts[i], "Insufficient payment");
        payable(recipients[i]).transfer(amounts[i]);
    }
}
```

**Attack scenario:**
- Attacker sends 1 ETH with transaction
- Provides 10 recipients, each with amount = 0.5 ETH
- Each iteration checks `msg.value >= 0.5 ETH` (always true!)
- Total sent: 5 ETH, but attacker only paid 1 ETH
- Contract drained if it has balance

**Real-World Examples:**

**Opyn Hack (August 2020, $371,260):**
The decentralized options protocol Opyn was exploited when attackers reused `msg.value` in a loop to purchase options at a fraction of their normal cost. The vulnerability allowed attackers to buy ETH call options worth ~$1.4M for only ~$370K.

**MISO Vulnerability (August 2021, $350M at risk):**
On August 18, 2021, samczsun reported a critical vulnerability in SushiSwap's MISO smart contracts putting 109,000 ETH (~$350M) at risk. The issue was similar to the Opyn attack - `msg.value` was reused in payable multicalls.

**Impact:** Critical - complete fund drainage possible
**Likelihood:** High when pattern exists - attackers actively scan for this
**False Alarm Risk:** Very Low - this pattern is almost always a critical bug

#### Common False Alarm Patterns

This builtin rule has **extremely low false positive rate**. The only legitimate scenarios are:

1. **Single Iteration Loops**
   - Loops that are proven to execute exactly once
   - Still flagged as the pattern is inherently dangerous

2. **msg.value Used Only for Validation Outside Loop Body**
   - Code reads `msg.value` before loop, uses cached value in loop
   - May still trigger if analysis detects `msg.value` access in loop context

3. **Delegatecall Batching in Multicall Patterns**
   - Intentional multicall/batch transaction systems
   - Legitimate but requires extremely careful implementation
   - *Example:* Uniswap's `multicall` function (carefully audited)

**Note:** Even when flagged as "false positive," these patterns warrant extensive security review.

#### Technical Deep Dive

**Why is msg.value reuse dangerous?**

`msg.value` is part of the transaction context (`msg.*` global variables) and remains immutable throughout the entire transaction execution, including all internal and external calls (although note external calls get their own `msg.value`). Resulting from that, it is obviously NOT:
- Decremented when ETH is sent
- Scoped to individual function calls
- Reset between loop iterations

**Delegatecall concerns:**

When using `delegatecall` in a loop with non-zero `msg.value`:
- Each delegated call sees the same `msg.value`
- Delegated code can treat it as "fresh" payment each time
- Enables creating phantom funds

**Solidity 0.8+ note:**

This vulnerability exists across all Solidity versions. The built-in overflow protection in Solidity 0.8+ does NOT prevent this issue because no arithmetic overflow occurs - the logic itself is flawed.

#### Mitigation Recommendations

1. **Track msg.value consumption explicitly**

```solidity
function batchTransfer(address[] calldata recipients, uint256[] calldata amounts)
    external
    payable
{
    uint256 totalRequired = 0;
    for (uint i = 0; i < recipients.length; i++) {
        totalRequired += amounts[i];
    }
    require(msg.value == totalRequired, "Incorrect payment");

    for (uint i = 0; i < recipients.length; i++) {
        payable(recipients[i]).transfer(amounts[i]);
    }
}
```

2. **Process msg.value outside the loop**

```solidity
function batchTransfer(address[] calldata recipients, uint256[] calldata amounts)
    external
    payable
{
    uint256 remaining = msg.value;
    for (uint i = 0; i < recipients.length; i++) {
        require(remaining >= amounts[i], "Insufficient funds");
        remaining -= amounts[i];
        payable(recipients[i]).transfer(amounts[i]);
    }
    // Return excess
    if (remaining > 0) {
        payable(msg.sender).transfer(remaining);
    }
}
```

3. **Avoid delegatecall in loops with payable functions**
   - Never combine `delegatecall` + loops + `payable`
   - If multicall is needed, implement with extreme care and audit

4. **Use separate transactions for each payment**
   - When possible, avoid batch processing with `msg.value`

5. **Implement comprehensive testing**
   - Test with varying array lengths
   - Test with intentionally low `msg.value`
   - Verify contract balance changes match expectations

#### Impact & Likelihood Assessment Framework

This rule detects `msg.value` used inside loops - can cause double-spending of the same ETH.

##### Impact Assessment Decision Tree

```
START: Rule violation - msg.value accessed in loop
│
├─→ [Q1] How is msg.value used in the loop?
│   ├─→ Transferred/sent to multiple recipients
│   │   └─→ CRITICAL IMPACT
│   │       Justification: Double-spending bug - same ETH counted multiple times
│   │       Example: Each iteration sends msg.value, but only sent once total
│   │
│   ├─→ Used in accounting/validation checks
│   │   └─→ HIGH IMPACT
│   │       Justification: Incorrect financial logic
│   │       Example: Sum checks that multiply msg.value by loop count
│   │
│   ├─→ Read-only logging or event emission
│   │   └─→ LOW IMPACT (Possibly FALSE ALARM)
│   │       Justification: No financial impact
│   │
│   └─→ Single iteration loop or break after first
│       └─→ MEDIUM IMPACT (Likely FALSE ALARM)
│           Justification: Technically violates pattern but not exploitable
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Does the loop actually iterate multiple times?
│   ├─→ Yes, variable-length arrays with user control
│   │   └─→ VERY HIGH LIKELIHOOD
│   │       Justification: Trivially exploitable
│   │
│   ├─→ Yes, but fixed small iterations (2-3)
│   │   └─→ HIGH LIKELIHOOD
│   │       Justification: Still vulnerable, limited scale
│   │
│   ├─→ Single iteration or early exit
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │       Justification: Loop structure but no actual bug
│   │
│   └─→ Read-only use of msg.value
│       └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│           Justification: No double-spending possible
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | LOW | VERY LOW |
|---------------------|-----------|------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 |

##### Example Assessment

**Scenario:** `function batchPay(address[] calldata recipients) external payable { for(uint i=0; i<recipients.length; i++) { recipients[i].call{value: msg.value}(""); } }`

**Impact:** Q1 → Transferred to multiple recipients = **CRITICAL IMPACT**
**Likelihood:** Q1 → Yes, variable-length user-controlled = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0** (Critical bug - same ETH sent N times)

---

## 10. Generic Rules - View Reentrancy

**Source File:** `GenericRules/specs/view_reentrancy.spec`

### Rule: `viewReentrancy` (builtin)

#### CVL Code

```cvl
use builtin rule viewReentrancy;
```

#### Rule Logic

Uses Certora's builtin `viewReentrancy` rule to detect read-only reentrancy vulnerabilities. The rule identifies execution paths where:
1. A contract makes an external call with an inconsistent internal state
2. The external call can re-enter view functions (or call other contracts' view functions that depend on this contract's state)
3. The view functions return values based on the inconsistent intermediate state

Unlike traditional reentrancy which modifies state, read-only reentrancy exploits the window where state is temporarily inconsistent to read manipulated values, typically for price oracle manipulation.

#### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Reentrancy** | **Primary** | Detects read-only reentrancy vectors |
| **Oracle Manipulation** | **Primary** | View functions used as price oracles |
| **State Integrity** | **Primary** | Identifies inconsistent state windows |
| **Logical Correctness** | Secondary | Ensures view functions return accurate data |

This addresses a novel vulnerability class responsible for **$100M+ funds at risk** across DeFi protocols.

#### Scope Classification

**Type:** Cross-contract state consistency analysis

Analyzes execution flows to detect patterns where:
- State-modifying operations occur in specific order
- External calls are made mid-state-update
- View functions can be called during inconsistent state

This is a **global property** check requiring analysis of the entire contract and its interactions with potential callers.

#### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes** | Attacker triggers specific execution paths |
| **Bad state integrity** | N/A | Vulnerability is the temporary state inconsistency itself |
| **Blockchain environment conditions** | Unlikely | Independent of block properties |
| **Other contracts** | **Yes (Primary)** | Attack requires interaction with external contracts during inconsistent state |

#### Worst-Case Scenario Analysis

**Highest Impact + Highest Likelihood (Least False Alarm):**

There are two main patterns where read-only reentrancy vulnerabilities occur:

**Pattern 1: State Updated AFTER External Calls (CEI Violation)**

```solidity
contract VulnerablePool {
    uint256 public totalSupply;
    uint256 public reserveA;
    uint256 public reserveB;

    // View function used as price oracle
    function getPrice() public view returns (uint256) {
        return (reserveA * 1e18) / totalSupply;
    }

    function removeLiquidity(uint256 amount) external {
        // BUG: Burn tokens first, update reserves later
        totalSupply -= amount;

        // External calls happen while reserves still have old values
        uint256 amountA = calculateAmountA(amount);
        uint256 amountB = calculateAmountB(amount);

        IERC20(tokenA).transfer(msg.sender, amountA);
        // VULNERABILITY WINDOW: During this callback, totalSupply is decreased
        // but reserveA and reserveB still have their original values!
        // getPrice() = (OLD_reserveA * 1e18) / NEW_totalSupply = INFLATED!

        IERC20(tokenB).transfer(msg.sender, amountB);

        // State finally updated AFTER external calls
        reserveA -= amountA;
        reserveB -= amountB;
    }
}
```

**Attack Flow (Pattern 1):**
1. Attacker calls `removeLiquidity()`
2. `totalSupply` is decreased (denominator goes down)
3. First external token transfer occurs
4. During transfer callback, `getPrice()` is called
5. `getPrice()` sees: decreased `totalSupply` but original `reserveA`
6. Returns inflated price (larger numerator / smaller denominator)
7. Attacker uses inflated price to over-borrow from lending protocol

**Pattern 2: Iterative Processing With Mid-Loop State Inconsistency**

This is the actual Curve vulnerability pattern:

```solidity
contract VulnerablePool {
    uint256 public totalSupply;
    uint256[2] public balances; // reserveA, reserveB
    address[2] public coins;

    function get_virtual_price() public view returns (uint256) {
        uint256 D = get_D(balances); // Total value calculation
        return (D * PRECISION) / totalSupply;
    }

    function remove_liquidity(uint256 _amount, uint256[2] calldata min_amounts) external {
        // BUG: Burn LP tokens immediately
        totalSupply -= _amount;

        uint256[2] memory amounts = calculate_amounts(_amount);

        // Transfer tokens one by one in a loop
        for (uint i = 0; i < 2; i++) {
            if (coins[i] == ETH_ADDRESS) {
                // ETH transfer - can trigger fallback
                payable(msg.sender).transfer(amounts[i]);
                // VULNERABILITY WINDOW: During ETH fallback callback:
                // - totalSupply is already decreased (NEW value)
                // - balances[0] (first token) transferred out (decreased)
                // - balances[1] (second token) NOT YET transferred (OLD value)
                // get_virtual_price() calculates D from inconsistent balances!
            } else {
                IERC20(coins[i]).transfer(msg.sender, amounts[i]);
            }
            balances[i] -= amounts[i];
        }
    }
}
```

**Attack Flow (Pattern 2 - Curve/Balancer):**
1. Attacker calls `remove_liquidity()`
2. LP tokens burned: `totalSupply` decreased
3. Loop begins transferring tokens
4. **First iteration**: ETH transferred, triggers attacker's fallback
5. **During callback**:
   - `totalSupply`: NEW (decreased)
   - `balances[0]`: Already transferred out
   - `balances[1]`: Still in pool (not yet sent)
6. `get_virtual_price()` calculation uses inconsistent balances
7. Pool appears to have more value per LP token than reality
8. Attacker uses this in lending protocol to borrow against inflated collateral value

**Common Attacker Contract:**

```solidity
contract AttackerLendingProtocol {
    VulnerablePool public pool;
    LendingProtocol public lendingProtocol;

    receive() external payable {
        // Reentered during ETH transfer from pool
        uint256 manipulatedPrice = pool.getPrice(); // or get_virtual_price()

        // Use manipulated price to borrow more than collateral is worth
        lendingProtocol.borrow(
            address(pool), // LP token as collateral
            calculateMaxBorrow(manipulatedPrice) // Inflated!
        );
    }
}
```

**Real-World Examples:**

**dForce Attack (February 9, 2023, $3.7M):**
dForce's lending protocol on Arbitrum and Optimism was attacked using read-only reentrancy to manipulate Curve pool price oracles. The attacker exploited the window during `remove_liquidity` where LP tokens were burned but tokens hadn't been transferred yet. During this window, `get_virtual_price()` returned manipulated values, allowing over-borrowing from lending pools.

**Curve Finance Attack (July 30, 2023, $70M):**
Curve Finance fell victim to a reentrancy attack due to a Vyper compiler bug (versions 0.2.15, 0.2.16, 0.3.0) where reentrancy guards were not properly implemented. The bug allowed manipulation of the `get_virtual_price` view function during liquidity operations, enabling price oracle manipulation.

**Sentiment Protocol (April 2023, $220K):**
Read-only reentrancy vulnerability in Curve LP oracle integration allowed attackers to manipulate the perceived value of LP tokens during withdrawal operations.

**Penpie Attack (September 3, 2024, $27M):**
Penpie, a yield farming protocol built on Pendle, suffered a reentrancy attack exploiting the `_harvestBatchMarketRewards` function. The attacker used reentrancy to manipulate reward calculations during external calls.

**Impact:** Critical - oracle manipulation enables over-borrowing, fund theft
**Likelihood:** High for protocols using vulnerable pools as oracles
**False Alarm Risk:** Medium - some view function calls during state updates are safe

#### Common False Alarm Patterns

1. **View Functions Not Used as Oracles**
   - Contract has view functions callable during state updates
   - But these views are never used by external protocols for critical decisions
   - *Note:* Still risky - composability means future integrations could be vulnerable

2. **View Functions With Reentrancy Guards**
   - Some protocols implement `nonReentrant` on view functions
   - This is unusual but valid pattern for high-security scenarios
   - Rule may still flag if guard detection is complex

3. **Consistent State Despite Ordering**
   - View function reads multiple state variables
   - Update order doesn't create exploitable inconsistency
   - *Example:* Reading balances of independent users

4. **Internal View Functions**
   - View functions only called internally, never exposed for external use
   - Cannot be exploited by external attackers
   - Rule may flag for completeness

5. **Atomic State Updates With SafeTransfer**
   - Using `SafeERC20.safeTransfer` which doesn't call back to sender
   - Eliminates reentrancy vector even if state is updated before transfer
   - *Note:* Only safe if ALL tokens used are non-reentrant

#### Technical Deep Dive

**Why are view functions vulnerable?**

View functions typically lack reentrancy guards because:
- They don't modify state (`view`/`pure` modifiers)
- Developers assume no security risk
- Reentrancy guards (like OpenZeppelin's `nonReentrant`) add gas costs
- Standard assumption: "view functions are read-only, therefore safe"

**The flaw in this reasoning:**

While view functions don't modify state, they **return values based on current state**. If state is temporarily inconsistent, view functions return inconsistent values. External protocols using these values (price oracles, collateral calculations, etc.) can be exploited.

**Curve/Balancer LP Token Oracle Vulnerability:**

Curve and Balancer pools provide `get_virtual_price()` to calculate LP token value:

```solidity
function get_virtual_price() public view returns (uint256) {
    return (D * PRECISION) / totalSupply;
}
```

During `remove_liquidity`:
1. LP tokens burned (totalSupply decreases)
2. ETH/tokens transferred to user (D not yet decreased in view)
3. If transfer triggers callback, `get_virtual_price()` returns inflated value
4. Lending protocols using this as oracle see inflated collateral value

**ChainSecurity's Warning (April 2023):**

Three months before the major Curve attack, ChainSecurity notified Curve of read-only reentrancy vulnerability in `get_virtual_price()`. The mechanism was known but difficult to fix without breaking existing integrations.

#### Mitigation Recommendations

1. **Implement Checks-Effects-Interactions (CEI) pattern**

```solidity
function removeLiquidity(uint256 amount) external {
    // Checks
    require(balances[msg.sender] >= amount, "Insufficient balance");

    // Effects - Update ALL state first
    totalSupply -= amount;
    reserveA -= amountA;
    reserveB -= amountB;
    balances[msg.sender] -= amount;

    // Interactions - External calls last
    IERC20(tokenA).transfer(msg.sender, amountA);
    IERC20(tokenB).transfer(msg.sender, amountB);
}
```

2. **Add reentrancy guards to view functions used as oracles**

```solidity
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

contract Pool is ReentrancyGuard {
    function getPrice() public view nonReentrantView returns (uint256) {
        return (reserveA * 1e18) / totalSupply;
    }
}
```

Note: OpenZeppelin's standard `ReentrancyGuard` doesn't support view functions. Custom implementation needed:

```solidity
uint256 private constant _NOT_ENTERED = 1;
uint256 private constant _ENTERED = 2;
uint256 private _status;

modifier nonReentrantView() {
    require(_status != _ENTERED, "ReentrancyGuard: reentrant call");
    _;
}
```

3. **Use reentrancy-safe oracle patterns**
   - Chainlink oracles (external, non-reentrant)
   - TWAP (Time-Weighted Average Price) over multiple blocks
   - Commit-reveal schemes for critical operations

4. **Document oracle safety**
   - Explicitly document which view functions are safe to use as oracles
   - Add warnings to view functions that should NOT be used as oracles

5. **Use transfer methods that don't callback to untrusted addresses**
   - `transfer()` over `call()` for ETH (limited gas)
   - Verify ERC20 tokens are standard implementations
   - Avoid interacting with arbitrary user-provided token addresses

6. **Implement emergency pause mechanisms**
   - Allow protocol to pause on detected anomalies
   - Monitor for unusual oracle price movements

7. **Consider Virtual Price Protection**

For AMM pools specifically:

```solidity
uint256 private _cachedVirtualPrice;
uint256 private _lastUpdateBlock;

function get_virtual_price() public view returns (uint256) {
    // During same block as state update, return cached value
    if (block.number == _lastUpdateBlock) {
        return _cachedVirtualPrice;
    }
    return _calculateVirtualPrice();
}

function _updateVirtualPrice() private {
    _cachedVirtualPrice = _calculateVirtualPrice();
    _lastUpdateBlock = block.number;
}
```

#### Industry Impact and Evolution

**Historical Context:**

- Traditional reentrancy (DAO hack 2016) was well-understood by 2020
- Read-only reentrancy emerged as protocols grew more composable
- DeFi's composability turned into vulnerability - protocols using other protocols' view functions as oracles

**Current Status:**

- Major protocols (Curve, Balancer, Uniswap V3) have addressed or documented issues
- Many existing integrations still vulnerable
- Ongoing challenge: balancing gas costs vs security for view functions

**$100M+ At Risk:**

The figure represents cumulative risk across DeFi protocols using vulnerable price oracles. While individual attacks were smaller ($3.7M, $220K), the total value locked in vulnerable positions was estimated at over $100M before mitigations.

#### Impact & Likelihood Assessment Framework

This rule detects view functions that can have different results when called during execution vs. after - indicating potential read-only reentrancy or oracle manipulation.

##### Impact Assessment Decision Tree

```
START: Rule violation - view function result differs between pre/post execution
│
├─→ [Q1] What does the view function return?
│   ├─→ Price/valuation data used by protocol
│   │   ├─→ [Q2] Is this used for critical decisions?
│   │   │   ├─→ Yes (liquidations, swaps, lending) → CRITICAL IMPACT
│   │   │   │   Justification: Oracle manipulation = protocol exploit
│   │   │   │   Examples: Curve vyper bug ($73.5M), dForce ($3.7M)
│   │   │   │
│   │   │   └─→ No (informational display) → LOW IMPACT
│   │   │       Justification: No financial decisions based on it
│   │   │
│   │   ├─→ Account balance/share calculations
│   │   │   └─→ HIGH IMPACT
│   │   │       Justification: Incorrect valuations, withdrawal manipulation
│   │   │       Example: Inflate share value during callback
│   │   │
│   │   ├─→ Intentionally state-dependent (e.g., "current reserves")
│   │   │   └─→ LOW IMPACT (Likely FALSE ALARM)
│   │   │       Justification: Expected to change after state modifications
│   │   │
│   │   └─→ Timestamp/block-dependent data
│   │       └─→ LOW IMPACT (FALSE ALARM)
│   │           Justification: Block properties naturally change
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/LOW)
```

##### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Can attacker trigger the state change?
│   ├─→ Yes, via user-controlled external calls
│   │   ├─→ [Q2] Are there external calls in state-changing functions?
│   │   │   ├─→ Yes, with no reentrancy guards → VERY HIGH LIKELIHOOD
│   │   │   │   Justification: Classic read-only reentrancy vector
│   │   │   │
│   │   │   └─→ Yes, but with nonReentrant → LOW LIKELIHOOD
│   │   │       Justification: Protected
│   │   │
│   │   ├─→ No - state changes are internal only
│   │   │   └─→ MEDIUM LIKELIHOOD
│   │   │       Justification: Harder to exploit but possible via composition
│   │   │
│   │   └─→ [Q3] Is the view function even used on-chain?
│   │       ├─→ No (off-chain only) → VERY LOW LIKELIHOOD
│   │       │   Justification: No on-chain exploit vector
│   │       │
│   │       └─→ Yes → Maintain assessment from Q1/Q2
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

##### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |

##### Example Assessment

**Scenario:** `function getPrice() public view returns (uint256) { return reserve0 * 1e18 / reserve1; }` (used for liquidations)

**Impact:** Q1 → Price data; Q2 → Yes, used for liquidations = **CRITICAL IMPACT**
**Likelihood:** Q1 → Yes, attacker controls external calls; Q2 → No reentrancy guards = **VERY HIGH LIKELIHOOD**
**Final Priority:** CRITICAL × VERY HIGH = **P0** (Read-only reentrancy vulnerability)

**Scenario 2:** `function getCurrentBalance() public view returns (uint256) { return balances[msg.sender]; }` (off-chain only)

**Impact:** Q1 → Account balance = **HIGH IMPACT**
**Likelihood:** Q1 → Yes; Q3 → No, off-chain only = **VERY LOW LIKELIHOOD**
**Final Priority:** HIGH × VERY LOW = P3 (Monitor, but low urgency)

---

## 11. Input Validation Checker Rules

**Source Files:**
- `InputValidationChecker/scripts/generate_input_validation_checker.py`
- `InputValidationChecker/scripts/cvl_rule_generator.py`
- Auto-generated spec files: `input_validation_{ContractName}.spec`

### Overview: Auto-Generated Parameter-by-Parameter Validation Rules

The Input Validation Checker is an **auto-generated rule suite** that systematically tests whether functions properly validate their input parameters. Unlike other checkers that look for specific patterns, this checker generates rules for **every parameter of every public/external non-view method**.

**Core Concept:**
- Run the function twice from the **same initial state**
- First call with `input1`, second call with `input2`
- Keep all other parameters identical
- **Assert:** `input1 != input2 => lastReverted`

**Interpretation:**
- If changing a parameter doesn't cause a revert, the function may not validate that input
- This could indicate:
  - **Vulnerability:** Missing input validation
  - **False Positive:** Parameter is intentionally user-controlled

### Rule Generation Strategy

#### Parameter Types and Generated Rules

| Parameter Type | Rules Generated | Comparison Method |
|---------------|----------------|-------------------|
| **Primitives** (uint, int, address, bool) | 1 rule | Direct inequality: `input1 != input2` |
| **Bytes/String** | 1 rule | Hash comparison: `keccak256(input1) != keccak256(input2)` |
| **Arrays** (T[]) | 2 rules | Length rule + Element rule (unrolled up to `loop_iter`) |
| **Structs** | N rules | One rule per field (other fields held equal) |
| **Nested Arrays** (T[][]) | N+1 rules | N length rules (one per level) + Element rule |
| **Arrays of Structs** (S[]) | M rules | One rule per struct field at each index |

#### CVL Code Example: Primitive Parameter

```cvl
rule input_validation_transfer_param0_address(address input1, address input2) {
    env e;
    storage initState = lastStorage;

    uint256 anotherInput1; // Other parameters (havoc'd)

    transfer(e, input1, anotherInput1);
    transfer@withrevert(e, input2, anotherInput1) at initState;

    // if the input affects the function's behavior, changing it should cause a revert
    assert input1 != input2 => lastReverted;
}
```

#### CVL Code Example: Array Element

```cvl
rule input_validation_batchTransfer_param0_array_element(uint256 index) {
    env e;
    storage initState = lastStorage;

    address[] array1;
    address[] array2;
    uint256[] anotherInput1; // amounts parameter

    require array1.length == array2.length;
    require array1.length <= 3; // loop_iter bound
    require index < array1.length;

    // Other indices must be equal (unrolled for loop_iter=3)
    require index != 0 => array1[0] == array2[0];
    require index != 1 => array1[1] == array2[1];
    require index != 2 => array1[2] == array2[2];

    batchTransfer(e, array1, anotherInput1);
    batchTransfer@withrevert(e, array2, anotherInput1) at initState;

    // if changing this element affects behavior, it should cause a revert
    assert array1[index] != array2[index] => lastReverted;
}
```

#### CVL Code Example: Struct Field

```cvl
rule input_validation_createOrder_param0_struct_field_price() {
    env e;
    storage initState = lastStorage;

    OrderParams input1;
    OrderParams input2;

    // All fields except price must be equal
    require input1.tokenIn == input2.tokenIn;
    require input1.tokenOut == input2.tokenOut;
    require input1.recipient == input2.recipient;
    require input1.deadline == input2.deadline;
    // price is the field under test

    createOrder(e, input1);
    createOrder@withrevert(e, input2) at initState;

    // if changing this field affects behavior, it should cause a revert
    assert input1.price != input2.price => lastReverted;
}
```

### Threat Coverage

| Threat Type | Coverage Level | Notes |
|-------------|---------------|-------|
| **Input Validation** | **Primary** | Detects missing parameter validation |
| **State Integrity** | Secondary | Invalid inputs can corrupt contract state |
| **Permission Control** | Secondary | Address validation critical for access control |
| **DoS/Griefing** | Secondary | Unchecked inputs enable denial-of-service |
| **Fund Theft** | Secondary | Missing amount/address checks enable theft |

This directly addresses **OWASP SC04:2025 - Lack of Input Validation** ($14.6M losses in 2024).

### Scope Classification

**Type:** Parameter-level exhaustive testing

- Tests **every parameter** of every qualifying function
- Granularity: Individual fields of structs, individual elements of arrays
- Scale: Can generate 100+ rules for a complex contract

### Violation Causes

| Cause | Can Violate? | Explanation |
|-------|-------------|-------------|
| **Invalid/unsanitized user input** | **Yes (Primary)** | Missing validation allows arbitrary user values |
| **Bad state integrity** | **Yes** | State corruption enables invalid parameter acceptance |
| **Blockchain environment conditions** | Unlikely | Parameters usually independent of block properties |
| **Other contracts** | **Yes** | External contract returns used as parameters |

### Worst-Case Scenarios with Real Hacks

#### 1. Missing Zero Address Validation

**Nomad Bridge Exploit (August 2022) - $190M Loss**

**The Vulnerability:**
```solidity
// Simplified vulnerable code
function process(address target, bytes memory data) external {
    // BUG: No validation that target != address(0)
    // Worse: 0x00 was marked as trusted, disabling ALL validation
    (bool success,) = target.call(data);
    require(success);
}
```

**The Attack:**
- Routine upgrade marked 0x00 (zero hash) as a trusted root
- This turned off validation that ensured withdrawals were made to valid addresses
- Withdrawal requests from **any address** were considered valid by default
- 300+ addresses collectively stole $190M
- Attack required no advanced technical knowledge - just edit transaction and change destination address

**Impact:** Critical - complete protocol drainage
**Likelihood:** High when address validation is missing
**Detection:** Input validation rule for address parameters would flag this

**Sources:** [Halborn Analysis](https://www.halborn.com/blog/post/explained-the-nomad-hack-august-2022), [Medium Analysis](https://medium.com/immunefi/hack-analysis-nomad-bridge-august-2022-5aa63d53814a)

---

#### 2. Zero Address in Token Operations

**Qubit Finance Exploit (January 2022) - $80M Loss**

**The Vulnerability:**
```solidity
function deposit(address tokenAddress, uint amount) external {
    // BUG: tokenAddress.safeTransferFrom() does not revert when tokenAddress == address(0)
    tokenAddress.safeTransferFrom(msg.sender, address(this), amount);
    _mint(msg.sender, amount);
}
```

**The Attack:**
- Attacker called deposit with `tokenAddress = address(0)` and `amount = 0`
- `safeTransferFrom` on address(0) didn't revert (unexpected behavior)
- Contract minted tokens without receiving collateral
- Attacker withdrew 206,809 BNB worth ~$80M

**Impact:** Critical - fund theft without collateral
**Likelihood:** Medium - depends on token implementation behavior
**Detection:** Input validation rule for address parameters would flag lack of zero-check

**Sources:** [CertiK Analysis](https://certik.medium.com/qubit-bridge-collapse-exploited-to-the-tune-of-80-million-a7ab9068e1a0), [SlowMist Analysis](https://slowmist.medium.com/our-analysis-of-the-80m-qubit-finance-exploit-b0f272cd8c25)

---

#### 3. Missing Amount Validation

**Onyx DeFi (2024) - $3.8M Loss**

**The Vulnerability:**
- Input validation vulnerability in amount parameters
- Attackers manipulated transaction amounts
- Missing minimum/maximum bounds checking

**Impact:** High - fund theft via amount manipulation
**Likelihood:** Medium - caught in thorough testing
**Detection:** Input validation rules for uint parameters would detect missing bounds

---

#### 4. Missing Slippage Protection (Amount Validation in DeFi)

**Pattern:** Missing `minAmountOut` Validation

**The Vulnerability:**
```solidity
function swap(address tokenIn, address tokenOut, uint amountIn) external {
    uint amountOut = getAmountOut(amountIn, tokenIn, tokenOut);
    // BUG: No minAmountOut parameter - vulnerable to frontrunning/MEV
    _executeSwap(tokenIn, tokenOut, amountIn, amountOut);
}
```

**Real-World Examples:**
- **Catgirl NFT:** No minimum output enforcement during swap operations
- Enabled frontrunning: attacker observes large transaction, frontruns with higher gas to manipulate price
- Victim's transaction executes at unfavorable rate

**Impact:** High - value extraction via MEV
**Likelihood:** Very High in public mempools
**Detection:** Input validation rule detects missing `minAmountOut` parameter

**Sources:** [DeFi Slippage Attacks](https://dacian.me/defi-slippage-attacks), [Unprotected Swaps](https://scsfg.io/hackers/unprotected-swaps/)

---

#### 5. Missing Array Bounds Validation (SWC-124)

**Pattern:** Out-of-Bounds Write

**The Vulnerability:**
```solidity
uint256[] public Ledger;

function UpdateLedgerAtIndex(uint idx, uint entry) external {
    Ledger[idx] = entry; // BUG: No bounds checking
    // Can write to arbitrary storage locations!
}
```

**Security Implications:**
- In very old Solidity versions (<0.5.0), missing bounds checks could enable storage corruption
- Can overwrite `owner` variable or other critical storage
- Modern Solidity (0.6.0+) automatically reverts on out-of-bounds access

**Impact:** Critical - storage corruption, ownership hijacking (historical)
**Likelihood:** Very Low in modern Solidity (0.6.0+ has automatic bounds checking) - primarily a historical vulnerability from very old versions or when using assembly/low-level operations that bypass safety checks
**Detection:** Input validation rule for array indices flags this; while modern Solidity provides automatic protection, explicit validation gives clearer error messages and documents intent

**Source:** [SWC-124 Classification](https://swcregistry.io/docs/SWC-124/)

---

### Common False Alarm Patterns

#### 1. **Intentionally User-Controlled Parameters**

**ERC20 Transfer Recipient:**
```solidity
function transfer(address to, uint256 amount) external returns (bool) {
    // 'to' is SUPPOSED to be user-provided
    // Input validation rule will flag: "changing 'to' doesn't cause revert"
    // This is CORRECT behavior - users choose recipients
    _transfer(msg.sender, to, amount);
    return true;
}
```

**Critical Distinction:**
- **Transfer recipient:** Generally safe (user's choice)
- **Stored address:** MUST validate address(0)
- **Called address:** CRITICAL - must whitelist or validate carefully

**Other Legitimate User-Controlled Parameters:**
- `recipient` in DeFi swaps
- `spender` in ERC20 `approve()`
- `operator` in ERC721 `setApprovalForAll()`

**When It Becomes Dangerous:**

```solidity
function executeOnTarget(address target, bytes data) external {
    // DANGER: User controls what contract is called
    (bool success,) = target.call(data);
}
```

If the parameter is **called** (not just transferred to), validation becomes critical.

---

#### 2. **Early Returns Instead of Reverts**

```solidity
function processOrder(uint256 orderId) external {
    Order storage order = orders[orderId];

    // Early exit for already-processed orders
    if (order.status == Status.Completed) {
        return; // No revert, just early return
    }

    // ... significant state changes below
    order.status = Status.Processing;
    _executeOrder(order);
}
```

**Pattern Analysis:**
- Rule detects: Different `orderId` values don't cause revert
- Reality: Function returns early **before significant side effects**
- **Safe when:** All checks happen before state modifications
- **Dangerous when:** Partial state changes occur before return

**Gas Optimization Pattern:**
```solidity
function withdraw(uint256 amount) external {
    uint256 balance = balances[msg.sender];

    // Early return for gas efficiency (vs revert)
    if (amount > balance) {
        return;
    }

    // Safe: no state changes before the check
    balances[msg.sender] -= amount;
    payable(msg.sender).transfer(amount);
}
```

**Best Practice:** While functionally safe, `require(amount <= balance)` is clearer and standard.

---

#### 3. **Idempotent Operations**

**ERC20 Approve:**
```solidity
function approve(address spender, uint256 amount) external returns (bool) {
    // Can be called multiple times with same OR different amounts
    // Input validation rule flags: "changing amount doesn't cause revert"
    // This is CORRECT - approve is idempotent by design
    _approve(msg.sender, spender, amount);
    return true;
}
```

**Other Idempotent Patterns:**
- `setApprovalForAll(address operator, bool approved)` - ERC721
- Configuration setters: `setBaseURI(string memory uri)`
- Flag toggles: `setPaused(bool paused)`
- Metadata updates: `setTokenURI(uint256 tokenId, string memory uri)`

**Why These Are Safe:**
- Designed to be called multiple times
- Last value wins (no accumulation)
- State overwrite is intentional behavior

**Note:** While false positives for input validation, some patterns (like unlimited ERC20 approvals) have known security implications. The Validation Rule correctly identifies lack of restrictions - the question is whether restrictions are appropriate.

---

#### 4. **Metadata and Configuration Parameters**

**Constructor Parameters:**
```solidity
constructor(string memory name_, string memory symbol_) {
    _name = name_; // Any string is valid - informational only
    _symbol = symbol_;
}
```

**Token Metadata:**
```solidity
function setTokenURI(uint256 tokenId, string memory uri) external {
    require(_exists(tokenId), "Token doesn't exist");
    // URI is user-provided metadata - any value is valid
    _tokenURIs[tokenId] = uri;
}

function setBaseURI(string memory baseURI_) external onlyOwner {
    // Base URI is configuration - owner can set any value
    _baseURI = baseURI_;
}
```

**NFT Minting with Metadata:**
```solidity
function mint(address to, string memory metadataURI) external {
    uint256 tokenId = _nextTokenId++;
    _mint(to, tokenId);
    _setTokenURI(tokenId, metadataURI); // Metadata is informational
}
```

**Pattern:** Parameters that are purely informational have no inherent constraints.

---

#### 5. **Zero-Value Transfers (ERC20 Standard Compliance)**

```solidity
function transfer(address to, uint256 amount) external returns (bool) {
    // ERC20 standard: "Transfers of 0 values MUST be treated as normal transfers"
    // Input validation rule may flag: "amount can be 0"
    // This is REQUIRED by the standard
    _transfer(msg.sender, to, amount);
    emit Transfer(msg.sender, to, amount);
    return true;
}
```

**From ERC20 Specification:**
> "Transfers of 0 values MUST be treated as normal transfers and fire the Transfer event."

**Similar Patterns:**
- ERC721 `safeTransferFrom` with `data = ""` (empty data is valid)
- Batch operations with empty arrays (length = 0)

---

#### 6. **Amounts with No Inherent Minimum/Maximum**

**Donations:**
```solidity
function donate() external payable {
    // Any msg.value is accepted - no minimum required
    // Rule may flag: "msg.value can be any amount"
    // This is intentional generosity
    totalDonations += msg.value;
}
```

**Staking with Zero for Reward Claims:**
```solidity
function stake(uint256 amount) external {
    _claimRewards(); // Claim pending rewards

    // Some protocols allow staking 0 just to claim rewards
    if (amount > 0) {
        token.transferFrom(msg.sender, address(this), amount);
        stakedBalance[msg.sender] += amount;
    }
}
```

**Flexible Fee Configuration:**
```solidity
function setFeePercentage(uint256 newFee) external onlyOwner {
    // Owner might legitimately set fee to 0 (no fee)
    // Or to 10000 (100% - unusual but valid for specific use cases)
    require(newFee <= MAX_FEE, "Exceeds maximum");
    feePercentage = newFee;
}
```

---

#### 7. **Array Indices with Implicit Bounds Checking**

```solidity
function claimRewards(uint256[] calldata poolIds) external {
    for (uint i = 0; i < poolIds.length; i++) {
        // Solidity 0.8+ provides automatic bounds checking
        // _pools[poolIds[i]] will revert if poolIds[i] >= _pools.length
        _pools[poolIds[i]].claim(msg.sender);
    }
}
```

**Pattern:** Solidity's built-in array bounds checking provides implicit validation.

**When Explicit Validation is Better:**
```solidity
function updatePool(uint256 poolId) external {
    require(poolId < _pools.length, "Invalid pool ID"); // Clearer error message
    _pools[poolId].update();
}
```

---

#### 8. **Batch Operation Parameters**

```solidity
function multiTransfer(
    address[] calldata recipients,
    uint256[] calldata amounts
) external {
    // Recipients and amounts SHOULD vary - that's the feature
    // Input validation rule may flag: "changing recipients[i] doesn't cause revert"
    // This is correct - batch ops accept varied inputs

    require(recipients.length == amounts.length, "Length mismatch");
    for (uint i = 0; i < recipients.length; i++) {
        _transfer(msg.sender, recipients[i], amounts[i]);
    }
}
```

**Key Validation:** Length consistency, not individual element values.

---

#### 9. **Enum Parameters (Limited Domain)**

```solidity
enum OrderStatus { Pending, Active, Completed, Cancelled }

function setOrderStatus(uint256 orderId, OrderStatus newStatus) external {
    // Enum provides implicit validation - only values 0-3 possible
    // Input validation rule may flag lack of explicit checks
    // Type system provides the validation
    orders[orderId].status = newStatus;
}
```

**Pattern:** Type system constrains the domain, reducing need for explicit validation.

---

#### 10. **Boolean Flags (Binary Domain)**

```solidity
function setPaused(bool paused) external onlyOwner {
    // Only two possible values: true or false
    // No additional validation needed
    _paused = paused;
}
```

---

### Real Dangerous Patterns (True Positives to Prioritize)

#### 1. **Missing Zero Address Checks on Stored Addresses**

```solidity
function setFeeRecipient(address newRecipient) external onlyOwner {
    feeRecipient = newRecipient; // BUG: No address(0) check
    // Fees will be lost forever!
}
```

**Severity:** Critical
**Impact:** Permanent fund loss
**Prevalence:** Common in contracts without thorough review

---

#### 2. **Missing Slippage Protection in DeFi**

```solidity
function swap(
    address tokenIn,
    address tokenOut,
    uint amountIn
) external returns (uint amountOut) {
    amountOut = getAmountOut(amountIn, tokenIn, tokenOut);
    // BUG: No minAmountOut parameter
    _executeSwap(tokenIn, tokenOut, amountIn, amountOut);
}
```

**Severity:** High
**Impact:** MEV extraction, frontrunning losses
**Prevalence:** Increasingly common as MEV sophistication grows

**Fix:**
```solidity
function swap(
    address tokenIn,
    address tokenOut,
    uint amountIn,
    uint minAmountOut // Add this parameter
) external returns (uint amountOut) {
    amountOut = getAmountOut(amountIn, tokenIn, tokenOut);
    require(amountOut >= minAmountOut, "Insufficient output");
    _executeSwap(tokenIn, tokenOut, amountIn, amountOut);
}
```

---

#### 3. **Missing Explicit Array Bounds Validation**

```solidity
function updateRewardAtIndex(uint idx, uint reward) external onlyOwner {
    rewards[idx] = reward; // Modern Solidity: automatically reverts if idx >= rewards.length
                           // Best practice: add explicit check for clearer error message
}
```

**Severity:** Critical (in very old Solidity <0.5.0); Low-Medium in modern Solidity (missing explicit validation)
**Impact:** Storage corruption (historical); unclear error messages (modern)
**Prevalence:** Extremely rare in modern Solidity (0.6.0+ has automatic bounds checking). Mainly relevant for assembly code or historical codebases. Explicit validation still recommended for clarity.

---

#### 4. **Missing Maximum Supply Checks**

```solidity
function mint(address to, uint256 amount) external onlyMinter {
    _mint(to, amount); // BUG: No MAX_SUPPLY check
    // Can inflate supply indefinitely
}
```

**Severity:** High
**Impact:** Token value dilution, economic attack
**Prevalence:** Common in token contracts

---

#### 5. **Missing Amount Bounds in Fee Calculations**

```solidity
function setFeePercentage(uint256 newFee) external onlyOwner {
    feePercentage = newFee; // BUG: No maximum check
    // Owner can set 100% fee (or 1000%, breaking calculations)
}
```

**Severity:** Medium-High
**Impact:** Fund extraction, contract bricking
**Prevalence:** Common

---

#### 6. **Unchecked Integer Inputs that Affect Critical Operations**

```solidity
function calculateLoanInterest(uint256 principal, uint256 ratePerDay, uint256 days)
    public pure returns (uint256) {
    // BUG: days parameter unchecked - could overflow
    return principal * ratePerDay * days / 10000;
}
```

**Severity:** Medium
**Impact:** Incorrect calculations, potential overflows
**Prevalence:** Common in financial calculations

---

### Mitigation Recommendations

#### 1. **For Address Parameters**

**Always validate stored addresses:**
```solidity
function setFeeRecipient(address newRecipient) external onlyOwner {
    require(newRecipient != address(0), "Zero address");
    feeRecipient = newRecipient;
}
```

**For addresses used in calls:**
```solidity
// Option 1: Whitelist
mapping(address => bool) public approvedTargets;

function callTarget(address target) external {
    require(approvedTargets[target], "Not approved");
    (bool success,) = target.call("");
    require(success);
}

// Option 2: Interface check
function callTarget(IERC20 token) external {
    // Type system ensures it's an ERC20-compliant address
    token.transfer(recipient, amount);
}
```

---

#### 2. **For Amount Parameters**

**Add bounds checking:**
```solidity
function setFeePercentage(uint256 newFee) external onlyOwner {
    require(newFee <= MAX_FEE_PERCENTAGE, "Exceeds maximum fee");
    feePercentage = newFee;
}

function mint(address to, uint256 amount) external onlyMinter {
    require(totalSupply() + amount <= MAX_SUPPLY, "Exceeds max supply");
    _mint(to, amount);
}
```

**Add slippage protection in DeFi:**
```solidity
function swap(
    address tokenIn,
    address tokenOut,
    uint amountIn,
    uint minAmountOut
) external returns (uint amountOut) {
    amountOut = getAmountOut(amountIn, tokenIn, tokenOut);
    require(amountOut >= minAmountOut, "Insufficient output");
    _executeSwap(tokenIn, tokenOut, amountIn, amountOut);
}
```

---

#### 3. **For Array Parameters**

**Add length checks:**
```solidity
function batchTransfer(
    address[] calldata recipients,
    uint256[] calldata amounts
) external {
    require(recipients.length == amounts.length, "Length mismatch");
    require(recipients.length <= MAX_BATCH_SIZE, "Batch too large");

    for (uint i = 0; i < recipients.length; i++) {
        _transfer(msg.sender, recipients[i], amounts[i]);
    }
}
```

**Validate indices:**
```solidity
function updateRewardAtIndex(uint idx, uint reward) external onlyOwner {
    require(idx < rewards.length, "Index out of bounds");
    rewards[idx] = reward;
}
```

---

#### 4. **Use OpenZeppelin Helpers**

```solidity
using Address for address payable;

function withdraw(address payable recipient, uint amount) external {
    recipient.sendValue(amount); // Reverts on failure
}
```

---

#### 5. **Document Intentional Lack of Validation**

```solidity
function transfer(address to, uint256 amount) external returns (bool) {
    // Note: 'to' is intentionally not validated beyond zero-check
    // Users have freedom to choose recipients, including contracts
    require(to != address(0), "ERC20: transfer to zero address");
    _transfer(msg.sender, to, amount);
    return true;
}
```

---

### When to Investigate Further

Input Validation rules that flag violations should be investigated when:

1. **Address parameters** that are:
   - Stored in contract state
   - Used in external calls
   - Used to determine access control

2. **Amount parameters** in:
   - Minting functions
   - Fee configuration
   - DeFi swap operations
   - Critical calculations

3. **Array indices** that:
   - Access storage arrays
   - Determine which operation to execute

4. **Struct fields** that:
   - Control critical operations
   - Determine fund flows
   - Affect access control

---

### Summary: Rule Categories and Risk Assessment

| Parameter Type | False Alarm Risk | When to Investigate | Real Vulnerability Risk |
|---------------|------------------|---------------------|------------------------|
| Address (transfer recipient) | High | If used in call() | Medium |
| Address (stored/called) | Low | Always | Very High |
| Amount (no inherent bounds) | Medium | Context-dependent | Medium |
| Amount (with expected bounds) | Low | Always | High |
| Array length | Low | Always | Medium |
| Array element | Medium | Depends on element type | Medium |
| Struct fields | Medium | Critical fields only | Medium-High |
| Metadata (string, uri) | Very High | Rarely | Low |
| Boolean/Enum | Very High | Rarely | Very Low |

### Impact & Likelihood Assessment Framework

Input Validation rules generate many findings due to their comprehensive parameter-by-parameter approach. Use this framework to systematically prioritize which violations require immediate attention.

#### Impact Assessment Decision Tree

```
START: Rule violation - parameter change causes different behavior but not revert
│
├─→ [Q1] What type of parameter is this?
│   ├─→ Address parameter
│   │   ├─→ [Q2] How is the address used?
│   │   │   ├─→ Stored in state (owner, treasury, oracle)
│   │   │   │   └─→ CRITICAL IMPACT
│   │   │   │       Justification: Protocol control/configuration
│   │   │   │       Examples: setFeeRecipient, updateOracle
│   │   │   │
│   │   │   ├─→ Used in external calls (target.call, delegatecall)
│   │   │   │   └─→ CRITICAL IMPACT
│   │   │   │       Justification: Arbitrary call vulnerability
│   │   │   │       Examples: Nomad ($190M), Qubit ($80M)
│   │   │   │
│   │   │   ├─→ ERC20 transfer recipient (to parameter)
│   │   │   │   └─→ LOW IMPACT (FALSE ALARM)
│   │   │   │       Justification: User freedom by design
│   │   │   │       Note: Still validate != address(0)
│   │   │   │
│   │   │   └─→ Lookup key (registry[address])
│   │   │       └─→ MEDIUM IMPACT
│   │   │           Justification: Determines behavior path
│   │   │
│   │   ├─→ Amount/value parameter
│   │   │   ├─→ [Q3] Is there a logical bound?
│   │   │   │   ├─→ Yes (fee %, supply cap, slippage limit)
│   │   │   │   │   ├─→ Missing validation → CRITICAL IMPACT
│   │   │   │   │   │   Justification: Economic attack vector
│   │   │   │   │   │   Examples: Onyx DeFi ($3.8M)
│   │   │   │   │   │
│   │   │   │   │   └─→ Has validation → INFORMATIONAL (FALSE ALARM)
│   │   │   │   │       Justification: Already protected
│   │   │   │   │
│   │   │   │   └─→ No (arbitrary amounts like transfer value)
│   │   │   │       └─→ LOW IMPACT (Likely FALSE ALARM)
│   │   │   │           Justification: Intentionally flexible
│   │   │   │
│   │   │   ├─→ Array parameter
│   │   │   │   ├─→ [Q4] Array elements or length?
│   │   │   │   │   ├─→ Array index (accessing storage array)
│   │   │   │   │   │   └─→ HIGH IMPACT
│   │   │   │   │   │       Justification: Out-of-bounds access
│   │   │   │   │   │       Note: Check Solidity version (0.6.0+)
│   │   │   │   │   │
│   │   │   │   │   └─→ Array elements (batch recipients, values)
│   │   │   │   │       └─→ MEDIUM IMPACT (Often FALSE ALARM)
│   │   │   │   │           Justification: Batch operations intended
│   │   │   │
│   │   │   ├─→ Boolean/Enum parameter
│   │   │   │   └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │   │   │       Justification: Limited domain, all values valid
│   │   │   │
│   │   │   ├─→ Struct fields
│   │   │   │   ├─→ Critical field (address, amount with bounds)
│   │   │   │   │   └─→ Apply address/amount rules above
│   │   │   │   │
│   │   │   │   └─→ Metadata field (string, bytes)
│   │   │   │       └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │   │   │
│   │   │   └─→ String/bytes parameter (metadata, URI)
│   │   │       └─→ INFORMATIONAL IMPACT (FALSE ALARM)
│   │   │           Justification: No inherent validation needed
│
└─→ OUTPUT: Impact Level (CRITICAL/HIGH/MEDIUM/LOW/INFORMATIONAL)
```

#### Likelihood Assessment Decision Tree

```
START: Evaluate exploitation likelihood
│
├─→ [Q1] Does the function return early instead of reverting?
│   ├─→ Yes (early return before side effects)
│   │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│   │       Justification: Different behavior = early exit, not vulnerability
│   │       Example: if (amount == 0) return; // No revert needed
│   │
│   └─→ No - continues execution with different parameter
│       │
│       ├─→ [Q2] Is the parameter user-provided by design?
│       │   ├─→ Yes (transfer recipient, swap parameters, user choices)
│       │   │   ├─→ [Q3] Are there ANY validation checks?
│       │   │   │   ├─→ No checks at all
│       │   │   │   │   └─→ VERY HIGH LIKELIHOOD
│       │   │   │   │       Justification: Exploitable immediately
│       │   │   │   │
│       │   │   │   ├─→ Partial validation (zero-check only)
│       │   │   │   │   ├─→ [Q4] Is more validation needed?
│       │   │   │   │   │   ├─→ Yes (bounds, whitelist) → HIGH LIKELIHOOD
│       │   │   │   │   │   └─→ No (zero-check sufficient) → VERY LOW (FALSE ALARM)
│       │   │   │   │
│       │   │   │   └─→ Comprehensive validation
│       │   │   │       └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│       │   │   │           Justification: Already protected
│       │   │
│       │   │   └─→ No (derived/computed parameter)
│       │   │       └─→ MEDIUM LIKELIHOOD
│       │   │           Justification: Depends on computation logic
│       │   │
│       │   └─→ [Q5] Is this idempotent operation?
│       │       ├─→ Yes (setters that can be called repeatedly)
│       │       │   └─→ VERY LOW LIKELIHOOD (FALSE ALARM)
│       │       │       Justification: Different values are intentional
│       │       │       Example: approve(spender, newAmount)
│       │       │
│       │       └─→ No (one-time or critical operations)
│       │           └─→ Maintain assessment from above
│
└─→ OUTPUT: Likelihood Level (VERY HIGH/HIGH/MEDIUM/LOW/VERY LOW)
```

#### Risk Priority Matrix

| Impact × Likelihood | VERY HIGH | HIGH | MEDIUM | LOW | VERY LOW |
|---------------------|-----------|------|--------|-----|----------|
| **CRITICAL**        | **P0** | **P0** | **P1** | P2 | P3 |
| **HIGH**            | **P0** | **P1** | P2 | P3 | P4 |
| **MEDIUM**          | **P1** | P2 | P3 | P4 | P4 |
| **LOW**             | P2 | P3 | P4 | P4 | P4 |
| **INFORMATIONAL**   | P3 | P4 | P4 | P4 | P4 |

#### Example Assessment Walkthroughs

**Scenario 1:** `function setFeeRecipient(address newRecipient) external onlyOwner { feeRecipient = newRecipient; }`

**Impact Assessment:**
- Q1: Address parameter
- Q2: Stored in state (feeRecipient)
- **Result: CRITICAL IMPACT**

**Likelihood Assessment:**
- Q1: No early return
- Q2: User-provided (owner-provided)
- Q3: No checks at all (no zero-address check)
- **Result: VERY HIGH LIKELIHOOD**

**Final Priority:** CRITICAL × VERY HIGH = **P0** (Add require(newRecipient != address(0)))

---

**Scenario 2:** `function transfer(address to, uint256 amount) external returns (bool) { require(to != address(0)); _transfer(msg.sender, to, amount); return true; }`

**Impact Assessment:**
- Q1: Address parameter
- Q2: ERC20 transfer recipient
- **Result: LOW IMPACT (FALSE ALARM)**

**Likelihood Assessment:**
- Q2: Yes, user-provided by design
- Q3: Partial validation (zero-check)
- Q4: No more validation needed
- **Result: VERY LOW LIKELIHOOD (FALSE ALARM)**

**Final Priority:** LOW × VERY LOW = P4 (Working as intended - ERC20 standard)

---

**Scenario 3:** `function setFeePercentage(uint256 newFee) external onlyOwner { feePercentage = newFee; }`

**Impact Assessment:**
- Q1: Amount/value parameter
- Q3: Yes, logical bound (fee should be ≤ 100%)
- Missing validation
- **Result: CRITICAL IMPACT**

**Likelihood Assessment:**
- Q1: No early return
- Q2: User-provided
- Q3: No checks at all
- **Result: VERY HIGH LIKELIHOOD**

**Final Priority:** CRITICAL × VERY HIGH = **P0** (Add require(newFee <= MAX_FEE))

---

**Scenario 4:** `function deposit(uint256 amount) external { if (amount == 0) return; balances[msg.sender] += amount; }`

**Impact Assessment:**
- Q1: Amount parameter
- Q3: No logical bound (arbitrary deposit amounts acceptable)
- **Result: LOW IMPACT (FALSE ALARM)**

**Likelihood Assessment:**
- Q1: Yes, early return before side effects
- **Result: VERY LOW LIKELIHOOD (FALSE ALARM)**

**Final Priority:** LOW × VERY LOW = P4 (Early return pattern - intentional)

---

**Scenario 5:** `function approve(address spender, uint256 amount) external returns (bool) { allowances[msg.sender][spender] = amount; return true; }`

**Impact Assessment:**
- Q1: Amount parameter (in context of approval)
- Q3: No logical bound (ERC20 allows infinite approvals)
- **Result: LOW IMPACT (FALSE ALARM)**

**Likelihood Assessment:**
- Q2: User-provided by design
- Q5: Yes, idempotent operation (can be called repeatedly)
- **Result: VERY LOW LIKELIHOOD (FALSE ALARM)**

**Final Priority:** LOW × VERY LOW = P4 (Standard ERC20 approval pattern)

---

## 12. Summary Matrix

| Rule | Primary Threat | Scope | Main Violation Cause | False Alarm Risk | Real-World Relevance |
|------|---------------|-------|---------------------|------------------|---------------------|
| `stable_extcall_targets_and_selectors` | Input Validation | Method-level | User input | Medium | Dexible, Poly Network |
| `privilegedOperation` | Permission Control | Method-level | Missing access control | Low | KiloEx, HospoWise |
| `detect_privileged_writes` | Permission Control | Storage-level | Unprotected writes | Medium | Various access control bugs |
| `detect_time_sensitive_writes` | Blockchain Environment | Storage-level | Timestamp manipulation | High | GovernMental, MEV |
| `nonGettersThatNeverRevert` | DoS/Availability | Method-level | (Informational) | Very High | N/A |
| `gettersThatNeverRevert` | Logical Correctness | Method-level | Division by zero | Low | Oracle failures |
| `payableFunctionsThatNeverRevert` | DoS/Availability | Method-level | Validation logic | High | N/A |
| `alwaysRevert` | Logical Correctness | Method-level | Dead code | Medium | Parity Freeze |
| `failing_CALL_leads_to_revert` | Input Validation | Call-level | Unchecked returns | Low | King of Ether |
| `oneTimeFunction*` | Logical Correctness | Method-level | Re-initialization | Low | Audius |
| `safeCasting` | Math Precision | Type-level | Unsafe downcasts | Low | Poolz, Cetus |
| `noSelfCalls` | Reentrancy | Call-level | Callback patterns | Medium | Penpie, Curve |
| `msgValueInLoopRule` | Fund Theft | Code pattern | User input arrays | Very Low | Opyn, MISO |
| `viewReentrancy` | Oracle Manipulation | Cross-contract | External contracts | Medium | dForce, Curve, Penpie |

| `inputValidation_*` | Input Validation | Parameter-level | Missing validation | Medium-High | Nomad, Qubit, Onyx |

---

## 13. References

### Smart Contract Security Resources

- [Hacken - Top 10 Smart Contract Vulnerabilities](https://hacken.io/discover/smart-contract-vulnerabilities/)
- [OWASP Smart Contract Top 10](https://owasp.org/www-project-smart-contract-top-10/)
- [OWASP SC Top 10 (2025) Breakdown](https://www.resonance.security/blog-posts/owasp-sc-top-10-2025-breakdown-the-most-critical-smart-contract-risks-of-2025)

### Hack Post-Mortems

- [Penpie Hack Analysis - Halborn](https://www.halborn.com/blog/post/explained-the-penpie-hack-september-2024)
- [Penpie Exploit Analysis - Three Sigma](https://threesigma.xyz/blog/penpie-reentrancy-exploit-analysis)
- [dForce Hack Analysis - Halborn](https://www.halborn.com/blog/post/explained-the-dforce-hack-february-2023)
- [dForce Attack via Read-Only Reentrancy - CertiK](https://www.certik.com/resources/blog/curve-conundrum-the-dforce-attack-via-a-read-only-reentrancy-vector-exploit)
- [Curve Finance Liquidity Pools Hack - Hacken](https://hacken.io/discover/curve-finance-liquidity-pools-hack-explained/)
- [Detecting MISO and Opyn's msg.value Vulnerability - Trail of Bits](https://blog.trailofbits.com/2021/12/16/detecting-miso-and-opyns-msg-value-reuse-vulnerability-with-slither/)
- [Reentrancy Attacks List - pcaversaccio](https://github.com/pcaversaccio/reentrancy-attacks)
- [2024 DeFi Smart Contract Hack Review - Cymetrics](https://tech-blog.cymetrics.io/en/posts/alice/2024_defi_hack/)

### Vulnerability Deep-Dives

- [Unchecked External Calls - OWASP](https://owasp.org/www-project-smart-contract-top-10/2023/en/src/SC10-unchecked-external-calls.html)
- [Delegatecall Vulnerabilities - Halborn](https://www.halborn.com/blog/post/delegatecall-vulnerabilities-in-solidity)
- [Integer Downcasting Vulnerability - BuildBear](https://www.buildbear.io/resources/guides-and-tutorials/Downcasting_Vulnerability)
- [Access Control Vulnerabilities - Metaschool](https://metaschool.so/articles/access-control-vulnerabilities-in-smart-contracts)
- [DoS Attacks in Smart Contracts - Nethermind](https://www.nethermind.io/blog/denial-of-service-dos-attacks-in-smart-contracts)
- [Block Timestamp Manipulation - Coinmonks](https://medium.com/coinmonks/smart-contract-security-block-timestamp-manipulation-baec1b95c921)
- [Unchecked Return Values - ImmuneBytes](https://immunebytes.com/blog/solidity-security-vulnerability-unchecked-return-values/)
- [msg.value in Loops - Conflux Documentation](https://doc.confluxnetwork.org/docs/general/build/smart-contracts/contract-security/msg-value-in-loop)
- [Using msg.value in a Loop - Kaden Zipfel](https://kadenzipfel.github.io/smart-contract-vulnerabilities/vulnerabilities/msgvalue-loop.html)
- [Read-Only Reentrancy - DevCon Presentation](https://archive.devcon.org/archive/watch/6/read-only-reentrancy-a-novel-vulnerability-class-responsible-for-100m-funds-at-risk/)
- [Curve LP Oracle Manipulation - ChainSecurity](https://chainsecurity.com/curve-lp-oracle-manipulation-post-mortem/)
- [Heartbreaks & Curve LP Oracles - ChainSecurity](https://chainsecurity.com/heartbreaks-curve-lp-oracles/)
- [Input Validation Best Practices - Cyfrin](https://www.cyfrin.io/blog/missing-or-improper-input-validation-in-smart-contracts)
- [Nomad Bridge Hack - Halborn](https://www.halborn.com/blog/post/explained-the-nomad-hack-august-2022)
- [Nomad Hack Analysis - Immunefi](https://medium.com/immunefi/hack-analysis-nomad-bridge-august-2022-5aa63d53814a)
- [Qubit Finance Exploit - CertiK](https://certik.medium.com/qubit-bridge-collapse-exploited-to-the-tune-of-80-million-a7ab9068e1a0)
- [Qubit Finance Exploit - SlowMist](https://slowmist.medium.com/our-analysis-of-the-80m-qubit-finance-exploit-b0f272cd8c25)
- [Zero Address Checks - Medium](https://medium.com/@joichiro.sai/solidity-attack-vectors-11-no-address-zero-check-7dd337bd9587)
- [DeFi Slippage Attacks](https://dacian.me/defi-slippage-attacks)
- [Unprotected Swaps - SCSFG](https://scsfg.io/hackers/unprotected-swaps/)
- [ERC20 Approval Risks - BlockSec](https://blocksecteam.medium.com/unlimited-approval-in-erc20-convenience-or-security-1c8dce421ed7)
- [Array Out-of-Bounds - SWC-124](https://swcregistry.io/docs/SWC-124/)

### Formal Verification

- [Certora Formal Verification Tutorial](https://dev.to/spalladino/a-look-into-formal-verification-of-smart-contracts-using-certora-3o8g)
- [Certora User's Guide](https://docs.certora.com/en/latest/docs/user-guide/index.html)
- [Formal Verification of Smart Contracts - Ethereum.org](https://ethereum.org/developers/docs/smart-contracts/formal-verification/)

### OpenZeppelin Libraries

- [SafeCast](https://docs.openzeppelin.com/contracts/4.x/api/utils#SafeCast)
- [ReentrancyGuard](https://docs.openzeppelin.com/contracts/4.x/api/security#ReentrancyGuard)
- [AccessControl](https://docs.openzeppelin.com/contracts/4.x/api/access#AccessControl)
- [Initializable](https://docs.openzeppelin.com/contracts/4.x/api/proxy#Initializable)
