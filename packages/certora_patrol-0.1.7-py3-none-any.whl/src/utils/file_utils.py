"""File utilities for safe file operations."""

import json
import os
import threading
import uuid
from pathlib import Path
from typing import Any


def atomic_write_json(file_path: Path, data: Any, indent: int = 2) -> None:
    """
    Write JSON data to a file atomically to prevent corruption.

    Writes to a temporary file first, flushes to disk, then atomically
    renames to the target path. This prevents readers from seeing
    incomplete/corrupted JSON during writes or after crashes.

    Uses unique temp file names (PID + thread ID + UUID) to prevent conflicts
    when multiple processes/threads write to the same file simultaneously.

    Args:
        file_path: Target file path
        data: Data to serialize as JSON
        indent: JSON indentation (default: 2)

    Raises:
        Exception: If write or rename fails
    """
    # Ensure file_path is a Path object
    file_path = Path(file_path)

    # Create unique temp file name using PID, thread ID, and UUID
    # This prevents conflicts when multiple processes/threads write simultaneously
    pid = os.getpid()
    tid = threading.get_ident()
    unique_id = uuid.uuid4().hex[:8]
    temp_file = file_path.with_suffix(f'.tmp.{pid}.{tid}.{unique_id}')

    try:
        with open(temp_file, 'w') as f:
            json.dump(data, f, indent=indent)
            f.flush()
            os.fsync(f.fileno())  # Ensure data is on disk before rename

        # Atomic rename (overwrites existing file if present)
        temp_file.replace(file_path)
    finally:
        # Clean up temp file if it still exists (e.g., if rename failed)
        if temp_file.exists():
            temp_file.unlink()
