"""Canonical environment variable names used across PreAudit."""

# This is the default env var name used by Anthropic's SDKs (Python, TypeScript, etc.)
ANTHROPIC_API_KEY_ENV = "ANTHROPIC_API_KEY"
