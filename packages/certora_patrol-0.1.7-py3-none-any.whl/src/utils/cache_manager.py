"""
Cache Manager for PreAudit Orchestrator

Tracks file hashes and job URLs to avoid redundant prover runs when files haven't changed.
"""


import hashlib
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.utils.file_utils import atomic_write_json
from src.utils.logger import logger


class CacheManager:
    """Manages caching of prover runs based on file hashes."""
    
    def __init__(self, cache_dir: Optional[str] = None):
        """
        Initialize the cache manager.
        
        Args:
            cache_dir: Directory to store cache files. Defaults to .certora_internal/preaudit_cache
        """
        if cache_dir:
            self.cache_dir = Path(cache_dir)
        else:
            self.cache_dir = Path.cwd() / ".certora_internal" / "preaudit_cache"
        
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_file = self.cache_dir / "orchestrator_cache.json"
        self.cache_data = self._load_cache()
    
    def _load_cache(self) -> Dict[str, Any]:
        """Load cache data from disk."""
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {
            "version": "1.0",
            "entries": {},
            "last_updated": None
        }
    
    def _save_cache(self) -> None:
        """Save cache data to disk atomically."""
        try:
            logger.debug(f"Writing cache to {self.cache_file} ({len(self.cache_data['entries'])} entries)", "CacheManager")
            atomic_write_json(self.cache_file, self.cache_data)
            logger.debug("Cache file written successfully", "CacheManager")
        except Exception as e:
            logger.warning(f"Could not save cache: {e}", "CacheManager")
    
    def _compute_file_hash(self, file_path: str) -> str:
        """Compute SHA-256 hash of a file."""
        hasher = hashlib.sha256()
        try:
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except IOError:
            # If file doesn't exist or can't be read, return empty hash
            return ""
    
    def _compute_files_signature(self, files: List[str]) -> str:
        """
        Compute a signature for a list of files based on their hashes.
        
        Args:
            files: List of file paths to include in signature
            
        Returns:
            Combined hash representing all files
        """
        # Sort files to ensure consistent ordering
        sorted_files = sorted(files)
        combined_hash = hashlib.sha256()
        
        for file_path in sorted_files:
            if os.path.exists(file_path):
                file_hash = self._compute_file_hash(file_path)
                # Include both filename and hash to detect file renames
                combined_hash.update(f"{file_path}:{file_hash}".encode())
            else:
                # File doesn't exist - include in signature so cache invalidates if file is deleted
                logger.warning(f"File does not exist for cache signature computation: {file_path}", "CacheManager")
                combined_hash.update(f"{file_path}:MISSING".encode())
        
        return combined_hash.hexdigest()
    
    def get_cache_key(self, contract_files: List[str], config_file: str) -> str:
        """
        Generate a cache key for a specific configuration run.
        
        Args:
            contract_files: List of contract source files
            config_file: Configuration file path
            
        Returns:
            Unique cache key for this combination
        """
        # Parse split key if present and find actual config file
        original_config_key = config_file
        actual_config_path: str | None = config_file

        if "#" in config_file:
            # Split key format: "config_file#contract_name"
            config_file_name = config_file.split("#", 1)[0]

            # First check if it's already a valid path
            if os.path.exists(config_file_name):
                actual_config_path = config_file_name
            else:
                # Search for config file in certora directory and its subdirectories
                actual_config_path = None
                for root, dirs, files in os.walk("certora"):
                    if config_file_name in files:
                        actual_config_path = os.path.join(root, config_file_name)
                        break

                if not actual_config_path:
                    raise FileNotFoundError(f"Configuration file '{config_file_name}' not found")

        # Validate that config file exists
        if actual_config_path is None or not os.path.exists(actual_config_path):
            raise FileNotFoundError(f"Configuration file not found: {actual_config_path}")

        # Include all relevant files in the signature
        all_files = contract_files.copy()
        all_files.append(actual_config_path)

        # Extract spec file from config and add it to files list
        try:
            with open(actual_config_path, 'r') as f:
                config_data = json.load(f)
                verify_field = config_data.get("verify", "")
                if ":" in verify_field:
                    spec_file = verify_field.split(":")[1]
                    if os.path.exists(spec_file):
                        all_files.append(spec_file)
        except (json.JSONDecodeError, IOError) as e:
            raise ValueError(f"Failed to parse configuration file {actual_config_path}: {e}")
        
        # Create cache key from file signature and original config key
        files_signature = self._compute_files_signature(all_files)
        # Use the original key (with split if present) for cache name
        config_name = Path(original_config_key).name.replace("#", "_")
        return f"{config_name}_{files_signature[:12]}"
    
    def get_cached_job_url(self, cache_key: str) -> Optional[str]:
        """
        Get cached job URL for a cache key.
        
        Args:
            cache_key: Cache key to look up
            
        Returns:
            Job URL if found in cache, None otherwise
        """
        return self.cache_data["entries"].get(cache_key, {}).get("job_url")
    
    def store_job_url(self, cache_key: str, job_url: str, config_file: str) -> None:
        """
        Store a job URL in the cache.

        Args:
            cache_key: Cache key to store under
            job_url: Job URL to store
            config_file: Configuration file path for reference
        """
        logger.debug(f"Storing job URL: {cache_key} -> {job_url}", "CacheManager")
        self.cache_data["entries"][cache_key] = {
            "job_url": job_url,
            "config_file": config_file,
            "cached_at": datetime.now().isoformat(),
        }
        self.cache_data["last_updated"] = datetime.now().isoformat()
        logger.debug(f"Total cache entries: {len(self.cache_data['entries'])}", "CacheManager")
        self._save_cache()
    
    def get_cache_summary(self) -> Dict[str, Any]:
        """Get summary of cache contents."""
        entries = self.cache_data["entries"]
        return {
            "total_entries": len(entries),
            "last_updated": self.cache_data.get("last_updated"),
            "cache_file": str(self.cache_file),
            "entries": [
                {
                    "cache_key": key,
                    "config_file": entry.get("config_file", "unknown"),
                    "job_url": entry.get("job_url", ""),
                    "cached_at": entry.get("cached_at", "unknown")
                }
                for key, entry in entries.items()
            ]
        }
    
    def clear_cache(self) -> None:
        """Clear all cache entries."""
        self.cache_data = {
            "version": "1.0", 
            "entries": {},
            "last_updated": None
        }
        self._save_cache()
    
    def remove_stale_entries(self, valid_config_files: List[str]) -> None:
        """
        Remove cache entries for configuration files that no longer exist.
        
        Args:
            valid_config_files: List of currently valid configuration files
        """
        valid_configs = set(valid_config_files)
        entries_to_remove = []
        
        for cache_key, entry in self.cache_data["entries"].items():
            config_file = entry.get("config_file", "")
            if config_file and config_file not in valid_configs:
                entries_to_remove.append(cache_key)
        
        for key in entries_to_remove:
            del self.cache_data["entries"][key]
        
        if entries_to_remove:
            self._save_cache()
            logger.info(f"Removed {len(entries_to_remove)} stale cache entries", "CacheManager")