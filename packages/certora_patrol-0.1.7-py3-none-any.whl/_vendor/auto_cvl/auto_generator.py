import json
import logging
import os
import sys
from pathlib import Path
from typing import Awaitable, Callable, TypedDict, cast
from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, Field, RootModel

# Add parent directory to path to import shared modules
sys.path.insert(0, str(Path(__file__).parent.parent))
from token_usage_tracker import TokenUsageTracker

# Configure logging
log_level = os.getenv("LOGLEVEL", "WARNING").upper()
logging.basicConfig(level=getattr(logging, log_level), format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Read the grammar file
GRAMMAR_FILE_PATH = Path(__file__).parent / "properties_grammar.lark"
PROPERTIES_GRAMMAR = GRAMMAR_FILE_PATH.read_text()


# Pydantic Models
class PropertyExplanation(BaseModel):
    what_it_means: str = Field(description="Clear explanation of what the property expresses")
    why_it_should_hold: str = Field(
        description="Reasoning for why this property is necessary based on the contract code"
    )
    possible_consequences: str = Field(description="Specific attack vectors or failures if this property is violated")
    exploit_scenario: str = Field(
        description="Detailed description with steps on how an attacker can exploit this property if violated"
    )


class PropertyAnalysis(RootModel[dict[str, dict[str, PropertyExplanation]]]):
    root: dict[str, dict[str, PropertyExplanation]] = Field(description="Analysis of each property")


class KeyedProperties(RootModel[dict[str, dict[str, str]]]):
    root: dict[str, dict[str, str]] = Field(description="Key to property names mapped to their expressions")


class ValidationToolResponse(TypedDict):
    success: bool
    errors: list[str]
    instruction: str


system_prompt = f"""
SYSTEM PROMPT: Web3 Formal Verification Expert
You are a web3 security expert specializing in formal verification of smart contracts. Your goal is to generate precise, non-duplicate properties that catch real bugs.

PROPERTY SYNTAX GRAMMAR:
Your expressions must conform to this exact grammar:

```lark
{PROPERTIES_GRAMMAR}
```

Key rules from the grammar:
- ALL function calls MUST have timing annotations (@before or @after)
- Timing annotations: modifier_suffix: AT BEFORE_AFTER

CORE RULES:

NO-OPS MUST REVERT: If an operation does nothing meaningful, it MUST revert

CORRECT: amount == 0 => revert
WRONG: amount == 0 => balanceOf(user)@before == balanceOf(user)@after

NO EVENTS: Never use emit - only state changes and reverts

CORRECT: balanceOf(user)@after == balanceOf(user)@before + amount
WRONG: emit Transfer(from, to, amount)

NO TYPE TAUTOLOGIES: Never generate properties always true due to Solidity's type system
WRONG: returnsUint128()@after <= type(uint128).max (uint128 function cannot exceed uint128 max)
WRONG: totalSupply()@after >= 0 (uint is always >= 0)

REALISTIC PROPERTIES: Each property must be able to fail with a buggy implementation

PROPERTY SYNTAX EXAMPLES:
State: token.balanceOf(user)@after == token.balanceOf(user)@before + amount
Reverts: amount <= 0 => revert
Combined: amount <= 0 || !authorized => revert
Timing: @after and @before go AFTER the function/variable name
Available variables: Function parameters, standard blockchain variables (msg.sender, block.timestamp, etc.), and storage variables.
Function return: use `result` if the function return parameter is not named

Forbidden:
WRONG: emit EventName(...)
WRONG: balanceOf(user) (missing timing annotation)
WRONG: @after balanceOf(user) (wrong timing placement)
WRONG: balanceOf@after(user) (wrong timing placement)
WRONG: English descriptions
WRONG: Always-true conditions like x == x

DEFENSIVE PATTERNS:
No-Op Prevention (MUST REVERT):
amount <= 0 => revert
from == to => revert
newValue == currentValue => revert

Parameter Validation:
amount <= 0 => revert
to == address(0) => revert
!exists(to) => revert

Access Control (COMBINED):
!hasRole(caller) || !isActive(caller) => revert

State Changes (VALID OPERATIONS):
amount > 0 && authorized => balanceOf(to)@after == balanceOf(to)@before + amount

Collection Consistency (VALID OPERATIONS):
- Adding to lists/mappings: other != newItem => collection[other] != collection[newItem]
- Token/ID uniqueness: tokenId != newTokenId => tokenData[tokenId] != tokenData[newTokenId]
- Address mapping: user1 != user2 => userToToken[user1] != userToToken[user2]

CRITICAL: REVERT ANNOTATION RULE
When a property description explicitly mentions:
- "WITHOUT REVERT"
- "should NOT REVERT"
- "must not revert"
- "does not revert"
- "successfully executes"
- Or any similar language about successful execution

Then the property definition MUST include `&& !revert` on the right side of the implication.
Example:
{{
    "property": "Valid transfer succeeds WITHOUT REVERT",
    "description": "When sender has sufficient balance, transfer should NOT REVERT and receiver balance should increase"
    "definition": "balance(sender)@before >= amount => balance(receiver)@after == balance(receiver)@before + amount && !revert"
}}

CORRECT: Description says "WITHOUT REVERT" → definition ends with `&& !revert`
WRONG: Description says "WITHOUT REVERT" → definition missing `&& !revert`
    "balance(sender)@before >= amount => balance(receiver)@after == balance(receiver)@before + amount"

Another example:
{{
    "property": "Deposit does not revert with valid input and total deposit increase",
    "definition": "amount > 0 && token != address(0) => totalDeposits@after == totalDeposits@before + amount && !revert"
}}
RULE: If the description mentions non-reverting behavior, the definition MUST include `&& !revert` at the end.


ANALYSIS PROCESS:
ACCESS_CONTROL: What authorization is required?
PARAMETER_VALIDATION: What makes inputs invalid?
NO_OP_PREVENTION: What meaningless operations should revert?
STATE_CHANGES: For valid operations, what should change?
BOUNDARY_CONDITIONS: What limits cause failures?
UNIQUENESS_CHECKS: What items must remain unique? (Prevent duplicates)

OUTPUT FORMAT:
JSON only. Property names: max 5 words in snake_case. Property values: Solidity-like expressions.
Quality Check Before Including:
Can this fail with a realistic bug?
Does this test specific behavior (not language features)?
Is this NOT covered by another property?
"""


async def request_properties(
    contract_code: str,
    storage_vars: dict[str, str] | None,
    contract_devdoc: dict[str, str] | None,
    extra_text: str,
    request: str,
    key: str,
    validator: Callable[[KeyedProperties], Awaitable[ValidationToolResponse]] | None,
    token_tracker: TokenUsageTracker,
) -> tuple[KeyedProperties, PropertyAnalysis]:
    logger.info(f"Requesting properties for key: {key}")

    newline = "\n"

    # Split query into cacheable and variable parts
    # Cacheable part: contract code and metadata (same across all method requests)
    cacheable_context = f"""
        Below is a contract:
        ```
        {contract_code}
        ```
        {f"Here is a mapping of its storage variables to their types:{newline}{json.dumps(storage_vars, indent=2)}{newline}ONLY these storage variables are available for use in properties." if storage_vars else ""}

        {f"Here is the devdoc for this contract:{newline}{json.dumps(contract_devdoc, indent=2)}" if contract_devdoc else ""}

        {f"Here is some extra info about this contract:{newline}{extra_text}" if extra_text else ""}
    """

    # Variable part: specific request and output format (changes per method)
    request_part = f"""
        {request}

        Please provide your response in JSON format with the following structure:
        {{
            "{key}": {{
                "property_name_1": "property_expression_1",
                "property_name_2": "property_expression_2"
            }}
        }}

        Property names should describe the behavior in at most 5 words.
        Output ONLY the JSON, without markdown formatting or ```json prefix.
    """

    # messages: list[MessageParam] = [{"role": "user", "content": [{"type": "text", "text": query}]}]

    model = ChatAnthropic(  # type: ignore - ChatAnthropic constructor signature varies between versions
        model_name="claude-opus-4-5-20251101",
        max_tokens=20000,  # type: ignore - parameter name varies between versions
        temperature=0,
    )
    properties_model = model.with_structured_output(KeyedProperties, include_raw=True)

    system_message = SystemMessage(
        content=[{"type": "text", "text": system_prompt, "cache_control": {"type": "ephemeral"}}]
    )

    # Cache the contract context, send only method-specific request fresh
    human_message = HumanMessage(
        content=[
            {"type": "text", "text": cacheable_context, "cache_control": {"type": "ephemeral"}},
            {"type": "text", "text": request_part},
        ]
    )

    messages = [system_message, human_message]

    max_attempts = 3
    attempt_count = 0
    properties_response = None

    while attempt_count < max_attempts:
        attempt_count += 1
        logger.info(f"{key}: Starting property generation attempt {attempt_count}/{max_attempts}")

        # Add a cache control point at the last message, use casting to make pyright happy
        cast(dict, cast(BaseMessage, messages[-1]).content[0])["cache_control"] = {"type": "ephemeral"}

        properties_response_dict = await properties_model.ainvoke(messages)
        assert isinstance(properties_response_dict, dict)
        properties_response = properties_response_dict["parsed"]
        assert isinstance(properties_response, KeyedProperties)

        # Track token usage from the raw response
        token_tracker.log_usage_generator(
            properties_response_dict["raw"], f"{key} - Property Generation Attempt {attempt_count}", ""
        )

        # Remove the cache control point (so we don't end up with more than 4 of them which is the maximum Claude supports), use casting to make pyright happy
        del cast(dict, cast(BaseMessage, messages[-1]).content[0])["cache_control"]

        # Add Claude's response to conversation
        messages.append(AIMessage(content=[{"type": "text", "text": properties_response.model_dump_json(indent=2)}]))

        # If we have a validator, run manual validation
        if validator:
            logger.info(f"{key}: Running validation on generated properties")
            validation_result = await validator(properties_response)
            logger.info(
                f"{key}: Validation result: success={validation_result['success']}, errors={len(validation_result.get('errors', []))}"
            )

            if validation_result.get("errors"):
                logger.debug(f"{key}: Validation errors: {validation_result['errors']}")

            # If validation passed, we're done
            if validation_result["success"]:
                logger.info(f"{key}: Validation passed, properties generation completed after {attempt_count} attempts")
                break
            else:
                # Validation failed, add feedback message and retry if attempts remain
                if attempt_count < max_attempts:
                    feedback_message = f"""
                    The properties you generated have validation errors. Here is the feedback:

                    {json.dumps(validation_result)}

                    Please fix these issues and provide a corrected response in the same JSON format.
                    Output ONLY the JSON, without markdown formatting or ```json prefix.
                    """
                    messages.append(HumanMessage(content=[{"type": "text", "text": feedback_message}]))
                    logger.info(
                        f"{key}: Validation failed, retrying with feedback (attempt {attempt_count + 1}/{max_attempts})"
                    )
                    continue
                else:
                    logger.warning(f"{key}: Validation failed after {max_attempts} attempts, using last response")
                    break
        else:
            # No validator, we're done
            logger.info(f"{key}: No validator provided, properties generation completed after {attempt_count} attempts")
            break

    assert properties_response is not None  # Loop always executes at least once
    logger.info(f"{key}: Properties generation completed after {attempt_count} attempts")

    # Second request for analysis
    logger.info(f"{key}: Requesting property analysis")
    analysis_model = model.with_structured_output(PropertyAnalysis, include_raw=True)

    # Add a cache control point at the last message, use casting to make pyright happy
    cast(dict, cast(BaseMessage, messages[-1]).content[0])["cache_control"] = {"type": "ephemeral"}

    analysis_message = HumanMessage(
        content=[
            {
                "type": "text",
                "text": f"""
                For each property you provided in your previous response, explain what it means and how you determined it should hold.

                CRITICAL: Use the EXACT property names as keys from your previous JSON response. Do not modify, abbreviate, or rephrase the property names in any way.

                Please provide your response in JSON format with the following structure:
                {{
                    "{key}": {{
                        "exact_property_name_from_previous": {{
                            "what_it_means": "Clear explanation of what the property expresses",
                            "why_it_should_hold": "Your reasoning for why this property is necessary based on the contract code",
                            "possible_consequences": "Specific attack vectors or failures if this property is violated (DoS, fund loss, state corruption, etc.)",
                            "exploit_scenario": "A detailed description with steps on how an attacker can exploit this property if it's violated"
                        }}
                    }}
                }}

                VALIDATION CHECK: Every key in the properties object must appear as a property name in your previous response.
                Output ONLY the JSON, without markdown formatting or ```json prefix.
            """,
            }
        ]
    )
    messages.append(analysis_message)

    analysis_response_dict = await analysis_model.ainvoke(messages)
    assert isinstance(analysis_response_dict, dict)
    analysis_response = analysis_response_dict["parsed"]
    assert isinstance(analysis_response, PropertyAnalysis)

    # Track token usage for analysis
    token_tracker.log_usage_generator(analysis_response_dict["raw"], f"{key} - Analysis", "")

    logger.info(f"{key}: Property analysis completed successfully")
    return properties_response, analysis_response


async def request_method_properties(
    contract_code: str,
    method_name: str,
    selector: str,
    storage_vars: dict[str, str],
    contract_devdoc: dict[str, str] | None,
    extra_text: str,
    validator: Callable[[KeyedProperties], Awaitable[ValidationToolResponse]] | None,
    token_tracker: TokenUsageTracker,
    summarized_contract: bool = False,
) -> tuple[KeyedProperties, PropertyAnalysis]:
    logger.info(f"Requesting properties for method: {method_name} (selector: {selector})")

    if summarized_contract:
        context_explanation = f"""
        IMPORTANT: The contract code shows function DECLARATIONS with summary comments (// Summary: ...).
        Function implementations have been removed and replaced with declarations.
        Each function has a summary comment describing what it does.
        Use these summaries to understand the expected behavior of each function.
        Generate properties for function {method_name} based on its summary and the contract structure.
        """
    else:
        context_explanation = f"""
        The body of function {method_name} was removed. Generate properties for this function only.
        """

    request = f"""
        {context_explanation}

        CRITICAL REMINDERS:

        Generate ALL properties
        NO-OPS MUST REVERT (use => revert, not => no change)
        Add uniqueness checks
        NO emit statements
        Focus ONLY on function {method_name}.
        Use ONLY storage variables from the provided mapping, taking their type into account
        IF property description mentions "WITHOUT REVERT", "NOT REVERT", or similar → definition MUST end with `&& !revert`

        WARNING: Make sure that you consider applying the rule.
        WARNING: Don't forget check REVERT if it's mentioned in property
    """

    return await request_properties(
        contract_code,
        storage_vars,
        contract_devdoc,
        extra_text,
        request,
        f"{method_name}:{selector}",
        validator,
        token_tracker,
    )


async def request_contract_properties(
    contract_code: str,
    contract_name: str,
    storage_vars: dict[str, str],
    contract_devdoc: dict[str, str] | None,
    extra_text: str,
    validator: Callable[[KeyedProperties], Awaitable[ValidationToolResponse]] | None,
    token_tracker: TokenUsageTracker,
    summarized_contract: bool = False,
) -> tuple[KeyedProperties, PropertyAnalysis]:
    logger.info(f"Requesting contract-wide properties for: {contract_name}")

    if summarized_contract:
        context_explanation = """
        IMPORTANT: The contract code shows function DECLARATIONS with summary comments (// Summary: ...).
        Function implementations have been removed and replaced with declarations.
        Each function has a summary comment describing what it does.
        Use these summaries to understand the expected behavior and generate contract-wide invariants.
        """
    else:
        context_explanation = ""

    request = f"""
        {context_explanation}

        Generate ALL properties for this contract.

        IMPORTANT
        These properties should be invariants that apply to ALL methods in the contract.
        If it applies only to some of the functions - skip it.

        PROPERTY IMPLEMENTATION:
        Each property will be implemented as: assume property; call some function from the contract; assert property
        This means we assume the property holds before the function call, then verify it still holds after.
        Since these are invariants (not function-specific properties), you CANNOT use "=> revert" patterns.
        You also CANNOT use @before and @after timing annotations - they make no sense for invariants.
        Focus only on state relationships that must be preserved across all function calls.
        Avoid tautologies (always-true statements like x == x or x >= x).

        HINTS:
        Think of properties regarding the relations between different state variables
        Avoid properties about the type of a variable - e.g. WRONG `totalSupply() >= 0`. This is pointless because totalSupply is stored in an unsigned integer.

        CRITICAL REMINDERS:

        NO emit statements
        NO @before/@after timing annotations
        NO tautologies (always-true conditions)
        Use ONLY storage variables from the provided mapping, taking their type into account
        NEVER use function parameters
    """

    return await request_properties(
        contract_code, storage_vars, contract_devdoc, extra_text, request, contract_name, validator, token_tracker
    )
