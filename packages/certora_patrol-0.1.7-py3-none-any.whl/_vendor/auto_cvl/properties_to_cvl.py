#!/usr/bin/env python3
from datetime import datetime
import sys
from pathlib import Path

# Add parent directory to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

from Crypto.Hash import keccak
from dataclasses import dataclass, field, replace
import json
from lark import Lark, Token, Transformer, v_args
from lark.exceptions import VisitError
import re
from typing import Any, Literal, Self, TypeAlias, TypedDict, cast

from auto_cvl.auto_generator import KeyedProperties, PropertyAnalysis, PropertyExplanation
from auto_cvl.solc_parsing import (
    ADDRESS_TYPE,
    BOOL_TYPE,
    INTEGER_TYPES,
    BYTES_TYPES,
    INT_TYPES,
    MATHINT,
    NUMBER_LITERAL,
    SIMPLE_TYPES,
    UINT_TYPES,
    ArrayType,
    ConstantValue,
    ContractType,
    EnumType,
    FunctionABI,
    MappingType,
    NamedParameter,
    SimpleType,
    SolidityType,
    StorageLayoutInfo,
    StructType,
    SolcParser,
    solidity_type_bounds,
)


AUTO_CVL_DIR = Path(".certora_internal/auto_cvl")


# TypedDict definitions for better type safety
class AssumptionExpression(TypedDict):
    """Represents an assumption/invariant expression with its description."""

    expression: str
    description: str


class _BaseAccumulated(TypedDict):
    """Base fields for accumulated assumptions/invariants."""

    description: str
    rules: list[str]


class AccumulatedAssumptionType(_BaseAccumulated):
    """Represents an accumulated blockchain state assumption."""

    assumption: str


class AccumulatedInvariantType(_BaseAccumulated):
    """Represents an accumulated contract state invariant."""

    invariant: str


# Union type for either assumption or invariant
AccumulatedAssumption = AccumulatedAssumptionType | AccumulatedInvariantType


def get_new_auto_cvl_dir() -> Path:
    return AUTO_CVL_DIR / datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def find_newest_dir(directory: Path) -> Path | None:
    """
    Find the newest directory in the specified directory.

    Args:
        directory: Directory to search in

    Returns:
        Path to the newest subdirectory, or None if none found
    """
    if not directory.exists():
        return None

    subdirs = [d for d in directory.iterdir() if d.is_dir()]

    if not subdirs:
        return None

    # Return the directory with the latest creation time
    return max(subdirs, key=lambda d: d.stat().st_ctime)


@dataclass
class CVLTranslationError(Exception):
    message: str
    suggestion: str | None = None

    def __str__(self):
        return self.message

    def with_suggestion(self):
        ret = self.message
        if self.suggestion:
            ret += f"\tSuggestion: {self.suggestion}"
        return ret


@dataclass
class SolcInfo:
    abi_info: dict[str, dict[str, FunctionABI]]
    storage_layout_info: dict[str, dict[str, StorageLayoutInfo]]
    immutables_and_constants: dict[str, dict[str, ConstantValue]]
    enum_types: dict[str, EnumType]
    udvts: dict[str, str]


@dataclass(frozen=True)
class ExpInfo:
    type: SolidityType | None = None
    parts: tuple[str | Self, ...] = ()
    modifier: Literal["before", "after"] | None = None
    needs_parens: bool = False

    def __str__(self):
        ret = "".join(p if isinstance(p, str) else p.name for p in self.parts)
        if self.needs_parens:
            return f"({ret})"
        return ret

    @classmethod
    def simple_exp(cls, name: str, ty: SolidityType | None = None) -> Self:
        return cls(type=ty, parts=(name,))

    @property
    def name(self) -> str:
        if not self.modifier:
            return str(self)
        return sanitize(str(self)) + f"_{self.modifier}"

    def sub_expressions(self) -> list[Self]:
        ret: list[Self] = []
        for exp in self.parts:
            if isinstance(exp, str):
                continue
            ret += exp.sub_expressions()
            ret.append(exp)
        ret.append(self)
        return ret


@dataclass(frozen=True)
class ExpInfoTyped(ExpInfo):
    type: SolidityType = SimpleType("dummy")

    def __post_init__(self):
        assert self.type != SimpleType("dummy"), "ExpInfoTyped must be initialized with a type"

    @classmethod
    def from_exp_info(cls, exp: ExpInfo, ty: SolidityType, parts: tuple[str | Self, ...]) -> Self:
        return cls(type=ty, parts=parts, modifier=exp.modifier, needs_parens=exp.needs_parens)


@dataclass(frozen=True)
class FunctionCall:
    name: str
    args: tuple[ExpInfo, ...]

    def __str__(self):
        return f"{self.name}({', '.join(['e'] + [str(arg) for arg in self.args])})"

    def to_assignment(self) -> tuple[str | ExpInfo, ...]:
        args_list: list[str | ExpInfo] = []
        for arg in self.args:
            args_list.append(", ")
            args_list.append(arg)
        return tuple([f"{self.name}(e"] + args_list + [")"])


FieldAccess: TypeAlias = str


@dataclass(frozen=True)
class AccessType:
    pass


@dataclass(frozen=True)
class DotAccessType(AccessType):
    access: FunctionCall | FieldAccess

    def __str__(self):
        return f".{self.access}"

    def to_assignment(self) -> list[str]:
        assert isinstance(self.access, FieldAccess), "Can't call `to_assignment` on an access to a function"
        return [f".{self.access}"]


@dataclass(frozen=True)
class IndexedAccessType(AccessType):
    access: ExpInfo

    def __str__(self):
        return f"[{self.access}]"

    def to_assignment(self) -> list[str | ExpInfo]:
        return ["[", self.access, "]"]


@dataclass
class RequireStatement:
    expression: ExpInfo
    description: str
    free_vars: dict[str, SolidityType | None]


def _find_index(the_list: list, value: Any) -> int:
    """
    Return first index of value.

    Returns -1 if the value is not present
    """
    try:
        return the_list.index(value)
    except ValueError:
        return -1


class CVLRuleGenerator(Transformer):
    def __init__(
        self,
        rule_name: str,
        property: str,
        contract_name: str,
        function_signature: str | None,
        selector: str | None,
        solc_info: SolcInfo,
        assumption_expressions: list[RequireStatement],
    ):
        self.rule_name = rule_name
        self.property = property
        self.contract = contract_name
        if function_signature:
            self.func_name: str | None = function_signature.split("(")[0]
            func_abi_info = solc_info.abi_info[contract_name][function_signature]
            self.inputs = func_abi_info.inputs
            self.outputs = func_abi_info.outputs
            if len(self.outputs) == 1 and not self.outputs[0].name:
                self.outputs = [NamedParameter("result", self.outputs[0].type)]
        else:
            self.func_name = None
            self.inputs = []
            self.outputs = []
        self.abi_info = solc_info.abi_info
        self.storage_layout_info = solc_info.storage_layout_info
        self.immutables_and_constants = solc_info.immutables_and_constants
        self.enum_types = solc_info.enum_types
        self.udvts = solc_info.udvts
        self.selector = selector
        self.assumption_expressions = assumption_expressions
        self.revert_rule = False

        # Give names to the unnamed input parameters
        for i in range(len(self.inputs)):
            if not self.inputs[i].name:
                self.inputs[i] = replace(self.inputs[i], name=f"__parameter_{i}")

        self.free_vars: dict[str, SolidityType | None] = {
            param.name: param.type for param in self.inputs + self.outputs if param.name
        }
        self.using_contracts: set[str] = set()

    @property
    def revert_var_name(self) -> str:
        return f"{self.func_name if self.func_name else 'f'}_reverted"

    @property
    def after_vars(self) -> list[str]:
        """Variables that must come in an `@after` context"""
        return [output.name for output in self.outputs] + [self.revert_var_name]

    def _is_free_var(self, var_name: str):
        return re.fullmatch(r"[a-zA-Z_$][a-zA-Z0-9_$]*", var_name) and var_name not in [
            "true",
            "false",
            "currentContract",
        ] + [t.type_str for t in SIMPLE_TYPES]

    def _is_enum_literal(self, s: str) -> bool:
        maybe_enum, _, maybe_member = s.rpartition(".")
        if (
            maybe_enum in self.enum_types
            and (members := self.enum_types[maybe_enum].members)
            and maybe_member in members
        ):
            return True
        return False

    def _check_number_literal_within_range(self, val: ExpInfo, ty: SolidityType):
        try:
            n = int(val.name, 0)
        except ValueError:
            return
        if ty in UINT_TYPES:
            width = int((_find_index(UINT_TYPES, ty) + 1) * 8)
            in_range = n >= 0 and n < 2**width
        elif ty in INT_TYPES:
            width = int((_find_index(INT_TYPES, ty) + 1) * 8)
            in_range = n >= -(2 ** (width - 1)) and n < 2 ** (width - 1)
        elif ty in BYTES_TYPES:
            width = int((_find_index(BYTES_TYPES, ty) + 1) * 8)
            in_range = n >= 0 and n < 2**width
        elif ty.type_str == "address":
            in_range = n >= 0 and n < 2**160
        elif ty in [MATHINT, NUMBER_LITERAL]:
            in_range = True
        else:
            raise RuntimeError(f"Unexpected type {ty} for number literal {n}")
        if not in_range:
            raise CVLTranslationError(f"Number literal {n} is out of range for type {ty}")

    def generate_expression(self, tree) -> ExpInfo:
        return super().transform(tree)

    def generate_require(self, tree) -> ExpInfo:
        return self.generate_expression(tree)

    def generate_rule_or_invariant(self, tree):
        # First, collect all necessary info by traversing the tree
        assert_expression = self.generate_expression(tree)

        unknown_free_vars = [k for k, v in self.free_vars.items() if not v]
        if unknown_free_vars:
            raise CVLTranslationError(f"Couldn't infer a type for the variables {unknown_free_vars}")

        assert_expression = self._typecheck(assert_expression)

        # Now, generate the CVL rule string
        if self.func_name:
            return self._generate_cvl_rule(assert_expression)
        else:
            return self._generate_cvl_invariant(assert_expression)

    # --- Transformer Methods to Collect Information ---

    def identifier(self, v):
        i = str(v[0])
        ty = self.free_vars.get(i, None)
        if i in ("true", "false"):
            ty = BOOL_TYPE
        return ExpInfo.simple_exp(i, ty)

    def _scientific_notation_to_decimal(self, n):
        return re.sub(r"(\d+)\s*[eE]\s*(\d+)", r"(\1 * 10 ^ \2)", n)

    def number_literal(self, n):
        # Add numeric literals directly to the assert expression
        val = str(n[0])
        return ExpInfo.simple_exp(self._scientific_notation_to_decimal(val), NUMBER_LITERAL)

    def hexnum_literal(self, n):
        # Add numeric literals directly to the assert expression
        return ExpInfo.simple_exp(str(n[0]), NUMBER_LITERAL)

    def _n_with_unit(self, val, unit):
        match unit:
            case "wei":
                return str(val)
            case "gwei":
                return f"({val} * 10 ^ 9)"
            case "ether":
                return f"({val} * 10 ^ 18)"
            case "seconds":
                return str(val)
            case "minutes":
                return f"({val} * 60)"
            case "hours":
                return f"({val} * 60 * 60)"
            case "days":
                return f"({val} * 60 * 60 * 24)"
            case "weeks":
                return f"({val} * 60 * 60 * 24 * 7)"
            case _:  # pragma: no cover
                assert False, f"non-existent unit {unit}"

    def number_with_unit(self, tokens):
        val = int(tokens[0])
        unit = str(tokens[1])
        n = self._n_with_unit(val, unit)
        return ExpInfo.simple_exp(n, NUMBER_LITERAL)

    def hexnum_with_unit(self, tokens):
        val = int(tokens[0], 16)
        unit = str(tokens[1])
        n = self._n_with_unit(val, unit)
        return ExpInfo.simple_exp(n, NUMBER_LITERAL)

    # This method is called when Lark encounters the MODIFIER_SUFFIX rule in the parse tree.
    # It receives the children of the MODIFIER_SUFFIX rule.
    @v_args(inline=True)  # MODIFIER_SUFFIX: "@" ("before" | "after")
    def modifier_suffix(self, at_token, modifier_keyword_token):
        # 'at_token' will be Token('@', '@')
        # 'modifier_keyword_token' will be Token('before', 'before') or Token('after', 'after')
        return str(modifier_keyword_token)  # Return just 'before' or 'after'

    def _access_chain_and_modifier(
        self,
        first_unit: ExpInfo | FunctionCall,
        modifier: Literal["before", "after"] | None,
        chain_elements: tuple[AccessType, ...],
    ) -> ExpInfo:
        if len(chain_elements) == 1:
            single_elem = chain_elements[0]  # Useful for many checks later in this function
        else:
            single_elem = None

        def handle_function_call(func: FunctionCall, contract: str) -> tuple[tuple[str | ExpInfo, ...], SolidityType]:
            """
            Handles anything of the form `name(args...)`

            @param func: The function call to transform
            @param contract: The base contract of this function
            """
            nonlocal modifier
            nonlocal chain_elements

            if modifier == "before":
                for arg in func.args:
                    for exp in arg.sub_expressions():
                        if exp.modifier == "after":
                            raise CVLTranslationError(
                                f"Cannot use the `@after` expression {exp} within the `@before` call {func}",
                                suggestion="`@before` calls can only have `@before` arguments, or non-timed ones",
                            )
                        if str(exp) in self.after_vars:
                            raise CVLTranslationError(
                                f"Cannot use the variable {exp} within the `@before` call {func}",
                                suggestion="return variables and the `revert` variable are only defined _after_ the main function call",
                            )

            if (
                func.name == "type"
                and len(func.args) == 1
                and len(func.args[0].parts) == 1
                and isinstance(single_elem, DotAccessType)
                and single_elem.access in ("min", "max")
            ):
                # type(someType).min/max
                min_or_max = single_elem.access
                chain_elements = ()
                ty = func.args[0]
                min, max = solidity_type_bounds(str(ty.parts[0]))
                if min_or_max == "min":
                    return (f"({min})",), NUMBER_LITERAL
                else:
                    return (f"({max})",), NUMBER_LITERAL

            if func.name == "address" and len(func.args) == 1:
                # This is a cast of something to address, CVL doesn't need this cast so short-circuit
                address = func.args[0]
                try:
                    int(str(address), 0)
                    # It's a constant, so no access path
                    return (str(address),), ADDRESS_TYPE
                except Exception:
                    if address.type and address.type.type_str == "address":
                        return (address,), ADDRESS_TYPE
                    if address.type == SimpleType("bytes32"):
                        return ("assert_address(", address, ")"), ADDRESS_TYPE
                    raise CVLTranslationError(
                        f"Cannot cast {address.type} to an address type",
                        suggestion="You can cast the other way around - an address to an integer type",
                    )

            if (udvt := f"{self.contract}.{func.name}") in self.udvts and len(func.args) == 1:
                # This is a cast of something to a udvt, CVL doesn't need this cast so short-circuit
                arg = func.args[0]
                try:
                    int(str(arg), 0)
                    # It's a constant, so no access path
                    return (str(arg),), SimpleType(self.udvts[udvt])
                except Exception:
                    return (arg,), SimpleType(self.udvts[udvt])

            if func.name in self.abi_info.keys() and len(func.args) == 1:
                # This is a cast of an address (or constant) to a contract. Short-circuit this to the address itself, typed as a ContractType
                arg = func.args[0]
                if arg.type != ADDRESS_TYPE and arg.type != NUMBER_LITERAL:
                    raise CVLTranslationError(
                        f"Cannot cast {arg} of type {arg.type} to {func.name}",
                        suggestion="Only number literals and address-typed variable can be cast to contract types",
                    )
                if arg.type == NUMBER_LITERAL:
                    self._check_number_literal_within_range(arg, ADDRESS_TYPE)
                address = str(arg)
                try:
                    int(address, 0)
                    # It's a constant, so no access path
                    return (address,), ContractType.create(func.name)
                except Exception:
                    return (arg,), ContractType.create(func.name)

            if func.name in (t.type_str for t in BYTES_TYPES) and len(func.args) == 1:
                # Cast to a bytesK, translate to CVL's `to_bytesK` if possible
                arg = func.args[0]
                k = int(func.name[5:])
                if (
                    arg.type
                    and arg.type != NUMBER_LITERAL
                    and (arg.type not in UINT_TYPES or int(arg.type.type_str[4:]) != k * 8)
                ):
                    raise CVLTranslationError(f"Type {arg.type.type_str} cannot be cast to {func.name}")
                ty = SimpleType(func.name)
                if arg.type == NUMBER_LITERAL:
                    self._check_number_literal_within_range(arg, ty)
                return (f"to_{func.name}(", arg, ")"), ty

            if func.name in (t.type_str for t in INT_TYPES) and len(func.args) == 1:
                # Cast to a intK. Note that casting in Solidity is actually just truncation, so
                # implement this same logic in CVL, and cast the output to the target intK type.
                n = int(func.name[3:]) if func.name[3:] else 256
                arg = func.args[0]

                if arg.type and (
                    arg.type not in INT_TYPES + [NUMBER_LITERAL]
                    and (arg.type not in UINT_TYPES or int(arg.type.type_str[4:]) != n)
                    and (arg.type not in BYTES_TYPES or int(arg.type.type_str[5:]) * 8 != n)
                ):
                    raise CVLTranslationError(f"Type {arg.type.type_str} cannot be directly cast to {func.name}")
                ty = SimpleType(func.name)
                if arg.type == NUMBER_LITERAL:
                    self._check_number_literal_within_range(arg, ty)
                _, max = solidity_type_bounds(func.name)
                total_range = f"2 ^ {n}"
                reduced: list[str | ExpInfo] = ["(", arg, f" % {total_range})"]
                return (
                    tuple(
                        [f"assert_{func.name}("]
                        + reduced
                        + [f" <= {max} ? "]
                        + reduced
                        + [" : "]
                        + reduced
                        + [f" - {total_range})"]
                    ),
                    ty,
                )

            if func.name in (t.type_str for t in UINT_TYPES) and len(func.args) == 1:
                # Cast to a uintK. Note that casting in Solidity is actually just truncation, so
                # implement this same logic in CVL, and cast the output to the target uintK type.
                n = int(func.name[4:]) if func.name[4:] else 256
                arg = func.args[0]
                if arg.type and (
                    arg.type not in UINT_TYPES + [NUMBER_LITERAL]
                    and (arg.type not in INT_TYPES or int(arg.type.type_str[3:]) != n)
                    and (arg.type not in BYTES_TYPES or int(arg.type.type_str[5:]) * 8 != n)
                ):
                    raise CVLTranslationError(f"Type {arg.type.type_str} cannot be directly cast to {func.name}")

                # Special case: case bytes32 to uint256, here there's nothing to do
                if n == 256 and arg.type and arg.type.type_str == "bytes32":
                    return ("assert_uint256(", arg, ")"), SimpleType("uint256")

                ty = SimpleType(func.name)
                if arg.type == NUMBER_LITERAL:
                    self._check_number_literal_within_range(arg, ty)
                _, max = solidity_type_bounds(func.name)
                total_range = f"2 ^ {n}"
                prefix: list[str | ExpInfo] = [f"assert_{func.name}(", arg, " >= 0 ? "]
                reduced = ["(", arg, f" % {total_range})"]
                suffix: list[str | ExpInfo] = [f" : {total_range} - (-(", arg, f") % {total_range}))"]
                return (
                    tuple(prefix + reduced + suffix),
                    ty,
                )

            # OK, this is actually a real function call. Search for an existing function that matches
            # the name and argument types
            signatures = [sig for sig in self.abi_info[contract].keys() if sig.startswith(f"{func.name}(")]
            f_infos = [self.abi_info[contract][signature] for signature in signatures]
            if not f_infos:
                raise CVLTranslationError(
                    f"No implementation of {func.name} found",
                    suggestion="If this function is private, recall that one cannot call such functions. If possible, try achieving a similar property using external function calls, storage accesses, or inlining the logic of the private function if it's simple",
                )
            f_infos = [f_info for f_info in f_infos if len(f_info.inputs) == len(func.args)]
            if not f_infos:
                raise CVLTranslationError(
                    f"Found no implementation of {func.name} with the provided number of input arguments ({len(func.args)})"
                )
            f_infos = [f_info for f_info in f_infos if len(f_info.outputs) == 1]
            if not f_infos:
                raise CVLTranslationError(
                    f"function {func.name} has more than one return value, so can't be directly derefenced"
                )
            updated_args = list(func.args)
            for i, arg in enumerate(func.args):
                if arg.name in [t.type_str for t in SIMPLE_TYPES]:
                    raise CVLTranslationError(f"Cannot use {arg} as a variable name for a function argument")

                if arg.type:
                    # The argument is typed, check if there's an implementation of the function
                    # with a matching type for this argument
                    f_infos = [
                        f_info
                        for f_info in f_infos
                        if f_info.inputs[i].type == arg.type
                        or (arg.type == NUMBER_LITERAL and isinstance(f_info.inputs[i].type, SimpleType))
                    ]
                    if not f_infos:
                        raise CVLTranslationError(
                            f"Cannot find an implementation of {func.name} with input #{i} of type {arg.type}"
                        )
                    if arg.type == NUMBER_LITERAL and (
                        (bytesK := _find_index(BYTES_TYPES, f_infos[0].inputs[i].type) + 1) > 0
                    ):
                        ty = f_infos[0].inputs[i].type
                        self._check_number_literal_within_range(arg, ty)
                        updated_args[i] = replace(
                            arg,
                            parts=(f"to_bytes{bytesK}(",) + arg.parts + (")",),
                            type=ty,
                        )
                else:
                    # The argument is untyped, let's infer its type from the function's argument type
                    input_type = f_infos[0].inputs[i].type
                    if not all(f_info.inputs[i].type == input_type for f_info in f_infos):
                        raise CVLTranslationError(f"Cannot infer the type of input #{i} of function {func.name}")
                    updated_args[i] = replace(arg, type=input_type)
                    if self._is_free_var(arg.name):
                        self.free_vars[arg.name] = input_type
            assert len(f_infos) == 1, (
                f"Unexpected: Found {len(f_infos)} functions named {func.name} that match all input argument types"
            )
            output_type = f_infos[0].outputs[0].type
            func = replace(func, args=tuple(updated_args))
            if not modifier and self.func_name:
                raise CVLTranslationError(
                    f"Function call {func} has no timing annotation", suggestion="Add `@before` or `@after` to the call"
                )

            return func.to_assignment(), output_type

        if first_unit.name == "this":
            if not isinstance(first_unit, ExpInfo):
                raise CVLTranslationError("unexpected call to `this`")
            if not chain_elements:
                # `this` as a standalone construct. Replace with `currentContract`
                first_unit = replace(first_unit, parts=("currentContract",), type=ContractType.create(self.contract))
            else:
                # `this.something.or[other]`. Remove the `this` part - it isn't needed in CVL
                first_elem = chain_elements[0]
                if not isinstance(first_elem, DotAccessType):
                    raise CVLTranslationError("Unexpected dereference type of 'this'")
                if isinstance(first_elem.access, FieldAccess):
                    first_unit = ExpInfo.simple_exp(first_elem.access)
                else:
                    # It's a function call
                    first_unit = first_elem.access
                chain_elements = chain_elements[1:]

        if isinstance(first_unit, FunctionCall):
            func_parts, ty = handle_function_call(first_unit, self.contract)
            first_unit = ExpInfo(type=ty, parts=func_parts)

        if first_unit.name in self.free_vars and not first_unit.type and self.free_vars[first_unit.name]:
            output_type = self.free_vars[first_unit.name]
            parts: list[str | ExpInfo] = list(first_unit.parts)
        elif first_unit.name == "result" and not chain_elements and len(self.outputs) == 1:
            # We're after looking for `first_unit` in the output types, so we're _not_ in the case where
            # the output type is unnamed (that case is handled by explicitly naming the output variable
            # `result`, see the definition of `self.outputs`)
            output_type = self.outputs[0].type
            parts = [self.outputs[0].name]
        elif first_unit.name in self.storage_layout_info.get(self.contract, {}):
            # Direct storage access
            storage_info = self.storage_layout_info.get(self.contract, {})[first_unit.name]
            if storage_info.multiple_inheritance:
                raise CVLTranslationError(
                    f"Cannot access storage named {storage_info.name} due to multiple inheritance",
                    suggestion="Check if there is a public getter for this field",
                )
            output_type = storage_info.type if not first_unit.type else first_unit.type
            parts = [f"currentContract.{first_unit}"]
            if not modifier and self.func_name:
                raise CVLTranslationError(
                    f"Storage access {first_unit} has no timing annotation",
                    suggestion="Add `@before` or `@after` to the access",
                )
        elif (
            self.contract in self.immutables_and_constants
            and first_unit.name in self.immutables_and_constants[self.contract]
        ):
            # CONSTANT / IMMUTABLE
            info = self.immutables_and_constants[self.contract][first_unit.name]
            if info.mutability == "constant":
                if info.visibility == "public":
                    first_unit = replace(first_unit, parts=(f"currentContract.{first_unit}(e)",), type=info.type)
                else:
                    raise CVLTranslationError(
                        f"Cannot inline private constant {first_unit}",
                        suggestion="Try inlining the actual value of the constant",
                    )
            else:
                assert info.mutability == "immutable", f"unexpected mutability {info.mutability}"
                first_unit = replace(first_unit, parts=(f"currentContract.{first_unit}",), type=info.type)

            output_type = info.type
            parts = [first_unit]
        elif (
            first_unit.name in self.immutables_and_constants
            and chain_elements
            and isinstance(chain_elements[0], DotAccessType)
            and isinstance(chain_elements[0].access, FieldAccess)
            and chain_elements[0].access in self.immutables_and_constants[first_unit.name]
        ):
            # Contract.CONSTANT / Contract.IMMUTABLE
            if not single_elem:
                raise CVLTranslationError(f"Cannot deref constant/immutable {first_unit}{chain_elements[0]}")
            single_elem = cast(DotAccessType, single_elem)
            const_var = cast(FieldAccess, single_elem.access)
            info = self.immutables_and_constants[first_unit.name][const_var]
            if info.mutability == "constant":
                if info.visibility == "public":
                    self.using_contracts.add(first_unit.name)
                    first_unit = replace(first_unit, parts=(f"{first_unit}{single_elem}(e)",), type=info.type)
                else:
                    raise CVLTranslationError(
                        f"Cannot inline private constant {first_unit}{single_elem}",
                        suggestion="Try inlining the actual value of the constant",
                    )
            else:
                assert info.mutability == "immutable", f"unexpected mutability {info.mutability}"
                self.using_contracts.add(first_unit.name)
                first_unit = replace(first_unit, parts=(f"{first_unit}{single_elem}",), type=info.type)

            chain_elements = chain_elements[1:]
            single_elem = None
            output_type = info.type
            parts = [first_unit]
        elif isinstance(single_elem, DotAccessType) and self._is_enum_literal(
            e := f"{self.contract}.{first_unit}{single_elem}"
        ):
            # Enum.MEMBER
            return ExpInfo.simple_exp(e, EnumType(f"{self.contract}.{first_unit}"))
        elif len(chain_elements) == 2 and self._is_enum_literal(
            e := f"{first_unit}{chain_elements[0]}{chain_elements[1]}"
        ):
            # Contract.Enum.MEMBER
            return ExpInfo.simple_exp(e, EnumType(f"{first_unit}{chain_elements[0]}"))
        elif first_unit.name in ("msg", "block", "tx"):
            # Solidity's built-in variables - no need to declare them or anything, only need to access them via the env variable.
            if not single_elem:
                raise CVLTranslationError(
                    f"{first_unit} has no field specified", suggestion=f"Use {first_unit}.<fieldname>"
                )
            if not isinstance(single_elem, DotAccessType):
                raise CVLTranslationError(
                    f"Only dot access makes sense for {first_unit}", suggestion=f"Use {first_unit}.<fieldname>"
                )
            access_str = f"e.{first_unit}{single_elem}"
            match (first_unit.name, str(single_elem.access)):
                case (var, field) if (var, field) in (("msg", "sender"), ("tx", "origin"), ("block", "coinbase")):
                    ty = ADDRESS_TYPE
                case (var, field) if (var, field) in (
                    ("msg", "value"),
                    ("tx", "origin"),
                    ("block", "basefee"),
                    ("block", "blobbasefee"),
                    ("block", "difficulty"),
                    ("block", "gaslimit"),
                    ("block", "number"),
                    ("block", "timestamp"),
                ):
                    ty = SimpleType("uint256")
                case ("msg", "sig"):
                    if not self.func_name:
                        raise CVLTranslationError("Cannot access msg.sig in invariants")
                    else:
                        access_str = f"to_bytes4(0x{self.selector})"
                    ty = SimpleType("bytes4")
                case _:
                    raise CVLTranslationError(f"{first_unit}{single_elem} cannot be accessed in CVL")
            return ExpInfo.simple_exp(access_str, ty)
        elif isinstance(single_elem, DotAccessType) and single_elem.access == "selector":
            # funcName.selector
            f_abi = next(
                (
                    self.abi_info[self.contract][sig]
                    for sig in self.abi_info[self.contract]
                    if sig.startswith(f"{first_unit}(")
                ),
                None,
            )
            if f_abi:
                signature = f"{f_abi.name}({','.join(input.type.type_str for input in f_abi.inputs)})"
                return ExpInfo.simple_exp(f"sig:{signature}.selector", SimpleType("uint32"))
            else:
                raise CVLTranslationError(f"Couldn't find a full signature for {first_unit}")
        elif first_unit.name == "revert":
            self.revert_rule = True
            return ExpInfo.simple_exp(self.revert_var_name, ty=BOOL_TYPE)
        else:
            if not first_unit.type and not chain_elements:
                if first_unit.name not in self.free_vars and self._is_free_var(first_unit.name):
                    self.free_vars[first_unit.name] = None
                return first_unit
            if not first_unit.type:
                raise CVLTranslationError(f"Couldn't infer type of {first_unit}")
            output_type = first_unit.type
            parts = list(first_unit.parts)

        for i, elem in enumerate(chain_elements):
            match elem:
                case DotAccessType():
                    dot_access = elem.access

                    if isinstance(dot_access, FunctionCall):
                        assert isinstance(elem, DotAccessType), (
                            f"unexpected FunctionCall {dot_access} in non-dot-access"
                        )
                        if not isinstance(output_type, ContractType):
                            raise CVLTranslationError(
                                f"Cannot perform a function call on type {output_type}",
                                suggestion="If the type is an `address`, cast it to the required contract type",
                            )
                        assignment, output_type = handle_function_call(dot_access, output_type.contract)
                        parts += ["."] + list(assignment)
                        continue

                    match output_type:
                        case ArrayType() if dot_access == "length":
                            output_type = SimpleType("uint256")
                            parts += elem.to_assignment()
                        case SimpleType(type_str=type_str) if (
                            type_str in ("bytes", "string") and dot_access == "length"
                        ):
                            if first_unit.name in self.storage_layout_info.get(self.contract, {}) and not any(
                                isinstance(e, DotAccessType) and isinstance(e.access, FunctionCall)
                                for e in chain_elements[:i]
                            ):
                                # Attempting to access the length of a storage array. This is unsupported by CVL
                                raise CVLTranslationError(f"CVL doesn't support accessing length of storage {type_str}")
                            output_type = SimpleType("uint256")
                            parts += elem.to_assignment()
                        case StructType(type_str=type_str, _members=_members):
                            members = dict(_members)
                            if dot_access not in members:
                                raise CVLTranslationError(f"Struct {type_str} has no field '{dot_access}'")
                            output_type = members[dot_access]
                            parts += elem.to_assignment()
                        case SimpleType(type_str=type_str) | ContractType(type_str=type_str) if (
                            type_str == "address" and dot_access == "balance"
                        ):
                            output_type = SimpleType("uint256")
                            parts = ["nativeBalances["] + parts + ["]"]
                            if not modifier and self.func_name:
                                raise CVLTranslationError(
                                    "`balance` must have timing annotation",
                                    suggestion="Add `@before` or `@after` to the balance access",
                                )
                        case _:
                            raise CVLTranslationError(f"got a dot access on non-struct-type {output_type}")
                case IndexedAccessType():
                    indexed_access = elem.access
                    if modifier == "before" and indexed_access.modifier == "after":
                        raise CVLTranslationError(
                            f"Cannot have an `@after` access {indexed_access} within `@before` context {first_unit}"
                        )

                    curr_index_type = indexed_access.type

                    if indexed_access.name in (t.type_str for t in SIMPLE_TYPES):
                        raise CVLTranslationError(f"Cannot use {indexed_access} as a variable name for indexed access")

                    match output_type:
                        case ArrayType(base=base):
                            if curr_index_type:
                                if curr_index_type == MATHINT:
                                    indexed_access = replace(
                                        indexed_access,
                                        parts=("assert_uint256(",) + indexed_access.parts + (")",),
                                        type=SimpleType("uint256"),
                                    )
                                    elem = replace(
                                        elem,
                                        access=indexed_access,
                                    )
                                elif curr_index_type not in UINT_TYPES + [NUMBER_LITERAL]:
                                    raise CVLTranslationError(
                                        f"Unexpected index {indexed_access} of type {curr_index_type} for array access"
                                    )
                            output_type = base
                            index_type: SolidityType = SimpleType("uint256")
                        case SimpleType(type_str="bytes"):
                            if first_unit.name in self.storage_layout_info.get(self.contract, {}) and not any(
                                isinstance(e, DotAccessType) and isinstance(e.access, FunctionCall)
                                for e in chain_elements[:i]
                            ):
                                # This is an indexed access to a storage bytes/string. CVL doesn't support that
                                raise CVLTranslationError(
                                    f"CVL doesn't support indexing operations on storage {output_type.type_str}"
                                )
                            if curr_index_type:
                                if curr_index_type.type_str == "mathint":
                                    indexed_access = replace(
                                        indexed_access,
                                        parts=("assert_uint256(",) + indexed_access.parts + (")",),
                                        type=SimpleType("uint256"),
                                    )
                                    elem = replace(
                                        elem,
                                        access=indexed_access,
                                    )
                                elif curr_index_type not in UINT_TYPES + [NUMBER_LITERAL]:
                                    raise CVLTranslationError(
                                        f"Unexpected index {indexed_access} of type {curr_index_type} for bytes access"
                                    )
                            output_type = SimpleType("bytes1")
                            index_type = SimpleType("uint256")
                        case MappingType(key=key, value=value):
                            if (
                                curr_index_type
                                and curr_index_type.type_str != key.type_str
                                and not (curr_index_type == NUMBER_LITERAL and key in SIMPLE_TYPES)
                            ):
                                raise CVLTranslationError(
                                    f"{indexed_access} has conflicting types {curr_index_type} and {key}"
                                )

                            # Special case - number literal keys for bytes-typed access
                            if curr_index_type == NUMBER_LITERAL and key in BYTES_TYPES:
                                self._check_number_literal_within_range(indexed_access, key)
                                indexed_access = replace(
                                    indexed_access,
                                    parts=(f"to_{key}(",) + indexed_access.parts + (")",),
                                    type=key,
                                )
                                elem = replace(
                                    elem,
                                    access=indexed_access,
                                )
                            output_type = value
                            index_type = key
                        case _:
                            raise CVLTranslationError(f"got indexed access for non-array or mapping type {output_type}")

                    if not curr_index_type:
                        # We didn't know the type of the index, but now we had inferred it so update the relevant constructs
                        if self._is_free_var(indexed_access.name):
                            self.free_vars[indexed_access.name] = index_type

                        indexed_access = replace(indexed_access, type=index_type)
                        elem = replace(elem, access=indexed_access)

                    parts += elem.to_assignment()

                    if str(indexed_access) in self.after_vars:
                        if modifier == "before":
                            raise CVLTranslationError("Cannot use {index} in a 'before' context")
                        modifier = "after"

                case _:  # pragma: no cover
                    assert False, f"Unexpected type of elem {type(elem)}"

        ret = ExpInfo(type=output_type, parts=tuple(parts), modifier=modifier)
        if str(parts[0]) not in self.free_vars:
            if isinstance(output_type, ArrayType):
                raise CVLTranslationError(
                    f"Cannot assign {''.join(str(a) for a in parts)} to {ret.name}: cannot assign to array typed variables"
                )
            if isinstance(output_type, StructType):
                raise CVLTranslationError(
                    f"Cannot assign {''.join(str(a) for a in parts)} to {ret.name}: cannot assign to struct typed variables"
                )
            if isinstance(output_type, SimpleType) and output_type.type_str == "string":
                raise CVLTranslationError(
                    f"Cannot assign {''.join(str(a) for a in parts)} to {ret.name}: cannot assign dynamic strings to string typed variables"
                )

        return ret

    @v_args(inline=True)
    def chained_access_and_indexing(
        self,
        first_unit: ExpInfo | FunctionCall,
        *chain_elements: AccessType | Literal["before", "after"],
    ) -> ExpInfo:
        modifier = None
        for i, elem in enumerate(chain_elements):
            if elem in ("before", "after"):
                modifier = cast(Literal["before", "after"], elem)
                chain_elements = chain_elements[:i] + chain_elements[i + 1 :]
                break
        return self._access_chain_and_modifier(first_unit, modifier, cast(tuple[AccessType, ...], chain_elements))

    # We don't need v_args(inline=True) here, as we want to return a Tree for complex_access_chain
    # But if we did inline, we'd return a tuple like ("dot", member_name_str)
    # For now, let the default Tree transformation happen, and complex_access_chain will inspect tree.data
    @v_args(inline=True)
    def dot_function_suffix(self, dot, child):
        # children will be [Token('.', '.'), Token('IDENTIFIER', 'field')]
        # We don't need to do much here, just let it form a Tree with data='dot_access_suffix'
        # and children=[member_name_token] (the dot token will be discarded by default in `children` of Tree)
        return DotAccessType(child)

    @v_args(inline=True)
    def dot_identifier_suffix(self, dot, child):
        # children will be [Token('.', '.'), Token('IDENTIFIER', 'field')]
        # We don't need to do much here, just let it form a Tree with data='dot_access_suffix'
        # and children=[member_name_token] (the dot token will be discarded by default in `children` of Tree)
        return DotAccessType(str(child))

    # Same as above, let it form a Tree.
    @v_args(inline=True)
    def indexed_access_suffix(self, lsqb, child, rsqb):
        return IndexedAccessType(child)

    @v_args(inline=True)
    def function_call(self, func_name_token, args=list()):
        return FunctionCall(
            str(func_name_token),
            args,
        )  # return the name and args separately, so _access_chain_and_modifier can use the info

    @v_args(inline=True)
    def arguments(self, *args):
        return list(args)

    # --- Methods to reconstruct the expression (recursive string building) ---
    @v_args(inline=True)
    def not_expression(self, negation, operand: ExpInfo):
        # We need to consider operator precedence and add parentheses if the operand
        # is a complex expression involving lower-precedence operators (e.g., `!(a && b)` vs `!a && b`).
        # Since this rule is above binary operators, adding parentheses around the operand
        # is a safe default to ensure correct evaluation in the output.
        # This will result in `!(expr)` rather than `!expr` for simple cases, which is harmless.
        return ExpInfo(parts=("!(", operand, ")"), type=BOOL_TYPE)

    @v_args(inline=True)
    def bitwise_not_expression(self, negation, operand: ExpInfo):
        return ExpInfo(parts=("~(", operand, ")"), type=operand.type)

    @v_args(inline=True)
    def minus_expression(self, uminus, operand: ExpInfo):
        return ExpInfo(parts=("-(", operand, ")"), type=MATHINT)

    @v_args(inline=True)
    def comparison_expression(self, left: ExpInfo, op=None, right: ExpInfo | None = None):
        if not op or not right:
            return left
        return ExpInfo(parts=("(", left, f" {op} ", right, ")"), type=BOOL_TYPE)

    def binary_expression(
        self,
        args: tuple[ExpInfo | Token, ...],
        output_type: SolidityType,
        add_parens: bool = False,
    ) -> ExpInfo:
        first = cast(ExpInfo, args[0])
        assignment: tuple[str | ExpInfo, ...] = (first,)
        for i in range(1, len(args), 2):
            op = str(args[i])
            right = cast(ExpInfo, args[i + 1])
            assignment = assignment + (f" {op} ", right)
        return ExpInfo(parts=assignment, needs_parens=add_parens, type=output_type)

    @v_args(inline=True)
    def sum_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, MATHINT)

    @v_args(inline=True)
    def prod_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, MATHINT)

    @v_args(inline=True)
    def exp_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, MATHINT)

    @v_args(inline=True)
    def implies_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, BOOL_TYPE, add_parens=True)

    @v_args(inline=True)
    def iff_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, BOOL_TYPE, add_parens=True)

    @v_args(inline=True)
    def and_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, BOOL_TYPE, add_parens=True)

    @v_args(inline=True)
    def or_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, BOOL_TYPE, add_parens=True)

    @v_args(inline=True)
    def bitwise_and_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, args[0].type, add_parens=True)

    @v_args(inline=True)
    def bitwise_or_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, args[0].type, add_parens=True)

    @v_args(inline=True)
    def shift_expression(self, *args):
        if len(args) == 1:
            return args[0]
        return self.binary_expression(args, args[0].type, add_parens=True)

    @v_args(inline=True)
    def ternary_expression(self, condition, true_expr: ExpInfo | None, false_expr: ExpInfo | None):
        if true_expr is None or false_expr is None:
            return condition  # No ternary part, just return the condition

        return ExpInfo(
            parts=("(", condition, " ? ", true_expr, " : ", false_expr, ")"),
            type=true_expr.type if true_expr.type != NUMBER_LITERAL else false_expr.type,
        )

    # --- CVL Rule Assembly ---

    def _typecheck(self, exp: ExpInfo) -> ExpInfoTyped:
        # First typecheck the parts
        new_parts: list[str | ExpInfoTyped] = []
        for i, p in enumerate(exp.parts):
            if isinstance(p, str):
                new_parts.append(p)
            if isinstance(p, ExpInfo):
                new_parts.append(self._typecheck(p))

        # Merge all adjacent string elements
        merged_parts: list[str | ExpInfoTyped] = []
        current_string = ""

        for p in new_parts:
            if isinstance(p, str):
                current_string += p
            else:
                if current_string:
                    merged_parts.append(current_string)
                    current_string = ""
                merged_parts.append(p)

        # Don't forget the last string if the list ends with strings
        if current_string:
            merged_parts.append(current_string)

        new_parts = merged_parts

        if exp.name in self.free_vars:
            ty = self.free_vars[exp.name]
            assert ty, "This should have been checked already"
            assert len(exp.parts) == 1 and isinstance(exp.parts[0], str), f"non-simple free var {exp}??"
            return ExpInfoTyped.from_exp_info(exp=exp, ty=ty, parts=(exp.parts[0],))

        def part(i: int) -> str | ExpInfoTyped:
            return new_parts[i]

        def get_operand(i: int) -> ExpInfoTyped:
            operand = part(i)
            assert isinstance(operand, ExpInfoTyped), f"unexpected {type(operand)} operand {operand} ({i})"
            return operand

        exp_type: SolidityType | None = exp.type
        needs_cast = False

        def set_exp_type(ty: SolidityType):
            nonlocal exp_type
            if exp_type in INT_TYPES + UINT_TYPES and ty == MATHINT:
                # Let's guess that we can do this cast and things will be fine
                nonlocal needs_cast
                needs_cast = True
                return
            assert not exp_type or exp_type == ty, f"Trying to overwrite the expression type from {exp_type} to {ty}"
            exp_type = ty

        for i in range(len(new_parts)):
            operator = part(i)
            if not isinstance(operator, str):
                continue
            operator = operator.strip()
            match operator:
                case "!(":
                    operand = get_operand(i + 1)
                    if operand.type != BOOL_TYPE:
                        raise CVLTranslationError(
                            f"Logical not cannot be applied to `{operand}` of type {operand.type}",
                            suggestion="logical not only works for bool",
                        )
                    set_exp_type(BOOL_TYPE)

                case "~(":
                    operand = get_operand(i + 1)
                    if operand.type not in BYTES_TYPES + UINT_TYPES + INT_TYPES + [NUMBER_LITERAL]:
                        raise CVLTranslationError(
                            f"bitwise not cannot be applied to `{operand}` of type {operand.type}",
                            suggestion="bitwise and can only be applied to bytesK, intN, uintN, and number literals. Use casting if needed",
                        )
                    set_exp_type(operand.type)

                case "-(":
                    operand = get_operand(i + 1)
                    if operand.type not in INTEGER_TYPES:
                        raise CVLTranslationError(
                            f"unary minus not cannot be applied to `{operand}` of type {operand.type}",
                            suggestion="unary minus can only be applied to intN, uintN, and number literals. Use casting if needed",
                        )
                    set_exp_type(MATHINT)

                case "==" | "!=" | "<" | ">" | "<=" | ">=":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)
                    assert left.type and right.type, f"{left} and {right} should have a type by now"

                    # Unwrap UDVTS - they're interchangeable with their alias in CVL
                    if left.type.type_str in self.udvts:
                        left = replace(left, type=SimpleType(self.udvts[left.type.type_str]))
                    if right.type.type_str in self.udvts:
                        right = replace(right, type=SimpleType(self.udvts[right.type.type_str]))

                    allowed_types = SIMPLE_TYPES
                    if operator in ("<", ">", "<=", ">="):
                        if left.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"{left} has type {left.type}, can't perform arithmetic comparisons on it"
                            )
                        if right.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"{right} has type {right.type}, can't perform arithmetic comparisons on it"
                            )
                        allowed_types = INTEGER_TYPES

                    if left.type not in allowed_types and not isinstance(left.type, (EnumType, StructType)):
                        raise CVLTranslationError(
                            f"comparison '{operator}' cannot be applied to {left} of type {left.type}"
                        )
                    if right.type not in allowed_types and not isinstance(right.type, (EnumType, StructType)):
                        raise CVLTranslationError(
                            f"comparison '{operator}' cannot be applied to {right} of type {right.type}"
                        )

                    if isinstance(left.type, EnumType) and isinstance(right.type, EnumType):
                        if right.type.type_str != left.type.type_str:
                            raise CVLTranslationError(
                                f"Cannot compare different enums {right.type} and {left.type}",
                                suggestion="You can cast them to a uint8 before comparing",
                            )
                    elif isinstance(left.type, EnumType):
                        if right.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"CAnnot compare enum {left.type} with non-integer type {right.type}"
                            )
                        left = replace(
                            left,
                            parts=("assert_uint8(",) + left.parts + (")",),
                            type=SimpleType("uint8"),
                        )
                        new_parts[i - 1] = left
                    elif isinstance(right.type, EnumType):
                        if left.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"CAnnot compare enum {right.type} with non-integer type {left.type}"
                            )
                        right = replace(
                            right,
                            parts=("assert_uint8(",) + left.parts + (")",),
                            type=SimpleType("uint8"),
                        )
                        new_parts[i + 1] = right
                    elif ((bytes_k := _find_index(BYTES_TYPES, right.type)) >= 0) and (
                        left.type == NUMBER_LITERAL
                        or ((uint_n := _find_index(UINT_TYPES, left.type)) >= 0 and bytes_k == uint_n)
                    ):
                        if left.type == NUMBER_LITERAL:
                            self._check_number_literal_within_range(left, right.type)
                        left = replace(
                            left,
                            parts=(f"to_bytes{bytes_k + 1}(",) + left.parts + (")",),
                            type=BYTES_TYPES[bytes_k],
                        )
                        new_parts[i - 1] = left
                    elif ((bytes_k := _find_index(BYTES_TYPES, left.type)) >= 0) and (
                        right.type == NUMBER_LITERAL
                        or ((uint_n := _find_index(UINT_TYPES, right.type)) >= 0 and bytes_k == uint_n)
                    ):
                        if right.type == NUMBER_LITERAL:
                            self._check_number_literal_within_range(right, left.type)
                        right = replace(
                            right,
                            parts=(f"to_bytes{bytes_k + 1}(",) + right.parts + (")",),
                            type=BYTES_TYPES[bytes_k],
                        )
                        new_parts[i + 1] = right
                    elif (
                        not (left.type in INTEGER_TYPES and right.type in INTEGER_TYPES)
                        and not (left.type.type_str == "address" and right.type.type_str == "address")
                        and not (left.type.type_str == "address" and right.type == NUMBER_LITERAL)
                        and not (left.type == NUMBER_LITERAL and right.type.type_str == "address")
                        and left.type != right.type
                    ):
                        raise CVLTranslationError(
                            f"Cannot compare {left} of type {left.type} with {right} of type {right.type}"
                        )

                    if left.type == NUMBER_LITERAL:
                        self._check_number_literal_within_range(left, right.type)
                    if right.type == NUMBER_LITERAL:
                        self._check_number_literal_within_range(right, left.type)
                    set_exp_type(BOOL_TYPE)

                case "<=>" | "=>" | "||" | "&&":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)
                    if left.type != BOOL_TYPE:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{left}` of type {left.type}")
                    if right.type != BOOL_TYPE:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{right}` of type {right.type}")
                    set_exp_type(BOOL_TYPE)

                case "+" | "-" | "*" | "/" | "%" | "^":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)

                    # Unwrap UDVTS - they're interchangeable with their alias in CVL
                    if left.type.type_str in self.udvts:
                        left = replace(left, type=SimpleType(self.udvts[left.type.type_str]))
                    if right.type.type_str in self.udvts:
                        right = replace(right, type=SimpleType(self.udvts[right.type.type_str]))

                    # Cast enums to uint8 for arithmetic
                    if isinstance(left.type, EnumType):
                        left = replace(
                            left,
                            parts=("assert_uint8(",) + left.parts + (")",),
                            type=SimpleType("uint8"),
                        )
                        new_parts[i - 1] = left
                    if isinstance(right.type, EnumType):
                        right = replace(
                            right,
                            parts=("assert_uint8(",) + left.parts + (")",),
                            type=SimpleType("uint8"),
                        )
                        new_parts[i + 1] = right

                    if left.type not in INTEGER_TYPES:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{left}` of type {left.type}")
                    if right.type not in INTEGER_TYPES:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{right}` of type {right.type}")
                    set_exp_type(MATHINT)

                case "|" | "&":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)
                    valid_types = INTEGER_TYPES + BYTES_TYPES
                    valid_types.remove(MATHINT)
                    if left.type not in valid_types:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{left}` of type {left.type}")
                    if right.type not in valid_types:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{right}` of type {right.type}")

                    # We're being more strict here than CVL is. In CVL you could use bitwise operations on types that have some
                    # common super-type, but here we'll just enforce same type on both sides (with the exception of number literals)
                    if left.type == NUMBER_LITERAL and (bytes_k := _find_index(BYTES_TYPES, right.type) + 1) > 0:
                        self._check_number_literal_within_range(left, right.type)
                        left = replace(
                            left,
                            parts=(f"to_bytes{bytes_k}(",) + left.parts + (")",),
                            type=right.type,
                        )
                        new_parts[i - 1] = left
                    elif right.type == NUMBER_LITERAL and (bytes_k := _find_index(BYTES_TYPES, left.type) + 1) > 0:
                        self._check_number_literal_within_range(right, left.type)
                        right = replace(
                            right,
                            parts=(f"to_bytes{bytes_k}(",) + right.parts + (")",),
                            type=left.type,
                        )
                        new_parts[i + 1] = right
                    elif left.type != right.type:
                        raise CVLTranslationError(
                            f"Cannot perform `{operator}` on different-typed operands `{left}` of type {left.type} with `{right}` of type {right.type}"
                        )
                    set_exp_type(left.type)  # same as right.type

                case "<<" | ">>":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)
                    valid_types = INTEGER_TYPES + BYTES_TYPES
                    valid_types.remove(MATHINT)
                    if left.type not in valid_types:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{left}` of type {left.type}")
                    if right.type not in UINT_TYPES + [NUMBER_LITERAL, MATHINT]:
                        raise CVLTranslationError(f"Cannot perform `{operator}` on `{right}` of type {right.type}")
                    if right.type == MATHINT:
                        right = replace(
                            right,
                            parts=("assert_uint256(",) + right.parts + (")",),
                            type=SimpleType("uint256"),
                        )
                        new_parts[i + 1] = right
                    if right.type == NUMBER_LITERAL:
                        self._check_number_literal_within_range(right, SimpleType("uint256"))
                    set_exp_type(left.type)

                case "?":
                    condition = get_operand(i - 1)
                    if condition.type != BOOL_TYPE:
                        raise CVLTranslationError(
                            f"condition `{condition}` of ternary expression must be of type bool, got {condition.type}"
                        )

                case ":":
                    left = get_operand(i - 1)
                    right = get_operand(i + 1)

                    if left.type == right.type:
                        set_exp_type(left.type)
                    elif left.type == NUMBER_LITERAL:
                        self._check_number_literal_within_range(left, right.type)
                        if right.type in BYTES_TYPES:
                            left = replace(
                                left,
                                parts=(f"to_{right.type}(",) + left.parts + (")",),
                                type=right.type,
                            )
                            new_parts[i - 1] = left
                        elif right.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"ternary expressions must have same type on true and false branches. For `{left} : {right}` got a number literal and {right.type}"
                            )
                        set_exp_type(right.type)
                    elif right.type == NUMBER_LITERAL:
                        self._check_number_literal_within_range(right, left.type)
                        if left.type in BYTES_TYPES:
                            right = replace(
                                right,
                                parts=(f"to_{left.type}(",) + right.parts + (")",),
                                type=left.type,
                            )
                            new_parts[i - 1] = left
                        elif left.type not in INTEGER_TYPES:
                            raise CVLTranslationError(
                                f"ternary expressions must have same type on true and false branches. For `{left} : {right}` got a {left.type} and number literal"
                            )
                        set_exp_type(left.type)
                    else:
                        raise CVLTranslationError(
                            f"ternary expressions must have same type on true and false branches. For `{left} : {right}` got {left.type} and {right.type}"
                        )

                case _:
                    continue

        assert exp_type, f"Failed to type `{exp}`"

        if needs_cast:
            new_parts = [f"assert_{exp_type}("] + new_parts + [")"]
        return ExpInfoTyped.from_exp_info(exp=exp, ty=exp_type, parts=tuple(new_parts))

    def _partition_definable_variables(
        self, graph: ExpInfo, visited: set[ExpInfo] | None = None
    ) -> tuple[list[ExpInfo], list[ExpInfo]]:
        if visited is None:
            visited = set()

        assert graph not in visited, "this should be a tree"

        # Mark as visited first
        visited.add(graph)

        define_before = []
        define_after = []

        # Recursively visit all unvisited neighbors FIRST
        for neighbor in [exp for exp in graph.parts if isinstance(exp, ExpInfo)]:
            if neighbor not in visited:
                b, a = self._partition_definable_variables(neighbor, visited)
                define_before += b
                define_after += a

        # Perform operation AFTER visiting all children
        action = self._declare_var(graph)
        match action:
            case "before":
                define_before.append(graph)
            case "after":
                define_after.append(graph)
            case None:
                pass
        return define_before, define_after

    def _declare_var(self, exp: ExpInfo) -> Literal["before", "after"] | None:
        if not exp.type:
            assert not self._is_free_var(exp.name) or exp.name in self.free_vars, (
                f"{exp} has no type but isn't a free var"
            )
            return None

        if exp.name in self.free_vars:
            return None

        return exp.modifier

    def _generate_cvl_rule(self, assert_expression: ExpInfo) -> str:
        lines = []
        rule_params = "env e"
        lines.append(f"rule {self.rule_name}({rule_params}")
        if not self.func_name:
            lines[-1] += ", calldataarg args, method f) filtered { f -> f.contract == currentContract && !f.isView } {"
        else:
            lines[-1] += ") {"

        define_before, define_after = self._partition_definable_variables(assert_expression)
        for name, ty in self.free_vars.items():
            lines.append(f"    {ty} {name};")
        lines.append("")

        lines.append("    // assign all the 'before' variables")
        for exp in define_before:
            lines.append(f"    {exp.type} {exp.name} = {exp};")
        lines.append("")

        # Add assumption expressions if provided
        # Exclude assumption with undeclared free vars or that fail typechecking
        assumptions: list[RequireStatement] = []
        for assumption in self.assumption_expressions:
            if not all(v in self.free_vars for v in assumption.free_vars.keys()):
                continue
            try:
                assumptions.append(replace(assumption, expression=self._typecheck(assumption.expression)))
            except CVLTranslationError:
                continue

        if assumptions:
            lines.append("    // assumptions to prevent false positives")
            for assumption in assumptions:
                lines.append(f'    require {assumption.expression}, "{assumption.description}";')
            lines.append("")

        # 3. Declare and call the function under test
        lines.append("    // call function under test")
        if self.func_name:
            in_names = [input.name if input.name else "_" for input in self.inputs]
            inputs = ", ".join(["e"] + list(in_names))
            out_names = [output.name if output.name else "_" for output in self.outputs]
            num_outs = len(self.outputs)
            if num_outs == 0:
                ret_vars = ""
            elif num_outs == 1:
                ret_vars = f"{out_names[0]} = "
            else:
                ret_vars = f"({', '.join(out_names)}) = "
            if not self.revert_rule:
                lines.append(f"    {ret_vars}{self.func_name}({inputs});")
            else:
                lines.append(f"    {ret_vars}{self.func_name}@withrevert({inputs});")
                lines.append(f"    bool {self.revert_var_name} = lastReverted;")
        else:
            if not self.revert_rule:
                lines.append("    f(e, args);")
            else:
                lines.append("    f@withrevert(e, args);")
                lines.append("    bool f_reverted = lastReverted;")
        lines.append("")

        lines.append("    // assign all the 'after' variables")
        for exp in define_after:
            lines.append(f"    {exp.type} {exp.name} = {exp};")
        lines.append("")

        # 6. Generate assert statement
        lines.append("    // verify integrity")
        lines.append(f'    assert {assert_expression.name}, "{self.property}";')

        lines.append("}")
        return "\n".join(lines)

    def _generate_cvl_invariant(self, assert_expression: ExpInfo) -> str:
        lines = []
        invariant_params = ", ".join(["env e"] + [f"{ty} {name}" for name, ty in self.free_vars.items() if ty])
        lines.append(f"invariant {self.rule_name}({invariant_params})")
        lines.append(f"    {assert_expression}")
        lines.append("    filtered { f -> f.contract == currentContract }")
        return "\n".join(lines)


def sanitize(s: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in s)


def get_rule_name(method_name: str | None, selector: str | None, property_name: str) -> str:
    ret = ""
    if method_name:
        ret += f"{method_name}_"
    if selector:
        ret += f"{selector}_"
    ret += sanitize(property_name)
    return ret


def generate_cvl_rule(
    parser: Lark,
    contract_name: str,
    method: str | None,
    selector: str | None,
    rule_name: str,
    property: str,
    analyze: PropertyExplanation | None,
    solc_info: SolcInfo,
    assumption_expressions: list[AssumptionExpression],
    error_suggestions: bool = False,
) -> tuple[str | None, str | None, set[str]]:
    def generate_comment() -> str:
        comment = f"/*\n * {property}\n"
        if analyze:
            comment += f" *\n * What it means: {analyze.what_it_means}\n"
            comment += f" *\n * Why it should hold: {analyze.why_it_should_hold}\n"
            comment += f" *\n * Possible consequences: {analyze.possible_consequences}\n"

        comment += " */\n"
        return comment

    try:
        tree = parser.parse(property)
    except Exception as e:
        newline = "\n"
        msg = f"Error parsing {'' if method else 'contract '}property '{rule_name}': '{property}': {str(e).replace(newline, '')}"
        return None, msg, set()
    try:
        translated_assumptions = translate_assumptions_for_rule(
            assumption_expressions, parser, contract_name, solc_info
        )

        generator = CVLRuleGenerator(
            rule_name, property, contract_name, method, selector, solc_info, translated_assumptions
        )
        cvl_rule = generator.generate_rule_or_invariant(tree)
    except Exception as e:
        if isinstance(e, VisitError):
            e = e.orig_exc
        if isinstance(e, CVLTranslationError) and error_suggestions:
            error_message = e.with_suggestion()
        else:
            error_message = str(e)
        msg = f"Error translating {'' if method else 'contract '}property '{rule_name}': '{property}' to CVL: {error_message}"
        return None, msg, set()

    cvl_rule = f"{generate_comment()}{cvl_rule}"
    return cvl_rule, None, generator.using_contracts


def compute_sighash(abi_signature: str) -> str:
    keccak_hash = keccak.new(digest_bits=256)
    keccak_hash.update(abi_signature.strip().encode("utf-8"))

    # Take first 4 bytes and convert to hex with 0x prefix
    return keccak_hash.hexdigest()[:8]


def replace_udvts_with_elementry_types(
    udvts: dict[str, str], storage_layout_info: dict[str, dict[str, StorageLayoutInfo]]
) -> dict[str, dict[str, StorageLayoutInfo]]:
    ret: dict[str, dict[str, StorageLayoutInfo]] = {}

    def recursive(ty: SolidityType) -> SolidityType:
        if isinstance(ty, SimpleType) and ty not in SIMPLE_TYPES:
            # This is a UDVT
            udvt = ty.type_str
            if udvt in udvts:
                return SimpleType(udvts[udvt])

            udvt = udvt.split(".")[1]
            if udvt in udvts:
                return SimpleType(udvts[udvt])

            raise CVLTranslationError(f"Cant' find udvt {udvt}")
        elif isinstance(ty, ArrayType):
            new_base = recursive(ty.base)
            type_str = new_base.type_str + ty.type_str[ty.type_str.find("[") :]
            return ArrayType(type_str, new_base)
        elif isinstance(ty, MappingType):
            new_key = recursive(ty.key)
            new_val = recursive(ty.value)
            type_str = f"mapping({new_key} => {new_val})"
            return MappingType(type_str, key=new_key, value=new_val)
        elif isinstance(ty, StructType):
            new_members = {field: recursive(ty) for field, ty in ty.members.items()}
            return StructType.struct(ty.type_str, new_members)
        return ty

    for contract, layout_info in storage_layout_info.items():
        ret[contract] = {var: replace(info, type=recursive(info.type)) for var, info in layout_info.items()}

    return ret


def translate_assumptions_for_rule(
    assumptions: list[AssumptionExpression], lark_parser: Lark, contract: str, solc_info: SolcInfo
) -> list[RequireStatement]:
    """
    Translate assumption expressions to CVL for a given rule using an existing parser.

    Args:
        assumptions: List of assumption dicts with 'expression' and 'description' keys
        lark_parser: Already instantiated Lark parser
        contract: The contract name
        solc_info: Solidity compilation info

    Returns:
        List of assumption expressions with translated expressions
    """
    translated_assumptions: list[RequireStatement] = []

    for assumption in assumptions:
        expression = assumption["expression"]
        description = assumption["description"]

        try:
            # Parse the assumption expression
            tree = lark_parser.parse(expression)

            # Create a minimal CVLRuleGenerator just for expression transformation
            generator = CVLRuleGenerator(
                rule_name="dummy_rule",
                property=expression,
                contract_name=contract,
                function_signature=None,
                selector=None,
                solc_info=solc_info,
                assumption_expressions=[],
            )

            # Transform just the expression part
            translated_expression = generator.generate_require(tree)

            translated_assumptions.append(
                RequireStatement(
                    expression=translated_expression, description=description, free_vars=generator.free_vars
                )
            )

        except Exception:
            pass

    return translated_assumptions


def merge_accumulated_assumptions(
    categorization_data: dict | None, accumulated_assumptions: list[AccumulatedAssumption] | None = None
) -> list[AccumulatedAssumption]:
    """
    Create a list of assumption/invariant objects based on categorization data.
    Combines new assumptions/invariants with previously accumulated ones to make them additive.

    [
        {
            "description": "category description",
            "assumption": "assumption expression if it's an assumption",
            "invariant": "invariant expression if it's an invariant",
            "rules": ["rule1", "rule2", ...]
        },
        ...
    ]

    Args:
        categorization_data: The output from violation_analyzer containing categorization results
        accumulated_assumptions: Previously accumulated assumptions/invariants

    Returns:
        List of accumulated assumption objects with their associated rules
    """
    if accumulated_assumptions is None:
        accumulated_assumptions = []

    # Start with existing accumulated assumptions
    merged_assumptions: list[AccumulatedAssumption] = accumulated_assumptions.copy()

    # Add new assumptions from current categorization
    if categorization_data:
        categorization = categorization_data.get("categorization", {})
        categories = categorization.get("categories", [])

        for category in categories:
            assumption_expr = category.get("assumption_expression", "")
            invariant_expr = category.get("invariant_expression", "")
            category_name = category.get("category_name", "Unknown Category")
            rule_names = category.get("rule_names", [])

            # Process blockchain state assumptions
            if assumption_expr and assumption_expr.strip():
                # Check if this assumption already exists
                existing_assumption = None
                for existing in merged_assumptions:
                    if "assumption" in existing and existing["assumption"] == assumption_expr:
                        existing_assumption = existing
                        break

                if existing_assumption:
                    # Add rules to existing assumption, avoiding duplicates
                    for rule_name in rule_names:
                        if rule_name not in existing_assumption["rules"]:
                            existing_assumption["rules"].append(rule_name)
                else:
                    # Create new assumption entry
                    merged_assumptions.append(
                        AccumulatedAssumptionType(
                            description=category_name,
                            assumption=assumption_expr,
                            rules=rule_names.copy(),
                        )
                    )

            # Process contract-specific invariants
            if invariant_expr and invariant_expr.strip():
                # Check if this invariant already exists
                existing_invariant = None
                for existing in merged_assumptions:
                    if "invariant" in existing and existing["invariant"] == invariant_expr:
                        existing_invariant = existing
                        break

                if existing_invariant:
                    # Add rules to existing invariant, avoiding duplicates
                    for rule_name in rule_names:
                        if rule_name not in existing_invariant["rules"]:
                            existing_invariant["rules"].append(rule_name)
                else:
                    # Create new invariant entry
                    merged_assumptions.append(
                        AccumulatedInvariantType(
                            description=category_name,
                            invariant=invariant_expr,
                            rules=rule_names.copy(),
                        )
                    )

    return merged_assumptions


def get_assumptions_for_rule(
    rule_name: str, assumptions: list[AccumulatedAssumption], global_assumptions: bool = False
) -> list[AssumptionExpression]:
    """
    Get all assumptions and invariants for a specific rule from the merged assumptions list.

    Args:
        rule_name: Name of the rule to get assumptions for
        assumptions: List of assumption/invariant objects with associated rules
        global_assumptions: If True, apply all assumptions to all rules regardless of mapping

    Returns:
        List of assumption expressions for the specified rule
    """
    rule_assumptions: list[AssumptionExpression] = []

    for assumption_obj in assumptions:
        description = assumption_obj["description"]
        rules = assumption_obj["rules"]

        # Apply assumption if it's mapped to this rule OR if global_assumptions is enabled
        if rule_name in rules or global_assumptions:
            # Check if this is an assumption type
            if "assumption" in assumption_obj:
                assumption_expr = assumption_obj["assumption"]
                rule_assumptions.append(AssumptionExpression(expression=assumption_expr, description=description))

            # Check if this is an invariant type
            if "invariant" in assumption_obj:
                invariant_expr = assumption_obj["invariant"]
                rule_assumptions.append(AssumptionExpression(expression=invariant_expr, description=description))

    return rule_assumptions


def save_accumulated_assumptions(merged_assumptions: list[AccumulatedAssumption], output_file: Path) -> None:
    """
    Save the merged accumulated assumptions to a file for the next iteration.

    Args:
        merged_assumptions: List of accumulated assumption objects
        output_file: Path to save the updated accumulated assumptions
    """
    with open(output_file, "w") as f:
        json.dump(merged_assumptions, f, indent=2)


def collect_rules(
    properties: tuple[KeyedProperties, PropertyAnalysis | None],
    solc_parser: SolcParser,
    contract: str,
    property: str | None = None,
    error_suggestions: bool = False,
    assumptions: list[AccumulatedAssumption] = list(),
    global_assumptions: bool = False,
) -> tuple[list[str], list[str], set[str]]:
    abi_info = solc_parser.parse_solc_abi()
    storage_layout_info = solc_parser.parse_solc_storage_layout()
    udvts = solc_parser.extract_udvt_mappings()

    # Storage layout info only mentions User-Defined-Value_types by their defined names, and doesn't mention
    # what elementary type they're aliasing. So use the ast to replace storage vars of UDVT type to the corresponding
    # elementary type. This is important e.g. if the udvt is an alias of a bytesK and the property compares it to a
    # constant - in this case we need to know the base type in order to know to wrap the constant with a `to_bytesK(constant)`
    storage_layout_info = replace_udvts_with_elementry_types(udvts, storage_layout_info)

    immutables_and_constants = solc_parser.parse_solc_ast_immutable_constants()
    enum_types = solc_parser.extract_enums_from_solc_output()

    solc_info = SolcInfo(
        abi_info=abi_info,
        storage_layout_info=storage_layout_info,
        immutables_and_constants=immutables_and_constants,
        enum_types=enum_types,
        udvts=udvts,
    )

    selector_to_abi = {compute_sighash(abi): abi for abi in abi_info[contract]}

    with open(Path(__file__).resolve().parent / "properties_grammar.lark") as f:
        grammar = f.read()

    lark_parser = Lark(grammar, parser="lalr")

    all_rules: list[str] = []
    error_rules: list[str] = []
    using_contracts: set[str] = set()
    keyed_properties, analysis = properties
    keys = keyed_properties.root.keys()
    for key in keys:
        for prop_name, prop in keyed_properties.root[key].items():
            if property and property != prop_name:
                continue
            if key == contract:
                method = None
                method_name = None
                selector = None
            else:
                try:
                    method_name, selector = key.split(":")
                except ValueError:
                    raise ValueError(f"Property key must be 'method_name:selector', got {key}")
                try:
                    method = selector_to_abi[selector]
                except KeyError:
                    raise KeyError(
                        f"Cannot find selector {selector} in the ABI:\n{json.dumps(selector_to_abi, indent=2)}"
                    )
                if (abi_name := method.split("(")[0]) != method_name:
                    raise KeyError(
                        f"method name mismatch between abi and key. name in key: {method_name}, name in abi: {abi_name}"
                    )

            analyze = analysis.root[key][prop_name] if analysis and key in analysis.root else None

            rule_name = get_rule_name(method_name, selector, prop_name)

            rule_assumptions_list = get_assumptions_for_rule(rule_name, assumptions, global_assumptions)

            cvl_rule, err, usings = generate_cvl_rule(
                lark_parser,
                contract,
                method,
                selector,
                rule_name,
                prop,
                analyze,
                solc_info,
                rule_assumptions_list,
                error_suggestions,
            )
            if err:
                error_rules.append(err)
                continue
            all_rules.append(cast(str, cvl_rule))
            using_contracts |= usings
    return all_rules, error_rules, using_contracts


def generate_spec(
    properties: tuple[KeyedProperties, PropertyAnalysis | None],
    solc_parser: SolcParser,
    contract: str,
    out: Path,
    cvl_imports: list[str],
    property: str | None,
    categorization_data: dict | None = None,
    accumulated_assumptions: list[AccumulatedAssumption] | None = None,
    save_accumulated_assumptions_to: Path | None = None,
    global_assumptions: bool = False,
) -> int:
    # Merge assumptions once at the beginning
    merged_assumptions = merge_accumulated_assumptions(categorization_data, accumulated_assumptions)

    rules, errors, using_contracts = collect_rules(
        properties,
        solc_parser,
        contract,
        property,
        assumptions=merged_assumptions,
        global_assumptions=global_assumptions,
    )
    print(f"Generated {len(rules)} rules")
    if rules:
        with open(out, "w") as f:
            f.write("".join(f'import "{imp}";\n' for imp in cvl_imports))
            f.write("\n")
            f.write("".join(f"using {c} as {c};\n" for c in using_contracts))
            f.write("\n")
            f.write("\n\n".join(rules))
    # Determine return code
    if errors:
        print(f"Failed to generate {len(errors)} rules:", file=sys.stderr)
        [print(f"\t\033[91m {err}\033[00m", file=sys.stderr) for err in errors]
        if rules:
            # Some rules were generated, so this is a partial success
            ret = 2
        else:
            ret = 1
    else:
        ret = 0

    # Save accumulated assumptions if successful and requested
    if ret != 1 and save_accumulated_assumptions_to and merged_assumptions:
        try:
            save_accumulated_assumptions(
                merged_assumptions=merged_assumptions, output_file=save_accumulated_assumptions_to
            )
            print(f"Saved accumulated assumptions to: {save_accumulated_assumptions_to}")
        except Exception as e:
            print(f"Warning: Failed to save accumulated assumptions: {e}")

    return ret


@dataclass
class PropertiesToCvlArgs:
    """Arguments for properties_to_cvl.py script."""

    contract_file: Path = field(default_factory=lambda: Path())
    contract: str = field(default="")
    solc: str = field(default="")
    remappings: list[str] = field(default_factory=list)
    via_ir: bool = field(default=False)
    out: Path = field(default_factory=lambda: Path())
    cvl_imports: list[str] = field(default_factory=list)
    properties_file: Path | None = field(default=None)
    properties_dir: Path = field(default_factory=lambda: Path())
    property: str | None = field(default=None)
    categorization_file: Path | None = field(default=None)
    accumulated_assumptions_file: Path | None = field(default=None)
    save_accumulated_assumptions_to: Path | None = field(default=None)
    global_assumptions: bool = field(default=False)


def run_properties_to_cvl(args: PropertiesToCvlArgs) -> int:
    """Run the properties to CVL conversion with the given arguments.

    Args:
        args: PropertiesToCvlArgs dataclass with all configuration

    Returns:
        Exit code (0=success, 1=failure, 2=partial success)
    """
    if not args.properties_file and args.properties_dir:
        args.properties_file = args.properties_dir / "properties.json"

    if not args.properties_file:
        print("Missing `--properties-file`")
        return 1

    with open(args.properties_file) as f:
        keyed_properties = KeyedProperties.model_validate_json(f.read())

    analysis_jsons = []
    if args.properties_dir:
        for k in keyed_properties.root.keys():
            f_name = args.properties_dir / f"{k.replace(':', '-')}-analysis.json"
            if f_name.exists():
                with open(f_name) as f:
                    analysis_jsons.append(json.load(f))
    analysis = PropertyAnalysis.model_validate({k: v for a in analysis_jsons for k, v in a.items()})

    # Load categorization data if provided
    categorization_data = None
    if args.categorization_file and args.categorization_file.exists():
        with open(args.categorization_file) as f:
            categorization_data = json.load(f)

    # Load accumulated assumptions if provided
    accumulated_assumptions = None
    if args.accumulated_assumptions_file and args.accumulated_assumptions_file.exists():
        with open(args.accumulated_assumptions_file) as f:
            accumulated_assumptions = json.load(f)

    solc_parser = SolcParser(args.contract_file, args.solc, args.remappings, args.via_ir)

    ret = generate_spec(
        properties=(keyed_properties, analysis),
        solc_parser=solc_parser,
        contract=args.contract,
        out=args.out,
        cvl_imports=args.cvl_imports,
        property=args.property,
        categorization_data=categorization_data,
        accumulated_assumptions=accumulated_assumptions,
        save_accumulated_assumptions_to=args.save_accumulated_assumptions_to,
        global_assumptions=args.global_assumptions,
    )

    return ret


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--properties-file", type=Path)
    parser.add_argument("--contract-file", type=Path, required=True)
    parser.add_argument("--contract", type=str, required=True)
    parser.add_argument("--solc", type=str, required=True)
    parser.add_argument("--remappings", type=str, nargs="+", default=list())
    parser.add_argument("--via-ir", action="store_true")
    parser.add_argument("--out", type=Path, default="nat.spec")
    parser.add_argument("--cvl-imports", type=str, nargs="+", default=list())
    parser.add_argument("--properties-dir", type=Path, default=find_newest_dir(AUTO_CVL_DIR))
    parser.add_argument("--property", type=str)
    parser.add_argument(
        "--categorization-file", type=Path, help="JSON file with violation categorization and assumptions"
    )
    parser.add_argument(
        "--accumulated-assumptions-file",
        type=Path,
        help="JSON file with accumulated assumptions from previous iterations",
    )
    parser.add_argument(
        "--save-accumulated-assumptions-to",
        type=Path,
        help="Path to save updated accumulated assumptions for next iteration",
    )
    parser.add_argument(
        "--global-assumptions",
        action="store_true",
        help="Apply all assumptions to all rules regardless of mapping",
    )

    # Parse args into our dataclass
    args = parser.parse_args(namespace=PropertiesToCvlArgs())

    ret = run_properties_to_cvl(args)

    exit(ret)
