#!/usr/bin/env python3
from pathlib import Path
import sys

# Add parent directory to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

import argparse
import asyncio
from dataclasses import dataclass, field
import json
import logging
from auto_cvl.auto_generator import (
    KeyedProperties,
    PropertyAnalysis,
    ValidationToolResponse,
    request_contract_properties,
    request_method_properties,
)
from auto_cvl.compactor import compact_solidity_code, filter_library_files
from auto_cvl.properties_to_cvl import collect_rules, get_new_auto_cvl_dir
from auto_cvl.solc_parsing import SolcParser
from auto_cvl.summarizer import Summarizer, create_summarizer
from token_usage_tracker import TokenUsageTracker
from typing import Awaitable, Callable

logger = logging.getLogger(__name__)


def write_analysis(log_dir: Path, prefix: str, analysis: PropertyAnalysis) -> None:
    with open(log_dir / f"{prefix}-analysis.json", "w") as f:
        f.write(analysis.model_dump_json(indent=2))
        f.write("\n")


def optimize_contract_tokens(
    contract: str, summarizer: Summarizer, exclude_libs: bool = False, compact: bool = False
) -> str:
    if summarizer.is_ready():
        # Note that in this case, we don't perform filtering libraries here
        # since it was already done during initialization of summarizer
        contract_code = summarizer.get_contract_for_properties()
    else:
        if exclude_libs:
            # Libraries are filtered here when summarizer is not ready.
            # When summarizer IS ready (the if-branch above), libraries were already
            # filtered during summarizer initialization (see summarizer:create_summarizer()).
            # TODO: Refactor to remove libraries before flattening, so they're never
            # included in the flattened contract at all.
            contract_code, _ = filter_library_files(contract)
        else:
            contract_code = contract

    # The compact is not done in initialization of summarizer since we want to provide
    # the summarizer with full code to get the best summaries.
    if compact:
        logger.info("Compacting contract code to reduce tokens...")
        contract_code, removed = compact_solidity_code(
            contract_code,
            remove_interfaces=True,
        )
        logger.info(
            f"Compaction removed {len(removed['interfaces'])} interfaces and {len(removed['libraries'])} libraries"
        )

    logger.info(f"Input contract size reduced from {len(contract)} to {len(contract_code)}")
    return contract_code


async def request_properties_per_function(
    solc_parser: SolcParser,
    contract_file_name: Path,
    contract_name: str,
    method_and_selector: tuple[str, str],
    storage_vars: dict[str, str],
    contract_devdoc: dict[str, str] | None,
    extra_text: str,
    semaphore: asyncio.Semaphore,
    log_dir: Path,
    validator: Callable[[KeyedProperties], Awaitable[ValidationToolResponse]] | None,
    token_tracker: TokenUsageTracker,
    summarizer: Summarizer,
    exclude_libs: bool = False,
    compact: bool = False,
) -> tuple[KeyedProperties, PropertyAnalysis] | None:
    method, selector = method_and_selector
    # TODO: If optimisations are used, particularly summarization, the body of functions are removed
    # later by optimize_contract_tokens(), therefore removing function here is redundant.
    # We should refactor code so that all summarised contracts are sent to LLM in the beginning
    # and we ask LLM here only for properties for the given method.
    removed_method_contract = solc_parser.remove_function_body_by_name_and_selector(contract_name, method, selector)
    if not removed_method_contract:
        logger.info(f"Skipping {method} - it isn't implemented directly in {contract_file_name}")
        return None

    # Optimize contract is called here since we don't have flattened code before
    contract_code = optimize_contract_tokens(removed_method_contract, summarizer, exclude_libs, compact)

    async with semaphore:
        properties, analysis = await request_method_properties(
            contract_code,
            method,
            selector,
            storage_vars,
            contract_devdoc,
            extra_text,
            validator,
            token_tracker,
            summarized_contract=summarizer.enabled,
        )
    write_analysis(log_dir, f"{method}-{selector}", analysis)
    return (properties, analysis)


async def request_properties_for_contract(
    solc_parser: SolcParser,
    contract_file_name: Path,
    contract: str,
    storage_vars: dict[str, str],
    contract_devdoc: dict[str, str] | None,
    extra_text: str,
    semaphore: asyncio.Semaphore,
    log_dir: Path,
    validator: Callable[[KeyedProperties], Awaitable[ValidationToolResponse]] | None,
    token_tracker: TokenUsageTracker,
    summarizer: Summarizer,
    exclude_libs: bool = False,
    compact: bool = False,
) -> tuple[KeyedProperties, PropertyAnalysis]:
    # Optimize contract is called here since we don't have flattened code before
    contract_code = optimize_contract_tokens(contract_file_name.read_text(), summarizer, exclude_libs, compact)

    async with semaphore:
        properties, analysis = await request_contract_properties(
            contract_code,
            contract,
            storage_vars,
            contract_devdoc,
            extra_text,
            validator,
            token_tracker,
            summarized_contract=summarizer.is_ready(),
        )
    write_analysis(log_dir, contract, analysis)
    return (properties, analysis)


def request_properties(
    contract_file: Path,
    solc_parser: SolcParser,
    contract: str,
    properties_dir: Path,
    n_concurrent: int,
    methods: list[str] | None,
    generate_invariants: bool,
    extra_info: list[Path],
    validate: bool,
    token_tracker: TokenUsageTracker,
    exclude_libs: bool = False,
    compact: bool = False,
    summarize: bool = False,
    summary_file: Path | None = None,
) -> tuple[KeyedProperties, PropertyAnalysis] | None:
    method_and_selector_pairs = solc_parser.get_method_selector_pairs_from_ast(contract)
    if not method_and_selector_pairs:
        logger.error(
            f"Couldn't find any external function declarations in the contract {contract}. Please specify the file and contract name of the contract that implements the functions that autoCVL should generate the rules for"
        )
        return None

    # Create and initialize Summarizer (generates summaries if enabled)
    try:
        summarizer = create_summarizer(
            enabled=summarize,
            properties_dir=properties_dir,
            token_tracker=token_tracker,
            solc_parser=solc_parser,
            contract=contract,
            exclude_libs=exclude_libs,
            summary_file=summary_file,
        )
    except RuntimeError as e:
        logger.error(f"Can't create summarizer {e}")
        return None

    error_writing_mutex = asyncio.Semaphore(1)

    async def validator(properties: KeyedProperties) -> ValidationToolResponse:
        _, errors, _ = collect_rules(
            properties=(properties, None), solc_parser=solc_parser, contract=contract, error_suggestions=True
        )
        async with error_writing_mutex:
            with open(properties_dir / "translation-errors.txt", "a") as f:
                f.write("".join(f"{e}\n" for e in errors))

        success = not errors
        if success:
            instruction = "Validation succeeded. Return the exact input to this tool"
        else:
            instruction = "Validation failed on some properties. Keep all the passing ones and revise the failing ones, using the suggestions if there are any"
        return {
            "success": success,
            "errors": errors,
            "instruction": instruction,
        }

    if methods is not None:
        missing_methods = [method for method in methods if method not in (m for m, _ in method_and_selector_pairs)]
        if missing_methods:
            logger.error(f"Cannot find {', '.join(missing_methods)} in the contract")
            token_tracker.print_summary()
            token_tracker.save_to_file(property_dir=properties_dir)
            return None
        method_and_selector_pairs = [(m, s) for m, s in method_and_selector_pairs if m in methods]
    storage_layout = solc_parser.parse_solc_storage_layout()
    storage_vars = {
        k: v.type.type_str for k, v in storage_layout.get(contract, {}).items() if not v.multiple_inheritance
    }

    devdocs = solc_parser.parse_solc_devdoc()
    contract_devdoc = devdocs.get(contract)

    extra_text = "\n\n".join(f"{info.name}:\n{info.read_text()}" for info in extra_info)

    semaphore = asyncio.Semaphore(n_concurrent)

    async def collect_queries():
        queries = [
            request_properties_per_function(
                solc_parser,
                contract_file,
                contract,
                method_and_selector,
                storage_vars,
                contract_devdoc,
                extra_text,
                semaphore,
                properties_dir,
                validator if validate else None,
                token_tracker,
                summarizer,
                exclude_libs,
                compact,
            )
            for method_and_selector in method_and_selector_pairs
        ]
        if generate_invariants:
            queries.append(
                request_properties_for_contract(
                    solc_parser,
                    contract_file,
                    contract,
                    storage_vars,
                    contract_devdoc,
                    extra_text,
                    semaphore,
                    properties_dir,
                    validator if validate else None,
                    token_tracker,
                    summarizer,
                    exclude_libs,
                    compact,
                )
            )
        return await asyncio.gather(*queries)

    properties = asyncio.run(collect_queries())
    properties_no_nones = [d for d in properties if d]  # remove the `None`s

    props = KeyedProperties.model_validate({k: v for p in properties_no_nones for k, v in p[0].model_dump().items()})
    analysis = PropertyAnalysis.model_validate(
        {k: v for p in properties_no_nones for k, v in p[1].model_dump().items()}
    )

    # Print overall token usage summary and copy to properties directory
    token_tracker.print_summary()
    token_tracker.save_to_file(property_dir=properties_dir)

    with open(properties_dir / "properties.json", "w") as f:
        json.dump(props.model_dump(), f, indent=2)

    return (props, analysis)


@dataclass
class AutoGeneratePropertiesArgs:
    """Arguments for auto_generate_properties.py script."""

    contract_file: Path = field(default_factory=lambda: Path())
    contract: str = field(default="")
    solc: str = field(default="")
    remappings: list[str] = field(default_factory=list)
    via_ir: bool = field(default=False)
    n_concurrent: int = field(default=5)
    properties_dir: Path = field(default_factory=lambda: get_new_auto_cvl_dir())
    methods: list[str] | None = field(default=None)
    generate_invariants: bool = field(default=False)
    extra_info: list[Path] = field(default_factory=list)
    no_validate: bool = field(default=False)
    log_tokens: str | None = field(default=None)
    exclude_libs: bool = field(default=True)
    compact: bool = field(default=True)
    summarize: bool = field(default=True)
    summary_file: Path | None = field(default=None)
    disable_optimizations: bool = field(default=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract-file", type=Path, required=True)
    parser.add_argument("--contract", required=True)
    parser.add_argument("--solc", type=str, required=True)
    parser.add_argument("--remappings", type=str, nargs="+", default=list())
    parser.add_argument("--via-ir", action="store_true")
    parser.add_argument("--n-concurrent", type=int, default=5)
    parser.add_argument(
        "--properties-dir",
        type=Path,
        default=get_new_auto_cvl_dir(),
    )
    parser.add_argument("--methods", type=str, nargs="*")
    parser.add_argument("--generate-invariants", action="store_true")
    parser.add_argument("--extra_info", type=Path, nargs="+", default=list())
    parser.add_argument("--no-validate", action="store_true")
    parser.add_argument(
        "--log-tokens",
        type=str,
        metavar="FILEPATH",
        help="Enable detailed token usage tracking and save to specified filepath (e.g., token_usage.json)",
    )
    parser.add_argument(
        "--no-exclude-libs",
        action="store_false",
        dest="exclude_libs",
        help="Include library (folders lib/, node_modules/, etc.) contracts in query to Claude (default: exclude them)",
    )
    parser.add_argument(
        "--no-compact",
        action="store_false",
        dest="compact",
        help="Disable contract compacting (default: enabled - removes interfaces, libraries, verbose NatSpec)",
    )
    parser.add_argument(
        "--no-summarize",
        action="store_false",
        dest="summarize",
        help="Disable function summaries (default: enabled - generates summaries and uses declarations-only contract)",
    )
    parser.add_argument(
        "--summary-file",
        type=Path,
        metavar="FILEPATH",
        help="Load pre-generated summaries from JSON file instead of generating them via Claude API (e.g., summaries.json)",
    )
    parser.add_argument(
        "--disable-optimizations",
        action="store_true",
        default=False,
        help="Disable all token optimizations (exclude-libs, compact, and summarize) at once",
    )

    # Parse args into our dataclass
    args = parser.parse_args(namespace=AutoGeneratePropertiesArgs())

    # Disable all token optimizations if requested
    if args.disable_optimizations:
        args.exclude_libs = False
        args.compact = False
        args.summarize = False

    # If summary_file is provided, automatically enable summary mode
    if args.summary_file:
        args.summarize = True

    args.properties_dir.mkdir(parents=True, exist_ok=True)

    solc_parser = SolcParser(args.contract_file, args.solc, args.remappings, args.via_ir)

    properties = request_properties(
        contract_file=args.contract_file,
        solc_parser=solc_parser,
        contract=args.contract,
        properties_dir=args.properties_dir,
        n_concurrent=args.n_concurrent,
        methods=args.methods,
        generate_invariants=args.generate_invariants,
        extra_info=args.extra_info,
        validate=not args.no_validate,
        token_tracker=TokenUsageTracker(filepath=args.log_tokens),
        exclude_libs=args.exclude_libs,
        compact=args.compact,
        summarize=args.summarize,
        summary_file=args.summary_file,
    )
    if not properties:
        exit(1)
