"""Login flow for Certora CLI."""

import base64
import errno
import hashlib
import re
import secrets
import socketserver
import webbrowser
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from http.server import SimpleHTTPRequestHandler
from logging import getLogger

from .constants import SERVERS, SUPPORTED_PORTS
from .credentials import convert_credentials, get_credentials, save_credentials
from .exceptions import CertoraLoginRefreshError, CertoraLoginValidationError
from .models import CertoraTokens, Env, cookie_string
from .url_opener import get_url

CODE_RE = re.compile(r"code=([^&]+)")

_RETRY_LIMIT = 5
_REQUEST_TIMEOUT = 30

_CURRENT_PORT = 51352

logger = getLogger(__name__)


def generate_pkce_pair() -> tuple[str, str]:
    """Generate a PKCE pair for local login.

    Docs:
        https://oauth.net/2/pkce/

    Returns:
        tuple[str, str]: Code verifier and code challenge

    """
    code_verifier = secrets.token_urlsafe(96)
    hashed = hashlib.sha256(code_verifier.encode()).digest()
    encoded = base64.urlsafe_b64encode(hashed)
    code_challenge = encoded.decode()[:-1]

    return code_verifier, code_challenge


@contextmanager
def _bind_port(
    *,
    host: str | bytes = "",
    RequestHandlerClass: type[socketserver.BaseRequestHandler],  # noqa: N803
    bind_and_activate: bool = True,
) -> Iterator[tuple[int, socketserver.TCPServer]]:
    """Bind to a port and yield the port and server.

    This function will try to bind to a port in `constants.SUPPORTED_PORTS` and yield
    the port and server. If the port is already in use, it will try the next one.

    Args:
        RequestHandlerClass (type[socketserver.BaseRequestHandler]): Request handler
        host (str | bytes, optional): Host. Defaults to "".
        bind_and_activate (bool, optional): If active server will automatically try to
            bind and activate. Defaults to True.

    Raises:
        OSError: If no ports are available

    Yields:
        Iterator[tuple[int, socketserver.TCPServer]]: Port and server

    """
    # We need to use a global variable here because we need to keep track of the port
    # that was used in the context manager
    global _CURRENT_PORT  # noqa: PLW0603
    for i, port in enumerate(SUPPORTED_PORTS, 1):
        try:
            with socketserver.TCPServer(
                (host, port),
                RequestHandlerClass,
                bind_and_activate,
            ) as httpd:
                _CURRENT_PORT = port
                yield port, httpd
                break
        except OSError as e:  # pragma: no cover
            if e.errno == errno.EADDRINUSE and i < len(SUPPORTED_PORTS):
                logger.debug("Port %d already in use", port)
            else:
                raise


def get_login_url(
    code_challenge: str,
    *,
    host: str = "http://localhost",
    port: int | None = None,
    path: str = "/client/callback/login",
    env: Env = "prod",
) -> tuple[str, str]:
    """Get the login URL and callback URL.

    Args:
        code_challenge (str): PKCE code challenge
        host (str, optional): Callback host. Defaults to "http://localhost".
        port (int | None, optional): Callback port. Defaults to None.
        path (str, optional): Callback path. Defaults to "/client/callback/login".
        env (Literal["dev", "stg", "prod"], optional): Environment. Defaults to "prod".

    Returns:
        tuple[str, str]: Redirect URL and login URL

    """
    if host.startswith("http://") and host != "http://localhost":  # pragma: no cover
        msg = "Only http://localhost is supported"
        raise CertoraLoginValidationError(msg)

    redirect_url = f"{host}:{port}" if port else host

    if not path.startswith("/"):  # pragma: no cover
        path = f"/{path}"

    redirect_url = f"{redirect_url}{path}"

    login_url = (
        f"{SERVERS[env]}/login?redirect_uri={redirect_url}&"
        f"code_challenge_method=S256&code_challenge={code_challenge}"
    )
    return redirect_url, login_url


def get_login_callback_url(
    *,
    redirect_url: str,
    code: str,
    code_verifier: str,
    env: Env = "prod",
) -> str:
    """Get the login callback URL.

    Args:
        redirect_url (str): Redirect URL
        code (str): Response code
        code_verifier (str): PKCE code verifier
        env (Literal["dev", "stg", "prod"], optional): Environment. Defaults to "prod".

    Returns:
        str: Login callback URL

    """
    return (
        f"{SERVERS[env]}/v1/auth/login-callback?"
        f"code={code}&mode=local&"
        f"code_verifier={code_verifier}&"
        f"redirect_uri={redirect_url}"
    )


def pkce_login(
    *,
    env: Env = "prod",
    no_browser: bool = False,
) -> CertoraTokens:
    """Login using PKCE flow.

    This function will start a local server to handle the login callback and open a
    browser window to the login page. It will then wait for the login to complete and
    return the credentials.

    Args:
        env (Literal["dev", "stg", "prod"], optional): Environment. Defaults to "prod".
        no_browser (bool, optional): Do not open the browser. Defaults to False.

    Returns:
        CertoraTokens: Certora tokens

    Raises:
        ValueError: If the login fails

    """
    code_verifier, code_challenge = generate_pkce_pair()
    cert_token_dict: dict[str, str | int] = {}

    class LoginHandler(SimpleHTTPRequestHandler):
        redirect_url: str = ""
        timeout = _REQUEST_TIMEOUT

        def _return_response(self, return_code: int, msg: bytes) -> None:
            self.send_response(return_code)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(msg)

        def do_GET(self) -> None:
            if not self.path.startswith("/client/callback/login"):  # pragma: no cover
                self.send_response(404)
                return

            code_match = CODE_RE.search(self.path)
            if not code_match:  # pragma: no cover
                self._return_response(400, b"No Code In Auth Call")
                return

            log_url = get_login_callback_url(
                redirect_url=self.redirect_url,
                code=code_match.group(1),
                code_verifier=code_verifier,
                env=env,
            )
            logger.debug("Login callback url: %s", log_url)

            try:
                _, cert_cookies = get_url(log_url)
            except CertoraLoginValidationError:  # pragma: no cover
                self._return_response(400, b"Auth Call Failed")
                return

            cert_token_dict.update(cert_cookies)

            self._return_response(
                200,
                b"Login successful! You can close this window now.",
            )

    with _bind_port(RequestHandlerClass=LoginHandler) as (port, httpd):
        # We can create the redirect_url here because we have the port
        LoginHandler.redirect_url, callback_url = get_login_url(
            code_challenge,
            host="http://localhost",
            port=port,
            path="/client/callback/login",
            env=env,
        )

        # Open the browser window
        logger.info("Callback url: %s", callback_url)
        if not no_browser:  # pragma: no cover
            webbrowser.open(callback_url)

        # Handle up to 5 requests
        i = 0
        while not cert_token_dict and i < _RETRY_LIMIT:
            httpd.handle_request()
            i += 1
            logger.debug("Incorrect request, retrying %d", i)

    return convert_credentials(cert_token_dict)


def _who_am_i(
    credentials: CertoraTokens,
    *,
    env: Env = "prod",
) -> CertoraTokens | None:
    """Call /who-am-i for the current user.

    This endpoint is used to get the user information and refresh the token if needed.

    Args:
        credentials (CertoraTokens): Credentials
        env (Literal["dev", "stg", "prod"], optional): Environment. Defaults to "prod".

    Returns:
        CertoraTokens | None: Refreshed credentials or None if the refresh token is
            expired.

    """
    try:
        _, cookies = get_url(
            f"{SERVERS[env]}/who-am-i",
            cookies=cookie_string(credentials),
        )
    except CertoraLoginValidationError:
        return None

    token = cookies.get("certoraToken")

    if token:
        logger.info("Token refreshed successfully")
        credentials["certoraToken"] = token
        credentials["timestamp"] = int(datetime.now(tz=UTC).timestamp())

    return credentials


def login(
    env: Env = "prod",
    *,
    force_file: bool = False,
    save: bool = True,
    no_browser: bool = False,
    no_pkce: bool = False,
) -> CertoraTokens:
    """Login to Certora.

    This function will try to get the credentials from the keyring and refresh the token
    if possible. If the token is invalid or not available, it will start the PKCE login
    flow.

    Args:
        env (Literal["dev", "stg", "prod"], optional): Environment. Defaults to "prod".
        force_file (bool, optional): Force saving to file even if keyring is available.
            Defaults to False.
        save (bool, optional): Save the credentials. Defaults to True.
        no_browser (bool, optional): Do not open the browser. Defaults to False.
        no_pkce (bool, optional): Do not use PKCE login flow. Defaults to False.

    Returns:
        CertoraTokens: Certora tokens

    """
    credentials = get_credentials()

    if credentials:
        credentials = _who_am_i(credentials, env=env)

    if not credentials and not no_pkce:
        credentials = pkce_login(env=env, no_browser=no_browser)

    if not credentials:
        msg = "Failed to obtain or refresh credentials"
        raise CertoraLoginRefreshError(msg)

    if save:
        save_credentials(credentials, force_file=force_file)

    return credentials
