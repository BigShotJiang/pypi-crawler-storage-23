"""Constants for the certora-login package."""

from .models import Env

SUPPORTED_PORTS = (51352, 51556)

SERVERS: dict[Env, str] = {
    "dev": "https://vaas-dev.certora.com",
    "stg": "https://vaas-stg.certora.com",
    "prod": "https://prover.certora.com",
}
