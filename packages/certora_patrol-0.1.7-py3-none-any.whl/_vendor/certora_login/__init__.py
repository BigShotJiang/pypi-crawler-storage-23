"""Certora CLI login package.

This package provides a way to login to the Certora CLI and save the credentials to
the keyring or a file. The credentials are stored in a dictionary with the following
fields: "certoraToken", "certoraRefreshToken", "user", and "timestamp".
"""

from .aws_credentials import convert_credentials, get_temporal_aws_credentials
from .constants import SERVERS
from .credentials import delete_credentials
from .login_flow import get_credentials, login
from .models import CertoraTokens, cookie_string

try:
    from ._version import __version__, __version_tuple__, version, version_tuple
except ImportError:
    __version__ = "0.0.0"
    __version_tuple__ = (0, 0, 0)
    version = __version__
    version_tuple = __version_tuple__


__all__ = [
    "SERVERS",
    "CertoraTokens",
    "__version__",
    "__version_tuple__",
    "convert_credentials",
    "cookie_string",
    "delete_credentials",
    "get_credentials",
    "get_temporal_aws_credentials",
    "login",
    "version",
    "version_tuple",
]
