"""Certora Login Exceptions."""


class CertoraLoginError(Exception):
    """Base exception for Certora login errors."""


class CertoraLoginValidationError(CertoraLoginError):
    """Exception for Certora login validation errors."""


class CertoraLoginRefreshError(CertoraLoginError):
    """Exception for Certora login refresh errors."""
