"""CLI for login to Certora CLI and save credentials."""

# pragma: no cover

import argparse
import json
import logging
import sys
from collections.abc import Callable

from .aws_credentials import convert_credentials, get_temporal_aws_credentials
from .credentials import KeyringError, delete_credentials
from .login_flow import login
from .models import Env, ExportType

logger = logging.getLogger(__name__)


def cli_login(
    *,
    env: Env,
    force_file: bool,
    no_save: bool,
    force_refresh: bool,
    no_browser: bool,
    export_aws_credentials: ExportType | None,
    print_function: Callable[..., None] = print,
) -> None:  # pragma: no cover
    """Login to Certora and save credentials."""
    if force_refresh:
        delete_credentials()

    credentials = login(
        env=env,
        force_file=force_file,
        save=not no_save,
        no_browser=no_browser,
    )

    export_type = export_aws_credentials
    if not export_type:
        return

    temp_creds = get_temporal_aws_credentials(credentials, env=env)
    if export_type == "process":
        print_function(
            json.dumps(
                convert_credentials(
                    temp_creds,
                    "process",
                ),
                indent=2,
            )
        )
    else:
        exported = convert_credentials(temp_creds, "env")

        for key, value in exported.items():
            msg = f"{key}={value}"
            if export_type == "env":
                msg = f"export {msg}"
            print_function(msg)


def main() -> None:  # pragma: no cover
    """Login to Certora and save credentials."""
    arg_parser = argparse.ArgumentParser(
        description="Login to Certora CLI and save credentials",
    )
    arg_parser.add_argument(
        "-e",
        "--env",
        type=str,
        default="prod",
        help="Environment to login to (prod, stg, dev)",
        choices=["prod", "stg", "dev"],
    )
    arg_parser.add_argument(
        "--force-file",
        action="store_true",
        help="Save credentials to file even if keyring is available",
    )
    arg_parser.add_argument(
        "--no-save",
        action="store_false",
        dest="save",
        help="Do not save credentials",
    )
    arg_parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Do not print output",
    )
    arg_parser.add_argument(
        "-f",
        "--force-refresh",
        action="store_true",
        help="Delete and refresh credentials",
    )
    # no browser
    arg_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the browser for login. "
        "Also available as `BROWSER=true` certora-login",
    )
    arg_parser.add_argument(
        "--export-aws-credentials",
        type=str,
        default=None,
        choices=["process", "env", "env-no-export"],
        help="Export temporal AWS credentials. "
        "Supported values: process, env, env-no-export",
    )
    args = arg_parser.parse_args()
    level = logging.ERROR if args.quiet else logging.INFO

    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    try:
        cli_login(
            env=args.env,
            force_file=args.force_file,
            no_save=not args.save,
            force_refresh=args.force_refresh,
            no_browser=args.no_browser,
            export_aws_credentials=args.export_aws_credentials,
        )
    except KeyringError as e:
        logger.error("Keyring error: %s - verify your keyring configuration", e)  # noqa: TRY400
        sys.exit(1)
