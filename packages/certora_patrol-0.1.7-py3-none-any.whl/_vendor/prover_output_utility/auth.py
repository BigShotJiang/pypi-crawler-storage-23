"""
Authentication handling for Certora Prover API.
"""

import os
from typing import Dict

import requests

from .exceptions import AuthenticationError

try:
    from certora_login import SERVERS, delete_credentials, login
except ImportError:
    login = None
    delete_credentials = None
    SERVERS = None


class ProverAuth:
    """
    Handles authentication with Certora Prover API using cert_cli_login.
    """

    def __init__(self):
        """
        Initialize authentication.
        Uses cert_cli_login for authentication, no CERTORAKEY needed.
        """
        self._retry_count = 0
        self._max_retries = 1

    def delete_stored_credentials(self) -> None:
        """
        Delete stored credentials when they are expired or invalid.

        Raises:
            AuthenticationError: If delete_credentials is not available
        """
        if delete_credentials is None:
            raise AuthenticationError(
                "certora_login package is not installed. "
                "Please install it with: pip install certora-login"
            )

        try:
            delete_credentials()
        except Exception as e:
            raise AuthenticationError(f"Failed to delete credentials: {e}")

    def get_auth_cookies(self, force_relogin: bool = False) -> requests.cookies.RequestsCookieJar:
        """
        Get authentication cookies for API requests.

        Args:
            force_relogin: If True, delete existing credentials and force a new login

        Returns:
            RequestsCookieJar with authentication cookies

        Raises:
            AuthenticationError: If cert_cli_login is not available or fails
        """
        cookies = requests.cookies.RequestsCookieJar()

        # Skip authentication in CI environment - return empty cookies
        if os.getenv("CI"):
            return cookies

        # Use cert_cli_login for authentication
        if login is None:
            raise AuthenticationError(
                "certora_login package is not installed. "
                "Please install it with: pip install certora-login"
            )

        if force_relogin:
            try:
                self.delete_stored_credentials()
            except Exception:
                pass

        try:
            credentials = login(env="prod", force_file=True)

            # Set all credential cookies with proper domain
            for name, value in credentials.items():
                cookies.set(name, str(value), domain="certora.com")

            return cookies

        except Exception as e:
            raise AuthenticationError(f"Authentication failed: {e}")

    def get_auth_headers(self) -> Dict[str, str]:
        """
        Get authentication headers for API requests.

        Note: Headers are typically not needed when using cookies from cert_cli_login.
        This method returns an empty dict as headers are handled via cookies.

        Returns:
            Empty dictionary (authentication is via cookies)
        """
        return {}
