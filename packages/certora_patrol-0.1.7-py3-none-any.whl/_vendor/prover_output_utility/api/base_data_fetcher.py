"""
Abstract base class for data fetchers.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class BaseDataFetcher(ABC):
    """Abstract base class for fetching prover data from different sources."""

    @abstractmethod
    def fetch_raw_output(self, job_identifier: str) -> Dict[str, Any]:
        """
        Fetch raw output data.

        Args:
            job_identifier: Job identifier (job ID for remote, emv path for local)

        Returns:
            Raw job data

        Raises:
            ProverAPIError: If fetch fails
        """
        pass

    @abstractmethod
    def fetch_tree_view_data(self, job_identifier: str, path: str = "treeViewStatus.json") -> Dict[str, Any]:
        """
        Fetch tree-view data.

        Args:
            job_identifier: Job identifier (job ID for remote, emv path for local)
            path: Optional path within the tree-view

        Returns:
            Tree-view data

        Raises:
            ProverAPIError: If fetch fails
        """
        pass

    @abstractmethod
    def list_recent_jobs(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        List recent jobs.

        Args:
            limit: Maximum number of jobs to return

        Returns:
            List of job information dictionaries

        Raises:
            ProverAPIError: If fetch fails
        """
        pass

    @abstractmethod
    def fetch_outputs(self, job_identifier: str) -> bytes:
        """
        Fetch outputs archive (tar.gz) for a job.

        Args:
            job_identifier: Job identifier (job ID for remote, emv path for local)

        Returns:
            Raw tar.gz content as bytes

        Raises:
            ProverAPIError: If fetch fails
        """
        pass

    @abstractmethod
    def cancel_jobs(self, job_ids: List[str]) -> Dict[str, Any]:
        """
        Cancel multiple jobs.

        Args:
            job_ids: List of job IDs to cancel

        Returns:
            API response data

        Raises:
            ProverAPIError: If cancellation fails
        """
        pass

    @abstractmethod
    def fetch_alert_report(self, job_identifier: str) -> List[Dict[str, Any]]:
        """
        Fetch alert report (alertReport.json) for a job.

        Args:
            job_identifier: Job identifier (job ID for remote, emv path for local)

        Returns:
            Alert report data as a list of alert objects

        Raises:
            ProverAPIError: If fetch fails
        """
        pass