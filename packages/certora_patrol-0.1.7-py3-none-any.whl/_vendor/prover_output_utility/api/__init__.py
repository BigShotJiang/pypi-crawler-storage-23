"""
Prover Output API package.

This package contains the refactored API modules for interacting with
the Certora Prover output data.
"""

from .main import ProverOutputAPI

__all__ = ["ProverOutputAPI"]
