from .base import Malet

__all__ = ["Malet"]
