# Changelog

All notable changes to this project are documented in this file.

## [0.5.0] - 2026-03-03

### Added

- `L2Snapshot` validity masks: `bid_px_valid`, `ask_px_valid`.
- `StepResult` event counters: `events_user`, `events_synthetic`, `events_total`.
- Intraday intensity regime configuration (`RegimeConfig`, `RegimeSegment`).
- Partial cancel controls in `CancelConfig` (`partial_cancel_prob`, `partial_min_ratio`).
- Runtime checkpoint module (`stock_gen.runtime.checkpoint`) for explicit atomic rollback.
- `docs/archive/migration-v0.5.md`.

### Changed

- `get_l2(as_ticks=False)` now returns `NaN` for missing prices.
- Event-cap rollback path now uses explicit checkpoint/restore objects instead of `deepcopy`.
- `StockGeneratorConfig` now enforces runtime type validation for policies and nested configs.
- Documentation was reorganized for v0.5 contracts and migration paths.

### Breaking Changes

- Missing prices in `get_l2(as_ticks=False)` changed from scaled negative sentinels to `NaN`.
- `StepResult` primary counters moved to `events_user/events_synthetic/events_total`; `events_processed` remains compatibility alias.
- Invalid runtime types for policy/nested config fields now raise `TypeError` at config construction.

## [0.4.0] - 2026-03-03

### Added

- `README.ko.md` Korean translation with reciprocal language switch and canonical-source note.
- `docs/plans/2026-03-03-v0.4.0-implementation.md` implementation plan record.
- Public API stability/docstring tests covering root `__all__` and exported methods/properties.

### Changed

- `StockGenerator.step()` now enforces atomic rollback for `EventCapPolicy.RAISE`; when cap is exceeded, state/history/time are restored before raising `EventCapExceededError`.
- Event-type sampling now recomputes event-loop features after time advance/flow decay at event time.
- Snapshot construction is now side-effect free; `last_mid_ticks` updates are handled in the simulation loop.
- `MarketHistory.to_numpy(as_ticks=False)` now exports `NaN` for missing prices instead of scaled `-1` sentinels.
- `MarketHistory.to_numpy()` now includes per-level validity masks: `bid_px_valid`, `ask_px_valid`.
- Docs were reorganized to English-first README + Korean README, deduplicated API usage docs, and archived migration notes under `docs/archive/`.

### Breaking Changes

- `to_numpy(as_ticks=False)` missing best quotes/levels are now `NaN` (previously negative scaled sentinels from tick `-1`).
- `EventCapPolicy.RAISE` now behaves transactionally at step level: no partial step mutation remains after cap-exceeded exceptions.
- Migration guide path changed from `docs/migration-v0.3.md` to `docs/archive/migration-v0.3.md`.

## [0.3.0] - 2026-03-03

### Added

- `docs/architecture.md` with system-level design, data flow, and extension points.
- `docs/archive/migration-v0.3.md` with upgrade checklist for users and maintainers.

### Changed

- README package description now reflects policy-driven order-book event dynamics.
- `pyproject.toml` metadata updated to `version = "0.3.0"` and aligned package description.
- Version-specific hardcoding in docs titles/pins was generalized (for example, no `v0.2` headings; reproducibility pin uses `X.Y.Z`).
- README Quickstart was reduced to a minimal entry flow; full typed walkthrough is centralized in `docs/api.md`.
- `docs/release.md` now matches GitHub Actions OIDC Trusted Publishing workflow and removes mandatory `twine upload` from standard release flow.
- Core engine internals were modularized into `src/stock_gen/engine/` to separate feature extraction, snapshot building, and event dispatch responsibilities.
- `recent_flow` half-life decay now applies across the full frame interval (including no-event residual time).

### Breaking Changes

- `StockGenerator.get_events()`, `get_trades()`, and `get_step_results()` now return immutable tuples.
- `MarketHistory.frames/events/trades` and `SimulationResult.steps` are now immutable tuples.
- L2/frame arrays are exported as read-only snapshots; downstream code must copy arrays before mutation.
- `get_l2(levels<=0)` now raises `ValueError` with an explicit domain message.
- Maintainer release process is now documented as tag-driven GitHub Actions OIDC publishing (instead of direct `twine` uploads in the primary flow).
- Version-tagged documentation heading text changed, so deep links/bookmarks targeting old `v0.2` headings may require updates.

### Migration Summary

- Runtime API keeps the same entry points, but returned collection mutability changed; update code that mutates returned containers/arrays.
- Maintainers should use the `vX.Y.Z` tag flow documented in `docs/release.md` and ensure PyPI Trusted Publisher is configured.
- Documentation consumers should update links to version-agnostic docs and follow `docs/archive/migration-v0.3.md` for rollout steps.

## [0.2.0] - 2026-03-03

### Added

- Public result types `StepResult` and `SimulationResult` in top-level API.
- Public policy enums `LiquidityPolicy` and `EventCapPolicy` in top-level API.
- Step-level truncation metadata (`truncated`, `events_processed`, `t_last_event`).
- `SimulationResult` convenience properties: `frames`, `events`, `trades`.
- Data-contract validity masks for array export (`*_valid` fields in `to_numpy` output).
- Policy-level controls for empty-book handling and event-cap handling.

### Changed

- Documentation reorganized for v0.2:
  - install-first README flow
  - API/data-contract/config/reproducibility/release docs

### Notes

- This is the first changelog entry in this repository snapshot.
