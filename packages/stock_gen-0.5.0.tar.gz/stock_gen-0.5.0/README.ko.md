# stock-gen

언어: [English (canonical)](README.md) | 한국어

`stock-gen`은 가상 주식 시장 실험을 위한 이벤트 기반 지정가 주문서(CLOB) 시뮬레이터입니다.
단일 자산 주문서에서 지정가/취소(부분 취소 포함)/정정/시장가 이벤트를 모델링합니다.

> 기준 문서는 영문 [README.md](README.md)입니다.

## 요구 사항

- Python >= 3.11

## 설치

```bash
python -m pip install stock-gen
```

로컬 개발:

```bash
python -m pip install -e '.[dev]'
```

## 빠른 시작

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## v0.5 주요 변경

- `get_l2(as_ticks=False)`의 결측 가격 표현이 `NaN`으로 통일되었습니다.
- `L2Snapshot`에 `bid_px_valid`, `ask_px_valid` 마스크가 추가되었습니다.
- `StepResult`에 `events_user`, `events_synthetic`, `events_total`가 추가되었습니다.
- `events_processed`는 `events_user`의 하위 호환 별칭으로 유지됩니다.
- 설정에 부분 취소(`partial_cancel_prob`, `partial_min_ratio`)와 레짐 배율이 추가되었습니다.

## 문서 맵

### 사용자 문서

- [docs/api.md](docs/api.md)
- [docs/config-reference.md](docs/config-reference.md)
- [docs/data-contract.md](docs/data-contract.md)
- [docs/reproducibility.md](docs/reproducibility.md)

### 유지보수 문서

- [docs/architecture.md](docs/architecture.md)
- [docs/release.md](docs/release.md)
- [docs/archive/migration-v0.3.md](docs/archive/migration-v0.3.md)
- [docs/archive/migration-v0.5.md](docs/archive/migration-v0.5.md)
