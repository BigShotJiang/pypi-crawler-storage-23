import pytest

from stock_gen import StockGeneratorConfig


def test_invalid_liquidity_policy_type_raises_type_error() -> None:
    with pytest.raises(TypeError, match="liquidity_policy"):
        StockGeneratorConfig(liquidity_policy="repair")  # type: ignore[arg-type]


def test_invalid_event_cap_policy_type_raises_type_error() -> None:
    with pytest.raises(TypeError, match="event_cap_policy"):
        StockGeneratorConfig(event_cap_policy="raise")  # type: ignore[arg-type]


def test_invalid_nested_config_types_raise_type_error() -> None:
    with pytest.raises(TypeError, match="intensity"):
        StockGeneratorConfig(intensity=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="placement"):
        StockGeneratorConfig(placement=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="size"):
        StockGeneratorConfig(size=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="cancel"):
        StockGeneratorConfig(cancel=object())  # type: ignore[arg-type]
    with pytest.raises(TypeError, match="regime"):
        StockGeneratorConfig(regime=object())  # type: ignore[arg-type]
