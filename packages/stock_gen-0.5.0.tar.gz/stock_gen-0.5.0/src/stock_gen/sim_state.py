from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SimulationStateSnapshot:
    """Immutable state checkpoint used for atomic step rollback."""

    t: float
    recent_flow: float
    last_mid_ticks: int | None
    frame_index: int
    next_event_seq: int


@dataclass(slots=True)
class SimulationState:
    t: float = 0.0
    recent_flow: float = 0.0
    last_mid_ticks: int | None = None
    frame_index: int = 0
    _next_event_seq: int = 1

    def reset(self) -> None:
        self.t = 0.0
        self.recent_flow = 0.0
        self.last_mid_ticks = None
        self.frame_index = 0
        self._next_event_seq = 1

    def next_event_seq(self) -> int:
        seq = self._next_event_seq
        self._next_event_seq += 1
        return seq

    def snapshot(self) -> SimulationStateSnapshot:
        """Capture a state snapshot for rollback."""

        return SimulationStateSnapshot(
            t=float(self.t),
            recent_flow=float(self.recent_flow),
            last_mid_ticks=None if self.last_mid_ticks is None else int(self.last_mid_ticks),
            frame_index=int(self.frame_index),
            next_event_seq=int(self._next_event_seq),
        )

    def restore(self, snapshot: SimulationStateSnapshot) -> None:
        """Restore state from ``snapshot``."""

        self.t = float(snapshot.t)
        self.recent_flow = float(snapshot.recent_flow)
        self.last_mid_ticks = None if snapshot.last_mid_ticks is None else int(snapshot.last_mid_ticks)
        self.frame_index = int(snapshot.frame_index)
        self._next_event_seq = int(snapshot.next_event_seq)
