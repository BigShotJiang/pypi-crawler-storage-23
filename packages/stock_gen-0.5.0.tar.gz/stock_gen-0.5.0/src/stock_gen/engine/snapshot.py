from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import FrameSnapshot, L2Snapshot, Side
from .features import compute_book_imbalance


def _readonly_int64(values: NDArray[np.int64]) -> NDArray[np.int64]:
    arr = np.array(values, dtype=np.int64, copy=True)
    arr.setflags(write=False)
    return arr


def _readonly_float64(values: NDArray[np.float64]) -> NDArray[np.float64]:
    arr = np.array(values, dtype=np.float64, copy=True)
    arr.setflags(write=False)
    return arr


def _readonly_bool(values: NDArray[np.bool_]) -> NDArray[np.bool_]:
    arr = np.array(values, dtype=np.bool_, copy=True)
    arr.setflags(write=False)
    return arr


def build_l2_snapshot(
    *,
    ob: OrderBook,
    levels: int,
    tick_size: float,
    as_ticks: bool,
) -> L2Snapshot:
    if levels <= 0:
        raise ValueError("levels must be positive")

    bid_px, bid_q, ask_px, ask_q = ob.get_l2_ticks(levels)

    bid_px_arr = np.full(levels, -1, dtype=np.int64)
    bid_q_arr = np.zeros(levels, dtype=np.int64)
    ask_px_arr = np.full(levels, -1, dtype=np.int64)
    ask_q_arr = np.zeros(levels, dtype=np.int64)

    for i, (price, qty) in enumerate(zip(bid_px, bid_q, strict=False)):
        bid_px_arr[i] = int(price)
        bid_q_arr[i] = int(qty)
    for i, (price, qty) in enumerate(zip(ask_px, ask_q, strict=False)):
        ask_px_arr[i] = int(price)
        ask_q_arr[i] = int(qty)
    bid_px_valid = bid_px_arr >= 0
    ask_px_valid = ask_px_arr >= 0

    if as_ticks:
        return L2Snapshot(
            bid_px=_readonly_int64(bid_px_arr),
            bid_qty=_readonly_int64(bid_q_arr),
            bid_px_valid=_readonly_bool(bid_px_valid),
            ask_px=_readonly_int64(ask_px_arr),
            ask_qty=_readonly_int64(ask_q_arr),
            ask_px_valid=_readonly_bool(ask_px_valid),
        )

    tick = float(tick_size)
    bid_px_float = np.full(levels, np.nan, dtype=np.float64)
    ask_px_float = np.full(levels, np.nan, dtype=np.float64)
    bid_px_float[bid_px_valid] = bid_px_arr[bid_px_valid].astype(np.float64) * tick
    ask_px_float[ask_px_valid] = ask_px_arr[ask_px_valid].astype(np.float64) * tick
    return L2Snapshot(
        bid_px=_readonly_float64(bid_px_float),
        bid_qty=_readonly_int64(bid_q_arr),
        bid_px_valid=_readonly_bool(bid_px_valid),
        ask_px=_readonly_float64(ask_px_float),
        ask_qty=_readonly_int64(ask_q_arr),
        ask_px_valid=_readonly_bool(ask_px_valid),
    )


def build_frame_snapshot(
    *,
    ob: OrderBook,
    state: SimulationState,
    depth_levels: int,
    tick_size: float,
) -> FrameSnapshot:
    if depth_levels <= 0:
        raise ValueError("depth_levels must be positive")

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    spread_ticks = int(best_ask - best_bid) if (best_bid is not None and best_ask is not None) else None

    mid_price: float | None = None
    if best_bid is not None and best_ask is not None:
        mid_ticks = (best_bid + best_ask) / 2.0
        mid_price = mid_ticks * float(tick_size)
    elif state.last_mid_ticks is not None:
        mid_price = float(state.last_mid_ticks) * float(tick_size)

    bid_px, bid_q, ask_px, ask_q = ob.get_l2_ticks(depth_levels)
    bid_px_arr = np.full(depth_levels, -1, dtype=np.int64)
    bid_q_arr = np.zeros(depth_levels, dtype=np.int64)
    ask_px_arr = np.full(depth_levels, -1, dtype=np.int64)
    ask_q_arr = np.zeros(depth_levels, dtype=np.int64)

    for i, (price, qty) in enumerate(zip(bid_px, bid_q, strict=False)):
        bid_px_arr[i] = int(price)
        bid_q_arr[i] = int(qty)
    for i, (price, qty) in enumerate(zip(ask_px, ask_q, strict=False)):
        ask_px_arr[i] = int(price)
        ask_q_arr[i] = int(qty)

    return FrameSnapshot(
        t=float(state.t),
        best_bid_ticks=best_bid,
        best_ask_ticks=best_ask,
        mid_price=mid_price,
        spread_ticks=spread_ticks,
        bid_px_ticks=_readonly_int64(bid_px_arr),
        bid_qty=_readonly_int64(bid_q_arr),
        ask_px_ticks=_readonly_int64(ask_px_arr),
        ask_qty=_readonly_int64(ask_q_arr),
        imbalance=compute_book_imbalance(ob=ob),
        recent_flow=float(state.recent_flow),
    )
