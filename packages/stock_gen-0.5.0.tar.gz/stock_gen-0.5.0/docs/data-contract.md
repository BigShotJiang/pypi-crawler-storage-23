# Data Contract

This document defines stable output semantics for downstream consumers.

## `StepResult`

- `frame`: frame snapshot at step end.
- `truncated`: true only for `EventCapPolicy.TRUNCATE_AND_FLAG` when cap is hit.
- `events_user`: count of non-synthetic in-step events.
- `events_synthetic`: count of synthetic repair events emitted in the step.
- `events_total`: `events_user + events_synthetic`.
- `t_last_event`: last non-synthetic event time in step, else `None`.
- `events_processed`: compatibility alias for `events_user`.

## `SimulationResult`

- `history.frames/events/trades` are immutable tuples.
- `steps` is an immutable tuple and accumulates prior `step()` calls on the instance.

## `FrameSnapshot`

- scalar fields:
  - `t`, `best_bid_ticks`, `best_ask_ticks`, `mid_price`, `spread_ticks`, `imbalance`, `recent_flow`
- L2 arrays:
  - `bid_px_ticks`, `bid_qty`, `ask_px_ticks`, `ask_qty`
  - shape `(depth_levels,)`, dtype `int64`, read-only
  - missing level sentinels: price `-1`, qty `0`

## `L2Snapshot`

- `bid_px`, `ask_px`, `bid_qty`, `ask_qty`, `bid_px_valid`, `ask_px_valid`
- masks (`*_px_valid`) indicate whether each level has a real price.

Encoding:
- `as_ticks=True`: missing price level -> `-1`
- `as_ticks=False`: missing price level -> `NaN`

## `MarketHistory.to_numpy()`

`to_numpy(as_ticks=True)` returns:
- `t`
- `mid`, `mid_valid`
- `spread_ticks`, `spread_valid`
- `best_bid_ticks`, `best_ask_ticks`, `best_bid_valid`, `best_ask_valid`
- `imbalance`, `imbalance_valid`
- `recent_flow`
- `bid_px_ticks`, `bid_qty`, `bid_px_valid`
- `ask_px_ticks`, `ask_qty`, `ask_px_valid`

`to_numpy(as_ticks=False)` additionally returns:
- `best_bid`, `best_ask`, `bid_px`, `ask_px`

Missing-value policy:
- float price arrays use `NaN` for missing values.
- tick-space price arrays use `-1` plus corresponding validity masks.

## `Event`

Stable fields:
- `seq`, `frame_index`, `t`, `event_type`, `side`
- `price_ticks`, `qty`, `order_id`
- `synthetic`, `reason`, `placement_mode`, `deep_distance`, `replaced_order_id`
