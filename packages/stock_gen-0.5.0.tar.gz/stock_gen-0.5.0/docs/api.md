# API Reference

## Public Imports

```python
from stock_gen import (
    EventCapPolicy,
    LiquidityPolicy,
    SimulationResult,
    StepResult,
    StockGenerator,
    StockGeneratorConfig,
)
```

## Core Objects

- `StockGeneratorConfig`: immutable simulator config.
- `StockGenerator`: stateful simulator.
- `StepResult`: one-step output.
- `SimulationResult`: cumulative output.

## `StockGenerator`

- `StockGenerator(config: StockGeneratorConfig | None = None)`
- `step(dt: float | None = None) -> StepResult`
- `gen(until_time: float | None = None) -> SimulationResult`
- `reset(seed: int | None = None) -> None`
- `get_history() -> MarketHistory`
- `get_step_results() -> tuple[StepResult, ...]`
- `get_events() -> tuple[Event, ...]`
- `get_trades() -> tuple[Trade, ...]`
- `get_l2(levels: int | None = None, *, as_ticks: bool = False) -> L2Snapshot`
- `get_time() -> float`
- `get_price() -> float`
- `get_best_bid_ask() -> tuple[tuple[float, int], tuple[float, int]]`

Notes:
- `gen()` is stateful and continues from current simulator time.
- Returned history/event/trade/step containers are immutable tuples.

## `StepResult`

- `frame: FrameSnapshot`
- `truncated: bool`
- `events_user: int`
- `events_synthetic: int`
- `events_total: int`
- `t_last_event: float | None`
- `events_processed: int` (property alias of `events_user` for compatibility)

## `SimulationResult`

- `history: MarketHistory`
- `steps: tuple[StepResult, ...]`
- `frames`, `events`, `trades`: convenience aliases to `history`.

## `L2Snapshot`

- `bid_px`, `ask_px`: price arrays (`int64` when `as_ticks=True`, `float64` when `as_ticks=False`)
- `bid_qty`, `ask_qty`: quantity arrays (`int64`)
- `bid_px_valid`, `ask_px_valid`: validity masks (`bool`)

Contract:
- `as_ticks=True`: missing levels use tick sentinel `-1` in price arrays.
- `as_ticks=False`: missing levels use `NaN` in price arrays.

## Policy Enums

### `LiquidityPolicy`

- `REPAIR` (default): inserts synthetic liquidity for one-sided states.
- `ALLOW_EMPTY`: allows one-sided states.
- `HALT_ON_EMPTY`: raises `RuntimeError` on one-sided states.

### `EventCapPolicy`

- `RAISE` (default): raises `EventCapExceededError` and rolls back the step atomically.
- `TRUNCATE_AND_FLAG`: truncates the step and sets `StepResult.truncated=True`.

## Error Behavior

Common exceptions:
- `StockGeneratorConfig(...)`: `ValueError` / `TypeError` for invalid ranges or types.
- `step(dt=...)`: `ValueError` if `dt <= 0`.
- `gen(until_time=...)`: `ValueError` if `until_time < current time`.
- `get_l2(levels=...)`: `ValueError` if `levels <= 0`.
- `LiquidityPolicy.HALT_ON_EMPTY`: `RuntimeError`.
- `EventCapPolicy.RAISE`: `EventCapExceededError`.
