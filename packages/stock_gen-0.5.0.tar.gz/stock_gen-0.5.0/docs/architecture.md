# Architecture Overview

`stock-gen` is an event-driven single-asset CLOB simulator with explicit policy controls and deterministic replay boundaries.

## Design Goals

- deterministic replay for fixed config + seed
- explicit contracts for frames/events/trades exports
- safe edge behavior through policies
- extensible microstructure models

## Module Layout

- `stock_gen/generator.py`
  - orchestration API (`step`, `gen`, `reset`)
- `stock_gen/orderbook.py`
  - price-time-priority order book, matching, replace, partial cancel
  - in-memory checkpoint/restore support
- `stock_gen/engine/`
  - `event_handlers.py`: event application
  - `features.py`: feature extraction and event sampling inputs
  - `snapshot.py`: immutable frame/L2 snapshot building
- `stock_gen/models_*`
  - `intensity`, `placement`, `size`, `cancel`
- `stock_gen/runtime/checkpoint.py`
  - atomic step checkpoint capture/restore for cap-exceeded rollback

## Step Execution Flow

1. Resolve frame end time.
2. Pre-loop liquidity policy handling.
3. Compute features and event intensities.
4. Sample event time and event type.
5. Apply event via dispatcher and record trades/events.
6. Repeat until frame end or event-cap policy stop.
7. Apply snapshot-time policy handling.
8. Build frame snapshot and return `StepResult`.

## Atomic Rollback Path

When `EventCapPolicy.RAISE` is active:
- capture checkpoint (`orderbook` + `simulation state` + output list lengths)
- execute step
- if cap exceeded, restore checkpoint and re-raise

This preserves transactional behavior with explicit checkpoint data structures.

## Policy Layer

- `LiquidityPolicy`: `REPAIR`, `ALLOW_EMPTY`, `HALT_ON_EMPTY`
- `EventCapPolicy`: `RAISE`, `TRUNCATE_AND_FLAG`

## Regime Multiplier

`RegimeConfig` provides optional time intervals with intensity multipliers.
Active multiplier at simulation time `t` scales all event intensities.

## Determinism Boundaries

Deterministic when all are fixed:
- package version
- Python/NumPy environment
- full config (including regime/cancel settings)
- seed

Non-deterministic when:
- `seed=None`
- environment/version drift
- changed defaults or configs
