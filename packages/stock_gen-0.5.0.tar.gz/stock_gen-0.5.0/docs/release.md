# Release Guide

## 1. Prepare Version

1. Update `pyproject.toml` version.
2. Update `CHANGELOG.md`.
3. Sync docs:
   - `README.md` (canonical EN)
   - `README.ko.md` (KR translation)
   - `docs/api.md`, `docs/config-reference.md`, `docs/data-contract.md`
4. Add migration note under `docs/archive/` for breaking changes.

## 2. Verify Locally

```bash
pytest -q
ruff check .
mypy src tests
python -m build
```

## 3. Artifact Smoke Test

```bash
python -m pip install --force-reinstall dist/*.whl
python - <<'PY'
from stock_gen import StockGenerator, StockGeneratorConfig
sim = StockGenerator(StockGeneratorConfig(seed=1, end_time=1.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
PY
```

## 4. Multi-Agent Hygiene

For any subagent workflow in release prep:
1. spawn subagent
2. wait for result
3. close subagent immediately

No lingering subagent threads are allowed before tagging.

## 5. Publish (Tag-Driven)

Repository workflow: `.github/workflows/workflow.yml`

```bash
git checkout main
git pull --ff-only
git push origin main
git tag vX.Y.Z
git push origin vX.Y.Z
```

The GitHub Actions workflow validates tag/version match, runs tests, builds artifacts, and publishes via PyPI Trusted Publishing.
