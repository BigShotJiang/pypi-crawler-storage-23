# Migration Guide: v0.5

This version introduces contract and configuration changes.

## Breaking Changes

1. `get_l2(as_ticks=False)` now returns `NaN` for missing prices.
2. `L2Snapshot` now includes `bid_px_valid` and `ask_px_valid` masks.
3. `StepResult` fields changed:
   - added: `events_user`, `events_synthetic`, `events_total`
   - `events_processed` remains as compatibility alias to `events_user`.
4. Config type checks are strict for policies and nested configs.

## New Features

- Partial cancel controls in `CancelConfig`:
  - `partial_cancel_prob`
  - `partial_min_ratio`
- Intraday regime multipliers via `RegimeConfig` and `RegimeSegment`.

## Migration Steps

1. Replace code that relied on negative scaled price sentinels with `NaN` checks:
   - use `np.isnan(...)` for `as_ticks=False`
   - use `*_px_valid` masks when available.
2. If you consumed `StepResult.events_processed`, keep usage as-is or migrate to `events_user`.
3. Validate custom configs now that runtime type checks are strict.
4. Update reproducibility baselines if you enable partial cancel or regime multipliers.
