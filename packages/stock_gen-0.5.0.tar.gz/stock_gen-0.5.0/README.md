# stock-gen

Language: English (canonical) | [한국어](README.ko.md)

`stock-gen` is an event-driven limit order book simulator for virtual stock market experiments.
It models placement, cancellation (including partial cancel), replace, and market events on a single-asset CLOB.

## Requirements

- Python >= 3.11

## Install

```bash
python -m pip install stock-gen
```

For local development:

```bash
python -m pip install -e '.[dev]'
```

## Quickstart

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## What Changed In v0.5

- `get_l2(as_ticks=False)` now encodes missing prices as `NaN`.
- `L2Snapshot` now includes `bid_px_valid` / `ask_px_valid` masks.
- `StepResult` now exposes `events_user`, `events_synthetic`, `events_total`.
- `StepResult.events_processed` is kept as a backward-compatible alias of `events_user`.
- Config now supports partial cancel controls (`partial_cancel_prob`, `partial_min_ratio`) and intraday regime multipliers.

## Documentation Map

### User Docs

- [docs/api.md](docs/api.md)
- [docs/config-reference.md](docs/config-reference.md)
- [docs/data-contract.md](docs/data-contract.md)
- [docs/reproducibility.md](docs/reproducibility.md)

### Maintainer Docs

- [docs/architecture.md](docs/architecture.md)
- [docs/release.md](docs/release.md)
- [docs/archive/migration-v0.3.md](docs/archive/migration-v0.3.md)
- [docs/archive/migration-v0.5.md](docs/archive/migration-v0.5.md)
