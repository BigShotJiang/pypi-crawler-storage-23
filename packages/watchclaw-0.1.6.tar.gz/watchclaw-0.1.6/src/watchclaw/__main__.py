"""Allow running as python -m watchclaw."""

from watchclaw.cli import main

main()
