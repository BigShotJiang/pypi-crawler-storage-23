"""WatchClaw - AI Agent runtime security monitor."""

__version__ = "0.1.0"
