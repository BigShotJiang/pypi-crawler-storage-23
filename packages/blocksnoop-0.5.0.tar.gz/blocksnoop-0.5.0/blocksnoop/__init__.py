"""blocksnoop — detect blocking calls in asyncio event loops using eBPF + py-spy."""

__version__ = "0.5.0"
