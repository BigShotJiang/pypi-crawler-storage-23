"""TUI screen widgets for tokenmeter."""
