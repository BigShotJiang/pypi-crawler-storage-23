"""
Supyagent — cloud integrations for AI agents.
"""

__version__ = "0.6.1"
