# Goals

## User Goals
<!-- Define what you want to achieve. The agent reads this on every conversation. -->

- test

## Subgoals
<!-- Managed by the assistant. The agent can append subgoals here but will never modify User Goals. -->
