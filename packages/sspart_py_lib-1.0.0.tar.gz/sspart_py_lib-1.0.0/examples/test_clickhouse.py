import os

from sspart_py_lib import ClickHouseClient


def main() -> None:
    host = os.getenv("CLICKHOUSE_HOST", "localhost")
    port = int(os.getenv("CLICKHOUSE_PORT", "8123"))
    username = os.getenv("CLICKHOUSE_USER", "app")
    password = os.getenv("CLICKHOUSE_PASSWORD", "app123")
    database = os.getenv("CLICKHOUSE_DATABASE", "market")
    secure = os.getenv("CLICKHOUSE_SECURE", "false").lower() in {"1", "true", "yes"}

    client = ClickHouseClient(
        host=host,
        port=port,
        username=username,
        password=password,
        database=database,
        secure=secure,
    )

    result = client.query('SELECT * FROM "market"."history" LIMIT 100')
    print("ClickHouse connection OK. Version:", result.result_rows)


if __name__ == "__main__":
    main()
