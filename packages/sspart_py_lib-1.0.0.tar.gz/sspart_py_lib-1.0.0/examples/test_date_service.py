from datetime import datetime
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from sspart_py_lib import DateService


def main() -> None:
    base = datetime(2026, 2, 25, 14, 30, 45)
    date_service = DateService()

    print("get_date_plus_milliseconds:", date_service.get_date_plus_milliseconds(base, 1500))
    print("get_date_plus_days:", date_service.get_date_plus_days(base, 3))
    print("get_date_without_time_from_unix:", date_service.get_date_without_time_from_unix(1741171200))
    print("date_formatter:", date_service.date_formatter(base, "DD-MMM-YYYY HH:mm:ss"))
    print("parse_custom_date:", date_service.parse_custom_date("07MAR2025"))
    print("get_current_date_without_time:", date_service.get_current_date_without_time())


if __name__ == "__main__":
    main()
