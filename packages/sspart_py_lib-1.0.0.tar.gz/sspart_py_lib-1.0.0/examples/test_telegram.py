import asyncio
import os
import sys
from pathlib import Path

from dotenv import load_dotenv

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
load_dotenv(Path(__file__).resolve().parents[1] / ".env")

from sspart_py_lib import TelegramClient

async def main() -> None:
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")

    if not token:
        print("Set TELEGRAM_BOT_TOKEN first.")
        return

    client = TelegramClient(token=token)
    bot_info = await client.get_me()
    print("Telegram bot authenticated as:", bot_info.username)

    if chat_id:
        response = await client.send_text(chat_id=chat_id, text="Hello from sspart-py-lib")
        print("Message sent. Message ID:", response.message_id)

        response = await client.send_photo(
            chat_id=chat_id,
            photo="/Users/sunnysabhanam/Downloads/EmptyGroup.png",
            caption="Hello from sspart-py-lib",
        )
        print("Photo sent. Message ID:", response.message_id)

        response = await client.send_media_group(
            chat_id=chat_id,
            data=[
                {
                    "photo": "/Users/sunnysabhanam/Downloads/EmptyGroup.png",
                    "caption": "Hello from sspart-py-lib",
                },
                {
                    "photo": "/Users/sunnysabhanam/Downloads/EmptyInsts.png",
                    "caption": "Hello from sspart-py-lib",
                },
            ],
        )
        print("Media group sent. Items:", len(response))
    else:
        print("Set TELEGRAM_CHAT_ID to also send photo/media group test messages.")


if __name__ == "__main__":
    asyncio.run(main())
