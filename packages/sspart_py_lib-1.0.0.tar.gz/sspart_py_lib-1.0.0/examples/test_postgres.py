import os

from sspart_py_lib import PostgresClient


def main() -> None:
    dsn = os.getenv("POSTGRES_DSN", 'postgresql://postgres:postgres@localhost:5432/int-trade')
    if not dsn:
        print("Set POSTGRES_DSN first, for example:")
        print("export POSTGRES_DSN='postgresql://user:pass@localhost:5432/dbname'")
        return

    client = PostgresClient(dsn=dsn)
    row = client.fetch_one("SELECT * from instruments LIMIT 1;")
    print("PostgreSQL connection OK. Current time:", row)


if __name__ == "__main__":
    main()
