from importlib import import_module
from typing import TYPE_CHECKING

__all__ = [
	"PostgresClient",
	"PostgresExecutionResult",
	"ClickHouseClient",
	"TelegramClient",
	"DateService",
]
__version__ = "0.1.0"

if TYPE_CHECKING:
	from .clickhouse import ClickHouseClient
	from .date_service import DateService
	from .postgres import PostgresClient, PostgresExecutionResult
	from .telegram import TelegramClient


_LAZY_EXPORTS = {
	"PostgresClient": (".postgres", "PostgresClient"),
	"PostgresExecutionResult": (".postgres", "PostgresExecutionResult"),
	"ClickHouseClient": (".clickhouse", "ClickHouseClient"),
	"TelegramClient": (".telegram", "TelegramClient"),
	"DateService": (".date_service", "DateService"),
}


def __getattr__(name: str):
	module_info = _LAZY_EXPORTS.get(name)
	if module_info is not None:
		module_name, symbol_name = module_info
		module = import_module(module_name, package=__name__)
		return getattr(module, symbol_name)
	raise AttributeError(f"module 'sspart_py_lib' has no attribute '{name}'")
