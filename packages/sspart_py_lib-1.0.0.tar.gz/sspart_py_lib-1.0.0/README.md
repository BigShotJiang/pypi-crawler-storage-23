# sspart-py-lib

Reusable Python library package for:
- PostgreSQL
- ClickHouse
- Telegram

## 1) Create virtual environment and install locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

## 2) Use in another project

### Option A: install from local path
```bash
pip install /absolute/path/to/sspart-py-lib
```

### Option B: install in editable mode during development
```bash
pip install -e /absolute/path/to/sspart-py-lib
```

## 3) Quick usage

```python
from sspart_py_lib import PostgresClient, ClickHouseClient, TelegramClient

pg = PostgresClient("postgresql://user:pass@localhost:5432/app")
result = pg.execute("INSERT INTO events(name) VALUES (%s)", ("boot",))
print(result.rowcount, result.status_message)
rows = pg.fetch_all("SELECT NOW()")

ch = ClickHouseClient(host="localhost", port=8123, username="default", password="")
result = ch.query("SELECT version()")

bot = TelegramClient("<telegram-bot-token>")
# await bot.send_text(chat_id=123456, text="Hello from sspart-py-lib")
```

## Project structure

```text
sspart-py-lib/
  pyproject.toml
  README.md
  src/
    sspart_py_lib/
      __init__.py
      postgres.py
      clickhouse.py
      telegram.py
```

## Next improvements (later)
- Add retries / timeouts configuration
- Add connection pooling
- Add structured logging
- Add integration tests with Docker
