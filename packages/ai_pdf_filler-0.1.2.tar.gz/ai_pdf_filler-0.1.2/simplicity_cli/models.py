from __future__ import annotations

from dataclasses import dataclass
from typing import Any


JSONDict = dict[str, Any]


@dataclass(frozen=True)
class GlobalOptions:
    api_key: str | None
    json_output: bool
    request_timeout_seconds: float


@dataclass(frozen=True)
class DownloadResolution:
    url: str | None
    form_payload: JSONDict | None = None
    document_payload: JSONDict | None = None
