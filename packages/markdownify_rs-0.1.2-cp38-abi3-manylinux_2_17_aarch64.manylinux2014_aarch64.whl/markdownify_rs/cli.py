import argparse
import sys

from . import markdownify, ATX, ATX_CLOSED, UNDERLINED, SPACES, BACKSLASH, ASTERISK, UNDERSCORE


def _optional_bool(parser, name: str, default, help_text: str) -> None:
    dest_name = name.replace("-", "_")
    parser.add_argument(
        f"--{name}",
        dest=dest_name,
        action="store_true",
        default=default,
        help=help_text,
    )
    parser.add_argument(
        f"--no-{name}",
        dest=dest_name,
        action="store_false",
        help=f"Disable {help_text.lower()}",
    )


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="markdownify-rs",
        description="Converts HTML to Markdown.",
    )

    parser.add_argument(
        "html",
        nargs="?",
        type=argparse.FileType("r"),
        default=sys.stdin,
        help="The HTML file to convert. Defaults to STDIN if not provided.",
    )
    parser.add_argument(
        "-s",
        "--strip",
        nargs="*",
        help="A list of tags to strip. This option can't be used with --convert.",
    )
    parser.add_argument(
        "-c",
        "--convert",
        nargs="*",
        help="A list of tags to convert. This option can't be used with --strip.",
    )

    _optional_bool(
        parser,
        "autolinks",
        None,
        "Use automatic link style when tag contents match the href.",
    )
    parser.add_argument(
        "--default-title",
        dest="default_title",
        action="store_true",
        default=None,
        help="Use the link href as its title when no title is given.",
    )
    parser.add_argument(
        "--heading-style",
        default=None,
        choices=(ATX, ATX_CLOSED, UNDERLINED),
        help="Defines how headings should be converted.",
    )
    parser.add_argument(
        "-b",
        "--bullets",
        default=None,
        help="A string of bullet styles to use; the bullet alternates by nesting level.",
    )
    parser.add_argument(
        "--strong-em-symbol",
        default=None,
        choices=(ASTERISK, UNDERSCORE),
        help="Use * or _ to convert strong and italics text.",
    )
    parser.add_argument("--sub-symbol", default=None, help="Chars that surround <sub>.")
    parser.add_argument("--sup-symbol", default=None, help="Chars that surround <sup>.")
    parser.add_argument(
        "--newline-style",
        default=None,
        choices=(SPACES, BACKSLASH),
        help="Defines the style of <br> conversions.",
    )
    parser.add_argument(
        "--code-language",
        default=None,
        help="Language to assume for all <pre> sections.",
    )
    parser.add_argument(
        "--no-escape-asterisks",
        dest="escape_asterisks",
        action="store_false",
        default=None,
        help="Do not escape '*' to '\\\\*' in text.",
    )
    parser.add_argument(
        "--no-escape-underscores",
        dest="escape_underscores",
        action="store_false",
        default=None,
        help="Do not escape '_' to '\\\\_' in text.",
    )
    parser.add_argument(
        "--escape-misc",
        dest="escape_misc",
        action="store_true",
        default=None,
        help="Escape additional Markdown special characters.",
    )
    parser.add_argument(
        "-i",
        "--keep-inline-images-in",
        default=None,
        nargs="*",
        help="Allow inline images inside the listed parent tags.",
    )
    parser.add_argument(
        "--table-infer-header",
        dest="table_infer_header",
        action="store_true",
        default=None,
        help="Infer a header row from the first body row if none is present.",
    )
    parser.add_argument(
        "-w",
        "--wrap",
        action="store_true",
        default=None,
        help="Wrap all text paragraphs at --wrap-width characters.",
    )
    parser.add_argument("--wrap-width", type=int, default=None)
    parser.add_argument(
        "--strip-document",
        default=None,
        choices=("lstrip", "rstrip", "strip", "none"),
        help="Strip whitespace around the document (use 'none' to disable).",
    )
    parser.add_argument(
        "--strip-pre",
        default=None,
        choices=("strip", "strip_one", "none"),
        help="Strip newlines around <pre> blocks (use 'none' to disable).",
    )

    args = parser.parse_args(argv)

    if args.strip is not None and args.convert is not None:
        parser.error("You may specify either tags to strip or tags to convert, but not both.")

    kwargs = {}
    if args.strip is not None:
        kwargs["strip"] = args.strip
    if args.convert is not None:
        kwargs["convert"] = args.convert

    for name in (
        "autolinks",
        "default_title",
        "heading_style",
        "bullets",
        "strong_em_symbol",
        "sub_symbol",
        "sup_symbol",
        "newline_style",
        "code_language",
        "escape_asterisks",
        "escape_underscores",
        "escape_misc",
        "keep_inline_images_in",
        "table_infer_header",
        "wrap",
        "wrap_width",
    ):
        value = getattr(args, name)
        if value is not None:
            kwargs[name] = value

    if args.strip_document is not None:
        kwargs["strip_document"] = None if args.strip_document == "none" else args.strip_document
    if args.strip_pre is not None:
        kwargs["strip_pre"] = None if args.strip_pre == "none" else args.strip_pre

    html = args.html.read()
    output = markdownify(html, **kwargs)
    sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
