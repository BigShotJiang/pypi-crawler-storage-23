from typing import Annotated

from rapid_api_client import Path, Query

from remnawave.models import GetUserUsageByRangeResponseDto
from remnawave.rapid import BaseController, get

