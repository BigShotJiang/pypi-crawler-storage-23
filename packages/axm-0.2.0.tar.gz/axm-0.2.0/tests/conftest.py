"""Shared pytest fixtures."""
