from pathlib import Path

info = (
    "Added localization attributes to summary observations."
    "Added RFT observations."
    "No change to current storage, only additions. "
)


def migrate(path: Path) -> None:
    pass
