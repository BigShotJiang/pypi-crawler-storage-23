from enum import StrEnum


class WorkflowKeys(StrEnum):
    DEFINE = "DEFINE"
