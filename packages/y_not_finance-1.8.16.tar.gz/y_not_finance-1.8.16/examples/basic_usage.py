"""
Basic example showing how to use Y-Not-Finance.

This example demonstrates the most common use cases:
- Fetching data for a single ticker
- Fetching data for multiple tickers
- Selecting specific fields
"""

import sys
from pathlib import Path

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from y_not_finance import YahooFinanceClient


def main():
    # Initialize the API client
    api = YahooFinanceClient()
    
    # Example 1: Single ticker, default settings (adjclose, 1d interval)
    print("=" * 60)
    print("Example 1: Single ticker with default settings")
    print("=" * 60)
    df = api.get_prices("AAPL", range_str="1mo")
    print(df.head())
    print(f"\nShape: {df.shape}\n")
    
    # Example 2: Single ticker, specific field, custom range
    print("=" * 60)
    print("Example 2: Single ticker with closing prices (3 months)")
    print("=" * 60)
    df = api.get_prices("AAPL", range_str="3mo", fields="close")
    print(df.head())
    print(f"Shape: {df.shape}\n")
    
    # Example 3: Multiple tickers, single field
    print("=" * 60)
    print("Example 3: Multiple tickers with adjusted close")
    print("=" * 60)
    tickers = ["AAPL", "MSFT", "GOOGL"]
    df = api.get_prices(tickers, range_str="6mo", fields="adjclose")
    print(df.head())
    print(f"Shape: {df.shape}\n")
    
    # Example 4: Multiple tickers, multiple fields (OHLCV)
    print("=" * 60)
    print("Example 4: OHLCV data for multiple tickers")
    print("=" * 60)
    df = api.get_prices(
        tickers,
        range_str="1y",
        interval="1d",
        fields=["open", "high", "low", "close", "volume"]
    )
    print(df.head())
    print(f"Shape: {df.shape}\n")
    
    # Example 5: All available data (no range filter)
    print("=" * 60)
    print("Example 5: All available historical data")
    print("=" * 60)
    df = api.get_prices("AAPL", interval="1d", fields="close")
    print(f"Data from {df.index[0]} to {df.index[-1]}")
    print(f"Total records: {len(df)}\n")


if __name__ == "__main__":
    main()
