"""
Example showing financial analysis workflows.

This example demonstrates:
- Calculating returns (simple, log, percentage)
- Computing statistics
- Correlation analysis
- Data normalization
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from y_not_finance import YahooFinanceClient


def main():
    api = YahooFinanceClient(max_workers=5, rate_limit_delay=0.2)
    
    # Fetch data for multiple tech stocks
    tickers = ["AAPL", "MSFT", "GOOGL", "TSLA"]
    df = api.get_prices(tickers, range_str="1y", interval="1d", fields="adjclose")
    
    # Example 1: Simple Returns
    print("=" * 60)
    print("Example 1: Simple Returns (daily % change)")
    print("=" * 60)
    simple_returns = df.pct_change()
    print("First 5 days of returns:")
    print(simple_returns.head())
    print(f"\nMean daily returns (%):")
    print((simple_returns.mean() * 100).round(3))
    print(f"\nDaily volatility (%):")
    print((simple_returns.std() * 100).round(3), "\n")
    
    # Example 2: Log Returns
    print("=" * 60)
    print("Example 2: Log Returns")
    print("=" * 60)
    log_returns = pd.DataFrame(np.log(df / df.shift(1)), index=df.index, columns=df.columns)
    print("First 5 days of log returns:")
    print(log_returns.head())
    print(f"\nMean log returns (%):")
    print((log_returns.mean() * 100).round(3), "\n")
    
    # Example 3: Annualized Volatility
    print("=" * 60)
    print("Example 3: Annualized Volatility")
    print("=" * 60)
    daily_returns = df.pct_change()
    annualized_vol = daily_returns.std() * np.sqrt(252)  # 252 trading days
    print("Annualized volatility (%):")
    print((annualized_vol * 100).round(2))
    print()
    
    # Example 4: Correlation Matrix
    print("=" * 60)
    print("Example 4: Correlation Matrix")
    print("=" * 60)
    correlation = daily_returns.corr()
    print("Correlation between stocks:")
    print(correlation.round(3))
    print()
    
    # Example 5: Cumulative Returns
    print("=" * 60)
    print("Example 5: Cumulative Returns (Normalized to 100)")
    print("=" * 60)
    df_normalized = (df / df.iloc[0]) * 100
    print("Normalized prices (starting at 100):")
    print(df_normalized.head())
    print("\nEnding prices:")
    print(df_normalized.tail(1).T)
    print("\nTotal return (%):")
    print(((df_normalized.iloc[-1] / 100 - 1) * 100).round(2))
    print()
    
    # Example 6: Basic Statistics
    print("=" * 60)
    print("Example 6: Summary Statistics for Returns")
    print("=" * 60)
    returns = df.pct_change()
    print(returns.describe().round(4))
    print()
    
    # Example 7: Sharpe Ratio (assuming 5% risk-free rate)
    print("=" * 60)
    print("Example 7: Sharpe Ratio")
    print("=" * 60)
    risk_free_rate = 0.05 / 252  # Daily risk-free rate
    excess_returns = daily_returns - risk_free_rate
    sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(252)
    print("Sharpe Ratio (assuming 5% annual risk-free rate):")
    print(sharpe_ratio.round(3))


if __name__ == "__main__":
    main()
