"""
Example usage demonstrating the Y-Not-Finance package capabilities.
"""

import logging
import time
import sys
from pathlib import Path

# Ensure local package is used when running from repo
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from y_not_finance import YahooFinanceClient, get_constituents

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Demonstrate usage of both prices and constituents modules."""
    
    # ==================== PRICES EXAMPLES ====================
    logger.info("="*60)
    logger.info("PRICES MODULE EXAMPLES")
    logger.info("="*60)
    
    # Initialize the client
    client = YahooFinanceClient(max_workers=5, rate_limit_delay=0.2)
    
    # Example 1: Single ticker, single field
    logger.info("\n--- Example 1: Single ticker with adjusted close ---")
    df = client.get_prices("AAPL", range_str="1mo")
    print(df.head())
    print(f"Shape: {df.shape}")
    
    # Example 2: Multiple tickers, single field
    logger.info("\n--- Example 2: Multiple tickers with close price ---")
    tickers = ["AAPL", "MSFT", "GOOGL"]
    df = client.get_prices(
        tickers,
        range_str="5d",
        interval="1d",
        fields="close"
    )
    print(df.tail())
    print(f"Shape: {df.shape}")
    
    # Example 3: Multiple tickers, multiple fields
    logger.info("\n--- Example 3: Multiple tickers with OHLCV data ---")
    df = client.get_prices(
        tickers,
        range_str="1mo",
        interval="1d",
        fields=["open", "high", "low", "close", "volume"]
    )
    print(df.head())
    print(f"Shape: {df.shape}")
    
    # ==================== CONSTITUENTS EXAMPLES ====================
    logger.info("\n" + "="*60)
    logger.info("CONSTITUENTS MODULE EXAMPLES")
    logger.info("="*60)
    
    # Example 4: Get S&P 500 constituents
    logger.info("\n--- Example 4: S&P 500 constituents ---")
    start = time.time()
    tickers_dict = get_constituents(
        "^SPX",
        include_benchmark=True,
        info=True,
        description=True
    )
    elapsed = time.time() - start
    
    print(f"\nFetched {len(tickers_dict)} tickers in {elapsed:.2f} seconds")
    print(f"First 5 tickers: {dict(list(tickers_dict.items())[:5])}")
    
    # Example 5: Get TSX constituents
    logger.info("\n--- Example 5: TSX Composite constituents ---")
    tickers_dict = get_constituents(
        "^GSPTSE",
        info=True
    )
    print(f"TSX has {len(tickers_dict)} constituents")
    
    # ==================== COMBINED EXAMPLE ====================
    logger.info("\n" + "="*60)
    logger.info("COMBINED EXAMPLE: Fetch constituents then get their prices")
    logger.info("="*60)
    
    # Get mega cap stocks
    logger.info("\n--- Example 6: Mega caps with price data ---")
    megacap_tickers = get_constituents("megacaps", info=True)
    
    # Get prices for first 5 mega cap stocks
    sample_tickers = list(megacap_tickers.keys())[:5]
    logger.info(f"\nFetching prices for: {sample_tickers}")
    
    df = client.get_prices(
        sample_tickers,
        range_str="1mo",
        fields="adjclose"
    )
    print(f"\nPrice data shape: {df.shape}")
    print(df.tail())
    
    logger.info("\n" + "="*60)
    logger.info("Examples completed successfully!")
    logger.info("="*60)


if __name__ == "__main__":
    main()
