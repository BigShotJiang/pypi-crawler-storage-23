"""Bump patch version in _version.py"""

import re
from pathlib import Path


def bump_version(version_str: str) -> str:
    """Bump patch version. E.g., 1.7.0 -> 1.7.1"""
    parts = version_str.split(".")
    parts[-1] = str(int(parts[-1]) + 1)
    return ".".join(parts)


def main():
    version_file = Path("y_not_finance/_version.py")
    content = version_file.read_text()
    
    # Extract current version
    match = re.search(r'__version__ = "([^"]+)"', content)
    if not match:
        raise ValueError("Could not find version in _version.py")
    
    current = match.group(1)
    new_version = bump_version(current)
    
    # Update file
    new_content = re.sub(
        r'__version__ = "[^"]+"',
        f'__version__ = "{new_version}"',
        content
    )
    version_file.write_text(new_content)
    
    print(f"Bumped version: {current} -> {new_version}")


if __name__ == "__main__":
    main()
