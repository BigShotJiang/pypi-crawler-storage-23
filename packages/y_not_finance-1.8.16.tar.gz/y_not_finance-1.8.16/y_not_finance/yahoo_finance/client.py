"""
Main client for fetching Yahoo Finance data.
"""

import logging
from typing import Union, List, Optional
import pandas as pd

from .core import YahooFinanceHTTPClient, utils
from .events.parser import extract_events
from .prices.constants import SHORT_INTERVALS, LONG_INTERVALS
from .prices.parser import extract_prices
from .prices.processor import process_dataframe

logger = logging.getLogger(__name__)


class YahooFinanceClient:
    """
    A client for fetching financial data from Yahoo Finance API.

    Features:
    - Multi-ticker concurrent fetching
    - Automatic retry with exponential backoff
    - Flexible date range filtering
    - Support for intraday and daily data
    - Price and corporate events data
    """

    def __init__(
        self,
        max_workers: int = 10,
        rate_limit_delay: float = 0.1,
        timeout: int = 10,
        max_retries: int = 5
    ):
        """
        Initialize the Yahoo Finance API client.

        Args:
            max_workers: Maximum number of concurrent API requests
            rate_limit_delay: Delay between requests in seconds
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts for failed requests
        """
        self.fetcher = YahooFinanceHTTPClient(
            max_workers=max_workers,
            rate_limit_delay=rate_limit_delay,
            timeout=timeout,
            max_retries=max_retries
        )

    def get_prices(
        self,
        tickers: Union[str, List[str]],
        range_str: Optional[str] = None,
        interval: str = "1d",
        fields: Optional[Union[str, List[str]]] = None
    ) -> pd.DataFrame:
        """
        Fetch price data for one or more tickers.

        This method fetches the maximum available data for the specified interval,
        then filters it based on the range_str parameter. Data is fetched concurrently
        for multiple tickers to optimize performance.

        Args:
            tickers: Single ticker string or list of ticker symbols
            range_str: Date range to filter (e.g., '1d', '5d', '1mo', '3mo', '50y').
                      If None, returns all available data.
            interval: Data interval - intraday: '1m', '5m', '15m', '30m', '1h'
                     or daily+: '1d', '5d', '1wk', '1mo', '3mo'
            fields: Field(s) to extract. Can be string or list.
                   Available: 'open', 'high', 'low', 'close', 'volume', 'adjclose'
                   Default: 'adjclose'

        Returns:
            DataFrame with datetime index and price data. For single field and multiple
            tickers, columns are ticker names. For multiple fields, MultiIndex columns
            with (ticker, field) pairs.
        """
        # Normalize tickers to list
        if isinstance(tickers, str):
            tickers = [tickers]

        # Validate interval
        all_intervals = {**SHORT_INTERVALS, **LONG_INTERVALS}
        if interval not in all_intervals:
            logger.error(
                f"Unsupported interval: '{interval}'. "
                f"Supported: {list(all_intervals.keys())}"
            )
            return pd.DataFrame()

        # Get maximum range for interval
        max_range_str = all_intervals[interval]

        # Warn if requested range exceeds available range for this interval
        if range_str:
            try:
                requested_delta = utils.parse_range_str(range_str)
                max_delta = utils.parse_range_str(max_range_str)
                if requested_delta > max_delta:
                    logger.warning(
                        f"Requested range '{range_str}' exceeds maximum available for "
                        f"interval '{interval}' ({max_range_str}). "
                        f"Will return data for {max_range_str} instead."
                    )
            except ValueError:
                pass  # Invalid range_str will be handled later

        # Fetch data concurrently
        raw_json_data = self.fetcher.fetch_concurrent(tickers, max_range_str, interval)

        if not raw_json_data:
            logger.warning("No data fetched for any ticker")
            return pd.DataFrame()

        # Extract prices from raw data
        prices_dict = {}
        for ticker, raw_json in raw_json_data.items():
            try:
                prices = extract_prices(raw_json, interval, fields)
                if not prices.empty:
                    prices_dict[ticker] = prices
            except Exception as e:
                logger.error(f"Error processing data for {ticker}: {e}")

        if not prices_dict:
            logger.warning("No valid price data extracted")
            return pd.DataFrame()

        # Concatenate and process data
        df_prices = process_dataframe(prices_dict, interval, range_str)

        return df_prices

    def get_events(
        self,
        tickers: Union[str, List[str]],
        range_str: str = "10y",
        event_type: str = "dividends"
    ) -> pd.DataFrame:
        """
        Fetch corporate events data for one or more tickers.

        Args:
            tickers: Single ticker string or list of ticker symbols
            range_str: Date range to fetch (e.g., '1y', '5y', '10y', 'max')
                      Default: '10y'
            event_type: Type of event to extract (string only).
                       Available: 'dividends', 'splits'
                       Default: 'dividends'

        Returns:
            DataFrame with date as index and ticker symbols as columns.
            For single ticker, column is the ticker name.
            For multiple tickers, each ticker is a separate column.
        """
        # Normalize tickers to list
        if isinstance(tickers, str):
            tickers = [tickers]

        # Events are only available with daily data
        interval = "1d"

        # Fetch data concurrently
        raw_json_data = self.fetcher.fetch_concurrent(tickers, range_str, interval)

        if not raw_json_data:
            logger.warning("No data fetched for any ticker")
            return pd.DataFrame()

        # Extract events from raw data
        ticker_frames = {}
        for ticker, raw_json in raw_json_data.items():
            try:
                df = extract_events(raw_json, event_type)
                if not df.empty:
                    ticker_frames[ticker] = df
            except Exception as e:
                logger.error(f"Error processing events for {ticker}: {e}")

        if not ticker_frames:
            logger.warning("No valid events data extracted")
            return pd.DataFrame()

        # Concatenate with date as index, tickers as columns
        result = pd.concat(ticker_frames, axis=1, sort=True)

        # Flatten MultiIndex columns - keep only ticker names
        if isinstance(result.columns, pd.MultiIndex):
            result.columns = result.columns.get_level_values(0)

        # Fill missing values with 0 for dividends, NaN for splits
        if event_type.lower() == "dividends":
            result = result.fillna(0.0)

        df_events = utils.format_as_daily(result.sort_index())

        df_events.columns.name = event_type.capitalize()
        df_events.index.name = 'Date'

        return df_events
