"""
Parser for extracting events data from Yahoo Finance JSON responses.
"""

import logging
import pandas as pd
from typing import Dict, Any, Optional, Union, List

logger = logging.getLogger(__name__)

SUPPORTED_EVENT_TYPES = {
    'dividends',
    'splits'
}


def extract_events(
    raw_json: Dict[str, Any],
    event_type: str = "dividends"
) -> pd.DataFrame:
    """
    Extract events data from Yahoo Finance JSON response.
    
    The events are located at a different JSON path than prices:
    - Prices: chart.result[0].indicators.quote[0]
    - Events: chart.result[0].events
    
    Args:
        raw_json: Raw JSON response from Yahoo Finance API
        event_type: Type of event to extract (string only).
                   Available: 'dividends', 'splits'
                   Default: 'dividends'
                    
    Returns:
        DataFrame with datetime index containing the requested event data
        
    Raises:
        ValueError: If JSON structure is invalid or missing required fields
    """
    try:
        result = raw_json['chart']['result'][0]
    except (KeyError, IndexError, TypeError) as e:
        raise ValueError(f"Invalid JSON structure: {e}")
    
    # Check if events exist
    if 'events' not in result or not result['events']:
        logger.info("No events data available in response")
        return pd.DataFrame()
    
    events_data = result['events']
    # import pprint
    # pprint.pprint(events_data)
    
    # Normalize event_type (lowercase)
    normalized_type = event_type.lower()
    
    # Validate event type
    if normalized_type not in SUPPORTED_EVENT_TYPES:
        logger.warning(
            "Invalid event type: %s. Supported types: %s",
            event_type,
            sorted(SUPPORTED_EVENT_TYPES)
        )
        return pd.DataFrame()
    
    # Check if the requested event type exists in data
    if normalized_type not in events_data:
        logger.info(f"No {normalized_type} data available in response")
        return pd.DataFrame()
    
    events = events_data[normalized_type]
    if not events:
        return pd.DataFrame()
    
    # Parse events into records with event-specific value extraction
    records = []
    for timestamp, event_info in events.items():
        # Extract value based on event type
        if normalized_type == 'dividends':
            value = event_info.get('amount', 0.0)
        elif normalized_type == 'splits':
            numerator = event_info.get('numerator', 1)
            denominator = event_info.get('denominator', 1)
            value = numerator / denominator if denominator != 0 else 0.0
        else:
            # Should not reach here as we validate event type above
            value = None
        
        record = {
            'date': pd.to_datetime(int(timestamp), unit='s'),
            'value': value
        }
        records.append(record)
    
    if not records:
        return pd.DataFrame()
    
    # Create DataFrame with date index
    df = pd.DataFrame(records)
    
    # Explicitly convert date column to datetime before setting as index
    df['date'] = pd.to_datetime(df['date'], unit='s')
    df.set_index('date', inplace=True)
    df.index.name = 'Date'

    column_name = normalized_type
    df = df.rename(columns={'value': column_name})

    return df


