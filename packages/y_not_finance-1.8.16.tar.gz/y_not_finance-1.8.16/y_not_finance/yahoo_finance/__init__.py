"""
Yahoo Finance provider module.

This module provides access to Yahoo Finance data including:
- Prices: Historical and intraday price data
- Events: Corporate events (dividends, splits, earnings)
"""

from .client import YahooFinanceClient

__all__ = ['YahooFinanceClient']
