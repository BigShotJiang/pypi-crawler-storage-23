"""Package version."""

__version__ = "1.8.16"
