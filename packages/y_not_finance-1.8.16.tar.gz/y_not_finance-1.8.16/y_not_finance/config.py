"""Secure configuration management for API keys and credentials."""

import os
from pathlib import Path
from typing import Optional

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


def load_env() -> None:
    """Load environment variables from .env file if python-dotenv is installed."""
    if load_dotenv is None:
        return

    env_path = Path.home() / ".env"
    if env_path.exists():
        load_dotenv(env_path)
    
    local_env = Path(".env.local")
    if local_env.exists():
        load_dotenv(local_env)


def get_api_token(name: str, default: Optional[str] = None) -> str:
    """
    Securely retrieve an API token from environment variables.
    
    Supports multiple sources in order of precedence:
    1. Environment variable (e.g., PYPI_API_TOKEN)
    2. ~/.env file
    3. .env.local file  
    4. Default value if provided
    
    Args:
        name: API key name (e.g., 'PYPI_API_TOKEN', 'WRDS_USERNAME')
        default: Fallback value if not found
        
    Returns:
        API token value
        
    Raises:
        ValueError: If token not found and no default provided
        
    Examples:
        >>> token = get_api_token('PYPI_API_TOKEN')
        >>> wrds_user = get_api_token('WRDS_USERNAME', default='guest')
    """
    load_env()
    
    token = os.getenv(name.upper(), default)
    
    if token is None:
        raise ValueError(
            f"API token '{name}' not found. Set it in environment variables or .env file"
        )
    
    return token


__all__ = ["load_env", "get_api_token"]
