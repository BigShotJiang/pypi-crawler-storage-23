import os
from pathlib import Path
from typing import Any

import yaml
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    YamlConfigSettingsSource,
)

__all__ = ['EnhancedYamlConfigSettingsSource', 'BaseYamlSettings']


def _deep_merge(target: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    """递归合并字典"""

    for key, value in source.items():
        if key in target and isinstance(target[key], dict) and isinstance(value, dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value

    return target


class EnhancedYamlConfigSettingsSource(YamlConfigSettingsSource):
    """
    增强版 YAML 配置源。

    特性:
    1. 环境变量插值: ${VAR} 或 $VAR (基于 os.path.expandvars)
    2. 多文件深度合并: 后加载的文件递归覆盖前者
    3. 严格的错误处理: 格式错误直接抛出异常
    """

    def __init__(self, settings_cls: type[BaseSettings]) -> None:
        super().__init__(settings_cls)

    def __call__(self) -> dict[str, Any]:
        yaml_files_config = self.config.get('yaml_file')
        encoding = self.config.get('yaml_file_encoding', 'utf-8')

        if not yaml_files_config:
            return {}

        # 统一标准化为 list[Path]
        yaml_files: list[Path] = []
        if isinstance(yaml_files_config, str | Path):
            yaml_files.append(Path(yaml_files_config))
        elif isinstance(yaml_files_config, list | tuple):
            yaml_files.extend(Path(f) for f in yaml_files_config)

        combined_config: dict[str, Any] = {}

        for file_path in yaml_files:
            # 策略：如果文件不存在，静默跳过（支持可选配置文件模式）
            if not file_path.exists():
                continue

            # 读取文件：IOError/PermissionError 会直接抛出
            with file_path.open('r', encoding=encoding) as f:
                content = f.read()

            # 1. 环境变量插值
            content_interpolated = os.path.expandvars(content)

            # 2. 解析 YAML：语法错误 (YAMLError) 会直接抛出
            file_config = yaml.safe_load(content_interpolated)

            # 3. 深度合并与类型检查
            if isinstance(file_config, dict):
                _deep_merge(combined_config, file_config)
            elif file_config is None:
                # 空文件视为无配置，安全跳过
                continue
            else:
                # 如果 YAML 内容不是字典（例如是列表或标量），抛出异常
                raise ValueError(
                    f'Config file content must be a dictionary mapping, '
                    f'but got {type(file_config).__name__} in {file_path}'
                )

        return combined_config


class BaseYamlSettings(BaseSettings):
    """
    预配置了增强版 YAML 源的基类。
    """

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            EnhancedYamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )
