"""Type definitions for the Khan Bank payment SDK."""

from dataclasses import dataclass
from typing import Optional

# ============================================================================
# Constants
# ============================================================================

MONGOLIAN_LANGUAGE_CODE = "mn"
ENGLISH_LANGUAGE_CODE = "en"

# ============================================================================
# Configuration
# ============================================================================


@dataclass
class KhanBankConfig:
    """Configuration for the KhanBankClient.

    Attributes:
        endpoint: Khan Bank API base endpoint.
        username: API username.
        password: API password.
        language: Language code (defaults to "mn").
    """

    endpoint: str
    username: str
    password: str
    language: Optional[str] = None

# ============================================================================
# SDK Input/Output Types (user-facing)
# ============================================================================


@dataclass
class OrderRegisterInput:
    """Input for registering a new order.

    Attributes:
        order_number: Merchant order number.
        amount: Payment amount (will be formatted as fixed 2 decimal places).
        success_callback: URL to redirect on successful payment.
        fail_callback: URL to redirect on failed payment.
    """

    order_number: str
    amount: float
    success_callback: str
    fail_callback: str


@dataclass
class RegisterOrderResponse:
    """Response from registering an order.

    Attributes:
        order_id: Order ID assigned by the bank.
        form_url: URL of the payment form to redirect the user to.
    """

    order_id: str
    form_url: str


@dataclass
class OrderStatusResponse:
    """Parsed response from checking order status.

    Attributes:
        success: Whether the payment was successful (orderStatus === "2").
        error_code: Error code from the bank.
        error_message: Error message from the bank.
        order_number: Merchant order number.
        ip: IP address of the payer.
    """

    success: bool
    error_code: str
    error_message: str
    order_number: str
    ip: str
