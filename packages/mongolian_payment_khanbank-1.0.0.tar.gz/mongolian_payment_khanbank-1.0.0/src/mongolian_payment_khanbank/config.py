"""Environment-based configuration loader for Khan Bank SDK."""

import os

from .types import KhanBankConfig


def load_config_from_env() -> KhanBankConfig:
    """Load Khan Bank configuration from environment variables.

    Required environment variables:
        KHANBANK_ENDPOINT - Khan Bank API base URL.
        KHANBANK_USERNAME - API username.
        KHANBANK_PASSWORD - API password.

    Optional environment variables:
        KHANBANK_LANGUAGE - Language code (defaults to "mn").

    Returns:
        A populated KhanBankConfig instance.

    Raises:
        ValueError: If any required variable is missing.
    """
    endpoint = os.environ.get("KHANBANK_ENDPOINT")
    username = os.environ.get("KHANBANK_USERNAME")
    password = os.environ.get("KHANBANK_PASSWORD")
    language = os.environ.get("KHANBANK_LANGUAGE")

    if not endpoint:
        raise ValueError("Missing environment variable: KHANBANK_ENDPOINT")
    if not username:
        raise ValueError("Missing environment variable: KHANBANK_USERNAME")
    if not password:
        raise ValueError("Missing environment variable: KHANBANK_PASSWORD")

    return KhanBankConfig(
        endpoint=endpoint,
        username=username,
        password=password,
        **({"language": language} if language else {}),
    )
