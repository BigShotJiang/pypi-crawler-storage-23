"""Khan Bank payment client implementations (sync and async)."""

import re
from typing import Any, Dict

import httpx

from .errors import KhanBankError
from .types import (
    MONGOLIAN_LANGUAGE_CODE,
    KhanBankConfig,
    OrderRegisterInput,
    OrderStatusResponse,
    RegisterOrderResponse,
)


class KhanBankClient:
    """Khan Bank payment client (synchronous).

    Handles order registration and payment status checks.
    Credentials (username/password) are sent in the request body with every call.
    """

    def __init__(self, config: KhanBankConfig) -> None:
        if not config.endpoint:
            raise ValueError("KhanBankClient: endpoint is required")
        if not config.username:
            raise ValueError("KhanBankClient: username is required")
        if not config.password:
            raise ValueError("KhanBankClient: password is required")

        # Strip trailing slashes for consistent URL building
        self._endpoint = re.sub(r"/+$", "", config.endpoint)
        self._username = config.username
        self._password = config.password
        self._language = config.language or MONGOLIAN_LANGUAGE_CODE
        self._client = httpx.Client()

    # ── Public API ──

    def register_order(self, input: OrderRegisterInput) -> RegisterOrderResponse:
        """Register a new payment order with Khan Bank.

        The amount is formatted as a fixed 2-decimal-place string
        (e.g. 1000 -> "1000.00"). Returns the bank-assigned order ID
        and a payment form URL to redirect the user to.

        Args:
            input: Order registration details.

        Returns:
            A RegisterOrderResponse with order_id and form_url.
        """
        body: Dict[str, Any] = {
            "orderNumber": input.order_number,
            "amount": f"{input.amount:.2f}",
            "returnUrl": input.success_callback,
            "failUrl": input.fail_callback,
            "jsonParams": {"orderNumber": input.order_number},
            "userName": self._username,
            "Password": self._password,
            "language": self._language,
        }

        raw = self._post("/register.do", body)

        return RegisterOrderResponse(
            order_id=raw.get("orderId", ""),
            form_url=raw.get("formUrl", ""),
        )

    def check_order(self, order_id: str) -> OrderStatusResponse:
        """Check the status of an existing order.

        Returns a parsed response with a success boolean
        (True when orderStatus is "2").

        Args:
            order_id: The bank-assigned order ID.

        Returns:
            An OrderStatusResponse with payment status details.
        """
        body: Dict[str, Any] = {
            "userName": self._username,
            "Password": self._password,
            "language": self._language,
            "orderId": order_id,
        }

        raw = self._post("/getOrderStatus.do", body)

        return OrderStatusResponse(
            success=raw.get("orderStatus") == "2",
            error_code=raw.get("ErrorCode", ""),
            error_message=raw.get("ErrorMessage", ""),
            order_number=raw.get("OrderNumber", ""),
            ip=raw.get("Ip", ""),
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "KhanBankClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Private helpers ──

    def _post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        """Send a POST request to the Khan Bank API."""
        url = f"{self._endpoint}{path}"

        try:
            res = self._client.post(
                url,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.HTTPError as exc:
            raise KhanBankError(
                f"Network error calling {path}: {exc}"
            ) from exc

        try:
            json_data: Dict[str, Any] = res.json()
        except Exception:
            raise KhanBankError(
                f"Invalid JSON response from {path}",
                status_code=res.status_code,
            )

        if res.status_code < 200 or res.status_code >= 300:
            raise KhanBankError(
                f"Khan Bank API error: HTTP {res.status_code}",
                status_code=res.status_code,
                response=json_data,
            )

        return json_data


class AsyncKhanBankClient:
    """Khan Bank payment client (asynchronous).

    Handles order registration and payment status checks.
    Credentials (username/password) are sent in the request body with every call.
    """

    def __init__(self, config: KhanBankConfig) -> None:
        if not config.endpoint:
            raise ValueError("AsyncKhanBankClient: endpoint is required")
        if not config.username:
            raise ValueError("AsyncKhanBankClient: username is required")
        if not config.password:
            raise ValueError("AsyncKhanBankClient: password is required")

        # Strip trailing slashes for consistent URL building
        self._endpoint = re.sub(r"/+$", "", config.endpoint)
        self._username = config.username
        self._password = config.password
        self._language = config.language or MONGOLIAN_LANGUAGE_CODE
        self._client = httpx.AsyncClient()

    # ── Public API ──

    async def register_order(
        self, input: OrderRegisterInput
    ) -> RegisterOrderResponse:
        """Register a new payment order with Khan Bank.

        The amount is formatted as a fixed 2-decimal-place string
        (e.g. 1000 -> "1000.00"). Returns the bank-assigned order ID
        and a payment form URL to redirect the user to.

        Args:
            input: Order registration details.

        Returns:
            A RegisterOrderResponse with order_id and form_url.
        """
        body: Dict[str, Any] = {
            "orderNumber": input.order_number,
            "amount": f"{input.amount:.2f}",
            "returnUrl": input.success_callback,
            "failUrl": input.fail_callback,
            "jsonParams": {"orderNumber": input.order_number},
            "userName": self._username,
            "Password": self._password,
            "language": self._language,
        }

        raw = await self._post("/register.do", body)

        return RegisterOrderResponse(
            order_id=raw.get("orderId", ""),
            form_url=raw.get("formUrl", ""),
        )

    async def check_order(self, order_id: str) -> OrderStatusResponse:
        """Check the status of an existing order.

        Returns a parsed response with a success boolean
        (True when orderStatus is "2").

        Args:
            order_id: The bank-assigned order ID.

        Returns:
            An OrderStatusResponse with payment status details.
        """
        body: Dict[str, Any] = {
            "userName": self._username,
            "Password": self._password,
            "language": self._language,
            "orderId": order_id,
        }

        raw = await self._post("/getOrderStatus.do", body)

        return OrderStatusResponse(
            success=raw.get("orderStatus") == "2",
            error_code=raw.get("ErrorCode", ""),
            error_message=raw.get("ErrorMessage", ""),
            order_number=raw.get("OrderNumber", ""),
            ip=raw.get("Ip", ""),
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncKhanBankClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ── Private helpers ──

    async def _post(self, path: str, body: Dict[str, Any]) -> Dict[str, Any]:
        """Send a POST request to the Khan Bank API."""
        url = f"{self._endpoint}{path}"

        try:
            res = await self._client.post(
                url,
                json=body,
                headers={"Content-Type": "application/json"},
            )
        except httpx.HTTPError as exc:
            raise KhanBankError(
                f"Network error calling {path}: {exc}"
            ) from exc

        try:
            json_data: Dict[str, Any] = res.json()
        except Exception:
            raise KhanBankError(
                f"Invalid JSON response from {path}",
                status_code=res.status_code,
            )

        if res.status_code < 200 or res.status_code >= 300:
            raise KhanBankError(
                f"Khan Bank API error: HTTP {res.status_code}",
                status_code=res.status_code,
                response=json_data,
            )

        return json_data
