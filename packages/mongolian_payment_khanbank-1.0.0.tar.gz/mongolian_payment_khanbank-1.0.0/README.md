# mongolian-payment-khanbank

Khan Bank payment gateway SDK for Python. Supports both synchronous and asynchronous usage.

## Installation

```bash
pip install mongolian-payment-khanbank
```

## Usage

### Synchronous

```python
from mongolian_payment_khanbank import KhanBankClient, KhanBankConfig, OrderRegisterInput

client = KhanBankClient(KhanBankConfig(
    endpoint="https://ecommerce.khanbank.com/payment/rest",
    username="your_username",
    password="your_password",
))

# Register a new order
result = client.register_order(OrderRegisterInput(
    order_number="ORD-001",
    amount=50000,
    success_callback="https://example.com/success",
    fail_callback="https://example.com/fail",
))

print(result.order_id)  # Bank-assigned order ID
print(result.form_url)  # Redirect user to this URL

# Check order status
status = client.check_order(result.order_id)
print(status.success)       # True if payment succeeded
print(status.error_code)
print(status.error_message)
```

### Asynchronous

```python
import asyncio
from mongolian_payment_khanbank import AsyncKhanBankClient, KhanBankConfig, OrderRegisterInput

async def main():
    async with AsyncKhanBankClient(KhanBankConfig(
        endpoint="https://ecommerce.khanbank.com/payment/rest",
        username="your_username",
        password="your_password",
    )) as client:
        result = await client.register_order(OrderRegisterInput(
            order_number="ORD-001",
            amount=50000,
            success_callback="https://example.com/success",
            fail_callback="https://example.com/fail",
        ))

        status = await client.check_order(result.order_id)
        print(status.success)

asyncio.run(main())
```

### Configuration from Environment Variables

```python
from mongolian_payment_khanbank import KhanBankClient, load_config_from_env

client = KhanBankClient(load_config_from_env())
```

Required environment variables:

| Variable              | Description                    |
|-----------------------|--------------------------------|
| `KHANBANK_ENDPOINT`   | Khan Bank API base URL         |
| `KHANBANK_USERNAME`   | API username                   |
| `KHANBANK_PASSWORD`   | API password                   |

Optional environment variables:

| Variable              | Description                    | Default |
|-----------------------|--------------------------------|---------|
| `KHANBANK_LANGUAGE`   | Language code (`mn` or `en`)   | `mn`    |

## License

MIT
