"""Tests for the Khan Bank payment SDK."""

import os
from unittest.mock import patch

import httpx
import pytest
import pytest_asyncio

from mongolian_payment_khanbank import (
    ENGLISH_LANGUAGE_CODE,
    MONGOLIAN_LANGUAGE_CODE,
    AsyncKhanBankClient,
    KhanBankClient,
    KhanBankConfig,
    KhanBankError,
    OrderRegisterInput,
    load_config_from_env,
)

# ── Fixtures ──


@pytest.fixture
def config() -> KhanBankConfig:
    return KhanBankConfig(
        endpoint="https://api.khanbank.test/",
        username="test_user",
        password="test_pass",
    )


@pytest.fixture
def register_input() -> OrderRegisterInput:
    return OrderRegisterInput(
        order_number="ORD-001",
        amount=1500.5,
        success_callback="https://example.com/success",
        fail_callback="https://example.com/fail",
    )


# ============================================================================
# Sync Client Tests
# ============================================================================


class TestKhanBankClient:
    """Tests for the synchronous KhanBankClient."""

    def test_constructor_strips_trailing_slash(self, config: KhanBankConfig) -> None:
        client = KhanBankClient(config)
        assert client._endpoint == "https://api.khanbank.test"

    def test_constructor_strips_multiple_trailing_slashes(self) -> None:
        config = KhanBankConfig(
            endpoint="https://api.khanbank.test///",
            username="user",
            password="pass",
        )
        client = KhanBankClient(config)
        assert client._endpoint == "https://api.khanbank.test"

    def test_constructor_defaults_language_to_mongolian(
        self, config: KhanBankConfig
    ) -> None:
        client = KhanBankClient(config)
        assert client._language == MONGOLIAN_LANGUAGE_CODE

    def test_constructor_uses_custom_language(self) -> None:
        config = KhanBankConfig(
            endpoint="https://api.khanbank.test",
            username="user",
            password="pass",
            language=ENGLISH_LANGUAGE_CODE,
        )
        client = KhanBankClient(config)
        assert client._language == ENGLISH_LANGUAGE_CODE

    def test_constructor_requires_endpoint(self) -> None:
        with pytest.raises(ValueError, match="endpoint is required"):
            KhanBankClient(
                KhanBankConfig(endpoint="", username="user", password="pass")
            )

    def test_constructor_requires_username(self) -> None:
        with pytest.raises(ValueError, match="username is required"):
            KhanBankClient(
                KhanBankConfig(
                    endpoint="https://api.khanbank.test",
                    username="",
                    password="pass",
                )
            )

    def test_constructor_requires_password(self) -> None:
        with pytest.raises(ValueError, match="password is required"):
            KhanBankClient(
                KhanBankConfig(
                    endpoint="https://api.khanbank.test",
                    username="user",
                    password="",
                )
            )

    def test_register_order(
        self,
        config: KhanBankConfig,
        register_input: OrderRegisterInput,
    ) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderId": "bank-order-123",
                "formUrl": "https://pay.khanbank.test/form/123",
            },
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response) as mock:
            result = client.register_order(register_input)

            mock.assert_called_once()
            call_kwargs = mock.call_args
            body = call_kwargs.kwargs["json"]

            assert body["orderNumber"] == "ORD-001"
            assert body["amount"] == "1500.50"
            assert body["returnUrl"] == "https://example.com/success"
            assert body["failUrl"] == "https://example.com/fail"
            assert body["jsonParams"] == {"orderNumber": "ORD-001"}
            assert body["userName"] == "test_user"
            assert body["Password"] == "test_pass"
            assert body["language"] == "mn"

        assert result.order_id == "bank-order-123"
        assert result.form_url == "https://pay.khanbank.test/form/123"

    def test_register_order_formats_amount_two_decimals(
        self,
        config: KhanBankConfig,
    ) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={"orderId": "id", "formUrl": "url"},
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response) as mock:
            client.register_order(
                OrderRegisterInput(
                    order_number="ORD-002",
                    amount=1000,
                    success_callback="https://example.com/ok",
                    fail_callback="https://example.com/fail",
                )
            )

            body = mock.call_args.kwargs["json"]
            assert body["amount"] == "1000.00"

    def test_check_order_success(self, config: KhanBankConfig) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderStatus": "2",
                "ErrorCode": "0",
                "ErrorMessage": "",
                "OrderNumber": "ORD-001",
                "Ip": "1.2.3.4",
            },
            request=httpx.Request(
                "POST", "https://api.khanbank.test/getOrderStatus.do"
            ),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response) as mock:
            result = client.check_order("bank-order-123")

            mock.assert_called_once()
            body = mock.call_args.kwargs["json"]
            assert body["orderId"] == "bank-order-123"
            assert body["userName"] == "test_user"
            assert body["Password"] == "test_pass"

        assert result.success is True
        assert result.error_code == "0"
        assert result.error_message == ""
        assert result.order_number == "ORD-001"
        assert result.ip == "1.2.3.4"

    def test_check_order_not_successful(self, config: KhanBankConfig) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderStatus": "1",
                "ErrorCode": "5",
                "ErrorMessage": "Payment declined",
                "OrderNumber": "ORD-001",
                "Ip": "1.2.3.4",
            },
            request=httpx.Request(
                "POST", "https://api.khanbank.test/getOrderStatus.do"
            ),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            result = client.check_order("bank-order-456")

        assert result.success is False
        assert result.error_code == "5"
        assert result.error_message == "Payment declined"

    def test_http_error_raises_khanbank_error(self, config: KhanBankConfig) -> None:
        mock_response = httpx.Response(
            status_code=500,
            json={"error": "Internal Server Error"},
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            with pytest.raises(KhanBankError, match="HTTP 500") as exc_info:
                client.register_order(
                    OrderRegisterInput(
                        order_number="ORD-ERR",
                        amount=100,
                        success_callback="https://example.com/ok",
                        fail_callback="https://example.com/fail",
                    )
                )

            assert exc_info.value.status_code == 500
            assert exc_info.value.response == {"error": "Internal Server Error"}

    def test_network_error_raises_khanbank_error(
        self, config: KhanBankConfig
    ) -> None:
        client = KhanBankClient(config)

        with patch.object(
            client._client,
            "post",
            side_effect=httpx.ConnectError("Connection refused"),
        ):
            with pytest.raises(KhanBankError, match="Network error"):
                client.check_order("some-order-id")

    def test_invalid_json_raises_khanbank_error(
        self, config: KhanBankConfig
    ) -> None:
        mock_response = httpx.Response(
            status_code=200,
            content=b"not json",
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            with pytest.raises(KhanBankError, match="Invalid JSON"):
                client.register_order(
                    OrderRegisterInput(
                        order_number="ORD-BAD",
                        amount=100,
                        success_callback="https://example.com/ok",
                        fail_callback="https://example.com/fail",
                    )
                )

    def test_context_manager(self, config: KhanBankConfig) -> None:
        with KhanBankClient(config) as client:
            assert client._endpoint == "https://api.khanbank.test"

    def test_missing_fields_default_to_empty_strings(
        self, config: KhanBankConfig
    ) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={},
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = KhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            result = client.register_order(
                OrderRegisterInput(
                    order_number="ORD-EMPTY",
                    amount=100,
                    success_callback="https://example.com/ok",
                    fail_callback="https://example.com/fail",
                )
            )

        assert result.order_id == ""
        assert result.form_url == ""


# ============================================================================
# Async Client Tests
# ============================================================================


class TestAsyncKhanBankClient:
    """Tests for the asynchronous AsyncKhanBankClient."""

    @pytest.mark.asyncio
    async def test_register_order(
        self,
        config: KhanBankConfig,
        register_input: OrderRegisterInput,
    ) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderId": "async-order-123",
                "formUrl": "https://pay.khanbank.test/form/async",
            },
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = AsyncKhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response) as mock:
            result = await client.register_order(register_input)

            mock.assert_called_once()
            body = mock.call_args.kwargs["json"]
            assert body["amount"] == "1500.50"

        assert result.order_id == "async-order-123"
        assert result.form_url == "https://pay.khanbank.test/form/async"

        await client.close()

    @pytest.mark.asyncio
    async def test_check_order_success(self, config: KhanBankConfig) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderStatus": "2",
                "ErrorCode": "0",
                "ErrorMessage": "",
                "OrderNumber": "ORD-ASYNC",
                "Ip": "5.6.7.8",
            },
            request=httpx.Request(
                "POST", "https://api.khanbank.test/getOrderStatus.do"
            ),
        )

        client = AsyncKhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            result = await client.check_order("async-order-123")

        assert result.success is True
        assert result.order_number == "ORD-ASYNC"
        assert result.ip == "5.6.7.8"

        await client.close()

    @pytest.mark.asyncio
    async def test_check_order_failure(self, config: KhanBankConfig) -> None:
        mock_response = httpx.Response(
            status_code=200,
            json={
                "orderStatus": "3",
                "ErrorCode": "10",
                "ErrorMessage": "Timeout",
                "OrderNumber": "ORD-FAIL",
                "Ip": "9.9.9.9",
            },
            request=httpx.Request(
                "POST", "https://api.khanbank.test/getOrderStatus.do"
            ),
        )

        client = AsyncKhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            result = await client.check_order("async-order-fail")

        assert result.success is False
        assert result.error_code == "10"
        assert result.error_message == "Timeout"

        await client.close()

    @pytest.mark.asyncio
    async def test_http_error_raises_khanbank_error(
        self, config: KhanBankConfig
    ) -> None:
        mock_response = httpx.Response(
            status_code=403,
            json={"error": "Forbidden"},
            request=httpx.Request("POST", "https://api.khanbank.test/register.do"),
        )

        client = AsyncKhanBankClient(config)

        with patch.object(client._client, "post", return_value=mock_response):
            with pytest.raises(KhanBankError, match="HTTP 403"):
                await client.register_order(
                    OrderRegisterInput(
                        order_number="ORD-FORBID",
                        amount=50,
                        success_callback="https://example.com/ok",
                        fail_callback="https://example.com/fail",
                    )
                )

        await client.close()

    @pytest.mark.asyncio
    async def test_network_error_raises_khanbank_error(
        self, config: KhanBankConfig
    ) -> None:
        client = AsyncKhanBankClient(config)

        with patch.object(
            client._client,
            "post",
            side_effect=httpx.ConnectError("Connection refused"),
        ):
            with pytest.raises(KhanBankError, match="Network error"):
                await client.check_order("unreachable-order")

        await client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager(self, config: KhanBankConfig) -> None:
        async with AsyncKhanBankClient(config) as client:
            assert client._endpoint == "https://api.khanbank.test"


# ============================================================================
# Config Tests
# ============================================================================


class TestLoadConfigFromEnv:
    """Tests for load_config_from_env."""

    def test_loads_all_env_vars(self) -> None:
        env = {
            "KHANBANK_ENDPOINT": "https://api.khanbank.test",
            "KHANBANK_USERNAME": "env_user",
            "KHANBANK_PASSWORD": "env_pass",
            "KHANBANK_LANGUAGE": "en",
        }
        with patch.dict(os.environ, env, clear=False):
            cfg = load_config_from_env()

        assert cfg.endpoint == "https://api.khanbank.test"
        assert cfg.username == "env_user"
        assert cfg.password == "env_pass"
        assert cfg.language == "en"

    def test_language_is_optional(self) -> None:
        env = {
            "KHANBANK_ENDPOINT": "https://api.khanbank.test",
            "KHANBANK_USERNAME": "user",
            "KHANBANK_PASSWORD": "pass",
        }
        with patch.dict(os.environ, env, clear=False):
            # Remove KHANBANK_LANGUAGE if it happens to be set
            os.environ.pop("KHANBANK_LANGUAGE", None)
            cfg = load_config_from_env()

        assert cfg.language is None

    def test_missing_endpoint_raises(self) -> None:
        env = {
            "KHANBANK_USERNAME": "user",
            "KHANBANK_PASSWORD": "pass",
        }
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("KHANBANK_ENDPOINT", None)
            with pytest.raises(ValueError, match="KHANBANK_ENDPOINT"):
                load_config_from_env()

    def test_missing_username_raises(self) -> None:
        env = {
            "KHANBANK_ENDPOINT": "https://api.khanbank.test",
            "KHANBANK_PASSWORD": "pass",
        }
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("KHANBANK_USERNAME", None)
            with pytest.raises(ValueError, match="KHANBANK_USERNAME"):
                load_config_from_env()

    def test_missing_password_raises(self) -> None:
        env = {
            "KHANBANK_ENDPOINT": "https://api.khanbank.test",
            "KHANBANK_USERNAME": "user",
        }
        with patch.dict(os.environ, env, clear=False):
            os.environ.pop("KHANBANK_PASSWORD", None)
            with pytest.raises(ValueError, match="KHANBANK_PASSWORD"):
                load_config_from_env()


# ============================================================================
# Error Tests
# ============================================================================


class TestKhanBankError:
    """Tests for KhanBankError."""

    def test_basic_error(self) -> None:
        err = KhanBankError("something went wrong")
        assert str(err) == "something went wrong"
        assert err.status_code is None
        assert err.response is None

    def test_error_with_status_code(self) -> None:
        err = KhanBankError("bad request", status_code=400)
        assert err.status_code == 400

    def test_error_with_response(self) -> None:
        body = {"error": "details"}
        err = KhanBankError("api error", status_code=500, response=body)
        assert err.status_code == 500
        assert err.response == body

    def test_is_exception(self) -> None:
        err = KhanBankError("test")
        assert isinstance(err, Exception)
