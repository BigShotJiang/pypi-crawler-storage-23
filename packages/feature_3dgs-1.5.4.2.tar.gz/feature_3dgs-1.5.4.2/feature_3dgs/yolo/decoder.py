import torch
import torch.nn as nn

from feature_3dgs.decoder import LinearDecoder


class YOLODecoder(LinearDecoder):
    pass  # TODO
