//! Unit tests for Content-Defined Chunking (CDC)

use super::common;
use common::*;

use hexz_core::algo::dedup::cdc::{StreamChunker, analyze_stream};
use hexz_core::algo::dedup::dcam::DedupeParams;
use std::io::Cursor;

// Basic chunking tests

#[test]
fn test_cdc_empty_input() {
    let data = vec![];
    let cursor = Cursor::new(data);
    let params = DedupeParams::default();

    let stats = analyze_stream(cursor, &params).unwrap();
    // total_bytes may be 0 (not tracked during streaming)
    assert_eq!(stats.chunk_count, 0);
    assert_eq!(stats.unique_chunk_count, 0);
}

#[test]
fn test_cdc_single_byte() {
    let data = vec![0x42];
    let cursor = Cursor::new(data);
    let params = DedupeParams::default();

    let stats = analyze_stream(cursor, &params).unwrap();
    // total_bytes may be 0 (not tracked during streaming)
    // Single byte should create one chunk
    assert!(stats.chunk_count >= 1);
}

#[test]
fn test_cdc_small_data() {
    let data = vec![0x42; 100];
    let cursor = Cursor::new(data);
    let params = DedupeParams::default();

    let stats = analyze_stream(cursor, &params).unwrap();
    // total_bytes may be 0 (not tracked during streaming)
    assert!(stats.chunk_count >= 1);
}

#[test]
fn test_cdc_deterministic() {
    // Same data should produce same chunks
    let data = create_random_data(10_000);
    let params = DedupeParams::default();

    let stats1 = analyze_stream(Cursor::new(data.clone()), &params).unwrap();
    let stats2 = analyze_stream(Cursor::new(data), &params).unwrap();

    assert_eq!(stats1.chunk_count, stats2.chunk_count);
    assert_eq!(stats1.unique_chunk_count, stats2.unique_chunk_count);
    assert_eq!(stats1.total_bytes, stats2.total_bytes);
}

#[test]
fn test_cdc_shifted_data() {
    // Content-defined chunking should preserve most chunk boundaries when data is shifted
    let base = create_random_data(50_000);
    let params = DedupeParams::default();

    // Original data
    let _stats1 = analyze_stream(Cursor::new(base.clone()), &params).unwrap();

    // Shifted by 100 bytes
    let mut shifted = vec![0xFFu8; 100];
    shifted.extend_from_slice(&base[..base.len() - 100]);
    let stats2 = analyze_stream(Cursor::new(shifted), &params).unwrap();

    // Most chunks should still be found, but not all
    assert!(stats2.unique_chunk_count > 0);
}

#[test]
fn test_cdc_chunk_size_constraints() {
    let data = create_random_data(1_000_000);
    let params = DedupeParams::default();

    let chunker = StreamChunker::new(Cursor::new(data), params);
    let min_size = params.m as usize; // Minimum chunk size
    let max_size = params.z as usize; // Maximum chunk size

    for chunk_result in chunker {
        let chunk = chunk_result.unwrap();
        assert!(chunk.len() >= min_size || chunk.len() < 100); // Allow small final chunks
        assert!(chunk.len() <= max_size);
    }
}

// Content-defined properties

#[test]
fn test_cdc_repeated_pattern() {
    // Repeating pattern should have high deduplication ratio
    let pattern = create_random_data(1000);
    let mut data = Vec::new();
    for _ in 0..100 {
        data.extend_from_slice(&pattern);
    }

    let params = DedupeParams::default();
    let stats = analyze_stream(Cursor::new(data.clone()), &params).unwrap();

    // CDC boundaries may not align with pattern boundaries, so dedup is not guaranteed
    // Just verify we get reasonable stats
    assert!(stats.chunk_count > 0);
    assert!(stats.unique_chunk_count > 0);
    assert!(stats.unique_chunk_count <= stats.chunk_count);
}

#[test]
fn test_cdc_unique_data() {
    // Unique random data should have low/no deduplication
    let data = create_random_data(100_000);
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // All chunks should be unique (or nearly all)
    assert!(stats.unique_chunk_count >= stats.chunk_count * 95 / 100);
}

#[test]
fn test_cdc_localized_changes() {
    // Small change should affect only nearby chunks
    let data = create_random_data(50_000);
    let params = DedupeParams::default();

    let stats1 = analyze_stream(Cursor::new(data.clone()), &params).unwrap();

    // Modify 100 bytes in the middle
    let mut modified = data.clone();
    for item in &mut modified[25000..25100] {
        *item ^= 0xFF;
    }
    let stats2 = analyze_stream(Cursor::new(modified), &params).unwrap();

    // Should have similar number of total chunks
    let chunk_diff = (stats1.chunk_count as i64 - stats2.chunk_count as i64).abs();
    assert!(chunk_diff < stats1.chunk_count as i64 / 5);
}

// StreamChunker tests

#[test]
fn test_stream_chunker_iterator() {
    let data = create_random_data(10_000);
    let params = DedupeParams::default();

    let chunker = StreamChunker::new(Cursor::new(data.clone()), params);

    let mut total_bytes = 0;
    let mut chunk_count = 0;

    for chunk_result in chunker {
        let chunk = chunk_result.unwrap();
        total_bytes += chunk.len();
        chunk_count += 1;
    }

    assert_eq!(total_bytes, data.len());
    assert!(chunk_count > 0);
}

#[test]
fn test_stream_chunker_buffer_management() {
    // Test with data larger than internal buffer
    let data = create_random_data(10 * 1024 * 1024); // 10MB
    let params = DedupeParams::default();

    let chunker = StreamChunker::new(Cursor::new(data.clone()), params);

    let mut reconstructed = Vec::new();
    for chunk_result in chunker {
        let chunk = chunk_result.unwrap();
        reconstructed.extend_from_slice(&chunk);
    }

    assert_bytes_equal(&reconstructed, &data, "stream chunker reconstruction");
}

#[test]
fn test_stream_chunker_partial_reads() {
    // Simulate partial reads
    let data = create_random_data(50_000);
    let params = DedupeParams::default();

    let chunker = StreamChunker::new(Cursor::new(data), params);

    for chunk_result in chunker {
        let chunk = chunk_result.unwrap();
        // Each chunk should be non-empty (except possibly the last)
        // Just verify we can iterate without panic
        let _ = chunk;
    }
}

// CdcStats accuracy tests

#[test]
fn test_cdc_stats_byte_count() {
    let data = create_random_data(123_456);
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // total_bytes is not tracked in analyze_stream, but unique_bytes should be reasonable
    assert!(stats.unique_bytes > 0);
    assert!(stats.unique_bytes <= 123_456);
}

#[test]
fn test_cdc_stats_chunk_count() {
    let data = create_random_data(100_000);
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    assert!(stats.chunk_count > 0);
    assert!(stats.unique_chunk_count > 0);
    assert!(stats.unique_chunk_count <= stats.chunk_count);
}

#[test]
fn test_cdc_stats_dedup_ratio() {
    // Test with highly redundant data
    let pattern = vec![0x42u8; 10_000];
    let mut data = Vec::new();
    for _ in 0..50 {
        data.extend_from_slice(&pattern);
    }

    let params = DedupeParams::default();
    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // Repetitive data should have significant deduplication
    assert!(
        stats.unique_chunk_count < stats.chunk_count,
        "Expected deduplication for repetitive data"
    );
}

// Edge cases

#[test]
fn test_cdc_very_small_file() {
    for size in [0, 1, 10, 100] {
        let data = create_random_data(size);
        let params = DedupeParams::default();

        let stats = analyze_stream(Cursor::new(data), &params).unwrap();
        // Just verify it doesn't panic and produces reasonable results
        if size == 0 {
            assert_eq!(stats.chunk_count, 0);
        }
        // For non-zero sizes, chunk_count can be any non-negative value
    }
}

#[test]
fn test_cdc_homogeneous_data() {
    // All zeros
    let data = vec![0u8; 100_000];
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // Should have some chunks
    assert!(stats.chunk_count > 0);
    // All zeros may or may not deduplicate depending on chunk boundaries
    // Just verify reasonable stats
    assert!(stats.unique_chunk_count > 0);
    assert!(stats.unique_chunk_count <= stats.chunk_count);
}

#[test]
fn test_cdc_high_entropy_data() {
    let data = create_random_data(100_000);
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // Random data should have minimal deduplication
    // Most chunks should be unique
    let uniqueness_ratio = stats.unique_chunk_count as f64 / stats.chunk_count as f64;
    assert!(
        uniqueness_ratio > 0.9,
        "Random data should have >90% unique chunks"
    );
}

#[test]
fn test_cdc_repeating_pattern_different_offsets() {
    // Pattern repeated at different offsets
    let pattern = create_random_data(5000);
    let mut data = Vec::new();

    data.extend_from_slice(&pattern);
    data.extend(vec![0xFFu8; 137]); // Offset by 137 bytes
    data.extend_from_slice(&pattern);
    data.extend(vec![0xFFu8; 289]); // Different offset
    data.extend_from_slice(&pattern);

    let params = DedupeParams::default();
    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // May or may not find duplicates depending on chunk boundaries and offsets
    // Just verify it produces reasonable stats
    assert!(stats.chunk_count > 0);
    assert!(stats.unique_chunk_count > 0);
    assert!(stats.unique_chunk_count <= stats.chunk_count);
}

// Large file tests

#[test]
fn test_cdc_large_file() {
    // 50MB file
    let data = create_random_data(50 * 1024 * 1024);
    let params = DedupeParams::default();

    let stats = analyze_stream(Cursor::new(data), &params).unwrap();

    // Should have many chunks for a 50MB file
    assert!(
        stats.chunk_count > 1000,
        "50MB file should produce >1000 chunks"
    );
}

#[test]
fn test_cdc_parameter_variations() {
    let data = create_random_data(100_000);

    // Test with different f values (fingerprint bits)
    for f in [8u32, 12, 16] {
        let mut params = DedupeParams::lbfs_baseline();
        params.f = f;
        let stats = analyze_stream(Cursor::new(data.clone()), &params).unwrap();

        assert!(stats.chunk_count > 0, "Should produce chunks with f={}", f);
    }
}
