"""PFC documentation system.

Provides command, Python API, and reference documentation loading,
formatting, and BM25-based search capabilities.
"""
