"""PFC MCP Server - ITASCA PFC discrete element simulation tools via MCP."""

__version__ = "0.2.4"
