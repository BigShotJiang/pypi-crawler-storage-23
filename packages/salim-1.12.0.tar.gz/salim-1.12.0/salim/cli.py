"""
Salim CLI — Beautiful onboarding + management interface.
Entry point: `salim` command.
"""

from __future__ import annotations

import os
import sys
import platform
import subprocess
import time
from pathlib import Path

# ── Smart auto-install bootstrap ─────────────────────────────────────────────
def _bootstrap():
    """
    First, try to auto-install all deps via salim.auto_install.
    Falls back gracefully: if even rich/questionary aren't available yet,
    we pip-install them first, then run the full installer.
    """
    # Ensure bare minimum for rich output
    for _pkg in ("rich", "questionary"):
        try:
            __import__(_pkg)
        except ImportError:
            print(f"[Salim] Installing {_pkg}…")
            subprocess.run(
                [sys.executable, "-m", "pip", "install", _pkg, "--quiet"],
                check=False
            )

    # Now run the full auto-installer (idempotent — skips if stamp file present)
    try:
        from salim.auto_install import run_auto_install
        try:
            from rich.console import Console
            _con = Console()
        except Exception:
            _con = None
        run_auto_install(verbose=False, console=_con)
    except Exception as e:
        print(f"[Salim] Auto-install warning: {e}")

_bootstrap()

# ── Now safe to import ───────────────────────────────────────────────────────
import argparse

from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.columns import Columns
from rich.align import Align
from rich import box
import questionary
from questionary import Style as QStyle

from salim.config import Config, CONFIG_DIR, CONFIG_FILE

console = Console()

# ── Custom questionary style ─────────────────────────────────────────────────
TD_STYLE = QStyle([
    ("qmark",    "fg:#2AABEE bold"),
    ("question", "fg:#e8e8f0 bold"),
    ("answer",   "fg:#2AABEE bold"),
    ("pointer",  "fg:#2AABEE bold"),
    ("highlighted", "fg:#2AABEE bold"),
    ("selected", "fg:#2AABEE"),
    ("separator","fg:#444466"),
    ("instruction","fg:#6b6b8a"),
])


# ── Banner ────────────────────────────────────────────────────────────────────
BANNER = """
[bold cyan] ███████╗  █████╗  ██╗      ██╗ ███╗   ███╗[/bold cyan]
[bold cyan] ██╔════╝ ██╔══██╗ ██║      ██║ ████╗ ████║[/bold cyan]
[cyan] ███████╗ ███████║ ██║      ██║ ██╔████╔██║[/cyan]
[cyan] ╚════██║ ██╔══██║ ██║      ██║ ██║╚██╔╝██║[/cyan]
[bold blue] ███████║ ██║  ██║ ███████╗ ██║ ██║ ╚═╝ ██║[/bold blue]
[bold blue] ╚══════╝ ╚═╝  ╚═╝ ╚══════╝ ╚═╝ ╚═╝     ╚═╝[/bold blue]

[bold white]    Control your laptop. Entirely from Telegram.[/bold white]
[dim]    v1.12.0 · github.com/salim/salim[/dim]
"""


def print_banner():
    console.print(BANNER)


# ── Main entry ────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        prog="salim",
        description="Salim — Control your laptop from Telegram",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  salim setup     Interactive onboarding wizard
  salim start     Start the bot
  salim status    Check if bot is running
  salim config    View/edit configuration
  salim logs      View command audit log
  salim test      Test Telegram connection
  salim adduser   Add an authorized user
  salim stop      Stop the running bot
  salim uninstall Remove all Salim data
        """.strip()
    )
    parser.add_argument("command", nargs="?", default="start",
                        choices=["setup", "start", "status", "config", "logs",
                                 "test", "adduser", "stop", "uninstall"],
                        help="Command to run (default: start)")
    parser.add_argument("--token", "-t", help="Bot token (skip wizard prompt)")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")
    parser.add_argument("--no-banner", action="store_true", help="Skip banner")

    args = parser.parse_args()

    if not args.no_banner:
        print_banner()

    config = Config()

    dispatch = {
        "setup":     lambda: cmd_setup(config, token_override=args.token),
        "start":     lambda: cmd_start(config, verbose=args.verbose),
        "status":    lambda: cmd_status(config),
        "config":    lambda: cmd_config(config),
        "logs":      lambda: cmd_logs(config),
        "test":      lambda: cmd_test(config),
        "adduser":   lambda: cmd_adduser(config),
        "stop":      lambda: cmd_stop(config),
        "uninstall": lambda: cmd_uninstall(config),
    }

    try:
        dispatch[args.command]()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow]")
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


# ── cmd_setup — Full onboarding wizard ───────────────────────────────────────
def _http_post_json(url: str, payload: dict, headers: dict, timeout: int = 15) -> tuple[int, dict]:
    """Generic HTTP POST returning (status_code, response_dict). Never raises."""
    import urllib.request
    import urllib.error
    import json as _json
    try:
        data = _json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = _json.loads(resp.read().decode())
            return resp.status, body
    except urllib.error.HTTPError as e:
        try:
            body = _json.loads(e.read().decode())
        except Exception:
            body = {"error": str(e)}
        return e.code, body
    except Exception as e:
        return 0, {"error": str(e)}


def _test_nvidia_key(api_key: str) -> tuple[bool, str]:
    """
    Validate an NVIDIA NIM API key.
    Returns (is_valid, error_message).
    Uses /models list endpoint — no tokens consumed, instant response.
    """
    import urllib.request
    import urllib.error
    try:
        req = urllib.request.Request(
            "https://integrate.api.nvidia.com/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=12) as resp:
            return (resp.status == 200), ""
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return False, "Invalid API key (401 Unauthorized)"
        if e.code == 403:
            return False, "Access denied (403 Forbidden)"
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, str(e)


def _test_groq_key(api_key: str) -> tuple[bool, str]:
    """
    Validate a Groq API key.
    Returns (is_valid, error_message).
    Uses /models list endpoint — no tokens consumed.
    """
    import urllib.request
    import urllib.error
    try:
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/models",
            headers={"Authorization": f"Bearer {api_key}"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=12) as resp:
            return (resp.status == 200), ""
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return False, "Invalid API key (401 Unauthorized)"
        if e.code == 403:
            return False, "Access denied (403 Forbidden)"
        return False, f"HTTP {e.code}"
    except Exception as e:
        return False, str(e)


def _test_zai_key(api_key: str) -> tuple[bool, str]:
    """
    Validate a Z.AI (Zhipu) API key with a minimal chat call.
    Returns (is_valid, error_message).
    GLM-4-Flash is free so a 1-token call costs nothing.
    """
    status, body = _http_post_json(
        "https://open.bigmodel.cn/api/paas/v4/chat/completions",
        payload={
            "model": "glm-4-flash",
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 1,
        },
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        timeout=15,
    )
    if status == 200:
        return True, ""
    if status == 401:
        return False, "Invalid API key (401 Unauthorized)"
    if status == 0:
        return False, body.get("error", "Connection failed")
    err = body.get("error", {})
    msg = err.get("message", str(body)) if isinstance(err, dict) else str(err)
    return False, f"HTTP {status}: {msg[:120]}"


def cmd_setup(config: Config, token_override: str | None = None):
    console.print(Panel.fit(
        "[bold cyan]Welcome to Salim Setup[/bold cyan]\n"
        "[dim]This wizard will configure your bot in under 2 minutes.[/dim]",
        border_style="cyan"
    ))
    console.print()

    # ── Step 1: Bot Token ─────────────────────────────────────────────────────
    console.print("[bold]Step 1/5 — Bot Token[/bold]")
    console.print(
        "\n[dim]You need a Telegram bot token from [cyan]@BotFather[/cyan].[/dim]\n"
        "[dim]1. Open Telegram → search @BotFather[/dim]\n"
        "[dim]2. Send [cyan]/newbot[/cyan][/dim]\n"
        "[dim]3. Follow the steps and copy your token[/dim]\n"
    )

    existing_token = config.bot_token
    if token_override:
        bot_token = token_override
        console.print(f"[green]✓ Using provided token: {bot_token[:15]}...[/green]")
    elif existing_token:
        keep = Confirm.ask(
            f"[yellow]Existing token found ({existing_token[:12]}...). Keep it?[/yellow]",
            default=True
        )
        bot_token = existing_token if keep else Prompt.ask("[cyan]Bot token[/cyan]")
    else:
        bot_token = Prompt.ask("[cyan]Paste your bot token[/cyan]")

    # Validate token format
    if not _validate_token_format(bot_token):
        console.print("[red]❌ Token format looks wrong. It should be like 1234567890:ABCdef...[/red]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    # ── Step 2: Test connection ───────────────────────────────────────────────
    console.print("\n[bold]Step 2/5 — Verifying Token[/bold]")
    bot_info = _test_token(bot_token)
    if bot_info:
        console.print(f"[green]✓ Connected to bot: @{bot_info['username']} ({bot_info['first_name']})[/green]")
    else:
        console.print("[red]❌ Could not connect with this token. Check it and try again.[/red]")
        if not Confirm.ask("Continue anyway?", default=False):
            return

    # ── Step 3: Authorized users ──────────────────────────────────────────────
    console.print("\n[bold]Step 3/5 — Authorized Users[/bold]")
    console.print(
        "\n[dim]Only these Telegram user IDs can control your laptop.[/dim]\n"
        "[dim]To find your ID: message [cyan]@userinfobot[/cyan] on Telegram → send /start[/dim]\n"
    )

    existing_ids = config.allowed_ids
    if existing_ids:
        console.print(f"[yellow]Existing authorized IDs: {existing_ids}[/yellow]")
        keep_ids = Confirm.ask("Keep existing authorized users?", default=True)
        if keep_ids:
            user_ids = existing_ids
        else:
            user_ids = _collect_user_ids()
    else:
        user_ids = _collect_user_ids()

    if not user_ids:
        console.print("[red]⚠️  No authorized users set. The bot will reject all messages.[/red]")

    # ── Step 4: Optional settings ─────────────────────────────────────────────
    console.print("\n[bold]Step 4/5 — Optional Settings[/bold]\n")

    advanced = questionary.confirm(
        "Configure advanced settings? (download dir, upload dir, etc.)",
        default=False,
        style=TD_STYLE
    ).ask()

    download_dir = str(config.download_dir)
    upload_dir   = str(config.upload_dir)
    max_file_mb  = config.max_file_mb
    sc_quality   = config.screenshot_quality

    if advanced:
        download_dir = questionary.path(
            "Download directory (files sent TO Telegram):",
            default=download_dir,
            style=TD_STYLE
        ).ask() or download_dir

        upload_dir = questionary.path(
            "Upload directory (files received FROM Telegram):",
            default=upload_dir,
            style=TD_STYLE
        ).ask() or upload_dir

        max_file_mb = int(questionary.text(
            "Max file download size (MB):",
            default=str(max_file_mb),
            style=TD_STYLE,
            validate=lambda x: x.isdigit()
        ).ask() or max_file_mb)

        sc_quality = int(questionary.text(
            "Screenshot JPEG quality (1-100):",
            default=str(sc_quality),
            style=TD_STYLE,
            validate=lambda x: x.isdigit() and 1 <= int(x) <= 100
        ).ask() or sc_quality)

    # ── Step 5: AI Providers Setup ────────────────────────────────────────────
    console.print("\n[bold]Step 5/5 — AI Assistant Setup[/bold]")
    console.print(
        "\n[dim]Salim AI lets you control your laptop in plain English.[/dim]\n"
        "[dim]Example: 'download day 3' or 'write a csv about GDC' or 'mute volume'[/dim]\n\n"
        "[dim][bold]Fallback chain: NVIDIA (required) → Groq (optional) → Z.AI (optional)[/bold][/dim]\n"
    )

    from salim.ai import SalimAI, NVIDIA_MODELS, GROQ_MODELS, ZAI_MODELS

    # ─────────────────────────────────────────────────────────────────────────
    # PROVIDER 1: NVIDIA NIM (REQUIRED)
    # ─────────────────────────────────────────────────────────────────────────
    console.print(Panel.fit(
        "[bold green]🟢 Provider 1/3 — NVIDIA NIM[/bold green]  [bold red](Required)[/bold red]\n"
        "[dim]Free tier at: [cyan]https://build.nvidia.com[/cyan][/dim]\n"
        "[dim]Sign up → top-right Profile → API Keys → Generate Key[/dim]\n"
        "[dim]Key format: nvapi-xxxxxxxxxxxxxxxxxxxx[/dim]",
        border_style="green"
    ))

    nvidia_api_key = ""
    nvidia_model   = "meta/llama-4-maverick-17b-128e-instruct"

    # Check for existing key
    existing_nvidia = config.get("SALIM_NVIDIA_API_KEY", "")
    if existing_nvidia:
        console.print(f"[yellow]Existing NVIDIA key found: {existing_nvidia[:12]}...[/yellow]")
        keep = Confirm.ask("Keep existing NVIDIA key?", default=True)
        if keep:
            nvidia_api_key = existing_nvidia

    # REQUIRED: loop until we get a valid-looking key
    while not nvidia_api_key:
        nvidia_api_key = Prompt.ask(
            "\n[cyan]Paste your NVIDIA API key[/cyan] [dim](nvapi-...)[/dim]"
        ).strip()
        if not nvidia_api_key:
            console.print("[red]❌ NVIDIA key is required. Please get one free at https://build.nvidia.com[/red]")
            continue
        if not nvidia_api_key.startswith("nvapi-"):
            console.print(f"[yellow]⚠️  That doesn't look like an NVIDIA key (should start with 'nvapi-').[/yellow]")
            console.print(f"[dim]   You entered: {nvidia_api_key[:20]}...[/dim]")
            if not Confirm.ask("Try again?", default=True):
                # let them proceed with whatever they typed
                break
            nvidia_api_key = ""

    # Live test
    console.print("[dim]  Testing NVIDIA key...[/dim]", end=" ")
    valid, err_msg = _test_nvidia_key(nvidia_api_key)
    if valid:
        console.print("[green]✓ Key accepted![/green]")
    else:
        console.print(f"[red]✗ Could not verify: {err_msg}[/red]")
        console.print("[yellow]  Saving key anyway — it may still work (network/firewall issues can cause false failures).[/yellow]")

    # Model picker — always shown once key is entered
    console.print()
    console.print(Panel(
        "[bold]Top 5 NVIDIA free-tier models:[/bold]\n\n" +
        "\n".join(
            f"  [{'green' if v['tier']=='S' else 'yellow' if v['tier']=='A' else 'white'}]"
            f"[{v['tier']}] {v['label']}[/{'green' if v['tier']=='S' else 'yellow' if v['tier']=='A' else 'white'}]"
            f" [dim]| {v['best_for']} | {v['context']}[/dim]"
            for v in NVIDIA_MODELS.values()
        ),
        border_style="dim green", title="🤖 Choose Your NVIDIA Model"
    ))
    sel = questionary.select(
        "Select NVIDIA model:", choices=SalimAI.nvidia_choices(), style=TD_STYLE
    ).ask()
    if sel:
        nvidia_model = SalimAI.nvidia_id(sel)
        console.print(f"  [green]✓ NVIDIA model: {nvidia_model.split('/')[-1]}[/green]")

    # ─────────────────────────────────────────────────────────────────────────
    # PROVIDER 2: Groq (OPTIONAL fallback)
    # ─────────────────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel.fit(
        "[bold yellow]🟡 Provider 2/3 — Groq[/bold yellow]  [dim](Optional fallback — press Enter to skip)[/dim]\n"
        "[dim]Free tier at: [cyan]https://console.groq.com[/cyan][/dim]\n"
        "[dim]Sign up → API Keys → Create API Key[/dim]\n"
        "[dim]Key format: gsk_...[/dim]\n"
        "[dim]Ultra-fast inference on custom LPU chips — up to 1000 tokens/sec[/dim]",
        border_style="yellow"
    ))

    groq_api_key = ""
    groq_model   = "openai/gpt-oss-120b"

    existing_groq = config.get("SALIM_GROQ_API_KEY", "")
    if existing_groq:
        console.print(f"[yellow]Existing Groq key found: {existing_groq[:12]}...[/yellow]")
        keep = Confirm.ask("Keep existing Groq key?", default=True)
        if keep:
            groq_api_key = existing_groq

    if not groq_api_key:
        raw = Prompt.ask(
            "\n[cyan]Paste your Groq API key[/cyan] [dim](gsk_... or press Enter to skip)[/dim]",
            default=""
        ).strip()
        groq_api_key = raw

    if groq_api_key:
        if not groq_api_key.startswith("gsk_"):
            console.print("[yellow]⚠️  Expected format: gsk_xxxxxxxxxx[/yellow]")
        console.print("[dim]  Testing Groq key...[/dim]", end=" ")
        valid, err_msg = _test_groq_key(groq_api_key)
        if valid:
            console.print("[green]✓ Key accepted![/green]")
        else:
            console.print(f"[red]✗ Could not verify: {err_msg}[/red]")
            retry_raw = Prompt.ask(
                "  Try a different Groq key? [dim](paste new key or press Enter to skip)[/dim]",
                default=""
            ).strip()
            if retry_raw:
                groq_api_key = retry_raw
                console.print("[dim]  Re-testing...[/dim]", end=" ")
                valid2, err2 = _test_groq_key(groq_api_key)
                console.print("[green]✓ Accepted![/green]" if valid2 else f"[yellow]⚠️  Still failed ({err2}) — saving anyway[/yellow]")
            else:
                groq_api_key = ""
                console.print("[dim]  Groq skipped.[/dim]")

        if groq_api_key:
            console.print()
            console.print(Panel(
                "[bold]Top 5 Groq free-tier models:[/bold]\n\n" +
                "\n".join(
                    f"  [{'green' if v['tier']=='S' else 'yellow'}][{v['tier']}] {v['label']}[/{'green' if v['tier']=='S' else 'yellow'}]"
                    f" [dim]| {v['speed']} | {v['context']}[/dim]"
                    for v in GROQ_MODELS.values()
                ),
                border_style="dim yellow", title="⚡ Choose Your Groq Model"
            ))
            sel = questionary.select(
                "Select Groq model:", choices=SalimAI.groq_choices(), style=TD_STYLE
            ).ask()
            if sel:
                groq_model = SalimAI.groq_id(sel)
                console.print(f"  [green]✓ Groq model: {groq_model}[/green]")
    else:
        console.print("[dim]  Groq skipped.[/dim]")

    # ─────────────────────────────────────────────────────────────────────────
    # PROVIDER 3: Z.AI / Zhipu (OPTIONAL fallback)
    # ─────────────────────────────────────────────────────────────────────────
    console.print()
    console.print(Panel.fit(
        "[bold blue]🔵 Provider 3/3 — Z.AI (Zhipu GLM)[/bold blue]  [dim](Optional fallback — press Enter to skip)[/dim]\n"
        "[dim]Free tier at: [cyan]https://z.ai[/cyan][/dim]\n"
        "[dim]Sign up → API Keys → Create Key[/dim]\n"
        "[dim]GLM-4.7-Flash is [bold]completely FREE[/bold] with no stated usage limits[/dim]",
        border_style="blue"
    ))

    zai_api_key = ""
    zai_model   = "glm-4.7-flash"

    existing_zai = config.get("SALIM_ZAI_API_KEY", "")
    if existing_zai:
        console.print(f"[yellow]Existing Z.AI key found: {existing_zai[:12]}...[/yellow]")
        keep = Confirm.ask("Keep existing Z.AI key?", default=True)
        if keep:
            zai_api_key = existing_zai

    if not zai_api_key:
        raw = Prompt.ask(
            "\n[cyan]Paste your Z.AI API key[/cyan] [dim](or press Enter to skip)[/dim]",
            default=""
        ).strip()
        zai_api_key = raw

    if zai_api_key:
        console.print("[dim]  Testing Z.AI key...[/dim]", end=" ")
        valid, err_msg = _test_zai_key(zai_api_key)
        if valid:
            console.print("[green]✓ Key accepted![/green]")
        else:
            console.print(f"[red]✗ Could not verify: {err_msg}[/red]")
            retry_raw = Prompt.ask(
                "  Try a different Z.AI key? [dim](paste new key or press Enter to skip)[/dim]",
                default=""
            ).strip()
            if retry_raw:
                zai_api_key = retry_raw
                console.print("[dim]  Re-testing...[/dim]", end=" ")
                valid2, err2 = _test_zai_key(zai_api_key)
                console.print("[green]✓ Accepted![/green]" if valid2 else f"[yellow]⚠️  Still failed ({err2}) — saving anyway[/yellow]")
            else:
                zai_api_key = ""
                console.print("[dim]  Z.AI skipped.[/dim]")

        if zai_api_key:
            console.print()
            console.print(Panel(
                "[bold]Z.AI GLM Flash models (all 100% FREE):[/bold]\n\n" +
                "\n".join(
                    f"  [{'green' if v['tier']=='S' else 'yellow'}][{v['tier']}] {v['label']}[/{'green' if v['tier']=='S' else 'yellow'}]"
                    f" [dim]| {v['best_for']} | {v['context']}[/dim]"
                    for v in ZAI_MODELS.values()
                ),
                border_style="dim blue", title="🧠 Choose Your Z.AI Model"
            ))

            sel = questionary.select(
                "Select Z.AI model:", choices=SalimAI.zai_choices(), style=TD_STYLE
            ).ask()
            if sel:
                zai_model = SalimAI.zai_id(sel)
                console.print(f"  [green]✓ Z.AI model: {zai_model}[/green]")
    else:
        console.print("[dim]  Z.AI skipped.[/dim]")

    # Summary of what was configured
    ai_providers_set = [
        p for p, k in [("NVIDIA", nvidia_api_key), ("Groq", groq_api_key), ("Z.AI", zai_api_key)] if k
    ]
    if ai_providers_set:
        chain = " → ".join(ai_providers_set)
        console.print(f"\n[bold green]✓ AI fallback chain: {chain}[/bold green]")
    else:
        console.print("\n[yellow]⚠️  No AI providers configured. You can add keys later with `salim setup`.[/yellow]")

    # ── Save config ───────────────────────────────────────────────────────────
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        task = progress.add_task("Saving configuration...", total=None)
        config.set("SALIM_BOT_TOKEN",         bot_token)
        config.set("SALIM_ALLOWED_IDS",        ",".join(str(uid) for uid in user_ids))
        config.set("SALIM_DOWNLOAD_DIR",       download_dir)
        config.set("SALIM_UPLOAD_DIR",         upload_dir)
        config.set("SALIM_MAX_FILE_MB",        str(max_file_mb))
        config.set("SALIM_SCREENSHOT_QUALITY", str(sc_quality))
        config.set("SALIM_LOG_COMMANDS",       "true")
        if nvidia_api_key:
            config.set("SALIM_NVIDIA_API_KEY", nvidia_api_key)
            config.set("SALIM_NVIDIA_MODEL",   nvidia_model)
        if groq_api_key:
            config.set("SALIM_GROQ_API_KEY",   groq_api_key)
            config.set("SALIM_GROQ_MODEL",     groq_model)
        if zai_api_key:
            config.set("SALIM_ZAI_API_KEY",    zai_api_key)
            config.set("SALIM_ZAI_MODEL",      zai_model)
        progress.update(task, description="[green]Configuration saved![/green]", completed=True)

    console.print()
    ai_chain_str = " → ".join(ai_providers_set) if ai_providers_set else "not configured"
    console.print(Panel(
        f"[bold green]✅ Setup Complete![/bold green]\n\n"
        f"Config saved to: [cyan]{CONFIG_FILE}[/cyan]\n"
        f"🤖 AI chain: [cyan]{ai_chain_str}[/cyan]\n\n"
        f"[bold]Next steps:[/bold]\n"
        f"1. Open Telegram → your bot\n"
        f"2. Send [cyan]/start[/cyan]\n"
        f"3. [bold]Just type anything in plain English[/bold] — AI understands!\n"
        f"   Examples:\n"
        f"   • [italic]download day 3[/italic] → searches laptop\n"
        f"   • [italic]write a csv about GDC[/italic] → AI generates file\n"
        f"   • [italic]mute volume[/italic] → mutes your laptop\n"
        f"   • [italic]take a screenshot[/italic] → sends screenshot\n\n"
        f"[dim]Run: [bold]salim start[/bold] to launch your bot[/dim]",
        border_style="green"
    ))

    # Ask to start now
    if Confirm.ask("\nStart Salim now?", default=True):
        cmd_start(config)




# ── cmd_start ─────────────────────────────────────────────────────────────────
def cmd_start(config: Config, verbose: bool = False):
    if not config.is_configured:
        console.print("[yellow]⚠️  Salim is not configured yet.[/yellow]")
        if Confirm.ask("Run setup now?", default=True):
            cmd_setup(config)
        return

    # Check optional deps
    _check_optional_deps()

    console.print(Panel.fit(
        f"[bold cyan]Starting Salim[/bold cyan]\n"
        f"[dim]Bot: {config.bot_token[:15]}...[/dim]\n"
        f"[dim]Authorized: {config.allowed_ids}[/dim]\n"
        f"[dim]Host: {platform.node()}[/dim]",
        border_style="cyan"
    ))

    from salim.bot import SalimBot
    from salim.auth import setup_logging

    setup_logging(verbose)
    bot = SalimBot(config)

    console.print("[green]✅ Bot started. Open Telegram and send /start to your bot.[/green]")
    console.print("[dim]Press Ctrl+C to stop.[/dim]\n")

    try:
        bot.run(verbose=verbose)
    except KeyboardInterrupt:
        console.print("\n[yellow]Bot stopped.[/yellow]")


# ── cmd_status ────────────────────────────────────────────────────────────────
def cmd_status(config: Config):
    table = Table(title="Salim Status", box=box.ROUNDED, border_style="cyan")
    table.add_column("Setting",  style="cyan", no_wrap=True)
    table.add_column("Value",    style="white")
    table.add_column("Status",   style="green")

    def check(val, ok_fn=None):
        if ok_fn:
            return "✅" if ok_fn(val) else "❌"
        return "✅" if val else "❌"

    token = config.bot_token
    table.add_row("Bot Token",     token[:15] + "..." if token else "(not set)",   check(token))
    table.add_row("Authorized IDs", str(config.allowed_ids) or "(none)",           check(config.allowed_ids))
    table.add_row("Download Dir",  str(config.download_dir), check(config.download_dir.exists(), lambda x: x))
    table.add_row("Upload Dir",    str(config.upload_dir),   check(config.upload_dir.exists(), lambda x: x))
    table.add_row("Max File",      f"{config.max_file_mb} MB",                     "✅")
    table.add_row("Screenshot Q",  f"{config.screenshot_quality}%",                "✅")
    table.add_row("Log Commands",  str(config.log_commands),                       "✅")
    table.add_row("Config File",   str(CONFIG_FILE), check(CONFIG_FILE.exists(), lambda x: x))

    # Optional deps
    opt_deps = {"pyautogui": "Screenshot/Input", "pyperclip": "Clipboard", "aiofiles": "Fast file transfer"}
    for mod, feature in opt_deps.items():
        try:
            __import__(mod)
            table.add_row(f"{mod}", feature, "✅")
        except ImportError:
            table.add_row(f"{mod}", f"{feature} [dim](pip install {mod})[/dim]", "⚠️")

    console.print(table)

    if not config.is_configured:
        console.print("\n[yellow]Not configured. Run: [bold]salim setup[/bold][/yellow]")
    else:
        console.print("\n[green]Ready. Run: [bold]salim start[/bold][/green]")


# ── cmd_config ────────────────────────────────────────────────────────────────
def cmd_config(config: Config):
    action = questionary.select(
        "What do you want to do?",
        choices=[
            "View current configuration",
            "Edit a setting",
            "Open config file",
            "Reset to defaults",
            "Back",
        ],
        style=TD_STYLE
    ).ask()

    if action == "View current configuration":
        table = Table(box=box.SIMPLE, border_style="cyan")
        table.add_column("Key",   style="cyan")
        table.add_column("Value", style="white")
        for k, v in config.all().items():
            display_k = k.replace("SALIM_", "").lower()
            display_v = v[:12] + "..." if "TOKEN" in k and len(v) > 12 else v
            table.add_row(display_k, display_v)
        console.print(table)

    elif action == "Edit a setting":
        key_choices = [
            "max_file_mb",
            "screenshot_quality",
            "download_dir",
            "upload_dir",
            "log_commands",
        ]
        key = questionary.select("Which setting?", choices=key_choices, style=TD_STYLE).ask()
        val = Prompt.ask(f"New value for [cyan]{key}[/cyan]")
        env_key = f"SALIM_{key.upper()}"
        config.set(env_key, val)
        console.print(f"[green]✅ Set {key} = {val}[/green]")

    elif action == "Open config file":
        _open_file(str(CONFIG_FILE))

    elif action == "Reset to defaults":
        if Confirm.ask("[red]This will erase your config. Are you sure?[/red]", default=False):
            CONFIG_FILE.unlink(missing_ok=True)
            console.print("[green]Config reset. Run [bold]salim setup[/bold] again.[/green]")


# ── cmd_logs ──────────────────────────────────────────────────────────────────
def cmd_logs(config: Config):
    from salim.auth import AuthMiddleware
    auth    = AuthMiddleware(config)
    n_str   = Prompt.ask("How many entries?", default="30")
    entries = auth.get_audit_log(int(n_str))

    if not entries:
        console.print("[yellow]No log entries found.[/yellow]")
        return

    table = Table(title="Salim Audit Log", box=box.ROUNDED, border_style="cyan")
    table.add_column("Time",    style="dim",    no_wrap=True)
    table.add_column("User",    style="cyan",   no_wrap=True)
    table.add_column("Command", style="yellow", no_wrap=True)
    table.add_column("Args",    style="white")

    for e in entries:
        table.add_row(
            e.get("ts", "")[:19].replace("T", " "),
            e.get("user", "?"),
            e.get("cmd", "?"),
            e.get("args", "")[:60]
        )
    console.print(table)


# ── cmd_test ──────────────────────────────────────────────────────────────────
def cmd_test(config: Config):
    if not config.bot_token:
        console.print("[red]No token configured. Run [bold]salim setup[/bold] first.[/red]")
        return

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        t = progress.add_task("Connecting to Telegram...", total=None)
        info = _test_token(config.bot_token)
        if info:
            progress.update(t, description=f"[green]✅ Connected as @{info['username']}[/green]", completed=True)
        else:
            progress.update(t, description="[red]❌ Connection failed[/red]", completed=True)

    if info:
        console.print(f"\n[bold]Bot Info:[/bold]")
        console.print(f"  Name:     {info['first_name']}")
        console.print(f"  Username: @{info['username']}")
        console.print(f"  ID:       {info['id']}")
        console.print(f"\n[green]Everything looks good! Run [bold]salim start[/bold][/green]")
    else:
        console.print("\n[red]Could not connect. Check your token and internet connection.[/red]")


# ── cmd_adduser ───────────────────────────────────────────────────────────────
def cmd_adduser(config: Config):
    console.print(
        "\n[dim]Find your Telegram ID: message [cyan]@userinfobot[/cyan] → send /start[/dim]\n"
    )
    uid_str = Prompt.ask("[cyan]Enter Telegram User ID to authorize[/cyan]")
    try:
        uid = int(uid_str.strip())
    except ValueError:
        console.print("[red]❌ User ID must be a number.[/red]")
        return

    existing = config.allowed_ids
    if uid in existing:
        console.print(f"[yellow]User {uid} is already authorized.[/yellow]")
        return

    existing.append(uid)
    config.set("SALIM_ALLOWED_IDS", ",".join(str(x) for x in existing))
    console.print(f"[green]✅ Added user {uid}. Authorized IDs: {existing}[/green]")
    console.print("[dim]Restart Salim for the change to take effect.[/dim]")


# ── cmd_stop ──────────────────────────────────────────────────────────────────
def cmd_stop(config: Config):
    pid_file = CONFIG_DIR / "salim.pid"
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 15)
            pid_file.unlink()
            console.print(f"[green]✅ Stopped Salim (PID {pid})[/green]")
        except Exception as e:
            console.print(f"[red]❌ Could not stop: {e}[/red]")
    else:
        console.print("[yellow]No running Salim process found.[/yellow]")
        console.print("[dim]If it's running, press Ctrl+C in its terminal.[/dim]")


# ── cmd_uninstall ─────────────────────────────────────────────────────────────
def cmd_uninstall(config: Config):
    console.print("[bold red]⚠️  This will delete all Salim data:[/bold red]")
    console.print(f"  - {CONFIG_DIR}")
    if Confirm.ask("[red]Are you sure?[/red]", default=False):
        if Confirm.ask("[red]Really sure? This cannot be undone.[/red]", default=False):
            import shutil
            shutil.rmtree(CONFIG_DIR, ignore_errors=True)
            console.print("[green]✅ Removed all Salim data.[/green]")
            console.print("[dim]To uninstall package: pip uninstall salim[/dim]")


# ── Helpers ───────────────────────────────────────────────────────────────────
def _validate_token_format(token: str) -> bool:
    parts = token.strip().split(":")
    return len(parts) == 2 and parts[0].isdigit() and len(parts[1]) > 20


def _test_token(token: str) -> dict | None:
    import urllib.request
    import json as _json
    try:
        url = f"https://api.telegram.org/bot{token}/getMe"
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = _json.loads(resp.read().decode())
            if data.get("ok"):
                return data["result"]
    except Exception:
        pass
    return None


def _collect_user_ids() -> list[int]:
    ids = []
    console.print("[dim]Enter user IDs one by one. Press Enter with empty input when done.[/dim]")
    while True:
        uid_str = Prompt.ask("[cyan]Telegram User ID[/cyan] (or Enter to finish)", default="")
        if not uid_str:
            break
        try:
            uid = int(uid_str.strip())
            ids.append(uid)
            console.print(f"[green]  ✓ Added {uid}[/green]")
        except ValueError:
            console.print("[red]  Invalid ID — must be a number[/red]")
    return ids


def _check_optional_deps():
    optional = {
        "pyautogui":    "Screenshot & mouse/keyboard control",
        "pyperclip":    "Clipboard text read/write",
        "aiofiles":     "Fast async file transfer",
        # v9 new feature dependencies
        "gtts":         "Text-to-Speech (gTTS — Google voices)",
        "pyttsx3":      "Text-to-Speech offline (system voices)",
        "asyncssh":     "SSH remote machine control",
        "playwright":   "Browser automation (run: python -m playwright install chromium)",
        "PIL":          "Image processing (Pillow)",
    }
    missing = []
    for mod, desc in optional.items():
        try:
            __import__(mod)
        except ImportError:
            missing.append((mod, desc))

    if missing:
        console.print("\n[yellow]⚠️  Optional features missing:[/yellow]")
        for mod, desc in missing:
            pkg = "Pillow" if mod == "PIL" else mod
            console.print(f"  [dim]• {pkg}: {desc}[/dim]")

        pkg_list = []
        for mod, _ in missing:
            pkg = "Pillow" if mod == "PIL" else mod
            pkg_list.append(pkg)
        console.print(f"[dim]  Install all: pip install {' '.join(pkg_list)}[/dim]")
        console.print(f"[dim]  Then: python -m playwright install chromium[/dim]\n")


def _open_file(path: str):
    OS = platform.system()
    if OS == "Darwin":
        subprocess.run(["open", path])
    elif OS == "Windows":
        os.startfile(path)
    else:
        subprocess.run(["xdg-open", path])


if __name__ == "__main__":
    main()
