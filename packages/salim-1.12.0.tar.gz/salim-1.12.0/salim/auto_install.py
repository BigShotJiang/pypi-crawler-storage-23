"""
salim.auto_install — Automatic dependency installer.

Called:
  1. As a setuptools post-install hook (via salim/_post_install.py)
  2. On first `salim` CLI invocation (early bootstrap)
  3. Lazily by individual handlers before they need an optional lib

Philosophy
----------
- Required libs  → install silently, fail loudly if they can't be installed
- Optional libs  → install silently, warn once but continue
- System tools   → detect and print a clear install hint, never sudo blindly
- Playwright     → install + `playwright install chromium` automatically
- Everything is idempotent (safe to call multiple times)
"""

from __future__ import annotations

import importlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

# ── Constants ─────────────────────────────────────────────────────────────────

STAMP_FILE = Path.home() / ".salim" / "auto_install_done.json"

# Required packages: (import_name, pip_name)
REQUIRED: list[tuple[str, str]] = [
    ("telegram",       "python-telegram-bot[job-queue]>=21.0"),
    ("psutil",         "psutil>=5.9"),
    ("PIL",            "Pillow>=10.0"),
    ("pyautogui",      "pyautogui>=0.9.54"),
    ("pyperclip",      "pyperclip>=1.8"),
    ("rich",           "rich>=13.0"),
    ("questionary",    "questionary>=2.0"),
    ("cryptography",   "cryptography>=41.0"),
    ("httpx",          "httpx>=0.25"),
    ("aiofiles",       "aiofiles>=23.0"),
    ("dotenv",         "python-dotenv>=1.0"),
    ("openpyxl",       "openpyxl>=3.1"),
    ("faster_whisper", "faster-whisper>=1.0"),
    ("cv2",            "opencv-python-headless>=4.8"),
    ("mss",            "mss>=9.0"),
    ("pynput",         "pynput>=1.7"),
]

# Optional packages: (import_name, pip_name, feature_description)
OPTIONAL: list[tuple[str, str, str]] = [
    ("gtts",       "gTTS>=2.4",          "Text-to-Speech (online)"),
    ("pyttsx3",    "pyttsx3>=2.90",      "Text-to-Speech (offline)"),
    ("asyncssh",   "asyncssh>=2.14",     "SSH remote control"),
    ("playwright", "playwright>=1.40",   "Browser automation"),
    ("pydub",      "pydub>=0.25",        "Audio conversion (TTS → OGG)"),
    ("qrcode",     "qrcode[pil]>=7.4",   "QR code generation"),
    ("schedule",   "schedule>=1.2",      "Advanced job scheduler"),
    ("speedtest",  "speedtest-cli>=2.1", "Internet speed test"),
    ("paramiko",   "paramiko>=3.4",      "SSH fallback (password auth)"),
    ("notify2",    "notify2>=0.3",       "Linux desktop notifications"),
    ("plyer",      "plyer>=2.1",         "Cross-platform notifications"),
    ("pytz",       "pytz>=2024.1",       "Timezone support"),
    ("babel",      "Babel>=2.14",        "Locale/number formatting"),
    ("barcode",    "python-barcode>=0.15","Barcode generation"),
    ("magic",      "python-magic>=0.4",  "MIME type detection"),
    ("watchdog",   "watchdog>=4.0",      "File system watching"),
    ("pyaudio",    "PyAudio>=0.2.14",    "Live microphone input"),
]

# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_importable(mod: str) -> bool:
    return importlib.util.find_spec(mod) is not None

def _pip_install(pkg: str, quiet: bool = True) -> bool:
    """Install a pip package. Returns True on success."""
    cmd = [sys.executable, "-m", "pip", "install", pkg]
    if quiet:
        cmd += ["--quiet", "--disable-pip-version-check"]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        return result.returncode == 0
    except Exception:
        return False

def _system_has(binary: str) -> bool:
    return shutil.which(binary) is not None

def _platform() -> str:
    s = platform.system().lower()
    if s == "darwin":
        return "macos"
    if s == "windows":
        return "windows"
    return "linux"

# ── Main installer ────────────────────────────────────────────────────────────

def run_auto_install(
    verbose: bool = False,
    force: bool = False,
    skip_optional: bool = False,
    console=None,          # rich Console, if available
) -> dict:
    """
    Install all required and optional packages.
    Returns a result dict with 'installed', 'failed', 'skipped' lists.
    """

    def _print(msg: str):
        if console:
            console.print(msg)
        elif verbose:
            print(msg)

    result = {"installed": [], "failed": [], "skipped": [], "already_ok": []}

    STAMP_FILE.parent.mkdir(parents=True, exist_ok=True)

    # Check stamp — skip if already done this version (unless forced)
    if not force and STAMP_FILE.exists():
        try:
            stamp = json.loads(STAMP_FILE.read_text())
            if stamp.get("version") == _salim_version():
                return result  # Already done for this version
        except Exception:
            pass

    _print("[bold cyan]🔧 Salim: Installing dependencies…[/bold cyan]")
    t0 = time.time()

    # ── Required ──────────────────────────────────────────────────────────────
    for mod, pkg in REQUIRED:
        if _is_importable(mod):
            result["already_ok"].append(pkg)
            continue
        _print(f"  [yellow]Installing[/yellow] {pkg} …")
        ok = _pip_install(pkg)
        if ok:
            result["installed"].append(pkg)
            _print(f"  [green]✓[/green] {pkg}")
        else:
            result["failed"].append(pkg)
            _print(f"  [red]✗ Failed:[/red] {pkg} — run: pip install {pkg}")

    # ── Optional ──────────────────────────────────────────────────────────────
    if not skip_optional:
        for mod, pkg, desc in OPTIONAL:
            if _is_importable(mod):
                result["already_ok"].append(pkg)
                continue
            _print(f"  [dim]Installing optional[/dim] {pkg} [dim]({desc})[/dim] …")
            ok = _pip_install(pkg)
            if ok:
                result["installed"].append(pkg)
                _print(f"  [green]✓[/green] {pkg}")
            else:
                result["skipped"].append(pkg)
                _print(f"  [dim]⚠ Skipped:[/dim] {pkg}")

    # ── Playwright browsers ───────────────────────────────────────────────────
    if _is_importable("playwright"):
        _print("  [dim]Installing Playwright browser (chromium)…[/dim]")
        try:
            subprocess.run(
                [sys.executable, "-m", "playwright", "install", "chromium", "--quiet"],
                capture_output=True, timeout=180
            )
            result["installed"].append("playwright-chromium")
            _print("  [green]✓[/green] Playwright chromium")
        except Exception as e:
            result["skipped"].append("playwright-chromium")
            _print(f"  [dim]⚠ Playwright browser install skipped: {e}[/dim]")

    # ── System tool hints ─────────────────────────────────────────────────────
    system_hints: dict[str, dict[str, str]] = {
        "ffmpeg": {
            "linux":   "sudo apt install ffmpeg",
            "macos":   "brew install ffmpeg",
            "windows": "choco install ffmpeg  (or download from https://ffmpeg.org)",
        },
    }
    for binary, hints in system_hints.items():
        if not _system_has(binary):
            plat = _platform()
            hint = hints.get(plat, f"Install {binary} for your platform")
            _print(f"  [yellow]System tool missing:[/yellow] {binary} — {hint}")

    # ── Stamp ─────────────────────────────────────────────────────────────────
    stamp = {
        "version":    _salim_version(),
        "timestamp":  time.time(),
        "installed":  result["installed"],
        "failed":     result["failed"],
    }
    try:
        STAMP_FILE.write_text(json.dumps(stamp, indent=2))
    except Exception:
        pass

    elapsed = time.time() - t0
    if result["installed"]:
        _print(
            f"\n[green]✅ Salim deps ready[/green] "
            f"({len(result['installed'])} installed, {elapsed:.1f}s)"
        )
    if result["failed"]:
        _print(f"[red]❌ {len(result['failed'])} package(s) failed — see above.[/red]")

    return result


def ensure_one(import_name: str, pip_name: str) -> bool:
    """
    Ensure a single package is available, installing it if needed.
    Returns True if available after the call.
    """
    if _is_importable(import_name):
        return True
    return _pip_install(pip_name)


def _salim_version() -> str:
    try:
        from salim import __version__
        return __version__
    except Exception:
        return "unknown"
