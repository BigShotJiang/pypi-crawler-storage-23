"""
SalimBot — Main bot class that assembles all handler modules.
Now includes AI natural language handler via NVIDIA NIM.
"""

from __future__ import annotations

import asyncio
import logging
import platform
from pathlib import Path

from telegram import (
    BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
)
from telegram.ext import (
    Application, ApplicationBuilder, CallbackQueryHandler,
    CommandHandler, ContextTypes, MessageHandler, filters
)

from salim.auth import AuthMiddleware, require_auth
from salim.config import Config
from salim.handlers.system import SystemHandlers
from salim.handlers.shell  import ShellHandlers
from salim.handlers.files  import FileHandlers
from salim.handlers.screen import ScreenHandlers
from salim.handlers.power  import PowerHandlers
from salim.handlers.ai_handler import AIHandler          # ← NEW
from salim.handlers.document_writer import DocumentHandlers
from salim.handlers.voice       import VoiceHandlers
from salim.handlers.camera      import CameraHandlers
from salim.handlers.alerts      import AlertHandlers, start_monitor
from salim.handlers.history     import ConversationHistoryHandlers
from salim.handlers.code_runner import CodeRunnerHandlers
from salim.handlers.guard       import IntrusionHandlers
from salim.handlers.smart_upload import SmartUploadHandlers
from salim.handlers.clipboard_image import ClipboardImageHandlers   # Feature 2: clipboard images
from salim.handlers.stream import ScreenStreamHandlers               # Feature 3: live stream
from salim.handlers.browser import BrowserHandlers                   # Feature 5: browser automation
from salim.handlers.tts import TTSHandlers                           # Feature 8: text-to-speech
from salim.handlers.ssh_handler import SSHHandlers                   # Feature 9: SSH remote control
from salim.handlers.vision import VisionHandlers                     # Feature 11: vision AI
# ── v10: New features ────────────────────────────────────────────────────────
from salim.handlers.speedtest_handler import SpeedTestHandlers       # v10: /speedtest
from salim.handlers.qr_handler        import QRHandlers              # v10: /qr /qrread
from salim.handlers.watcher_handler   import WatcherHandlers         # v10: /watch /watchlist /watchstop
from salim.handlers.notes_handler     import NotesHandlers           # v10: /note /notes /notedel
from salim.handlers.scheduler_handler import SchedulerHandlers       # v10: /at /every /jobs /jobcancel
# ── v11: New features ────────────────────────────────────────────────────────
from salim.handlers.mic_handler import MicHandlers                   # v11: /mic microphone recording
import html
from salim.utils import short_time

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

logger = logging.getLogger("salim.bot")


class SalimBot(
    SystemHandlers, ShellHandlers, FileHandlers,
    ScreenHandlers, PowerHandlers,
    AIHandler,
    DocumentHandlers,
    VoiceHandlers,
    CameraHandlers,
    AlertHandlers,
    ConversationHistoryHandlers,
    CodeRunnerHandlers,
    IntrusionHandlers,
    SmartUploadHandlers,
    ClipboardImageHandlers,    # v9: clipboard image support
    ScreenStreamHandlers,      # v9: live screen stream
    BrowserHandlers,           # v9: browser automation
    TTSHandlers,               # v9: text-to-speech
    SSHHandlers,               # v9: SSH remote control
    VisionHandlers,            # v9: vision AI
    SpeedTestHandlers,         # v10: internet speed test
    QRHandlers,                # v10: QR code generate + read
    WatcherHandlers,           # v10: file system watcher
    NotesHandlers,             # v10: quick notes scratchpad
    SchedulerHandlers,         # v10: task scheduler
    MicHandlers,               # v11: microphone recording
):
    """
    Main Salim bot — composes all handler mixins into one class.
    AIHandler adds natural language understanding via NVIDIA NIM.
    """

    def __init__(self, config: Config):
        self.config = config
        self.auth   = AuthMiddleware(config)
        self._cwd   = str(Path.home())
        # v9: override /paste with smart version (handles images + text)
        self.cmd_paste = self.cmd_paste_smart

    # ── Build telegram Application ───────────────────────────────────────────
    def build(self) -> Application:
        app = (
            ApplicationBuilder()
            .token(self.config.bot_token)
            .build()
        )
        self._register_handlers(app)
        return app

    def _register_handlers(self, app: Application):
        # ── Start / Help ──────────────────────────────────────────────────────
        app.add_handler(CommandHandler("start",      self.cmd_start))
        app.add_handler(CommandHandler("help",       self.cmd_help))
        app.add_handler(CommandHandler("status",     self.cmd_status))
        app.add_handler(CommandHandler("config",     self.cmd_config))
        app.add_handler(CommandHandler("logs",       self.cmd_logs))

        # ── System ───────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("info",       self.cmd_info))
        app.add_handler(CommandHandler("cpu",        self.cmd_cpu))
        app.add_handler(CommandHandler("mem",        self.cmd_mem))
        app.add_handler(CommandHandler("disk",       self.cmd_disk))
        app.add_handler(CommandHandler("battery",    self.cmd_battery))
        app.add_handler(CommandHandler("network",    self.cmd_network))
        app.add_handler(CommandHandler("uptime",     self.cmd_uptime))
        app.add_handler(CommandHandler("ps",         self.cmd_ps))
        app.add_handler(CommandHandler("top",        self.cmd_top))
        app.add_handler(CommandHandler("kill",       self.cmd_kill))

        # ── Shell ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("run",        self.cmd_run))
        app.add_handler(CommandHandler("sh",         self.cmd_run))
        app.add_handler(CommandHandler("exec",       self.cmd_run))
        app.add_handler(CommandHandler("runbg",      self.cmd_runbg))
        app.add_handler(CommandHandler("pipe",       self.cmd_pipe))
        app.add_handler(CommandHandler("env",        self.cmd_env))
        app.add_handler(CommandHandler("which",      self.cmd_which))
        app.add_handler(CommandHandler("cron",       self.cmd_cron))
        app.add_handler(CommandHandler("cronstop",   self.cmd_cronstop))
        app.add_handler(CommandHandler("cronjobs",   self.cmd_cronjobs))

        # ── Files ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("ls",         self.cmd_ls))
        app.add_handler(CommandHandler("cd",         self.cmd_cd))
        app.add_handler(CommandHandler("pwd",        self.cmd_pwd))
        app.add_handler(CommandHandler("cat",        self.cmd_cat))
        app.add_handler(CommandHandler("stat",       self.cmd_stat))
        app.add_handler(CommandHandler("find",       self.cmd_find))
        app.add_handler(CommandHandler("grep",       self.cmd_grep))
        app.add_handler(CommandHandler("mkdir",      self.cmd_mkdir))
        app.add_handler(CommandHandler("rm",         self.cmd_rm))
        app.add_handler(CommandHandler("mv",         self.cmd_mv))
        app.add_handler(CommandHandler("cp",         self.cmd_cp))
        app.add_handler(CommandHandler("download",   self.cmd_download))
        app.add_handler(CommandHandler("upload",     self.cmd_upload_prompt))
        app.add_handler(CommandHandler("zip",        self.cmd_zip))
        app.add_handler(CommandHandler("unzip",      self.cmd_unzip))
        app.add_handler(CommandHandler("write",      self.cmd_write))

        # ── Screen ────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("screenshot", self.cmd_screenshot))
        app.add_handler(CommandHandler("ss",         self.cmd_screenshot))
        app.add_handler(CommandHandler("type",       self.cmd_type))
        app.add_handler(CommandHandler("key",        self.cmd_key))
        app.add_handler(CommandHandler("click",      self.cmd_click))
        app.add_handler(CommandHandler("scroll",     self.cmd_scroll))
        app.add_handler(CommandHandler("move",       self.cmd_move))
        app.add_handler(CommandHandler("mousepos",   self.cmd_mousepos))
        app.add_handler(CommandHandler("notify",     self.cmd_notify))
        app.add_handler(CommandHandler("volume",     self.cmd_volume))
        app.add_handler(CommandHandler("brightness", self.cmd_brightness))
        app.add_handler(CommandHandler("copy",       self.cmd_copy))
        app.add_handler(CommandHandler("paste",      self.cmd_paste))
        app.add_handler(CommandHandler("open",       self.cmd_open))

        # ── Document Writer ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("doc",        self.cmd_doc))

        # ── Camera & Recording ───────────────────────────────────────────────────
        app.add_handler(CommandHandler("cam",        self.cmd_cam))
        app.add_handler(CommandHandler("record",     self.cmd_record))

        # ── Alerts ───────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("alert",      self.cmd_alert))

        # ── Conversation History ──────────────────────────────────────────────────
        app.add_handler(CommandHandler("history",    self.cmd_history))

        # ── AI Code Runner ────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("code",       self.cmd_code))

        # ── Intrusion Guard ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("guard",      self.cmd_guard))

        # ── Smart Upload ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("uploads",    self.cmd_uploads_history))

        # ── Voice status ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("voicestatus", self.cmd_voice_status))

        # ── v9: Clipboard Image ────────────────────────────────────────────────────
        app.add_handler(CommandHandler("copyphoto",  self.cmd_copyphoto))

        # ── v9: Live Screen Stream ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("stream",      self.cmd_stream))
        app.add_handler(CommandHandler("streamstop",  self.cmd_streamstop))

        # ── v9: Browser Automation ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("browse",          self.cmd_browse))
        app.add_handler(CommandHandler("browse_click",    self.cmd_browse_click))
        app.add_handler(CommandHandler("browse_type",     self.cmd_browse_type))
        app.add_handler(CommandHandler("browse_scroll",   self.cmd_browse_scroll))
        app.add_handler(CommandHandler("browse_js",       self.cmd_browse_js))
        app.add_handler(CommandHandler("browse_back",     self.cmd_browse_back))
        app.add_handler(CommandHandler("browse_get",      self.cmd_browse_get))
        app.add_handler(CommandHandler("browse_close",    self.cmd_browse_close))

        # ── v9: Text-to-Speech ─────────────────────────────────────────────────────
        app.add_handler(CommandHandler("tts",         self.cmd_tts))
        app.add_handler(CommandHandler("say",         self.cmd_say))
        app.add_handler(CommandHandler("tts_lang",    self.cmd_tts_lang))
        app.add_handler(CommandHandler("tts_speed",   self.cmd_tts_speed))
        app.add_handler(CommandHandler("tts_engine",  self.cmd_tts_engine))
        app.add_handler(CommandHandler("tts_voice",   self.cmd_tts_voice))

        # ── v9: SSH Remote Control ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("ssh_add",      self.cmd_ssh_add))
        app.add_handler(CommandHandler("ssh_list",     self.cmd_ssh_list))
        app.add_handler(CommandHandler("ssh",          self.cmd_ssh))
        app.add_handler(CommandHandler("ssh_remove",   self.cmd_ssh_remove))
        app.add_handler(CommandHandler("ssh_password", self.cmd_ssh_password))
        app.add_handler(CommandHandler("ssh_upload",   self.cmd_ssh_upload))
        app.add_handler(CommandHandler("ssh_download", self.cmd_ssh_download))

        # ── v9: Vision AI ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("vision",       self.cmd_vision))
        app.add_handler(CommandHandler("askvision",    self.cmd_askvision))

        # ── v10: Speed Test ────────────────────────────────────────────────────
        app.add_handler(CommandHandler("speedtest",    self.cmd_speedtest))

        # ── v10: QR Code ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("qr",           self.cmd_qr))
        app.add_handler(CommandHandler("qrread",       self.cmd_qrread))

        # ── v10: File Watcher ──────────────────────────────────────────────────
        app.add_handler(CommandHandler("watch",        self.cmd_watch))
        app.add_handler(CommandHandler("watchlist",    self.cmd_watchlist))
        app.add_handler(CommandHandler("watchstop",    self.cmd_watchstop))

        # ── v10: Notes Scratchpad ─────────────────────────────────────────────
        app.add_handler(CommandHandler("note",         self.cmd_note))
        app.add_handler(CommandHandler("notes",        self.cmd_notes))
        app.add_handler(CommandHandler("notedel",      self.cmd_notedel))
        app.add_handler(CommandHandler("noteclear",    self.cmd_noteclear))

        # ── v10: Task Scheduler ───────────────────────────────────────────────
        app.add_handler(CommandHandler("at",           self.cmd_at))
        app.add_handler(CommandHandler("every",        self.cmd_every))
        app.add_handler(CommandHandler("jobs",         self.cmd_jobs))
        app.add_handler(CommandHandler("jobcancel",    self.cmd_jobcancel))

        # ── v11: Microphone Recording ─────────────────────────────────────
        app.add_handler(CommandHandler("mic",          self.cmd_mic))

        # ── Power ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("shutdown",   self.cmd_shutdown))
        app.add_handler(CommandHandler("restart",    self.cmd_restart))
        app.add_handler(CommandHandler("sleep",      self.cmd_sleep))
        app.add_handler(CommandHandler("lock",       self.cmd_lock))
        app.add_handler(CommandHandler("logout",     self.cmd_logout))
        app.add_handler(CommandHandler("hibernate",  self.cmd_hibernate))
        app.add_handler(CommandHandler("screensaver",self.cmd_screensaver))
        app.add_handler(CommandHandler("displays",   self.cmd_displays))

        # ── Callback queries ──────────────────────────────────────────────────
        # Order matters: ai_handler callbacks checked first, then existing ones
        app.add_handler(CallbackQueryHandler(self._dispatch_callback))

        # ── Documents (file uploads) — smart upload with folder picker ─────────
        app.add_handler(MessageHandler(
            filters.Document.ALL,
            self.handle_document_smart
        ))

        # ── Photos — vision AI handler ─────────────────────────────────────────
        app.add_handler(MessageHandler(
            filters.PHOTO,
            self.handle_photo_message
        ))

        # ── Text replies to photos — vision AI ────────────────────────────────
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.REPLY,
            self._handle_text_or_photo_reply
        ))

        # ── Voice / Audio messages → transcribe & execute ─────────────────────
        app.add_handler(MessageHandler(
            filters.VOICE | filters.AUDIO,
            self.handle_voice_message
        ))

        # ── Unknown /commands ─────────────────────────────────────────────────
        app.add_handler(MessageHandler(
            filters.COMMAND,
            self.cmd_unknown
        ))

        # ── AI: plain text messages (non-reply, MUST be last) ─────────────────
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & ~filters.REPLY,
            self.handle_ai_message
        ))

        # ── Post-init: set bot command menu + start background services ─────
        async def post_init(app2: Application):
            await app2.bot.set_my_commands(self._bot_commands())
            # Start alert monitor if alerts exist
            self._start_alert_monitor(app2)
            # Store app reference for callbacks
            self._app = app2
        app.post_init = post_init

    # ── /start ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        from salim.ai import SalimAI
        ai = SalimAI(self.config)
        ai_status = ai.status_line()

        keyboard = [
            [
                InlineKeyboardButton("💻 System",     callback_data="dash:info"),
                InlineKeyboardButton("📸 Screenshot", callback_data="dash:screenshot"),
                InlineKeyboardButton("📊 Top",        callback_data="dash:top"),
            ],
            [
                InlineKeyboardButton("📂 Files",      callback_data="dash:ls"),
                InlineKeyboardButton("⚙️ Processes",  callback_data="dash:ps"),
                InlineKeyboardButton("🌐 Network",    callback_data="dash:network"),
            ],
            [
                InlineKeyboardButton("🔋 Battery",    callback_data="dash:battery"),
                InlineKeyboardButton("📋 Clipboard",  callback_data="dash:paste"),
                InlineKeyboardButton("💿 Disk",       callback_data="dash:disk"),
            ],
            [
                InlineKeyboardButton("📋 All Commands", callback_data="dash:help"),
                InlineKeyboardButton("⚙️ Config",       callback_data="dash:config"),
            ],
        ]
        markup = InlineKeyboardMarkup(keyboard)
        user   = update.effective_user
        os_name = platform.system()
        await update.effective_message.reply_text(
            f"🖥️ <b>Salim</b> — {esc(os_name)} Control\n\n"
            f"Hello, {esc(user.first_name)}! Your laptop is ready.\n"
            f"📂 CWD: <code>{esc(self._cwd)}</code>\n"
            f"🕐 {short_time()}\n"
            f"{esc(ai_status)}\n\n"
            "💬 <b>Just type anything in plain English — AI will understand!</b>\n"
            "Or choose an action below:",
            parse_mode=H,
            reply_markup=markup
        )

    # ── /help ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "📋 <b>Salim v11 Commands</b>\n\n"

            "🤖 <b>AI Mode — just type in plain English!</b>\n\n"

            "🖥️ <b>System</b>\n"
            "<code>/info /cpu /mem /disk /battery /network /uptime /top</code>\n\n"

            "⚙️ <b>Processes</b>\n"
            "<code>/ps [name]  /kill &lt;pid&gt;  /top</code>\n\n"

            "💻 <b>Shell</b>\n"
            "<code>/run  /runbg  /pipe  /env  /which  /cron  /cronjobs  /cronstop</code>\n\n"

            "📂 <b>Files</b>\n"
            "<code>/ls  /cd  /pwd  /cat  /stat  /find  /grep</code>\n"
            "<code>/mkdir  /rm  /mv  /cp  /write  /download  /upload  /zip  /unzip</code>\n\n"

            "📸 <b>Screen &amp; Input</b>\n"
            "<code>/screenshot  /stream [interval] [secs]  /streamstop</code>\n"
            "<code>/type  /key  /click  /scroll  /move  /open</code>\n\n"

            "📋 <b>Clipboard</b>\n"
            "<code>/paste</code> — read text OR image from clipboard\n"
            "<code>/copy &lt;text&gt;</code> — copy text\n"
            "<code>/copyphoto</code> — reply to a photo to copy it to clipboard\n\n"

            "🎙️ <b>Microphone &amp; Voice</b>\n"
            "<code>/mic</code> — record 10s from laptop mic → sends voice note to Telegram\n"
            "<code>/mic 30</code> — record 30 seconds\n"
            "<code>/mic 10 exec</code> — record, transcribe, execute as command\n"
            "<code>/mic 5 trans</code> — record, transcribe only (show text)\n"
            "Send any voice note — transcribed and executed via AI\n\n"

            "🔊 <b>Volume (real control)</b>\n"
            "<code>/volume</code> — get current volume\n"
            "<code>/volume 75</code> — set to 75%\n"
            "<code>/volume up</code> — increase +10%\n"
            "<code>/volume down</code> — decrease -10%\n"
            "<code>/volume mute</code> — mute\n"
            "<code>/volume unmute</code> — unmute\n"
            "Uses: pulsectl → pactl → amixer (Linux), osascript (Mac)\n\n"

            "🚀 <b>Open Apps</b>\n"
            "<code>/open chrome</code> — launch Chrome (or say <i>'open chrome'</i>)\n"
            "<code>/open spotify</code> — launch Spotify\n"
            "<code>/open https://youtube.com</code> — open URL\n"
            "<code>/open ~/file.pdf</code> — open file\n"
            "Supports: chrome, firefox, vscode, spotify, discord, slack, zoom, vlc, gimp, obs, terminal...\n\n"

            "🌐 <b>Browser Automation (Playwright)</b>\n"
            "<code>/browse &lt;url&gt;</code> — open + screenshot\n"
            "<code>/browse_click &lt;selector&gt;</code> — click element\n"
            "<code>/browse_type &lt;selector&gt; &lt;text&gt;</code> — type in field\n"
            "<code>/browse_scroll [up|down|top|bottom]</code>\n"
            "<code>/browse_js &lt;javascript&gt;</code> — run JS\n"
            "<code>/browse_back  /browse_get &lt;url&gt;  /browse_close</code>\n\n"

            "🗣️ <b>Text-to-Speech</b>\n"
            "<code>/tts &lt;text&gt;</code> — Salim speaks to you\n"
            "<code>/say &lt;text&gt;</code> — same as /tts\n"
            "<code>/tts_lang &lt;en|ar|fr|...&gt;</code> — set language\n"
            "<code>/tts_speed &lt;0.5-2.0&gt;  /tts_engine  /tts_voice</code>\n\n"

            "🔌 <b>SSH Remote Control</b>\n"
            "<code>/ssh_add &lt;alias&gt; &lt;user@host&gt; [port] [--key /path]</code>\n"
            "<code>/ssh &lt;alias&gt; &lt;command&gt;</code> — run command on remote\n"
            "<code>/ssh_list  /ssh_remove  /ssh_password</code>\n"
            "<code>/ssh_upload &lt;alias&gt; &lt;local&gt; &lt;remote&gt;</code>\n"
            "<code>/ssh_download &lt;alias&gt; &lt;remote_path&gt;</code>\n\n"

            "👁️ <b>Vision AI (Image Understanding)</b>\n"
            "Send any photo, then ask questions about it\n"
            "<code>/vision on</code> — auto-describe all photos\n"
            "<code>/askvision &lt;question&gt;</code> — ask about last photo\n\n"

            "🔔 <b>UI &amp; Media</b>\n"
            "<code>/notify  /volume  /brightness</code>\n\n"

            "🔋 <b>Power</b>\n"
            "<code>/shutdown  /restart  /sleep  /hibernate  /lock  /logout</code>\n\n"

            "📄 <b>Document Writer (Real Files)</b>\n"
            "<code>/doc resume  /doc invoice  /doc cover letter  /doc budget</code>\n"
            "Or say: <i>'write me a resume for Ahmed, software engineer'</i>\n\n"

            "🔍 <b>Smart File Search</b>\n"
            "Say: <i>'find my Day 03 video'</i> or <i>'download lecture notes'</i>\n"
            "→ AI searches your whole laptop, shows results with buttons:\n"
            "⬇️ Download · 🗑️ Delete · ▶️ Play · 📂 Open\n\n"

            "📷 <b>Camera &amp; Recording</b>\n"
            "<code>/cam  /cam list  /record &lt;seconds&gt;</code>\n\n"

            "🚨 <b>Alerts</b>\n"
            "<code>/alert add cpu &gt; 80  /alert list  /alert del &lt;id&gt;</code>\n\n"

            "🧑‍💻 <b>AI Code Runner</b>\n"
            "<code>/code &lt;describe what to build&gt;</code>\n\n"

            "🛡️ <b>Intrusion Guard</b>\n"
            "<code>/guard on  /guard off  /guard status</code>\n\n"

            "📤 <b>Smart Upload</b>\n"
            "Send any file → pick destination folder\n\n"

            "⚡ <b>v10 Features</b>\n"
            "<code>/speedtest  /qr  /qrread  /watch  /watchlist  /watchstop</code>\n"
            "<code>/note  /notes  /notedel  /at  /every  /jobs  /jobcancel</code>\n\n"

            "⚙️ <b>Bot</b>\n"
            "<code>/config  /logs  /status  /history</code>"
        )
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /status ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        import psutil
        from salim.utils import bytes_to_human
        from salim.ai import SalimAI
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        ai  = SalimAI(self.config)
        text = (
            f"✅ <b>Salim Online</b>\n"
            f"🕐 {short_time()} · {esc(platform.node())}\n"
            f"📂 <code>{esc(self._cwd)}</code>\n"
            f"⚙️ CPU {cpu}% · RAM {mem.percent}%\n"
            f"{esc(ai.status_line())}"
        )
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /config ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_config(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if ctx.args and ctx.args[0] == "set" and len(ctx.args) >= 3:
            key_map = {
                "max_file_mb":        "SALIM_MAX_FILE_MB",
                "screenshot_quality": "SALIM_SCREENSHOT_QUALITY",
                "log_commands":       "SALIM_LOG_COMMANDS",
                "download_dir":       "SALIM_DOWNLOAD_DIR",
                "upload_dir":         "SALIM_UPLOAD_DIR",
                "nvidia_model":       "SALIM_NVIDIA_MODEL",
                "groq_model":         "SALIM_GROQ_MODEL",
                "zai_model":          "SALIM_ZAI_MODEL",
            }
            k = ctx.args[1].lower()
            v = " ".join(ctx.args[2:])
            env_key = key_map.get(k)
            if env_key:
                self.config.set(env_key, v)
                await update.effective_message.reply_text(
                    f"✅ Set <code>{esc(k)}</code> = <code>{esc(v)}</code>", parse_mode=H
                )
            else:
                valid = ", ".join(key_map.keys())
                await update.effective_message.reply_text(
                    f"❌ Unknown key <code>{esc(k)}</code>\nValid: {esc(valid)}", parse_mode=H
                )
            return

        summary = self.config.summary()
        # Add all 3 AI providers to summary
        for _k, _env, _model_env in [
            ("nvidia", "SALIM_NVIDIA_API_KEY", "SALIM_NVIDIA_MODEL"),
            ("groq",   "SALIM_GROQ_API_KEY",   "SALIM_GROQ_MODEL"),
            ("zai",    "SALIM_ZAI_API_KEY",     "SALIM_ZAI_MODEL"),
        ]:
            _key = self.config.get(_env, "")
            _model = self.config.get(_model_env, "(not set)").split("/")[-1]
            summary[f"{_k}_model"]   = _model
            summary[f"{_k}_api_key"] = (_key[:8] + "...") if _key else "(not set)"

        lines = [f"• <code>{esc(k)}</code>: <code>{esc(v)}</code>" for k, v in summary.items()]
        text = "⚙️ <b>Salim Config</b>\n\n" + "\n".join(lines) + \
               "\n\n<i>Change with: <code>/config set &lt;key&gt; &lt;value&gt;</code></i>"
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /logs ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_logs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        n = int(ctx.args[0]) if ctx.args else 20
        entries = self.auth.get_audit_log(n)
        if not entries:
            await update.effective_message.reply_text("📋 No log entries yet.")
            return
        lines = [
            f"<code>{esc(e['ts'][11:19])}</code> {esc(e.get('user','?'))} → <code>{esc(e['cmd'])}</code> {esc(e.get('args','')[:40])}"
            for e in entries
        ]
        await update.effective_message.reply_text(
            f"📋 <b>Last {len(lines)} Commands</b>\n\n" + "\n".join(lines),
            parse_mode=H
        )

    # ── Callback dispatcher ───────────────────────────────────────────────────
    async def _dispatch_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data  = query.data or ""

        # ── AI callbacks ──────────────────────────────────────────────────────
        if data.startswith("ai_"):
            await self.handle_ai_callback(update, ctx)
            return
        # ── Stream callbacks ──────────────────────────────────────────────────
        if data.startswith("stream_"):
            await self.handle_stream_callback(update, ctx)
            return

        # ── Browser callbacks ─────────────────────────────────────────────────
        if data.startswith("browse_"):
            await self.handle_browse_callback(update, ctx)
            return

        # ── Vision callbacks ──────────────────────────────────────────────────
        if data.startswith("vision_"):
            await self.handle_vision_callback(update, ctx)
            return

        # ── Existing dashboard callbacks ──────────────────────────────────────
        dispatch_map = {
            "dash:info":       self.cmd_info,
            "dash:screenshot": self.cmd_screenshot,
            "dash:top":        self.cmd_top,
            "dash:ls":         self.cmd_ls,
            "dash:ps":         self.cmd_ps,
            "dash:network":    self.cmd_network,
            "dash:battery":    self.cmd_battery,
            "dash:paste":      self.cmd_paste_smart,  # use new smart paste
            "dash:disk":       self.cmd_disk,
            "dash:help":       self.cmd_help,
            "dash:config":     self.cmd_config,
        }

        if data in dispatch_map:
            ctx.args = []
            await dispatch_map[data](update, ctx)
        elif data.startswith("rm_confirm:"):
            await self.cb_rm_confirm(update, ctx)
        elif data == "rm_cancel":
            await query.edit_message_text("❌ Deletion cancelled.")
        elif data.startswith("power:"):
            await self.cb_power(update, ctx)
        elif data.startswith("upload_dest:") or data.startswith("upload_cancel:") or data.startswith("upload_custom:"):
            await self.handle_upload_callback(update, ctx)
        elif data.startswith("code_rerun:") or data.startswith("code_save:"):
            await self.handle_code_callback(update, ctx)
        else:
            logger.warning(f"Unknown callback: {data!r}")

    async def _handle_text_or_photo_reply(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Routes reply messages:
        - If replying to a photo → vision AI
        - Otherwise → AI handler
        """
        msg = update.effective_message
        if msg and msg.reply_to_message and msg.reply_to_message.photo:
            await self.handle_photo_reply(update, ctx)
        else:
            await self.handle_ai_message(update, ctx)

    # ── Unknown command ───────────────────────────────────────────────────────
    async def cmd_unknown(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self.auth.is_allowed(update.effective_user.id):
            return
        cmd = update.effective_message.text.split()[0]
        await update.effective_message.reply_text(
            f"❓ Unknown command: <code>{esc(cmd)}</code>\n"
            f"Send /help for all commands, or just <b>type in plain English</b> — AI will understand!",
            parse_mode=H
        )

    # ── Bot command menu list ─────────────────────────────────────────────────
    def _bot_commands(self) -> list[BotCommand]:
        return [
            BotCommand("start",       "Dashboard"),
            BotCommand("help",        "All commands"),
            BotCommand("info",        "System overview"),
            BotCommand("screenshot",  "Take screenshot"),
            BotCommand("stream",      "Live screen stream"),
            BotCommand("run",         "Run shell command"),
            BotCommand("ls",          "List files"),
            BotCommand("download",    "Download file"),
            BotCommand("upload",      "Upload file to laptop"),
            BotCommand("ps",          "Running processes"),
            BotCommand("kill",        "Kill process"),
            BotCommand("top",         "Live resource monitor"),
            BotCommand("cpu",         "CPU usage"),
            BotCommand("mem",         "Memory usage"),
            BotCommand("disk",        "Disk usage"),
            BotCommand("battery",     "Battery status"),
            BotCommand("network",     "Network info"),
            BotCommand("type",        "Type text on screen"),
            BotCommand("key",         "Press keyboard shortcut"),
            BotCommand("click",       "Mouse click"),
            BotCommand("notify",      "Desktop notification"),
            BotCommand("volume",      "Get/set volume"),
            BotCommand("copy",        "Copy to clipboard"),
            BotCommand("paste",       "Read clipboard (text or image)"),
            BotCommand("copyphoto",   "Copy photo to clipboard"),
            BotCommand("shutdown",    "Shutdown laptop"),
            BotCommand("restart",     "Restart laptop"),
            BotCommand("sleep",       "Sleep / suspend"),
            BotCommand("lock",        "Lock screen"),
            BotCommand("config",      "Bot settings"),
            BotCommand("logs",        "Audit log"),
            BotCommand("doc",         "Create Word/Excel document"),
            BotCommand("cam",         "Webcam snapshot"),
            BotCommand("record",      "Record screen (seconds)"),
            BotCommand("alert",       "System threshold alerts"),
            BotCommand("history",     "Conversation memory"),
            BotCommand("code",        "AI writes & runs code"),
            BotCommand("guard",       "Intrusion detection"),
            BotCommand("uploads",     "Upload history"),
            # v9 new commands
            BotCommand("browse",      "Open URL in browser + screenshot"),
            BotCommand("browse_click","Click element in browser"),
            BotCommand("browse_type", "Type text in browser field"),
            BotCommand("browse_js",   "Run JavaScript in browser"),
            BotCommand("browse_close","Close browser session"),
            BotCommand("tts",         "Text-to-speech voice reply"),
            BotCommand("say",         "Speak text aloud (TTS)"),
            BotCommand("tts_lang",    "Set TTS language"),
            BotCommand("tts_engine",  "Switch TTS engine"),
            BotCommand("ssh_add",     "Register SSH host"),
            BotCommand("ssh_list",    "List SSH hosts"),
            BotCommand("ssh",         "Run command on remote machine"),
            BotCommand("ssh_upload",  "Upload file to remote via SSH"),
            BotCommand("ssh_download","Download file from remote via SSH"),
            BotCommand("vision",      "Vision AI — ask about images"),
            BotCommand("askvision",   "Ask question about last photo"),
            # v10 new commands
            BotCommand("speedtest",   "Internet speed test (download/upload/ping)"),
            BotCommand("qr",          "Generate a QR code"),
            BotCommand("qrread",      "Read QR code from a photo"),
            BotCommand("watch",       "Watch file/folder for changes"),
            BotCommand("watchlist",   "List active file watchers"),
            BotCommand("watchstop",   "Stop a file watcher"),
            BotCommand("note",        "Save a quick note"),
            BotCommand("notes",       "List saved notes"),
            BotCommand("notedel",     "Delete a note"),
            BotCommand("at",          "Schedule command at a time"),
            BotCommand("every",       "Run command on repeat"),
            BotCommand("jobs",        "List scheduled jobs"),
            BotCommand("jobcancel",   "Cancel a scheduled job"),
            # v11 new commands
            BotCommand("mic",         "Record from laptop microphone → send to Telegram"),
        ]

    # ── Run ───────────────────────────────────────────────────────────────────
    def run(self, verbose: bool = False):
        from salim.auth import setup_logging
        setup_logging(verbose)
        app = self.build()
        logger.info(f"Salim starting on {platform.node()}...")
        app.run_polling(allowed_updates=Update.ALL_TYPES)
