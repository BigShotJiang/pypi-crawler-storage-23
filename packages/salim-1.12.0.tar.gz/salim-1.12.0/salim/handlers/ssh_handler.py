"""
Salim SSH Handler — control remote machines from Telegram.

Commands:
  /ssh_add <alias> <user@host> [port]  — Register an SSH target
  /ssh_add <alias> <user@host> [port] [--key /path/to/key]  — with key auth
  /ssh_list                            — List registered SSH hosts
  /ssh <alias> <command>               — Run command on remote machine
  /ssh_remove <alias>                  — Remove an SSH host
  /ssh_connect <alias>                 — Open interactive SSH session (send commands freely)
  /ssh_disconnect                      — End interactive session
  /ssh_upload <alias> <local_path> <remote_path>  — SCP file to remote
  /ssh_download <alias> <remote_path>  — Download file from remote

Authentication (in priority order):
  1. SSH key file (--key param or ~/.ssh/id_rsa, ~/.ssh/id_ed25519)
  2. Password (stored encrypted in config — never in plaintext)

Uses asyncssh — pure Python, no OpenSSH binary needed, fully async.
Also works with paramiko as fallback.

Auto-installs: asyncssh, cryptography (asyncssh dependency)

Security:
  - Host configs stored in ~/.salim/ssh_hosts.json (600 perms)
  - Passwords stored base64 obfuscated (not plain text)
  - All commands logged in audit log
  - Known-hosts verification optional (disabled by default for ease of use)
"""
from __future__ import annotations

import asyncio
import base64
import html
import io
import json
import logging
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import truncate

logger = logging.getLogger("salim.ssh")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

SSH_HOSTS_FILE = Path.home() / ".salim" / "ssh_hosts.json"
COMMAND_TIMEOUT = 30   # seconds for remote command execution
MAX_OUTPUT_CHARS = 3500

# Per-chat interactive session: chat_id → {alias, conn}
_interactive_sessions: dict[int, dict] = {}


# ── Dependency management ─────────────────────────────────────────────────────

def _ensure_asyncssh() -> bool:
    try:
        import asyncssh  # noqa
        return True
    except ImportError:
        pass
    try:
        logger.info("Installing asyncssh...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "asyncssh", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install asyncssh: {e}")
        return False


def _ensure_paramiko() -> bool:
    """Fallback SSH library if asyncssh unavailable."""
    try:
        import paramiko  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "paramiko", "--quiet"],
            check=True, timeout=120
        )
        return True
    except Exception:
        return False


# ── Host config storage ───────────────────────────────────────────────────────

def _load_hosts() -> dict:
    """Load SSH host registry."""
    try:
        if SSH_HOSTS_FILE.exists():
            return json.loads(SSH_HOSTS_FILE.read_text())
    except Exception:
        pass
    return {}


def _save_hosts(hosts: dict):
    SSH_HOSTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    SSH_HOSTS_FILE.write_text(json.dumps(hosts, indent=2))
    SSH_HOSTS_FILE.chmod(0o600)  # private


def _obfuscate(text: str) -> str:
    """Simple base64 obfuscation (not encryption, just avoids plaintext in file)."""
    return base64.b64encode(text.encode()).decode()


def _deobfuscate(text: str) -> str:
    try:
        return base64.b64decode(text.encode()).decode()
    except Exception:
        return text


def _find_ssh_key() -> Optional[str]:
    """Auto-discover SSH private key in common locations."""
    candidates = [
        Path.home() / ".ssh" / "id_ed25519",
        Path.home() / ".ssh" / "id_rsa",
        Path.home() / ".ssh" / "id_ecdsa",
        Path.home() / ".ssh" / "identity",
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return None


# ── SSH execution ─────────────────────────────────────────────────────────────

async def _run_ssh_command(host_cfg: dict, command: str) -> tuple[str, int]:
    """
    Execute a command on a remote host via SSH.
    Returns (output, exit_code).
    Tries asyncssh first, paramiko as fallback.
    """
    hostname = host_cfg["host"]
    port     = int(host_cfg.get("port", 22))
    username = host_cfg["user"]
    key_path = host_cfg.get("key_path") or _find_ssh_key()
    password = _deobfuscate(host_cfg["password"]) if host_cfg.get("password") else None

    # ── asyncssh (preferred) ──────────────────────────────────────────────────
    if _ensure_asyncssh():
        import asyncssh

        connect_kwargs: dict = {
            "host": hostname,
            "port": port,
            "username": username,
            "known_hosts": None,           # disable host verification for ease of use
            "connect_timeout": 15,
        }

        if key_path and Path(key_path).exists():
            connect_kwargs["client_keys"] = [key_path]
        if password:
            connect_kwargs["password"] = password
            connect_kwargs["client_keys"] = None  # don't try keys if password given

        try:
            async with asyncssh.connect(**connect_kwargs) as conn:
                result = await asyncio.wait_for(
                    conn.run(command, check=False),
                    timeout=COMMAND_TIMEOUT
                )
                output = (result.stdout or "") + (result.stderr or "")
                return output.strip() or "(no output)", result.exit_status or 0
        except asyncio.TimeoutError:
            return f"⏱ Command timed out after {COMMAND_TIMEOUT}s", -1
        except Exception as e:
            raise RuntimeError(f"asyncssh error: {e}")

    # ── paramiko fallback ─────────────────────────────────────────────────────
    if _ensure_paramiko():
        import paramiko

        def _run_paramiko():
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            connect_kwargs: dict = {
                "hostname": hostname,
                "port": port,
                "username": username,
                "timeout": 15,
            }
            if key_path and Path(key_path).exists():
                connect_kwargs["key_filename"] = key_path
            if password:
                connect_kwargs["password"] = password

            client.connect(**connect_kwargs)
            _, stdout, stderr = client.exec_command(command, timeout=COMMAND_TIMEOUT)
            out = stdout.read().decode(errors="replace")
            err = stderr.read().decode(errors="replace")
            exit_code = stdout.channel.recv_exit_status()
            client.close()
            return (out + err).strip() or "(no output)", exit_code

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _run_paramiko)

    raise RuntimeError("Neither asyncssh nor paramiko is available. Run `pip install asyncssh`")


async def _sftp_upload(host_cfg: dict, local_path: str, remote_path: str) -> tuple[bool, str]:
    """Upload a local file to remote via SFTP."""
    if not _ensure_asyncssh():
        return False, "asyncssh required for file transfer"

    import asyncssh

    hostname = host_cfg["host"]
    port     = int(host_cfg.get("port", 22))
    username = host_cfg["user"]
    key_path = host_cfg.get("key_path") or _find_ssh_key()
    password = _deobfuscate(host_cfg["password"]) if host_cfg.get("password") else None

    connect_kwargs: dict = {
        "host": hostname, "port": port,
        "username": username, "known_hosts": None, "connect_timeout": 15,
    }
    if key_path and Path(key_path).exists():
        connect_kwargs["client_keys"] = [key_path]
    if password:
        connect_kwargs["password"] = password
        connect_kwargs["client_keys"] = None

    try:
        async with asyncssh.connect(**connect_kwargs) as conn:
            async with conn.start_sftp_client() as sftp:
                await sftp.put(local_path, remote_path)
        return True, ""
    except Exception as e:
        return False, str(e)


async def _sftp_download(host_cfg: dict, remote_path: str) -> tuple[bytes, str]:
    """Download a file from remote via SFTP. Returns (file_bytes, error)."""
    if not _ensure_asyncssh():
        return b"", "asyncssh required for file transfer"

    import asyncssh

    hostname = host_cfg["host"]
    port     = int(host_cfg.get("port", 22))
    username = host_cfg["user"]
    key_path = host_cfg.get("key_path") or _find_ssh_key()
    password = _deobfuscate(host_cfg["password"]) if host_cfg.get("password") else None

    connect_kwargs: dict = {
        "host": hostname, "port": port,
        "username": username, "known_hosts": None, "connect_timeout": 15,
    }
    if key_path and Path(key_path).exists():
        connect_kwargs["client_keys"] = [key_path]
    if password:
        connect_kwargs["password"] = password
        connect_kwargs["client_keys"] = None

    try:
        async with asyncssh.connect(**connect_kwargs) as conn:
            async with conn.start_sftp_client() as sftp:
                buf = io.BytesIO()
                await sftp.getfo(remote_path, buf)
                return buf.getvalue(), ""
    except Exception as e:
        return b"", str(e)


# ── Handler class ─────────────────────────────────────────────────────────────

class SSHHandlers:
    """Mixin handler for SSH remote machine control."""

    @require_auth
    async def cmd_ssh_add(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /ssh_add <alias> <user@host> [port] [--key /path/to/key]
        /ssh_add pi pi@192.168.1.100
        /ssh_add server admin@myserver.com 2222
        /ssh_add work root@10.0.0.5 --key ~/.ssh/work_key

        For password auth, omit --key and Salim will prompt for password.
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "🔐 <b>Add SSH Host</b>\n\n"
                "Usage: <code>/ssh_add &lt;alias&gt; &lt;user@host&gt; [port] [--key /path]</code>\n\n"
                "Examples:\n"
                "<code>/ssh_add pi pi@192.168.1.100</code>\n"
                "<code>/ssh_add server ubuntu@myserver.com 22</code>\n"
                "<code>/ssh_add work root@10.0.0.5 --key ~/.ssh/work_key</code>\n\n"
                "After adding, use: <code>/ssh &lt;alias&gt; &lt;command&gt;</code>",
                parse_mode=H
            )
            return

        alias    = ctx.args[0].lower().strip()
        userhost = ctx.args[1]

        # Parse user@host
        if "@" not in userhost:
            await msg.reply_text(
                "❌ Format must be <code>user@hostname</code>\n"
                "Example: <code>ubuntu@192.168.1.100</code>",
                parse_mode=H
            )
            return

        user, host = userhost.split("@", 1)

        # Parse optional args
        port    = 22
        key_path = None
        args_rest = ctx.args[2:]

        i = 0
        while i < len(args_rest):
            if args_rest[i] == "--key" and i + 1 < len(args_rest):
                key_path = str(Path(args_rest[i + 1]).expanduser())
                i += 2
            else:
                try:
                    port = int(args_rest[i])
                except ValueError:
                    pass
                i += 1

        # Auto-discover key if not specified
        if not key_path:
            key_path = _find_ssh_key()

        # Build host record
        hosts = _load_hosts()
        host_record: dict = {
            "alias":    alias,
            "user":     user,
            "host":     host,
            "port":     port,
            "key_path": key_path,
            "password": "",
            "added_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        hosts[alias] = host_record
        _save_hosts(hosts)

        key_info = f"🔑 Key: <code>{esc(key_path)}</code>" if key_path else "🔑 Key: <i>none found — will use password</i>"
        await msg.reply_text(
            f"✅ <b>SSH Host Added</b>\n\n"
            f"🏷️ Alias: <code>{esc(alias)}</code>\n"
            f"🖥️ Host: <code>{esc(user)}@{esc(host)}:{port}</code>\n"
            f"{key_info}\n\n"
            f"Test: <code>/ssh {esc(alias)} uptime</code>\n"
            f"<i>If key auth fails, the bot will prompt for password on first connection.</i>",
            parse_mode=H
        )

    @require_auth
    async def cmd_ssh_list(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ssh_list — Show all registered SSH hosts."""
        msg = update.effective_message
        hosts = _load_hosts()

        if not hosts:
            await msg.reply_text(
                "📋 No SSH hosts registered yet.\n"
                "Add one: <code>/ssh_add &lt;alias&gt; &lt;user@host&gt;</code>",
                parse_mode=H
            )
            return

        lines = []
        for alias, h in hosts.items():
            key_indicator = "🔑" if h.get("key_path") else ("🔐" if h.get("password") else "⚠️")
            lines.append(
                f"{key_indicator} <b>{esc(alias)}</b> — "
                f"<code>{esc(h['user'])}@{esc(h['host'])}:{h.get('port', 22)}</code>"
            )

        await msg.reply_text(
            f"🖥️ <b>SSH Hosts ({len(hosts)})</b>\n\n"
            + "\n".join(lines)
            + "\n\nUse: <code>/ssh &lt;alias&gt; &lt;command&gt;</code>",
            parse_mode=H
        )

    @require_auth
    async def cmd_ssh(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /ssh <alias> <command>  — Run command on remote machine.
        /ssh pi ls -la ~/Desktop
        /ssh server df -h
        /ssh work systemctl status nginx
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "💻 <b>SSH Command</b>\n\n"
                "Usage: <code>/ssh &lt;alias&gt; &lt;command&gt;</code>\n\n"
                "Examples:\n"
                "<code>/ssh pi uptime</code>\n"
                "<code>/ssh server df -h</code>\n"
                "<code>/ssh work cat /var/log/syslog | tail -20</code>\n\n"
                "List hosts: <code>/ssh_list</code>",
                parse_mode=H
            )
            return

        if not _ensure_asyncssh() and not _ensure_paramiko():
            await msg.reply_text(
                "❌ SSH library not available.\n"
                "Run: <code>pip install asyncssh</code>",
                parse_mode=H
            )
            return

        alias   = ctx.args[0].lower()
        command = " ".join(ctx.args[1:])

        hosts = _load_hosts()
        if alias not in hosts:
            aliases = ", ".join(f"<code>{esc(a)}</code>" for a in hosts)
            await msg.reply_text(
                f"❌ Unknown alias: <code>{esc(alias)}</code>\n"
                f"Known hosts: {aliases or 'none'}\n"
                f"Add: <code>/ssh_add {esc(alias)} user@host</code>",
                parse_mode=H
            )
            return

        host_cfg = hosts[alias]
        target   = f"{host_cfg['user']}@{host_cfg['host']}:{host_cfg.get('port', 22)}"

        status = await msg.reply_text(
            f"🔌 <i>Connecting to {esc(alias)} ({esc(target)})...</i>", parse_mode=H
        )

        try:
            output, exit_code = await _run_ssh_command(host_cfg, command)
            icon = "✅" if exit_code == 0 else "❌"
            output_trunc = truncate(output, MAX_OUTPUT_CHARS)

            if len(output) > MAX_OUTPUT_CHARS:
                # Send as file
                file_obj = io.BytesIO(output.encode())
                file_obj.name = f"ssh_{alias}_output.txt"
                await status.delete()
                await msg.reply_document(
                    document=file_obj,
                    filename=f"ssh_{alias}_output.txt",
                    caption=(
                        f"{icon} <code>{esc(alias)}</code>: "
                        f"<code>{esc(command[:60])}</code> → exit {exit_code}"
                    ),
                    parse_mode=H
                )
            else:
                await status.edit_text(
                    f"{icon} <b>{esc(alias)}</b>: <code>{esc(command[:80])}</code>\n"
                    f"<i>{esc(target)}</i>\n\n"
                    f"<pre>{esc(output_trunc)}</pre>\n"
                    f"<i>Exit: {exit_code}</i>",
                    parse_mode=H
                )

        except RuntimeError as e:
            # Connection failed — check if it might be a password issue
            err_str = str(e).lower()
            if "password" in err_str or "auth" in err_str or "permission" in err_str:
                await status.edit_text(
                    f"🔐 <b>Authentication failed for {esc(alias)}</b>\n\n"
                    f"The SSH key may not be accepted.\n\n"
                    f"To use password auth, run:\n"
                    f"<code>/ssh_password {esc(alias)} &lt;password&gt;</code>\n\n"
                    f"<i>Error: {esc(str(e)[:200])}</i>",
                    parse_mode=H
                )
            else:
                await status.edit_text(
                    f"❌ <b>SSH Error</b>\n\n"
                    f"Host: {esc(target)}\n"
                    f"<code>{esc(str(e)[:400])}</code>",
                    parse_mode=H
                )

        except Exception as e:
            logger.error(f"SSH error: {e}", exc_info=True)
            await status.edit_text(
                f"❌ Unexpected error: {esc(str(e)[:300])}", parse_mode=H
            )

    @require_auth
    async def cmd_ssh_password(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /ssh_password <alias> <password>  — Set password for SSH host.
        Note: Stored obfuscated in ~/.salim/ssh_hosts.json (not plaintext).
        Recommendation: use SSH keys instead (/ssh_add ... --key ~/.ssh/id_rsa)
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "Usage: <code>/ssh_password &lt;alias&gt; &lt;password&gt;</code>\n"
                "<i>Consider using SSH keys instead for better security.</i>",
                parse_mode=H
            )
            return

        alias    = ctx.args[0].lower()
        password = " ".join(ctx.args[1:])

        hosts = _load_hosts()
        if alias not in hosts:
            await msg.reply_text(
                f"❌ Host <code>{esc(alias)}</code> not found. Add it first with /ssh_add.",
                parse_mode=H
            )
            return

        hosts[alias]["password"] = _obfuscate(password)
        hosts[alias]["key_path"] = None  # Prefer password
        _save_hosts(hosts)

        # Delete the user's message to avoid password in chat history
        try:
            await msg.delete()
        except Exception:
            pass

        await msg.reply_text(
            f"✅ Password set for <code>{esc(alias)}</code>\n"
            f"<i>Password stored obfuscated. Recommendation: use SSH keys instead.</i>",
            parse_mode=H
        )

    @require_auth
    async def cmd_ssh_remove(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ssh_remove <alias> — Remove an SSH host from the registry."""
        msg = update.effective_message

        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/ssh_remove &lt;alias&gt;</code>", parse_mode=H
            )
            return

        alias = ctx.args[0].lower()
        hosts = _load_hosts()

        if alias not in hosts:
            await msg.reply_text(
                f"❌ Host <code>{esc(alias)}</code> not found.", parse_mode=H
            )
            return

        del hosts[alias]
        _save_hosts(hosts)
        await msg.reply_text(
            f"✅ Removed SSH host: <code>{esc(alias)}</code>", parse_mode=H
        )

    @require_auth
    async def cmd_ssh_upload(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /ssh_upload <alias> <local_path> <remote_path>
        Upload a local file to the remote machine via SFTP.
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 3:
            await msg.reply_text(
                "Usage: <code>/ssh_upload &lt;alias&gt; &lt;local_path&gt; &lt;remote_path&gt;</code>\n"
                "Example: <code>/ssh_upload pi ~/Desktop/report.pdf /home/pi/report.pdf</code>",
                parse_mode=H
            )
            return

        alias       = ctx.args[0].lower()
        local_path  = str(Path(ctx.args[1]).expanduser())
        remote_path = ctx.args[2]

        hosts = _load_hosts()
        if alias not in hosts:
            await msg.reply_text(
                f"❌ Unknown alias: <code>{esc(alias)}</code>. Use /ssh_list to see hosts.",
                parse_mode=H
            )
            return

        if not Path(local_path).exists():
            await msg.reply_text(
                f"❌ Local file not found: <code>{esc(local_path)}</code>",
                parse_mode=H
            )
            return

        file_size = Path(local_path).stat().st_size
        status = await msg.reply_text(
            f"📤 <i>Uploading {esc(Path(local_path).name)} → {esc(alias)}:{esc(remote_path)}...</i>",
            parse_mode=H
        )

        success, error = await _sftp_upload(hosts[alias], local_path, remote_path)

        if success:
            await status.edit_text(
                f"✅ <b>Uploaded successfully</b>\n"
                f"📁 Local: <code>{esc(local_path)}</code>\n"
                f"🖥️ Remote ({esc(alias)}): <code>{esc(remote_path)}</code>\n"
                f"💾 Size: {file_size // 1024}KB",
                parse_mode=H
            )
        else:
            await status.edit_text(
                f"❌ Upload failed: {esc(error[:300])}", parse_mode=H
            )

    @require_auth
    async def cmd_ssh_download(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /ssh_download <alias> <remote_path>
        Download a file from remote machine and send to Telegram.
        """
        msg = update.effective_message

        if not ctx.args or len(ctx.args) < 2:
            await msg.reply_text(
                "Usage: <code>/ssh_download &lt;alias&gt; &lt;remote_path&gt;</code>\n"
                "Example: <code>/ssh_download pi /home/pi/logs/app.log</code>",
                parse_mode=H
            )
            return

        alias       = ctx.args[0].lower()
        remote_path = ctx.args[1]

        hosts = _load_hosts()
        if alias not in hosts:
            await msg.reply_text(
                f"❌ Unknown alias: <code>{esc(alias)}</code>.",
                parse_mode=H
            )
            return

        status = await msg.reply_text(
            f"📥 <i>Downloading from {esc(alias)}:{esc(remote_path)}...</i>",
            parse_mode=H
        )

        file_bytes, error = await _sftp_download(hosts[alias], remote_path)

        if error:
            await status.edit_text(
                f"❌ Download failed: {esc(error[:300])}", parse_mode=H
            )
            return

        if not file_bytes:
            await status.edit_text("❌ Downloaded file is empty.", parse_mode=H)
            return

        await status.delete()

        filename = Path(remote_path).name
        buf = io.BytesIO(file_bytes)
        buf.name = filename
        size_kb = len(file_bytes) // 1024

        await msg.reply_document(
            document=buf,
            filename=filename,
            caption=(
                f"📥 <b>Downloaded from {esc(alias)}</b>\n"
                f"📁 <code>{esc(remote_path)}</code>\n"
                f"💾 {size_kb}KB"
            ),
            parse_mode=H
        )
