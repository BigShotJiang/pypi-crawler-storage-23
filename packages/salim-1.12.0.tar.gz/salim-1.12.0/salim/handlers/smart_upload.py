"""
Salim Smart Upload — enhanced file upload with destination folder selection.

When a user sends any file to the bot, instead of blindly saving to Desktop,
Salim shows an interactive button menu to choose the save destination:
  • Desktop
  • Downloads
  • Documents
  • Custom path (type it)
  • Same as last time

Also handles:
  /upload               — show upload instructions + folder picker
  /upload <path>        — set default upload directory
  /uploads              — list recently uploaded files
  /upload clear         — clear upload history

Files > 50MB show a warning (Telegram limit).
Duplicate filename detection — asks to overwrite or rename.
Upload history stored in ~/.salim/upload_history.jsonl
"""
from __future__ import annotations

import html
import io
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import (
    Update, Message, InlineKeyboardButton,
    InlineKeyboardMarkup, Document
)
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human

logger = logging.getLogger("salim.upload")

UPLOAD_HISTORY_FILE = Path.home() / ".salim" / "upload_history.jsonl"
MAX_HISTORY = 50

# Pending uploads: file_id → metadata, waiting for folder selection
_pending_uploads: dict[str, dict] = {}

# Per-user last destination (remembered across sessions)
_last_dest: dict[int, str] = {}


def _esc(v) -> str:
    return html.escape(str(v), quote=False)


def _common_destinations(config) -> list[tuple[str, str]]:
    """Return list of (label, path) for the inline keyboard."""
    home = Path.home()
    destinations = [
        ("🖥️ Desktop",     str(home / "Desktop")),
        ("📥 Downloads",   str(home / "Downloads")),
        ("📄 Documents",   str(home / "Documents")),
        ("🎵 Music",       str(home / "Music")),
        ("🖼️ Pictures",    str(home / "Pictures")),
        ("🎬 Videos",      str(home / "Videos")),
    ]
    # Add configured upload_dir if different from Desktop
    configured = str(config.upload_dir) if hasattr(config, 'upload_dir') else None
    if configured and configured not in [d[1] for d in destinations]:
        destinations.insert(0, ("⚙️ Default", configured))
    return destinations


def _build_dest_keyboard(file_id: str, config, user_id: int) -> InlineKeyboardMarkup:
    """Build inline keyboard with destination folder buttons."""
    dests = _common_destinations(config)
    rows = []

    # 2 columns
    for i in range(0, len(dests), 2):
        row = []
        for label, path in dests[i:i+2]:
            short_path = path.replace(str(Path.home()), "~")
            row.append(InlineKeyboardButton(
                label,
                callback_data=f"upload_dest:{file_id}:{path[:100]}"
            ))
        rows.append(row)

    # Last used
    if user_id in _last_dest:
        last = _last_dest[user_id]
        short = last.replace(str(Path.home()), "~")
        rows.append([InlineKeyboardButton(
            f"🔁 Last: {short}",
            callback_data=f"upload_dest:{file_id}:{last[:100]}"
        )])

    rows.append([
        InlineKeyboardButton("📝 Custom path...", callback_data=f"upload_custom:{file_id}"),
        InlineKeyboardButton("❌ Cancel", callback_data=f"upload_cancel:{file_id}"),
    ])

    return InlineKeyboardMarkup(rows)


def _log_upload(filename: str, dest: str, size_bytes: int, user_id: int):
    UPLOAD_HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "ts": datetime.now().isoformat(),
        "filename": filename,
        "dest": dest,
        "size": size_bytes,
        "uid": user_id,
    }
    try:
        with open(UPLOAD_HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


def _get_upload_history(limit: int = 20) -> list[dict]:
    try:
        if not UPLOAD_HISTORY_FILE.exists():
            return []
        lines = UPLOAD_HISTORY_FILE.read_text().strip().splitlines()
        result = []
        for line in lines[-limit:]:
            try:
                result.append(json.loads(line))
            except Exception:
                pass
        return list(reversed(result))
    except Exception:
        return []


async def _save_file_to(bot, file_id: str, filename: str, dest_dir: str) -> tuple[str, int]:
    """Download from Telegram and save to dest_dir. Returns (full_path, size_bytes)."""
    dest = Path(dest_dir).expanduser()
    dest.mkdir(parents=True, exist_ok=True)

    # Handle duplicate filenames
    target = dest / filename
    if target.exists():
        stem = target.stem
        suffix = target.suffix
        counter = 1
        while target.exists():
            target = dest / f"{stem}_{counter}{suffix}"
            counter += 1

    file_obj = await bot.get_file(file_id)
    buf = io.BytesIO()
    await file_obj.download_to_memory(buf)
    data = buf.getvalue()

    target.write_bytes(data)
    return str(target), len(data)


class SmartUploadHandlers:

    async def handle_document_smart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Called for every document/file sent to the bot.
        Shows destination folder picker instead of blindly saving.
        """
        user = update.effective_user
        if not self.auth.is_allowed(user.id):
            return

        msg: Message = update.effective_message
        doc: Optional[Document] = msg.document

        if not doc:
            return

        filename = doc.file_name or f"file_{int(time.time())}"
        file_id = doc.file_id
        size_bytes = doc.file_size or 0
        size_str = bytes_to_human(size_bytes)

        # Warn about large files
        max_bytes = 50 * 1024 * 1024
        if size_bytes > max_bytes:
            await msg.reply_text(
                f"⚠️ File is {size_str} — Telegram bots can only receive up to 50MB.\n"
                "This file may fail to download.",
                parse_mode="HTML"
            )

        # Store pending upload info
        _pending_uploads[file_id] = {
            "filename": filename,
            "file_id": file_id,
            "size": size_bytes,
            "user_id": user.id,
            "msg_id": msg.message_id,
            "chat_id": msg.chat_id,
        }

        # Build keyboard
        keyboard = _build_dest_keyboard(file_id, self.config, user.id)

        # Detect file type for icon
        ext = Path(filename).suffix.lower()
        icon_map = {
            ".pdf": "📄", ".docx": "📝", ".xlsx": "📊", ".pptx": "📊",
            ".zip": "📦", ".tar": "📦", ".gz": "📦",
            ".mp4": "🎬", ".mkv": "🎬", ".avi": "🎬",
            ".mp3": "🎵", ".wav": "🎵",
            ".jpg": "🖼️", ".jpeg": "🖼️", ".png": "🖼️",
            ".py": "🐍", ".js": "📜", ".sh": "⚙️",
        }
        icon = icon_map.get(ext, "📁")

        await msg.reply_text(
            f"{icon} <b>{_esc(filename)}</b>\n"
            f"📦 Size: {size_str}\n\n"
            f"📂 <b>Where should I save this?</b>",
            parse_mode="HTML",
            reply_markup=keyboard
        )

    async def handle_upload_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle destination selection from inline keyboard."""
        query = update.callback_query
        await query.answer()
        data = query.data or ""
        user_id = update.effective_user.id

        if data.startswith("upload_cancel:"):
            file_id = data[len("upload_cancel:"):]
            _pending_uploads.pop(file_id, None)
            await query.edit_message_text("❌ Upload cancelled.")
            return

        if data.startswith("upload_custom:"):
            file_id = data[len("upload_custom:"):]
            pending = _pending_uploads.get(file_id)
            if not pending:
                await query.edit_message_text("❌ Upload expired. Please resend the file.")
                return
            await query.edit_message_text(
                f"📂 <b>Custom destination</b>\n\n"
                f"File: <code>{_esc(pending['filename'])}</code>\n\n"
                f"Reply to this message with the full path, e.g.:\n"
                f"<code>/upload_to {file_id} ~/Projects/myproject</code>",
                parse_mode="HTML"
            )
            return

        if data.startswith("upload_dest:"):
            rest = data[len("upload_dest:"):]
            # file_id can contain colons in Telegram's format, dest is last segment
            # Format: upload_dest:<file_id>:<path>
            # Split at most once from the right on last colon-path boundary
            # We stored it as upload_dest:{file_id}:{path} where path starts with /
            parts = rest.split(":", 1)
            if len(parts) < 2:
                await query.edit_message_text("❌ Invalid callback data.")
                return
            file_id = parts[0]
            dest_dir = parts[1]

            pending = _pending_uploads.get(file_id)
            if not pending:
                await query.edit_message_text(
                    "❌ Upload session expired. Please resend the file.",
                    parse_mode="HTML"
                )
                return

            filename = pending["filename"]

            await query.edit_message_text(
                f"📥 <i>Saving {_esc(filename)} to {_esc(dest_dir)}...</i>",
                parse_mode="HTML"
            )

            try:
                saved_path, size = await _save_file_to(
                    ctx.bot, file_id, filename, dest_dir
                )

                # Remember last destination
                _last_dest[user_id] = dest_dir
                _pending_uploads.pop(file_id, None)

                # Log it
                _log_upload(filename, saved_path, size, user_id)

                size_str = bytes_to_human(size)
                short_path = saved_path.replace(str(Path.home()), "~")

                await query.edit_message_text(
                    f"✅ <b>Saved!</b>\n\n"
                    f"📄 {_esc(filename)}\n"
                    f"📂 <code>{_esc(short_path)}</code>\n"
                    f"📦 {size_str}",
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton(
                            "📤 Send back to Telegram",
                            callback_data=f"ai_dl:{saved_path[:200]}"
                        ),
                    ]])
                )

            except Exception as e:
                logger.error(f"Upload save error: {e}", exc_info=True)
                await query.edit_message_text(
                    f"❌ Failed to save file: {_esc(str(e))}",
                    parse_mode="HTML"
                )

    @require_auth
    async def cmd_upload_smart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /upload           — show instructions + set default folder
        /upload <path>    — set default upload directory
        /uploads          — show upload history
        """
        args = ctx.args or []
        msg = update.effective_message

        if args and args[0] == "history" or not args and False:
            pass

        if not args:
            # Build quick destination picker
            dests = _common_destinations(self.config)
            lines = "\n".join(
                f"  <code>{path.replace(str(Path.home()), '~')}</code>"
                for _, path in dests[:4]
            )
            await msg.reply_text(
                "📤 <b>Smart Upload</b>\n\n"
                "<b>How to upload:</b>\n"
                "Simply <b>send any file</b> to this chat.\n"
                "A folder picker will appear to choose where to save it.\n\n"
                "<b>Quick folders:</b>\n" + lines +
                "\n\n<b>Commands:</b>\n"
                "  <code>/upload &lt;path&gt;</code>  — set default save folder\n"
                "  <code>/uploads</code>  — view upload history",
                parse_mode="HTML"
            )
            return

        if args[0].lower() in ("history", "list", "recent"):
            history = _get_upload_history(20)
            if not history:
                await msg.reply_text("📭 No upload history yet.")
                return
            lines = []
            for entry in history[:15]:
                ts = entry.get("ts", "")[:16]
                fn = entry.get("filename", "?")
                dest = entry.get("dest", "?").replace(str(Path.home()), "~")
                size = bytes_to_human(entry.get("size", 0))
                lines.append(f"• <code>{_esc(fn)}</code> → {_esc(dest)} · {size} · {ts}")
            await msg.reply_text(
                f"📋 <b>Upload History ({len(history)} files)</b>\n\n" + "\n".join(lines),
                parse_mode="HTML"
            )
            return

        # Set default directory
        path_str = " ".join(args)
        path = Path(path_str).expanduser()
        if not path.exists():
            try:
                path.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                await msg.reply_text(f"❌ Cannot create directory: {_esc(e)}", parse_mode="HTML")
                return

        # Save to config
        if hasattr(self.config, 'set'):
            self.config.set("SALIM_UPLOAD_DIR", str(path))

        await msg.reply_text(
            f"✅ Default upload folder set to:\n<code>{_esc(path)}</code>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_uploads_history(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Alias: /uploads — show upload history."""
        ctx.args = ["history"]
        await self.cmd_upload_smart(update, ctx)
