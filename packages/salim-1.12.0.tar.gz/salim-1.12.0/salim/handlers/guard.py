"""
Salim Intrusion Alert — physical security monitor.

When armed, Salim watches for:
  • Mouse movement (detected via psutil or pynput)
  • Keyboard activity
  • New USB devices plugged in
  • Webcam access attempts (process monitor)
  • Login/logout events (on Linux via wtmp, on Mac via last)

On detection:
  1. Takes a screenshot immediately
  2. Takes a webcam photo (if available)
  3. Sends alert + photos to Telegram with timestamp

Commands:
  /guard on      — arm intrusion detection (with grace period)
  /guard off     — disarm
  /guard status  — show armed/disarmed status + last event
  /guard grace 60 — set grace period in seconds (default: 30s)

Uses pynput (auto-installed) for keyboard/mouse monitoring.
Falls back to psutil mouse position polling if pynput unavailable.
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import psutil
from telegram import Bot, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows

logger = logging.getLogger("salim.guard")

GUARD_STATE_FILE = Path.home() / ".salim" / "guard_state.json"

# Global guard state
_guard_armed = False
_guard_task: Optional[asyncio.Task] = None
_guard_bot: Optional[Bot] = None
_guard_user_ids: list[int] = []
_grace_period = 30          # seconds before monitoring starts after arming
_last_mouse_pos = (0, 0)
_last_alert_time = 0.0
_alert_cooldown = 60        # seconds between alerts (avoid spam)


def _save_guard_state():
    GUARD_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    GUARD_STATE_FILE.write_text(json.dumps({
        "armed": _guard_armed,
        "grace": _grace_period,
    }))


def _load_guard_state() -> dict:
    try:
        if GUARD_STATE_FILE.exists():
            return json.loads(GUARD_STATE_FILE.read_text())
    except Exception:
        pass
    return {"armed": False, "grace": 30}


def _ensure_pynput() -> bool:
    try:
        from pynput import mouse, keyboard  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pynput", "--quiet"],
            check=True, timeout=60
        )
        return True
    except Exception:
        return False


async def _take_screenshot() -> Optional[bytes]:
    """Take a screenshot. Returns JPEG bytes or None."""
    try:
        import pyautogui
        from PIL import Image
        shot = pyautogui.screenshot()
        buf = io.BytesIO()
        shot.save(buf, format="JPEG", quality=75, optimize=True)
        return buf.getvalue()
    except Exception:
        pass
    # Fallback: ffmpeg
    try:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
            path = f.name
        if is_linux():
            display = os.environ.get("DISPLAY", ":0")
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-f", "x11grab", "-video_size", "1920x1080",
                "-i", display, "-vframes", "1", path,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
            )
        elif is_mac():
            proc = await asyncio.create_subprocess_exec(
                "screencapture", "-x", path,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
            )
        else:
            return None

        await proc.wait()
        if Path(path).exists():
            data = Path(path).read_bytes()
            Path(path).unlink()
            return data
    except Exception:
        pass
    return None


async def _take_webcam_photo() -> Optional[bytes]:
    """Capture webcam frame. Returns JPEG bytes or None."""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return None
        for _ in range(3):
            cap.read()
        ret, frame = cap.read()
        cap.release()
        if not ret:
            return None
        ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        return buf.tobytes() if ret else None
    except Exception:
        return None


async def _send_intrusion_alert(reason: str):
    """Send alert with screenshot and webcam photo to all authorized users."""
    global _last_alert_time

    now = time.time()
    if now - _last_alert_time < _alert_cooldown:
        return
    _last_alert_time = now

    if not _guard_bot or not _guard_user_ids:
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.warning(f"Intrusion detected: {reason}")

    # Capture evidence
    screenshot = await _take_screenshot()
    webcam = await _take_webcam_photo()

    alert_text = (
        f"🚨 <b>INTRUSION DETECTED</b>\n\n"
        f"📍 Reason: <b>{reason}</b>\n"
        f"🕐 Time: {ts}\n"
        f"💻 Host: {os.uname().nodename if hasattr(os, 'uname') else 'unknown'}\n\n"
        f"<i>Photos below if available.</i>"
    )

    for uid in _guard_user_ids:
        try:
            await _guard_bot.send_message(
                chat_id=uid, text=alert_text, parse_mode="HTML"
            )
            if screenshot:
                buf = io.BytesIO(screenshot)
                await _guard_bot.send_photo(
                    chat_id=uid, photo=buf,
                    caption=f"🖥️ Screenshot at {ts}"
                )
            if webcam:
                buf = io.BytesIO(webcam)
                await _guard_bot.send_photo(
                    chat_id=uid, photo=buf,
                    caption=f"📷 Webcam at {ts}"
                )
        except Exception as e:
            logger.error(f"Failed to send intrusion alert to {uid}: {e}")


async def _psutil_guard_loop():
    """Fallback mouse-position polling when pynput unavailable."""
    global _last_mouse_pos, _guard_armed

    try:
        import pyautogui
        _last_mouse_pos = pyautogui.position()
    except Exception:
        pass

    while _guard_armed:
        try:
            import pyautogui
            pos = pyautogui.position()
            if pos != _last_mouse_pos:
                _last_mouse_pos = pos
                await _send_intrusion_alert("Mouse movement detected")
        except Exception:
            pass
        await asyncio.sleep(3)


def _get_usb_devices() -> set[str]:
    """Get current list of USB device names (Linux)."""
    try:
        result = subprocess.run(
            ["lsusb"], capture_output=True, text=True, timeout=5
        )
        return set(result.stdout.strip().splitlines())
    except Exception:
        return set()


async def _pynput_guard_loop():
    """Full intrusion detection using pynput (mouse + keyboard events)."""
    global _guard_armed

    from pynput import mouse as pynput_mouse, keyboard as pynput_keyboard

    activity_detected = asyncio.Event()

    def on_move(x, y):
        if _guard_armed:
            activity_detected.set()

    def on_click(x, y, button, pressed):
        if _guard_armed and pressed:
            activity_detected.set()

    def on_press(key):
        if _guard_armed:
            activity_detected.set()

    mouse_listener = pynput_mouse.Listener(on_move=on_move, on_click=on_click)
    keyboard_listener = pynput_keyboard.Listener(on_press=on_press)
    mouse_listener.start()
    keyboard_listener.start()

    # USB monitoring baseline
    usb_baseline = _get_usb_devices() if is_linux() else set()

    try:
        while _guard_armed:
            # Wait for activity event or timeout for USB check
            try:
                await asyncio.wait_for(asyncio.shield(
                    asyncio.get_event_loop().run_in_executor(
                        None, activity_detected.wait
                    )
                ), timeout=10)

                if activity_detected.is_set() and _guard_armed:
                    activity_detected.clear()
                    await _send_intrusion_alert("Input activity detected (mouse/keyboard)")

            except asyncio.TimeoutError:
                pass

            # USB check (Linux only)
            if is_linux():
                current_usb = _get_usb_devices()
                new_devices = current_usb - usb_baseline
                if new_devices:
                    usb_baseline = current_usb
                    device_names = ", ".join(list(new_devices)[:3])
                    await _send_intrusion_alert(f"New USB device detected: {device_names}")

    finally:
        mouse_listener.stop()
        keyboard_listener.stop()


async def _guard_loop():
    """Main guard loop — picks best monitoring method available."""
    global _guard_armed

    logger.info("Guard: monitoring started")

    if _ensure_pynput():
        await _pynput_guard_loop()
    else:
        logger.warning("Guard: pynput unavailable, falling back to mouse polling")
        await _psutil_guard_loop()

    logger.info("Guard: monitoring stopped")


class IntrusionHandlers:

    @require_auth
    async def cmd_guard(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /guard on [grace_seconds]  — arm intrusion detection
        /guard off                 — disarm
        /guard status              — show status
        /guard grace <seconds>     — set grace period
        """
        global _guard_armed, _guard_task, _guard_bot, _guard_user_ids, _grace_period

        args = ctx.args or []
        msg = update.effective_message

        if not args or args[0].lower() == "status":
            await self._guard_status(msg)
            return

        sub = args[0].lower()

        if sub == "grace" and len(args) >= 2:
            try:
                _grace_period = max(5, int(args[1]))
                await msg.reply_text(
                    f"⏱️ Grace period set to <b>{_grace_period}s</b>",
                    parse_mode="HTML"
                )
            except ValueError:
                await msg.reply_text("❌ Grace period must be a number of seconds.")
            return

        if sub == "on":
            if _guard_armed:
                await msg.reply_text("🛡️ Guard is already armed.")
                return

            # Parse optional grace override
            grace = _grace_period
            if len(args) >= 2:
                try:
                    grace = int(args[1])
                except ValueError:
                    pass

            _guard_armed = True
            _guard_bot = ctx.bot
            _guard_user_ids = self.config.allowed_ids
            _save_guard_state()

            await msg.reply_text(
                f"🛡️ <b>Guard arming in {grace}s...</b>\n\n"
                f"Move away from your laptop now.\n"
                f"Any mouse/keyboard activity after {grace}s will trigger an alert\n"
                f"with screenshots sent here.\n\n"
                f"<code>/guard off</code> to disarm.",
                parse_mode="HTML"
            )

            # Grace period
            await asyncio.sleep(grace)

            if not _guard_armed:
                return  # Disarmed during grace period

            await msg.reply_text(
                "🔴 <b>Guard ARMED</b> — Watching for intrusions.",
                parse_mode="HTML"
            )

            # Start monitoring
            if _guard_task and not _guard_task.done():
                _guard_task.cancel()

            _guard_task = asyncio.create_task(_guard_loop())
            return

        if sub == "off":
            if not _guard_armed:
                await msg.reply_text("🛡️ Guard is already disarmed.")
                return

            _guard_armed = False
            _save_guard_state()

            if _guard_task:
                _guard_task.cancel()
                _guard_task = None

            await msg.reply_text(
                "🟢 <b>Guard DISARMED</b> — Monitoring stopped.",
                parse_mode="HTML"
            )
            return

        # Unknown subcommand — show help
        await msg.reply_text(
            "🛡️ <b>Intrusion Guard</b>\n\n"
            "<b>Commands:</b>\n"
            "  <code>/guard on</code>       — arm (30s grace period)\n"
            "  <code>/guard on 60</code>    — arm with 60s grace\n"
            "  <code>/guard off</code>      — disarm\n"
            "  <code>/guard status</code>   — show current state\n"
            "  <code>/guard grace 45</code> — set grace period\n\n"
            "<b>What it detects:</b>\n"
            "• Mouse movement\n"
            "• Any key press\n"
            "• USB devices plugged in (Linux)\n\n"
            "<b>On detection:</b>\n"
            "• Sends alert to Telegram\n"
            "• Takes screenshot + webcam photo\n"
            f"• Cooldown: {_alert_cooldown}s between alerts",
            parse_mode="HTML"
        )

    async def _guard_status(self, msg):
        global _guard_armed, _grace_period

        state = "🔴 <b>ARMED</b>" if _guard_armed else "🟢 Disarmed"
        last_alert = ""
        if _last_alert_time > 0:
            dt = datetime.fromtimestamp(_last_alert_time).strftime("%H:%M:%S")
            last_alert = f"\nLast alert: {dt}"

        has_pynput = False
        try:
            from pynput import mouse  # noqa
            has_pynput = True
        except ImportError:
            pass

        await msg.reply_text(
            f"🛡️ <b>Guard Status</b>\n\n"
            f"State: {state}\n"
            f"Grace period: {_grace_period}s\n"
            f"Monitor method: {'pynput (keyboard+mouse)' if has_pynput else 'mouse polling'}{last_alert}\n\n"
            f"<code>/guard on</code> to arm · <code>/guard off</code> to disarm",
            parse_mode="HTML"
        )
