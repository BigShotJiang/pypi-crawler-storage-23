"""
Salim AI Handler — Telegram message handler for natural language control.

Uses HTML parse mode throughout to avoid Markdown entity errors caused by
underscores in filenames, backslashes in paths, backticks in content, etc.
"""

from __future__ import annotations

import html
import logging
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.ai import SalimAI
from salim.ai_search import SearchResult, search_laptop
from salim.auth import require_auth
from salim.handlers.history import save_message, get_ai_context

logger = logging.getLogger("salim.ai_handler")

MAX_BUTTON_RESULTS = 8
HTML = "HTML"


def esc(text: str) -> str:
    """HTML-escape so any string is safe inside Telegram HTML messages."""
    return html.escape(str(text), quote=False)


# Commands that map to handler method names
HANDLER_MAP = {
    "screenshot": "cmd_screenshot",
    "ss":         "cmd_screenshot",
    "info":       "cmd_info",
    "cpu":        "cmd_cpu",
    "mem":        "cmd_mem",
    "disk":       "cmd_disk",
    "battery":    "cmd_battery",
    "network":    "cmd_network",
    "uptime":     "cmd_uptime",
    "top":        "cmd_top",
    "ps":         "cmd_ps",
    "ls":         "cmd_ls",
    "pwd":        "cmd_pwd",
    "paste":      "cmd_paste",
    "volume":     "cmd_volume",
    "brightness": "cmd_brightness",
    "lock":       "cmd_lock",
    "sleep":      "cmd_sleep",
    "screensaver":"cmd_screensaver",
    "notify":     "cmd_notify",
    "open":       "cmd_open",
    "type":       "cmd_type",
    "key":        "cmd_key",
    "mousepos":   "cmd_mousepos",
    "click":      "cmd_click",
    "scroll":     "cmd_scroll",
    "move":       "cmd_move",
    "run":        "cmd_run",
    "sh":         "cmd_run",
    "env":        "cmd_env",
    "which":      "cmd_which",
    "find":       "cmd_find",
    "grep":       "cmd_grep",
    "cat":        "cmd_cat",
    "stat":       "cmd_stat",
    "download":   "cmd_download",
    "copy":       "cmd_copy",
    "mkdir":      "cmd_mkdir",
    "zip":        "cmd_zip",
    "unzip":      "cmd_unzip",
    "write":      "cmd_write",
    "mv":         "cmd_mv",
    "cp":         "cmd_cp",
    "mic":        "cmd_mic",
    "record":     "cmd_mic",
    "speedtest":  "cmd_speedtest",
    "qr":         "cmd_qr",
    "tts":        "cmd_tts",
    "say":        "cmd_say",
    "screenshot": "cmd_screenshot",
    "ss":         "cmd_screenshot",
}

DESTRUCTIVE_MAP = {
    "shutdown":  "cmd_shutdown",
    "restart":   "cmd_restart",
    "sleep":     "cmd_sleep",
    "lock":      "cmd_lock",
    "hibernate": "cmd_hibernate",
    "logout":    "cmd_logout",
    "rm":        "cb_rm_confirm",
    "kill":      "cmd_kill",
}


async def _safe_edit(msg, text: str, **kwargs):
    """Edit a message safely — falls back to plain text on parse error."""
    try:
        await msg.edit_text(text, **kwargs)
    except Exception as e:
        logger.error(f"edit_text failed ({e}), retrying plain")
        try:
            await msg.edit_text(text[:4000], parse_mode=None)
        except Exception:
            pass


async def _safe_reply(msg, text: str, **kwargs):
    """Reply safely — falls back to plain text on parse error."""
    try:
        await msg.reply_text(text, **kwargs)
    except Exception as e:
        logger.error(f"reply_text failed ({e}), retrying plain")
        try:
            await msg.reply_text(text[:4000], parse_mode=None)
        except Exception:
            pass


class AIHandler:
    """
    Mixin for SalimBot — adds full natural language understanding.
    All plain-text Telegram messages go through handle_ai_message().
    """

    @property
    def _ai(self) -> SalimAI:
        if not hasattr(self, "_ai_instance"):
            self._ai_instance = SalimAI(self.config)
        return self._ai_instance

    @require_auth
    async def handle_ai_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        text = (msg.text or "").strip()
        if not text:
            return

        if not self._ai.is_configured():
            await _safe_reply(
                msg,
                "🤖 <b>AI mode is not configured.</b>\n\n"
                "Run <code>salim setup</code> on your laptop to add API keys.\n"
                "You can still use /commands directly — send /help.",
                parse_mode=HTML,
            )
            return

        # ── Save user message to conversation history ──────────────────────────
        user_id = update.effective_user.id if update.effective_user else 0
        if user_id:
            save_message(user_id, "user", text)

        # ── Document writer intercept (before AI call) ────────────────────────
        if hasattr(self, "handle_natural_doc"):
            from salim.handlers.document_writer import detect_doc_type
            _cat, _dt = detect_doc_type(text)
            _creation_kws = ["write", "create", "make", "generate", "draft", "prepare", "build"]
            if _dt and any(kw in text.lower() for kw in _creation_kws):
                handled = await self.handle_natural_doc(update, ctx, text)
                if handled:
                    return

        thinking = await msg.reply_text("🤖 <i>Thinking...</i>", parse_mode=HTML)

        # ── Build messages with conversation history context ─────────────────
        history_ctx = get_ai_context(user_id) if user_id else []

        try:
            intent = await self._ai.parse_intent_with_history(text, history_ctx)
        except Exception as e:
            await _safe_edit(thinking, f"⚠️ AI error: {esc(str(e))}", parse_mode=HTML)
            return

        action   = intent.get("action", "clarify")
        ai_msg   = esc(intent.get("message", ""))
        provider = intent.get("_provider", "")
        ptag     = f" <i>[{esc(provider)}]</i>" if provider else ""

        if action == "search_files":
            await _safe_edit(thinking, (ai_msg or "🔍 Searching your laptop...") + ptag, parse_mode=HTML)
            await self._do_search(update, ctx, intent)

        elif action == "execute":
            await _safe_edit(thinking, (ai_msg or "⚙️ Running...") + ptag, parse_mode=HTML)
            await self._do_execute(update, ctx, intent)

        elif action == "generate_and_write":
            await _safe_edit(thinking, (ai_msg or "✍️ Generating content...") + ptag, parse_mode=HTML)
            await self._do_generate_write(update, ctx, intent)

        elif action == "confirm":
            body = ai_msg or "⚠️ Confirm this action?"
            cmd  = intent.get("command", "").lstrip("/")
            args = intent.get("args", "")
            await _safe_edit(
                thinking,
                f"{body}{ptag}\n\n<i>This action may be irreversible.</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Yes, do it", callback_data=f"ai_confirm:{cmd}:{args}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel"),
                ]]),
            )

        elif action == "clarify":
            reply = ai_msg or "🤔 Could you be more specific? Or use a /command directly."
            await _safe_edit(thinking, reply, parse_mode=HTML)
            if user_id:
                save_message(user_id, "assistant", reply)

        else:
            reply = ai_msg or "⚠️ Something went wrong. Try a /command directly."
            await _safe_edit(thinking, reply, parse_mode=HTML)
            if user_id:
                save_message(user_id, "assistant", reply)

    async def _do_search(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        msg = update.effective_message
        keywords: list[str] = intent.get("keywords", [])
        file_types: list[str] = intent.get("file_types", [])

        if not keywords:
            await _safe_reply(
                msg,
                "❓ I couldn't extract search keywords.\n"
                "Try: <i>find my day 3 recording</i> or <i>search for project files</i>",
                parse_mode=HTML,
            )
            return

        results = await search_laptop(
            keywords=keywords,
            file_types=file_types or None,
            max_results=MAX_BUTTON_RESULTS,
        )

        if not results:
            kws = esc(", ".join(keywords))
            await _safe_reply(
                msg,
                f"🔍 No files found for: <b>{kws}</b>\n\n"
                f"Try different keywords, or use <code>/find &lt;pattern&gt;</code> directly.",
                parse_mode=HTML,
            )
            return

        text = _format_results_html(results)
        keyboard = _build_result_buttons(results)
        keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel")])

        await _safe_reply(msg, text, parse_mode=HTML, reply_markup=InlineKeyboardMarkup(keyboard))

    async def _do_execute(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        command  = intent.get("command", "").lstrip("/")
        args_str = intent.get("args", "")
        ctx.args = args_str.split() if args_str.strip() else []

        handler_name = HANDLER_MAP.get(command)
        if handler_name and hasattr(self, handler_name):
            await getattr(self, handler_name)(update, ctx)
        else:
            display = esc(f"{command} {args_str}".strip())
            await _safe_reply(
                update.effective_message,
                f"⚙️ Running: <code>{display}</code>",
                parse_mode=HTML,
            )
            ctx.args = [f"{command} {args_str}".strip()]
            if hasattr(self, "cmd_run"):
                await self.cmd_run(update, ctx)

    async def _do_generate_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        msg          = update.effective_message
        topic        = intent.get("topic", "")
        fmt          = intent.get("format", "txt").lower()
        filename     = intent.get("filename", f"salim_output.{fmt}")
        save_path    = Path(intent.get("save_path", "~/Desktop")).expanduser()
        instructions = intent.get("content_instructions", f"Write about: {topic}")

        if not topic:
            await _safe_reply(
                msg,
                "❓ I couldn't determine what to write about.\n"
                "Example: <i>create a txt file about the history of chess</i>",
                parse_mode=HTML,
            )
            return

        gen_msg = await msg.reply_text(
            f"✍️ <b>Writing your {esc(fmt.upper())} file about {esc(topic)}...</b>",
            parse_mode=HTML,
        )

        try:
            content, provider = await self._ai.generate_content(
                topic=topic, format=fmt, instructions=instructions, max_tokens=2048,
            )
        except Exception as e:
            await _safe_edit(gen_msg, f"⚠️ Content generation failed: {esc(str(e))}", parse_mode=HTML)
            return

        try:
            save_path.mkdir(parents=True, exist_ok=True)
            full_path = save_path / filename
            full_path.write_text(content, encoding="utf-8")
        except Exception as e:
            await _safe_edit(gen_msg, f"⚠️ Could not save file: {esc(str(e))}", parse_mode=HTML)
            return

        try:
            display_path = "~/" + str(full_path.relative_to(Path.home()))
        except ValueError:
            display_path = str(full_path)

        preview = esc(content[:300]) + ("..." if len(content) > 300 else "")

        await _safe_edit(
            gen_msg,
            f"✅ <b>Created</b> <code>{esc(filename)}</code> <i>[{esc(provider)}]</i>\n"
            f"📁 <code>{esc(display_path)}</code>\n"
            f"📝 {len(content):,} characters\n\n"
            f"<b>Preview:</b>\n<pre>{preview}</pre>",
            parse_mode=HTML,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("⬇️ Send to Telegram", callback_data=f"ai_dl:{str(full_path)[:200]}"),
                    InlineKeyboardButton("👁️ Read file", callback_data=f"ai_cat:{str(full_path)[:200]}"),
                ],
                [InlineKeyboardButton("✅ Done", callback_data="ai_cancel")],
            ]),
        )

    async def handle_ai_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        if data == "ai_cancel":
            await query.edit_message_text("❌ Cancelled.")
            return

        if data.startswith("ai_dl:"):
            path = data[6:]
            ctx.args = [path]
            if hasattr(self, "cmd_download"):
                await self.cmd_download(update, ctx)
            # After download, show action buttons for the file
            await _show_file_actions(query, path)

        elif data.startswith("ai_rm:"):
            path = data[6:]
            await query.edit_message_text(
                f"⚠️ <b>Delete this file?</b>\n<code>{esc(path)}</code>\n\n<i>Cannot be undone.</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🗑️ Yes, delete", callback_data=f"rm_confirm:{path}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel"),
                ]]),
            )

        elif data.startswith("ai_cat:"):
            path = data[7:]
            ctx.args = [path]
            if hasattr(self, "cmd_cat"):
                await self.cmd_cat(update, ctx)

        elif data.startswith("ai_play:"):
            # Open a media file with the default player
            path = data[8:]
            ctx.args = [path]
            if hasattr(self, "cmd_open"):
                await self.cmd_open(update, ctx)
            else:
                await query.answer("Opening file...", show_alert=False)

        elif data.startswith("ai_open:"):
            path = data[8:]
            ctx.args = [path]
            if hasattr(self, "cmd_open"):
                await self.cmd_open(update, ctx)

        elif data.startswith("ai_send_photo:"):
            # Send image file to Telegram
            path = data[14:]
            from pathlib import Path as _Path
            import io as _io
            try:
                p = _Path(path)
                if p.exists() and p.is_file():
                    with open(p, "rb") as f:
                        data_bytes = f.read()
                    buf = _io.BytesIO(data_bytes)
                    buf.name = p.name
                    await query.message.reply_photo(
                        photo=buf,
                        caption=f"🖼️ {esc(p.name)}"
                    )
                else:
                    await query.answer("File not found!", show_alert=True)
            except Exception as e:
                await query.answer(f"Error: {e}", show_alert=True)

        elif data.startswith("ai_confirm:"):
            rest     = data[11:]
            parts    = rest.split(":", 1)
            command  = parts[0]
            args_str = parts[1] if len(parts) > 1 else ""
            ctx.args = args_str.split() if args_str.strip() else []
            handler_name = DESTRUCTIVE_MAP.get(command)
            if handler_name and hasattr(self, handler_name):
                await query.edit_message_text(
                    f"⚙️ Executing <code>/{esc(command)}</code>...", parse_mode=HTML
                )
                await getattr(self, handler_name)(update, ctx)
            else:
                await query.edit_message_text(
                    f"❓ Unknown command: <code>{esc(command)}</code>", parse_mode=HTML
                )


async def _show_file_actions(query, path: str):
    """After downloading a file, show additional action buttons."""
    from pathlib import Path as _Path
    p = _Path(path)
    ext = p.suffix.lower()

    buttons = []
    if ext in {".mp4", ".mkv", ".avi", ".mov", ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"}:
        buttons.append(InlineKeyboardButton("▶️ Play", callback_data=f"ai_play:{path[:190]}"))
    if ext in {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"}:
        buttons.append(InlineKeyboardButton("🖼️ View", callback_data=f"ai_send_photo:{path[:190]}"))
    buttons.append(InlineKeyboardButton("🗑️ Delete", callback_data=f"ai_rm:{path[:190]}"))
    buttons.append(InlineKeyboardButton("📂 Open", callback_data=f"ai_open:{path[:190]}"))

    if buttons:
        try:
            await query.message.reply_text(
                f"📁 <b>{esc(p.name)}</b> — What next?",
                parse_mode="HTML",
                reply_markup=InlineKeyboardMarkup([buttons[:3], buttons[3:]] if len(buttons) > 3 else [buttons])
            )
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

TEXT_EXTENSIONS = {
    ".txt", ".md", ".csv", ".log", ".json", ".py", ".js", ".ts",
    ".html", ".css", ".xml", ".yaml", ".yml", ".sh", ".bat", ".env",
    ".ini", ".cfg", ".toml",
}

MEDIA_EXTENSIONS = {
    ".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm",
    ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a",
}

IMAGE_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp",
}


def _format_results_html(results: list[SearchResult]) -> str:
    """Format search results as safe HTML for Telegram."""
    count = len(results)
    lines = [f"🔍 <b>Found {count} result{'s' if count != 1 else ''}:</b>\n"]
    for i, r in enumerate(results, 1):
        lines.append(
            f"{i}️⃣ {r.icon} <b>{esc(r.path.name)}</b>\n"
            f"   📁 <code>{esc(r.short_path)}</code>\n"
            f"   💾 {esc(r.size_human)} · 🕐 {esc(r.modified_human)}"
        )
    lines.append("\n<i>Tap a button below to act on a file:</i>")
    return "\n".join(lines)


def _build_result_buttons(results: list[SearchResult]) -> list[list[InlineKeyboardButton]]:
    """Build action buttons per search result — ⬇️Send, 🗑️Delete, ▶️Play/Open, 👁️Read."""
    keyboard = []
    for i, r in enumerate(results, 1):
        path_str = str(r.path)[:190]  # Telegram callback_data limit ~64 bytes per button data
        ext = r.path.suffix.lower()

        # Row 1: file name label (non-functional, just shows filename)
        # We use multiple rows per result for clarity
        row1 = [
            InlineKeyboardButton(f"{i}️⃣ ⬇️ Download", callback_data=f"ai_dl:{path_str}"),
            InlineKeyboardButton("🗑️ Delete", callback_data=f"ai_rm:{path_str}"),
        ]
        # Add Open/Play/Read button based on file type
        if ext in MEDIA_EXTENSIONS:
            row1.append(InlineKeyboardButton("▶️ Play", callback_data=f"ai_play:{path_str}"))
        elif ext in IMAGE_EXTENSIONS:
            row1.append(InlineKeyboardButton("🖼️ View", callback_data=f"ai_send_photo:{path_str}"))
        elif ext in TEXT_EXTENSIONS:
            row1.append(InlineKeyboardButton("👁️ Read", callback_data=f"ai_cat:{path_str}"))
        else:
            row1.append(InlineKeyboardButton("📂 Open", callback_data=f"ai_open:{path_str}"))

        keyboard.append(row1)
    return keyboard
