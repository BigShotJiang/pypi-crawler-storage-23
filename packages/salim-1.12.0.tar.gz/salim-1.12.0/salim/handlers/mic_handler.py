"""
Salim Microphone Handler — /mic command.

Records audio from the laptop's microphone and sends it back to Telegram
as a voice note (OGG/Opus). Can also transcribe the recording via Whisper
and feed it into the AI command pipeline.

Usage:
  /mic            — record for 10 seconds (default)
  /mic 30         — record for 30 seconds
  /mic 5 exec     — record 5s, transcribe, execute as AI command
  /mic 5 trans    — record 5s, transcribe only (show text)

Dependencies (auto-installed on first use):
  sounddevice, scipy  — cross-platform mic recording
  ffmpeg              — convert WAV → OGG/Opus for Telegram
"""

from __future__ import annotations

import asyncio
import io
import logging
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.mic")

H = "HTML"
DEFAULT_DURATION = 10
MAX_DURATION = 300  # 5 minutes max


def _install_pkg(pkg: str) -> bool:
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet", "--break-system-packages"],
            check=True, timeout=120, capture_output=True
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install {pkg}: {e}")
        return False


def _ensure_deps() -> tuple[bool, str]:
    """Ensure sounddevice and scipy are available. Returns (ok, error_msg)."""
    try:
        import sounddevice  # noqa
        import scipy.io.wavfile  # noqa
        return True, ""
    except ImportError:
        pass
    # Try installing
    ok1 = _install_pkg("sounddevice")
    ok2 = _install_pkg("scipy")
    if ok1 and ok2:
        try:
            import sounddevice  # noqa
            import scipy.io.wavfile  # noqa
            return True, ""
        except ImportError as e:
            return False, str(e)
    return False, "Failed to install sounddevice/scipy"


def _record_wav(duration: int, sample_rate: int = 44100) -> bytes:
    """Synchronously record from mic → returns WAV bytes."""
    import sounddevice as sd
    import scipy.io.wavfile as wav
    import numpy as np

    recording = sd.rec(
        int(duration * sample_rate),
        samplerate=sample_rate,
        channels=1,
        dtype="int16",
    )
    sd.wait()  # Block until done

    buf = io.BytesIO()
    wav.write(buf, sample_rate, recording)
    buf.seek(0)
    return buf.read()


async def _wav_to_ogg(wav_bytes: bytes) -> bytes:
    """Convert WAV bytes → OGG/Opus bytes for Telegram via ffmpeg."""
    with tempfile.TemporaryDirectory() as tmp:
        wav_path = os.path.join(tmp, "mic.wav")
        ogg_path = os.path.join(tmp, "mic.ogg")

        with open(wav_path, "wb") as f:
            f.write(wav_bytes)

        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-i", wav_path,
            "-c:a", "libopus", "-b:a", "32k", ogg_path,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await proc.wait()

        if not os.path.exists(ogg_path):
            # Fallback: try libvorbis
            proc2 = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-i", wav_path,
                "-c:a", "libvorbis", ogg_path,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc2.wait()

        if os.path.exists(ogg_path):
            with open(ogg_path, "rb") as f:
                return f.read()
        return wav_bytes  # Fallback: send raw WAV


def _has_ffmpeg() -> bool:
    import shutil
    return bool(shutil.which("ffmpeg"))


class MicHandlers:
    """Mixin — /mic command to record from laptop microphone."""

    @require_auth
    async def cmd_mic(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /mic [duration_seconds] [exec|trans]

        Records audio from the laptop microphone and sends it to Telegram.
        Optional: transcribe and execute the recording as a voice command.
        """
        msg = update.effective_message

        # Parse args
        duration = DEFAULT_DURATION
        mode = "send"  # send | exec | trans
        for arg in (ctx.args or []):
            if arg.isdigit():
                duration = min(int(arg), MAX_DURATION)
            elif arg.lower() in ("exec", "execute", "run"):
                mode = "exec"
            elif arg.lower() in ("trans", "transcribe", "text"):
                mode = "trans"

        # Check deps
        ok, err = _ensure_deps()
        if not ok:
            await msg.reply_text(
                f"❌ <b>Mic recording unavailable</b>\n\n"
                f"Missing dependencies: <code>sounddevice scipy</code>\n"
                f"Install with: <code>pip install sounddevice scipy</code>\n\n"
                f"Error: <code>{err}</code>",
                parse_mode=H
            )
            return

        if not _has_ffmpeg():
            await msg.reply_text(
                "❌ <b>ffmpeg not found</b> — needed for audio conversion.\n"
                "Install: <code>sudo apt install ffmpeg</code> (Linux) | "
                "<code>brew install ffmpeg</code> (Mac)",
                parse_mode=H
            )
            return

        # Status message
        status = await msg.reply_text(
            f"🎙️ <b>Recording for {duration} seconds...</b>\n"
            f"<i>Speak now — recording from your laptop microphone</i>",
            parse_mode=H
        )

        try:
            # Record in executor (blocking call)
            loop = asyncio.get_event_loop()
            wav_bytes = await loop.run_in_executor(None, _record_wav, duration)
        except Exception as e:
            err_str = str(e)
            # Friendly error for common issues
            if "PortAudio" in err_str or "No such file" in err_str:
                err_str = (
                    "No microphone found or PortAudio not installed.\n"
                    "Install: <code>sudo apt install portaudio19-dev</code> then "
                    "<code>pip install sounddevice</code>"
                )
            await status.edit_text(f"❌ Recording failed: {err_str}", parse_mode=H)
            return

        await status.edit_text(
            f"🎙️ Recorded {duration}s — converting and sending...",
            parse_mode=H
        )

        # Convert to OGG
        try:
            ogg_bytes = await _wav_to_ogg(wav_bytes)
        except Exception as e:
            ogg_bytes = wav_bytes  # Send raw WAV as fallback

        buf = io.BytesIO(ogg_bytes)
        buf.name = "mic_recording.ogg"

        if mode == "send":
            # Just send the audio file
            await status.delete()
            await msg.reply_voice(
                voice=buf,
                caption=f"🎙️ Mic recording — {duration}s",
            )

        elif mode in ("exec", "trans"):
            # Transcribe using Whisper
            await status.edit_text("🎙️ Transcribing recording...", parse_mode=H)

            try:
                # Import transcription from voice handler
                from salim.handlers.voice import transcribe_audio
                text = await transcribe_audio(wav_bytes)
            except Exception as e:
                await status.edit_text(
                    f"❌ Transcription failed: {e}\n\n"
                    f"Make sure faster-whisper is installed:\n"
                    f"<code>pip install faster-whisper</code>",
                    parse_mode=H
                )
                return

            if not text:
                await status.edit_text(
                    "🎙️ <i>No speech detected in recording. Speak clearly.</i>",
                    parse_mode=H
                )
                return

            if mode == "trans":
                await status.edit_text(
                    f"🎙️ <b>Transcribed:</b>\n<blockquote>{text}</blockquote>",
                    parse_mode=H
                )
            else:
                # Execute as AI command
                await status.edit_text(
                    f"🎙️ <b>Transcribed:</b> <i>\"{text}\"</i>\n\n⚙️ Processing as command...",
                    parse_mode=H
                )
                if hasattr(self, "handle_ai_message"):
                    original_text = msg.text
                    msg.text = text
                    await self.handle_ai_message(update, ctx)
                    msg.text = original_text
