"""
Salim Clipboard Image Handler — read AND write images from/to clipboard.

/paste          — reads clipboard: text OR image (auto-detected, sends image as photo)
/copy <text>    — copies text to clipboard (existing behavior, extended here)
/copyphoto      — reply to a Telegram photo to copy it to clipboard

Paste pipeline:
  Linux  : xclip / xsel / wl-paste (Wayland) — checks all, uses first available
  macOS  : pbpaste for text, pngpaste / screencapture -c for images
  Windows: win32clipboard / PIL ImageGrab

Image detection:
  Checks clipboard MIME type for image/png, image/bmp, etc.
  Falls back to text if no image found.

Auto-installs: pngpaste (macOS via brew), xclip (Linux via apt)
"""
from __future__ import annotations

import asyncio
import html
import io
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows, run_shell_async

logger = logging.getLogger("salim.clipboard_image")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)


# ── Dependency helpers ────────────────────────────────────────────────────────

def _ensure_xclip() -> bool:
    """Install xclip on Linux if missing."""
    if shutil.which("xclip"):
        return True
    if is_linux():
        try:
            subprocess.run(
                ["sudo", "apt-get", "install", "-y", "xclip"],
                check=True, timeout=60, capture_output=True
            )
            return bool(shutil.which("xclip"))
        except Exception:
            pass
    return False


def _ensure_pngpaste() -> bool:
    """Install pngpaste on macOS via brew if missing."""
    if shutil.which("pngpaste"):
        return True
    if is_mac() and shutil.which("brew"):
        try:
            subprocess.run(
                ["brew", "install", "pngpaste"],
                check=True, timeout=120, capture_output=True
            )
            return bool(shutil.which("pngpaste"))
        except Exception:
            pass
    return False


def _ensure_pyperclip() -> bool:
    try:
        import pyperclip  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyperclip", "--quiet"],
            check=True, timeout=60
        )
        import pyperclip  # noqa
        return True
    except Exception:
        return False


def _ensure_pillow() -> bool:
    try:
        from PIL import Image, ImageGrab  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "Pillow", "--quiet"],
            check=True, timeout=120
        )
        from PIL import Image, ImageGrab  # noqa
        return True
    except Exception:
        return False


# ── Core clipboard read logic ─────────────────────────────────────────────────

class ClipboardResult:
    """Result of reading clipboard."""
    def __init__(
        self,
        has_image: bool = False,
        image_bytes: bytes | None = None,
        image_format: str = "PNG",
        text: str = "",
        error: str = "",
    ):
        self.has_image = has_image
        self.image_bytes = image_bytes
        self.image_format = image_format
        self.text = text
        self.error = error


def _read_clipboard_linux() -> ClipboardResult:
    """
    Read clipboard on Linux.
    Tries: wl-paste (Wayland) → xclip → xsel
    For images: checks if clipboard has image/png target first.
    """
    display = os.environ.get("DISPLAY", "")
    wayland = os.environ.get("WAYLAND_DISPLAY", "")

    # ── Wayland (wl-clipboard) ──────────────────────────────────────────────
    if wayland and shutil.which("wl-paste"):
        # Check if image is in clipboard
        try:
            mime_result = subprocess.run(
                ["wl-paste", "--list-types"],
                capture_output=True, text=True, timeout=5
            )
            mime_types = mime_result.stdout.lower()
            has_img = "image/" in mime_types

            if has_img:
                # Get image as PNG
                for mime in ["image/png", "image/bmp", "image/jpeg"]:
                    if mime in mime_types:
                        img_result = subprocess.run(
                            ["wl-paste", "--type", mime],
                            capture_output=True, timeout=10
                        )
                        if img_result.returncode == 0 and img_result.stdout:
                            fmt = mime.split("/")[1].upper()
                            fmt = "JPEG" if fmt == "JPEG" else fmt
                            return ClipboardResult(
                                has_image=True,
                                image_bytes=img_result.stdout,
                                image_format=fmt,
                            )
            # Fallback to text
            txt = subprocess.run(
                ["wl-paste", "--no-newline"],
                capture_output=True, text=True, timeout=5
            )
            return ClipboardResult(text=txt.stdout or "")
        except Exception as e:
            logger.debug(f"wl-paste failed: {e}")

    # ── X11 (xclip) ──────────────────────────────────────────────────────────
    if display and shutil.which("xclip"):
        try:
            # Check targets (MIME types available)
            targets_result = subprocess.run(
                ["xclip", "-selection", "clipboard", "-t", "TARGETS", "-o"],
                capture_output=True, text=True, timeout=5
            )
            targets = targets_result.stdout.lower()
            has_img = "image/" in targets

            if has_img:
                for mime in ["image/png", "image/bmp", "image/jpeg"]:
                    if mime in targets:
                        img_result = subprocess.run(
                            ["xclip", "-selection", "clipboard", "-t", mime, "-o"],
                            capture_output=True, timeout=10
                        )
                        if img_result.returncode == 0 and img_result.stdout:
                            fmt = mime.split("/")[1].upper()
                            fmt = "JPEG" if fmt == "JPEG" else fmt
                            return ClipboardResult(
                                has_image=True,
                                image_bytes=img_result.stdout,
                                image_format=fmt,
                            )

            # Text fallback
            txt = subprocess.run(
                ["xclip", "-selection", "clipboard", "-o"],
                capture_output=True, text=True, timeout=5
            )
            return ClipboardResult(text=txt.stdout or "")
        except Exception as e:
            logger.debug(f"xclip failed: {e}")

    # ── xsel fallback ─────────────────────────────────────────────────────────
    if display and shutil.which("xsel"):
        try:
            txt = subprocess.run(
                ["xsel", "--clipboard", "--output"],
                capture_output=True, text=True, timeout=5
            )
            return ClipboardResult(text=txt.stdout or "")
        except Exception as e:
            logger.debug(f"xsel failed: {e}")

    return ClipboardResult(error="No clipboard tool found (install xclip or wl-clipboard)")


def _read_clipboard_mac() -> ClipboardResult:
    """
    Read clipboard on macOS.
    Uses: pngpaste for images, pbpaste for text.
    """
    # Try image first with pngpaste
    if shutil.which("pngpaste"):
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            tmp_path = f.name
        try:
            result = subprocess.run(
                ["pngpaste", tmp_path],
                capture_output=True, timeout=5
            )
            if result.returncode == 0 and Path(tmp_path).exists():
                img_bytes = Path(tmp_path).read_bytes()
                Path(tmp_path).unlink(missing_ok=True)
                if img_bytes:
                    return ClipboardResult(
                        has_image=True,
                        image_bytes=img_bytes,
                        image_format="PNG",
                    )
        except Exception as e:
            logger.debug(f"pngpaste failed: {e}")
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    # Try PIL ImageGrab (also works for images on macOS)
    try:
        from PIL import ImageGrab
        img = ImageGrab.grabclipboard()
        if img is not None:
            buf = io.BytesIO()
            # Convert RGBA → RGB for JPEG compatibility
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            img.save(buf, format="PNG")
            buf.seek(0)
            return ClipboardResult(
                has_image=True,
                image_bytes=buf.getvalue(),
                image_format="PNG",
            )
    except Exception as e:
        logger.debug(f"PIL ImageGrab failed on mac: {e}")

    # Text fallback
    try:
        result = subprocess.run(
            ["pbpaste"], capture_output=True, text=True, timeout=5
        )
        return ClipboardResult(text=result.stdout or "")
    except Exception as e:
        return ClipboardResult(error=f"pbpaste failed: {e}")


def _read_clipboard_windows() -> ClipboardResult:
    """
    Read clipboard on Windows using win32clipboard.
    Auto-installs pywin32 if missing.
    """
    # Try win32clipboard first
    try:
        import win32clipboard
        import win32con
        win32clipboard.OpenClipboard()
        try:
            # Check for image (DIB = Device Independent Bitmap)
            if win32clipboard.IsClipboardFormatAvailable(win32con.CF_DIB):
                data = win32clipboard.GetClipboardData(win32con.CF_DIB)
                # Convert DIB to PNG using PIL
                try:
                    from PIL import Image
                    import struct
                    # Parse BMP header
                    buf = io.BytesIO()
                    # Add BMP file header (14 bytes) before the DIB
                    size = len(data) + 14
                    buf.write(b'BM')
                    buf.write(struct.pack('<I', size))
                    buf.write(b'\x00\x00\x00\x00')
                    buf.write(struct.pack('<I', 14 + 40))  # offset to pixel data
                    buf.write(data)
                    buf.seek(0)
                    img = Image.open(buf)
                    out = io.BytesIO()
                    img.save(out, format="PNG")
                    return ClipboardResult(
                        has_image=True,
                        image_bytes=out.getvalue(),
                        image_format="PNG",
                    )
                except Exception as e:
                    logger.debug(f"DIB→PNG conversion failed: {e}")

            # Text
            if win32clipboard.IsClipboardFormatAvailable(win32con.CF_UNICODETEXT):
                text = win32clipboard.GetClipboardData(win32con.CF_UNICODETEXT)
                return ClipboardResult(text=text or "")
        finally:
            win32clipboard.CloseClipboard()
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f"win32clipboard error: {e}")

    # PIL ImageGrab (Windows)
    try:
        from PIL import ImageGrab
        img = ImageGrab.grabclipboard()
        if img is not None:
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return ClipboardResult(
                has_image=True,
                image_bytes=buf.getvalue(),
                image_format="PNG",
            )
    except Exception as e:
        logger.debug(f"PIL ImageGrab windows failed: {e}")

    # pyperclip text fallback
    try:
        import pyperclip
        text = pyperclip.paste()
        return ClipboardResult(text=text or "")
    except Exception as e:
        return ClipboardResult(error=f"Cannot read clipboard: {e}")


def _read_clipboard_sync() -> ClipboardResult:
    """Dispatch to correct OS implementation."""
    if is_linux():
        return _read_clipboard_linux()
    elif is_mac():
        return _read_clipboard_mac()
    else:
        return _read_clipboard_windows()


async def read_clipboard() -> ClipboardResult:
    """Async wrapper around sync clipboard reading."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _read_clipboard_sync)


# ── Copy image to clipboard ───────────────────────────────────────────────────

def _write_image_to_clipboard(image_bytes: bytes) -> tuple[bool, str]:
    """
    Write PNG image bytes to system clipboard.
    Returns (success, error_message).
    """
    if is_linux():
        # Try wl-copy (Wayland) first
        if os.environ.get("WAYLAND_DISPLAY") and shutil.which("wl-copy"):
            try:
                proc = subprocess.run(
                    ["wl-copy", "--type", "image/png"],
                    input=image_bytes, timeout=5
                )
                return proc.returncode == 0, ""
            except Exception as e:
                logger.debug(f"wl-copy image failed: {e}")

        # X11 xclip
        if shutil.which("xclip"):
            try:
                proc = subprocess.run(
                    ["xclip", "-selection", "clipboard", "-t", "image/png", "-i"],
                    input=image_bytes, timeout=5
                )
                return proc.returncode == 0, ""
            except Exception as e:
                return False, str(e)

        return False, "No clipboard tool found (install xclip or wl-clipboard)"

    elif is_mac():
        # Use osascript to set clipboard from PNG file
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            f.write(image_bytes)
            tmp = f.name
        try:
            result = subprocess.run(
                ["osascript", "-e",
                 f'set the clipboard to (read (POSIX file "{tmp}") as «class PNGf»)'],
                capture_output=True, timeout=5
            )
            return result.returncode == 0, result.stderr.decode(errors="replace")
        except Exception as e:
            return False, str(e)
        finally:
            Path(tmp).unlink(missing_ok=True)

    else:  # Windows
        try:
            import win32clipboard
            import win32con
            from PIL import Image
            img = Image.open(io.BytesIO(image_bytes))
            output = io.BytesIO()
            img.convert("RGB").save(output, "BMP")
            data = output.getvalue()[14:]  # skip BMP file header
            win32clipboard.OpenClipboard()
            win32clipboard.EmptyClipboard()
            win32clipboard.SetClipboardData(win32con.CF_DIB, data)
            win32clipboard.CloseClipboard()
            return True, ""
        except Exception as e:
            return False, str(e)


# ── Handler class ─────────────────────────────────────────────────────────────

class ClipboardImageHandlers:
    """
    Extends paste/copy to handle images.
    Integrated into existing screen.py cmd_paste / cmd_copy flow
    by being called from those methods OR used standalone.
    """

    @require_auth
    async def cmd_paste_smart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /paste — read clipboard. If it contains an image, sends it as a photo.
        If text, sends the text. Smart auto-detection.
        """
        msg = update.effective_message
        status = await msg.reply_text("📋 <i>Reading clipboard...</i>", parse_mode=H)

        # Ensure deps
        if is_linux():
            if not _ensure_xclip() and not shutil.which("wl-paste"):
                await status.edit_text(
                    "❌ Clipboard tools not found.\n"
                    "Install: <code>sudo apt install xclip</code> or <code>sudo apt install wl-clipboard</code>",
                    parse_mode=H
                )
                return
        elif is_mac():
            # Try to install pngpaste for image support (non-critical)
            _ensure_pngpaste()
        else:
            _ensure_pillow()

        result = await read_clipboard()

        if result.error:
            await status.edit_text(
                f"❌ Clipboard error: {esc(result.error)}", parse_mode=H
            )
            return

        if result.has_image and result.image_bytes:
            # Send as photo
            try:
                await status.delete()
            except Exception:
                pass

            size_kb = len(result.image_bytes) // 1024
            buf = io.BytesIO(result.image_bytes)
            buf.name = f"clipboard_{int(time.time())}.{result.image_format.lower()}"

            await msg.reply_photo(
                photo=buf,
                caption=(
                    f"📋 <b>Clipboard Image</b>\n"
                    f"🖼️ Format: {result.image_format} · 💾 {size_kb} KB\n"
                    f"🕐 {time.strftime('%H:%M:%S')}"
                ),
                parse_mode=H,
            )

        elif result.text:
            text = result.text
            await status.edit_text(
                f"📋 <b>Clipboard Text</b>\n\n"
                f"<pre>{esc(text[:3000])}</pre>"
                + (f"\n\n<i>...{len(text) - 3000} more chars</i>" if len(text) > 3000 else ""),
                parse_mode=H,
            )
        else:
            await status.edit_text("📋 Clipboard is empty.", parse_mode=H)

    @require_auth
    async def cmd_copyphoto(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /copyphoto — reply to a Telegram photo to copy it to the system clipboard.
        Usage: reply to any photo message with /copyphoto
        """
        msg = update.effective_message

        # Find photo — either replied-to message or current message
        photo = None
        if msg.reply_to_message and msg.reply_to_message.photo:
            photo = msg.reply_to_message.photo[-1]  # largest size
        elif msg.photo:
            photo = msg.photo[-1]

        if not photo:
            await msg.reply_text(
                "📷 <b>Copy Photo to Clipboard</b>\n\n"
                "Reply to any photo message with <code>/copyphoto</code> to copy it to your laptop's clipboard.\n\n"
                "<i>Example: send a screenshot from your phone, then reply with /copyphoto</i>",
                parse_mode=H
            )
            return

        status = await msg.reply_text("📋 <i>Copying photo to clipboard...</i>", parse_mode=H)

        try:
            # Download the photo
            file_obj = await ctx.bot.get_file(photo.file_id)
            buf = io.BytesIO()
            await file_obj.download_to_memory(buf)
            image_bytes = buf.getvalue()

            # Convert to PNG using Pillow (ensures compatibility)
            _ensure_pillow()
            try:
                from PIL import Image as PILImage
                img = PILImage.open(io.BytesIO(image_bytes))
                png_buf = io.BytesIO()
                img.save(png_buf, format="PNG")
                png_bytes = png_buf.getvalue()
            except Exception:
                png_bytes = image_bytes  # use raw if Pillow fails

            # Write to clipboard
            loop = asyncio.get_event_loop()
            success, error = await loop.run_in_executor(
                None, _write_image_to_clipboard, png_bytes
            )

            if success:
                size_kb = len(png_bytes) // 1024
                await status.edit_text(
                    f"✅ <b>Photo copied to clipboard!</b>\n"
                    f"💾 {size_kb} KB PNG\n"
                    f"<i>You can now paste it in any app on your laptop (Ctrl+V)</i>",
                    parse_mode=H
                )
            else:
                await status.edit_text(
                    f"❌ Failed to copy to clipboard: {esc(error or 'unknown error')}",
                    parse_mode=H
                )

        except Exception as e:
            logger.error(f"copyphoto error: {e}", exc_info=True)
            await status.edit_text(f"❌ Error: {esc(str(e))}", parse_mode=H)
