"""
salim._post_install

This module is invoked automatically by pip after `pip install salim` via
the console_scripts entry point `salim-postinstall`.

It triggers the full auto-install flow so users never have to manually
pip install any required or optional dependency.
"""
from __future__ import annotations
import sys


def run():
    # Try to import rich for a nice output, fall back to print
    try:
        from rich.console import Console
        console = Console()
    except ImportError:
        console = None

    try:
        from salim.auto_install import run_auto_install
        run_auto_install(verbose=True, force=False, console=console)
    except Exception as e:
        msg = f"[Salim post-install] Warning: auto-install step failed: {e}"
        if console:
            console.print(f"[yellow]{msg}[/yellow]")
        else:
            print(msg)


if __name__ == "__main__":
    run()
