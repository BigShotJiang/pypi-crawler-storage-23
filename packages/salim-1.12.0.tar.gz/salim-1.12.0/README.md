# 🖥️ Salim v11 — AI-Powered Telegram Laptop Control Bot

Control your laptop from anywhere via Telegram. Type in **plain English** — AI understands and acts.

---

## ✨ What's New in v11

| Feature | Details |
|---|---|
| 🎙️ `/mic` command | Record from laptop microphone → sends voice note to Telegram |
| 🔊 Real volume control | Uses `pulsectl` → `pactl` → `amixer` (Linux), `osascript` (Mac) |
| 🚀 Fixed app launcher | Proper `setsid` + `DISPLAY` env for GUI apps on Linux |
| 🔍 Smart file search | AI extracts keywords, searches whole laptop, shows buttons |
| ⬇️▶️🗑️📂 File action buttons | Download · Play · Delete · Open for every search result |
| 📄 Real documents | `.docx`/`.xlsx` created by AI from natural language |
| 📝 HTML parse mode | All Telegram messages use HTML — no Markdown escaping issues |

---

## 🚀 Quick Start

### 1. Install

```bash
pip install salim
# or from source:
pip install -e .
```

### 2. Setup

```bash
salim setup
```

Prompts for:
- **Telegram Bot Token** — get from [@BotFather](https://t.me/BotFather)
- **Your Telegram User ID** — get from [@userinfobot](https://t.me/userinfobot)
- **AI API key** — NVIDIA NIM / Groq / Z.AI (at least one)

### 3. Run

```bash
salim start
salim start --verbose    # with debug logging
```

---

## 🤖 AI Natural Language

Just **type anything** — no need to memorize commands:

> *"open chrome"*  
> *"take a screenshot"*  
> *"what's my battery"*  
> *"find my Day 03 video"*  
> *"turn up the volume"*  
> *"mute"*  
> *"create a budget spreadsheet for March"*  
> *"write me a cover letter for a Python dev role at Google"*  
> *"record from microphone for 30 seconds"*

---

## 📋 All Commands

### 🎙️ Microphone Recording (NEW v11)

```
/mic              — Record 10s from laptop mic → sends as Telegram voice note
/mic 30           — Record 30 seconds
/mic 10 exec      — Record, transcribe, and execute as AI command
/mic 5 trans      — Record and transcribe only (show text)
```

**Tip:** also send any Telegram voice note → transcribed by Whisper → executed as command.

---

### 🔊 Volume Control

```
/volume           — Get current volume (e.g. 75%)
/volume 75        — Set to 75%
/volume up        — Increase +10%
/volume down      — Decrease -10%
/volume mute      — Mute audio
/volume unmute    — Unmute audio
```

Linux: `pulsectl` → `pactl` → `amixer` | Mac: `osascript` | Windows: PowerShell

---

### 🚀 Open Apps & URLs

```
/open chrome           — Launch Google Chrome
/open spotify          — Launch Spotify
/open vscode           — Launch VS Code
/open terminal         — Launch terminal
/open https://yt.com   — Open URL
/open ~/file.pdf       — Open file with default app
```

Supported: chrome, firefox, safari, brave, vscode, spotify, discord, slack, zoom,
telegram, vlc, gimp, obs, terminal, files/nautilus/finder, calculator, settings,
libreoffice, word, excel, and any installed app name.

---

### 🔍 Smart File Search

Type naturally:

> *"download Day 03"*  
> *"find my lecture notes"*  
> *"where's the project report"*

Results appear as interactive buttons:

```
1️⃣ 🎬 Day03_Lecture.mp4   ~/Videos/Course   1.2 GB · 3 days ago
   [⬇️ Download]  [🗑️ Delete]  [▶️ Play]

2️⃣ 📝 day03_notes.txt     ~/Documents       45 KB · today
   [⬇️ Download]  [🗑️ Delete]  [👁️ Read]
```

After download → additional buttons: **Play · Delete · Open**

---

### 📄 Document Creation

```
/doc resume           — AI creates professional resume (.docx)
/doc invoice          — Invoice spreadsheet (.xlsx)
/doc cover letter     — Cover letter (.docx)
/doc budget           — Budget tracker (.xlsx)
/doc meeting minutes  — Meeting minutes (.docx)
/doc report           — Business report (.docx)
```

Natural language: *"write me a resume for Ahmed, software engineer"*

Files created locally and sent to Telegram.

---

### 📸 Screen & Input

```
/screenshot           — Take screenshot
/ss                   — Same as /screenshot
/stream               — Live screen stream
/streamstop           — Stop stream
/type <text>          — Type on screen
/key ctrl+c           — Press keyboard shortcut
/click <x> <y>        — Mouse click
/scroll <n>           — Scroll (+ up, - down)
/move <x> <y>         — Move mouse cursor
/mousepos             — Get current mouse position
/brightness <0-100>   — Set screen brightness
/notify <title>|<msg> — Desktop notification
```

---

### 💻 System & Shell

```
/info     — Full system overview (CPU, RAM, disk, network)
/cpu      — CPU usage & cores
/mem      — Memory usage
/disk     — Disk usage
/battery  — Battery % and charging status
/network  — Network interfaces and IPs
/uptime   — System uptime
/top      — Live process monitor
/ps [name]— Running processes
/kill <pid>— Kill process
/run <cmd>— Run shell command
/runbg <cmd>— Run in background
/env      — Environment variables
/which <prog>— Find binary path
/cron <cmd> <schedule>— Add cron job
/cronjobs — List cron jobs
/cronstop <id>— Remove cron job
```

---

### 📂 Files

```
/ls [path]    /cd <path>    /pwd
/cat <file>   /stat <file>  /find <pattern>
/grep <pattern> [path]      /mkdir <name>
/rm <path>    /mv <s> <d>   /cp <s> <d>
/write <file> <text>
/download <path>   — Send file to Telegram
/upload            — Receive file from Telegram
/zip <path>        /unzip <file>
```

---

### 📋 Clipboard

```
/copy <text>    — Copy text to clipboard
/paste          — Read clipboard (text or image)
/copyphoto      — Copy photo to clipboard (reply to photo)
```

---

### 🌐 Browser Automation

```
/browse <url>             — Open URL + screenshot
/browse_click <selector>  — Click element
/browse_type <sel> <text> — Type in field
/browse_scroll [up|down]  — Scroll page
/browse_js <javascript>   — Run JS
/browse_back              — Go back
/browse_close             — Close browser
```

---

### 🗣️ Text-to-Speech

```
/tts <text>         — Laptop speaks text
/say <text>         — Same as /tts
/tts_lang <code>    — Language (en, ar, fr...)
/tts_speed <0.5-2>  — Speed
/tts_engine         — Switch engine
/tts_voice          — List voices
```

---

### 🔌 SSH

```
/ssh_add <alias> <user@host> [port]
/ssh <alias> <command>
/ssh_list   /ssh_remove <alias>
/ssh_upload <alias> <local> <remote>
/ssh_download <alias> <remote>
```

---

### 👁️ Vision AI

```
/vision on      — Auto-describe all photos
/askvision <q>  — Ask about last photo
```

Send any photo → reply with a question.

---

### 🔋 Power

```
/shutdown   /restart   /sleep   /hibernate
/lock       /logout    /screensaver
```

Destructive commands ask for confirmation.

---

### 📷 Camera & Recording

```
/cam           — Webcam snapshot
/cam list      — List cameras
/record <sec>  — Record screen video
```

---

### 🔔 Alerts

```
/alert add cpu > 80       — Alert when CPU > 80%
/alert add battery < 20   — Low battery alert
/alert list               — View alerts
/alert del <id>           — Remove alert
```

---

### 📝 Notes

```
/note <text>   — Save note
/notes         — List notes
/notedel <id>  — Delete note
/noteclear     — Clear all
```

---

### ⏰ Scheduler

```
/at 14:30 screenshot    — Run at specific time
/every 5m screenshot    — Run on repeat
/jobs                   — List jobs
/jobcancel <id>         — Cancel job
```

---

### 📡 File Watcher

```
/watch <path>    — Watch for changes
/watchlist       — List watchers
/watchstop <id>  — Stop watcher
```

---

### ⚡ Other

```
/speedtest          — Internet speed (download/upload/ping)
/qr <text>          — Generate QR code
/qrread             — Read QR from photo
/code <desc>        — AI writes & runs Python code
/guard on/off       — Intrusion detection (webcam)
/config             — Bot settings
/logs [n]           — Audit log
/history            — Conversation memory
/uploads            — Upload history
```

---

## 🔧 System Dependencies

**Linux:**
```bash
sudo apt install -y ffmpeg portaudio19-dev pulseaudio-utils
pip install pulsectl sounddevice scipy
```

**Mac:**
```bash
brew install ffmpeg portaudio
pip install sounddevice scipy
```

**Windows:** install ffmpeg from ffmpeg.org, add to PATH.

---

## 🔑 AI Providers (at least one required)

| Provider | Free Tier | Setup |
|---|---|---|
| **NVIDIA NIM** | Credits | [build.nvidia.com](https://build.nvidia.com) |
| **Groq** | Yes | [console.groq.com](https://console.groq.com) |
| **Z.AI** | Yes (FREE) | [z.ai](https://z.ai) |

---

## 🔒 Security

- Only your Telegram user ID can control the bot
- All commands logged (`/logs`)
- Destructive commands require confirmation
- Intrusion guard alerts via Telegram

---

*Salim v11 — Python · python-telegram-bot · faster-whisper · sounddevice · pulsectl*
