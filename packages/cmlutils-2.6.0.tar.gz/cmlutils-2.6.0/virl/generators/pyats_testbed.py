def pyats_testbed_generator(lab):
    return lab.get_pyats_testbed()
