# -*- coding: utf-8 -*-
"""wordextractor — 한국어 혼성어(blend word) 추출 파이프라인

설치:
    pip install wordextractor          # 기본 (step 1~4)
    pip install wordextractor[naver]   # + 네이버 검색 (step 6)
    pip install wordextractor[all]     # 전체

주요 함수:
    extract_patterns(words)
        기등재 혼성어 목록에서 N-Gram 패턴을 추출한다.

    extract_matched_eojeol(corpus, patterns)
        말뭉치에서 패턴에 매칭되는 어절과 빈도를 추출한다.
        - exclude_urimalsam=True: 내장 우리말샘 표제어(약 97만개) 자동 제외
        - exclude_input_words=True: 패턴 추출에 사용된 입력 혼성어 자동 제외

    search_corpus_example(words, corpus)
        후보 어절의 말뭉치 용례를 검색한다.

    search_naver_first_occurrence(words)
        네이버 뉴스에서 최초 출현일을 검색한다.
        Colab/PC 환경을 자동 감지하여 Selenium을 설정한다.

    build_prompt(word, pattern, examples)
        혼성어 판정용 LLM 프롬프트를 생성한다.
        후보 어절 + 매칭 패턴 + 용례를 조합. n_examples로 용례 수 설정 가능.

    load_dictionary(path)
        사전 파일(xlsx/xls)에서 한글 표제어를 로드한다.
        우리말샘 디렉토리, wordlist 파일 등에 사용.

사용 예:
    >>> from wordextractor import *
    >>>
    >>> # 1) 패턴 추출
    >>> patterns = extract_patterns(["호캉스", "펫캉스", "브렉시트"])
    >>>
    >>> # 2) 매칭 어절 추출 (우리말샘 + 입력 혼성어 자동 제외)
    >>> matched = extract_matched_eojeol(sentences, patterns)
    >>>
    >>> # 3) 제외 옵션 조절
    >>> matched = extract_matched_eojeol(
    ...     sentences, patterns,
    ...     exclude_urimalsam=False,      # 우리말샘 제외 끄기
    ...     exclude_input_words=False,    # 입력 혼성어 제외 끄기
    ... )
    >>>
    >>> # 4) 용례 검색
    >>> examples = search_corpus_example(matched["어절"].tolist(), sentences)
    >>>
    >>> # 5) LLM 프롬프트 생성
    >>> prompt = build_prompt("슬세권", pattern="세권",
    ...     examples=["슬세권 아파트 인기"], n_examples=3)
    >>>
    >>> # 6) 네이버 최초 출현일
    >>> naver = search_naver_first_occurrence(matched["어절"].tolist())
"""

__version__ = "0.2.1"

from wordextractor.config import PipelineConfig, CorpusProfile
from wordextractor.prompt import build_prompt, format_prompt, parse_judgment_json
from wordextractor.api import (
    extract_patterns,
    extract_matched_eojeol,
    search_corpus_example,
    search_naver_first_occurrence,
    load_dictionary,
)

__all__ = [
    "__version__",
    # Config
    "PipelineConfig",
    "CorpusProfile",
    # Public API
    "extract_patterns",
    "extract_matched_eojeol",
    "search_corpus_example",
    "search_naver_first_occurrence",
    "load_dictionary",
    # LLM helpers
    "build_prompt",
    "format_prompt",
    "parse_judgment_json",
]
