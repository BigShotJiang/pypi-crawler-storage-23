# -*- coding: utf-8 -*-
"""Step registry for the blend extraction pipeline."""

from __future__ import annotations

from typing import Callable, Dict

from wordextractor.config import PipelineConfig


def _step1(cfg: PipelineConfig):
    from wordextractor.steps.step1_extract_patterns import run

    run(cfg)


def _step2(cfg: PipelineConfig):
    from wordextractor.steps.step2_build_eojeol_type_freq import run

    run(cfg)


def _step3(cfg: PipelineConfig):
    from wordextractor.steps.step3_pattern_matching import run

    run(cfg)


def _step4(cfg: PipelineConfig):
    from wordextractor.steps.step4_search_corpus_example import run

    run(cfg)


def _step5(cfg: PipelineConfig):
    from wordextractor.steps.step5_llm_annotation import run

    run(cfg)


def _step6(cfg: PipelineConfig):
    from wordextractor.steps.step6_naver_first_occurrence import run

    run(cfg)


STEPS: Dict[str, Callable[[PipelineConfig], None]] = {
    "step1": _step1,
    "step2": _step2,
    "step3": _step3,
    "step4": _step4,
    "step5": _step5,
    "step6": _step6,
}
