# -*- coding: utf-8 -*-
"""Bundled data for wordextractor."""

from __future__ import annotations

import gzip
from functools import lru_cache
from importlib import resources


@lru_cache(maxsize=1)
def load_urimalsam_headwords() -> frozenset[str]:
    """패키지에 내장된 우리말샘 표제어(한글 2음절 이상)를 로드한다.

    Returns
    -------
    frozenset[str]
        우리말샘 한글 표제어 집합 (약 97만개)

    Examples
    --------
    >>> from wordextractor.data import load_urimalsam_headwords
    >>> headwords = load_urimalsam_headwords()
    >>> "사과" in headwords
    True
    >>> len(headwords)
    969324
    """
    ref = resources.files("wordextractor.data") / "urimalsam_headwords.txt.gz"
    with resources.as_file(ref) as path:
        with gzip.open(path, "rt", encoding="utf-8") as f:
            words = frozenset(line.strip() for line in f if line.strip())
    return words
