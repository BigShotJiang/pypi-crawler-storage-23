# -*- coding: utf-8 -*-
"""Allow running as: python -m wordextractor"""
from wordextractor.cli import main

main()
