# -*- coding: utf-8 -*-
"""Shared Korean text utilities."""

import re

KO_PATTERN = re.compile(r"[가-힣]+")
ONLY_KO_PATTERN = re.compile(r"^[가-힣]+$")


def keep_korean(text: str) -> str:
    """Extract only Korean characters from text."""
    return "".join(KO_PATTERN.findall(str(text)))


def is_korean_only(text: str) -> bool:
    """Check if text contains only Korean syllables."""
    return bool(ONLY_KO_PATTERN.match(text))
