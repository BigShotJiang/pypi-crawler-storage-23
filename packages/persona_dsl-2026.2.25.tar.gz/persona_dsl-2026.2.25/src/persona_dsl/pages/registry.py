import inspect
from dataclasses import fields, MISSING
from typing import Dict, Type

from . import elements as elements_module
from .elements import Element
from .page import Page

# Explicit exports of classes are no longer needed for internal logic,
# but we keep them available for backward compatibility if anyone imports from here.
from .elements import *  # noqa: F403


def _build_registry() -> Dict[str, Type[Element]]:
    """
    Dynamically builds the ROLE_TO_CLASS registry by inspecting the elements module.

    Logic:
    1. Scan all classes in `persona_dsl.pages.elements`.
    2. If class has a 'role' field with a default value, map role -> class.
    3. Register class name (lowercase) as alias if it doesn't conflict.
    """
    registry: Dict[str, Type[Element]] = {}

    for name, cls in inspect.getmembers(elements_module, inspect.isclass):
        # Must be subclass of Element, but not Element itself or Page
        if issubclass(cls, Element) and cls is not Element and cls is not Page:

            # 1. Extract Role
            role = None
            # Inspect dataclass fields for default value of 'role'
            for f in fields(cls):
                if f.name == "role":
                    if f.default != MISSING:
                        role = f.default
                    break

            # 2. Register Role
            if role:
                registry[str(role)] = cls

            # 3. Register Alias (Class Name Lowercase)
            # This handles cases like 'TextField' -> 'textfield', 'TableRow' -> 'tablerow'
            alias = cls.__name__.lower()
            if alias != role and alias not in registry:
                registry[alias] = cls

    return registry


ROLE_TO_CLASS: Dict[str, Type[Element]] = _build_registry()
