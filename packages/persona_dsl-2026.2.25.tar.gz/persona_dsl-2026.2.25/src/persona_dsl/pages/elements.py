from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Type, Iterator, Literal

from persona_dsl.utils.naming import to_snake_case


class Strategy(str, Enum):
    """Стратегии поиска элемента."""

    TEST_ID = "test_id"
    ROLE = "role"
    TEXT = "text"
    PLACEHOLDER = "placeholder"
    ALT_TEXT = "alt_text"
    TITLE = "title"
    LOCATOR = "locator"  # css/xpath
    REF = "ref"  # data-persona-id (Highest Priority with Runtime)
    LINK = "link"  # href
    ALL = "all"  # Использовать все доступные


@dataclass
class Element:
    """
    Базовый класс для элементов страницы с поддержкой Multi-Strategy Resolution и Hybrid Navigation.
    """

    name: str
    role: Optional[str] = None
    accessible_name: Optional[str] = None
    text: Optional[str | Any] = None
    label: Optional[str] = None
    placeholder: Optional[str] = None
    test_id: Optional[str] = None
    alt_text: Optional[str] = None
    title: Optional[str] = None
    locator: Optional[str] = None
    index: Optional[int] = None
    exact: bool = False
    description: Optional[str] = None
    static_screenshot_path: Optional[str] = None
    static_aria_snapshot_path: Optional[str] = None
    aria_ref: Optional[str] = None
    url: Optional[str] = None  # Для Strategy.LINK
    variants: Optional[List[Any] | Type[Enum]] = (
        None  # List of allowed values or Enum Class
    )
    Options: Optional[Type[Enum]] = None  # Dynamic Enum storage

    _filters: List[Dict[str, Any]] = field(default_factory=list, repr=False, init=False)
    # Список стратегий поиска (если None — используется стандартный приоритет)
    _strategies: Optional[List[Strategy]] = field(default=None, repr=False, init=False)
    parent: Optional["Element"] = field(default=None, repr=False, init=False)

    # Навигационные поля
    _nav_source: Optional["Element"] = field(default=None, repr=False, init=False)
    _nav_type: Optional[str] = field(
        default=None, repr=False, init=False
    )  # 'child', 'next', 'prev', 'parent'
    _nav_arg: Optional[Any] = field(default=None, repr=False, init=False)

    # Кэш для Smart Shortcuts
    _shortcut_cache: Dict[str, "Element"] = field(
        default_factory=dict, repr=False, init=False
    )

    def __post_init__(self) -> None:
        self._elements: Optional[Dict[str, Element | ElementList]] = None

        # UNI-ARGUMENT LOGIC:
        # 1. If 'text' is a list, treat it as 'variants'
        if isinstance(self.text, list) and not self.variants:
            self.variants = self.text
            self.text = None

        # 2. If 'variants' is a single value, treat it as 'text' BUT preserve it as list for Options
        if self.variants is not None and not isinstance(self.variants, (list, type)):
            if self.text is None:
                self.text = self.variants
            # Promote to list so Options logic (lines 98+) will generate Enum for it
            self.variants = [self.variants]

        # SMART VARIANTS LOGIC
        if self.variants:
            # Case 1: Enum Class passed
            if isinstance(self.variants, type) and issubclass(self.variants, Enum):
                self.Options = self.variants
                # Convert variants to list of values for validation
                try:
                    self.variants = [e.value for e in self.Options]
                except Exception:
                    # Fallback if Enum values issues
                    pass
            # Case 2: List passed -> Auto-Create Enum
            elif isinstance(self.variants, list) and len(self.variants) > 0:
                try:
                    enum_dict = {}
                    for val in self.variants:
                        # Auto-generate name: "Value One" -> "VALUE_ONE"
                        s_val = str(val)
                        name = to_snake_case(s_val).upper()

                        # Sanitize
                        name = re.sub(r"\W", "_", name)
                        if not name:
                            name = "VAL"
                        if name[0].isdigit():
                            name = f"OPT_{name}"

                        # Ensure uniqueness if collision? Enum handles duplicate values but not keys.
                        # We assume unique keys for now.
                        enum_dict[name] = val

                    # Create dynamic Enum
                    enum_name = (
                        f"{self.name.capitalize()}Options" if self.name else "Options"
                    )
                    self.Options = Enum(enum_name, enum_dict)  # type: ignore[misc]
                except Exception:
                    # Fallback (e.g. non-string values)
                    pass

        # validate variants
        if self.text is not None and self.variants is not None:
            # If text is an Enum member, comparison might work directly if variants has Enum members
            # If text is a string, check if it matches
            if self.text not in self.variants:
                # TODO: Add nicer error message with available options
                raise ValueError(
                    f"Invalid text value '{self.text}' for element '{self.name}'. "
                    f"Allowed variants: {self.variants}"
                )

    @property
    def is_container(self) -> bool:
        return self._elements is not None

    def using(self, strategies: List[Strategy]) -> "Element":
        """
        Возвращает копию элемента с заданным набором стратегий поиска.
        """
        new_element = copy.copy(self)
        new_element._strategies = strategies
        new_element._filters = list(self._filters)
        return new_element

    def robust(self) -> "Element":
        """Алиас для использования всех доступных стратегий (Strategy.ALL)."""
        return self.using([Strategy.ALL])

    def __call__(self, text: str | None = None, **kwargs: Any) -> "Element":
        """
        Возвращает ЭЛЕМЕНТ (не список), найденный по тексту.
        """
        return self.clone(text=text, **kwargs)

    def by_variant(self, value: Enum | str) -> "Element":
        """
        Семантичный способ получения конкретного варианта (Enum или строки) из заданных `variants`.
        Автоматически определяет тип элемента:
        - Для контейнеров опций (напр. combobox, listbox): возвращает вложенную опцию.
        - Для простых текстовых элементов: возвращает клонированный элемент с привязкой к варианту.
        """
        container_roles = ["combobox", "listbox", "radiogroup", "menu"]
        if self.role in container_roles or (
            self.name and "select" in self.name.lower()
        ):
            return self.get_option(value)
        text_value = str(value.value) if isinstance(value, Enum) else str(value)
        return self.clone(text=text_value)

    def get_option(self, value: Enum | str) -> "Element":
        """
        Stragegy to find an option within this element (container).
        Default implementation: Returns a dynamic Search Strategy for an option
        with the given text/value (accessible_name).

        Subclasses (like ListBox) can override this to provide more specific structure
        (e.g. if options are children).
        """
        text_value = str(value.value) if isinstance(value, Enum) else str(value)
        safe_name = to_snake_case(text_value)

        # Avoid circular imports by using string references or local imports if needed?
        # Option is defined in this file (usually).
        # But Element is defined before Option.
        # So we can't return Option(...) easily without forward ref or local import?
        # Option is defined later in file.
        # We can use a factory or local resolve?
        # Actually, python classes are defined sequentially.
        # We can implement it near end of file or just use Element(role="option", ...)

        # Better: Implementation in base class should be simple.
        # But Option class is defined at line 1389.
        # So we can't use Option() here.

        # We can inject it or use Element(role="option")
        el = Element(
            name=f"dynamic_option_{safe_name}",
            role="option",
            accessible_name=text_value,
        )
        el.parent = self
        return el

    def get_option_by_index(self, index: int) -> "Element":
        """
        Stragegy to find an option by index within this element (container).
        Default implementation: Returns a dynamic Search Strategy for an option
        at the specified index.
        """
        # We can inject it or use Element(role="option")
        el = Element(
            name=f"dynamic_option_index_{index}",
            role="option",
            index=index,
        )
        el.parent = self
        return el

    def clone(self, text: Optional[str] = None, **kwargs: Any) -> "Element":
        """
        Возвращает копию элемента с модифицированными атрибутами.
        """
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        for k, v in kwargs.items():
            if hasattr(new_element, k):
                setattr(new_element, k, v)

        if text is not None:
            # Handle Enum input for 'text'
            text_val = text.value if isinstance(text, Enum) else text

            # If role is 'text', we should set the 'text' attribute, not accessible_name
            # For other roles (like button, link), text argument usually implies accessible_name (label)
            if self.role == "text" or (not self.role) or self.role == "generic":
                new_element.text = text_val
            else:
                new_element.accessible_name = text_val

            # Validate against variants if they exist
            if new_element.variants and text_val not in new_element.variants:
                # Check if variants are Enum members and text matches value
                is_enum_match = False
                if isinstance(new_element.variants, list):
                    for v in new_element.variants:
                        v_val = v.value if isinstance(v, Enum) else v
                        if v_val == text_val:
                            is_enum_match = True
                            break

                if not is_enum_match:
                    raise ValueError(
                        f"Invalid text value '{text_val}' for element '{new_element.name}'. "
                        f"Allowed variants: {new_element.variants}"
                    )

        return new_element

    # --- Structural Navigation Methods ---

    def _create_nav_element(self, nav_type: str, arg: Any = None) -> "Element":
        """Создает новый элемент, привязанный к текущему через навигацию."""
        # Создаем generic элемент, так как мы не знаем роль цели заранее
        name_suffix = f"_{nav_type}"
        if arg is not None:
            name_suffix += f"_{arg}"

        new_el = Element(name=f"{self.name}{name_suffix}", role="generic")
        new_el.parent = self  # Важно для цепочки resolve
        new_el._nav_source = self
        new_el._nav_type = nav_type
        new_el._nav_arg = arg
        return new_el

    def child(self, index: int = 0) -> "Element":
        """Возвращает n-го ребенка элемента."""
        return self._create_nav_element("child", index)

    def first_child(self) -> "Element":
        """Возвращает первого ребенка."""
        return self.child(0)

    def last_child(self) -> "Element":
        """Возвращает последнего ребенка."""
        return self._create_nav_element("last_child")

    def next_sibling(self) -> "Element":
        """Возвращает следующий элемент на том же уровне."""
        return self._create_nav_element("next")

    def prev_sibling(self) -> "Element":
        """Возвращает предыдущий элемент на том же уровне."""
        return self._create_nav_element("prev")

    def parent_element(self) -> "Element":
        """Возвращает родительский элемент (DOM parent)."""
        return self._create_nav_element("parent")

    # --- Resolution Logic ---

    def _resolve_single_strategy(self, base: Any, strategy: Strategy) -> Any:
        """Строит локатор для одной конкретной стратегии."""
        if strategy == Strategy.REF and self.aria_ref:
            return base.locator(f'[data-persona-id="{self.aria_ref}"]')

        if strategy == Strategy.LINK and self.url:
            # Ищем ссылку с частичным совпадением href
            return base.locator(f'a[href*="{self.url}"]')

        if strategy == Strategy.TEST_ID and self.test_id:
            return base.get_by_test_id(self.test_id)

        if strategy == Strategy.ROLE and self.role:
            if self.accessible_name:
                return base.get_by_role(
                    self.role, name=self.accessible_name, exact=self.exact
                )
            return base.get_by_role(self.role, exact=self.exact)

        if strategy == Strategy.TEXT and self.text:
            return base.get_by_text(self.text, exact=self.exact)

        if strategy == Strategy.PLACEHOLDER and self.placeholder:
            return base.get_by_placeholder(self.placeholder, exact=self.exact)

        if strategy == Strategy.ALT_TEXT and self.alt_text:
            return base.get_by_alt_text(self.alt_text, exact=self.exact)

        if strategy == Strategy.TITLE and self.title:
            return base.get_by_title(self.title, exact=self.exact)

        if strategy == Strategy.LOCATOR and self.locator:
            return base.locator(self.locator)

        return None

    def _resolve_navigation_step(self, base: Any) -> Any:
        """
        Гибридный резолвер навигации.
        Пытается использовать Runtime JS, иначе падает в CSS/XPath.
        """
        page = base.page

        # 1. Hybrid Path: Try JS Runtime if parent has ref
        if self._nav_source and self._nav_source.aria_ref:
            # Проверяем наличие Runtime (быстрая проверка через evaluate handle или просто try/catch в JS)
            # Используем evaluate для атомарности
            js_script = """
                ([ref, type, arg]) => {
                    if (!window.__PERSONA__) return null;
                    const el = window.__PERSONA__.navigate(ref, type, arg);
                    return el ? el.getAttribute('data-persona-id') : null;
                }
            """
            try:
                target_id = page.evaluate(
                    js_script,
                    [self._nav_source.aria_ref, self._nav_type, self._nav_arg],
                )

                if target_id:
                    # Если JS нашел элемент и вернул ID -> строим прямой локатор
                    # Важно: ищем от корня страницы, так как ID уникален
                    return page.locator(f'[data-persona-id="{target_id}"]')
            except Exception:
                # Если JS упал или Runtime нет - игнорируем и идем в fallback
                pass

        # 2. Pure Path: CSS/XPath Fallback
        if self._nav_type == "child":
            # Playwright/CSS nth-child is 1-based
            # :scope > * выбирает всех детей
            return base.locator(":scope > *").nth(self._nav_arg)

        if self._nav_type == "last_child":
            return base.locator(":scope > *").last

        if self._nav_type == "next":
            return base.locator("xpath=following-sibling::*[1]")

        if self._nav_type == "prev":
            return base.locator("xpath=preceding-sibling::*[1]")

        if self._nav_type == "parent":
            return base.locator("xpath=..")

        raise ValueError(f"Unknown navigation type: {self._nav_type}")

    def _get_playwright_locator(self, base: Any) -> Any:
        """Получение локатора с поддержкой Multi-Strategy и Navigation."""

        # 0. Navigation Step
        if self._nav_type:
            return self._resolve_navigation_step(base)

        # 1. Сбор локаторов
        locators = []

        # Приоритет REF стратегии, если есть aria_ref (LCL-47)
        # Если стратегии не заданы явно, добавляем REF в начало списка приоритетов
        strategies_to_check = []

        if self._strategies:
            if Strategy.ALL in self._strategies:
                strategies_to_check = [
                    Strategy.REF,
                    Strategy.TEST_ID,
                    Strategy.ROLE,
                    Strategy.PLACEHOLDER,
                    Strategy.ALT_TEXT,
                    Strategy.TITLE,
                    Strategy.TEXT,
                    Strategy.LINK,
                    Strategy.LOCATOR,
                ]
            else:
                strategies_to_check = self._strategies
        else:
            # Стандартный приоритет
            # REF > TEST_ID > ROLE ...
            strategies_to_check = []
            if self.aria_ref:
                strategies_to_check.append(Strategy.REF)
            if self.test_id:
                strategies_to_check.append(Strategy.TEST_ID)
            if self.role:
                strategies_to_check.append(Strategy.ROLE)
            if self.label:
                # Label strategy is not in Enum yet, handled via get_by_label below if needed,
                # or we can add it. For now keeping legacy fallback logic structure if strategies not explicit.
                pass
            if self.placeholder:
                strategies_to_check.append(Strategy.PLACEHOLDER)
            if self.alt_text:
                strategies_to_check.append(Strategy.ALT_TEXT)
            if self.title:
                strategies_to_check.append(Strategy.TITLE)
            if self.text:
                strategies_to_check.append(Strategy.TEXT)
            if self.url:
                strategies_to_check.append(Strategy.LINK)
            if self.locator:
                strategies_to_check.append(Strategy.LOCATOR)

        # Если список стратегий сформирован (явный или неявный)
        if strategies_to_check:
            for strat in strategies_to_check:
                loc = self._resolve_single_strategy(base, strat)
                if loc is not None:
                    locators.append(loc)
        else:
            # Fallback для label (так как его нет в Strategy Enum пока) и дефолтов
            if self.label:
                locators.append(base.get_by_label(self.label, exact=self.exact))

            # Если совсем ничего нет
            if not locators:
                if self.parent is None:
                    return base
                raise ValueError(f"Элемент '{self.name}' не имеет стратегии поиска.")

        # 2. Объединение локаторов (OR)
        if not locators:
            raise ValueError(f"Element '{self.name}': не удалось построить локатор.")

        final_locator = locators[0]
        for loc in locators[1:]:
            final_locator = final_locator.or_(loc)

        # 3. Применение фильтров
        if hasattr(self, "_filters") and self._filters:
            for filter_kwargs in self._filters:
                f_kwargs = filter_kwargs.copy()
                if "has" in f_kwargs and isinstance(f_kwargs["has"], Element):
                    f_kwargs["has"] = f_kwargs["has"].resolve(final_locator.page)
                if "has_not" in f_kwargs and isinstance(f_kwargs["has_not"], Element):
                    f_kwargs["has_not"] = f_kwargs["has_not"].resolve(
                        final_locator.page
                    )
                final_locator = final_locator.filter(**f_kwargs)

        # 4. Индекс
        if self.index is not None:
            idx = self.index
            if idx < 0:
                total = final_locator.count()
                idx = total + idx
                # Note: Playwright nth() handles negatives? No, it throws if out of bounds usually or wraps?
                # Playwright nth() argument is 0-based index. Negative values like -1 mean last.
                # So we can pass negative directly to nth()!
                # But let's keep explicit logic if we want safety.
                # Actually playwright .nth(-1) works.
            final_locator = final_locator.nth(idx)

        return final_locator

    def resolve(self, page: Any) -> Any:
        """Вернуть Playwright Locator."""
        chain: List[Element] = [self]
        curr = self.parent
        while curr is not None:
            chain.append(curr)
            curr = curr.parent

        locator = page
        for element in reversed(chain):
            # Removed: if element.parent is None: continue
            # Logic handled in _get_playwright_locator (returns base if no strategy & parent is None)
            locator = element._get_playwright_locator(locator)

        return locator

    def resolve_or(self, page: Any, *alternatives: "Element") -> Any:
        """
        Построить локатор как OR от self и альтернативных элементов.
        """
        loc = self.resolve(page)
        for alt in alternatives:
            loc = loc.or_(alt.resolve(page))
        return loc

    def filter(
        self,
        has_text: Optional[str | Any] = None,
        has_not_text: Optional[str | Any] = None,
        has: Optional["Element" | Any] = None,
        has_not: Optional["Element" | Any] = None,
    ) -> "Element":
        new_element = copy.copy(self)
        new_element._filters = list(self._filters)

        filter_kwargs = {}
        if has_text is not None:
            filter_kwargs["has_text"] = has_text
        if has_not_text is not None:
            filter_kwargs["has_not_text"] = has_not_text
        if has is not None:
            filter_kwargs["has"] = has
        if has_not is not None:
            filter_kwargs["has_not"] = has_not

        if filter_kwargs:
            new_element._filters.append(filter_kwargs)

        return new_element

    # --- Container methods ---

    def add_element(
        self, element: "Element", *, alias: str | None = None, overwrite: bool = False
    ) -> "Element":
        if self._elements is None:
            self._elements = {}

        name = alias or element.name

        # Check for collision in current container ONLY (ignore nested via __getattr__)
        collision = False
        if not overwrite:
            # 1. Already in container map?
            if self._elements is not None and name in self._elements:
                collision = True
            # 2. Instance attribute? (e.g. self.foo = ...)
            elif name in self.__dict__:
                collision = True
            # 3. Class attribute/method? (e.g. def foo(self)...)
            elif hasattr(type(self), name):
                collision = True

        if collision:
            raise ValueError(
                f"Элемент/атрибут '{name}' уже существует в контейнере '{self.name}'"
            )

        element.parent = self
        self._elements[name] = element
        setattr(self, name, element)
        return element

    def add_element_list(
        self, prototype: "Element", *, alias: str | None = None, overwrite: bool = False
    ) -> "ElementList":
        if self._elements is None:
            self._elements = {}

        list_name = alias or f"{prototype.name}s"

        # Check for collision in current container ONLY
        collision = False
        if not overwrite:
            if self._elements is not None and list_name in self._elements:
                collision = True
            elif list_name in self.__dict__:
                collision = True
            elif hasattr(type(self), list_name):
                collision = True

        if collision:
            raise ValueError(
                f"Элемент/атрибут '{list_name}' уже существует в контейнере '{self.name}'"
            )

        el_list = ElementList(owner=self, prototype=prototype, name=list_name)
        self._elements[list_name] = el_list
        setattr(self, list_name, el_list)
        return el_list

    def get_element(self, name: str) -> "Element":
        if self._elements is None or name not in self._elements:
            raise AttributeError(
                f"Элемент '{name}' не найден в контейнере '{self.name}'"
            )
        el = self._elements[name]
        if isinstance(el, ElementList):
            raise AttributeError(
                f"'{name}' является коллекцией. Используйте индекс или вызов."
            )
        return el

    def _find_element_by_name_recursive(self, name: str) -> Optional["Element"]:
        """Рекурсивный поиск элемента по имени (Smart Shortcut)."""
        if not self._elements:
            return None

        for el in self._elements.values():
            if isinstance(el, Element):
                if el.name == name:
                    return el
                # Recurse
                found = el._find_element_by_name_recursive(name)
                # FIX: Explicit check for None because Element might be Falsy if empty (calls __len__)
                if found is not None:
                    return found
        return None

    def __getattr__(self, name: str) -> "Element":
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

        # 1. Try direct child
        try:
            return self.get_element(name)
        except AttributeError:
            pass

        # 2. Check cache
        if name in self._shortcut_cache:
            return self._shortcut_cache[name]

        # 3. Recursive search (Smart Shortcut)
        found = self._find_element_by_name_recursive(name)
        if found is not None:
            self._shortcut_cache[name] = found
            return found

        raise AttributeError(
            f"Element '{name}' not found in '{self.name}' or its descendants."
        )

    def _children_in_order(self) -> List["Element"]:
        if not self._elements:
            return []
        items: List[Element] = []
        for v in self._elements.values():
            if isinstance(v, Element):
                items.append(v)
        return items

    def __len__(self) -> int:
        return len(self._children_in_order())

    def __iter__(self) -> Iterator["Element"]:
        yield from self._children_in_order()

    def __getitem__(self, key: int | str) -> "Element":
        if isinstance(key, int):
            children = self._children_in_order()
            try:
                return children[key]
            except IndexError:
                raise IndexError(f"Index {key} out of range")
        if isinstance(key, str):
            # Support dict-like access via shortcuts too?
            # Usually __getitem__ string access is direct.
            # But let's use getattr logic to be consistent with shortcuts.
            return getattr(self, key)
        raise TypeError("Index must be int or str")


class ElementList:
    """Коллекция однотипных элементов."""

    def __init__(self, owner: Element, prototype: Element, name: str) -> None:
        self._owner = owner
        self._prototype = prototype
        self.name = name
        self._prototype.parent = owner

    def __call__(self, text: str | None = None, **kwargs: Any) -> Element:
        """
        Возвращает ЭЛЕМЕНТ (не список), найденный по тексту.
        """
        item = self._make_item(None)  # index=None -> ищем среди всех

        if text:
            item = item.filter(has_text=text)

        return item

    def _make_item(self, index: int | None) -> Element:
        cls: Type[Element] = type(self._prototype)

        # Get field definitions to check init=False
        from dataclasses import fields

        cls_fields = {f.name: f for f in fields(cls)}

        kwargs = {
            "name": (
                f"{self._prototype.name}_{index}"
                if index is not None
                else self._prototype.name
            ),
            "accessible_name": self._prototype.accessible_name,
            "locator": self._prototype.locator,
            "index": index,
            "exact": self._prototype.exact,
            "description": self._prototype.description,
            "static_screenshot_path": self._prototype.static_screenshot_path,
            "static_aria_snapshot_path": self._prototype.static_aria_snapshot_path,
            "aria_ref": self._prototype.aria_ref,
            "test_id": self._prototype.test_id,
            "placeholder": self._prototype.placeholder,
            "text": self._prototype.text,
            "role": self._prototype.role,
            "url": self._prototype.url,
        }

        # Filter out fields that have init=False in the target class
        filtered_kwargs = {
            k: v for k, v in kwargs.items() if k not in cls_fields or cls_fields[k].init
        }

        item = cls(**filtered_kwargs)  # type: ignore[arg-type]
        item.parent = self._owner
        if self._prototype._strategies:
            item._strategies = list(self._prototype._strategies)

        # FIX: Copy filters from prototype!
        if hasattr(self._prototype, "_filters") and self._prototype._filters:
            item._filters = list(self._prototype._filters)

        return item

    def __getitem__(self, index: int) -> Element:
        if not isinstance(index, int):
            raise IndexError("Index must be int")
        return self._make_item(index)

    def get(self, index: int) -> Element:
        return self.__getitem__(index)

    def first(self) -> Element:
        return self._make_item(0)

    def last(self) -> Element:
        return self._make_item(-1)

    def nth(self, index: int) -> Element:
        return self.__getitem__(index)

    def with_text(self, text: str, *, exact: bool = True) -> Element:
        item = self._make_item(None)
        return item.filter(has_text=text)

    def filter(
        self,
        has_text: Optional[str | Any] = None,
        has_not_text: Optional[str | Any] = None,
        has: Optional["Element" | Any] = None,
        has_not: Optional["Element" | Any] = None,
    ) -> ElementList:
        new_prototype = self._prototype.filter(
            has_text=has_text, has_not_text=has_not_text, has=has, has_not=has_not
        )
        return ElementList(owner=self._owner, prototype=new_prototype, name=self.name)

    def resolve_all(self, page: Any) -> List[Any]:
        """
        Resolves the list definition to a list of Playwright Locators.
        """
        # Create a generic item representing the collection strategy
        collection_item = self._make_item(None)
        # Resolve it to get the base locator (e.g. matching all rows)
        base_locator = collection_item.resolve(page)
        # Return all matching locators
        return base_locator.all()


# --- Примитивные элементы ---


@dataclass
class Button(Element):
    role: str = field(default="button", init=False)


@dataclass
class TextField(Element):
    role: str = field(default="textbox", init=False)


@dataclass
class Link(Element):
    role: str = field(default="link", init=False)


@dataclass
class Checkbox(Element):
    role: str = field(default="checkbox", init=False)


@dataclass
class Radio(Element):
    role: str = field(default="radio", init=False)


@dataclass
class Heading(Element):
    role: str = field(default="heading", init=False)


@dataclass
class Paragraph(Element):
    role: str = field(default="paragraph", init=False)


@dataclass
class Strong(Element):
    role: str = field(default="strong", init=False)


@dataclass
class ListElement(Element):
    role: str = field(default="list", init=False)


@dataclass
class ListItem(Element):
    role: str = field(default="listitem", init=False)


@dataclass
class TableRow(Element):
    role: str = field(default="row", init=False)
    _where_criteria: dict[str, str] | None = field(default=None, repr=False, init=False)

    def _get_playwright_locator(self, base: Any) -> Any:
        # Если это навигационный элемент, используем базовую логику
        if self._nav_type:
            return super()._get_playwright_locator(base)

        locator = super()._get_playwright_locator(base)
        if not self._where_criteria:
            return locator

        header_locs = base.locator("th, [role=columnheader]").all()
        # Clean up whitespace and newlines for robust matching
        headers = [
            " ".join((h.text_content() or "").strip().split()) for h in header_locs
        ]

        if not headers:
            # Если нет заголовков, но есть where - пытаемся искать прямо в строке по тексту (Fallback)
            filtered = locator
            for col_name, value in (self._where_criteria or {}).items():
                val_str = value.value if isinstance(value, Enum) else str(value)
                filtered = filtered.filter(has_text=val_str)
            return filtered

        filtered = locator
        for col_name, value in (self._where_criteria or {}).items():
            # Resolve Enum to string
            col_str = col_name.value if isinstance(col_name, Enum) else str(col_name)
            val_str = value.value if isinstance(value, Enum) else str(value)

            # Find closest match if exact match fails
            col_index = -1
            for i, h in enumerate(headers):
                if h == col_str or col_str.lower() in h.lower():
                    col_index = i
                    break

            if col_index == -1:
                # Fallback: Just look anywhere in the row
                filtered = filtered.filter(has_text=val_str)
                continue

            # Используем XPath с position() для выбора конкретной ячейки ВНУТРИ строки.
            # Индексация XPath начинается с 1. Передаем этот локатор в has=.
            cell_xpath = f"./*[self::td or @role='cell' or self::th or @role='rowheader'][{col_index + 1}]"
            cell_in_row = base.page.locator(f"xpath={cell_xpath}").filter(
                has_text=val_str
            )
            filtered = filtered.filter(has=cell_in_row)
        return filtered

    def cell(self, column: int | str | Enum) -> "TableCell":
        # Resolve enum to string if necessary
        col_str = column.value if isinstance(column, Enum) else str(column)

        if isinstance(column, int):
            item = TableCell(name=f"cell_{column}", accessible_name="", index=column)
        else:
            item = TableCell(name="cell", accessible_name="", column_header=col_str)
        item.parent = self
        return item


@dataclass
class Table(Element):
    role: str = field(default="table", init=False)
    columns: type[Enum] | None = field(default=None, kw_only=True)
    row_type: type["TableRow"] = field(default=TableRow, kw_only=True)

    def rows(self) -> ElementList:
        if hasattr(self, "rows") and isinstance(getattr(self, "rows"), ElementList):
            return getattr(self, "rows")

        # Priority: 1. Nested Row class, 2. row_type kwarg, 3. Default TableRow
        row_cls = getattr(self, "Row", self.row_type)
        prototype = row_cls(name="row", accessible_name="")

        return self.add_element_list(prototype, alias="rows", overwrite=True)

    def body_rows(self) -> ElementList:
        """
        Возвращает список строк, исключая заголовок (thead).
        Использует фильтрацию по отсутствию предка thead.
        """
        if hasattr(self, "body_rows_list") and isinstance(
            getattr(self, "body_rows_list"), ElementList
        ):
            return getattr(self, "body_rows_list")

        row_cls = getattr(self, "Row", self.row_type)
        prototype = row_cls(name="row", accessible_name="")

        # Override strategy to use restrictive XPath
        # We target rows that are NOT inside a thead.
        # XPath: .//*[self::tr or @role="row"][not(ancestor::thead)]
        prototype.role = None  # Disable role strategy
        prototype.locator = 'xpath=.//*[self::tr or @role="row"][not(ancestor::thead)]'

        # Force LOCATOR strategy
        prototype._strategies = [Strategy.LOCATOR]

        return self.add_element_list(prototype, alias="body_rows", overwrite=True)

    def row(
        self, index: int | None = None, *, where: dict[str, str] | None = None
    ) -> "TableRow":
        # Priority: 1. Nested Row class, 2. row_type kwarg, 3. Default TableRow
        row_cls = getattr(self, "Row", self.row_type)

        if index is not None and where is None:
            item = row_cls(name=f"row_{index}", accessible_name="", index=index)
            item.parent = self
            return item
        if where is not None and index is None:
            item = row_cls(name="row_where", accessible_name="")
            setattr(item, "_where_criteria", where)
            item.parent = self
            return item

        raise ValueError("Must specify either index or where")

    def header(self, index: int | str | Enum) -> "ColumnHeader":
        col_str = index.value if isinstance(index, Enum) else str(index)
        if isinstance(index, int):
            item = ColumnHeader(name=f"header_{index}", accessible_name="", index=index)
        else:
            item = ColumnHeader(name=f"header_{col_str}", accessible_name=col_str)
        item.parent = self
        return item

    def headers(self) -> ElementList:
        if hasattr(self, "headers_list") and isinstance(
            getattr(self, "headers_list"), ElementList
        ):
            return getattr(self, "headers_list")

        prototype = ColumnHeader(name="header", accessible_name="")
        return self.add_element_list(prototype, alias="headers", overwrite=True)

    def cell(self, row_index: int, column_index: int) -> "TableCell":
        row_el = self.row(index=row_index)
        cell_el = TableCell(
            name=f"cell_{row_index}_{column_index}",
            accessible_name="",
            index=column_index,
        )
        cell_el.parent = row_el
        return cell_el

    def get_all_data(self, page: Any) -> list[dict[str, str]]:
        """
        Извлекает данные из таблицы в виде списка словарей.
        Типизация для mypy (реализация может быть инжектирована или находиться здесь).
        """
        # Эта реализация будет переопределена или используется динамически
        raise NotImplementedError("Make sure get_all_data is implemented.")

    def get_column_data(self, page: Any, column: Any) -> list[str]:
        """
        Извлекает данные конкретной колонки в виде списка строк.
        """
        raise NotImplementedError("Make sure get_column_data is implemented.")

    def scroll(
        self,
        page: Any,
        direction: Literal["right", "left", "bottom", "top"] = "bottom",
        amount: int | str | None = None,
    ) -> None:
        """
        Скроллит таблицу в заданном направлении.
        """
        raise NotImplementedError("Make sure scroll is implemented.")


@dataclass
class ListBox(Element):
    role: str = field(default="listbox", init=False)
    options_enum: Optional[Type[Enum]] = None

    def get_option(self, value: Enum | str) -> "Element":
        """
        Retrieves an Option element by its Enum value or string text.
        Dynamic lookup: does not require pre-generated child fields.
        """
        text_value = str(value.value) if isinstance(value, Enum) else str(value)

        # 1. Create Option Element
        # We assume the option is a child of the listbox (standard ARIA)
        opt = Option(
            name=f"option_{to_snake_case(text_value)}", accessible_name=text_value
        )
        opt.parent = self
        return opt

    def select_option(
        self,
        page: Any,
        value: Optional[str | Enum] = None,
        label: Optional[str | Enum] = None,
        index: Optional[int] = None,
        force: bool = False,
        **kwargs: Any,
    ) -> None:
        """
        Selects an option within the ListBox.
        """
        # Determine target text/value
        target_val = value or label
        if isinstance(target_val, Enum):
            target_val = str(target_val.value)

        target_option: Element | None = None

        if target_val:
            target_option = self.get_option(target_val)
        elif index is not None:
            # Resolve self to get locator, then nth child option
            # This requires constructing a locator-based Element
            # Or resolving options collection
            pass

        if target_option:
            # Resolve and Click
            loc = target_option.resolve(page)
            # Ensure visible
            loc.scroll_into_view_if_needed()
            loc.click(force=force)
            return

        raise ValueError(
            "ListBox: Could not select option. Specify value/label (index not fully supported yet)."
        )


@dataclass
class Slider(Element):
    role: str = field(default="slider", init=False)


@dataclass
class ProgressBar(Element):
    role: str = field(default="progressbar", init=False)


@dataclass
class SearchBox(Element):
    role: str = field(default="searchbox", init=False)


@dataclass
class SpinButton(Element):
    role: str = field(default="spinbutton", init=False)


@dataclass
class Switch(Element):
    role: str = field(default="switch", init=False)


@dataclass
class Code(Element):
    role: str = field(default="code", init=False)


@dataclass
@dataclass
class BlockQuote(Element):
    role: str = field(default="blockquote", init=False)


@dataclass
class TableCell(Element):
    role: str = field(default="cell", init=False)
    column_header: Optional[str] = None

    def _get_playwright_locator(self, base: Any) -> Any:
        if self.column_header:
            # Robust Dynamic XPath:
            # 1. Find ancestor table.
            # 2. Find header with matching text.
            # 3. Count preceding headers to determine index.
            # 4. Select cell at that index (1-based because XPath).

            # Safe quote handling for XPath
            text = self.column_header
            if '"' in text and "'" in text:
                # Concat fallback if mixed quotes
                # Simple version: assume single quotes generally safe or use normalize-space
                # For simplicity here assuming header doesn't have complex mixed quotes usually.
                escaped = f'"{text}"'  # Default wrap in double
            elif '"' in text:
                escaped = f"'{text}'"
            else:
                escaped = f'"{text}"'

            # Note: aria-level or roles might vary (th vs [role=columnheader])
            # We target standard structure.
            # xpath=td[...] or [role=cell][...]
            # position() matching is cleaner than count() sum if simplified.

            # Strategy: "Select the cell whose position matches the position of the header with text X"
            # (Old implementation removed due to F841 unused variable)

            # Optimised XPath:
            # Use existing relative index logic?
            # Let's try simpler:
            # position() = count(header/preceding-sibling::header) + 1

            # Correct XPath pattern for "Cell corresponding to Header X":
            xpath_expr = (
                f"./*[self::td or @role='cell']"
                f"["
                f"count("
                f"ancestor::*[self::table or @role='grid'][1]"
                f"//*[self::th or @role='columnheader'][normalize-space(.)={escaped}]"
                f"/preceding-sibling::*[self::th or @role='columnheader']"
                f") + 1"
                f"]"
            )
            return base.locator(f"xpath={xpath_expr}")

        return super()._get_playwright_locator(base)


@dataclass
class ColumnHeader(Element):
    role: str = field(default="columnheader", init=False)


@dataclass
class RowHeader(Element):
    role: str = field(default="rowheader", init=False)


@dataclass
class Grid(Element):
    role: str = field(default="grid", init=False)


@dataclass
class GridCell(Element):
    role: str = field(default="gridcell", init=False)


@dataclass
class Navigation(Element):
    role: str = field(default="navigation", init=False)


@dataclass
class Main(Element):
    role: str = field(default="main", init=False)


@dataclass
class Banner(Element):
    role: str = field(default="banner", init=False)


@dataclass
class ContentInfo(Element):
    role: str = field(default="contentinfo", init=False)


@dataclass
class Region(Element):
    role: str = field(default="region", init=False)


@dataclass
class Search(Element):
    role: str = field(default="search", init=False)


@dataclass
class Complementary(Element):
    role: str = field(default="complementary", init=False)


@dataclass
class Article(Element):
    role: str = field(default="article", init=False)


@dataclass
class Image(Element):
    role: str = field(default="img", init=False)


@dataclass
class Figure(Element):
    role: str = field(default="figure", init=False)


@dataclass
class Form(Element):
    role: str = field(default="form", init=False)


@dataclass
class Group(Element):
    role: str = field(default="group", init=False)


@dataclass
class RadioGroup(Element):
    role: str = field(default="radiogroup", init=False)


@dataclass
class Dialog(Element):
    role: str = field(default="dialog", init=False)


@dataclass
class AlertDialog(Element):
    role: str = field(default="alertdialog", init=False)


@dataclass
class Alert(Element):
    role: str = field(default="alert", init=False)


@dataclass
class Status(Element):
    role: str = field(default="status", init=False)


@dataclass
class Log(Element):
    role: str = field(default="log", init=False)


@dataclass
class Timer(Element):
    role: str = field(default="timer", init=False)


@dataclass
class Menu(Element):
    role: str = field(default="menu", init=False)


@dataclass
class MenuBar(Element):
    role: str = field(default="menubar", init=False)


@dataclass
class MenuItem(Element):
    role: str = field(default="menuitem", init=False)


@dataclass
class MenuItemCheckbox(Element):
    role: str = field(default="menuitemcheckbox", init=False)


@dataclass
class MenuItemRadio(Element):
    role: str = field(default="menuitemradio", init=False)


@dataclass
class TabList(Element):
    role: str = field(default="tablist", init=False)


@dataclass
class Tab(Element):
    role: str = field(default="tab", init=False)


@dataclass
class TabPanel(Element):
    role: str = field(default="tabpanel", init=False)


@dataclass
class Tree(Element):
    role: str = field(default="tree", init=False)


@dataclass
class TreeItem(Element):
    role: str = field(default="treeitem", init=False)


@dataclass
class Meter(Element):
    role: str = field(default="meter", init=False)


@dataclass
class ScrollBar(Element):
    role: str = field(default="scrollbar", init=False)


@dataclass
class Separator(Element):
    role: str = field(default="separator", init=False)


@dataclass
class Toolbar(Element):
    role: str = field(default="toolbar", init=False)


@dataclass
class Tooltip(Element):
    role: str = field(default="tooltip", init=False)


@dataclass
class Caption(Element):
    role: str = field(default="caption", init=False)


@dataclass
class Definition(Element):
    role: str = field(default="definition", init=False)


@dataclass
class Deletion(Element):
    role: str = field(default="deletion", init=False)


@dataclass
class Directory(Element):
    role: str = field(default="directory", init=False)


@dataclass
class Document(Element):
    role: str = field(default="document", init=False)


@dataclass
class Emphasis(Element):
    role: str = field(default="emphasis", init=False)


@dataclass
class Feed(Element):
    role: str = field(default="feed", init=False)


@dataclass
class Generic(Element):
    role: str = field(default="generic", init=False)


@dataclass
class Marquee(Element):
    role: str = field(default="marquee", init=False)


@dataclass
class Math(Element):
    role: str = field(default="math", init=False)


@dataclass
class Text(Element):
    """
    Element strictly identified by text.
    Requires 'text' to be set during initialization.
    """

    role: str = field(default="text", init=False)

    def __post_init__(self) -> None:
        super().__post_init__()
        # Allow missing text IF variants/Options are provided (acting as a generic text container)
        if not self.text and not getattr(self, "Options", None) and not self.variants:
            raise ValueError(
                f"Text element '{self.name}' must have 'text' attribute set or 'variants' provided."
            )


@dataclass
class NoneElement(Element):
    role: str = field(default="none", init=False)


@dataclass
class Select(Element):
    """
    Standard HTML <select> element.
    """

    role: str = field(default="combobox", init=False)
    options_enum: Optional[Type[Enum]] = None  # Optional Enum for fixed values

    def select_option(
        self,
        page: Any,
        value: Optional[str | Enum] = None,
        label: Optional[str | Enum] = None,
        index: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        locator = self.resolve(page)

        # Resolve Enum values
        if isinstance(value, Enum):
            value = value.value
        if isinstance(label, Enum):
            # For label, we might want the name or value depending on convention.
            # Usually label implies the visible text.
            # If Enum value is the text, use value.
            label = str(label.value)

        select_kwargs: Dict[str, Any] = {}
        if value is not None:
            select_kwargs["value"] = value
        if label is not None:
            select_kwargs["label"] = label
        if index is not None:
            select_kwargs["index"] = index

        locator.select_option(**select_kwargs, **kwargs)


@dataclass
class Dropdown(Element):
    """
    Custom Dropdown component (Trigger + Options List).
    Assumes interaction: Click Trigger -> Click Option.
    """

    role: str = field(default="combobox", init=False)
    options_enum: Optional[Type[Enum]] = None

    def select_option(
        self,
        page: Any,
        value: Optional[str | Enum] = None,
        label: Optional[str | Enum] = None,
        index: Optional[int] = None,
        **kwargs: Any,
    ) -> None:
        # Resolve Enums
        if isinstance(value, Enum):
            value = str(value.value)
        if isinstance(label, Enum):
            # If the Enum value IS the label (common), use it.
            # If the Enum name is the label, use .name.
            # We assume value for now as standard.
            label = str(label.value)

        target_val = value if value is not None else label

        # 1. Resolve element and Check mechanism
        element = self.resolve(page)

        # Check if it is a native <select>
        try:
            tag_name = element.evaluate("el => el.tagName", timeout=500).lower()
        except Exception:
            tag_name = "unknown"

        if tag_name == "select":
            # Native Select: Use Playwright's optimized select_option
            select_kwargs: Dict[str, Any] = {}
            if value:
                select_kwargs["value"] = value
            if label:
                select_kwargs["label"] = label
            if index is not None:
                select_kwargs["index"] = index

            element.select_option(**select_kwargs, **kwargs)
            return

        # Custom Dropdown Logic
        trigger = element
        trigger.scroll_into_view_if_needed()

        force = kwargs.get("force", False)
        trigger.click(force=force)

        # Wait slightly for animation/portal mounting if needed?
        # Playwright usually handles this, but for some JS frameworks a small tick helps.
        # page.wait_for_timeout(100)

        if target_val:
            # 2. Select the option using Element Resolution
            # Create a temporary Option element for searching.
            # If we don't set parent, it resolves globally (fine for portals/roots).
            # But we can try to find it via specific role/name.

            # Primary Strategy: Role=option, Name=Target
            target_option = Option(name="temp_option", accessible_name=target_val)

            # Resolve it
            # If resolution fails (which it shouldn't for creation, but check count)
            opt_loc = target_option.resolve(page)

        elif index is not None:
            # Index strategy via global option role (or scoped if we had a parent)
            # Since Dropdown often uses portals, global option role index *might* be risky if multiple open.
            # But without a specific container locator, it's the best we have.
            # We assume only one dropdown active.
            target_option = Option(name=f"option_index_{index}", index=index)
            opt_loc = target_option.resolve(page)

        if target_option and opt_loc.count() > 0:
            # We found it!
            # Use the ELEMENT's resolve logic (which we did manually above to check count)
            # But to be clean we just use the locator we got.
            opt_loc.scroll_into_view_if_needed()
            opt_loc.click(force=force)
            return

        raise ValueError(
            f"Dropdown: Could not find option with label/value='{target_val}' or index='{index}'"
        )


@dataclass
class Note(Element):
    role: str = field(default="note", init=False)


@dataclass
class Option(Element):
    role: str = field(default="option", init=False)


@dataclass
class Presentation(Element):
    role: str = field(default="presentation", init=False)


@dataclass
class RowGroup(Element):
    role: str = field(default="rowgroup", init=False)


@dataclass
class Term(Element):
    role: str = field(default="term", init=False)


# Alias ComboBox to Dropdown to use Enhanced Logic
ComboBox = Dropdown
