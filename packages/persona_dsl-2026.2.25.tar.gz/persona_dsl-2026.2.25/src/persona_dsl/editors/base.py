import libcst as cst
from typing import Any, Dict, Optional, List, Set, Union, cast, Sequence

try:
    import black

    HAS_BLACK = True
except ImportError:
    HAS_BLACK = False


class CodeEditor:
    """
    A unified utility for performing non-destructive code modifications using LibCST.
    """

    def __init__(self, code: str):
        self.module = cst.parse_module(code)

    def get_code(self, use_black: bool = True) -> str:
        code = self.module.code
        if use_black and HAS_BLACK:
            try:
                # Use default mode
                return black.format_str(code, mode=black.Mode())
            except Exception:
                # If formatting fails (e.g. syntax error in intermediate code), return as is
                return code
        return code

    def update_class_attributes(
        self, class_name: str, attributes: Dict[str, str]
    ) -> "CodeEditor":
        """
        Updates or adds class-level string attributes (e.g. url = "...")
        """

        class AttributeUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, attrs: Dict[str, str]):
                self.target_class = target_class
                self.attrs = attrs
                self.found_class = False
                self.handled_attrs: Set[str] = set()

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if not self.found_class:
                    return updated_node

                new_body_stmts: List[cst.BaseStatement] = []
                # 1. Update existing
                current_body = cast(Sequence[cst.BaseStatement], updated_node.body.body)
                for stmt in current_body:
                    if isinstance(stmt, cst.SimpleStatementLine):
                        if isinstance(stmt.body[0], cst.Assign):
                            assign: cst.Assign = stmt.body[0]
                            replaced = False
                            for target in assign.targets:
                                if (
                                    isinstance(target.target, cst.Name)
                                    and target.target.value in self.attrs
                                ):
                                    attr_name = target.target.value
                                    new_val = self.attrs[attr_name]
                                    self.handled_attrs.add(attr_name)
                                    new_assign = assign.with_changes(
                                        value=cst.SimpleString(f'"{new_val}"')
                                    )
                                    new_body_stmts.append(
                                        stmt.with_changes(body=[new_assign])
                                    )
                                    replaced = True
                                    break
                            if replaced:
                                continue
                    new_body_stmts.append(stmt)

                # 2. Insert missing
                to_insert: List[cst.SimpleStatementLine] = []
                for attr, val in self.attrs.items():
                    if attr not in self.handled_attrs and val:
                        assign_stmt = cst.SimpleStatementLine(
                            body=[
                                cst.Assign(
                                    targets=[cst.AssignTarget(target=cst.Name(attr))],
                                    value=cst.SimpleString(f'"{val}"'),
                                )
                            ]
                        )
                        to_insert.append(assign_stmt)

                if to_insert:
                    insert_idx = 0
                    if (
                        new_body_stmts
                        and isinstance(new_body_stmts[0], cst.SimpleStatementLine)
                        and isinstance(new_body_stmts[0].body[0], cst.Expr)
                        and isinstance(
                            new_body_stmts[0].body[0].value, cst.SimpleString
                        )
                    ):
                        insert_idx = 1

                    for item in reversed(to_insert):
                        new_body_stmts.insert(insert_idx, item)

                self.found_class = False
                return updated_node.with_changes(
                    body=cst.IndentedBlock(
                        body=cast(Sequence[cst.BaseStatement], new_body_stmts)
                    )
                )

        transformer = AttributeUpdater(class_name, attributes)
        self.module = self.module.visit(transformer)
        return self

    def replace_method(
        self, class_name: str, method_node: cst.FunctionDef
    ) -> "CodeEditor":
        """
        Replaces a method in a class with a new CST definition.
        If the method doesn't exist, it appends it (after __init__ or at start).
        """

        class MethodReplacer(cst.CSTTransformer):
            def __init__(self, target_class: str, new_method: cst.FunctionDef):
                self.target_class = target_class
                self.new_method = new_method
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    target_name = self.new_method.name.value

                    new_body_stmts: List[cst.BaseStatement] = []
                    replaced = False

                    current_body = cast(
                        Sequence[cst.BaseStatement], updated_node.body.body
                    )
                    for stmt in current_body:
                        if (
                            isinstance(stmt, cst.FunctionDef)
                            and stmt.name.value == target_name
                        ):
                            new_body_stmts.append(self.new_method)
                            replaced = True
                        else:
                            new_body_stmts.append(stmt)

                    if not replaced:
                        # Insert strategy:
                        # If __init__ exists, insert after it?
                        # Or just at the top?
                        # Let's insert at the top (after docstring) for simplicity, or strict append?
                        # Generator usually puts __init__ first.
                        # If replacing __init__, we handled it.
                        # If adding new method, maybe append?

                        # Logic: if __init__ is the target, we likely inserted it.
                        # If it's a random method, append to end.
                        if target_name == "__init__":
                            idx = 0
                            if (
                                new_body_stmts
                                and isinstance(
                                    new_body_stmts[0], cst.SimpleStatementLine
                                )
                                and isinstance(new_body_stmts[0].body[0], cst.Expr)
                                and isinstance(
                                    new_body_stmts[0].body[0].value, cst.SimpleString
                                )
                            ):
                                idx = 1
                            new_body_stmts.insert(idx, self.new_method)
                        else:
                            new_body_stmts.append(self.new_method)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(
                            body=cast(Sequence[cst.BaseStatement], new_body_stmts)
                        )
                    )
                return updated_node

        transformer = MethodReplacer(class_name, method_node)
        self.module = self.module.visit(transformer)
        return self

        return self

    def update_class_docstring(self, class_name: str, docstring: str) -> "CodeEditor":
        """
        Updates or adds a docstring to the specified class.
        """

        class DocstringUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, new_doc: str):
                self.target_class = target_class
                self.new_doc = new_doc
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    # Create docstring statement
                    doc_stmt = cst.SimpleStatementLine(
                        [cst.Expr(value=cst.SimpleString(repr(self.new_doc)))]
                    )

                    current_body = cast(
                        Sequence[cst.BaseStatement], updated_node.body.body
                    )
                    new_body: List[cst.BaseStatement] = list(current_body)

                    # Check if first statement is a docstring
                    if (
                        new_body
                        and isinstance(new_body[0], cst.SimpleStatementLine)
                        and new_body[0].body
                        and isinstance(new_body[0].body[0], cst.Expr)
                        and isinstance(new_body[0].body[0].value, cst.SimpleString)
                    ):
                        new_body[0] = doc_stmt
                    else:
                        new_body.insert(0, doc_stmt)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body)
                    )
                return updated_node

        transformer = DocstringUpdater(class_name, docstring)
        self.module = self.module.visit(transformer)
        return self

    def merge_init_from_other_code(
        self, source_code: str, class_name: str
    ) -> "CodeEditor":
        """
        Extracts __init__ method and imports from source_code and applies them to the current module.
        """
        other_module = cst.parse_module(source_code)

        # 1. Extract new __init__ and imports
        class NewCodeExtractor(cst.CSTVisitor):
            def __init__(self, target_class: str):
                self.target_class = target_class
                self.found_init: Optional[cst.FunctionDef] = None
                self.collected_imports: List[Union[cst.Import, cst.ImportFrom]] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    for body_item in node.body.body:
                        if (
                            isinstance(body_item, cst.FunctionDef)
                            and body_item.name.value == "__init__"
                        ):
                            self.found_init = body_item
                    return False
                return False

            def visit_Import(self, node: cst.Import) -> None:
                self.collected_imports.append(node)

            def visit_ImportFrom(self, node: cst.ImportFrom) -> None:
                self.collected_imports.append(node)

        extractor = NewCodeExtractor(class_name)
        other_module.visit(extractor)

        if not extractor.found_init:
            return self

        # 2. Add imports
        # Convert imports back to strings for add_imports which handles deduplication
        import_strings = []
        for imp in extractor.collected_imports:
            import_strings.append(
                cst.Module(body=[cst.SimpleStatementLine(body=[imp])]).code.strip()
            )

        self.add_imports(import_strings)

        # 3. Replace __init__
        self.replace_method(class_name, extractor.found_init)

        return self

    def merge_all_classes_from_other_code(self, source_code: str) -> "CodeEditor":
        """
        Merges ALL classes from source_code into the current module.
        - If class exists: updates its __init__.
        - If class is new: appends it to the module.
        - Merges imports.
        """
        other_module = cst.parse_module(source_code)

        # 1. Collect all classes and imports from source
        class MultiClassExtractor(cst.CSTVisitor):
            def __init__(self) -> None:
                self.classes: Dict[str, cst.ClassDef] = {}
                self.imports: List[str] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                self.classes[node.name.value] = node
                return False  # Don't recurse into nested classes

            def visit_Import(self, node: cst.Import) -> Optional[bool]:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

            def visit_ImportFrom(self, node: cst.ImportFrom) -> Optional[bool]:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

        extractor = MultiClassExtractor()
        other_module.visit(extractor)

        # 2. Add imports
        self.add_imports(extractor.imports)

        # 3. Process Classes
        for cls_name, cls_node in extractor.classes.items():
            # Check existence freshly
            exists = False
            for stmt in self.module.body:
                if isinstance(stmt, cst.ClassDef) and stmt.name.value == cls_name:
                    exists = True
                    break

            if exists:
                # Update __init__
                new_init = None
                for body_item in cls_node.body.body:
                    if (
                        isinstance(body_item, cst.FunctionDef)
                        and body_item.name.value == "__init__"
                    ):
                        new_init = body_item
                        break
                if new_init:
                    self.replace_method(cls_name, new_init)
            else:
                # Append new class
                new_body = list(self.module.body)
                new_body.append(cls_node)
                self.module = self.module.with_changes(body=new_body)

        return self

    def add_imports(self, imports: List[str]) -> "CodeEditor":
        """
        Adds import statements if they are not already present.
        Input strings should be full statements like "from foo import bar".
        """
        # Parse new imports to CST
        new_import_nodes = []
        for imp_str in imports:
            try:
                # Wrap in simple statement to parse
                mod = cst.parse_module(imp_str)
                if mod.body:
                    new_import_nodes.append(mod.body[0])
            except Exception:
                pass

        if not new_import_nodes:
            return self

        existing_lines = set()
        for stmt in self.module.body:
            existing_lines.add(cst.Module(body=[stmt]).code.strip())

        to_add = []
        for node in new_import_nodes:
            code = cst.Module(body=[node]).code.strip()
            if code not in existing_lines:
                to_add.append(node)
                existing_lines.add(code)

        if to_add:
            # Find last import
            last_import_idx = -1
            for i, stmt in enumerate(self.module.body):
                if isinstance(stmt, cst.SimpleStatementLine) and isinstance(
                    stmt.body[0], (cst.Import, cst.ImportFrom)
                ):
                    last_import_idx = i

            new_body = list(self.module.body)
            insert_pos = last_import_idx + 1 if last_import_idx >= 0 else 0

            for item in reversed(to_add):
                new_body.insert(insert_pos, item)

            self.module = self.module.with_changes(body=new_body)

        return self

    def transform_assignments(
        self,
        class_name: str,
        method_name: str,
        transformer_func: Any,  # Callable[[cst.Assign, str], Optional[cst.BaseSmallStatement]]
    ) -> "CodeEditor":
        """
        Visits assignments in a specified method and applies a transformation function.
        The transformer_func receives (assignment_node, lhs_full_name) and returns:
        - cst.BaseStatement (modified node)
        - cst.RemoveFromParent() (to delete)
        - None (to keep original)
        """

        class AssignmentTransformer(cst.CSTTransformer):
            def __init__(self, target_class: str, target_method: str, func: Any):
                self.target_class = target_class
                self.target_method = target_method
                self.func = func
                self.found_class = False
                self.in_method = False

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def visit_FunctionDef(self, node: cst.FunctionDef) -> Optional[bool]:
                if self.found_class and node.name.value == self.target_method:
                    self.in_method = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                if self.in_method:
                    self.in_method = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> Union[cst.BaseSmallStatement, cst.RemovalSentinel]:
                if not self.in_method:
                    return updated_node

                # Extract LHS string (e.g. "self.foo.bar")
                # Assume single target
                if not updated_node.targets:
                    return updated_node

                target = updated_node.targets[0].target
                lhs_str = self._get_full_name(target)

                # Apply transformation
                if lhs_str:
                    result = self.func(updated_node, lhs_str)
                    if result is None:
                        return updated_node
                    return cast(cst.BaseSmallStatement, result)

                return updated_node

            def _get_full_name(self, node: cst.BaseExpression) -> Optional[str]:
                if isinstance(node, cst.Name):
                    return node.value
                if isinstance(node, cst.Attribute):
                    base = self._get_full_name(node.value)
                    if base:
                        return f"{base}.{node.attr.value}"
                return None

        transformer = AssignmentTransformer(class_name, method_name, transformer_func)
        self.module = self.module.visit(transformer)
        return self

    def insert_statements_to_method(
        self, class_name: str, method_name: str, statements: List[cst.BaseStatement]
    ) -> "CodeEditor":
        """
        Appends statements to the end of a method.
        """

        class StatementInserter(cst.CSTTransformer):
            def __init__(
                self,
                target_class: str,
                target_method: str,
                stmts: List[cst.BaseStatement],
            ):
                self.target_class = target_class
                self.target_method = target_method
                self.stmts = stmts
                self.found_class = False

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                if self.found_class and original_node.name.value == self.target_method:
                    new_body = list(updated_node.body.body)
                    new_body.extend(self.stmts)
                    self.found_class = False  # Stop processing
                    return updated_node.with_changes(
                        body=cst.IndentedBlock(
                            body=cast(Sequence[cst.BaseStatement], new_body)
                        )
                    )
                return updated_node

        transformer = StatementInserter(class_name, method_name, statements)
        self.module = self.module.visit(transformer)
        return self

    def insert_statements_to_function(
        self, func_name: str, statements: List[cst.BaseStatement]
    ) -> "CodeEditor":
        """
        Appends statements to the end of a top-level function.
        """

        class FunctionInserter(cst.CSTTransformer):
            def __init__(self, target_func: str, stmts: List[cst.BaseStatement]):
                self.target_func = target_func
                self.stmts = stmts

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                # Check if it's top-level (no class parent check needed in visit)
                # But we need to ensure we don't accidentally match methods with same name if we only want top-level?
                # For now, let's assume unique names or strictly top-level?
                # LibCST traversal visits everything.
                # To restrict to top-level, we could check if we are inside a ClassDef.
                # But typically test functions are unique in a file.

                if original_node.name.value == self.target_func:
                    new_body = list(updated_node.body.body)

                    # Remove 'pass' if it's the only statement and we are adding stuff
                    if (
                        len(new_body) == 1
                        and isinstance(new_body[0], cst.SimpleStatementLine)
                        and isinstance(new_body[0].body[0], cst.Pass)
                    ):
                        new_body = []

                    new_body.extend(self.stmts)
                    return updated_node.with_changes(
                        body=cst.IndentedBlock(
                            body=cast(Sequence[cst.BaseStatement], new_body)
                        )
                    )
                return updated_node

        transformer = FunctionInserter(func_name, statements)
        self.module = self.module.visit(transformer)
        return self

    @staticmethod
    def update_call_args(call_node: cst.Call, updates: Dict[str, Any]) -> cst.Call:
        """
        Updates keyword arguments of a Call node.
        - updates: keys are kwarg names.
          Values:
            - string: update/add (wrapped in quotes if not int-like?)
            - int: Integer
            - bool: Name("True"/"False")
            - None/Empty: remove.
        """
        new_args: List[cst.Arg] = []
        processed_args = set()

        def to_cst_value(val: Any) -> cst.BaseExpression:
            if isinstance(val, bool):
                return cst.Name("True" if val else "False")
            if isinstance(val, int):
                return cst.Integer(str(val))
            if isinstance(val, str):
                if val.isdigit():
                    return cst.Integer(val)
                return cst.SimpleString(f'"{val}"')
            return cst.SimpleString(f'"{str(val)}"')

        # Update existing
        for arg in call_node.args:
            if isinstance(arg.keyword, cst.Name):
                kw = arg.keyword.value
                if kw in updates:
                    val = updates[kw]
                    processed_args.add(kw)
                    # Logic: if val is None -> remove.
                    # if val is "" -> remove? (Previous logic: val != "")
                    if val is not None and val != "":
                        new_args.append(arg.with_changes(value=to_cst_value(val)))
                    else:
                        # Remove (skip)
                        pass
                else:
                    new_args.append(arg)
            else:
                new_args.append(arg)

        # Add new
        for kw, val in updates.items():
            if kw not in processed_args and val is not None and val != "":
                node_val = to_cst_value(val)
                new_args.append(
                    cst.Arg(
                        keyword=cst.Name(kw),
                        value=node_val,
                        equal=cst.AssignEqual(
                            whitespace_before=cst.SimpleWhitespace(""),
                            whitespace_after=cst.SimpleWhitespace(""),
                        ),
                    )
                )

        return call_node.with_changes(args=new_args)

    def upsert_complex_call(
        self,
        class_name: str,
        method_name: str,
        target_lhs: str,
        inner_func: str,
        inner_kwargs: Dict[str, Any],
        wrapper_attr: Optional[str] = None,
        wrapper_kwargs: Optional[Dict[str, Any]] = None,
    ) -> "CodeEditor":
        """
        Updates or Creates an assignment: target_lhs = wrapper_attr(inner_func(**kwargs))
        Wrapper is optional. If None, target_lhs = inner_func(**kwargs).
        """

        class AssignmentUpserter(cst.CSTTransformer):
            def __init__(self, parent: CodeEditor):
                self.parent = parent
                self.found = False
                self.in_correct_scope = False

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                return node.name.value == class_name

            def visit_FunctionDef(self, node: cst.FunctionDef) -> Optional[bool]:
                if node.name.value == method_name:
                    self.in_correct_scope = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                self.in_correct_scope = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> cst.BaseSmallStatement:
                if not self.in_correct_scope:
                    return updated_node

                # Check LHS
                match = False
                for t in original_node.targets:
                    if self.parent._get_full_name(t.target) == target_lhs:
                        match = True
                        break

                if match:
                    self.found = True
                    # Update Value
                    new_val = self.parent._build_updated_value(
                        original_node.value,
                        target_lhs,  # Pass LHS
                        inner_func,
                        inner_kwargs,
                        wrapper_attr,
                        wrapper_kwargs,
                    )
                    return updated_node.with_changes(value=new_val)

                return updated_node

        upserter = AssignmentUpserter(self)
        self.module = self.module.visit(upserter)

        if not upserter.found:
            # Create new
            val_node = self._build_updated_value(
                None, target_lhs, inner_func, inner_kwargs, wrapper_attr, wrapper_kwargs
            )
            stmt = cst.SimpleStatementLine(
                body=[
                    cst.Assign(
                        targets=[
                            cst.AssignTarget(
                                target=cast(
                                    cst.BaseAssignTargetExpression,
                                    cst.parse_expression(target_lhs),
                                )
                            )
                        ],
                        value=val_node,
                    )
                ]
            )
            self.insert_statements_to_method(class_name, method_name, [stmt])

        return self

    def remove_assignments_not_in(
        self,
        class_name: str,
        method_name: str,
        allowed_lhs: Set[str],
        wrapper_whitelist: Set[str],
    ) -> "CodeEditor":
        """
        Removes assignments in the method where the value is a call to one of `wrapper_whitelist` attributes,
        BUT the LHS is NOT in `allowed_lhs`.
        Used to clean up deleted elements.
        """

        class Cleanup(cst.CSTTransformer):
            def __init__(self, parent: CodeEditor):
                self.parent = parent
                self.in_correct_scope = False

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                return node.name.value == class_name

            def visit_FunctionDef(self, node: cst.FunctionDef) -> Optional[bool]:
                if node.name.value == method_name:
                    self.in_correct_scope = True
                    return True
                return False

            def leave_FunctionDef(
                self, original_node: cst.FunctionDef, updated_node: cst.FunctionDef
            ) -> cst.BaseStatement:
                self.in_correct_scope = False
                return updated_node

            def leave_Assign(
                self, original_node: cst.Assign, updated_node: cst.Assign
            ) -> Union[cst.BaseSmallStatement, cst.RemovalSentinel]:
                if not self.in_correct_scope:
                    return updated_node

                # Check value first: is it a wrapper call we manage?
                is_managed = False
                if isinstance(original_node.value, cst.Call):
                    func = original_node.value.func
                    if (
                        isinstance(func, cst.Attribute)
                        and func.attr.value in wrapper_whitelist
                    ):
                        is_managed = True

                if not is_managed:
                    return updated_node

                # Check LHS
                should_keep = False
                for t in original_node.targets:
                    lhs = self.parent._get_full_name(t.target)
                    if lhs in allowed_lhs:
                        should_keep = True
                        break

                if not should_keep:
                    return cst.RemoveFromParent()

                return updated_node

        self.module = self.module.visit(Cleanup(self))
        return self

    def _get_full_name(self, node: cst.BaseExpression) -> Optional[str]:
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            base = self._get_full_name(node.value)
            if base:
                return f"{base}.{node.attr.value}"
        return None

    def _build_updated_value(
        self,
        current_node: Optional[cst.BaseExpression],
        target_lhs: str,
        inner_func: str,
        inner_kwargs: Dict[str, Any],
        wrapper_attr: Optional[str],
        wrapper_kwargs: Optional[Dict[str, Any]],
    ) -> cst.BaseExpression:

        # Helper to get inner call from wrapper
        inner_call = None
        current_wrapper = None

        if current_node and isinstance(current_node, cst.Call):
            if wrapper_attr:
                func = current_node.func
                if isinstance(func, cst.Attribute) and func.attr.value == wrapper_attr:
                    current_wrapper = current_node
                    if current_node.args and isinstance(
                        current_node.args[0].value, cst.Call
                    ):
                        inner_call = current_node.args[0].value
            else:
                inner_call = current_node  # No wrapper, direct call

        # Update Inner
        if inner_call:
            # Update Function Name if changed
            updated_inner = inner_call
            if (
                isinstance(inner_call.func, cst.Name)
                and inner_call.func.value != inner_func
            ):
                updated_inner = inner_call.with_changes(func=cst.Name(inner_func))

            # Update Args
            updated_inner = self.update_call_args(updated_inner, inner_kwargs)
        else:
            # Create new Inner
            args = self._dict_to_cst_args(inner_kwargs)
            updated_inner = cst.Call(func=cst.Name(inner_func), args=args)

        # Update or Create Wrapper
        if wrapper_attr:
            if current_wrapper:
                # Update inner arg (index 0)
                new_wrapper_args = list(current_wrapper.args)
                new_wrapper_args[0] = new_wrapper_args[0].with_changes(
                    value=updated_inner
                )

                updated_wrapper = current_wrapper.with_changes(args=new_wrapper_args)
                if wrapper_kwargs:
                    updated_wrapper = self.update_call_args(
                        updated_wrapper, wrapper_kwargs
                    )
                return updated_wrapper

            else:
                # NEW Wrapper creation
                # Determine caller from LHS: self.banner.logo -> self.banner
                parts = target_lhs.split(".")
                if len(parts) > 1:
                    caller_str = ".".join(parts[:-1])
                else:
                    caller_str = (
                        "self"  # Fallback? Should not happen for elements usually
                    )

                # Create wrapper call: caller.wrapper_attr(inner)
                wrapper_args = [cst.Arg(value=updated_inner)]
                if wrapper_kwargs:
                    wrapper_args.extend(self._dict_to_cst_args(wrapper_kwargs))

                return cst.Call(
                    func=cst.Attribute(
                        value=cst.parse_expression(caller_str),
                        attr=cst.Name(wrapper_attr),
                    ),
                    args=wrapper_args,
                )

        return updated_inner

    def _dict_to_cst_args(self, kwargs: Dict[str, Any]) -> List[cst.Arg]:
        new_args = []
        for k, v in kwargs.items():
            if v is not None and v != "":
                # Value conversion
                node_val: cst.BaseExpression
                if isinstance(v, bool):
                    node_val = cst.Name("True" if v else "False")
                elif isinstance(v, int):
                    node_val = cst.Integer(str(v))
                elif isinstance(v, str):
                    if v.isdigit():
                        node_val = cst.Integer(v)
                    else:
                        node_val = cst.SimpleString(f'"{v}"')
                else:
                    node_val = cst.SimpleString(f'"{str(v)}"')

                new_args.append(
                    cst.Arg(
                        keyword=cst.Name(k),
                        value=node_val,
                        equal=cst.AssignEqual(
                            whitespace_before=cst.SimpleWhitespace(""),
                            whitespace_after=cst.SimpleWhitespace(""),
                        ),
                    )
                )
        return new_args
