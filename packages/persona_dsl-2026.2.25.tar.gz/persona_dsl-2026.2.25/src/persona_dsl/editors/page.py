from typing import List, Dict, Any, Type, Optional
from dataclasses import fields
import importlib
from .base import CodeEditor


class PageEditor:
    """
    Persona-Specific Domain Logic for editing Page Objects using generic CodeEditor.
    Handles mapping of Element Definitions to Python syntax.

    Acts as the Single Source of Truth for Element Creation Rules.
    """

    def __init__(self, code: str):
        self.editor = CodeEditor(code)

    @staticmethod
    def get_element_class(type_name: str) -> Optional[Type]:
        try:
            mod = importlib.import_module("persona_dsl.pages.elements")
            return getattr(mod, type_name, None)
        except ImportError:
            return None

    @staticmethod
    def get_class_name_for_role(role: str) -> str:
        """
        Returns the simplified class name (e.g. 'Button') for a given ARIA role.
        Defaults to 'Element' if no specific class exists.
        """
        try:
            from persona_dsl.pages.registry import ROLE_TO_CLASS

            if role in ROLE_TO_CLASS:
                return ROLE_TO_CLASS[role].__name__
        except ImportError:
            pass
        return "Element"

    @staticmethod
    def resolve_element_class(type_name: str) -> Optional[Type]:
        """
        Resolves the actual Class Type from a class name string.
        """
        return PageEditor.get_element_class(type_name)

    @staticmethod
    def should_pass_role(type_name: str) -> bool:
        """
        Returns True if the 'role' argument should be explicitly passed to the constructor.
        """
        cls = PageEditor.get_element_class(type_name)
        if not cls:
            return True

        for f in fields(cls):
            if f.name == "role":
                return f.init
        return True

    @staticmethod
    @staticmethod
    def _get_allowed_fields(type_name: str) -> List[str]:
        """Returns set of field names accepted by the element's __init__."""
        cls = PageEditor.resolve_element_class(type_name)

        if not cls:
            # Fallback to base Element
            cls = PageEditor.get_element_class("Element")

        if not cls:
            return []

        return [f.name for f in fields(cls) if f.init]

    @staticmethod
    def normalize_element_args(
        el_def: Dict[str, Any], type_name: str, include_none: bool = False
    ) -> Dict[str, Any]:
        """
        Constructs the authoritative kwargs dict for an element from a loose definition.
        Uses introspection to valid arguments against the Element Class definition.
        """
        allowed_fields = PageEditor._get_allowed_fields(type_name)

        # Candidate construction (Aliases & Normalization)
        # We merge el_def with some standard aliases to ensure 'loose' definitions (like from frontend) match.
        candidates = el_def.copy()

        # 1. Alias Handling
        if "var_name" in candidates and "name" not in candidates:
            candidates["name"] = candidates["var_name"]

        # 2. Filtering
        mapping = {}
        for key in allowed_fields:
            if key in candidates:
                mapping[key] = candidates[key]

        # 3. Role Logic (Special Handling)
        should_pass = PageEditor.should_pass_role(type_name)
        if "role" in mapping and not should_pass:
            del mapping["role"]
        elif "role" in candidates and should_pass:
            mapping["role"] = candidates["role"]

        # 4. Clean empty values
        if include_none:
            cleaned = mapping
        else:
            cleaned = {k: v for k, v in mapping.items() if v is not None and v != ""}

        return cleaned

    def get_code(self) -> str:
        return self.editor.get_code()

    def update_class_attributes(self, class_name: str, attrs: Dict[str, str]) -> None:
        self.editor.update_class_attributes(class_name, attrs)

    def sync_elements(
        self, class_name: str, elements: List[Dict[str, Any]]
    ) -> "PageEditor":
        """
        Syncs the __init__ method's element assignments.
        """
        # 1. Flatten Definitions
        element_map: Dict[str, Dict[str, Any]] = {}
        ordered_lhs: List[str] = []

        def flatten(defs: List[Dict[str, Any]], parent_lhs: str) -> None:
            for el in defs:
                var = el.get("var_name")
                if not var:
                    continue
                lhs = f"{parent_lhs}.{var}"
                element_map[lhs] = el
                ordered_lhs.append(lhs)
                if "children" in el:
                    flatten(el["children"], lhs)

        flatten(elements, "self")

        # 2. Upsert each element
        for lhs in ordered_lhs:
            el_def = element_map[lhs]
            self._upsert_element(class_name, "__init__", lhs, el_def)

        # 3. Cleanup deleted
        allowed_lhs = set(element_map.keys())
        wrappers = {"add_element", "add_element_list"}
        self.editor.remove_assignments_not_in(
            class_name, "__init__", allowed_lhs, wrappers
        )

        return self

    def _upsert_element(
        self, class_name: str, method_name: str, lhs: str, el_def: Dict[str, Any]
    ) -> None:
        type_name = el_def.get("type", "Element")

        # Use centralized logic (self reference)
        kwargs = self.normalize_element_args(el_def, type_name, include_none=True)

        # Ensure role is explicitly cleared if not allowed (to remove from existing code)
        if not self.should_pass_role(type_name):
            kwargs["role"] = None

        # Ensure var_name fallback for name if not set
        if not kwargs.get("name"):
            kwargs["name"] = el_def.get("var_name")

        # Wrapper details
        wrapper = "add_element"
        wrapper_kwargs = None

        if el_def.get("is_list"):
            wrapper = "add_element_list"
            var_name = lhs.split(".")[-1]
            wrapper_kwargs = {"alias": var_name}

        self.editor.upsert_complex_call(
            class_name=class_name,
            method_name=method_name,
            target_lhs=lhs,
            inner_func=type_name,
            inner_kwargs=kwargs,
            wrapper_attr=wrapper,
            wrapper_kwargs=wrapper_kwargs,
        )
