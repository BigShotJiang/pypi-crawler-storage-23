import libcst as cst
from typing import List, Dict, Optional
from .base import CodeEditor


class TestEditor:
    """
    Domain Logic for editing Test Files (Pytest + Allure + Persona).
    """

    __test__ = False

    def __init__(self, code: str):
        self.editor = CodeEditor(code)

    def get_code(self) -> str:
        return self.editor.get_code()

    def add_import(self, module: str, name: str, alias: Optional[str] = None) -> None:
        self.editor.add_imports(
            [f"from {module} import {name}" + (f" as {alias}" if alias else "")]
        )

    def add_test_function(
        self,
        name: str,
        docstring: str = "",
        steps: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        links: Optional[List[Dict[str, str]]] = None,
    ) -> None:
        """
        Adds a new test function with allure decorators.
        """
        # 0. Auto-import allure
        if tags or links:
            self.editor.add_imports(["import allure"])

        # 1. Build Decorators
        decorators = []
        if tags:
            for tag in tags:
                decorators.append(
                    cst.Decorator(
                        decorator=cst.Call(
                            func=cst.Attribute(
                                value=cst.Name("allure"), attr=cst.Name("tag")
                            ),
                            args=[cst.Arg(cst.SimpleString(f'"{tag}"'))],
                        )
                    )
                )

        if links:
            for link in links:
                decorators.append(
                    cst.Decorator(
                        decorator=cst.Call(
                            func=cst.Attribute(
                                value=cst.Name("allure"), attr=cst.Name("link")
                            ),
                            args=[
                                cst.Arg(cst.SimpleString(f'"{link["url"]}"')),
                                cst.Arg(
                                    keyword=cst.Name("name"),
                                    value=cst.SimpleString(f'"{link["name"]}"'),
                                ),
                            ],
                        )
                    )
                )

        # 2. Build Body
        body_stmts: List[cst.BaseStatement] = []
        if docstring:
            body_stmts.append(
                cst.SimpleStatementLine(
                    body=[cst.Expr(cst.SimpleString(f'"""{docstring}"""'))]
                )
            )

        if steps:
            for step in steps:
                # Parse step string to CST node (simplistic approach)
                try:
                    stmt = cst.parse_statement(step)
                    body_stmts.append(stmt)
                except Exception:
                    pass  # Skip invalid steps or handle better

        if not body_stmts:
            body_stmts.append(cst.SimpleStatementLine(body=[cst.Pass()]))

        # 3. Create FunctionDef
        func_def = cst.FunctionDef(
            name=cst.Name(name),
            params=cst.Parameters(
                params=[cst.Param(name=cst.Name("persona"))]
            ),  # Standard fixture
            body=cst.IndentedBlock(body=body_stmts),
            decorators=decorators,
        )

        # 4. Append to Module
        new_body = list(self.editor.module.body)
        new_body.append(func_def)
        self.editor.module = self.editor.module.with_changes(body=new_body)

    def add_step(self, test_name: str, step_code: str) -> None:
        """
        Adds a step to an existing test function.
        """
        try:
            stmt = cst.parse_statement(step_code)
            self.editor.insert_statements_to_function(test_name, [stmt])
        except Exception:
            # Handle parse error
            pass
