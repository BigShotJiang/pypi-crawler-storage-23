from typing import Optional, cast
from pathlib import Path

from playwright.sync_api import Page

from .core.base import Skill


class UseBrowser(Skill):
    """Навык, который предоставляет доступ к драйверу страницы Playwright.

    Хранит и применяет глобальные настройки таймаутов страницы:
      - default_timeout: общий таймаут ожиданий (мс) для всех операций
      - default_navigation_timeout: таймаут навигации/загрузки (мс)
      - inject_runtime: автоматически внедрять Persona Runtime JS (по умолчанию True)
    """

    def __init__(
        self,
        page: Page,
        base_url: Optional[str] = None,
        default_timeout: Optional[float] = None,
        default_navigation_timeout: Optional[float] = None,
        inject_runtime: bool = True,
    ):
        super().__init__(page)
        self.base_url = base_url
        self._default_timeout = default_timeout
        self._default_navigation_timeout = default_navigation_timeout
        self._inject_runtime = inject_runtime

        # Применяем таймауты к странице, если заданы
        if self._default_timeout is not None:
            page.set_default_timeout(float(self._default_timeout))
        if self._default_navigation_timeout is not None:
            page.set_default_navigation_timeout(float(self._default_navigation_timeout))

        if self._inject_runtime:
            self._inject_persona_runtime(page)

    def _inject_persona_runtime(self, page: Page) -> None:
        """Внедряет JS-ядро Persona Runtime на страницу."""
        try:
            # Путь к бандлу относительно текущего файла
            # persona_dsl/skills/use_browser.py -> ... -> persona_dsl/runtime/dist/persona_bundle.js
            current_dir = Path(__file__).parent
            bundle_path = current_dir.parent / "runtime" / "dist" / "persona_bundle.js"

            if bundle_path.exists():
                js_content = bundle_path.read_text(encoding="utf-8")
                page.add_init_script(js_content)
            else:
                # В dev-режиме или если не собрано — предупреждаем, но не падаем жестко,
                # хотя функционал Runtime будет недоступен.
                print(f"[Persona] Warning: Runtime bundle not found at {bundle_path}")
        except Exception as e:
            print(f"[Persona] Error injecting runtime: {e}")

    @property
    def page(self) -> Page:
        return cast(Page, self.driver)

    def switch_active_page(self, new_page: Page) -> None:
        """Меняет активную страницу (вкладку) и применяет необходимые настройки."""
        self.driver = new_page

        if self._default_timeout is not None:
            new_page.set_default_timeout(float(self._default_timeout))
        if self._default_navigation_timeout is not None:
            new_page.set_default_navigation_timeout(
                float(self._default_navigation_timeout)
            )

        if self._inject_runtime:
            self._inject_persona_runtime(new_page)

        # Bring tab to front physically if needed
        new_page.bring_to_front()

    @classmethod
    def from_page(
        cls,
        page: Page,
        base_url: Optional[str] = None,
        default_timeout: Optional[float] = None,
        default_navigation_timeout: Optional[float] = None,
        inject_runtime: bool = True,
    ) -> "UseBrowser":
        return cls(
            page,
            base_url=base_url,
            default_timeout=default_timeout,
            default_navigation_timeout=default_navigation_timeout,
            inject_runtime=inject_runtime,
        )
