import json
import os
import difflib
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from persona_dsl.components.expectation import Expectation


class MatchesDataSnapshot(Expectation):
    """
    Сравнивает извлеченные данные (Dict или List[Dict]) с сохраненным JSON-эталоном.
    Работает по принципу визуальных скриншотов, но для структурированных данных.

    Если эталон не существует (или передан флаг update=True), он будет создан/перезаписан.

    Args:
        name: Имя файла эталона (без расширения).
        exclude_keys: Список ключей, которые нужно игнорировать при сравнении (например, "id", "date").
        update: Если True, перезапишет (или создаст) эталон текущими данными.
        ignore_order: Если True и данные - это List, то порядок элементов игнорируется.
    """

    def __init__(
        self,
        name: str,
        exclude_keys: Optional[List[str]] = None,
        update: bool = False,
        ignore_order: bool = False,
    ) -> None:
        self.name = name
        self.exclude_keys = exclude_keys or []
        self.update = update
        self.ignore_order = ignore_order

    def _get_step_description(self, persona: Any) -> str:
        return f"Сверка данных со снимком '{self.name}'"

    def _clean_data(self, data: Any) -> Any:
        """Рекурсивно удаляет ключи из exclude_keys"""
        if isinstance(data, dict):
            return {
                k: self._clean_data(v)
                for k, v in data.items()
                if k not in self.exclude_keys
            }
        elif isinstance(data, list):
            return [self._clean_data(item) for item in data]
        return data

    def _sort_data(self, data: Any) -> Any:
        """Сортирует списки словарей для сравнения без учета порядка"""
        if isinstance(data, list) and self.ignore_order:
            try:
                # Пытаемся отсортировать словари, сериализуя их в строку
                return sorted(data, key=lambda x: json.dumps(x, sort_keys=True))
            except TypeError:
                return data
        return data

    def _perform(
        self, persona: Any, target: Union[Dict[str, Any], List[Dict[str, Any]]]
    ) -> bool:
        # 1. Очищаем фактические данные
        cleaned_actual = self._clean_data(target)
        sorted_actual = self._sort_data(cleaned_actual)

        # 2. Определяем путь к snapshot
        snapshots_dir = Path.cwd() / "tests" / "snapshots" / "data_snapshots"
        snapshots_dir.mkdir(parents=True, exist_ok=True)
        snapshot_path = snapshots_dir / f"{self.name}.json"

        # 3. Режим обновления (или файл не существует)
        if self.update or not os.path.exists(snapshot_path):
            with open(snapshot_path, "w", encoding="utf-8") as f:
                json.dump(
                    sorted_actual, f, ensure_ascii=False, indent=4, sort_keys=True
                )
            return True

        # 4. Режим сравнения
        with open(snapshot_path, "r", encoding="utf-8") as f:
            expected_data = json.load(f)

        sorted_expected = self._sort_data(expected_data)

        if sorted_actual == sorted_expected:
            return True

        # 5. Если есть различия - генерируем читаемый diff
        actual_str = json.dumps(
            sorted_actual, ensure_ascii=False, indent=2, sort_keys=True
        )
        expected_str = json.dumps(
            sorted_expected, ensure_ascii=False, indent=2, sort_keys=True
        )

        diff = list(
            difflib.unified_diff(
                expected_str.splitlines(keepends=True),
                actual_str.splitlines(keepends=True),
                fromfile=f"Expected ({self.name}.json)",
                tofile="Actual Data",
            )
        )
        diff_text = "".join(diff)

        error_message = f"Данные не совпадают с эталоном '{self.name}'.\n\nРазличия:\n{textwrap.indent(diff_text, '  ')}"
        raise AssertionError(error_message)
