from typing import Any

from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.pages.elements import Element
from persona_dsl.skills.core.skill_definition import SkillId


class HaveValue(Expectation):
    """
    Проверка: Input имеет ожидаемое значение.
    Wrapper for: expect(locator).to_have_value(value)
    """

    def __init__(self, value: str, timeout: float = 5000):
        self.value = value
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        return f"имеет значение '{self.value}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        element_or_locator = args[0]
        page = persona.skill(SkillId.BROWSER).page

        if isinstance(element_or_locator, Element):
            locator = element_or_locator.resolve(page)
        else:
            locator = element_or_locator

        expect(locator).to_have_value(self.value, timeout=self.timeout)
