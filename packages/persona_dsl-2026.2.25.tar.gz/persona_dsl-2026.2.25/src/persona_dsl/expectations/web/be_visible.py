from typing import Any

from playwright.sync_api import expect

from persona_dsl.components.expectation import Expectation
from persona_dsl.pages.elements import Element
from persona_dsl.skills.core.skill_definition import SkillId


class BeVisible(Expectation):
    """
    Проверка: Элемент видим на странице.
    Wrapper for: expect(locator).to_be_visible()
    """

    def __init__(self, timeout: float = 5000):
        self.timeout = timeout

    def _get_step_description(self, persona: Any) -> str:
        return "видим на странице"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        element_or_locator = args[0]
        page = persona.skill(SkillId.BROWSER).page

        if isinstance(element_or_locator, Element):
            locator = element_or_locator.resolve(page)
        else:
            locator = element_or_locator

        expect(locator).to_be_visible(timeout=self.timeout)
