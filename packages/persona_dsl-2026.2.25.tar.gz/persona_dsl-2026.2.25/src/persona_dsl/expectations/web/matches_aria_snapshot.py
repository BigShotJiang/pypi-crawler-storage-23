import os
import shutil
import time
import difflib
import yaml
from pathlib import Path
from typing import Optional, List, Any

import allure

from persona_dsl.components.expectation import Expectation
from persona_dsl.utils.artifacts import sanitize_filename, artifacts_dir
from persona_dsl.utils.path import remove_by_path


def _normalize(obj: Any, sort_keys: bool = True) -> Any:
    """
    Рекурсивно нормализует JSON-структуру:
    - сортирует ключи словарей (если sort_keys=True)
    - оставляет списки как есть
    """
    if isinstance(obj, dict):
        items_gen = ((k, _normalize(v, sort_keys)) for k, v in obj.items())
        items: Any
        if sort_keys:
            items = sorted(items_gen, key=lambda kv: kv[0])
        else:
            items = items_gen
        return {k: v for k, v in items}
    if isinstance(obj, list):
        return [_normalize(v, sort_keys) for v in obj]
    return obj


class MatchesAriaSnapshot(Expectation):
    """
    Ожидание: ARIA-снепшот (YAML строка) совпадает с baseline (.yaml).
    - baseline ищется по умолчанию в tests/snapshots/<name>.yaml.
    - при отсутствии baseline:
        * если update=True или UPDATE_SNAPSHOTS=1 — baseline создаётся из actual;
        * иначе — ошибка.
    - перед сравнением можно исключить пути (ignore_paths) и нормализовать порядок ключей (sort_keys=True).
    """

    def __init__(
        self,
        snapshot_name: str,
        update: bool = False,
        baseline_dir: Optional[str] = None,
        ignore_paths: Optional[List[str]] = None,
        sort_keys: bool = True,
    ):
        """
        Args:
            snapshot_name: имя baseline-файла (например, "home-aria.yaml" или без .yaml).
            update: разрешить создание/обновление baseline.
            baseline_dir: каталог для baseline (по умолчанию tests/snapshots).
            ignore_paths: список путей (dot/bracket), которые следует удалить перед сравнением.
            sort_keys: сортировать ли ключи словарей перед сравнением.
        """
        self.snapshot_name = snapshot_name
        self.update = bool(update)
        self.baseline_dir = baseline_dir
        self.ignore_paths = ignore_paths or []
        self.sort_keys = bool(sort_keys)

    def _get_step_description(self, persona: Any) -> str:
        return f"совпадает с ARIA-снепшотом '{self.snapshot_name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        actual_value = args[0]

        if not isinstance(actual_value, str):
            raise TypeError(
                f"MatchesAriaSnapshot ожидает YAML строку, получено: {type(actual_value)}"
            )

        # Преобразуем YAML в словарь для нормализации и сравнения
        try:
            actual_dict = yaml.safe_load(actual_value)
        except Exception as e:
            raise ValueError(f"Не удалось распарсить YAML снепшот: {e}") from e

        snap_name = sanitize_filename(self.snapshot_name)
        if not snap_name.lower().endswith((".yaml", ".yml")):
            snap_name += ".yaml"
        base_dir = (
            Path(self.baseline_dir)
            if self.baseline_dir
            else (Path.cwd() / "tests" / "snapshots")
        )
        baseline_path = base_dir / snap_name

        # Подготовим копии для нормализации/фильтрации
        def _prepare(val: Any) -> Any:
            import copy

            v = copy.deepcopy(val)
            for p in self.ignore_paths:
                remove_by_path(v, p, strict=False)
            return _normalize(v, self.sort_keys)

        actual_norm = _prepare(actual_dict)

        # Если baseline отсутствует — возможно создаём
        if not baseline_path.exists():
            if self.update or os.getenv("UPDATE_SNAPSHOTS") == "1":
                baseline_path.parent.mkdir(parents=True, exist_ok=True)
                with open(baseline_path, "w", encoding="utf-8") as f:
                    yaml.dump(
                        actual_norm,
                        f,
                        default_flow_style=False,
                        allow_unicode=True,
                        indent=2,
                    )
                try:
                    allure.attach(
                        yaml.dump(
                            actual_norm,
                            default_flow_style=False,
                            allow_unicode=True,
                            indent=2,
                        ),
                        name=f"baseline-created:{snap_name}",
                        attachment_type=allure.attachment_type.TEXT,
                    )
                except Exception:
                    pass
                return
            raise AssertionError(
                f"ARIA baseline не найден: {baseline_path}. "
                f"Запустите с UPDATE_SNAPSHOTS=1 или установите update=True для создания baseline."
            )

        # Сравнение
        with open(baseline_path, "r", encoding="utf-8") as f:
            try:
                base_data = yaml.safe_load(f)
            except Exception as e:
                raise AssertionError(
                    f"Не удалось прочитать baseline YAML {baseline_path}: {e}"
                ) from e
        base_norm = _prepare(base_data)

        if base_norm == actual_norm:
            return

        # Если разрешён update — обновляем baseline и выходим
        if self.update or os.getenv("UPDATE_SNAPSHOTS") == "1":
            shutil.copyfile(baseline_path, baseline_path.with_suffix(".bak.yaml"))
            with open(baseline_path, "w", encoding="utf-8") as f:
                yaml.dump(
                    actual_norm,
                    f,
                    default_flow_style=False,
                    allow_unicode=True,
                    indent=2,
                )
            try:
                allure.attach(
                    yaml.dump(
                        actual_norm,
                        default_flow_style=False,
                        allow_unicode=True,
                        indent=2,
                    ),
                    name=f"baseline-updated:{snap_name}",
                    attachment_type=allure.attachment_type.TEXT,
                )
            except Exception:
                pass
            return

        # Иначе — формируем артефакты diff
        ts = int(time.time() * 1000)
        art_dir = artifacts_dir("snapshots")
        actual_path = art_dir / f"{ts}-actual-{snap_name}"
        diff_path = art_dir / f"{ts}-diff-{snap_name}.diff"

        with open(actual_path, "w", encoding="utf-8") as f:
            yaml.dump(
                actual_norm, f, default_flow_style=False, allow_unicode=True, indent=2
            )

        base_str = yaml.dump(
            base_norm, default_flow_style=False, allow_unicode=True, indent=2
        ).splitlines(keepends=True)
        act_str = yaml.dump(
            actual_norm, default_flow_style=False, allow_unicode=True, indent=2
        ).splitlines(keepends=True)
        udiff = "".join(
            difflib.unified_diff(
                base_str, act_str, fromfile="baseline", tofile="actual"
            )
        )

        with open(diff_path, "w", encoding="utf-8") as f:
            f.write(udiff)

        try:
            allure.attach.file(
                str(baseline_path),
                name=f"baseline:{snap_name}",
                attachment_type=allure.attachment_type.TEXT,
            )
            allure.attach.file(
                str(actual_path),
                name=f"actual:{snap_name}",
                attachment_type=allure.attachment_type.TEXT,
            )
            allure.attach(
                udiff,
                name=f"diff:{snap_name}",
                attachment_type=allure.attachment_type.TEXT,
            )
        except Exception:
            pass

        raise AssertionError(
            f"ARIA YAML не совпадает с baseline: {baseline_path}. Diff: {diff_path}"
        )
