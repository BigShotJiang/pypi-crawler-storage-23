import argparse
import os
import sys
from pathlib import Path
from typing import Any, Dict
import yaml

from .page.generator import PageGenerator
from .api_generator import ApiGenerator
from persona_dsl.utils.naming import to_pascal_case, to_snake_case
from unidecode import unidecode

ENV_FILE_NAME = ".persona_gen.env"
ENV_KEY_HEADLESS = "PERSONA_GEN_HEADLESS"
ENV_KEY_BROWSER_EXEC = "PERSONA_GEN_BROWSER_EXECUTABLE"
ENV_KEY_DEFAULT_URL = "PERSONA_GEN_DEFAULT_URL"


def _prompt_non_empty(prompt: str, default: str | None = None) -> str:
    while True:
        raw = input(prompt).strip()
        if raw:
            return raw
        if default is not None:
            return default
        print("Значение не может быть пустым. Повторите ввод.")


def _prompt_yes_no(prompt: str, default: bool = True) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    while True:
        raw = input(f"{prompt} {suffix}: ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("Введите 'y' или 'n'.")


def _suggest_class_name_from_title(title: str | None) -> str:
    if title:
        ascii_title = unidecode(title)
        candidate = to_pascal_case(ascii_title)
        if not candidate:
            candidate = "Generated"
        if not candidate.endswith("Page"):
            candidate += "Page"
        return candidate
    return "GeneratedPage"


def _load_env_config(env_path: Path) -> Dict[str, str]:
    cfg: Dict[str, str] = {}
    if env_path.exists() and env_path.is_file():
        try:
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" in line:
                        k, v = line.split("=", 1)
                        cfg[k.strip()] = v.strip()
        except Exception:
            # Не маскируем ошибки в логике генерации; просто игнорируем битый env и пересохраняем позже
            pass
    return cfg


def _save_env_config(env_path: Path, cfg: Dict[str, str]) -> None:
    try:
        lines = [
            "# Persona DSL Generators settings\n",
            f"{ENV_KEY_HEADLESS}={cfg.get(ENV_KEY_HEADLESS, 'true')}\n",
            f"{ENV_KEY_BROWSER_EXEC}={cfg.get(ENV_KEY_BROWSER_EXEC, '')}\n",
            f"{ENV_KEY_DEFAULT_URL}={cfg.get(ENV_KEY_DEFAULT_URL, '')}\n",
        ]
        env_path.parent.mkdir(parents=True, exist_ok=True)
        with open(env_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        print(f"Настройки сохранены в {env_path}")
    except Exception as e:
        print(
            f"Предупреждение: не удалось сохранить настройки в {env_path}: {e}",
            file=sys.stderr,
        )


def page_main() -> None:
    """Entry point для persona-page-gen (интерактивный при отсутствии аргументов)."""
    parser = argparse.ArgumentParser(
        description="Генерация класса Page из ARIA-снепшота открытой страницы."
    )
    parser.add_argument("--url", help="URL страницы для анализа.")
    parser.add_argument(
        "--output-path", help="Путь для сохранения сгенерированного Python-файла."
    )
    parser.add_argument("--class-name", help="Имя для генерируемого класса страницы.")
    parser.add_argument(
        "--env-file",
        help=f"Путь к env-файлу настроек (по умолчанию ./{ENV_FILE_NAME}).",
    )
    args = parser.parse_args()

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print(
            "Ошибка: 'playwright' не установлен. Пожалуйста, установите его: pip install playwright",
            file=sys.stderr,
        )
        sys.exit(1)

    # 1) Загрузка и интерактивная настройка генератора до запроса URL
    env_path = Path(args.env_file) if args.env_file else Path.cwd() / ENV_FILE_NAME
    cfg = _load_env_config(env_path)

    # Headless
    cur_headless = cfg.get(ENV_KEY_HEADLESS, "true").lower() in (
        "1",
        "true",
        "yes",
        "y",
    )
    headless = _prompt_yes_no(
        "Запускать браузер в фоне (headless)?", default=cur_headless
    )
    cfg[ENV_KEY_HEADLESS] = "true" if headless else "false"

    # Проверка на наличие X-сервера, если пользователь выбрал не-headless режим.
    is_display_available = bool(os.environ.get("DISPLAY"))
    if not headless and not is_display_available:
        print(
            "\n\033[93mПредупреждение: Графический интерфейс (X-сервер) недоступен.\033[0m"
        )
        print(
            "Браузер будет принудительно запущен в фоновом (headless) режиме, чтобы избежать ошибки."
        )
        headless = True

    # Browser executable path
    cur_exec = cfg.get(ENV_KEY_BROWSER_EXEC, "")
    prompt_exec = input(
        "Укажите путь к исполняемому файлу браузера для Playwright (пусто — использовать встроенный):\n"
        f"[Текущее значение: '{cur_exec or 'не задано'}'] Введите новое значение или оставьте пустым: "
    ).strip()
    browser_executable = prompt_exec if prompt_exec else cur_exec
    cfg[ENV_KEY_BROWSER_EXEC] = browser_executable

    # Новые вопросы
    save_aria = _prompt_yes_no("Сохранить ARIA-снепшот в отдельный файл?", default=True)
    save_screenshot = _prompt_yes_no(
        "Сделать и сохранить скриншот страницы?", default=False
    )

    _save_env_config(env_path, cfg)

    # 2) Теперь спрашиваем URL (если не передан)
    cur_url = cfg.get(ENV_KEY_DEFAULT_URL, "")
    url = args.url or _prompt_non_empty(
        f"Введите URL страницы для анализа [по умолчанию: '{cur_url or 'не задан'}']: ",
        default=cur_url if cur_url else None,
    )
    cfg[ENV_KEY_DEFAULT_URL] = url
    _save_env_config(env_path, cfg)

    # 3) Открываем страницу, чтобы считать заголовок и предложить имя класса
    print(f"Открытие страницы {url} в браузере...")
    with sync_playwright() as p:
        launch_kwargs: Dict[str, Any] = {"headless": headless}
        if browser_executable:
            launch_kwargs["executable_path"] = browser_executable
        browser = p.chromium.launch(**launch_kwargs)
        page: Any = browser.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            print("Страница открыта. Вы можете взаимодействовать с ней.")

            try:
                title = page.title()
            except Exception:
                title = None
            suggested_class_name = args.class_name or _suggest_class_name_from_title(
                title
            )
            class_name = args.class_name or _prompt_non_empty(
                f"Введите имя класса страницы [по умолчанию: {suggested_class_name}]: ",
                default=suggested_class_name,
            )

            default_output = Path("tests/pages") / f"{to_snake_case(class_name)}.py"
            output_path_arg = args.output_path or _prompt_non_empty(
                f"Введите путь для сохранения Python-файла [по умолчанию: {default_output}]: ",
                default=str(default_output),
            )
            output_path = Path(output_path_arg)

            confirm_params = (
                input(
                    "\nПараметры генерации:\n"
                    f"- Headless:          {headless}\n"
                    f"- Browser exe:       {browser_executable or 'builtin'}\n"
                    f"- URL:               {url}\n"
                    f"- Class name:        {class_name}\n"
                    f"- Output path:       {output_path}\n"
                    f"- Save ARIA snapshot: {save_aria}\n"
                    f"- Save screenshot:   {save_screenshot}\n"
                    "Продолжить с этими параметрами? [Y/n]: "
                )
                .lower()
                .strip()
                or "y"
            )
            if confirm_params not in ("y", "yes"):
                print("Отменено пользователем.")
                sys.exit(0)

            input(
                "Нажмите Enter в этой консоли, когда будете готовы сделать ARIA-снепшот..."
            )

            print("Ожидание полной загрузки страницы (networkidle)...")
            try:
                page.wait_for_load_state("networkidle", timeout=60000)
            except Exception as e:
                print(
                    f"Предупреждение: не удалось дождаться состояния 'networkidle': {e}"
                )

            print("Создание rich ARIA-снепшота...")
            # Inject Runtime
            try:
                runtime_path = (
                    Path(__file__).parent.parent / "runtime" / "persona_runtime.js"
                )
                if runtime_path.exists():
                    js_content = runtime_path.read_text(encoding="utf-8")
                    page.evaluate(js_content)
                else:
                    print(
                        f"Предупреждение: Persona Runtime не найден по пути {runtime_path}. Инъекция пропущена.",
                        file=sys.stderr,
                    )
            except Exception as e:
                print(f"Ошибка загрузки Persona Runtime: {e}", file=sys.stderr)
                # Non-fatal? Or sys.exit?
                # Original code exit(1). Let's keep it but allow skip if just missing?
                # If missing -> warning. If evaluate fails -> error.
                pass

            snapshot = page.evaluate(
                "window.__PERSONA__ && window.__PERSONA__.getTreeForTransport()"
            )

            if not snapshot:
                # Fallback/Debug
                print(
                    "Warning: getTreeForTransport returned null. Trying getRichAriaSnapshot..."
                )
                snapshot = page.evaluate(
                    "window.__PERSONA__ && window.__PERSONA__.getRichAriaSnapshot()"
                )

            # RichAriaSnapshot has _tree_to_yaml but it is instance method?
            # It takes root.
            # We need standard yaml dump for saving?
            # Existing code used yaml.dump(snapshot).

            print(f"Получен rich снепшот (тип: {type(snapshot).__name__})")

            try:
                axtree = page.accessibility.snapshot()
                print("AXTree snapshot получен.")
            except Exception as e:
                raise RuntimeError(
                    f"page.accessibility.snapshot() недоступен или завершился с ошибкой: {e}"
                )

            if isinstance(snapshot, list):
                print(f"Снепшот содержит {len(snapshot)} корневых элементов")
                for i, item in enumerate(snapshot[:3]):
                    print(f"  Элемент {i}: {type(item).__name__}")
                    if isinstance(item, dict):
                        print(f"    Ключи: {list(item.keys())}")
            elif isinstance(snapshot, dict):
                print(f"Снепшот содержит ключи: {list(snapshot.keys())}")

            if not snapshot:
                print("Предупреждение: снепшот пустой или не содержит данных")
            print("Снепшот создан.")

            assets_dir = output_path.parent / "aria"
            assets_dir.mkdir(parents=True, exist_ok=True)
            aria_snapshot_rel_path: str | None = None
            screenshot_rel_path: str | None = None
            axtree_snapshot_rel_path: str | None = None

            if save_screenshot:
                screenshot_file = f"{output_path.stem}_screenshot.png"
                screenshot_abs_path = assets_dir / screenshot_file
                page.screenshot(path=screenshot_abs_path, full_page=True)
                screenshot_rel_path = f"aria/{screenshot_file}"
                print(f"Скриншот сохранен: {screenshot_abs_path}")

            if save_aria:
                snapshot_file = f"{output_path.stem}_snapshot.yaml"
                snapshot_abs_path = assets_dir / snapshot_file
                with open(snapshot_abs_path, "w", encoding="utf-8") as f:
                    yaml.dump(snapshot, f, default_flow_style=False, allow_unicode=True)
                aria_snapshot_rel_path = f"aria/{snapshot_file}"
                print(f"ARIA-снепшот сохранен: {snapshot_abs_path}")

                axtree_file = f"{output_path.stem}_axtree.yaml"
                axtree_abs_path = assets_dir / axtree_file
                with open(axtree_abs_path, "w", encoding="utf-8") as f:
                    yaml.dump(axtree, f, default_flow_style=False, allow_unicode=True)
                axtree_snapshot_rel_path = f"aria/{axtree_file}"
                print(f"AXTree-снепшот сохранен: {axtree_abs_path}")

        finally:
            browser.close()

    generator = PageGenerator()
    from urllib.parse import urlparse

    page_path = urlparse(url).path

    existing_code: str | None = None
    try:
        if output_path.exists():
            existing_code = output_path.read_text(encoding="utf-8")
    except Exception:
        existing_code = None

    generated_code = generator.generate_or_update_from_aria_snapshot(
        snapshot=snapshot,
        class_name=class_name,
        page_path=page_path,
        aria_snapshot_path=aria_snapshot_rel_path,
        screenshot_path=screenshot_rel_path,
        existing_code=existing_code,
    )

    _ = axtree_snapshot_rel_path

    print("\n--- Сгенерированный код ---")
    print(generated_code)
    print("---------------------------\n")

    final_output = input(
        f"Сохранить этот код в файл '{output_path}'? [Y/n] (или укажите другой путь): "
    ).strip()

    if final_output and final_output.lower() not in ("y", "yes", "n", "no"):
        output_path = Path(final_output)
        save_confirm = (
            input(f"Подтвердите сохранение в '{output_path}' [Y/n]: ").lower().strip()
            or "y"
        )
        if save_confirm not in ("y", "yes"):
            print("Сохранение отменено.")
            sys.exit(0)
    elif not final_output or final_output.lower() in ("y", "yes"):
        pass
    else:
        print("Сохранение отменено.")
        sys.exit(0)

    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(generated_code)
        print(f"Код успешно сохранен в {output_path}")
    except IOError as e:
        print(f"Ошибка: не удалось сохранить файл: {e}", file=sys.stderr)
        sys.exit(1)


def api_main() -> None:
    """Entry point для persona-api-gen (интерактивные вопросы при отсутствии аргументов)."""
    parser = argparse.ArgumentParser(
        description="Генерация API Steps из спецификации OpenAPI."
    )
    parser.add_argument(
        "--spec", help="Путь к файлу спецификации OpenAPI (YAML или JSON)."
    )
    parser.add_argument(
        "--output-dir", help="Директория для сохранения сгенерированных файлов."
    )
    args = parser.parse_args()

    spec_path_str = args.spec or _prompt_non_empty(
        "Введите путь к спецификации OpenAPI (YAML/JSON): "
    )
    spec_path = Path(spec_path_str)
    while not spec_path.exists() or not spec_path.is_file():
        print(f"Файл не найден: {spec_path}")
        spec_path_str = _prompt_non_empty(
            "Укажите корректный путь к спецификации OpenAPI: "
        )
        spec_path = Path(spec_path_str)

    output_dir_str = args.output_dir or _prompt_non_empty(
        "Введите директорию для генерации файлов (например, tests/api_steps): "
    )
    output_dir = Path(output_dir_str)

    print("\nПараметры генерации:")
    print(f"- Spec:       {spec_path}")
    print(f"- Output dir: {output_dir}")
    confirm = input("Продолжить? [Y/n]: ").lower().strip() or "y"
    if confirm not in ("y", "yes"):
        print("Отменено пользователем.")
        sys.exit(0)

    generator = ApiGenerator()
    try:
        generator.generate_from_spec(
            spec_path=str(spec_path), output_dir=str(output_dir)
        )
        print("Завершено.")
    except (FileNotFoundError, ValueError) as e:
        print(f"Ошибка: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    api_main()
