from typing import Any, Dict, List, Optional
import re
from .utils import INTERESTING_ROLES, derive_base_name, get_unique_name


class StructureParser:
    """
    Handles parsing of ARIA snapshots into a flat list of elements and
    structural analysis (sections identification).
    """

    def __init__(self, test_id_prefix: Optional[str] = None):
        self._test_id_prefix = test_id_prefix

    def _parse_concise_string(self, key: str, val: Any) -> Optional[Dict[str, Any]]:
        """
        Parses concise string format: `role "name" [ref=...]`
        """
        # Heuristic: Must contain typical indicators to be concise?
        # 1. [attr]
        # 2. "name"
        # 3. Known role
        # OR we just try to parse.

        parsed_node: Dict[str, Any] = {"children": [], "props": {}}

        # Extract Name: "..."
        name_match = re.search(r'"(.*?)"', key)
        if name_match:
            parsed_node["name"] = name_match.group(1)
            # Remove name from key for further parsing
            key_no_name = key.replace(f'"{parsed_node["name"]}"', "")
        else:
            key_no_name = key

        # Extract attributes [key=val] or [key]
        attrs = re.findall(r"\[(.*?)\]", key_no_name)
        has_attrs = len(attrs) > 0  # Indicator of concise format

        for attr in attrs:
            if "=" in attr:
                k, v = attr.split("=", 1)
                if k == "ref":
                    parsed_node["ref"] = v
                    parsed_node["aria_ref"] = v
                elif k == "testId":
                    parsed_node["test_id"] = v
                else:
                    parsed_node["props"][k] = v
            else:
                # Boolean prop [hidden], [disabled]
                parsed_node["props"][attr] = True

        # Remove attributes from key to get role
        # (Remove [...] blocks)
        key_clean = re.sub(r"\[.*?\]", "", key_no_name).strip()

        parts = key_clean.split()
        if not parts and not has_attrs and not name_match:
            # If no role, no attrs, no Name -> probably just text string
            return None

        if parts:
            parsed_node["role"] = parts[0]
        else:
            # If we have name/attrs but no role string? " [ref=...]"
            # Assume generic?
            parsed_node["role"] = "generic"

        # Process Value (list of children/props)
        if isinstance(val, list):
            for child in val:
                is_prop = False
                if isinstance(child, dict) and len(child) == 1:
                    ck = next(iter(child))
                    if ck.startswith("/"):
                        # It's a property: { "/url": "/" }
                        prop_name = ck[1:]
                        parsed_node["props"][prop_name] = child[ck]
                        is_prop = True

                if not is_prop:
                    # It's a child node (or a text string?)
                    parsed_node["children"].append(child)
        elif val is None:
            pass  # No children

        return parsed_node

    def parse_aria_node_recursive(
        self,
        nodes: List[Dict[str, Any]] | Dict[str, Any],
        used_names: set[str],
        context: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Строит внутреннее дерево элементов из JSON-структуры (от Runtime).
        """
        if isinstance(nodes, dict):
            nodes = [nodes]

        result = []
        for node in nodes:
            # --- 0. PRE-PROCESS CONCISE FORMAT (single key dict OR string) ---
            # If node is { "role name [ref=...]": [children/props] } OR "role name [ref=...]"

            parsed_concise: Optional[Dict[str, Any]] = None

            if isinstance(node, dict) and len(node) == 1:
                key = next(iter(node))
                val = node[key]
                if key not in (
                    "role",
                    "name",
                    "children",
                    "props",
                    "test_id",
                    "var_name",
                    "selector",
                    "locator",
                ):
                    parsed_concise = self._parse_concise_string(key, val)

            elif isinstance(node, str):
                # Try to parse string as concise node
                parsed_concise = self._parse_concise_string(node, None)

                # If parsing returned a generic text node because it failed to find a role,
                # we might want to keep it as simple text?
                # Actually _parse_concise_string defaults to role=text if no role found?
                # Let's check logic below.

            if parsed_concise:
                node = parsed_concise

            # If it was a string and failed to parse as concise role (e.g. just "Submit"),
            # _parse_concise_string might interpret "Submit" as role?
            # We need a whitelist of roles or check if first word is a known role?
            # OR we rely on the fact that concise format usually involves [ref] or quotes?

            if isinstance(node, str):
                # Fallback for simple strings that didn't parse into a rich element
                # (OR if _parse_concise_string wasn't confident)

                # Check if it was processed by _parse_concise_string?
                # If parsed_concise is None, it means it's still a string.

                result.append(
                    {
                        "role": "text",
                        "name": node,
                        "var_name": "text",
                        "init_kwargs": {"text": node},
                        "children": [],
                        "test_id": None,
                        "node_ref": {"text": node},
                    }
                )
                continue

            role = node.get("role", "")
            name = node.get("name", "")
            test_id = node.get("test_id")
            if not test_id and "props" in node and isinstance(node["props"], dict):
                test_id = node["props"].get("testId")

            placeholder = node.get("placeholder")
            if not placeholder and "props" in node and isinstance(node["props"], dict):
                placeholder = node["props"].get("placeholder")

            value = node.get("value")
            if not value and "props" in node and isinstance(node["props"], dict):
                value = node["props"].get("value")

            text = node.get("text")
            if not text and "props" in node and isinstance(node["props"], dict):
                text = node["props"].get("text")

            # --- 0. PORTAL DETECTION (Pre-Process) ---
            # Check for container classes (ant-select-dropdown) and assign name early prevents stripping.
            node_props_raw = node.get("props") or node.get("node_ref", {}).get(
                "props", {}
            )
            raw_class = node_props_raw.get("class", "") if node_props_raw else ""
            if not isinstance(raw_class, str):
                raw_class = ""

            if "ant-select-dropdown" in raw_class:
                name = "Dropdown Layer"
            elif any(
                x in raw_class for x in ["ant-dropdown", "MuiPopover", "bp3-portal"]
            ):
                name = "Overlay"

            # --- 1. PRE-FILTERING ---

            # Пропускаем "служебные" узлы, если это Generic без имени/test_id
            if role in ("generic", "", "none") and not name and not test_id:
                # Но если у ноды есть дети, мы должны их обработать и поднять наверх
                if "children" in node and node["children"]:
                    children = self.parse_aria_node_recursive(
                        node["children"], used_names, context
                    )
                    result.extend(children)
                continue

            # Игнорируем role="img" без имени (декоративные)
            if role == "img" and not name:
                continue

            # --- 2. ATTRIBUTE EXTRACTION ---

            # Smart Logic for test_id prefix stripping
            # (Assuming context might have common prefix if calculated appropriately)
            # For now passing raw test_id. Prefix logic can be applied later or here.
            # Using self._test_id_prefix if available to clean it.
            cleaned_test_id = test_id
            if (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}-")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]
            elif (
                test_id
                and self._test_id_prefix
                and test_id.startswith(f"{self._test_id_prefix}_")
            ):
                cleaned_test_id = test_id[len(self._test_id_prefix) + 1 :]

            # --- 3. NAME GENERATION ---
            base_name = derive_base_name(
                role, name, cleaned_test_id, text, placeholder  # text_prop
            )

            # Генерируем уникальное имя
            unique_name = get_unique_name(base_name, used_names)
            used_names.add(unique_name)

            # --- 4. ATTRIBUTE PREPARATION ---
            # Формируем словарь для атрибутов __init__
            # role/name/test_id всегда идут как базовые
            init_kwargs: Dict[str, Any] = {"name": unique_name}

            if placeholder:
                init_kwargs["placeholder"] = placeholder
            if value:
                # init_kwargs["value"] = value  # Element definition does not support value
                pass

            # Если есть accessible name
            # Check if name is dynamic (equals value) or looks like transient data (date/time)
            is_dynamic_name = False
            if value and name == value:
                is_dynamic_name = True

            # Simple heuristic for dates (common sources of flakiness)
            # Matches DD.MM.YYYY, YYYY-MM-DD.
            # We ALLOW Time (HH:MM) as it is often static structure (calendar slots).
            if re.search(r"\d{2}\.\d{2}\.\d{4}", name) or re.search(
                r"\d{4}-\d{2}-\d{2}", name
            ):
                is_dynamic_name = True

            # Use name if valid, else try text prop
            acc_name = name
            if not acc_name and text and not value:
                # If name is missing but we have text (and it's not a value input), use text
                acc_name = text

            if acc_name and not is_dynamic_name:
                # FIX: For Generics/Text/Paragraph without explicit Aria Role (or just generic),
                # prefer 'text' strategy if the name essentially IS the text content.
                # This makes them interactable via Click(Generic(text="...")) which is robust.
                # RELAXED: TreeWalker doesn't always send 'text' prop, so if role is generic and we have a name,
                # we assume the name comes from text content.
                if role in ("generic", "text", "paragraph", "presentation", "none", ""):
                    # Use the explicit text if available, otherwise name
                    # (Name often IS the text, but if manually named, we want the content)
                    if text:
                        init_kwargs["text"] = text
                    else:
                        init_kwargs["text"] = acc_name

                    # Explicitly set role to 'text' for mapping if generic/none
                    if role in ("generic", "none", ""):
                        role = "text"
                else:
                    init_kwargs["accessible_name"] = acc_name

            if (
                role and role != "group"
            ):  # role is usually implicit by class, but allowed explicitly
                # However, Persona classes handle role internally usually.
                # Only if generic Element is used do we need role.
                # Note: PageGenerator codegen logic will decide class.
                pass

            if cleaned_test_id:
                init_kwargs["test_id"] = cleaned_test_id

            # EXPLICIT LOCATOR SUPPORT (for Page Editor)
            if node.get("selector"):
                init_kwargs["locator"] = node.get("selector")
            elif node.get("locator"):
                init_kwargs["locator"] = node.get("locator")

            # EXPLICIT ACCESSIBLE NAME SUPPORT
            # Only add if it wasn't already used as 'text' strategy
            # If init_kwargs has 'text' and it equals explicit accessible_name, skip adding accessible_name
            explicit_acc_name = node.get("accessible_name")
            if explicit_acc_name:
                used_text = init_kwargs.get("text")
                # If we used text strategy, and the text is the same as accessible_name, don't duplicate
                if used_text and used_text == explicit_acc_name:
                    pass
                else:
                    init_kwargs["accessible_name"] = explicit_acc_name

            # --- EXTENDED ATTRIBUTES (Pass-through for Schema Validation) ---
            # Data-driven extraction to avoid repetition
            # --- EXTENDED ATTRIBUTES (Pass-through for Schema Validation) ---
            # Data-driven extraction, now checking against Element definitions where possible
            # Standard Element fields:
            # text, label, placeholder, test_id, alt_text, title, description, url, exact.

            ATTR_MAPPING = {
                "title": ["title", "/title"],
                "alt_text": ["alt", "alt_text", "/alt", "/alt_text"],
                "label": ["label", "aria-label", "/label", "/aria-label"],
                "description": [
                    "description",
                    "aria-description",
                    "/description",
                    "/aria-description",
                ],
                "url": ["href", "url", "src", "/href", "/url", "/src"],
                "exact": ["exact", "/exact"],
                "value": ["value", "/value"],  # Some elements use value
                "checked": ["checked", "/checked"],
                "disabled": ["disabled", "/disabled"],
                "expanded": ["expanded", "/expanded"],
                "selected": ["selected", "/selected"],
                "variants": [
                    "variants",
                    "/variants",
                ],  # Allow passing explicit variants (for Enums)
            }

            # Helper to get prop
            def get_prop(keys: List[str]) -> Any:
                for k in keys:
                    if k in node:
                        return node[k]
                    if (
                        "props" in node
                        and isinstance(node["props"], dict)
                        and k in node["props"]
                    ):
                        return node["props"][k]
                return None

            for attr, keys in ATTR_MAPPING.items():
                val = get_prop(keys)
                if val is not None:
                    init_kwargs[attr] = val

            # --- 5. RECURSION ---
            children_list = []
            if "children" in node:
                children_list = self.parse_aria_node_recursive(
                    node["children"], used_names, context
                )

            # --- 6. ELEMENT CONSTRUCTION ---
            element_def = {
                "var_name": unique_name,
                "role": role,
                "name": name,  # raw accessible name
                "text": text,  # text content (if any)
                "test_id": cleaned_test_id,  # for logic
                "original_test_id": test_id,  # for prefix calc
                "children": children_list,
                "init_kwargs": init_kwargs,
                "node_ref": node,  # link to original node
                "is_section": False,  # Flag for wrapping
                "is_complex_section": name
                in ("Dropdown Layer", "Overlay"),  # Flag for extracting to Class
            }

            # Extract aria_ref if present (support both ref and aria_ref keys)
            # STABLE ID: Re-enabled after fixing IdGenerator stability
            aria_ref = node.get("ref") or node.get("aria_ref")
            if aria_ref:
                init_kwargs["aria_ref"] = aria_ref
                element_def["aria_ref"] = (
                    aria_ref  # Ensure it is available for flattening check
                )

            result.append(element_def)

        return result

    def collect_consumed_refs(self, elements: List[Dict[str, Any]]) -> set[str]:
        """Собирает все ID (aria_ref) элементов, которые используются как лейблы другими элементами."""
        refs = set()
        for el in elements:
            # Check if this element consumes refs?
            # (Logic depends on if 'labelled_by' is in element dict, usually extracted from Node)
            # Assuming node_ref has it
            node = el.get("node_ref", {})

            # Check standard keys
            if "labelledby" in node:
                refs.add(node["labelledby"])
            if "describedby" in node:
                refs.add(node["describedby"])

            # Check snapshot property keys (common in RichAriaSnapshot yaml/json)
            # Value might be list or string representation of list: "['ref1', 'ref2']"
            # Also check inside 'props' dictionary where properties often reside

            targets = [node]
            if "props" in node:
                targets.append(node["props"])

            for target in targets:
                for key in [
                    "/labelledByRefs",
                    "labelledByRefs",
                    "/describedByRefs",
                    "describedByRefs",
                ]:
                    val = target.get(key)
                    if val:
                        if isinstance(val, list):
                            refs.update(val)
                        elif isinstance(val, str):
                            # Try to parse string list "['a', 'b']"
                            import ast

                            try:
                                parsed = ast.literal_eval(val)
                                if isinstance(parsed, list):
                                    refs.update(parsed)
                                else:
                                    refs.add(val)
                            except Exception:
                                refs.add(val)

            if el["children"]:
                refs = refs.union(self.collect_consumed_refs(el["children"]))
        return refs

    def flatten_tree_recursive(
        self, elements: List[Dict[str, Any]], consumed_refs: set[str] | None = None
    ) -> List[Dict[str, Any]]:
        """
        Рекурсивно проходит дерево и делает служебные generic-обёртки прозрачными.
        Также удаляет элементы, помеченные как "consumed" (лейблы) или как вспомогательные.
        """
        consumed_refs = consumed_refs or set()
        flat_list = []

        for el in elements:
            role = el["role"]
            name = el["name"]

            # 1. Скрываем consumed элементы (если они используются как лейблы)
            # Note: Need 'ref' from node (RichAriaSnapshot uses 'ref')
            node = el.get("node_ref", {})
            node_id = node.get("ref") or node.get("aria_ref") or node.get("id")

            if node_id and node_id in consumed_refs:
                # Skip adding this element to list, but process children?
                # Usually labels are leaf nodes. If not, we might lose children.
                # Heuristic: skip only if leaf or text-only logic
                if not el["children"]:
                    continue

            # 2. Generic-обёртки: если роль generic/none и нет полезных атрибутов -> поднимаем детей
            # We ignore 'name' for these roles because they are usually layout/content wrappers,
            # not semantic regions (use role='region' or 'group' for those).
            # FIX: Restoring named generics (user requirement). ONLY filter if name is empty.
            # But filter 'text'/'paragraph' even if named (usually just labels).
            # ALSO: If element has aria_ref, it is stable and should be preserved.
            has_ref = bool(
                el.get("aria_ref")
                or el.get("ref")
                or el.get("node_ref", {}).get("ref")
                or el.get("node_ref", {}).get("aria_ref")
            )

            if role in ("paragraph", "presentation"):
                is_uninteresting_generic = not el.get("test_id") and not has_ref
            else:
                is_uninteresting_generic = (
                    (role in ("generic", "", "none"))
                    and not name
                    and not el.get("test_id")
                    and not has_ref
                )

            if is_uninteresting_generic:
                if el["children"]:
                    # Recurse on children and add them to THIS level
                    flattened_children = self.flatten_tree_recursive(
                        el["children"], consumed_refs
                    )
                    flat_list.extend(flattened_children)
            else:
                # Оставляем элемент, но его children тоже нужно "сплющить" внутри него
                if el["children"]:
                    el["children"] = self.flatten_tree_recursive(
                        el["children"], consumed_refs
                    )
                flat_list.append(el)

        return flat_list

    def recalculate_names(self, elements: List[Dict[str, Any]]) -> None:
        """
        Полностью пересчитывает имена (var_name) для списка элементов.
        Это нужно вызывать после фильтрации/схлопывания, чтобы освободившиеся
        красивые имена (например 'login' вместо 'login_1') достались оставшимся элементам.
        """
        # Scoped within each level
        # We need to traverse tree level by level and recalculate uniqueness per level

        def process_level(
            level_elements: List[Dict[str, Any]], inherited_used_names: set[str]
        ) -> None:
            # Collect base names again
            current_level_names: set[str] = set()

            # 1. Locator Uniqueness Pass
            # We need to identify if elements will have identical locators.
            # Signature: (role, accessible_name, test_id, placeholder, text)
            # Note: We rely on init_kwargs primarily as that's what constructs the Element.
            locator_counts: Dict[tuple, int] = {}

            for el in level_elements:
                ik = el["init_kwargs"]
                # Build signature based on what Element uses for locating
                sig = (
                    el["role"],
                    ik.get("accessible_name"),
                    ik.get("test_id"),
                    ik.get("placeholder"),
                    ik.get("text"),
                    # ik.get("aria_ref"), # aria_ref is unique but not used for locating, so we EXCLUDE it to detect collisions
                )
                locator_counts[sig] = locator_counts.get(sig, 0) + 1

            locator_current_indices: Dict[tuple, int] = {}

            # Prioritize interactive elements for better naming (e.g. login input > login text)
            # level_elements.sort(key=sort_key) # DISABLED: Preserving DOM order to prevent layout shifts

            for el in level_elements:
                ik = el["init_kwargs"]
                sig = (
                    el["role"],
                    ik.get("accessible_name"),
                    ik.get("test_id"),
                    ik.get("placeholder"),
                    ik.get("text"),
                    # ik.get("aria_ref"),
                )

                # Assign Index if duplicates exist
                if locator_counts.get(sig, 0) > 1:
                    idx = locator_current_indices.get(sig, 0)
                    # Use 0-based or 1-based? Usually 0 is fine, locator.nth(0) matches first.
                    el["init_kwargs"]["index"] = idx
                    locator_current_indices[sig] = idx + 1

                # Double-check uniqueness logic
                # 'locator_counts' ensures we add indices to locators.
                # 'process_level' needs to ensure 'var_name' is unique.

                # Re-derive base name based on current data
                # (Logic implies re-running base_name derivation or storing it)
                # Re-running is safer.
                base_name = derive_base_name(
                    el["role"],
                    el["name"],
                    el["test_id"],
                    (
                        el["node_ref"].get("text")
                        or (el["node_ref"].get("props") or {}).get("text")
                    ),
                    (
                        el["node_ref"].get("placeholder")
                        or (el["node_ref"].get("props") or {}).get("placeholder")
                    ),
                )

                # Unique in current context
                unique = get_unique_name(base_name, current_level_names)
                current_level_names.add(unique)

                el["var_name"] = unique
                el["init_kwargs"]["name"] = unique

                if el["children"]:
                    process_level(el["children"], set())  # New scope for children

        process_level(elements, set())

    def promote_semantic_wrappers(
        self, elements: List[Dict[str, Any]], used_names: set[str]
    ) -> None:
        """
        Находит семантические группы (group, region, form, etc.) без имени.
        Пытается найти внутри них заголовок (Heading) и использовать его текст как имя группы.
        Если находит -> переименовывает группу и делает её 'named region'.
        """
        for el in elements:
            role = el["role"]
            name = el["name"]

            # Recurse first
            if el["children"]:
                self.promote_semantic_wrappers(el["children"], used_names)

            # Logic: If un-named semantic container
            if role in ("group", "region", "form", "section", "article") and not name:
                heading_el = self._find_first_heading(el)
                if heading_el and heading_el.get("name"):
                    # Found a heading! Promote this wrapper.
                    new_name_text = heading_el["name"]

                    # Generate new var_name
                    base_name = derive_base_name(role, new_name_text, None, None, None)
                    unique = get_unique_name(base_name, used_names)
                    used_names.add(unique)

                    el["var_name"] = unique
                    el["name"] = new_name_text
                    el["init_kwargs"]["name"] = unique
                    el["init_kwargs"]["accessible_name"] = new_name_text

                    # Also, ideally, we might construct a 'locator' based on this heading
                    # This is advanced, sticking to Name promotion for now.

    def _find_first_heading(
        self, element: Dict[str, Any], depth: int = 0, max_depth: int = 2
    ) -> Optional[Dict[str, Any]]:
        """
        Рекурсивный поиск первого заголовка для именования секции.
        Останавливается, если встречает уже именованную семантическую группу.
        """
        if depth > max_depth:
            return None

        role = element.get("role")
        if role == "heading":
            return element

        if "children" in element:
            for child in element["children"]:
                # Stop if child is a significant landmark itself
                if (
                    child.get("role")
                    in (
                        "region",
                        "form",
                        "banner",
                        "main",
                    )
                    and child.get("name")
                    or child.get("is_semantic_group")
                ):
                    continue

                found = self._find_first_heading(child, depth + 1, max_depth)
                if found:
                    return found
        return None

    def identify_complex_sections(self, elements: List[Dict[str, Any]]) -> None:
        """
        Identifies elements that should be extracted into nested classes.
        Criteria:
        1. Specific Role (banner, contentinfo, form, etc.)
        2. Complexity (e.g. > 1 meaningful children)
        """
        for el in elements:
            role = el.get("role")
            children = el.get("children", [])

            # Recurse first
            if children:
                self.identify_complex_sections(children)

            # Check criteria
            # Check criteria
            is_interesting = role in INTERESTING_ROLES

            # Explicitly interesting if it has variants (User wants Enums)
            # Currently focused on ListBox/Select
            has_variants = False
            init_kwargs = el.get("init_kwargs", {})
            if "variants" in init_kwargs and isinstance(init_kwargs["variants"], list):
                has_variants = True
                # If it has variants, we WANT a class to hold the Enum.

            if role in ("listbox", "combobox") and has_variants:
                is_interesting = True

            # STRUCTURAL GROUPING (User Request: "Tree Structure")
            # If it's a generic container with meaningful children (e.g. Label + Input),
            # we should treat it as a Component (Section).
            if role == "generic" and len(children) >= 2:
                # Filter out purely layout generics?
                # For now, if it has 2+ children, we assume it's a group.
                # Check if children are "widgets" (not just text leaf nodes?)
                # Actually, Label (text) + Input (widget) is exactly what we want.
                is_interesting = True

            # Count meaningful children (not pure layout wrappers if we have any left)
            # Essentially, if it has children that will generate code.
            # has_children = len(children) > 0  # Simple check

            # Additional heuristic: Don't extract simple wrappers with 1 child
            # unless it's a critical role like 'main' or 'banner'
            is_complex = len(children) >= 1

            # If it has variants, it is complex enough to warrant a class (for Enum)
            if has_variants:
                is_complex = True

            if is_interesting and is_complex:
                el["is_complex_section"] = True
                # If it's complex, we will generate a class for it.
                # The class name will be derived from var_name in codegen.

    def identify_table_prototypes(self, elements: List[Dict[str, Any]]) -> None:
        """
        Analyzes Tables to detect repetitive Row patterns.
        Delegates to external analyzer.
        """
        from .table_analysis import identify_table_prototypes

        identify_table_prototypes(elements)

    def identify_dropdown_options(self, elements: List[Dict[str, Any]]) -> None:
        """
        Analyzes Combobox/Select/Listbox elements to collect their Options.
        If options are found (either as children or via aria-controls),
        they are collected into 'options_data' attribute for Enum generation.
        """
        for el in elements:
            role = el.get("role")

            # Recurse first? Or after?
            # Recurse first to ensure children are processed
            if el.get("children"):
                self.identify_dropdown_options(el["children"])

            if role in ("combobox", "listbox"):
                # Strategy:
                # 1. Look for 'option' children directly
                # 2. If Combobox, look for 'listbox' child, then options
                # 3. Future: Look for aria-controls (requires global lookup, might be hard in recursive pass without context)

                options = []

                def collect_options(nodes: List[Dict[str, Any]]) -> None:
                    for node in nodes:
                        if node.get("role") == "option":
                            # Extract text/value
                            opt_text = node.get("text") or node.get("name")
                            # We need a value for the Enum.
                            # If no text/name, skip?
                            if opt_text:
                                options.append(opt_text)

                        # Recurse into groups/generic/listbox inside combobox
                        if node.get("children"):
                            collect_options(node["children"])

                # Collect from children
                collect_options(el.get("children", []))

                # Also collect from 'variants' (if normalized or manually set)
                # This supports inline definitions: ListBox(variants=["A", "B"])
                init_kwargs = el.get("init_kwargs", {})
                if "variants" in init_kwargs:
                    vars_val = init_kwargs["variants"]
                    if isinstance(vars_val, list):
                        options.extend(vars_val)
                    elif isinstance(vars_val, str):
                        options.append(vars_val)

                if options:
                    # Found options!
                    # Deduplicate preserving order
                    unique_options = list(dict.fromkeys(options))

                    if len(unique_options) > 0:
                        el["has_options_enum"] = True
                        el["options_values"] = unique_options

                        # Also, if it's a combobox, we might want to ensure it maps to Select or Dropdown class
                        # PageEditor maps combobox -> Select (or Dropdown if custom?)
                        # Logic needed: If basic structure -> Select? If complex -> Dropdown?
                        # For now, let PageEditor decide class, but we provide data for Enum.
                        pass

    def identify_text_enums(self, elements: List[Dict[str, Any]]) -> None:
        """
        Analyzes Text elements. If a Text element has a static 'text' value,
        we can promote it to use an Enum for that value.
        """
        for el in elements:
            role = el.get("role")
            text = el.get("text") or el.get("init_kwargs", {}).get("text")

            if el.get("children"):
                self.identify_text_enums(el["children"])

            if (
                role in ("text", "generic")
                and text
                and isinstance(text, str)
                and len(text) < 50
            ):
                el["has_text_enum"] = True
                el["text_enum_value"] = text
