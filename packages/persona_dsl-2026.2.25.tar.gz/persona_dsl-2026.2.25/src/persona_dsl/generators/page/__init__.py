from .generator import PageGenerator

__all__ = ["PageGenerator"]
