import ast
import re
from typing import Dict, List, Optional
from unidecode import unidecode
from persona_dsl.utils.naming import to_snake_case


class EnumStorage:
    """Хранит и переиспользует сгенерированные Enum для элементов страницы."""

    def __init__(self) -> None:
        self._enum_signatures: Dict[str, str] = {}
        self._enums_by_name: Dict[str, List[str]] = {}
        self._enum_defs: Dict[str, ast.ClassDef] = {}

    def _get_signature(self, options: List[str]) -> str:
        return "|".join(sorted(options))

    def _sanitize_name(self, name: str) -> str:
        # Basic sanitization
        clean = re.sub(r"[^a-zA-Z0-9_]", "", unidecode(name).replace(" ", "_"))
        if not clean:
            clean = "Dynamic"
        # Ensure starts with uppercase letter
        if clean[0].isdigit():
            clean = "E" + clean
        clean = clean[0].upper() + clean[1:]
        if not clean.endswith("Enum"):
            clean += "Enum"
        return clean

    def get_enum_name(self, base_name: str, options: List[str]) -> str:
        """Возвращает существующее имя Enum или регистрирует новое."""
        sig = self._get_signature(options)
        if sig in self._enum_signatures:
            return self._enum_signatures[sig]

        # Генерируем новое имя
        clean_name = self._sanitize_name(base_name)

        # Разрешение коллизий
        final_name = clean_name
        counter = 1
        while (
            final_name in self._enums_by_name
            and self._enums_by_name[final_name] != options
        ):
            counter += 1
            # Вставляем номер перед Enum, например Status2Enum
            base_part = clean_name[:-4]
            final_name = f"{base_part}{counter}Enum"

        self._enum_signatures[sig] = final_name
        self._enums_by_name[final_name] = options
        return final_name

    def generate_single_ast(self, enum_name: str) -> Optional[ast.ClassDef]:
        """Возвращает AST-узел для ранее зарегистрированного класса Enum."""
        if enum_name in self._enum_defs:
            return self._enum_defs[enum_name]

        options = self._enums_by_name.get(enum_name)
        if not options:
            return None

        body: List[ast.stmt] = []
        for opt in options:
            # Очистка ключа для Enum через базовый utils
            key = to_snake_case(str(opt)).upper()
            if not key:
                key = "OPTION"
            if key[0].isdigit():
                key = "OPT_" + key

            # assign
            assign = ast.Assign(
                targets=[ast.Name(id=key, ctx=ast.Store())],
                value=ast.Constant(value=opt),
                lineno=1,
            )
            body.append(assign)

        if not body:
            body.append(ast.Pass())

        class_def = ast.ClassDef(
            name=enum_name,
            bases=[
                ast.Name(id="str", ctx=ast.Load()),
                ast.Name(id="Enum", ctx=ast.Load()),
            ],
            keywords=[],
            body=body,
            decorator_list=[],
            type_params=[],
            lineno=1,
        )
        self._enum_defs[enum_name] = class_def
        return class_def

    def get_all_enums(self) -> Dict[str, List[str]]:
        return self._enums_by_name
