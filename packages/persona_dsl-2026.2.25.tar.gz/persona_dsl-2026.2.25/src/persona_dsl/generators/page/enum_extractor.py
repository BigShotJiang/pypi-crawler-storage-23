import ast
from typing import Dict


def extract_enums_from_code(code: str) -> Dict[str, Dict[str, Dict[str, str]]]:
    """
    Парсит код и возвращает структуру существующих Enum:
    { "PageClassName": { "EnumName": { "MEMBER": "value" } } }
    """
    result: Dict[str, Dict[str, Dict[str, str]]] = {}
    if not code.strip():
        return result

    try:
        tree = ast.parse(code)
    except SyntaxError:
        return result

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            page_name = node.name
            page_enums: Dict[str, Dict[str, str]] = {}

            # Ищем Enum рекурсивно внутри всего класса страницы
            for child in ast.walk(node):
                if isinstance(child, ast.ClassDef) and "Enum" in [
                    b.id for b in child.bases if isinstance(b, ast.Name)
                ]:
                    enum_dict = {}
                    for assign in child.body:
                        if (
                            isinstance(assign, ast.Assign)
                            and len(assign.targets) == 1
                            and isinstance(assign.targets[0], ast.Name)
                        ):
                            if isinstance(assign.value, ast.Constant):
                                enum_dict[assign.targets[0].id] = str(
                                    assign.value.value
                                )
                    if enum_dict:
                        page_enums[child.name] = enum_dict

            if page_enums:
                result[page_name] = page_enums

    return result
