import ast
import re
from typing import Any, Dict, List, Optional, Tuple, cast, Set

from persona_dsl.utils.naming import to_pascal_case, to_snake_case
from .enum_storage import EnumStorage


class CodeGenerator:
    """
    Handles generation of Python AST and source code from the elements tree.
    """

    def __init__(self, debug_mode: bool = False):
        self.debug_mode = debug_mode
        self._seen_test_ids: List[str] = []  # Used for prefix calc

    def set_seen_test_ids(self, ids: List[str]) -> None:
        self._seen_test_ids = ids

    def generate_code(
        self,
        elements_tree: List[Dict[str, Any]],
        class_name: str,
        page_path: Optional[str] = None,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
        component_overrides: Optional[Dict[str, Tuple[str, str]]] = None,
        base_class: str = "Page",
        extra_init_stmts: Optional[List[ast.stmt]] = None,
        existing_enums: Optional[Dict[str, Dict[str, Dict[str, str]]]] = None,
        existing_local_vars: Optional[Dict[str, Any]] = None,
        enum_storage: Optional[EnumStorage] = None,
    ) -> str:

        # 1. Imports
        import_nodes: List[ast.stmt] = []

        # ... (import collection logic remains, but we add Enum if enum_storage has enums) ...
        # Assume existing import logic works, but ensure 'Enum' is imported if needed.

        # 2. Main Page Class
        main_class_def = self._generate_class_ast(
            class_name=class_name,
            base_class=base_class,
            elements=elements_tree,
            parent_var="self",
            leaf_overrides=leaf_overrides or {},
            leaf_seen={},
            is_root_page=True,
            aria_snapshot_path=aria_snapshot_path,
            screenshot_path=screenshot_path,
            page_path=page_path,
            extra_init_stmts=extra_init_stmts,
            existing_enums=existing_enums,
            existing_local_vars=existing_local_vars,
            enum_storage=enum_storage,
        )

        # 3. Imports Generation (Simplified for brevity in diff, but retaining logic)
        # Collect imports...
        used_classes = {base_class}
        has_enums = False
        if enum_storage and enum_storage._enum_defs:
            has_enums = True

        # ... (copying existing efficient collection logic) ...
        def collect_used_classes(els: List[Dict[str, Any]]) -> None:
            nonlocal has_enums
            for el in els:
                if (
                    el.get("explicit_enum_name")
                    or el.get("has_options_enum")
                    or el.get("has_columns_enum")
                ):
                    has_enums = True

                # Handle Table Row Prototype imports (Recurse into hidden row structure)
                if el.get("has_row_prototype"):
                    used_classes.add("TableRow")
                    row_proto = el.get("row_prototype")
                    if row_proto and isinstance(row_proto, dict):
                        collect_used_classes(row_proto.get("children", []))
                # ... existing logic ...
                if el.get("custom_import_module"):
                    continue
                if el.get("class_name_ref"):
                    role = el.get("role")
                    if role:
                        from persona_dsl.editors.page import PageEditor

                        used_classes.add(PageEditor.get_class_name_for_role(role))
                    else:
                        used_classes.add("Element")
                    if el.get("children"):
                        collect_used_classes(el["children"])
                    continue

                if el.get("forced_class_name"):
                    used_classes.add(el["forced_class_name"])
                else:
                    role = el.get("role")
                    if role:
                        from persona_dsl.editors.page import PageEditor

                        used_classes.add(PageEditor.get_class_name_for_role(role))
                    else:
                        used_classes.add("Element")

                if el.get("children"):
                    collect_used_classes(el["children"])

        collect_used_classes(elements_tree)

        sorted_imports = sorted(list(used_classes))

        imports_stmt = ast.ImportFrom(
            module="persona_dsl.pages",
            names=[ast.alias(name=cls_name) for cls_name in sorted_imports],
            level=0,
        )
        import_nodes.append(imports_stmt)

        # Pathlib imports...
        uses_pathlib = False
        # ... (pathlib check) ...
        if not extra_init_stmts and (
            page_path or aria_snapshot_path or screenshot_path
        ):
            uses_pathlib = True
        if uses_pathlib:
            import_nodes.append(
                ast.ImportFrom(
                    module="pathlib", names=[ast.alias(name="PosixPath")], level=0
                )
            )

        if has_enums:
            import_nodes.append(
                ast.ImportFrom(module="enum", names=[ast.alias(name="Enum")], level=0)
            )

        # Custom Component Imports (from deep update / registry)
        custom_imports_map: Dict[str, set[str]] = {}

        def collect_custom_imports(els: List[Dict[str, Any]]) -> None:
            for el in els:
                mod = el.get("custom_import_module")
                cls_obj = el.get("class")
                if cls_obj and hasattr(cls_obj, "__name__"):
                    cls = cls_obj.__name__
                else:
                    cls = str(cls_obj) if cls_obj else ""

                if mod and cls:
                    if mod not in custom_imports_map:
                        custom_imports_map[mod] = set()
                    custom_imports_map[mod].add(cls)

                if el.get("children"):
                    collect_custom_imports(el["children"])

        collect_custom_imports(elements_tree)

        for mod, classes in custom_imports_map.items():
            sorted_cls = sorted(list(classes))
            imp = ast.ImportFrom(
                module=mod, names=[ast.alias(name=c) for c in sorted_cls], level=0
            )
            import_nodes.append(imp)

        # 4. Explicit Enums Generation (Class Level - Shared Only)
        # REMOVED: All Enums are now generated inline at first usage.
        enum_definitions: List[ast.stmt] = []

        # Inject Enums into the class body (before __init__)
        main_class_def.body = enum_definitions + main_class_def.body

        # 5. Assemble Module
        module_body: List[ast.stmt] = []
        module_body.extend(import_nodes)
        # module_body.extend(enum_definitions) # REMOVED: Now in class body
        module_body.append(main_class_def)

        module = ast.Module(body=module_body, type_ignores=[])
        code = ast.unparse(ast.fix_missing_locations(module))

        try:
            import black

            return black.format_str(code, mode=black.Mode())
        except Exception:
            return code

    def _generate_standalone_enum(
        self, class_name: str, members: dict[str, str]
    ) -> ast.ClassDef:
        """
        Generates a standalone Enum class definition.
        Example:
            class Title(str, Enum):
                 TEXT = "Title Text"
        """
        bases = [
            ast.Name(id="str", ctx=ast.Load()),
            ast.Name(id="Enum", ctx=ast.Load()),
        ]

        class_body = []
        for name, value in members.items():
            assign = ast.Assign(
                targets=[ast.Name(id=name, ctx=ast.Store())],
                value=ast.Constant(value=value),
                lineno=0,
            )
            class_body.append(assign)

        return ast.ClassDef(
            name=class_name,
            bases=cast(List[ast.expr], bases),
            keywords=[],
            body=cast(List[ast.stmt], class_body),
            decorator_list=[],
            type_params=[],
        )

    def _generate_class_ast(
        self,
        class_name: str,
        base_class: str,
        elements: List[Dict[str, Any]],
        parent_var: str,
        leaf_overrides: Dict[str, List[str]],
        leaf_seen: Dict[str, int],
        is_root_page: bool = False,
        aria_snapshot_path: Optional[str] = None,
        screenshot_path: Optional[str] = None,
        page_path: Optional[str] = None,
        nested_row_info: Optional[Dict[str, Any]] = None,
        extra_init_stmts: Optional[List[ast.stmt]] = None,
        current_element_context: Optional[Dict[str, Any]] = None,
        suppress_child_assignments: bool = False,  # If True, skip generating self.child = ...
        inject_variants_enum: bool = False,  # If True, pass variants=list(self.Options) to super().__init__
        existing_enums: Optional[Dict[str, Dict[str, Dict[str, str]]]] = None,
        existing_local_vars: Optional[Dict[str, Any]] = None,
        enum_storage: Optional[EnumStorage] = None,
        root_class_name: Optional[str] = None,
    ) -> ast.ClassDef:

        # Body of __init__
        init_body: List[Any] = []

        # super().__init__()
        # If it's a component (not root page), pass **kwargs to super
        if is_root_page:
            super_call = ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Call(
                            func=ast.Name(id="super", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                        attr="__init__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[],
                )
            )
            init_body.append(super_call)
        else:
            # Component: def __init__(self, **kwargs): super().__init__(**kwargs)
            super_call = ast.Expr(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Call(
                            func=ast.Name(id="super", ctx=ast.Load()),
                            args=[],
                            keywords=[],
                        ),
                        attr="__init__",
                        ctx=ast.Load(),
                    ),
                    args=[],
                    keywords=[
                        ast.keyword(
                            arg=None, value=ast.Name(id="kwargs", ctx=ast.Load())
                        )
                    ],
                )
            )

        # Inject variants argument if requested (for simplified Lists)
        if inject_variants_enum:
            # variants=list(self.Options)
            # We access super_call.value (Expr.value -> Call)
            # Call.keywords is a list
            variants_call = ast.Call(
                func=ast.Name(id="list", ctx=ast.Load()),
                args=[
                    ast.Attribute(
                        value=ast.Name(id="self", ctx=ast.Load()),
                        attr="Options",
                        ctx=ast.Load(),
                    )
                ],
                keywords=[],
            )
            # super_call is ast.Expr, value is ast.Call
            cast(ast.Call, super_call.value).keywords.insert(
                0, ast.keyword(arg="variants", value=variants_call)
            )

        init_body.append(super_call)

        # Inject Extra Init Statements (e.g. preserved attributes)
        if extra_init_stmts:
            init_body.extend(extra_init_stmts)

        inner_class_defs = []

        # --- RECURSIVELY GENERATE NESTED CLASSES (Sections/Complex) ---

        # Any elements that need promotion (Sections, Tables, Enums) become inner classes here.

        # --- INNER ENUM GENERATION (for promoted classes) ---
        if current_element_context:
            el_context = current_element_context
            # DEBUG
            # print(f"DEBUG: Context Name={el_context.get('name')}, has_options={el_context.get('has_options_enum')}, options={el_context.get('options_values')}")

            # Text Enum
            if el_context.get("has_text_enum") and el_context.get("text_enum_value"):
                text_val = el_context["text_enum_value"]

                # Member Name
                member_name = to_snake_case(text_val).upper()
                if len(member_name) > 30:
                    member_name = member_name[:30]
                if not member_name:
                    member_name = "VALUE"
                if member_name[0].isdigit():
                    member_name = f"TXT_{member_name}"
                member_name = re.sub(r"\W|^(?=\d)", "_", member_name)

                members = [
                    ast.Assign(
                        targets=[ast.Name(id=member_name, ctx=ast.Store())],
                        value=ast.Constant(value=text_val),
                    )
                ]

                enum_defs = ast.ClassDef(
                    name="Values",  # Standard name for inner text enum
                    bases=[
                        ast.Name(id="str", ctx=ast.Load()),
                        ast.Name(id="Enum", ctx=ast.Load()),
                    ],
                    keywords=[],
                    body=cast(List[ast.stmt], members),
                    decorator_list=[],
                    type_params=[],
                )
                inner_class_defs.append(enum_defs)

            # Options Enum
            if el_context.get("has_options_enum") and el_context.get("options_values"):
                # Assuming options collected
                options = el_context["options_values"]

                # MERGE LOGIC: Check existing enums
                # Structure: existing_enums[class_name][enum_name][value] -> member_name
                existing_members = {}
                if existing_enums:
                    # DEBUG
                    # print(f"DEBUG: Checking existing_enums for class='{class_name}', Enum='Options'")
                    # print(f"DEBUG: Available classes: {list(existing_enums.keys())}")
                    existing_members = existing_enums.get(class_name, {}).get(
                        "Options", {}
                    )
                    # if existing_members:
                    #    print(f"DEBUG: Found existing members: {existing_members}")

                members = []
                # 1. Add current options (using existing names if available)
                # DEBUG
                # print(f"DEBUG: Processing options: {options}")
                for val in options:
                    if val in existing_members:
                        m_name = existing_members[val]
                    else:
                        m_name = to_snake_case(val).upper()
                        if not m_name:
                            m_name = "VAL"
                        if m_name[0].isdigit():
                            m_name = f"OPT_{m_name}"

                    m_name = re.sub(r"\W|^(?=\d)", "_", m_name)

                    members.append(
                        ast.Assign(
                            targets=[ast.Name(id=m_name, ctx=ast.Store())],
                            value=ast.Constant(value=val),
                        )
                    )

                # 2. Add existing options not present in current scan (Accumulation)
                current_vals = set(options)
                for exist_val, exist_name in existing_members.items():
                    if exist_val not in current_vals:
                        members.append(
                            ast.Assign(
                                targets=[ast.Name(id=exist_name, ctx=ast.Store())],
                                value=ast.Constant(value=exist_val),
                            )
                        )

                enum_defs = ast.ClassDef(
                    name="Options",  # Standard name? Or ListboxOptions? "Options" is generic.
                    bases=[
                        ast.Name(id="str", ctx=ast.Load()),
                        ast.Name(id="Enum", ctx=ast.Load()),
                    ],
                    keywords=[],
                    body=cast(List[ast.stmt], members),
                    decorator_list=[],
                    type_params=[],
                )
                inner_class_defs.append(enum_defs)

        # nested_row_info is obsolete for Generic Tables; we no longer generate Row classes

        # Paths (only for root page)
        # Only add defaults if we didn't inject them via extra_init_stmts
        # We check simply if extra_init_stmts is empty/None
        if is_root_page and not extra_init_stmts:
            if page_path:
                init_body.append(
                    ast.Assign(
                        targets=[self._create_attribute_chain("self.expected_path")],
                        value=ast.Call(
                            func=ast.Name(id="PosixPath", ctx=ast.Load()),
                            args=[ast.Constant(value=str(page_path))],
                            keywords=[],
                        ),
                    )
                )
            if aria_snapshot_path:
                init_body.append(
                    ast.Assign(
                        targets=[
                            self._create_attribute_chain(
                                "self.static_aria_snapshot_path"
                            )
                        ],
                        value=ast.Constant(value=aria_snapshot_path),
                    )
                )
            if screenshot_path:
                init_body.append(
                    ast.Assign(
                        targets=[
                            self._create_attribute_chain("self.static_screenshot_path")
                        ],
                        value=ast.Constant(value=screenshot_path),
                    )
                )

        # Shared collector for text values in this class scope
        # Elements Generation

        # If suppress_child_assignments is True, we pass empty list to skip child generation
        # BUT we still wanted Enums (inner_class_defs) which were generated above using 'elements'.

        # If suppress_child_assignments is True, we pass empty list to skip child generation
        # BUT we still wanted Enums (inner_class_defs) which were generated above using 'elements'.

        # Determine root class name for Enums (if not passed, and we are root, it is us)
        # If we are root page, we ARE the root class.
        actual_root_class: Optional[str]
        if is_root_page:
            actual_root_class = class_name
        else:
            actual_root_class = root_class_name

        element_stmts = self._build_init_body_ast(
            elements,
            parent_var,
            [],
            {},
            leaf_overrides,
            leaf_seen.copy(),
            existing_enums=existing_enums,
            existing_local_vars=existing_local_vars,
            enum_storage=enum_storage,
            root_class_name=actual_root_class,
        )
        init_body.extend(element_stmts)

        # Determine kwonlyargs for __init__
        # ERROR: kwonlyargs means `def foo(*, kwargs)`, combined with `**kwargs` this is invalid: `def foo(*, kwargs, **kwargs)`.
        # We want `def foo(**kwargs)`. So kwonlyargs should be empty of kwargs.
        # But we pass `kw_defaults=[None]`.

        # Correct approach for def __init__(self, **kwargs):
        # args=[self], vararg=None, kwonlyargs=[], kwarg=kwargs

        # 4. Define __init__ method
        init_method = ast.FunctionDef(
            name="__init__",
            args=ast.arguments(
                posonlyargs=[],
                args=[ast.arg(arg="self")],
                vararg=None,
                kwonlyargs=[],  # No keyword-only args
                kw_defaults=[],
                kwarg=ast.arg(arg="kwargs") if not is_root_page else None,
                defaults=[],
            ),
            body=init_body,  # type: ignore
            decorator_list=[],
            returns=ast.Name(id="None", ctx=ast.Load()),
        )

        # 1. Class-Level Constants (Text)
        # Removed as per new requirement: Local Constants in __init__
        class_body: List[ast.AST] = []

        # 5. Define Class
        # Combine [__init__]
        # class_body = [init_method] # Removed as we initialized it above
        # Moved to bottom for better readability of the Page Object
        class_body.append(init_method)

        # Handle Table Row Prototype
        if current_element_context and current_element_context.get("has_row_prototype"):
            row_proto = current_element_context.get("row_prototype")
            if row_proto and isinstance(row_proto, dict):
                # Force is_complex_section to ensure wrapper generation
                row_proto["is_complex_section"] = True
                row_class_name = current_element_context.get("row_class_name", "Row")

                row_class_def = self._generate_class_ast(
                    class_name=cast(str, row_class_name),
                    base_class="TableRow",
                    elements=row_proto.get("children", []),
                    parent_var="self",
                    leaf_overrides=leaf_overrides,
                    leaf_seen={},
                    is_root_page=False,
                    current_element_context=row_proto,
                    existing_enums=existing_enums,
                    existing_local_vars=existing_local_vars,
                    enum_storage=enum_storage,
                )
                inner_class_defs.append(row_class_def)

        class_body.extend(inner_class_defs)

        class_def = ast.ClassDef(
            name=class_name,
            bases=[ast.Name(id=base_class, ctx=ast.Load())],
            keywords=[],
            body=cast(List[ast.stmt], class_body),
            decorator_list=[],
            type_params=[],  # Added in py3.12
        )

        return class_def

    def _build_init_body_ast(
        self,
        elements: List[Dict[str, Any]],
        parent_var: str,
        path_stack: List[str],
        context: Dict[str, Any],
        leaf_overrides: Dict[str, List[str]],
        leaf_seen: Dict[str, int],
        existing_enums: Optional[Dict[str, Dict[str, Dict[str, str]]]] = None,
        existing_local_vars: Optional[Dict[str, Any]] = None,
        enum_storage: Optional[EnumStorage] = None,
        root_class_name: Optional[str] = None,
    ) -> List[ast.AST]:
        """
        Рекурсивно строит список AST-инструкций для __init__.
        """
        stmts: List[Any] = []

        # Track local text constants to reuse variables: value -> var_name
        local_text_values: Dict[str, str] = {}

        # Track defined enums in this scope to reuse them
        defined_enums: Set[str] = set()

        # Seed from existing local vars (Reverse mapping: Value -> Name)
        if existing_local_vars:
            for name, val in existing_local_vars.items():
                if isinstance(val, str):
                    local_text_values[val] = name
                    # Also mark name as seen to avoid collisions
                    leaf_seen[name] = 1

        for el in elements:
            role = el["role"]
            var_name = el["var_name"]
            class_name_ref = el.get("class_name_ref")  # If generated nested class
            base_class = None
            custom_import_name = None
            if el.get("custom_import_module"):
                # It's a custom imported component
                cls_obj = el.get("class")
                if cls_obj and hasattr(cls_obj, "__name__"):
                    custom_import_name = cls_obj.__name__
                else:
                    custom_import_name = str(cls_obj) if cls_obj else None

            # Check duplication in this scope
            reserved_names = {
                "text",
                "name",
                "role",
                "locator",
                "click",
                "fill",
                "press",
                "check",
                "uncheck",
                "select_option",
                "hover",
                "wait_for",
                "expect",
                "is_visible",
                "is_hidden",
                "parent",
                "root",
                "page",
            }

            # If var_name conflicts with reserved names, rename it immediately
            if var_name in reserved_names:
                var_name = f"{var_name}_element"

            if var_name in leaf_seen:
                leaf_seen[var_name] += 1
                var_name = f"{var_name}_{leaf_seen[var_name]}"
            else:
                leaf_seen[var_name] = 1  # Start count

            # Determine class name via ElementEditor (Single Source of Truth)
            # This ensures that class name and argument validation use the exact same logic.
            from persona_dsl.editors.page import PageEditor

            element_class = "Element"
            if el.get("forced_class_name"):
                element_class = el["forced_class_name"]
            elif custom_import_name:
                element_class = custom_import_name
            elif class_name_ref:
                element_class = class_name_ref
            else:
                # Use ElementEditor to map role -> ClassName (e.g. 'menu' -> 'Menu')
                element_class = PageEditor.get_class_name_for_role(role)

            # Build Definitions
            flat_def = el["init_kwargs"].copy()
            flat_def["role"] = role
            flat_def["var_name"] = var_name
            # Ensure 'name' argument matches the (possibly renamed) var_name
            # to avoid conflicts with parent attributes (e.g. parent.text vs child named 'text')
            flat_def["name"] = var_name

            # For wrappers (class_name_ref), we technically validate against the base class (e.g. Menu)
            # But get_class_name_for_role handles the base mapping for standard roles.
            # If class_name_ref is a custom Table row, introspection on that class works too.
            schema_type = element_class
            if class_name_ref and role:
                # If it's a wrapper, we might want to check the Role's base class for args
                # e.g. MyMenu(Menu).
                base_for_role = PageEditor.get_class_name_for_role(role)
                if base_for_role != "Element":
                    schema_type = base_for_role

            # --- LOCAL CLASS GENERATION (Mixed Mode) ---
            # If the element needs a class (Text or Options Enum), we generate it RIGHT HERE.

            local_class_def = None
            generated_class_name = None
            is_standalone_enum = False
            variants_param_node: Optional[ast.AST] = (
                None  # To store the AST node for variants argument
            )

            # [NEW] EXPLICIT ENUM SUPPORT
            if el.get("explicit_enum_name") and enum_storage:
                enum_name = el["explicit_enum_name"]

                # Check usage count (DEPRECATED - Removed)
                pass

                # Check if already defined in this scope
                if enum_name not in defined_enums:
                    # INLINE GENERATION (First usage in this scope)
                    enum_class_def = enum_storage.generate_single_ast(enum_name)
                    if enum_class_def:
                        stmts.append(enum_class_def)
                        defined_enums.add(enum_name)

                # Reference by local name
                variants_param_node = ast.Name(id=enum_name, ctx=ast.Load())

            # 1. Determine if we need a local class (WRAPPER)

            # CASE B: Options Enum (Complex Element or just Options) - Fallback
            # REFACTOR: Default to Inline List (variants=[...]) for simplicity.
            # Only use Wrapper Class if existing Enums imply custom renaming (Accumulation) OR if it's a Complex Section.

            # 1. Determine Class Name if needed (for Enum or Wrapper)
            if (
                el.get("has_options_enum") or el.get("is_complex_section")
            ) and not el.get("explicit_enum_name"):
                generated_class_name = to_pascal_case(el["var_name"])
                if generated_class_name and generated_class_name[0].isdigit():
                    generated_class_name = f"Text{generated_class_name}"

                role = el.get("role")
                base_class = (
                    PageEditor.get_class_name_for_role(role) if role else "Element"
                )

                if generated_class_name == base_class:
                    generated_class_name = f"{generated_class_name}Component"

            # Ensure base_class is set if we force wrapper later
            if base_class is None:
                role = el.get("role")
                base_class = (
                    PageEditor.get_class_name_for_role(role) if role else "Element"
                )

            # 2. Check if we should use Inline List or Wrapper Cls
            # User preference: Explicit Enums for variants (Transliterated) AND Grouping
            use_wrapper = False

            # Logic: Always use wrapper if we have options to generate an Enum (Legacy / Local)
            if (
                el.get("has_options_enum")
                and el.get("options_values")
                and not el.get("explicit_enum_name")
            ):
                use_wrapper = False

            # Logic: Always use wrapper if it is a complex section (grouping)
            if el.get("is_complex_section"):
                use_wrapper = True

            # Logic: If explicit enum, we NEVER use wrapper for just options (we use global enum)
            if (
                el.get("explicit_enum_name")
                and not el.get("is_complex_section")
                and not el.get("class_name_ref")
            ):
                use_wrapper = False

            # Logic: If class_name_ref is explicit, we MUST use wrapper and that name
            if el.get("class_name_ref"):
                use_wrapper = True
                generated_class_name = el["class_name_ref"]

            # Also preserve existing behavior
            if existing_enums and generated_class_name:
                cls_enums = existing_enums.get(generated_class_name, {})
                if "Options" in cls_enums:
                    if el.get("is_complex_section"):
                        use_wrapper = True

            # Determine injection flags
            should_inject_enum = bool(
                el.get("has_options_enum")
                and el.get("options_values")
                and not el.get("explicit_enum_name")
            )
            should_suppress_children = should_inject_enum

            if use_wrapper:
                # Ensure we have a class name
                if not generated_class_name:
                    generated_class_name = to_pascal_case(var_name)
                if not generated_class_name:
                    generated_class_name = f"Element_{var_name}"

                # Generate the Wrapper Class Body
                # suppress_child_assignments: Don't generate self.child = ... (if used as Enum)
                # inject_variants_enum: Pass variants=list(self.Options) to super.__init__ (if has Enum)
                local_class_def = self._generate_class_ast(
                    class_name=generated_class_name,
                    base_class=base_class,
                    elements=el.get("children", []),
                    parent_var="self",
                    leaf_overrides=leaf_overrides,
                    leaf_seen={},
                    is_root_page=False,
                    current_element_context=el,
                    suppress_child_assignments=should_suppress_children,
                    inject_variants_enum=should_inject_enum,
                    existing_enums=existing_enums,
                    existing_local_vars=existing_local_vars,
                    enum_storage=enum_storage,
                    root_class_name=root_class_name,
                )

                stmts.append(local_class_def)
            else:
                # INLINE GENERATION (List or Local Enum)
                # Only if NOT explicit enum

                if not el.get("explicit_enum_name"):
                    options = el.get("options_values", [])

                    if options and el.get("has_options_enum"):
                        # GENERATE LIST CONSTANT (Simpler than Enum Class)
                        # VAR_NAME_VARIANTS = ["Val1", "Val2"]
                        list_name = f"{to_snake_case(var_name).upper()}_VARIANTS"

                        # Deduplicate options
                        unique_options = list(dict.fromkeys(options))

                        list_assign = ast.Assign(
                            targets=[ast.Name(id=list_name, ctx=ast.Store())],
                            value=ast.List(
                                elts=[ast.Constant(value=o) for o in unique_options],
                                ctx=ast.Load(),
                            ),
                        )
                        stmts.append(list_assign)
                        variants_param_node = ast.Name(id=list_name, ctx=ast.Load())

                    elif options:
                        variants_param_node = ast.List(
                            elts=[ast.Constant(value=o) for o in options],
                            ctx=ast.Load(),
                        )
                    # We do NOT generate local class.

            # --- EXTRACT TABLE COLUMNS ENUM ---
            # If element is a Table without an explicit enum, create an inline Columns Enum
            if el.get("has_columns_enum") and el.get("columns_values"):
                columns = el["columns_values"]
                members = []
                for val in columns:
                    m_name = to_snake_case(val).upper()
                    if not m_name:
                        m_name = "COL"
                    if m_name[0].isdigit():
                        m_name = f"COL_{m_name}"

                    m_name = re.sub(r"\W|^(?=\d)", "_", m_name)

                    members.append(
                        ast.Assign(
                            targets=[ast.Name(id=m_name, ctx=ast.Store())],
                            value=ast.Constant(value=val),
                        )
                    )

                if members:
                    enum_name = f"{to_pascal_case(el.get('var_name', 'table'))}Columns"
                    el["generated_columns_enum_name"] = (
                        enum_name  # Save for kwargs later
                    )

                    # Prevent redeclaration if multiple tables use same name in edge cases
                    if enum_name not in defined_enums:
                        enum_defs = ast.ClassDef(
                            name=enum_name,
                            bases=[
                                ast.Name(id="str", ctx=ast.Load()),
                                ast.Name(id="Enum", ctx=ast.Load()),
                            ],
                            keywords=[],
                            body=cast(List[ast.stmt], members),
                            decorator_list=[],
                            type_params=[],
                        )
                        stmts.append(enum_defs)
                        defined_enums.add(enum_name)

            # Note: We determine func_node later, but we needed local_class_def for kwargs

            init_kwargs = PageEditor.normalize_element_args(flat_def, schema_type)
            if variants_param_node:
                # If explicit enum, utilize 'Options' param name?
                # Element init expects 'variants'. Logic in elements.py handles Enum passed to variants.
                # So `variants=MyEnum` is correct.
                init_kwargs["variants"] = variants_param_node

            if el.get("generated_columns_enum_name"):
                init_kwargs["columns"] = ast.Name(
                    id=el["generated_columns_enum_name"], ctx=ast.Load()
                )

            # --- OPTIONS ENUM ---
            # If we generated a custom class (class_name_ref), it has the Enum inside it as 'Options'
            if (
                class_name_ref
                and el.get("has_options_enum")
                and el.get("options_values")
                and not el.get("explicit_enum_name")
            ):
                # Access: self.ClassName.Options (Nested Class)
                enum_access = ast.Attribute(
                    value=ast.Attribute(
                        value=ast.Name(id="self", ctx=ast.Load()),
                        attr=class_name_ref,
                        ctx=ast.Load(),
                    ),
                    attr="Options",
                    ctx=ast.Load(),
                )
                init_kwargs["options_enum"] = enum_access

            # --- TEXT ENUM ---
            # If we promoted this to a class, it has 'Values' inside.
            # --- TEXT ENUM (Component Strategy) ---
            # The element is promoted to a class, so we access its internal Values enum.
            # --- TEXT LITERAL (Fallback/Default) ---
            # Wait, we need to handle TEXT ENUM access here before the loop.

            # [NEW] Skip local constant generation if Explicit Enum is used
            # Unless it's a specific 'text' value?
            # If explicit enum is used, we usually don't set 'text' unless it's a specific default value.
            # But normally 'variants' defines the set.

            # --- LOCAL CONSTANTS (Replacing Text Enum) ---
            # Detect text values (either promoted enum or literal) and lift to local variable
            # Detect text values (either promoted enum or literal) and lift to local variable
            text_val = None

            # If explicit enum, we generally don't utilize local constants for the *value* unless it's a default.
            # But let's preserve existing behavior for non-variant text args.

            if not el.get("explicit_enum_name"):
                text_arg_key = "text"  # Default to 'text' for backward compat, but switch to 'variants' if needed

                if el.get("has_text_enum") and el.get("text_enum_value"):
                    text_val = el["text_enum_value"]
                elif isinstance(init_kwargs.get("text"), str):
                    text_val = init_kwargs["text"]
                elif isinstance(init_kwargs.get("variants"), str):
                    text_val = init_kwargs["variants"]
                    text_arg_key = "variants"

                if text_val:
                    if text_val in local_text_values:
                        const_name = local_text_values[text_val]
                    else:
                        # Generate Name
                        raw_snake = to_snake_case(text_val).upper()
                        if not raw_snake:
                            raw_snake = "VAL"

                        const_name = raw_snake
                        # Use TXT prefix only if name starts with digit
                        if const_name and const_name[0].isdigit():
                            const_name = f"TXT_{const_name}"

                        const_name = re.sub(r"\W|^(?=\d)", "_", const_name)
                        if len(const_name) > 40:
                            const_name = const_name[:40]

                        # Check collisions
                        base_name = const_name
                        acc = 1
                        while (
                            const_name in leaf_seen
                            or const_name in local_text_values.values()
                        ):
                            const_name = f"{base_name}_{acc}"
                            acc += 1

                        local_text_values[text_val] = const_name
                        leaf_seen[const_name] = 1  # Reserve this name

                        # Generate Assignment: txt_foo = "Foo"
                        stmts.append(
                            ast.Assign(
                                targets=[ast.Name(id=const_name, ctx=ast.Store())],
                                value=ast.Constant(value=text_val),
                            )
                        )

                    # Use variable reference
                    init_kwargs[text_arg_key] = ast.Name(id=const_name, ctx=ast.Load())

            # Helper to check if value is an AST node (for dynamic overrides)
            def is_ast_node(val: Any) -> bool:
                return isinstance(val, ast.AST)

            keywords = []
            for k, v in init_kwargs.items():
                if is_ast_node(v):
                    val_node = v
                else:
                    val_node = ast.Constant(value=v)
                    # If value is a class definition (string ref), we need ast.Name
                    if k == "row_type":
                        val_node = ast.Name(id=v, ctx=ast.Load())

                    elif k == "options_enum":
                        # It's a nested class, so access via self? NO, now it's local.
                        # If we generated a local class for options, it's 'ClassName.Options'
                        if local_class_def:
                            val_node = ast.Attribute(
                                value=ast.Name(
                                    id=cast(str, generated_class_name), ctx=ast.Load()
                                ),
                                attr=v,  # v is "Options"
                                ctx=ast.Load(),
                            )
                        else:
                            # Fallback to self.ClassName.Options if not local (e.g. complex section?)
                            val_node = ast.Attribute(
                                value=ast.Name(id="self", ctx=ast.Load()),
                                attr=v,
                                ctx=ast.Load(),
                            )

                keywords.append(ast.keyword(arg=k, value=val_node))

            # Call Construction: ElementClass(name="...", ...)
            # If we generated a local class (WRAPPER), we use its name directly: LocalClass(...)
            # If we generated a Standalone Enum, we use the STANDARD element_class (e.g. Text)
            # Otherwise we use the standard element_class

            if local_class_def and not is_standalone_enum:
                # Wrapper Class
                func_node: ast.expr = ast.Name(
                    id=cast(str, generated_class_name), ctx=ast.Load()
                )
                class_name_ref = generated_class_name

            elif class_name_ref:
                # Fallback for complex sections if they are still handled via inner_classes (which we removed, but just in case)
                func_node = ast.Attribute(
                    value=ast.Name(id="self", ctx=ast.Load()),
                    attr=element_class,
                    ctx=ast.Load(),
                )
            else:
                # Standard Element (including Standalone Enum case)
                func_node = ast.Name(id=element_class, ctx=ast.Load())

            element_call = ast.Call(
                func=func_node,
                args=[],
                keywords=keywords,
            )

            # Check for Unstable Locator
            # If no text, no accessible name, no test_id, no placeholder, and NO index -> Unstable?
            # Elements with explicit index are stable by definition (they target structural position).
            has_stable_locator = any(
                k in init_kwargs
                for k in [
                    "text",
                    "accessible_name",
                    "test_id",
                    "placeholder",
                    "locator",
                    "index",
                    "column_header",
                    "aria_ref",
                ]
            )
            if not has_stable_locator and role not in [
                "document",
                "generic",
                "row",
                "rowgroup",
            ]:  # row/rowgroup often structural only
                # Add TODO comment
                stmts.append(
                    ast.Expr(value=ast.Constant(value="TODO: Unstable Locator"))
                )

            # Parent Add: self.parent.add_element(...)
            # If parent_var is "self", direct. If "self.banner", also direct.

            # Smart Preservation Override Check
            # If this element corresponds to a manually written assignment in leaf_overrides,
            # we try to preserve that EXACT assignment AST?
            # Or simplified: if 'banner' exists in leaf_overrides, we check if we should skip?
            # Current logic: leaf_overrides used for 'leaf' fields match.
            # Impl: If we have overrides, we might need complex matching.
            # For now standard generation.

            add_call = ast.Call(
                func=ast.Attribute(
                    value=(
                        ast.Name(id=parent_var, ctx=ast.Load())
                        if "." not in parent_var
                        else self._create_attribute_chain(parent_var)
                    ),
                    attr="add_element",
                    ctx=ast.Load(),
                ),
                args=[element_call],
                keywords=[],
            )

            # Assign: parent_var.var_name = ...
            # target_value = ast.Name(id="self", ctx=ast.Load())
            if parent_var != "self":
                # target_value = self._create_attribute_chain(parent_var)
                pass

            # Note: ast.Assign targets require ctx=Store() on the final attribute
            # _create_attribute_chain returns separate nodes with Load().
            # We need to construct the Store() target manually.
            if parent_var == "self":
                target_node = ast.Attribute(
                    value=ast.Name(id="self", ctx=ast.Load()),
                    attr=var_name,
                    ctx=ast.Store(),
                )
            else:
                # parent_var is e.g. "self.foo", we want "self.foo.var_name"
                # We reuse _create_attribute_chain for "self.foo" (Load), then add attr.
                parent_node = self._create_attribute_chain(parent_var)
                target_node = ast.Attribute(
                    value=parent_node, attr=var_name, ctx=ast.Store()
                )

            assign = ast.Assign(targets=[target_node], value=add_call)

            stmts.append(assign)

            # Recursion
            if not custom_import_name and not class_name_ref:
                # Standard element, generate children appended to it
                new_parent = (
                    f"{parent_var}.{var_name}"
                    if parent_var != "self"
                    else f"self.{var_name}"
                )

                # COLLAPSING LOGIC:
                # If we generated an options_enum, we assume the children are covered by it
                # and do NOT need to be generated as individual fields.
                should_recurse = True
                if el.get("has_options_enum") and el.get("options_values"):
                    should_recurse = False

                if el["children"] and should_recurse:
                    # Create NEW scope for children names properties
                    child_seen: Dict[str, Any] = {}
                    child_stmts = self._build_init_body_ast(
                        el["children"],
                        new_parent,
                        path_stack + [var_name],
                        context,
                        leaf_overrides,
                        child_seen,  # Pass new scope
                        existing_enums=existing_enums,
                        existing_local_vars=existing_local_vars,
                        enum_storage=enum_storage,
                        root_class_name=root_class_name,
                    )
                    stmts.extend(child_stmts)

        return stmts

    def _create_attribute_chain(self, dot_path: str) -> ast.expr:
        parts = dot_path.split(".")
        if len(parts) == 1:
            return ast.Name(id=parts[0], ctx=ast.Load())

        value: ast.expr = ast.Name(id=parts[0], ctx=ast.Load())
        for part in parts[1:]:
            value = ast.Attribute(value=value, attr=part, ctx=ast.Load())
        return value

    def extract_field_mappings(self, class_node: ast.ClassDef) -> Dict[str, List[str]]:
        """
        Анализирует AST существующего класса и находит маппинг:
        var_name -> [locator_chain] (?)

        For now: returns map of defined fields to detect prescence.
        """
        mappings: Dict[str, Any] = {}

        init_method = next(
            (
                n
                for n in class_node.body
                if isinstance(n, ast.FunctionDef) and n.name == "__init__"
            ),
            None,
        )
        if not init_method:
            return {}

        for stmt in init_method.body:
            if isinstance(stmt, ast.Assign):
                for target in stmt.targets:
                    if (
                        isinstance(target, ast.Attribute)
                        and isinstance(target.value, ast.Name)
                        and target.value.id == "self"
                    ):
                        mappings[target.attr] = []  # Found field

        return mappings

    def _compute_test_id_prefix(self) -> str:
        """Находит общий префикс для test_id по токенам '-', '_'."""
        if not self._seen_test_ids or len(self._seen_test_ids) < 2:
            return ""

        # Dummy impl relies on external setting
        return ""
