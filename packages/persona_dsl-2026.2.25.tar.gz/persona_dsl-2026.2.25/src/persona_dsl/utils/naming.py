import re
from unidecode import unidecode


def to_pascal_case(s: str) -> str:
    """Преобразует snake_case или kebab-case (и пути) в PascalCase."""
    # Split by underscores or non-word characters (spaces, punctuation)
    if not s:
        return ""
    # Convert to snake case first to handle existing CamelCase properly
    snake = to_snake_case(s)
    parts = snake.split("_")
    return "".join(p.capitalize() for p in parts if p)


def to_snake_case(name: str) -> str:
    """Преобразует PascalCase или kebab-case, или Cyrillic string в snake_case."""
    if not name:
        return ""
    # Transliterate to ASCII (Cyrillic -> Latin)
    name = unidecode(name)

    # Handle spaces first
    name = re.sub(r"\s+", "_", name)
    name = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)

    # Remove non-alphanumeric (except underscore)
    name = re.sub(r"[^a-zA-Z0-9_]", "", name)

    return name.replace("-", "_").lower()
