import libcst as cst
from typing import Dict, Optional, List, Set, Union, cast, Sequence

try:
    import black

    HAS_BLACK = True
except ImportError:
    HAS_BLACK = False


class CodeEditor:
    """
    A unified utility for performing non-destructive code modifications using LibCST.
    """

    def __init__(self, code: str):
        self.module = cst.parse_module(code)

    def get_code(self, use_black: bool = True) -> str:
        code = self.module.code
        if use_black and HAS_BLACK:
            try:
                # Use default mode
                return black.format_str(code, mode=black.Mode())
            except Exception:
                # If formatting fails (e.g. syntax error in intermediate code), return as is
                return code
        return code

    def update_class_attributes(
        self, class_name: str, attributes: Dict[str, str]
    ) -> "CodeEditor":
        """
        Updates or adds class-level string attributes (e.g. url = "...")
        """

        class AttributeUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, attrs: Dict[str, str]):
                self.target_class = target_class
                self.attrs = attrs
                self.found_class = False
                self.handled_attrs: Set[str] = set()

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    self.found_class = True
                    return True
                return False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if not self.found_class:
                    return updated_node

                new_body_stmts: List[cst.BaseStatement] = []
                # 1. Update existing
                current_body = cast(Sequence[cst.BaseStatement], updated_node.body.body)
                for stmt in current_body:
                    if isinstance(stmt, cst.SimpleStatementLine):
                        if isinstance(stmt.body[0], cst.Assign):
                            assign: cst.Assign = stmt.body[0]
                            replaced = False
                            for target in assign.targets:
                                if (
                                    isinstance(target.target, cst.Name)
                                    and target.target.value in self.attrs
                                ):
                                    attr_name = target.target.value
                                    new_val = self.attrs[attr_name]
                                    self.handled_attrs.add(attr_name)
                                    new_assign = assign.with_changes(
                                        value=cst.SimpleString(f'"{new_val}"')
                                    )
                                    new_body_stmts.append(
                                        stmt.with_changes(body=[new_assign])
                                    )
                                    replaced = True
                                    break
                            if replaced:
                                continue
                    new_body_stmts.append(stmt)

                # 2. Insert missing
                to_insert: List[cst.SimpleStatementLine] = []
                for attr, val in self.attrs.items():
                    if attr not in self.handled_attrs and val:
                        assign_stmt = cst.SimpleStatementLine(
                            body=[
                                cst.Assign(
                                    targets=[cst.AssignTarget(target=cst.Name(attr))],
                                    value=cst.SimpleString(f'"{val}"'),
                                )
                            ]
                        )
                        to_insert.append(assign_stmt)

                if to_insert:
                    insert_idx = 0
                    if (
                        new_body_stmts
                        and isinstance(new_body_stmts[0], cst.SimpleStatementLine)
                        and isinstance(new_body_stmts[0].body[0], cst.Expr)
                        and isinstance(
                            new_body_stmts[0].body[0].value, cst.SimpleString
                        )
                    ):
                        insert_idx = 1

                    for item in reversed(to_insert):
                        new_body_stmts.insert(insert_idx, item)

                self.found_class = False
                return updated_node.with_changes(
                    body=cst.IndentedBlock(body=new_body_stmts)
                )

        transformer = AttributeUpdater(class_name, attributes)
        self.module = self.module.visit(transformer)
        return self

    def replace_method(
        self, class_name: str, method_node: cst.FunctionDef
    ) -> "CodeEditor":
        """
        Replaces a method in a class with a new CST definition.
        If the method doesn't exist, it appends it (after __init__ or at start).
        """

        class MethodReplacer(cst.CSTTransformer):
            def __init__(self, target_class: str, new_method: cst.FunctionDef):
                self.target_class = target_class
                self.new_method = new_method
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    target_name = self.new_method.name.value

                    new_body_stmts: List[cst.BaseStatement] = []
                    replaced = False

                    current_body = cast(
                        Sequence[cst.BaseStatement], updated_node.body.body
                    )
                    for stmt in current_body:
                        if (
                            isinstance(stmt, cst.FunctionDef)
                            and stmt.name.value == target_name
                        ):
                            new_body_stmts.append(self.new_method)
                            replaced = True
                        else:
                            new_body_stmts.append(stmt)

                    if not replaced:
                        # Insert strategy:
                        # If __init__ exists, insert after it?
                        # Or just at the top?
                        # Let's insert at the top (after docstring) for simplicity, or strict append?
                        # Generator usually puts __init__ first.
                        # If replacing __init__, we handled it.
                        # If adding new method, maybe append?

                        # Logic: if __init__ is the target, we likely inserted it.
                        # If it's a random method, append to end.
                        if target_name == "__init__":
                            idx = 0
                            if (
                                new_body_stmts
                                and isinstance(
                                    new_body_stmts[0], cst.SimpleStatementLine
                                )
                                and isinstance(new_body_stmts[0].body[0], cst.Expr)
                                and isinstance(
                                    new_body_stmts[0].body[0].value, cst.SimpleString
                                )
                            ):
                                idx = 1
                            new_body_stmts.insert(idx, self.new_method)
                        else:
                            new_body_stmts.append(self.new_method)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body_stmts)
                    )
                return updated_node

        transformer = MethodReplacer(class_name, method_node)
        self.module = self.module.visit(transformer)
        return self

        return self

    def update_class_docstring(self, class_name: str, docstring: str) -> "CodeEditor":
        """
        Updates or adds a docstring to the specified class.
        """

        class DocstringUpdater(cst.CSTTransformer):
            def __init__(self, target_class: str, new_doc: str):
                self.target_class = target_class
                self.new_doc = new_doc
                self.found_class = False

            def leave_ClassDef(
                self, original_node: cst.ClassDef, updated_node: cst.ClassDef
            ) -> cst.BaseStatement:
                if original_node.name.value == self.target_class:
                    self.found_class = True
                    # Create docstring statement
                    doc_stmt = cst.SimpleStatementLine(
                        [cst.Expr(value=cst.SimpleString(repr(self.new_doc)))]
                    )

                    current_body = cast(
                        Sequence[cst.BaseStatement], updated_node.body.body
                    )
                    new_body: List[cst.BaseStatement] = list(current_body)

                    # Check if first statement is a docstring
                    if (
                        new_body
                        and isinstance(new_body[0], cst.SimpleStatementLine)
                        and new_body[0].body
                        and isinstance(new_body[0].body[0], cst.Expr)
                        and isinstance(new_body[0].body[0].value, cst.SimpleString)
                    ):
                        new_body[0] = doc_stmt
                    else:
                        new_body.insert(0, doc_stmt)

                    return updated_node.with_changes(
                        body=cst.IndentedBlock(body=new_body)
                    )
                return updated_node

        transformer = DocstringUpdater(class_name, docstring)
        self.module = self.module.visit(transformer)
        return self

    def merge_init_from_other_code(
        self, source_code: str, class_name: str
    ) -> "CodeEditor":
        """
        Extracts __init__ method and imports from source_code and applies them to the current module.
        """
        other_module = cst.parse_module(source_code)

        # 1. Extract new __init__ and imports
        class NewCodeExtractor(cst.CSTVisitor):
            def __init__(self, target_class: str):
                self.target_class = target_class
                self.found_init: Optional[cst.FunctionDef] = None
                self.collected_imports: List[Union[cst.Import, cst.ImportFrom]] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                if node.name.value == self.target_class:
                    for body_item in node.body.body:
                        if (
                            isinstance(body_item, cst.FunctionDef)
                            and body_item.name.value == "__init__"
                        ):
                            self.found_init = body_item
                    return False
                return False

            def visit_Import(self, node: cst.Import) -> None:
                self.collected_imports.append(node)

            def visit_ImportFrom(self, node: cst.ImportFrom) -> None:
                self.collected_imports.append(node)

        extractor = NewCodeExtractor(class_name)
        other_module.visit(extractor)

        if not extractor.found_init:
            return self

        # 2. Add imports
        # Convert imports back to strings for add_imports which handles deduplication
        import_strings = []
        for imp in extractor.collected_imports:
            import_strings.append(
                cst.Module(body=[cst.SimpleStatementLine(body=[imp])]).code.strip()
            )

        self.add_imports(import_strings)

        # 3. Replace __init__
        self.replace_method(class_name, extractor.found_init)

        return self

    def merge_all_classes_from_other_code(self, source_code: str) -> "CodeEditor":
        """
        Merges ALL classes from source_code into the current module.
        - If class exists: updates its __init__.
        - If class is new: appends it to the module.
        - Merges imports.
        """
        other_module = cst.parse_module(source_code)

        # 1. Collect all classes and imports from source
        class MultiClassExtractor(cst.CSTVisitor):
            def __init__(self) -> None:
                self.classes: Dict[str, cst.ClassDef] = {}
                self.imports: List[str] = []

            def visit_ClassDef(self, node: cst.ClassDef) -> Optional[bool]:
                self.classes[node.name.value] = node
                return False  # Don't recurse into nested classes

            def visit_Import(self, node: cst.Import) -> Optional[bool]:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

            def visit_ImportFrom(self, node: cst.ImportFrom) -> Optional[bool]:
                self.imports.append(
                    cst.Module(body=[cst.SimpleStatementLine(body=[node])]).code.strip()
                )
                return False

        extractor = MultiClassExtractor()
        other_module.visit(extractor)

        # 2. Add imports
        self.add_imports(extractor.imports)

        # 3. Process Classes
        for cls_name, cls_node in extractor.classes.items():
            # Check existence freshly
            exists = False
            for stmt in self.module.body:
                if isinstance(stmt, cst.ClassDef) and stmt.name.value == cls_name:
                    exists = True
                    break

            if exists:
                # Update __init__
                new_init = None
                for body_item in cls_node.body.body:
                    if (
                        isinstance(body_item, cst.FunctionDef)
                        and body_item.name.value == "__init__"
                    ):
                        new_init = body_item
                        break
                if new_init:
                    self.replace_method(cls_name, new_init)
            else:
                # Append new class
                new_body = list(self.module.body)
                new_body.append(cls_node)
                self.module = self.module.with_changes(body=new_body)

        return self

    def add_imports(self, imports: List[str]) -> "CodeEditor":
        """
        Adds import statements if they are not already present.
        Input strings should be full statements like "from foo import bar".
        """
        # Parse new imports to CST
        new_import_nodes = []
        for imp_str in imports:
            try:
                # Wrap in simple statement to parse
                mod = cst.parse_module(imp_str)
                if mod.body:
                    new_import_nodes.append(mod.body[0])
            except Exception:
                pass

        if not new_import_nodes:
            return self

        existing_lines = set()
        for stmt in self.module.body:
            existing_lines.add(cst.Module(body=[stmt]).code.strip())

        to_add = []
        for node in new_import_nodes:
            code = cst.Module(body=[node]).code.strip()
            if code not in existing_lines:
                to_add.append(node)
                existing_lines.add(code)

        if to_add:
            # Find last import
            last_import_idx = -1
            for i, stmt in enumerate(self.module.body):
                if isinstance(stmt, cst.SimpleStatementLine) and isinstance(
                    stmt.body[0], (cst.Import, cst.ImportFrom)
                ):
                    last_import_idx = i

            new_body = list(self.module.body)
            insert_pos = last_import_idx + 1 if last_import_idx >= 0 else 0

            for item in reversed(to_add):
                new_body.insert(insert_pos, item)

            self.module = self.module.with_changes(body=new_body)

        return self
