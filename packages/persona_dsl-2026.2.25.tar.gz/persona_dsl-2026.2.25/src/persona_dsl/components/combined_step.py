from abc import abstractmethod
from typing import Any, Generator

from .base_step import BaseStep


class CombinedStep(BaseStep):
    """
    Базовый класс для высокоуровневого, композитного шага (Combined Step),
    который объединяет последовательность других шагов (Steps) для достижения
    бизнес-цели. Управляется через генератор.

    Также предоставляет метод make(persona) для story-стиля, который
    просто вызывает execute(persona) без добавления логики.

    Основной контракт — реализация генераторного метода _run(), который
    позволяет описывать как простые последовательности Steps, так и сложную
    логику с передачей результатов между ними.
    """

    def make(self, persona: Any) -> None:
        self.execute(persona)

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        """
        Исполняет генераторный сценарий из `_run`, передавая результаты
        выполнения Steps обратно в генератор.
        """
        from .step import Step

        gen = self._run(persona, *args, **kwargs)
        try:
            # Первый вызов для запуска генератора и получения первого шага
            step_to_execute = gen.send(None)
            while True:
                # Проверяем, что из CombinedStep не yield'ят низко-уровневые Ops
                if not isinstance(step_to_execute, (Step, CombinedStep)):
                    raise TypeError(
                        f"Компонент '{self.__class__.__name__}' (наследник CombinedStep) "
                        f"может yield'ить только другие шаги (наследники Step/CombinedStep), "
                        f"но был получен объект типа {type(step_to_execute).__name__}."
                    )

                # Выполняем полученный шаг
                last_result = step_to_execute.execute(persona)
                # Отправляем результат обратно в генератор и получаем следующий шаг
                step_to_execute = gen.send(last_result)
        except StopIteration as e:
            # Генератор завершился (оператором return), его результат в e.value
            return e.value

    @abstractmethod
    def _get_step_description(self, persona: Any) -> str:  # pragma: no cover
        """Возвращает текстовое описание шага для Allure."""
        ...

    @abstractmethod
    def _run(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Generator[Any, Any, Any]:  # pragma: no cover
        """
        Декларативно-императивный контракт.
        Yield'ит последовательность Steps и явно возвращает результат.
        """
        # Этот код нужен, чтобы сделать метод абстрактным генератором.
        # В реальных реализациях он будет заменён.
        if False:
            yield
