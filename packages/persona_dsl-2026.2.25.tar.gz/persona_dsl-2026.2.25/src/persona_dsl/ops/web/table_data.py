from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Table


class TableData(Ops):
    """
    Извлекает данные из таблицы в виде списка словарей.
    Ключи — заголовки столбцов, значения — текст ячеек.
    """

    def __init__(self, table_element: Table):
        self.table = table_element

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} извлекает данные из таблицы '{self.table.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> list[dict[str, str]]:
        page = persona.skill(SkillId.BROWSER).page
        return self.table.get_all_data(page)
