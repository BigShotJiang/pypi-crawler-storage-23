from typing import Any, Dict

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Table


class TableRowData(Ops):
    """
    Извлекает данные конкретной строки таблицы в виде словаря.
    Удобно для создания снепшотов по конкретным строкам.

    Пример:
        row_data = persona.ask(TableRowData(table, where={"ID": "1"}))
        # Возвращает: {"ID": "1", "Status": "Active", ...}
    """

    def __init__(self, table: Table, where: Dict[str, Any]) -> None:
        self.table = table
        self.where = where

    def _get_step_description(self, persona: Any) -> str:
        return "Получение данных строки таблицы"

    def _perform(self, persona: Any) -> Dict[str, str]:
        # Получаем Playwright Page
        page = persona.skill(SkillId.BROWSER).page

        # Резолвим саму таблицу и собираем заголовки
        table_locator = self.table.resolve(page)
        headers_loc = table_locator.locator("thead th, tr th")
        headers = [h.strip() for h in headers_loc.all_inner_texts()]

        if not headers:
            raise ValueError(
                f"Не удалось найти заголовки в таблице '{self.table.name}'."
            )

        # Находим нужную строку через стандартный метод Table
        row_element = self.table.row(where=self.where)
        row_locator = row_element.resolve(page)

        # Получаем ячейки найденной строки
        cells = [
            c.strip()
            for c in row_locator.locator(
                "td, [role=cell], th, [role=rowheader]"
            ).all_inner_texts()
        ]

        if not cells:
            raise ValueError(
                f"Строка с условиями {self.where} найдена, но ячейки пусты."
            )

        row_data = {}
        for i in range(min(len(headers), len(cells))):
            row_data[headers[i]] = cells[i]

        self.result = row_data
        return self.result
