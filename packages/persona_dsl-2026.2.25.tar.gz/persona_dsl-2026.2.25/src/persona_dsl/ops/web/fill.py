from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class Fill(Ops):
    """
    Атомарное действие: заполнить поле текстом.
    Приоритет поиска: по ARIA-роли и имени, затем по `locator`.
    Поддерживает проброс аргументов в Playwright (force, timeout, etc).
    """

    def __init__(self, element: Element, text: str, **kwargs: Any):
        if not isinstance(element, Element):
            raise TypeError(
                f"Fill ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element
        self.text = text
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        # Не логируем пароли и другие чувствительные данные
        text_to_log = self.text
        name_lower = self.element.name.lower()
        accessible_name_lower = (self.element.accessible_name or "").lower()
        if (
            "password" in name_lower
            or "pass" in name_lower
            or "парол" in accessible_name_lower
        ):
            text_to_log = "****"
        extra = f" с параметрами {self.kwargs}" if self.kwargs else ""
        return f"{persona} заполняет поле '{self.element.name}' текстом '{text_to_log}'{extra}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        locator.fill(self.text, **self.kwargs)
