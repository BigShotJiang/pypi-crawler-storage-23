from enum import Enum
from typing import Any, Dict, List, Optional, Union

from persona_dsl.components.expectation import Expectation
from persona_dsl.expectations.web.have_text import HaveText
from persona_dsl.pages.elements import Table


class TableCellHasText(Expectation):
    """
    Убеждается, что конкретная ячейка в строке (найденной по фильтру) содержит заданный текст.
    """

    def __init__(
        self,
        table: Table,
        where: dict[str, str],
        column: Union[str, Enum, int],
        text: str,
    ):
        self.table = table
        self.where = where
        self.column = column
        self.text = text

    def _get_step_description(self, persona: Any) -> str:
        col_name = self.column.name if isinstance(self.column, Enum) else self.column
        where_str = ", ".join(
            f"'{k.name if isinstance(k, Enum) else k}'='{v}'"
            for k, v in self.where.items()
        )
        return f"{persona} проверяет, что ячейка '{col_name}' в строке где {where_str} содержит '{self.text}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        row = self.table.row(where=self.where)
        cell = row.cell(self.column)

        expectation = HaveText(self.text)
        return expectation._perform(persona, cell)


class TableHasRowCount(Expectation):
    """
    Проверяет, что в таблице ровно `count` строк (без учета заголовков).
    """

    def __init__(self, table: Table, count: int):
        self.table = table
        self.count = count

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} проверяет, что в таблице '{self.table.name}' ровно {self.count} строк"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        # Для TableHasRowCount мы применяем HaveCount к дочерним строкам тела таблицы (body_rows)
        # У Table есть метод row(index=), но чтобы посчитать элементы Playwright,
        # нам нужен общий локатор, например `table.row()` без where,
        # но TableType не имеет `all_rows` локатора в базовом Elements.
        # Доработаем это через page locator

        # Получаем базовый locator от table
        from persona_dsl.skills.core.skill_definition import SkillId

        page = persona.skill(SkillId.BROWSER).page

        prototype = self.table.body_rows()._make_item(None)
        rows_locator = prototype.resolve(page)

        try:
            from playwright.sync_api import expect

            expect(rows_locator).to_have_count(self.count)
            return True
        except AssertionError as e:
            raise AssertionError(
                f"Ожидалось {self.count} строк, но найдено другое количество: {e}"
            )


class TableHasData(Expectation):
    """
    Проверяет эталонные данные (Snapshot-style).
    Сравнивает все данные на текущей странице таблицы с ожидаемым списком словарей.
    """

    def __init__(
        self,
        table: Table,
        expected_data: List[Dict[Union[str, Enum], Any]],
        exclude_columns: Optional[List[Union[str, Enum]]] = None,
        ignore_order: bool = False,
    ):
        self.table = table
        self.expected_data = expected_data
        self.exclude_columns = exclude_columns or []
        self.ignore_order = ignore_order

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} сверяет данные таблицы '{self.table.name}' с эталонным набором ({len(self.expected_data)} строк)"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        from persona_dsl.skills.core.skill_definition import SkillId

        page = persona.skill(SkillId.BROWSER).page

        try:
            actual_data = self.table.get_all_data(page)
        except Exception as e:
            raise ValueError(f"Ошибка при чтении таблицы '{self.table.name}': {e}")

        # Нормализация ожидаемых данных (приведение ключей Enum к строкам)
        normalized_expected = []
        for expected_row in self.expected_data:
            norm_row = {}
            for k, v in expected_row.items():
                if isinstance(k, Enum):
                    # Если у нас Enum с value равным заголовку, используем value
                    key_str = k.value if hasattr(k, "value") else k.name
                else:
                    key_str = str(k)
                norm_row[key_str] = v
            normalized_expected.append(norm_row)

        # Исключение колонок
        normalized_exclude = []
        for col in self.exclude_columns:
            if isinstance(col, Enum):
                normalized_exclude.append(
                    col.value if hasattr(col, "value") else col.name
                )
            else:
                normalized_exclude.append(str(col))

        # Фильтрация колонок
        filtered_expected = []
        for row in normalized_expected:
            filtered_expected.append(
                {k: v for k, v in row.items() if k not in normalized_exclude}
            )

        filtered_actual = []
        for row in actual_data:
            filtered_actual.append(
                {k: v for k, v in row.items() if k not in normalized_exclude}
            )

        # Сравнение
        if self.ignore_order:
            # Сортируем списки словарей для независимого порядка (стабильная сортировка)
            import json

            exp_sorted = sorted(
                filtered_expected, key=lambda x: json.dumps(x, sort_keys=True)
            )
            act_sorted = sorted(
                filtered_actual, key=lambda x: json.dumps(x, sort_keys=True)
            )
            is_match = exp_sorted == act_sorted
            compare_exp = exp_sorted
            compare_act = act_sorted
        else:
            is_match = filtered_expected == filtered_actual
            compare_exp = filtered_expected
            compare_act = filtered_actual

        if not is_match:
            import difflib
            import json

            exp_json = json.dumps(
                compare_exp, ensure_ascii=False, indent=2
            ).splitlines()
            act_json = json.dumps(
                compare_act, ensure_ascii=False, indent=2
            ).splitlines()
            diff = "\\n".join(
                difflib.unified_diff(
                    exp_json,
                    act_json,
                    fromfile="Expected",
                    tofile="Actual",
                    lineterm="",
                )
            )

            # Прикрепляем Diff в Allure, если доступно
            try:
                import allure

                allure.attach(
                    diff,
                    name="Отличия в таблице (Diff)",
                    attachment_type=allure.attachment_type.TEXT,
                )
            except ImportError:
                pass

            raise AssertionError(
                f"Данные таблицы не совпадают с эталонными.\\nРазличия:\\n{diff}"
            )

        return True
