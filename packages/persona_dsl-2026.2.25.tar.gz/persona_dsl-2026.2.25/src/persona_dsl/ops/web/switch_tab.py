from typing import Any, Optional
import re

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_browser import UseBrowser


class SwitchTab(Ops):
    """
    Переключается на другую вкладку браузера (Page).

    Параметры:
        index (int, optional): Индекс вкладки (0 - первая вкладка, -1 - последняя). По умолчанию -1.
        url (str, optional): Регулярное выражение для поиска вкладки по URL.
        title (str, optional): Регулярное выражение для поиска вкладки по заголовку (title).
    """

    def __init__(
        self,
        index: Optional[int] = None,
        url: Optional[str] = None,
        title: Optional[str] = None,
    ):
        self.index: Optional[int]
        # По умолчанию переключаемся на последнюю открытую вкладку, если не переданы другие фильтры
        if index is None and url is None and title is None:
            self.index = -1
        else:
            self.index = index

        self.url = url
        self.title = title

    def _get_step_description(self, persona: Any) -> str:
        condition = []
        if self.index is not None:
            condition.append(f"index={self.index}")
        if self.url is not None:
            condition.append(f"url=~{self.url}")
        if self.title is not None:
            condition.append(f"title=~{self.title}")

        cond_str = ", ".join(condition)
        return f"{persona} переключается на вкладку: {cond_str}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        browser_skill = persona.skill(SkillId.BROWSER)
        if not isinstance(browser_skill, UseBrowser):
            raise TypeError("SwitchTab требует наличия навыка UseBrowser.")

        current_page = browser_skill.page
        context = current_page.context

        pages = context.pages
        if not pages:
            raise RuntimeError("Нет открытых вкладок браузера.")

        target_page = None

        if self.url is not None:
            pattern = re.compile(self.url)
            for p in pages:
                if pattern.search(p.url):
                    target_page = p
                    break
        elif self.title is not None:
            pattern = re.compile(self.title)
            for p in pages:
                if pattern.search(p.title()):
                    target_page = p
                    break
        elif self.index is not None:
            try:
                target_page = pages[self.index]
            except IndexError:
                raise IndexError(
                    f"Вкладка с индексом {self.index} не найдена. Всего вкладок: {len(pages)}"
                )

        if target_page is None:
            raise ValueError(
                f"Не удалось найти вкладку по заданным критериям: url={self.url}, title={self.title}, index={self.index}"
            )

        # Переключаем активную страницу в навыке
        browser_skill.switch_active_page(target_page)

        self.result = target_page
        return target_page
