from typing import Any, Generator, List
from enum import Enum

from persona_dsl.components.fact import Fact
from persona_dsl.pages.elements import Table, TableRow
from persona_dsl.ops.web.element_text import ElementText
from persona_dsl.ops.web.elements_count import ElementsCount


class TableColumnData(Fact):
    """
    Факт для извлечения всех видимых на текущей странице значений из конкретной колонки.

    Полезно для сверки сортировки или работы фильтров (например, убедиться,
    что в колонке 'Статус' все значения равны 'Active').

    Аргументы:
        table: Элемент таблицы (PageObject/Element).
        column: Название колонки (поле модели строки или Enum), из которой нужно извлечь данные.

    Возвращает:
        List[str]: Список строк с текстом ячеек для заданной колонки (сверху вниз).
    """

    def __init__(self, table: Table, column: Any) -> None:
        self.table = table
        self.column = column

    def _get_step_description(self, persona: Any) -> str:
        col_name = (
            self.column.value if isinstance(self.column, Enum) else str(self.column)
        )
        return (
            f"Получить все значения из колонки '{col_name}' таблицы '{self.table.name}'"
        )

    def _run(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Generator[Any, Any, List[str]]:
        result = []

        # 1. Считаем количество строк
        rows_collection = self.table.body_rows()
        row_count = yield ElementsCount(rows_collection)

        # 2. Проходим по каждой строке и достаем данные ячейки для выбранной колонки
        for i in range(row_count):
            row_el = rows_collection.nth(i)
            # Приводим к TableRow для type checker
            from typing import cast

            row = cast(TableRow, row_el)
            # Извлекаем ячейку абстрактно: если есть явный enum, используем его, иначе пытаемся как атрибут
            if isinstance(self.column, Enum):
                cell = row.cell(self.column)
            elif hasattr(row, str(self.column)):
                cell = getattr(row, str(self.column))
            else:
                cell = row.cell(self.column)

            text = yield ElementText(cell)
            result.append(text)

        return result
