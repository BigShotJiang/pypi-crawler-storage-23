from typing import Any, Literal, Optional

from persona_dsl.components.action import Action
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element, Table


class ScrollTable(Action):
    """
    Выполняет скроллинг контейнера таблицы.
    Полезно для виртуализированных таблиц или таблиц с горизонтальным скроллом.

    Args:
        table: Элемент таблицы. Скроллинг применяется к ближайшему скроллируемому контейнеру
               или к самой таблице (tbody).
        direction: Направление скролла ("right", "left", "bottom", "top").
        amount: Количество пикселей для скролла, или "max" для скролла до упора.
    """

    def __init__(
        self,
        table: Table,
        direction: Literal["right", "left", "bottom", "top"] = "bottom",
        amount: Optional[int | str] = None,
        column: Optional[Any] = None,
        where: Optional[dict[Any, Any]] = None,
    ) -> None:
        self.table = table
        self.direction = direction
        self.amount = amount
        self.column = column
        self.where = where

    def _get_step_description(self, persona: Any) -> str:
        desc = "Скроллинг таблицы"
        if self.where and self.column:
            desc += f" до ячейки '{self.column}' в строке {self.where}"
        elif self.where:
            desc += f" до строки {self.where}"
        elif self.column:
            desc += f" до заголовка '{self.column}'"
        else:
            desc += f" {self.direction}"
        return desc

    def _perform(self, persona: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page

        target_element: Element | None = None
        if self.where and self.column:
            # Скроллинг до конкретной ячейки
            target_element = self.table.row(where=self.where).cell(self.column)
        elif self.where:
            # Скроллинг до конкретной строки
            target_element = self.table.row(where=self.where)
        elif self.column:
            # Скроллинг до заголовка колонки (горизонтальный скролл)
            target_element = self.table.header(self.column)

        if target_element:
            try:
                # Если таблица не виртуализована и элемент просто вне видимости overflow, это сразу сработает
                # Если она виртуализована (и элемента нет в DOM), нужно использовать расширенные стратегии
                element_locator = target_element.resolve(page)
                element_locator.scroll_into_view_if_needed(timeout=2000)
                return None
            except Exception:
                # Fallback: Если элемент так и не был найден (таймаут),
                # мы можем сделать fallback на обычный скролл в направлении конца,
                # но для начала просто пробросим ошибку.
                raise ValueError(
                    f"Не удалось найти элемент {target_element.name} для прокрутки. В виртуализированных таблицах элемент может отсутствовать в DOM."
                )

        self.table.scroll(page, direction=self.direction, amount=self.amount)
        return None
