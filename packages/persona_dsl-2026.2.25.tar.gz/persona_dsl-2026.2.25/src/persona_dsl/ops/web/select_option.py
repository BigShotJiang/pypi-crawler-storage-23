from typing import Any, Generator, Optional

from persona_dsl.components.step import Step
from .click import Click
from persona_dsl.pages.elements import Element


class SelectOption(Step):
    """
    Выбирает опцию в выпадающем списке.
    Поддерживает как стандартные <select>, так и кастомные dropdowns (через клик).

    Args:
        element (Element): Элемент (Select/Dropdown/ComboBox)
        value (str, optional): Значение атрибута value опции.
        label (str, optional): Видимый текст опции (Accessible Name).
        text (str, optional): Алиас для label (предпочтительно для DSL читаемости).
        index (int, optional): Индекс опции (0-based).
        force (bool): Игнорировать проверки interactability.
    """

    def __init__(
        self,
        element: Element,
        value: Optional[str] = None,
        label: Optional[str] = None,
        index: Optional[int] = None,
        force: bool = False,
    ) -> None:
        self.element = element
        self.value = value
        self.label = label
        self.index = index
        self.force = force

        desc_parts = []
        if value:
            desc_parts.append(f"value='{value}'")
        if label:
            desc_parts.append(f"label='{label}'")
        if index is not None:
            desc_parts.append(f"index={index}")
        if force:
            desc_parts.append("force=True")

        self.description = f"Выбрать опцию в {element}: {', '.join(desc_parts)}"
        super().__init__()

    def _get_step_description(self, persona: Any) -> str:
        return self.description

    def _run(
        self, persona: Any, *args: Any, **kwargs: Any
    ) -> Generator[Any, Any, None]:
        # 0. Get the page/browser (Standard)
        # Use persona.use to trigger lazy loading if not present

        # We can use SkillId.BROWSER or string "browser" if generic
        # To avoid importing SkillId if not needed, we can try safe string
        browser = persona.skill("browser")
        page = browser.page

        # The logic for selecting an option is now encapsulated in the Element classes.
        # This allows different element types (Select, Dropdown, Custom) to implement
        # their own specific strategies for opening and selecting.

        # We try to call select_option on the element.
        # Base Element class or specific subclasses (Select, Dropdown) must implement this.
        if hasattr(self.element, "select_option"):
            self.element.select_option(
                page=page,
                value=self.value,
                label=self.label,
                index=self.index,
                force=self.force,
            )
        else:
            # Fallback for Elements that don't explicitly support select_option
            # We rely on get_option() which is now available on ALL Elements (base class).

            # 1. Click the trigger (container)
            yield Click(self.element)

            # 2. Get the option (Search Strategy)
            target_text = self.label or self.value
            if target_text:
                # Clean up target text for naming

                # STRATEGY A: If Element knows how to find its own options (e.g. ListBox), use it.
                # This returns the "official" element definition if available.
                # Since we added get_option to Element base class, this is always available.
                target_option = self.element.get_option(target_text)

                # Resolve to check existence
                opt_loc = target_option.resolve(page)

                if opt_loc.count() > 0:
                    opt_loc.first.scroll_into_view_if_needed()
                    opt_loc.first.click()
                    return

                # Strict failure if Option not found
                # Strict failure if Option not found
                raise ValueError(
                    f"SelectOption: Could not find option '{target_text}' in {self.element}."
                )

            elif self.index is not None:
                # Use unified index strategy from Element base class
                target_option = self.element.get_option_by_index(self.index)
                opt_loc = target_option.resolve(page)

                if opt_loc.count() > 0:
                    opt_loc.first.scroll_into_view_if_needed()
                    opt_loc.first.click()
                    return

                raise ValueError(
                    f"SelectOption: Could not find option at index {self.index} in {self.element}."
                )
