from typing import Any, Dict, Optional

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Table, TableRow


class GetTableRow(Ops):
    """
    Находит строку в таблице по заданному условию.

    Args:
        table_element: Элемент таблицы (Table).
        where: Словарь с условиями поиска (колонка: значение).
               Колонка может быть строкой или Enum таблицы.
        index: Индекс строки (если не используется where).
    """

    def __init__(
        self,
        table_element: Table,
        where: Optional[Dict[str, str]] = None,
        index: Optional[int] = None,
    ):
        self.table = table_element
        self.where = where
        self.index = index

    def _get_step_description(self, persona: Any) -> str:
        condition = self.where if self.where else f"index={self.index}"
        return f"{persona} находит строку в таблице '{self.table.name}' по условию: {condition}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> TableRow:
        row_element = self.table.row(where=self.where, index=self.index)

        # Verify it can be resolved (will raise timeout/error if not found)
        page = persona.skill(SkillId.BROWSER).page
        row_element.resolve(page)

        # Omit count assertion here to allow "verify(Not(BeVisible()), row_element)"
        # But we want to ensure the element instance is returned for further chaining.
        self.result = row_element
        return row_element
