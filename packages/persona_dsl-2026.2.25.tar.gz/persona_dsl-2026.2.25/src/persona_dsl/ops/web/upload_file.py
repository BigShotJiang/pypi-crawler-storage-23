from pathlib import Path
from typing import Any, Union, List

from persona_dsl.components.ops import Ops
from persona_dsl.pages.elements import Element
from persona_dsl.skills.core.skill_definition import SkillId


class UploadFile(Ops):
    """
    Действие: Загрузить файл(ы) в input[type='file'].
    Wrapper for: locator.set_input_files(files)
    """

    def __init__(
        self, element: Element, files: Union[str, Path, List[Union[str, Path]]]
    ):
        self.element = element
        self.files = files

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} загружает файлы в '{self.element}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        page = persona.skill(SkillId.BROWSER).page
        locator = self.element.resolve(page)
        locator.set_input_files(self.files)
