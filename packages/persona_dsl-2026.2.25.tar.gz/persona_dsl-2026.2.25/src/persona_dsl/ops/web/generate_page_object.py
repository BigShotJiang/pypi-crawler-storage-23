from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Optional, Dict, Tuple, Type, List
from urllib.parse import urlparse

from persona_dsl.pages import Element


from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.generators import PageGenerator
from persona_dsl.utils.naming import to_snake_case
from .rich_aria_snapshot import RichAriaSnapshot


class GeneratePageObject(Ops):
    """
    Бизнес-операция: сгенерировать и сохранить PageObject на основе текущего состояния страницы.
    Работает при запуске pytest с флагом --generate-pages (см. pytest_plugin.py).

    По умолчанию также сохраняет ARIA-снепшот в tests/pages/aria/<stem>_snapshot.yaml
    и прокидывает относительный путь в сгенерированный Page (static_aria_snapshot_path).

    Параметры ожидания перед генерацией регулируются аргументами:
      - wait_for_state: состояние загрузки Playwright ('load' | 'domcontentloaded' | 'networkidle' | 'commit')
      - wait_timeout: таймаут в миллисекундах; если None — используется дефолтный таймаут Playwright/страницы
      - sleep_before: если задано (в секундах), выполнить простую паузу перед генерацией и не ждать состояние загрузки
    """

    def __init__(
        self,
        class_name: str = "GeneratedPage",
        output_path: Optional[str] = None,
        wait_for_state: Optional[str] = "networkidle",
        wait_timeout: Optional[float] = None,
        sleep_before: Optional[float] = None,
        debug_mode: bool = False,
        leaf_overrides: Optional[Dict[str, List[str]]] = None,
        component_registry: Optional[  # Legacy argument kept for compatibility but ignored
            Dict[Tuple[str, str], Tuple[Type[Element], str]]
        ] = None,
    ):
        self.class_name = class_name or "GeneratedPage"
        if output_path is None:
            file_name = f"{to_snake_case(self.class_name)}.py"
            # Дефолт как у клиента: tests/pages/
            self.output_path = Path("tests/pages") / file_name
        else:
            self.output_path = Path(output_path)
        self.wait_for_state = wait_for_state
        self.wait_timeout = wait_timeout
        self.sleep_before = sleep_before
        self.debug_mode = debug_mode
        self.leaf_overrides = leaf_overrides
        self.component_registry = (
            None  # Legacy argument kept for compatibility but ignored
        )

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} генерирует PageObject '{self.class_name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        # Проверяем флаг в pytest (регистрируется в pytest_plugin.py)
        request = getattr(persona, "_pytest_request", None)
        generate_enabled = False
        if request is not None:
            try:
                generate_enabled = bool(request.config.getoption("--generate-pages"))
            except Exception:
                generate_enabled = False

        if not generate_enabled:
            # Явный no-op без побочных эффектов
            return

        browser_skill = persona.skill(SkillId.BROWSER)
        page = browser_skill.page

        # Варианты ожидания перед генерацией: простая пауза или ожидание состояния
        if self.sleep_before is not None:
            time.sleep(self.sleep_before)
        elif self.wait_for_state:
            if self.wait_timeout is None:
                page.wait_for_load_state(self.wait_for_state)
            else:
                page.wait_for_load_state(self.wait_for_state, timeout=self.wait_timeout)

        # Получаем относительный путь URL
        page_path = urlparse(page.url).path

        # --- Inject Generator Configuration (Portal Classes) ---
        try:
            # Access project config via pytest fixture available in request
            if request:
                project_config = request.getfixturevalue("config")
                portal_classes = project_config.generator.get("portal_classes")
                portal_patterns = project_config.generator.get("portal_patterns")

                if portal_classes or portal_patterns:
                    # 1. Set global config for future reloads
                    # 2. Reconfigure active runtime immediately
                    js_config = {}
                    if portal_classes:
                        js_config["portalClasses"] = portal_classes
                    if portal_patterns:
                        js_config["portalPatterns"] = portal_patterns

                    page.evaluate(f"window.__PERSONA_CONFIG__ = {js_config};")
                    page.evaluate(
                        f"window.__PERSONA__ && window.__PERSONA__.configure && window.__PERSONA__.configure({js_config});"
                    )
        except Exception:
            # Fallback or ignore if config is not available/malformed
            pass

        # Используем rich ARIA snapshot вместо стандартного
        rich_snapshot_op = RichAriaSnapshot()
        snapshot_struct = rich_snapshot_op.get_tree(persona)

        # Сохраняем ARIA снепшот на диск как YAML-строку
        assets_dir = self.output_path.parent / "aria"
        assets_dir.mkdir(parents=True, exist_ok=True)

        snapshot_file = f"{self.output_path.stem}_snapshot.yaml"
        snapshot_abs_path = assets_dir / snapshot_file

        snapshot_yaml: str = (
            RichAriaSnapshot.to_yaml(snapshot_struct) if snapshot_struct else ""
        )
        if snapshot_yaml:
            snapshot_abs_path.write_text(snapshot_yaml, encoding="utf-8")
        aria_snapshot_rel_path = f"aria/{snapshot_file}"

        generator = PageGenerator(
            debug_mode=self.debug_mode,
            leaf_overrides=self.leaf_overrides,
        )
        # Если файл уже существует — читаем его и выполняем умное обновление (merge)
        existing_code: Optional[str] = None
        try:
            if self.output_path.exists():
                existing_code = self.output_path.read_text(encoding="utf-8")
        except Exception:
            existing_code = None

        generated_code = generator.generate_or_update_from_aria_snapshot(
            snapshot=snapshot_struct,
            class_name=self.class_name,
            page_path=page_path,
            aria_snapshot_path=aria_snapshot_rel_path,
            existing_code=existing_code,
        )

        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.output_path.write_text(generated_code, encoding="utf-8")

        # 6. Write Deep Updates (Recursive)
        generator.apply_pending_updates()
