from typing import Any

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import Element


class ElementText(Ops):
    """
    Бизнес-факт: получить текстовое содержимое элемента.
    Приоритет поиска: по ARIA-роли и имени, затем по `locator`.
    """

    def __init__(self, element: Element):
        if not isinstance(element, Element):
            raise TypeError(
                f"ElementText ожидает экземпляр Element, получено: {type(element)}"
            )
        self.element = element

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} запрашивает текст элемента '{self.element.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        """Возвращает текстовое содержимое элемента."""
        page = persona.skill(SkillId.BROWSER).page
        text = self.element.resolve(page).text_content()
        return text or ""
