from typing import Any, Literal
import re

from persona_dsl.components.expectation import Expectation
from persona_dsl.pages.elements import Table
from persona_dsl.skills.core.skill_definition import SkillId


class TableColumnIsSorted(Expectation):
    """
    Проверяет, что колонка таблицы отсортирована в указанном порядке.

    Args:
        table: Таблица
        column: Название колонки
        order: "asc" (по возрастанию) или "desc" (по убыванию)
        data_type: "string", "number" или "date" (влияет на алгоритм сравнения)
    """

    def __init__(
        self,
        table: Table,
        column: Any,
        order: Literal["asc", "desc"] = "asc",
        data_type: Literal["string", "number", "date"] = "string",
    ) -> None:
        self.table = table
        self.column = column
        self.order = order
        self.data_type = data_type

    def _get_step_description(self, persona: Any) -> str:
        return f"Проверка сортировки колонки '{self.column}' ({self.order})"

    def _perform(self, persona: Any, target: Any = None) -> bool:
        page = persona.skill(SkillId.BROWSER).page

        try:
            raw_values = self.table.get_column_data(page, self.column)
        except ValueError as e:
            raise ValueError(
                f"Колонка '{self.column}' не найдена в таблице '{self.table.name}': {e}"
            )

        if len(raw_values) <= 1:
            return True  # 1 или 0 элементов всегда отсортированы

        # Конвертация данных для сортировки
        parsed_values: list[Any] = []
        for val in raw_values:
            if self.data_type == "number":
                # Оставляем только цифры, точки и минусы
                clean_num = re.sub(r"[^\d\.\-]", "", str(val))
                try:
                    parsed_values.append(float(clean_num) if clean_num else 0.0)
                except ValueError:
                    parsed_values.append(0.0)
            elif self.data_type == "date":
                # Пытаемся распарсить дату. Если не получается, падаем
                try:
                    # Очень простая эвристика, в реальных проектах
                    # лучше передавать формат даты как опцию.
                    from dateutil.parser import parse  # type: ignore

                    parsed_values.append(parse(val))
                except Exception:
                    # Fallback on string comparison if parsing fails
                    parsed_values.append(val)
            else:
                parsed_values.append(val)

        # Проверяем сортировку
        is_sorted = True
        failed_at = -1

        for i in range(len(parsed_values) - 1):
            if self.order == "asc":
                if parsed_values[i] > parsed_values[i + 1]:
                    is_sorted = False
                    failed_at = i
                    break
            else:
                if parsed_values[i] < parsed_values[i + 1]:
                    is_sorted = False
                    failed_at = i
                    break

        if not is_sorted:
            error_msg = f"Таблица не отсортирована ({self.order}). Нарушение между {raw_values[failed_at]} и {raw_values[failed_at+1]}."
            raise AssertionError(error_msg)

        return True
