import time
from typing import Any, Optional

import allure

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.utils.artifacts import sanitize_filename, screenshots_dir
from persona_dsl.pages.elements import Element


class PageScreenshot(Ops):
    """
    Факт: сделать скриншот текущей страницы.
    Возвращает путь к PNG-файлу.
    """

    def __init__(
        self, name: str, full_page: bool = False, omit_background: bool = False
    ):
        self.name = name
        self.full_page = full_page
        self.omit_background = omit_background

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} делает скриншот страницы '{self.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        page = persona.skill(SkillId.BROWSER).page
        ts = int(time.time() * 1000)
        base_name = sanitize_filename(self.name)
        path = screenshots_dir() / f"{ts}-{base_name}.png"
        page.screenshot(
            path=str(path),
            full_page=self.full_page,
            omit_background=self.omit_background,
        )
        allure.attach.file(
            str(path), name=base_name, attachment_type=allure.attachment_type.PNG
        )
        return str(path)


class ElementScreenshot(Ops):
    """
    Факт: сделать скриншот элемента.
    Возвращает путь к PNG-файлу.
    """

    def __init__(self, element: Element, name: Optional[str] = None):
        self.element = element
        self.name = name or element.name

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} делает скриншот элемента '{self.element.name}' как '{self.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> str:
        page = persona.skill(SkillId.BROWSER).page
        ts = int(time.time() * 1000)
        base_name = sanitize_filename(self.name)
        path = screenshots_dir() / f"{ts}-{base_name}.png"

        locator = self.element.resolve(page)
        locator.screenshot(path=str(path))
        allure.attach.file(
            str(path), name=base_name, attachment_type=allure.attachment_type.PNG
        )
        return str(path)
