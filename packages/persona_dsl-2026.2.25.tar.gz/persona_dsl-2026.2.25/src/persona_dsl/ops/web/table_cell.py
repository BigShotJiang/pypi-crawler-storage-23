from typing import Any, Union
from enum import Enum

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.pages.elements import TableRow, TableCell


class GetTableCell(Ops):
    """
    Находит ячейку в строке таблицы по колонке (Enum или индекс).

    Args:
        row_element: Структура строки таблицы (TableRow).
        column: Колонка, значение Enum или строка с названием колонки.
    """

    def __init__(
        self,
        row_element: TableRow,
        column: Union[str, Enum, int],
    ):
        self.row = row_element
        self.column = column

    def _get_step_description(self, persona: Any) -> str:
        col_name = self.column.name if isinstance(self.column, Enum) else self.column
        return f"{persona} находит ячейку для колонки '{col_name}' в строке '{self.row.name}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> TableCell:
        cell_element = self.row.cell(self.column)

        # Verify it can be resolved (will raise timeout/error if not found)
        page = persona.skill(SkillId.BROWSER).page
        cell_element.resolve(page)

        self.result = cell_element
        return cell_element
