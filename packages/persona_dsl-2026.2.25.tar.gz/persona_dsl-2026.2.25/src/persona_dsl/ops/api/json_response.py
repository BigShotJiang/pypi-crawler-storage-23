from typing import Any, Optional, Dict

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_api import UseAPI


class JsonResponse(Ops):
    """
    Низкоуровневая операция: получает тело JSON-ответа после отправки запроса.
    Этот факт предполагает, что запрос УЖЕ был отправлен (например, через SendRequest),
    и мы работаем с последним ответом. В реальной реализации лучше объединить
    отправку и получение ответа в один Fact.

    Примечание: Для практического использования лучше создать Fact, который
    сам делает запрос и возвращает результат.
    """

    def __init__(
        self,
        method: str,
        path: str,
        json: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ):
        self.method = method
        self.path = path
        self.json = json
        self.params = params
        self.headers = headers
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} получает JSON-ответ от {self.method.upper()} '{self.path}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        api: UseAPI = persona.skill(SkillId.API)
        response = api._request(
            method=self.method,
            path=self.path,
            json=self.json,
            params=self.params,
            headers=self.headers,
            **self.kwargs,
        )
        return response.json()
