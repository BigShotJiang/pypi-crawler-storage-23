from typing import Any, Optional, Dict

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_api import UseAPI


class JsonAs(Ops):
    """
    Низкоуровневая операция: делает HTTP-запрос и валидирует JSON-ответ как указанный тип.
    Использует типизированные методы UseAPI (get_json_as/post_json_as/...).
    Возвращает типизированный объект согласно model_type.
    """

    def __init__(
        self,
        method: str,
        path: str,
        model_type: Any,
        json: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ):
        self.method = method
        self.path = path
        self.model_type = model_type
        self.json = json
        self.params = params
        self.headers = headers
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} запрашивает {self.method.upper()} '{self.path}' и парсит JSON как {getattr(self.model_type, '__name__', str(self.model_type))}"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> Any:
        api: UseAPI = persona.skill(SkillId.API)
        m = self.method.upper()
        if m == "GET":
            return api.get_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        if m == "POST":
            return api.post_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        if m == "PUT":
            return api.put_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        if m == "PATCH":
            return api.patch_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        if m == "DELETE":
            return api.delete_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        # Для прочих методов (HEAD/OPTIONS) пробуем соответствующие typed-методы, если они вернут None — так и вернём
        if m == "HEAD":
            return api.head_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        if m == "OPTIONS":
            return api.options_json_as(
                self.path,
                self.model_type,
                params=self.params,
                headers=self.headers,
                json=self.json,
                **self.kwargs,
            )
        # Явная ошибка для неподдерживаемых методов
        raise ValueError(f"JsonAs: неподдерживаемый метод {self.method}")
