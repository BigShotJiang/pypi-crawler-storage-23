from typing import Any, Optional, Dict

from persona_dsl.components.ops import Ops
from persona_dsl.skills.core.skill_definition import SkillId
from persona_dsl.skills.use_api import UseAPI


class SendRequest(Ops):
    """
    Низкоуровневая операция: отправляет HTTP-запрос.
    """

    def __init__(
        self,
        method: str,
        path: str,
        json: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        **kwargs: Any,
    ):
        self.method = method
        self.path = path
        self.json = json
        self.params = params
        self.headers = headers
        self.kwargs = kwargs

    def _get_step_description(self, persona: Any) -> str:
        return f"{persona} отправляет {self.method.upper()} запрос на '{self.path}'"

    def _perform(self, persona: Any, *args: Any, **kwargs: Any) -> None:
        api: UseAPI = persona.skill(SkillId.API)
        api._request(
            method=self.method,
            path=self.path,
            json=self.json,
            params=self.params,
            headers=self.headers,
            **self.kwargs,
        )
