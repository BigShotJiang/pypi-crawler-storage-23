"""TUI Widget components."""

# Widgets will be expanded as needed
