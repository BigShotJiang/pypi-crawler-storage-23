"""OpenArtemis - Harvest transcripts from YouTube, TikTok, Instagram, and X."""

from openartemis.config import load_config

load_config()  # Run first so API keys are always available

__version__ = "0.2.11"
