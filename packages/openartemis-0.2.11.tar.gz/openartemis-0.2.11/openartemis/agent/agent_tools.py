"""Agent workspace tools — read_file, write_file, list_dir, run_terminal, take_screenshot. Sandboxed to workspace.
Plugins: add .py files in ~/.openartemis/tools/ that define TOOL_SCHEMA (OpenAI function schema) and run(args) -> str."""

import base64
import importlib.util
import subprocess
from pathlib import Path
from typing import Any, Optional

from openartemis.auth.db import DATA_DIR

TOOLS_DIR = Path.home() / ".openartemis" / "tools"
PLUGIN_TOOLS: list[dict[str, Any]] = []
PLUGIN_HANDLERS: dict[str, Any] = {}

_DEFAULT_WORKSPACE = DATA_DIR / "agent_workspace"
_current_workspace: Optional[Path] = None

# Public alias for code that imports AGENT_WORKSPACE; prefer get_agent_workspace()
AGENT_WORKSPACE = _DEFAULT_WORKSPACE


def get_agent_workspace() -> Path:
    """Return current workspace (user override or default)."""
    return _current_workspace if _current_workspace is not None else _DEFAULT_WORKSPACE


def set_agent_workspace(path: Optional[Path]) -> None:
    """Set workspace override for this run. Pass None to clear."""
    global _current_workspace
    _current_workspace = path


def _resolve(path: str) -> Path:
    """Resolve path within workspace. Raises ValueError if outside."""
    base = get_agent_workspace().resolve()
    resolved = (base / path).resolve()
    if not str(resolved).startswith(str(base)):
        raise ValueError("Path must be inside workspace")
    return resolved


def read_file(path: str) -> str:
    """Read file contents. Path is relative to workspace."""
    try:
        p = _resolve(path)
        return p.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return f"Error: File not found: {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to file. Path is relative to workspace. Creates parent dirs."""
    try:
        p = _resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {path}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def list_dir(path: str = ".") -> str:
    """List files and dirs. Path is relative to workspace."""
    get_agent_workspace().mkdir(parents=True, exist_ok=True)
    try:
        p = _resolve(path)
        if not p.is_dir():
            return f"Error: Not a directory: {path}"
        items = []
        for x in sorted(p.iterdir()):
            kind = "dir" if x.is_dir() else "file"
            items.append(f"  {kind}: {x.name}")
        return "\n".join(items) if items else "(empty)"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: {e}"


def take_screenshot(url_or_path: str, prompt: str = "Describe what you see. Any issues or improvements?") -> str:
    """Take screenshot of URL or file path, send to vision model for feedback."""
    try:
        from playwright.sync_api import sync_playwright
        from openai import OpenAI
        import os

        if url_or_path.startswith(("http://", "https://")):
            url = url_or_path
        else:
            p = _resolve(url_or_path)
            url = f"file:///{p.as_posix()}"

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 720})
            page.goto(url, wait_until="networkidle", timeout=15000)
            screenshot_bytes = page.screenshot()
            browser.close()

        b64 = base64.standard_b64encode(screenshot_bytes).decode()
        client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                    ],
                }
            ],
        )
        return (resp.choices[0].message.content or "").strip()
    except Exception as e:
        return f"Error: {e}"


def run_terminal(command: str) -> str:
    """Run command in workspace directory. Restricted to workspace cwd."""
    try:
        ws = get_agent_workspace()
        ws.mkdir(parents=True, exist_ok=True)
        result = subprocess.run(
            command,
            shell=True,
            cwd=str(ws),
            capture_output=True,
            text=True,
            timeout=300,
        )
        out = result.stdout or ""
        err = result.stderr or ""
        if err:
            out = out + "\n[stderr]\n" + err
        return out.strip() or f"(exit {result.returncode})"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out (5 min)"
    except Exception as e:
        return f"Error: {e}"


def _execute_builtin(name: str, args: dict) -> str:
    """Execute built-in tool only."""
    if name == "read_file":
        return read_file(args.get("path", ""))
    if name == "write_file":
        return write_file(args.get("path", ""), args.get("content", ""))
    if name == "list_dir":
        return list_dir(args.get("path", "."))
    if name == "run_terminal":
        return run_terminal(args.get("command", ""))
    if name == "take_screenshot":
        return take_screenshot(
            args.get("url_or_path", ""),
            args.get("prompt", "Describe what you see. Any issues or improvements?"),
        )
    return f"Unknown tool: {name}"


def load_plugin_tools() -> None:
    """Load plugin tools from ~/.openartemis/tools/*.py. Each module must define TOOL_SCHEMA and run(args)."""
    global PLUGIN_TOOLS, PLUGIN_HANDLERS
    PLUGIN_TOOLS.clear()
    PLUGIN_HANDLERS.clear()
    if not TOOLS_DIR.exists():
        return
    for py in TOOLS_DIR.glob("*.py"):
        if py.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"openartemis_plugin_{py.stem}", py)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            schema = getattr(mod, "TOOL_SCHEMA", None)
            run_fn = getattr(mod, "run", None)
            if schema and callable(run_fn):
                fn = schema.get("function") if isinstance(schema, dict) else {}
                name = (fn.get("name") if isinstance(fn, dict) else None) or (schema.get("name") if isinstance(schema, dict) else None)
                if not name:
                    continue
                if isinstance(schema, dict) and schema.get("type") != "function":
                    schema = {"type": "function", "function": {"name": name, "description": str((fn or schema).get("description", "")), "parameters": (fn or schema).get("parameters", {"type": "object", "properties": {}})}}
                PLUGIN_TOOLS.append(schema)
                PLUGIN_HANDLERS[name] = run_fn
        except Exception:
            continue


def get_all_agent_tools() -> list[dict[str, Any]]:
    """Return built-in tools plus loaded plugin tools."""
    if not PLUGIN_TOOLS:
        load_plugin_tools()
    return AGENT_TOOLS + PLUGIN_TOOLS


def execute_agent_tool(name: str, args: dict) -> str:
    """Execute built-in or plugin tool by name."""
    if name in PLUGIN_HANDLERS:
        try:
            return str(PLUGIN_HANDLERS[name](args))
        except Exception as e:
            return f"Plugin error: {e}"
    return _execute_builtin(name, args)


AGENT_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read file contents. Path is relative to workspace.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "File path (e.g. index.html)"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to file. Creates parent dirs if needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path"},
                    "content": {"type": "string", "description": "File content"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "List files and directories in path.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string", "description": "Directory path (default: .)", "default": "."}},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_terminal",
            "description": "Run shell command in workspace. Use for npm, python, etc.",
            "parameters": {
                "type": "object",
                "properties": {"command": {"type": "string", "description": "Shell command to run"}},
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "take_screenshot",
            "description": "Take screenshot of URL (e.g. http://localhost:8000) or file path. Sends to vision model for feedback on UI.",
            "parameters": {
                "type": "object",
                "properties": {
                    "url_or_path": {"type": "string", "description": "URL or file path to capture"},
                    "prompt": {"type": "string", "description": "What to ask the vision model (default: describe and suggest improvements)", "default": "Describe what you see. Any issues or improvements?"},
                },
                "required": ["url_or_path"],
            },
        },
    },
]
