"""Preflight environment checker: validate required env vars and tools per mode (chat, harvest, agent, research)."""

import os
import shutil
from pathlib import Path
from typing import Any, Callable

# Mode -> list of (check_id, required, description, checker)
# checker(env) -> (ok: bool, message: str)
def _check_present(key: str) -> tuple[bool, str]:
    v = os.environ.get(key, "").strip()
    if not v:
        return False, "not set"
    if v.startswith("sk-") and len(v) < 20:
        return False, "looks like a placeholder"
    return True, "set"


def _check_ffmpeg() -> tuple[bool, str]:
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        return True, ffmpeg
    return False, "not in PATH (required for TikTok/Instagram/X audio)"


def _check_openai() -> tuple[bool, str]:
    return _check_present("OPENAI_API_KEY")


def _check_transcriptapi() -> tuple[bool, str]:
    return _check_present("TRANSCRIPTAPI_API_KEY")


def _check_youtube() -> tuple[bool, str]:
    return _check_present("YOUTUBE_API_KEY")


def _check_brave() -> tuple[bool, str]:
    return _check_present("BRAVE_SEARCH_API_KEY")


def _check_workspace() -> tuple[bool, str]:
    base = Path.home() / ".openartemis"
    agent_out = base / "agent_output"
    try:
        agent_out.mkdir(parents=True, exist_ok=True)
        return True, str(agent_out)
    except Exception as e:
        return False, str(e)


CHECKS: dict[str, list[tuple[str, bool, str, Callable[[], tuple[bool, str]]]]] = {
    "chat": [
        ("OPENAI_API_KEY", True, "Artemis chat", _check_openai),
    ],
    "harvest": [
        ("TRANSCRIPTAPI_API_KEY", False, "YouTube (TranscriptAPI)", _check_transcriptapi),
        ("YOUTUBE_API_KEY", False, "YouTube (Google API)", _check_youtube),
        ("ffmpeg", False, "TikTok/Instagram/X audio", _check_ffmpeg),
    ],
    "agent": [
        ("OPENAI_API_KEY", True, "Agent mode", _check_openai),
        ("workspace", False, "Agent output dir", _check_workspace),
    ],
    "research": [
        ("OPENAI_API_KEY", True, "Research pipeline", _check_openai),
        ("BRAVE_SEARCH_API_KEY", False, "Web search", _check_brave),
        ("TRANSCRIPTAPI_API_KEY", False, "Harvest in research", _check_transcriptapi),
    ],
}


def run_preflight(mode: str | None = None) -> list[tuple[str, str, bool, str]]:
    """
    Run preflight checks for the given mode or all modes.
    Returns list of (mode, check_id, ok, message).
    """
    modes = [mode] if mode else list(CHECKS.keys())
    results: list[tuple[str, str, bool, str]] = []
    for m in modes:
        if m not in CHECKS:
            results.append((m, "?", False, "unknown mode"))
            continue
        for check_id, required, desc, checker in CHECKS[m]:
            ok, msg = checker()
            results.append((m, check_id, ok, msg))
    return results


def preflight_table(results: list[tuple[str, str, bool, str]]) -> str:
    """Format results as a simple table string (for console or tests)."""
    lines = ["Mode     | Check              | Status  | Detail", "-" * 55]
    for mode, check_id, ok, msg in results:
        status = "OK" if ok else "MISSING"
        lines.append(f"{mode:8} | {check_id:18} | {status:7} | {msg}")
    return "\n".join(lines)
