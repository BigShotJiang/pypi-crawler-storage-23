"""Shared console formatting helpers (chat list, stream wrap) to avoid circular imports."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.console import Console


def chat_list_line(session: dict, console: "Console") -> str:
    """Format one chat session for list display; truncate title to fit terminal width."""
    title = (session.get("title") or "(no title)").strip()
    ts = (session.get("updated_at") or "")[:16]
    width = getattr(console.size, "width", 80) or 80
    max_title_len = max(20, width - 25 - len(ts))
    if len(title) > max_title_len:
        title = title[: max_title_len - 1].rstrip() + "\u2026"
    return f"  [{session['id']}] {title} \u2014 {ts}"
