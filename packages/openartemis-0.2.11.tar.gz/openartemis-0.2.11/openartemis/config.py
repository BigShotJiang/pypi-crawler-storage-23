"""Config loading — .env from project, ~/.openartemis, or cwd. Default keys for zero-setup."""

import os
from pathlib import Path

from dotenv import load_dotenv

# OpenArtemis data dir (same as auth)
CONFIG_DIR = Path.home() / ".openartemis"
CONFIG_ENV = CONFIG_DIR / ".env"

# Artemis model aliases — never expose real model names in UI
ARTEMIS_MODEL_MAP = {
    "artemis-1": "gpt-4o",
    "artemis-1-mini": "gpt-4o-mini",
}


def resolve_artemis_model(alias: str | None) -> str:
    """Resolve Artemis alias to real OpenAI model ID. Default: gpt-4o-mini."""
    if not alias:
        return "gpt-4o-mini"
    key = (alias or "").strip().lower()
    return ARTEMIS_MODEL_MAP.get(key, "gpt-4o-mini")


def get_max_tokens() -> int | None:
    """Return OPENARTEMIS_MAX_TOKENS if set (per-completion cap), else None (no cap)."""
    v = os.environ.get("OPENARTEMIS_MAX_TOKENS", "").strip()
    if not v:
        return None
    try:
        n = int(v)
        return n if n > 0 else None
    except ValueError:
        return None


def get_max_credits() -> int | None:
    """Return OPENARTEMIS_MAX_CREDITS if set (per-session credits cap), else None (no cap)."""
    v = os.environ.get("OPENARTEMIS_MAX_CREDITS", "").strip()
    if not v:
        return None
    try:
        n = int(v)
        return n if n > 0 else None
    except ValueError:
        return None


# Default API keys (login-gated; only approved users can use the app)
# Friends run "pip install openartemis" then "openartemis" — no setup needed
_DEFAULTS = {
    "OPENAI_API_KEY": "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",
    "TRANSCRIPTAPI_API_KEY": "sk_0PvwkFdm9afMiLyq1KVC_A1067aoFWE-WTQCdYD3uCc",
    "SCRAPINGDOG_API_KEY": "5eaa61a6e562fc52fe763tr516e4653",
    "BRAVE_SEARCH_API_KEY": "BSADXSyagBkdXqvjm5p3BcanvLhrlOL",
}


def _ensure_default_config() -> None:
    """Create ~/.openartemis/.env with default keys if missing."""
    if not CONFIG_ENV.exists():
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        lines = ["# OpenArtemis config (auto-created)\n"]
        for k, v in _DEFAULTS.items():
            lines.append(f"{k}={v}\n")
        CONFIG_ENV.write_text("".join(lines), encoding="utf-8")


def _apply_defaults() -> None:
    """Set env vars from defaults when not already set."""
    for key, val in _DEFAULTS.items():
        if not os.environ.get(key):
            os.environ[key] = val


# Profile-driven defaults (OPENARTEMIS_PROFILE=local|cloud|rl-heavy)
PROFILE_CONFIGS: dict[str, dict[str, int | str]] = {
    "local": {"max_workers": 3, "default_model": "artemis-1-mini"},
    "cloud": {"max_workers": 8, "default_model": "artemis-1-mini"},
    "rl-heavy": {"max_workers": 4, "default_model": "artemis-1"},
}


def get_profile() -> str:
    """Current profile from OPENARTEMIS_PROFILE. Default: cloud."""
    v = os.environ.get("OPENARTEMIS_PROFILE", "").strip().lower()
    if v in PROFILE_CONFIGS:
        return v
    return "cloud"


def get_profile_setting(key: str, default: int | str | None = None) -> int | str | None:
    """Get a profile-specific setting (e.g. max_workers, default_model)."""
    profile = get_profile()
    cfg = PROFILE_CONFIGS.get(profile, {})
    if key in cfg:
        return cfg[key]
    return default


def load_config() -> None:
    """Load .env from project root, ~/.openartemis, then cwd. Apply defaults for zero-setup."""
    pkg_root = Path(__file__).resolve().parents[1]
    load_dotenv(pkg_root / ".env")
    load_dotenv(CONFIG_ENV)
    load_dotenv(Path.cwd() / ".env")
    _ensure_default_config()
    _apply_defaults()
