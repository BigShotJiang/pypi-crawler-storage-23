"""Retry helper: max attempts, backoff, optional variation for agent/pipeline LLM and tool calls."""

import time
from typing import Callable, TypeVar

from openartemis.errors import ErrorType, classify_exception, is_retriable

T = TypeVar("T")


def retry_with_backoff(
    fn: Callable[[], T],
    max_attempts: int = 3,
    backoff_base: float = 1.0,
    backoff_max: float = 60.0,
    on_retry: Callable[[int, Exception], None] | None = None,
) -> T:
    """
    Call fn(); on exception, classify and retry if retriable (RateLimit, Transient).
    Uses exponential backoff: backoff_base * 2 ** attempt, capped at backoff_max.
    Raises the last exception if all attempts fail.
    """
    last: BaseException | None = None
    for attempt in range(max_attempts):
        try:
            return fn()
        except BaseException as e:
            last = e
            et = classify_exception(e)
            if not is_retriable(et) or attempt == max_attempts - 1:
                raise
            delay = min(backoff_base * (2**attempt), backoff_max)
            if on_retry:
                on_retry(attempt + 1, e)
            time.sleep(delay)
    if last:
        raise last
    raise RuntimeError("retry_with_backoff: no result")
