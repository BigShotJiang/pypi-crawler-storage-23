"""ACP adapters for shared command handlers."""
