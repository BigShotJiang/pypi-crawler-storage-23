sql_assignment_generator.assignments
====================================

.. py:module:: sql_assignment_generator.assignments

.. autoapi-nested-parse::

   Data structures for SQL assignments.



Classes
-------

.. autoapisummary::

   sql_assignment_generator.assignments.Assignment
   sql_assignment_generator.assignments.Exercise
   sql_assignment_generator.assignments.Dataset


Package Contents
----------------

.. py:class:: Assignment

   A full SQL assignment consisting of a dataset and exercises.


   .. py:attribute:: dataset
      :type:  sql_assignment_generator.assignments.dataset.Dataset

      The dataset associated with the assignment.



   .. py:attribute:: exercises
      :type:  list[sql_assignment_generator.assignments.exercise.Exercise]

      The exercises included in the assignment.



.. py:class:: Exercise

   A SQL exercise consisting of a title, request, and solutions.


   .. py:attribute:: title
      :type:  str

      The title of the exercise.



   .. py:attribute:: request
      :type:  str

      The natural language request or question for the exercise.



   .. py:attribute:: solutions
      :type:  list[sqlscope.Query]

      The list of SQL query solutions for the exercise.



   .. py:attribute:: difficulty
      :type:  sql_assignment_generator.difficulty_level.DifficultyLevel

      The difficulty level of the exercise.



   .. py:attribute:: error
      :type:  sql_error_taxonomy.SqlErrors

      The SQL error type associated with the exercise.



   .. py:method:: generate(error, difficulty, constraints, *, extra_details, dataset, title, sql_dialect, language, max_attempts = 3)
      :staticmethod:


      Generate a SQL exercise based on the specified parameters.



.. py:class:: Dataset

   A SQL dataset related to a specific domain, including schema creation and data insertion commands.


   .. py:attribute:: create_commands
      :type:  list[str]

      SQL commands to create the database schema.



   .. py:attribute:: insert_commands
      :type:  list[str]

      SQL commands to insert data into the database.



   .. py:attribute:: domain
      :type:  str

      The domain associated with the dataset.



   .. py:attribute:: _catalog_cache
      :type:  sqlscope.Catalog | None
      :value: None


      Cached SQLScope Catalog for the dataset.



   .. py:attribute:: _catalog_cache_commands_hash
      :type:  int | None
      :value: None


      Hash of the CREATE TABLE commands used to build the cached Catalog.



   .. py:property:: catalog
      :type: sqlscope.Catalog


      Build and return a SQLScope Catalog from the dataset's SQL commands.
      The result is cached for handling multiple accesses efficiently.
      Cache is properly invalidated if the CREATE TABLE commands change.



   .. py:method:: to_sql_no_context()

      Generate the SQL commands to create and populate the dataset without schema context.



   .. py:method:: to_sql(schema)

      Generate the SQL commands to create and populate the dataset within the specified schema.



   .. py:method:: from_sql(sql_str, sql_dialect)
      :staticmethod:


      Create a Dataset instance from a raw SQL string containing CREATE TABLE and INSERT INTO commands.



   .. py:method:: generate(domain, sql_dialect, constraints, extra_details = [], *, language, max_attempts = 5)
      :staticmethod:


      Generate a SQL dataset based on the specified parameters.



