sql_assignment_generator.constraints
====================================

.. py:module:: sql_assignment_generator.constraints

.. autoapi-nested-parse::

   Constraints for assignment generation.



Submodules
----------

.. toctree::
   :maxdepth: 1

   /autoapi/sql_assignment_generator/constraints/query/index
   /autoapi/sql_assignment_generator/constraints/schema/index


Classes
-------

.. autoapisummary::

   sql_assignment_generator.constraints.BaseConstraint
   sql_assignment_generator.constraints.QueryConstraint
   sql_assignment_generator.constraints.SchemaConstraint


Package Contents
----------------

.. py:class:: BaseConstraint

   Bases: :py:obj:`abc.ABC`


   Abstract base class for SQL query constraints.


   .. py:property:: description
      :type: sql_assignment_generator.translatable_text.TranslatableText

      :abstractmethod:


      Textual description of the constraint, to be used in prompts.



.. py:class:: QueryConstraint

   Bases: :py:obj:`sql_assignment_generator.constraints.base.BaseConstraint`


   Base class for query-related constraints.


   .. py:method:: validate(query)
      :abstractmethod:


      Validate if the given SQL query satisfies the constraint.

      Args:
          query (Query): The SQL query to validate.
      Raises:
          ConstraintValidationError: If the query does not satisfy the constraint.



.. py:class:: SchemaConstraint

   Bases: :py:obj:`sql_assignment_generator.constraints.base.BaseConstraint`


   Base class for schema-related constraints.


   .. py:method:: validate(catalog, tables_sql, values_sql)
      :abstractmethod:


      Validate if the given table creation and insertion statements satisfy the constraint.

      Args:
          catalog (Catalog): The catalog representing the database schema.
          tables_sql (list[exp.Create]): List of CREATE TABLE expressions.
          values_sql (list[exp.Insert]): List of INSERT INTO expressions.
      Raises:
          ConstraintValidationError: If the schema does not satisfy the constraint.



   .. py:method:: merge(other)
      :abstractmethod:


      Merges this constraint with another constraint of the same type.



