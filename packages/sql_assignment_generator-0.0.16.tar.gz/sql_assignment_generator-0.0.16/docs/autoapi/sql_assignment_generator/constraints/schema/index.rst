sql_assignment_generator.constraints.schema
===========================================

.. py:module:: sql_assignment_generator.constraints.schema

.. autoapi-nested-parse::

   Constraints related to database schema.



Classes
-------

.. autoapisummary::

   sql_assignment_generator.constraints.schema.SchemaConstraint


Functions
---------

.. autoapisummary::

   sql_assignment_generator.constraints.schema.merge_constraints


Package Contents
----------------

.. py:class:: SchemaConstraint

   Bases: :py:obj:`sql_assignment_generator.constraints.base.BaseConstraint`


   Base class for schema-related constraints.


   .. py:method:: validate(catalog, tables_sql, values_sql)
      :abstractmethod:


      Validate if the given table creation and insertion statements satisfy the constraint.

      Args:
          catalog (Catalog): The catalog representing the database schema.
          tables_sql (list[exp.Create]): List of CREATE TABLE expressions.
          values_sql (list[exp.Insert]): List of INSERT INTO expressions.
      Raises:
          ConstraintValidationError: If the schema does not satisfy the constraint.



   .. py:method:: merge(other)
      :abstractmethod:


      Merges this constraint with another constraint of the same type.



.. py:function:: merge_constraints(constraints)

   Merge similar schema constraints into a single set of constraints.


