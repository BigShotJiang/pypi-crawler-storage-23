sql_assignment_generator.constraints.query
==========================================

.. py:module:: sql_assignment_generator.constraints.query

.. autoapi-nested-parse::

   Constraints related to SQL queries.



Classes
-------

.. autoapisummary::

   sql_assignment_generator.constraints.query.QueryConstraint


Package Contents
----------------

.. py:class:: QueryConstraint

   Bases: :py:obj:`sql_assignment_generator.constraints.base.BaseConstraint`


   Base class for query-related constraints.


   .. py:method:: validate(query)
      :abstractmethod:


      Validate if the given SQL query satisfies the constraint.

      Args:
          query (Query): The SQL query to validate.
      Raises:
          ConstraintValidationError: If the query does not satisfy the constraint.



