sql_assignment_generator.llm.models
===================================

.. py:module:: sql_assignment_generator.llm.models

.. autoapi-nested-parse::

   JSON models for LLM outputs.



Classes
-------

.. autoapisummary::

   sql_assignment_generator.llm.models.Assignment
   sql_assignment_generator.llm.models.Schema
   sql_assignment_generator.llm.models.RemoveHints


Module Contents
---------------

.. py:class:: Assignment(/, **data)

   Bases: :py:obj:`pydantic.BaseModel`


   JSON model for assignments


.. py:class:: Schema(/, **data)

   Bases: :py:obj:`pydantic.BaseModel`


   JSON model for database schemas


.. py:class:: RemoveHints(/, **data)

   Bases: :py:obj:`pydantic.BaseModel`


   JSON model for removing hints from a request


