sql_assignment_generator.llm
============================

.. py:module:: sql_assignment_generator.llm

.. autoapi-nested-parse::

   Interaction with LLMs



Submodules
----------

.. toctree::
   :maxdepth: 1

   /autoapi/sql_assignment_generator/llm/models/index


Functions
---------

.. autoapisummary::

   sql_assignment_generator.llm.generate_answer


Package Contents
----------------

.. py:function:: generate_answer(message, *, json_format, add_to_messages = True, **kwargs)

   Generate an answer from the LLM using the provided message and tools.


