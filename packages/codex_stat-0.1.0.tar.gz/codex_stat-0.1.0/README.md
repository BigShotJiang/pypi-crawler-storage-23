# codex-stat

一个可以读取本地 `~/.codex/sessions` 日志、统计 Codex token 用量并估算价格的命令行工具。

可以通过 `uvx codex-stat` 直接调用。

## 功能

- 统计 `input_tokens`、`cached_input_tokens`、`output_tokens`、`reasoning_output_tokens`
- 按 `today`、`7d`、`30d`、`all` 或自定义日期范围查询
- 输出人类可读报表或 JSON
- 按每 1M token 单价估算成本

## 本地开发

```bash
uv run codex-stat --range today
uv run codex-stat --range 7d --limit 5
uv run codex-stat --from-date 2026-03-01 --to-date 2026-03-06
uv run codex-stat --range today --json
```

## 成本估算

```bash
uv run codex-stat \
  --range today \
  --input-price-per-m 2.5 \
  --cached-input-price-per-m 1.25 \
  --output-price-per-m 10
```

估价公式：

- 非缓存输入 = `input_tokens - cached_input_tokens`
- 总费用 = 非缓存输入费用 + 缓存输入费用 + 输出费用
- `reasoning_output_tokens` 仅做展示，通常已经包含在 `output_tokens` 中
