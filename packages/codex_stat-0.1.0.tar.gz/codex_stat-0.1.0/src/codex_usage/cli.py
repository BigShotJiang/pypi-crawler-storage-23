from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from typing import Any

DATE_PATH_RE = re.compile(r"/(\d{4})/(\d{2})/(\d{2})/")


@dataclass(slots=True)
class Usage:
    input_tokens: int = 0
    cached_input_tokens: int = 0
    output_tokens: int = 0
    reasoning_output_tokens: int = 0
    total_tokens: int = 0

    @property
    def non_cached_input_tokens(self) -> int:
        return max(self.input_tokens - self.cached_input_tokens, 0)

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(slots=True)
class Pricing:
    input_per_million: float = 0.0
    cached_input_per_million: float = 0.0
    output_per_million: float = 0.0

    def enabled(self) -> bool:
        return any(
            value > 0
            for value in (
                self.input_per_million,
                self.cached_input_per_million,
                self.output_per_million,
            )
        )

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(slots=True)
class SessionSummary:
    session_id: str | None
    timestamp: datetime
    provider: str
    cwd: str
    file_path: str
    total_usage: Usage
    last_usage: Usage
    estimated_cost: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "timestamp": self.timestamp.isoformat(),
            "provider": self.provider,
            "cwd": self.cwd,
            "file_path": self.file_path,
            "total_usage": self.total_usage.to_dict(),
            "last_usage": self.last_usage.to_dict(),
            "estimated_cost": round(self.estimated_cost, 8),
        }


@dataclass(slots=True)
class Window:
    label: str
    start: datetime | None
    end: datetime | None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "label": self.label,
            "start": self.start.isoformat() if self.start else None,
            "end": self.end.isoformat() if self.end else None,
        }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Query Codex CLI token usage from local session JSONL logs.",
    )
    parser.add_argument(
        "--sessions-dir",
        default="~/.codex/sessions",
        help="Codex session directory, default: ~/.codex/sessions",
    )
    parser.add_argument(
        "--range",
        choices=("today", "7d", "30d", "all"),
        default="today",
        help="Quick time window, default: today",
    )
    parser.add_argument(
        "--from-date",
        type=parse_date_arg,
        help="Custom start date in YYYY-MM-DD, overrides --range",
    )
    parser.add_argument(
        "--to-date",
        type=parse_date_arg,
        help="Custom end date in YYYY-MM-DD, overrides --range",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="How many recent sessions to print, default: 10",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print JSON instead of a text report",
    )
    parser.add_argument(
        "--input-price-per-m",
        type=float,
        default=0.0,
        help="Non-cached input price per 1M tokens",
    )
    parser.add_argument(
        "--cached-input-price-per-m",
        type=float,
        default=0.0,
        help="Cached input price per 1M tokens",
    )
    parser.add_argument(
        "--output-price-per-m",
        type=float,
        default=0.0,
        help="Output price per 1M tokens",
    )
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def parse_date_arg(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"invalid date: {value}") from exc


def current_timezone() -> timezone:
    tzinfo = datetime.now().astimezone().tzinfo
    if tzinfo is None:
        return timezone.utc
    return tzinfo


def build_window(args: argparse.Namespace, tzinfo: timezone) -> Window:
    now = datetime.now(tzinfo)
    if args.from_date or args.to_date:
        start = (
            datetime.combine(args.from_date, time.min, tzinfo=tzinfo)
            if args.from_date
            else None
        )
        end = (
            datetime.combine(args.to_date, time.max, tzinfo=tzinfo)
            if args.to_date
            else None
        )
        return Window(label="custom", start=start, end=end)

    if args.range == "all":
        return Window(label="all", start=None, end=None)
    if args.range == "today":
        start = datetime.combine(now.date(), time.min, tzinfo=tzinfo)
        return Window(label="today", start=start, end=now)
    if args.range == "7d":
        return Window(label="7d", start=now - timedelta(days=7), end=now)
    return Window(label="30d", start=now - timedelta(days=30), end=now)


def expand_path(path_text: str) -> Path:
    return Path(path_text).expanduser().resolve()


def parse_timestamp(value: str | None) -> datetime | None:
    if not value:
        return None
    normalized = value.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def infer_timestamp_from_path(file_path: Path) -> datetime | None:
    match = DATE_PATH_RE.search(file_path.as_posix())
    if not match:
        return None
    year, month, day = (int(piece) for piece in match.groups())
    return datetime(year, month, day, tzinfo=timezone.utc)


def normalize_usage(payload: dict[str, Any] | None) -> Usage:
    payload = payload or {}
    input_tokens = int(payload.get("input_tokens", 0) or 0)
    cached_input_tokens = int(payload.get("cached_input_tokens", 0) or 0)
    output_tokens = int(payload.get("output_tokens", 0) or 0)
    reasoning_output_tokens = int(payload.get("reasoning_output_tokens", 0) or 0)
    total_tokens = int(payload.get("total_tokens", 0) or 0)
    if total_tokens <= 0:
        total_tokens = input_tokens + output_tokens
    return Usage(
        input_tokens=input_tokens,
        cached_input_tokens=cached_input_tokens,
        output_tokens=output_tokens,
        reasoning_output_tokens=reasoning_output_tokens,
        total_tokens=total_tokens,
    )


def estimate_cost(usage: Usage, pricing: Pricing) -> float:
    return (
        usage.non_cached_input_tokens / 1_000_000 * pricing.input_per_million
        + usage.cached_input_tokens / 1_000_000 * pricing.cached_input_per_million
        + usage.output_tokens / 1_000_000 * pricing.output_per_million
    )


def load_session(
    file_path: Path, tzinfo: timezone, pricing: Pricing
) -> SessionSummary | None:
    session_meta: dict[str, Any] = {}
    total_usage: Usage | None = None
    last_usage: Usage | None = None

    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue

        if event.get("type") == "session_meta":
            session_meta = event.get("payload") or {}
            continue

        payload = event.get("payload") or {}
        if event.get("type") == "event_msg" and payload.get("type") == "token_count":
            info = payload.get("info") or {}
            total_usage = normalize_usage(info.get("total_token_usage"))
            last_usage = normalize_usage(info.get("last_token_usage"))

    if total_usage is None:
        return None

    timestamp = parse_timestamp(session_meta.get("timestamp"))
    if timestamp is None:
        timestamp = infer_timestamp_from_path(file_path)
    if timestamp is None:
        timestamp = datetime.fromtimestamp(file_path.stat().st_mtime, tz=timezone.utc)

    timestamp = timestamp.astimezone(tzinfo)
    last_usage = last_usage or Usage()
    return SessionSummary(
        session_id=session_meta.get("id"),
        timestamp=timestamp,
        provider=str(session_meta.get("model_provider") or "unknown"),
        cwd=str(session_meta.get("cwd") or ""),
        file_path=str(file_path),
        total_usage=total_usage,
        last_usage=last_usage,
        estimated_cost=estimate_cost(total_usage, pricing),
    )


def load_sessions(
    root: Path, tzinfo: timezone, pricing: Pricing
) -> list[SessionSummary]:
    if not root.exists():
        raise FileNotFoundError(f"sessions dir not found: {root}")

    sessions: list[SessionSummary] = []
    for file_path in root.rglob("*.jsonl"):
        session = load_session(file_path, tzinfo, pricing)
        if session is not None:
            sessions.append(session)

    sessions.sort(key=lambda item: item.timestamp, reverse=True)
    return sessions


def filter_sessions(
    sessions: list[SessionSummary], window: Window
) -> list[SessionSummary]:
    filtered: list[SessionSummary] = []
    for session in sessions:
        if window.start and session.timestamp < window.start:
            continue
        if window.end and session.timestamp > window.end:
            continue
        filtered.append(session)
    return filtered


def aggregate_usage(sessions: list[SessionSummary]) -> Usage:
    result = Usage()
    for session in sessions:
        usage = session.total_usage
        result.input_tokens += usage.input_tokens
        result.cached_input_tokens += usage.cached_input_tokens
        result.output_tokens += usage.output_tokens
        result.reasoning_output_tokens += usage.reasoning_output_tokens
        result.total_tokens += usage.total_tokens
    return result


def summarize(
    sessions: list[SessionSummary],
    window: Window,
    pricing: Pricing,
    limit: int,
    sessions_dir: Path,
    tzinfo: timezone,
) -> dict[str, Any]:
    aggregate = aggregate_usage(sessions)
    total_cost = sum(session.estimated_cost for session in sessions)
    return {
        "sessions_dir": str(sessions_dir),
        "timezone": str(tzinfo),
        "window": window.to_dict(),
        "pricing": pricing.to_dict(),
        "summary": {
            "session_count": len(sessions),
            "usage": aggregate.to_dict(),
            "non_cached_input_tokens": aggregate.non_cached_input_tokens,
            "estimated_cost": round(total_cost, 8),
        },
        "recent_sessions": [session.to_dict() for session in sessions[: max(limit, 0)]],
    }


def format_int(value: int) -> str:
    return f"{value:,}"


def format_money(value: float) -> str:
    return f"${value:,.6f}"


def shorten(text: str, width: int) -> str:
    if width <= 0 or len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3] + "..."


def print_report(report: dict[str, Any], pricing: Pricing) -> None:
    summary = report["summary"]
    usage = summary["usage"]
    window = report["window"]

    print("Codex Usage Report")
    print(f"Sessions dir : {report['sessions_dir']}")
    print(f"Timezone     : {report['timezone']}")
    print(f"Window       : {window['label']} ({window['start']} -> {window['end']})")
    print(f"Sessions     : {summary['session_count']}")
    print()

    print("Tokens")
    print(f"  Input              : {format_int(usage['input_tokens'])}")
    print(f"  Cached input       : {format_int(usage['cached_input_tokens'])}")
    print(f"  Non-cached input   : {format_int(summary['non_cached_input_tokens'])}")
    print(f"  Output             : {format_int(usage['output_tokens'])}")
    print(f"  Reasoning output   : {format_int(usage['reasoning_output_tokens'])}")
    print(f"  Total              : {format_int(usage['total_tokens'])}")

    if pricing.enabled():
        print()
        print("Estimated Cost")
        print(f"  Total              : {format_money(summary['estimated_cost'])}")
        print(
            "  Note               : reasoning tokens are counted inside output tokens"
        )

    recent_sessions = report["recent_sessions"]
    if not recent_sessions:
        return

    print()
    print("Recent Sessions")
    header = (
        f"{'Time':16}  {'Provider':10}  {'Total':>12}  {'Input':>12}  "
        f"{'Cached':>12}  {'Output':>12}  {'Cost':>10}  CWD"
    )
    print(header)
    print("-" * len(header))
    for session in recent_sessions:
        total_usage = session["total_usage"]
        timestamp = parse_timestamp(session["timestamp"])
        when = timestamp.strftime("%Y-%m-%d %H:%M") if timestamp else "-"
        cost_text = (
            format_money(session["estimated_cost"]) if pricing.enabled() else "-"
        )
        row = (
            f"{when:16}  "
            f"{shorten(session['provider'], 10):10}  "
            f"{format_int(total_usage['total_tokens']):>12}  "
            f"{format_int(total_usage['input_tokens']):>12}  "
            f"{format_int(total_usage['cached_input_tokens']):>12}  "
            f"{format_int(total_usage['output_tokens']):>12}  "
            f"{cost_text:>10}  "
            f"{shorten(session['cwd'], 48)}"
        )
        print(row)


def run(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    tzinfo = current_timezone()
    sessions_dir = expand_path(args.sessions_dir)
    pricing = Pricing(
        input_per_million=args.input_price_per_m,
        cached_input_per_million=args.cached_input_price_per_m,
        output_per_million=args.output_price_per_m,
    )
    window = build_window(args, tzinfo)

    try:
        sessions = load_sessions(sessions_dir, tzinfo, pricing)
    except FileNotFoundError as exc:
        print(str(exc))
        return 1

    filtered_sessions = filter_sessions(sessions, window)
    report = summarize(
        filtered_sessions,
        window=window,
        pricing=pricing,
        limit=args.limit,
        sessions_dir=sessions_dir,
        tzinfo=tzinfo,
    )

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print_report(report, pricing)
    return 0


def main() -> None:
    raise SystemExit(run())
