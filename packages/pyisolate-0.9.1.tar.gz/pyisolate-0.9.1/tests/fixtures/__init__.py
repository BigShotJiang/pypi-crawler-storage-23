"""Test fixtures for pyisolate unit tests.

This package contains reference implementations and test utilities
that demonstrate proper adapter patterns and enable contract testing.
"""
