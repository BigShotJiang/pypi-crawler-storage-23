# baponi-sdk

**This package has moved to [`baponi`](https://pypi.org/project/baponi/).**

```bash
pip install baponi
```

This package exists only to reserve the name and redirect users. Installing it will install `baponi` as a dependency.
