# -*- coding: utf-8 -*-
"""
Optional tuning (post-training) module for AtendentePro.

Consumes feedback from Supabase (conversation_message_feedback) and records
from MonkAI Trace, then generates and optionally applies suggestions to client YAML configs.

Install with: pip install atendentepro[tuning]

Environment: SUPABASE_URL, SUPABASE_SERVICE_KEY (or SUPABASE_ANON_KEY), MONKAI_TRACER_TOKEN.
"""

from atendentepro.tuning.mapping import AGENT_TO_YAML, CUSTOMIZABLE_YAML_FILES, get_yaml_for_agent
from atendentepro.tuning.suggestions import Suggestion

__all__ = [
    "AGENT_TO_YAML",
    "CUSTOMIZABLE_YAML_FILES",
    "Suggestion",
    "get_yaml_for_agent",
    "load_feedback_for_tuning",
    "load_records_from_trace",
    "merge_feedback_with_records",
    "run_analysis",
    "apply_suggestions",
    "write_suggestions_to_folder",
    "replace_originals_with_suggested",
    "run_tuning_pipeline",
]


def load_feedback_for_tuning(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Load feedback from Supabase. Requires atendentepro[tuning]."""
    from atendentepro.tuning.client import fetch_feedback
    return fetch_feedback(*args, **kwargs)


def load_records_from_trace(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Load records from MonkAI Trace. Requires atendentepro[tuning]."""
    from atendentepro.tuning.client import load_trace_records
    return load_trace_records(*args, **kwargs)


def merge_feedback_with_records(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Merge feedback rows with trace records by session_id/message_id."""
    from atendentepro.tuning.client import merge_feedback_with_records as _merge
    return _merge(*args, **kwargs)


def run_analysis(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Run heuristic analysis on enriched records; returns list of Suggestion."""
    from atendentepro.tuning.analyzer import run_analysis as _run
    return _run(*args, **kwargs)


def apply_suggestions(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Apply suggestions to client YAML files. Supports dry_run and backup."""
    from atendentepro.tuning.applier import apply_suggestions as _apply
    return _apply(*args, **kwargs)


def write_suggestions_to_folder(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Write modified YAMLs to client/_suggested/ for review. Originals unchanged."""
    from atendentepro.tuning.applier import write_suggestions_to_folder as _write
    return _write(*args, **kwargs)


def replace_originals_with_suggested(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Copy YAMLs from client/_suggested/ to client/, overwriting originals. Call after review."""
    from atendentepro.tuning.applier import replace_originals_with_suggested as _replace
    return _replace(*args, **kwargs)


def run_tuning_pipeline(*args: object, **kwargs: object):  # type: ignore[no-any-unimported]
    """Run full pipeline: fetch -> merge -> run_analysis -> optionally apply_suggestions."""
    from atendentepro.tuning.pipeline import run_tuning_pipeline as _pipeline
    return _pipeline(*args, **kwargs)
