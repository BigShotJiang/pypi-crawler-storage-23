# -*- coding: utf-8 -*-
"""
Analyzer: from enriched records (feedback + trace) to list of Suggestion.

Phase 1: heuristic (extract terms from description / last user message, suggest
add_triage_keyword or escalation/feedback triggers).
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any, Dict, List

from atendentepro.tuning.mapping import get_yaml_for_agent
from atendentepro.tuning.suggestions import Suggestion


def _extract_words(text: str, min_len: int = 2) -> List[str]:
    """Extract normalized words from text for keyword suggestions."""
    if not text or not isinstance(text, str):
        return []
    text = text.lower().strip()
    words = re.findall(r"[a-zà-ú0-9]+", text)
    return [w for w in words if len(w) >= min_len and w not in ("nao", "na", "que", "com", "para", "uma", "por", "dos", "das")]


def _last_user_message(record: Dict[str, Any]) -> str:
    """Get last user message content from record messages."""
    messages = record.get("messages") or record.get("message") or []
    if isinstance(messages, str):
        return messages
    for m in reversed(messages):
        if isinstance(m, dict) and m.get("role") == "user":
            content = m.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        return part.get("text") or ""
            break
    return ""


def run_analysis(
    enriched_records: List[Dict[str, Any]],
    deduplicate: bool = True,
) -> List[Suggestion]:
    """
    Run heuristic analysis on enriched records and return list of Suggestion.

    - For Triage Agent: extracts words from description and last user message,
      suggests add_triage_keyword for the agent that received feedback (so it can
      be routed there when similar words appear).
    - For Escalation Agent: if description mentions human/reclamação, suggests
      add_escalation_trigger.
    - For Feedback Agent: if description mentions reclamação/sugestão, suggests
      add_feedback_ticket_type or trigger.

    Args:
        enriched_records: List from merge_feedback_with_records.
        deduplicate: If True, merge suggestions with same (yaml_file, change_type, payload key).

    Returns:
        List of Suggestion.
    """
    suggestions: List[Suggestion] = []
    seen: Dict[tuple, Suggestion] = {}

    for rec in enriched_records:
        agent_name = rec.get("agent_name") or ""
        description = (rec.get("description") or "").strip()
        yaml_file = get_yaml_for_agent(agent_name)
        if not yaml_file:
            continue

        # Triage: suggest adding keywords so this agent is chosen for similar queries
        if yaml_file == "triage_config.yaml":
            words = _extract_words(description)
            last_msg = _last_user_message(rec)
            words.extend(_extract_words(last_msg))
            for w in words[:5]:  # Limit to 5 keywords per record
                if not w:
                    continue
                payload = {"target_agent": agent_name, "keyword": w}
                key = (yaml_file, "add_triage_keyword", w, agent_name)
                if deduplicate and key in seen:
                    continue
                s = Suggestion(
                    yaml_file=yaml_file,
                    agent_name=agent_name,
                    change_type="add_triage_keyword",
                    payload=payload,
                    reason=description or f"From user message: {last_msg[:80]}",
                )
                suggestions.append(s)
                if deduplicate:
                    seen[key] = s

        # Escalation: suggest adding trigger phrases
        if yaml_file == "escalation_config.yaml":
            desc_lower = description.lower()
            if any(
                x in desc_lower
                for x in ("humano", "atendente", "pessoa", "reclamação", "reclamacao", "falar com")
            ):
                payload = {"trigger_phrase": description[:100] or "falar com humano"}
                key = (yaml_file, "add_escalation_trigger", payload["trigger_phrase"])
                if deduplicate and key in seen:
                    continue
                s = Suggestion(
                    yaml_file=yaml_file,
                    agent_name=agent_name,
                    change_type="add_escalation_trigger",
                    payload=payload,
                    reason=description,
                )
                suggestions.append(s)
                if deduplicate:
                    seen[key] = s

        # Feedback: suggest adding ticket type or priority keyword
        if yaml_file == "feedback_config.yaml":
            desc_lower = description.lower()
            if "reclamação" in desc_lower or "reclamacao" in desc_lower:
                payload = {"suggestion": "ensure reclamacao ticket type and high priority"}
                key = (yaml_file, "feedback_ensure_reclamacao", "reclamacao")
                if deduplicate and key not in seen:
                    s = Suggestion(
                        yaml_file=yaml_file,
                        agent_name=agent_name,
                        change_type="feedback_ensure_reclamacao",
                        payload=payload,
                        reason=description,
                    )
                    suggestions.append(s)
                    seen[key] = s

    return suggestions
