# Tuning (Post-Training) Module

Optional module to improve client YAML configs based on conversation feedback and Trace records.

## Installation

```bash
pip install atendentepro[tuning]
```

## Environment

- `SUPABASE_URL` – Supabase project URL
- `SUPABASE_SERVICE_KEY` or `SUPABASE_ANON_KEY` – Supabase API key (read access to `conversation_message_feedback`)
- `MONKAI_TRACER_TOKEN` – MonkAI Trace token for querying records

## Pipeline

1. **Fetch feedback** from Supabase table `conversation_message_feedback` (filters: namespace, start_date, end_date, user_ids, feedback="negative").
2. **Load records** from MonkAI Trace via `query_records` (namespace, start_date, end_date, limit).
3. **Merge** by `session_id` and `message_id` so each record has messages, agent_name, feedback, description.
4. **Analyze** (heuristic or LLM) to produce suggestions (e.g. add_triage_keyword, add_escalation_trigger).
5. **Apply** (optional): write suggestions to a **suggested folder** (`client/_suggested/`) for review, or in-place with backup. After reviewing, the user can call `replace_originals_with_suggested()` to overwrite originals.

## Suggested folder flow (recommended)

1. Run the pipeline with `apply=True` and `write_to_suggested_folder=True` (default). Modified YAMLs are written to `client/_suggested/` and a report `_suggestions_report.json` is generated. **Originals are not changed.**
2. Review the files in `client/_suggested/` and the report.
3. If you approve, call `replace_originals_with_suggested(client, templates_root)` to copy suggested YAMLs over the originals.

## Usage

### Full pipeline with suggested folder (recommended)

```python
from pathlib import Path
from atendentepro.tuning import run_tuning_pipeline, replace_originals_with_suggested

# 1. Generate suggestions and write to client/_suggested/
result = run_tuning_pipeline(
    namespace="customer-support",
    client="meu_cliente",
    templates_root=Path("./client_templates"),
    start_date="2025-01-01",
    end_date="2025-01-31",
    feedback_value="negative",
    apply=True,
    write_to_suggested_folder=True,  # default
)
print("Suggestions:", result["suggestions"])
print("Written to:", result.get("suggested_folder"), result.get("written_files"))
print("Report:", result.get("report_path"))

# 2. After reviewing client_templates/meu_cliente/_suggested/, replace originals
replace_result = replace_originals_with_suggested(
    client="meu_cliente",
    templates_root=Path("./client_templates"),
    remove_suggested_after=False,  # set True to delete _suggested after copy
)
print("Replaced:", replace_result["replaced_files"])
```

### Pipeline without applying (only get suggestions)

```python
result = run_tuning_pipeline(
    namespace="customer-support",
    client="meu_cliente",
    templates_root=Path("./client_templates"),
    start_date="2025-01-01",
    feedback_value="negative",
    apply=False,
)
print("Suggestions:", result["suggestions"])
print("Counts:", result["feedback_count"], result["records_count"], result["enriched_count"])
```

### Step by step

```python
from pathlib import Path
from atendentepro.tuning import (
    load_feedback_for_tuning,
    load_records_from_trace,
    merge_feedback_with_records,
    run_analysis,
    apply_suggestions,
)

feedback = load_feedback_for_tuning(
    namespace="customer-support",
    start_date="2025-01-01",
    feedback_value="negative",
)
records = load_records_from_trace(namespace="customer-support", start_date="2025-01-01")
enriched = merge_feedback_with_records(feedback, records)
suggestions = run_analysis(enriched)

# Optional: write to suggested folder for review (originals unchanged)
from atendentepro.tuning import write_suggestions_to_folder

write_result = write_suggestions_to_folder(
    client="meu_cliente",
    suggestions=suggestions,
    templates_root=Path("./client_templates"),
    suggested_subdir="_suggested",
)
print("Written:", write_result["written_files"], "to", write_result["suggested_folder"])

# Or apply in-place with dry_run first (writes to originals with backup)
apply_suggestions(
    client="meu_cliente",
    suggestions=suggestions,
    templates_root=Path("./client_templates"),
    dry_run=True,
    backup=True,
)
```

## Suggestion types

- **add_triage_keyword** – Add a keyword to `triage_config.yaml` for a target agent (payload: `target_agent`, `keyword`).
- **add_escalation_trigger** – Add a trigger phrase to `escalation_config.yaml` (payload: `trigger_phrase`).
- **feedback_ensure_reclamacao** – Informational; ensures feedback config has reclamação handling.

## Agent to YAML mapping

| agent_name       | yaml_file              |
|------------------|------------------------|
| Triage Agent     | triage_config.yaml     |
| Flow Agent       | flow_config.yaml       |
| Interview Agent  | interview_config.yaml  |
| Answer Agent     | answer_config.yaml     |
| Knowledge Agent  | knowledge_config.yaml  |
| Confirmation Agent | confirmation_config.yaml |
| Onboarding Agent | onboarding_config.yaml |
| Escalation Agent | escalation_config.yaml |
| Feedback Agent   | feedback_config.yaml   |
| Usage Agent      | (none)                 |
