# -*- coding: utf-8 -*-
"""
Rate Limiter para AtendentePro.

Fornece controle de taxa de requisições por usuário usando o algoritmo
sliding window com estruturas thread-safe.

Uso típico:

    from atendentepro import RateLimiter, RateLimitExceededError

    limiter = RateLimiter(max_requests=10, window_seconds=60)

    async def handle_message(user_id: str, message: str):
        try:
            limiter.check(user_id)
        except RateLimitExceededError:
            return "Limite de mensagens atingido. Tente novamente em breve."

        result = await Runner.run(network.triage, message)
        return result.final_output
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Dict


class RateLimitExceededError(Exception):
    """
    Levantada quando o usuário excede o limite de requisições configurado.

    Atributos:
        user_id: Identificador do usuário que excedeu o limite.
        max_requests: Limite máximo configurado.
        window_seconds: Janela de tempo em segundos.
        retry_after: Segundos até a próxima requisição ser permitida.
    """

    def __init__(
        self,
        user_id: str,
        max_requests: int,
        window_seconds: int,
        retry_after: float,
    ) -> None:
        self.user_id = user_id
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.retry_after = retry_after
        super().__init__(
            f"Rate limit excedido para usuario '{user_id}': "
            f"{max_requests} requisicoes por {window_seconds}s. "
            f"Tente novamente em {retry_after:.1f}s."
        )


class RateLimiter:
    """
    Sliding window rate limiter por user_id.

    Controla quantas requisições cada usuário pode fazer dentro de uma
    janela de tempo deslizante. Thread-safe e compatível com código assíncrono
    (não bloqueia o event loop — operações são O(1) em tempo de CPU).

    O isolamento é por user_id: o limite de um usuário não afeta outro.

    Args:
        max_requests: Número máximo de requisições permitidas na janela.
        window_seconds: Duração da janela deslizante em segundos.

    Exemplo:
        >>> limiter = RateLimiter(max_requests=5, window_seconds=60)
        >>> limiter.check("user_123")   # OK
        >>> limiter.is_allowed("user_123")  # True até o 5o request
    """

    def __init__(self, max_requests: int, window_seconds: int) -> None:
        if max_requests <= 0:
            raise ValueError("max_requests deve ser positivo")
        if window_seconds <= 0:
            raise ValueError("window_seconds deve ser positivo")

        self._max_requests = max_requests
        self._window_seconds = window_seconds

        # Dicionário de deques: cada deque guarda os timestamps dos requests
        # do usuário dentro da janela atual.
        self._windows: Dict[str, deque] = {}
        # Um lock por usuário, criado sob demanda (protegido pelo lock global).
        self._user_locks: Dict[str, threading.Lock] = {}
        self._global_lock = threading.Lock()

    def _get_user_lock(self, user_id: str) -> threading.Lock:
        """Retorna o lock do usuário, criando-o se necessário (thread-safe)."""
        with self._global_lock:
            if user_id not in self._user_locks:
                self._user_locks[user_id] = threading.Lock()
                self._windows[user_id] = deque()
            return self._user_locks[user_id]

    def _clean_window(self, window: deque, now: float) -> None:
        """Remove timestamps fora da janela deslizante."""
        cutoff = now - self._window_seconds
        while window and window[0] <= cutoff:
            window.popleft()

    def is_allowed(self, user_id: str) -> bool:
        """
        Verifica se o usuário pode fazer mais uma requisição.

        Não registra a requisição — use `check()` para registrar e validar
        ao mesmo tempo.

        Args:
            user_id: Identificador único do usuário.

        Returns:
            True se o usuário ainda tem requisições disponíveis.
        """
        lock = self._get_user_lock(user_id)
        with lock:
            now = time.monotonic()
            window = self._windows[user_id]
            self._clean_window(window, now)
            return len(window) < self._max_requests

    def check(self, user_id: str) -> None:
        """
        Verifica e registra uma requisição do usuário.

        Se o limite foi excedido, levanta RateLimitExceededError.
        Se permitida, registra o timestamp da requisição.

        Args:
            user_id: Identificador único do usuário.

        Raises:
            RateLimitExceededError: Se o limite foi excedido.
        """
        lock = self._get_user_lock(user_id)
        with lock:
            now = time.monotonic()
            window = self._windows[user_id]
            self._clean_window(window, now)

            if len(window) >= self._max_requests:
                # Calcula quanto falta para o request mais antigo expirar
                retry_after = self._window_seconds - (now - window[0])
                raise RateLimitExceededError(
                    user_id=user_id,
                    max_requests=self._max_requests,
                    window_seconds=self._window_seconds,
                    retry_after=max(0.0, retry_after),
                )

            window.append(now)

    def reset(self, user_id: str) -> None:
        """
        Limpa o contador de requisições do usuário.

        Útil para testes ou para resetar manualmente após ação administrativa.

        Args:
            user_id: Identificador único do usuário.
        """
        lock = self._get_user_lock(user_id)
        with lock:
            self._windows[user_id].clear()

    def reset_all(self) -> None:
        """Limpa os contadores de todos os usuários."""
        with self._global_lock:
            for window in self._windows.values():
                window.clear()

    def get_stats(self, user_id: str) -> dict:
        """
        Retorna estatísticas do uso atual do usuário.

        Args:
            user_id: Identificador único do usuário.

        Returns:
            Dicionário com:
                - user_id: str
                - requests_in_window: int — requisições na janela atual
                - max_requests: int — limite configurado
                - window_seconds: int — duração da janela
                - remaining: int — requisições restantes
                - allowed: bool — se próxima requisição seria permitida
        """
        lock = self._get_user_lock(user_id)
        with lock:
            now = time.monotonic()
            window = self._windows[user_id]
            self._clean_window(window, now)
            count = len(window)
            remaining = max(0, self._max_requests - count)
            return {
                "user_id": user_id,
                "requests_in_window": count,
                "max_requests": self._max_requests,
                "window_seconds": self._window_seconds,
                "remaining": remaining,
                "allowed": remaining > 0,
            }
