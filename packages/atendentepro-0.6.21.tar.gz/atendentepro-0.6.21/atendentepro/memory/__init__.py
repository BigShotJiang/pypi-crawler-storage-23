# -*- coding: utf-8 -*-
"""
Optional memory module for AtendentePro (long-context memory with GRKMemory).

Provides run_with_memory to search memories before run, inject context, and save
the turn after. Install with: pip install atendentepro[memory]

Environment: GRKMEMORY_API_KEY, OPENAI_API_KEY (or Azure vars). See GRKMemory README.
"""

from atendentepro.memory.backend import (
    MemoryBackend,
    GRKMemoryBackend,
    create_grk_backend,
)
from atendentepro.memory.config import MemoryConfig
from atendentepro.memory.runner import run_with_memory

__all__ = [
    "MemoryBackend",
    "GRKMemoryBackend",
    "create_grk_backend",
    "MemoryConfig",
    "run_with_memory",
]
