"""func_api — convert Python functions to HTTP APIs with one decorator."""

from func_api.app import FuncAPI

__version__ = "1.0.0"
__all__ = ["FuncAPI", "__version__"]
