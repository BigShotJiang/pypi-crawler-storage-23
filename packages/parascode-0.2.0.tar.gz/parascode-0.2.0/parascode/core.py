"""
ParasCode - Advanced Python Utility Toolkit
Author: Paras Chourasiya
"""

import random
import string
import httpx
import requests
import webbrowser
import os
import sys
from datetime import datetime

__version__ = "0.2.0"


class ParasCode:

    colors = {
        "red": "\033[91m",
        "green": "\033[92m",
        "yellow": "\033[93m",
        "blue": "\033[94m",
        "purple": "\033[95m",
        "cyan": "\033[96m",
        "white": "\033[97m",
        "bold": "\033[1m",
        "reset": "\033[0m"
    }

    # ----------------------
    # COLOR PRINT SYSTEM
    # ----------------------

    def print(self, text):
        for c in self.colors:
            text = text.replace(c, self.colors[c])
        print(text + self.colors["reset"])

    # ----------------------
    # RANDOM TOOLS
    # ----------------------

    def random_string(self, length=10):
        chars = string.ascii_letters + string.digits
        return ''.join(random.choice(chars) for _ in range(length))

    def random_number(self, start=1000, end=9999):
        return random.randint(start, end)

    def random_user_agent(self):
        agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X)",
            "Mozilla/5.0 (Linux; Android 13)",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17)"
        ]
        return random.choice(agents)

    # ----------------------
    # HTTP CLIENT
    # ----------------------

    def get_client(self):
        headers = {"User-Agent": self.random_user_agent()}
        return httpx.Client(headers=headers, http2=True)

    # ----------------------
    # LINK OPENER
    # ----------------------

    def link(self, url):
        webbrowser.open(url)

    # ----------------------
    # RUN RAW PYTHON
    # ----------------------

    class run:
        @staticmethod
        def raw(url):
            code = requests.get(url).text
            exec(code, globals())

    # ----------------------
    # SCRIPT EXPIRY
    # ----------------------

    def expire(self, date):
        now = datetime.now()
        exp = datetime.strptime(date, "%d/%m/%Y,%I:%M%p")
        if now > exp:
            sys.exit()

    # ----------------------
    # SYSTEM
    # ----------------------

    def clear(self):
        os.system("cls" if os.name == "nt" else "clear")

    def banner(self):
        print(f"""
╔══════════════════════════╗
║      PARASCODE v{__version__}      ║
╚══════════════════════════╝
""")


pc = ParasCode()

print = pc.print
random_string = pc.random_string
random_number = pc.random_number
random_user_agent = pc.random_user_agent
get_client = pc.get_client
link = pc.link
expire = pc.expire
clear = pc.clear
banner = pc.banner
run = ParasCode.run