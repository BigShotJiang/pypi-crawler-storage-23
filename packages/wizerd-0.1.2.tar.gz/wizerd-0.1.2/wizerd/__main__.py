"""Main entrypoint for WizERD CLI."""

from wizerd.cli import app

if __name__ == "__main__":
    """Entry point for `python -m wizerd.cli` and editable installs."""
    app()
