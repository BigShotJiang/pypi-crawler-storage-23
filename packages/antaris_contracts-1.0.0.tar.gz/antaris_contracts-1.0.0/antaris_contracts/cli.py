"""
antaris-debug — Debug CLI for the Antaris Analytics Suite.

Commands:
  antaris-debug memory inspect <store_path>
      Show shard count, entry count, index health, last modified.

  antaris-debug memory search <store_path> <query>
      Top 5 search results from the memory store.

  antaris-debug telemetry tail <log_path>
      Last 20 telemetry events, human-readable.

  antaris-debug telemetry summary <log_path>
      Aggregate stats by module/event_type.

  antaris-debug telemetry dashboard <log_path>
      Rich dashboard: module breakdown, latency percentiles, guard ratio.

  antaris-debug pipeline trace <session_id> <log_path>
      Show all events for one session in chronological order.

  antaris-debug schema validate <file.json>
      Validate a JSON file against known antaris-contracts schemas.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional


# ── Helpers ──────────────────────────────────────────────────────────────────

def _fmt_ts(ts: str) -> str:
    """Format an ISO timestamp for display, or return as-is on failure."""
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        return ts or "(none)"


def _load_json(path: str) -> Any:
    """Load a JSON file, raise SystemExit with message on failure."""
    if not os.path.exists(path):
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(1)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON in {path}: {e}", file=sys.stderr)
        sys.exit(1)


def _load_jsonl(path: str) -> List[Dict[str, Any]]:
    """Load a JSONL file; skip invalid lines with a warning."""
    if not os.path.exists(path):
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(1)
    events = []
    with open(path, "r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                print(f"WARNING: Skipping invalid JSONL line {lineno}", file=sys.stderr)
    return events


def _find_json_files(directory: str, pattern: str) -> List[str]:
    """Find JSON files in a directory matching a name pattern substring."""
    results = []
    try:
        for fname in sorted(os.listdir(directory)):
            if fname.endswith(".json") and pattern in fname:
                results.append(os.path.join(directory, fname))
    except OSError:
        pass
    return results


# ── memory inspect ───────────────────────────────────────────────────────────

def cmd_memory_inspect(store_path: str) -> None:
    """
    Inspect a memory store directory.

    Expected layout (antaris-memory):
        <store_path>/
            memory_index.json
            shards/
                shard_YYYY-MM_<category>.json
    """
    if not os.path.isdir(store_path):
        print(f"ERROR: Not a directory: {store_path}", file=sys.stderr)
        sys.exit(1)

    print(f"\n{'='*60}")
    print(f"  Memory Store: {store_path}")
    print(f"{'='*60}")

    # ── Index health ────────────────────────────────────────────────
    index_path = os.path.join(store_path, "memory_index.json")
    index_ok = os.path.exists(index_path)
    print(f"\n  Index file:   {'PRESENT' if index_ok else 'MISSING (will rebuild on load)'}")

    total_entries = 0
    index_last_modified = "(unknown)"
    if index_ok:
        try:
            idx = _load_json(index_path)
            total_entries = idx.get("total_entries", 0)
            index_last_modified = _fmt_ts(idx.get("last_modified", ""))
            index_schema = idx.get("schema_version", "(none)")
            shard_manifest = idx.get("shard_manifest", {})
            tag_count = len(idx.get("tag_index", {}))
            print(f"  Index entries:{total_entries:>8,}")
            print(f"  Index shards: {len(shard_manifest):>8,}")
            print(f"  Tag index:    {tag_count:>8,} tags")
            print(f"  Schema ver:   {index_schema}")
            print(f"  Last modified:{index_last_modified:>26}")
        except SystemExit:
            print("  Index file:   CORRUPT (cannot parse)")

    # ── Shard scan ──────────────────────────────────────────────────
    shards_dir = os.path.join(store_path, "shards")
    shard_files = []
    if os.path.isdir(shards_dir):
        shard_files = [
            f for f in sorted(os.listdir(shards_dir)) if f.endswith(".json")
        ]

    print(f"\n  Shards on disk: {len(shard_files)}")

    actual_entry_count = 0
    last_shard_modified = ""
    for fname in shard_files:
        spath = os.path.join(shards_dir, fname)
        try:
            shard = _load_json(spath)
            entries = shard.get("entries", [])
            declared = shard.get("entry_count", -1)
            actual = len(entries)
            actual_entry_count += actual
            lm = shard.get("last_modified", "")
            if lm > last_shard_modified:
                last_shard_modified = lm

            health = "OK"
            if declared != -1 and declared != actual:
                health = f"PARTIAL WRITE (declared={declared}, actual={actual})"
            print(f"    {fname:<40} {actual:>5} entries  [{health}]")
        except SystemExit:
            print(f"    {fname:<40} CORRUPT")

    print(f"\n  Total entries (actual scan): {actual_entry_count:,}")
    if last_shard_modified:
        print(f"  Last shard modified: {_fmt_ts(last_shard_modified)}")

    if index_ok and total_entries != actual_entry_count:
        print(f"\n  WARNING: Index declares {total_entries:,} entries "
              f"but shards contain {actual_entry_count:,}. "
              f"Run consolidation to rebuild index.")
    else:
        print(f"\n  Index health: OK")

    print(f"{'='*60}\n")


# ── memory search ─────────────────────────────────────────────────────────────

def cmd_memory_search(store_path: str, query: str) -> None:
    """
    Search a memory store using simple keyword matching (no deps).
    Returns top 5 results by importance × keyword hit count.
    """
    if not os.path.isdir(store_path):
        print(f"ERROR: Not a directory: {store_path}", file=sys.stderr)
        sys.exit(1)

    query_terms = query.lower().split()
    if not query_terms:
        print("ERROR: Empty query.", file=sys.stderr)
        sys.exit(1)

    shards_dir = os.path.join(store_path, "shards")
    if not os.path.isdir(shards_dir):
        print(f"ERROR: No shards/ directory found in {store_path}", file=sys.stderr)
        sys.exit(1)

    results = []
    for fname in os.listdir(shards_dir):
        if not fname.endswith(".json"):
            continue
        spath = os.path.join(shards_dir, fname)
        try:
            shard = _load_json(spath)
        except SystemExit:
            continue
        for entry in shard.get("entries", []):
            content = entry.get("content", "").lower()
            hits = sum(1 for t in query_terms if t in content)
            if hits > 0:
                score = hits * entry.get("importance", 1.0) * entry.get("confidence", 1.0)
                results.append((score, hits, entry))

    results.sort(key=lambda x: x[0], reverse=True)
    top = results[:5]

    print(f"\n  Memory search: '{query}'")
    print(f"  Store: {store_path}")
    print(f"  Found {len(results)} matching entries — showing top {len(top)}\n")

    if not top:
        print("  No results.\n")
        return

    for rank, (score, hits, entry) in enumerate(top, 1):
        content = entry.get("content", "")
        short = content[:120].replace("\n", " ")
        if len(content) > 120:
            short += "..."
        print(f"  [{rank}] score={score:.3f}  hits={hits}")
        print(f"      {short}")
        print(f"      source={entry.get('source','?')}  "
              f"type={entry.get('memory_type','episodic')}  "
              f"importance={entry.get('importance', 1.0):.2f}  "
              f"confidence={entry.get('confidence', 1.0):.2f}")
        print()


# ── telemetry tail ────────────────────────────────────────────────────────────

def cmd_telemetry_tail(log_path: str, count: int = 20) -> None:
    """Display the last N telemetry events from a JSONL log."""
    events = _load_jsonl(log_path)
    tail = events[-count:]

    print(f"\n  Telemetry tail: {log_path}")
    print(f"  Total events: {len(events)}  —  showing last {len(tail)}\n")

    if not tail:
        print("  No events in log.\n")
        return

    for ev in tail:
        ts = _fmt_ts(ev.get("timestamp", ""))
        module = ev.get("module", "?")
        event_type = ev.get("event_type", "?")
        confidence = ev.get("confidence")
        conf_str = f"  conf={confidence:.3f}" if confidence is not None else ""
        basis = ev.get("basis", "")
        basis_str = f"  basis={basis}" if basis else ""
        session = ev.get("session_id", "")
        session_str = f"  session={session[:8]}..." if session else ""

        evidence = ev.get("evidence", [])
        evidence_str = ""
        if evidence:
            evidence_str = f"\n      evidence: {evidence[:3]}"

        perf = ev.get("performance") or {}
        perf_parts = []
        if perf.get("latency_ms") is not None:
            perf_parts.append(f"lat={perf['latency_ms']:.1f}ms")
        if perf.get("cost_usd") is not None:
            perf_parts.append(f"cost=${perf['cost_usd']:.6f}")
        perf_str = f"\n      perf: {', '.join(perf_parts)}" if perf_parts else ""

        print(f"  {ts}  [{module:>8}] {event_type}"
              f"{conf_str}{basis_str}{session_str}{evidence_str}{perf_str}")

    print()


# ── telemetry summary ─────────────────────────────────────────────────────────

def cmd_telemetry_summary(log_path: str) -> None:
    """Aggregate telemetry stats by module and event_type."""
    events = _load_jsonl(log_path)

    if not events:
        print(f"\n  No events in {log_path}\n")
        return

    from collections import defaultdict

    by_module: Dict[str, int] = defaultdict(int)
    by_event_type: Dict[str, int] = defaultdict(int)
    by_module_event: Dict[str, int] = defaultdict(int)
    confidence_sum: Dict[str, float] = defaultdict(float)
    confidence_cnt: Dict[str, int] = defaultdict(int)
    total_latency = 0.0
    latency_count = 0
    total_cost = 0.0
    first_ts = ""
    last_ts = ""

    for ev in events:
        module = ev.get("module", "unknown")
        event_type = ev.get("event_type", "unknown")
        key = f"{module}/{event_type}"
        by_module[module] += 1
        by_event_type[event_type] += 1
        by_module_event[key] += 1

        conf = ev.get("confidence")
        if conf is not None:
            confidence_sum[module] += conf
            confidence_cnt[module] += 1

        perf = ev.get("performance") or {}
        if perf.get("latency_ms") is not None:
            total_latency += perf["latency_ms"]
            latency_count += 1
        if perf.get("cost_usd") is not None:
            total_cost += perf["cost_usd"]

        ts = ev.get("timestamp", "")
        if ts:
            if not first_ts or ts < first_ts:
                first_ts = ts
            if not last_ts or ts > last_ts:
                last_ts = ts

    print(f"\n{'='*60}")
    print(f"  Telemetry Summary: {log_path}")
    print(f"{'='*60}")
    print(f"\n  Total events: {len(events):,}")
    if first_ts:
        print(f"  Time range:   {_fmt_ts(first_ts)}  →  {_fmt_ts(last_ts)}")
    if latency_count:
        print(f"  Avg latency:  {total_latency / latency_count:.1f} ms")
    if total_cost:
        print(f"  Total cost:   ${total_cost:.6f}")

    print(f"\n  By module:")
    for module, count in sorted(by_module.items(), key=lambda x: -x[1]):
        avg_conf = ""
        if confidence_cnt.get(module):
            avg = confidence_sum[module] / confidence_cnt[module]
            avg_conf = f"  avg_conf={avg:.3f}"
        print(f"    {module:<20} {count:>6,} events{avg_conf}")

    print(f"\n  By event type (top 10):")
    for etype, count in sorted(by_event_type.items(), key=lambda x: -x[1])[:10]:
        print(f"    {etype:<35} {count:>6,}")

    print(f"\n  By module/event (top 15):")
    for key, count in sorted(by_module_event.items(), key=lambda x: -x[1])[:15]:
        print(f"    {key:<45} {count:>6,}")

    print(f"{'='*60}\n")


# ── telemetry dashboard ───────────────────────────────────────────────────────

def cmd_telemetry_dashboard(log_path: str) -> None:
    """Rich text telemetry dashboard: module breakdown, latency percentiles, guard ratio."""
    events = _load_jsonl(log_path)

    if not events:
        print(f"\n  No events in {log_path}\n")
        return

    from collections import defaultdict

    # ── Aggregate ─────────────────────────────────────────────────────────
    by_module: Dict[str, int] = defaultdict(int)
    by_event_type: Dict[str, int] = defaultdict(int)
    latencies_by_module: Dict[str, list] = defaultdict(list)
    all_latencies: list = []
    guard_allow = 0
    guard_deny = 0
    total_cost = 0.0
    first_ts = ""
    last_ts = ""

    for ev in events:
        module = ev.get("module", "unknown")
        event_type = ev.get("event_type", "unknown")
        by_module[module] += 1
        by_event_type[event_type] += 1

        perf = ev.get("performance") or {}
        lat = perf.get("latency_ms")
        if lat is not None:
            latencies_by_module[module].append(lat)
            all_latencies.append(lat)
        cost = perf.get("cost_usd")
        if cost is not None:
            total_cost += cost

        # Guard stats
        if event_type in ("guard.allow", "guard.scan"):
            if ev.get("payload", {}).get("allowed", True):
                guard_allow += 1
            else:
                guard_deny += 1
        elif event_type == "guard.deny":
            guard_deny += 1

        ts = ev.get("timestamp", "")
        if ts:
            if not first_ts or ts < first_ts:
                first_ts = ts
            if ts > last_ts:
                last_ts = ts

    # ── Percentile helper ────────────────────────────────────────────────
    def _pct(data: list, p: float) -> float:
        if not data:
            return 0.0
        s = sorted(data)
        k = (len(s) - 1) * p / 100.0
        lo, hi = int(k), min(int(k) + 1, len(s) - 1)
        return s[lo] + (s[hi] - s[lo]) * (k - lo)

    sep = "=" * 64

    print(f"\n{sep}")
    print(f"  TELEMETRY DASHBOARD: {log_path}")
    print(sep)
    print(f"  Total events: {len(events):,}")
    if first_ts:
        print(f"  Time range:   {_fmt_ts(first_ts)}  →  {_fmt_ts(last_ts)}")
    if total_cost:
        print(f"  Total cost:   ${total_cost:.6f}")

    # ── Module breakdown ──────────────────────────────────────────────────
    print(f"\n  {'Module':<20} {'Events':>8}  {'Avg lat (ms)':>14}  {'p50':>8}  {'p95':>8}  {'p99':>8}")
    print(f"  {'-'*20} {'-'*8}  {'-'*14}  {'-'*8}  {'-'*8}  {'-'*8}")
    for module, count in sorted(by_module.items(), key=lambda x: -x[1]):
        lats = latencies_by_module.get(module, [])
        avg_s = f"{sum(lats)/len(lats):.1f}" if lats else "-"
        p50_s = f"{_pct(lats, 50):.1f}" if len(lats) >= 3 else "-"
        p95_s = f"{_pct(lats, 95):.1f}" if len(lats) >= 3 else "-"
        p99_s = f"{_pct(lats, 99):.1f}" if len(lats) >= 3 else "-"
        print(f"  {module:<20} {count:>8,}  {avg_s:>14}  {p50_s:>8}  {p95_s:>8}  {p99_s:>8}")

    # ── Overall latency percentiles ───────────────────────────────────────
    if all_latencies:
        print(f"\n  Overall latency percentiles (across all modules):")
        print(f"    p50: {_pct(all_latencies, 50):.1f} ms   "
              f"p95: {_pct(all_latencies, 95):.1f} ms   "
              f"p99: {_pct(all_latencies, 99):.1f} ms")

    # ── Top event types ───────────────────────────────────────────────────
    print(f"\n  Top event types:")
    for etype, count in sorted(by_event_type.items(), key=lambda x: -x[1])[:10]:
        bar = "#" * min(count, 30)
        print(f"    {etype:<38} {count:>6,}  {bar}")

    # ── Guard allow/deny ratio ────────────────────────────────────────────
    total_guard = guard_allow + guard_deny
    if total_guard > 0:
        allow_pct = guard_allow / total_guard * 100
        deny_pct = guard_deny / total_guard * 100
        allow_bar = "#" * int(allow_pct / 5)
        deny_bar = "!" * int(deny_pct / 5)
        print(f"\n  Guard allow/deny ratio  ({total_guard} total scans):")
        print(f"    Allow {guard_allow:>6,}  ({allow_pct:5.1f}%)  {allow_bar}")
        print(f"    Deny  {guard_deny:>6,}  ({deny_pct:5.1f}%)  {deny_bar}")
    else:
        print(f"\n  Guard: no guard events found")

    print(f"{sep}\n")


# ── pipeline trace ────────────────────────────────────────────────────────────

def cmd_pipeline_trace(session_id: str, log_path: str) -> None:
    """Show all events for one session in chronological order."""
    events = _load_jsonl(log_path)

    matching = [ev for ev in events if ev.get("session_id", "") == session_id]

    print(f"\n  Pipeline trace: session_id={session_id!r}")
    print(f"  Source: {log_path}")
    print(f"  Found {len(matching)} events out of {len(events)} total\n")

    if not matching:
        print(f"  No events found for session {session_id!r}\n")
        return

    # Sort chronologically
    matching.sort(key=lambda ev: ev.get("timestamp", ""))

    for i, ev in enumerate(matching, 1):
        ts = _fmt_ts(ev.get("timestamp", ""))
        module = ev.get("module", "?")
        event_type = ev.get("event_type", "?")
        event_id = ev.get("event_id", "")[:12]

        perf = ev.get("performance") or {}
        perf_parts = []
        if perf.get("latency_ms") is not None:
            perf_parts.append(f"lat={perf['latency_ms']:.1f}ms")
        if perf.get("cost_usd") is not None:
            perf_parts.append(f"cost=${perf['cost_usd']:.6f}")
        perf_str = f"  [{', '.join(perf_parts)}]" if perf_parts else ""

        payload = ev.get("payload", {})
        payload_keys = list(payload.keys())[:3]
        payload_str = ""
        if payload_keys:
            kv_parts = []
            for k in payload_keys:
                v = payload[k]
                if isinstance(v, (str, int, float, bool)):
                    kv_parts.append(f"{k}={v!r}")
                else:
                    kv_parts.append(f"{k}=[...]")
            payload_str = f"  {{{', '.join(kv_parts)}}}"

        print(f"  [{i:>3}] {ts}  [{module:>8}] {event_type:<35}{perf_str}{payload_str}")
        if event_id:
            print(f"        event_id={event_id}...")

    print()


# ── schema validate ───────────────────────────────────────────────────────────

# Known schema types and their required top-level fields
_SCHEMA_SIGNATURES: Dict[str, List[str]] = {
    "MemoryEntry":           ["content", "schema_version"],
    "MemoryShard":           ["shard_id", "entries", "schema_version"],
    "MemoryIndex":           ["total_entries", "shard_manifest", "schema_version"],
    "RouterState":           ["session_id", "total_requests", "schema_version"],
    "RouteDecision":         ["model", "tier", "confidence", "schema_version"],
    "ClassificationResult":  ["tier", "confidence", "reasoning", "schema_version"],
    "GuardDecision":         ["threat_level", "is_safe", "schema_version"],
    "GuardPolicy":           ["policy_id", "rules", "schema_version"],
    "ContextPacket":         ["task", "sections", "total_budget", "schema_version"],
    "ContextSection":        ["name", "budget", "items", "schema_version"],
    "TelemetryEvent":        ["event_id", "timestamp", "module", "event_type", "schema_version"],
    "AuditRecord":           ["audit_id", "timestamp", "action", "schema_version"],
}

_CURRENT_SCHEMA_VERSION = "2.2.0"


def cmd_schema_validate(file_path: str) -> None:
    """Validate a JSON file against known antaris-contracts schemas."""
    data = _load_json(file_path)

    print(f"\n  Schema validation: {file_path}")
    print()

    objects = data if isinstance(data, list) else [data]
    errors = 0
    warnings = 0

    for i, obj in enumerate(objects):
        label = f"[{i}]" if isinstance(data, list) else "(root)"
        if not isinstance(obj, dict):
            print(f"  {label} SKIP — not a JSON object (type={type(obj).__name__})")
            continue

        sv = obj.get("schema_version", "(missing)")
        if sv == "(missing)":
            print(f"  {label} WARNING: no schema_version field")
            warnings += 1
        elif sv != _CURRENT_SCHEMA_VERSION:
            print(f"  {label} WARNING: schema_version={sv!r} "
                  f"(current is {_CURRENT_SCHEMA_VERSION!r})")
            warnings += 1

        # Detect schema type and validate required fields
        matched = []
        for schema_name, required_fields in _SCHEMA_SIGNATURES.items():
            if all(k in obj for k in required_fields):
                matched.append(schema_name)

        if not matched:
            print(f"  {label} UNKNOWN schema — does not match any known contract")
            warnings += 1
            continue

        # Pick most specific match (most required fields)
        best = max(matched, key=lambda s: len(_SCHEMA_SIGNATURES[s]))
        required = _SCHEMA_SIGNATURES[best]
        missing = [k for k in required if k not in obj]

        if missing:
            print(f"  {label} ERROR [{best}]: missing required fields: {missing}")
            errors += 1
        else:
            extra_fields = set(obj.keys()) - set(required)
            print(f"  {label} OK [{best}]  schema_version={sv}  "
                  f"extra_fields={len(extra_fields)}")

    print()
    print(f"  Result: {len(objects)} object(s)  {errors} error(s)  {warnings} warning(s)")
    if errors:
        print(f"  VALIDATION FAILED")
        sys.exit(2)
    else:
        print(f"  VALIDATION PASSED")
    print()


# ── CLI entry point ───────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="antaris-debug",
        description="Antaris Analytics Suite — debug and inspection CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  antaris-debug memory inspect ./workspace
  antaris-debug memory search ./workspace "recent mistakes"
  antaris-debug telemetry tail ./telemetry.jsonl
  antaris-debug telemetry summary ./telemetry.jsonl
  antaris-debug telemetry dashboard ./telemetry.jsonl
  antaris-debug pipeline trace session_abc123 ./telemetry.jsonl
  antaris-debug schema validate ./data.json
""",
    )

    sub = parser.add_subparsers(dest="group", metavar="GROUP")
    sub.required = True

    # ── memory ──
    mem = sub.add_parser("memory", help="Inspect and search memory stores")
    mem_sub = mem.add_subparsers(dest="command", metavar="COMMAND")
    mem_sub.required = True

    inspect_p = mem_sub.add_parser("inspect", help="Show store health and stats")
    inspect_p.add_argument("store_path", help="Path to memory store directory")

    search_p = mem_sub.add_parser("search", help="Search entries with a query")
    search_p.add_argument("store_path", help="Path to memory store directory")
    search_p.add_argument("query", help="Search query string")

    # ── telemetry ──
    tel = sub.add_parser("telemetry", help="Inspect telemetry JSONL logs")
    tel_sub = tel.add_subparsers(dest="command", metavar="COMMAND")
    tel_sub.required = True

    tail_p = tel_sub.add_parser("tail", help="Show last N events")
    tail_p.add_argument("log_path", help="Path to .jsonl telemetry log")
    tail_p.add_argument("-n", "--count", type=int, default=20,
                        help="Number of events to show (default: 20)")

    summary_p = tel_sub.add_parser("summary", help="Aggregate stats by module/event_type")
    summary_p.add_argument("log_path", help="Path to .jsonl telemetry log")

    dashboard_p = tel_sub.add_parser("dashboard", help="Rich dashboard with latency percentiles and guard ratio")
    dashboard_p.add_argument("log_path", help="Path to .jsonl telemetry log")

    # ── pipeline ──
    pip = sub.add_parser("pipeline", help="Pipeline analysis commands")
    pip_sub = pip.add_subparsers(dest="command", metavar="COMMAND")
    pip_sub.required = True

    trace_p = pip_sub.add_parser("trace", help="Show all events for one session")
    trace_p.add_argument("session_id", help="Session ID to trace")
    trace_p.add_argument("log_path", help="Path to .jsonl telemetry log")

    # ── schema ──
    schema = sub.add_parser("schema", help="Validate JSON files against contracts")
    schema_sub = schema.add_subparsers(dest="command", metavar="COMMAND")
    schema_sub.required = True

    validate_p = schema_sub.add_parser("validate", help="Validate a JSON file")
    validate_p.add_argument("file_path", help="Path to JSON file to validate")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.group == "memory":
        if args.command == "inspect":
            cmd_memory_inspect(args.store_path)
        elif args.command == "search":
            cmd_memory_search(args.store_path, args.query)

    elif args.group == "telemetry":
        if args.command == "tail":
            cmd_telemetry_tail(args.log_path, count=args.count)
        elif args.command == "summary":
            cmd_telemetry_summary(args.log_path)
        elif args.command == "dashboard":
            cmd_telemetry_dashboard(args.log_path)

    elif args.group == "pipeline":
        if args.command == "trace":
            cmd_pipeline_trace(args.session_id, args.log_path)

    elif args.group == "schema":
        if args.command == "validate":
            cmd_schema_validate(args.file_path)


if __name__ == "__main__":
    main()
