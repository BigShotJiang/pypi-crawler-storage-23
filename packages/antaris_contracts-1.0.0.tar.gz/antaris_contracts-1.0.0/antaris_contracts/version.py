"""Schema version for antaris-contracts."""

SCHEMA_VERSION = "2.2.0"
