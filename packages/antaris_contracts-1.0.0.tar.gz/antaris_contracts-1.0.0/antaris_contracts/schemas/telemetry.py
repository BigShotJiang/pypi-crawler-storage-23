"""
Telemetry event contracts — the shared event schema across all antaris packages.

This is the canonical format for Sprint 2.x cross-package telemetry.

Failure behavior:
- TelemetryEvent: if a sink (file, callback) raises during emit, the error is
  caught and a WARNING is written to stderr; the pipeline is NOT interrupted.
- PerformanceMetrics: all fields are Optional; partial metrics are valid.
- The JSONL log is append-only; partial line writes (process kill mid-write)
  produce an invalid JSON line that is skipped on read, not a corrupt file.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "2.2.0"

# Canonical module names
MODULE_MEMORY = "memory"
MODULE_ROUTER = "router"
MODULE_GUARD = "guard"
MODULE_CONTEXT = "context"
MODULE_PIPELINE = "pipeline"

# Canonical confidence basis values
BASIS_CLASSIFIER = "classifier"
BASIS_QUALITY_TRACKER = "quality_tracker"
BASIS_GUARD = "guard"
BASIS_CONTEXT_BUDGET = "context_budget"
BASIS_KEYWORD = "keyword"
BASIS_COMPOSITE = "composite"
BASIS_RULE = "rule"
BASIS_FALLBACK = "fallback"


@dataclass
class PerformanceMetrics:
    """
    Performance data attached to a telemetry event.

    All fields are optional — partial metrics are valid and expected.
    A missing field means it was not measured, not that it was zero.
    """
    latency_ms: Optional[float] = None
    tokens_processed: Optional[int] = None
    cost_usd: Optional[float] = None
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None
    throughput_ops_sec: Optional[float] = None
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PerformanceMetrics":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


@dataclass
class TelemetryEvent:
    """
    A single structured event emitted by any antaris module.

    All packages emit this exact structure, enabling unified log analysis.

    Fields:
        timestamp: ISO-8601 UTC string.
        module: one of MODULE_* constants above.
        event_type: module-specific string (e.g. "guard_decision", "route_selected").
        confidence: 0.0–1.0 normalized score. Meaning is module-specific but
                    scale is always 0=low confidence, 1=high confidence.
        basis: what mechanism produced the confidence score (BASIS_* constants).
        evidence: list of signal strings that informed the decision.
        payload: module-specific structured data.
        performance: optional latency/cost metrics.
        correlations: event_ids of related events (e.g. guard event caused by pipeline event).
        triggers: event_ids that this event caused.

    Failure semantics:
    - Sink failures are non-fatal; telemetry is best-effort.
    - Missing optional fields default to None / empty list — never raise on read.
    - Unknown payload keys are preserved as-is (forward compatibility).
    """
    event_id: str = ""
    timestamp: str = ""
    session_id: str = ""
    module: str = ""
    event_type: str = ""
    confidence: Optional[float] = None
    basis: Optional[str] = None
    evidence: List[str] = field(default_factory=list)
    payload: Dict[str, Any] = field(default_factory=dict)
    performance: Optional[PerformanceMetrics] = None
    correlations: List[str] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)
    user_id: Optional[str] = None
    conversation_id: Optional[str] = None
    agent_id: Optional[str] = None
    trace_id: Optional[str] = None
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TelemetryEvent":
        perf_data = data.pop("performance", None)
        performance = PerformanceMetrics.from_dict(perf_data) if perf_data else None
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(performance=performance, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "TelemetryEvent":
        return cls.from_dict(json.loads(s))

    def to_jsonl_line(self) -> str:
        """Single-line JSONL format for log appending."""
        return self.to_json() + "\n"
