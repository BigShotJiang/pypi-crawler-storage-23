"""
Memory state contracts for antaris-memory.

Failure behavior:
- MemoryEntry: immutable once created; if deserialization fails, the entry is
  skipped and logged — never silently mutated.
- MemoryShard: partial writes are detected via the `entry_count` field;
  a mismatch triggers shard repair on next load.
- MemoryIndex: rebuilt from shards on corruption; the index is a cache, not
  a source of truth — loss is non-fatal.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "2.2.0"


@dataclass
class MemoryEntry:
    """
    A single remembered unit.

    Failure semantics:
    - If `content` is empty the entry must be rejected at ingest time.
    - If `hash` is missing it is recomputed from (source, line, content[:100]).
    - On corruption: skip and log; never raise in hot paths.
    """
    content: str
    source: str = "inline"
    line: int = 0
    category: str = "general"
    created: str = ""
    last_accessed: str = ""
    access_count: int = 0
    importance: float = 1.0
    confidence: float = 1.0
    sentiment: Dict[str, float] = field(default_factory=dict)
    tags: List[str] = field(default_factory=list)
    related: List[str] = field(default_factory=list)
    hash: str = ""
    memory_type: str = "episodic"
    type_metadata: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryEntry":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "MemoryEntry":
        return cls.from_dict(json.loads(s))


@dataclass
class SearchResult:
    """
    A scored retrieval result returned by memory search.

    Failure semantics:
    - If BM25 scoring fails for an entry, that entry is excluded from results.
    - Score normalization errors produce score=0.0 rather than raising.
    """
    entry: MemoryEntry
    score: float = 0.0
    relevance: float = 0.0
    matched_terms: List[str] = field(default_factory=list)
    explanation: str = ""
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SearchResult":
        entry_data = data.pop("entry", {})
        entry = MemoryEntry.from_dict(entry_data)
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(entry=entry, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


@dataclass
class MemoryShard:
    """
    A on-disk shard file containing a list of MemoryEntry objects.

    Shard path convention: shards/shard_YYYY-MM_<category>.json

    Failure semantics:
    - `entry_count` is written last; a count mismatch indicates a partial write.
    - On partial write: discard incomplete shard, reload from WAL if available.
    - On missing shard file: treat as empty; do not raise.
    - File lock must be held during write; reads are lock-free (MVCC-style).
    """
    shard_id: str = ""
    category: str = "general"
    period: str = ""
    entries: List[MemoryEntry] = field(default_factory=list)
    entry_count: int = 0
    created: str = ""
    last_modified: str = ""
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryShard":
        entries_raw = data.pop("entries", [])
        entries = [MemoryEntry.from_dict(e) for e in entries_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(entries=entries, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "MemoryShard":
        return cls.from_dict(json.loads(s))


@dataclass
class MemoryIndex:
    """
    The in-memory and on-disk index over all shards.

    Failure semantics:
    - The index is a derived cache; it can always be rebuilt from shards.
    - On corruption: delete index files, trigger rebuild on next load.
    - On stale index (shard newer than index): rebuild affected partitions.
    - Index write is atomic via temp-file + rename pattern.
    """
    total_entries: int = 0
    shard_count: int = 0
    categories: List[str] = field(default_factory=list)
    last_consolidated: str = ""
    last_modified: str = ""
    shard_manifest: Dict[str, str] = field(default_factory=dict)
    tag_index: Dict[str, List[str]] = field(default_factory=dict)
    search_index: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MemoryIndex":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "MemoryIndex":
        return cls.from_dict(json.loads(s))
