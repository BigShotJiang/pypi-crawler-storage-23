"""
Модуль для управления WebSocket соединениями с Bybit API v5.

Этот модуль предоставляет класс WebSocketManager для управления WebSocket соединениями
с API Bybit, включая автоматическую аутентификацию, обработку сообщений,
переподключение при разрыве соединения и управление событиями.
"""

import ast
import json
import threading
import time
import websocket

from bybit_api_ancous.bybit import Bybit
from bybit_api_ancous.encryption import HMACSHA256


class WebSocketManager(Bybit):
    """
    Класс для управления WebSocket соединениями с Bybit API v5.

    Предоставляет базовую функциональность для:
    - Установки и управления WebSocket соединениями
    - Автоматической аутентификации для приватных каналов
    - Обработки входящих сообщений и маршрутизации к callback функциям
    - Автоматического переподключения при разрыве соединения
    - Управления событиями соединения (открытие, закрытие, ошибки)

    Note:
    Атрибуты callback и name должны быть определены в дочерних классах.

    Arguments:
    api_key (str | None): API ключ для аутентификации
    secret_key (str | None): Секретный ключ для аутентификации
    """

    def __init__(self, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация менеджера WebSocket соединений.

        Parameters:
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации
        """
        super().__init__(api_key, secret_key)
        self.ws = None
        self.msg_auth = None
        self.open_event = threading.Event()
        self.auth_event = threading.Event()
        self.stop_event = threading.Event()

    def on_message(self, ws: websocket.WebSocketApp, message: str) -> None:
        """
        Обработчик входящих сообщений от WebSocket сервера.

        Обрабатывает различные типы сообщений:
        - Сообщения аутентификации (op: "auth")
        - Сообщения с топиками (topic в сообщении)
        - Сообщения с заголовками (header в сообщении)
        - Операционные сообщения (op в сообщении)
        - Системные сообщения (system.status)

        Parameters:
        ws (websocket.WebSocketApp): Объект WebSocket соединения
        message (str): JSON строка с сообщением от сервера
        """
        _ = ws
        message = json.loads(message)

        if message.get("op") == "auth":
            self.msg_auth = message
            if message.get("success", True) is False or message.get("retCode", 0) != 0:
                self.stop_event.set()
                print("Аутентификация провалилась. Закрываем соединение и останавливаем переподключения.")
                self.ws.close()
            else:
                self.auth_event.set()
                print("Аутентификация прошла успешно.")

        if self.callback:
            if "topic" in message:
                self.callback[message["topic"]](message)
            elif "header" in message:
                if self.msg_auth:
                    self.callback["trade"](self.msg_auth)
                    self.msg_auth = False
                self.callback["trade"](message)
            elif "op" in message:
                for i in ast.literal_eval(message["req_id"]):
                    if self.msg_auth:
                        self.callback[i](self.msg_auth)
                        self.msg_auth = False
                    self.callback[i](message)
            elif message["data"]["successTopics"] == ["system.status"]:
                self.callback["system.status"](message)
        else:
            print(message)

    def on_error(self, ws: websocket.WebSocketApp, error: Exception | str) -> None:
        """
        Обработчик ошибок WebSocket соединения.

        Устанавливает стоп-событие для прекращения переподключений
        при возникновении ошибки.

        Parameters:
        ws (websocket.WebSocketApp): Объект WebSocket соединения
        error (Exception | str): Ошибка, возникшая в соединении
        """
        _ = ws
        self.stop_event.set()
        print(f"Ошибка: {error}")

    def on_close(self, ws: websocket.WebSocketApp, close_status_code: int, close_msg: str | None) -> None:
        """
        Обработчик закрытия WebSocket соединения.

        Устанавливает стоп-событие для прекращения переподключений
        при закрытии соединения.

        Parameters:
        ws (websocket.WebSocketApp): Объект WebSocket соединения
        close_status_code (int): Код статуса закрытия соединения
        close_msg (str | None): Сообщение о закрытии соединения
        """
        _ = ws
        self.stop_event.set()
        print(f"Соединение закрыто: {close_status_code} {close_msg}")

    def on_open(self, ws: websocket.WebSocketApp) -> None:
        """
        Обработчик открытия WebSocket соединения.

        Устанавливает событие открытия соединения и отправляет запрос
        аутентификации для приватных каналов (WsPrivate, WsTrade).

        Parameters:
        ws (websocket.WebSocketApp): Объект WebSocket соединения
        """
        _ = ws
        self.open_event.set()
        print("Соединение открыто")

        if self.name in ("WsPrivate", "WsTrade"):
            time_stamp = int((time.time() + 1) * 1000)
            signature = HMACSHA256().compute_hex_by_ws(self.secret_key, time_stamp)

            auth_request = {"op": "auth", "args": [self.api_key, time_stamp, signature]}
            ws.send(json.dumps(auth_request))

            print("Запрос аутентификации отправлен")

    def run_websocket(self, url: str) -> None:
        """
        Запуск WebSocket соединения с автоматическим переподключением.

        Создает WebSocket соединение и запускает его в бесконечном цикле.
        При разрыве соединения автоматически пытается переподключиться,
        если не установлено стоп-событие.

        Parameters:
        url (str): URL WebSocket сервера для подключения
        """
        while True:
            self.ws = websocket.WebSocketApp(url)
            self.ws.on_message = self.on_message
            self.ws.on_error = self.on_error
            self.ws.on_close = self.on_close
            self.ws.on_open = self.on_open

            self.ws.run_forever(ping_interval=20, ping_timeout=5)

            if self.stop_event.is_set():
                print("Остановка переподключений по стоп-событию.")
                break

            print("Соединение потеряно. Попытка переподключения...")
            time.sleep(5)
