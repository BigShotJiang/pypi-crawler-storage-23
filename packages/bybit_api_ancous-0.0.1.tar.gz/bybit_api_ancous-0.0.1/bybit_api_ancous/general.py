"""
Модуль для работы с общими функциями через Bybit API v5.

Этот модуль предоставляет класс General для получения общей информации о системе,
включая статус системы и объявления.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class General:
    """
    Класс для работы с общими функциями Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для:
    - Получения статуса системы
    - Получения объявлений и новостей
    """

    def get_general_system_status(self) -> dict[str, Any]:
        """
        Получение статуса системы Bybit.

        Return:
        dict[str, Any]: Ответ API со статусом системы
        """
        end_point = "/v5/system/status"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request)

    def get_general_announcement_index(
        self,
        locale: str,
        page: int = 1,
        limit: int = 20,
        type_args: str | None = None,
        tag: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение объявлений и новостей.

        Parameters:
        locale (str): Локаль для языка объявлений
        page (int): Номер страницы
        limit (int): Количество записей на странице
        type_args (str | None): Тип объявлений для фильтрации
        tag (str | None): Тег для фильтрации объявлений

        Return:
        dict[str, Any]: Ответ API с объявлениями и новостями
        """
        end_point = "/v5/announcements/index"
        complete_request = self.base_url + end_point
        parameters = {
            "locale": locale,
            "page": page,
            "limit": limit,
            "type": type_args,
            "tag": tag,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)
