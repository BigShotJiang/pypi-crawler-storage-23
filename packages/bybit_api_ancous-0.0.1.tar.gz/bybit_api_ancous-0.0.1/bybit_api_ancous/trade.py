"""
Модуль для работы с торговыми операциями через Bybit API v5.

Этот модуль предоставляет класс Trade для управления торговыми операциями,
включая создание, изменение, отмену ордеров, получение истории торговли
и выполнение пакетных операций.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class Trade:
    """
    Класс для работы с торговыми операциями Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для:
    - Получения информации об ордерах в реальном времени
    - Создания, изменения и отмены ордеров
    - Выполнения пакетных операций с ордерами
    - Получения истории торговли и исполнений
    """

    def get_order_realtime(
        self,
        category: str,
        open_only: int = 0,
        limit: int = 20,
        symbol: str | None = None,
        base_coin: str | None = None,
        settle_coin: str | None = None,
        order_id: str | None = None,
        order_filter: str | None = None,
        cursor: str | None = None,
        order_link_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации об ордерах в реальном времени.

        Parameters:
        category (str): Категория продукта
        open_only (int): Показывать только открытые ордера
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета
        settle_coin (str | None): Монета расчетов
        order_id (str | None): ID ордера
        order_filter (str | None): Фильтр ордеров
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией об ордерах в реальном времени
        """
        end_point = "/v5/order/realtime"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "openOnly": open_only,
            "limit": limit,
            "symbol": symbol,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "orderId": order_id,
            "orderFilter": order_filter,
            "cursor": cursor,
            "orderLinkId": order_link_id,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_order_spot_borrow_check(
        self,
        category: str | None = None,
        symbol: str | None = None,
        side: str | None = None,
    ) -> dict[str, Any]:
        """
        Проверка возможности займа для спот ордеров.

        Parameters:
        category (str | None): Категория продукта
        symbol (str | None): Символ торговой пары
        side (str | None): Направление сделки

        Return:
        dict[str, Any]: Ответ API с результатом проверки займа
        """
        end_point = "/v5/order/spot-borrow-check"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "side": side,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_order_history(
        self,
        category: str,
        limit: int = 20,
        symbol: str | None = None,
        base_coin: str | None = None,
        settle_coin: str | None = None,
        order_id: str | None = None,
        order_link_id: str | None = None,
        order_filter: str | None = None,
        order_status: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории ордеров.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета
        settle_coin (str | None): Монета расчетов
        order_id (str | None): ID ордера
        order_link_id (str | None): ID ордера пользователя
        order_filter (str | None): Фильтр ордеров
        order_status (str | None): Статус ордера
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с историей ордеров
        """
        end_point = "/v5/order/history"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "limit": limit,
            "symbol": symbol,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "orderFilter": order_filter,
            "orderStatus": order_status,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_disconnected_cancel_all(
        self,
        time_window: int,
        product: str = "OPTIONS",
    ) -> dict[str, Any]:
        """
        Запрос на настройку DCP.

        Parameters:
        time_window (int): Временное окно в секундах
        product (str): Тип продукта

        Return:
        dict[str, Any]: Ответ API с результатом отмены ордеров
        """
        end_point = "/v5/order/disconnected-cancel-all"
        complete_request = self.base_url + end_point
        parameters = {
            "timeWindow": time_window,
            "product": product,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_execution_list(
        self,
        category: str,
        limit: int = 50,
        symbol: str | None = None,
        order_id: str | None = None,
        order_link_id: str | None = None,
        base_coin: str | None = None,
        settle_coin: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        exec_type: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка исполнений ордеров.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        order_id (str | None): ID ордера
        order_link_id (str | None): ID ордера пользователя
        base_coin (str | None): Базовая монета
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        exec_type (str | None): Тип исполнения
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API со списком исполнений
        """
        end_point = "/v5/execution/list"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "limit": limit,
            "symbol": symbol,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "startTime": start_time,
            "endTime": end_time,
            "execType": exec_type,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_pre_check(
        self,
        category: str,
        symbol: str,
        side: str,
        order_type: str,
        qty: str,
        is_leverage: int = 0,
        order_filter: str = "order",
        time_in_force: str = "GTC",
        tp_trigger_by: str = "LastPrice",
        sl_trigger_by: str = "LastPrice",
        market_unit: str | None = None,
        slippage_tolerance_type: str | None = None,
        slippage_tolerance: str | None = None,
        price: str | None = None,
        trigger_direction: int | None = None,
        trigger_price: str | None = None,
        trigger_by: str | None = None,
        order_iv: str | None = None,
        position_idx: int | None = None,
        order_link_id: str | None = None,
        take_profit: str | None = None,
        stop_loss: str | None = None,
        reduce_only: bool | None = None,
        close_on_trigger: bool | None = None,
        smp_type: str | None = None,
        mmp: bool | None = None,
        tpsl_mode: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
        tp_order_type: str | None = None,
        sl_order_type: str | None = None,
        bbo_side_type: str | None = None,
        bbo_level: str | None = None,

    ) -> dict[str, Any]:
        """
        Предварительная проверка ордера.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        side (str): Направление сделки
        order_type (str): Тип ордера
        qty (str): Количество
        is_leverage (int): Флаг использования кредитного плеча
        order_filter (str): Фильтр ордеров
        time_in_force (str): Время действия ордера
        tp_trigger_by (str): Способ срабатывания тейк-профита
        sl_trigger_by (str): Способ срабатывания стоп-лосса
        market_unit (str | None): Единицы измерения для рыночных ордеров
        slippage_tolerance_type (str | None): Тип допуска проскальзывания
        slippage_tolerance (str | None): Допуск проскальзывания
        price (str | None): Цена
        trigger_direction (int | None): Направление срабатывания
        trigger_price (str | None): Цена срабатывания
        trigger_by (str | None): Способ срабатывания
        order_iv (str | None): Волатильность ордера
        position_idx (int | None): Индекс позиции
        order_link_id (str | None): ID ордера пользователя
        take_profit (str | None): Цена тейк-профита
        stop_loss (str | None): Цена стоп-лосса
        reduce_only (bool | None): Флаг только уменьшения позиции
        close_on_trigger (bool | None): Флаг закрытия при срабатывании
        smp_type (str | None): Тип SMP
        mmp (bool | None): Флаг MMP
        tpsl_mode (str | None): Режим TPSL
        tp_limit_price (str | None): Лимитная цена тейк-профита
        sl_limit_price (str | None): Лимитная цена стоп-лосса
        tp_order_type (str | None): Тип ордера тейк-профита
        sl_order_type (str | None): Тип ордера стоп-лосса
        bbo_side_type (str | None): Тип стороны BBO
        bbo_level (str | None): Уровень BBO

        Return:
        dict[str, Any]: Ответ API с результатом предварительной проверки
        """
        end_point = "/v5/order/pre-check"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "isLeverage": is_leverage,
            "side": side,
            "orderType": order_type,
            "qty": qty,
            "marketUnit": market_unit,
            "slippageToleranceType": slippage_tolerance_type,
            "slippageTolerance": slippage_tolerance,
            "price": price,
            "triggerDirection": trigger_direction,
            "orderFilter": order_filter,
            "triggerPrice": trigger_price,
            "triggerBy": trigger_by,
            "orderIv": order_iv,
            "timeInForce": time_in_force,
            "positionIdx": position_idx,
            "orderLinkId": order_link_id,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "reduceOnly": reduce_only,
            "closeOnTrigger": close_on_trigger,
            "smpType": smp_type,
            "mmp": mmp,
            "tpslMode": tpsl_mode,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
            "tpOrderType": tp_order_type,
            "slOrderType": sl_order_type,
            "bboSideType": bbo_side_type,
            "bboLevel": bbo_level,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_create(
        self,
        category: str,
        symbol: str,
        side: str,
        order_type: str,
        qty: str,
        is_leverage: int = 0,
        order_filter: str = "order",
        time_in_force: str = "GTC",
        tp_trigger_by: str = "LastPrice",
        sl_trigger_by: str = "LastPrice",
        market_unit: str | None = None,
        slippage_tolerance_type: str | None = None,
        slippage_tolerance: str | None = None,
        price: str | None = None,
        trigger_direction: int | None = None,
        trigger_price: str | None = None,
        trigger_by: str | None = None,
        order_iv: str | None = None,
        position_idx: int | None = None,
        order_link_id: str | None = None,
        take_profit: str | None = None,
        stop_loss: str | None = None,
        reduce_only: bool | None = None,
        close_on_trigger: bool | None = None,
        smp_type: str | None = None,
        mmp: bool | None = None,
        tpsl_mode: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
        tp_order_type: str | None = None,
        sl_order_type: str | None = None,
        bbo_side_type: str | None = None,
        bbo_level: str | None = None,
    ) -> dict[str, Any]:
        """
        Создание ордера.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        side (str): Направление сделки
        order_type (str): Тип ордера
        qty (str): Количество
        is_leverage (int): Флаг использования кредитного плеча
        order_filter (str): Фильтр ордеров
        time_in_force (str): Время действия ордера
        tp_trigger_by (str): Способ срабатывания тейк-профита
        sl_trigger_by (str): Способ срабатывания стоп-лосса
        market_unit (str | None): Единицы измерения для рыночных ордеров
        slippage_tolerance_type (str | None): Тип допуска проскальзывания
        slippage_tolerance (str | None): Допуск проскальзывания
        price (str | None): Цена
        trigger_direction (int | None): Направление срабатывания
        trigger_price (str | None): Цена срабатывания
        trigger_by (str | None): Способ срабатывания
        order_iv (str | None): Волатильность ордера
        position_idx (int | None): Индекс позиции
        order_link_id (str | None): ID ордера пользователя
        take_profit (str | None): Цена тейк-профита
        stop_loss (str | None): Цена стоп-лосса
        reduce_only (bool | None): Флаг только уменьшения позиции
        close_on_trigger (bool | None): Флаг закрытия при срабатывании
        smp_type (str | None): Тип SMP
        mmp (bool | None): Флаг MMP
        tpsl_mode (str | None): Режим TPSL
        tp_limit_price (str | None): Лимитная цена тейк-профита
        sl_limit_price (str | None): Лимитная цена стоп-лосса
        tp_order_type (str | None): Тип ордера тейк-профита
        sl_order_type (str | None): Тип ордера стоп-лосса
        bbo_side_type (str | None): Тип стороны BBO
        bbo_level (str | None): Уровень BBO

        Return:
        dict[str, Any]: Ответ API с результатом создания ордера
        """
        end_point = "/v5/order/create"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "isLeverage": is_leverage,
            "side": side,
            "orderType": order_type,
            "qty": qty,
            "marketUnit": market_unit,
            "slippageToleranceType": slippage_tolerance_type,
            "slippageTolerance": slippage_tolerance,
            "price": price,
            "triggerDirection": trigger_direction,
            "orderFilter": order_filter,
            "triggerPrice": trigger_price,
            "triggerBy": trigger_by,
            "orderIv": order_iv,
            "timeInForce": time_in_force,
            "positionIdx": position_idx,
            "orderLinkId": order_link_id,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "reduceOnly": reduce_only,
            "closeOnTrigger": close_on_trigger,
            "smpType": smp_type,
            "mmp": mmp,
            "tpslMode": tpsl_mode,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
            "tpOrderType": tp_order_type,
            "slOrderType": sl_order_type,
            "bboSideType": bbo_side_type,
            "bboLevel": bbo_level,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_amend(
        self,
        category: str,
        symbol: str,
        order_id: str | None = None,
        order_link_id: str | None = None,
        order_iv: str | None = None,
        trigger_price: str | None = None,
        qty: str | None = None,
        price: str | None = None,
        tpsl_mode: str | None = None,
        take_profit: str | None = None,
        stop_loss: str | None = None,
        tp_trigger_by: str | None = None,
        sl_trigger_by: str | None = None,
        trigger_by: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
    ) -> dict[str, Any]:
        """
        Изменение ордера.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        order_id (str | None): ID ордера
        order_link_id (str | None): ID ордера пользователя
        order_iv (str | None): Волатильность ордера
        trigger_price (str | None): Цена срабатывания
        qty (str | None): Количество
        price (str | None): Цена
        tpsl_mode (str | None): Режим TPSL
        take_profit (str | None): Цена тейк-профита
        stop_loss (str | None): Цена стоп-лосса
        tp_trigger_by (str | None): Способ срабатывания тейк-профита
        sl_trigger_by (str | None): Способ срабатывания стоп-лосса
        trigger_by (str | None): Способ срабатывания
        tp_limit_price (str | None): Лимитная цена тейк-профита
        sl_limit_price (str | None): Лимитная цена стоп-лосса

        Return:
        dict[str, Any]: Ответ API с результатом изменения ордера
        """
        end_point = "/v5/order/amend"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "orderIv": order_iv,
            "triggerPrice": trigger_price,
            "qty": qty,
            "price": price,
            "tpslMode": tpsl_mode,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "triggerBy": trigger_by,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_cancel(
        self,
        category: str,
        symbol: str,
        order_filter: str = "order",
        order_id: str | None = None,
        order_link_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Отмена ордера

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        order_filter (str): Фильтр ордеров
        order_id (str | None): ID ордера
        order_link_id (str | None): ID ордера пользователя

        Return:
        dict[str, Any]: Ответ API с результатом отмены ордера
        """
        end_point = "/v5/order/cancel"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "orderFilter": order_filter,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_cancel_all(
        self,
        category: str,
        symbol: str | None = None,
        base_coin: str | None = None,
        settle_coin: str | None = None,
        order_filter: str | None = None,
        stop_order_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Отмена всех ордеров.

        Parameters:
        category (str): Категория продукта
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета
        settle_coin (str | None): Монета расчетов
        order_filter (str | None): Фильтр ордеров
        stop_order_type (str | None): Тип стоп-ордера

        Return:
        dict[str, Any]: Ответ API с результатом отмены всех ордеров
        """
        end_point = "/v5/order/cancel-all"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "orderFilter": order_filter,
            "stopOrderType": stop_order_type,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_create_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
    ) -> dict[str, Any]:
        """
        Пакетное создание ордеров.

        Каждый словарь в request должен содержать:
        - symbol (str): Символ торговой пары (обязательный)
        - side (str): Направление сделки (обязательный)
        - orderType (str): Тип ордера (обязательный)
        - qty (str): Количество (обязательный)
        - isLeverage (int): Флаг использования кредитного плеча
        - marketUnit (str): Единицы измерения
        - price (str): Цена
        - triggerDirection (int): Направление срабатывания
        - orderFilter (str): Фильтр ордеров
        - triggerPrice (str): Цена срабатывания
        - triggerBy (str): Способ срабатывания
        - orderIv (str): Волатильность ордера
        - timeInForce (str): Время исполнения
        - positionIdx (int): Индекс позиции
        - orderLinkId (str): ID ордера
        - takeProfit (str): Лимит прибыли
        - stopLoss (str): Лимит убытка
        - tpTriggerBy (str): Способ срабатывания прибыли
        - slTriggerBy (str): Способ срабатывания убытка
        - reduceOnly (bool): Флаг reduce only
        - closeOnTrigger (bool): Флаг закрытия позиции при срабатывании
        - smpType (str): Тип SMP
        - mmp (bool): Флаг MMP
        - tpslMode (str): Тип TPSL
        - tpLimitPrice (str): Лимит цены прибыли
        - slLimitPrice (str): Лимит цены убытка
        - tpOrderType (str): Тип ордера прибыли
        - slOrderType (str): Тип ордера убытка

        request должен получить данные такого вида:
        [
            {
                "category": "linear",
                "symbol": "BTCUSDT",
                "side": "Buy",
                "order_type": "Limit",
                "qty": "0.001",
                "price": "56000",
                "orderLinkId": "linear-001",
            },
            {
                "category": "linear",
                "symbol": "BTCUSDT",
                "side": "Buy",
                "order_type": "Limit",
                "qty": "0.003",
                "price": "76000",
                "orderLinkId": "linear-002",
            },
        ]

        Parameters:
        category (str): Категория продукта
        request (list[dict[str, str | int | bool]]): Список ордеров для создания

        Return:
        dict[str, Any]: Ответ API с результатом пакетного создания ордеров
        """
        end_point = "/v5/order/create-batch"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "request": request,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_amend_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
    ) -> dict[str, Any]:
        """
        Пакетное изменение ордеров

        Каждый словарь в request должен содержать:
        - symbol (str): Символ торговой пары (обязательный)
        - order_id (str): ID ордера (обязательный)
        - order_link_id (str): ID ордера пользователя
        - order_iv (str): Волатильность ордера
        - trigger_price (str): Цена срабатывания
        - qty (str): Количество
        - price (str): Цена
        - tpsl_mode (str): Тип TPSL
        - take_profit (str): Лимит прибыли
        - stop_loss (str): Лимит убытка
        - tp_trigger_by (str): Способ срабатывания прибыли
        - sl_trigger_by (str): Способ срабатывания убытка
        - trigger_by (str): Способ срабатывания
        - tp_limit_price (str): Лимит цены прибыли
        - sl_limit_price (str): Лимит цены убытка

        request должен получить данные такого вида:
        [
            {
                "category": "linear",
                "symbol": "BTCUSDT",
                "side": "Buy",
                "order_type": "Limit",
                "qty": "0.007",
                "price": "16000",
                "order_link_id": "linear-001",
            },
            {
                "category": "linear",
                "symbol": "BTCUSDT",
                "side": "Buy",
                "order_type": "Limit",
                "qty": "0.009",
                "price": "36000",
                "order_link_id": "linear-002",
            },
        ]

        Parameters:
        category (str): Категория продукта
        request (list[dict[str, str | int | bool]]): Список ордеров для изменения

        Return:
        dict[str, Any]: Ответ API с результатом пакетного изменения ордеров
        """
        end_point = "/v5/order/amend-batch"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "request": request,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_order_cancel_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
    ) -> dict[str, Any]:
        """
        Пакетная отмена ордеров.

        Каждый словарь в request должен содержать:
        - symbol (str): Символ торговой пары (обязательный)
        - order_id (str): ID ордера (обязательный)
        - order_link_id (str): ID ордера пользователя

        request должен получить данные такого вида:
        [
            {
                "symbol": "BTCUSDT",
                "order_link_id": "linear-001"
            },
            {
                "symbol": "BTCUSDT",
                "order_link_id": "linear-002"
            }
        ]

        Parameters:
        category (str): Категория продукта
        request (list[dict[str, str | int | bool]]): Список ордеров для отмены

        Return:
        dict[str, Any]: Ответ API с результатом пакетной отмены ордеров
        """
        end_point = "/v5/order/cancel-batch"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "request": request,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
