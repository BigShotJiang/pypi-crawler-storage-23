"""
Модуль для работы с приватными WebSocket каналами Bybit API v5.

Этот модуль предоставляет класс WsPrivate для подписки на приватные WebSocket каналы,
включая каналы исполнений, позиций, ордеров, кошелька, греков и других приватных данных.
"""

import json
import time
from typing import Callable
from .websocket_manager import WebSocketManager


class WsPrivate(WebSocketManager):
    """
    Класс для работы с приватными WebSocket каналами Bybit API v5.

    Предоставляет методы для подписки на приватные каналы:
    - Исполнения ордеров (execution, execution.fast)
    - Позиции (position)
    - Ордера (order)
    - Кошелек (wallet)
    - Греки (greeks)
    - Спред ордера и исполнения (spread.order, spread.execution)
    - RFQ каналы (rfq.open.quotes, rfq.open.trades, rfq.open.rfqs)
    - DCP каналы (dcp)

    Требует аутентификации через API ключ и секрет.

    """

    def __init__(self, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация клиента приватных WebSocket каналов.

        Parameters:
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации
        callback (dict): словарь callback функций для обработки сообщений
        args (list): список аргументов для подписки
        """
        super().__init__(api_key, secret_key)
        self.callback = {}
        self.args = []

    def _add_args_and_callback(
        self,
        prefix_1: str,
        callback: Callable | None,
        prefix_2: str | None = None,
    ) -> None:
        """
        Добавляет аргументы и callback в список и словарь.

        Формирует строку аргумента из префиксов и добавляет её в список args.
        Если передан callback, добавляет его в словарь callback с ключом аргумента.

        Parameters:
        prefix_1 (str): Первый префикс аргумента
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        prefix_2 (str | None): Второй префикс аргумента (опциональный)
        """
        arg = f"{prefix_1}.{prefix_2}" if prefix_2 else f"{prefix_1}"

        self.args.append(arg)
        if callback:
            self.callback[arg] = callback

    def ws_execution(
        self,
        op: str = "subscribe",
        categories_topic: str | list[str] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал исполнений ордеров.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        categories_topic (str | list[str] | None): Категория или список категорий для подписки
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if categories_topic:
            categories_topic = categories_topic if isinstance(categories_topic, list) else [categories_topic]
            for ct in categories_topic:
                self._add_args_and_callback(prefix_1="execution", prefix_2=ct, callback=callback)
        else:
            self._add_args_and_callback(prefix_1="execution", callback=callback)

        subscribe_request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(subscribe_request))

    def ws_execution_fast(
        self,
        op: str = "subscribe",
        categories_topic: str | list[str] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на быстрый канал исполнений ордеров.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        categories_topic (str | list[str] | None): Категория или список категорий для подписки
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if categories_topic:
            categories_topic = categories_topic if isinstance(categories_topic, list) else [categories_topic]
            for ct in categories_topic:
                self._add_args_and_callback(prefix_1="execution.fast", prefix_2=ct, callback=callback)
        else:
            self._add_args_and_callback(prefix_1="execution.fast", callback=callback)

        subscribe_request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(subscribe_request))

    def ws_position(
        self,
        op: str = "subscribe",
        categories_topic: str | list[str] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал позиций.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        categories_topic (str | list[str] | None): Категория или список категорий для подписки
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if categories_topic:
            categories_topic = categories_topic if isinstance(categories_topic, list) else [categories_topic]
            for ct in categories_topic:
                self._add_args_and_callback(prefix_1="position", prefix_2=ct, callback=callback)
        else:
            self._add_args_and_callback(prefix_1="position", callback=callback)

        subscribe_request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(subscribe_request))

    def ws_order(
        self,
        op: str = "subscribe",
        categories_topic: str | list[str] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал ордеров.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        categories_topic (str | list[str] | None): Категория или список категорий для подписки
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if categories_topic:
            categories_topic = categories_topic if isinstance(categories_topic, list) else [categories_topic]
            for ct in categories_topic:
                self._add_args_and_callback(prefix_1="order", prefix_2=ct, callback=callback)
        else:
            self._add_args_and_callback(prefix_1="order", callback=callback)

        subscribe_request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(subscribe_request))

    def ws_dcp(
        self,
        categories_topic: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал DCP (Derivatives Clearing Platform).

        Parameters:
        categories_topic (str | list[str]): Категория или список категорий для подписки (обязательный)
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if categories_topic:
            categories_topic = categories_topic if isinstance(categories_topic, list) else [categories_topic]
            for ct in categories_topic:
                self._add_args_and_callback(prefix_1="dcp", prefix_2=ct, callback=callback)
        else:
            self._add_args_and_callback(prefix_1="dcp", callback=callback)

        subscribe_request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(subscribe_request))

    def ws_wallet(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал кошелька.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["wallet"] = callback

        subscribe_request = {"op": op, "args": ["wallet"], "req_id": "['wallet']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_greeks(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал греков.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["greeks"] = callback

        subscribe_request = {"op": op, "args": ["greeks"], "req_id": "['greeks']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_spread_order(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал спред ордеров.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["spread.order"] = callback

        subscribe_request = {"op": op, "args": ["spread.order"], "req_id": "['spread.order']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_spread_execution(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал спред исполнений.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["spread.execution"] = callback

        subscribe_request = {"op": op, "args": ["spread.execution"], "req_id": "['spread.execution']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_rfq_open_quotes(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал открытых котировок RFQ.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["rfq.open.quotes"] = callback

        subscribe_request = {"op": op, "args": ["rfq.open.quotes"], "req_id": "['rfq.open.quotes']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_rfq_open_trades(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал открытых сделок RFQ

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["rfq.open.trades"] = callback

        subscribe_request = {"op": op, "args": ["rfq.open.trades"], "req_id": "['rfq.open.trades']"}
        self.ws.send(json.dumps(subscribe_request))

    def ws_rfq_open_rfqs(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал открытых RFQ запросов.

        Parameters:
        op (str): Операция (subscribe или unsubscribe)
        callback (Callable | None): Функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["rfq.open.rfqs"] = callback

        subscribe_request = {"op": op, "args": ["rfq.open.rfqs"], "req_id": "['rfq.open.rfqs']"}
        self.ws.send(json.dumps(subscribe_request))
