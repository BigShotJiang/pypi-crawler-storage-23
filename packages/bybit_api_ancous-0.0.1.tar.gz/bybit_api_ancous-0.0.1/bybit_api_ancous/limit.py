"""
Модуль для работы с лимитами API через Bybit API v5.

Этот модуль предоставляет класс Limit для управления лимитами API запросов,
включая запрос информации о лимитах, установку лимитов и получение квот.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class Limit:
    """
    Класс для работы с лимитами API Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для:
    - Запроса информации о лимитах API
    - Установки лимитов для пользователей
    - Получения квот и ограничений
    """

    def get_limit_query_all(
        self,
        limit: int = 1000,
        cursor: str | None = None,
        uids: str | None = None,
    ) -> dict[str, Any]:
        """
        Запрос всех лимитов API.

        Parameters:
        limit (int): Максимальное количество записей
        cursor (str | None): Курсор для пагинации
        uids (str | None): UID пользователей для фильтрации

        Return:
        dict[str, Any]: Ответ API с информацией о всех лимитах
        """
        end_point = "/v5/apilimit/query-all"
        complete_request = self.base_url + end_point
        parameters = {
            "limit": limit,
            "cursor": cursor,
            "uids": uids,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_limit_query(
        self,
        uids: str,
    ) -> dict[str, Any]:
        """
        Запрос лимитов API для конкретных пользователей.

        Parameters:
        uids (str): UID пользователей, разделенные запятыми

        Return:
        dict[str, Any]: Ответ API с информацией о лимитах для указанных пользователей
        """
        end_point = "/v5/apilimit/query"
        complete_request = self.base_url + end_point
        parameters = {
            "uids": uids,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_limit_query_cap(self) -> dict[str, Any]:
        """
        Запрос квот лимитов API.

        Return:
        dict[str, Any]: Ответ API с информацией о квотах лимитов
        """
        end_point = "/v5/apilimit/query-cap"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def post_limit_set(
        self,
        limits: list[dict[str, str | int]],
    ) -> dict[str, Any]:
        """
        Установка лимитов API для пользователей.

        Каждый словарь должен содержать:
        - uids (str): UID пользователей, если несколько — разделить запятыми
        - bizType (str): Тип бизнеса ("DERIVATIVES", "SPOT", "OPTIONS")
        - rate (int): Лимит API-запросов в секунду

        limits должен получить данные такого вида:
        [
            {"uids": "106293838, 34231231", "bizType": "DERIVATIVES", "rate": 50},
            {"uids": "234324324234", "bizType": "SPOT", "rate": 10}
        ]

        Parameters:
        limits (list[dict[str, str | int]]): Список словарей с лимитами

        Return:
        dict[str, Any]: Ответ API с результатом установки лимитов
        """
        end_point = "/v5/apilimit/set"
        complete_request = self.base_url + end_point

        parameters = {"list": limits}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
