"""
Модуль для работы с рыночными данными через Bybit API v5.

Этот модуль предоставляет класс Market для получения различных рыночных данных,
включая свечи, стакан заявок, тикеры, информацию об инструментах и другие данные.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class Market:
    """
    Класс для работы с рыночными данными Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для получения различных рыночных данных:
    - Временные данные и свечи
    - Стакан заявок и торговые данные
    - Информация об инструментах и тикерах
    - Данные по финансированию и волатильности
    """

    def get_market_time(self) -> dict[str, Any]:
        """
        Получение серверного времени Bybit.

        Return:
        dict[str, Any]: Ответ API с серверным временем в формате timestamp
        """
        end_point = "/v5/market/time"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request)

    def get_market_kline(
        self,
        symbol: str,
        interval: str,
        category: str = "linear",
        limit: int = 200,
        start: int | None = None,
        end: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение исторических данных свечей.

        Parameters:
        symbol (str): Символ торговой пары
        interval (str): Интервал свечей
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        start (int | None): Время начала в формате timestamp
        end (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с историческими данными свечей
        """

        end_point = "/v5/market/kline"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "interval": interval,
            "category": category,
            "limit": limit,
            "start": start,
            "end": end,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_orderbook(
        self,
        category: str,
        symbol: str,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение стакана заявок.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        limit (int | None): Количество уровней в стакане

        Return:
        dict[str, Any]: Ответ API со стаканом заявок
        """

        end_point = "/v5/market/orderbook"
        complete_request = self.base_url + end_point
        parameters = {"category": category, "symbol": symbol, "limit": limit}

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_rpi_orderbook(
        self,
        symbol: str,
        limit: int,
        category: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение стакана заявок с RPI.

        Parameters:
        symbol (str): Символ торговой пары
        limit (int): Количество уровней в стакане
        category (str | None): Категория продукта

        Return:
        dict[str, Any]: Ответ API со стаканом заявок с RPI
        """

        end_point = "/v5/market/rpi_orderbook"
        complete_request = self.base_url + end_point
        parameters = {"category": category, "symbol": symbol, "limit": limit}

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_fee_group_info(
        self,
        product_type: str,
        group_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о группах комиссий.

        Parameters:
        product_type (str): Тип продукта
        group_id (str | None): ID группы комиссий

        Return:
        dict[str, Any]: Ответ API с информацией о группах комиссий
        """

        end_point = "/v5/market/fee-group-info"
        complete_request = self.base_url + end_point
        parameters = {
            "productType": product_type,
            "groupId": group_id,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_adl_alert(self, symbol: str | None = None) -> dict[str, Any]:
        """
        Получение предупреждений ADL

        Parameters:
        symbol (str | None): Символ торговой пары

        Return:
        dict[str, Any]: Ответ API с предупреждениями ADL
        """

        end_point = "/v5/market/adlAlert"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_delivery_price(
        self,
        category: str,
        base_coin: str = "BTC",
        settle_coin: str = "USDC",
        limit: int = 50,
        symbol: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение цен поставки.

        Parameters:
        category (str): Категория продукта
        base_coin (str): Базовая монета
        settle_coin (str): Монета расчетов
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с ценами поставки
        """

        end_point = "/v5/market/delivery-price"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "limit": limit,
            "symbol": symbol,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_mark_price_kline(
        self,
        symbol: str,
        interval: str,
        category: str = "linear",
        limit: int = 200,
        start: int | None = None,
        end: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение исторических данных маркировочных цен в формате свечей

        Parameters:
        symbol (str): Символ торговой пары
        interval (str): Интервал свечей
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        start (int | None): Время начала в формате timestamp
        end (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с историческими данными маркировочных цен
        """

        end_point = "/v5/market/mark-price-kline"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "interval": interval,
            "category": category,
            "limit": limit,
            "start": start,
            "end": end,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_index_price_kline(
        self,
        symbol: str,
        interval: str,
        category: str = "linear",
        limit: int = 200,
        start: int | None = None,
        end: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение исторических данных индексных цен в формате свечей.

        Parameters:
        symbol (str): Символ торговой пары
        interval (str): Интервал свечей
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        start (int | None): Время начала в формате timestamp
        end (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с историческими данными индексных цен
        """

        end_point = "/v5/market/index-price-kline"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "interval": interval,
            "category": category,
            "limit": limit,
            "start": start,
            "end": end,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_premium_index_price_kline(
        self,
        symbol: str,
        interval: str,
        category: str = "linear",
        limit: int = 200,
        start: int | None = None,
        end: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение исторических данных премиум-индексных цен в формате свечей

        Parameters:
        symbol (str): Символ торговой пары
        interval (str): Интервал свечей
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        start (int | None): Время начала в формате timestamp
        end (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с историческими данными премиум-индексных цен
        """

        end_point = "/v5/market/premium-index-price-kline"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "interval": interval,
            "category": category,
            "limit": limit,
            "start": start,
            "end": end,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_recent_trade(
        self,
        category: str,
        base_coin: str = "BTC",
        symbol: str | None = None,
        option_type: str | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение последних сделок.

        Parameters:
        category (str): Категория продукта
        base_coin (str): Базовая монета
        symbol (str | None): Символ торговой пары
        option_type (str | None): Тип опциона
        limit (int | None): Максимальное количество записей

        Return:
        dict[str, Any]: Ответ API с последними сделками
        """

        end_point = "/v5/market/recent-trade"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "baseCoin": base_coin,
            "symbol": symbol,
            "optionType": option_type,
            "limit": limit,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_open_interest(
        self,
        category: str,
        symbol: str,
        interval_time: str,
        limit: int = 50,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение данных об открытом интересе

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        interval_time (str): Интервал времени
        limit (int): Максимальное количество записей
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с данными об открытом интересе
        """

        end_point = "/v5/market/open-interest"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "intervalTime": interval_time,
            "limit": limit,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_new_delivery_price(
        self,
        category: str,
        base_coin: str,
        settle_coin: str = "USDC",
    ) -> dict[str, Any]:
        """
        Получение новых цен поставки.

        Parameters:
        category (str): Категория продукта
        base_coin (str): Базовая монета
        settle_coin (str): Монета расчетов

        Return:
        dict[str, Any]: Ответ API с новыми ценами поставки
        """

        end_point = "/v5/market/new-delivery-price"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_price_limit(
        self,
        category: str = "linear",
        symbol: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение лимитов цен

        Parameters:
        category (str): Категория продукта
        symbol (str | None): Символ торговой пары

        Return:
        dict[str, Any]: Ответ API с лимитами цен
        """

        end_point = "/v5/market/price-limit"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_risk_limit(
        self,
        category: str,
        symbol: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение лимитов риска.

        Parameters:
        category (str): Категория продукта
        symbol (str | None): Символ торговой пары
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с лимитами риска
        """

        end_point = "/v5/market/risk-limit"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_index_price_components(
        self,
        index_name: str,
    ) -> dict[str, Any]:
        """
        Получение компонентов индексной цены

        Parameters:
        index_name (str): Название индекса

        Return:
        dict[str, Any]: Ответ API с компонентами индексной цены
        """

        end_point = "/v5/market/index-price-components"
        complete_request = self.base_url + end_point
        parameters = {
            "indexName": index_name,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_funding_history(
        self,
        category: str,
        symbol: str,
        limit: int = 200,
        start_time: int | None = None,
        end_time: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории финансирования.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        limit (int): Максимальное количество записей
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с историей финансирования
        """

        end_point = "/v5/market/funding/history"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "limit": limit,
            "startTime": start_time,
            "endTime": end_time,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_historical_volatility(
        self,
        category: str,
        base_coin: str = "BTC",
        quote_coin: str = "USD",
        period: int = 7,
        start_time: int | None = None,
        end_time: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение исторической волатильности.

        Parameters:
        category (str): Категория продукта
        base_coin (str): Базовая монета
        quote_coin (str): Котируемая монета
        period (int): Период в днях
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp

        Return:
        dict[str, Any]: Ответ API с исторической волатильностью
        """

        end_point = "/v5/market/historical-volatility"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "baseCoin": base_coin,
            "quoteCoin": quote_coin,
            "period": period,
            "startTime": start_time,
            "endTime": end_time,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_tickers(
        self,
        category: str,
        symbol: str | None = None,
        base_coin: str | None = None,
        exp_date: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о тикерах

        Parameters:
        category (str): Категория продукта
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета
        exp_date (str | None): Дата экспирации

        Return:
        dict[str, Any]: Ответ API с тикерами
        """

        end_point = "/v5/market/tickers"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "quoteCoin": base_coin,
            "expDate": exp_date,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_instruments_info(
        self,
        category: str,
        limit: int = 500,
        symbol_type: str | None = None,
        symbol: str | None = None,
        status: str | None = None,
        base_coin: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации об инструментах.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol_type (str | None): Тип символа
        symbol (str | None): Символ торговой пары
        status (str | None): Статус инструмента
        base_coin (str | None): Базовая монета
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией об инструментах
        """

        end_point = "/v5/market/instruments-info"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "limit": limit,
            "symbolType": symbol_type,
            "symbol": symbol,
            "status": status,
            "baseCoin": base_coin,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_account_ratio(
        self,
        category: str,
        symbol: str,
        period: str,
        limit: int = 50,
        start_time: str | None = None,
        end_time: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение соотношения аккаунтов

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        period (str): Период
        limit (int): Максимальное количество записей
        start_time (str | None): Время начала в формате timestamp
        end_time (str | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с соотношением аккаунтов
        """

        end_point = "/v5/market/account-ratio"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "period": period,
            "limit": limit,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)

    def get_market_insurance(
        self,
        coin: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о страховом фонде.

        Parameters:
        coin (str | None): Монета для фильтрации

        Return:
        dict[str, Any]: Ответ API с информацией о страховом фонде
        """

        end_point = "/v5/market/insurance"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(url=complete_request, params=parameters)
