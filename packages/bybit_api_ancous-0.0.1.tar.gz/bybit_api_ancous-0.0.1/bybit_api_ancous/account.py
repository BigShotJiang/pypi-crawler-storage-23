"""
Модуль для работы с аккаунтом через Bybit API v5

Этот модуль предоставляет класс Account для управления аккаунтом,
включая получение баланса, информации об аккаунте, истории транзакций,
управление залогами, маржинальным режимом и другими настройками аккаунта.
"""

from typing import Any, Dict, List

from bybit_api_ancous.api_manager import ApiManager


class Account:
    """
    Класс для работы с аккаунтом Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для:
    - Получения баланса кошелька и информации об аккаунте
    - Просмотра истории транзакций и займов
    - Управления залогами и маржинальным режимом
    - Настройки параметров аккаунта и комиссий
    - Управления займами и погашениями
    """

    def get_account_wallet_balance(self, account_type: str, coin: str | None = None) -> dict[str, Any]:
        """
        Получение баланса кошелька аккаунта.

        Parameters:
        account_type (str): Тип аккаунта
        coin (str | None): Монета для фильтрации

        Return:
        dict[str, Any]: Ответ API с балансом кошелька
        """
        end_point = "/v5/account/wallet-balance"
        complete_request = self.base_url + end_point
        parameters = {"accountType": account_type, "coin": coin}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_transaction_log(
        self,
        category: str,
        limit: int = 20,
        trans_sub_type: str | None = None,
        account_type: str | None = None,
        currency: str | None = None,
        base_coin: str | None = None,
        type_args: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение лога транзакций аккаунта.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        trans_sub_type (str | None): Подтип транзакции
        account_type (str | None): Тип аккаунта
        currency (str | None): Валюта
        base_coin (str | None): Базовая монета
        type_args (str | None): Тип транзакции
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с логом транзакций
        """
        end_point = "/v5/account/transaction-log"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "limit": limit,
            "transSubType": trans_sub_type,
            "accountType": account_type,
            "currency": currency,
            "baseCoin": base_coin,
            "type": type_args,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_contract_transaction_log(
        self,
        limit: int = 20,
        currency: str | None = None,
        base_coin: str | None = None,
        type_args: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение лога транзакций контрактов аккаунта.

        Parameters:
        limit (int): Максимальное количество записей
        currency (str | None): Валюта
        base_coin (str | None): Базовая монета
        type_args (str | None): Тип транзакции
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с логом транзакций контрактов
        """
        end_point = "/v5/account/contract-transaction-log"
        complete_request = self.base_url + end_point
        parameters = {
            "limit": limit,
            "currency": currency,
            "baseCoin": base_coin,
            "type": type_args,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_smp_group(self) -> dict[str, Any]:
        """
        Получение информации о SMP группе аккаунта.

        Return:
        dict[str, Any]: Ответ API с информацией о SMP группе
        """
        end_point = "/v5/account/smp-group"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_account_info(self) -> dict[str, Any]:
        """
        Получение информации об аккаунте.

        Return:
        dict[str, Any]: Ответ API с информацией об аккаунте
        """
        end_point = "/v5/account/info"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_account_instruments_info(
        self,
        category: str,
        limit: int = 200,
        symbol: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации об инструментах аккаунта.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией об инструментах
        """
        end_point = "/v5/account/instruments-info"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "limit": limit,
            "symbol": symbol,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_collateral_info(
        self,
        currency: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о залогах аккаунта.

        Parameters:
        currency (str | None): Валюта для фильтрации

        Return:
        dict[str, Any]: Ответ API с информацией о залогах
        """
        end_point = "/v5/account/collateral-info"
        complete_request = self.base_url + end_point
        parameters = {
            "currency": currency,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_query_dcp_info(self) -> dict[str, Any]:
        """
        Получение информации о DCP аккаунта.

        Return:
        dict[str, Any]: Ответ API с информацией о DCP
        """
        end_point = "/v5/account/query-dcp-info"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_account_borrow_history(
        self,
        limit: int = 20,
        currency: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории займов аккаунта.

        Parameters:
        limit (int): Максимальное количество записей
        currency (str | None): Валюта для фильтрации
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с историей займов
        """
        end_point = "/v5/account/borrow-history"
        complete_request = self.base_url + end_point
        parameters = {
            "limit": limit,
            "currency": currency,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_user_setting_config(self) -> dict:
        """
        Получение конфигурации настроек пользователя аккаунта

        Return:
        dict: Ответ API с конфигурацией настроек пользователя
        """
        end_point = "/v5/account/user-setting-config"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_account_fee_rate(
        self, category: str, symbol: str | None = None, base_coin: str | None = None
    ) -> dict[str, Any]:
        """
        Получение информации о комиссиях аккаунта.

        Parameters:
        category (str): Категория продукта
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета

        Return:
        dict[str, Any]: Ответ API с информацией о комиссиях
        """
        end_point = "/v5/account/fee-rate"
        complete_request = self.base_url + end_point
        parameters = {"category": category, "symbol": symbol, "baseCoin": base_coin}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_account_withdrawal(self, coin_name: str) -> dict[str, Any]:
        """
        Получение информации о выводах средств аккаунта.

        Parameters:
        coin_name (str): Название монеты

        Return:
        dict[str, Any]: Ответ API с информацией о выводах средств
        """
        end_point = "/v5/account/withdrawal"
        complete_request = self.base_url + end_point
        parameters = {"coinName": coin_name}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_mmp_state(self, base_coin: str) -> dict:
        """
        Получение состояния MMP (Market Maker Protection) для базовой монеты

        Parameters:
        base_coin (str): Базовая монета

        Return:
        dict: Ответ API с состоянием MMP
        """
        end_point = "/v5/account/mmp-state"
        complete_request = self.base_url + end_point
        parameters = {"baseCoin": base_coin}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_upgrade_to_uta(self) -> dict[str, Any]:
        """
        Обновление аккаунта до UTA (Unified Trading Account).

        Return:
        dict[str, Any]: Ответ API с результатом обновления
        """
        end_point = "/v5/account/upgrade-to-uta"
        complete_request = self.base_url + end_point

        return ApiManager().post(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def post_account_mmp_reset(
        self,
        base_coin: str,
    ) -> dict[str, Any]:
        """
        Сброс настроек MMP (Market Maker Protection) для базовой монеты.

        Parameters:
        base_coin (str): Базовая монета

        Return:
        dict[str, Any]: Ответ API с результатом сброса
        """
        end_point = "/v5/account/mmp-reset"
        complete_request = self.base_url + end_point
        parameters = {
            "baseCoin": base_coin,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_set_collateral_switch(
        self,
        coin: str,
        collateral_switch: str,
    ) -> dict[str, Any]:
        """
        Установка переключателя залога для монеты.

        Parameters:
        coin (str): Монета
        collateral_switch (str): Состояние переключателя залога

        Return:
        dict[str, Any]: Ответ API с результатом установки
        """
        end_point = "/v5/account/set-collateral-switch"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "collateralSwitch": collateral_switch,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_set_limit_px_action(
        self,
        category: str,
        modify_enable: bool,
    ) -> dict[str, Any]:
        """
        Установка действия лимитной цены для категории.

        Parameters:
        category (str): Категория продукта
        modify_enable (bool): Разрешить модификацию

        Return:
        dict[str, Any]: Ответ API с результатом установки
        """
        end_point = "/v5/account/set-limit-px-action"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "modifyEnable": modify_enable,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_set_collateral_switch_batch(
        self, request: List[Dict[str, str]]
    ) -> dict[str, Any]:
        """
        Установка переключателей залога для нескольких монет пакетно.

        Parameters:
        request (List[Dict[str, str]]): Список словарей с настройками залогов.
            Каждый словарь должен содержать:
            - coin (str): Монета (обязательный)
            - collateralSwitch (str): Состояние переключателя залога (обязательный)

        Return:
        dict[str, Any]: Ответ API с результатом установки

        Пример:
        [
            {
                "coin": "BTC",
                "collateralSwitch": "ON",
            },
            {
                "coin": "BNB",
                "collateralSwitch": "ON",
            },
        ]
        """
        end_point = "/v5/account/set-collateral-switch-batch"
        complete_request = self.base_url + end_point
        parameters = {"request": request}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_set_margin_mode(
        self,
        set_margin_mode: str,
    ) -> dict[str, Any]:
        """
        Установка маржинального режима аккаунта.

        Parameters:
        set_margin_mode (str): Маржинальный режим

        Return:
        dict[str, Any]: Ответ API с результатом установки
        """
        end_point = "/v5/account/set-margin-mode"
        complete_request = self.base_url + end_point
        parameters = {
            "setMarginMode": set_margin_mode,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_set_hedging_mode(
        self,
        set_hedging_mode: str,
    ) -> dict[str, Any]:
        """
        Установка режима хеджирования аккаунта.

        Parameters:
        set_hedging_mode (str): Режим хеджирования

        Return:
        dict[str, Any]: Ответ API с результатом установки
        """
        end_point = "/v5/account/set-hedging-mode"
        complete_request = self.base_url + end_point
        parameters = {
            "setHedgingMode": set_hedging_mode,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_mmp_modify(
        self,
        base_coin: str = "BTC",
        window: str = "5000",
        frozen_period: str = "100",
        qty_limit: str = "100",
        delta_limit: str = "100",
    ) -> dict[str, Any]:
        """
        Изменение настроек MMP (Market Maker Protection) для базовой монеты.

        Parameters:
        base_coin (str): Базовая монета
        window (str): Окно времени
        frozen_period (str): Период заморозки
        qty_limit (str): Лимит количества
        delta_limit (str): Лимит дельты

        Return:
        dict[str, Any]: Ответ API с результатом изменения
        """
        end_point = "/v5/account/mmp-modify"
        complete_request = self.base_url + end_point
        parameters = {
            "baseCoin": base_coin,
            "window": window,
            "frozenPeriod": frozen_period,
            "qtyLimit": qty_limit,
            "deltaLimit": delta_limit,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_borrow(
        self,
        coin: str,
        amount: str,
    ) -> dict:
        """
        Заимствование средств для аккаунта

        Parameters:
        coin (str): Монета для заимствования
        amount (str): Сумма заимствования

        Return:
        dict: Ответ API с результатом заимствования
        """
        end_point = "/v5/account/borrow"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "amount": amount,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_repay(
        self,
        coin: str | None = None,
        amount: str | None = None,
    ) -> dict[str, Any]:
        """
        Погашение займа для аккаунта.

        Parameters:
        coin (str | None): Монета для погашения
        amount (str | None): Сумма погашения

        Return:
        dict[str, Any]: Ответ API с результатом погашения
        """
        end_point = "/v5/account/repay"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "amount": amount,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_quick_repayment(self, coin: str | None = None) -> dict[str, Any]:
        """
        Быстрое погашение займа для аккаунта.

        Parameters:
        coin (str | None): Монета для погашения

        Return:
        dict[str, Any]: Ответ API с результатом быстрого погашения
        """
        end_point = "/v5/account/quick-repayment"
        complete_request = self.base_url + end_point
        parameters = {"coin": coin}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_account_no_convert_repay(
        self,
        coin: str,
        amount: str | None = None,
    ) -> dict[str, Any]:
        """
        Погашение займа без конвертации для аккаунта.

        Parameters:
        coin (str): Монета для погашения
        amount (str | None): Сумма погашения

        Return:
        dict[str, Any]: Ответ API с результатом погашения
        """
        end_point = "/v5/account/no-convert-repay"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "amount": amount,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_coin_greeks(self, base_coin: str | None = None) -> dict[str, Any]:
        """
        Получение греков (Greeks) для базовой монеты.

        Parameters:
        base_coin (str | None): Базовая монета

        Return:
        dict[str, Any]: Ответ API с греками монеты
        """
        end_point = "/v5/asset/coin-greeks"
        complete_request = self.base_url + end_point
        parameters = {"baseCoin": base_coin}
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
