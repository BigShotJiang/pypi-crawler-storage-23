"""
Модуль для выполнения HTTP запросов к Bybit API v5

Этот модуль предоставляет класс ApiManager для выполнения GET и POST запросов
к API Bybit с автоматической аутентификацией и подписью запросов.
"""

import time
from typing import Any

import requests

from bybit_api_ancous.encryption import HMACSHA256


class ApiManager:
    """
    Класс для выполнения HTTP запросов к Bybit API v5.

    Предоставляет статические методы для выполнения GET и POST запросов
    с автоматической аутентификацией и подписью запросов при наличии
    API ключей и секретов.
    """

    @staticmethod
    def get(
        url: str,
        api_key: str | None = None,
        secret_key: str | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Выполнение GET запроса к API Bybit.

        Parameters:
        url (str): URL для запроса
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации
        params (dict[str, Any] | None): Параметры запроса

        Return:
        dict[str, Any]: JSON ответ от API
        """
        if params is None:
            params = {}

        if api_key and secret_key:
            time_stamp = str(int(time.time() * 1000))
            recv_window = "5000"

            signature = HMACSHA256().compute_hex_by_get(
                api_key, secret_key, time_stamp, recv_window, params
            )
            headers = {
                "X-BAPI-API-KEY": api_key,
                "X-BAPI-SIGN": signature,
                "X-BAPI-TIMESTAMP": time_stamp,
                "X-BAPI-RECV-WINDOW": recv_window,
            }

            response = requests.get(url=url, params=params, headers=headers, timeout=10)

        else:
            response = requests.get(url=url, params=params, timeout=10)

        return response.json()

    @staticmethod
    def post(
        url: str,
        api_key: str,
        secret_key: str,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Выполнение POST запроса к API Bybit.

        Parameters:
        url (str): URL для запроса
        api_key (str): API ключ для аутентификации
        secret_key (str): Секретный ключ для аутентификации
        json (dict[str, Any] | None): JSON данные для отправки

        Return:
        dict[str, Any]: JSON ответ от API
        """
        if json is None:
            json = {}

        time_stamp = str(int(time.time() * 1000))
        recv_window = "5000"

        signature = HMACSHA256().compute_hex_by_post(
            api_key, secret_key, time_stamp, recv_window, json
        )
        headers = {
            "X-BAPI-API-KEY": api_key,
            "X-BAPI-SIGN": signature,
            "X-BAPI-TIMESTAMP": time_stamp,
            "X-BAPI-RECV-WINDOW": recv_window,
        }

        response = requests.post(url=url, json=json, headers=headers, timeout=10)

        return response.json()
