"""
Модуль для работы с WebSocket соединениями Bybit API v5 (Testnet).

Этот модуль предоставляет класс WebSocketBybitTest для создания WebSocket соединений
с тестовой сетью Bybit, включая автоматический выбор соответствующего класса
в зависимости от типа канала.
"""

import threading

from .ws_private import WsPrivate
from .ws_public import WsPublic
from .ws_system import WsSystem
from .ws_trade import WsTrade


class WebSocketBybitTest:
    """
    Класс для работы с WebSocket соединениями Bybit API v5 (Testnet).

    Предоставляет динамическое создание WebSocket соединений для различных каналов:
    - spot, linear, inverse, spread, option: публичные каналы (WsPublic)
    - private: приватные каналы (WsPrivate)
    - system: системные каналы (WsSystem)
    - trade: торговые каналы (WsTrade)

    Arguments:
    url (str): Базовый URL WebSocket сервера для testnet
    """

    url: str = "wss://stream-testnet.bybit.com/v5"

    def __new__(
        cls,
        channel: str,
        api_key: str | None = None,
        secret_key: str | None = None,
    ) -> "WebSocketBybitTest":
        """
        Создание нового экземпляра класса с динамическим выбором базового класса.

        Parameters:
        channel (str): Тип канала (spot, linear, inverse, spread, option, private, system, trade)
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации

        Return:
        WebSocketBybitTest: Экземпляр класса с соответствующим базовым классом
        """
        if channel in ("spot", "linear", "inverse", "spread", "option"):
            base = WsPublic
        elif channel == "private":
            base = WsPrivate
        elif channel == "system":
            base = WsSystem
        elif channel == "trade":
            base = WsTrade
        else:
            raise ValueError("Неверный канал")

        NewClass = type(cls.__name__, (cls, base), {})
        instance = object.__new__(NewClass)
        return instance

    def __init__(self, channel: str, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация WebSocket соединения для testnet.

        Parameters:
        channel (str): Тип канала (spot, linear, inverse, spread, option, private, system, trade)
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации
        """
        super().__init__(api_key, secret_key)
        if channel in ("spot", "linear", "inverse", "spread", "option"):
            self.name = "WsPublic"
            self.url = self.url + f"/public/{channel}"
        elif channel == "private":
            self.name = "WsPrivate"
            self.url = self.url + f"/{channel}"
        elif channel == "system":
            self.name = "WsSystem"
            self.url = self.url + "/public/misc/status"
        elif channel == "trade":
            self.name = "WsTrade"
            self.url = self.url + f"/{channel}"
        else:
            raise ValueError("Неверный канал")

        self.thread = threading.Thread(target=self.run_websocket, args=(self.url,))
        self.thread.start()
