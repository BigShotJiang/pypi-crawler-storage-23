"""
Модуль для работы с Bybit Mainnet API v5

Этот модуль предоставляет класс ApiBybitMain для работы с основной сетью Bybit,
объединяющий все функциональные модули для продакшн использования API.
"""

from bybit_api_ancous.user import User
from bybit_api_ancous.asset import Asset
from bybit_api_ancous.bybit import Bybit
from bybit_api_ancous.limit import Limit
from bybit_api_ancous.trade import Trade
from bybit_api_ancous.market import Market
from bybit_api_ancous.account import Account
from bybit_api_ancous.general import General
from bybit_api_ancous.position import Position


class ApiBybitMain(Bybit, Market, General, Limit, Trade, Position, Account, Asset, User):
    """
    Класс для работы с Bybit Mainnet API v5.

    Наследует функциональность от базовых классов:
    - Bybit: базовая инициализация API ключей
    - Market: работа с рыночными данными
    - General: общие функции API
    - Limit: управление лимитами API
    - Trade: управление торговлей
    - Position: управление позициями
    - Account: работа с аккаунтом
    - Asset: работа с активами
    - User: работа с пользователем

    Предназначен для продакшн использования с основной сетью Bybit.

    Arguments:
    api_key (str | None): API ключ для аутентификации (из Bybit)
    secret_key (str | None): Секретный ключ для аутентификации (из Bybit)
    """

    base_url: str = "https://api.bybit.com"
