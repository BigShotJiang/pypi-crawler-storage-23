"""
Модуль для работы с системными WebSocket каналами Bybit API v5.

Этот модуль предоставляет класс WsSystem для подписки на системные WebSocket каналы,
включая канал статуса системы.
"""

import json
import time
from typing import Callable
from bybit_api_ancous.websocket_manager import WebSocketManager


class WsSystem(WebSocketManager):
    """
    Класс для работы с системными WebSocket каналами Bybit API v5.

    Предоставляет методы для подписки на системные каналы:
    - Статус системы (system.status)

    Не требует аутентификации.
    """

    def __init__(self, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация клиента системных WebSocket каналов.

        Parameters:
        api_key (str | None): API ключ для аутентификации (опционально)
        secret_key (str | None): секретный ключ для аутентификации (опционально)
        callback (dict): словарь callback функций для обработки сообщений
        """
        super().__init__(api_key, secret_key)
        self.callback = {}

    def ws_status(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал статуса системы.

        Parameters:
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["system.status"] = callback

        request = {"op": op, "args": ["system.status"], "req_id": "['system.status']"}
        self.ws.send(json.dumps(request))
