"""
Модуль для работы с позициями через Bybit API v5.

Этот модуль предоставляет класс Position для управления позициями,
включая получение информации о позициях и настройку кредитного плеча.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class Position:
    """
    Класс для работы с позициями Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для:
    - Получения информации о позициях
    - Настройки кредитного плеча для позиций
    """

    def get_position_get_closed_positions(
        self,
        category: str = "option",
        limit: int = 50,
        symbol: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение полной информации о каждой закрытой позиций.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией о закрытых позициях
        """
        end_point = "/v5/position/get-closed-positions"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_position_closed_pnl(
        self,
        category: str,
        limit: int = 50,
        symbol: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение реализованного PnL по каждой закрытой позиций.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией о PnL закрытых позиций
        """
        end_point = "/v5/position/closed-pnl"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_position_list(
        self,
        category: str,
        limit: int = 20,
        symbol: str | None = None,
        base_coin: str | None = None,
        settle_coin: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о позициях.

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ торговой пары
        base_coin (str | None): Базовая монета
        settle_coin (str | None): Монета расчетов
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с информацией о позициях
        """
        end_point = "/v5/position/list"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "baseCoin": base_coin,
            "settleCoin": settle_coin,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_position_move_history(
        self,
        category: str | None = None,
        symbol: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        status: str | None = None,
        block_trade_id: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории перемещения позиций.

        Parameters:
        category (str | None): Категория продукта
        symbol (str | None): Символ торговой пары
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        status (str | None): Статус перемещения
        block_trade_id (str | None): ID блок-сделки
        limit (int | None): Максимальное количество записей
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с историей перемещения позиций
        """
        end_point = "/v5/position/move-history"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "startTime": start_time,
            "endTime": end_time,
            "status": status,
            "blockTradeId": block_trade_id,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_add_margin(
        self,
        symbol: str,
        category: str,
        margin: str,
        position_idx: int | None = None,
    ) -> dict[str, Any]:
        """
        Добавление маржи к позиции.

        Parameters:
        symbol (str): Символ торговой пары
        category (str): Категория продукта
        margin (str): Количество маржи для добавления
        position_idx (int | None): Индекс позиции

        Return:
        dict[str, Any]: Ответ API с результатом добавления маржи
        """
        end_point = "/v5/position/add-margin"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "margin": margin,
            "positionIdx": position_idx,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_switch_mode(
        self,
        category: str,
        mode: int,
        symbol: str | None = None,
        coin: str | None = None,
    ) -> dict[str, Any]:
        """
        Переключение режима торговли.

        Parameters:
        category (str): Категория продукта
        mode (int): Режим торговли
        symbol (str | None): Символ торговой пары
        coin (str | None): Монета

        Return:
        dict[str, Any]: Ответ API с результатом переключения режима
        """
        end_point = "/v5/position/switch-mode"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "coin": coin,
            "mode": mode,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_move_positions(
        self,
        from_uid: str,
        to_uid: str,
        list_obj: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """
        Перемещение позиций между аккаунтами.

        Parameters:
        from_uid (str): UID исходного аккаунта
        to_uid (str): UID целевого аккаунта
        list_obj (list[dict[str, Any]]): Список словарей с позициями для перемещения

        Return:
        dict[str, Any]: Ответ API с результатом перемещения позиций
        """
        end_point = "/v5/position/move-positions"
        complete_request = self.base_url + end_point
        parameters = {
            "fromUid": from_uid,
            "toUid": to_uid,
            "list": list_obj,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_confirm_pending_mmr(
        self,
        category: str,
        symbol: str,
    ) -> dict[str, Any]:
        """
        Подтверждение ожидающего MMR.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары

        Return:
        dict[str, Any]: Ответ API с результатом подтверждения MMR
        """
        end_point = "/v5/position/confirm-pending-mmr"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "category": category,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_set_auto_add_margin(
        self,
        symbol: str,
        category: str,
        auto_add_margin: int,
        position_idx: int | None = None,
    ) -> dict[str, Any]:
        """
        Установка автоматического добавления маржи.

        Parameters:
        symbol (str): Символ торговой пары
        category (str): Категория продукта
        auto_add_margin (int): Флаг автоматического добавления маржи
        position_idx (int | None): Индекс позиции

        Return:
        dict[str, Any]: Ответ API с результатом установки автоматического добавления маржи
        """
        end_point = "/v5/position/set-auto-add-margin"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "category": category,
            "autoAddMargin": auto_add_margin,
            "positionIdx": position_idx,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_set_leverage(
        self,
        symbol: str,
        category: str,
        buy_leverage: str,
        sell_leverage: str,
    ) -> dict[str, Any]:
        """
        Установка кредитного плеча для позиции.

        Parameters:
        symbol (str): Символ торговой пары
        category (str): Категория продукта
        buy_leverage (str): Кредитное плечо для покупки
        sell_leverage (str): Кредитное плечо для продажи

        Return:
        dict[str, Any]: Ответ API с результатом установки кредитного плеча
        """
        end_point = "/v5/position/set-leverage"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
            "category": category,
            "buyLeverage": buy_leverage,
            "sellLeverage": sell_leverage,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_position_trading_stop(
        self,
        category: str,
        symbol: str,
        tpsl_mode: str,
        position_idx: int,
        tp_order_type: str = "Market",
        sl_order_type: str = "Market",
        take_profit: str | None = None,
        stop_loss: str | None = None,
        trailing_stop: str | None = None,
        tp_trigger_by: str | None = None,
        sl_trigger_by: str | None = None,
        active_price: str | None = None,
        tp_size: str | None = None,
        sl_size: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
    ) -> dict[str, Any]:
        """
        Установка торговых стопов для позиции.

        Parameters:
        category (str): Категория продукта
        symbol (str): Символ торговой пары
        tpsl_mode (str): Режим TPSL
        position_idx (int): Индекс позиции
        tp_order_type (str): Тип ордера тейк-профита
        sl_order_type (str): Тип ордера стоп-лосса
        take_profit (str | None): Цена тейк-профита
        stop_loss (str | None): Цена стоп-лосса
        trailing_stop (str | None): Трейлинг стоп
        tp_trigger_by (str | None): Способ срабатывания тейк-профита
        sl_trigger_by (str | None): Способ срабатывания стоп-лосса
        active_price (str | None): Активная цена
        tp_size (str | None): Размер тейк-профита
        sl_size (str | None): Размер стоп-лосса
        tp_limit_price (str | None): Лимитная цена тейк-профита
        sl_limit_price (str | None): Лимитная цена стоп-лосса

        Return:
        dict[str, Any]: Ответ API с результатом установки торговых стопов
        """
        end_point = "/v5/position/trading-stop"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "tpslMode": tpsl_mode,
            "positionIdx": position_idx,
            "tpOrderType": tp_order_type,
            "slOrderType": sl_order_type,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "trailingStop": trailing_stop,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "activePrice": active_price,
            "tpSize": tp_size,
            "slSize": sl_size,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
