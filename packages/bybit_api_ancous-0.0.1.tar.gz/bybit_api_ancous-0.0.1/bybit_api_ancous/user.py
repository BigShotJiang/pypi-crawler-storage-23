"""
Модуль для работы с пользователем и суб-аккаунтами через Bybit API v5.

Предоставляет класс User для управления суб-участниками, суб-API ключами,
настройками API и типами участников.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class User:
    """
    Класс для работы с пользователем и суб-аккаунтами Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для создания и управления суб-участниками, суб-API ключами,
    заморозки, обновления и удаления API и суб-участников.
    """

    def post_user_create_sub_member(
        self,
        username: str,
        member_type: int,
        switch: int | None = 0,
        password: str | None = None,
        note: str | None = None,
        is_uta: bool | None = None,
    ) -> dict[str, Any]:
        """
        Создание sub-пользователя.

        Parameters:
        username (str): Имя пользователя
        member_type (int): Тип пользователя
        switch (int | None): Переключатель
        password (str | None): Пароль
        note (str | None): Заметка
        is_uta (bool | None): Флаг UTA

        Return:
        dict[str, Any]: Ответ API с результатом создания суб-участника
        """
        end_point = "/v5/user/create-sub-member"
        complete_request = self.base_url + end_point
        parameters = {
            "username": username,
            "memberType": member_type,
            "switch": switch,
            "password": password,
            "note": note,
            "isUta": is_uta,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_create_sub_api(
        self,
        subuid: int,
        wallet: list,
        read_only: int | None = 0,
        note: str | None = None,
        ips: str | None = None,
        contract_trade: str | None = None,
        spot: str | None = None,
        options: str | None = None,
        exchange: str | None = None,
        earn: str | None = None,
        derivatives: str | None = None,
        copy_trading: str | None = None,
    ) -> dict[str, Any]:
        """
        Создание API-ключа для sub-пользователя.

        Parameters:
        subuid (int): ID sub-пользователя
        read_only (int | None): Только чтение
        note (str | None): Заметка
        ips (str | None): Разрешённые IP
        contract_trade (str | None): Разрешение контрактной торговли
        spot (str | None): Разрешение спот
        options (str | None): Разрешение опционов
        wallet (str | None): Разрешение кошелька
        exchange (str | None): Разрешение обмена
        earn (str | None): Разрешение Earn
        derivatives (str | None): Разрешение деривативов
        copy_trading (str | None): Разрешение копирования

        Return:
        dict[str, Any]: Ответ API с результатом создания суб-API
        """
        end_point = "/v5/user/create-sub-api"
        complete_request = self.base_url + end_point
        parameters = {
            "subuid": subuid,
            "readOnly": read_only,
            "note": note,
            "ips": ips,
        }
        permissions = {
            "ContractTrade": contract_trade,
            "Spot": spot,
            "Options": options,
            "Wallet": wallet,
            "Exchange": exchange,
            "Earn": earn,
            "Derivatives": derivatives,
            "CopyTrading": copy_trading,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        permissions = {key: value for key, value in permissions.items() if value is not None}
        if permissions:
            parameters["permissions"] = permissions

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_user_sub_apikeys(
        self,
        sub_member_id: str,
        limit: int = 20,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка API-ключей sub-пользователя.

        Parameters:
        sub_member_id (str): ID sub-пользователя
        limit (int): Максимальное количество записей
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API со списком суб-API ключей
        """
        end_point = "/v5/user/sub-apikeys"
        complete_request = self.base_url + end_point
        parameters = {
            "subMemberId": sub_member_id,
            "limit": limit,
            "cursor": cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_user_query_api(self) -> dict[str, Any]:
        """
        Запрос информации об API-ключе.

        Return:
        dict[str, Any]: Ответ API с информацией об API ключе
        """
        end_point = "/v5/user/query-api"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_user_escrow_sub_members(
        self,
        page_size: str | None = None,
        next_cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка кастодиальных sub-пользователей.

        Parameters:
        page_size (str | None): Размер страницы
        next_cursor (str | None): Курсор для следующей страницы

        Return:
        dict[str, Any]: Ответ API со списком кастодиальных суб-участников
        """
        end_point = "/v5/user/escrow_sub_members"
        complete_request = self.base_url + end_point
        parameters = {
            "pageSize": page_size,
            "nextCursor": next_cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_user_submembers(
        self,
        page_size: str | None = None,
        next_cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка sub-пользователей.

        Parameters:
        page_size (str | None): Размер страницы
        next_cursor (str | None): Курсор для следующей страницы

        Return:
        dict[str, Any]: Ответ API со списком суб-участников
        """
        end_point = "/v5/user/submembers"
        complete_request = self.base_url + end_point
        parameters = {
            "pageSize": page_size,
            "nextCursor": next_cursor,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_user_query_sub_members(self) -> dict[str, Any]:
        """
        Запрос списка (не более 10000) sub-пользователей.

        Return:
        dict[str, Any]: Ответ API со списком суб-участников
        """
        end_point = "/v5/user/query-sub-members"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_user_get_member_type(
        self,
        member_ids: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение типа кошелка пользователя.

        Parameters:
        member_ids (str | None): ID участников через запятую

        Return:
        dict[str, Any]: Ответ API с типом участника
        """
        end_point = "/v5/user/get-member-type"
        complete_request = self.base_url + end_point
        parameters = {
            "memberIds": member_ids,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_frozen_sub_member(
        self,
        subuid: int,
        frozen: int,
    ) -> dict[str, Any]:
        """
        Заморозка или разморозка sub-пользователя.

        Parameters:
        subuid (int): ID суб-участника
        frozen (int): Флаг заморозки (1 — заморозить, 0 — разморозить)

        Return:
        dict[str, Any]: Ответ API с результатом
        """
        end_point = "/v5/user/frozen-sub-member"
        complete_request = self.base_url + end_point
        parameters = {
            "subuid": subuid,
            "frozen": frozen,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_update_api(
        self,
        wallet: list,
        read_only: int | None = 0,
        ips: str | None = None,
        contract_trade: list | None = None,
        spot: list | None = None,
        options: list | None = None,
        exchange: list | None = None,
        earn: list | None = None,
        fiat_p2p: list | None = None,
        fiat_bybit_pay: list | None = None,
        fiat_convert_broker: list | None = None,
        affiliate: list | None = None,
        derivatives: list | None = None,
        block_trade: list | None = None,
    ) -> dict[str, Any]:
        """
        Обновление настроек API ключа.

        Parameters:
        read_only (int | None): Только чтение
        ips (str | None): Разрешённые IP
        contract_trade (list | None): Разрешения контрактной торговли
        spot (list | None): Разрешения спот
        wallet (list | None): Разрешения кошелька
        options (list | None): Разрешения опционов
        exchange (list | None): Разрешения обмена
        earn (list | None): Разрешения Earn
        fiat_p2p (list | None): Разрешения P2P
        fiat_bybit_pay (list | None): Разрешения Bybit Pay
        fiat_convert_broker (list | None): Разрешения конвертации
        affiliate (list | None): Разрешения партнёрской программы
        derivatives (list | None): Разрешения деривативов
        block_trade (list | None): Разрешения блок-сделок

        Return:
        dict[str, Any]: Ответ API с результатом обновления
        """
        end_point = "/v5/user/update-api"
        complete_request = self.base_url + end_point
        parameters = {
            "readOnly": read_only,
            "ips": ips,
        }
        permissions = {
            "ContractTrade": contract_trade,
            "Spot": spot,
            "Wallet": wallet,
            "Options": options,
            "Exchange": exchange,
            "Earn": earn,
            "FiatP2P": fiat_p2p,
            "FiatBybitPay": fiat_bybit_pay,
            "FiatConvertBroker": fiat_convert_broker,
            "Affiliate": affiliate,
            "Derivatives": derivatives,
            "BlockTrade": block_trade,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        permissions = {key: value for key, value in permissions.items() if value is not None}
        if permissions:
            parameters["permissions"] = permissions

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_update_sub_api(
        self,
        wallet: list,
        read_only: int | None = 0,
        apikey: str | None = None,
        ips: str | None = None,
        contract_trade: list | None = None,
        spot: list | None = None,
        options: list | None = None,
        derivatives: list | None = None,
        exchange: list | None = None,
        earn: list | None = None,
    ) -> dict[str, Any]:
        """
        Обновление настроек API_ключа sub-пользователя.

        Parameters:
        read_only (int | None): Только чтение
        apikey (str | None): API ключ
        ips (str | None): Разрешённые IP
        contract_trade (list | None): Разрешения контрактной торговли
        spot (list | None): Разрешения спот
        wallet (list | None): Разрешения кошелька
        options (list | None): Разрешения опционов
        derivatives (list | None): Разрешения деривативов
        exchange (list | None): Разрешения обмена
        earn (list | None): Разрешения Earn

        Return:
        dict[str, Any]: Ответ API с результатом обновления
        """
        end_point = "/v5/user/update-sub-api"
        complete_request = self.base_url + end_point
        parameters = {
            "readOnly": read_only,
            "apikey": apikey,
            "ips": ips,
        }
        permissions = {
            "ContractTrade": contract_trade,
            "Spot": spot,
            "Wallet": wallet,
            "Options": options,
            "Derivatives": derivatives,
            "Exchange": exchange,
            "Earn": earn,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}
        permissions = {key: value for key, value in permissions.items() if value is not None}
        if permissions:
            parameters["permissions"] = permissions

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_delete_api(
        self,
        apikey: str | None = None,
    ) -> dict[str, Any]:
        """
        Удаление API-ключа.

        Parameters:
        apikey (str | None): API ключ для удаления

        Return:
        dict[str, Any]: Ответ API с результатом удаления
        """
        end_point = "/v5/user/delete-api"
        complete_request = self.base_url + end_point
        parameters = {
            "apikey": apikey,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_delete_sub_api(
        self,
        apikey: str | None = None,
    ) -> dict[str, Any]:
        """
        Удаление API-ключа sub-пользователя.

        Parameters:
        apikey (str | None): API ключ sub-пользователя для удаления

        Return:
        dict[str, Any]: Ответ API с результатом удаления
        """
        end_point = "/v5/user/delete-sub-api"
        complete_request = self.base_url + end_point
        parameters = {
            "apikey": apikey,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_user_delete_sub_member(
        self,
        sub_member_id: str,
    ) -> dict[str, Any]:
        """
        Удаление sub-пользователя.

        Parameters:
        sub_member_id (str): ID суб-участника для удаления

        Return:
        dict[str, Any]: Ответ API с результатом удаления
        """
        end_point = "/v5/user/del-submember"
        complete_request = self.base_url + end_point
        parameters = {
            "subMemberId": sub_member_id,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
