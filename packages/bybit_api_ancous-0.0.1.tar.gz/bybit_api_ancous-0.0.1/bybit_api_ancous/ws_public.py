"""
Модуль для работы с публичными WebSocket каналами Bybit API v5.

Этот модуль предоставляет класс WsPublic для подписки на публичные WebSocket каналы,
включая каналы свечей, стакана заявок, публичных сделок, тикеров и других публичных данных.
"""

import json
import time
from typing import Callable
from bybit_api_ancous.websocket_manager import WebSocketManager


class WsPublic(WebSocketManager):
    """
    Класс для работы с публичными WebSocket каналами Bybit API v5.

    Предоставляет методы для подписки на публичные каналы:
    - Свечи (kline)
    - Стакан заявок (orderbook, orderbook.rpi)
    - Публичные сделки (publicTrade)
    - Тикеры (tickers)
    - Лимиты цен (priceLimit)
    - Ликвидации (allLiquidation)
    - ADL алерты (adlAlert)
    - RFQ публичные сделки (rfq.open.public.trades)

    Не требует аутентификации для большинства каналов.
    """

    def __init__(self, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация клиента публичных WebSocket каналов.

        Parameters:
        api_key (str | None): API ключ для аутентификации (опционально)
        secret_key (str | None): секретный ключ для аутентификации (опционально)
        callback (dict): словарь callback функций для обработки сообщений
        args (list): список аргументов для подписки
        """
        super().__init__(api_key, secret_key)
        self.callback = {}
        self.args = []

    def _add_args_and_callback(
        self,
        prefix: str,
        symbol: str,
        callback: Callable | None,
        size_data: str | int | None = None,
    ) -> None:
        """
        Добавляет аргументы и callback в список и словарь.

        Формирует строку аргумента из префикса, size_data и символа, и добавляет её в список args.
        Если передан callback, добавляет его в словарь callback с ключом аргумента.

        Parameters:
        prefix (str): префикс аргумента
        symbol (str): символ торговой пары
        callback (Callable | None): функция обратного вызова для обработки сообщений
        size_data (str | int | None): данные размера (интервал, глубина и т.д.)
        """
        arg = f"{prefix}.{size_data}.{symbol}" if size_data else f"{prefix}.{symbol}"

        self.args.append(arg)
        if callback:
            self.callback[arg] = callback

    def ws_kline(
        self,
        op: str = "subscribe",
        interval: str | int | None = None,
        symbol: str | list[str] | None = None,
        interval_symbol: dict[int, str | list[str]] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал свечей.

        Parameters:
        op (str): операция (subscribe или unsubscribe)
        interval (str | int | None): интервал свечей
        symbol (str | list[str] | None): символ или список символов торговых пар
        interval_symbol (dict[int, str | list[str]] | None): словарь с интервалами как ключами и символами как начениями
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if interval_symbol is None and (interval is None or symbol is None):
            raise ValueError("Ошибка: необходимо передать interval и symbol или interval_symbol.")

        if interval_symbol is not None:
            for key, values in interval_symbol.items():
                if isinstance(values, str):
                    values = [values]
                for value in values:
                    self._add_args_and_callback(prefix="kline", symbol=value, callback=callback, size_data=key)
        else:
            symbols = symbol if isinstance(symbol, list) else [symbol]
            for s in symbols:
                self._add_args_and_callback(prefix="kline", symbol=s, callback=callback, size_data=interval)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_orderbook(
        self,
        op: str = "subscribe",
        depth: str | int | None = None,
        symbol: str | list[str] | None = None,
        depth_symbol: dict[int, str | list[str]] | None = None,
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал стакана заявок.

        Parameters:
        op (str): операция (subscribe или unsubscribe)
        depth (str | int | None): глубина стакана заявок
        symbol (str | list[str] | None): символ или список символов торговых пар
        depth_symbol (dict[int, str | list[str]] | None): словарь с глубинами как ключами и символами как значениями
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        if depth_symbol is None and (depth is None or symbol is None):
            raise ValueError("Ошибка: необходимо передать depth и symbol или depth_symbol.")

        if depth_symbol is not None:
            for key, values in depth_symbol.items():
                if isinstance(values, str):
                    values = [values]
                for value in values:
                    self._add_args_and_callback(prefix="orderbook", symbol=value, callback=callback, size_data=key)
        else:
            symbols = symbol if isinstance(symbol, list) else [symbol]
            for s in symbols:
                self._add_args_and_callback(prefix="orderbook", symbol=s, callback=callback, size_data=depth)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_orderbook_rpi(
        self,
        symbol: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал стакана заявок RPI (Real-time Price Index).

        Parameters:
        symbol (str | list[str]): символ или список символов торговых пар
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        symbols = symbol if isinstance(symbol, list) else [symbol]
        for s in symbols:
            self._add_args_and_callback(prefix="orderbook.rpi", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_public_trade(
        self,
        symbol: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал публичных сделок.

        Parameters:
        symbol (str | list[str]): символ или список символов торговых пар
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        symbols = symbol if isinstance(symbol, list) else [symbol]
        for s in symbols:
            self._add_args_and_callback(prefix="publicTrade", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_adl_alert(
        self,
        coin: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал ADL алертов (Auto-Deleveraging Alert).

        Parameters:
        coin (str | list[str]): монета или список монет
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        coins = coin if isinstance(coin, list) else [coin]
        for s in coins:
            self._add_args_and_callback(prefix="adlAlert", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_tickers(
        self,
        symbol: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал тикеров.

        Parameters:
        symbol (str | list[str]): символ или список символов торговых пар
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        symbols = symbol if isinstance(symbol, list) else [symbol]
        for s in symbols:
            self._add_args_and_callback(prefix="tickers", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_price_limit(
        self,
        symbol: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал лимитов цен.

        Parameters:
        symbol (str | list[str]): символ или список символов торговых пар
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        symbols = symbol if isinstance(symbol, list) else [symbol]
        for s in symbols:
            self._add_args_and_callback(prefix="priceLimit", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_all_liquidation(
        self,
        symbol: str | list[str],
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал всех ликвидаций.

        Parameters:
        symbol (str | list[str]): символ или список символов торговых пар
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        self.args.clear()

        symbols = symbol if isinstance(symbol, list) else [symbol]
        for s in symbols:
            self._add_args_and_callback(prefix="allLiquidation", symbol=s, callback=callback)

        request = {"op": op, "args": self.args, "req_id": str(self.args)}
        self.ws.send(json.dumps(request))

    def ws_rfq_open_public_trades(
        self,
        op: str = "subscribe",
        callback: Callable | None = None,
    ) -> None:
        """
        Подписка на канал публичных сделок RFQ.

        Parameters:
        op (str): операция (subscribe или unsubscribe)
        callback (Callable | None): функция обратного вызова для обработки сообщений
        """
        while not self.stop_event.is_set() and not self.open_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["rfq.open.public.trades"] = callback

        request = {"op": op, "args": ["rfq.open.public.trades"], "req_id": "['rfq.open.public.trades']"}
        self.ws.send(json.dumps(request))
