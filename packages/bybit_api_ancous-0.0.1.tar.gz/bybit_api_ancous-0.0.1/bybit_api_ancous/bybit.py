"""
Модуль базового класса для работы с Bybit API v5

Этот модуль предоставляет базовый класс Bybit для инициализации
API ключей и секретов, используемых в других модулях библиотеки.
"""


class Bybit:
    """
    Базовый класс для работы с Bybit API v5.

    Предоставляет базовую функциональность для инициализации
    API ключей и секретов, необходимых для аутентификации
    в API Bybit.

    Arguments:
    api_key (str | None): API ключ для аутентификации
    secret_key (str | None): Секретный ключ для аутентификации
    """

    def __init__(
        self, api_key: str | None = None, secret_key: str | None = None
    ) -> None:
        """
        Инициализация базового класса Bybit.

        Parameters:
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): Секретный ключ для аутентификации
        """
        self.api_key = api_key
        self.secret_key = secret_key
