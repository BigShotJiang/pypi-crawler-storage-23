"""
Модуль для шифрования и подписи запросов к Bybit API v5

Этот модуль предоставляет класс HMACSHA256 для создания HMAC-SHA256 подписей
запросов к API Bybit в соответствии с требованиями аутентификации.
"""

import hmac
import json
import hashlib
from typing import Any

from urllib.parse import urlencode


class HMACSHA256:
    """
    Класс для создания HMAC-SHA256 подписей запросов.

    Предоставляет статические методы для создания подписей GET и POST запросов
    к API Bybit с использованием HMAC-SHA256 алгоритма.
    """

    @staticmethod
    def compute_hex_by_get(
        api_key: str,
        secret_key: str,
        time_stamp: str,
        recv_window: str,
        data: dict[str, Any],
    ) -> str:
        """
        Создание HMAC-SHA256 подписи для GET запроса.

        Parameters:
        api_key (str): API ключ
        secret_key (str): Секретный ключ
        time_stamp (str): Временная метка
        recv_window (str): Окно получения
        data (dict[str, Any]): Параметры запроса

        Return:
        str: HMAC-SHA256 подпись в hex формате
        """

        param_str = time_stamp + api_key + recv_window + urlencode(data)

        signature = hmac.new(
            key=secret_key.encode("utf-8"),
            msg=param_str.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).hexdigest()

        return signature

    @staticmethod
    def compute_hex_by_post(
        api_key: str,
        secret_key: str,
        time_stamp: str,
        recv_window: str,
        data: dict[str, Any],
    ) -> str:
        """
        Создание HMAC-SHA256 подписи для POST запроса.

        Parameters:
        api_key (str): API ключ
        secret_key (str): Секретный ключ
        time_stamp (str): Временная метка
        recv_window (str): Окно получения
        data (dict[str, Any]): JSON данные запроса

        Return:
        str: HMAC-SHA256 подпись в hex формате
        """

        param_str = time_stamp + api_key + recv_window + json.dumps(data)

        signature = hmac.new(
            key=secret_key.encode("utf-8"),
            msg=param_str.encode("utf-8"),
            digestmod=hashlib.sha256,
        ).hexdigest()

        return signature

    @staticmethod
    def compute_hex_by_ws(secret_key: str, time_stamp: int) -> str:
        """
        Создание HMAC-SHA256 подписи для WebSocket аутентификации.

        Parameters:
        secret_key (str): Секретный ключ
        time_stamp (int): Временная метка в миллисекундах

        Return:
        str: HMAC-SHA256 подпись в hex формате
        """

        signature = str(
            hmac.new(
                key=secret_key.encode("utf-8"),
                msg=f"GET/realtime{time_stamp}".encode("utf-8"),
                digestmod="sha256",
            ).hexdigest()
        )

        return signature
