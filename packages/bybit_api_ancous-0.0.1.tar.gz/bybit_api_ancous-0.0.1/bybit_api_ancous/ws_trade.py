"""
Модуль для работы с торговыми операциями через WebSocket Bybit API v5.

Этот модуль предоставляет класс WsTrade для выполнения торговых операций через WebSocket,
включая создание, изменение и отмену ордеров, а также пакетные операции с ордерами.
"""

import json
import time
from typing import Callable
from bybit_api_ancous.websocket_manager import WebSocketManager


class WsTrade(WebSocketManager):
    """
    Класс для работы с торговыми операциями через WebSocket Bybit API v5.

    Предоставляет методы для:
    - Создания ордеров (ws_order_create, ws_order_create_batch)
    - Изменения ордеров (ws_order_amend, ws_order_amend_batch)
    - Отмены ордеров (ws_order_cancel, ws_order_cancel_batch)

    Требует аутентификации через API ключ и секрет.

    Arguments:
    callback (dict): словарь callback функций для обработки сообщений
    """

    def __init__(self, api_key: str | None = None, secret_key: str | None = None) -> None:
        """
        Инициализация клиента торговых операций через WebSocket.

        Parameters:
        api_key (str | None): API ключ для аутентификации
        secret_key (str | None): секретный ключ для аутентификации
        """
        super().__init__(api_key, secret_key)
        self.callback = {}

    def ws_order_create(
        self,
        category: str,
        symbol: str,
        side: str,
        order_type: str,
        qty: str,
        is_leverage: int = 0,
        recv_window: str = "5000",
        order_filter: str = "order",
        time_in_force: str = "GTC",
        tp_trigger_by: str = "LastPrice",
        sl_trigger_by: str = "LastPrice",
        callback: Callable | None = None,
        market_unit: str | None = None,
        slippage_tolerance_type: str | None = None,
        slippage_tolerance: str | None = None,
        price: str | None = None,
        trigger_direction: int | None = None,
        trigger_price: str | None = None,
        trigger_by: str | None = None,
        order_iv: str | None = None,
        position_idx: int | None = None,
        order_link_id: str | None = None,
        take_profit: str | None = None,
        stop_loss: str | None = None,
        reduce_only: bool | None = None,
        close_on_trigger: bool | None = None,
        smp_type: str | None = None,
        mmp: bool | None = None,
        tpsl_mode: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
        tp_order_type: str | None = None,
        sl_order_type: str | None = None,
    ) -> None:
        """
        Создание ордера через WebSocket.

        Parameters:
        category (str): категория продукта
        symbol (str): символ торговой пары
        side (str): направление сделки (Buy/Sell)
        order_type (str): тип ордера
        qty (str): количество
        is_leverage (int): флаг использования кредитного плеча
        recv_window (str): окно получения запроса
        order_filter (str): фильтр ордеров
        time_in_force (str): время исполнения
        tp_trigger_by (str): способ срабатывания тейк-профита
        sl_trigger_by (str): способ срабатывания стоп-лосса
        callback (Callable | None): функция обратного вызова для обработки ответа
        market_unit (str | None): единицы измерения для маркет ордеров
        slippage_tolerance_type (str | None): тип допуска проскальзывания
        slippage_tolerance (str | None): допуск проскальзывания
        price (str | None): цена для лимитных ордеров
        trigger_direction (int | None): направление срабатывания
        trigger_price (str | None): цена срабатывания
        trigger_by (str | None): способ срабатывания
        order_iv (str | None): волатильность ордера
        position_idx (int | None): индекс позиции
        order_link_id (str | None): пользовательский ID ордера
        take_profit (str | None): цена тейк-профита
        stop_loss (str | None): цена стоп-лосса
        reduce_only (bool | None): флаг reduce only
        close_on_trigger (bool | None): флаг закрытия при срабатывании
        smp_type (str | None): тип SMP
        mmp (bool | None): флаг MMP
        tpsl_mode (str | None): режим TPSL
        tp_limit_price (str | None): лимитная цена тейк-профита
        sl_limit_price (str | None): лимитная цена стоп-лосса
        tp_order_type (str | None): тип ордера тейк-профита
        sl_order_type (str | None): тип ордера стоп-лосса
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        parameters = {
            "category": category,
            "symbol": symbol,
            "isLeverage": is_leverage,
            "side": side,
            "orderType": order_type,
            "qty": qty,
            "marketUnit": market_unit,
            "slippageToleranceType": slippage_tolerance_type,
            "slippageTolerance": slippage_tolerance,
            "price": price,
            "triggerDirection": trigger_direction,
            "orderFilter": order_filter,
            "triggerPrice": trigger_price,
            "triggerBy": trigger_by,
            "orderIv": order_iv,
            "timeInForce": time_in_force,
            "positionIdx": position_idx,
            "orderLinkId": order_link_id,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "reduceOnly": reduce_only,
            "closeOnTrigger": close_on_trigger,
            "smpType": smp_type,
            "mmp": mmp,
            "tpslMode": tpsl_mode,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
            "tpOrderType": tp_order_type,
            "slOrderType": sl_order_type,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        time_stamp = str(int(time.time() * 1000))
        request_create_order = {
            "op": "order.create",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [parameters],
        }
        self.ws.send(json.dumps(request_create_order))

    def ws_order_amend(
        self,
        category: str,
        symbol: str,
        recv_window: str = "5000",
        callback: Callable | None = None,
        order_id: str | None = None,
        order_link_id: str | None = None,
        order_iv: str | None = None,
        trigger_price: str | None = None,
        qty: str | None = None,
        price: str | None = None,
        tpsl_mode: str | None = None,
        take_profit: str | None = None,
        stop_loss: str | None = None,
        tp_trigger_by: str | None = None,
        sl_trigger_by: str | None = None,
        trigger_by: str | None = None,
        tp_limit_price: str | None = None,
        sl_limit_price: str | None = None,
    ) -> None:
        """
        Изменение ордера через WebSocket.

        Parameters:
        category (str): категория продукта
        symbol (str): символ торговой пары
        recv_window (str): окно получения запроса
        callback (Callable | None): функция обратного вызова для обработки ответа
        order_id (str | None): ID ордера
        order_link_id (str | None): пользовательский ID ордера
        order_iv (str | None): волатильность ордера
        trigger_price (str | None): цена срабатывания
        qty (str | None): количество
        price (str | None): цена
        tpsl_mode (str | None): режим TPSL
        take_profit (str | None): цена тейк-профита
        stop_loss (str | None): цена стоп-лосса
        tp_trigger_by (str | None): способ срабатывания тейк-профита
        sl_trigger_by (str | None): способ срабатывания стоп-лосса
        trigger_by (str | None): способ срабатывания
        tp_limit_price (str | None): лимитная цена тейк-профита
        sl_limit_price (str | None): лимитная цена стоп-лосса
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        parameters = {
            "category": category,
            "symbol": symbol,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "orderIv": order_iv,
            "triggerPrice": trigger_price,
            "qty": qty,
            "price": price,
            "tpslMode": tpsl_mode,
            "takeProfit": take_profit,
            "stopLoss": stop_loss,
            "tpTriggerBy": tp_trigger_by,
            "slTriggerBy": sl_trigger_by,
            "triggerBy": trigger_by,
            "tpLimitPrice": tp_limit_price,
            "slLimitPrice": sl_limit_price,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        time_stamp = str(int(time.time() * 1000))
        request_amend_order = {
            "op": "order.amend",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [parameters],
        }
        self.ws.send(json.dumps(request_amend_order))

    def ws_order_cancel(
        self,
        category: str,
        symbol: str,
        recv_window: str = "5000",
        order_filter: str = "order",
        callback: Callable | None = None,
        order_id: str | None = None,
        order_link_id: str | None = None,
    ) -> None:
        """
        Отмена ордера через WebSocket.

        Parameters:
        category (str): категория продукта
        symbol (str): символ торговой пары
        recv_window (str): окно получения запроса
        order_filter (str): фильтр ордеров
        callback (Callable | None): функция обратного вызова для обработки ответа
        order_id (str | None): ID ордера
        order_link_id (str | None): пользовательский ID ордера
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        parameters = {
            "category": category,
            "symbol": symbol,
            "orderId": order_id,
            "orderLinkId": order_link_id,
            "orderFilter": order_filter,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}

        time_stamp = str(int(time.time() * 1000))
        request_cancel_order = {
            "op": "order.cancel",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [parameters],
        }
        self.ws.send(json.dumps(request_cancel_order))

    def ws_order_create_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
        recv_window: str = "5000",
        callback: Callable | None = None,
    ) -> None:
        """
        Создание нескольких ордеров пакетно через WebSocket.

        Parameters:
        category (str): категория продукта
        request (list[dict[str, str | int | bool]]): список словарей с параметрами ордеров.
            Каждый словарь должен содержать:
            - symbol (str): символ торговой пары
            - side (str): направление сделки
            - orderType (str): тип ордера
            - qty (str): количество
            - isLeverage (int): флаг использования кредитного плеча
            - marketUnit (str): единицы измерения
            - price (str): цена
            - triggerDirection (int): направление срабатывания
            - orderFilter (str): фильтр ордеров
            - triggerPrice (str): цена срабатывания
            - triggerBy (str): способ срабатывания
            - orderIv (str): волатильность ордера
            - timeInForce (str): время исполнения
            - positionIdx (int): индекс позиции
            - orderLinkId (str): ID ордера
            - takeProfit (str): лимит прибыли
            - stopLoss (str): лимит убытка
            - tpTriggerBy (str): способ срабатывания прибыли
            - slTriggerBy (str): способ срабатывания убытка
            - reduceOnly (bool): флаг reduce only
            - closeOnTrigger (bool): флаг закрытия позиции при срабатывании
            - smpType (str): тип SMP
            - mmp (bool): флаг MMP
            - tpslMode (str): тип TPSL
            - tpLimitPrice (str): лимит цены прибыли
            - slLimitPrice (str): лимит цены убытка
            - tpOrderType (str): тип ордера прибыли
            - slOrderType (str): тип ордера убытка
        recv_window (str): окно получения запроса
        callback (Callable | None): функция обратного вызова для обработки ответа
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        time_stamp = str(int(time.time() * 1000))
        request_create_order_batch = {
            "op": "order.create-batch",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [{"category": category, "request": request}],
        }
        self.ws.send(json.dumps(request_create_order_batch))

    def ws_order_amend_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
        recv_window: str = "5000",
        callback: Callable | None = None,
    ) -> None:
        """
        Изменение нескольких ордеров пакетно через WebSocket.

        Parameters:
        category (str): категория продукта
        request (list[dict[str, str | int | bool]]): список словарей с параметрами ордеров.
            Каждый словарь должен содержать:
            - symbol (str): символ торговой пары
            - orderId (str): ID ордера
            - orderLinkId (str): ID ордера пользователя
            - orderIv (str): волатильность ордера
            - triggerPrice (str): цена срабатывания
            - qty (str): количество
            - price (str): цена
            - tpslMode (str): тип TPSL
            - takeProfit (str): лимит прибыли
            - stopLoss (str): лимит убытка
            - tpTriggerBy (str): способ срабатывания прибыли
            - slTriggerBy (str): способ срабатывания убытка
            - triggerBy (str): способ срабатывания
            - tpLimitPrice (str): лимит цены прибыли
            - slLimitPrice (str): лимит цены убытка
        recv_window (str): окно получения запроса
        callback (Callable | None): функция обратного вызова для обработки ответа
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        time_stamp = str(int(time.time() * 1000))
        request_amend_order_batch = {
            "op": "order.amend-batch",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [{"category": category, "request": request}],
        }
        self.ws.send(json.dumps(request_amend_order_batch))

    def ws_order_cancel_batch(
        self,
        category: str,
        request: list[dict[str, str | int | bool]],
        recv_window: str = "5000",
        callback: Callable | None = None,
    ) -> None:
        """
        Отмена нескольких ордеров пакетно через WebSocket.

        Parameters:
        category (str): категория продукта
        request (list[dict[str, str | int | bool]]): список словарей с параметрами ордеров.
            Каждый словарь должен содержать:
            - symbol (str): символ торговой пары
            - orderId (str): ID ордера (если не указан orderLinkId)
            - orderLinkId (str): ID ордера пользователя (если не указан orderId)
        recv_window (str): окно получения запроса
        callback (Callable | None): функция обратного вызова для обработки ответа
        """

        while not self.stop_event.is_set() and not self.auth_event.is_set():
            time.sleep(1)

        if self.stop_event.is_set():
            raise TimeoutError("Соединение с websocket закрыто. Аутентификация не удалась.")

        if callback:
            self.callback["trade"] = callback

        time_stamp = str(int(time.time() * 1000))
        request_cancel_order_batch = {
            "op": "order.cancel-batch",
            "header": {"X-BAPI-TIMESTAMP": time_stamp, "X-BAPI-RECV-WINDOW": recv_window},
            "args": [{"category": category, "request": request}],
        }
        self.ws.send(json.dumps(request_cancel_order_batch))
