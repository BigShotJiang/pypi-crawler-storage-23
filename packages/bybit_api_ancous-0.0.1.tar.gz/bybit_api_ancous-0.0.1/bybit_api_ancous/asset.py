"""
Модуль для работы с активами через Bybit API v5.

Предоставляет класс Asset для управления активами: информация о монетах,
вывод и пополнение, переводы, обмен, фиат, конвертация мелких остатков.
"""

from typing import Any

from bybit_api_ancous.api_manager import ApiManager


class Asset:
    """
    Класс для работы с активами Bybit API v5.

    Используется как миксин вместе с Bybit (или наследниками). Атрибуты base_url,
    api_key, secret_key задаются классом, с которым смешивается (например ApiBybitMain).

    Предоставляет методы для запросов информации о монетах, вывода и пополнения,
    переводов между счетами, обмена, фиатных операций и конвертации мелких остатков.
    """

    def get_asset_coin_query_info(
        self,
        coin: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение информации о монетах.

        Parameters:
        coin (str | None): Монета для фильтрации

        Return:
        dict[str, Any]: Ответ API с информацией о монетах
        """
        end_point = "/v5/asset/coin/query-info"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_delivery_record(
        self,
        category: str,
        limit: int = 20,
        symbol: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        exp_date: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей о поставках (delivery).

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        exp_date (str | None): Дата экспирации
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями о поставках
        """
        end_point = "/v5/asset/delivery-record"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "startTime": start_time,
            "endTime": end_time,
            "expDate": exp_date,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_settlement_record(
        self,
        category: str,
        limit: int = 20,
        symbol: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей о расчётах (settlement).

        Parameters:
        category (str): Категория продукта
        limit (int): Максимальное количество записей
        symbol (str | None): Символ
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями о расчётах
        """
        end_point = "/v5/asset/settlement-record"
        complete_request = self.base_url + end_point
        parameters = {
            "category": category,
            "symbol": symbol,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_withdraw_create(
        self,
        account_type: str,
        coin: str,
        amount: str,
        chain: str,
        address: str,
        timestamp: int,
        force_chain: int = 0,
        fee_type: int = 0,
        beneficiary_legal_type: str = "individual",
        beneficiary_wallet_type: str = "0",
        tag: str | None = None,
        request_id: str | None = None,
        vasp_entity_id: str | None = None,
        beneficiary_transaction_purpose: str | None = None,
        beneficiary_representative_first_name: str | None = None,
        beneficiary_representative_last_name: str | None = None,
        beneficiary_name: str | None = None,
        beneficiary_unhosted_wallet_type: str | None = None,
        beneficiary_poi_number: str | None = None,
        beneficiary_poi_type: str | None = None,
        beneficiary_poi_issuing_country: str | None = None,
        beneficiary_poi_expired_date: str | None = None,
        beneficiary_address_country: str | None = None,
        beneficiary_address_state: str | None = None,
        beneficiary_address_city: str | None = None,
        beneficiary_address_building: str | None = None,
        beneficiary_address_street: str | None = None,
        beneficiary_address_postal_code: str | None = None,
        beneficiary_date_of_birth: str | None = None,
        beneficiary_place_of_birth: str | None = None,
    ) -> dict[str, Any]:
        """
        Создание заявки на вывод средств.

        Parameters:
        account_type (str): Тип аккаунта
        coin (str): Монета
        amount (str): Сумма
        chain (str): Сеть (chain)
        address (str): Адрес вывода
        timestamp (int): Временная метка
        force_chain (int): Принудительный выбор сети
        fee_type (int): Тип комиссии
        beneficiary_legal_type (str): Юридический тип бенефициара
        beneficiary_wallet_type (str): Тип кошелька бенефициара
        tag (str | None): Тег (для XRP и др.)
        request_id (str | None): Идентификатор запроса
        vasp_entity_id (str | None): VASP entity ID
        beneficiary_transaction_purpose (str | None): Цель транзакции бенефициара
        beneficiary_representative_first_name (str | None): Имя представителя
        beneficiary_representative_last_name (str | None): Фамилия представителя
        beneficiary_name (str | None): Имя бенефициара
        beneficiary_unhosted_wallet_type (str | None): Тип некастодиального кошелька
        beneficiary_poi_number (str | None): Номер документа бенефициара
        beneficiary_poi_type (str | None): Тип документа
        beneficiary_poi_issuing_country (str | None): Страна выдачи документа
        beneficiary_poi_expired_date (str | None): Дата истечения документа
        beneficiary_address_country (str | None): Страна адреса
        beneficiary_address_state (str | None): Регион адреса
        beneficiary_address_city (str | None): Город
        beneficiary_address_building (str | None): Здание
        beneficiary_address_street (str | None): Улица
        beneficiary_address_postal_code (str | None): Индекс
        beneficiary_date_of_birth (str | None): Дата рождения
        beneficiary_place_of_birth (str | None): Место рождения

        Return:
        dict[str, Any]: Ответ API с результатом создания заявки
        """
        end_point = "/v5/asset/withdraw/create"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "chain": chain,
            "address": address,
            "tag": tag,
            "amount": amount,
            "timestamp": timestamp,
            "forceChain": force_chain,
            "accountType": account_type,
            "feeType": fee_type,
            "requestId": request_id,
        }
        beneficiary = {
            "beneficiaryTransactionPurpose": beneficiary_transaction_purpose,
            "beneficiaryRepresentativeFirstName": beneficiary_representative_first_name,
            "beneficiaryRepresentativeLastName": beneficiary_representative_last_name,
            "beneficiaryName": beneficiary_name,
            "beneficiaryUnhostedWalletType": beneficiary_unhosted_wallet_type,
            "beneficiaryPoiNumber": beneficiary_poi_number,
            "beneficiaryPoiType": beneficiary_poi_type,
            "beneficiaryPoiIssuingCountry": beneficiary_poi_issuing_country,
            "beneficiaryPoiExpiredDate": beneficiary_poi_expired_date,
            "beneficiaryAddressCountry": beneficiary_address_country,
            "beneficiaryAddressState": beneficiary_address_state,
            "beneficiaryAddressCity": beneficiary_address_city,
            "beneficiaryAddressBuilding": beneficiary_address_building,
            "beneficiaryAddressStreet": beneficiary_address_street,
            "beneficiaryAddressPostalCode": beneficiary_address_postal_code,
            "beneficiaryDateOfBirth": beneficiary_date_of_birth,
            "beneficiaryPlaceOfBirth": beneficiary_place_of_birth,
        }

        parameters = {key: value for key, value in parameters.items() if value is not None}
        beneficiary = {key: value for key, value in beneficiary.items() if value is not None}
        if vasp_entity_id:
            beneficiary["vaspEntityId"] = {"vaspEntityId": vasp_entity_id}
        if beneficiary:
            beneficiary["beneficiaryLegalType"] = beneficiary_legal_type
            beneficiary["beneficiaryWalletType"] = beneficiary_wallet_type
            parameters["beneficiary"] = beneficiary

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_withdraw_cancel(
        self,
        id_args: str,
    ) -> dict[str, Any]:
        """
        Отмена заявки на вывод средств.

        Parameters:
        id_args (str): Идентификатор заявки на вывод

        Return:
        dict[str, Any]: Ответ API с результатом отмены
        """
        end_point = "/v5/asset/withdraw/cancel"
        complete_request = self.base_url + end_point
        parameters = {
            "id": id_args,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_withdraw_query_record(
        self,
        withdraw_id: str | None = None,
        tx_id: str | None = None,
        coin: str | None = None,
        withdraw_type: int | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей о выводе средств.

        Parameters:
        withdraw_id (str | None): Идентификатор вывода
        tx_id (str | None): Идентификатор транзакции
        coin (str | None): Монета
        withdraw_type (int | None): Тип вывода
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        limit (int | None): Максимальное количество записей
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями о выводе
        """
        end_point = "/v5/asset/withdraw/query-record"
        complete_request = self.base_url + end_point
        parameters = {
            "withdrawID": withdraw_id,
            "txID": tx_id,
            "coin": coin,
            "withdrawType": withdraw_type,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_withdraw_query_address(
        self,
        coin: str | None = None,
        chain: str | None = None,
        address_type: int | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение адресов для вывода.

        Parameters:
        coin (str | None): Монета
        chain (str | None): Сеть
        address_type (int | None): Тип адреса
        limit (int | None): Максимальное количество записей
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с адресами для вывода
        """
        end_point = "/v5/asset/withdraw/query-address"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "chain": chain,
            "addressType": address_type,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_withdraw_vasp_list(self) -> dict[str, Any]:
        """
        Получение списка VASP для вывода.

        Return:
        dict[str, Any]: Ответ API со списком VASP
        """
        end_point = "/v5/asset/withdraw/vasp/list"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_asset_withdraw_withdrawable_amount(
        self,
        coin: str,
    ) -> dict[str, Any]:
        """
        Получение доступной для вывода суммы по монете.

        Parameters:
        coin (str): Монета

        Return:
        dict[str, Any]: Ответ API с доступной суммой
        """
        end_point = "/v5/asset/withdraw/withdrawable-amount"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_transfer_query_transfer_coin_list(
        self,
        from_account_type: str,
        to_account_type: str,
    ) -> dict[str, Any]:
        """
        Получение списка монет для перевода между типами счетов.

        Parameters:
        from_account_type (str): Тип счёта источника
        to_account_type (str): Тип счёта назначения

        Return:
        dict[str, Any]: Ответ API со списком монет для перевода
        """
        end_point = "/v5/asset/transfer/query-transfer-coin-list"
        complete_request = self.base_url + end_point
        parameters = {
            "fromAccountType": from_account_type,
            "toAccountType": to_account_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_transfer_universal_transfer(
        self,
        transfer_id: str,
        coin: str,
        amount: str,
        from_member_id: int,
        to_member_id: int,
        from_account_type: str,
        to_account_type: str,
    ) -> dict[str, Any]:
        """
        Универсальный перевод между участниками.

        Parameters:
        transfer_id (str): Идентификатор перевода
        coin (str): Монета
        amount (str): Сумма
        from_member_id (int): ID участника-источника
        to_member_id (int): ID участника-получателя
        from_account_type (str): Тип счёта источника
        to_account_type (str): Тип счёта назначения

        Return:
        dict[str, Any]: Ответ API с результатом перевода
        """
        end_point = "/v5/asset/transfer/universal-transfer"
        complete_request = self.base_url + end_point
        parameters = {
            "transferId": transfer_id,
            "coin": coin,
            "amount": amount,
            "fromMemberId": from_member_id,
            "toMemberId": to_member_id,
            "fromAccountType": from_account_type,
            "toAccountType": to_account_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_transfer_query_universal_transfer_list(
        self,
        limit: int = 20,
        transfer_id: str | None = None,
        coin: str | None = None,
        status: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка универсальных переводов.

        Parameters:
        limit (int): Максимальное количество записей
        transfer_id (str | None): Идентификатор перевода
        coin (str | None): Монета
        status (str | None): Статус
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API со списком переводов
        """
        end_point = "/v5/asset/transfer/query-universal-transfer-list"
        complete_request = self.base_url + end_point
        parameters = {
            "transferId": transfer_id,
            "coin": coin,
            "status": status,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_transfer_inter_transfer(
        self,
        transfer_id: str,
        coin: str,
        amount: str,
        from_account_type: str,
        to_account_type: str,
    ) -> dict[str, Any]:
        """
        Внутренний перевод между счетами одного участника.

        Parameters:
        transfer_id (str): Идентификатор перевода
        coin (str): Монета
        amount (str): Сумма
        from_account_type (str): Тип счёта источника
        to_account_type (str): Тип счёта назначения

        Return:
        dict[str, Any]: Ответ API с результатом перевода
        """
        end_point = "/v5/asset/transfer/inter-transfer"
        complete_request = self.base_url + end_point
        parameters = {
            "transferId": transfer_id,
            "coin": coin,
            "amount": amount,
            "fromAccountType": from_account_type,
            "toAccountType": to_account_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_transfer_query_inter_transfer_list(
        self,
        limit: int = 20,
        transfer_id: str | None = None,
        coin: str | None = None,
        status: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка внутренних переводов.

        Parameters:
        limit (int): Максимальное количество записей
        transfer_id (str | None): Идентификатор перевода
        coin (str | None): Монета
        status (str | None): Статус
        start_time (str | None): Время начала
        end_time (str | None): Время окончания
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API со списком внутренних переводов
        """
        end_point = "/v5/asset/transfer/query-inter-transfer-list"
        complete_request = self.base_url + end_point
        parameters = {
            "transferId": transfer_id,
            "coin": coin,
            "status": status,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_transfer_query_sub_member_list(self) -> dict[str, Any]:
        """
        Получение списка суб-участников для перевода.

        Return:
        dict[str, Any]: Ответ API со списком суб-участников
        """
        end_point = "/v5/asset/transfer/query-sub-member-list"
        complete_request = self.base_url + end_point

        return ApiManager().get(url=complete_request, api_key=self.api_key, secret_key=self.secret_key)

    def get_asset_transfer_query_account_coin_balance(
        self,
        account_type: str,
        coin: str,
        with_bonus: int = 0,
        with_transfer_safe_amount: int = 0,
        with_ltv_transfer_safe_amount: int = 0,
        member_id: str | None = None,
        to_member_id: str | None = None,
        to_account_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение баланса монеты на счёте.

        Parameters:
        account_type (str): Тип аккаунта
        coin (str): Монета
        with_bonus (int): Включать бонус
        with_transfer_safe_amount (int): Включать безопасную сумму для перевода
        with_ltv_transfer_safe_amount (int): Включать LTV безопасную сумму
        member_id (str | None): ID участника
        to_member_id (str | None): ID участника-получателя
        to_account_type (str | None): Тип счёта назначения

        Return:
        dict[str, Any]: Ответ API с балансом монеты
        """
        end_point = "/v5/asset/transfer/query-account-coin-balance"
        complete_request = self.base_url + end_point
        parameters = {
            "memberId": member_id,
            "toMemberId": to_member_id,
            "accountType": account_type,
            "toAccountType": to_account_type,
            "coin": coin,
            "withBonus": with_bonus,
            "withTransferSafeAmount": with_transfer_safe_amount,
            "withLtvTransferSafeAmount": with_ltv_transfer_safe_amount,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_transfer_query_account_coins_balance(
        self,
        account_type: str,
        with_bonus: int = 0,
        member_id: str | None = None,
        coin: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение балансов монет на счёте.

        Parameters:
        account_type (str): Тип аккаунта
        with_bonus (int): Включать бонус
        member_id (str | None): ID участника
        coin (str | None): Монета для фильтрации

        Return:
        dict[str, Any]: Ответ API с балансами монет
        """
        end_point = "/v5/asset/transfer/query-account-coins-balance"
        complete_request = self.base_url + end_point
        parameters = {
            "memberId": member_id,
            "accountType": account_type,
            "coin": coin,
            "withBonus": with_bonus,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_exchange_query_coin_list(
        self,
        account_type: str,
        coin: str | None = None,
        side: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка монет для обмена.

        Parameters:
        account_type (str): Тип аккаунта
        coin (str | None): Монета для фильтрации
        side (int | None): Сторона (покупка/продажа)

        Return:
        dict[str, Any]: Ответ API со списком монет для обмена
        """
        end_point = "/v5/asset/exchange/query-coin-list"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "coin": coin,
            "side": side,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_exchange_quote_apply(
        self,
        account_type: str,
        from_coin: str,
        to_coin: str,
        request_coin: str,
        request_amount: str,
        from_coin_type: str | None = None,
        to_coin_type: str | None = None,
        param_type: str | None = None,
        param_value: str | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Запрос котировки для обмена.

        Parameters:
        account_type (str): Тип аккаунта
        from_coin (str): Исходная монета
        to_coin (str): Целевая монета
        request_coin (str): Монета запроса (from или to)
        request_amount (str): Сумма запроса
        from_coin_type (str | None): Тип исходной монеты
        to_coin_type (str | None): Тип целевой монеты
        param_type (str | None): Тип параметра
        param_value (str | None): Значение параметра
        request_id (str | None): Идентификатор запроса

        Return:
        dict[str, Any]: Ответ API с котировкой обмена
        """
        end_point = "/v5/asset/exchange/quote-apply"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "fromCoin": from_coin,
            "toCoin": to_coin,
            "requestCoin": request_coin,
            "requestAmount": request_amount,
            "fromCoinType": from_coin_type,
            "toCoinType": to_coin_type,
            "paramType": param_type,
            "paramValue": param_value,
            "requestId": request_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_exchange_convert_execute(
        self,
        quote_tx_id: str,
    ) -> dict[str, Any]:
        """
        Выполнение обмена по котировке.

        Parameters:
        quote_tx_id (str): Идентификатор котировки

        Return:
        dict[str, Any]: Ответ API с результатом обмена
        """
        end_point = "/v5/asset/exchange/convert-execute"
        complete_request = self.base_url + end_point
        parameters = {
            "quoteTxId": quote_tx_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_exchange_convert_result_query(
        self,
        quote_tx_id: str,
        account_type: str,
    ) -> dict[str, Any]:
        """
        Запрос результата конвертации по котировке.

        Parameters:
        quote_tx_id (str): Идентификатор котировки
        account_type (str): Тип аккаунта

        Return:
        dict[str, Any]: Ответ API с результатом конвертации
        """
        end_point = "/v5/asset/exchange/convert-result-query"
        complete_request = self.base_url + end_point
        parameters = {
            "quoteTxId": quote_tx_id,
            "accountType": account_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_exchange_query_convert_history(
        self,
        index: int = 1,
        limit: int = 20,
        account_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории конвертаций.

        Parameters:
        index (int): Начальный индекс
        limit (int): Максимальное количество записей
        account_type (str | None): Тип аккаунта

        Return:
        dict[str, Any]: Ответ API с историей конвертаций
        """
        end_point = "/v5/asset/exchange/query-convert-history"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "index": index,
            "limit": limit,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_exchange_order_record(
        self,
        limit: int = 10,
        from_coin: str | None = None,
        to_coin: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей ордеров обмена.

        Parameters:
        limit (int): Максимальное количество записей
        from_coin (str | None): Исходная монета
        to_coin (str | None): Целевая монета
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями ордеров обмена
        """
        end_point = "/v5/asset/exchange/order-record"
        complete_request = self.base_url + end_point
        parameters = {
            "fromCoin": from_coin,
            "toCoin": to_coin,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_fiat_query_coin_list(
        self,
        side: int | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка фиатных монет.

        Parameters:
        side (int | None): Сторона (покупка/продажа)

        Return:
        dict[str, Any]: Ответ API со списком фиатных монет
        """
        end_point = "/v5/fiat/query-coin-list"
        complete_request = self.base_url + end_point
        parameters = {
            "side": side,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_fiat_quote_apply(
        self,
        from_coin: str,
        from_coin_type: str,
        to_coin: str,
        to_coin_type: str,
        request_amount: str,
        request_coin_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Запрос котировки фиатной операции.

        Parameters:
        from_coin (str): Исходная монета
        from_coin_type (str): Тип исходной монеты
        to_coin (str): Целевая монета
        to_coin_type (str): Тип целевой монеты
        request_amount (str): Сумма запроса
        request_coin_type (str | None): Тип монеты запроса

        Return:
        dict[str, Any]: Ответ API с котировкой фиатной операции
        """
        end_point = "/v5/fiat/quote-apply"
        complete_request = self.base_url + end_point
        parameters = {
            "fromCoin": from_coin,
            "fromCoinType": from_coin_type,
            "toCoin": to_coin,
            "toCoinType": to_coin_type,
            "requestAmount": request_amount,
            "requestCoinType": request_coin_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_fiat_trade_execute(
        self,
        quote_tx_id: str,
        sub_user_id: str,
        webhook_url: str | None = None,
        merchant_request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Выполнение фиатной сделки по котировке.

        Parameters:
        quote_tx_id (str): Идентификатор котировки
        sub_user_id (str): ID суб-пользователя
        webhook_url (str | None): URL вебхука
        merchant_request_id (str | None): Идентификатор запроса мерчанта

        Return:
        dict[str, Any]: Ответ API с результатом сделки
        """
        end_point = "/v5/fiat/trade-execute"
        complete_request = self.base_url + end_point
        parameters = {
            "quoteTxId": quote_tx_id,
            "subUserId": sub_user_id,
            "webhookUrl": webhook_url,
            "MerchantRequestId": merchant_request_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_fiat_trade_query(
        self,
        trade_no: str | None = None,
        merchant_request_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Запрос статуса фиатной сделки.

        Parameters:
        trade_no (str | None): Номер сделки
        merchant_request_id (str | None): Идентификатор запроса мерчанта

        Return:
        dict[str, Any]: Ответ API со статусом сделки
        """
        end_point = "/v5/fiat/trade-query"
        complete_request = self.base_url + end_point
        parameters = {
            "tradeNo": trade_no,
            "merchantRequestId": merchant_request_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_fiat_query_trade_history(
        self,
        index: int = 1,
        limit: int = 20,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории фиатных сделок.

        Parameters:
        index (int): Начальный индекс
        limit (int): Максимальное количество записей
        start_time (str | None): Время начала
        end_time (str | None): Время окончания

        Return:
        dict[str, Any]: Ответ API с историей фиатных сделок
        """
        end_point = "/v5/fiat/query-trade-history"
        complete_request = self.base_url + end_point
        parameters = {
            "index": index,
            "limit": limit,
            "startTime": start_time,
            "endTime": end_time,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_fiat_reference_price(
        self,
        symbol: str,
    ) -> dict[str, Any]:
        """
        Получение справочной цены фиата.

        Parameters:
        symbol (str): Символ (например BTCUSDT)

        Return:
        dict[str, Any]: Ответ API со справочной ценой
        """
        end_point = "/v5/fiat/reference-price"
        complete_request = self.base_url + end_point
        parameters = {
            "symbol": symbol,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_fiat_balance_query(
        self,
        currency: str | None = None,
    ) -> dict[str, Any]:
        """
        Запрос фиатного баланса.

        Parameters:
        currency (str | None): Валюта

        Return:
        dict[str, Any]: Ответ API с фиатным балансом
        """
        end_point = "/v5/fiat/balance-query"
        complete_request = self.base_url + end_point
        parameters = {
            "currency": currency,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_deposit_deposit_to_account(
        self,
        account_type: str = "FUND",
    ) -> dict[str, Any]:
        """
        Пополнение счёта (deposit to account).

        Parameters:
        account_type (str): Тип аккаунта

        Return:
        dict[str, Any]: Ответ API с результатом
        """
        end_point = "/v5/asset/deposit/deposit-to-account"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_deposit_query_address(
        self,
        coin: str,
        chain_type: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение адреса для пополнения.

        Parameters:
        coin (str): Монета
        chain_type (str | None): Тип сети

        Return:
        dict[str, Any]: Ответ API с адресом для пополнения
        """
        end_point = "/v5/asset/deposit/query-address"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "chainType": chain_type,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_deposit_query_sub_member_address(
        self,
        coin: str,
        chain_type: str,
        sub_member_id: str,
    ) -> dict[str, Any]:
        """
        Получение адреса пополнения суб-участника.

        Parameters:
        coin (str): Монета
        chain_type (str): Тип сети
        sub_member_id (str): ID суб-участника

        Return:
        dict[str, Any]: Ответ API с адресом пополнения
        """
        end_point = "/v5/asset/deposit/query-sub-member-address"
        complete_request = self.base_url + end_point
        parameters = {
            "coin": coin,
            "chainType": chain_type,
            "subMemberId": sub_member_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_deposit_query_internal_record(
        self,
        limit: int = 50,
        tx_id: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        coin: str | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей внутреннего пополнения.

        Parameters:
        limit (int): Максимальное количество записей
        tx_id (str | None): Идентификатор транзакции
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        coin (str | None): Монета
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями внутреннего пополнения
        """
        end_point = "/v5/asset/deposit/query-internal-record"
        complete_request = self.base_url + end_point
        parameters = {
            "txID": tx_id,
            "startTime": start_time,
            "endTime": end_time,
            "coin": coin,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_deposit_query_record(
        self,
        limit: int = 50,
        id_args: str | None = None,
        tx_id: str | None = None,
        coin: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей о пополнении.

        Parameters:
        limit (int): Максимальное количество записей
        id_args (str | None): Идентификатор
        tx_id (str | None): Идентификатор транзакции
        coin (str | None): Монета
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями о пополнении
        """
        end_point = "/v5/asset/deposit/query-record"
        complete_request = self.base_url + end_point
        parameters = {
            "id": id_args,
            "txID": tx_id,
            "coin": coin,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_deposit_query_sub_member_record(
        self,
        sub_member_id: str,
        limit: int = 50,
        coin: str | None = None,
        id_args: str | None = None,
        tx_id: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение записей о пополнении суб-участника.

        Parameters:
        sub_member_id (str): ID суб-участника
        limit (int): Максимальное количество записей
        coin (str | None): Монета
        id_args (str | None): Идентификатор
        tx_id (str | None): Идентификатор транзакции
        start_time (int | None): Время начала в формате timestamp
        end_time (int | None): Время окончания в формате timestamp
        cursor (str | None): Курсор для пагинации

        Return:
        dict[str, Any]: Ответ API с записями о пополнении суб-участника
        """
        end_point = "/v5/asset/deposit/query-sub-member-record"
        complete_request = self.base_url + end_point
        parameters = {
            "id": id_args,
            "txID": tx_id,
            "subMemberId": sub_member_id,
            "coin": coin,
            "startTime": start_time,
            "endTime": end_time,
            "limit": limit,
            "cursor": cursor,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_covert_small_balance_list(
        self,
        account_type: str,
        from_coin: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение списка монет с мелким остатком для конвертации.

        Parameters:
        account_type (str): Тип аккаунта
        from_coin (str | None): Исходная монета для фильтрации

        Return:
        dict[str, Any]: Ответ API со списком монет с мелким остатком
        """
        end_point = "/v5/asset/covert/small-balance-list"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "fromCoin": from_coin,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_covert_get_quote(
        self,
        account_type: str,
        from_coin_list: list[str],
        to_coin: str,
    ) -> dict[str, Any]:
        """
        Запрос котировки конвертации мелких остатков.

        Parameters:
        account_type (str): Тип аккаунта
        from_coin_list (list[str]): Список исходных монет
        to_coin (str): Целевая монета

        Return:
        dict[str, Any]: Ответ API с котировкой конвертации
        """
        end_point = "/v5/asset/covert/get-quote"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "fromCoinList": from_coin_list,
            "toCoin": to_coin,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def post_asset_covert_small_balance_execute(
        self,
        quote_id: str,
    ) -> dict[str, Any]:
        """
        Выполнение конвертации мелких остатков по котировке.

        Parameters:
        quote_id (str): Идентификатор котировки

        Return:
        dict[str, Any]: Ответ API с результатом конвертации
        """
        end_point = "/v5/asset/covert/small-balance-execute"
        complete_request = self.base_url + end_point
        parameters = {
            "quoteId": quote_id,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().post(
            url=complete_request,
            json=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )

    def get_asset_covert_small_balance_history(
        self,
        account_type: str,
        quote_id: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        cursor: str | None = None,
        size: str | None = None,
    ) -> dict[str, Any]:
        """
        Получение истории конвертации мелких остатков.

        Parameters:
        account_type (str): Тип аккаунта
        quote_id (str | None): Идентификатор котировки
        start_time (str | None): Время начала
        end_time (str | None): Время окончания
        cursor (str | None): Курсор для пагинации
        size (str | None): Размер страницы

        Return:
        dict[str, Any]: Ответ API с историей конвертации мелких остатков
        """
        end_point = "/v5/asset/covert/small-balance-history"
        complete_request = self.base_url + end_point
        parameters = {
            "accountType": account_type,
            "quoteId": quote_id,
            "startTime": start_time,
            "endTime": end_time,
            "cursor": cursor,
            "size": size,
        }
        parameters = {key: value for key, value in parameters.items() if value is not None}

        return ApiManager().get(
            url=complete_request,
            params=parameters,
            api_key=self.api_key,
            secret_key=self.secret_key,
        )
