"use strict";
(self["webpackChunkjupyter_mlflow_argo_workflows_extension"] = self["webpackChunkjupyter_mlflow_argo_workflows_extension"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);



async function getLinks() {
    const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
    const url = `${baseUrl}jupyter_mlflow_argo_workflows_extension/links`;
    const r = await fetch(url, { credentials: 'same-origin' });
    if (!r.ok)
        throw new Error(`GET ${url} failed: ${r.status}`);
    return (await r.json());
}
async function loadSvg(url) {
    const r = await fetch(url, { cache: 'no-cache' });
    if (!r.ok)
        throw new Error(`GET ${url} failed: ${r.status}`);
    return await r.text();
}
/**
 * Fix: many logos have width/height but no viewBox -> LabIcon can't scale well.
 * We add viewBox from width/height if missing, and remove width/height.
 */
function normalizeSvgForLab(svgText) {
    let s = (svgText || '').trim();
    const wMatch = s.match(/\bwidth="([\d.]+)"/i);
    const hMatch = s.match(/\bheight="([\d.]+)"/i);
    const width = wMatch ? Number(wMatch[1]) : 24;
    const height = hMatch ? Number(hMatch[1]) : 24;
    if (!/\bviewBox="/i.test(s)) {
        s = s.replace(/<svg\b/i, `<svg viewBox="0 0 ${width || 24} ${height || 24}"`);
    }
    s = s.replace(/\swidth="[^"]*"/gi, '');
    s = s.replace(/\sheight="[^"]*"/gi, '');
    return s;
}
/**
 * Open external URL using JupyterLab command (popup-safe).
 * Tries multiple command IDs because they can differ by build/distribution.
 */
async function openWithJupyter(app, url) {
    const trimmed = (url || '').trim();
    if (!trimmed)
        return;
    const candidates = [
        'app:open-url',
        'apputils:open-url',
        'application:open-url'
    ];
    const cmd = candidates.find(c => app.commands.hasCommand(c));
    if (cmd) {
        await app.commands.execute(cmd, { url: trimmed });
        return;
    }
    window.open(trimmed, '_blank', 'noopener,noreferrer');
}
/**
 * A widget that only exists as a left sidebar tab.
 */
class SidebarLauncher extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor(id, caption, icon, onActivate) {
        super();
        this.id = id;
        this.title.label = '';
        this.title.caption = caption;
        this.title.icon = icon;
        // No visible panel
        this.node.style.display = 'none';
        this._onActivate = onActivate;
    }
    onActivateRequest() {
        this._onActivate();
    }
}
const plugin = {
    id: 'mlflow-argo-launcher',
    autoStart: true,
    activate: (app) => {
        const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
        // JupyterLab serves installed labextensions here:
        const argoSvgUrl = `${baseUrl}lab/extensions/jupyter_mlflow_argo_workflows_extension/static/icons/argo.svg`;
        const mlflowSvgUrl = `${baseUrl}lab/extensions/jupyter_mlflow_argo_workflows_extension/static/icons/mlflow.svg`;
        const placeholder = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
        <rect width="16" height="16" fill="currentColor" opacity="0.18"/>
        </svg>`;
        const argoIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
            name: 'jupyter_mlflow_argo_workflows_extension:argo',
            svgstr: placeholder
        });
        const mlflowIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
            name: 'jupyter_mlflow_argo_workflows_extension:mlflow',
            svgstr: placeholder
        });
        // Cache links once (fast + avoids popup timing issues)
        const links = { mlflow: '', argo: '' };
        const refreshLinks = async () => {
            try {
                const l = await getLinks();
                links.mlflow = (l.mlflow || '').trim();
                links.argo = (l.argo || '').trim();
            }
            catch (e) {
                console.error('Failed to load /jupyter_mlflow_argo_workflows_extension/links:', e);
            }
        };
        void refreshLinks();
        const openCached = (key, label) => {
            const url = (links[key] || '').trim();
            if (!url) {
                console.warn(`${label} URL not configured (empty from server). Refreshing...`);
                void refreshLinks();
                return;
            }
            void openWithJupyter(app, url);
        };
        // Create launchers
        const mlflowLauncher = new SidebarLauncher('mlflow-launcher', 'MLflow', mlflowIcon, () => openCached('mlflow', 'MLflow'));
        const argoLauncher = new SidebarLauncher('argo-launcher', 'Argo Workflows', argoIcon, () => openCached('argo', 'Argo Workflows'));
        app.shell.add(mlflowLauncher, 'left', { rank: 900 });
        app.shell.add(argoLauncher, 'left', { rank: 901 });
        // Load SVGs and refresh icons
        void (async () => {
            try {
                const [argoSvgRaw, mlflowSvgRaw] = await Promise.all([
                    loadSvg(argoSvgUrl),
                    loadSvg(mlflowSvgUrl)
                ]);
                argoIcon.svgstr = normalizeSvgForLab(argoSvgRaw);
                mlflowIcon.svgstr = normalizeSvgForLab(mlflowSvgRaw);
                // Force repaint
                argoLauncher.title.icon = argoIcon;
                mlflowLauncher.title.icon = mlflowIcon;
            }
            catch (e) {
                console.error('Failed to load SVG icons:', e);
            }
        })();
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.27923ebe58414f2d87d4.js.map