# jupyter_mlflow_argo_workflows_extension/__init__.py

try:
    from ._version import __version__
except Exception:
    __version__ = "0.0.0"


def _jupyter_labextension_paths():
    # IMPORTANT: "dest" must match your JS package name / labextension dest
    return [{
        "src": "labextension",
        "dest": "jupyter_mlflow_argo_workflows_extension"
    }]


def _jupyter_server_extension_points():
    return [{"module": "jupyter_mlflow_argo_workflows_extension.serverext"}]


def load_jupyter_server_extension(server_app):
    from .serverext import load_jupyter_server_extension as _load
    _load(server_app)
