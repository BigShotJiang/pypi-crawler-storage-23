import os
import tornado.web
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join

class LinksHandler(APIHandler):
    @tornado.web.authenticated
    def get(self):
        self.finish({
            "mlflow": os.environ.get("MLFLOW_URL", ""),
            "argo": os.environ.get("ARGO_WORKFLOWS_URL", "")
        })

def _jupyter_server_extension_points():
    return [{"module": "jupyter_mlflow_argo_workflows_extension.serverext"}]

def load_jupyter_server_extension(server_app):
    web_app = server_app.web_app
    base_url = web_app.settings.get("base_url", "/")
    route = url_path_join(base_url, "jupyter_mlflow_argo_workflows_extension", "links")
    web_app.add_handlers(".*$", [(route, LinksHandler)])