import os
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join

class LinksHandler(APIHandler):
    def get(self):
        mlflow = os.getenv("MLFLOW_URL", "")
        argo = os.getenv("ARGO_WORKFLOWS_URL", "")

        self.finish({
            "mlflow": mlflow,
            "argo": argo
        })

def setup_handlers(web_app):
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]
    route = url_path_join(base_url, "jupyter_mlflow_argo_workflows_extension", "links")
    web_app.add_handlers(host_pattern, [(route, LinksHandler)])