from setuptools import setup, find_packages
from pathlib import Path

# README is one level up from sdk/; fall back gracefully if not found
_here = Path(__file__).parent
_readme = _here.parent / "README.md"
long_description = _readme.read_text(encoding="utf-8") if _readme.exists() else ""

setup(
    name="learnml-sdk",
    version="0.1.0",
    description="Python SDK for the LearnML training data management platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="LearnML",
    author_email="milindjain0@gmail.com",
    url="https://github.com/milindjain0/learnml",
    python_requires=">=3.8",
    packages=find_packages(),
    install_requires=[
        "grpcio>=1.50.0",
        "protobuf>=4.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
