"""
LearnML Python SDK — direct gRPC client.

Quick start:
    from learnml import LearnMLClient

    client = LearnMLClient("localhost:50051")
    client.login("you@example.com", "password")

    universe = client.create_universe("my-experiments")
    run = client.create_training_run(
        universe["id"], name="gpt2-run-1", model_name="gpt2",
        config={"lr": "3e-4", "batch_size": "32"}
    )
    client.log_metrics(universe["id"], run["id"], step=100, loss=1.5, perplexity=4.5)
"""

from __future__ import annotations

import io
import os
from typing import Dict, Generator, List, Optional

import grpc

from . import (
    auth_pb2, auth_pb2_grpc,
    checkpoint_pb2, checkpoint_pb2_grpc,
    common_pb2,
    data_pb2, data_pb2_grpc,
    metrics_pb2, metrics_pb2_grpc,
    service_pb2_grpc,
    universe_pb2, universe_pb2_grpc,
)
from .exceptions import raise_from_grpc

# Protobuf → plain dict helpers
from google.protobuf.json_format import MessageToDict

_CHUNK_SIZE = 4 * 1024 * 1024  # 4 MB

# Data type string → proto enum
_DATA_TYPE = {
    "IMAGE":       data_pb2.DATA_TYPE_IMAGE,
    "VIDEO":       data_pb2.DATA_TYPE_VIDEO,
    "PDF":         data_pb2.DATA_TYPE_PDF,
    "TEXT":        data_pb2.DATA_TYPE_TEXT,
    "LLM_SFT":     data_pb2.DATA_TYPE_LLM_SFT,
    "LLM_RL":      data_pb2.DATA_TYPE_LLM_RL,
    "LLM_PRETRAIN":data_pb2.DATA_TYPE_LLM_PRETRAIN,
    "CUSTOM":      data_pb2.DATA_TYPE_CUSTOM,
}

_CHECKPOINT_FORMAT = {
    "PYTORCH":      checkpoint_pb2.CHECKPOINT_FORMAT_PYTORCH,
    "TENSORFLOW":   checkpoint_pb2.CHECKPOINT_FORMAT_TENSORFLOW,
    "ONNX":         checkpoint_pb2.CHECKPOINT_FORMAT_ONNX,
    "SAFETENSORS":  checkpoint_pb2.CHECKPOINT_FORMAT_SAFETENSORS,
    "CUSTOM":       checkpoint_pb2.CHECKPOINT_FORMAT_CUSTOM,
}


class LearnMLClient:
    """
    Synchronous gRPC client for the LearnML backend.

    Args:
        host:  gRPC server address, e.g. ``"localhost:50051"``.
        token: Optional pre-existing access token (skip login step).
    """

    def __init__(self, host: str = "localhost:50051", token: Optional[str] = None):
        self.host = host
        self.token = token
        self._refresh_token: Optional[str] = None
        self._channel: Optional[grpc.Channel] = None

    # ── Connection ────────────────────────────────────────────────────────────

    def _ch(self) -> grpc.Channel:
        if self._channel is None:
            self._channel = grpc.insecure_channel(self.host)
        return self._channel

    def _meta(self, universe_id: Optional[str] = None) -> list:
        meta = []
        if self.token:
            meta.append(("authorization", f"Bearer {self.token}"))
        if universe_id:
            meta.append(("x-universe-id", universe_id))
        return meta

    def close(self):
        if self._channel:
            self._channel.close()
            self._channel = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    # ── Auth ──────────────────────────────────────────────────────────────────

    def register(self, email: str, password: str, display_name: str = "") -> Dict:
        """Register a new user account."""
        stub = service_pb2_grpc.AuthServiceStub(self._ch())
        try:
            r = stub.Register(auth_pb2.RegisterRequest(
                email=email, password=password, display_name=display_name))
            return MessageToDict(r)
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def login(self, email: str, password: str) -> Dict:
        """
        Login and store the token for subsequent calls.

        Returns:
            dict with ``access_token``, ``refresh_token``, and ``user``.
        """
        stub = service_pb2_grpc.AuthServiceStub(self._ch())
        try:
            r = stub.Login(auth_pb2.LoginRequest(email=email, password=password))
            self.token = r.access_token
            self._refresh_token = r.refresh_token
            return MessageToDict(r)
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def refresh(self) -> str:
        """Refresh the access token using the stored refresh token."""
        stub = service_pb2_grpc.AuthServiceStub(self._ch())
        try:
            r = stub.RefreshToken(
                auth_pb2.RefreshTokenRequest(refresh_token=self._refresh_token))
            self.token = r.access_token
            self._refresh_token = r.refresh_token
            return self.token
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def me(self) -> Dict:
        """Return the current authenticated user."""
        stub = service_pb2_grpc.AuthServiceStub(self._ch())
        try:
            r = stub.GetCurrentUser(auth_pb2.GetCurrentUserRequest(),
                                    metadata=self._meta())
            return MessageToDict(r)
        except grpc.RpcError as e:
            raise_from_grpc(e)

    # ── Universes ─────────────────────────────────────────────────────────────

    def create_universe(self, name: str, description: str = "") -> Dict:
        """Create a new universe (multi-tenant workspace)."""
        stub = service_pb2_grpc.UniverseServiceStub(self._ch())
        try:
            r = stub.CreateUniverse(universe_pb2.CreateUniverseRequest(
                name=name, description=description), metadata=self._meta())
            return MessageToDict(r)["universe"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def list_universes(self) -> List[Dict]:
        """List all universes the current user is a member of."""
        stub = service_pb2_grpc.UniverseServiceStub(self._ch())
        try:
            r = stub.ListMyUniverses(
                universe_pb2.ListMyUniversesRequest(), metadata=self._meta())
            return MessageToDict(r).get("universes", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def get_universe(self, universe_id: str) -> Dict:
        stub = service_pb2_grpc.UniverseServiceStub(self._ch())
        try:
            r = stub.GetUniverse(
                universe_pb2.GetUniverseRequest(universe_id=universe_id),
                metadata=self._meta(universe_id))
            return MessageToDict(r)["universe"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    # ── Data Points ───────────────────────────────────────────────────────────

    def create_data_point(
        self,
        universe_id: str,
        name: str,
        data_type: str = "CUSTOM",
        labels: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """
        Create a data point record (metadata only; use ``upload_data`` for files).

        Args:
            data_type: One of IMAGE, VIDEO, PDF, TEXT, LLM_SFT, LLM_RL,
                       LLM_PRETRAIN, CUSTOM.
            labels:    Key/value labels, e.g. ``{"class": "cat", "split": "train"}``.
            metadata:  Arbitrary string metadata.
        """
        stub = service_pb2_grpc.DataServiceStub(self._ch())
        label_protos = [
            data_pb2.DataLabel(key=k, value=v)
            for k, v in (labels or {}).items()
        ]
        req = data_pb2.CreateDataPointRequest(
            universe_id=universe_id,
            name=name,
            data_type=_DATA_TYPE.get(data_type.upper(), data_pb2.DATA_TYPE_CUSTOM),
            labels=label_protos,
        )
        for k, v in (metadata or {}).items():
            req.metadata[k] = v
        try:
            r = stub.CreateDataPoint(req, metadata=self._meta(universe_id))
            return MessageToDict(r)["dataPoint"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def upload_data(
        self,
        universe_id: str,
        name: str,
        data_type: str,
        file_path: str,
        labels: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, str]] = None,
        chunk_size: int = _CHUNK_SIZE,
    ) -> Dict:
        """
        Create a data point and stream-upload the file content.

        Args:
            file_path: Local path to the file to upload.
        """
        dp = self.create_data_point(universe_id, name, data_type, labels, metadata)
        dp_id = dp["id"]
        stub = service_pb2_grpc.DataServiceStub(self._ch())

        def _stream():
            yield data_pb2.UploadDataContentRequest(data_point_id=dp_id)
            with open(file_path, "rb") as f:
                while chunk := f.read(chunk_size):
                    yield data_pb2.UploadDataContentRequest(chunk=chunk)

        try:
            stub.UploadDataContent(_stream(), metadata=self._meta(universe_id))
        except grpc.RpcError as e:
            raise_from_grpc(e)
        return dp

    def list_data_points(
        self,
        universe_id: str,
        data_type: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict]:
        stub = service_pb2_grpc.DataServiceStub(self._ch())
        req = data_pb2.ListDataPointsRequest(
            universe_id=universe_id,
            pagination=common_pb2.PaginationRequest(page_size=limit),
        )
        if data_type:
            req.data_type_filter = _DATA_TYPE.get(
                data_type.upper(), data_pb2.DATA_TYPE_UNSPECIFIED)
        try:
            r = stub.ListDataPoints(req, metadata=self._meta(universe_id))
            return MessageToDict(r).get("dataPoints", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def get_data_point(self, universe_id: str, data_point_id: str) -> Dict:
        stub = service_pb2_grpc.DataServiceStub(self._ch())
        try:
            r = stub.GetDataPoint(
                data_pb2.GetDataPointRequest(
                    universe_id=universe_id, data_point_id=data_point_id),
                metadata=self._meta(universe_id))
            return MessageToDict(r)["dataPoint"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def stream_data_batch(
        self, universe_id: str, collection_id: str, batch_size: int = 32
    ) -> Generator[List[Dict], None, None]:
        """
        Stream data in batches for training loops.

        Yields:
            Lists of data point dicts of length up to ``batch_size``.
        """
        stub = service_pb2_grpc.DataServiceStub(self._ch())
        req = data_pb2.StreamDataBatchRequest(
            universe_id=universe_id,
            collection_id=collection_id,
            batch_size=batch_size,
        )
        try:
            for batch_resp in stub.StreamDataBatch(
                    req, metadata=self._meta(universe_id)):
                yield [MessageToDict(dp) for dp in batch_resp.data_points]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    # ── Collections ───────────────────────────────────────────────────────────

    def create_collection(
        self, universe_id: str, name: str, description: str = ""
    ) -> Dict:
        stub = service_pb2_grpc.CollectionServiceStub(self._ch())
        try:
            r = stub.CreateCollection(
                data_pb2.CreateCollectionRequest(
                    universe_id=universe_id, name=name, description=description),
                metadata=self._meta(universe_id))
            return MessageToDict(r)["collection"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def list_collections(self, universe_id: str) -> List[Dict]:
        stub = service_pb2_grpc.CollectionServiceStub(self._ch())
        try:
            r = stub.ListCollections(
                data_pb2.ListCollectionsRequest(universe_id=universe_id),
                metadata=self._meta(universe_id))
            return MessageToDict(r).get("collections", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def add_to_collection(
        self, universe_id: str, collection_id: str, data_point_ids: List[str]
    ) -> int:
        stub = service_pb2_grpc.CollectionServiceStub(self._ch())
        try:
            r = stub.AddDataToCollection(
                data_pb2.AddDataToCollectionRequest(
                    collection_id=collection_id,
                    data_point_ids=data_point_ids),
                metadata=self._meta(universe_id))
            return r.added_count
        except grpc.RpcError as e:
            raise_from_grpc(e)

    # ── Training Runs ─────────────────────────────────────────────────────────

    def create_training_run(
        self,
        universe_id: str,
        name: str,
        model_name: str = "",
        config: Optional[Dict[str, str]] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """
        Create a training run and return its dict (includes ``id``).

        Example:
            run = client.create_training_run(
                uid, "gpt2-run-1", "gpt2-medium",
                config={"lr": "3e-4", "batch_size": "32"}
            )
        """
        stub = service_pb2_grpc.MetricsServiceStub(self._ch())
        req = metrics_pb2.CreateTrainingRunRequest(
            universe_id=universe_id,
            name=name,
            model_name=model_name,
        )
        for k, v in (config or {}).items():
            req.config[k] = v
        for k, v in (metadata or {}).items():
            req.metadata[k] = v
        try:
            r = stub.CreateTrainingRun(req, metadata=self._meta(universe_id))
            return MessageToDict(r)["trainingRun"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def log_metrics(
        self, universe_id: str, run_id: str, step: int, **metrics: float
    ) -> None:
        """
        Log metrics for a training step.

        Example:
            client.log_metrics(uid, run_id, step=100,
                               loss=1.5, perplexity=4.48, accuracy=0.72)
        """
        stub = service_pb2_grpc.MetricsServiceStub(self._ch())
        snapshot = metrics_pb2.MetricSnapshot(step=step)
        for k, v in metrics.items():
            snapshot.metrics[k] = float(v)
        req = metrics_pb2.LogMetricsRequest(
            universe_id=universe_id, run_id=run_id, snapshot=snapshot)
        try:
            stub.LogMetrics(req, metadata=self._meta(universe_id))
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def get_metrics(
        self,
        universe_id: str,
        run_id: str,
        metric_name: str = "",
        start_step: int = 0,
        end_step: int = 0,
    ) -> List[Dict]:
        """
        Query logged metrics.

        Args:
            metric_name: Filter to a specific metric (e.g. ``"loss"``).
                         Empty string returns all metrics.
            end_step:    0 means no upper bound.
        """
        stub = service_pb2_grpc.MetricsServiceStub(self._ch())
        req = metrics_pb2.GetMetricsRequest(
            universe_id=universe_id,
            run_id=run_id,
            metric_name=metric_name,
            start_step=start_step,
            end_step=end_step or (2**63 - 1),
        )
        try:
            r = stub.GetMetrics(req, metadata=self._meta(universe_id))
            return MessageToDict(r).get("entries", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def list_training_runs(self, universe_id: str, limit: int = 50) -> List[Dict]:
        stub = service_pb2_grpc.MetricsServiceStub(self._ch())
        try:
            r = stub.ListTrainingRuns(
                metrics_pb2.ListTrainingRunsRequest(
                    universe_id=universe_id,
                    pagination=common_pb2.PaginationRequest(page_size=limit)),
                metadata=self._meta(universe_id))
            return MessageToDict(r).get("trainingRuns", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def end_training_run(self, universe_id: str, run_id: str) -> Dict:
        stub = service_pb2_grpc.MetricsServiceStub(self._ch())
        try:
            r = stub.EndTrainingRun(
                metrics_pb2.EndTrainingRunRequest(
                    universe_id=universe_id, run_id=run_id),
                metadata=self._meta(universe_id))
            return MessageToDict(r)["trainingRun"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    # ── Checkpoints ───────────────────────────────────────────────────────────

    def save_checkpoint(
        self,
        universe_id: str,
        run_id: str,
        step: int,
        epoch: int,
        file_path: str,
        format: str = "PYTORCH",
        metadata: Optional[Dict[str, str]] = None,
        chunk_size: int = _CHUNK_SIZE,
    ) -> Dict:
        """
        Stream-upload a checkpoint file to the server.

        Args:
            file_path: Local path to the checkpoint file.
            format:    PYTORCH, TENSORFLOW, ONNX, SAFETENSORS, or CUSTOM.

        Example:
            ckpt = client.save_checkpoint(
                uid, run_id, step=1000, epoch=5,
                file_path="model.pt", format="PYTORCH"
            )
            print(ckpt["id"])
        """
        stub = service_pb2_grpc.CheckpointServiceStub(self._ch())
        fmt = _CHECKPOINT_FORMAT.get(format.upper(),
                                     checkpoint_pb2.CHECKPOINT_FORMAT_CUSTOM)
        ckpt_meta = checkpoint_pb2.SaveCheckpointMetadata(
            universe_id=universe_id,
            run_id=run_id,
            step=step,
            epoch=epoch,
            filename=os.path.basename(file_path),
            format=fmt,
        )
        for k, v in (metadata or {}).items():
            ckpt_meta.metadata[k] = v

        def _stream():
            yield checkpoint_pb2.SaveCheckpointRequest(metadata=ckpt_meta)
            with open(file_path, "rb") as f:
                while chunk := f.read(chunk_size):
                    yield checkpoint_pb2.SaveCheckpointRequest(chunk=chunk)

        try:
            r = stub.SaveCheckpoint(_stream(), metadata=self._meta(universe_id))
            return MessageToDict(r)["checkpoint"]
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def load_checkpoint(
        self,
        universe_id: str,
        checkpoint_id: str,
        save_to: Optional[str] = None,
    ) -> bytes:
        """
        Stream-download a checkpoint.

        Args:
            save_to: If provided, write bytes to this local file path.

        Returns:
            Raw checkpoint bytes (also written to ``save_to`` if given).
        """
        stub = service_pb2_grpc.CheckpointServiceStub(self._ch())
        req = checkpoint_pb2.LoadCheckpointRequest(
            universe_id=universe_id, checkpoint_id=checkpoint_id)
        buf = io.BytesIO()
        ckpt_info = None
        try:
            for msg in stub.LoadCheckpoint(req, metadata=self._meta(universe_id)):
                if msg.HasField("metadata"):
                    ckpt_info = MessageToDict(msg.metadata)
                elif msg.HasField("chunk"):
                    buf.write(msg.chunk)
        except grpc.RpcError as e:
            raise_from_grpc(e)

        data = buf.getvalue()
        if save_to:
            with open(save_to, "wb") as f:
                f.write(data)
        return data

    def list_checkpoints(self, universe_id: str, run_id: str) -> List[Dict]:
        stub = service_pb2_grpc.CheckpointServiceStub(self._ch())
        try:
            r = stub.ListCheckpoints(
                checkpoint_pb2.ListCheckpointsRequest(
                    universe_id=universe_id, run_id=run_id),
                metadata=self._meta(universe_id))
            return MessageToDict(r).get("checkpoints", [])
        except grpc.RpcError as e:
            raise_from_grpc(e)

    def get_latest_checkpoint(self, universe_id: str, run_id: str) -> Optional[Dict]:
        stub = service_pb2_grpc.CheckpointServiceStub(self._ch())
        try:
            r = stub.GetLatestCheckpoint(
                checkpoint_pb2.GetLatestCheckpointRequest(
                    universe_id=universe_id, run_id=run_id),
                metadata=self._meta(universe_id))
            d = MessageToDict(r)
            return d.get("checkpoint")
        except grpc.RpcError as e:
            raise_from_grpc(e)
