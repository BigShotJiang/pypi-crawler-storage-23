import grpc


class LearnMLError(Exception):
    """Base exception for LearnML SDK errors."""
    def __init__(self, message: str, code: str = "UNKNOWN"):
        super().__init__(message)
        self.code = code


class AuthError(LearnMLError):
    """Raised when authentication fails."""


class NotFoundError(LearnMLError):
    """Raised when a resource is not found."""


class PermissionError(LearnMLError):
    """Raised when the user lacks permission."""


class AlreadyExistsError(LearnMLError):
    """Raised when creating a resource that already exists."""


def raise_from_grpc(e: grpc.RpcError):
    code = e.code()
    msg = e.details() or str(e)
    if code == grpc.StatusCode.UNAUTHENTICATED:
        raise AuthError(msg, "UNAUTHENTICATED")
    elif code == grpc.StatusCode.NOT_FOUND:
        raise NotFoundError(msg, "NOT_FOUND")
    elif code == grpc.StatusCode.PERMISSION_DENIED:
        raise PermissionError(msg, "PERMISSION_DENIED")
    elif code == grpc.StatusCode.ALREADY_EXISTS:
        raise AlreadyExistsError(msg, "ALREADY_EXISTS")
    else:
        raise LearnMLError(msg, code.name)
