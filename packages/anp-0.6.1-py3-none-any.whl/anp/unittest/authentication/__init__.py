"""
Authentication Unit Tests Package

This package contains all unit tests related to DID WBA authentication.
"""
