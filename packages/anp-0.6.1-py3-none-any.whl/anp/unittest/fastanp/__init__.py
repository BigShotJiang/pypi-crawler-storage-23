"""
FastANP Framework Unit Tests Package

Tests cover:
- Interface registration and OpenRPC generation
- Context and session management
- DID WBA authentication middleware
- Agent description generation
"""
