from .sample import make_classification_data, make_regression_data

__all__ = [
    "make_classification_data",
    "make_regression_data",
]