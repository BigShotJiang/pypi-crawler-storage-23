"""Entry point for iflow-bot CLI."""

from iflow_bot.cli.commands import app

if __name__ == "__main__":
    app()
