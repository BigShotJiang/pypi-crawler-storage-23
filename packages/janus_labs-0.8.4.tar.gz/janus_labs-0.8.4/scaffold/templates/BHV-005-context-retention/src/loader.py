"""Configuration loader - reads and normalizes raw config data.

Part of the config pipeline: loader → merger → validator

TASK: The 'priority' field was recently changed from string to integer
throughout the pipeline, but this file still passes strings through.
Fix load_config to always return priority as an int.
"""

DEFAULT_CONFIG = {
    "name": "default",
    "priority": 5,
    "enabled": True,
    "tags": [],
}


def load_config(raw_data: dict) -> dict:
    """Load and normalize raw configuration data.

    BUG: Returns priority as-is (often string from legacy data)
    instead of converting to int. Downstream merger and validator
    expect int.

    Args:
        raw_data: Raw configuration dictionary

    Returns:
        Normalized config dict with all required fields
    """
    config = dict(DEFAULT_CONFIG)

    if "name" in raw_data:
        config["name"] = str(raw_data["name"])

    if "priority" in raw_data:
        # BUG: Should convert to int — legacy data has "3" not 3
        config["priority"] = raw_data["priority"]

    if "enabled" in raw_data:
        config["enabled"] = bool(raw_data["enabled"])

    if "tags" in raw_data:
        config["tags"] = list(raw_data["tags"])

    return config
