#!/usr/bin/env python3
"""
Run MultiLat Localizer with a YAML config (when not using the installed command).

  python scripts/multilat_solver.py --config config.yaml
  PYTHONPATH=src python scripts/multilat_solver.py --config config.yaml --logs /path/to/logs

After install, prefer: multilat_solver --config config.yaml
"""

import sys

from multilat_solver.cli import main

if __name__ == "__main__":
    sys.exit(main())
