"""Allow running the package as python -m multilat_solver."""

from multilat_solver.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
