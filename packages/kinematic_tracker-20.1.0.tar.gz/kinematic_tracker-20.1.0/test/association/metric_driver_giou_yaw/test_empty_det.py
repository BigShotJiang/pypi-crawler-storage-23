"""."""

import numpy as np

from kinematic_tracker.association.metric_giou_yaw import FT, MetricGIoUYaw


def test_empty_det(filters: FT, driver: MetricGIoUYaw) -> None:
    metric = driver.compute_metric(np.empty((0, 10)), filters)
    assert metric.shape == (0, 3)
