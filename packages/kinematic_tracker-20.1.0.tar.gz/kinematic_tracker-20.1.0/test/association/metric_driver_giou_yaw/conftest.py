"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.types import FMT, FT


@pytest.fixture
def driver() -> MetricGIoUYaw:
    return MetricGIoUYaw(5, 7, 10, (0, 1, 2, 3, 6, 7, 8, 9))


@pytest.fixture
def filters() -> FT:
    h_mat_zx = np.eye(10, 16)
    vec_nz = np.linspace(1.0, 30.0, 30).reshape(3, 10)
    vec_nz[:, 4:6] = 0

    filters = []
    for vec_z in vec_nz:
        kf = cv2.KalmanFilter(16, 10, 0, cv2.CV_64F)
        kf.measurementMatrix = h_mat_zx
        kf.statePre = vec_z.dot(h_mat_zx).reshape(16, 1)
        filters.append(kf)

    return filters


@pytest.fixture
def det_rz() -> FMT:
    vec_nz = np.linspace(1.0, 20.0, 20).reshape(2, 10)
    vec_nz[:, 4:6] = 0
    return vec_nz
