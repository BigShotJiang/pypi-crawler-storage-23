"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw


def test_set_target_tz(driver: MetricGIoUYaw, filters: list[cv2.KalmanFilter]) -> None:
    driver.set_target_tz(filters)
    assert driver.target_buf.num_rect == 3
    ref = [
        [1.0, 2.0, 3.0, 4.0, 0.0, 0.0, 7.0, 8.0, 9.0, 10.0],
        [11.0, 12.0, 13.0, 14.0, 0.0, 0.0, 17.0, 18.0, 19.0, 20.0],
        [21.0, 22.0, 23.0, 24.0, 0.0, 0.0, 27.0, 28.0, 29.0, 30.0],
    ]
    assert driver.xx_tz[:3] == pytest.approx(np.array(ref))
