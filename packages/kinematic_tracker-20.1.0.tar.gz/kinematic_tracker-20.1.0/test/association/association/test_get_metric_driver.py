"""."""

from kinematic_tracker.association.association import Association
from kinematic_tracker.association.association_metric import AssociationMetric
from kinematic_tracker.association.metric_giou_aligned import MetricGIoUAligned
from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw
from kinematic_tracker.association.metric_mahalanobis import MetricMahalanobis
from kinematic_tracker.association.metric_mahalanobis_size_mod import MetricMahalanobisSizeMod


def test_get_num_z_6(association: Association) -> None:
    """."""
    association.metric = AssociationMetric.MAHALANOBIS
    assert isinstance(association.get_metric_driver(), MetricMahalanobis)

    association.metric = AssociationMetric.GIOU_AXES_ALIGNED
    assert isinstance(association.get_metric_driver(), MetricGIoUAligned)

    association.metric = AssociationMetric.MAHALANOBIS_SIZE_MODULATED
    assert isinstance(association.get_metric_driver(), MetricMahalanobisSizeMod)


def test_giou_yaw() -> None:
    association = Association(16, 10)
    association.metric = AssociationMetric.GIOU_YAW
    assert isinstance(association.get_metric_driver(), MetricGIoUYaw)
