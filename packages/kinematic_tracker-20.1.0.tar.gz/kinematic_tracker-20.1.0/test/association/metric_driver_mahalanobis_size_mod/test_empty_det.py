"""."""

import cv2

from kinematic_tracker.association.metric_mahalanobis_size_mod import MetricMahalanobisSizeMod


def test_no_det(filters: list[cv2.KalmanFilter], driver: MetricMahalanobisSizeMod) -> None:
    metric = driver.compute_metric([], filters)
    assert metric.shape == (0, 3)
