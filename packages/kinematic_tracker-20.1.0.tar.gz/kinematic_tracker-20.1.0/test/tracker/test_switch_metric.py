"""."""

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.association.association_metric import AssociationMetric
from kinematic_tracker.association.metric_mahalanobis_size_mod import MetricMahalanobisSizeMod


def test_switch_metric() -> None:
    """."""
    tracker = NdKkfTracker([2, 2], [2, 2])
    name = AssociationMetric.MAHALANOBIS_SIZE_MODULATED.value
    tracker.set_association_metric(name, ind_pos_size=(0, 1, 2, 3))
    assert isinstance(tracker.metric_driver, MetricMahalanobisSizeMod)
