"""."""

import numpy as np

from kinematic_tracker import NdKkfTracker


def test_zero_detections_default(tracker: NdKkfTracker) -> None:
    tracker.set_measurement_cov(0.01 * np.eye(6))
    tracker.advance(100_000_000, np.empty((0, 6)))
    assert len(tracker.tracks_c[0]) == 0
