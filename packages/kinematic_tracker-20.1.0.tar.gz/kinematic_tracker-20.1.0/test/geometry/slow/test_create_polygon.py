"""."""

import numpy as np
import pytest
import shapely

from shapely import Polygon

from kinematic_tracker.geometry.slow.create_polygon import create_polygon


def test_create_polygon() -> None:
    poly = create_polygon(np.ones(9))
    assert isinstance(poly, Polygon)
    assert poly.representative_point() == shapely.geometry.Point(1, 1)
    # fmt: off
    ref = [
        [1.690886645338018, 1.1505843394698783], [0.8494156605301216, 1.690886645338018],
        [0.30911335466198187, 0.8494156605301216], [1.1505843394698783, 0.30911335466198187],
        [1.690886645338018, 1.1505843394698783]
    ]
    # fmt: on
    assert poly.exterior.coords == pytest.approx(np.array(ref))


def test_assert() -> None:
    with pytest.raises(AssertionError):
        create_polygon([0, 1, 1, 1, 1, 1, 1, 1, 1])

    with pytest.raises(AssertionError):
        create_polygon(np.zeros(8))

    with pytest.raises(AssertionError):
        create_polygon(np.zeros((1, 9)))
