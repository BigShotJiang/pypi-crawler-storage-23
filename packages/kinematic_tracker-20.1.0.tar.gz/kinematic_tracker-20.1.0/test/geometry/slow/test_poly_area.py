"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.slow.poly_area import get_poly_area


def test_get_poly_area() -> None:
    vertices = [
        [1.690886645338018, 1.1505843394698783],
        [0.8494156605301216, 1.690886645338018],
        [0.30911335466198187, 0.8494156605301216],
        [1.1505843394698783, 0.30911335466198187],
        [1.690886645338018, 1.1505843394698783],
    ]
    assert get_poly_area(np.array(vertices)) == pytest.approx(1.0)
    assert get_poly_area(2 * np.array(vertices)) == pytest.approx(4.0)
