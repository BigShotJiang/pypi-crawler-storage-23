"""."""

from kinematic_tracker.geometry.nu_scenes_giou import NuScenesGiou


def test_init(driver: NuScenesGiou) -> None:
    assert driver.report_buf.num_max == 5
    assert driver.target_buf.num_max == 6
