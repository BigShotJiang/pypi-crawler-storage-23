"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.geometry.nu_scenes_giou import NuScenesGiou
from kinematic_tracker.types import FMT


def test_compute(driver: NuScenesGiou, filters: list[cv2.KalmanFilter], det_rz: FMT) -> None:
    metric_rt = np.zeros((2, 3))
    driver.compute_giou(det_rz, filters, metric_rt)
    ref = [
        [1.0, 0.3185216546083782, 0.26513977158265706],
        [0.3185216546083782, 1.0, 0.4392318438129806],
    ]
    assert metric_rt == pytest.approx(np.array(ref))
