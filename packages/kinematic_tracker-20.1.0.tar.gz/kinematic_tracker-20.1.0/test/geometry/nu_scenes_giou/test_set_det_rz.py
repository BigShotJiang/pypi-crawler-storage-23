"""."""

from kinematic_tracker.geometry.nu_scenes_giou import NuScenesGiou
from kinematic_tracker.types import FMT


def test_set_det_rz(driver: NuScenesGiou, det_rz: FMT) -> None:
    driver.set_det_rz(det_rz)
    assert driver.report_buf.num_rect == 2
