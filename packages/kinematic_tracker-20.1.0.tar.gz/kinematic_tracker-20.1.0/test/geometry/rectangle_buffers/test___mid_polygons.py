"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers
from kinematic_tracker.types import FMT


def test_mid_polygons(rb5: RectangleBuffers, vec_2z: FMT) -> None:
    rb5.set_nu_scenes(vec_2z)
    rb5._mid_polygons()
    ref0 = [
        [2.8461538461538463, 7.730769230769232],
        [-4.90769230769231, 3.1615384615384614],
        [-0.8461538461538463, -3.7307692307692317],
        [6.90769230769231, 0.8384615384615386],
        [2.8461538461538463, 7.730769230769232],
    ]
    assert rb5.mid_polygons_n[0].exterior.coords == pytest.approx(np.array(ref0))
    ref1 = [
        [18.5979381443299, 22.654639175257735],
        [-0.049484536082477604, 19.01134020618557],
        [3.4020618556701017, 1.345360824742265],
        [22.049484536082478, 4.988659793814432],
        [18.5979381443299, 22.654639175257735],
    ]
    assert rb5.mid_polygons_n[1].exterior.coords == pytest.approx(np.array(ref1))
