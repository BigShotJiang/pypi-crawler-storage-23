"""."""

import numpy as np
import pytest

from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers
from kinematic_tracker.types import FMT


@pytest.fixture
def rb5() -> RectangleBuffers:
    return RectangleBuffers(5)


@pytest.fixture
def vec_2z() -> FMT:
    vec_rz = np.linspace(1, 20, 20).reshape(2, 10)
    vec_rz[:, 4:6] = 0
    return vec_rz
