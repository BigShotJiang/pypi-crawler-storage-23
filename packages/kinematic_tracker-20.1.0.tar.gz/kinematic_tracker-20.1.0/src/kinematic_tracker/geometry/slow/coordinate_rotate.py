import numpy as np


def coordinate_rotate(x: float, y: float, theta: float) -> tuple[float, float]:
    # Rotate the coordinates by theta
    x_ = np.cos(theta) * x + np.sin(theta) * y
    y_ = np.sin(theta) * (-x) + np.cos(theta) * y
    return x_, y_
