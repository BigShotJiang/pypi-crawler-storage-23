"""The module for computing Generalized Intersection over Union (GIoU) association metric.

This module provides functionality for computing the similarity score between detection reports
and Kalman filter states (targets) using the Generalized Intersection over Union (GIoU) metric.
The metric is computed between the 3D bounding boxes which are oriented by yaw angle.

Classes:
    MetricGIoU: GIoU association metrics between detections and Kalman filters.
"""

from typing import Sequence

import numpy as np

from kinematic_tracker.geometry.rectangle_buffers import RectangleBuffers
from kinematic_tracker.geometry.slow.giou_yaw_shapely import giou_3d_shapely
from kinematic_tracker.types import FMT, FT

from .metric_driver_base import MetricDriverBase


class MetricGIoUYaw(MetricDriverBase):
    """Computes GIoU association metric between detections and Kalman filter states.

    This class inherits from MetricDriverBase and implements GIoU-based metric computation
    for data association between detection reports and Kalman filter states. The computation
    is performed between cuboids (3D bounding boxes) rotated by yaw angle (around z axis
    by default).

    Args:
        num_reports_max: Maximum number of detection reports to handle.
        num_targets_max: Maximum number of targets (Kalman filters) to handle.
        num_z: Dimension of the measurement vector.
    """

    def __init__(
        self,
        num_reports_max: int,
        num_targets_max: int,
        num_z: int,
        ind_pos_w_rz_size: Sequence[int],
    ) -> None:
        """Initialize the MetricGIoUAligned instance.

        Args:
            num_reports_max: maximum number of detection reports to handle.
            num_targets_max: maximum number of targets (Kalman filters) to handle.
            num_z: number of variables in the measurement vector.
            ind_pos_w_rz_size: location of variables in the measurement vector.
                          By default, the indices are 0,1,2,3,6,7,8,9, i.e.
                          the center of the cuboid is taken as first three variables,
                          the scalar part of the quaternion follows the center,
                          the z-projection of the quaternion follows the scalar part,
                          and sizes (dimensions) of the cuboids are taken from
                          the last three variables.
        """
        assert num_z > 7, 'Number of variables should be 8 or greater.'
        super().__init__(num_reports_max, num_targets_max, num_z)
        self.ind_pos_w_rz_size = np.array(ind_pos_w_rz_size, dtype=int)
        assert self.ind_pos_w_rz_size.ndim == 1, 'Indices should be one-dimensional.'
        assert self.ind_pos_w_rz_size.size == 8, 'There should be 8 fancy indices.'
        self.report_buf = RectangleBuffers(num_reports_max)
        self.target_buf = RectangleBuffers(num_targets_max)
        self.xx_tz = np.zeros((num_targets_max, 10))
        self.xx_rz = np.zeros((num_reports_max, 10))
        self.xx_idx = np.array((0, 1, 2, 3, 6, 7, 8, 9), int)

    def set_det_rz(self, det_rz: FMT) -> None:
        num_r = det_rz.shape[0]
        self.xx_rz[:num_r, self.xx_idx] = det_rz[:, self.ind_pos_w_rz_size]
        self.report_buf.set_nu_scenes(self.xx_rz[:num_r])

    def set_target_tz(self, filters: FT) -> None:
        for t, kf in enumerate(filters):
            np.dot(kf.measurementMatrix, kf.statePre[:, 0], out=self.vec_z[:, 0])
            self.xx_tz[t, self.xx_idx] = self.vec_z[self.ind_pos_w_rz_size, 0]
        num_t = len(filters)
        self.target_buf.set_nu_scenes(self.xx_tz[:num_t])

    def compute_metric(self, det_rz: FMT, filters: FT) -> FMT:
        """Compute GIoU association metric between detections and Kalman filter states.

        Args:
            det_rz: Detection measurements, either as a 2D numpy array.
            filters: Sequence of OpenCV KalmanFilter objects representing tracked targets.

        Returns:
            np.ndarray: A matrix of GIoU scores between each detection-target pair,
                with shape (num_detections, num_targets).
        """
        self.set_det_rz(det_rz)
        self.set_target_tz(filters)
        metric_rt = self.get_rect_chunk(self.report_buf.num_rect, len(filters))
        for r_num in range(self.report_buf.num_rect):
            det_z = self.xx_rz[r_num]
            det_poly = self.report_buf.mid_polygons_n[r_num]
            for t_num in range(self.target_buf.num_rect):
                trk_z = self.xx_tz[t_num]
                trk_poly = self.target_buf.mid_polygons_n[t_num]
                metric_rt[r_num, t_num] = giou_3d_shapely(det_z, det_poly, trk_z, trk_poly)
        return metric_rt
