# Introduction
jot-translator is a library that translates text into more than 50 languages.

# Installation
To install the library, use one of the following commands:
```
pip install jot-translator
```
```
pip3 install jot-translator
```

# Usage
jot-translator provides a specific function for each language. To use them, you must use the abbreviations listed below. In any of the functions, we write our text inside the parentheses and specify lang (the language the text is written in), separating them with a comma. The text must be a string and lang must be the string code of the source language. For example:
```python
import jot_translator

translation = jot_translator.es("hello", lang="en") # "es" is the abbreviation for Spanish and "en" for English

print(translation)
```
The output of the code would be the Spanish word: <u>hola</u>.

Another example:
```python
import jot_translator

# Note: Remember to use the imported module name
translation = jot_translator.en("Me encantan las mates", lang="es")

print(translation)
```
The output of the program is: <u>I love maths</u>.

# Abbreviations
The available abbreviations are:
```
Punjabi: pa
Catalán: ca
Chino Mandarín: zh
Inglés: en
Hindi: hi
Spanish: es
Francés: fr
Árabe: ar
Bengalí: bn
Portugués: pt
Ruso: ru
Urdu: ur
Indonesio: id
Alemán: de
Japonés: ja
Maratí: mr
Telugu: te
Turco: tr
Tamil: ta
Vietnamita: vi
Tagalo: tl
Coreano: ko
Persa: fa
Hausa: ha
Suajili: sw
Javanés: jv
Italiano: it
Canarés: kn
Guyaratí: gu
Tailandés: th
Amhárico: am
Oromo: om
Pashto: ps
Malabar: ml
Polaco: pl
Ucraniano: uk
Uzbeko: uz
Sindhi: sd
Yoruba: yo
Maithili: mai
Birmano: my
Azerbaiyano: az
Nigerian Pidgin: pcm
Rumano: ro
Kurdo: ku
Neerlandés: nl
Sondanés: su
Jemer: km
Cingalés: si
Panyabí Occid: pnb
Gallego: gl
```

# Author
<u>Jotpartap Singh</u>, known on GitHub as Jotsisi.
- profile link: https://github.com/jotsisi

# Other Libraries of the Author
jotprint: For easier and customized printing.
- Link: https://github.com/jotsisi/jotprint

# License
MIT License
