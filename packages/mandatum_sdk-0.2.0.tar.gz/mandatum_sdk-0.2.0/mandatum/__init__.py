"""
Mandatum Python SDK

Provides transparent wrapping of LLM provider SDKs (OpenAI, Anthropic, Google)
to automatically log all requests to Mandatum for observability and analytics.

Usage:
    from mandatum import Mandatum

    mandatum = Mandatum(api_key="md_xxxxx")

    # Get wrapped OpenAI client
    OpenAI = mandatum.openai.OpenAI
    client = OpenAI()

    # Use normally - automatically logged to Mandatum
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        md_tags=["production"],
        md_environment="production"
    )
"""

from .client import Mandatum
from .version import __version__
from .prompts import PromptsResource, PromptRunResponse, PromptTemplate

__all__ = [
    "Mandatum",
    "__version__",
    "PromptsResource",
    "PromptRunResponse",
    "PromptTemplate",
]
