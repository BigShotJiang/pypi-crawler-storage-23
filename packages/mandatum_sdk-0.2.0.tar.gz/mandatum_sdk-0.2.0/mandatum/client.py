"""Main Mandatum client for initializing SDK wrappers."""

import os
from typing import Optional, TYPE_CHECKING

from .wrappers.openai import OpenAIWrapper
from .wrappers.anthropic import AnthropicWrapper

if TYPE_CHECKING:
    from .prompts import PromptsResource


class Mandatum:
    """
    Main Mandatum SDK client.

    Provides access to wrapped LLM provider SDKs that automatically log
    all requests to Mandatum for observability.

    Args:
        api_key: Mandatum API key (or set MANDATUM_API_KEY env var)
        base_url: Mandatum API base URL (default: http://localhost:8000)
                  Note: /api/v1 will be appended automatically if not present
        organization_id: Optional organization ID for requests
        async_logging: Whether to log asynchronously (default: True)
        debug: Enable debug logging (default: False)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:8000",
        organization_id: Optional[str] = None,
        async_logging: bool = True,
        debug: bool = False,
    ):
        self.api_key = api_key or os.getenv("MANDATUM_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Mandatum API key is required. "
                "Set MANDATUM_API_KEY environment variable or pass api_key parameter."
            )

        self.base_url = base_url.rstrip("/")
        self.organization_id = organization_id
        self.async_logging = async_logging
        self.debug = debug

        self._openai_wrapper = None
        self._anthropic_wrapper = None
        self._prompts_resource = None

    @property
    def openai(self) -> OpenAIWrapper:
        """Get OpenAI SDK wrapper."""
        if self._openai_wrapper is None:
            self._openai_wrapper = OpenAIWrapper(self)
        return self._openai_wrapper

    @property
    def anthropic(self) -> AnthropicWrapper:
        """Get Anthropic SDK wrapper."""
        if self._anthropic_wrapper is None:
            self._anthropic_wrapper = AnthropicWrapper(self)
        return self._anthropic_wrapper

    @property
    def prompts(self) -> "PromptsResource":
        """Get prompts resource for SDK-first local execution."""
        if self._prompts_resource is None:
            from .prompts import PromptsResource

            self._prompts_resource = PromptsResource(self)
        return self._prompts_resource
