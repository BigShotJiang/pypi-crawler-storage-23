# *************************************************************************
#  *
#  * Copyright (c) 2026 - Datatailr Inc.
#  * All Rights Reserved.
#  *
#  * This file is part of Datatailr and subject to the terms and conditions
#  * defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  * of this file, in parts or full, via any medium is strictly prohibited.
#  *************************************************************************

"""Shared visual constants used across all page modules."""

ACCENT = "#0072B5"
ACCENT_LIGHT = "#e8f4fa"
CARD_STYLE: dict[str, str] = {
    "border-radius": "8px",
    "box-shadow": "0 2px 8px rgba(0,0,0,0.08)",
}
