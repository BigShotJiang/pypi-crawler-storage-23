from service_forge.sft.config.injector_default_files import DEFAULT_TRAEFIK_INGRESS_YAML
from service_forge.sft.config.injector_default_files import DEFAULT_AUTH_MIDDLEWARE_YAML
from service_forge.sft.config.injector_default_files import DEFAULT_NOAUTH_WORKFLOW_YAML

def test_injector_files():
    result = DEFAULT_TRAEFIK_INGRESS_YAML.format(
        name="test",
        version="1.0.0",
        namespace="test",
        auth_middleware_yaml=DEFAULT_AUTH_MIDDLEWARE_YAML.format(namespace="test")
    ) + DEFAULT_NOAUTH_WORKFLOW_YAML.format(
        name="test",
        version="1.0.0",
        namespace="test",
        path="/docs".lstrip("/"),
        method="GET",
    )
    print(result)

if __name__ == "__main__":
    test_injector_files()