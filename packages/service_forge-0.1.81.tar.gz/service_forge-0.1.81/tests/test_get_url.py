from service_forge.workflow.node import Node
from service_forge.workflow.nodes.call_service_node import CallServiceNode
from service_forge.workflow.context import Context
from service_forge.sft.config.sf_metadata import load_metadata
from service_forge.workflow.workflow_factory import create_workflow_group
from service_forge.service import Service

def test_get_url():
    metadata = load_metadata("./sf-meta.yaml")
    service = Service.from_config(metadata)

    workflow_config_path = service.config.workflows[0]
    workflow_group = create_workflow_group(
        config_path=service.parse_workflow_path(workflow_config_path),
        entry_config=service.config.entry,
        service_env=service.service_env,
        _handle_stream_output=service._handle_stream_output,
        _handle_query_user=service._handle_query_user,
        database_manager=service.database_manager,
        llm=service.llm,
    )
    main_workflow = workflow_group.get_main_workflow()

    node = main_workflow.nodes[0]
    print(node.get_url(service_name="service-center", version="1.0.0", path="/test", internal=True))
    print(node.get_url(service_name="service-center", version="1.0.0", path="/test", internal=False))
    print(node.get_url(service_name="entry", version="1.0.0", path="/test", internal=True))
    print(node.get_url(service_name="entry", version="1.0.0", path="/test", internal=False))
    print(node.get_url(service_name="data-collection-service", version="1.0.0", path="/test", internal=True))
    print(node.get_url(service_name="data-collection-service", version="1.0.0", path="/test", internal=False))
    print(node.get_url(subdomain="file", service_name="entry", version="1.0.0", path="/test", internal=True))
    print(node.get_url(subdomain="file", service_name="entry", version="1.0.0", path="/test", internal=False))

if __name__ == "__main__":
    test_get_url()