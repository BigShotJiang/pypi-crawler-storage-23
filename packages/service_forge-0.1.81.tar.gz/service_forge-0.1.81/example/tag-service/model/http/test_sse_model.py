from service_forge.workflow.registry.sf_base_model import SfBaseModel

class TestSSEModel(SfBaseModel):
    message: str