from pydantic import BaseModel

class Reply(BaseModel):
    reply: str