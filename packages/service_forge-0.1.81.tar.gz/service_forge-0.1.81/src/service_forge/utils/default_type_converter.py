import enum
import inspect
from ..utils.type_converter import TypeConverter
from ..workflow.workflow import Workflow
from ..api.http_api import fastapi_app
from ..api.kafka_api import KafkaApp, kafka_app
from ..workflow.workflow_type import WorkflowType, workflow_type_register
from fastapi import FastAPI
from ..llm import Model

type_converter = TypeConverter()
type_converter.register(str, Workflow, lambda s, node, **_: node.sub_workflows.get_workflow(s))
type_converter.register(str, FastAPI, lambda s, node, **_: fastapi_app)
type_converter.register(str, KafkaApp, lambda s, node, **_: kafka_app)
type_converter.register(str, type, lambda s, node, **_: workflow_type_register.items[s].type)
type_converter.register(str, Model, lambda s, node, **_: Model[s])