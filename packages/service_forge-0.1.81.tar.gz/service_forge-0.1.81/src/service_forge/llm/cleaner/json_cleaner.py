from ..llm_cleaner import LLMCleaner
from typing import Any
import json
import re

class JsonCleaner(LLMCleaner):
    def __init__(self):
        pass

    def clean(self, content: str) -> Any:
        pattern = r'```json\s*(.*?)\s*```'
        match = re.search(pattern, content, re.DOTALL)
        
        if match:
            json_str = match.group(1).strip()
            return json.loads(json_str)
        else:
            raise ValueError("No JSON code block found in content")
