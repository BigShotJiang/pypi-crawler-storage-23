from typing import Any
from abc import ABC, abstractmethod

class LLMCleaner(ABC):
    @abstractmethod
    def clean(self, content: str) -> Any:
        pass
