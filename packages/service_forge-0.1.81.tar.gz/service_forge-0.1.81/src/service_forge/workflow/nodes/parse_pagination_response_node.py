from typing import Any
from service_forge.workflow.registry.sf_base_model import SfBaseModel
from service_forge.workflow.node import Node
from service_forge.workflow.port import Port

class ParsePaginationResponseNodeType(SfBaseModel):
    items: list[Any]
    page: int
    page_size: int
    total: int

class ParsePaginationResponseNode(Node):
    DEFAULT_INPUT_PORTS = [
        Port("response", ParsePaginationResponseNodeType),
        Port("assert_not_empty", bool),
    ]

    DEFAULT_OUTPUT_PORTS = [
        Port("items", list[Any]),
        Port("page", int),
        Port("page_size", int),
        Port("total", int),
        Port("first_item", Any),
    ]

    def __init__(self, name: str):
        super().__init__(name)

    async def _run(self, response: ParsePaginationResponseNodeType, assert_not_empty: bool) -> None:
        self.activate_output_edges('items', response.items)
        self.activate_output_edges('page', response.page)
        self.activate_output_edges('page_size', response.page_size)
        self.activate_output_edges('total', response.total)

        if assert_not_empty:
            if len(response.items) == 0:
                raise ValueError("Pagination response items is empty")

        self.activate_output_edges('first_item', response.items[0] if len(response.items) > 0 else None)