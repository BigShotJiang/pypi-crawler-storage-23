from typing import Any
from service_forge.workflow.registry.sf_base_model import SfBaseModel
from service_forge.workflow.node import Node
from service_forge.workflow.port import Port

class ParseListResponseNodeType(SfBaseModel):
    items: list[Any]
    total: int
    query_num: int

class ParseListResponseNode(Node):
    DEFAULT_INPUT_PORTS = [
        Port("response", ParseListResponseNodeType),
        Port("assert_not_empty", bool),
    ]

    DEFAULT_OUTPUT_PORTS = [
        Port("items", list[Any]),
        Port("total", int),
        Port("query_num", int),
        Port("first_item", Any),
    ]

    def __init__(self, name: str):
        super().__init__(name)

    async def _run(self, response: ParseListResponseNodeType, assert_not_empty: bool) -> None:
        self.activate_output_edges('items', response.items)
        self.activate_output_edges('total', response.total)
        self.activate_output_edges('query_num', response.query_num)

        if assert_not_empty:
            if len(response.items) == 0:
                raise ValueError("List response items is empty")

        self.activate_output_edges('first_item', response.items[0] if len(response.items) > 0 else None)