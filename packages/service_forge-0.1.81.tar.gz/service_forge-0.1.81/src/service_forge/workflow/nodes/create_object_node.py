from typing import Any
from service_forge.workflow.node import Node
from service_forge.workflow.port import Port

class CreateObjectNode(Node):
    DEFAULT_INPUT_PORTS = [
        Port("object_type", type),
        Port("fields", tuple[str, Any], is_extended=True),
    ]

    DEFAULT_OUTPUT_PORTS = [
        Port("object", Any),
    ]

    def __init__(self, name: str) -> None:
        super().__init__(name)

    def _run(
        self,
        object_type: type,
        fields: list[tuple[int, tuple[str, Any]]],
    ) -> Any:
        if object_type == dict:
            object = {}
            for _, f in fields:
                object[f[0]] = f[1]
        elif object_type == list:
            object = []
            for _, f in fields:
                object.append(f[1])
        else:
            fields = {f[0]: f[1] for _, f in fields}
            object = object_type(**fields)

        self.activate_output_edges('object', object)
