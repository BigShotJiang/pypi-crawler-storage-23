from __future__ import annotations
from typing import Any
from service_forge.workflow.node import Node
from service_forge.workflow.port import Port

class AnyGateNode(Node):
    DEFAULT_INPUT_PORTS = [
        Port("input", Any),
    ]

    DEFAULT_OUTPUT_PORTS = [
        Port("output", Any),
    ]

    def __init__(self, name: str):
        super().__init__(name)

    def _run(self, input: Any) -> Any:
        self.activate_output_edges('output', input)