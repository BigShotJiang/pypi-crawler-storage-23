import os

def load_prompt(prompt_path: str) -> str:
    if os.path.exists(prompt_path):
        if prompt_path in prompt_registry:
            return prompt_registry[prompt_path]
        with open(prompt_path, "r") as f:
            prompt = f.read()
            prompt_registry[prompt_path] = prompt
            return prompt
    else:
        return prompt_path

prompt_registry = {}