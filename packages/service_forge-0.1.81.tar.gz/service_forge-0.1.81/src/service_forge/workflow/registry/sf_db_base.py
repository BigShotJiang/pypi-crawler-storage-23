from __future__ import annotations
from sqlalchemy.orm import DeclarativeBase
from service_forge.utils.register import Register
from service_forge.db.trace_mixin import register_trace_events

register_trace_events(DeclarativeBase)

class SfDbBase(DeclarativeBase):
    __abstract__ = True
    
    def __init_subclass__(cls) -> None:
        if cls.__name__ not in ["SfDbBase"]:
            sf_dbbase_register.register(cls.__name__, cls)
        return super().__init_subclass__()

sf_dbbase_register = Register[SfDbBase]()
