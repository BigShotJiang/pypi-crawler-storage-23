from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from service_forge.workflow.workflow import Workflow

class WorkflowValidator:
    def __init__(self, workflow: Workflow) -> None:
        self.workflow = workflow

    def validate(self) -> None:
        pass