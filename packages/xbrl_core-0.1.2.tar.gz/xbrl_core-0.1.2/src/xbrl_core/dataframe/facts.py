"""LineItem を DataFrame に変換するモジュール。

``line_items_to_dataframe()`` で LineItem シーケンスを
全フィールドの DataFrame に変換する。
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Final

from xbrl_core.models.financial import LineItem
from xbrl_core.periods import DurationPeriod, InstantPeriod

if TYPE_CHECKING:
    import pandas as pd

__all__ = ["line_items_to_dataframe"]

_FULL_COLUMNS: Final[list[str]] = [
    "concept",
    "namespace_uri",
    "local_name",
    "label",
    "value",
    "unit_ref",
    "decimals",
    "context_id",
    "period_type",
    "period_start",
    "period_end",
    "entity_id",
    "dimensions_str",
    "is_nil",
    "source_line",
    "order",
]


def _format_dimensions(item: LineItem) -> str:
    """dimensions を文字列表現に変換する。

    Args:
        item: 対象の LineItem。

    Returns:
        ``"axis1=member1;axis2=member2"`` 形式。空なら ``""``。
    """
    if not item.dimensions:
        return ""
    parts = []
    for dim in item.dimensions:
        axis_short = dim.axis.rsplit("}", 1)[-1] if "}" in dim.axis else dim.axis
        member_short = dim.member.rsplit("}", 1)[-1] if "}" in dim.member else dim.member
        parts.append(f"{axis_short}={member_short}")
    return ";".join(parts)


def line_items_to_dataframe(
    items: Sequence[LineItem],
    *,
    label_lang: str = "en",
    metadata: dict[str, object] | None = None,
) -> pd.DataFrame:
    """LineItem シーケンスを DataFrame に変換する。

    Args:
        items: LineItem のシーケンス。
        label_lang: ラベル列に使用する言語コード（デフォルト ``"en"``）。
        metadata: DataFrame の attrs に付与するメタデータ。

    Returns:
        pandas DataFrame。

    Raises:
        ImportError: pandas がインストールされていない場合。
    """
    try:
        import pandas as pd_
    except ImportError:
        raise ImportError(
            "pandas is required. Install with: pip install xbrl-core[analysis]"
        ) from None

    rows: list[dict[str, object]] = []
    for item in items:
        period = item.period
        if isinstance(period, InstantPeriod):
            period_type = "instant"
            period_start = None
            period_end = period.instant
        elif isinstance(period, DurationPeriod):
            period_type = "duration"
            period_start = period.start_date
            period_end = period.end_date
        else:
            period_type = None
            period_start = None
            period_end = None

        label_text = item.label(label_lang) or item.local_name

        rows.append({
            "concept": item.concept,
            "namespace_uri": item.namespace_uri,
            "local_name": item.local_name,
            "label": label_text,
            "value": item.value,
            "unit_ref": item.unit_ref,
            "decimals": item.decimals,
            "context_id": item.context_id,
            "period_type": period_type,
            "period_start": period_start,
            "period_end": period_end,
            "entity_id": item.entity_id,
            "dimensions_str": _format_dimensions(item),
            "is_nil": item.is_nil,
            "source_line": item.source_line,
            "order": item.order,
        })

    if not rows:
        df = pd_.DataFrame(columns=_FULL_COLUMNS)
    else:
        df = pd_.DataFrame(rows, columns=_FULL_COLUMNS)

    if metadata:
        df.attrs.update(metadata)
    return df
