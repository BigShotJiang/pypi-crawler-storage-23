"""xbrl_core.dataframe — DataFrame 変換・エクスポート。"""
