"""財務諸表の HTML 表示モジュール。

Jupyter Notebook での ``_repr_html_()`` プロトコル用の HTML テーブル生成を提供する。
``display/statements.py`` の ``build_display_rows()`` を再利用し、
``DisplayRow`` → HTML ``<tr>`` への変換を行う。
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal
from html import escape

from xbrl_core.models.financial import LineItem
from xbrl_core.display.statements import DisplayHint, build_display_rows

__all__ = ["to_html"]

_CSS = """\
<style scoped>
.xbrl-stmt { border-collapse: collapse; width: 100%; font-family: system-ui, sans-serif; font-size: 13px; }
.xbrl-stmt th { background: #f5f5f5; text-align: left; padding: 6px 8px; border-bottom: 2px solid #ddd; }
.xbrl-stmt td { padding: 4px 8px; border-bottom: 1px solid #eee; }
.xbrl-stmt .amount { text-align: right; font-variant-numeric: tabular-nums; }
.xbrl-stmt .abstract td { font-weight: bold; background: #fafafa; }
.xbrl-stmt .total td { font-weight: bold; border-top: 1px solid #333; }
.xbrl-stmt .label { white-space: nowrap; }
</style>
"""


def _format_value(value: Decimal | str | None) -> str:
    """値を表示用文字列に変換する。

    Args:
        value: 変換対象の値。

    Returns:
        表示用文字列。
    """
    if value is None:
        return ""
    if isinstance(value, Decimal):
        return f"{value:,.0f}"
    return escape(str(value))


def to_html(
    items: Sequence[LineItem],
    *,
    hints: Sequence[DisplayHint] | None = None,
    title: str | None = None,
    label_lang: str = "en",
) -> str:
    """LineItem シーケンスを HTML テーブル文字列に変換する。

    ``display/statements.py`` の ``build_display_rows()`` を使用して
    ``DisplayRow`` リストを生成し、HTML テーブルに変換する。

    Args:
        items: 表示対象の LineItem シーケンス。
        hints: 階層表示用の DisplayHint。None の場合はフラット表示。
        title: テーブルキャプション。
        label_lang: ラベルの言語コード。

    Returns:
        HTML テーブル文字列。
    """
    rows = build_display_rows(items, hints=hints, label_lang=label_lang)

    lines = [_CSS]
    lines.append('<table class="xbrl-stmt">')
    if title:
        lines.append(f"<caption><strong>{escape(title)}</strong></caption>")
    lines.append(
        "<thead><tr><th>Label</th><th class='amount'>Amount</th></tr></thead>"
    )
    lines.append("<tbody>")

    for row in rows:
        css_classes: list[str] = []
        if row.is_abstract:
            css_classes.append("abstract")
        if row.is_total:
            css_classes.append("total")
        class_attr = f' class="{" ".join(css_classes)}"' if css_classes else ""

        indent = f"padding-left:{row.depth * 1.5}em" if row.depth > 0 else ""
        style_attr = f' style="{indent}"' if indent else ""

        value_str = _format_value(row.value)

        lines.append(f"<tr{class_attr}>")
        lines.append(f'  <td class="label"{style_attr}>{escape(row.label)}</td>')
        lines.append(f'  <td class="amount">{value_str}</td>')
        lines.append("</tr>")

    lines.append("</tbody></table>")
    return "\n".join(lines)
