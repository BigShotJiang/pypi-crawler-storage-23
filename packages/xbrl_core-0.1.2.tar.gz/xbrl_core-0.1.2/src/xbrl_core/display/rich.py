"""Rich 表示向けの描画ヘルパー。

``render_statement()`` で LineItem シーケンスを Rich Table に変換する。

Examples:
    >>> from rich.console import Console
    >>> from xbrl_core.display.rich import render_statement
    >>> table = render_statement(items, title="Balance Sheet")
    >>> Console().print(table)
"""

from __future__ import annotations

from collections.abc import Sequence
from decimal import Decimal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from rich.table import Table

from xbrl_core.models.financial import LineItem

__all__ = ["render_statement"]


def render_statement(
    items: Sequence[LineItem],
    *,
    title: str | None = None,
    label_lang: str = "en",
) -> Table:
    """LineItem シーケンスを Rich Table に変換する。

    Args:
        items: 表示対象の LineItem シーケンス。
        title: テーブルタイトル。
        label_lang: ラベルの言語コード。

    Returns:
        Rich Table オブジェクト。``console.print(table)`` で表示する。

    Raises:
        ImportError: rich がインストールされていない場合。
    """
    try:
        from rich.table import Table as RichTable
    except ImportError:
        raise ImportError(
            "rich is required for render_statement(). "
            "Install with: pip install xbrl-core[display]"
        ) from None

    table = RichTable(title=title, title_style="bold", show_lines=False)

    table.add_column("Label", style="cyan", min_width=20)
    table.add_column("Amount", justify="right", style="green", min_width=20)
    table.add_column("concept", style="dim", no_wrap=True)

    for item in items:
        label = item.label(label_lang) or item.local_name
        if isinstance(item.value, Decimal):
            value_str = f"{item.value:,}"
        elif item.value is None:
            value_str = "\u2014"
        else:
            value_str = str(item.value)
        table.add_row(label, value_str, item.local_name)

    return table
