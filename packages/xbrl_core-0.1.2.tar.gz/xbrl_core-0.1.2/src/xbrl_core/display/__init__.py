"""xbrl_core.display — 表示ユーティリティ (Rich / HTML)。"""
