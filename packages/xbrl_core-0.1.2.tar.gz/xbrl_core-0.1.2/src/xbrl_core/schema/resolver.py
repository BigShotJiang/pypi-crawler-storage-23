"""スキーマ解決 Protocol。

将来のスキーマ解決（URL → XSD bytes）のための Protocol 定義。
現時点では基本インターフェースのみ提供する。
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class SchemaResolver(Protocol):
    """XSD スキーマを解決するための Protocol。

    将来的にリモート / ローカルファイルシステム / キャッシュ等の
    実装を差し替え可能にする。
    """

    def resolve(self, schema_ref: str) -> bytes | None:
        """スキーマ参照を解決し XSD bytes を返す。

        Args:
            schema_ref: スキーマ参照（URL またはパス）。

        Returns:
            XSD のバイト列。解決できない場合は ``None``。
        """
        ...
