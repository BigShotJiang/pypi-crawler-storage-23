"""xbrl_core の例外・警告定義。

エラーコード体系:
    - ``XBRL_PARSE_xxx``: XML/XBRL パースエラー
    - ``XBRL_CTX_xxx``: Context 構造解析エラー
    - ``XBRL_UNIT_xxx``: Unit 構造解析エラー
    - ``XBRL_LINK_xxx``: リンクベース解析エラー
    - ``XBRL_VAL_xxx``: 検証エラー
    - ``XBRL_IXBRL_xxx``: iXBRL 解析エラー
"""

from __future__ import annotations


class XbrlError(Exception):
    """xbrl_core の基底例外。

    Attributes:
        code: エラーコード（例: ``"XBRL_PARSE_001"``）。
        context: エラーの追加コンテキスト情報。
    """

    def __init__(self, code: str, message: str, **context: object) -> None:
        """エラーコードとメッセージで初期化する。

        Args:
            code: エラーコード。
            message: エラーメッセージ（英語）。
            **context: 追加のコンテキスト情報。
        """
        self.code = code
        self.context = context
        full_message = f"[{code}] {message}"
        if context:
            details = ", ".join(f"{k}={v!r}" for k, v in context.items())
            full_message = f"{full_message} ({details})"
        super().__init__(full_message)


class XbrlParseError(XbrlError):
    """XML/XBRL パースエラー。"""


class XbrlValidationError(XbrlError):
    """XBRL 検証エラー。"""


class XbrlWarning(UserWarning):
    """xbrl_core が発行する warning の基底クラス。"""
