"""xbrl_core パッケージのバージョン定義。"""

__version__ = "0.1.2"
