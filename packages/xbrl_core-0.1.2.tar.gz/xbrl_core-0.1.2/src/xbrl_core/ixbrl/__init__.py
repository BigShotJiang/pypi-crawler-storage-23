"""xbrl_core.ixbrl — iXBRL (Inline XBRL) パーサー。"""
