"""XBRL 標準名前空間定数。

XBRL 2.1 仕様で定義される基盤名前空間 URI を定数として提供する。
EDINET 固有の名前空間はここには含めない。
"""

from __future__ import annotations

# XBRL Instance
NS_XBRLI = "http://www.xbrl.org/2003/instance"
# XBRL Dimensions
NS_XBRLDI = "http://xbrl.org/2006/xbrldi"
# XBRL Linkbase
NS_LINK = "http://www.xbrl.org/2003/linkbase"
# XLink
NS_XLINK = "http://www.w3.org/1999/xlink"
# XML Schema Instance
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
# XML (xml:lang etc.)
NS_XML = "http://www.w3.org/XML/1998/namespace"
# ISO 4217 currency codes
NS_ISO4217 = "http://www.xbrl.org/2003/iso4217"
# XBRL Dimensions Taxonomy
NS_XBRLDT = "http://xbrl.org/2005/xbrldt"
# XBRL numeric types (DTR)
NS_NUM = "http://www.xbrl.org/dtr/type/numeric"
# XBRL non-numeric types (DTR)
NS_NONNUM = "http://www.xbrl.org/dtr/type/non-numeric"
# Unit Type Registry
NS_UTR = "http://www.xbrl.org/2009/utr"
