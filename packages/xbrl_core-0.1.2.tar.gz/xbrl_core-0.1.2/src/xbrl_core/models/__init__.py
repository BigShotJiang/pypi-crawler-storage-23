"""xbrl_core データモデル。"""
