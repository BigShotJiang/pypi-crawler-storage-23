"""xbrl_core.validation — XBRL バリデーション。"""
