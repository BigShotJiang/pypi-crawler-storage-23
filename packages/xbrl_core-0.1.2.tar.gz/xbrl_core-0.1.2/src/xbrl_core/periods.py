"""XBRL 期間型定義。

InstantPeriod（時点）と DurationPeriod（期間）を提供する。
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass

__all__ = [
    "InstantPeriod",
    "DurationPeriod",
    "Period",
]


@dataclass(frozen=True, slots=True)
class InstantPeriod:
    """時点を表す期間。

    Attributes:
        instant: 時点の日付。
    """

    instant: datetime.date


@dataclass(frozen=True, slots=True)
class DurationPeriod:
    """期間を表す期間。

    Attributes:
        start_date: 期間の開始日。
        end_date: 期間の終了日。
    """

    start_date: datetime.date
    end_date: datetime.date


Period = InstantPeriod | DurationPeriod
"""期間型。InstantPeriod または DurationPeriod。"""
