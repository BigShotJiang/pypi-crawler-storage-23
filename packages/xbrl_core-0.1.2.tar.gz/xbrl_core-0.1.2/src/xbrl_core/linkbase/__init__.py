"""XBRL リンクベースパーサー群。

Presentation / Calculation / Definition / Label / Footnote リンクベースの
パースと構造化を提供する。
"""
