"""xbrl_core — 汎用 XBRL パーサーライブラリ。

XBRL 2.1 インスタンスのパース、Context/Unit の構造化、
リンクベース解析、LineItem への変換を提供する。
"""

from xbrl_core._version import __version__
from xbrl_core._linkbase_utils import ConceptExtractor
from xbrl_core.errors import XbrlError, XbrlParseError, XbrlValidationError, XbrlWarning
from xbrl_core.parser import ParsedXBRL, RawFact, RawContext, RawUnit, parse_xbrl_facts
from xbrl_core.periods import InstantPeriod, DurationPeriod, Period
from xbrl_core.contexts import (
    DimensionMember,
    StructuredContext,
    ContextCollection,
    structure_contexts,
)
from xbrl_core.units import (
    SimpleMeasure,
    DivideMeasure,
    StructuredUnit,
    structure_units,
)
from xbrl_core.models.financial import LabelSource, LabelInfo, LineItem
from xbrl_core.facts import build_line_items
from xbrl_core.labels import LabelResolver

# Linkbase types (Phase 2)
from xbrl_core.linkbase.presentation import (
    PresentationNode,
    PresentationTree,
    parse_presentation_linkbase,
    merge_presentation_trees,
)
from xbrl_core.linkbase.calculation import (
    CalculationArc,
    CalculationTree,
    CalculationLinkbase,
    parse_calculation_linkbase,
)
from xbrl_core.linkbase.definition import (
    DefinitionArc,
    DefinitionTree,
    HypercubeInfo,
    AxisInfo,
    MemberNode,
    parse_definition_linkbase,
)
from xbrl_core.linkbase.footnotes import (
    Footnote,
    FootnoteMap,
    parse_footnote_links,
)
from xbrl_core.linkbase.label import (
    RawLabel,
    parse_label_linkbase,
)
from xbrl_core.linkbase.reference import (
    ReferenceInfo,
    ReferencePart,
    parse_reference_linkbase,
)

# Schema types (Phase 2)
from xbrl_core.schema.elements import (
    ElementDefinition,
    parse_xsd_elements,
)
from xbrl_core.schema.resolver import SchemaResolver

# iXBRL types (Phase 3)
from xbrl_core.ixbrl.format_registry import FormatRegistry
from xbrl_core.ixbrl_parser import parse_ixbrl_facts, merge_ixbrl_results

# Text types (Phase 3)
from xbrl_core.text.blocks import TextBlock, extract_text_blocks
from xbrl_core.text.clean import clean_html

# Validation types (Phase 3)
from xbrl_core.validation.calc_check import (
    CalcValidationResult,
    ValidationIssue,
    validate_calculations,
)

# Display types (Phase 4)
from xbrl_core.display.statements import (
    DisplayRow,
    DisplayHint,
    build_display_rows,
    render_hierarchical_statement,
)
from xbrl_core.display.rich import render_statement
from xbrl_core.display.html import to_html

# DataFrame types (Phase 4)
from xbrl_core.dataframe.facts import line_items_to_dataframe
from xbrl_core.dataframe.export import to_csv, to_parquet, to_excel

__all__ = [
    "__version__",
    # customization
    "ConceptExtractor",
    # errors
    "XbrlError",
    "XbrlParseError",
    "XbrlValidationError",
    "XbrlWarning",
    # parser
    "ParsedXBRL",
    "RawFact",
    "RawContext",
    "RawUnit",
    "parse_xbrl_facts",
    # periods
    "InstantPeriod",
    "DurationPeriod",
    "Period",
    # contexts
    "DimensionMember",
    "StructuredContext",
    "ContextCollection",
    "structure_contexts",
    # units
    "SimpleMeasure",
    "DivideMeasure",
    "StructuredUnit",
    "structure_units",
    # models
    "LabelSource",
    "LabelInfo",
    "LineItem",
    # facts
    "build_line_items",
    # labels
    "LabelResolver",
    # linkbase - presentation
    "PresentationNode",
    "PresentationTree",
    "parse_presentation_linkbase",
    "merge_presentation_trees",
    # linkbase - calculation
    "CalculationArc",
    "CalculationTree",
    "CalculationLinkbase",
    "parse_calculation_linkbase",
    # linkbase - definition
    "DefinitionArc",
    "DefinitionTree",
    "HypercubeInfo",
    "AxisInfo",
    "MemberNode",
    "parse_definition_linkbase",
    # linkbase - footnotes
    "Footnote",
    "FootnoteMap",
    "parse_footnote_links",
    # linkbase - label
    "RawLabel",
    "parse_label_linkbase",
    # linkbase - reference
    "ReferenceInfo",
    "ReferencePart",
    "parse_reference_linkbase",
    # schema
    "ElementDefinition",
    "parse_xsd_elements",
    "SchemaResolver",
    # ixbrl
    "FormatRegistry",
    "parse_ixbrl_facts",
    "merge_ixbrl_results",
    # text
    "TextBlock",
    "extract_text_blocks",
    "clean_html",
    # validation
    "CalcValidationResult",
    "ValidationIssue",
    "validate_calculations",
    # display
    "DisplayRow",
    "DisplayHint",
    "build_display_rows",
    "render_hierarchical_statement",
    "render_statement",
    "to_html",
    # dataframe
    "line_items_to_dataframe",
    "to_csv",
    "to_parquet",
    "to_excel",
]
