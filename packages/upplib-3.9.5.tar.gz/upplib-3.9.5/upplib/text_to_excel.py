from upplib import *
from upplib.common_package import *


# 将文件导出成excel格式的
def to_excel(data_list: set | list | tuple | None,
             file_name: str = None,
             file_dir: str = 'excel') -> None:
    if file_name is None:
        file_name = 'excel'
    file_name = str(file_name)
    while file_dir.endswith('/'):
        file_dir = file_dir[0:-1]
    check_file(file_dir)
    # 实例化对象excel对象
    excel_obj = openpyxl.Workbook()
    # excel 内第一个sheet工作表
    excel_obj_sheet = excel_obj[excel_obj.sheetnames[0]]
    # 给单元格赋值
    for one_data in data_list:
        s_list = []
        if isinstance(one_data, list) or isinstance(one_data, set):
            for one in one_data:
                if isinstance(one, dict) or isinstance(one, list):
                    s = json.dumps(one)
                else:
                    s = str(one)
                s_list.append(s)
            excel_obj_sheet.append(s_list)
        else:
            if is_json_serializable(one_data):
                s = json.dumps(one_data)
            else:
                s = str(one_data)
            excel_obj_sheet.append([s])

    # 文件保存
    excel_obj.save(file_dir + '/' + get_file_name(file_name, '.xlsx'))


def to_csv(data_list: set | list | tuple | dict,
           file_name: str = None,
           file_dir: str = 'csv') -> None:
    """
    将文件导出成csv格式的
    data_list 格式
    data_list = [['Name', 'Age', 'Gender'],
                 ['Alice', 25, 'Female'],
                 ['Bob', 30, 'Male'],
                 ['Charlie', 35, 'Male']]
    data_list = [{
          "a": 1,
          "b": 2,
      },{
          "a": 1,
          "b": 2,
    }]
    file_name = 'data'
    """
    if file_name is None:
        file_name = 'csv'
    file_name = get_file_name(file_name, '.csv')
    while file_dir.endswith('/'):
        file_dir = file_dir[0:-1]
    check_file(file_dir)
    d_list = []
    if isinstance(data_list, tuple):
        d_list = list(data_list)
    else:
        if len(data_list) and (isinstance(data_list[0], dict) or isinstance(data_list[0], tuple)):
            title_list = []
            for key in data_list[0]:
                title_list.append(key)
            d_list.append(title_list)
            for one_data in data_list:
                one_list = []
                for k in title_list:
                    one_list.append(one_data[k])
                d_list.append(one_list)
        else:
            d_list = data_list
    with open(file_dir + '/' + file_name, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(d_list)
