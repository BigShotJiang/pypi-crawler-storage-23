"""Engine package — core processing modules."""
