# Imports
from typing import Any, Protocol, Callable, Iterable
from xml.etree.ElementTree import Element
from os import PathLike

    
PathString = str|PathLike
PlistStruct = dict|list|tuple
NumKey = int|str
RGBA = tuple[int,int,int,float]


class Caster(Protocol):
    def __call__(self, value: Any, **kwargs:Any) -> Any : ...

class DictCaster(Protocol):
    def __call__(self, key:NumKey, value: Any, **kwargs:Any) -> tuple[NumKey, Any]: ...
    
    
class StringDecoder(Protocol):
    def __call__(self, value: str, **kwargs:Any) -> Any : ...

class StringEncoder(Protocol):
    def __call__(self, value: Any, **kwargs:Any) -> str : ...

class KeyValueCondition(Protocol):
    def __call__(self, key: Any, value: Any) -> bool : ...


class StringDictDecoder(Protocol):
    def __call__(self, key: str, value: str, **kwargs:Any) -> tuple[NumKey, Any]: ...
    
class StringDictEncoder(Protocol):
    def __call__(self, key:NumKey, value:Any, **kwargs:Any) -> tuple[str, str]: ...


class PlistDictDecoder(Protocol):
    def __call__(self, key:str, value:Element) -> tuple[int, Any]: ...
    
class PlistDictEncoder(Protocol):
    def __call__(self, key:str, value:Any) -> tuple[int, Element]: ...

class PlistArrayDecoder(Protocol):
    def __call__(self, value:Element) -> Any: ...
    
class PlistArrayEncoder(Protocol):
    def __call__(self, value:Any) -> Element: ...


PlistDecoder = PlistDictDecoder|PlistArrayDecoder
PlistEncoder = PlistDictEncoder|PlistArrayDecoder


class PlistWrapper(Protocol):
    def __call__(self, data:Any, func:Callable, **kwargs) -> Any: ...
    
class DictWrapper(Protocol):
    def __call__(self, data:dict, func:DictCaster, **kwargs) -> dict: ...
    
class ArrayWrapper(Protocol):
    def __call__(self, data:Iterable, func:Caster, **kwargs) -> list: ...
    
    
class KeyValueFormat(Protocol):
    def __call__(self, key: Any, value: Any) -> str : ...