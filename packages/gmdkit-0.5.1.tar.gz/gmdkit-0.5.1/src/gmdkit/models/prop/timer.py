# Package Imports
from gmdkit.serialization.mixins import DataclassDecoderMixin
from gmdkit.serialization.functions import dataclass_decoder, field_decoder
from gmdkit.models.prop.remaps import RemapData


@dataclass_decoder(slots=True, separator='&', from_array=True)
class TimerData(DataclassDecoderMixin):

    item_id: int
    time: float
    active: bool
    time_mod: int
    ignore_time_warp: bool
    target_time: float
    stop_time: bool
    target_id: int
    trigger_id: int
    control_id: int
    paused: bool
    remaps: RemapData = field_decoder(decoder=RemapData.from_string,encoder=RemapData.to_string)