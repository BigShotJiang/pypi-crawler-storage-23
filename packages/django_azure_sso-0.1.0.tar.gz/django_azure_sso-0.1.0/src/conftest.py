import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import django
from django.conf import settings

if not settings.configured:
    settings.configure(
        SECRET_KEY="test-secret-key-for-testing-only",
        DEBUG=True,
        DATABASES={
            "default": {
                "ENGINE": "django.db.backends.sqlite3",
                "NAME": ":memory:",
            }
        },
        INSTALLED_APPS=[
            "django.contrib.auth",
            "django.contrib.contenttypes",
            "django.contrib.sessions",
            "sso",
        ],
        MIDDLEWARE=[
            "django.middleware.security.SecurityMiddleware",
            "django.contrib.sessions.middleware.SessionMiddleware",
            "django.middleware.common.CommonMiddleware",
            "django.middleware.csrf.CsrfViewMiddleware",
            "django.contrib.auth.middleware.AuthenticationMiddleware",
            "django.contrib.messages.middleware.MessageMiddleware",
        ],
        AUTH_USER_MODEL="auth.User",
        DEFAULT_AUTO_FIELD="django.db.models.BigAutoField",
        USE_TZ=True,
        ROOT_URLCONF="sso.urls_root",
        LOGIN_URL="/login/",
        LOGIN_REDIRECT_URL="/",
        LOGOUT_REDIRECT_URL="/login/",
        SSO_ENABLED=True,
        AZURE_AD_TENANT_ID="test-tenant",
        AZURE_AD_CLIENT_ID="test-client",
        AZURE_AD_CLIENT_SECRET="test-secret",
        AZURE_AD_REDIRECT_URI="http://localhost/sso/callback/",
        AZURE_AD_AUTHORITY_URL="https://login.microsoftonline.com",
        AZURE_AD_USERINFO_URL="https://graph.microsoft.com/oidc/userinfo",
        SSO_GET_OR_VALIDATE_USER_METHOD="sso.tests.mock_user_validator.mock_get_or_validate_user",
    )
    django.setup()
