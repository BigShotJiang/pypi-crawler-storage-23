import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

SECRET_KEY = "test-secret-key-for-testing-only"

DEBUG = True

ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "sso",
]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": ":memory:",
    }
}

AUTH_USER_MODEL = "auth.User"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

USE_TZ = True

SSO_ENABLED = True
AZURE_AD_TENANT_ID = "test-tenant"
AZURE_AD_CLIENT_ID = "test-client"
AZURE_AD_CLIENT_SECRET = "test-secret"
AZURE_AD_REDIRECT_URI = "http://localhost/sso/callback/"
AZURE_AD_AUTHORITY_URL = "https://login.microsoftonline.com"
AZURE_AD_USERINFO_URL = "https://graph.microsoft.com/oidc/userinfo"
SSO_GET_OR_VALIDATE_USER_METHOD = "sso.services.get_or_validate_user"
