import logging
import secrets
from importlib import import_module

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.shortcuts import redirect

from .rate_limit import increment_attempts, rate_limit_sso, reset_attempts
from .services import (
    AzureADError,
    AzureADService,
    generate_pkce_pair,
)

logger = logging.getLogger(__name__)


def get_user_validator():
    """
    Carga dinámicamente la función de validación de usuario configurada en settings.
    Se llama en cada request para permitir que los tests cambien el setting.
    """
    method_path = getattr(settings, 'SSO_GET_OR_VALIDATE_USER_METHOD', None)
    if not method_path:
        raise ValueError(
            "SSO_GET_OR_VALIDATE_USER_METHOD must be configured in settings. "
            "Example: SSO_GET_OR_VALIDATE_USER_METHOD = 'myapp.sso_utils.get_or_validate_user'"
        )
    module_path, function_name = method_path.rsplit('.', 1)
    module = import_module(module_path)
    return getattr(module, function_name)


@rate_limit_sso
def sso_login(request):
    """Inicia el flujo de autenticación con Azure AD."""
    # Generar state para prevenir CSRF
    state = secrets.token_urlsafe(32)
    request.session["sso_state"] = state

    # Generar PKCE pair para seguridad adicional
    code_verifier, code_challenge = generate_pkce_pair()
    request.session["sso_code_verifier"] = code_verifier

    # Guardar next URL si existe
    next_url = request.GET.get("next", "/")
    request.session["sso_next"] = next_url

    service = AzureADService()
    authorization_url = service.get_authorization_url(
        state, code_challenge=code_challenge
    )

    return redirect(authorization_url)


@rate_limit_sso
def sso_callback(request):
    """Callback de Azure AD después de autenticación."""
    # Verificar errores de Azure AD
    error = request.GET.get("error")
    if error:
        increment_attempts(request)
        error_description = request.GET.get("error_description", "")
        logger.error(f"Error de Azure AD: {error} - {error_description}")
        azure_error = AzureADError(
            error_code=error, error_description=error_description
        )
        messages.error(request, azure_error.message)
        return redirect("login")

    # Verificar state para prevenir CSRF
    state = request.GET.get("state")
    expected_state = request.session.pop("sso_state", None)

    if not state or state != expected_state:
        increment_attempts(request)
        messages.error(request, "Error de seguridad. Intente nuevamente.")
        return redirect("login")

    # Obtener código de autorización
    code = request.GET.get("code")
    if not code:
        increment_attempts(request)
        messages.error(request, "No se recibió código de autorización.")
        return redirect("login")

    try:
        service = AzureADService()

        # Obtener code_verifier de la sesión para PKCE
        code_verifier = request.session.pop("sso_code_verifier", None)

        # Intercambiar código por tokens (con PKCE si está disponible)
        tokens = service.exchange_code_for_tokens(code, code_verifier=code_verifier)
        access_token = tokens.get("access_token")

        # Obtener información del usuario
        user_info = service.get_user_info(access_token)
        email = user_info.get("email")

        if not email:
            messages.error(request, "No se pudo obtener el email del usuario.")
            return redirect("login")

        # Buscar usuario en el sistema
        user = get_user_validator()(email)

        if not user:
            increment_attempts(request)
            messages.error(
                request,
                "Su cuenta de Microsoft no está vinculada a ningún usuario del sistema. "
                "Contacte al administrador.",
            )
            return redirect("login")

        if not user.is_active:
            increment_attempts(request)
            messages.error(
                request, "Su cuenta está desactivada. Contacte al administrador."
            )
            return redirect("login")

        # Login exitoso - resetear intentos
        reset_attempts(request)

        # Iniciar sesión en Django
        login(request, user)

        # Redirect a la URL guardada o al home
        next_url = request.session.pop("sso_next", "/")
        return redirect(next_url)

    except AzureADError as e:
        increment_attempts(request)
        logger.error(f"Error SSO: {e.error_code} - {e.error_description}")
        messages.error(request, e.message)
        return redirect("login")
    except Exception:
        increment_attempts(request)
        logger.exception("Error inesperado en SSO callback")
        messages.error(request, "Error inesperado. Intente nuevamente.")
        return redirect("login")


def sso_logout(request):
    """Cierra sesión en Django (Helios). No cierra sesión en Azure AD."""
    logout(request)
    return redirect("login")
