import base64
import hashlib
import logging
import secrets
from urllib.parse import urlencode

import requests
from django.conf import settings
from django.contrib.auth import get_user_model

from .constants import AZURE_AD_ERROR_MESSAGES, DEFAULT_ERROR_MESSAGE

logger = logging.getLogger(__name__)
User = get_user_model()


def generate_pkce_pair() -> tuple[str, str]:
    """
    Generar un par code_verifier y code_challenge para PKCE.

    Returns:
        tuple: (code_verifier, code_challenge)
    """
    # Generar code_verifier aleatorio (43-128 caracteres)
    code_verifier = secrets.token_urlsafe(64)

    # Generar code_challenge usando S256
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    return code_verifier, code_challenge


class AzureADService:
    """Servicio para manejar autenticación con Azure AD via OAuth2/OIDC."""

    def __init__(self):
        self.tenant_id = settings.AZURE_AD_TENANT_ID
        self.client_id = settings.AZURE_AD_CLIENT_ID
        self.client_secret = settings.AZURE_AD_CLIENT_SECRET
        self.redirect_uri = settings.AZURE_AD_REDIRECT_URI
        self.authority_url = settings.AZURE_AD_AUTHORITY_URL
        self.userinfo_url = settings.AZURE_AD_USERINFO_URL
        self.base_url = f"{self.authority_url}/{self.tenant_id}/oauth2/v2.0"

    def get_authorization_url(self, state: str, code_challenge: str = None) -> str:
        """Genera la URL de autorización para redirect a Azure AD."""
        params = {
            "client_id": self.client_id,
            "response_type": "code",
            "redirect_uri": self.redirect_uri,
            "response_mode": "query",
            "scope": "openid profile email",
            "state": state,
        }

        # Agregar PKCE si se proporciona code_challenge
        if code_challenge:
            params["code_challenge"] = code_challenge
            params["code_challenge_method"] = "S256"

        return f"{self.base_url}/authorize?{urlencode(params)}"

    def exchange_code_for_tokens(self, code: str, code_verifier: str = None) -> dict:
        """Intercambia el código de autorización por tokens."""
        token_url = f"{self.base_url}/token"
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "code": code,
            "redirect_uri": self.redirect_uri,
            "grant_type": "authorization_code",
        }

        # Agregar code_verifier para PKCE
        if code_verifier:
            data["code_verifier"] = code_verifier

        response = requests.post(token_url, data=data, timeout=30)

        if response.status_code != 200:
            logger.error(f"Error al obtener tokens: {response.text}")
            error_data = response.json() if response.content else {}
            raise AzureADError(
                error_code=error_data.get("error", "server_error"),
                error_description=error_data.get("error_description", ""),
            )

        return response.json()

    def get_user_info(self, access_token: str) -> dict:
        """Obtiene información del usuario desde MS Graph."""
        headers = {"Authorization": f"Bearer {access_token}"}

        response = requests.get(self.userinfo_url, headers=headers, timeout=30)

        if response.status_code != 200:
            logger.error(f"Error al obtener userinfo: {response.text}")
            raise AzureADError(
                error_code="invalid_token",
                error_description="No se pudo obtener información del usuario.",
            )

        return response.json()


class AzureADError(Exception):
    """Excepción para errores de Azure AD."""

    def __init__(self, error_code: str, error_description: str = ""):
        self.error_code = error_code
        self.error_description = error_description
        self.message = self._get_user_message()
        super().__init__(self.message)

    def _get_user_message(self):
        """Obtiene mensaje amigable para el usuario."""
        # Buscar por código exacto
        if self.error_code in AZURE_AD_ERROR_MESSAGES:
            return AZURE_AD_ERROR_MESSAGES[self.error_code]

        # Buscar códigos AADSTS en la descripción
        for code, message in AZURE_AD_ERROR_MESSAGES.items():
            if code.startswith("AADSTS") and code in self.error_description:
                return message

        return DEFAULT_ERROR_MESSAGE
