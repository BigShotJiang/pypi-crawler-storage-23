from django.urls import path, include

urlpatterns = [
    path('sso/', include('sso.urls', namespace='sso')),
]
