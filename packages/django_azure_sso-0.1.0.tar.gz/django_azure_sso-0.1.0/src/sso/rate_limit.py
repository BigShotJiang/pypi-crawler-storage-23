import hashlib
import logging
from functools import wraps

from django.core.cache import cache
from django.http import HttpResponseForbidden

logger = logging.getLogger(__name__)

# Configuración de rate limiting
MAX_ATTEMPTS = 300
LOCKOUT_DURATION = 300  # 5 minutos en segundos


def get_client_ip(request) -> str:
    """Obtiene la IP real del cliente, considerando proxies."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0].strip()
    else:
        ip = request.META.get('REMOTE_ADDR', 'unknown')
    return ip


def get_rate_limit_key(request) -> str:
    """
    Genera una clave única para rate limiting.
    Combina: IP + User-Agent + Session ID (si existe)
    """
    ip = get_client_ip(request)
    user_agent = request.META.get('HTTP_USER_AGENT', '')[:100]
    session_key = request.session.session_key or 'no-session'

    # Hash para no exponer datos sensibles en la cache key
    raw_key = f'{ip}:{user_agent}:{session_key}'
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()[:32]

    return f'sso_rate_limit:{key_hash}'


def is_rate_limited(request) -> bool:
    """Verifica si el request está bloqueado por rate limiting."""
    key = get_rate_limit_key(request)
    attempts = cache.get(key, 0)
    return attempts >= MAX_ATTEMPTS


def increment_attempts(request) -> int:
    """Incrementa el contador de intentos y retorna el nuevo valor."""
    key = get_rate_limit_key(request)
    attempts = cache.get(key, 0) + 1
    cache.set(key, attempts, LOCKOUT_DURATION)

    if attempts >= MAX_ATTEMPTS:
        ip = get_client_ip(request)
        logger.warning(f'Rate limit alcanzado para IP: {ip}')

    return attempts


def reset_attempts(request):
    """Resetea el contador de intentos (llamar después de login exitoso)."""
    key = get_rate_limit_key(request)
    cache.delete(key)


def get_remaining_attempts(request) -> int:
    """Retorna los intentos restantes."""
    key = get_rate_limit_key(request)
    attempts = cache.get(key, 0)
    return max(0, MAX_ATTEMPTS - attempts)


def rate_limit_sso(view_func):
    """Decorator para aplicar rate limiting a vistas SSO."""

    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if is_rate_limited(request):
            ip = get_client_ip(request)
            logger.warning(f'Intento bloqueado por rate limiting. IP: {ip}')
            return HttpResponseForbidden(
                'Demasiados intentos de inicio de sesión. '
                'Por favor espere 5 minutos antes de intentar nuevamente.'
            )
        return view_func(request, *args, **kwargs)

    return wrapper
