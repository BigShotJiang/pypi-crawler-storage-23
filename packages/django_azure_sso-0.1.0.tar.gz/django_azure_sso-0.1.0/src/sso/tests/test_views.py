from unittest.mock import patch, MagicMock

import pytest
from django.core.cache import cache
from django.urls import clear_url_caches, reverse

from sso.rate_limit import MAX_ATTEMPTS


@pytest.fixture
def sso_settings(settings):
    """Configura settings de Azure AD para tests."""
    settings.SSO_ENABLED = True
    settings.AZURE_AD_TENANT_ID = "test-tenant"
    settings.AZURE_AD_CLIENT_ID = "test-client"
    settings.AZURE_AD_CLIENT_SECRET = "test-secret"
    settings.AZURE_AD_REDIRECT_URI = "http://localhost/sso/callback/"
    settings.AZURE_AD_AUTHORITY_URL = "https://login.microsoftonline.com"
    settings.AZURE_AD_USERINFO_URL = "https://graph.microsoft.com/oidc/userinfo"
    settings.SSO_GET_OR_VALIDATE_USER_METHOD = (
        "sso.tests.mock_user_validator.mock_get_or_validate_user"
    )
    settings.ROOT_URLCONF = "sso.urls_root"
    settings.LOGIN_URL = "/login/"
    clear_url_caches()
    return settings


@pytest.mark.django_db
class TestSsoLogin:
    def test_login_redirects_to_azure(self, client, sso_settings):
        """sso_login redirige a Azure AD con parámetros correctos."""
        response = client.get(reverse("sso:login"))

        assert response.status_code == 302
        assert "login.microsoftonline.com" in response.url
        assert "test-tenant" in response.url
        assert "client_id=test-client" in response.url
        assert "response_type=code" in response.url

    def test_login_stores_state_in_session(self, client, sso_settings):
        """sso_login guarda state en sesión para validación CSRF."""
        client.get(reverse("sso:login"))

        assert "sso_state" in client.session

    def test_login_stores_next_url(self, client, sso_settings):
        """sso_login guarda la URL de redirección."""
        client.get(reverse("sso:login") + "?next=/rrhh/")

        assert client.session.get("sso_next") == "/rrhh/"

    def test_login_rate_limited_after_max_attempts(self, client, sso_settings):
        """sso_login bloquea después de máximos intentos."""
        from sso.rate_limit import MAX_ATTEMPTS

        # Simular intentos fallidos
        with patch("sso.views.increment_attempts") as mock_inc:
            with patch("sso.rate_limit.cache") as mock_cache:
                mock_cache.get.return_value = MAX_ATTEMPTS
                response = client.get(reverse("sso:login"))

        assert response.status_code == 403
        assert "Demasiados intentos" in response.content.decode()


@pytest.mark.django_db
class TestSsoCallback:
    def test_callback_error_from_azure(self, client, sso_settings):
        """callback maneja errores de Azure AD."""
        response = client.get(
            reverse("sso:callback"),
            {"error": "access_denied", "error_description": "User cancelled"},
        )

        assert response.status_code == 302
        assert response.url == reverse("login")

    def test_callback_invalid_state(self, client, sso_settings):
        """callback rechaza state inválido."""
        # Iniciar flujo para generar state válido
        client.get(reverse("sso:login"))

        # Callback con state incorrecto
        response = client.get(
            reverse("sso:callback"),
            {"code": "test-code", "state": "wrong-state"},
        )

        assert response.status_code == 302

    def test_callback_missing_code(self, client, sso_settings):
        """callback rechaza si no hay code."""
        # Iniciar flujo para generar state
        client.get(reverse("sso:login"))
        state = client.session.get("sso_state")

        response = client.get(
            reverse("sso:callback"),
            {"state": state},  # Sin code
        )

        assert response.status_code == 302

    @patch("sso.views.AzureADService")
    def test_callback_user_not_found(self, mock_service_class, client, sso_settings):
        """callback rechaza si el usuario no existe en el sistema."""
        # Setup mock
        mock_service = MagicMock()
        mock_service.get_authorization_url.return_value = (
            "https://login.microsoftonline.com/test"
        )
        mock_service.exchange_code_for_tokens.return_value = {
            "access_token": "test-token"
        }
        mock_service.get_user_info.return_value = {"email": "noexiste@test.com"}
        mock_service_class.return_value = mock_service

        # Iniciar flujo
        client.get(reverse("sso:login"))
        state = client.session.get("sso_state")

        response = client.get(
            reverse("sso:callback"),
            {"code": "test-code", "state": state},
        )

        assert response.status_code == 302
        assert response.url == reverse("login")

    @patch("sso.views.get_user_validator")
    @patch("sso.views.AzureADService")
    def test_callback_successful_login(
        self, mock_service_class, mock_get_user, client, sso_settings, django_user_model
    ):
        """callback inicia sesión correctamente con usuario válido."""
        # Crear usuario
        user = django_user_model.objects.create_user(
            username="testuser",
            email="test@bancorioja.com.ar",
            password="testpass",
            first_name="Test",
            last_name="User",
        )

        # Setup mocks
        mock_service = MagicMock()
        mock_service.get_authorization_url.return_value = (
            "https://login.microsoftonline.com/test"
        )
        mock_service.exchange_code_for_tokens.return_value = {
            "access_token": "test-token"
        }
        mock_service.get_user_info.return_value = {"email": "test@bancorioja.com.ar"}
        mock_service_class.return_value = mock_service
        mock_get_user.return_value = lambda email: user

        # Iniciar flujo
        client.get(reverse("sso:login"))
        state = client.session.get("sso_state")

        response = client.get(
            reverse("sso:callback"),
            {"code": "test-code", "state": state},
        )

        assert response.status_code == 302
        assert response.url == "/"  # Redirect al home

    @patch("sso.views.AzureADService")
    def test_callback_inactive_user_rejected(
        self, mock_service_class, client, sso_settings, django_user_model
    ):
        """callback rechaza usuarios inactivos."""
        # Crear usuario inactivo
        user = django_user_model.objects.create_user(
            username="inactiveuser",
            email="inactive@bancorioja.com.ar",
            password="testpass",
            first_name="Inactive",
            last_name="User",
            is_active=False,
        )

        # Setup mock
        mock_service = MagicMock()
        mock_service.get_authorization_url.return_value = (
            "https://login.microsoftonline.com/test"
        )
        mock_service.exchange_code_for_tokens.return_value = {
            "access_token": "test-token"
        }
        mock_service.get_user_info.return_value = {
            "email": "inactive@bancorioja.com.ar"
        }
        mock_service_class.return_value = mock_service

        # Iniciar flujo
        client.get(reverse("sso:login"))
        state = client.session.get("sso_state")

        response = client.get(
            reverse("sso:callback"),
            {"code": "test-code", "state": state},
        )

        assert response.status_code == 302
        assert response.url == reverse("login")


@pytest.mark.django_db
class TestSsoLogout:
    def test_logout_redirects_to_login(self, client, sso_settings, django_user_model):
        """sso_logout cierra sesión Django y redirige al login."""
        user = django_user_model.objects.create_user(
            username="testuser",
            email="test@test.com",
            password="testpass",
            first_name="Test",
            last_name="User",
        )
        client.force_login(user)

        response = client.get(reverse("sso:logout"))

        assert response.status_code == 302
        assert response.url == reverse("login")


@pytest.mark.django_db
class TestRateLimiting:
    def test_rate_limit_increments_on_failure(self, client, sso_settings):
        """Rate limit incrementa en cada fallo."""

        # Limpiar cache
        cache.clear()

        # Simular errores
        for i in range(2):
            client.get(
                reverse("sso:callback"),
                {"error": "access_denied"},
            )

        # El tercer intento debería seguir pasando (se incrementó a 2)
        response = client.get(reverse("sso:login"))
        assert response.status_code == 302  # Aún no bloqueado

    def test_rate_limit_blocks_after_max_attempts(self, client, sso_settings):
        """Rate limit bloquea después de 3 intentos."""

        # Limpiar cache
        cache.clear()

        # Simular MAX_ATTEMPTS errores
        for i in range(MAX_ATTEMPTS):
            client.get(
                reverse("sso:callback"),
                {"error": "access_denied"},
            )

        # El siguiente intento debería estar bloqueado
        response = client.get(reverse("sso:login"))
        assert response.status_code == 403
