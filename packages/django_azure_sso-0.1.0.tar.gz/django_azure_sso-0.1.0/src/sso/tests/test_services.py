from unittest.mock import patch, MagicMock

import pytest

from sso.constants import AZURE_AD_ERROR_MESSAGES
from sso.services import AzureADError, AzureADService, generate_pkce_pair


class TestGeneratePkcePair:
    def test_generates_code_verifier(self):
        """Genera code_verifier aleatorio."""
        code_verifier, code_challenge = generate_pkce_pair()
        assert len(code_verifier) >= 43
        assert len(code_verifier) <= 128

    def test_generates_code_challenge(self):
        """Genera code_challenge con S256."""
        code_verifier, code_challenge = generate_pkce_pair()
        assert len(code_challenge) > 0
        # code_challenge debe ser base64url sin padding
        assert '=' not in code_challenge

    def test_different_calls_generate_different_pairs(self):
        """Cada llamada genera un par diferente."""
        pair1 = generate_pkce_pair()
        pair2 = generate_pkce_pair()
        assert pair1[0] != pair2[0]


class TestAzureADError:
    def test_error_with_known_code(self):
        """Error con código conocido retorna mensaje en español."""
        error = AzureADError(error_code='AADSTS50105', error_description='')
        assert error.message == AZURE_AD_ERROR_MESSAGES['AADSTS50105']

    def test_error_with_code_in_description(self):
        """Error con código AADSTS en descripción busca en el mensaje."""
        error = AzureADError(
            error_code='unknown_error',
            error_description='AADSTS70043: Token expired',
        )
        assert error.message == AZURE_AD_ERROR_MESSAGES['AADSTS70043']


class TestAzureADService:
    @pytest.fixture
    def service(self, settings):
        settings.AZURE_AD_TENANT_ID = 'test-tenant'
        settings.AZURE_AD_CLIENT_ID = 'test-client'
        settings.AZURE_AD_CLIENT_SECRET = 'test-secret'
        settings.AZURE_AD_REDIRECT_URI = 'http://localhost/callback'
        settings.AZURE_AD_AUTHORITY_URL = 'https://login.microsoftonline.com'
        settings.AZURE_AD_USERINFO_URL = 'https://graph.microsoft.com/oidc/userinfo'
        return AzureADService()

    def test_get_authorization_url(self, service):
        """Genera URL de autorización correctamente."""
        url = service.get_authorization_url(state='test-state')

        assert 'login.microsoftonline.com' in url
        assert 'test-tenant' in url
        assert 'client_id=test-client' in url
        assert 'state=test-state' in url
        assert 'scope=openid+profile+email' in url

    def test_get_authorization_url_with_pkce(self, service):
        """Genera URL de autorización con PKCE."""
        url = service.get_authorization_url(state='test-state', code_challenge='test-challenge')

        assert 'code_challenge=test-challenge' in url
        assert 'code_challenge_method=S256' in url

    @patch('sso.services.requests.post')
    def test_exchange_code_for_tokens_success(self, mock_post, service):
        """Intercambio exitoso de código por tokens."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'access_token': 'test-access-token',
            'id_token': 'test-id-token',
        }
        mock_post.return_value = mock_response

        tokens = service.exchange_code_for_tokens('test-code')

        assert tokens['access_token'] == 'test-access-token'

    @patch('sso.services.requests.post')
    def test_exchange_code_for_tokens_error(self, mock_post, service):
        """Error al intercambiar código."""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.content = b'{"error": "invalid_grant"}'
        mock_response.json.return_value = {'error': 'invalid_grant'}
        mock_response.text = 'Error'
        mock_post.return_value = mock_response

        with pytest.raises(AzureADError) as exc_info:
            service.exchange_code_for_tokens('invalid-code')

        assert exc_info.value.error_code == 'invalid_grant'

    @patch('sso.services.requests.get')
    def test_get_user_info_success(self, mock_get, service):
        """Obtención exitosa de user info."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'email': 'test@example.com',
            'name': 'Test User',
        }
        mock_get.return_value = mock_response

        user_info = service.get_user_info('test-token')

        assert user_info['email'] == 'test@example.com'
