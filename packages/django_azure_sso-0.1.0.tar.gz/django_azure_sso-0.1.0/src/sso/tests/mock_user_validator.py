def mock_get_or_validate_user(email: str):
    """
    Función mock para testing. Debe configurarse en SSO_GET_OR_VALIDATE_USER_METHOD.
    """
    from django.contrib.auth import get_user_model
    User = get_user_model()
    try:
        return User.objects.get(email__iexact=email, is_active=True)
    except User.DoesNotExist:
        return None
    except User.MultipleObjectsReturned:
        return User.objects.filter(email__iexact=email, is_active=True).first()
