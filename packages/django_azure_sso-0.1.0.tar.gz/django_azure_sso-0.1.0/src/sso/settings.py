import os

SECRET_KEY = "test-secret-key-for-testing-only"

DEBUG = True

ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "sso",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": ":memory:",
    }
}

AUTH_USER_MODEL = "auth.User"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

USE_TZ = True

ROOT_URLCONF = "sso.urls_root"

LOGIN_URL = "/login/"
LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/login/"

SSO_ENABLED = True
AZURE_AD_TENANT_ID = "test-tenant"
AZURE_AD_CLIENT_ID = "test-client"
AZURE_AD_CLIENT_SECRET = "test-secret"
AZURE_AD_REDIRECT_URI = "http://localhost/sso/callback/"
AZURE_AD_AUTHORITY_URL = "https://login.microsoftonline.com"
AZURE_AD_USERINFO_URL = "https://graph.microsoft.com/oidc/userinfo"
SSO_GET_OR_VALIDATE_USER_METHOD = "sso.services.get_or_validate_user"
