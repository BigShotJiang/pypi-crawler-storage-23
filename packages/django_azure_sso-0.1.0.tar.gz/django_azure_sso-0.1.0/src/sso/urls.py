from django.urls import path

from . import views

app_name = 'sso'

urlpatterns = [
    path('login/', views.sso_login, name='login'),
    path('callback/', views.sso_callback, name='callback'),
    path('logout/', views.sso_logout, name='logout'),
]
