# Mapeo de códigos de error Azure AD a mensajes en español
AZURE_AD_ERROR_MESSAGES = {
    'AADSTS50105': 'No tiene acceso a la aplicación. Contacte al administrador.',
    'AADSTS70043': 'Su sesión ha expirado. Intente iniciar sesión nuevamente.',
    'AADSTS53003': 'Acceso bloqueado por políticas de seguridad.',
    'AADSTS65004': 'El usuario rechazó el consentimiento para acceder a la aplicación.',
    'AADSTS70011': 'Solicitud inválida. El scope solicitado no es válido.',
    'AADSTS700016': 'Aplicación no encontrada en el directorio.',
    'AADSTS7000218': 'El cuerpo de la solicitud debe contener client_assertion o client_secret.',
    'invalid_token': 'Token inválido. Intente iniciar sesión nuevamente.',
    'access_denied': 'Acceso denegado.',
    'invalid_request': 'Solicitud inválida.',
    'unauthorized_client': 'Cliente no autorizado.',
    'invalid_client': 'Credenciales de cliente inválidas.',
    'invalid_grant': 'El código de autorización ha expirado o es inválido.',
    'server_error': 'Error del servidor. Intente nuevamente más tarde.',
}

DEFAULT_ERROR_MESSAGE = 'Error de autenticación. Intente nuevamente o contacte al administrador.'
