import itertools

ENGINE_ID_COUNTER = itertools.count()
