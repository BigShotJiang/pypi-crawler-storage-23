"""
BiasClear client exceptions.

Hierarchy:
    BiasClearError
    ├── AuthError          (401)
    ├── RateLimitError     (429)
    └── ServerError        (5xx)
"""

from __future__ import annotations


class BiasClearError(Exception):
    """Base exception for all BiasClear client errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthError(BiasClearError):
    """401 — Invalid or missing API key."""

    def __init__(self, message: str = "Invalid or missing API key."):
        super().__init__(message, status_code=401)


class RateLimitError(BiasClearError):
    """429 — Rate limit exceeded."""

    def __init__(self, message: str, retry_after: int | None = None):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ServerError(BiasClearError):
    """5xx — Server-side error."""

    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message, status_code=status_code)
