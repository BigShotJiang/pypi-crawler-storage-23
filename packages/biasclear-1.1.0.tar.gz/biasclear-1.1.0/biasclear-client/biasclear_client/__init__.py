"""
BiasClear Client SDK

Typed Python client for the BiasClear API.

Usage:
    from biasclear_client import Client
    bc = Client(base_url="http://localhost:8100", api_key="sk-...")
    result = bc.scan("text to analyze", domain="legal")
"""

from biasclear_client.client import Client
from biasclear_client.exceptions import (
    BiasClearError,
    AuthError,
    RateLimitError,
    ServerError,
)
from biasclear_client.models import (
    ScanResult,
    CorrectionResult,
    PatternsResult,
    AuditResult,
    Flag,
    AuditEntry,
    ChainIntegrity,
)

__version__ = "1.0.0"

__all__ = [
    "Client",
    "BiasClearError",
    "AuthError",
    "RateLimitError",
    "ServerError",
    "ScanResult",
    "CorrectionResult",
    "PatternsResult",
    "AuditResult",
    "Flag",
    "AuditEntry",
    "ChainIntegrity",
]
