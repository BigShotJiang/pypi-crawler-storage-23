# BiasClear

**Structural bias detection and correction engine built on Persistent Influence Theory (PIT).**

BiasClear identifies and corrects structural bias in text — not surface-level sentiment, but the deeper patterns that shape how information is framed, weighted, and presented. It uses a frozen ethics core (immutable code, not tunable weights) to evaluate text against epistemological principles.

## Features

- **Scan** — Detect structural bias patterns (framing, anchoring, authority, omission, false equivalence)
- **Correct** — Generate debiased alternatives with inline diffs
- **Score** — Calculate truth alignment scores based on PIT principles
- **Audit** — SHA-256 blockchain audit chain for every evaluation
- **Frozen Ethics Core** — Immutable governance engine that cannot be prompt-injected

## Quick Start

```bash
# Install
pip install -e .

# CLI usage
biasclear scan "The data clearly proves that this approach is the only viable option."
biasclear correct "Studies overwhelmingly show..."

# API server
pip install -e ".[api]"
uvicorn biasclear.api:app --port 8100
```

## Architecture

```
biasclear/
├── frozen_core.py    # Immutable ethics engine (PIT-based)
├── detector.py       # Bias pattern detection
├── corrector.py      # Bias correction with diffs
├── scorer.py         # Truth alignment scoring
├── audit.py          # SHA-256 audit chain
├── api.py            # FastAPI server
├── cli.py            # Command-line interface
└── demo.html         # Interactive demo page
```

## Client SDK

A Python client SDK for consuming the BiasClear API is included in `biasclear-client/`:

```bash
pip install -e ./biasclear-client
```

```python
from biasclear_client import BiasClearClient

client = BiasClearClient(base_url="http://localhost:8100", api_key="your-key")
result = client.scan("The data clearly shows...")
print(result.flags)
```

See [biasclear-client/README.md](biasclear-client/README.md) for full SDK documentation.

## License

AGPL-3.0 — See [LICENSE](LICENSE) for details.

The client SDK (`biasclear-client/`) is licensed under MIT for unrestricted integration.
