from collections.abc import Callable
from functools import partial
from pathlib import Path

import anyio
import anyio.to_thread
import httpx
import structlog
from pydantic import BaseModel

from runlayer_cli.api import RunlayerClient, SkillDetail
from runlayer_cli.skills.discovery import discover_skills
from runlayer_cli.skills.models import DiscoveredSkill

logger = structlog.get_logger(__name__)

_MAX_CONCURRENT = 10


class SyncResult(BaseModel):
    created: int = 0
    updated: int = 0
    unchanged: int = 0
    deleted: int = 0
    errors: list[str] = []


def _create_file_ignore_409(
    client: RunlayerClient, skill_id: str, title: str, content: str
) -> None:
    try:
        client.create_skill_file(skill_id, title=title, content=content)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 409:
            logger.warning("file_conflict_on_create", title=title, skill_id=skill_id)
        else:
            raise


async def _async_sync_skill_files(
    client: RunlayerClient,
    skill_id: str,
    skill: DiscoveredSkill,
    remote_file_ids: dict[str, str],
    limiter: anyio.CapacityLimiter,
) -> None:
    local_files = {f.title: f for f in skill.files}

    async def _sync_one(title: str, content: str) -> None:
        async with limiter:
            if title in remote_file_ids:
                await anyio.to_thread.run_sync(
                    partial(
                        client.update_skill_file,
                        skill_id,
                        remote_file_ids[title],
                        content=content,
                    )
                )
            else:
                await anyio.to_thread.run_sync(
                    partial(
                        _create_file_ignore_409,
                        client,
                        skill_id,
                        title,
                        content,
                    )
                )

    async with anyio.create_task_group() as tg:
        for title, local_file in local_files.items():
            tg.start_soon(_sync_one, title, local_file.content)


async def _async_sync_one_update(
    client: RunlayerClient,
    skill_id: str,
    skill: DiscoveredSkill,
    dry_run: bool,
    limiter: anyio.CapacityLimiter,
) -> bool | None:
    try:
        async with limiter:
            remote = await anyio.to_thread.run_sync(partial(client.get_skill, skill_id))
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return None
        raise

    changed = False

    if remote.name != skill.name or remote.description != skill.description:
        if not dry_run:
            async with limiter:
                await anyio.to_thread.run_sync(
                    partial(
                        client.update_skill,
                        skill_id,
                        name=skill.name,
                        description=skill.description,
                    )
                )
        changed = True

    remote_files = {f.title: f for f in remote.files}
    local_files = {f.title: f for f in skill.files}

    # Phase 1: fetch remote file contents in parallel
    fetched: dict[str, object] = {}

    async def _fetch(title: str, file_id: str) -> None:
        async with limiter:
            result = await anyio.to_thread.run_sync(
                partial(client.get_skill_file, skill_id, file_id)
            )
        fetched[title] = result

    async with anyio.create_task_group() as tg:
        for title in local_files:
            if title in remote_files:
                tg.start_soon(_fetch, title, remote_files[title].id)

    # Phase 2: compute diffs, then mutate in parallel
    async def _update_file(file_id: str, content: str) -> None:
        async with limiter:
            await anyio.to_thread.run_sync(
                partial(
                    client.update_skill_file,
                    skill_id,
                    file_id,
                    content=content,
                )
            )

    async def _create_file(title: str, content: str) -> None:
        async with limiter:
            await anyio.to_thread.run_sync(
                partial(
                    client.create_skill_file,
                    skill_id,
                    title=title,
                    content=content,
                )
            )

    async def _delete_file(file_id: str) -> None:
        async with limiter:
            await anyio.to_thread.run_sync(
                partial(client.delete_skill_file, skill_id, file_id)
            )

    async with anyio.create_task_group() as tg:
        for title, local_file in local_files.items():
            if title in fetched:
                if fetched[title].content != local_file.content:  # type: ignore[union-attr]
                    if not dry_run:
                        tg.start_soon(
                            _update_file, remote_files[title].id, local_file.content
                        )
                    changed = True
            else:
                if not dry_run:
                    tg.start_soon(_create_file, title, local_file.content)
                changed = True

        for title, remote_file in remote_files.items():
            if title not in local_files:
                if not dry_run:
                    tg.start_soon(_delete_file, remote_file.id)
                changed = True

    return changed


def _process_delete(
    client: RunlayerClient, skill_id: str, name: str, dry_run: bool
) -> tuple[str, str | None]:
    log = logger.bind(name=name)
    try:
        if dry_run:
            log.debug("would_delete", skill_id=skill_id)
        else:
            client.delete_skill(skill_id)
            log.debug("deleted", skill_id=skill_id)
        return "deleted", None
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            log.debug("skill_already_gone", skill_id=skill_id)
            return "gone", None
        return "error", f"{name}: {e}"
    except Exception as e:
        return "error", f"{name}: {e}"


async def _retry_as_update(
    client: RunlayerClient,
    skill: DiscoveredSkill,
    namespace: str,
    dry_run: bool,
    limiter: anyio.CapacityLimiter,
) -> tuple[str, str | None]:
    """Re-fetch skills and update when create returned 409 (race condition)."""
    remote_skills = await anyio.to_thread.run_sync(
        partial(client.list_skills, namespace=namespace)
    )
    existing = next((s for s in remote_skills if s.path == skill.path), None)
    if not existing:
        return "error", f"{skill.name}: skill conflict but not found on retry"
    changed = await _async_sync_one_update(
        client, existing.id, skill, dry_run=dry_run, limiter=limiter
    )
    if changed:
        return "updated", existing.id
    return "unchanged", existing.id


async def _async_process_sync(
    client: RunlayerClient,
    skill: DiscoveredSkill,
    namespace: str,
    remote: SkillDetail | None,
    dry_run: bool,
    limiter: anyio.CapacityLimiter,
) -> tuple[str, str | None]:
    log = logger.bind(name=skill.name)
    try:
        if remote:
            changed = await _async_sync_one_update(
                client, remote.id, skill, dry_run=dry_run, limiter=limiter
            )
            if changed is None:
                log.debug("skill_not_found_recreating", old_id=remote.id)
                if dry_run:
                    return "created", None
                async with limiter:
                    new_id, remote_file_ids = await anyio.to_thread.run_sync(
                        partial(_create_skill_remote, client, skill, namespace)
                    )
                await _async_sync_skill_files(
                    client, new_id, skill, remote_file_ids, limiter
                )
                return "created", new_id
            elif changed:
                return "updated", remote.id
            else:
                return "unchanged", remote.id
        else:
            if dry_run:
                log.debug("would_create")
                return "created", None

            try:
                async with limiter:
                    new_id, remote_file_ids = await anyio.to_thread.run_sync(
                        partial(_create_skill_remote, client, skill, namespace)
                    )
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 409:
                    log.info("skill_conflict_retrying_as_update", path=skill.path)
                    return await _retry_as_update(
                        client, skill, namespace, dry_run, limiter
                    )
                raise
            await _async_sync_skill_files(
                client, new_id, skill, remote_file_ids, limiter
            )
            return "created", new_id
    except Exception as e:
        log.error("sync_error", error=str(e))
        return "error", f"{skill.name}: {e}"


def _create_skill_remote(
    client: RunlayerClient, skill: DiscoveredSkill, namespace: str
) -> tuple[str, dict[str, str]]:
    remote = client.create_skill(
        name=skill.name,
        description=skill.description,
        namespace=namespace,
        path=skill.path,
    )
    return remote.id, {f.title: f.id for f in remote.files}


async def sync_skills(
    root: Path,
    client: RunlayerClient,
    namespace: str,
    dry_run: bool = False,
    prune: bool = False,
    on_progress: Callable[[str, str], None] | None = None,
) -> SyncResult:
    discovered = discover_skills(root)
    remote_skills = client.list_skills(namespace=namespace)
    remote_by_path: dict[str, SkillDetail] = {
        s.path: s for s in remote_skills if s.path
    }

    result = SyncResult()
    discovered_paths: set[str] = set()
    limiter = anyio.CapacityLimiter(_MAX_CONCURRENT)

    async def _handle_sync(skill: DiscoveredSkill) -> None:
        existing = remote_by_path.get(skill.path)
        status, _ = await _async_process_sync(
            client, skill, namespace, existing, dry_run, limiter
        )
        if status == "created":
            result.created += 1
        elif status == "updated":
            result.updated += 1
        elif status == "unchanged":
            result.unchanged += 1
        elif status == "error" and _:
            result.errors.append(_)
        if on_progress:
            on_progress(skill.path, status)

    async def _handle_delete(name: str, remote: SkillDetail) -> None:
        async with limiter:
            status, error = await anyio.to_thread.run_sync(
                partial(_process_delete, client, remote.id, name, dry_run)
            )
        if status == "deleted":
            result.deleted += 1
        elif error:
            result.errors.append(error)
        if on_progress:
            on_progress(name, status)

    async with anyio.create_task_group() as tg:
        for skill in discovered:
            discovered_paths.add(skill.path)
            tg.start_soon(_handle_sync, skill)

        if prune:
            for path, remote in remote_by_path.items():
                if path not in discovered_paths:
                    tg.start_soon(_handle_delete, path, remote)

    return result
