"""Manage named organization API keys stored in CLI config."""

from typing import Optional

import typer

from runlayer_cli.config import load_config, normalize_url, save_config

app = typer.Typer(help="Manage stored organization API keys")


def _resolve_host(ctx: typer.Context, host: Optional[str]) -> str:
    """Resolve effective host from flag, context chain, or config default."""
    # Walk context chain to pick up global --host from root callback
    if not host:
        current = ctx.parent
        while current:
            if current.obj and current.obj.get("host"):
                host = current.obj["host"]
                break
            current = current.parent

    config = load_config()
    effective = host or config.default_host
    if not effective:
        typer.secho(
            "Error: No host configured. "
            "Please provide --host or run 'runlayer login --host <url>' first.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(1)
    return normalize_url(effective)


@app.command()
def add(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Name to reference this key by"),
    secret: str = typer.Option(
        ...,
        "--secret",
        "-s",
        prompt="Org API key",
        hide_input=True,
        help="The org API key value (rl_org_...)",
    ),
    host: Optional[str] = typer.Option(
        None,
        "--host",
        "-H",
        help="Host to store the key for (defaults to current host)",
    ),
) -> None:
    """Store a named org API key for the current host."""
    effective_host = _resolve_host(ctx, host)
    config = load_config()
    try:
        config.set_org_api_key(effective_host, name, secret)
    except ValueError as exc:
        typer.secho(f"Error: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1) from None
    save_config(config)
    typer.secho(
        f"Org API key '{name}' saved for {effective_host}.",
        fg=typer.colors.GREEN,
        err=True,
    )


@app.command()
def remove(
    ctx: typer.Context,
    name: str = typer.Argument(..., help="Name of the key to remove"),
    host: Optional[str] = typer.Option(
        None,
        "--host",
        "-H",
        help="Host to remove the key from (defaults to current host)",
    ),
) -> None:
    """Remove a stored org API key."""
    effective_host = _resolve_host(ctx, host)
    config = load_config()
    if config.remove_org_api_key(effective_host, name):
        save_config(config)
        typer.secho(
            f"Org API key '{name}' removed for {effective_host}.",
            fg=typer.colors.GREEN,
            err=True,
        )
    else:
        typer.secho(
            f"No org API key '{name}' found for {effective_host}.",
            fg=typer.colors.YELLOW,
            err=True,
        )


@app.command(name="list")
def list_keys(
    ctx: typer.Context,
    host: Optional[str] = typer.Option(
        None,
        "--host",
        "-H",
        help="Host to list keys for (defaults to current host)",
    ),
) -> None:
    """List stored org API key names for the current host."""
    effective_host = _resolve_host(ctx, host)
    config = load_config()
    keys = config.list_org_api_keys(effective_host)
    if not keys:
        typer.echo(f"No org API keys stored for {effective_host}.", err=True)
        return
    typer.echo(f"Org API keys for {effective_host}:", err=True)
    for name, prefix in keys.items():
        typer.echo(f"  {name}: {prefix}", err=True)
