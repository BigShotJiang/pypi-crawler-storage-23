from pathlib import Path

import anyio
import structlog
import typer

from runlayer_cli.api import RunlayerClient
from runlayer_cli.config import resolve_credentials, set_credentials_in_context
from runlayer_cli.logging import setup_logging
from runlayer_cli.skills.sync_engine import SyncResult, sync_skills

logger = structlog.get_logger(__name__)

app = typer.Typer(help="Manage skills")


def _print_error(message: str, log_file_path: str) -> None:
    typer.secho(f"Error: {message}", fg=typer.colors.RED, err=True)
    typer.secho(
        f"See logs for details: {log_file_path}", fg=typer.colors.YELLOW, err=True
    )


@app.command()
def push(
    ctx: typer.Context,
    path: str = typer.Argument(".", help="Root directory"),
    namespace: str = typer.Option(
        ..., "--namespace", "-N", help="Namespace for matching skills on the server"
    ),
    secret: str | None = typer.Option(
        None, "--secret", "-s", envvar="RUNLAYER_API_KEY"
    ),
    host: str | None = typer.Option(None, "--host", "-H", envvar="RUNLAYER_HOST"),
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    prune: bool = typer.Option(
        False, "--prune", help="Remove skills from API whose directories were removed"
    ),
) -> None:
    """Push skills to Runlayer API."""
    root = Path(path).resolve()

    log_file_path = setup_logging(command="skills-push", quiet_console=False)

    set_credentials_in_context(ctx, secret, host)
    credentials = resolve_credentials(ctx, require_auth=not dry_run)

    try:
        client = RunlayerClient(
            hostname=credentials["host"], secret=credentials["secret"]
        )

        def on_progress(skill_path: str, status: str) -> None:
            typer.echo(f"  {skill_path}: {status}")

        async def _run() -> SyncResult:
            return await sync_skills(
                root,
                client,
                namespace=namespace,
                dry_run=dry_run,
                prune=prune,
                on_progress=on_progress,
            )

        result = anyio.run(_run)

        if dry_run:
            typer.secho("[dry run] ", fg=typer.colors.YELLOW, nl=False)

        typer.echo(
            f"Sync complete: {result.created} created, "
            f"{result.updated} updated, {result.unchanged} unchanged, "
            f"{result.deleted} deleted"
        )
        if result.errors:
            for err in result.errors:
                typer.secho(f"  Error: {err}", fg=typer.colors.RED, err=True)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("push_failed", error=str(e), exc_info=True)
        _print_error(str(e), str(log_file_path))
        raise typer.Exit(1)
