"""Tests for runlayer_cli.verified_local_proxy."""
