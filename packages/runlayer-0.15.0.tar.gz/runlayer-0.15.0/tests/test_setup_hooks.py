"""Tests for the setup hooks command."""

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from runlayer_cli.commands.setup import (
    Client,
    _install_cursorignore,
    _migrate_user_to_enterprise,
    _uninstall_cursorignore,
)
from runlayer_cli.main import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Strip ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1b\[[0-9;]*m")
    return ansi_escape.sub("", text)


def test_setup_hooks_help():
    """Test that setup hooks command shows help."""
    result = runner.invoke(app, ["setup", "hooks", "--help"])
    assert result.exit_code == 0
    plain_output = strip_ansi(result.stdout)
    assert "Install or uninstall Runlayer client hooks" in plain_output
    assert "--install" in plain_output
    assert "--uninstall" in plain_output
    assert "--host" in plain_output
    assert "--yes" in plain_output
    assert "--mdm" in plain_output
    assert "cursor" in plain_output.lower()


def test_setup_hooks_requires_action():
    """Test that setup hooks command requires --install or --uninstall."""
    result = runner.invoke(
        app,
        ["setup", "hooks", "--client", "cursor"],
    )
    assert result.exit_code != 0
    plain_output = strip_ansi(result.output)
    assert "Must specify either --install or --uninstall" in plain_output


def test_setup_hooks_install_uninstall_mutually_exclusive():
    """Test that --install and --uninstall cannot be used together."""
    result = runner.invoke(
        app,
        [
            "setup",
            "hooks",
            "--client",
            "cursor",
            "--install",
            "--uninstall",
        ],
    )
    assert result.exit_code != 0
    plain_output = strip_ansi(result.output)
    assert "Cannot use both --install and --uninstall" in plain_output


def test_setup_hooks_install_requires_config():
    """Test that --install requires config.yaml to exist."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--yes",
                ],
            )
            assert result.exit_code != 0
            plain_output = strip_ansi(result.output)
            assert "No Runlayer config found" in plain_output


def test_setup_hooks_install():
    """Test that --install installs hook files with static script."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        # Create config.yaml
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--yes",
                ],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "Hooks installed" in plain_output
            assert "Restart Cursor" in plain_output

            hook_script = client_dir / "hooks" / "runlayer-hook.sh"
            assert hook_script.exists()

            # Verify hook script is static (no baked-in credentials)
            hook_content = hook_script.read_text()
            assert "__RUNLAYER_API_KEY__" not in hook_content
            assert "__RUNLAYER_API_HOST__" not in hook_content
            assert "beforeMCPExecution" in hook_content
            assert "beforeReadFile" in hook_content

            # Verify hooks.json has both hook types
            hooks_json = client_dir / "hooks.json"
            assert hooks_json.exists()
            hooks_config = json.loads(hooks_json.read_text())
            assert hooks_config["version"] == 1
            assert "beforeMCPExecution" in hooks_config["hooks"]
            assert "beforeReadFile" in hooks_config["hooks"]
            assert (
                str(hook_script)
                in hooks_config["hooks"]["beforeMCPExecution"][0]["command"]
            )
            assert (
                str(hook_script)
                in hooks_config["hooks"]["beforeReadFile"][0]["command"]
            )


def test_setup_hooks_install_all_clients():
    """Test that setup hooks installs to all clients when --client is not specified."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--install",
                    "--yes",
                ],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "Hooks installed" in plain_output

            hook_script = client_dir / "hooks" / "runlayer-hook.sh"
            assert hook_script.exists()


def test_setup_hooks_install_creates_backup():
    """Test that --install backs up existing files."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        # Create existing files
        existing_hook = hooks_dir / "runlayer-hook.sh"
        existing_hook.write_text("# existing hook")
        existing_json = client_dir / "hooks.json"
        existing_json.write_text('{"version": 0}')

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--yes",
                ],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "Backed up" in plain_output

            # Verify backup files were created
            backup_files = list(hooks_dir.glob("runlayer-hook.backup_*.sh"))
            assert len(backup_files) == 1
            assert backup_files[0].read_text() == "# existing hook"

            json_backups = list(client_dir.glob("hooks.backup_*.json"))
            assert len(json_backups) == 1
            assert json_backups[0].read_text() == '{"version": 0}'


def test_setup_hooks_install_validates_host_in_config():
    """Test that --host validates the host exists in config."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        from runlayer_cli.config import Config, HostConfig

        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": HostConfig(
                    url="https://app.runlayer.com", secret="test-key"
                )
            },
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
            patch("runlayer_cli.config.load_config", return_value=config),
        ):
            # Unknown host should fail
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--yes",
                    "--host",
                    "https://unknown.example.com",
                ],
            )
            assert result.exit_code != 0
            plain_output = strip_ansi(result.output)
            assert "not found in config" in plain_output


def test_setup_hooks_install_mdm():
    """Test that --mdm installs to enterprise location."""
    with tempfile.TemporaryDirectory() as temp_dir:
        enterprise_dir = Path(temp_dir) / "enterprise"
        user_dir = Path(temp_dir) / ".cursor"

        with (
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: user_dir},
            ),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--mdm",
                    "--yes",
                ],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "Hooks installed" in plain_output

            # Verify installed to enterprise location
            hook_script = enterprise_dir / "hooks" / "runlayer-hook.sh"
            assert hook_script.exists()
            hooks_json = enterprise_dir / "hooks.json"
            assert hooks_json.exists()


def test_setup_hooks_install_quotes_path_with_spaces():
    """Test that hooks.json quotes the command when path has spaces."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # Simulate enterprise path with spaces (like /Library/Application Support/Cursor/)
        enterprise_dir = Path(temp_dir) / "Library" / "Application Support" / "Cursor"
        user_dir = Path(temp_dir) / ".cursor"

        with (
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: user_dir},
            ),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--mdm",
                    "--yes",
                ],
            )

            assert result.exit_code == 0
            hooks_json = enterprise_dir / "hooks.json"
            hooks_config = json.loads(hooks_json.read_text())
            command = hooks_config["hooks"]["beforeMCPExecution"][0]["command"]
            # Path with spaces must be quoted
            assert command.startswith('"')
            assert command.endswith('"')
            assert "Application Support" in command


def test_setup_hooks_install_mdm_skips_config_check():
    """Test that --mdm skips config.yaml check (runs as root)."""
    with tempfile.TemporaryDirectory() as temp_dir:
        enterprise_dir = Path(temp_dir) / "enterprise"
        user_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "root_home"
        fake_home.mkdir()
        # No config.yaml exists -- should still succeed with --mdm

        with (
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: user_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--mdm",
                    "--yes",
                ],
            )

            assert result.exit_code == 0
            hook_script = enterprise_dir / "hooks" / "runlayer-hook.sh"
            assert hook_script.exists()


def test_setup_hooks_uninstall():
    """Test that --uninstall removes hook files."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"

        # Create hook files
        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho test")
        hooks_json = client_dir / "hooks.json"
        hooks_json.write_text('{"version": 1}')

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--client", "cursor", "--uninstall", "--yes"],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "Removed" in plain_output
            assert "runlayer-hook.sh" in plain_output
            assert "hooks.json" in plain_output
            assert "Restart Cursor" in plain_output

            assert not hook_script.exists()
            assert not hooks_json.exists()


def test_setup_hooks_uninstall_no_files():
    """Test --uninstall when no hooks are installed."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        client_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--client", "cursor", "--uninstall", "--yes"],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "No Runlayer hooks found" in plain_output


def test_setup_hooks_uninstall_all_clients():
    """Test that --uninstall removes hooks from all clients."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"

        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho test")
        hooks_json = client_dir / "hooks.json"
        hooks_json.write_text('{"version": 1}')

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--uninstall", "--yes"],
            )

            plain_output = strip_ansi(result.stdout)
            assert result.exit_code == 0
            assert "runlayer-hook.sh" in plain_output
            assert not hook_script.exists()
            assert not hooks_json.exists()


def test_setup_hooks_uninstall_permission_error_enterprise():
    """Test --uninstall handles PermissionError on enterprise files gracefully."""
    with tempfile.TemporaryDirectory() as temp_dir:
        # User-level hooks
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho test")
        hooks_json = client_dir / "hooks.json"
        hooks_json.write_text('{"version": 1}')

        # Enterprise-level hooks
        enterprise_dir = Path(temp_dir) / "enterprise"
        ent_hooks_dir = enterprise_dir / "hooks"
        ent_hooks_dir.mkdir(parents=True)
        ent_hook_script = ent_hooks_dir / "runlayer-hook.sh"
        ent_hook_script.write_text("#!/bin/bash\necho enterprise")
        ent_hooks_json = enterprise_dir / "hooks.json"
        ent_hooks_json.write_text('{"version": 1}')

        original_unlink = Path.unlink

        def guarded_unlink(self, *args, **kwargs):
            if str(self).startswith(str(enterprise_dir)):
                raise PermissionError(13, "Permission denied", str(self))
            return original_unlink(self, *args, **kwargs)

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
            patch.object(Path, "unlink", guarded_unlink),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--client", "cursor", "--uninstall", "--yes"],
            )

            plain_output = strip_ansi(result.output)
            assert result.exit_code == 0
            # User-level hooks should be removed
            assert not hook_script.exists()
            assert not hooks_json.exists()
            # Enterprise files remain (permission denied)
            assert ent_hook_script.exists()
            assert ent_hooks_json.exists()
            # Should warn about enterprise permission issue
            assert "permission denied" in plain_output.lower()
            # cursorignore cleanup should still run (not skipped by crash)
            assert "Runlayer hooks removed" in plain_output


def test_setup_hooks_install_prompts_without_yes():
    """Test that --install prompts for confirmation without --yes."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                ],
                input="n\n",
            )

            plain_output = strip_ansi(result.output)
            assert result.exit_code == 0
            assert "Proceed with installation?" in plain_output
            assert "Aborted" in plain_output

            hook_script = client_dir / "hooks" / "runlayer-hook.sh"
            assert not hook_script.exists()


def test_setup_hooks_install_confirms_with_prompt():
    """Test that --install proceeds when user confirms."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: test-key\n"
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                ],
                input="y\n",
            )

            plain_output = strip_ansi(result.output)
            assert result.exit_code == 0
            assert "Hooks installed" in plain_output

            hook_script = client_dir / "hooks" / "runlayer-hook.sh"
            assert hook_script.exists()


def test_setup_hooks_uninstall_prompts_without_yes():
    """Test that --uninstall prompts for confirmation without --yes."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"

        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho test")

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--client", "cursor", "--uninstall"],
                input="n\n",
            )

            plain_output = strip_ansi(result.output)
            assert result.exit_code == 0
            assert "Proceed with uninstallation?" in plain_output
            assert "Aborted" in plain_output

            assert hook_script.exists()


def test_setup_hooks_invalid_client():
    """Test that setup hooks command rejects invalid client."""
    result = runner.invoke(
        app,
        [
            "setup",
            "hooks",
            "--client",
            "invalid-client",
            "--install",
            "--yes",
        ],
    )
    assert result.exit_code != 0


def test_setup_hooks_deprecated_secret_saves_config():
    """Test that deprecated --secret saves to config.yaml."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()
        runlayer_dir = fake_home / ".runlayer"
        runlayer_dir.mkdir()
        (runlayer_dir / "config.yaml").write_text(
            "default_host: https://app.runlayer.com\nhosts:\n  app.runlayer.com:\n    url: https://app.runlayer.com\n    secret: old-key\n"
        )

        from runlayer_cli.config import Config, HostConfig

        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": HostConfig(
                    url="https://app.runlayer.com", secret="old-key"
                )
            },
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
            patch("runlayer_cli.config.load_config", return_value=config),
            patch("runlayer_cli.config.save_config") as mock_save,
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--yes",
                    "--secret",
                    "new-key",
                    "--host",
                    "https://app.runlayer.com",
                ],
            )

            assert result.exit_code == 0
            plain_output = strip_ansi(result.output)
            assert "deprecated" in plain_output.lower()
            mock_save.assert_called_once()


# =============================================================================
# _install_cursorignore tests
# =============================================================================


def test_install_cursorignore_creates_new_file():
    """Test creating ~/.cursorignore from scratch."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _install_cursorignore()

        path = fake_home / ".cursorignore"
        assert path.exists()
        content = path.read_text()
        assert "# >>> Runlayer managed" in content
        assert ".env" in content
        assert "mcp.json" in content


def test_install_cursorignore_appends_to_existing():
    """Test appending to existing ~/.cursorignore."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)
        path = fake_home / ".cursorignore"
        path.write_text("# my custom ignores\nnode_modules/\n")

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _install_cursorignore()

        content = path.read_text()
        assert "# my custom ignores" in content
        assert "node_modules/" in content
        assert "# >>> Runlayer managed" in content
        assert ".env" in content


def test_install_cursorignore_idempotent_update():
    """Test that running twice replaces the managed block."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _install_cursorignore()
            _install_cursorignore()

        path = fake_home / ".cursorignore"
        content = path.read_text()
        # Should only appear once
        assert content.count("# >>> Runlayer managed") == 1
        # .env appears twice: once as ".env" line, once in ".env.*"
        assert content.count("# <<< Runlayer managed") == 1


# =============================================================================
# _migrate_user_to_enterprise tests
# =============================================================================


def test_migrate_removes_user_hooks():
    """Test that MDM migration removes user-level hooks."""
    with tempfile.TemporaryDirectory() as temp_dir:
        user_dir = Path(temp_dir) / ".cursor"
        hooks_dir = user_dir / "hooks"
        hooks_dir.mkdir(parents=True)

        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho hook")
        hooks_json = user_dir / "hooks.json"
        hooks_json.write_text(
            json.dumps(
                {
                    "version": 1,
                    "hooks": {"beforeMCPExecution": [{"command": str(hook_script)}]},
                }
            )
        )

        with patch.dict(
            "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
            {Client.CURSOR: user_dir},
        ):
            _migrate_user_to_enterprise(Client.CURSOR)

        assert not hook_script.exists()
        assert not hooks_json.exists()
        # Backups should exist
        assert len(list(hooks_dir.glob("runlayer-hook.backup_*.sh"))) == 1
        assert len(list(user_dir.glob("hooks.backup_*.json"))) == 1


def test_migrate_removes_user_hooks_jsonc():
    """Test that MDM migration handles JSONC hooks.json (comments, trailing commas)."""
    with tempfile.TemporaryDirectory() as temp_dir:
        user_dir = Path(temp_dir) / ".cursor"
        hooks_dir = user_dir / "hooks"
        hooks_dir.mkdir(parents=True)

        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho hook")
        hooks_json = user_dir / "hooks.json"
        # JSONC: has comments and trailing comma — json.loads would choke on this
        hooks_json.write_text(
            "{\n"
            "  // Cursor hooks config\n"
            '  "version": 1,\n'
            '  "hooks": {\n'
            '    "beforeMCPExecution": [\n'
            '      {"command": "' + str(hook_script).replace("\\", "\\\\") + '"},\n'
            "    ]\n"
            "  }\n"
            "}\n"
        )

        with patch.dict(
            "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
            {Client.CURSOR: user_dir},
        ):
            _migrate_user_to_enterprise(Client.CURSOR)

        assert not hook_script.exists()
        assert not hooks_json.exists()
        assert len(list(hooks_dir.glob("runlayer-hook.backup_*.sh"))) == 1
        assert len(list(user_dir.glob("hooks.backup_*.json"))) == 1


def test_migrate_leaves_non_runlayer_hooks():
    """Test that migration leaves non-Runlayer hooks.json alone."""
    with tempfile.TemporaryDirectory() as temp_dir:
        user_dir = Path(temp_dir) / ".cursor"
        user_dir.mkdir(parents=True)

        hooks_json = user_dir / "hooks.json"
        hooks_json.write_text(
            json.dumps(
                {
                    "version": 1,
                    "hooks": {"afterFileEdit": [{"command": "/some/other/hook.sh"}]},
                }
            )
        )

        with patch.dict(
            "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
            {Client.CURSOR: user_dir},
        ):
            _migrate_user_to_enterprise(Client.CURSOR)

        # hooks.json should NOT be removed (not Runlayer-managed)
        assert hooks_json.exists()


def test_migrate_mdm_install_creates_enterprise_hooks():
    """Test full --mdm install: migrate user hooks + create enterprise hooks."""
    with tempfile.TemporaryDirectory() as temp_dir:
        user_dir = Path(temp_dir) / ".cursor"
        user_hooks_dir = user_dir / "hooks"
        user_hooks_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"

        # Create user-level hooks
        user_hook = user_hooks_dir / "runlayer-hook.sh"
        user_hook.write_text("#!/bin/bash\necho old")
        user_json = user_dir / "hooks.json"
        user_json.write_text(
            json.dumps(
                {
                    "version": 1,
                    "hooks": {"beforeMCPExecution": [{"command": str(user_hook)}]},
                }
            )
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: user_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
        ):
            result = runner.invoke(
                app,
                [
                    "setup",
                    "hooks",
                    "--client",
                    "cursor",
                    "--install",
                    "--mdm",
                    "--yes",
                ],
            )

            assert result.exit_code == 0

            # User hooks should be gone
            assert not user_hook.exists()
            assert not user_json.exists()

            # Enterprise hooks should exist
            ent_hook = enterprise_dir / "hooks" / "runlayer-hook.sh"
            assert ent_hook.exists()
            ent_json = enterprise_dir / "hooks.json"
            assert ent_json.exists()


# =============================================================================
# _uninstall_cursorignore tests
# =============================================================================


def test_uninstall_cursorignore_removes_managed_block():
    """Test that uninstall removes the Runlayer managed block."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _install_cursorignore()

            path = fake_home / ".cursorignore"
            assert path.exists()

            _uninstall_cursorignore()

            # File should be removed (was only Runlayer content)
            assert not path.exists()


def test_uninstall_cursorignore_preserves_user_content():
    """Test that uninstall preserves user-added content."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)
        path = fake_home / ".cursorignore"
        path.write_text("# my custom ignores\nnode_modules/\n")

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _install_cursorignore()
            _uninstall_cursorignore()

        assert path.exists()
        content = path.read_text()
        assert "# my custom ignores" in content
        assert "node_modules/" in content
        assert "Runlayer managed" not in content


def test_uninstall_cursorignore_noop_when_no_file():
    """Test that uninstall is a no-op when ~/.cursorignore doesn't exist."""
    with tempfile.TemporaryDirectory() as temp_dir:
        fake_home = Path(temp_dir)

        with patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home):
            _uninstall_cursorignore()  # should not raise

        assert not (fake_home / ".cursorignore").exists()


def _run_hook_with_fake_curl(hook_src: Path, home_dir: str) -> dict:
    """Run the hook with a fake curl that captures the API key header.

    Returns dict with 'api_key' (extracted from header) and 'url' (curl target).
    The fake curl writes the key to a file, then exits non-zero so the hook
    returns a deny with "Failed to contact Runlayer API".
    """
    key_file = Path(home_dir) / ".captured_key"
    url_file = Path(home_dir) / ".captured_url"
    bin_dir = Path(home_dir) / "bin"
    bin_dir.mkdir(exist_ok=True)

    # Fake curl: extract -H x-runlayer-api-key header value and save it
    fake_curl = bin_dir / "curl"
    fake_curl.write_text(
        "#!/bin/bash\n"
        "while [[ $# -gt 0 ]]; do\n"
        '  case "$1" in\n'
        "    -H) shift;\n"
        '      if [[ "$1" == x-runlayer-api-key:* ]]; then\n'
        f'        echo "${{1#x-runlayer-api-key: }}" > "{key_file}"\n'
        "      fi;;\n"
        f'    http*) echo "$1" > "{url_file}";;\n'
        "  esac\n"
        "  shift\n"
        "done\n"
        "exit 1\n"  # fail so hook returns deny
    )
    fake_curl.chmod(0o755)

    hook_input = json.dumps(
        {
            "hook_event_name": "beforeMCPExecution",
            "tool_name": "test",
            "tool_input": "{}",
        }
    )
    env = {**os.environ, "HOME": home_dir, "PATH": f"{bin_dir}:{os.environ['PATH']}"}
    result = subprocess.run(
        ["bash", str(hook_src)],
        input=hook_input,
        capture_output=True,
        text=True,
        env=env,
    )
    output = json.loads(result.stdout)

    captured = {"output": output}
    if key_file.exists():
        captured["api_key"] = key_file.read_text().strip()
    if url_file.exists():
        captured["url"] = url_file.read_text().strip()
    return captured


def test_hook_script_strips_yaml_quoted_secret():
    """Test that the hook script strips YAML single-quotes from secret values.

    Regression: yaml.safe_dump quotes strings that look like non-string types
    (e.g., numeric secret '123456' -> secret: '123456'). Without stripping,
    RUNLAYER_API_KEY includes literal single quotes, failing auth silently.
    """
    hook_src = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"
    assert hook_src.exists()

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / ".runlayer" / "config.yaml"
        config_path.parent.mkdir()
        # PyYAML safe_dump quotes purely numeric secrets with single quotes
        config_path.write_text(
            "default_host: https://app.example.com\n"
            "hosts:\n"
            "  app.example.com:\n"
            "    url: https://app.example.com\n"
            "    secret: '123456'\n"
        )

        captured = _run_hook_with_fake_curl(hook_src, temp_dir)
        assert captured["output"]["permission"] == "deny"
        assert "Failed to contact Runlayer API" in captured["output"]["user_message"]
        assert captured["api_key"] == "123456", (
            f"Expected '123456' but got '{captured.get('api_key')}' "
            "(YAML single-quotes not stripped)"
        )


def test_hook_script_strips_yaml_double_quoted_secret():
    """Test that double-quoted YAML secrets are also stripped."""
    hook_src = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"
    assert hook_src.exists()

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / ".runlayer" / "config.yaml"
        config_path.parent.mkdir()
        config_path.write_text(
            "default_host: https://app.example.com\n"
            "hosts:\n"
            "  app.example.com:\n"
            "    url: https://app.example.com\n"
            '    secret: "my-secret-key"\n'
        )

        captured = _run_hook_with_fake_curl(hook_src, temp_dir)
        assert captured["output"]["permission"] == "deny"
        assert "Failed to contact Runlayer API" in captured["output"]["user_message"]
        assert captured["api_key"] == "my-secret-key", (
            f"Expected 'my-secret-key' but got '{captured.get('api_key')}' "
            "(YAML double-quotes not stripped)"
        )


def test_hook_script_strips_yaml_quoted_default_host():
    """Test that YAML quotes on default_host are stripped."""
    hook_src = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"
    assert hook_src.exists()

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / ".runlayer" / "config.yaml"
        config_path.parent.mkdir()
        config_path.write_text(
            "default_host: 'https://app.example.com'\n"
            "hosts:\n"
            "  app.example.com:\n"
            "    url: https://app.example.com\n"
            "    secret: test-secret\n"
        )

        captured = _run_hook_with_fake_curl(hook_src, temp_dir)
        assert captured["output"]["permission"] == "deny"
        # If quotes weren't stripped, host_key derivation breaks and we'd get
        # "No API key" instead of reaching curl
        assert "No API key" not in captured["output"].get("user_message", ""), (
            f"YAML quotes not stripped from default_host: {captured['output']['user_message']}"
        )
        # URL should be clean (no quotes)
        assert captured.get("url", "").startswith("https://app.example.com"), (
            f"Expected URL starting with https://app.example.com but got '{captured.get('url')}'"
        )


def test_hook_script_lowercases_host_key():
    """Test that the hook script lowercases host_key when deriving from default_host.

    Regression test: if default_host has uppercase (e.g. https://App.Example.Com),
    the YAML host key is lowercase (app.example.com, per Python's urlparse().hostname).
    Without lowercasing, the awk lookup fails and all MCP execution is blocked.
    """
    hook_src = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"
    assert hook_src.exists(), "Hook source script not found"

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / ".runlayer" / "config.yaml"
        config_path.parent.mkdir()
        # Mixed-case default_host but lowercase host key (as Python login writes)
        config_path.write_text(
            "default_host: https://App.Example.Com\n"
            "hosts:\n"
            "  app.example.com:\n"
            "    url: https://App.Example.Com\n"
            "    secret: test-secret-123\n"
        )

        hook_input = json.dumps(
            {
                "hook_event_name": "beforeMCPExecution",
                "tool_name": "test",
                "tool_input": "{}",
            }
        )

        # Run the hook; curl will fail (no server) so we expect a deny, but the
        # important thing is that the denial message should be about curl, NOT
        # about "No API key for App.Example.Com" which would indicate the
        # lowercase bug.
        result = subprocess.run(
            ["bash", str(hook_src)],
            input=hook_input,
            capture_output=True,
            text=True,
            env={**os.environ, "HOME": temp_dir},
        )
        output = json.loads(result.stdout)
        assert output["permission"] == "deny"
        # Should fail at curl (API key was found), not at host_key lookup
        assert "No API key" not in output.get("user_message", ""), (
            f"Host key lookup failed (case mismatch): {output['user_message']}"
        )


def test_hook_script_handles_uppercase_scheme():
    """Test that uppercase scheme (HTTPS://) is stripped correctly.

    Regression: sed -E 's|^https?://||' is case-sensitive, so HTTPS:// was
    not stripped, producing a garbage host_key like 'https:' and silently
    blocking all MCP calls with 'No API key'.
    """
    hook_src = Path(__file__).resolve().parent.parent / "hooks" / "runlayer-hook.sh"
    assert hook_src.exists(), "Hook source script not found"

    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / ".runlayer" / "config.yaml"
        config_path.parent.mkdir()
        config_path.write_text(
            "default_host: HTTPS://APP.EXAMPLE.COM\n"
            "hosts:\n"
            "  app.example.com:\n"
            "    url: HTTPS://APP.EXAMPLE.COM\n"
            "    secret: test-secret-456\n"
        )

        hook_input = json.dumps(
            {
                "hook_event_name": "beforeMCPExecution",
                "tool_name": "test",
                "tool_input": "{}",
            }
        )

        result = subprocess.run(
            ["bash", str(hook_src)],
            input=hook_input,
            capture_output=True,
            text=True,
            env={**os.environ, "HOME": temp_dir},
        )
        output = json.loads(result.stdout)
        assert output["permission"] == "deny"
        # Should fail at curl (key was found), not at host_key lookup
        assert "No API key" not in output.get("user_message", ""), (
            f"Uppercase scheme broke host_key derivation: {output['user_message']}"
        )


def test_uninstall_hooks_removes_cursorignore():
    """Test that full uninstall also cleans up ~/.cursorignore."""
    with tempfile.TemporaryDirectory() as temp_dir:
        client_dir = Path(temp_dir) / ".cursor"
        hooks_dir = client_dir / "hooks"
        hooks_dir.mkdir(parents=True)
        enterprise_dir = Path(temp_dir) / "enterprise"
        fake_home = Path(temp_dir) / "home"
        fake_home.mkdir()

        # Create hook files
        hook_script = hooks_dir / "runlayer-hook.sh"
        hook_script.write_text("#!/bin/bash\necho test")
        hooks_json = client_dir / "hooks.json"
        hooks_json.write_text('{"version": 1}')

        # Create cursorignore
        cursorignore = fake_home / ".cursorignore"
        cursorignore.write_text(
            "# >>> Runlayer managed - do not edit >>>\n.env\n# <<< Runlayer managed <<<\n"
        )

        with (
            patch.dict(
                "runlayer_cli.commands.setup.CLIENT_CONFIG_DIRS",
                {Client.CURSOR: client_dir},
            ),
            patch.dict(
                "runlayer_cli.commands.setup.ENTERPRISE_CONFIG_DIRS",
                {Client.CURSOR: enterprise_dir},
            ),
            patch("runlayer_cli.commands.setup.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(
                app,
                ["setup", "hooks", "--client", "cursor", "--uninstall", "--yes"],
            )

            assert result.exit_code == 0
            assert not hook_script.exists()
            assert not hooks_json.exists()
            assert not cursorignore.exists()
