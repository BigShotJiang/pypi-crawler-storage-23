import datetime
from unittest.mock import MagicMock

import httpx
import pytest

from runlayer_cli.api import SkillDetail, SkillFileDetail, SkillFileMetadata
from runlayer_cli.skills.sync_engine import sync_skills

NAMESPACE = "myorg/repo"


def _make_skill_dir(tmp_path, rel_path, name="Test Skill", extra_files=None):
    skill_dir = tmp_path / rel_path
    skill_dir.mkdir(parents=True, exist_ok=True)
    fm = f"---\nname: {name}\ndescription: test\n---\n"
    (skill_dir / "SKILL.md").write_text(fm + "# Docs\n")
    if extra_files:
        for fname, content in extra_files.items():
            p = skill_dir / fname
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)


def _mock_client():
    client = MagicMock()
    client.list_skills.return_value = []
    return client


def _ts():
    return datetime.datetime(2024, 1, 1, tzinfo=datetime.timezone.utc)


@pytest.mark.asyncio
async def test_sync_create_new(tmp_path):
    _make_skill_dir(tmp_path, "skills/hello", name="Hello Skill")
    client = _mock_client()
    client.create_skill.return_value = SkillDetail(
        id="new-id",
        name="Hello Skill",
        path="skills/hello",
        namespace=NAMESPACE,
        files=[
            SkillFileMetadata(
                id="f1", skill_id="new-id", title="SKILL.md", updated_at=_ts()
            )
        ],
    )
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE)
    assert result.created == 1
    client.create_skill.assert_called_once()
    call_kwargs = client.create_skill.call_args
    assert call_kwargs.kwargs.get("namespace") == NAMESPACE
    assert call_kwargs.kwargs.get("path") == "skills/hello"


@pytest.mark.asyncio
async def test_sync_update_existing(tmp_path):
    _make_skill_dir(tmp_path, "skills/demo", name="Demo Skill")
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(
            id="existing-id",
            name="Demo Skill",
            path="skills/demo",
            namespace=NAMESPACE,
            files=[
                SkillFileMetadata(
                    id="f1",
                    skill_id="existing-id",
                    title="SKILL.md",
                    updated_at=_ts(),
                )
            ],
        )
    ]
    client.get_skill.return_value = SkillDetail(
        id="existing-id",
        name="Demo Skill",
        path="skills/demo",
        description="test",
        files=[
            SkillFileMetadata(
                id="f1",
                skill_id="existing-id",
                title="SKILL.md",
                updated_at=_ts(),
            )
        ],
    )
    fm = "---\nname: Demo Skill\ndescription: test\n---\n# Docs\n"
    client.get_skill_file.return_value = SkillFileDetail(
        id="f1", skill_id="existing-id", title="SKILL.md", content=fm
    )

    result = await sync_skills(tmp_path, client, namespace=NAMESPACE)
    assert result.unchanged == 1
    assert result.updated == 0
    client.create_skill.assert_not_called()


@pytest.mark.asyncio
async def test_sync_update_detects_changes(tmp_path):
    _make_skill_dir(tmp_path, "skills/demo", name="Demo Skill")
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(
            id="existing-id",
            name="Demo Skill",
            path="skills/demo",
            namespace=NAMESPACE,
            files=[
                SkillFileMetadata(
                    id="f1",
                    skill_id="existing-id",
                    title="SKILL.md",
                    updated_at=_ts(),
                )
            ],
        )
    ]
    client.get_skill.return_value = SkillDetail(
        id="existing-id",
        name="Demo Skill",
        path="skills/demo",
        files=[
            SkillFileMetadata(
                id="f1",
                skill_id="existing-id",
                title="SKILL.md",
                updated_at=_ts(),
            )
        ],
    )
    client.get_skill_file.return_value = SkillFileDetail(
        id="f1", skill_id="existing-id", title="SKILL.md", content="old content"
    )
    client.update_skill_file.return_value = SkillFileDetail(
        id="f1", skill_id="existing-id", title="SKILL.md", content=""
    )

    result = await sync_skills(tmp_path, client, namespace=NAMESPACE)
    assert result.updated == 1
    client.update_skill_file.assert_called()


@pytest.mark.asyncio
async def test_sync_dry_run_no_api_writes(tmp_path):
    _make_skill_dir(tmp_path, "skills/demo", name="Demo Skill")
    client = _mock_client()

    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, dry_run=True)
    assert result.created == 1
    client.create_skill.assert_not_called()


@pytest.mark.asyncio
async def test_sync_prune_deletes_remote_only(tmp_path):
    """Remote has skill not on disk -> deleted when prune=True."""
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(id="old-id", name="Gone Skill", path="skills/gone", namespace=NAMESPACE)
    ]
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, prune=True)
    assert result.deleted == 1
    client.delete_skill.assert_called_once_with("old-id")


@pytest.mark.asyncio
async def test_sync_no_prune_keeps_remote(tmp_path):
    """Remote has skill not on disk but prune=False -> not deleted."""
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(id="old-id", name="Gone Skill", path="skills/gone", namespace=NAMESPACE)
    ]
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, prune=False)
    assert result.deleted == 0
    client.delete_skill.assert_not_called()


@pytest.mark.asyncio
async def test_sync_delete_404_no_error(tmp_path):
    """API returns 404 on delete -> no error reported."""
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(id="old-id", name="Gone Skill", path="skills/gone", namespace=NAMESPACE)
    ]
    response = httpx.Response(404, request=httpx.Request("DELETE", "http://test"))
    client.delete_skill.side_effect = httpx.HTTPStatusError(
        "Not Found", request=response.request, response=response
    )
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, prune=True)
    assert result.errors == []


@pytest.mark.asyncio
async def test_sync_delete_500_reports_error(tmp_path):
    """API returns 500 on delete -> error reported."""
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(id="old-id", name="Gone Skill", path="skills/gone", namespace=NAMESPACE)
    ]
    response = httpx.Response(500, request=httpx.Request("DELETE", "http://test"))
    client.delete_skill.side_effect = httpx.HTTPStatusError(
        "Server Error", request=response.request, response=response
    )
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, prune=True)
    assert len(result.errors) == 1


@pytest.mark.asyncio
async def test_sync_create_409_retries_as_update(tmp_path):
    """create_skill returns 409 (race) -> re-fetches and updates."""
    _make_skill_dir(tmp_path, "skills/demo", name="Demo Skill")
    client = _mock_client()

    response_409 = httpx.Response(409, request=httpx.Request("POST", "http://test"))
    client.create_skill.side_effect = httpx.HTTPStatusError(
        "Conflict", request=response_409.request, response=response_409
    )
    # list_skills is called twice: once in sync_skills, once in _retry_as_update
    client.list_skills.side_effect = [
        [],  # first call: no remote skills → triggers create
        [   # second call (retry): skill now exists
            SkillDetail(
                id="existing-id",
                name="Demo Skill",
                path="skills/demo",
                namespace=NAMESPACE,
                description="test",
                files=[
                    SkillFileMetadata(
                        id="f1",
                        skill_id="existing-id",
                        title="SKILL.md",
                        updated_at=_ts(),
                    )
                ],
            )
        ],
    ]
    client.get_skill.return_value = SkillDetail(
        id="existing-id",
        name="Demo Skill",
        path="skills/demo",
        description="test",
        files=[
            SkillFileMetadata(
                id="f1",
                skill_id="existing-id",
                title="SKILL.md",
                updated_at=_ts(),
            )
        ],
    )
    fm = "---\nname: Demo Skill\ndescription: test\n---\n# Docs\n"
    client.get_skill_file.return_value = SkillFileDetail(
        id="f1", skill_id="existing-id", title="SKILL.md", content=fm
    )

    result = await sync_skills(tmp_path, client, namespace=NAMESPACE)
    assert result.errors == []
    assert result.unchanged == 1
    client.create_skill.assert_called_once()


@pytest.mark.asyncio
async def test_sync_dry_run_no_recreate_on_404(tmp_path):
    """dry_run + remote 404 on get_skill should not call create_skill."""
    _make_skill_dir(tmp_path, "skills/demo", name="Demo Skill")
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(
            id="stale-id",
            name="Demo Skill",
            path="skills/demo",
            namespace=NAMESPACE,
            files=[],
        )
    ]
    response = httpx.Response(404, request=httpx.Request("GET", "http://test"))
    client.get_skill.side_effect = httpx.HTTPStatusError(
        "Not Found", request=response.request, response=response
    )
    result = await sync_skills(tmp_path, client, namespace=NAMESPACE, dry_run=True)
    assert result.created == 1
    client.create_skill.assert_not_called()


@pytest.mark.asyncio
async def test_sync_update_deletes_removed_file(tmp_path):
    """Remote has extra file not on disk -> deleted."""
    _make_skill_dir(
        tmp_path, "skills/demo", name="Demo Skill", extra_files={"extra.md": "keep"}
    )
    client = _mock_client()
    client.list_skills.return_value = [
        SkillDetail(
            id="existing-id",
            name="Demo Skill",
            path="skills/demo",
            namespace=NAMESPACE,
            files=[
                SkillFileMetadata(
                    id="f1",
                    skill_id="existing-id",
                    title="SKILL.md",
                    updated_at=_ts(),
                ),
                SkillFileMetadata(
                    id="f2",
                    skill_id="existing-id",
                    title="extra.md",
                    updated_at=_ts(),
                ),
                SkillFileMetadata(
                    id="f3",
                    skill_id="existing-id",
                    title="gone.md",
                    updated_at=_ts(),
                ),
            ],
        )
    ]
    client.get_skill.return_value = SkillDetail(
        id="existing-id",
        name="Demo Skill",
        path="skills/demo",
        description="test",
        files=[
            SkillFileMetadata(
                id="f1",
                skill_id="existing-id",
                title="SKILL.md",
                updated_at=_ts(),
            ),
            SkillFileMetadata(
                id="f2",
                skill_id="existing-id",
                title="extra.md",
                updated_at=_ts(),
            ),
            SkillFileMetadata(
                id="f3",
                skill_id="existing-id",
                title="gone.md",
                updated_at=_ts(),
            ),
        ],
    )
    fm = "---\nname: Demo Skill\ndescription: test\n---\n# Docs\n"
    client.get_skill_file.side_effect = lambda sid, fid: {
        "f1": SkillFileDetail(id="f1", skill_id=sid, title="SKILL.md", content=fm),
        "f2": SkillFileDetail(
            id="f2", skill_id=sid, title="extra.md", content="keep"
        ),
    }[fid]

    result = await sync_skills(tmp_path, client, namespace=NAMESPACE)
    assert result.updated == 1
    client.delete_skill_file.assert_called_once_with("existing-id", "f3")
