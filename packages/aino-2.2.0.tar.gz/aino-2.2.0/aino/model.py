from .backend import xp, to_cpu
from typing import List, Optional, Dict, Any, Union
import numpy as np
from .layer import Layer


class NeuralNetwork:
    """
    A flexible feedforward neural network that supports both single-head
    and multi-head architectures, mini-batch training, and GPU acceleration.

    Attributes:
        config (List[int]): Layer sizes defining the network architecture.
        activation_type (str): Activation function used in hidden layers.
        output_activation (str): Activation function used in the output layer.
        heads_config (Optional[List[Dict]]): Configuration for multi-head outputs.
        trunk_layers (List[Layer]): Shared hidden layers of the network.
        head_layers (List[Layer]): Output head layers of the network.
        is_multi_head (bool): Whether the network uses multiple output heads.
    """

    def __init__(self, layer_config: List[int], activation_type: str = 'relu',
                 output_activation: str = 'softmax', heads: Optional[List[Dict[str, Any]]] = None):
        """
        Initialize the NeuralNetwork.

        Args:
            layer_config (List[int]): A list of integers specifying the number of
                neurons in each layer, including input and output layers.
                Example: [128, 64, 32, 10] creates a network with 3 layer transitions.
            activation_type (str): Activation function for hidden layers.
                Defaults to 'relu'. Supported values depend on the Layer implementation.
            output_activation (str): Activation function for the output layer.
                Defaults to 'softmax'. Ignored when using multi-head mode.
            heads (Optional[List[Dict[str, Any]]]): Configuration for multi-head outputs.
                Each dict must contain:
                    - 'size' (int): Number of output neurons for this head.
                    - 'activation' (str): Activation function for this head.
                    - 'loss' (str, optional): Loss function for this head.
                If None, the network uses a single output head. Defaults to None.

        Example (single-head):
            >>> model = NeuralNetwork([784, 128, 64, 10])

        Example (multi-head):
            >>> heads = [
            ...     {'size': 10, 'activation': 'softmax', 'loss': 'cross_entropy'},
            ...     {'size': 1,  'activation': 'sigmoid', 'loss': 'mse'}
            ... ]
            >>> model = NeuralNetwork([784, 128, 64], heads=heads)
        """
        self.config = layer_config
        self.activation_type = activation_type if activation_type is not None else 'relu'
        self.output_activation = output_activation
        self.heads_config = heads

        self.trunk_layers: List[Layer] = []
        self.head_layers: List[Layer] = []

        if heads is None:
            self.is_multi_head = False
            for i in range(len(layer_config) - 2):
                self.trunk_layers.append(
                    Layer(layer_config[i], layer_config[i + 1], activation_type=self.activation_type))

            self.head_layers.append(Layer(layer_config[-2], layer_config[-1], activation_type=self.output_activation))

            self._internal_heads = [{'size': layer_config[-1], 'activation': self.output_activation}]

        else:
            self.is_multi_head = True
            for i in range(len(layer_config) - 1):
                self.trunk_layers.append(
                    Layer(layer_config[i], layer_config[i + 1], activation_type=self.activation_type))

            current_dim = layer_config[-1]
            for head in heads:
                self.head_layers.append(Layer(current_dim, head['size'], activation_type=head['activation']))

            self._internal_heads = heads

    def _forward(self, X: xp.ndarray) -> List[xp.ndarray]:
        """
        Perform a forward pass through the entire network.

        Passes the input through all trunk layers sequentially, then feeds
        the trunk output into each head layer independently.

        Args:
            X (xp.ndarray): Input data of shape (batch_size, input_features).

        Returns:
            List[xp.ndarray]: A list of output arrays, one per head.
                For single-head networks, this is a list with one element.
        """
        current_input = X
        for layer in self.trunk_layers:
            current_input = layer.forward(current_input)

        head_outputs = []
        for head_layer in self.head_layers:
            head_outputs.append(head_layer.forward(current_input))

        return head_outputs

    def _backprop(self, head_error_gradients: List[xp.ndarray], n: float) -> None:
        """
        Perform backpropagation and update all layer weights.

        Gradients from each head are summed at the trunk junction point,
        then propagated backwards through all trunk layers.

        Args:
            head_error_gradients (List[xp.ndarray]): A list of loss gradients,
                one per head, each with shape (batch_size, head_output_size).
            n (float): Learning rate used to scale weight updates.
        """
        total_trunk_error = xp.zeros_like(self.head_layers[0].last_x)

        for i, head_layer in enumerate(self.head_layers):
            error_from_head = head_layer.backward(head_error_gradients[i])
            total_trunk_error += error_from_head
            head_layer.update(n)

        error = total_trunk_error
        for layer in reversed(self.trunk_layers):
            error = layer.backward(error)
            layer.update(n)

    def predict(self, X: xp.ndarray) -> Union[xp.ndarray, List[xp.ndarray]]:
        """
        Generate predictions for the given input data.

        Args:
            X (xp.ndarray): Input data. Will be cast to at least 2D automatically.

        Returns:
            Union[xp.ndarray, List[xp.ndarray]]:
                - A single array of shape (n_samples, output_size) for single-head networks.
                - A list of arrays, one per head, for multi-head networks.
        """
        X = xp.ascontiguousarray(xp.atleast_2d(X))
        preds = self._forward(X)

        if not self.is_multi_head:
            return preds[0]
        return preds

    def fit(self, X: xp.ndarray, y: Union[xp.ndarray, List[xp.ndarray]], epochs: int = 1000, n: float = 0.1,
            batch_size: int = 32, verbose: bool = False, loss_type: str = 'cross_entropy') -> None:
        """
        Train the network on the provided dataset using mini-batch gradient descent.

        For single-head networks, the loss function is set by `loss_type`.
        For multi-head networks, each head's loss must be defined in its config dict.

        Args:
            X (xp.ndarray): Training input data of shape (n_samples, input_features).
            y (Union[xp.ndarray, List[xp.ndarray]]): Training labels.
                - For single-head: a single array of shape (n_samples, output_size).
                - For multi-head: a list of arrays, one per head.
            epochs (int): Number of full passes over the training data. Defaults to 1000.
            n (float): Learning rate. Defaults to 0.1.
            batch_size (int): Number of samples per mini-batch. Defaults to 32.
            verbose (bool): If True, prints loss every ~10% of epochs (single-head only).
                Defaults to False.
            loss_type (str): Loss function to use for single-head training.
                - 'cross_entropy': For classification tasks (default).
                - 'mse': For regression tasks.
                Ignored for multi-head networks (each head defines its own loss).
        """
        if hasattr(xp, 'cuda'):
            xp.cuda.Device(0).use()

        X = xp.ascontiguousarray(xp.asarray(X, dtype=xp.float32))

        if not self.is_multi_head:
            y_device_list = [xp.ascontiguousarray(xp.asarray(y, dtype=xp.float32))]
            self._internal_heads[0]['loss'] = loss_type
        else:
            y_device_list = [xp.ascontiguousarray(xp.asarray(target, dtype=xp.float32)) for target in y]

        n_samples = len(X)
        num_batches = int(xp.ceil(n_samples / batch_size))

        head_count_str = "Single-Head" if not self.is_multi_head else f"Multi-Head ({len(self.head_layers)} Heads)"
        print(f"Start training AINO {head_count_str} (Mini-Batch) over {epochs} epochs...")

        indices = xp.arange(n_samples)

        for epoch in range(epochs):
            xp.random.shuffle(indices)
            total_error = 0.0

            for i in range(0, n_samples, batch_size):
                idx_batch = indices[i: i + batch_size]
                X_batch = X[idx_batch]
                y_batches = [y_dev[idx_batch] for y_dev in y_device_list]

                preds = self._forward(X_batch)
                head_errors = []

                for j, head_config in enumerate(self._internal_heads):
                    pred = preds[j]
                    y_batch = y_batches[j]
                    current_loss_type = head_config.get('loss', 'cross_entropy')

                    if current_loss_type == 'mse':
                        error_grad = (pred - y_batch)
                        batch_loss = xp.sum((y_batch - pred) ** 2) / batch_size
                    else:
                        epsilon = xp.float32(1e-7)
                        error_grad = (pred - y_batch)
                        batch_loss = -xp.sum(y_batch * xp.log(pred + epsilon)) / batch_size

                    head_errors.append(error_grad)

                    if not self.is_multi_head:
                        if hasattr(batch_loss, 'get'):
                            total_error += float(batch_loss.get())
                        else:
                            total_error += float(batch_loss)

                self._backprop(head_errors, n)

            if hasattr(xp, 'get_default_memory_pool'):
                xp.get_default_memory_pool().free_all_blocks()

            if not self.is_multi_head and verbose and (epoch % (max(1, epochs // 10)) == 0):
                avg_loss = total_error / num_batches
                print(f"Epoch {epoch}, Loss: {avg_loss:.6f}")
            elif self.is_multi_head and (epoch % max(1, (epochs // 10)) == 0):
                print(f"Epoch {epoch} completed.")

        print("Training is done!")

    def save(self, filename: str = "model.dit") -> None:
        """
        Serialize and save the model weights and configuration to a `.dit` file.

        All layer weights, biases, and architecture metadata are saved using
        NumPy's compressed `.npz` format under a `.dit` extension.

        Args:
            filename (str): Path to save the model file. The `.dit` extension
                will be appended automatically if not present. Defaults to 'model.dit'.
        """
        if not filename.endswith(".dit"):
            filename += ".dit"

        data = {
            'config': np.array(self.config),
            'activation': np.array(self.activation_type),
            'output_activation': np.array(self.output_activation),
            'is_multi_head': np.array(self.is_multi_head)
        }

        if self.is_multi_head:
            data['heads_config'] = np.array(self.heads_config, dtype=object)

        all_layers = self.trunk_layers + self.head_layers
        for i, layer in enumerate(all_layers):
            data[f"layer_{i}_w"] = to_cpu(layer.w)
            data[f"layer_{i}_b"] = to_cpu(layer.b)

        with open(filename, 'wb') as f:
            np.savez(f, **data)

        print(f"Successfully saved universal model to '{filename}'")

    @staticmethod
    def load(filename: str) -> Optional['NeuralNetwork']:
        """
        Load a previously saved model from a `.dit` file.

        Reconstructs the network architecture from saved metadata and
        restores all layer weights and biases.

        Args:
            filename (str): Path to the `.dit` model file to load.

        Returns:
            Optional[NeuralNetwork]: The restored NeuralNetwork instance,
                or None if loading fails due to a missing file or corrupt data.

        Warns:
            Prints a warning if the file does not have the `.dit` extension.
        """
        if not filename.endswith(".dit"):
            print(f"Warning: '{filename}' isn't a .dit model...")

        try:
            with open(filename, 'rb') as f:
                data = xp.load(f, allow_pickle=True)
                config = data['config'].tolist()
                activation = str(data['activation'])
                out_activation = str(data['output_activation']) if 'output_activation' in data else 'softmax'

                is_multi = bool(data.get('is_multi_head', False))
                heads_config = data['heads_config'].tolist() if is_multi else None

                print(f"Architecture: {config}, Hidden: {activation}, Output: {out_activation}")

                new_model = NeuralNetwork(config, activation_type=activation,
                                          output_activation=out_activation, heads=heads_config)

                all_layers = new_model.trunk_layers + new_model.head_layers
                for i, layer in enumerate(all_layers):
                    layer.w = data[f"layer_{i}_w"]
                    layer.b = data[f"layer_{i}_b"]

                print("AINO model ready")
                return new_model

        except Exception as e:
            print(f"Error when trying to load model: {e}")
            return None