"""fastapi-correlation — Correlation ID middleware and structured logging for FastAPI."""

__version__ = "0.0.1"
