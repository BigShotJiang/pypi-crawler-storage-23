====
spmo
====

``spmo`` is a utility-oriented Python library that collects lightweight helpers for networking, domain/WHOIS lookup, strings, files, date/time conversion, data serialization, and simple database access. The current version is ``2.0.12``.


Features
--------

- ``spmo.net.http``: URI parsing, HTTP requests, cookie handling, and basic JSON request/response helpers.
- ``spmo.net.domain``: domain parsing, WHOIS server lookup, WHOIS text fetching, and field extraction.
- ``spmo.net.network``: IPv4 network, netmask, and private-IP utility functions.
- ``spmo.file.common``: text file reading/writing and path conversion helpers.
- ``spmo.datetime_s.common``: conversion of common date strings into timestamps.
- ``spmo.data_serialize``: JSON and pickle serialization/deserialization helpers.
- ``spmo.db.mysql``: a small MySQL wrapper built on top of ``MySQLdb``.


Installation
------------

Install the package itself::

    pip install .

Install in editable mode for local development::

    pip install -e .

Some modules depend on third-party packages that are not currently declared in ``setup.py``. Install them manually as needed::

    pip install dnspython mysqlclient

If you use ``spmo.net.network`` on Python 2.7, you will usually also need::

    pip install ipaddress


Quick Start
-----------

JSON / pickle serialization::

    from spmo.data_serialize import DataSerialize

    ds = DataSerialize()
    payload = {'name': 'spmo', 'enabled': True}
    text = ds.serialize(payload, sort_keys=True)
    data = ds.deserialize(text)

Network helpers::

    from spmo.net.network import get_ip_network, is_private_ip

    print(get_ip_network('192.168.1.23', '255.255.255.0'))
    print(is_private_ip('10.1.2.3'))

URI parsing::

    from spmo.net.http import parse_uri

    print(parse_uri('https://example.com:8443/api/v1?q=1'))

File reading::

    from spmo.file.common import File

    fh = File(encoding='utf-8')
    print(fh.read_file('README.rst'))


Module Overview
---------------

``spmo.common``
    Basic helper functions for debug output, UUID generation, and timestamps.

``spmo.data_serialize``
    A unified ``serialize`` / ``deserialize`` interface for JSON and pickle workflows.

``spmo.net.domain``
    Uses the built-in ``spmo/conf/`` data files to resolve WHOIS server information; this module depends on ``dnspython``.

``spmo.db.mysql``
    Provides a simple MySQL query wrapper; install ``MySQLdb`` or a compatible implementation before using it.


Development
-----------

Run tests::

    python -m unittest discover -s tests

Build a source distribution::

    python setup.py sdist

Show the current version::

    python setup.py --version


Notes
-----

- The repository includes ``spmo/conf/effective_tld_names.dat`` and ``spmo/conf/whois.servers.json``. WHOIS-related features depend on these data files.
- The project originally targeted both Python 2 and Python 3, so some compatibility branches are still present. Run tests or a small integration check on your target interpreter before shipping changes.
- Modules such as ``spmo.db.mysql`` and ``spmo.net.domain`` are optional, dependency-driven utilities. Avoid importing everything blindly in minimal environments.


License
-------

BSD
