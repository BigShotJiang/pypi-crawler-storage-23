# -*- coding:utf-8 -*-

import uuid
import pprint
from datetime import datetime


def DD(vars):
    """Pretty-print a value for ad-hoc debugging."""
    pprint.pprint(vars)


def get_uuid():
    """Return a composite UUID string built from uuid1 and uuid4."""
    uuid_1 = uuid.uuid1()
    uuid_4 = uuid.uuid4()
    return '%s-%s' % (uuid_1, uuid_4)


def get_now_timestamp():
    """Return the current local time formatted as YYYYMMDDHHMMSS."""
    return datetime.now().strftime('%Y%m%d%H%M%S')


class Common(object):
    """Small base class exposing shared utility helpers."""

    def __init__(self, *args, **kwargs):
        pass

    def DD(self, vars):
        """Pretty-print a value for ad-hoc debugging."""
        DD(vars)

    def get_uuid(self):
        """Return a composite UUID string built from uuid1 and uuid4."""
        return get_uuid()

    def get_create_date(self):
        """Return the current local time formatted as YYYYMMDDHHMMSS."""
        return get_now_timestamp()
