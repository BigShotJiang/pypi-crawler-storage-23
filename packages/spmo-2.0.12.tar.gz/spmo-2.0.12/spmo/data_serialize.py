# -*- coding: utf-8 -*-

import sys

try:
    import cPickle as pickle
except ImportError:
    import pickle

if sys.version_info >= (2, 6, 0):
    import json
else:
    import simplejson as json

from datetime import date, datetime

from .common import Common


def normalize_json_data(value):
    """Recursively decode bytes so the payload can be JSON-serialized."""
    if isinstance(value, bytes):
        return value.decode('utf-8')
    if isinstance(value, dict):
        return dict((normalize_json_data(key), normalize_json_data(item))
                    for key, item in value.items())
    if isinstance(value, list):
        return [normalize_json_data(item) for item in value]
    if isinstance(value, tuple):
        return tuple(normalize_json_data(item) for item in value)
    return value


class AdvEncoder(json.JSONEncoder):
    def default(self, obj):
        """Serialize date-like objects using string representations."""
        if isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return super(AdvEncoder, self).default(obj)


class DataSerialize(Common):
    """Dispatch serialization helpers for json, pickle, and xml formats."""

    def __init__(self, *args, **kwargs):
        """Initialize serializer functions based on the requested format."""
        data_format = kwargs.pop('format', 'json')
        self.is_json_adv_encode = kwargs.pop('is_json_adv_encode', True)
        self.kwargs = kwargs

        serializer_map = {
            'json': (self.data_to_json, self.json_to_data),
            'xml': (self.data_to_xml, self.xml_to_data),
            'pickle': (self.data_to_pickle, self.pickle_to_data),
        }
        if data_format not in serializer_map:
            raise ValueError('Unsupported serialization format: %s' % data_format)

        self.serialize, self.deserialize = serializer_map[data_format]

    def data_to_json(self, json_d=None, **kwargs):
        """Serialize Python data into a JSON string."""
        akwargs = dict(self.kwargs, **kwargs)
        if sys.version_info >= (3, 0, 0):
            json_d = normalize_json_data(json_d)
        if self.is_json_adv_encode:
            json_str = json.dumps(json_d, cls=AdvEncoder, **akwargs)
        else:
            json_str = json.dumps(json_d, **akwargs)
        return json_str

    def json_to_data(self, json_str='', **kwargs):
        """Deserialize JSON text or bytes into Python data."""
        akwargs = dict(self.kwargs, **kwargs)
        if json_str is None:
            return None
        if isinstance(json_str, bytes):
            json_str = json_str.decode('utf-8')
        if hasattr(json_str, 'strip') and json_str.strip() == '':
            return {}
        json_d = json.loads(json_str, **akwargs)
        return json_d

    def data_to_pickle(self, pickle_d=None, **kwargs):
        """Serialize Python data into pickle bytes."""
        akwargs = dict(self.kwargs, **kwargs)
        pickle_str = pickle.dumps(pickle_d, **akwargs)
        return pickle_str

    def pickle_to_data(self, pickle_str='', **kwargs):
        """Deserialize pickle bytes into Python data."""
        akwargs = dict(self.kwargs, **kwargs)
        pickle_d = pickle.loads(pickle_str, **akwargs)
        return pickle_d

    def data_to_xml(self, *args, **kwargs):
        """Placeholder for XML serialization support."""
        raise NotImplementedError('XML serialization is not implemented')

    def xml_to_data(self, *args, **kwargs):
        """Placeholder for XML deserialization support."""
        raise NotImplementedError('XML deserialization is not implemented')


def test():
    """Simple manual smoke test for JSON serialization."""
    date_obj = datetime.now()
    ds = DataSerialize()
    print(ds.serialize(date_obj))


if __name__ == '__main__':
    test()
