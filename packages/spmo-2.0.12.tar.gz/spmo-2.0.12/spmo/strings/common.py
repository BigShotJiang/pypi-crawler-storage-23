# -*- coding: utf-8 -*-

import sys
try:
    from collections.abc import Iterable, Mapping
except ImportError:
    from collections import Iterable, Mapping

try:
    text_type = unicode
    binary_type = str
    string_types = (basestring,)
except NameError:
    text_type = str
    binary_type = bytes
    string_types = (str, bytes)


def trans_encode(input='', c_type='utf-8'):
    """Encode a text value to bytes and leave other values untouched."""
    if isinstance(input, text_type):
        input = input.encode(c_type)
        return input
    else:
        return input


def trans_to_unicode(i_str='', c_type='utf-8'):
    """Return a text string regardless of the original input type."""
    if isinstance(i_str, text_type):
        return i_str
    if isinstance(i_str, binary_type):
        return i_str.decode(c_type)
    return text_type(i_str)


def convert(data):
    """Recursively normalize text and bytes across nested container values."""

    if isinstance(data, binary_type):
        if sys.version_info >= (3, 0, 0):
            return data.decode('utf-8')
        return data
    elif isinstance(data, text_type):
        if sys.version_info >= (3, 0, 0):
            return data
        return data.encode('utf-8')
    elif isinstance(data, Mapping):
        if hasattr(data, 'iteritems'):
            data_iter = data.iteritems()
        else:
            data_iter = data.items()
        return dict((convert(key), convert(value)) for key, value in data_iter)
    elif isinstance(data, tuple):
        return tuple(convert(item) for item in data)
    elif isinstance(data, list):
        return [convert(item) for item in data]
    elif isinstance(data, set):
        return set(convert(item) for item in data)
    elif isinstance(data, Iterable) and not isinstance(data, string_types):
        return type(data)(map(convert, data))
    else:
        return data


def b2str(data):
    """Recursively decode bytes values when running under Python 3."""
    if isinstance(data, binary_type):
        if sys.version_info >= (3, 0, 0):
            return data.decode('utf-8')
        return data
    if isinstance(data, dict):
        return dict((b2str(key), b2str(value)) for key, value in data.items())
    if isinstance(data, tuple):
        return tuple(b2str(item) for item in data)
    if isinstance(data, list):
        return [b2str(item) for item in data]
    return data


def dequote(s=''):
    """Strip matching single or double quotes from both ends of a string."""
    s = s.strip()
    if s == '':
        return s
    if (s[0] == s[-1]) and s.startswith(("'", '"')):
        return s[1:-1]
    return s


def is_contain_chinese(v_str):
    """Return True when the input contains at least one Chinese character."""
    if sys.version_info < (3, 0, 0):
        v_str = v_str.decode('utf-8')
    for ch in v_str:
        if u'\u4e00' <= ch <= u'\u9fff':
            return True
    return False

    
