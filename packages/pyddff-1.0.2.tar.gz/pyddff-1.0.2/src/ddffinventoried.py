#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  7 19:11:09 2022

@author: repa
"""
import os
from functools import partial
try:
    from .ddffbase import DDFF, DDFFStream, dprint
except ImportError:
    from ddffbase import DDFF, DDFFStream, dprint
import json
import numpy as np
import h5py

# map with common conversions
_typemap = {
    "int32_t": np.int32,
    "int64_t": np.int64,
    "int16_t": np.int16,
    "int8_t": np.int8,
    "uint32_t": np.uint32,
    "uint64_t": np.uint64,
    "uint16_t": np.uint16,
    "uint8_t": np.uint8,
    "float": np.float32,
    "double": np.float64,
    "std::string": h5py.string_dtype(encoding="utf-8"),
    "Dstring": h5py.string_dtype(encoding="utf-8"),  # temporary
    "string8": h5py.string_dtype(encoding="utf-8", length=8),
    "string16": h5py.string_dtype(encoding="utf-8", length=16),
    "string32": h5py.string_dtype(encoding="utf-8", length=32),
    "string64": h5py.string_dtype(encoding="utf-8", length=64),
    "string128": h5py.string_dtype(encoding="utf-8", length=128),
    "smartstring": h5py.string_dtype(encoding="utf-8"),
    "LogString": h5py.string_dtype(encoding="utf-8", length=236),
    "bool": bool,
}


def _single_type(info: dict):
    if info["type"] == "primitive":
        return _typemap.get(info["class"], None)
    if info["type"] == "enum":
        ebasetype = _typemap.get(info.get("enumint", ""), np.uint32)
        if info.get("enumvalues", False):
            return h5py.enum_dtype(info["enumvalues"], basetype=ebasetype)
        else:
            # old recordings, just ints
            return ebasetype


def _get_single_type(info: dict):
    if info["type"] == "primitive":
        return _typemap.get(info["class"], None)
    if info["type"] == "enum":
        ebasetype = _typemap.get(info.get("enumint", ""), np.uint32)
        if info.get("enumvalues", False):
            return h5py.enum_dtype(info["enumvalues"], basetype=ebasetype)
        else:
            # old recordings, just ints
            return ebasetype
    if info["type"] == "object":
        res = []
        for m in info["members"]:
            otype = _get_object_type(m)
            if otype:
                res.append(otype)
        return res

def _get_object_type(info: dict):

    # single objects
    if info.get("container", None) is None:
        return (info.get("name", "data"), _get_single_type(info))

    # arrays
    if info.get("container", "") == "array":
        if info.get("size", 0): # fixed size
            return (info.get("name", "data"), _get_single_type(info), (info.get("size"),))
        else:                   # var length
            return (info.get("name", "data"), h5py.vlen_dtype(_get_single_type(info)))

    if info.get("container", "") == "map":
        ktype = _typemap.get(info.get("key_class", ""), None)
        btype = _get_single_type(info)
        return (info.get("name"), h5py.vlen_dtype(np.dtype([("key", ktype), ("val", btype)])))


    # other objects (variable length arrays, maps), dont work for this.
    return None


def shape_type_exclude(count: int, info: dict):
    """Given type information, return the array shape and numpy/hdf5 type information

    Parameters
    ----------
    count : int
        Array length
    info : dict
        Type information

    Returns
    -------
    dict
        Dictionary with a 'shape' tuple, a 'dtype' type information object, and optionally
        'excluded' for the data members that cannot be packed.

    Raises
    ------
    ValueError
        info dict not correct.
    """
    excluded = []

    shape = info.get("size", False) and (count, info.get("size")) or (count,)
    if info["type"] == "primitive":
        btype = _typemap.get(info["class"], None)
    elif info["type"] == "object":

        # nested object, run through the members
        mtypes = []
        for im, m in enumerate(info["members"]):
            if m["type"] in ("primitive", "enum"):
                if m.get("container", None) is None:
                    mtypes.append((m["name"], _single_type(m)))
                elif m.get("container") == "array" and m.get("size", None):
                    mtypes.append((m["name"], _single_type(m), m["size"]))
                else:
                    excluded.append(im)
        btype = np.dtype(mtypes)

    elif info["type"] == "enum":
        ebasetype = _typemap.get(info.get("enumint", ""), np.uint32)
        if info.get("enumvalues", False):
            btype = h5py.enum_dtype(info["enumvalues"], basetype=ebasetype)
        else:
            # old recordings, just ints
            btype = ebasetype
    else:
        raise ValueError(f"Wrong info specification {info}")

    ktype = _typemap.get(info.get("key_class", ""), None)
    if ktype:
        dtype = h5py.vlen_dtype(np.dtype([("key", ktype), ("val", btype)]))
    elif "size" in info:
        dtype = btype
    elif info.get("container", "") == "array":
        dtype = h5py.vlen_dtype(btype)
    else:
        dtype = btype
    dprint(f"{info['name']} shape {shape} from {info['class']} type {dtype}")

    return dict(shape=shape, dtype=dtype), excluded

def _struc2npstruc(tgt, struc):
    for m, d in struc.items():
        if isinstance(d, dict):
            _struc2npstruc(tgt[m], d)
        elif isinstance(d, list) and len(d) and isinstance(d[0], dict):
            tgt[m] = np.empty(dtype=tgt[m].dtype, shape=(len(d),))
            for i, _x in enumerate(d):
                _struc2npstruc(tgt[m][i], _x)
        else:
            tgt[m] = d

class Objecter:
    """Helper class, to create structs matching the data content description.
    Typically used for non-time (index) data."""

    def __init__(self, info: dict, enumnumeric: bool=False):
        """Create objecter

        Parameters
        ----------
        info : dict
            Data description
        """
        self.info = info
        self.enumnumeric = enumnumeric

    def __call__(self, data):
        """Convert data object into a structure matching data type description

        Parameters
        ----------
        data : Typically array with nested data, structs, parsed with msgpack
            Raw parsed data

        Returns
        -------
        struct
            Structure matching the info dict
        """
        res = dict()
        for ix, midx in enumerate(self.info["members"]):
            m = midx["name"]
            if midx.get("container", "") == "":
                if midx["type"] == "primitive":
                    res[m] = data[ix]
                elif midx["type"] == "object":
                    res[m] = Objecter(midx, self.enumnumeric)(data[ix])
                elif midx["type"] == "enum":
                    if self.enumnumeric:
                        res[m] = data[ix]
                    else:
                        try:
                            res[m] = midx["enummapper"][data[ix]]
                        except KeyError:
                            midx["enummapper"] = dict(
                                [(k, v) for v, k in midx["enumvalues"].items()]
                            )
                            res[m] = midx["enummapper"][data[ix]]

            if midx.get("container", "") == "array":
                if midx["type"] == "primitive":
                    res[m] = data[ix]
                elif midx["type"] == "object":
                    res[m] = list(map(Objecter(midx, self.enumnumeric), data[ix]))
                elif midx["type"] == "enum":
                    if self.enumnumeric:
                        res[m] = data[ix]
                    else:
                        try:
                            res[m] = list(map(midx["enummapper"].get, data[ix]))
                        except KeyError:
                            midx["enummapper"] = dict(
                                [(k, v) for v, k in midx["enumvalues"].items()]
                            )
                            res[m] = list(map(midx["enummapper"].get, data[ix]))
            elif midx.get("container", "") == "map":
                res[m] = dict()
                if midx["type"] == "primitive":
                    for k, v in data[ix].items():
                        res[m][k] = v
                elif midx["type"] == "object":
                    for k, v in data[ix].items():
                        res[m][k] = Objecter(midx, self.enumnumeric)(v)
                elif midx["type"] == "enum":
                    if self.enumnumeric:
                        for k, v in data[ix].items():
                            res[m][k] = v
                    else:
                        try:
                            for k, v in data[ix].items():
                                res[m][k] = midx["enummapper"][v]
                        except KeyError:
                            midx["enummapper"] = dict(
                                [(k, v) for v, k in midx["enumvalues"].items()]
                            )
                            for k, v in data[ix].items():
                                res[m][k] = midx["enummapper"][v]
        return res


class DDFFInventoriedStream:
    """Datastream in an inventory

    Such a datastream is timed or tagged (usually with an integer),
    and has a series of data members all of the same type.
    """

    class BaseIt:
        """Base iterator"""

        def __init__(self, ddffs: DDFFStream):
            self.reader = ddffs.reader()

        def __iter__(self):
            return self

        def __next__(self):
            raise StopIteration

    class TimeIt(BaseIt):
        """Iterator for time or tag values."""

        def __next__(self):
            """Return next time point

            Returns
            -------
            int
                Time/index value

            Raises
            ------
            StopIteration
                End of period
            """

            tmp = next(self.reader)
            return tmp[0]

    class ValueIt(BaseIt):
        """Iterator for data values"""

        def __init__(self, ddffs: DDFFStream, idx: int | None):
            """Create an iterator for data values on an inventoried stream

            Parameters
            ----------
            ddffs : DDFFStream
                Base data stream
            idx : int
                Data member to return, or None for returning the complete
                data structure
            """
            super().__init__(ddffs)
            self.idx = idx

        def __next__(self):
            """Return next data point

            Returns
            -------
            list with data
                Unpacked data from msgpack

            Raises
            ------
            StopIteration
                End of period
            """
            tmp = next(self.reader)
            if self.idx is None:
                return tmp[-1]
            return tmp[-1][self.idx]

    class TimeAndObjectIt(BaseIt):
        """Iterator for data values"""

        def __init__(self, ddffs: DDFFStream, objecter: Objecter):
            """Create an iterator for data values on an inventoried stream

            Parameters
            ----------
            ddffs : DDFFStream
                Base data stream
            idx : int
                Data member to return, or None for returning the complete
                data structure
            """
            super().__init__(ddffs)
            self.objecter = objecter

        def __next__(self):
            """Return next data point

            Returns
            -------
            list with data
                Unpacked data from msgpack

            Raises
            ------
            StopIteration
                End of period
            """
            tmp = next(self.reader)
            return (tmp[:-1], self.objecter(tmp[-1]))

    def __init__(self, ddffs: DDFFStream, tag: str, description: str):
        """Create a pared inventory of stream ids and content metadata.

        Parameters
        ----------
        ddffs : DDFFStream
            Raw stream data, in msgpack format
        tag : str
            Name of the stream, id
        description : str
            JSON encoded string with a description of the contents
        """
        self.base = ddffs
        self.tag = tag
        self.structure = json.loads(description)
        self.klass = self.structure["class"]
        self.members = {}
        for im, m in enumerate(self.structure["members"]):
            self.members[m["name"]] = im

    def time(self):
        """Create an iterator to run through all time values in the
            data stream.

        Returns
        -------
        TimeIt
            Iterator to get all time values.
        """
        return DDFFInventoriedStream.TimeIt(self.base)

    def __getitem__(self, key: int | str | None):
        """Obtain an iterator on the data

        Parameters
        ----------
        key : int|str|None
            Which part of the data to access, None gives whole structure

        Returns
        -------
        ValueIt
            Iterator on values.
        """
        if key is None:
            return DDFFInventoriedStream.ValueIt(self.base, None)
        elif isinstance(key, int):
            return DDFFInventoriedStream.ValueIt(self.base, key)
        else:
            return DDFFInventoriedStream.ValueIt(self.base, self.members[key])

    def __str__(self):
        return f'Object(class="{self.klass}",members={", ".join(self.members.keys())})'

    def get_meta(self, key: int | str | None = None):
        """Metadata description of the data in this stream

        Parameters
        ----------
        key : int | str | None, optional
            access either metadata for a single member (give by key) or for the whole
            stream, by default None

        Returns
        -------
        dict
            dictionary with data on the stream or member.
        """
        if isinstance(key, str):
            key = self.members[key]
        if key is None:
            return self.structure["members"]
        return self.structure["members"][key]

    def get_mappers(self, icount):
        """Helper to obtain mapping functions from msgpack object to numpy arrays

        Returns
        -------
        tuple(list, mappers)
            Result struct and list of mapping functions
        """
        result = dict()
        mappers = list()

        for m, midx in self.members.items():
            meminfo = self.get_meta(midx)
            res, excluded = shape_type_exclude(icount, meminfo)

            # create empty default array
            result[m] = np.zeros(**res)

            if excluded:
                # object with excluded members
                if meminfo.get("container", "") == "array":
                    if "size" in meminfo:
                        mappers.append(
                            partial(
                                _copy_object_fixed_array_exclude,
                                res=result[m],
                                midx=midx,
                                excluded=excluded,
                            )
                        )
                    else:
                        mappers.append(
                            partial(
                                _copy_object_array_exclude,
                                res=result[m],
                                midx=midx,
                                excluded=excluded,
                            )
                        )
                else:
                    mappers.append(
                        partial(
                            _copy_object_exclude,
                            res=result[m],
                            midx=midx,
                            excluded=excluded,
                        )
                    )
            elif meminfo["type"] == "object":
                # object, all members can be included
                if meminfo.get("container", "") == "array":
                    if "size" in meminfo:
                        mappers.append(
                            partial(_copy_object_fixed_array, res=result[m], midx=midx)
                        )
                    else:
                        mappers.append(
                            partial(_copy_object_array, res=result[m], midx=midx)
                        )
                else:
                    mappers.append(partial(_copy_object, res=result[m], midx=midx))
            elif meminfo["type"] == "map":
                # map object
                mappers.append(partial(_copy_map, res=result[m], midx=midx))
            elif "container" not in meminfo:
                mappers.append(partial(_copy_default, res=result[m], midx=midx))
            elif "size" in meminfo:
                mappers.append(partial(_copy_fixed_array, res=result[m], midx=midx))
            else:
                mappers.append(partial(_copy_default, res=result[m], midx=midx))
        return result, mappers


    def get_events(self, icount=100):
        """Return data as a numpy array of complex numpy type

        For "event" data, this way of obtaining the data makes it suitable for conversion
        to hdf5 format. Iterating over the stream (with __next__) returns pure-python
        objects. This returns all data points as a labeled numpy array.

        Parameters
        ----------
        icount : int, optional
            size to initially reserve for the data, by default 100
        """
        time0 = np.empty(shape=(icount,), dtype=np.uint32)
        atype = _get_object_type(self.structure)

        data = np.empty(shape=(icount,), dtype=atype[1])

        i = -1
        for i, d in enumerate(self.items(True)):
            if i == icount:
                icount = icount*2
                time0.resize((icount,))
                data.resize((icount,))
            _struc2npstruc(data[i], d[1])
            time0[i] = d[0][0]

        icount = i + 1
        time0.resize((icount,))
        data.resize((icount,))

        return time0, data

    def get_data(self, icount=100):
        """Return data from the stream as a dictionary of numpy arrays

        For "numeric" data, this way of obtaining the data is often much more
        efficient than iterating over the stream, which returns a sequence of objects with
        the data.
        This returns a dictionary of objects with numpy arrays, which can then directly
        be used in plotting, etc.

        Parameters
        ----------
        icount : int, optional
            size to initially reserve for the data, by default 100

        Returns
        -------
        (np.array, np.array, dict())
            Time points, time spans, and a dictionary with all object member data in arrays
        """

        time0 = np.zeros(shape=(icount,), dtype=np.uint32)
        time1 = np.zeros(shape=(icount,), dtype=np.uint32)
        result, mappers = self.get_mappers(icount)

        i = -1
        for i, d in enumerate(self.base.reader()):
            if i == icount:
                icount = icount * 2
                time0.resize((icount, *time0.shape[1:]))
                time1.resize((icount, *time1.shape[1:]))
                for v in result.values():
                    v.resize((icount, *v.shape[1:]), refcheck=False)
            for m in mappers:
                m(d[2], i)
            time0[i] = d[0]
            time1[i] = d[1]

        if i != icount:
            icount = i + 1
            time0.resize((icount, *time0.shape[1:]))
            time1.resize((icount, *time1.shape[1:]))
            for v in result.values():
                v.resize((icount, *v.shape[1:]), refcheck=False)

        return time0, time1, result

    def items(self, enumnumeric=False):
        """Create an iterator on the stream objects, returns time,object tuples.

        Use this to read a typically limited number of items, returned as
        python struct, and following the definition of data in the inventory.
        This is less efficient than using the get_data function.

        Returns
        -------
        Iterator on tuple(int, object)
            Runs through data. Each iteration returns the next data object as
            a dictionary.
        """
        return DDFFInventoriedStream.TimeAndObjectIt(
            self.base, Objecter(self.structure, enumnumeric)
        )


# support routines, extracting different types of objects from
# data structures
def _copy_object_fixed_array_exclude(obj, i, res, midx, excluded):
    # array of tuples
    res[i] = [(x for ix, x in enumerate(obj[midx]) if ix not in excluded)]


def _copy_object_array_exclude(obj, i, res, midx, excluded):
    # nested tuples
    res[i] = tuple((x for ix, x in enumerate(obj[midx]) if ix not in excluded))


def _copy_object_exclude(obj, i, res, midx, excluded):
    # single tuple
    res[i] = (x for ix, x in enumerate(obj[midx]) if ix not in excluded)


def _copy_object_fixed_array(obj, i, res, midx):
    # array of tuples
    res[i] = [tuple(x) for x in obj[midx]]


def _copy_object_array(obj, i, res, midx):
    # nested tuples
    res[i] = tuple(obj[midx])


def _copy_object(obj, i, res, _m, midx):
    # single tuple
    res[i] = tuple(obj[midx])


def _copy_map(obj, i, res, midx):
    res[i] = obj[midx].items()


def _copy_fixed_array(obj, i, res, midx):
    res[i] = obj[midx]


def _copy_default(obj, i, res, midx):
    res[i] = obj[midx]


class DDFFInventoried(DDFF):
    """Inventoried file representation.

    The inventory functions as a dictionary with "streams",
    partial data in the file of a specific type. Each stream
    is named, however, you can also access the streams with their
    integer id. Stream 0 for such an inventoried file is by
    definition the inventory itself.

    The dictionary members are data streams of DDFFInventoriedStream
    type. These are tagged with a time or index, and are all of the same
    data type.
    """

    def __init__(self, fname: str, *args, mode="r", nstreams=frozenset((0,)), **kwargs):
        """Open or create an inventoried DDFF file

        Parameters
        ----------
        fname : str
            File name.
        mode : str, optional
            Reading or writing mode, by default "r".
        nstreams : iterable with integers, optional
            Streams to fully scan, by default frozenset((0,)), the stream with the inventory
        """

        # analyse with base DDFF read, scans my requested base streams
        super().__init__(fname, *args, mode=mode, nstreams=nstreams, **kwargs)
        self.mapping = {}

        # read the inventory into the stream as list
        self.streams[0].read_to_list()

        if len(nstreams) == 1:
            self._do_initial_scan()

    def _do_initial_scan(self, offsets=None):

        # Read how many data streams are there
        descriptions = self.streams[0]
        neededstreams = frozenset((d[1] for d in descriptions))

        # find the initial blocks for streams with data
        if offsets:
            self._initStreams(neededstreams, offsets)
        else:
            self._scan_streams(neededstreams)

        # Use the inventory to enhance the streams
        for tag, streamid, description in descriptions:

            try:
                # replace/swap the raw streams with inventoried ones
                self.streams[streamid] = DDFFInventoriedStream(
                    self.streams[streamid], tag, description
                )
                self.mapping[tag] = self.streams[streamid]
            except KeyError:
                print(f"Cannot find data for stream {streamid}/{tag}, create empty")
                base = DDFFStream(self.file, stream_id=streamid)
                self.streams[streamid] = DDFFInventoriedStream(base, tag, description)

    def __getitem__(self, key: str | int):
        """Access a specific data stream in the file

        Parameters
        ----------
        key : str|int
            Stream id or number to access.

        Returns
        -------
        DDFFInventoriedStream
            Data access.
        """
        if isinstance(key, int):
            return self.streams[self.streams[0][key][1]]
        return self.mapping[key]

    def keys(self):
        """Return an overview of available named streams.

        Returns:
            Iterator of strings
        """
        return [k[0] for k in self.streams[0]]

    def __len__(self):
        """Return number of data streams.

        Returns:
            Integer
        """
        return len(self.streams[0])


if __name__ == "__main__":

    stuff = DDFFInventoried(
        os.path.dirname(__file__) + "/../../../test/ddff/recordings-PHLAB-new.ddff"
    )

    # known entries
    print(stuff.keys())

    for t in stuff["WriteUnified:first blip"].time():
        print(t)

    for x in stuff["WriteUnified:first blip"]["rx"]:
        print(x)
    for x in stuff["WriteUnified:first blip"]["ry"]:
        print(x)

    t0, t1, _data = stuff["WriteUnified:first blip"].get_data()
    print(t0, t1, _data)
