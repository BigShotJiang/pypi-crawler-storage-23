"""
This package contains built in EntityModel instances supplied by ibek itself.
"""
