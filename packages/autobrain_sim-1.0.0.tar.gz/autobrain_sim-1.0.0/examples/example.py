"""
Example usage of the WorldQuant Brain API client library.
"""

from brain_client import BrainClient

# ── วิธีที่ 1: ใส่ email/password โดยตรง ────────────────────────────────────
client = BrainClient(email="your@email.com", password="yourpassword")
client.authenticate()

# ── วิธีที่ 2: Interactive prompt (ถามตอนรัน) ────────────────────────────────
# client = BrainClient()          # ถ้าไม่มี ~/.brain_credentials จะ prompt อัตโนมัติ
# client.authenticate()

# ── วิธีที่ 3: login() — สั้นสุด สร้าง + auth ในบรรทัดเดียว ─────────────────
# client = BrainClient.login()                          # interactive prompt
# client = BrainClient.login("your@email.com", "pass") # หรือใส่ตรงๆ

# ── วิธีที่ 4: Credentials file ──────────────────────────────────────────────
# client = BrainClient(credentials_file="~/my_creds.json")
# client.authenticate()

print("Authenticated!")

# Submit simulation
sim = client.simulate(
    expression="close / ts_mean(close, 20) - 1",
    settings={
        "region": "USA",
        "universe": "TOP3000",
        "neutralization": "SUBINDUSTRY",
    }
)

result = sim.wait(verbose=True)
print("Alpha ID:", sim.alpha_id)

alpha = sim.get_alpha()
print("Sharpe:", alpha["is"]["sharpe"])
print("Fitness:", alpha["is"]["fitness"])
