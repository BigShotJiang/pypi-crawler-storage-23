"""Risk scoring."""

from skill_scanner.scoring.risk import evaluate_risk

__all__ = ["evaluate_risk"]
