"""Chaotic CLI command modules.

Each module defines a Click command group (or root-level commands).
Import and register them on the `cli` group from main.py.
"""
