"""Bash command execution tool for agent operations."""

import asyncio
import os
import subprocess
from asyncio.subprocess import Process

from tunacode.configuration.limits import get_command_limit
from tunacode.exceptions import ToolRetryError

from tunacode.tools.decorators import base_tool

COMMAND_OUTPUT_THRESHOLD = 3500
COMMAND_OUTPUT_START_INDEX = 2500
COMMAND_OUTPUT_END_SIZE = 1000
CMD_OUTPUT_TRUNCATED = "\n...\n[truncated]\n...\n"
MIN_TIMEOUT_SECONDS = 1
MAX_TIMEOUT_SECONDS = 300
DEFAULT_TIMEOUT_SECONDS = 30


@base_tool
async def bash(
    command: str,
    cwd: str | None = None,
    env: dict[str, str] | None = None,
    timeout: int | None = DEFAULT_TIMEOUT_SECONDS,
    capture_output: bool = True,
) -> str:
    """Execute a bash command with enhanced features.

    Args:
        command: The bash command to execute.
        cwd: Working directory for the command.
        env: Additional environment variables to set.
        timeout: Command timeout in seconds (1-300, default 30).
        capture_output: Whether to capture stdout/stderr.

    Returns:
        Formatted output with exit code, stdout, and stderr.
    """
    _validate_inputs(command, cwd, timeout)

    exec_env = os.environ.copy()
    if env:
        for key, value in env.items():
            if isinstance(key, str) and isinstance(value, str):
                exec_env[key] = value

    exec_cwd = cwd or os.getcwd()

    process = None
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=subprocess.PIPE if capture_output else None,
            stderr=subprocess.PIPE if capture_output else None,
            cwd=exec_cwd,
            env=exec_env,
        )

        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        except TimeoutError as err:
            process.kill()
            await process.wait()
            raise ToolRetryError(
                f"Command timed out after {timeout} seconds: {command}\n"
                "Consider using a longer timeout or breaking the command into smaller parts."
            ) from err

        stdout_text = stdout.decode("utf-8", errors="replace").strip() if stdout else ""
        stderr_text = stderr.decode("utf-8", errors="replace").strip() if stderr else ""

        return_code = process.returncode
        assert return_code is not None

        _check_common_errors(command, return_code, stderr_text)

        return _format_output(command, return_code, stdout_text, stderr_text, exec_cwd)

    except FileNotFoundError as err:
        raise ToolRetryError(
            f"Shell not found. Cannot execute command: {command}\n"
            "This typically indicates a system configuration issue."
        ) from err
    finally:
        await _cleanup_process(process)


def _validate_inputs(command: str, cwd: str | None, timeout: int | None) -> None:
    """Validate command inputs."""
    if not command.strip():
        raise ToolRetryError("Empty command not allowed")

    if timeout is not None and (timeout < MIN_TIMEOUT_SECONDS or timeout > MAX_TIMEOUT_SECONDS):
        raise ToolRetryError(
            f"Timeout must be between {MIN_TIMEOUT_SECONDS} and {MAX_TIMEOUT_SECONDS} seconds. "
            "Use shorter timeouts for quick commands, longer for builds/tests."
        )

    if cwd and not os.path.isdir(cwd):
        raise ToolRetryError(
            f"Working directory '{cwd}' does not exist. "
            "Please verify the path or create the directory first."
        )


def _check_common_errors(command: str, returncode: int, stderr: str) -> None:
    """Check for common error patterns and provide guidance."""
    if returncode == 0 or not stderr:
        return


async def _cleanup_process(process: Process | None) -> None:
    """Ensure process cleanup."""
    if process is None or process.returncode is not None:
        return

    try:
        try:
            process.terminate()
            await asyncio.wait_for(process.wait(), timeout=5.0)
        except TimeoutError:
            process.kill()
            await asyncio.wait_for(process.wait(), timeout=1.0)
    except Exception:
        pass


def _format_output(command: str, exit_code: int, stdout: str, stderr: str, cwd: str) -> str:
    """Format command output."""
    lines = [
        f"Command: {command}",
        f"Exit Code: {exit_code}",
        f"Working Directory: {cwd}",
        "",
        "STDOUT:",
        stdout or "(no output)",
        "",
        "STDERR:",
        stderr or "(no errors)",
    ]

    result = "\n".join(lines)

    max_output = get_command_limit()
    if len(result) > max_output:
        start_part = result[:COMMAND_OUTPUT_START_INDEX]
        if len(result) > COMMAND_OUTPUT_THRESHOLD:
            end_part = result[-COMMAND_OUTPUT_END_SIZE:]
        else:
            end_part = result[COMMAND_OUTPUT_START_INDEX:]
        result = start_part + CMD_OUTPUT_TRUNCATED + end_part

    return result
