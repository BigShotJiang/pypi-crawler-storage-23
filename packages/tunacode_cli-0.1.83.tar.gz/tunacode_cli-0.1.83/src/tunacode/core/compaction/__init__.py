"""Context compaction package."""
