# SPDX-License-Identifier: MIT
# Copyright (c) 2025 OmniNode Team
"""Pattern Storage Effect node.

This module exports the pattern storage effect node and its supporting
models, handlers, and protocols. The node persists learned patterns
with governance enforcement and state promotion capabilities.

Key Components:
    - NodePatternStorageEffect: Pure declarative effect node (thin shell)
    - ModelPatternStorageInput: Input from pattern-learned.v1 events
    - ModelPatternStoredEvent: Output for pattern-stored.v1 events
    - ModelPatternPromotedEvent: Output for pattern-promoted.v1 events
    - EnumPatternState: Pattern lifecycle states (candidate/provisional/validated)
    - ProtocolPatternStore: Interface for pattern storage backends
    - ProtocolPatternStateManager: Interface for state management backends
    - ContractLoader: Declarative contract loading and handler dispatch

Governance Invariants:
    - Confidence >= 0.5 (MIN_CONFIDENCE)
    - UNIQUE(domain, signature_hash, version)
    - UNIQUE(domain, signature_hash) WHERE is_current = true

State Transitions:
    - CANDIDATE -> PROVISIONAL: Pattern passes verification
    - PROVISIONAL -> VALIDATED: Pattern meets all validation criteria

Usage (Declarative Pattern):
    from omniintelligence.nodes.node_pattern_storage_effect import (
        NodePatternStorageEffect,
        handle_store_pattern,
        handle_promote_pattern,
        ModelPatternStorageInput,
        EnumPatternState,
    )

    # Create node via container (pure declarative shell)
    from omnibase_core.models.container import ModelONEXContainer
    container = ModelONEXContainer()
    node = NodePatternStorageEffect(container)

    # Handlers are called directly with their dependencies
    result = await handle_store_pattern(
        input_data=ModelPatternStorageInput(...),
        pattern_store=pattern_store_impl,
        conn=db_conn,
    )

    # For event-driven execution, use RuntimeHostProcess
    # which reads handler_routing from contract.yaml

Reference:
    - OMN-1668: Pattern storage effect node implementation
    - OMN-1757: Refactor to declarative pattern
"""

# State transition constants and validation (canonical source: constants.py)
from omniintelligence.nodes.node_pattern_storage_effect.constants import (
    VALID_TRANSITIONS,
    get_valid_targets,
    is_valid_transition,
)
from omniintelligence.nodes.node_pattern_storage_effect.contract_loader import (
    ContractLoader,
    EventBusConfig,
    HandlerConfig,
    HandlerRouting,
    OperationHandler,
    clear_loader_cache,
    get_contract_loader,
)
from omniintelligence.nodes.node_pattern_storage_effect.handlers import (
    DEFAULT_ACTOR,
    GovernanceResult,
    GovernanceViolation,
    ModelStateTransition,
    PatternNotFoundError,
    PatternStateTransition,
    PatternStateTransitionError,
    PromotePatternResult,
    ProtocolPatternStateManager,
    ProtocolPatternStore,
    StorePatternResult,
    handle_promote_pattern,
    handle_store_pattern,
    validate_governance,
)
from omniintelligence.nodes.node_pattern_storage_effect.models import (
    EnumPatternState,
    ModelPatternMetricsSnapshot,
    ModelPatternPromotedEvent,
    ModelPatternStorageInput,
    ModelPatternStorageMetadata,
    ModelPatternStoredEvent,
    PatternStorageGovernance,
)
from omniintelligence.nodes.node_pattern_storage_effect.node import (
    NodePatternStorageEffect,
)

__all__ = [
    "DEFAULT_ACTOR",
    "VALID_TRANSITIONS",
    "ContractLoader",
    "EnumPatternState",
    "EventBusConfig",
    "GovernanceResult",
    "GovernanceViolation",
    "HandlerConfig",
    "HandlerRouting",
    "ModelPatternMetricsSnapshot",
    "ModelPatternPromotedEvent",
    "ModelPatternStorageInput",
    "ModelPatternStorageMetadata",
    "ModelPatternStoredEvent",
    "ModelStateTransition",
    "NodePatternStorageEffect",
    "OperationHandler",
    "PatternNotFoundError",
    "PatternStateTransition",
    "PatternStateTransitionError",
    "PatternStorageGovernance",
    "PromotePatternResult",
    "ProtocolPatternStateManager",
    "ProtocolPatternStore",
    "StorePatternResult",
    "clear_loader_cache",
    "get_contract_loader",
    "get_valid_targets",
    "handle_promote_pattern",
    "handle_store_pattern",
    "is_valid_transition",
    "validate_governance",
]
