"""Intelligence Reducer Node."""

from omniintelligence.nodes.node_intelligence_reducer.node import (
    NodeIntelligenceReducer,
)

__all__ = ["NodeIntelligenceReducer"]
