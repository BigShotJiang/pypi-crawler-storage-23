"""Quality Scoring Compute Node."""

from omniintelligence.nodes.node_quality_scoring_compute.node import (
    NodeQualityScoringCompute,
)

__all__ = ["NodeQualityScoringCompute"]
