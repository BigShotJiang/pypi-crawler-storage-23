"""Intent Classifier Compute Node."""

from omniintelligence.nodes.node_intent_classifier_compute.node import (
    NodeIntentClassifierCompute,
)

__all__ = ["NodeIntentClassifierCompute"]
