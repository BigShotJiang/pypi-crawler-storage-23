# SPDX-License-Identifier: Apache-2.0
"""
OmniIntelligence Runtime Contracts Package.

Contains YAML contract definitions for the runtime configuration.
"""
