"""Command-line interface for dotpromptz.

Usage::

    dotprompt my_prompt.prompt input.json
    dotprompt my_prompt.prompt input.yaml --dry-run
    dotprompt my_prompt.prompt batch_inputs.jsonl
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
from pathlib import Path
from typing import Any

import click
from dotenv import load_dotenv

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore

from dotpromptz import Dotprompt
from dotpromptz.adapters import get_adapter, list_adapters
from dotpromptz.typing import AdapterConfig, DataArgument


def _configure_logging(verbose: bool = False) -> None:
    """Send all log output to stderr so stdout stays clean for CLI output.

    Args:
        verbose: If True, set level to DEBUG; otherwise WARNING.
    """
    level = logging.DEBUG if verbose else logging.WARNING
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(level)
    logging.root.handlers = [handler]
    logging.root.setLevel(level)

    # Silence structlog if present as a transitive dependency (e.g. dotpromptz-handlebars).
    try:
        import structlog

        structlog.configure(
            wrapper_class=structlog.make_filtering_bound_logger(level),
            logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        )
    except ImportError:
        pass



def _run_coroutine(coro: Any) -> Any:
    """Run an async coroutine from synchronous code.

    Avoids ``asyncio.run()`` as it closes the event loop which can
    interfere with callers that still need their I/O handles (e.g.
    Click's ``CliRunner``).

    Args:
        coro: The awaitable coroutine to run.

    Returns:
        The coroutine result.
    """
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        # Shut down async generators but do NOT call loop.close() —
        # that closes the selector and can invalidate I/O file
        # descriptors shared with the caller (e.g. Click CliRunner).
        try:
            loop.run_until_complete(loop.shutdown_asyncgens())
        except Exception:  # noqa: BLE001 — best-effort cleanup, cannot propagate here
            pass


def _load_env_file(env_file: str | None) -> None:
    """Load a ``.env`` file if it exists.

    Args:
        env_file: Path to the env file. ``None`` means try ``.env`` in cwd.
    """
    path = Path(env_file) if env_file else Path('.env')
    if path.is_file():
        load_dotenv(path, override=False)


def _load_input_file(path: str) -> dict | list[dict]:
    """Load input from .json, .yaml, .yml, or .jsonl file.

    Args:
        path: Path to the input file.

    Returns:
        A dict (single execution) or list of dicts (batch execution).

    Raises:
        click.UsageError: On unsupported file extension or invalid format.
    """
    p = Path(path)
    ext = p.suffix.lower()

    try:
        content = p.read_text(encoding='utf-8')
    except OSError as exc:
        raise click.UsageError(f'Failed to read input file: {exc}') from exc

    # JSON format
    if ext == '.json':
        try:
            data = json.loads(content)
        except json.JSONDecodeError as exc:
            raise click.UsageError(f'Invalid JSON: {exc}') from exc

        # Validate: must be dict or list[dict]
        if isinstance(data, dict):
            return data
        elif isinstance(data, list):
            if not all(isinstance(item, dict) for item in data):
                raise click.UsageError('JSON array must contain only objects (dicts)')
            return data
        else:
            raise click.UsageError(f'JSON must be an object or array, not {type(data).__name__}')

    # YAML format
    elif ext in ('.yaml', '.yml'):
        if yaml is None:
            raise click.UsageError('YAML support requires PyYAML: pip install pyyaml')
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as exc:
            raise click.UsageError(f'Invalid YAML: {exc}') from exc

        # Validate: must be dict or list[dict]
        if isinstance(data, dict):
            return data
        elif isinstance(data, list):
            if not all(isinstance(item, dict) for item in data):
                raise click.UsageError('YAML array must contain only objects (dicts)')
            return data
        else:
            raise click.UsageError(f'YAML must be an object or array, not {type(data).__name__}')

    # JSONL format (always returns list)
    elif ext == '.jsonl':
        items = []
        for line_num, line in enumerate(content.splitlines(), start=1):
            stripped = line.strip()
            if not stripped:  # Skip blank lines
                continue
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError as exc:
                raise click.UsageError(f'Invalid JSON at line {line_num}: {exc}') from exc
            if not isinstance(obj, dict):
                raise click.UsageError(f'JSONL line {line_num} must be an object, not {type(obj).__name__}')
            items.append(obj)
        return items

    else:
        raise click.UsageError(f'Unsupported input file format: {ext}. Supported: .json, .yaml, .yml, .jsonl')


# Model-name prefixes used to auto-infer a suitable adapter.
_MODEL_ADAPTER_PREFIXES: list[tuple[str, str]] = [
    ('gpt-', 'openai'),
    ('o1', 'openai'),
    ('o3', 'openai'),
    ('o4', 'openai'),
    ('chatgpt', 'openai'),
    ('claude', 'anthropic'),
    ('gemini', 'google'),
]


def _infer_adapter_from_model(model: str | None) -> str | None:
    """Guess the adapter name from the model identifier.

    Args:
        model: The model string from the prompt frontmatter.

    Returns:
        An adapter name, or ``None`` if it cannot be inferred.
    """
    if not model:
        return None
    lower = model.lower()
    for prefix, adapter_name in _MODEL_ADAPTER_PREFIXES:
        if lower.startswith(prefix):
            return adapter_name
    return None


def _resolve_adapter(rendered: Any) -> Any:
    """Resolve adapter from RenderedPrompt's adapter field.

    Handles three scenarios:
    1. AdapterConfig object: use name and base_url/api_key
    2. String adapter name: use directly
    3. None: auto-infer from config.model or rendered.model

    Args:
        rendered: The RenderedPrompt with adapter configuration.

    Returns:
        An Adapter instance ready to generate responses.

    Raises:
        click.UsageError: If no adapter can be determined.
    """
    adapter_cfg = rendered.adapter  # str | AdapterConfig | None
    adapter_name: str | None = None
    adapter_kwargs: dict[str, Any] = {}

    if isinstance(adapter_cfg, AdapterConfig):
        adapter_name = adapter_cfg.name
        if adapter_cfg.base_url:
            adapter_kwargs['base_url'] = adapter_cfg.base_url
        if adapter_cfg.api_key:
            adapter_kwargs['api_key'] = adapter_cfg.api_key
    elif isinstance(adapter_cfg, str):
        adapter_name = adapter_cfg
    else:
        # Auto-infer from config.model or legacy top-level model.
        config = rendered.config if isinstance(rendered.config, dict) else {}
        model_name = config.get('model') or rendered.model
        adapter_name = _infer_adapter_from_model(model_name)

    if not adapter_name:
        available = ', '.join(list_adapters())
        raise click.UsageError(
            'Cannot determine which adapter to use. '
            f'Add "adapter: <name>" to the .prompt frontmatter, '
            f'or use a model name that can be auto-detected. '
            f'Available adapters: {available}'
        )

    return get_adapter(adapter_name, **adapter_kwargs)


def _part_to_dict(part: Any) -> dict[str, Any]:
    """Convert a Part to a simple dict for JSON output.

    Args:
        part: A dotprompt Part object.

    Returns:
        A simplified dict representation.
    """
    from dotpromptz.typing import (
        DataPart,
        MediaPart,
        TextPart,
        ToolRequestPart,
        ToolResponsePart,
    )

    if isinstance(part, TextPart):
        return {'text': part.text}
    if isinstance(part, MediaPart):
        return {'media': part.media.model_dump(exclude_none=True, by_alias=True)}
    if isinstance(part, DataPart):
        return {'data': part.data}
    if isinstance(part, ToolRequestPart):
        return {'tool_request': part.tool_request.model_dump(exclude_none=True)}
    if isinstance(part, ToolResponsePart):
        return {'tool_response': part.tool_response.model_dump(exclude_none=True)}
    return {'type': type(part).__name__}


@click.command()
@click.argument('prompt_file', type=click.Path(exists=True, dir_okay=False))
@click.argument('input_file', type=click.Path(exists=True, dir_okay=False))
@click.option('--dry-run', is_flag=True, default=False, help='Only render the prompt, do not call the API.')
@click.option('-v', '--verbose', is_flag=True, default=False, help='Enable verbose logging to stderr.')
@click.version_option(package_name='dotpromptz')
def cli(
    prompt_file: str,
    input_file: str,
    dry_run: bool,
    verbose: bool,
) -> None:
    """Run a .prompt file against an LLM API (single or batch mode auto-detected).

    Auto-detects single vs batch mode based on input file contents:
    - Dict input → single execution
    - List input → batch execution with concurrency control

    Batch execution settings (max_workers, output_dir, jsonl) are read from
    the .prompt file's 'runtime:' section.

    PROMPT_FILE is the path to a .prompt file.
    INPUT_FILE is a .json, .yaml, .yml, or .jsonl file with input variables.

    Examples::

      dotprompt explain.prompt input.json
      dotprompt explain.prompt input.yaml --dry-run
      dotprompt explain.prompt batch_inputs.jsonl
    """
    _configure_logging(verbose)
    _run_coroutine(
        _run_cli_async(
            prompt_file=prompt_file,
            input_file=input_file,
            dry_run=dry_run,
            verbose=verbose,
        )
    )


async def _run_cli_async(
    *,
    prompt_file: str,
    input_file: str,
    dry_run: bool,
    verbose: bool,
) -> None:
    """Async implementation of the unified CLI command."""
    # 1. Load .env from cwd if present.
    _load_env_file(None)

    # 2. Read the prompt source.
    source = Path(prompt_file).read_text(encoding='utf-8')

    # 3. Load input data (dict or list).
    input_data = _load_input_file(input_file)

    # 4. Auto-detect mode.
    if isinstance(input_data, dict):
        # Single execution mode
        await _run_single(source, input_data, dry_run, verbose)
    elif isinstance(input_data, list):
        # Batch execution mode
        if not input_data:  # Empty list
            return  # Exit silently with code 0
        await _run_batch(source, input_data, dry_run, verbose)
    else:
        raise click.UsageError(f'Invalid input data type: {type(input_data).__name__}')


async def _run_single(
    source: str,
    input_data: dict,
    dry_run: bool,
    verbose: bool,
) -> None:
    """Execute single prompt rendering and generation.

    Args:
        source: The .prompt file content.
        input_data: Dict of input variables.
        dry_run: If True, only render; don't call API.
        verbose: If True, print request details.
    """
    # 1. Create Dotprompt instance and render.
    dp = Dotprompt()
    rendered = await dp.render(source, data=DataArgument(input=input_data))

    # 2. Dry-run: print rendered messages and exit.
    if dry_run:
        config = rendered.config if isinstance(rendered.config, dict) else {}
        effective_model = config.get('model') or rendered.model or (rendered.raw or {}).get('model')
        output = {
            'model': effective_model,
            'messages': [
                {
                    'role': m.role.value,
                    'content': [_part_to_dict(p) for p in m.content],
                }
                for m in rendered.messages
            ],
        }
        if rendered.tool_defs:
            output['tool_defs'] = [td.model_dump(exclude_none=True, by_alias=True) for td in rendered.tool_defs]
        if rendered.config:
            output['config'] = rendered.config if isinstance(rendered.config, dict) else str(rendered.config)
        click.echo(json.dumps(output, indent=2, ensure_ascii=False))
        return

    # 3. Resolve adapter.
    adapter = _resolve_adapter(rendered)

    # 4. Verbose: print request body.
    if verbose:
        request_dict = adapter.convert(rendered)
        click.echo('--- Request ---', err=True)
        click.echo(json.dumps(request_dict, indent=2, ensure_ascii=False, default=str), err=True)
        click.echo('--- Response ---', err=True)

    # 5. Generate.
    try:
        response = await adapter.generate(rendered)
    except ImportError as exc:
        raise click.ClickException(str(exc)) from exc

    # 6. Output.
    if response.image:
        click.echo(f'Image saved to: {response.image.saved_path}')
    elif response.text:
        click.echo(response.text)
    elif response.tool_calls:
        click.echo(json.dumps([tc.model_dump() for tc in response.tool_calls], indent=2, ensure_ascii=False))

    if verbose and response.usage:
        click.echo(f'\n--- Usage: {response.usage.model_dump(by_alias=True)} ---', err=True)


async def _run_batch(
    source: str,
    input_list: list[dict],
    dry_run: bool,
    verbose: bool,
) -> None:
    """Execute batch prompt rendering and generation with concurrency control.

    Args:
        source: The .prompt file content.
        input_list: List of input variable dicts.
        dry_run: If True, only render; don't call API.
        verbose: If True, print verbose output to stderr.
    """
    # 1. Create Dotprompt instance.
    dp = Dotprompt()

    # 2. Parse the prompt once to get runtime config.
    from dotpromptz.parse import parse_document

    parsed_prompt = parse_document(source)
    runtime_config = parsed_prompt.runtime  # RuntimeConfig | None

    # 3. Get batch settings from runtime config.
    max_workers = runtime_config.max_workers if runtime_config else 5
    output_dir = runtime_config.output_dir if runtime_config else None
    # jsonl_format = runtime_config.jsonl if runtime_config else False  # Currently always JSONL anyway

    # 4. Render first item to resolve adapter (only needed if not dry-run).
    if not dry_run:
        first_rendered = await dp.render(source, data=DataArgument(input=input_list[0]))
        adapter = _resolve_adapter(first_rendered)
    else:
        adapter = None

    # 5. Create output directory if needed (before concurrent tasks).
    if output_dir:
        Path(output_dir).mkdir(parents=True, exist_ok=True)

    # 6. Create semaphore for concurrency control.
    sem = asyncio.Semaphore(max_workers)

    # 7. Define task function to process one input.
    async def _process_one(index: int, variables: dict[str, Any]) -> dict[str, Any]:
        async with sem:
            try:
                # Render the prompt with this input set
                rendered = await dp.render(source, data=DataArgument(input=variables))

                if dry_run:
                    # Dry-run mode: return rendered messages without API call
                    config = rendered.config if isinstance(rendered.config, dict) else {}
                    effective_model = config.get('model') or rendered.model or (rendered.raw or {}).get('model')
                    return {
                        'index': index,
                        'input': variables,
                        'status': 'success',
                        'messages': [
                            {
                                'role': m.role.value,
                                'content': [_part_to_dict(p) for p in m.content],
                            }
                            for m in rendered.messages
                        ],
                        'model': effective_model,
                    }
                else:
                    # Real API call
                    response = await adapter.generate(rendered)
                    return {
                        'index': index,
                        'input': variables,
                        'status': 'success',
                        'text': response.text,
                        'tool_calls': [tc.model_dump() for tc in response.tool_calls] if response.tool_calls else None,
                        'image': response.image.saved_path if response.image else None,
                        'usage': response.usage.model_dump(by_alias=True) if response.usage else None,
                        'model': response.model,
                        'finish_reason': response.finish_reason,
                        'error': None,
                    }
            except Exception as exc:
                # Capture any error as a result
                return {
                    'index': index,
                    'input': variables,
                    'status': 'error',
                    'text': None,
                    'tool_calls': None,
                    'image': None,
                    'usage': None,
                    'model': None,
                    'finish_reason': None,
                    'error': str(exc),
                }

    # 8. Run all tasks concurrently with gather(return_exceptions=True)
    tasks = [_process_one(i, v) for i, v in enumerate(input_list)]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # 9. Handle any unexpected exceptions from gather
    final_results = []
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            # Unexpected exception that wasn't caught in _process_one
            final_results.append({
                'index': i,
                'input': input_list[i],
                'status': 'error',
                'text': None,
                'tool_calls': None,
                'image': None,
                'usage': None,
                'model': None,
                'finish_reason': None,
                'error': str(result),
            })
        else:
            final_results.append(result)

    # 10. Sort by index to maintain order
    final_results.sort(key=lambda r: r['index'])

    # 11. Output results
    if output_dir:
        # Write individual JSON files
        for result in final_results:
            filename = f'{result["index"]}.json'
            filepath = Path(output_dir) / filename
            filepath.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    # Always output to stdout as JSONL
    for result in final_results:
        click.echo(json.dumps(result, ensure_ascii=False))

    # Exit with error code if ALL items failed
    failed = sum(1 for r in final_results if r.get('status') == 'error')
    if failed == len(final_results):
        sys.exit(1)
