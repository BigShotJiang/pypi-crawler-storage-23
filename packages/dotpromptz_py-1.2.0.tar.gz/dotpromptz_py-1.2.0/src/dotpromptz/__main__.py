"""Allow running dotpromptz as ``python -m dotpromptz``."""

from dotpromptz.cli import cli

if __name__ == '__main__':
    cli()
