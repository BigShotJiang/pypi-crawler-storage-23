# Session / Auth Skill

Authenticate users, manage sessions with tokens, expiry, and refresh.

## Auth Methods

- Password (PBKDF2-SHA256 hashed)
- Magic link (email-based, from core)
- SSO (from core/auth)
- API token

## Session Management

- Token-based sessions with configurable expiry
- Session validation on every request
- Revocation (single session or all user sessions)
- Audit logging of all auth events
