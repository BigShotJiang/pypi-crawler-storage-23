# Contacts Skill

Unified address book that cross-references across all other skills.
The connective tissue of the entire platform.

## Usage

Use this skill when the user wants to:
- Add, update, or look up contacts
- Find contact information (email, phone, org, role)
- Link contacts to donor records, email threads, calendar events
- Import/export contacts from vCard (.vcf) or CSV
- Merge duplicate contacts
- View interaction history across all skills for a given person

## Cross-Skill Integration

Contacts provides the unified identity layer. Other skills reference
contacts by ID so the agent can answer "who is Mrs. Henderson" across
email, donor records, calendar, and messaging.

- **nonprofit**: Donors auto-link to contacts. donor_details pulls from contacts.
- **email**: Incoming emails resolve sender to contact. Drafts pre-fill from contacts.
- **calendar**: Meeting attendees resolved from contacts.
- **tasks**: Task assignees reference contacts.

## Data Privacy

Contact records may contain PII. When HIPAA compliance mode is active,
contacts are encrypted at rest via EncryptedJSONStorage. Never share
full contact lists externally.
