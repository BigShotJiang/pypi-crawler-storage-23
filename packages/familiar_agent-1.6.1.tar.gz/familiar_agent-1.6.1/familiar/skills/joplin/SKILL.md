# Joplin Notes

Manage notes and notebooks via Joplin Data API.

## Setup
Set `JOPLIN_TOKEN` environment variable. Optionally set `JOPLIN_URL` (defaults to `http://localhost:41184`).

## Tools
- `joplin_list_notebooks` — List all notebooks
- `joplin_search_notes` — Search notes by query
- `joplin_get_note` — Get a note's content
- `joplin_create_note` — Create a new note
- `joplin_update_note` — Update an existing note
- `joplin_list_tags` — List all tags
