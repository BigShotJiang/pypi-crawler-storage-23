# Home Assistant

Control your smart home via Home Assistant.

## Setup
Set `HOMEASSISTANT_URL` and `HOMEASSISTANT_TOKEN` environment variables.

## Tools
- `ha_list_entities` — List entities by domain (light, switch, sensor, etc.)
- `ha_get_state` — Get current state of an entity
- `ha_call_service` — Call a Home Assistant service (requires confirmation)
- `ha_toggle_entity` — Toggle an entity on/off (requires confirmation)
- `ha_get_history` — Get entity history
- `ha_create_automation` — Create a new automation (requires confirmation)
