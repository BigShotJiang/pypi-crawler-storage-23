# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar MCP (Model Context Protocol) Integration

Provides connectivity to MCP servers, enabling access to the universal
tool ecosystem including GitHub, Slack, filesystem, databases, and more.

Usage:
    from familiar.core.mcp import MCPManager, MCPConfig

    # Configure servers
    config = MCPConfig(servers=[
        MCPServerConfig(
            name="github",
            transport="stdio",
            command="npx",
            args=["-y", "@modelcontextprotocol/server-github"],
            env={"GITHUB_TOKEN": os.environ["GITHUB_TOKEN"]}
        ),
        MCPServerConfig(
            name="filesystem",
            transport="stdio",
            command="uvx",
            args=["mcp-server-filesystem", "/home/user/documents"]
        ),
    ])

    # Initialize manager
    manager = MCPManager(config)
    await manager.connect_all()

    # Get tools for agent
    tools = manager.get_familiar_tools()

    # Or integrate with existing ToolRegistry
    registry = get_tool_registry()
    manager.register_with_tool_registry(registry)

See Also:
    - https://modelcontextprotocol.io/specification
    - https://github.com/modelcontextprotocol
"""

from .bridge import MCPToolBridge, mcp_tool_to_familiar
from .client import MCPClient, MCPClientError, MCPConnectionError
from .config import MCPConfig, MCPServerConfig, MCPTransport
from .manager import MCPManager
from .server import (
    SkillMCPServer,
    generate_claude_desktop_config,
    generate_vscode_config,
    get_available_skills,
)

__all__ = [
    # Config
    "MCPConfig",
    "MCPServerConfig",
    "MCPTransport",
    # Client
    "MCPClient",
    "MCPClientError",
    "MCPConnectionError",
    # Manager
    "MCPManager",
    # Bridge
    "MCPToolBridge",
    "mcp_tool_to_familiar",
    # Server (new — skills as MCP servers)
    "SkillMCPServer",
    "get_available_skills",
    "generate_claude_desktop_config",
    "generate_vscode_config",
]

__version__ = "1.0.0"
