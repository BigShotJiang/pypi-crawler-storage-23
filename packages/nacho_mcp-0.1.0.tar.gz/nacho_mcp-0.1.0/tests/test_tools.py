import httpx
import pytest
from unittest.mock import patch

from nacho_mcp.tools import (
    NachoAPIError,
    _api_get,
    _get_api_url,
    _get_headers,
    info,
    init,
    install,
    pull,
    search,
)


def _resp(status_code=200, json=None, text=""):
    """Create an httpx.Response for testing."""
    kwargs = {"request": httpx.Request("GET", "http://test")}
    if json is not None:
        kwargs["json"] = json
    else:
        kwargs["text"] = text
    return httpx.Response(status_code, **kwargs)


SEARCH_ITEM = {
    "owner_username": "nacho",
    "name": "fastapi-react",
    "title": "FastAPI + React",
    "short_description": "Full-stack web app template",
    "tags": ["python", "react"],
    "download_count": 42,
    "upvote_count": 10,
}

SEARCH_RESPONSE = {
    "items": [SEARCH_ITEM],
    "total": 1,
    "page": 1,
    "pages": 1,
    "per_page": 10,
}

EMPTY_SEARCH = {"items": [], "total": 0, "page": 1, "pages": 0, "per_page": 10}

CONTEXT_DATA = {
    "id": "abc-123",
    "owner_username": "nacho",
    "name": "fastapi-react",
    "title": "FastAPI + React",
    "short_description": "Full-stack template",
    "long_description": "A complete full-stack template with FastAPI and React.",
    "tags": ["python", "react"],
    "download_count": 42,
    "upvote_count": 10,
    "latest_version": 3,
    "license": "MIT",
}

VERSIONS_DATA = [
    {"version": 3, "changelog": "Added tests", "created_at": "2025-01-15T00:00:00Z"},
    {"version": 2, "changelog": "Bug fixes", "created_at": "2025-01-10T00:00:00Z"},
]


# --- _get_api_url ---


def test_get_api_url_default(monkeypatch):
    monkeypatch.delenv("NACHO_API_URL", raising=False)
    assert _get_api_url() == "http://localhost:8000/api"


def test_get_api_url_env_override(monkeypatch):
    monkeypatch.setenv("NACHO_API_URL", "https://nacho.example.com/api")
    assert _get_api_url() == "https://nacho.example.com/api"


# --- _get_headers ---


def test_get_headers_no_credentials(no_credentials):
    assert _get_headers() == {}


def test_get_headers_with_credentials(fake_credentials):
    headers = _get_headers()
    assert headers == {"Authorization": "Bearer nacho_test_token_123"}


# --- _api_get ---


def test_api_get_success(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json={"ok": True})):
        result = _api_get("/test")
        assert result == {"ok": True}


def test_api_get_401(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(401, json={"error": "unauth"})):
        with pytest.raises(NachoAPIError, match="Authentication required"):
            _api_get("/test")


def test_api_get_404(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(404, json={"error": "missing"})):
        with pytest.raises(NachoAPIError, match="Not found"):
            _api_get("/test")


def test_api_get_connect_error(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", side_effect=httpx.ConnectError("refused")):
        with pytest.raises(NachoAPIError, match="Could not connect"):
            _api_get("/test")


# --- search ---


def test_search_with_results(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json=SEARCH_RESPONSE)):
        result = search(query="fastapi")
        assert "FastAPI + React" in result
        assert "nacho/fastapi-react" in result
        assert "Full-stack web app template" in result
        assert "python" in result
        assert "↓42" in result
        assert "▲10" in result


def test_search_empty_results(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json=EMPTY_SEARCH)):
        result = search(query="nonexistent")
        assert "No contexts found" in result


def test_search_passes_params(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json=EMPTY_SEARCH)) as mock_get:
        search(query="web", tags="python,react", sort="downloads", page=2)
        call_kwargs = mock_get.call_args
        params = call_kwargs.kwargs.get("params") or call_kwargs[1].get("params")
        assert params["q"] == "web"
        assert params["tags"] == "python,react"
        assert params["sort"] == "downloads"
        assert params["page"] == 2


def test_search_api_error(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", side_effect=httpx.ConnectError("refused")):
        result = search(query="test")
        assert "Error" in result
        assert "Could not connect" in result


# --- info ---


def test_info_valid_ref(no_credentials):
    def mock_get(url, **kwargs):
        if "/versions" in url:
            return _resp(json=VERSIONS_DATA)
        return _resp(json=CONTEXT_DATA)

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = info("nacho/fastapi-react")
        assert "FastAPI + React" in result
        assert "Full-stack template" in result
        assert "MIT" in result
        assert "v3" in result
        assert "Added tests" in result
        assert "python" in result


def test_info_invalid_ref():
    result = info("invalid-ref")
    assert "Error" in result
    assert "username/context-name" in result


def test_info_not_found(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(404, json={"error": "nope"})):
        result = info("nobody/nothing")
        assert "Error" in result
        assert "Not found" in result


# --- pull ---


def test_pull_valid_ref(no_credentials):
    def mock_get(url, **kwargs):
        if "/download" in url:
            return _resp(text="# Hello World\nThis is a context.")
        return _resp(json={"id": "abc-123", "name": "test-context"})

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = pull("nacho/test-context")
        assert "Hello World" in result
        assert "This is a context" in result


def test_pull_invalid_ref():
    result = pull("no-slash")
    assert "Error" in result
    assert "username/context-name" in result


def test_pull_with_version(no_credentials):
    def mock_get(url, **kwargs):
        params = kwargs.get("params", {})
        if "/download" in url:
            assert params.get("version") == 2
            return _resp(text="# Version 2 content")
        return _resp(json={"id": "abc-123"})

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = pull("nacho/test-context", version=2)
        assert "Version 2 content" in result


# --- install ---


def test_install_creates_claude_md(no_credentials, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    def mock_get(url, **kwargs):
        if "/download" in url:
            return _resp(text="# Test Context\nInstructions here.")
        return _resp(json={"id": "abc-123"})

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = install("nacho/test-context")
        assert "Created CLAUDE.md" in result

        claude_md = tmp_path / "CLAUDE.md"
        assert claude_md.exists()
        content = claude_md.read_text()
        assert "nacho/test-context" in content
        assert "Test Context" in content


def test_install_appends_to_existing(no_credentials, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    claude_md = tmp_path / "CLAUDE.md"
    claude_md.write_text("# Existing content\n")

    def mock_get(url, **kwargs):
        if "/download" in url:
            return _resp(text="# New Context\nNew instructions.")
        return _resp(json={"id": "abc-123"})

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = install("nacho/new-context")
        assert "Appended" in result

        content = claude_md.read_text()
        assert "Existing content" in content
        assert "New Context" in content
        assert "nacho/new-context" in content


def test_install_api_error(no_credentials, tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    with patch("nacho_mcp.tools.httpx.get", side_effect=httpx.ConnectError("refused")):
        result = install("nacho/test-context")
        assert "Error" in result
        assert not (tmp_path / "CLAUDE.md").exists()


# --- init ---


def test_init_with_results(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json=SEARCH_RESPONSE)):
        result = init(project_description="python fastapi backend")
        assert "FastAPI + React" in result
        assert "nacho_install" in result
        assert "nacho_info" in result


def test_init_fallback_without_tags(no_credentials):
    call_count = 0

    def mock_get(url, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return _resp(json=EMPTY_SEARCH)
        return _resp(json=SEARCH_RESPONSE)

    with patch("nacho_mcp.tools.httpx.get", side_effect=mock_get):
        result = init(project_description="python backend", tags="fastapi")
        assert "FastAPI + React" in result
        assert call_count == 2


def test_init_no_results(no_credentials):
    with patch("nacho_mcp.tools.httpx.get", return_value=_resp(json=EMPTY_SEARCH)):
        result = init(project_description="something very obscure")
        assert "No matching contexts found" in result
        assert "scaffold" in result
