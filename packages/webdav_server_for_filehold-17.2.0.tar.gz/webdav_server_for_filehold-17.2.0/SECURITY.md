# Security Policy

## Disclaimer

This is a community-developed, unofficial implementation and is **not** provided, supported, or endorsed by **FileHold Systems Inc.** or **Keymark**.

## Supported Versions

To minimize the risk of vulnerabilities when using this project, we recommend that you use the latest available version.

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting a Vulnerability

Please report sensitive information via [GitHub Private Vulnerability Reporting](https://github.com/danielklecha/webdav-server-for-filehold/security/advisories/new).

Please do not report security vulnerabilities through public GitHub issues.
