from typing import Any, List

class ColumnsWithValues:
    def __init__(self, columns: Any, document_data: List[Any]):
        self.Columns = columns
        self.DocumentData = document_data
