from setuptools import setup, find_packages


with open("README.md", "r") as readme:
    description = readme.read()


setup(
    name="bigraph-schema",
)
