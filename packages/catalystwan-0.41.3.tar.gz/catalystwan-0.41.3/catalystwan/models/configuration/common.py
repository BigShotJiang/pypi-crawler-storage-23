# Copyright 2023 Cisco Systems, Inc. and its affiliates

from typing import Literal

Solution = Literal[
    "mobility",
    "sdwan",
    "nfvirtual",
    "sd-routing",
]
