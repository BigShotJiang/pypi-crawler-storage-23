import json

from tensor_grep.cli.formatters.base import OutputFormatter
from tensor_grep.core.result import SearchResult


class JsonFormatter(OutputFormatter):
    def format(self, result: SearchResult) -> str:
        data = {
            "total_matches": result.total_matches,
            "total_files": result.total_files,
            "routing_backend": result.routing_backend,
            "routing_reason": result.routing_reason,
            "routing_gpu_device_ids": result.routing_gpu_device_ids,
            "routing_gpu_chunk_plan_mb": [
                {"device_id": device_id, "chunk_mb": chunk_mb}
                for device_id, chunk_mb in result.routing_gpu_chunk_plan_mb
            ],
            "routing_distributed": result.routing_distributed,
            "routing_worker_count": result.routing_worker_count,
            "matches": [
                {"file": m.file, "line_number": m.line_number, "text": m.text}
                for m in result.matches
            ],
        }
        return json.dumps(data)
