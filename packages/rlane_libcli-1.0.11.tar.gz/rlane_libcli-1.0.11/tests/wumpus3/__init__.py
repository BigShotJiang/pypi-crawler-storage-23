"""Wumpus3 - all subcommand classes prefixed with `Wumpus`."""
