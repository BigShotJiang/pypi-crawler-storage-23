"""Base class for our `Option`s."""

__all__ = ["BaseOption"]


class BaseOption:
    # pylint: disable=too-few-public-methods
    """Base class for our `Option`s."""
