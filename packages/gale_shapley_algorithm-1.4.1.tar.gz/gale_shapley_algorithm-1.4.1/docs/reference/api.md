---
title: API reference
hide:
- navigation
---

::: gale_shapley_algorithm
