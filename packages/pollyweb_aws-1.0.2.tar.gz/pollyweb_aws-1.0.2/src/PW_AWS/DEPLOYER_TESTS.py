from DEPLOYER import DEPLOYER
from PW_AWS.AWS_TEST import AWS_TEST
from DEPLOYER_ARGS import DEPLOYER_ARGS
from DEPLOYER_EXEC_DUMMY import DEPLOYER_EXEC_DUMMY
from DEPLOYER_TASK import DEPLOYER_TASK
from LOG import LOG
from PW_UTILS.TESTS import TESTS
from PW_UTILS.UTILS import UTILS

class DEPLOYER_TESTS():
    

    @classmethod
    def TestYaml(cls):
        file = UTILS.OS().GetFileInClass(cls, 'TestYaml')
        yaml = file.ReadText()
        yaml = UTILS().FromYaml(yaml)

        AWS_TEST.SetDomain('any-test.com')     
        DEPLOYER(
            DEPLOYER_ARGS(
                Name= 'Deployer.Test.Yaml',
                Simulate= True)
        ).ExecuteYaml(
            stack= 'test', 
            yaml= yaml, 
            path= file.GetPath())


    @classmethod
    def TestParser(cls):
        file = UTILS.OS().GetFileInClass(cls, 'TestParser')
        yaml = file.ReadText()
        yaml = UTILS().FromYaml(yaml)
        tasks = DEPLOYER.PARSER().YamlToTasks(
            stack= 'MyStack', 
            yaml= yaml,
            path= file.GetPath())
        
        TESTS.AssertEqual(len(tasks), 1)
        task = tasks[0]

        TESTS.AssertEqual(
            task.RequireStackName(), 
            'MyStack')
        
        TESTS.AssertEqual(
            task.RequireAsset(), 
            'MyResource')
        
        TESTS.AssertEqual(
            task.RequireType(), 
            'Dummy')
        
        TESTS.AssertEqual(
            task.RequireParams(), 
            {'MyParam': 'MyValue'})
        
        TESTS.AssertEqual(
            task.RequireDependencies(), 
            ['MyStack.MyDependency'])


    @classmethod
    def TestExecuteInSequence(cls):     
        
        file = UTILS.OS().GetFileInClass(cls, 'TestExecuteInSequence')
        yaml = file.ReadText()
        yaml = UTILS().FromYaml(yaml)

        DEPLOYER(
            DEPLOYER_ARGS(
                Name='Deployer.Test.ExecuteInSequence',
                Simulate=True,
                Parallel=False)
        ).ExecuteYaml(stack='MyStack', 
            yaml=yaml, 
            path= file.GetPath())


    @classmethod
    def TestExecuteInParallel(cls):
        file = UTILS.OS().GetFileInClass(cls, 'TestExecuteInParallel')
        yaml = file.ReadText()     
        yaml = UTILS().FromYaml(yaml)

        deployer = DEPLOYER(
            DEPLOYER_ARGS(
                Parallel= True,
                Seconds= 5))

        deployer.ExecuteYaml(
            stack= 'MyStack', 
            yaml= yaml, 
            path= file.GetPath())
        
        LOG.PARALLEL().SetMethodDone()
        

    @classmethod
    def TestExecuteDirectoryInSequence(cls):
        
        # Get the directory path.
        dir = UTILS.OS().GetDirectoryInClass(cls, 
            'TestExecuteDirectory').AssertExists()
        
        # Clear the executions.
        DEPLOYER_EXEC_DUMMY.DummyExecutions = []

        def myOnTask(task:DEPLOYER_TASK, result:dict):
            LOG.Print('Task executed:', task.RequireFullName())

        # Execute the directory.
        ret = DEPLOYER(
            DEPLOYER_ARGS(
                Name= 'Deployer.Test.ExecuteDirectoryInSequence',
                Parallel= False,
                OnTask= myOnTask)
        ).ExecuteDirectory(
            path= dir.GetPath())
        
        # Check the results.
        TESTS.AssertEqual(
            DEPLOYER_EXEC_DUMMY.DummyExecutions, [
                'StackA.Step1',
                'StackB.Step2',
                'StackA.Step3',
                'StackB.Step4'
            ])
        

    @classmethod
    def TestExecuteDirectoryInParallel(cls):
        
        # Get the directory path.
        dir = UTILS.OS().GetDirectoryInClass(cls, 
            'TestExecuteDirectory').AssertExists() 
        
        # Clear the executions.
        DEPLOYER_EXEC_DUMMY.DummyExecutions = []

        cls._asserted = False
        def Assert():
            TESTS.AssertEqual(
                DEPLOYER_EXEC_DUMMY.DummyExecutions, [
                    'StackA.Step1',
                    'StackB.Step2',
                    'StackA.Step3',
                    'StackB.Step4'
                ])
            cls._asserted = True

        # Execute the directory.
        runner = DEPLOYER(
            DEPLOYER_ARGS(
                Parallel= True,
                Seconds= 5))
        
        runner.ExecuteDirectory(
            path= dir.GetPath(), 
            assertMethod= Assert)

        if not cls._asserted:
            LOG.RaiseException('Assert not executed.')

        LOG.PARALLEL().SetMethodDone()


    @classmethod
    def TestForInfiniteLoops(cls):
        
        file = UTILS.OS().GetFileInClass(cls, 
            'TestForInfiniteLoops').AssertExists()
        
        yaml = file.ReadYaml()
        tasks = DEPLOYER.PARSER().YamlToTasks('myStack', 
            yaml= yaml,
            path= file.GetPath())
        
        with TESTS.AssertValidation():
            deployerArgs = DEPLOYER_ARGS()
            DEPLOYER.MAESTRO(deployerArgs).CheckForInfiniteLoops(tasks)        
            LOG.RaiseException('Infinite loop not detected.')


    @classmethod
    def TestDeadLockInSequence(cls):
        
        # Get the directory path.
        dir = UTILS.OS().GetDirectoryInClass(cls, 
            'TestDeadLock').AssertExists()
        
        # Execute the directory.
        with TESTS.AssertValidation():
          DEPLOYER(
              name= 'Deployer.Test.DeadLockInSequence',
              parallel= False
          ).ExecuteDirectory(
              path= dir.GetPath())
          LOG.RaiseException('Deadlock not detected.')


    @classmethod
    def TestDeadLockInParallel(cls):
        
        # Get the directory path.
        dir = UTILS.OS().GetDirectoryInClass(cls, 
            'TestDeadLock').AssertExists()
        
        # Execute the directory, expecting a deadlock.
        with TESTS.AssertValidation():
            DEPLOYER(
                DEPLOYER_ARGS(
                    Name= 'Deployer.Test.DeadLockInParallel',
                    Parallel= True,
                    Seconds= 5)
            ).ExecuteDirectory(
                path= dir.GetPath())
            LOG.RaiseException('Deadlock not detected.')
        

    @classmethod
    def TestAllDeployer(cls):
        
        '''👉️ Tests all the methods in the class.'''
        cls.TestParser()
        cls.TestYaml()
        cls.TestForInfiniteLoops()
        cls.TestExecuteInSequence()
        cls.TestExecuteInParallel()
        cls.TestExecuteDirectoryInSequence()
        cls.TestExecuteDirectoryInParallel()
        cls.TestDeadLockInSequence()
        cls.TestDeadLockInParallel()

        LOG.PARALLEL().SetClassDone()