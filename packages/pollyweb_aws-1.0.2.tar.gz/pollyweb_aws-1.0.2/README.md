# PollyWeb AWS

AWS helpers for PollyWeb.

## Installation

```bash
pip install pollyweb-aws
```
