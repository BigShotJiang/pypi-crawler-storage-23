from jpipe_runner import runner

if __name__ == '__main__':
    runner.main()
