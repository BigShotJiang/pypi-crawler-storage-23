"""
soul-schema CLI — connect, review, export
"""

import sys
import json
import click
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm

from .connector import SchemaConnector
from .generator import SemanticGenerator
from .memory import SchemaMemory

console = Console()


@click.group()
@click.version_option()
def cli():
    """soul-schema — auto-generate semantic layers for any database.\n
    Metadata only. No row data ever leaves your infrastructure."""
    pass


@cli.command()
@click.option("--db",      required=True,  help="Database connection string (SQLAlchemy format)")
@click.option("--llm",     default="anthropic", help="LLM provider: anthropic, openai, openai-compatible")
@click.option("--key",     default="",     help="LLM API key (or set via env var)")
@click.option("--model",   default=None,   help="Model name (default: claude-haiku / gpt-4o-mini)")
@click.option("--base-url",default=None,   help="Base URL for openai-compatible (e.g. Ollama)")
@click.option("--output",  default="./schema_memory.md", help="Output memory file path")
@click.option("--schema",  default=None,   help="Database schema (optional, e.g. 'public')")
@click.option("--tables",  default=None,   help="Comma-separated list of tables to process (default: all)")
def connect(db, llm, key, model, base_url, output, schema, tables):
    """Connect to a database and generate semantic descriptions."""
    console.print("\n[bold purple]soul-schema[/bold purple] — Semantic layer generator")
    console.print("[dim]Metadata only. No row data leaves your infrastructure.[/dim]\n")

    # Connect
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
        t = p.add_task("Connecting to database...")
        try:
            connector = SchemaConnector(db)
            all_tables = connector.get_tables(schema=schema)
            p.update(t, description=f"[green]Connected. Found {len(all_tables)} tables.[/green]")
        except Exception as e:
            console.print(f"[red]Connection failed: {e}[/red]")
            sys.exit(1)

    # Filter tables
    if tables:
        target_tables = [t.strip() for t in tables.split(",")]
        missing = [t for t in target_tables if t not in all_tables]
        if missing:
            console.print(f"[yellow]Warning: tables not found: {missing}[/yellow]")
        target_tables = [t for t in target_tables if t in all_tables]
    else:
        target_tables = all_tables

    console.print(f"Processing [bold]{len(target_tables)}[/bold] tables...\n")

    # Load existing memory
    memory = SchemaMemory(output)
    generator = SemanticGenerator(provider=llm, api_key=key, model=model, base_url=base_url)

    # Process each table
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
        for table_name in target_tables:
            task = p.add_task(f"[cyan]{table_name}[/cyan]...")
            try:
                data = connector.get_full_schema(schema=schema)
                table_data = data.get(table_name, {})
                result = generator.generate_table(
                    table=table_name,
                    columns=table_data.get("columns", []),
                    sample=table_data.get("sample", []),
                    row_count=table_data.get("row_count", 0),
                )
                memory.set_table(
                    table=table_name,
                    description=result.get("table_description", ""),
                    columns=result.get("columns", {}),
                )
                p.update(task, description=f"[green]✓ {table_name}[/green]")
            except Exception as e:
                p.update(task, description=f"[red]✗ {table_name}: {e}[/red]")

    console.print(f"\n[bold green]✅ Done![/bold green] Semantic layer saved to [cyan]{output}[/cyan]")
    console.print(f"Run [bold]soul-schema review[/bold] to verify and correct descriptions.")


@cli.command()
@click.option("--input",  default="./schema_memory.md", help="Memory file to review")
def review(input):
    """Interactively review and correct generated descriptions."""
    memory = SchemaMemory(input)
    tables = memory.all_tables()

    if not tables:
        console.print("[yellow]No schema memory found. Run soul-schema connect first.[/yellow]")
        return

    console.print(f"\n[bold purple]Reviewing {len(tables)} tables[/bold purple]")
    console.print("[dim]Press Enter to accept, or type a correction. 's' to skip table.[/dim]\n")

    for table in tables:
        meta = memory.get_table(table)
        console.print(f"\n[bold cyan]── {table} ──[/bold cyan]")
        console.print(f"[dim]Description:[/dim] {meta['description']}")

        if not Confirm.ask("Accept table description?", default=True):
            new_desc = Prompt.ask("New description")
            meta["description"] = new_desc
            memory.set_table(table, new_desc, meta["columns"])

        if Confirm.ask("Skip column review for this table?", default=False):
            continue

        for col, desc in sorted(meta["columns"].items()):
            locked = "🔒 " if col in meta.get("locked", set()) else ""
            console.print(f"\n  [bold]{locked}{col}[/bold]")
            console.print(f"  [dim]{desc}[/dim]")

            if col in meta.get("locked", set()):
                console.print("  [dim](locked — human verified)[/dim]")
                continue

            correction = Prompt.ask("  Correction (Enter to accept)", default="")
            if correction:
                memory.correct(table, col, correction)
                console.print(f"  [green]✓ Saved and locked.[/green]")

    console.print(f"\n[bold green]✅ Review complete.[/bold green] Memory saved to [cyan]{input}[/cyan]")


@cli.command()
@click.option("--input",  default="./schema_memory.md", help="Memory file to export")
@click.option("--format", "fmt", default="json",
              type=click.Choice(["json", "dbt", "vanna"]), help="Export format")
@click.option("--output", default=None, help="Output file (default: stdout)")
def export(input, fmt, output):
    """Export the semantic layer to dbt, Vanna, or JSON format."""
    memory = SchemaMemory(input)

    if fmt == "json":
        result = json.dumps(memory.export_json(), indent=2)
        ext = "json"
    elif fmt == "dbt":
        result = memory.export_dbt()
        ext = "yml"
    elif fmt == "vanna":
        result = json.dumps(memory.export_vanna(), indent=2)
        ext = "json"

    if output:
        with open(output, "w") as f:
            f.write(result)
        console.print(f"[green]✅ Exported to {output}[/green]")
    else:
        out_file = f"schema.{ext}" if fmt == "dbt" else f"soul_schema_export.{ext}"
        with open(out_file, "w") as f:
            f.write(result)
        console.print(f"[green]✅ Exported to {out_file}[/green]")


@cli.command()
@click.option("--input", default="./schema_memory.md", help="Memory file")
def status(input):
    """Show a summary of the current semantic layer."""
    memory = SchemaMemory(input)
    tables = memory.all_tables()

    if not tables:
        console.print("[yellow]No schema memory found. Run soul-schema connect first.[/yellow]")
        return

    t = Table(title=f"Schema Memory — {input}")
    t.add_column("Table", style="cyan")
    t.add_column("Columns", justify="right")
    t.add_column("Described", justify="right")
    t.add_column("Locked", justify="right")
    t.add_column("Description", style="dim", max_width=50)

    total_cols = total_desc = total_locked = 0

    for table in tables:
        meta = memory.get_table(table)
        cols = len(meta.get("columns", {}))
        desc = sum(1 for d in meta["columns"].values() if d)
        locked = len(meta.get("locked", set()))
        total_cols += cols
        total_desc += desc
        total_locked += locked
        t.add_row(
            table, str(cols), f"[green]{desc}[/green]" if desc == cols else f"[yellow]{desc}[/yellow]",
            str(locked), meta.get("description", "")[:60]
        )

    console.print(t)
    console.print(f"\n[bold]{len(tables)} tables · {total_cols} columns · {total_desc} described · {total_locked} locked[/bold]")
