"""
SemanticGenerator — uses an LLM to generate table and column descriptions.

Supports: Anthropic Claude, OpenAI, and any OpenAI-compatible endpoint (Ollama etc.)
"""

import json
import requests
from typing import Optional


SYSTEM_PROMPT = """You are a senior data engineer helping document a database schema.
You will be given a table name, its columns (with types and constraints), and a small
sample of actual data values.

Your job is to write clear, concise descriptions for:
1. The TABLE itself — what it represents in the business context
2. Each COLUMN — what it stores, its business meaning, any important notes

Rules:
- Be specific, not generic. "Stores customer ID" is bad. "Unique identifier for a customer account, referenced by orders and transactions" is good.
- Infer business meaning from column names, types, and sample values.
- If a column looks like a flag/boolean, explain what TRUE/FALSE means.
- If a column looks like a code/enum, list the values you see and what they likely mean.
- Keep each description to 1-2 sentences.
- Respond ONLY with valid JSON — no markdown, no explanation."""

TABLE_PROMPT = """Table: {table}
Row count: ~{row_count:,}

Columns:
{columns}

Sample data (first {n} rows):
{sample}

Respond with this exact JSON structure:
{{
  "table_description": "...",
  "columns": {{
    "column_name": "description",
    ...
  }}
}}"""


class SemanticGenerator:
    """
    Generates semantic descriptions for database tables and columns.
    """

    def __init__(
        self,
        provider: str = "anthropic",
        api_key: str = "",
        model: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        """
        Args:
            provider: "anthropic", "openai", or "openai-compatible" (Ollama etc.)
            api_key: Your LLM provider API key
            model: Model name (defaults to a sensible choice per provider)
            base_url: Override base URL (for Ollama/local)
        """
        self.provider = provider
        self.api_key = api_key
        self.base_url = base_url
        self.model = model or self._default_model()

    def _default_model(self) -> str:
        defaults = {
            "anthropic": "claude-haiku-4-5",
            "openai": "gpt-4o-mini",
            "openai-compatible": "llama3.2",
        }
        return defaults.get(self.provider, "gpt-4o-mini")

    def _call(self, prompt: str) -> str:
        if self.provider == "anthropic":
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": self.model,
                    "max_tokens": 2048,
                    "system": SYSTEM_PROMPT,
                    "messages": [{"role": "user", "content": prompt}],
                },
                timeout=60,
            )
            r.raise_for_status()
            return r.json()["content"][0]["text"].strip()

        else:  # openai / openai-compatible
            base = self.base_url or "https://api.openai.com/v1"
            key = self.api_key or "ollama"
            r = requests.post(
                f"{base.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {key}", "content-type": "application/json"},
                json={
                    "model": self.model,
                    "max_tokens": 2048,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                },
                timeout=60,
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()

    def generate_table(self, table: str, columns: list, sample: list, row_count: int) -> dict:
        """Generate descriptions for a single table."""
        cols_str = "\n".join(
            f"  - {c['name']} ({c['type']})"
            + (" PK" if c.get("primary_key") else "")
            + (f" FK→{c['foreign_key']}" if c.get("foreign_key") else "")
            + ("" if c.get("nullable", True) else " NOT NULL")
            for c in columns
        )
        sample_str = json.dumps(sample[:10], default=str, indent=2)

        prompt = TABLE_PROMPT.format(
            table=table,
            row_count=row_count,
            columns=cols_str,
            sample=sample_str,
            n=min(len(sample), 10),
        )

        raw = self._call(prompt)

        # Strip markdown code blocks if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]

        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            return {
                "table_description": "[Generation failed — edit manually]",
                "columns": {c["name"]: "" for c in columns},
            }
