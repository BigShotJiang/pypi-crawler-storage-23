"""
SchemaConnector — connects to any database and extracts metadata.

IMPORTANT: Only reads metadata (table names, column names, types, constraints)
and a small sample of values (max 10 rows) to help the LLM understand context.
No row-level data is stored or transmitted.
"""

from typing import Optional
from sqlalchemy import create_engine, text, inspect


class SchemaConnector:
    """
    Connects to a database and extracts schema metadata.

    Supported: PostgreSQL, MySQL, SQLite (Phase 1)
    Coming soon: BigQuery, Snowflake, Redshift, DuckDB
    """

    def __init__(self, connection_string: str):
        """
        Args:
            connection_string: SQLAlchemy connection string
                postgresql://user:pass@host/db
                mysql+pymysql://user:pass@host/db
                sqlite:///path/to/db.sqlite
        """
        self.connection_string = connection_string
        self.engine = create_engine(connection_string)
        self._inspector = None

    @property
    def inspector(self):
        if self._inspector is None:
            self._inspector = inspect(self.engine)
        return self._inspector

    def get_tables(self, schema: Optional[str] = None) -> list[str]:
        """Return list of all table names."""
        return self.inspector.get_table_names(schema=schema)

    def get_columns(self, table: str, schema: Optional[str] = None) -> list[dict]:
        """Return column metadata for a table."""
        cols = self.inspector.get_columns(table, schema=schema)
        pks = set(self.inspector.get_pk_constraint(table, schema=schema).get("constrained_columns", []))
        fks = {
            fk["constrained_columns"][0]: f"{fk['referred_table']}.{fk['referred_columns'][0]}"
            for fk in self.inspector.get_foreign_keys(table, schema=schema)
            if fk["constrained_columns"]
        }
        return [
            {
                "name": col["name"],
                "type": str(col["type"]),
                "nullable": col.get("nullable", True),
                "primary_key": col["name"] in pks,
                "foreign_key": fks.get(col["name"]),
                "default": str(col["default"]) if col.get("default") is not None else None,
            }
            for col in cols
        ]

    def get_sample(self, table: str, n: int = 10, schema: Optional[str] = None) -> list[dict]:
        """
        Fetch up to n sample rows for LLM context.

        NOTE: These samples are used ONLY to help the LLM generate better
        descriptions. They are never stored or transmitted outside your
        infrastructure.
        """
        qualified = f"{schema}.{table}" if schema else table
        with self.engine.connect() as conn:
            rows = conn.execute(
                text(f"SELECT * FROM {qualified} LIMIT :n"), {"n": n}
            ).mappings().all()
        return [dict(r) for r in rows]

    def get_row_count(self, table: str, schema: Optional[str] = None) -> int:
        """Get approximate row count."""
        qualified = f"{schema}.{table}" if schema else table
        with self.engine.connect() as conn:
            result = conn.execute(text(f"SELECT COUNT(*) FROM {qualified}")).scalar()
        return result or 0

    def get_full_schema(self, schema: Optional[str] = None, sample_rows: int = 10) -> dict:
        """
        Extract complete schema metadata for all tables.

        Returns:
            Dict mapping table_name → {columns, sample, row_count}
        """
        tables = self.get_tables(schema=schema)
        result = {}
        for table in tables:
            try:
                result[table] = {
                    "columns": self.get_columns(table, schema=schema),
                    "sample": self.get_sample(table, n=sample_rows, schema=schema),
                    "row_count": self.get_row_count(table, schema=schema),
                }
            except Exception as e:
                result[table] = {"error": str(e), "columns": [], "sample": [], "row_count": 0}
        return result
