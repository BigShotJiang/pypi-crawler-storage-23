"""
soul-schema — Auto-generate semantic layers for any database using LLMs.

Metadata only. No row data ever leaves your infrastructure.
"""

__version__ = "0.1.0"

from .connector import SchemaConnector
from .generator import SemanticGenerator
from .memory import SchemaMemory

__all__ = ["SchemaConnector", "SemanticGenerator", "SchemaMemory"]
