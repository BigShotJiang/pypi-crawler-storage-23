"""
soul-schema demo — Northwind database

Shows the full workflow:
  1. Connect to SQLite database
  2. Generate descriptions for all 4 tables
  3. Apply a human correction (locked forever)
  4. Export to dbt YAML, Vanna training data, and JSON

Run:
    pip install soul-schema[anthropic]
    python examples/demo_northwind.py --key sk-ant-...

Or with Ollama (fully local):
    python examples/demo_northwind.py --provider ollama --model llama3.2
"""

import argparse
import json
import os
from create_northwind import create_northwind

from soul_schema import SchemaConnector, SemanticGenerator, SchemaMemory


def run_demo(provider: str, api_key: str, model: str = None, base_url: str = None):
    db_path = "northwind.db"
    memory_path = "northwind_schema_memory.md"

    # ── 1. Create demo database ───────────────────────────────────────────────
    print("\n🗄  Creating Northwind demo database...")
    create_northwind(db_path)

    # ── 2. Connect ────────────────────────────────────────────────────────────
    print("\n🔌 Connecting to database...")
    connector = SchemaConnector(f"sqlite:///{db_path}")
    tables = connector.get_tables()
    print(f"   Found {len(tables)} tables: {', '.join(tables)}")

    # ── 3. Generate descriptions ──────────────────────────────────────────────
    print(f"\n🧠 Generating descriptions with {provider}...")
    print("   (Metadata only — no row data leaves your machine)\n")

    generator = SemanticGenerator(
        provider=provider,
        api_key=api_key,
        model=model,
        base_url=base_url,
    )
    memory = SchemaMemory(memory_path)
    schema = connector.get_full_schema()

    for table, data in schema.items():
        print(f"   Processing {table}...", end=" ", flush=True)
        result = generator.generate_table(
            table=table,
            columns=data["columns"],
            sample=data["sample"],
            row_count=data["row_count"],
        )
        memory.set_table(table, result["table_description"], result["columns"])
        print("✅")

    # ── 4. Show generated descriptions ───────────────────────────────────────
    print("\n📋 Generated descriptions (customers table):")
    meta = memory.get_table("customers")
    print(f"   Table: {meta['description']}\n")
    for col, desc in sorted(meta["columns"].items()):
        print(f"   {col:15} → {desc}")

    # ── 5. Apply a human correction ───────────────────────────────────────────
    print("\n✍️  Applying correction: cust_ltv → 'Customer lifetime value in USD'")
    memory.correct("customers", "cust_ltv",
                   "Customer lifetime value in USD — total revenue attributed to this customer")
    print("   Saved and locked. Will never be overwritten by re-generation.")

    # ── 6. Export ─────────────────────────────────────────────────────────────
    print("\n📤 Exporting...")

    # dbt
    dbt_path = "schema.yml"
    with open(dbt_path, "w") as f:
        f.write(memory.export_dbt())
    print(f"   ✅ dbt YAML     → {dbt_path}")

    # Vanna
    vanna_path = "vanna_training.json"
    with open(vanna_path, "w") as f:
        json.dump(memory.export_vanna(), f, indent=2)
    print(f"   ✅ Vanna data   → {vanna_path} ({len(memory.export_vanna())} training pairs)")

    # JSON
    json_path = "semantic_layer.json"
    with open(json_path, "w") as f:
        json.dump(memory.export_json(), f, indent=2)
    print(f"   ✅ JSON export  → {json_path}")

    # ── 7. Preview dbt output ─────────────────────────────────────────────────
    print("\n📄 schema.yml preview (first 30 lines):")
    dbt = memory.export_dbt().splitlines()
    for line in dbt[:30]:
        print(f"   {line}")
    if len(dbt) > 30:
        print(f"   ... ({len(dbt) - 30} more lines)")

    print(f"\n✅ Done! Memory saved to {memory_path}")
    print("   Run soul-schema review to verify and correct any descriptions.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="soul-schema Northwind demo")
    parser.add_argument("--provider", default="anthropic",
                        choices=["anthropic", "openai", "openai-compatible"],
                        help="LLM provider")
    parser.add_argument("--key", default=os.environ.get("ANTHROPIC_API_KEY", ""),
                        help="LLM API key")
    parser.add_argument("--model", default=None, help="Model name")
    parser.add_argument("--base-url", default=None, help="Base URL (for Ollama)")
    args = parser.parse_args()

    if not args.key and args.provider != "openai-compatible":
        print("❌ Provide --key or set ANTHROPIC_API_KEY / OPENAI_API_KEY")
        raise SystemExit(1)

    run_demo(args.provider, args.key, args.model, args.base_url)
