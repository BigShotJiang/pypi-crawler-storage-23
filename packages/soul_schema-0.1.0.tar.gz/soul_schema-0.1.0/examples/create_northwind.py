"""
Creates the Northwind demo database for soul-schema examples.

A realistic e-commerce schema with intentionally cryptic column names —
exactly the kind of thing soul-schema was built for.
"""

import sqlite3
import os

def create_northwind(path: str = "northwind.db"):
    conn = sqlite3.connect(path)
    c = conn.cursor()

    c.executescript("""
    -- Customers: mix of B2B and B2C, cryptic column names
    CREATE TABLE IF NOT EXISTS customers (
        cust_id       INTEGER PRIMARY KEY,
        cust_nm       TEXT NOT NULL,
        cust_email    TEXT UNIQUE,
        cust_ltv      REAL,          -- what does this mean?
        reg_cd        TEXT,          -- NA? EU? what?
        flg_b2b       INTEGER DEFAULT 0,
        acq_dt        TEXT,
        tier_cd       TEXT           -- bronze/silver/gold/platinum
    );

    -- Products: electronics and furniture catalog
    CREATE TABLE IF NOT EXISTS products (
        prod_id       INTEGER PRIMARY KEY,
        prod_nm       TEXT NOT NULL,
        cat_cd        TEXT,          -- ELEC? FURN?
        unit_prc      REAL,
        inv_qty       INTEGER,
        disc_flg      INTEGER DEFAULT 0,
        supplier_id   INTEGER
    );

    -- Orders: transaction records
    CREATE TABLE IF NOT EXISTS orders (
        ord_id        INTEGER PRIMARY KEY,
        cust_id       INTEGER REFERENCES customers(cust_id),
        ord_dt        TEXT,
        ship_dt       TEXT,
        ord_amt       REAL,
        ord_sts       TEXT,          -- DELIVERED? PENDING?
        promo_cd      TEXT
    );

    -- Order line items
    CREATE TABLE IF NOT EXISTS order_items (
        item_id       INTEGER PRIMARY KEY,
        ord_id        INTEGER REFERENCES orders(ord_id),
        prod_id       INTEGER REFERENCES products(prod_id),
        qty           INTEGER,
        unit_prc      REAL,
        disc_pct      REAL DEFAULT 0
    );

    INSERT OR IGNORE INTO customers VALUES
    (1,'Acme Corp','acme@acme.com',42500.00,'NA',1,'2022-01-15','gold'),
    (2,'Jane Smith','jane@gmail.com',1200.00,'EU',0,'2023-06-01','silver'),
    (3,'TechVision LLC','tv@techvision.com',98000.00,'NA',1,'2021-03-10','platinum'),
    (4,'Bob Jones','bob@gmail.com',350.00,'NA',0,'2024-01-20','bronze');

    INSERT OR IGNORE INTO products VALUES
    (1,'Laptop Pro 15','ELEC',1299.99,45,0,101),
    (2,'Wireless Mouse','ELEC',29.99,200,1,102),
    (3,'Desk Chair','FURN',449.00,30,0,103),
    (4,'USB-C Hub','ELEC',49.99,150,0,102);

    INSERT OR IGNORE INTO orders VALUES
    (1001,1,'2024-01-10','2024-01-12',2599.98,'DELIVERED','CORP10'),
    (1002,2,'2024-02-14','2024-02-16',29.99,'DELIVERED',NULL),
    (1003,3,'2024-03-01',NULL,5199.96,'PENDING','VIP20'),
    (1004,1,'2024-03-15','2024-03-17',449.00,'DELIVERED',NULL);

    INSERT OR IGNORE INTO order_items VALUES
    (1,1001,1,2,1299.99,0),
    (2,1002,2,1,29.99,0),
    (3,1003,1,4,1299.99,0.20),
    (4,1004,3,1,449.00,0);
    """)

    conn.commit()
    conn.close()
    print(f"✅ Created {path}")
    print("   Tables: customers, products, orders, order_items")
    print("   Rows:   4 customers, 4 products, 4 orders, 4 order_items")


if __name__ == "__main__":
    create_northwind()
