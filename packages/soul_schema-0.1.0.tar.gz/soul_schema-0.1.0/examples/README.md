# soul-schema Examples

## Northwind Demo

A realistic e-commerce database with intentionally cryptic column names —
exactly the kind of schema soul-schema was built to document.

```
customers   cust_id, cust_nm, cust_ltv, reg_cd, flg_b2b, tier_cd ...
products    prod_id, prod_nm, cat_cd, unit_prc, inv_qty, disc_flg ...
orders      ord_id, cust_id, ord_amt, ord_sts, promo_cd ...
order_items item_id, ord_id, prod_id, qty, unit_prc, disc_pct
```

### Run with Anthropic Claude

```bash
cd examples
python demo_northwind.py --key sk-ant-...
```

### Run with OpenAI

```bash
python demo_northwind.py --provider openai --key sk-...
```

### Run fully local with Ollama (air-gapped)

```bash
# Start Ollama first: ollama pull llama3.2
python demo_northwind.py \
  --provider openai-compatible \
  --base-url http://localhost:11434/v1 \
  --model llama3.2
```

### What you get

After running the demo you'll have:

- `northwind_schema_memory.md` — human-readable semantic layer
- `schema.yml` — ready to drop into your dbt project
- `vanna_training.json` — training pairs for Vanna AI Text-to-SQL
- `semantic_layer.json` — portable JSON for any downstream tool

### Sample output

```
customers.cust_ltv  → Customer lifetime value in USD
customers.reg_cd    → Geographic region code: 'NA' (North America), 'EU' (Europe)
customers.flg_b2b   → 1 = B2B (business), 0 = B2C (consumer)
customers.tier_cd   → bronze / silver / gold / platinum
orders.ord_sts      → DELIVERED (completed) or PENDING (awaiting shipment)
products.cat_cd     → ELEC (Electronics), FURN (Furniture)
```
