"""Base executor interface for AI agents."""

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any


class EventType(str, Enum):
    """Types of events emitted by agents."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL_USE = "tool_use"
    TOOL_RESULT = "tool_result"
    ERROR = "error"
    RESULT = "result"


@dataclass
class StreamEvent:
    """An event from the agent's output stream."""

    event_type: EventType
    timestamp: datetime
    data: dict[str, Any]
    raw_json: str

    @property
    def is_final(self) -> bool:
        """Check if this is the final event (result)."""
        return self.event_type == EventType.RESULT


class AgentExecutor(ABC):
    """Abstract base class for agent executors.

    Executors handle launching and managing CLI agents (Claude Code, Codex, Aider)
    as subprocesses, streaming their JSON output.
    """

    def __init__(self, working_directory: str) -> None:
        """Initialize the executor.

        Args:
            working_directory: Directory to run the agent in.
        """
        self.working_directory = working_directory
        self._session_id: str | None = None

    @property
    def session_id(self) -> str | None:
        """Get the agent's native session ID for resume support."""
        return self._session_id

    @property
    @abstractmethod
    def agent_type(self) -> str:
        """Return the agent type identifier (e.g., 'claude', 'codex', 'aider')."""
        ...

    @abstractmethod
    async def start(self, prompt: str) -> None:
        """Start the agent with an initial prompt.

        Args:
            prompt: The initial prompt to send to the agent.
        """
        ...

    @abstractmethod
    async def resume(self, session_id: str, message: str) -> None:
        """Resume an existing session with a new message.

        Args:
            session_id: The native session ID to resume.
            message: The message to continue the conversation with.
        """
        ...

    @abstractmethod
    def stream_events(self) -> AsyncIterator[StreamEvent]:
        """Stream events from the agent's output.

        Yields:
            StreamEvent objects as they are parsed from the agent's output.
        """
        ...

    @abstractmethod
    async def stop(self) -> None:
        """Stop the agent process."""
        ...

    @abstractmethod
    async def wait(self) -> int:
        """Wait for the agent process to complete.

        Returns:
            The exit code of the agent process.
        """
        ...

    @property
    @abstractmethod
    def is_running(self) -> bool:
        """Check if the agent process is still running."""
        ...

    async def get_stderr(self) -> str:
        """Get any stderr output from the agent.

        Override in subclasses that support stderr capture.

        Returns:
            Stderr output as a string, empty by default.
        """
        return ""
