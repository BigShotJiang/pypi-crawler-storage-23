"""JSON stream parser for Claude's stream-json output format."""

import json
from collections.abc import AsyncIterator
from datetime import UTC, datetime
from typing import Any, ClassVar

from loguru import logger

from steerdev_agent.executor.base import EventType, StreamEvent


class StreamParser:
    """Parser for Claude Code's stream-json output format.

    Claude Code outputs newline-delimited JSON when run with --output-format stream-json.
    Each line is a complete JSON object representing an event.
    """

    # Event type mapping from Claude's output to our EventType
    EVENT_TYPE_MAP: ClassVar[dict[str, EventType]] = {
        "system": EventType.SYSTEM,
        "user": EventType.USER,
        "assistant": EventType.ASSISTANT,
        "tool_use": EventType.TOOL_USE,
        "tool_result": EventType.TOOL_RESULT,
        "error": EventType.ERROR,
        "result": EventType.RESULT,
    }

    def __init__(self) -> None:
        """Initialize the parser."""
        self._buffer = ""
        self._session_id: str | None = None

    @property
    def session_id(self) -> str | None:
        """Get the session ID extracted from the stream."""
        return self._session_id

    def parse_line(self, line: str) -> StreamEvent | None:
        """Parse a single JSON line into a StreamEvent.

        Args:
            line: A single line from the JSON stream.

        Returns:
            A StreamEvent if parsing succeeded, None otherwise.
        """
        line = line.strip()
        if not line:
            return None

        try:
            data = json.loads(line)
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse JSON line: {e}")
            return None

        # Extract event type
        event_type_str = data.get("type", "unknown")
        event_type = self.EVENT_TYPE_MAP.get(event_type_str, EventType.SYSTEM)

        # Extract session ID from result events
        if event_type == EventType.RESULT:
            self._extract_session_id(data)

        # Parse timestamp if available, otherwise use now
        timestamp = self._parse_timestamp(data.get("timestamp"))

        return StreamEvent(
            event_type=event_type,
            timestamp=timestamp,
            data=data,
            raw_json=line,
        )

    def _extract_session_id(self, data: dict[str, Any]) -> None:
        """Extract session ID from result data.

        Args:
            data: The parsed JSON data.
        """
        # Claude stores session ID in result.session_id
        if "session_id" in data:
            self._session_id = data["session_id"]
        elif (
            "result" in data and isinstance(data["result"], dict) and "session_id" in data["result"]
        ):
            self._session_id = data["result"]["session_id"]

    def _parse_timestamp(self, ts: str | None) -> datetime:
        """Parse a timestamp string or return current time.

        Args:
            ts: ISO format timestamp string or None.

        Returns:
            Parsed datetime or current UTC time.
        """
        if ts is None:
            return datetime.now(UTC)

        try:
            # Handle ISO format with or without Z suffix
            if ts.endswith("Z"):
                ts = ts[:-1] + "+00:00"
            return datetime.fromisoformat(ts)
        except ValueError:
            return datetime.now(UTC)

    async def parse_stream(
        self,
        lines: AsyncIterator[str],
    ) -> AsyncIterator[StreamEvent]:
        """Parse an async stream of lines into events.

        Args:
            lines: Async iterator of lines from the process output.

        Yields:
            StreamEvent objects for each valid JSON line.
        """
        async for line in lines:
            event = self.parse_line(line)
            if event is not None:
                yield event

    def feed(self, chunk: str) -> list[StreamEvent]:
        """Feed a chunk of data and return any complete events.

        For use with non-async streams or buffered reading.

        Args:
            chunk: A chunk of data (may contain partial lines).

        Returns:
            List of parsed events from complete lines.
        """
        self._buffer += chunk
        events: list[StreamEvent] = []

        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            event = self.parse_line(line)
            if event is not None:
                events.append(event)

        return events

    def flush(self) -> StreamEvent | None:
        """Flush any remaining buffered data.

        Call this when the stream ends to handle any partial line.

        Returns:
            A StreamEvent if there was buffered data, None otherwise.
        """
        if self._buffer.strip():
            event = self.parse_line(self._buffer)
            self._buffer = ""
            return event
        return None
