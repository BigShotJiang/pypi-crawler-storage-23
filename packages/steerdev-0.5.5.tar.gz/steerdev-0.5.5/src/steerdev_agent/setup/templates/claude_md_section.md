## Task Management

This project uses steerdev.com for task management. **You must respect the task lifecycle.**

### Task Lifecycle

Tasks follow this Linear-compatible lifecycle:

```
BACKLOG → TODO → IN-PROGRESS → DONE
```

| Status | Description | Your Action |
|--------|-------------|-------------|
| `backlog` | Task is queued, not ready for work | Do not work on these tasks |
| `todo` | Ready to be worked on | Pick up task and move to `in-progress` |
| `in-progress` | Currently being worked on | Implement the task |
| `done` | Task completed | No action needed |
| `cancelled` | Task was cancelled | No action needed |

### Available Commands

| Command | Description |
|---------|-------------|
| `steerdev tasks next` | Get the next task to work on |
| `steerdev tasks list` | List all tasks with optional filters |
| `steerdev tasks get TASK_ID` | Get details of a specific task |
| `steerdev tasks update TASK_ID --status STATUS` | Update task status |
| `steerdev tasks create --title "..." --prompt "..."` | Create a new task |

### Workflow

1. Run `steerdev tasks next` to get the next task
2. Update task to `in-progress` before starting work
3. **Create a feature branch** using the task ID: `git checkout -b task/<task-id-short>`
4. Implement the task
5. **Commit your changes** with clear, descriptive commit messages
6. **Create a pull request** using GitHub CLI: `gh pr create`
7. Update task to `done` with a result summary and PR URL: `--result "Summary of work done. PR: <url>"`

### Git Workflow (Required)

**You MUST use Git and GitHub CLI to manage your work.** Every task implementation must result in a pull request.

#### Branch Naming

Create a branch before starting any implementation work:

```bash
# Use task ID for branch name (use first 8 chars of UUID)
git checkout -b task/<short-task-id>

# Example
git checkout -b task/abc12345
```

#### Committing Changes

Make atomic commits with clear messages:

```bash
# Stage and commit your changes
git add .
git commit -m "feat: implement user authentication

- Add JWT token generation
- Create login/logout endpoints
- Add auth middleware"
```

Follow conventional commit format:
- `feat:` - New features
- `fix:` - Bug fixes
- `refactor:` - Code refactoring
- `docs:` - Documentation changes
- `test:` - Adding or updating tests
- `chore:` - Maintenance tasks

#### Creating Pull Requests

**Always create a PR when completing a task:**

```bash
# Push branch and create PR
git push -u origin HEAD
gh pr create --title "Task: <title>" --body "## Summary

<description of changes>

## Task Reference
Task ID: <task-id>

## Changes Made
- Change 1
- Change 2

## Testing
- How to test the changes"
```

#### Complete Workflow Example

```bash
# 1. Get next task
steerdev tasks next

# 2. Mark as in-progress
steerdev tasks update abc123-... --status in-progress

# 3. Create feature branch
git checkout -b task/abc12345

# 4. Implement the feature (make commits as you go)
git add .
git commit -m "feat: add new endpoint for user data"

# 5. Push and create PR
git push -u origin HEAD
gh pr create --title "Add user data endpoint" --body "Implementation for task abc123..."

# 6. Update task to done with PR link
steerdev tasks update abc123-... --status done --result "Implemented user data endpoint. PR: https://github.com/org/repo/pull/42"
```

**IMPORTANT:** Never leave work uncommitted. Always create a PR before marking a task as `done`.

**Wave Mode:** If you are running in **wave mode** (processing multiple tasks in a single session), **only create the PR at the end of the wave**, not after each individual task. Commit your changes after each task, but defer the `git push` and PR creation until all tasks in the wave are completed.

### Status Values

- `backlog` - Task queued, not ready for work
- `todo` - Ready to be worked on
- `in-progress` - Currently working on task
- `done` - Task completed
- `cancelled` - Task was cancelled

### Environment Variables

- `STEERDEV_API_KEY` - Required for API authentication
- `STEERDEV_PROJECT_ID` - Optional, default project ID
- `STEERDEV_AGENT_ID` - Optional, agent identifier for tracking
- `STEERDEV_API_ENDPOINT` - Optional, defaults to https://platform.steerdev.com/api/v1
