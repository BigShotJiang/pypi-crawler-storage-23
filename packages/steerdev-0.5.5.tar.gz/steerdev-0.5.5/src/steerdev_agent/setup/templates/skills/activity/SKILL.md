# Activity Skill

This skill enables self-reporting of progress, blockers, and querying activity history via the steerdev.com API.

Activity reporting provides visibility into agent work and enables better coordination and debugging.

## Event Types

| Type | Description | When to Use |
|------|-------------|-------------|
| `progress` | Progress update | Report incremental progress on a task |
| `blocker` | Blocked on something | Report when stuck or waiting |
| `question` | Need clarification | Report questions about requirements |
| `milestone` | Reached a milestone | Report significant achievements |
| `error` | Encountered an error | Report errors during execution |
| `warning` | Warning/heads-up | Report potential issues |
| `info` | General information | Report general updates |

## When to Use

- **Making progress**: Report progress updates periodically
- **Encountering blockers**: Report blockers that prevent progress
- **Need clarification**: Report questions about requirements or approach
- **Completing milestones**: Report when significant milestones are reached
- **Debugging issues**: Query activity history to understand what happened

## Available Commands

### Report Activity

```bash
steerdev activity report --type TYPE --message "MESSAGE" [OPTIONS]
```

Self-report progress, blockers, or other activity events.

**Options:**
- `--type`, `-t`: Event type (required) - `progress`, `blocker`, `question`, `milestone`, `error`, `warning`, `info`
- `--message`, `-m`: Human-readable message (required)
- `--metadata`: Additional metadata as JSON string
- `--run-id`, `-r`: Run ID to associate with
- `--session`, `-s`: Session name

**Examples:**
```bash
# Report progress
steerdev activity report \
  --type progress \
  --message "Completed authentication module, starting API endpoints"

# Report a blocker
steerdev activity report \
  --type blocker \
  --message "Need database credentials to continue testing"

# Report with metadata
steerdev activity report \
  --type milestone \
  --message "All unit tests passing" \
  --metadata '{"tests_passed": 42, "coverage": "85%"}'

# Report a question
steerdev activity report \
  --type question \
  --message "Should login endpoint support OAuth or just email/password?"

# Report an error
steerdev activity report \
  --type error \
  --message "Build failed: missing dependency @types/node"
```

### Query Activity

```bash
steerdev activity query [--run-id RUN_ID] [--type TYPE] [--limit N]
```

Query activity history with optional filters.

**Options:**
- `--run-id`, `-r`: Filter by run ID
- `--type`, `-t`: Filter by event type
- `--limit`, `-l`: Maximum events to return (default: 20)

**Examples:**
```bash
# Get recent activity
steerdev activity query

# Get activity for a specific run
steerdev activity query --run-id abc123...

# Get only blockers
steerdev activity query --type blocker

# Get recent errors
steerdev activity query --type error --limit 10
```

## Workflow Example

```bash
# Starting a task - report progress
steerdev activity report \
  --type progress \
  --message "Starting work on user authentication feature"

# Working on implementation
steerdev activity report \
  --type progress \
  --message "Implemented JWT token generation"

# Hit a blocker
steerdev activity report \
  --type blocker \
  --message "Blocked: Need Redis connection for session storage"

# Ask a question
steerdev activity report \
  --type question \
  --message "Token expiry: 1 hour or 24 hours?"

# Reached a milestone
steerdev activity report \
  --type milestone \
  --message "Authentication module complete with tests"

# Check what happened in a run
steerdev activity query --run-id abc123...
```

## Best Practices

1. **Report progress regularly** - Helps track work and identify issues
2. **Be specific about blockers** - Include what's needed to unblock
3. **Include relevant metadata** - Add structured data for better tracking
4. **Report milestones** - Helps identify when major pieces are complete
5. **Report errors immediately** - Helps with debugging and recovery
6. **Write progress logs** - Also write to `docs/progress.jsonl` for local visibility

## Complementary: Progress Logging

Activity reporting sends events to the steerdev.com API. You should ALSO write progress logs locally:

- **`docs/progress.jsonl`**: Append JSON lines for each significant event
- **`docs/{timestamp}_{task}.md`**: Detailed markdown progress notes

See the Progress Logging skill for full details. Both systems work together:
- Activity API: Real-time server-side visibility
- Progress logs: Local audit trail and documentation

## Environment

Requires `STEERDEV_API_KEY` environment variable to be set.

**Optional:**
- `STEERDEV_API_ENDPOINT`: Override the API base URL (default: https://platform.steerdev.com/api/v1)
- `STEERDEV_AGENT_ID`: Agent identifier for tracking
- `STEERDEV_AGENT_NAME`: Agent name for display
