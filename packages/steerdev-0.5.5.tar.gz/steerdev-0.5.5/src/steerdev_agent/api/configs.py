"""Agent configuration sync client for platform configs and workflows."""

from typing import Any, Self

import httpx
from loguru import logger

from steerdev_agent.api.client import get_api_endpoint, get_api_key, get_project_id
from steerdev_agent.config.platform import PlatformConfig, WorkflowConfig


class ConfigsClient:
    """Async HTTP client for syncing agent configurations from platform.

    Manages fetching platform configs (system prompts, skills, MCPs, env vars)
    and workflow definitions for agent startup and execution.
    """

    def __init__(
        self,
        api_key: str | None = None,
        project_id: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY.
            project_id: Project ID to sync configs for. If not provided, reads from STEERDEV_PROJECT_ID.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or get_api_key()
        self.project_id = project_id or get_project_id()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        await self.close()

    async def sync_configs(self, project_id: str | None = None) -> PlatformConfig | None:
        """Sync all active configurations from platform.

        Args:
            project_id: Override project ID for this request.

        Returns:
            PlatformConfig with all synced configs, or None on failure.
        """
        project_id = project_id or self.project_id
        if not project_id:
            logger.error("No project_id provided for config sync")
            return None

        client = await self._get_client()
        logger.debug(f"Syncing configs for project {project_id}")

        try:
            response = await client.get(
                f"{self.api_base}/configs/sync",
                headers=self.headers,
                params={"project_id": project_id},
            )

            if response.status_code == 200:
                data = response.json()
                config = PlatformConfig.from_api_response(data)
                logger.info(
                    f"Synced configs: {len(config.system_prompts)} prompts, "
                    f"{len(config.skills)} skills, {len(config.mcps)} MCPs, "
                    f"{len(config.env_vars)} env var sets"
                )
                return config

            logger.error(f"Failed to sync configs: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error syncing configs: {e}")
            return None

    async def get_workflow(
        self,
        workflow_id: str,
    ) -> WorkflowConfig | None:
        """Get a specific workflow by ID.

        Args:
            workflow_id: Workflow ID to fetch.

        Returns:
            WorkflowConfig or None if not found.
        """
        client = await self._get_client()
        logger.debug(f"Fetching workflow {workflow_id}")

        try:
            response = await client.get(
                f"{self.api_base}/workflows/{workflow_id}",
                headers=self.headers,
            )

            if response.status_code == 200:
                data = response.json()
                return WorkflowConfig.from_api_response(data)

            if response.status_code == 404:
                logger.warning(f"Workflow {workflow_id} not found")
                return None

            logger.error(f"Failed to get workflow: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error getting workflow: {e}")
            return None

    async def get_default_workflow(
        self,
        project_id: str | None = None,
    ) -> WorkflowConfig | None:
        """Get the default workflow for a project.

        Args:
            project_id: Override project ID for this request.

        Returns:
            WorkflowConfig or None if no default workflow exists.
        """
        project_id = project_id or self.project_id
        if not project_id:
            logger.error("No project_id provided for getting default workflow")
            return None

        client = await self._get_client()
        logger.debug(f"Fetching default workflow for project {project_id}")

        try:
            response = await client.get(
                f"{self.api_base}/workflows",
                headers=self.headers,
                params={"project_id": project_id},
            )

            if response.status_code == 200:
                data = response.json()
                workflows = data.get("workflows", [])

                # Find the default workflow
                for wf in workflows:
                    if wf.get("is_default"):
                        return WorkflowConfig.from_api_response(wf)

                # If no default, return the first workflow if any
                if workflows:
                    logger.debug("No default workflow found, using first available")
                    return WorkflowConfig.from_api_response(workflows[0])

                logger.debug("No workflows found for project")
                return None

            logger.error(f"Failed to list workflows: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error listing workflows: {e}")
            return None

    async def list_workflows(
        self,
        project_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[WorkflowConfig]:
        """List all workflows for a project.

        Args:
            project_id: Override project ID for this request.
            limit: Maximum number of workflows to return.
            offset: Offset for pagination.

        Returns:
            List of WorkflowConfig objects.
        """
        project_id = project_id or self.project_id
        if not project_id:
            logger.error("No project_id provided for listing workflows")
            return []

        client = await self._get_client()
        logger.debug(f"Listing workflows for project {project_id}")

        try:
            response = await client.get(
                f"{self.api_base}/workflows",
                headers=self.headers,
                params={"project_id": project_id, "limit": limit, "offset": offset},
            )

            if response.status_code == 200:
                data = response.json()
                workflows = [
                    WorkflowConfig.from_api_response(wf) for wf in data.get("workflows", [])
                ]
                logger.debug(f"Found {len(workflows)} workflows")
                return workflows

            logger.error(f"Failed to list workflows: {response.status_code} - {response.text}")
            return []

        except httpx.RequestError as e:
            logger.error(f"Request error listing workflows: {e}")
            return []
