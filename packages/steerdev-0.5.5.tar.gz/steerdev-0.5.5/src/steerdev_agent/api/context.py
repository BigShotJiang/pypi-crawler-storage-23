"""Context API client for SteerDev Agent.

Provides methods for retrieving and managing project context
(tech stack, patterns, structure, etc.) for AI agents.

The Codebase Awareness feature provides:
- Tech stack detection (frameworks, libraries, tools)
- Directory structure analysis
- Code patterns and conventions
- Dependencies mapping
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field
from rich.console import Console
from rich.panel import Panel

from steerdev_agent.api.client import SteerDevClient, get_project_id

console = Console()


class TechStackInfo(BaseModel):
    """Tech stack detection result."""

    framework: dict[str, Any] | None = None
    language: dict[str, Any] | None = None
    database: dict[str, Any] | None = None
    auth: dict[str, Any] | None = None
    styling: dict[str, Any] | None = None
    testing: dict[str, Any] | None = None
    package_manager: str | None = Field(default=None, alias="packageManager")
    build_tool: str | None = Field(default=None, alias="buildTool")


class StructureInfo(BaseModel):
    """Directory structure analysis."""

    type: str = "single"
    directories: list[dict[str, Any]] = Field(default_factory=list)
    entry_points: list[str] = Field(default_factory=list, alias="entryPoints")
    config_files: list[str] = Field(default_factory=list, alias="configFiles")


class PatternsInfo(BaseModel):
    """Code patterns and conventions."""

    naming: dict[str, str] = Field(default_factory=dict)
    architecture: list[str] = Field(default_factory=list)
    conventions: list[dict[str, Any]] = Field(default_factory=list)
    abstractions: dict[str, list[str]] = Field(default_factory=dict)


class CodebaseContext(BaseModel):
    """Codebase context model - full analysis result."""

    project_id: str
    repositories: list[dict[str, Any]] = Field(default_factory=list)
    context: dict[str, Any] | None = None
    status: str
    last_analyzed_at: str | None = None
    error: str | None = None


class ContextClient(SteerDevClient):
    """Client for project context operations.

    Provides methods to retrieve and refresh project context
    that helps AI agents understand the codebase.
    """

    def get_context(
        self, project_id: str | None = None, format: str = "json"
    ) -> dict[str, Any] | str | None:
        """Get project context.

        Args:
            project_id: Project ID. Falls back to STEERDEV_PROJECT_ID env var.
            format: Response format - "json" or "markdown".

        Returns:
            Project context (dict for JSON, str for markdown) or None if not found.
        """
        effective_project_id = project_id or get_project_id()
        if not effective_project_id:
            console.print(
                "[red]Error: project_id is required. "
                "Use --project-id or set STEERDEV_PROJECT_ID environment variable[/red]"
            )
            return None

        console.print(
            f"Fetching context for project {effective_project_id} "
            f"from {self.api_base}/context?project_id={effective_project_id}"
        )
        response = self.get(f"/context?project_id={effective_project_id}&format={format}")

        if response.status_code == 404:
            console.print(f"[yellow]No context found for project {effective_project_id}[/yellow]")
            return None

        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        # Return raw text for markdown format
        if format == "markdown":
            return response.text

        return response.json()

    def refresh_context(
        self, project_id: str | None = None, force: bool = False
    ) -> dict[str, Any] | None:
        """Force refresh of project context.

        Triggers a re-analysis of the project repositories to update cached context.

        Args:
            project_id: Project ID. Falls back to STEERDEV_PROJECT_ID env var.
            force: Force re-analysis even if context is up to date.

        Returns:
            Analysis result dict or None on failure.
        """
        effective_project_id = project_id or get_project_id()
        if not effective_project_id:
            console.print(
                "[red]Error: project_id is required. "
                "Use --project-id or set STEERDEV_PROJECT_ID environment variable[/red]"
            )
            return None

        console.print(
            f"Refreshing context for project {effective_project_id} "
            f"at {self.api_base}/context/analyze"
        )
        response = self.post(
            "/context/analyze",
            json={"project_id": effective_project_id, "force": force},
        )

        if response.status_code == 404:
            console.print(f"[red]Error: Project '{effective_project_id}' not found[/red]")
            return None

        if response.status_code == 400:
            error_data = response.json()
            console.print(f"[red]Error: {error_data.get('error', 'Unknown error')}[/red]")
            return None

        if response.status_code not in (200, 201, 202):
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return None

        return response.json()


def display_context(context: dict[str, Any]) -> None:
    """Display project context in a formatted panel.

    Args:
        context: Project context dict from the API.
    """
    project_id = context.get("project_id", "Unknown")
    status = context.get("status", "unknown")
    ctx = context.get("context") or {}
    repos = context.get("repositories", [])

    # Build context info
    info_lines = []

    # Repositories
    if repos:
        info_lines.append("[bold cyan]Repositories:[/bold cyan]")
        for repo in repos:
            info_lines.append(f"  • {repo.get('full_name', 'unknown')}")
        info_lines.append("")

    # Summary (markdown)
    if ctx.get("summary"):
        info_lines.append("[bold cyan]Summary:[/bold cyan]")
        # Truncate long summaries
        summary = ctx["summary"]
        lines = summary.split("\n")[:15]
        for line in lines:
            info_lines.append(f"  {line}")
        if len(summary.split("\n")) > 15:
            info_lines.append("  ...")
        info_lines.append("")

    # Tech stack
    tech_stack = ctx.get("tech_stack", {})
    if tech_stack:
        info_lines.append("[bold cyan]Tech Stack:[/bold cyan]")
        if tech_stack.get("framework"):
            fw = tech_stack["framework"]
            fw_str = fw.get("name", "")
            if fw.get("version"):
                fw_str += f" {fw['version']}"
            if fw.get("router"):
                fw_str += f" ({fw['router']})"
            info_lines.append(f"  • Framework: {fw_str}")
        if tech_stack.get("language"):
            info_lines.append(f"  • Language: {tech_stack['language'].get('primary', 'unknown')}")
        if tech_stack.get("database"):
            db = tech_stack["database"]
            db_str = db.get("name", "")
            if db.get("client"):
                db_str += f" ({db['client']})"
            info_lines.append(f"  • Database: {db_str}")
        if tech_stack.get("auth"):
            info_lines.append(f"  • Auth: {tech_stack['auth'].get('provider', 'unknown')}")
        if tech_stack.get("styling"):
            style = tech_stack["styling"]
            style_str = style.get("framework", "")
            if style.get("ui"):
                style_str += f" + {style['ui']}"
            info_lines.append(f"  • Styling: {style_str}")
        if tech_stack.get("testing"):
            test = tech_stack["testing"]
            test_parts = []
            if test.get("framework"):
                test_parts.append(test["framework"])
            if test.get("e2e"):
                test_parts.append(test["e2e"])
            if test_parts:
                info_lines.append(f"  • Testing: {' + '.join(test_parts)}")
        if tech_stack.get("packageManager"):
            info_lines.append(f"  • Package Manager: {tech_stack['packageManager']}")
        info_lines.append("")

    # Patterns
    patterns = ctx.get("patterns", {})
    if patterns:
        arch = patterns.get("architecture", [])
        if arch:
            info_lines.append("[bold cyan]Architecture:[/bold cyan]")
            for a in arch[:5]:
                info_lines.append(f"  • {a}")
            info_lines.append("")

        conventions = patterns.get("conventions", [])
        if conventions:
            info_lines.append("[bold cyan]Conventions:[/bold cyan]")
            for conv in conventions[:5]:
                info_lines.append(f"  • {conv.get('pattern', '')}")
            info_lines.append("")

    # Structure (directories)
    structure = ctx.get("structure", {})
    if structure:
        dirs = structure.get("directories", [])
        if dirs:
            info_lines.append("[bold cyan]Key Directories:[/bold cyan]")
            for d in dirs[:6]:
                path = d.get("path", "")
                purpose = d.get("purpose", "")
                info_lines.append(f"  • {path}: {purpose}")
            if len(dirs) > 6:
                info_lines.append(f"  ... and {len(dirs) - 6} more")
            info_lines.append("")

    # Status and metadata
    status_color = {
        "completed": "green",
        "analyzing": "blue",
        "pending": "yellow",
        "failed": "red",
    }.get(status, "white")
    info_lines.append(f"[dim]Status: [{status_color}]{status}[/{status_color}][/dim]")

    if context.get("last_analyzed_at"):
        info_lines.append(f"[dim]Last analyzed: {context['last_analyzed_at']}[/dim]")

    if context.get("error"):
        info_lines.append(f"[red]Error: {context['error']}[/red]")

    console.print(
        Panel(
            "\n".join(info_lines),
            title=f"Codebase Context: {project_id[:8]}...",
            border_style="blue",
        )
    )


def display_context_refresh_success(project_id: str) -> None:
    """Display context refresh success message.

    Args:
        project_id: Project ID that was refreshed.
    """
    console.print(
        Panel(
            f"[bold green]Context refresh initiated[/bold green]\n\n"
            f"Project: {project_id}\n\n"
            "The context will be updated in the background. "
            "Run `steerdev context get` to retrieve the updated context.",
            title="Success",
            border_style="green",
        )
    )
