"""Tests for the prompt builder module."""

from steerdev_agent.prompt.builder import (
    ProjectContext,
    PromptBuilder,
    PromptContext,
    TaskContext,
    WorkflowContext,
)
from steerdev_agent.prompt.templates import PromptTemplates


class TestPromptTemplates:
    """Tests for PromptTemplates."""

    def test_format_task(self):
        """Test task formatting."""
        result = PromptTemplates.format_task(
            title="Fix bug",
            task_id="task-123",
            prompt="Fix the login issue",
            priority=1,
            status="started",
            working_directory="/project",
        )

        assert "Fix bug" in result
        assert "task-123" in result
        assert "Urgent" in result
        assert "started" in result
        assert "/project" in result

    def test_format_project(self):
        """Test project formatting."""
        result = PromptTemplates.format_project(
            name="MyProject",
            project_id="proj-456",
            description="A test project",
        )

        assert "MyProject" in result
        assert "proj-456" in result
        assert "A test project" in result

    def test_format_workflow_phase(self):
        """Test workflow phase formatting."""
        result = PromptTemplates.format_workflow_phase(
            phase_name="Implementation",
            phase_description="Build the feature",
            phase_instructions="Write code and tests",
        )

        assert "Implementation" in result
        assert "Build the feature" in result
        assert "Write code and tests" in result

    def test_format_system_prompt(self):
        """Test system prompt formatting."""
        result = PromptTemplates.format_system_prompt(
            project_info="Project: Test",
            task_info="Task: Build",
            instructions="Follow TDD",
        )

        assert "Project: Test" in result
        assert "Task: Build" in result
        assert "Follow TDD" in result


class TestPromptBuilder:
    """Tests for PromptBuilder."""

    def test_build_with_task_only(self):
        """Test building prompt with task context only."""
        builder = PromptBuilder()
        context = PromptContext(
            task=TaskContext(
                id="task-1",
                title="Implement feature",
                prompt="Build login system",
            ),
        )

        prompt = builder.build(context)

        assert "Implement feature" in prompt
        assert "task-1" in prompt
        assert "Build login system" in prompt

    def test_build_with_project_and_task(self):
        """Test building prompt with project and task."""
        builder = PromptBuilder()
        context = PromptContext(
            project=ProjectContext(
                id="proj-1",
                name="WebApp",
                description="A web application",
            ),
            task=TaskContext(
                id="task-1",
                title="Add auth",
                prompt="Implement OAuth",
            ),
        )

        prompt = builder.build(context)

        assert "WebApp" in prompt
        assert "Add auth" in prompt
        assert "Implement OAuth" in prompt

    def test_build_with_workflow(self):
        """Test building prompt with workflow context."""
        builder = PromptBuilder()
        context = PromptContext(
            task=TaskContext(
                id="task-1",
                title="Test feature",
                prompt="Write tests",
            ),
            workflow=WorkflowContext(
                phase_name="Testing",
                phase_description="Verify functionality",
                phase_instructions="Cover edge cases",
            ),
        )

        prompt = builder.build(context)

        assert "Testing" in prompt
        assert "Verify functionality" in prompt
        assert "Cover edge cases" in prompt

    def test_build_resume_prompt(self):
        """Test building resume prompt."""
        builder = PromptBuilder()
        context = PromptContext(
            resume_message="Continue with the tests",
        )

        prompt = builder.build(context)

        assert "Continue with the tests" in prompt
        assert "Continue working" in prompt

    def test_build_with_custom_instructions(self):
        """Test building prompt with custom instructions."""
        builder = PromptBuilder()
        context = PromptContext(
            task=TaskContext(
                id="task-1",
                title="Feature",
                prompt="Build it",
            ),
            custom_instructions="Always write tests first",
        )

        prompt = builder.build(context)

        assert "Always write tests first" in prompt

    def test_build_from_dict(self):
        """Test building prompt from dictionary input."""
        builder = PromptBuilder()

        prompt = builder.build_from_dict(
            project={"id": "p1", "name": "Project"},
            task={"id": "t1", "title": "Task", "prompt": "Do work"},
        )

        assert "Project" in prompt
        assert "Task" in prompt
        assert "Do work" in prompt

    def test_project_custom_instructions(self):
        """Test project-level custom instructions."""
        builder = PromptBuilder()
        context = PromptContext(
            project=ProjectContext(
                id="proj-1",
                name="Strict Project",
                custom_instructions="Never use globals",
            ),
            task=TaskContext(
                id="task-1",
                title="Task",
                prompt="Work",
            ),
        )

        prompt = builder.build(context)

        assert "Never use globals" in prompt

    def test_working_directory_from_task(self):
        """Test working directory comes from task."""
        builder = PromptBuilder()
        context = PromptContext(
            task=TaskContext(
                id="task-1",
                title="Task",
                prompt="Work",
                working_directory="/custom/path",
            ),
        )

        prompt = builder.build(context)

        assert "/custom/path" in prompt

    def test_working_directory_fallback_to_project(self):
        """Test working directory falls back to project."""
        builder = PromptBuilder()
        context = PromptContext(
            project=ProjectContext(
                id="proj-1",
                name="Project",
                working_directory="/project/path",
            ),
            task=TaskContext(
                id="task-1",
                title="Task",
                prompt="Work",
                working_directory=None,
            ),
        )

        prompt = builder.build(context)

        assert "/project/path" in prompt

    def test_task_with_spec(self):
        """Test task with specification."""
        builder = PromptBuilder()
        context = PromptContext(
            task=TaskContext(
                id="task-1",
                title="Implement from spec",
                prompt="Build feature",
                spec="## Technical Specification\n- Use React\n- Add tests",
            ),
        )

        prompt = builder.build(context)

        assert "Technical Specification" in prompt
        assert "Use React" in prompt
