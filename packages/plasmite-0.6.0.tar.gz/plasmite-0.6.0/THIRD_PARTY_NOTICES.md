# Third-party notices

This project vendors the following third-party components:

## Lite3

Source: `vendor/lite3`  
License: `vendor/lite3/LICENSE`

## yyjson

Source: `vendor/lite3/lib/yyjson`  
License: `vendor/lite3/lib/yyjson/LICENSE`

## nibble_base64

Source: `vendor/lite3/lib/nibble_base64`  
License: `vendor/lite3/lib/nibble_base64/LICENSE`
