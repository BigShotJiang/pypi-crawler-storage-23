---
name: Task
about: General task or improvement
title: "[TASK] "
labels: task
assignees: ""
---

## Task Description

<!-- Describe the task to be performed -->

## Checklist

- [ ]

## Related Domain

- [ ] SDK Core
- [ ] HTTP Client
- [ ] Models/Types
- [ ] Authentication
- [ ] Examples
- [ ] Testing
- [ ] Infrastructure
- [ ] Documentation

## Related Issues / PRs

<!-- Link any related issues or pull requests -->

## Additional Information

<!-- Provide any additional information -->
