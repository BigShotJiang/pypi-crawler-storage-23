from __future__ import annotations

from .index import NAMESPACE_DECLARATIONS, NAMESPACE_LOADERS, get_catalog_declarations

__all__ = ["NAMESPACE_DECLARATIONS", "NAMESPACE_LOADERS", "get_catalog_declarations"]
