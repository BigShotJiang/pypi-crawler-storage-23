from __future__ import annotations

from .core import CMB_CORE_DECLARATIONS

__all__ = ["CMB_CORE_DECLARATIONS"]
