"""
Shipp.ai Sports Data Integration
=================================
Core module for interacting with the Shipp.ai API to retrieve live scores,
game schedules, and play-by-play event feeds for NBA, MLB, and Soccer.

Uses cursor-based polling (since_event_id) for efficient event streaming.
Connections are created once and reused across multiple poll cycles.

Environment:
    SHIPP_API_KEY - Required. Obtain at https://platform.shipp.ai
"""

import os
import time
import logging
from typing import Optional
from datetime import datetime, timezone

import requests

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SHIPP_BASE_URL = "https://api.shipp.ai/api/v1"
VALID_SPORTS = ("nba", "mlb", "soccer")

# Retry / backoff settings
MAX_RETRIES = 3
INITIAL_BACKOFF_SECONDS = 1.0
BACKOFF_MULTIPLIER = 2.0

# Polling defaults
DEFAULT_POLL_INTERVAL_SECONDS = 10
MAX_POLL_CYCLES = 60  # safety cap

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ShippAPIError(Exception):
    """Raised when the Shipp API returns a non-recoverable error."""

    def __init__(self, status_code: int, message: str, response_body: Optional[dict] = None):
        self.status_code = status_code
        self.message = message
        self.response_body = response_body
        super().__init__(f"Shipp API {status_code}: {message}")


class ShippAuthError(ShippAPIError):
    """Raised on 401 Unauthorized — invalid or missing API key."""
    pass


class ShippPaymentError(ShippAPIError):
    """Raised on 402 Payment Required — plan limit reached."""
    pass


class ShippRateLimitError(ShippAPIError):
    """Raised on 429 Too Many Requests — rate limit hit."""
    pass


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_api_key() -> str:
    """Retrieve the Shipp API key from the environment."""
    key = os.environ.get("SHIPP_API_KEY", "").strip()
    if not key:
        raise ShippAuthError(
            status_code=401,
            message=(
                "SHIPP_API_KEY environment variable is not set. "
                "Get your key at https://platform.shipp.ai"
            ),
        )
    return key


def _headers() -> dict:
    """Build standard request headers."""
    return {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "shipp-sports-skill/1.0",
    }


def _url_with_key(path: str) -> str:
    """Build full URL with api_key query parameter."""
    sep = "&" if "?" in path else "?"
    return f"{SHIPP_BASE_URL}{path}{sep}api_key={_get_api_key()}"


def _handle_error_response(resp: requests.Response) -> None:
    """
    Inspect a non-2xx response and raise the appropriate typed exception.
    """
    body = None
    try:
        body = resp.json()
    except (ValueError, requests.exceptions.JSONDecodeError):
        pass

    msg = ""
    if body and isinstance(body, dict):
        msg = body.get("error", body.get("message", ""))
    if not msg:
        msg = resp.text[:500] if resp.text else resp.reason or "Unknown error"

    if resp.status_code == 401:
        raise ShippAuthError(resp.status_code, msg, body)
    if resp.status_code == 402:
        raise ShippPaymentError(resp.status_code, msg, body)
    if resp.status_code == 429:
        raise ShippRateLimitError(resp.status_code, msg, body)
    raise ShippAPIError(resp.status_code, msg, body)


def _request_with_retry(
    method: str,
    url: str,
    *,
    json_body: Optional[dict] = None,
    params: Optional[dict] = None,
    max_retries: int = MAX_RETRIES,
) -> dict:
    """
    Execute an HTTP request with exponential backoff on 429 and 5xx errors.

    Returns the parsed JSON response body on success.
    Raises ShippAPIError (or subclass) on non-recoverable failures.
    """
    backoff = INITIAL_BACKOFF_SECONDS

    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.request(
                method,
                url,
                headers=_headers(),
                json=json_body,
                params=params,
                timeout=45,
            )
        except requests.exceptions.ConnectionError as exc:
            logger.warning("Connection error on attempt %d/%d: %s", attempt, max_retries, exc)
            if attempt == max_retries:
                raise ShippAPIError(0, f"Connection failed after {max_retries} attempts: {exc}")
            time.sleep(backoff)
            backoff *= BACKOFF_MULTIPLIER
            continue
        except requests.exceptions.Timeout as exc:
            logger.warning("Timeout on attempt %d/%d: %s", attempt, max_retries, exc)
            if attempt == max_retries:
                raise ShippAPIError(0, f"Request timed out after {max_retries} attempts: {exc}")
            time.sleep(backoff)
            backoff *= BACKOFF_MULTIPLIER
            continue

        if resp.status_code in range(200, 300):
            try:
                return resp.json()
            except (ValueError, requests.exceptions.JSONDecodeError):
                return {"raw": resp.text}

        # Retryable errors: 429 and 5xx
        if resp.status_code == 429 or resp.status_code >= 500:
            logger.warning(
                "Retryable error %d on attempt %d/%d. Backing off %.1fs.",
                resp.status_code,
                attempt,
                max_retries,
                backoff,
            )
            if attempt == max_retries:
                _handle_error_response(resp)
            # Respect Retry-After header if present
            retry_after = resp.headers.get("Retry-After")
            wait = float(retry_after) if retry_after else backoff
            time.sleep(wait)
            backoff *= BACKOFF_MULTIPLIER
            continue

        # Non-retryable errors (400, 401, 402, 403, 404, etc.)
        _handle_error_response(resp)

    # Should not reach here, but just in case
    raise ShippAPIError(0, "Exhausted retries without a response")


def _validate_sport(sport: str) -> str:
    """Normalize and validate the sport parameter."""
    sport = sport.strip().lower()
    if sport not in VALID_SPORTS:
        raise ValueError(
            f"Invalid sport '{sport}'. Must be one of: {', '.join(VALID_SPORTS)}"
        )
    return sport


# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------

# In-memory cache of connection IDs keyed by sport.
# In production you would persist this, but for a skill session, memory is fine.
_connection_cache: dict[str, str] = {}


def create_connection(sport: str, *, force_new: bool = False) -> str:
    """
    Create (or retrieve cached) a Shipp connection for the given sport.

    Parameters
    ----------
    sport : str
        One of "nba", "mlb", "soccer".
    force_new : bool
        If True, always create a fresh connection even if one is cached.

    Returns
    -------
    str
        The connection_id to use for polling.
    """
    sport = _validate_sport(sport)

    if not force_new and sport in _connection_cache:
        logger.debug("Reusing cached connection for %s: %s", sport, _connection_cache[sport])
        return _connection_cache[sport]

    filter_map = {
        "nba": "Track all NBA games today including scores, play-by-play, and game status updates",
        "mlb": "Track all MLB games today including scores, play-by-play, and pitching changes",
        "soccer": "Track all soccer matches today across major leagues including goals, cards, and substitutions",
    }
    url = _url_with_key("/connections/create")
    payload = {
        "filter_instructions": filter_map.get(sport, f"Track all {sport} games today with scores and play-by-play"),
    }

    data = _request_with_retry("POST", url, json_body=payload)

    connection_id = data.get("connection_id") or data.get("id")
    if not connection_id:
        raise ShippAPIError(0, f"No connection_id in response: {data}")

    _connection_cache[sport] = connection_id
    logger.info("Created connection for %s: %s", sport, connection_id)
    return connection_id


def list_connections() -> list[dict]:
    """
    List all active Shipp connections for the authenticated account.

    Returns
    -------
    list[dict]
        Each dict contains at minimum: id, sport, status.
    """
    url = _url_with_key("/connections")
    data = _request_with_retry("GET", url)

    # The response might be a list directly or wrapped in a key
    if isinstance(data, list):
        return data
    return data.get("connections", data.get("data", []))


# ---------------------------------------------------------------------------
# Polling for events
# ---------------------------------------------------------------------------


def poll_connection(
    connection_id: str,
    *,
    since_event_id: Optional[str] = None,
    limit: int = 100,
) -> dict:
    """
    Poll a connection for new events using cursor-based pagination.

    Parameters
    ----------
    connection_id : str
        The connection to poll.
    since_event_id : str, optional
        Cursor — only return events after this ID. Pass None for the first poll.
    limit : int
        Maximum events to return per request.

    Returns
    -------
    dict
        Keys: "events" (list[dict]), "last_event_id" (str or None),
        "has_more" (bool).
    """
    url = _url_with_key(f"/connections/{connection_id}")
    payload: dict = {"limit": limit}
    if since_event_id:
        payload["since_event_id"] = since_event_id

    data = _request_with_retry("POST", url, json_body=payload)

    events = data.get("events", data.get("data", []))
    if not isinstance(events, list):
        events = []

    last_event_id = data.get("last_event_id") or data.get("cursor")
    if not last_event_id and events:
        # Derive cursor from last event if the API didn't provide one
        last_event = events[-1]
        last_event_id = last_event.get("event_id") or last_event.get("id")

    has_more = data.get("has_more", len(events) >= limit)

    return {
        "events": events,
        "last_event_id": last_event_id,
        "has_more": bool(has_more),
    }


def poll_all_events(
    connection_id: str,
    *,
    since_event_id: Optional[str] = None,
    max_pages: int = 10,
) -> list[dict]:
    """
    Drain all available events from a connection, paginating as needed.

    Returns
    -------
    list[dict]
        All events across pages.
    """
    all_events: list[dict] = []
    cursor = since_event_id

    for _ in range(max_pages):
        result = poll_connection(connection_id, since_event_id=cursor)
        page_events = result["events"]
        all_events.extend(page_events)

        if not result["has_more"] or not result["last_event_id"]:
            break
        cursor = result["last_event_id"]

    return all_events


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------


def get_todays_games(sport: str) -> list[dict]:
    """
    Retrieve today's game schedule for the given sport.

    Parameters
    ----------
    sport : str
        One of "nba", "mlb", "soccer".

    Returns
    -------
    list[dict]
        Each dict represents a game with defensive field access — all fields
        are treated as optional. Common fields: game_id, home_team, away_team,
        start_time, status, venue.
    """
    sport = _validate_sport(sport)
    url = _url_with_key(f"/sports/{sport}/schedule")

    data = _request_with_retry("GET", url)

    games_raw = data.get("games", data.get("schedule", data.get("data", [])))
    if not isinstance(games_raw, list):
        games_raw = []

    # Normalize each game with defensive access
    games = []
    for g in games_raw:
        if not isinstance(g, dict):
            continue
        games.append({
            "game_id": g.get("game_id") or g.get("id", ""),
            "home_team": g.get("home_team", g.get("home", {}).get("name", "TBD")),
            "away_team": g.get("away_team", g.get("away", {}).get("name", "TBD")),
            "start_time": g.get("start_time") or g.get("datetime") or g.get("scheduled", ""),
            "status": g.get("status", "scheduled"),
            "venue": g.get("venue") or g.get("location", ""),
            "sport": sport,
            "source": "shipp",
        })

    return games


# ---------------------------------------------------------------------------
# Live scores
# ---------------------------------------------------------------------------


def get_live_scores(sport: str) -> list[dict]:
    """
    Get live scores for all in-progress games for the given sport.

    Creates a connection if needed, polls for the latest events, and extracts
    score data.

    Returns
    -------
    list[dict]
        Each dict: game_id, home_team, away_team, home_score, away_score,
        period/inning/half, clock, status.
    """
    sport = _validate_sport(sport)
    connection_id = create_connection(sport)
    events = poll_all_events(connection_id)

    # Build a dict of the latest score per game_id
    score_map: dict[str, dict] = {}
    for event in events:
        if not isinstance(event, dict):
            continue

        game_id = event.get("game_id") or event.get("match_id", "")
        if not game_id:
            continue

        # Always overwrite with the latest event for this game
        score_map[game_id] = {
            "game_id": game_id,
            "home_team": event.get("home_team") or event.get("home", {}).get("name", ""),
            "away_team": event.get("away_team") or event.get("away", {}).get("name", ""),
            "home_score": _safe_int(event.get("home_score") or event.get("home", {}).get("score")),
            "away_score": _safe_int(event.get("away_score") or event.get("away", {}).get("score")),
            "period": event.get("period") or event.get("inning") or event.get("half", ""),
            "clock": event.get("clock") or event.get("time", ""),
            "status": event.get("status", "in_progress"),
            "sport": sport,
            "source": "shipp",
            "updated_at": event.get("timestamp") or event.get("created_at", ""),
        }

    return list(score_map.values())


def _safe_int(value) -> int:
    """Safely convert a value to int, defaulting to 0."""
    if value is None:
        return 0
    try:
        return int(value)
    except (ValueError, TypeError):
        return 0


# ---------------------------------------------------------------------------
# Play-by-play
# ---------------------------------------------------------------------------


def get_play_by_play(
    game_id: str,
    sport: str = "nba",
    *,
    since_event_id: Optional[str] = None,
) -> list[dict]:
    """
    Get play-by-play events for a specific game.

    Parameters
    ----------
    game_id : str
        The game identifier.
    sport : str
        The sport this game belongs to (needed to identify the connection).
    since_event_id : str, optional
        Only return events after this cursor.

    Returns
    -------
    list[dict]
        Chronological play-by-play events. Each dict contains at minimum:
        event_id, game_id, event_type, description, timestamp.
    """
    sport = _validate_sport(sport)
    connection_id = create_connection(sport)
    all_events = poll_all_events(connection_id, since_event_id=since_event_id)

    # Filter to the requested game
    pbp = []
    for event in all_events:
        if not isinstance(event, dict):
            continue
        evt_game = event.get("game_id") or event.get("match_id", "")
        if evt_game != game_id:
            continue

        pbp.append({
            "event_id": event.get("event_id") or event.get("id", ""),
            "game_id": game_id,
            "event_type": event.get("event_type") or event.get("type", "unknown"),
            "description": event.get("description") or event.get("text", ""),
            "timestamp": event.get("timestamp") or event.get("created_at", ""),
            "period": event.get("period") or event.get("inning") or event.get("half", ""),
            "clock": event.get("clock") or event.get("time", ""),
            "team": event.get("team", ""),
            "player": event.get("player", ""),
            "home_score": _safe_int(event.get("home_score")),
            "away_score": _safe_int(event.get("away_score")),
            "source": "shipp",
        })

    return pbp


# ---------------------------------------------------------------------------
# Continuous polling helper
# ---------------------------------------------------------------------------


def stream_live_updates(
    sport: str,
    *,
    callback=None,
    poll_interval: int = DEFAULT_POLL_INTERVAL_SECONDS,
    max_cycles: int = MAX_POLL_CYCLES,
) -> None:
    """
    Continuously poll for live updates, invoking callback for each new batch.

    This is a blocking call suitable for scripts that need to watch a live feed.
    For agent use, prefer get_live_scores() or get_play_by_play() per query.

    Parameters
    ----------
    sport : str
        One of "nba", "mlb", "soccer".
    callback : callable, optional
        Called with (events: list[dict]) for each new batch. If None, events
        are logged.
    poll_interval : int
        Seconds between polls.
    max_cycles : int
        Safety cap on total poll iterations.
    """
    sport = _validate_sport(sport)
    connection_id = create_connection(sport)
    cursor: Optional[str] = None

    for cycle in range(max_cycles):
        try:
            result = poll_connection(connection_id, since_event_id=cursor)
        except ShippRateLimitError:
            logger.warning("Rate limited, backing off for %d seconds", poll_interval * 3)
            time.sleep(poll_interval * 3)
            continue
        except ShippAPIError as exc:
            logger.error("API error during polling cycle %d: %s", cycle, exc)
            break

        events = result["events"]
        if events:
            if callback:
                callback(events)
            else:
                logger.info("Received %d events at cycle %d", len(events), cycle)

            cursor = result["last_event_id"]

        time.sleep(poll_interval)

    logger.info("Polling stopped after %d cycles", max_cycles)


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    # Quick smoke test — prints today's NBA schedule
    logging.basicConfig(level=logging.INFO)
    print("=== Today's NBA Games ===")
    try:
        for game in get_todays_games("nba"):
            home = game["home_team"]
            away = game["away_team"]
            tip = game["start_time"]
            print(f"  {away} @ {home} — {tip}")
    except ShippAPIError as e:
        print(f"  Error: {e}")

    print("\n=== Live NBA Scores ===")
    try:
        scores = get_live_scores("nba")
        if not scores:
            print("  No live games right now.")
        for s in scores:
            print(
                f"  {s['away_team']} {s['away_score']} — "
                f"{s['home_team']} {s['home_score']}  "
                f"({s['period']} {s['clock']})"
            )
    except ShippAPIError as e:
        print(f"  Error: {e}")
