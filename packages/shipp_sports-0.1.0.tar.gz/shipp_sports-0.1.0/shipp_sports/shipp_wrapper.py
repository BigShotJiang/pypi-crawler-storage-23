"""
Shipp Sports Unified Wrapper
==============================
The single entry point for all sports data queries. Routes requests to the
appropriate source (Shipp.ai for live data, external APIs for enrichment)
and merges results with clear source attribution.

Usage:
    from scripts.shipp_wrapper import ShippSports

    ss = ShippSports()
    scores = ss.get_scores("nba")
    stats  = ss.get_player_stats("nba", "LeBron James")
    table  = ss.get_standings("soccer", league="premier_league")
"""

import logging
from typing import Optional, Any
from datetime import datetime, timezone

from .sports_data import (
    get_todays_games,
    get_live_scores,
    get_play_by_play,
    create_connection,
    ShippAPIError,
    ShippAuthError,
)
from .external_sources import (
    get_nba_player_stats,
    get_nba_injuries,
    get_mlb_roster,
    get_mlb_player_stats,
    get_mlb_injuries,
    get_soccer_standings,
    get_soccer_team,
    get_soccer_matches,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Unified response container
# ---------------------------------------------------------------------------


class SportsResponse:
    """
    Standardized response object combining data from multiple sources.
    Every response carries source attribution so the agent knows where
    each piece of data came from.
    """

    def __init__(
        self,
        sport: str,
        query_type: str,
        *,
        data: Any = None,
        sources: Optional[list[str]] = None,
        errors: Optional[list[str]] = None,
    ):
        self.sport = sport
        self.query_type = query_type
        self.data = data or {}
        self.sources = sources or []
        self.errors = errors or []
        self.timestamp = datetime.now(timezone.utc).isoformat()
        self.success = bool(data) and not errors

    def to_dict(self) -> dict:
        return {
            "sport": self.sport,
            "query_type": self.query_type,
            "success": self.success,
            "data": self.data,
            "sources": self.sources,
            "errors": self.errors,
            "timestamp": self.timestamp,
        }

    def __repr__(self) -> str:
        status = "OK" if self.success else "ERROR"
        return f"<SportsResponse {self.sport}/{self.query_type} [{status}] sources={self.sources}>"


# ---------------------------------------------------------------------------
# Main wrapper class
# ---------------------------------------------------------------------------


class ShippSports:
    """
    Unified sports data interface.

    Routing logic:
        - Live scores, schedules, play-by-play => Shipp.ai (primary)
        - Player stats, rosters => External APIs (balldontlie, MLB Stats API)
        - Standings, league tables => External APIs (football-data.org)
        - Injuries => External / public feeds
        - If Shipp is down, attempts external fallback where possible
    """

    def __init__(self):
        self._shipp_available: Optional[bool] = None

    # ------------------------------------------------------------------
    # Health check
    # ------------------------------------------------------------------

    def _check_shipp_health(self) -> bool:
        """Quick check if Shipp.ai is reachable and authenticated."""
        if self._shipp_available is not None:
            return self._shipp_available
        try:
            create_connection("nba")
            self._shipp_available = True
        except ShippAuthError:
            logger.error("Shipp.ai auth failed — check SHIPP_API_KEY")
            self._shipp_available = False
        except ShippAPIError as exc:
            logger.warning("Shipp.ai health check failed: %s", exc)
            self._shipp_available = False
        return self._shipp_available

    # ------------------------------------------------------------------
    # Scores
    # ------------------------------------------------------------------

    def get_scores(self, sport: str) -> SportsResponse:
        """
        Get live scores for the given sport.
        Primary: Shipp.ai. Fallback: external match APIs.
        """
        sources = []
        errors = []
        scores = []

        # Try Shipp first
        try:
            scores = get_live_scores(sport)
            sources.append("shipp.ai")
        except ShippAPIError as exc:
            errors.append(f"Shipp.ai: {exc.message}")
            logger.warning("Shipp live scores failed for %s: %s", sport, exc)

        # If Shipp returned nothing and sport is soccer, try football-data.org
        if not scores and sport == "soccer":
            try:
                matches = get_soccer_matches("PL", status="IN_PLAY")
                if matches:
                    scores = [
                        {
                            "game_id": str(m.get("match_id", "")),
                            "home_team": m.get("home_team", ""),
                            "away_team": m.get("away_team", ""),
                            "home_score": m.get("home_score", 0),
                            "away_score": m.get("away_score", 0),
                            "status": m.get("status", ""),
                            "source": "football_data_org",
                        }
                        for m in matches
                    ]
                    sources.append("football-data.org")
            except Exception as exc:
                errors.append(f"football-data.org fallback: {exc}")

        return SportsResponse(
            sport=sport,
            query_type="live_scores",
            data={"scores": scores, "game_count": len(scores)},
            sources=sources,
            errors=errors if not scores else [],
        )

    # ------------------------------------------------------------------
    # Schedule
    # ------------------------------------------------------------------

    def get_schedule(self, sport: str) -> SportsResponse:
        """
        Get today's game schedule.
        Primary: Shipp.ai. Fallback: external match APIs for soccer.
        """
        sources = []
        errors = []
        games = []

        # Try Shipp first
        try:
            games = get_todays_games(sport)
            sources.append("shipp.ai")
        except ShippAPIError as exc:
            errors.append(f"Shipp.ai: {exc.message}")
            logger.warning("Shipp schedule failed for %s: %s", sport, exc)

        # Fallback for soccer
        if not games and sport == "soccer":
            try:
                matches = get_soccer_matches("PL", status="SCHEDULED")
                if matches:
                    games = [
                        {
                            "game_id": str(m.get("match_id", "")),
                            "home_team": m.get("home_team", ""),
                            "away_team": m.get("away_team", ""),
                            "start_time": m.get("start_time", ""),
                            "status": "scheduled",
                            "source": "football_data_org",
                        }
                        for m in matches
                    ]
                    sources.append("football-data.org")
            except Exception as exc:
                errors.append(f"football-data.org fallback: {exc}")

        return SportsResponse(
            sport=sport,
            query_type="schedule",
            data={"games": games, "game_count": len(games)},
            sources=sources,
            errors=errors if not games else [],
        )

    # ------------------------------------------------------------------
    # Play-by-play
    # ------------------------------------------------------------------

    def get_play_by_play(
        self, sport: str, game_id: str, *, since_event_id: Optional[str] = None
    ) -> SportsResponse:
        """
        Get play-by-play events for a specific game. Shipp.ai only.
        """
        sources = []
        errors = []
        events = []

        try:
            events = get_play_by_play(game_id, sport, since_event_id=since_event_id)
            sources.append("shipp.ai")
        except ShippAPIError as exc:
            errors.append(f"Shipp.ai: {exc.message}")
            logger.warning("Shipp play-by-play failed for game %s: %s", game_id, exc)

        return SportsResponse(
            sport=sport,
            query_type="play_by_play",
            data={
                "game_id": game_id,
                "events": events,
                "event_count": len(events),
            },
            sources=sources,
            errors=errors if not events else [],
        )

    # ------------------------------------------------------------------
    # Player stats
    # ------------------------------------------------------------------

    def get_player_stats(self, sport: str, player_name: str, **kwargs) -> SportsResponse:
        """
        Get player statistics. Always uses external sources (Shipp doesn't
        provide historical / aggregate stats).
        """
        sources = []
        errors = []
        stats = None

        if sport == "nba":
            stats = get_nba_player_stats(player_name, **kwargs)
            if stats:
                sources.append("balldontlie")
            else:
                errors.append(f"balldontlie: Player '{player_name}' not found or API unavailable")

        elif sport == "mlb":
            stats = get_mlb_player_stats(player_name, **kwargs)
            if stats:
                sources.append("mlb_stats_api")
            else:
                errors.append(f"MLB Stats API: Player '{player_name}' not found or API unavailable")

        elif sport == "soccer":
            # football-data.org free tier doesn't have detailed player stats
            errors.append(
                "Player stats for soccer are limited on the free tier. "
                "Try team info or standings instead."
            )

        else:
            errors.append(f"Player stats not supported for sport: {sport}")

        return SportsResponse(
            sport=sport,
            query_type="player_stats",
            data={"player": player_name, "stats": stats},
            sources=sources,
            errors=errors if not stats else [],
        )

    # ------------------------------------------------------------------
    # Injuries
    # ------------------------------------------------------------------

    def get_injuries(self, sport: str, *, team: Optional[str] = None) -> SportsResponse:
        """
        Get injury reports. Uses external/public sources.
        """
        sources = []
        errors = []
        injuries = []

        if sport == "nba":
            injuries = get_nba_injuries()
            sources.append("public_feed")
        elif sport == "mlb":
            injuries = get_mlb_injuries()
            sources.append("mlb_stats_api")
        elif sport == "soccer":
            errors.append("Injury data is not available for soccer through current sources.")
        else:
            errors.append(f"Injury reports not supported for sport: {sport}")

        # Filter by team if requested
        if team and injuries:
            team_lower = team.strip().lower()
            injuries = [
                inj for inj in injuries
                if team_lower in (inj.get("team", "") or "").lower()
            ]

        return SportsResponse(
            sport=sport,
            query_type="injuries",
            data={"injuries": injuries, "injury_count": len(injuries)},
            sources=sources,
            errors=errors if not injuries else [],
        )

    # ------------------------------------------------------------------
    # Standings
    # ------------------------------------------------------------------

    def get_standings(self, sport: str, *, league: str = "premier_league") -> SportsResponse:
        """
        Get league standings / table. Currently supported for soccer only.
        """
        sources = []
        errors = []
        standings = None

        if sport == "soccer":
            standings = get_soccer_standings(league)
            if standings:
                sources.append("football-data.org")
            else:
                errors.append("football-data.org: Standings unavailable")
        else:
            errors.append(
                f"Standings queries for {sport} are not yet supported. "
                f"Try 'soccer' with a league parameter."
            )

        return SportsResponse(
            sport=sport,
            query_type="standings",
            data=standings or {},
            sources=sources,
            errors=errors if not standings else [],
        )

    # ------------------------------------------------------------------
    # Roster
    # ------------------------------------------------------------------

    def get_roster(self, sport: str, team: str, **kwargs) -> SportsResponse:
        """
        Get team roster. Currently supported for MLB and soccer.
        """
        sources = []
        errors = []
        roster = None

        if sport == "mlb":
            roster = get_mlb_roster(team, **kwargs)
            if roster:
                sources.append("mlb_stats_api")
            else:
                errors.append(f"MLB Stats API: Roster for '{team}' not found")

        elif sport == "soccer":
            team_data = get_soccer_team(team)
            if team_data:
                roster = {
                    "team": team_data.get("name", team),
                    "coach": team_data.get("coach", ""),
                    "players": team_data.get("squad", []),
                    "player_count": len(team_data.get("squad", [])),
                }
                sources.append("football-data.org")
            else:
                errors.append(f"football-data.org: Team '{team}' not found")

        elif sport == "nba":
            errors.append(
                "NBA rosters are not available through current external sources. "
                "Try player stats instead."
            )
        else:
            errors.append(f"Roster query not supported for sport: {sport}")

        return SportsResponse(
            sport=sport,
            query_type="roster",
            data=roster or {},
            sources=sources,
            errors=errors if not roster else [],
        )

    # ------------------------------------------------------------------
    # Unified query router
    # ------------------------------------------------------------------

    def query(self, sport: str, query_type: str, **kwargs) -> SportsResponse:
        """
        Route a query to the appropriate handler.

        Parameters
        ----------
        sport : str
            "nba", "mlb", or "soccer".
        query_type : str
            One of: "scores", "schedule", "play_by_play", "player_stats",
            "injuries", "standings", "roster".
        **kwargs
            Additional parameters passed to the handler.
        """
        handlers = {
            "scores": self.get_scores,
            "live_scores": self.get_scores,
            "schedule": self.get_schedule,
            "games": self.get_schedule,
            "play_by_play": lambda s: self.get_play_by_play(s, kwargs.pop("game_id", ""), **kwargs),
            "pbp": lambda s: self.get_play_by_play(s, kwargs.pop("game_id", ""), **kwargs),
            "player_stats": lambda s: self.get_player_stats(s, kwargs.pop("player_name", ""), **kwargs),
            "stats": lambda s: self.get_player_stats(s, kwargs.pop("player_name", ""), **kwargs),
            "injuries": lambda s: self.get_injuries(s, **kwargs),
            "standings": lambda s: self.get_standings(s, **kwargs),
            "table": lambda s: self.get_standings(s, **kwargs),
            "roster": lambda s: self.get_roster(s, kwargs.pop("team", ""), **kwargs),
        }

        handler = handlers.get(query_type.lower())
        if not handler:
            return SportsResponse(
                sport=sport,
                query_type=query_type,
                errors=[
                    f"Unknown query type '{query_type}'. "
                    f"Supported: {', '.join(sorted(handlers.keys()))}"
                ],
            )

        try:
            return handler(sport)
        except Exception as exc:
            logger.exception("Unhandled error in query(%s, %s)", sport, query_type)
            return SportsResponse(
                sport=sport,
                query_type=query_type,
                errors=[f"Unexpected error: {exc}"],
            )


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

# Singleton for simple usage
_default_instance: Optional[ShippSports] = None


def get_client() -> ShippSports:
    """Get or create the default ShippSports client."""
    global _default_instance
    if _default_instance is None:
        _default_instance = ShippSports()
    return _default_instance


# Convenience functions that use the default client

def scores(sport: str) -> dict:
    """Get live scores. Returns dict."""
    return get_client().get_scores(sport).to_dict()


def schedule(sport: str) -> dict:
    """Get today's schedule. Returns dict."""
    return get_client().get_schedule(sport).to_dict()


def player_stats(sport: str, player_name: str, **kwargs) -> dict:
    """Get player stats. Returns dict."""
    return get_client().get_player_stats(sport, player_name, **kwargs).to_dict()


def injuries(sport: str, **kwargs) -> dict:
    """Get injury reports. Returns dict."""
    return get_client().get_injuries(sport, **kwargs).to_dict()


def standings(sport: str, **kwargs) -> dict:
    """Get standings. Returns dict."""
    return get_client().get_standings(sport, **kwargs).to_dict()


def play_by_play(sport: str, game_id: str, **kwargs) -> dict:
    """Get play-by-play. Returns dict."""
    return get_client().get_play_by_play(sport, game_id, **kwargs).to_dict()


# ---------------------------------------------------------------------------
# CLI demo
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import json
    logging.basicConfig(level=logging.INFO)

    ss = ShippSports()

    print("=" * 60)
    print("SHIPP SPORTS UNIFIED WRAPPER — DEMO")
    print("=" * 60)

    # NBA live scores
    print("\n--- NBA Live Scores ---")
    result = ss.get_scores("nba")
    print(json.dumps(result.to_dict(), indent=2, default=str))

    # NBA player stats
    print("\n--- NBA Player Stats (LeBron James) ---")
    result = ss.get_player_stats("nba", "LeBron James")
    print(json.dumps(result.to_dict(), indent=2, default=str))

    # MLB schedule
    print("\n--- MLB Schedule ---")
    result = ss.get_schedule("mlb")
    print(json.dumps(result.to_dict(), indent=2, default=str))

    # Premier League standings
    print("\n--- Premier League Standings ---")
    result = ss.get_standings("soccer", league="premier_league")
    print(json.dumps(result.to_dict(), indent=2, default=str))
