"""
shipp-sports: Real-time sports data for NBA, MLB, and Soccer via Shipp.ai.
"""

from .shipp_wrapper import ShippSports, SportsResponse
from .sports_data import (
    create_connection,
    get_todays_games,
    get_live_scores,
    get_play_by_play,
    ShippAPIError,
    ShippAuthError,
    ShippPaymentError,
    ShippRateLimitError,
)

__version__ = "0.1.0"
__all__ = [
    "ShippSports",
    "SportsResponse",
    "create_connection",
    "get_todays_games",
    "get_live_scores",
    "get_play_by_play",
    "ShippAPIError",
    "ShippAuthError",
    "ShippPaymentError",
    "ShippRateLimitError",
]
