"""
External Sports Data Sources
==============================
Integrations with free / public APIs to enrich Shipp.ai live data with
player statistics, injury reports, rosters, and league standings.

Sources:
    - balldontlie API  — NBA player stats (no key required)
    - MLB Stats API    — MLB rosters, player stats (no key required)
    - football-data.org — Soccer standings, team data (free tier, key required)
    - Public feeds     — Injury reports for NBA and MLB

All functions include proper error handling and rate-limit awareness.
"""

import os
import time
import logging
from typing import Optional

import requests

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

BALLDONTLIE_BASE = "https://api.balldontlie.io/v1"
MLB_STATS_BASE = "https://statsapi.mlb.com/api/v1"
FOOTBALL_DATA_BASE = "https://api.football-data.org/v4"

# Rate limit tracking (simple in-memory)
_rate_limit_state: dict[str, float] = {}

REQUEST_TIMEOUT = 15  # seconds


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _rate_limit_wait(source: str, min_interval: float) -> None:
    """
    Enforce a minimum interval between requests to the same source.
    balldontlie: 30 req/min => 2s minimum
    football-data.org free: 10 req/min => 6s minimum
    MLB Stats API: no strict limit, use 0.5s courtesy
    """
    last = _rate_limit_state.get(source, 0.0)
    elapsed = time.time() - last
    if elapsed < min_interval:
        sleep_time = min_interval - elapsed
        logger.debug("Rate limit wait %.1fs for %s", sleep_time, source)
        time.sleep(sleep_time)
    _rate_limit_state[source] = time.time()


def _safe_get(url: str, *, headers: Optional[dict] = None, params: Optional[dict] = None,
              source: str = "unknown") -> Optional[dict]:
    """
    Perform a GET request with error handling. Returns parsed JSON or None.
    """
    try:
        resp = requests.get(url, headers=headers or {}, params=params or {}, timeout=REQUEST_TIMEOUT)

        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After", "60")
            logger.warning("%s rate limited. Retry-After: %s", source, retry_after)
            return None

        if resp.status_code == 403:
            logger.warning("%s returned 403 Forbidden — check API key or permissions", source)
            return None

        if resp.status_code == 404:
            logger.info("%s returned 404 — resource not found", source)
            return None

        if resp.status_code >= 400:
            logger.warning("%s returned %d: %s", source, resp.status_code, resp.text[:300])
            return None

        return resp.json()
    except requests.exceptions.ConnectionError:
        logger.error("Connection error reaching %s at %s", source, url)
        return None
    except requests.exceptions.Timeout:
        logger.error("Timeout reaching %s at %s", source, url)
        return None
    except (ValueError, requests.exceptions.JSONDecodeError):
        logger.error("Invalid JSON from %s at %s", source, url)
        return None


# ===========================================================================
# NBA — balldontlie API
# ===========================================================================


def get_nba_player_stats(player_name: str, *, season: int = 2025) -> Optional[dict]:
    """
    Get NBA player season averages from the balldontlie API.

    Parameters
    ----------
    player_name : str
        Full or partial player name (e.g., "LeBron James", "LeBron").
    season : int
        The season year (e.g., 2025 for the 2025-26 season).

    Returns
    -------
    dict or None
        Player info and season averages, or None on error. Keys include:
        player_id, name, team, position, games_played, pts, reb, ast, stl,
        blk, fg_pct, ft_pct, three_pct, min.
    """
    _rate_limit_wait("balldontlie", 2.0)

    # Step 1: Search for the player
    search_url = f"{BALLDONTLIE_BASE}/players"
    data = _safe_get(search_url, params={"search": player_name}, source="balldontlie")
    if not data:
        return None

    players = data.get("data", [])
    if not players:
        logger.info("No NBA player found matching '%s'", player_name)
        return None

    # Take best match (first result)
    player = players[0]
    player_id = player.get("id")
    if not player_id:
        return None

    first_name = player.get("first_name", "")
    last_name = player.get("last_name", "")
    team_data = player.get("team", {})

    # Step 2: Fetch season averages
    _rate_limit_wait("balldontlie", 2.0)
    avg_url = f"{BALLDONTLIE_BASE}/season_averages"
    avg_data = _safe_get(
        avg_url,
        params={"season": season, "player_ids[]": player_id},
        source="balldontlie",
    )

    averages = {}
    if avg_data:
        avg_list = avg_data.get("data", [])
        if avg_list:
            averages = avg_list[0]

    return {
        "player_id": player_id,
        "name": f"{first_name} {last_name}".strip(),
        "team": team_data.get("full_name", team_data.get("name", "")),
        "position": player.get("position", ""),
        "games_played": averages.get("games_played", 0),
        "pts": averages.get("pts", 0.0),
        "reb": averages.get("reb", 0.0),
        "ast": averages.get("ast", 0.0),
        "stl": averages.get("stl", 0.0),
        "blk": averages.get("blk", 0.0),
        "fg_pct": averages.get("fg_pct", 0.0),
        "ft_pct": averages.get("ft_pct", 0.0),
        "three_pct": averages.get("fg3_pct", 0.0),
        "min": averages.get("min", "0:00"),
        "turnover": averages.get("turnover", 0.0),
        "source": "balldontlie",
    }


def get_nba_injuries() -> list[dict]:
    """
    Get current NBA injury reports from public sources.

    Returns a list of dicts with: player, team, status, injury, update_date.
    Falls back to an empty list if the source is unavailable.
    """
    # CBS Sports NBA injury report (public HTML — we parse a known JSON endpoint)
    # In production, you'd use a more reliable feed. This demonstrates the pattern.
    url = "https://www.cbssports.com/nba/injuries/api"

    _rate_limit_wait("nba_injuries", 5.0)
    data = _safe_get(url, source="nba_injuries")

    if not data:
        # Fallback: try an alternative public source
        alt_url = "https://www.rotowire.com/basketball/tables/injury-report.php?pos=ALL&conf=ALL"
        logger.info("Primary NBA injury source unavailable, trying alternative")
        # In practice this returns HTML; we'd parse it. For the skill, return empty.
        return _get_nba_injuries_fallback()

    injuries = []
    for entry in data if isinstance(data, list) else data.get("injuries", []):
        if not isinstance(entry, dict):
            continue
        injuries.append({
            "player": entry.get("player", entry.get("name", "")),
            "team": entry.get("team", ""),
            "status": entry.get("status", entry.get("designation", "")),
            "injury": entry.get("injury", entry.get("description", "")),
            "update_date": entry.get("date", entry.get("updated", "")),
            "source": "public_feed",
        })

    return injuries


def _get_nba_injuries_fallback() -> list[dict]:
    """
    Fallback injury source. In production, scrape or use another API.
    Returns empty list as a safe default.
    """
    logger.warning("NBA injury data unavailable from all sources")
    return []


# ===========================================================================
# MLB — Stats API (statsapi.mlb.com)
# ===========================================================================

# Common MLB team name -> ID mapping for convenience
MLB_TEAM_IDS = {
    "yankees": 147, "red sox": 111, "dodgers": 119, "mets": 121,
    "cubs": 112, "white sox": 145, "braves": 144, "astros": 117,
    "phillies": 143, "padres": 135, "giants": 137, "cardinals": 138,
    "brewers": 158, "guardians": 114, "mariners": 136, "orioles": 110,
    "rays": 139, "blue jays": 141, "twins": 142, "rangers": 140,
    "angels": 108, "athletics": 133, "tigers": 116, "royals": 118,
    "reds": 113, "pirates": 134, "marlins": 146, "nationals": 120,
    "rockies": 115, "diamondbacks": 109,
}


def _resolve_mlb_team_id(team_name: str) -> Optional[int]:
    """Resolve a team name (or partial) to an MLB team ID."""
    team_lower = team_name.strip().lower()

    # Direct match
    if team_lower in MLB_TEAM_IDS:
        return MLB_TEAM_IDS[team_lower]

    # Partial match
    for name, tid in MLB_TEAM_IDS.items():
        if team_lower in name or name in team_lower:
            return tid

    # Try the API search
    _rate_limit_wait("mlb_stats", 0.5)
    url = f"{MLB_STATS_BASE}/teams"
    data = _safe_get(url, params={"sportId": 1, "season": 2026}, source="mlb_stats")
    if data:
        for team in data.get("teams", []):
            full_name = (team.get("name", "") or "").lower()
            short_name = (team.get("teamName", "") or "").lower()
            if team_lower in full_name or team_lower in short_name:
                return team.get("id")

    return None


def get_mlb_roster(team_name: str, *, roster_type: str = "40Man") -> Optional[dict]:
    """
    Get the current roster for an MLB team.

    Parameters
    ----------
    team_name : str
        Team name, e.g., "Yankees", "Dodgers", "Red Sox".
    roster_type : str
        Roster type: "40Man", "active", "depthChart".

    Returns
    -------
    dict or None
        Keys: team, roster_type, players (list of dicts with name, position,
        number, status).
    """
    team_id = _resolve_mlb_team_id(team_name)
    if not team_id:
        logger.info("Could not resolve MLB team: '%s'", team_name)
        return None

    _rate_limit_wait("mlb_stats", 0.5)
    url = f"{MLB_STATS_BASE}/teams/{team_id}/roster"
    data = _safe_get(url, params={"rosterType": roster_type}, source="mlb_stats")
    if not data:
        return None

    roster_entries = data.get("roster", [])
    players = []
    for entry in roster_entries:
        if not isinstance(entry, dict):
            continue
        person = entry.get("person", {})
        position = entry.get("position", {})
        players.append({
            "name": person.get("fullName", ""),
            "player_id": person.get("id"),
            "position": position.get("abbreviation", position.get("name", "")),
            "jersey_number": entry.get("jerseyNumber", ""),
            "status": entry.get("status", {}).get("description", "Active"),
        })

    return {
        "team": team_name,
        "team_id": team_id,
        "roster_type": roster_type,
        "players": players,
        "player_count": len(players),
        "source": "mlb_stats_api",
    }


def get_mlb_player_stats(player_name: str, *, season: int = 2025) -> Optional[dict]:
    """
    Search for an MLB player and return their season stats.

    Parameters
    ----------
    player_name : str
        Full or partial name.
    season : int
        Stats season year.

    Returns
    -------
    dict or None
        Player info and stats, or None if not found.
    """
    _rate_limit_wait("mlb_stats", 0.5)

    # Search for the player
    url = f"{MLB_STATS_BASE}/people/search"
    data = _safe_get(url, params={"names": player_name, "sportId": 1}, source="mlb_stats")
    if not data:
        return None

    people = data.get("people", data.get("searchResults", {}).get("results", []))
    if not people:
        # Try alternative endpoint
        _rate_limit_wait("mlb_stats", 0.5)
        alt_url = f"{MLB_STATS_BASE}/people/search"
        alt_data = _safe_get(alt_url, params={"search": player_name}, source="mlb_stats")
        if alt_data:
            people = alt_data.get("people", [])
        if not people:
            logger.info("No MLB player found matching '%s'", player_name)
            return None

    player = people[0] if isinstance(people, list) else people
    player_id = player.get("id") or player.get("playerId")
    if not player_id:
        return None

    # Get season stats
    _rate_limit_wait("mlb_stats", 0.5)
    stats_url = f"{MLB_STATS_BASE}/people/{player_id}"
    stats_data = _safe_get(
        stats_url,
        params={"hydrate": f"stats(group=[hitting,pitching],type=season,season={season})"},
        source="mlb_stats",
    )
    if not stats_data:
        return {
            "player_id": player_id,
            "name": player.get("fullName", player.get("name", "")),
            "position": player.get("primaryPosition", {}).get("abbreviation", ""),
            "team": player.get("currentTeam", {}).get("name", ""),
            "stats": {},
            "source": "mlb_stats_api",
        }

    person = stats_data.get("people", [{}])[0] if stats_data.get("people") else {}
    stats_groups = person.get("stats", [])

    compiled_stats = {}
    for group in stats_groups:
        if not isinstance(group, dict):
            continue
        group_name = group.get("group", {}).get("displayName", "unknown")
        splits = group.get("splits", [])
        if splits:
            compiled_stats[group_name] = splits[0].get("stat", {})

    return {
        "player_id": player_id,
        "name": person.get("fullName") or player.get("fullName", ""),
        "position": person.get("primaryPosition", {}).get("abbreviation", ""),
        "team": person.get("currentTeam", {}).get("name", ""),
        "bats": person.get("batSide", {}).get("code", ""),
        "throws": person.get("pitchHand", {}).get("code", ""),
        "season": season,
        "stats": compiled_stats,
        "source": "mlb_stats_api",
    }


def get_mlb_injuries() -> list[dict]:
    """
    Get current MLB injury list (IL) from public sources.

    Returns a list of dicts: player, team, status, injury, update_date.
    """
    # MLB Stats API doesn't have a direct injuries endpoint publicly,
    # so we check each team's IL status via roster.
    # For production, a dedicated injury feed would be better.
    _rate_limit_wait("mlb_stats", 0.5)

    url = f"{MLB_STATS_BASE}/injuries"
    data = _safe_get(url, params={"sportId": 1}, source="mlb_stats")

    if not data:
        # Fallback: query a public injuries feed
        logger.info("MLB injuries endpoint unavailable, using fallback")
        return _get_mlb_injuries_fallback()

    injuries = []
    for entry in data if isinstance(data, list) else data.get("injuries", data.get("data", [])):
        if not isinstance(entry, dict):
            continue
        player_info = entry.get("player", entry.get("person", {}))
        team_info = entry.get("team", {})
        injuries.append({
            "player": player_info.get("fullName", player_info.get("name", "")),
            "player_id": player_info.get("id"),
            "team": team_info.get("name", ""),
            "status": entry.get("status", entry.get("designation", "")),
            "injury": entry.get("notes", entry.get("description", "")),
            "update_date": entry.get("date", entry.get("lastUpdate", "")),
            "source": "mlb_stats_api",
        })

    return injuries


def _get_mlb_injuries_fallback() -> list[dict]:
    """Fallback for MLB injuries. Returns empty list as safe default."""
    logger.warning("MLB injury data unavailable from all sources")
    return []


# ===========================================================================
# Soccer — football-data.org
# ===========================================================================

# Competition codes for common leagues
SOCCER_COMPETITIONS = {
    "premier_league": "PL",
    "premier league": "PL",
    "epl": "PL",
    "pl": "PL",
    "la_liga": "PD",
    "la liga": "PD",
    "laliga": "PD",
    "champions_league": "CL",
    "champions league": "CL",
    "ucl": "CL",
    "cl": "CL",
    "bundesliga": "BL1",
    "serie_a": "SA",
    "serie a": "SA",
    "ligue_1": "FL1",
    "ligue 1": "FL1",
}


def _football_data_headers() -> dict:
    """Build headers for football-data.org requests."""
    key = os.environ.get("FOOTBALL_DATA_API_KEY", "").strip()
    headers = {"Accept": "application/json"}
    if key:
        headers["X-Auth-Token"] = key
    else:
        logger.warning(
            "FOOTBALL_DATA_API_KEY not set. Requests may be heavily rate-limited. "
            "Get a free key at https://www.football-data.org/client/register"
        )
    return headers


def _resolve_competition_code(league: str) -> str:
    """Resolve a league name to a football-data.org competition code."""
    league_lower = league.strip().lower()
    code = SOCCER_COMPETITIONS.get(league_lower)
    if code:
        return code

    # Fuzzy match
    for name, c in SOCCER_COMPETITIONS.items():
        if league_lower in name or name in league_lower:
            return c

    # Default to Premier League if unrecognized
    logger.info("Unrecognized league '%s', defaulting to Premier League", league)
    return "PL"


def get_soccer_standings(league: str = "premier_league") -> Optional[dict]:
    """
    Get current league standings/table.

    Parameters
    ----------
    league : str
        League name or code: "premier_league", "la_liga", "champions_league",
        "bundesliga", "serie_a", "ligue_1", or short codes like "PL", "CL".

    Returns
    -------
    dict or None
        Keys: league, season, standings (list of dicts with position, team,
        played, won, draw, lost, points, goals_for, goals_against, goal_diff).
    """
    code = _resolve_competition_code(league)
    _rate_limit_wait("football_data", 6.0)

    url = f"{FOOTBALL_DATA_BASE}/competitions/{code}/standings"
    data = _safe_get(url, headers=_football_data_headers(), source="football_data")
    if not data:
        return None

    competition = data.get("competition", {})
    season_info = data.get("season", {})
    standings_groups = data.get("standings", [])

    # Usually the first standings group is "TOTAL"
    table = []
    for group in standings_groups:
        if not isinstance(group, dict):
            continue
        if group.get("type", "TOTAL") != "TOTAL":
            continue

        for entry in group.get("table", []):
            if not isinstance(entry, dict):
                continue
            team = entry.get("team", {})
            table.append({
                "position": entry.get("position", 0),
                "team": team.get("name", team.get("shortName", "")),
                "team_id": team.get("id"),
                "crest": team.get("crest", ""),
                "played": entry.get("playedGames", 0),
                "won": entry.get("won", 0),
                "draw": entry.get("draw", 0),
                "lost": entry.get("lost", 0),
                "points": entry.get("points", 0),
                "goals_for": entry.get("goalsFor", 0),
                "goals_against": entry.get("goalsAgainst", 0),
                "goal_diff": entry.get("goalDifference", 0),
                "form": entry.get("form", ""),
            })

        break  # Only need TOTAL standings

    return {
        "league": competition.get("name", league),
        "league_code": code,
        "season": season_info.get("currentMatchday", ""),
        "start_date": season_info.get("startDate", ""),
        "end_date": season_info.get("endDate", ""),
        "standings": table,
        "source": "football_data_org",
    }


def get_soccer_team(team_name: str, *, league: str = "PL") -> Optional[dict]:
    """
    Get information about a soccer team.

    Parameters
    ----------
    team_name : str
        Team name to search for.
    league : str
        Competition code to search within.

    Returns
    -------
    dict or None
        Team info: name, id, venue, coach, squad, league.
    """
    code = _resolve_competition_code(league)
    _rate_limit_wait("football_data", 6.0)

    url = f"{FOOTBALL_DATA_BASE}/competitions/{code}/teams"
    data = _safe_get(url, headers=_football_data_headers(), source="football_data")
    if not data:
        return None

    teams = data.get("teams", [])
    team_lower = team_name.strip().lower()

    matched_team = None
    for t in teams:
        if not isinstance(t, dict):
            continue
        name = (t.get("name") or "").lower()
        short = (t.get("shortName") or "").lower()
        tla = (t.get("tla") or "").lower()
        if team_lower in name or team_lower in short or team_lower == tla:
            matched_team = t
            break

    if not matched_team:
        logger.info("No soccer team found matching '%s' in %s", team_name, code)
        return None

    coach = matched_team.get("coach", {})
    squad = []
    for player in matched_team.get("squad", []):
        if not isinstance(player, dict):
            continue
        squad.append({
            "name": player.get("name", ""),
            "position": player.get("position", ""),
            "nationality": player.get("nationality", ""),
        })

    return {
        "name": matched_team.get("name", ""),
        "short_name": matched_team.get("shortName", ""),
        "tla": matched_team.get("tla", ""),
        "team_id": matched_team.get("id"),
        "venue": matched_team.get("venue", ""),
        "crest": matched_team.get("crest", ""),
        "coach": coach.get("name", ""),
        "squad": squad,
        "league": code,
        "source": "football_data_org",
    }


def get_soccer_matches(league: str = "premier_league", *, status: str = "SCHEDULED") -> Optional[list]:
    """
    Get upcoming or live matches for a competition.

    Parameters
    ----------
    league : str
        League name or code.
    status : str
        Match status filter: "SCHEDULED", "LIVE", "IN_PLAY", "FINISHED".

    Returns
    -------
    list[dict] or None
        Match info.
    """
    code = _resolve_competition_code(league)
    _rate_limit_wait("football_data", 6.0)

    url = f"{FOOTBALL_DATA_BASE}/competitions/{code}/matches"
    params = {"status": status}
    data = _safe_get(url, headers=_football_data_headers(), params=params, source="football_data")
    if not data:
        return None

    matches = []
    for m in data.get("matches", []):
        if not isinstance(m, dict):
            continue
        home = m.get("homeTeam", {})
        away = m.get("awayTeam", {})
        score = m.get("score", {})
        ft = score.get("fullTime", {})

        matches.append({
            "match_id": m.get("id"),
            "home_team": home.get("name", home.get("shortName", "")),
            "away_team": away.get("name", away.get("shortName", "")),
            "start_time": m.get("utcDate", ""),
            "status": m.get("status", ""),
            "matchday": m.get("matchday"),
            "home_score": ft.get("home"),
            "away_score": ft.get("away"),
            "venue": m.get("venue", ""),
            "source": "football_data_org",
        })

    return matches


# ---------------------------------------------------------------------------
# Module-level test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    print("=== NBA Player Stats (LeBron James) ===")
    stats = get_nba_player_stats("LeBron James")
    if stats:
        print(f"  {stats['name']} ({stats['team']}) — {stats['position']}")
        print(f"  PPG: {stats['pts']}  RPG: {stats['reb']}  APG: {stats['ast']}")
    else:
        print("  Could not fetch stats")

    print("\n=== MLB Roster (Yankees) ===")
    roster = get_mlb_roster("Yankees")
    if roster:
        print(f"  {roster['team']} — {roster['player_count']} players on {roster['roster_type']}")
        for p in roster["players"][:5]:
            print(f"    #{p['jersey_number']} {p['name']} ({p['position']})")
    else:
        print("  Could not fetch roster")

    print("\n=== Premier League Standings ===")
    standings = get_soccer_standings("premier_league")
    if standings:
        print(f"  {standings['league']} — Matchday {standings['season']}")
        for row in standings["standings"][:5]:
            print(f"    {row['position']}. {row['team']}  {row['points']} pts  ({row['won']}W-{row['draw']}D-{row['lost']}L)")
    else:
        print("  Could not fetch standings")
