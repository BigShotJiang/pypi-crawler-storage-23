"""
shipp-sports scripts package.
"""
