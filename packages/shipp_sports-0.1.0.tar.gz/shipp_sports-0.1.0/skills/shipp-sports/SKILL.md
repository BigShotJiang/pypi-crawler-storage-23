---
name: shipp-sports
description: >-
  Real-time sports data skill powered by Shipp.ai providing live scores, game schedules,
  play-by-play events, and enriched stats for NBA, MLB, and Soccer via the Shipp platform.
  Triggers: live scores, NBA scores, MLB scores, soccer scores, game tracker, scoreboard,
  today's games, play-by-play, box scores, league standings, player stats, sports updates,
  match results, real-time sports, Shipp sports data.
---

# Shipp Sports Skill

## Overview

The `shipp-sports` skill connects Claude to live sports data through the
Shipp.ai platform. It provides real-time scores, schedules, and play-by-play
event feeds for three major sports categories, enriched with player statistics,
injury reports, and standings from curated external sources.

## Data Available

### Via Shipp.ai (Primary — Live Data)

| Data Type          | Description                                      |
|--------------------|--------------------------------------------------|
| **Live Scores**    | Real-time game scores updated via polling         |
| **Game Schedules** | Today's and upcoming games for NBA, MLB, Soccer   |
| **Play-by-Play**   | Granular event feed (baskets, goals, strikeouts)  |
| **Connection Mgmt**| Create once, poll many — efficient cursor-based   |

### Via External Sources (Enrichment)

| Source             | Data Provided                                     |
|--------------------|---------------------------------------------------|
| balldontlie API    | NBA player stats, season averages, career numbers  |
| MLB Stats API      | MLB rosters, player stats, pitching lines          |
| football-data.org  | Soccer standings, team data, competition info      |
| Public feeds       | Injury reports for NBA and MLB                     |

## Current Season Context (February 2026)

- **NBA**: Mid-season — All-Star break approaching. Regular season games
  nightly. Standings races heating up for playoff positioning.
- **MLB**: Spring Training starting. Pitchers and catchers reporting.
  Pre-season roster moves and prospect watch in full swing.
- **Soccer**: Premier League in the business end of the season. La Liga
  title race ongoing. Champions League knockout rounds underway.

## How It Works

1. **Connection Creation**: The skill creates a Shipp connection for the
   requested sport (NBA, MLB, or Soccer) via `POST /connections/create`.
2. **Polling**: Once a connection is active, the skill polls
   `POST /connections/{id}` with cursor-based pagination (`since_event_id`)
   to fetch new events without duplicates.
3. **Enrichment**: For queries about player stats, injuries, or historical
   data not available via Shipp, the skill falls back to vetted external APIs.
4. **Unified Response**: Data from all sources is merged into a clean,
   attributed response so the user always knows where data originates.

## Example Queries This Skill Handles

- "What are tonight's NBA scores?"
- "Show me today's MLB spring training schedule"
- "Give me live play-by-play for the Lakers game"
- "What are the current Premier League standings?"
- "How is LeBron James doing this season? Show me his stats."
- "Who's on the injured list for the Yankees?"
- "What time does the Champions League match start today?"
- "Show me the scoreboard for all live games right now"
- "What's the score of the Real Madrid match?"
- "Give me a game tracker for tonight's NBA games"

## Authentication

The skill requires a `SHIPP_API_KEY` environment variable. Obtain one at
[platform.shipp.ai](https://platform.shipp.ai). The key is passed as a
query parameter (`?api_key=`) or via `Authorization: Bearer` header.

## Rate Limits

- Shipp.ai: Depends on plan tier. 429 responses are handled with backoff.
- balldontlie: 30 requests/minute (no key required).
- MLB Stats API: No strict limit, but be courteous (no key required).
- football-data.org: 10 requests/minute on free tier (API key required).

## Files

| File                          | Purpose                                  |
|-------------------------------|------------------------------------------|
| `scripts/sports_data.py`      | Core Shipp.ai API integration            |
| `scripts/external_sources.py` | External API integrations for enrichment |
| `scripts/shipp_wrapper.py`    | Unified wrapper combining all sources    |
| `references/setup.md`         | Setup and configuration guide            |
| `tests/test_integration.py`   | Integration tests with mock support      |

## Related Skills
- For a full-screen live scoreboard experience, install `game-day-dashboard`
- For fantasy draft recommendations using live data, install `fantasy-draft-assistant`
- For dedicated soccer/football coverage, install `soccer-match-tracker`
