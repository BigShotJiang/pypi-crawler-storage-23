"""
Integration Tests — shipp-sports Skill
========================================
Tests verify core functionality with mock-friendly patterns. All external
HTTP calls are mocked so tests can run without API keys or network access.

Run:
    cd skills/branded/shipp-sports
    python -m pytest tests/test_integration.py -v

Or:
    python -m pytest tests/ -v
"""

import os
import json
import pytest
from unittest.mock import patch, MagicMock

# Ensure SHIPP_API_KEY is set for module imports (tests mock actual calls)
os.environ.setdefault("SHIPP_API_KEY", "shipp_test_mock_key_for_tests")

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.sports_data import (
    create_connection,
    poll_connection,
    poll_all_events,
    get_todays_games,
    get_live_scores,
    get_play_by_play,
    list_connections,
    ShippAPIError,
    ShippAuthError,
    ShippPaymentError,
    ShippRateLimitError,
    _connection_cache,
)
from scripts.external_sources import (
    get_nba_player_stats,
    get_nba_injuries,
    get_mlb_roster,
    get_mlb_player_stats,
    get_mlb_injuries,
    get_soccer_standings,
    get_soccer_team,
)
from scripts.shipp_wrapper import ShippSports, SportsResponse


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def clear_connection_cache():
    """Clear the connection cache before each test."""
    _connection_cache.clear()
    yield
    _connection_cache.clear()


def _mock_response(status_code=200, json_data=None, text="", headers=None):
    """Create a mock requests.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.text = text or json.dumps(json_data or {})
    resp.reason = "OK" if status_code < 400 else "Error"
    resp.headers = headers or {}
    resp.json.return_value = json_data or {}
    return resp


# ===========================================================================
# Shipp.ai — Connection Tests
# ===========================================================================


class TestConnectionCreation:
    """Test connection creation via Shipp API."""

    @patch("scripts.sports_data.requests.request")
    def test_create_connection_returns_id(self, mock_request):
        """Connection creation should return a valid connection_id."""
        mock_request.return_value = _mock_response(
            200, {"connection_id": "conn_abc123", "status": "active"}
        )

        conn_id = create_connection("nba")
        assert conn_id == "conn_abc123"
        assert mock_request.called

    @patch("scripts.sports_data.requests.request")
    def test_create_connection_caches_id(self, mock_request):
        """Second call for same sport should use cached connection_id."""
        mock_request.return_value = _mock_response(
            200, {"connection_id": "conn_abc123"}
        )

        conn1 = create_connection("nba")
        conn2 = create_connection("nba")

        assert conn1 == conn2
        # Should only have called the API once
        assert mock_request.call_count == 1

    @patch("scripts.sports_data.requests.request")
    def test_create_connection_force_new(self, mock_request):
        """force_new=True should create a new connection even if cached."""
        mock_request.side_effect = [
            _mock_response(200, {"connection_id": "conn_first"}),
            _mock_response(200, {"connection_id": "conn_second"}),
        ]

        conn1 = create_connection("nba")
        conn2 = create_connection("nba", force_new=True)

        assert conn1 == "conn_first"
        assert conn2 == "conn_second"
        assert mock_request.call_count == 2

    def test_create_connection_invalid_sport(self):
        """Invalid sport should raise ValueError."""
        with pytest.raises(ValueError, match="Invalid sport"):
            create_connection("hockey")

    @patch("scripts.sports_data.requests.request")
    def test_create_connection_alternate_id_field(self, mock_request):
        """API might return 'id' instead of 'connection_id'."""
        mock_request.return_value = _mock_response(
            200, {"id": "conn_alt_456"}
        )

        conn_id = create_connection("mlb")
        assert conn_id == "conn_alt_456"


class TestListConnections:
    """Test listing active connections."""

    @patch("scripts.sports_data.requests.request")
    def test_list_connections_returns_list(self, mock_request):
        """Should return a list of connection dicts."""
        mock_request.return_value = _mock_response(200, {
            "connections": [
                {"id": "conn_1", "sport": "nba", "status": "active"},
                {"id": "conn_2", "sport": "mlb", "status": "active"},
            ]
        })

        result = list_connections()
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["sport"] == "nba"


# ===========================================================================
# Shipp.ai — Polling Tests
# ===========================================================================


class TestPolling:
    """Test event polling with cursor-based pagination."""

    @patch("scripts.sports_data.requests.request")
    def test_poll_returns_events(self, mock_request):
        """Polling should return events array."""
        mock_request.return_value = _mock_response(200, {
            "events": [
                {"event_id": "evt_1", "game_id": "g1", "type": "score_update"},
                {"event_id": "evt_2", "game_id": "g1", "type": "period_end"},
            ],
            "last_event_id": "evt_2",
            "has_more": False,
        })

        result = poll_connection("conn_abc123")
        assert "events" in result
        assert len(result["events"]) == 2
        assert result["last_event_id"] == "evt_2"
        assert result["has_more"] is False

    @patch("scripts.sports_data.requests.request")
    def test_poll_with_cursor(self, mock_request):
        """Polling with since_event_id should pass it in the request."""
        mock_request.return_value = _mock_response(200, {
            "events": [{"event_id": "evt_3"}],
            "last_event_id": "evt_3",
            "has_more": False,
        })

        poll_connection("conn_abc123", since_event_id="evt_2")

        call_kwargs = mock_request.call_args
        body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json", {})
        assert body.get("since_event_id") == "evt_2"

    @patch("scripts.sports_data.requests.request")
    def test_poll_all_events_paginates(self, mock_request):
        """poll_all_events should follow has_more pagination."""
        mock_request.side_effect = [
            _mock_response(200, {
                "events": [{"event_id": "e1"}, {"event_id": "e2"}],
                "last_event_id": "e2",
                "has_more": True,
            }),
            _mock_response(200, {
                "events": [{"event_id": "e3"}],
                "last_event_id": "e3",
                "has_more": False,
            }),
        ]

        events = poll_all_events("conn_abc123")
        assert len(events) == 3

    @patch("scripts.sports_data.requests.request")
    def test_poll_empty_response(self, mock_request):
        """Polling when no new events should return empty list."""
        mock_request.return_value = _mock_response(200, {
            "events": [],
            "has_more": False,
        })

        result = poll_connection("conn_abc123")
        assert result["events"] == []
        assert result["has_more"] is False


# ===========================================================================
# Shipp.ai — Error Handling Tests
# ===========================================================================


class TestErrorHandling:
    """Test error handling for all HTTP status codes."""

    @patch("scripts.sports_data.requests.request")
    def test_400_bad_request(self, mock_request):
        """400 should raise ShippAPIError."""
        mock_request.return_value = _mock_response(
            400, {"error": "Invalid sport parameter"}
        )

        with pytest.raises(ShippAPIError) as exc_info:
            create_connection("nba")
        assert exc_info.value.status_code == 400

    @patch("scripts.sports_data.requests.request")
    def test_401_unauthorized(self, mock_request):
        """401 should raise ShippAuthError."""
        mock_request.return_value = _mock_response(
            401, {"error": "Invalid API key"}
        )

        with pytest.raises(ShippAuthError) as exc_info:
            create_connection("nba")
        assert exc_info.value.status_code == 401

    @patch("scripts.sports_data.requests.request")
    def test_402_payment_required(self, mock_request):
        """402 should raise ShippPaymentError."""
        mock_request.return_value = _mock_response(
            402, {"error": "Plan limit reached"}
        )

        with pytest.raises(ShippPaymentError) as exc_info:
            create_connection("nba")
        assert exc_info.value.status_code == 402

    @patch("scripts.sports_data.requests.request")
    def test_429_rate_limited_with_retry(self, mock_request):
        """429 should retry and eventually succeed or raise ShippRateLimitError."""
        mock_request.side_effect = [
            _mock_response(429, {"error": "Rate limited"}, headers={"Retry-After": "0.1"}),
            _mock_response(429, {"error": "Rate limited"}, headers={"Retry-After": "0.1"}),
            _mock_response(429, {"error": "Rate limited"}, headers={"Retry-After": "0.1"}),
        ]

        with pytest.raises(ShippRateLimitError):
            create_connection("nba")

    @patch("scripts.sports_data.requests.request")
    def test_429_succeeds_after_retry(self, mock_request):
        """429 followed by 200 should succeed."""
        mock_request.side_effect = [
            _mock_response(429, {"error": "Rate limited"}, headers={"Retry-After": "0.01"}),
            _mock_response(200, {"connection_id": "conn_retry_ok"}),
        ]

        conn_id = create_connection("nba")
        assert conn_id == "conn_retry_ok"

    @patch("scripts.sports_data.requests.request")
    def test_500_server_error_with_retry(self, mock_request):
        """5xx should retry and raise ShippAPIError if all retries fail."""
        mock_request.side_effect = [
            _mock_response(500, {"error": "Internal server error"}),
            _mock_response(502, {"error": "Bad gateway"}),
            _mock_response(503, {"error": "Service unavailable"}),
        ]

        with pytest.raises(ShippAPIError) as exc_info:
            create_connection("nba")
        assert exc_info.value.status_code >= 500

    @patch("scripts.sports_data.requests.request")
    def test_500_succeeds_after_retry(self, mock_request):
        """5xx followed by 200 should succeed."""
        mock_request.side_effect = [
            _mock_response(500, {"error": "Temporary failure"}),
            _mock_response(200, {"connection_id": "conn_recovered"}),
        ]

        conn_id = create_connection("nba")
        assert conn_id == "conn_recovered"

    def test_missing_api_key(self):
        """Missing API key should raise ShippAuthError."""
        with patch.dict(os.environ, {"SHIPP_API_KEY": ""}):
            with pytest.raises(ShippAuthError, match="not set"):
                create_connection("nba")


# ===========================================================================
# Shipp.ai — Schedule and Scores Tests
# ===========================================================================


class TestScheduleAndScores:
    """Test schedule and score retrieval."""

    @patch("scripts.sports_data.requests.request")
    def test_get_todays_games(self, mock_request):
        """Should return normalized game list."""
        mock_request.return_value = _mock_response(200, {
            "games": [
                {
                    "game_id": "g1",
                    "home_team": "Boston Celtics",
                    "away_team": "Los Angeles Lakers",
                    "start_time": "2026-02-18T19:30:00Z",
                    "status": "scheduled",
                    "venue": "TD Garden",
                },
            ]
        })

        games = get_todays_games("nba")
        assert len(games) == 1
        assert games[0]["home_team"] == "Boston Celtics"
        assert games[0]["source"] == "shipp"

    @patch("scripts.sports_data.requests.request")
    def test_get_live_scores(self, mock_request):
        """Should return latest score per game from polled events."""
        # First call: create_connection
        # Second call: poll_connection (inside poll_all_events)
        mock_request.side_effect = [
            _mock_response(200, {"connection_id": "conn_nba"}),
            _mock_response(200, {
                "events": [
                    {
                        "game_id": "g1",
                        "home_team": "Celtics",
                        "away_team": "Lakers",
                        "home_score": 55,
                        "away_score": 48,
                        "period": "Q2",
                        "clock": "3:45",
                        "status": "in_progress",
                    },
                    {
                        "game_id": "g1",
                        "home_team": "Celtics",
                        "away_team": "Lakers",
                        "home_score": 58,
                        "away_score": 50,
                        "period": "Q2",
                        "clock": "2:10",
                        "status": "in_progress",
                    },
                ],
                "has_more": False,
            }),
        ]

        scores = get_live_scores("nba")
        assert len(scores) == 1  # deduplicated by game_id
        assert scores[0]["home_score"] == 58  # latest event wins
        assert scores[0]["away_score"] == 50

    @patch("scripts.sports_data.requests.request")
    def test_get_play_by_play(self, mock_request):
        """Should return filtered play-by-play for a specific game."""
        mock_request.side_effect = [
            _mock_response(200, {"connection_id": "conn_nba"}),
            _mock_response(200, {
                "events": [
                    {"event_id": "e1", "game_id": "g1", "event_type": "basket", "description": "3-pointer"},
                    {"event_id": "e2", "game_id": "g2", "event_type": "foul", "description": "Offensive foul"},
                    {"event_id": "e3", "game_id": "g1", "event_type": "free_throw", "description": "FT made"},
                ],
                "has_more": False,
            }),
        ]

        pbp = get_play_by_play("g1", "nba")
        assert len(pbp) == 2  # only g1 events
        assert all(e["game_id"] == "g1" for e in pbp)

    @patch("scripts.sports_data.requests.request")
    def test_defensive_field_access(self, mock_request):
        """Games with missing fields should not crash."""
        mock_request.return_value = _mock_response(200, {
            "games": [
                {"id": "g_sparse"},  # Minimal data
            ]
        })

        games = get_todays_games("nba")
        assert len(games) == 1
        assert games[0]["game_id"] == "g_sparse"
        assert games[0]["home_team"] == "TBD"  # default value


# ===========================================================================
# External Sources Tests
# ===========================================================================


class TestExternalNBA:
    """Test NBA external source integrations."""

    @patch("scripts.external_sources.requests.get")
    def test_get_nba_player_stats(self, mock_get):
        """Should return player info and season averages."""
        mock_get.side_effect = [
            # Player search
            _mock_response(200, {
                "data": [{
                    "id": 237,
                    "first_name": "LeBron",
                    "last_name": "James",
                    "position": "F",
                    "team": {"full_name": "Los Angeles Lakers"},
                }]
            }),
            # Season averages
            _mock_response(200, {
                "data": [{
                    "games_played": 45,
                    "pts": 25.3,
                    "reb": 7.8,
                    "ast": 8.1,
                    "stl": 1.2,
                    "blk": 0.6,
                    "fg_pct": 0.515,
                    "ft_pct": 0.742,
                    "fg3_pct": 0.381,
                    "min": "34:20",
                    "turnover": 3.5,
                }]
            }),
        ]

        stats = get_nba_player_stats("LeBron James")
        assert stats is not None
        assert stats["name"] == "LeBron James"
        assert stats["pts"] == 25.3
        assert stats["source"] == "balldontlie"

    @patch("scripts.external_sources.requests.get")
    def test_get_nba_player_not_found(self, mock_get):
        """Should return None for unknown player."""
        mock_get.return_value = _mock_response(200, {"data": []})

        stats = get_nba_player_stats("Nonexistent Player")
        assert stats is None

    @patch("scripts.external_sources.requests.get")
    def test_get_nba_injuries_graceful_failure(self, mock_get):
        """Should return empty list if injury source is unavailable."""
        mock_get.return_value = _mock_response(404)

        injuries = get_nba_injuries()
        assert isinstance(injuries, list)


class TestExternalMLB:
    """Test MLB external source integrations."""

    @patch("scripts.external_sources.requests.get")
    def test_get_mlb_roster(self, mock_get):
        """Should return roster with player list."""
        mock_get.return_value = _mock_response(200, {
            "roster": [
                {
                    "person": {"id": 660271, "fullName": "Aaron Judge"},
                    "position": {"abbreviation": "RF"},
                    "jerseyNumber": "99",
                    "status": {"description": "Active"},
                },
                {
                    "person": {"id": 592450, "fullName": "Juan Soto"},
                    "position": {"abbreviation": "LF"},
                    "jerseyNumber": "22",
                    "status": {"description": "Active"},
                },
            ]
        })

        roster = get_mlb_roster("Yankees")
        assert roster is not None
        assert roster["player_count"] == 2
        assert roster["players"][0]["name"] == "Aaron Judge"
        assert roster["source"] == "mlb_stats_api"

    @patch("scripts.external_sources.requests.get")
    def test_get_mlb_roster_unknown_team(self, mock_get):
        """Should return None for unknown team if API search also fails."""
        mock_get.return_value = _mock_response(200, {"teams": []})

        roster = get_mlb_roster("Unknown FC")
        assert roster is None

    @patch("scripts.external_sources.requests.get")
    def test_get_mlb_injuries_graceful_failure(self, mock_get):
        """Should return empty list if injury source is down."""
        mock_get.return_value = _mock_response(500)

        injuries = get_mlb_injuries()
        assert isinstance(injuries, list)


class TestExternalSoccer:
    """Test soccer external source integrations."""

    @patch("scripts.external_sources.requests.get")
    def test_get_soccer_standings(self, mock_get):
        """Should return league table."""
        mock_get.return_value = _mock_response(200, {
            "competition": {"name": "Premier League"},
            "season": {"currentMatchday": 26},
            "standings": [{
                "type": "TOTAL",
                "table": [
                    {
                        "position": 1,
                        "team": {"name": "Arsenal FC", "id": 57},
                        "playedGames": 25,
                        "won": 18,
                        "draw": 4,
                        "lost": 3,
                        "points": 58,
                        "goalsFor": 52,
                        "goalsAgainst": 20,
                        "goalDifference": 32,
                    },
                    {
                        "position": 2,
                        "team": {"name": "Liverpool FC", "id": 64},
                        "playedGames": 25,
                        "won": 17,
                        "draw": 5,
                        "lost": 3,
                        "points": 56,
                        "goalsFor": 55,
                        "goalsAgainst": 22,
                        "goalDifference": 33,
                    },
                ],
            }],
        })

        standings = get_soccer_standings("premier_league")
        assert standings is not None
        assert standings["league"] == "Premier League"
        assert len(standings["standings"]) == 2
        assert standings["standings"][0]["team"] == "Arsenal FC"
        assert standings["source"] == "football_data_org"

    @patch("scripts.external_sources.requests.get")
    def test_get_soccer_standings_api_down(self, mock_get):
        """Should return None if football-data.org is down."""
        mock_get.return_value = _mock_response(503)

        standings = get_soccer_standings("premier_league")
        assert standings is None


# ===========================================================================
# Unified Wrapper Tests
# ===========================================================================


class TestShippWrapper:
    """Test the unified ShippSports wrapper."""

    def test_sports_response_success(self):
        """SportsResponse should indicate success when data is present."""
        resp = SportsResponse("nba", "live_scores", data={"scores": [1, 2]}, sources=["shipp.ai"])
        assert resp.success is True
        d = resp.to_dict()
        assert d["sport"] == "nba"
        assert d["sources"] == ["shipp.ai"]

    def test_sports_response_failure(self):
        """SportsResponse should indicate failure on errors."""
        resp = SportsResponse("nba", "live_scores", errors=["Something broke"])
        assert resp.success is False

    @patch("scripts.shipp_wrapper.get_live_scores")
    def test_wrapper_get_scores(self, mock_scores):
        """Wrapper should route scores to Shipp."""
        mock_scores.return_value = [
            {"game_id": "g1", "home_score": 100, "away_score": 95}
        ]

        ss = ShippSports()
        result = ss.get_scores("nba")
        assert result.success
        assert len(result.data["scores"]) == 1
        assert "shipp.ai" in result.sources

    @patch("scripts.shipp_wrapper.get_live_scores")
    @patch("scripts.shipp_wrapper.get_soccer_matches")
    def test_wrapper_scores_fallback_soccer(self, mock_matches, mock_shipp):
        """When Shipp fails for soccer, should fall back to football-data.org."""
        mock_shipp.side_effect = ShippAPIError(500, "Server error")
        mock_matches.return_value = [
            {"match_id": 1, "home_team": "Arsenal", "away_team": "Chelsea",
             "home_score": 2, "away_score": 1, "status": "IN_PLAY"},
        ]

        ss = ShippSports()
        result = ss.get_scores("soccer")
        assert result.success
        assert "football-data.org" in result.sources

    @patch("scripts.shipp_wrapper.get_nba_player_stats")
    def test_wrapper_player_stats_nba(self, mock_stats):
        """Player stats for NBA should use balldontlie."""
        mock_stats.return_value = {"name": "LeBron James", "pts": 25.3}

        ss = ShippSports()
        result = ss.get_player_stats("nba", "LeBron James")
        assert result.success
        assert "balldontlie" in result.sources

    @patch("scripts.shipp_wrapper.get_mlb_roster")
    def test_wrapper_roster_mlb(self, mock_roster):
        """Roster for MLB should use MLB Stats API."""
        mock_roster.return_value = {"team": "Yankees", "players": [], "player_count": 0}

        ss = ShippSports()
        result = ss.get_roster("mlb", "Yankees")
        assert result.success
        assert "mlb_stats_api" in result.sources

    @patch("scripts.shipp_wrapper.get_soccer_standings")
    def test_wrapper_standings_soccer(self, mock_standings):
        """Standings for soccer should use football-data.org."""
        mock_standings.return_value = {"league": "Premier League", "standings": []}

        ss = ShippSports()
        result = ss.get_standings("soccer", league="premier_league")
        assert result.success
        assert "football-data.org" in result.sources

    def test_wrapper_query_router_unknown_type(self):
        """Unknown query type should return error response."""
        ss = ShippSports()
        result = ss.query("nba", "unknown_query_type")
        assert not result.success
        assert any("Unknown query type" in e for e in result.errors)

    @patch("scripts.shipp_wrapper.get_todays_games")
    def test_wrapper_query_router_schedule(self, mock_games):
        """Query router should route 'schedule' to get_schedule."""
        mock_games.return_value = [{"game_id": "g1"}]

        ss = ShippSports()
        result = ss.query("nba", "schedule")
        assert result.success
        assert result.query_type == "schedule"

    def test_wrapper_query_router_handles_exception(self):
        """Query router should catch unexpected exceptions gracefully."""
        ss = ShippSports()
        with patch.object(ss, "get_scores", side_effect=RuntimeError("boom")):
            result = ss.query("nba", "scores")
            assert not result.success
            assert any("Unexpected error" in e for e in result.errors)


# ===========================================================================
# Edge Cases
# ===========================================================================


class TestEdgeCases:
    """Test edge cases and defensive coding."""

    @patch("scripts.sports_data.requests.request")
    def test_poll_with_alternate_response_shape(self, mock_request):
        """API might return 'data' instead of 'events'."""
        mock_request.return_value = _mock_response(200, {
            "data": [{"id": "e1", "type": "score"}],
            "cursor": "cur_123",
        })

        result = poll_connection("conn_test")
        assert len(result["events"]) == 1
        assert result["last_event_id"] == "cur_123"

    @patch("scripts.sports_data.requests.request")
    def test_schedule_with_nested_team_objects(self, mock_request):
        """Schedule response might use nested team objects."""
        mock_request.return_value = _mock_response(200, {
            "schedule": [{
                "id": "g_nested",
                "home": {"name": "Home Team"},
                "away": {"name": "Away Team"},
                "datetime": "2026-02-18T20:00:00Z",
                "status": "scheduled",
            }]
        })

        games = get_todays_games("soccer")
        assert len(games) == 1
        assert games[0]["home_team"] == "Home Team"
        assert games[0]["away_team"] == "Away Team"

    @patch("scripts.sports_data.requests.request")
    def test_connection_no_id_in_response(self, mock_request):
        """Should raise if response has no connection ID at all."""
        mock_request.return_value = _mock_response(200, {"status": "created"})

        with pytest.raises(ShippAPIError, match="No connection_id"):
            create_connection("nba")

    @patch("scripts.external_sources.requests.get")
    def test_external_api_timeout(self, mock_get):
        """External API timeout should return None, not crash."""
        import requests as req
        mock_get.side_effect = req.exceptions.Timeout("Timed out")

        stats = get_nba_player_stats("LeBron James")
        assert stats is None

    @patch("scripts.external_sources.requests.get")
    def test_external_api_connection_error(self, mock_get):
        """External API connection error should return None."""
        import requests as req
        mock_get.side_effect = req.exceptions.ConnectionError("DNS failed")

        roster = get_mlb_roster("Yankees")
        assert roster is None


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
