"""
shipp-sports test package.
"""
