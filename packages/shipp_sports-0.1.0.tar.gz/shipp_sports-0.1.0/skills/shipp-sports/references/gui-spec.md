# GUI Specification: shipp-sports

## Design Direction
- **Style:** Multi-sport hub serving as the unified gateway to all sports data. Tab-navigated interface with a universal header and sport-specific accent theming. Card grid layout for games that expand into detailed views. Designed to feel like a premium sports command center that adapts its personality per sport while maintaining a cohesive Shipp brand identity.
- **Inspiration:** The Score app multi-sport hub on Dribbble, Apple Sports app clean card layout on Behance, Google Sports one-stop-shop overview on Mobbin
- **Mood:** Unified, premium, adaptive, comprehensive

## Layout
- **Primary view:** Universal header (64px) with Shipp branding and sport selector tabs. Below, a responsive card grid (3 columns desktop, 2 tablet, 1 mobile) of GameCards for the selected sport showing today's games. Cards are grouped by status: LIVE (top, sorted by start time), UPCOMING (middle, sorted by start time), FINAL (bottom, sorted by end time). Clicking a card expands inline or navigates to a detail view matching the sport-specific skill (game-day-dashboard, soccer-match-tracker, etc.).
- **Mobile:** Single-column card feed. Sport selector becomes a horizontal scrollable pill bar. Cards are full-width with slightly condensed info. Sticky header with sport selector. Pull-to-refresh supported.
- **Header:** Full-width Shipp-branded header with: Shipp Sports logo (left), horizontal sport selector tabs with sport icons — NBA, NFL, MLB, NCAA, Soccer (center), search icon + settings gear + notification bell (right). Active sport tab has a thick bottom border in that sport's accent color.

## Color Palette
- Background: #0D1117 (Midnight Base)
- Surface: #161B22 (Carbon Card)
- Primary accent: Dynamic per sport —
  - NBA: #C9082A (NBA Red) — active tab, live game borders, score highlights
  - NFL: #013369 (NFL Blue) — active tab, live game borders, score highlights
  - MLB: #002D72 (MLB Navy) — active tab, live game borders, score highlights
  - NCAA: #FF6600 (NCAA Orange) — active tab, live game borders, score highlights
  - Soccer: #44CC44 (Pitch Green) — active tab, live game borders, score highlights
- Success: #34D399 (Universal Green) — live indicators, score updates, positive changes
- Warning: #EF4444 (Universal Red) — alerts, injury flags, final buzzer indicators
- Text primary: #F0F6FC (Ice White)
- Text secondary: #8B949E (Slate Grey)

## Component Structure
- **SportSelectorTabs** — Horizontal tab bar with sport icons and labels (NBA, NFL, MLB, NCAA, Soccer). Active tab has sport-specific accent color bottom border (3px). Inactive tabs are #8B949E. Hover shows accent color at 50% opacity. Tabs are evenly spaced on desktop, horizontally scrollable on mobile.
- **GameCard** — Versatile card component showing: two team rows (logo + name + score), game status badge (LIVE/FINAL/time), sport-specific accent border on left edge for live games, and a mini stat preview row. Card is the atomic unit of the grid.
- **LiveSection** — Grouped container for live games with a pulsing "LIVE NOW" section header. Cards in this section have a subtle left-border glow in the sport's accent color and display real-time updating scores.
- **GameDetail** — Expanded view replacing or overlaying the card grid when a game is selected. Contains full scoreboard, key stats, and links to deeper skill-specific views (play-by-play for basketball, event timeline for soccer, etc.).
- **SearchOverlay** — Full-screen overlay triggered by the search icon. Allows searching for teams, players, or games across all sports. Results grouped by sport with accent-colored section headers.
- **ScoreUpdateIndicator** — Small animated element on GameCards that briefly flashes when a score changes. The score digits animate (number flip) and a subtle glow in the sport's accent color appears for 1s.
- **DateNavigator** — Horizontal date strip below the sport tabs allowing navigation between game days. Today is highlighted. Swiping or clicking arrows navigates dates. Shows game count badge per date.

## Typography
- Headings: Inter Bold, 20-28px, letter-spacing -0.02em, #F0F6FC
- Body: Inter Regular, 14-16px, line-height 1.5, #8B949E for secondary, #F0F6FC for primary
- Stats/numbers: JetBrains Mono Medium, 28-40px for scores on cards, 14-16px for stat values, tabular-nums enabled

## Key Interactions
- **Sport tab switch:** Clicking a sport tab transitions the accent color across the UI (tab border, live card borders, section headers) with a 300ms color transition. Card grid cross-fades to the new sport's games.
- **Card tap/click:** Tapping a GameCard expands it inline (400ms height animation) to show the GameDetail view with full stats, or navigates to the sport-specific skill page. A subtle scale-down (0.98x) on press provides tactile feedback.
- **Live score update:** When a live game's score changes, the score digits perform a number-flip animation (each digit rolls vertically), the card briefly glows in the sport's accent color, and the card reorders to reflect the latest activity.
- **Pull-to-refresh (mobile):** Pulling down on the card feed triggers a refresh animation with the Shipp logo spinning briefly, then new/updated cards animate into position.
- **Date navigation:** Swiping the date strip or clicking arrows loads games for that date. Cards animate out (fade left) and new cards animate in (fade right) with a 250ms stagger.
- **Cross-sport search:** Typing in the search overlay filters results in real-time across all sports. Selecting a result navigates directly to the relevant game or player detail, with the sport tab auto-switching to match.

## Reference Screenshots
- [The Score Multi-Sport Hub on Dribbble](https://dribbble.com/search/multi-sport-scores-app) — Multi-sport tabbed interface with card grid layout and sport-specific accent theming
- [Apple Sports App on Behance](https://www.behance.net/search/projects?search=sports+scores+app+clean) — Clean, minimal card-based game list with live indicators and expandable detail views
- [Google Sports Overview on Mobbin](https://mobbin.com/search/sports-scores-hub) — Unified sports hub with sport selector, date navigation, and responsive game cards
