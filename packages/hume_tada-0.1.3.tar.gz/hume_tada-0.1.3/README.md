<!-- ---
license: mit
language:
  - en
tags:
  - tts
  - text-to-speech
  - speech-language-model
--- -->

# Text-Acoustic Dual-Alignment Large Language Model

TADA is a unified speech-language model that synchronizes speech and text into a single, cohesive stream via 1:1 alignment. By leveraging a novel tokenizer and architectural design, TADA achieves high-fidelity synthesis and generation with a fraction of the computational overhead required by traditional models.

⭐️ arxiv: https://arxiv.org/abs/2602.23068 \
⭐️ demo: https://huggingface.co/spaces/HumeAI/tada \
⭐️ github: https://github.com/HumeAI/tada \
⭐️ blog post:

## Key Features

- 1:1 Token Alignment: Unlike standard models, TADA’s tokenizer encodes audio into a sequence of vectors that perfectly matches the number of text tokens.
- Dynamic Duration Synthesis: As a TTS model, it generates the full speech segment for a text token in a single autoregressive step, regardless of length. This eliminates the need for fixed-frame-rate processing.
- Dual-Stream Generation: In speech-language modeling mode, it generates a text token and the speech for the preceding token simultaneously, maintaining the same context length and minimal overhead compared to text-only generation.
- Efficiency & Reliability: TADA delivers superior expressiveness and natural flow while significantly reducing the computational cost associated with fixed audio frame rates.

## How It Works

### The Tokenization Schema

TADA unifies modalities by ensuring that for every word or subword token, there is exactly one corresponding speech vector. This synchronized stream allows the model to "understand" the precise timing of speech relative to text.

### Dynamic Autoregression

Most TTS models require a fixed number of steps to produce one second of audio (e.g., 50 frames per second). TADA breaks this constraint:

- Each autoregressive step covers one text token.
- The model dynamically determines the duration and prosody for that specific token.
- This results in a more natural flow and eliminates transcript hallucination.

## Evaluation

<table>
  <tr>
    <td><img src="figures/CER.png" alt="CER" height="300px"></td>
    <td><img src="figures/MOS.png" alt="MOS" height="300px"></td>
  </tr>
  <tr>
    <td><img src="figures/real-time.png" alt="Speed" height="300px"></td>
    <td><img src="figures/speaker-sim.png" alt="Speaker Similarity" height="300px"></td>
  </tr>
</table>

## Installation

From the github repo

```bash
pip install git+https://github.com/HumeAI/tada.git
```

From source

```bash
pip install -e .
```

## Models

We provide several model checkpoints:

| Model   | Base Model   | HuggingFace Hub                                           |
| ------- | ------------ | --------------------------------------------------------- |
| TADA-1B | Llama 3.2 1B | [`HumeAI/tada-1b`](https://huggingface.co/HumeAI/tada-1b) |
| TADA-3B | Llama 3.2 3B | [`HumeAI/tada-3b`](https://huggingface.co/HumeAI/tada-3b) |

All models use the same encoder ([`HumeAI/tada-codec`](https://huggingface.co/HumeAI/tada-codec)) and can be loaded using the same API.

## Run Inference

### Text-to-Speech

```python
import torch
import torchaudio

from tada.modules.encoder import Encoder
from tada.modules.tada import TadaForCausalLM

device = "cuda"
encoder = Encoder.from_pretrained("HumeAI/tada-codec", subfolder="encoder").to(device)
model = TadaForCausalLM.from_pretrained("HumeAI/tada-3b").to(device)

audio, sample_rate = torchaudio.load("samples/ljspeech.wav")
audio = audio.to(device)
prompt_text = "The examination and testimony of the experts, enabled the commission to conclude that five shots may have been fired."
prompt = encoder(
    audio, text=[prompt_text], sample_rate=sample_rate
)

output = model.generate(
    prompt=prompt,
    text="Please call Stella. Ask her to bring these things with her from the store.",
)
```

### Speech continuation

Provide `num_extra_steps` if you want to generate text-speech continuation of the prompt

```python
output = model.generate(
    prompt=prompt,
    num_extra_steps=50
)
```

### Contact

Hume AI is an empathic AI research company. We research the datasets, tools, and models needed to give empathy to AI models to serve human wellbeing. If you're interested in any of our product or research collaborations, please reach out to us at hello@hume.ai