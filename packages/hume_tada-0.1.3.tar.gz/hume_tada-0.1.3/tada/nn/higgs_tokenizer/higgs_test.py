import pytest
import torch
from tokenization.rich_stoks.types import Audio


@pytest.mark.prod
def test_higgs_encoder(device):
    """Test dac encoder"""
    from .higgs import HiggsAudioExtractor

    encoder = HiggsAudioExtractor().to(device)
    x = torch.randn(2, encoder.sample_rate).to(device)
    codes = encoder(Audio(audio=x, sample_rate=24000).to(device))
    assert codes.shape == (2, 8, 25)


def test_higgs(device):
    from .higgs import HiggsAudioExtractor

    encoder = HiggsAudioExtractor().to(device)
    num_params = sum(p.numel() for p in encoder.tokenizer.decoder_2.parameters())
    assert num_params == 20_247_074

    num_params = sum(p.numel() for p in encoder.tokenizer.decoder_semantic.parameters())
    assert num_params == 16_516_608


def test_higgs_decoder(device):
    from .higgs import HiggsAudioDecoder

    decoder = HiggsAudioDecoder().to(device)
    x = torch.randint(0, 1024, (2, 8, 25)).to(device)
    audio = decoder(x)
    assert audio.shape == (2, 24000)


def test_dac_decoder(device):
    """Test dac decoder"""
    from .higgs import HiggsAudioDecoder

    decoder = HiggsAudioDecoder()
    x = torch.randint(0, 1024, (2, 8, 25)).to(device)
    audio = decoder(x)
    assert audio.shape == (2, 24000)
