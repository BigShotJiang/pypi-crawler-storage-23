"""Higgs Audio tokenizer"""

import torch
import torchaudio
from humer.core.nn.codec import BaseAudioDecoder, BaseAudioEncoder
from tokenization.rich_stoks.types import Audio

from .higgs_audio_tokenizer import load_higgs_audio_tokenizer


class HiggsAudioExtractor(BaseAudioEncoder):
    frame_rate = 25
    sample_rate = 24000
    num_channels = 8
    vocab_size = 1024
    embed_dim = 1024

    def __init__(
        self,
        tokenizer_name_or_path: str = "bosonai/higgs-audio-v2-tokenizer",
    ):
        super().__init__()
        self.tokenizer = load_higgs_audio_tokenizer(
            tokenizer_name_or_path,
            device="cuda" if torch.cuda.is_available() else "cpu",
        )
        for param in self.tokenizer.parameters():
            param.requires_grad = False

        self.tokenizer.eval()

    @property
    def device(self) -> torch.device:
        return self.tokenizer.device

    def forward(self, audio: Audio | torch.Tensor) -> torch.Tensor:
        # Resample to the tokenizer's sample rate if needed
        if isinstance(audio, Audio):
            if audio.sample_rate != self.sample_rate:
                wav = torchaudio.functional.resample(audio.audio, audio.sample_rate, self.sample_rate)
            else:
                wav = audio.audio
        else:
            wav = audio

        # Move to device if needed
        if wav.device != self.device:
            wav = wav.to(self.device)

        # Encode audio to tokens
        with torch.no_grad():
            inputs = self.tokenizer.audio_tokenizer_feature_extractor(
                raw_audio=wav.unsqueeze(1),
                sampling_rate=self.tokenizer.audio_tokenizer_feature_extractor.sampling_rate,
                return_tensors="pt",
            )
            tokens = self.tokenizer._xcodec_encode(inputs["input_values"]).audio_codes

        return tokens

    def extract_features(self, tokens: torch.Tensor) -> torch.Tensor:
        vq_codes = tokens.permute(1, 0, 2)
        quantized = self.tokenizer.quantizer.decode(vq_codes)
        quantized_acoustic = self.tokenizer.fc_post2(quantized.transpose(1, 2))
        return quantized_acoustic


class HiggsAudioDecoder(BaseAudioDecoder):
    sample_rate = 24000
    frame_rate = 25

    def __init__(
        self,
        tokenizer_name_or_path: str = "bosonai/higgs-audio-v2-tokenizer",
        super_resolution: bool = False,
    ):
        super().__init__()
        self.tokenizer = load_higgs_audio_tokenizer(tokenizer_name_or_path, device="cuda")
        for param in self.tokenizer.parameters():
            param.requires_grad = False
        self.tokenizer.eval()

        self.super_resolution = super_resolution
        if super_resolution:
            self.sample_rate = 48000

    @property
    def sr_model(self):
        if not hasattr(self, "_sr_model"):
            from hifi_gan_bwe import BandwidthExtender

            self._sr_model = BandwidthExtender.from_pretrained("hifi-gan-bwe-10-42890e3-vctk-48kHz")

            self._sr_model.eval()
            for param in self._sr_model.parameters():
                param.requires_grad = False
        return self._sr_model

    def forward(self, codes: torch.Tensor, **kwargs) -> torch.Tensor:
        if len(codes.shape) == 2:
            codes = codes.unsqueeze(0)

        # Decode tokens to audio
        with torch.no_grad():
            audio = self.tokenizer.decode(codes)

        # Convert to tensor if it's numpy array
        if isinstance(audio, (list, tuple)):
            audio = torch.from_numpy(audio[0])
        elif not isinstance(audio, torch.Tensor):
            audio = torch.from_numpy(audio)

        if self.super_resolution:
            audio = self.sr_model(audio, 24000)

        audio = audio.squeeze(1)

        return audio

    def decode(self, codes: torch.Tensor, **kwargs) -> torch.Tensor:
        return self.forward(codes.transpose(2, 1))
