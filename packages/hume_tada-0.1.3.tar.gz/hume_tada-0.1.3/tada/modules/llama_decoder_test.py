import os

import pytest
import torch
import torchaudio

from ..utils.test_utils import get_sample_dir
from .encoder import Encoder, EncoderConfig
from .llama_decoder import LlamaDecoder, LlamaDecoderConfig


@pytest.mark.parametrize(
    "model_name_or_path",
    [
        # None,
        # os.path.join(get_weight_dir(), "uploads")
        "HumeAI/tada-codec",
    ],
)
def test_llama_decoder(model_name_or_path: str | None):
    device = "cpu"
    if model_name_or_path is None:
        encoder = Encoder(EncoderConfig()).to(device)
        encoder.aligner.to(device)
        decoder = LlamaDecoder(LlamaDecoderConfig()).to(device)
    else:
        encoder = Encoder.from_pretrained(model_name_or_path, subfolder="encoder").to(device)
        decoder = LlamaDecoder.from_pretrained(model_name_or_path, subfolder="llama_decoder").to(device)
    audio, sample_rate = torchaudio.load(os.path.join(get_sample_dir(), "ljspeech.wav"))
    audio = audio.to(device)
    text = "The examination and testimony of the experts, enabled the commission to conclude that five shots may have been fired."
    out = encoder(
        audio, text=[text], audio_length=torch.tensor([audio.shape[1]], device=device), sample_rate=sample_rate
    )
    out = decoder.generate(out.encoded_expanded)
    assert out.shape == (1, 1, 184320)
    torchaudio.save(os.path.join(get_sample_dir(), "ljspeech_decoded.wav"), out.detach().squeeze(1), sample_rate)
