import os
from typing import Optional, Union

import torch
import torch.nn as nn
from transformers import (
    Cache,
    GenerationConfig,
    LlamaConfig,
    LlamaForCausalLM,
    LogitsProcessorList,
    StoppingCriteriaList,
)
from transformers.generation.streamers import BaseStreamer
from transformers.generation.utils import GenerateNonBeamOutput

from tada.nn.higgs_tokenizer.higgs_audio_tokenizer import load_higgs_audio_tokenizer


class LlamaDecoderConfig(LlamaConfig):
    def __init__(
        self,
        num_codebooks: int = 8,
        vocab_size: int = 1024,
        max_num_frames: int = 256,
        hidden_size: int = 1024,
        intermediate_size: int = 4096,
        num_hidden_layers: int = 16,
        num_attention_heads: int = 16,
        num_key_value_heads: int = 4,
        hidden_act: str = "silu",
        max_position_embeddings: int = 2048,
        initializer_range: float = 0.02,
        rms_norm_eps: float = 1e-6,
        use_cache: bool = True,
        tie_word_embeddings: bool = False,
        rope_theta: float = 10000.0,
        **kwargs,
    ):
        super().__init__(
            vocab_size=vocab_size,
            hidden_size=hidden_size,
            intermediate_size=intermediate_size,
            num_hidden_layers=num_hidden_layers,
            num_attention_heads=num_attention_heads,
            num_key_value_heads=num_key_value_heads,
            hidden_act=hidden_act,
            max_position_embeddings=max_position_embeddings,
            initializer_range=initializer_range,
            rms_norm_eps=rms_norm_eps,
            use_cache=use_cache,
            tie_word_embeddings=tie_word_embeddings,
            rope_theta=rope_theta,
            **kwargs,
        )
        self.num_codebooks = num_codebooks
        self.max_num_frames = max_num_frames


class LlamaDecoder(LlamaForCausalLM):
    def __init__(
        self,
        config: LlamaDecoderConfig,
    ):
        super().__init__(config)
        self.num_codebooks = config.num_codebooks

        self.token_emb = torch.nn.ModuleList(
            [torch.nn.Embedding(config.vocab_size + 1, config.hidden_size) for _ in range(config.num_codebooks)]
        )
        self.token_proj = torch.nn.ModuleList(
            [torch.nn.Linear(config.hidden_size, config.vocab_size + 1) for _ in range(config.num_codebooks)]
        )
        self.cont_token_emb = torch.nn.Linear(config.hidden_size, config.hidden_size)
        self.num_frame_emb = torch.nn.Embedding(config.max_num_frames, config.hidden_size)
        self.num_frame_emb.weight.data.zero_()

    def embed_tokens(self, input_ids: torch.LongTensor) -> torch.Tensor:
        return sum(self.token_emb[i](input_ids[..., i]) for i in range(self.num_codebooks))

    def prepare_inputs_for_generation(
        self,
        input_ids: torch.LongTensor,
        multi_level_input_ids: torch.LongTensor,
        past_key_values: Optional[Cache] = None,
        attention_mask: Optional[torch.LongTensor] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        cache_position: Optional[torch.LongTensor] = None,
        **kwargs,
    ):
        """
        Prepare the model inputs for generation. In includes operations like computing the 4D attention mask or
        slicing inputs given the existing cache.

        See the forward pass in the model documentation for expected arguments (different models might have different
        requirements for e.g. `past_key_values`). This function should work as is for most LLMs.
        """
        encoded_expanded = kwargs.pop("encoded_expanded", None)
        num_frames = kwargs.pop("num_frames", None)

        model_inputs = super().prepare_inputs_for_generation(
            input_ids=input_ids,
            past_key_values=past_key_values,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
            cache_position=cache_position,
            **kwargs,
        )
        if model_inputs["input_ids"].shape[1] < multi_level_input_ids.shape[1]:
            model_inputs["input_ids"] = multi_level_input_ids[:, -model_inputs["input_ids"].shape[1] :, :]
        else:
            model_inputs["input_ids"] = multi_level_input_ids
        if kwargs.get("use_cache", False) and encoded_expanded is not None:
            model_inputs["encoded_expanded"] = encoded_expanded[:, cache_position[0] : input_ids.shape[1]]
            model_inputs["num_frames"] = num_frames[:, cache_position[0] : input_ids.shape[1]]
        else:
            model_inputs["encoded_expanded"] = encoded_expanded
            model_inputs["num_frames"] = num_frames
        return model_inputs

    def forward(
        self,
        input_ids: torch.LongTensor,
        encoded_expanded: torch.Tensor | None = None,
        num_frames: torch.LongTensor | None = None,
        **kwargs,
    ):
        assert kwargs.get("inputs_embeds", None) is None
        kwargs["inputs_embeds"] = self.embed_tokens(input_ids)
        kwargs["inputs_embeds"] += self.cont_token_emb(encoded_expanded)
        if num_frames is not None:
            kwargs["inputs_embeds"] += self.num_frame_emb(num_frames.clamp(max=self.config.max_num_frames - 1))
        out = super().forward(**kwargs)
        logits = [self.token_proj[i](out.logits) for i in range(self.num_codebooks)]
        out.logits = torch.stack(logits, dim=-2)
        return out

    def _sample(
        self,
        input_ids: torch.LongTensor,
        multi_level_input_ids: torch.LongTensor,
        logits_processor: LogitsProcessorList,
        stopping_criteria: StoppingCriteriaList,
        generation_config: GenerationConfig,
        synced_gpus: bool,
        streamer: Optional[BaseStreamer] = None,
        **model_kwargs,
    ) -> Union[GenerateNonBeamOutput, torch.LongTensor]:
        r"""
        Generates sequences of token ids for models with a language modeling head using **multinomial sampling** and
        can be used for text-decoder, text-to-text, speech-to-text, and vision-to-text models.

        Parameters:
            input_ids (`torch.LongTensor` of shape `(batch_size, sequence_length)`):
                The sequence used as a prompt for the generation.
            logits_processor (`LogitsProcessorList`):
                An instance of [`LogitsProcessorList`]. List of instances of class derived from [`LogitsProcessor`]
                used to modify the prediction scores of the language modeling head applied at each generation step.
            stopping_criteria (`StoppingCriteriaList`):
                An instance of [`StoppingCriteriaList`]. List of instances of class derived from [`StoppingCriteria`]
                used to tell if the generation loop should stop.
            generation_config ([`~generation.GenerationConfig`]):
                The generation configuration to be used as parametrization of the decoding method.
            synced_gpus (`bool`):
                Whether to continue running the while loop until max_length (needed to avoid deadlocking with
                `FullyShardedDataParallel` and DeepSpeed ZeRO Stage 3).
            streamer (`BaseStreamer`, *optional*):
                Streamer object that will be used to stream the generated sequences. Generated tokens are passed
                through `streamer.put(token_ids)` and the streamer is responsible for any further processing.
            model_kwargs:
                Additional model specific kwargs will be forwarded to the `forward` function of the model. If model is
                an encoder-decoder model the kwargs should include `encoder_outputs`.

        Return:
            [`~generation.GenerateDecoderOnlyOutput`], [`~generation.GenerateEncoderDecoderOutput`] or `torch.LongTensor`:
            A `torch.LongTensor` containing the generated tokens (default behaviour) or a
            [`~generation.GenerateDecoderOnlyOutput`] if `model.config.is_encoder_decoder=False` and
            `return_dict_in_generate=True` or a [`~generation.GenerateEncoderDecoderOutput`] if
            `model.config.is_encoder_decoder=True`.
        """
        # init values
        input_ids = multi_level_input_ids
        pad_token_id = generation_config._pad_token_tensor
        output_attentions = generation_config.output_attentions
        output_hidden_states = generation_config.output_hidden_states
        output_scores = generation_config.output_scores
        output_logits = generation_config.output_logits
        return_dict_in_generate = generation_config.return_dict_in_generate
        has_eos_stopping_criteria = any(hasattr(criteria, "eos_token_id") for criteria in stopping_criteria)
        do_sample = generation_config.do_sample

        # init attention / hidden states / scores tuples
        scores = () if (return_dict_in_generate and output_scores) else None
        raw_logits = () if (return_dict_in_generate and output_logits) else None
        decoder_attentions = () if (return_dict_in_generate and output_attentions) else None
        cross_attentions = () if (return_dict_in_generate and output_attentions) else None
        decoder_hidden_states = () if (return_dict_in_generate and output_hidden_states) else None

        # if model is an encoder-decoder, retrieve encoder attention weights and hidden states
        if return_dict_in_generate and self.config.is_encoder_decoder:
            encoder_attentions = model_kwargs["encoder_outputs"].get("attentions") if output_attentions else None
            encoder_hidden_states = (
                model_kwargs["encoder_outputs"].get("hidden_states") if output_hidden_states else None
            )

        # keep track of which sequences are already finished
        batch_size, _, cur_len = input_ids.shape
        this_peer_finished = False
        unfinished_sequences = torch.ones(batch_size, dtype=torch.long, device=input_ids.device)
        try:
            model_kwargs = self._get_initial_cache_position(input_ids[..., 0], model_kwargs)
        except Exception:
            model_kwargs = self._get_initial_cache_position(input_ids.shape[1], input_ids.device, model_kwargs)

        model_forward = self.__call__
        if isinstance(model_kwargs.get("past_key_values"), Cache):
            # is_compileable = model_kwargs["past_key_values"].is_compileable and self._supports_static_cache
            is_compileable = False
            if getattr(self, "hf_quantizer", None) is not None:
                is_compileable &= self.hf_quantizer.is_compileable
            is_compileable = is_compileable and not generation_config.disable_compile
            if is_compileable and (self.device.type == "cuda" or generation_config.compile_config._compile_all_devices):
                os.environ["TOKENIZERS_PARALLELISM"] = "0"
                model_forward = self.get_compiled_call(generation_config.compile_config)

        is_prefill = True
        while self._has_unfinished_sequences(this_peer_finished, synced_gpus, device=input_ids.device):
            # prepare model inputs
            model_inputs = self.prepare_inputs_for_generation(input_ids[..., 0], multi_level_input_ids, **model_kwargs)

            # prepare variable output controls (note: some models won't accept all output controls)
            model_inputs.update({"output_attentions": output_attentions} if output_attentions else {})
            model_inputs.update({"output_hidden_states": output_hidden_states} if output_hidden_states else {})

            if is_prefill:
                outputs = self(**model_inputs, return_dict=True)
                is_prefill = False
            else:
                outputs = model_forward(**model_inputs, return_dict=True)

            # synced_gpus: don't waste resources running the code we don't need; kwargs must be updated before skipping
            model_kwargs = self._update_model_kwargs_for_generation(
                outputs,
                model_kwargs,
                is_encoder_decoder=self.config.is_encoder_decoder,
            )
            if synced_gpus and this_peer_finished:
                continue

            # Clone is needed to avoid keeping a hanging ref to outputs.logits which may be very large for first iteration
            # (the clone itself is always small)
            next_token_logits = outputs.logits[:, -1, :].clone().float()
            next_token_logits = next_token_logits.to(input_ids.device)

            # pre-process distribution
            next_token_scores = logits_processor(input_ids, next_token_logits)

            # token selection
            if do_sample:
                probs = nn.functional.softmax(next_token_scores, dim=-1)
                # TODO (joao): this OP throws "skipping cudagraphs due to ['incompatible ops']", find solution
                probs = probs.reshape(-1, probs.shape[-1])
                next_tokens = torch.multinomial(probs, num_samples=1).squeeze(1)
                next_tokens = next_tokens.reshape(batch_size, -1)
            else:
                next_tokens = torch.argmax(next_token_scores, dim=-1)

            # finished sentences should have their next token be a padding token
            if has_eos_stopping_criteria:
                next_tokens = next_tokens * unfinished_sequences.unsqueeze(-1) + pad_token_id * (
                    1 - unfinished_sequences
                ).unsqueeze(-1)

            # update generated ids, model inputs, and length for next step
            input_ids = torch.cat([input_ids, next_tokens.unsqueeze(1)], dim=1)
            multi_level_input_ids = input_ids
            if streamer is not None:
                streamer.put(next_tokens.cpu())

            unfinished_sequences = unfinished_sequences & ~stopping_criteria(input_ids[..., 0], scores)
            this_peer_finished = unfinished_sequences.max() == 0
            cur_len += 1

            # This is needed to properly delete outputs.logits which may be very large for first iteration
            # Otherwise a reference to outputs is kept which keeps the logits alive in the next iteration
            del outputs

        if streamer is not None:
            streamer.end()

        return input_ids

    def _generate(self, input_ids: torch.LongTensor, **kwargs):
        return super().generate(input_ids[..., 0], multi_level_input_ids=input_ids, **kwargs)

    def backfill_sparse_encoding(
        self, encoded_padded: torch.Tensor, seq_len: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Backfill zero vectors with the next non-zero vector along seq_len dimension.

        Args:
            encoded_padded: Tensor of shape [batch_size, max_seq_len, d] with sparse entries
            seq_len: Tensor of shape [batch_size] indicating actual sequence length for each batch

        Returns:
            Tuple of (encoded_resized, num_frames) where:
                - encoded_resized: Tensor with zero vectors backfilled
                - num_frames: Number of steps until next non-zero column for each position
        """
        batch_size, max_seq_len, d = encoded_padded.shape
        is_nonzero = encoded_padded.abs().sum(dim=-1) > 0  # [batch_size, max_seq_len]

        # Create indices for each position in sequence
        indices = torch.arange(max_seq_len, device=encoded_padded.device).view(1, -1).expand(batch_size, -1)

        # Create mask for positions within seq_len
        position_mask = indices < seq_len.unsqueeze(1)  # [batch_size, max_seq_len]

        # Pretend there's a non-zero position at seq_len
        at_seq_len = indices == seq_len.unsqueeze(1)  # [batch_size, max_seq_len]

        # Set indices to inf where zero AND not at seq_len, keep original where non-zero OR at seq_len
        indices_masked = torch.where(
            (is_nonzero & position_mask) | at_seq_len,
            indices.float(),
            torch.tensor(float("inf"), device=encoded_padded.device),
        )

        # Reverse cummin to find next non-zero index (going forward in sequence)
        indices_flipped = indices_masked.flip(dims=[1])
        next_nonzero_idx = torch.cummin(indices_flipped, dim=1)[0].flip(dims=[1])

        # Clamp to valid range and convert to long
        next_nonzero_idx = next_nonzero_idx.clamp(max=max_seq_len - 1).long()

        # Gather the non-zero vectors using torch.gather
        # Expand next_nonzero_idx from [batch_size, max_seq_len] to [batch_size, max_seq_len, d]
        seq_indices = next_nonzero_idx.unsqueeze(-1).expand(-1, -1, d)
        encoded_backfilled = torch.gather(encoded_padded, dim=1, index=seq_indices)
        encoded_backfilled = torch.nn.functional.pad(
            encoded_backfilled, (0, 0, 0, 1 if encoded_backfilled.shape[1] % 2 == 1 else 0)
        )

        encoded_resized = torch.cat([encoded_backfilled[:, 0::2], encoded_backfilled[:, 1::2]], dim=-1)

        # Calculate distance to next non-zero column
        num_frames_full = (next_nonzero_idx.float() - indices.float()).clamp(min=0, max=max_seq_len - 1).long()

        # For positions at or after seq_len, set num_frames to 0
        num_frames_full = torch.where(position_mask, num_frames_full, torch.zeros_like(num_frames_full))

        # Resize to match encoded_resized shape by taking every other element
        num_frames = num_frames_full[:, 0::2] // 2

        return encoded_resized, num_frames

    @property
    def higgs_tokenizer(self):
        if not hasattr(self, "_higgs_tokenizer"):
            self._higgs_tokenizer = load_higgs_audio_tokenizer(
                "bosonai/higgs-audio-v2-tokenizer",
                device=self.device,
            )
            for param in self._higgs_tokenizer.parameters():
                param.requires_grad = False
            self._higgs_tokenizer.eval()
        return self._higgs_tokenizer

    def generate(
        self,
        encoded_expanded: torch.Tensor,
        **kwargs,
    ) -> torch.Tensor:
        encoded_padded = torch.nn.functional.pad(
            encoded_expanded, (0, 0, 0, 1 if encoded_expanded.shape[1] % 2 == 1 else 0)
        )
        seq_len = torch.tensor([encoded_expanded.shape[1]] * encoded_expanded.shape[0], device=encoded_expanded.device)
        encoded_resized, num_frames = self.backfill_sparse_encoding(encoded_expanded, seq_len)
        encoded_padded = torch.nn.functional.pad(encoded_resized, (0, 0, 0, self.config.num_codebooks - 1))
        num_frames = torch.nn.functional.pad(num_frames, (0, self.config.num_codebooks - 1))
        generation_length = encoded_padded.shape[1]
        generated_tokens = self._generate(
            input_ids=torch.zeros(
                encoded_padded.shape[0], 1, self.config.num_codebooks, device=self.device, dtype=torch.long
            ),
            encoded_expanded=encoded_padded,
            num_frames=num_frames,
            max_new_tokens=generation_length,
            do_sample=True,
            generation_config=GenerationConfig(
                eos_token_id=1025,
                pad_token_id=1025,
                max_new_tokens=generation_length,
                do_sample=True,
                temperature=1.0,
                top_k=20,
            ),
        )
        unshifted_tokens = torch.stack(
            [
                generated_tokens[:, i : generated_tokens.shape[1] - self.config.num_codebooks + i + 1, i]
                for i in range(self.config.num_codebooks)
            ],
            dim=-1,
        )
        audio = self.higgs_tokenizer.decode(unshifted_tokens.transpose(2, 1).clamp(max=self.config.vocab_size - 1))
        return torch.from_numpy(audio).to(self.device)
