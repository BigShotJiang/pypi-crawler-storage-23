"""A Singer tap for Postgres, built with the Meltano SDK."""
