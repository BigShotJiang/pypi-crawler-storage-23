"""Lead time analysis — supplier reliability from receiving history.

TODO: Implement lead time analytics:
    - Compute actual vs. promised lead times from receiving records
    - Distribution fitting (mean, std, percentiles)
    - Supplier reliability scoring
    - Lead time variability impact on safety stock

Planned backends:
    - builtin: Descriptive statistics from receiving history
    - scipy: Distribution fitting (normal, lognormal, gamma) via scipy.stats

Usage (planned):
    from platoon.learning.providers import get_provider
    lt = get_provider("leadtime")
    result = lt.analyze(receiving_history, supplier_id="SUP-001")
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List

from platoon.learning.providers import ModelProvider, register_provider


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class LeadTimeResult:
    """Output of lead time analysis."""

    mean_days: float
    std_days: float
    percentiles: Dict[str, float]  # {"p50": 5.0, "p90": 8.0, "p95": 10.0}
    reliability_score: float  # 0-1, fraction of deliveries within promised window


# ---------------------------------------------------------------------------
# Provider stubs
# ---------------------------------------------------------------------------


@register_provider
class BuiltinLeadTimeProvider(ModelProvider):
    """Descriptive lead time analysis — basic statistics from receiving history.

    TODO: Implement analyze() with mean/std/percentile calculation.
    """

    name = "builtin_leadtime"
    domain = "leadtime"
    backend = "builtin"

    def analyze(self, receiving_history: List[Dict], supplier_id: str = None, **kwargs) -> LeadTimeResult:
        """Analyze lead time reliability from receiving records."""
        raise NotImplementedError("builtin lead time provider not yet implemented")


@register_provider
class ScipyLeadTimeProvider(ModelProvider):
    """Distribution-fitted lead time analysis via scipy.stats.

    TODO: Implement analyze() with best-fit distribution selection.
    Requires: scipy
    """

    name = "scipy_leadtime"
    domain = "leadtime"
    backend = "scipy"

    @classmethod
    def is_available(cls) -> bool:
        try:
            import scipy  # noqa: F401
            return True
        except ImportError:
            return False

    def analyze(self, receiving_history: List[Dict], supplier_id: str = None, **kwargs) -> LeadTimeResult:
        """Analyze lead time with distribution fitting."""
        raise NotImplementedError("scipy lead time provider not yet implemented")
