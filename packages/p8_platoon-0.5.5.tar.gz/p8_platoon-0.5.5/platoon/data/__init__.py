"""Data infrastructure for platoon.

Provides the pipeline framework for syncing data from external sources
(Shopify, etc.) into standard Pydantic schema and percolate-compatible storage.

Key concepts:
    - DataProvider: Base class for all data source integrations
    - SyncState: Watermark tracking for incremental syncs
    - Pipeline: Orchestrates Source → Transform → Sink per tenant/integration
    - Schema: Standard Pydantic models for commerce entities (products, orders, etc.)
"""

from platoon.data.pipeline import Pipeline, SyncState, SyncSummary
from platoon.data.provider import DataProvider, DataProviderResult

__all__ = [
    "DataProvider",
    "DataProviderResult",
    "Pipeline",
    "SyncState",
    "SyncSummary",
]
