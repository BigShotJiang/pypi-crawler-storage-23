from labchain.plugins.filters.classification.knn import *  # noqa: F403
from labchain.plugins.filters.classification.svm import *  # noqa: F403
