from textanalyzer import analyze_text, sentiment_scores

def test_basic():
    text = "Hello world! How are you? I'm fine."
    stats = analyze_text(text)
    assert stats['chars'] == len(text)
    assert stats['words'] == 7
    assert stats['sentences'] == 3
    print("基础统计测试通过")

def test_sentiment():
    text = "I love this project! It's amazing."
    scores = sentiment_scores(text)
    assert scores['compound'] > 0
    print("情感分析测试通过")

if __name__ == "__main__":
    test_basic()
    test_sentiment()