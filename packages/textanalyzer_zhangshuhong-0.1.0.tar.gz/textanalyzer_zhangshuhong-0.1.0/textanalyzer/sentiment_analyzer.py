from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

def sentiment_scores(text: str) -> dict:
    analyzer = SentimentIntensityAnalyzer()
    return analyzer.polarity_scores(text)

def sentiment_label(text: str) -> str:
    scores = sentiment_scores(text)
    compound = scores['compound']
    if compound >= 0.05:
        return 'Positive'
    elif compound <= -0.05:
        return 'Negative'
    else:
        return 'Neutral'