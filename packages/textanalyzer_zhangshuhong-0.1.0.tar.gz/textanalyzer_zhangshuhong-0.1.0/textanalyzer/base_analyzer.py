def count_chars(text: str) -> int:
    return len(text)

def count_words(text: str) -> int:
    return len(text.split())

def count_sentences(text: str) -> int:
    for punc in '!?':
        text = text.replace(punc, '.')
    sentences = [s for s in text.split('.') if s.strip() != '']
    return len(sentences)

def analyze_text(text: str) -> dict:
    return {
        'chars': count_chars(text),
        'words': count_words(text),
        'sentences': count_sentences(text)
    }