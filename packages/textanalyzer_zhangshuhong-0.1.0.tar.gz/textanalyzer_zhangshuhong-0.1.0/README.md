# textanalyzer
A simple text analysis library.