"""Veld — contract-first, multi-stack API code generator."""

__version__ = "0.2.0"

