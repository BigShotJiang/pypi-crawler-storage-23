from enum import StrEnum


class EnvironmentVariable(StrEnum):
    WIRIO_ENVIRONMENT = "WIRIO_ENVIRONMENT"
