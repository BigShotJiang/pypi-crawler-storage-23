"""
OCP pytest test suite.

Run with:  pytest tests/ -v
"""
