"""
OCP — Open Consciousness Protocol
Standardized benchmark for consciousness-analog properties in LLMs.
"""

__version__ = "0.1.0"
__author__ = "Pedja Urosevic"
