import os
import platform

import requests
import json

from parfive import Downloader
from tqdm import tqdm
from datetime import datetime


def get_version_meta(version: str) -> MinecraftVersionMeta:
    url = "https://piston-meta.mojang.com/mc/game/version_manifest.json"
    data = requests.get(url).json()

    for version_meta in data["versions"]:
        if version_meta["id"] == version:
            return MinecraftVersionMeta(version_meta)

    raise MinecraftVersionNotFoundError


def get_sys() -> str:
    sys_name = platform.system().lower()
    if sys_name == "darwin":
        return "osx"
    return sys_name


class SimpleLogger:
    def __init__(self, name, proj_name: str):
        self.name = name
        self.proj_name = proj_name

    def gen_log(self, message, color: str) -> str:
        current_time = datetime.now().strftime("%H:%M:%S")
        return f"\033[0;34m[{current_time}] {color}[%s/{self.name}] \033[0;36m({self.proj_name}) \033[0m{message}"

    def debug(self, message) -> None:
        print(self.gen_log(message, "\033[0;37m") % "DEBUG")

    def info(self, message) -> None:
        print(self.gen_log(message, "\033[0;32m") % "INFO")

    def warning(self, message) -> None:
        print(self.gen_log(message, "\033[0;33m") % "WARNING")

    def error(self, message) -> None:
        print(self.gen_log(message, "\033[0;31m") % "ERROR")

    def critical(self, message) -> None:
        print(self.gen_log(message, "\033[1;31m") % "CRITICAL")


logger = SimpleLogger("main", "MinecraftDownloader")


class MinecraftVersionNotFoundError(Exception):
    pass


class MinecraftVersionDownloader:
    def __init__(self, meta: MinecraftVersionMeta, version_name: str):
        self.response = requests.get(meta.url).json()
        self.version_name = version_name

    @staticmethod
    def should_download(lib_info: dict, os_type: str) -> bool:
        try:
            if lib_info["rules"][0]["os"]["name"] == os_type:
                return True
            return False
        except KeyError:
            return True

    def download_index(self, index_folder: str) -> None:
        url = self.response["assetIndex"]["url"]
        resp = requests.get(url).json()

        os.makedirs(index_folder, exist_ok=True)

        with open(f"{index_folder}/{self.response["assets"]}.json", "w") as f:
            f.write(json.dumps(resp))

    def download_libs(self, os_type: str, lib_folder: str) -> None:
        dl = Downloader(max_conn=16, max_splits=24, progress=False, overwrite=True)

        for lib in tqdm(self.response["libraries"], desc="Collecting Libraries"):
            if self.should_download(lib, os_type):
                url = lib["downloads"]["artifact"]["url"]

                file_path = lib["downloads"]["artifact"]["path"]

                path = lib_folder + "/" + "/".join(file_path.split("/")[:-1])
                name = file_path.split("/")[-1]

                dl.enqueue_file(url=url, path=path, filename=name)

        logger.info("Downloading Libraries")

        logger.info("Done!\nFailed: " + str(dl.download().errors))

    def download_assets(self, asset_folder: str) -> None:
        url = self.response["assetIndex"]["url"]
        resp = requests.get(url).json()

        dl = Downloader(max_conn=48, max_splits=8, progress=False, overwrite=True)

        for value in tqdm(resp["objects"].values(), desc="Collecting Assets"):
            file_url = f"https://resources.download.minecraft.net/{value["hash"][:2]}/{value["hash"]}"
            file_path = f"{asset_folder}/{value["hash"][:2]}/"

            dl.enqueue_file(url=file_url, path=file_path, filename=value["hash"])

        logger.info("Downloading Assets (It will take a few minutes)")

        logger.info("Done!\nFailed: " + str(dl.download().errors))

    def download_version_json(self, version_folder: str) -> None:
        with open(f"{version_folder}/{self.version_name}.json", "w") as f:
            f.write(json.dumps(self.response))

    def download_client(self, version_folder: str) -> None:
        url = self.response["downloads"]["client"]["url"]
        logger.info("Downloading Client")
        resp = requests.get(url).content

        with open(f"{version_folder}/{self.version_name}.jar", "wb") as f:
            f.write(resp)

        logger.info("Done!")

    def download(self) -> None:
        logger.info("Downloading Minecraft")

        os.makedirs(f"./.minecraft/versions/{self.version_name}", exist_ok=True)

        self.download_client(f"./.minecraft/versions/{self.version_name}")  # 下载版本
        self.download_version_json(f"./.minecraft/versions/{self.version_name}")  # 下载版本Json文件

        self.download_assets("./.minecraft/assets/objects")  # 下载 assets
        self.download_index("./.minecraft/assets/indexes")  # 下载 index

        self.download_libs(get_sys(), "./.minecraft/libraries")  # 下载 libs


class MinecraftVersionMeta:
    def __init__(self, meta: dict):
        self.meta = meta
        self.url = meta["url"]

    def print(self) -> None:
        print(f"Minecraft {self.meta["id"]} ({self.meta["type"]}) Url: {self.meta['url']}")
