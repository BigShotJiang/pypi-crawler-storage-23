from unittest import TestCase

from src.mcdownloader import get_sys
from src.mcdownloader.mcdl import SimpleLogger


class Test(TestCase):
    def test_get_version_meta(self):
        pass

    def test_get_sys(self):
        if get_sys() not in ["windows", "linux", "osx"]:
            self.fail()

    def test_simple_logger(self):
        try:
            logger = SimpleLogger("test", "mcdl")
            logger.debug("test")
        except Exception as e:
            self.fail(e)

    def test_minecraft_version_not_found_error(self):
        pass

    def test_minecraft_version_downloader(self):
        pass

    def test_minecraft_version_meta(self):
        pass
