# MCDL

a simple game downloader for [Minecraft](https://www.minecraft.net/)

## Install

```commandline
pip install mcdl
```

## How to use?

```python
# Example: download Minecraft 1.21.11
from mcdl import get_version_meta, MinecraftVersionDownloader

# create downloader
downloader = MinecraftVersionDownloader(get_version_meta("1.21.11"), "version-name")

# download
downloader.download()
```