"""Long-Term Memory System for AI assistants."""

__version__ = "0.6.0"
