"""Setup script for actus-jax package.

This file is kept for backward compatibility with older tools.
The main configuration is in pyproject.toml.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
