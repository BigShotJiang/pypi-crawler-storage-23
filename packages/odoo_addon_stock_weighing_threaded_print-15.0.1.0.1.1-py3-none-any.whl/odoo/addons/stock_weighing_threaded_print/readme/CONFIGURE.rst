The default behavior is to **print in main thread**, but it can be configured by
following these steps:

* Activate developer mode.
* Go to *Settings > Technical > Parameters > System Parameters*.
* Create a **stock_weighing_threaded_print.print_in_new_thread** key.
