This module is aimed to speed up the label printing process by returning the control of
the user's screen and triggering the printing in a background process. If something goes
wrong, the user is informed with a notification that can be used to retry the process.
