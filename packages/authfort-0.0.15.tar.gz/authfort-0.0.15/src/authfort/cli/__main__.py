"""Allow running ``python -m authfort.cli``."""

from authfort.cli import main

main()
