"""SSO CLI - Keycloak auth tool"""

from .auth import SSOAuthenticator

__all__ = ["SSOAuthenticator"]

