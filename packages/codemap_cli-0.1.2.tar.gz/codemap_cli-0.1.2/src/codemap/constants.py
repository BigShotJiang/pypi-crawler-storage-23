GLOBAL_IGNORE = [
    ".git",
    ".idea",
    ".vscode",
]

GLOBAL_HIDDEN_FILES = [
    ".env",
    ".env.local",
    ".env.production",
]