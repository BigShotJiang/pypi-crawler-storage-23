This modules implements an automatic redirection to the configured OAuth
provider login page, if there is one and only one enabled. This
effectively makes the regular Odoo login screen invisible in normal
circumstances.
