# ArticleAlpha Python Client

The official Python wrapper for the [ArticleAlpha](https://articlealpha.com) API. 

ArticleAlpha tracks investor curiosity by monitoring Wikipedia pageview trends for thousands of global stocks. This library allows data scientists and analysts to pull that "Attention Data" directly into Pandas for behavioral finance research.

## Installation

```bash
pip install articlealpha
```

### Usage

```python
from articlealpha import ArticleAlpha

# Get daily time-series for all stocks
df = ArticleAlpha.get_timeseries()
print(df.head())

# Get deep details for a specific ticker
nvda = ArticleAlpha.get_ticker_details("NVDA")
```

## Data Source & Attribution

This project utilizes data from the **Wikimedia Metrics API**.

- **Source:** [Wikimedia API](https://doc.wikimedia.org/generated-data-platform/aqs/analytics-api/concepts/page-views.html)
- **Trademark Notice:** Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc. ArticleAlpha is an independent project and is not affiliated with or endorsed by the Wikimedia Foundation.

## Disclaimer
This data is for informational purposes only. ArticleAlpha does not provide investment advice. Wikipedia pageviews represent public interest and curiosity, which may or may not correlate with market performance.

## License
MIT
