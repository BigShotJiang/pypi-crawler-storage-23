import pandas as pd
import requests
import io

class ArticleAlpha:
    """Client for the ArticleAlpha Market Attention API."""
    
    BASE_URL = "https://articlealpha.com/api/v1"
    
    HEADERS = {
        "User-Agent": "ArticleAlpha-Client/0.1 (Mozilla/5.0 compatible; DataScience/1.0)"
    }

    @classmethod
    def _fetch(cls, endpoint):
        """Internal helper to fetch URL with proper headers."""
        url = f"{cls.BASE_URL}{endpoint}"
        response = requests.get(url, headers=cls.HEADERS)
        
        if response.status_code == 403:
            raise ConnectionError(
                "403 Forbidden"
                "The server might be under high load or blocking scripts."
            )
        elif response.status_code != 200:
            raise ConnectionError(f"API Error {response.status_code}: {url}")
            
        return response

    @classmethod
    def get_timeseries(cls):
        """
        Fetches the bulk daily time-series for all tracked stocks.
        Returns:
            pd.DataFrame: Columns [Ticker, Date, Raw Views, Smoothed Views, Baseline, Multiplier, Edits]
        """
        try:
            # 1. Fetch raw CSV text with headers
            response = cls._fetch("/market/timeseries.csv")
            
            # 2. Parse string into DataFrame
            df = pd.read_csv(io.StringIO(response.text))
            
            if 'Date' in df.columns:
                df['Date'] = pd.to_datetime(df['Date'])
            return df
            
        except Exception as e:
            raise ConnectionError(f"Failed to fetch data from ArticleAlpha API: {e}")

    @classmethod
    def get_summary(cls):
        """
        Fetches the latest market snapshot/heatmap data.
        Returns:
            pd.DataFrame: Latest metrics for all symbols.
        """
        try:
            response = cls._fetch("/market/summary.json")
            return pd.DataFrame(response.json())
        except Exception as e:
            raise ConnectionError(f"Failed to fetch summary from ArticleAlpha API: {e}")

    @classmethod
    def get_ticker_details(cls, symbol):
        """
        Fetches deep metadata and related pages for a specific stock.
        Args:
            symbol (str): The stock ticker (e.g., 'AAPL')
        """
        try:
            response = cls._fetch(f"/ticker/{symbol.upper()}.json")
            return response.json()
        except:
            return None
