"""Tests for teckel.otel.processor.TeckelSpanProcessor."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

try:
    import opentelemetry.sdk.trace  # noqa: F401

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False

pytestmark = pytest.mark.skipif(not HAS_OTEL, reason="opentelemetry-sdk not installed")


# ---------------------------------------------------------------------------
# Fake span helpers (matching OTel ReadableSpan interface)
# ---------------------------------------------------------------------------


class _FakeSpanContext:
    def __init__(self, trace_id: int, span_id: int):
        self.trace_id = trace_id
        self.span_id = span_id


class _FakeStatus:
    def __init__(self, code_value: int = 1):
        self.status_code = type("StatusCode", (), {"value": code_value})()
        self.description = None


class _FakeSpan:
    def __init__(
        self,
        name: str,
        attributes: dict[str, Any] | None = None,
        trace_id: int = 0x1234567890ABCDEF1234567890ABCDEF,
        span_id: int = 0x1234567890ABCDEF,
        parent: _FakeSpanContext | None = None,
        start_time: int = 1700000000_000_000_000,
        end_time: int = 1700000001_000_000_000,
    ):
        self.name = name
        self.attributes = attributes or {}
        self.context = _FakeSpanContext(trace_id, span_id)
        self.parent = parent
        self.start_time = start_time
        self.end_time = end_time
        self.status = _FakeStatus()


class TestTeckelSpanProcessor:
    @patch("teckel.otel.processor.TeckelTracer")
    def test_buffers_non_root_spans(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")

        # Send a child span (not root)
        child = _FakeSpan(
            name="ai.generateText.doGenerate",
            attributes={"gen_ai.request.model": "gpt-5"},
        )
        processor.on_end(child)

        # Tracer.trace should NOT have been called yet
        mock_tracer_cls.return_value.trace.assert_not_called()
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_sends_on_root_span(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        mock_tracer = mock_tracer_cls.return_value

        trace_id = 0x1234567890ABCDEF1234567890ABCDEF

        # Send child span first
        child = _FakeSpan(
            name="ai.generateText.doGenerate",
            trace_id=trace_id,
            span_id=0xAAAABBBBCCCCDDDD,
            attributes={
                "gen_ai.request.model": "gpt-5",
                "gen_ai.usage.input_tokens": 100,
                "gen_ai.usage.output_tokens": 50,
            },
        )
        processor.on_end(child)

        # Send root span
        root = _FakeSpan(
            name="ai.generateText",
            trace_id=trace_id,
            span_id=0x1111222233334444,
            attributes={
                "ai.prompt.messages": json.dumps([
                    {"role": "system", "content": "You are helpful"},
                    {"role": "user", "content": "Hello"},
                ]),
                "ai.response.text": "Hi there!",
                "ai.telemetry.functionId": "my-chatbot",
                "ai.telemetry.metadata.sessionId": "session-123",
                "ai.telemetry.metadata.userId": "user-456",
            },
        )
        processor.on_end(root)

        # Verify trace was sent
        mock_tracer.trace.assert_called_once()
        call_args = mock_tracer.trace.call_args[0][0]
        assert call_args["query"] == "Hello"
        assert call_args["response"] == "Hi there!"
        assert call_args["agentName"] == "my-chatbot"
        assert call_args["sessionId"] == "session-123"
        assert call_args["userId"] == "user-456"
        assert call_args["systemPrompt"] == "You are helpful"
        assert len(call_args["spans"]) == 2
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_stream_text_is_root(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        mock_tracer = mock_tracer_cls.return_value

        root = _FakeSpan(
            name="ai.streamText",
            attributes={
                "ai.prompt": "What is AI?",
                "ai.response.text": "AI is...",
            },
        )
        processor.on_end(root)
        mock_tracer.trace.assert_called_once()
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_generate_object_is_root(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        mock_tracer = mock_tracer_cls.return_value

        root = _FakeSpan(
            name="ai.generateObject",
            attributes={
                "ai.prompt": "Generate JSON",
                "ai.response.text": '{"result": true}',
            },
        )
        processor.on_end(root)
        mock_tracer.trace.assert_called_once()
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_evicts_oldest_on_capacity(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import MAX_PENDING_TRACES, TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")

        # Fill to capacity with non-root spans (each with unique trace ID)
        for i in range(MAX_PENDING_TRACES):
            span = _FakeSpan(
                name="ai.generateText.doGenerate",
                trace_id=i + 1,
                span_id=i + 1,
            )
            processor.on_end(span)

        assert len(processor._pending) == MAX_PENDING_TRACES

        # One more should evict the oldest
        span = _FakeSpan(
            name="ai.generateText.doGenerate",
            trace_id=MAX_PENDING_TRACES + 1,
            span_id=MAX_PENDING_TRACES + 1,
        )
        processor.on_end(span)

        assert len(processor._pending) == MAX_PENDING_TRACES
        # First trace should be evicted
        first_key = format(1, "032x")
        assert first_key not in processor._pending
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_on_start_is_noop(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        processor.on_start(MagicMock())  # Should not raise
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_force_flush(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        processor.force_flush()
        mock_tracer_cls.return_value.flush.assert_called_once()
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_extracts_tokens(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        mock_tracer = mock_tracer_cls.return_value

        trace_id = 0xAAAABBBBCCCCDDDDEEEEFFFF00001111

        # LLM call with tokens
        child = _FakeSpan(
            name="ai.generateText.doGenerate",
            trace_id=trace_id,
            span_id=0x1111,
            attributes={
                "gen_ai.usage.input_tokens": 200,
                "gen_ai.usage.output_tokens": 100,
            },
        )
        processor.on_end(child)

        # Root span
        root = _FakeSpan(
            name="ai.generateText",
            trace_id=trace_id,
            span_id=0x2222,
            attributes={
                "ai.prompt": "Hello",
                "ai.response.text": "Hi",
            },
        )
        processor.on_end(root)

        call_args = mock_tracer.trace.call_args[0][0]
        assert call_args["tokens"]["prompt"] == 200
        assert call_args["tokens"]["completion"] == 100
        assert call_args["tokens"]["total"] == 300
        processor.shutdown()

    @patch("teckel.otel.processor.TeckelTracer")
    def test_metadata_extraction(self, mock_tracer_cls: MagicMock):
        from teckel.otel.processor import TeckelSpanProcessor

        processor = TeckelSpanProcessor(api_key="tk_live_test123456789012345678")
        mock_tracer = mock_tracer_cls.return_value

        root = _FakeSpan(
            name="ai.generateText",
            attributes={
                "ai.prompt": "Test",
                "ai.response.text": "Response",
                "ai.telemetry.metadata.customField": "custom_value",
                "ai.telemetry.metadata.sessionId": "sess",
                "ai.telemetry.metadata.userId": "usr",
            },
        )
        processor.on_end(root)

        call_args = mock_tracer.trace.call_args[0][0]
        assert call_args["metadata"] == {"customField": "custom_value"}
        assert call_args["sessionId"] == "sess"
        assert call_args["userId"] == "usr"
        processor.shutdown()
