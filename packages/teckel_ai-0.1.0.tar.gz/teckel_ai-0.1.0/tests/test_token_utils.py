"""Tests for token aggregation utility."""

from teckel._token_utils import calculate_tokens_from_spans
from teckel.models import SpanData


def _span(**kwargs) -> SpanData:
    defaults = {"name": "test", "started_at": "2025-01-01T00:00:00Z"}
    defaults.update(kwargs)
    return SpanData(**defaults)


class TestCalculateTokensFromSpans:
    def test_aggregates_tokens(self):
        result = calculate_tokens_from_spans([
            _span(prompt_tokens=10, completion_tokens=20),
            _span(prompt_tokens=5, completion_tokens=15),
        ])
        assert result.prompt == 15
        assert result.completion == 35
        assert result.total == 50

    def test_returns_zeros_when_no_tokens(self):
        result = calculate_tokens_from_spans([_span()])
        assert result.prompt == 0
        assert result.completion == 0
        assert result.total == 0

    def test_handles_partial_tokens(self):
        result = calculate_tokens_from_spans([
            _span(prompt_tokens=10),
            _span(completion_tokens=20),
        ])
        assert result.prompt == 10
        assert result.completion == 20
        assert result.total == 30

    def test_empty_spans(self):
        result = calculate_tokens_from_spans([])
        assert result.total == 0
