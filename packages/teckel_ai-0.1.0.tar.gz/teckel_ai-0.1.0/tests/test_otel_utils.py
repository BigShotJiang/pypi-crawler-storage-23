"""Tests for teckel.otel._utils."""

from teckel.otel._utils import (
    convert_to_teckel_span,
    map_span_type,
    span_id_to_uuid,
    truncate_to_size,
)

# ---------------------------------------------------------------------------
# truncate_to_size
# ---------------------------------------------------------------------------


class TestTruncateToSize:
    def test_small_object_unchanged(self):
        obj = {"key": "value"}
        assert truncate_to_size(obj, 1000) == obj

    def test_large_dict_truncated(self):
        obj = {"data": "x" * 2000}
        result = truncate_to_size(obj, 100)
        assert result["_truncated"] is True
        assert "_originalSizeBytes" in result
        assert "_maxSizeBytes" in result
        assert result["_maxSizeBytes"] == 100
        assert "_preview" in result

    def test_large_list_keeps_fitting_items(self):
        items = [{"id": i, "data": "x" * 50} for i in range(100)]
        result = truncate_to_size(items, 500)
        assert result["_truncated"] is True
        assert result["_originalCount"] == 100
        assert result["_keptCount"] < 100
        assert len(result["items"]) == result["_keptCount"]

    def test_small_list_unchanged(self):
        items = [1, 2, 3]
        assert truncate_to_size(items, 1000) == items


# ---------------------------------------------------------------------------
# map_span_type
# ---------------------------------------------------------------------------


class TestMapSpanType:
    def test_tool_call(self):
        assert map_span_type("ai.toolCall") == "tool_call"

    def test_do_generate(self):
        assert map_span_type("ai.generateText.doGenerate") == "llm_call"

    def test_do_stream(self):
        assert map_span_type("ai.streamText.doStream") == "llm_call"

    def test_generate_text_root(self):
        assert map_span_type("ai.generateText") == "agent"

    def test_stream_text_root(self):
        assert map_span_type("ai.streamText") == "agent"

    def test_generate_object_root(self):
        assert map_span_type("ai.generateObject") == "agent"

    def test_unknown(self):
        assert map_span_type("something.else") == "custom"


# ---------------------------------------------------------------------------
# span_id_to_uuid
# ---------------------------------------------------------------------------


class TestSpanIdToUuid:
    def test_16_char_hex(self):
        result = span_id_to_uuid("1234567890abcdef")
        assert result == "12345678-90ab-cdef-0000-000000000000"

    def test_short_padded(self):
        result = span_id_to_uuid("abc")
        assert result.startswith("abc00000-")
        assert len(result) == 36  # Standard UUID length

    def test_valid_uuid_format(self):
        result = span_id_to_uuid("fedcba9876543210")
        parts = result.split("-")
        assert len(parts) == 5
        assert len(parts[0]) == 8
        assert len(parts[1]) == 4
        assert len(parts[2]) == 4
        assert len(parts[3]) == 4
        assert len(parts[4]) == 12


# ---------------------------------------------------------------------------
# convert_to_teckel_span
# ---------------------------------------------------------------------------


class _FakeSpanContext:
    def __init__(self, trace_id: int, span_id: int):
        self.trace_id = trace_id
        self.span_id = span_id


class _FakeStatus:
    def __init__(self, code_value: int = 1, description: str | None = None):
        self.status_code = type("StatusCode", (), {"value": code_value})()
        self.description = description


class _FakeSpan:
    """Mimics OTel ReadableSpan interface."""

    def __init__(
        self,
        name: str = "ai.generateText.doGenerate",
        attributes: dict | None = None,
        span_id: int = 0x1234567890ABCDEF,
        trace_id: int = 0x1234567890ABCDEF1234567890ABCDEF,
        parent: _FakeSpanContext | None = None,
        start_time: int = 1700000000_000_000_000,  # nanoseconds
        end_time: int = 1700000001_000_000_000,
        status: _FakeStatus | None = None,
    ):
        self.name = name
        self.attributes = attributes or {}
        self.context = _FakeSpanContext(trace_id, span_id)
        self.parent = parent
        self.start_time = start_time
        self.end_time = end_time
        self.status = status or _FakeStatus()


class TestConvertToTeckelSpan:
    def test_basic_llm_call(self):
        span = _FakeSpan(
            name="ai.generateText.doGenerate",
            attributes={
                "gen_ai.request.model": "gpt-5",
                "gen_ai.usage.input_tokens": 100,
                "gen_ai.usage.output_tokens": 50,
            },
        )
        result = convert_to_teckel_span(span)
        assert result["type"] == "llm_call"
        assert result["model"] == "gpt-5"
        assert result["promptTokens"] == 100
        assert result["completionTokens"] == 50
        assert result["durationMs"] == 1000
        assert result["status"] == "completed"
        assert "spanId" in result

    def test_tool_call(self):
        span = _FakeSpan(
            name="ai.toolCall",
            attributes={
                "ai.toolCall.name": "get_weather",
                "ai.toolCall.args": '{"city": "NYC"}',
                "ai.toolCall.result": '{"temp": 72}',
            },
        )
        result = convert_to_teckel_span(span)
        assert result["type"] == "tool_call"
        assert result["toolName"] == "get_weather"
        assert result["toolArguments"] == {"city": "NYC"}
        assert result["toolResult"] == {"temp": 72}

    def test_tool_call_array_result_wrapped(self):
        span = _FakeSpan(
            name="ai.toolCall",
            attributes={
                "ai.toolCall.name": "search",
                "ai.toolCall.result": '[1, 2, 3]',
            },
        )
        result = convert_to_teckel_span(span)
        assert result["toolResult"] == {"items": [1, 2, 3]}

    def test_agent_with_response(self):
        span = _FakeSpan(
            name="ai.generateText",
            attributes={
                "ai.response.text": "Hello world",
                "gen_ai.request.model": "gpt-5",
            },
        )
        result = convert_to_teckel_span(span)
        assert result["type"] == "agent"
        assert result["output"] == {"text": "Hello world"}

    def test_error_status(self):
        span = _FakeSpan(
            status=_FakeStatus(code_value=2, description="Something went wrong"),
        )
        result = convert_to_teckel_span(span)
        assert result["status"] == "error"
        assert result["statusMessage"] == "Something went wrong"

    def test_parent_span_id(self):
        parent_ctx = _FakeSpanContext(
            trace_id=0x1234567890ABCDEF1234567890ABCDEF,
            span_id=0xFEDCBA9876543210,
        )
        span = _FakeSpan(parent=parent_ctx)
        result = convert_to_teckel_span(span)
        assert "parentSpanId" in result

    def test_extra_attributes_in_metadata(self):
        span = _FakeSpan(
            name="ai.generateText.doGenerate",
            attributes={
                "gen_ai.request.model": "gpt-5",
                "custom.field": "value",
                "another.field": 42,
            },
        )
        result = convert_to_teckel_span(span)
        assert result["metadata"]["custom.field"] == "value"
        assert result["metadata"]["another.field"] == 42
        # Model-related keys should not be in metadata
        assert "gen_ai.request.model" not in result.get("metadata", {})

    def test_iso_timestamps(self):
        span = _FakeSpan()
        result = convert_to_teckel_span(span)
        assert "startedAt" in result
        assert "endedAt" in result
        # Should be valid ISO format
        assert "T" in result["startedAt"]
        assert "T" in result["endedAt"]

    def test_invalid_tool_args_json(self):
        span = _FakeSpan(
            name="ai.toolCall",
            attributes={
                "ai.toolCall.name": "test",
                "ai.toolCall.args": "not-json{{{",
            },
        )
        result = convert_to_teckel_span(span)
        assert "raw" in result["toolArguments"]
