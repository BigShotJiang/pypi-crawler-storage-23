"""Tests for Pydantic models -- mirrors Zod schema tests from tracer.test.ts."""

import pytest
from pydantic import ValidationError

from teckel.models import (
    BatchConfig,
    Document,
    FeedbackData,
    FeedbackType,
    SpanData,
    SpanType,
    TraceData,
)


class TestTraceData:
    def test_valid_minimal(self):
        t = TraceData(query="What is the weather?", response="The weather is sunny.")
        assert t.query == "What is the weather?"

    def test_rejects_empty_query(self):
        with pytest.raises(ValidationError, match="query"):
            TraceData(query="", response="Some response")

    def test_rejects_empty_response(self):
        with pytest.raises(ValidationError, match="response"):
            TraceData(query="Some query", response="")

    def test_accepts_optional_fields(self):
        t = TraceData(
            query="Hello",
            response="Hi",
            model="gpt-5-nano",
            latency_ms=150,
            session_id="session-123",
            user_id="user-456",
            metadata={"source": "test"},
        )
        assert t.model == "gpt-5-nano"
        assert t.latency_ms == 150
        assert t.session_id == "session-123"

    def test_accepts_camel_case_aliases(self):
        t = TraceData(
            query="Hello",
            response="Hi",
            latencyMs=150,
            sessionId="session-123",
            agentName="my-agent",
        )
        assert t.latency_ms == 150
        assert t.session_id == "session-123"
        assert t.agent_name == "my-agent"

    def test_valid_documents(self):
        t = TraceData(
            query="Hello",
            response="Hi",
            documents=[Document(id="doc-1", name="Test", text="Content")],
        )
        assert len(t.documents) == 1

    def test_documents_all_optional_fields(self):
        t = TraceData(
            query="Hello",
            response="Hi",
            documents=[
                Document(
                    id="guide.md",
                    name="User Guide",
                    text="Content here...",
                    last_updated="2025-01-01T00:00:00Z",
                    url="https://example.com/guide",
                    source="confluence",
                    file_format="md",
                    similarity=0.95,
                    rank=0,
                    owner_email="owner@example.com",
                )
            ],
        )
        assert t.documents[0].id == "guide.md"
        assert t.documents[0].file_format == "md"

    def test_document_validates_email(self):
        with pytest.raises(ValidationError, match="ownerEmail"):
            Document(id="doc-1", name="Doc", text="content", owner_email="not-an-email")

    def test_document_validates_iso_datetime(self):
        with pytest.raises(ValidationError, match="lastUpdated"):
            Document(id="doc-1", name="Doc", text="content", last_updated="not-a-date")

    def test_rejects_invalid_document(self):
        with pytest.raises(ValidationError):
            TraceData(
                query="Hello",
                response="Hi",
                documents=[Document(id="", name="", text="")],
            )

    def test_rejects_too_many_documents(self):
        docs = [Document(id="d", name="n", text="t") for _ in range(16)]
        with pytest.raises(ValidationError, match="documents"):
            TraceData(query="Hello", response="Hi", documents=docs)

    def test_validates_trace_id_as_uuid(self):
        t = TraceData(
            query="Hello",
            response="Hi",
            trace_id="550e8400-e29b-41d4-a716-446655440000",
        )
        assert t.trace_id == "550e8400-e29b-41d4-a716-446655440000"

    def test_rejects_invalid_trace_id(self):
        with pytest.raises(ValidationError, match="UUID"):
            TraceData(query="Hello", response="Hi", trace_id="not-a-uuid")

    def test_validates_session_id_length(self):
        t = TraceData(query="Hello", response="Hi", session_id="a" * 200)
        assert len(t.session_id) == 200

        with pytest.raises(ValidationError):
            TraceData(query="Hello", response="Hi", session_id="a" * 201)

    def test_validates_metadata_size_limit(self):
        TraceData(query="Hello", response="Hi", metadata={"key": "value"})

        with pytest.raises(ValidationError, match="metadata exceeds 10KB limit"):
            TraceData(query="Hello", response="Hi", metadata={"data": "x" * 11_000})

    def test_rejects_oversized_payload(self):
        # 100 spans * ~25KB input each = ~2.5MB + docs/query/response = >3MB
        with pytest.raises(ValidationError, match="3MB limit"):
            TraceData(
                query="x" * 10_000,
                response="x" * 50_000,
                system_prompt="x" * 50_000,
                documents=[
                    Document(id="x" * 500, name="x" * 500, text="x" * 50_000)
                    for _ in range(15)
                ],
                spans=[
                    SpanData(
                        name=f"span-{i}",
                        started_at="2025-01-01T00:00:00Z",
                        input={"data": "x" * 25_000},
                    )
                    for i in range(100)
                ],
                metadata={"data": "x" * 9_000},
            )

    def test_accepts_large_valid_payload(self):
        # Within limits (under 3MB)
        TraceData(
            query="x" * 5_000,
            response="x" * 5_000,
            documents=[
                Document(id="doc", name="name", text="x" * 1_000) for _ in range(5)
            ],
        )


class TestSpanData:
    def test_tool_call_requires_tool_name(self):
        with pytest.raises(ValidationError, match="toolName"):
            SpanData(
                name="my-tool",
                type=SpanType.TOOL_CALL,
                started_at="2025-01-01T00:00:00Z",
            )

    def test_tool_call_with_tool_name(self):
        s = SpanData(
            name="my-tool",
            type=SpanType.TOOL_CALL,
            started_at="2025-01-01T00:00:00Z",
            tool_name="search",
        )
        assert s.tool_name == "search"

    def test_jsonb_size_limit(self):
        big = {"data": "x" * 600_000}
        with pytest.raises(ValidationError, match="512KB"):
            SpanData(
                name="test",
                started_at="2025-01-01T00:00:00Z",
                tool_arguments=big,
            )

    def test_started_at_requires_timezone_offset(self):
        with pytest.raises(ValidationError, match="startedAt"):
            SpanData(name="test", started_at="2025-01-01T00:00:00")

    def test_ended_at_requires_timezone_offset(self):
        with pytest.raises(ValidationError, match="endedAt"):
            SpanData(
                name="test",
                started_at="2025-01-01T00:00:00Z",
                ended_at="2025-01-01T00:00:01",
            )


class TestBatchConfig:
    def test_accepts_flush_interval_seconds(self):
        cfg = BatchConfig(flush_interval_s=0.25)
        assert cfg.flush_interval_s == 0.25


class TestFeedbackData:
    def test_valid_with_trace_id(self):
        fb = FeedbackData(
            trace_id="550e8400-e29b-41d4-a716-446655440000",
            type=FeedbackType.THUMBS_UP,
        )
        assert fb.type == FeedbackType.THUMBS_UP

    def test_valid_with_session_id(self):
        fb = FeedbackData(session_id="session-123", type=FeedbackType.THUMBS_DOWN)
        assert fb.session_id == "session-123"

    def test_all_feedback_types(self):
        for ft in FeedbackType:
            FeedbackData(
                trace_id="550e8400-e29b-41d4-a716-446655440000", type=ft
            )

    def test_rejects_invalid_type(self):
        with pytest.raises(ValidationError):
            FeedbackData(
                trace_id="550e8400-e29b-41d4-a716-446655440000", type="invalid"
            )

    def test_requires_target(self):
        with pytest.raises(ValidationError, match="traceId or sessionId"):
            FeedbackData(type=FeedbackType.THUMBS_UP)

    def test_optional_comment(self):
        fb = FeedbackData(
            trace_id="550e8400-e29b-41d4-a716-446655440000",
            type=FeedbackType.THUMBS_DOWN,
            comment="Not helpful",
        )
        assert fb.comment == "Not helpful"

    def test_optional_value(self):
        fb = FeedbackData(
            trace_id="550e8400-e29b-41d4-a716-446655440000",
            type=FeedbackType.RATING,
            value="5",
        )
        assert fb.value == "5"
