"""Tests for SendWorker."""

import time

import pytest

from teckel._worker import SendWorker


class TestSendWorker:
    def test_sequential_processing(self):
        results = []
        worker = SendWorker()

        worker.enqueue(lambda: results.append(1), "op1")
        worker.enqueue(lambda: results.append(2), "op2")
        worker.enqueue(lambda: results.append(3), "op3")

        worker.flush_with_timeout(2.0)
        assert results == [1, 2, 3]
        worker.shutdown()

    def test_flush_timeout(self):
        worker = SendWorker()

        worker.enqueue(lambda: time.sleep(5), "slow_op")

        result = worker.flush_with_timeout(0.1)
        assert result is False
        worker.shutdown(timeout_s=0.1)

    def test_flush_with_timeout_raises(self):
        worker = SendWorker()
        worker.enqueue(lambda: time.sleep(2), "slow_op")
        try:
            with pytest.raises(TimeoutError):
                worker.flush(timeout_s=0.05)
        finally:
            worker.shutdown(timeout_s=0.1)

    def test_error_routing(self):
        errors = []
        worker = SendWorker(on_error=lambda e: errors.append(e))

        def fail():
            raise ConnectionError("network down")

        worker.enqueue(fail, "failing_op")
        worker.flush_with_timeout(2.0)

        assert len(errors) == 1
        assert errors[0]["type"] == "network"
        assert "network down" in errors[0]["message"]
        worker.shutdown()

    def test_timeout_error_routing(self):
        errors = []
        worker = SendWorker(on_error=lambda e: errors.append(e))

        def timeout():
            raise TimeoutError("timed out waiting")

        worker.enqueue(timeout, "timeout_op")
        worker.flush_with_timeout(2.0)

        assert len(errors) == 1
        assert errors[0]["type"] == "timeout"
        worker.shutdown()
