"""Tests for TeckelTracer -- mirrors tracer.test.ts behavior."""

import json

import httpx
import pytest
import respx

from teckel import TeckelTracer

API = "https://app.teckel.ai/api"


def _mock_success():
    """Mock successful /sdk/traces and /sdk/feedback and /sdk/dropped."""
    respx.post(f"{API}/sdk/traces").mock(
        return_value=httpx.Response(200, json={"successCount": 1})
    )
    respx.post(f"{API}/sdk/feedback").mock(
        return_value=httpx.Response(200, json={"feedbackId": "fb-1"})
    )
    respx.post(f"{API}/sdk/dropped").mock(
        return_value=httpx.Response(200, json={})
    )


class TestInitialization:
    def test_valid_api_key(self):
        with TeckelTracer(api_key="tk_live_test123") as t:
            assert t is not None

    def test_invalid_api_key_format_warns(self, capsys):
        with TeckelTracer(api_key="invalid_key") as _:
            pass
        captured = capsys.readouterr()
        assert "Invalid API key format" in captured.err

    def test_empty_api_key_raises(self):
        with pytest.raises(ValueError, match="api_key is required"):
            TeckelTracer(api_key="")

    def test_invalid_endpoint_raises(self):
        with pytest.raises(ValueError, match="endpoint must be a valid URL"):
            TeckelTracer(api_key="tk_live_test123", endpoint="not-a-url")

    def test_invalid_timeout_raises(self):
        with pytest.raises(ValueError, match="timeout_s must be between 0 and 60 seconds"):
            TeckelTracer(api_key="tk_live_test123", timeout_s=0)

    @respx.mock
    def test_default_endpoint(self, valid_api_key, valid_trace):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace(valid_trace)
            t.flush(timeout_s=2.0)
        assert respx.calls.last.request.url.host == "app.teckel.ai"

    @respx.mock
    def test_custom_endpoint(self, valid_api_key, valid_trace):
        respx.post("https://custom.api.com/sdk/traces").mock(
            return_value=httpx.Response(200, json={"successCount": 1})
        )
        with TeckelTracer(api_key=valid_api_key, endpoint="https://custom.api.com") as t:
            t.trace(valid_trace)
            t.flush(timeout_s=2.0)
        assert respx.calls.last.request.url.host == "custom.api.com"


class TestTrace:
    @respx.mock
    def test_sends_required_fields(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({"query": "How do I reset my password?", "response": "Go to Settings..."})
            t.flush(timeout_s=2.0)

        body = json.loads(respx.calls[0].request.content)
        assert body["traces"][0]["query"] == "How do I reset my password?"

    @respx.mock
    def test_sends_all_optional_fields(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({
                "query": "test query",
                "response": "test response",
                "model": "gpt-5-nano",
                "latencyMs": 150,
                "sessionId": "session-123",
                "userId": "user@example.com",
                "traceId": "550e8400-e29b-41d4-a716-446655440000",
                "systemPrompt": "You are a helpful assistant",
                "tokens": {"prompt": 100, "completion": 50, "total": 150},
                "documents": [{"id": "doc-1", "name": "Test", "text": "Content"}],
                "metadata": {"source": "test"},
            })
            t.flush(timeout_s=2.0)

        body = json.loads(respx.calls[0].request.content)
        trace = body["traces"][0]
        assert trace["model"] == "gpt-5-nano"
        assert trace["sessionId"] == "session-123"
        assert trace["userId"] == "user@example.com"

    @respx.mock
    def test_includes_documents_with_camel_case(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({
                "query": "test",
                "response": "resp",
                "documents": [{
                    "id": "guide.md",
                    "name": "Password Guide",
                    "text": "To reset...",
                    "lastUpdated": "2025-01-15T10:00:00Z",
                    "url": "https://kb.example.com/guide",
                    "source": "confluence",
                    "fileFormat": "md",
                    "similarity": 0.92,
                    "rank": 0,
                    "ownerEmail": "author@example.com",
                }],
            })
            t.flush(timeout_s=2.0)

        body = json.loads(respx.calls[0].request.content)
        doc = body["traces"][0]["documents"][0]
        assert doc["id"] == "guide.md"
        assert doc["fileFormat"] == "md"
        assert doc["ownerEmail"] == "author@example.com"

    @respx.mock
    def test_auto_aggregates_tokens_from_spans(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({
                "query": "test",
                "response": "resp",
                "spans": [
                    {
                        "name": "llm1",
                        "startedAt": "2025-01-01T00:00:00Z",
                        "promptTokens": 100,
                        "completionTokens": 50,
                    },
                    {
                        "name": "llm2",
                        "startedAt": "2025-01-01T00:00:00Z",
                        "promptTokens": 200,
                        "completionTokens": 100,
                    },
                ],
            })
            t.flush(timeout_s=2.0)

        body = json.loads(respx.calls[0].request.content)
        tokens = body["traces"][0]["tokens"]
        assert tokens["prompt"] == 300
        assert tokens["completion"] == 150
        assert tokens["total"] == 450

    @respx.mock
    def test_does_not_override_explicit_tokens(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({
                "query": "test",
                "response": "resp",
                "tokens": {"prompt": 10, "completion": 5, "total": 15},
                "spans": [
                    {
                        "name": "llm",
                        "startedAt": "2025-01-01T00:00:00Z",
                        "promptTokens": 999,
                        "completionTokens": 999,
                    },
                ],
            })
            t.flush(timeout_s=2.0)

        body = json.loads(respx.calls[0].request.content)
        tokens = body["traces"][0]["tokens"]
        assert tokens["prompt"] == 10  # Not overridden


class TestFeedback:
    @respx.mock
    def test_sends_with_trace_id(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.feedback({
                "traceId": "550e8400-e29b-41d4-a716-446655440000",
                "type": "thumbs_up",
            })
            t.flush(timeout_s=2.0)

        # Find the feedback call
        fb_call = [c for c in respx.calls if "/sdk/feedback" in str(c.request.url)]
        assert len(fb_call) == 1
        body = json.loads(fb_call[0].request.content)
        assert body["type"] == "thumbs_up"

    @respx.mock
    def test_sends_with_session_id(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.feedback({
                "sessionId": "session-456",
                "type": "thumbs_down",
                "comment": "Not helpful",
            })
            t.flush(timeout_s=2.0)

        fb_call = [c for c in respx.calls if "/sdk/feedback" in str(c.request.url)]
        body = json.loads(fb_call[0].request.content)
        assert body["sessionId"] == "session-456"
        assert body["comment"] == "Not helpful"


class TestOnError:
    @respx.mock
    def test_fires_on_validation_failure(self, valid_api_key):
        _mock_success()
        errors = []
        with TeckelTracer(api_key=valid_api_key, on_error=lambda e: errors.append(e)) as t:
            t.trace({"query": "", "response": "valid"})

        assert len(errors) == 1
        assert errors[0].type == "validation"

    @respx.mock
    def test_fires_on_http_error(self, valid_api_key, valid_trace):
        respx.post(f"{API}/sdk/traces").mock(return_value=httpx.Response(401))
        respx.post(f"{API}/sdk/dropped").mock(return_value=httpx.Response(200, json={}))
        errors = []
        with TeckelTracer(api_key=valid_api_key, on_error=lambda e: errors.append(e)) as t:
            t.trace(valid_trace)
            try:
                t.flush(timeout_s=2.0)
            except Exception:
                pass

        http_errors = [e for e in errors if e.type == "http"]
        assert len(http_errors) >= 1


class TestFlush:
    @respx.mock
    def test_waits_for_pending(self, valid_api_key, valid_trace):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace(valid_trace)
            t.flush(timeout_s=5.0)
        assert len(respx.calls) >= 1

    def test_timeout_raises(self, valid_api_key, valid_trace):
        import time

        # Inject a slow task directly into the worker to block it
        t = TeckelTracer(api_key=valid_api_key)
        t._worker.enqueue(lambda: time.sleep(10), "slow_task")
        t._buffer.add({"query": "test", "response": "test"})
        # The worker thread is blocked on slow_task, so flush will timeout
        with pytest.raises(TimeoutError):
            t.flush(timeout_s=0.1)
        t._is_destroyed = True


class TestQueueBehavior:
    @respx.mock
    def test_batches_multiple_traces(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({"query": "Q1", "response": "R1"})
            t.trace({"query": "Q2", "response": "R2"})
            t.trace({"query": "Q3", "response": "R3"})
            t.flush(timeout_s=2.0)

        # All 3 traces should be in a single batch
        trace_calls = [c for c in respx.calls if "/sdk/traces" in str(c.request.url)]
        assert len(trace_calls) == 1
        body = json.loads(trace_calls[0].request.content)
        assert len(body["traces"]) == 3

    @respx.mock
    def test_traces_and_feedback(self, valid_api_key):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace({"query": "Q", "response": "R"})
            t.feedback({
                "traceId": "550e8400-e29b-41d4-a716-446655440000",
                "type": "thumbs_up",
            })
            t.flush(timeout_s=2.0)

        urls = [str(c.request.url) for c in respx.calls]
        assert any("/sdk/traces" in u for u in urls)
        assert any("/sdk/feedback" in u for u in urls)


class TestDestroy:
    @respx.mock
    def test_drops_after_destroy(self, valid_api_key, capsys):
        _mock_success()
        t = TeckelTracer(api_key=valid_api_key, debug=True)
        t.destroy()
        t.trace({"query": "test", "response": "test"})
        # No calls should have been made for the trace
        trace_calls = [c for c in respx.calls if "/sdk/traces" in str(c.request.url)]
        assert len(trace_calls) == 0

    @respx.mock
    def test_context_manager_calls_destroy(self, valid_api_key, valid_trace):
        _mock_success()
        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace(valid_trace)
        # After exiting, tracer is destroyed
        assert t._is_destroyed is True


class TestPendingCount:
    def test_pending_trace_count(self, valid_api_key):
        t = TeckelTracer(api_key=valid_api_key)
        assert t.pending_trace_count == 0
        # We need to avoid flush timer from draining.
        # Add trace directly to buffer to test count.
        t._buffer.add({"query": "test", "response": "test"})
        assert t.pending_trace_count == 1
        t._is_destroyed = True


class TestRetry:
    @respx.mock
    def test_retries_on_429(self, valid_api_key, valid_trace):
        route = respx.post(f"{API}/sdk/traces")
        route.side_effect = [
            httpx.Response(429),
            httpx.Response(200, json={"successCount": 1}),
        ]
        respx.post(f"{API}/sdk/dropped").mock(return_value=httpx.Response(200, json={}))

        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace(valid_trace)
            t.flush(timeout_s=5.0)

        assert route.call_count == 2

    @respx.mock
    def test_retries_on_5xx(self, valid_api_key, valid_trace):
        route = respx.post(f"{API}/sdk/traces")
        route.side_effect = [
            httpx.Response(500),
            httpx.Response(200, json={"successCount": 1}),
        ]
        respx.post(f"{API}/sdk/dropped").mock(return_value=httpx.Response(200, json={}))

        with TeckelTracer(api_key=valid_api_key) as t:
            t.trace(valid_trace)
            t.flush(timeout_s=5.0)

        assert route.call_count == 2
