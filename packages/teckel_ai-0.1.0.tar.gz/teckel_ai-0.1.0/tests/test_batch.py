"""Tests for BatchBuffer."""

import threading

from teckel._batch import BatchBuffer


class TestBatchBuffer:
    def test_add_and_drain(self):
        buf = BatchBuffer(max_size=10, max_bytes=1_000_000)
        buf.add({"query": "test", "response": "resp"})
        buf.add({"query": "test2", "response": "resp2"})

        assert buf.count == 2
        assert not buf.is_empty

        items = buf.drain()
        assert len(items) == 2
        assert buf.is_empty
        assert buf.count == 0

    def test_flush_trigger_on_max_size(self):
        buf = BatchBuffer(max_size=2, max_bytes=1_000_000)
        assert not buf.add({"query": "a", "response": "b"})
        assert buf.add({"query": "c", "response": "d"})  # Returns True

    def test_flush_trigger_on_max_bytes(self):
        buf = BatchBuffer(max_size=1000, max_bytes=100)
        # This single item exceeds 100 bytes when serialized
        result = buf.add({"query": "x" * 50, "response": "y" * 50})
        assert result is True

    def test_thread_safety(self):
        buf = BatchBuffer(max_size=10_000, max_bytes=100_000_000)
        errors = []

        def add_items():
            try:
                for i in range(100):
                    buf.add({"query": f"q{i}", "response": f"r{i}"})
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=add_items) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert buf.count == 1000
