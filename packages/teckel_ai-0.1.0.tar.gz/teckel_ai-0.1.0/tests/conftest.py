"""Shared fixtures for teckel tests."""

import pytest


@pytest.fixture
def valid_api_key() -> str:
    return "tk_live_test123"


@pytest.fixture
def valid_trace() -> dict:
    return {"query": "How do I reset my password?", "response": "Go to Settings > Security..."}
