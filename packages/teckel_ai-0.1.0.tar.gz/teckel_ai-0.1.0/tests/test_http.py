"""Tests for HTTP client with retry logic."""

import httpx
import pytest
import respx

from teckel._http import HttpClient


@pytest.fixture
def client() -> HttpClient:
    c = HttpClient(api_key="tk_live_test", endpoint="https://api.test.com", timeout_s=2.0)
    yield c
    c.close()


class TestHttpClient:
    @respx.mock
    def test_successful_post(self, client: HttpClient):
        respx.post("https://api.test.com/sdk/traces").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        resp = client.post("/sdk/traces", {"traces": []})
        assert resp.status_code == 200

    @respx.mock
    def test_retry_on_429(self, client: HttpClient):
        route = respx.post("https://api.test.com/sdk/traces")
        route.side_effect = [
            httpx.Response(429),
            httpx.Response(200, json={"ok": True}),
        ]
        resp = client.post("/sdk/traces", {"traces": []})
        assert resp.status_code == 200
        assert route.call_count == 2

    @respx.mock
    def test_retry_on_500(self, client: HttpClient):
        route = respx.post("https://api.test.com/sdk/traces")
        route.side_effect = [
            httpx.Response(500),
            httpx.Response(200, json={"ok": True}),
        ]
        resp = client.post("/sdk/traces", {"traces": []})
        assert resp.status_code == 200
        assert route.call_count == 2

    @respx.mock
    def test_no_retry_on_400(self, client: HttpClient):
        route = respx.post("https://api.test.com/sdk/traces")
        route.mock(return_value=httpx.Response(400, json={"error": "bad request"}))
        resp = client.post("/sdk/traces", {"traces": []})
        assert resp.status_code == 400
        assert route.call_count == 1

    @respx.mock
    def test_returns_last_error_after_max_retries(self, client: HttpClient):
        route = respx.post("https://api.test.com/sdk/traces")
        route.side_effect = [httpx.Response(500), httpx.Response(502)]
        resp = client.post("/sdk/traces", {"traces": []})
        assert resp.status_code == 502
        assert route.call_count == 2

    @respx.mock
    def test_fire_and_forget_swallows_errors(self, client: HttpClient):
        respx.post("https://api.test.com/sdk/dropped").mock(
            side_effect=httpx.ConnectError("fail")
        )
        # Should not raise
        client.post_fire_and_forget("/sdk/dropped", {"error": "test"})
