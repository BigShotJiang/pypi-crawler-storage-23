"""Integration tests -- skipped without TECKEL_API_KEY env var.

These tests verify end-to-end trace delivery. They use on_error to assert
the server actually accepted (no HTTP errors), not just that flush() completed.
"""

import os
import uuid

import pytest

from teckel import TeckelTracer

API_KEY = os.environ.get("TECKEL_API_KEY")
ENDPOINT = os.environ.get("TECKEL_ENDPOINT")  # e.g. http://localhost:3001/api
pytestmark = pytest.mark.skipif(not API_KEY, reason="TECKEL_API_KEY not set")


@pytest.fixture
def tracer():
    errors: list = []
    kwargs: dict = {"api_key": API_KEY, "on_error": lambda e: errors.append(e)}
    if ENDPOINT:
        kwargs["endpoint"] = ENDPOINT
    t = TeckelTracer(**kwargs)
    yield t, errors
    t.destroy()


class TestIntegration:
    def test_minimal_trace(self, tracer):
        t, errors = tracer
        t.trace({"query": "integration test", "response": "pong"})
        t.flush(timeout_s=10.0)
        http_errors = [e for e in errors if e.type == "http"]
        assert not http_errors, f"Server rejected trace: {http_errors}"

    def test_full_trace(self, tracer):
        t, errors = tracer
        t.trace({
            "query": "integration full trace",
            "response": "full response",
            "model": "gpt-5-nano",
            "latencyMs": 42,
            "traceId": str(uuid.uuid4()),
            "sessionId": "integration-session",
            "documents": [
                {"id": "int-doc", "name": "Integration Doc", "text": "content"}
            ],
            "spans": [
                {
                    "name": "llm-call",
                    "type": "llm_call",
                    "startedAt": "2025-01-01T00:00:00Z",
                    "promptTokens": 50,
                    "completionTokens": 25,
                }
            ],
        })
        t.flush(timeout_s=10.0)
        http_errors = [e for e in errors if e.type == "http"]
        assert not http_errors, f"Server rejected trace: {http_errors}"

    def test_feedback(self, tracer):
        t, errors = tracer
        trace_id = str(uuid.uuid4())
        t.trace({
            "query": "feedback test",
            "response": "response",
            "traceId": trace_id,
        })
        t.flush(timeout_s=10.0)

        pre_errors = len(errors)
        t.feedback({"traceId": trace_id, "type": "thumbs_up"})
        t.flush(timeout_s=10.0)
        # Feedback may 404 if trace isn't processed yet -- that's expected in fast tests.
        # But it should NOT 401 (auth failure).
        auth_errors = [
            e for e in errors[pre_errors:]
            if e.type == "http" and e.context and e.context.get("status") == 401
        ]
        assert not auth_errors, f"Auth failure on feedback: {auth_errors}"

    def test_invalid_api_key_401(self):
        errors = []
        kwargs: dict = {
            "api_key": "tk_live_invalid_key_12345",
            "on_error": lambda e: errors.append(e),
        }
        if ENDPOINT:
            kwargs["endpoint"] = ENDPOINT
        t = TeckelTracer(**kwargs)
        t.trace({"query": "test", "response": "test"})
        try:
            t.flush(timeout_s=10.0)
        except Exception:
            pass
        t.destroy()
        assert any(e.type == "http" for e in errors), "Expected HTTP error for invalid key"

    def test_client_side_validation(self, tracer):
        t, errors = tracer
        t.trace({"query": "", "response": "valid"})
        assert any(e.type == "validation" for e in errors)
