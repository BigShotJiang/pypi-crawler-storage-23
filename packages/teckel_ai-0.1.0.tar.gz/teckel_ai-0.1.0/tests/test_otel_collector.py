"""Tests for teckel.otel.collector.TeckelSpanCollector."""

import pytest

try:
    import opentelemetry.sdk.trace  # noqa: F401

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False

pytestmark = pytest.mark.skipif(not HAS_OTEL, reason="opentelemetry-sdk not installed")


class TestTeckelSpanCollector:
    def test_creates_tracer(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()
        assert tracer is not None
        collector.shutdown()

    def test_collects_spans(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()

        # Create a span manually
        with tracer.start_as_current_span("ai.generateText.doGenerate") as span:
            span.set_attribute("gen_ai.request.model", "gpt-5")
            span.set_attribute("gen_ai.usage.input_tokens", 100)
            span.set_attribute("gen_ai.usage.output_tokens", 50)

        collector.force_flush()
        spans = collector.get_spans()
        assert len(spans) == 1
        assert spans[0]["name"] == "ai.generateText.doGenerate"
        assert spans[0]["type"] == "llm_call"
        assert spans[0]["model"] == "gpt-5"
        assert spans[0]["promptTokens"] == 100
        assert spans[0]["completionTokens"] == 50
        collector.shutdown()

    def test_collects_nested_spans(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()

        with tracer.start_as_current_span("ai.generateText") as root:
            root.set_attribute("ai.response.text", "Hello")
            with tracer.start_as_current_span(
                "ai.generateText.doGenerate"
            ) as child:
                child.set_attribute("gen_ai.request.model", "gpt-5")

        collector.force_flush()
        spans = collector.get_spans()
        assert len(spans) == 2

        # Verify parent-child relationship
        child_span = next(s for s in spans if s["type"] == "llm_call")
        assert "parentSpanId" in child_span
        collector.shutdown()

    def test_clear(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()

        with tracer.start_as_current_span("test-span"):
            pass

        collector.force_flush()
        assert len(collector.get_spans()) == 1

        collector.clear()
        assert len(collector.get_spans()) == 0
        collector.shutdown()

    def test_get_raw_spans(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()

        with tracer.start_as_current_span("test-span"):
            pass

        collector.force_flush()
        raw = collector.get_raw_spans()
        assert len(raw) == 1
        assert hasattr(raw[0], "name")
        assert raw[0].name == "test-span"
        collector.shutdown()

    def test_tool_call_span(self):
        from teckel.otel import TeckelSpanCollector

        collector = TeckelSpanCollector()
        tracer = collector.get_tracer()

        with tracer.start_as_current_span("ai.toolCall") as span:
            span.set_attribute("ai.toolCall.name", "get_weather")
            span.set_attribute("ai.toolCall.args", '{"city": "NYC"}')
            span.set_attribute("ai.toolCall.result", '{"temp": 72}')

        collector.force_flush()
        spans = collector.get_spans()
        assert len(spans) == 1
        assert spans[0]["type"] == "tool_call"
        assert spans[0]["toolName"] == "get_weather"
        assert spans[0]["toolArguments"] == {"city": "NYC"}
        assert spans[0]["toolResult"] == {"temp": 72}
        collector.shutdown()

    def test_debug_mode(self, capsys):
        import logging

        from teckel.otel import TeckelSpanCollector

        logging.basicConfig(level=logging.DEBUG)
        collector = TeckelSpanCollector(debug=True)
        tracer = collector.get_tracer()

        with tracer.start_as_current_span("test-span"):
            pass

        collector.force_flush()
        collector.shutdown()
