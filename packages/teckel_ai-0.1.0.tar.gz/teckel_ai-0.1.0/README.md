# teckel-ai (Python SDK)

Python SDK for [Teckel AI](https://teckel.ai) an agentic monitoring platform for tracking behavior and improving AI output.

## Install

```bash
pip install teckel-ai
```

## Minimal Usage

```python
from teckel import TeckelTracer

tracer = TeckelTracer(api_key="tk_live_...")
tracer.trace({"query": "Hello", "response": "Hi there"})
```

For serverless runtimes, call `tracer.flush(timeout_s=5.0)` before returning.

## Documentation

- Getting Started: https://docs.teckel.ai/docs/getting_started
- Python SDK Reference: https://docs.teckel.ai/docs/python_sdk_reference
- OpenTelemetry Integration: https://docs.teckel.ai/docs/opentelemetry_integration
- HTTP API Reference (canonical fields): https://docs.teckel.ai/docs/http_api_reference

## Requirements

- Python 3.10+
