"""Daemon worker thread consuming a send queue."""

from __future__ import annotations

import queue
import threading
from collections.abc import Callable
from typing import Any

_SENTINEL = object()


class SendWorker:
    """Single daemon thread that processes (callable, op_name) tasks sequentially."""

    def __init__(self, *, on_error: Callable[[dict[str, Any]], None] | None = None) -> None:
        self._queue: queue.Queue[Any] = queue.Queue()
        self._on_error = on_error
        self._thread = threading.Thread(target=self._run, daemon=True, name="teckel-worker")
        self._thread.start()

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def enqueue(self, task_fn: Callable[[], None], op_name: str) -> None:
        """Add a callable to the work queue."""
        self._queue.put((task_fn, op_name))

    def flush(self, timeout_s: float | None = None) -> None:
        """Block until all pending tasks are processed (or timeout)."""
        if timeout_s is None:
            self._queue.join()
            return

        if not self.flush_with_timeout(timeout_s):
            raise TimeoutError(f"Flush timeout after {timeout_s}s")

    def flush_with_timeout(self, timeout_s: float) -> bool:
        """Block until queue is drained or timeout. Returns True if drained."""
        done = threading.Event()

        def _signal() -> None:
            done.set()

        self._queue.put((_signal, "_flush_signal"))
        return done.wait(timeout=timeout_s)

    def shutdown(self, timeout_s: float = 2.0) -> None:
        """Send sentinel and join thread."""
        self._queue.put(_SENTINEL)
        self._thread.join(timeout=timeout_s)

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    def _run(self) -> None:
        while True:
            item = self._queue.get()
            if item is _SENTINEL:
                self._queue.task_done()
                break
            task_fn, op_name = item
            try:
                task_fn()
            except Exception as exc:
                msg = str(exc)
                if self._on_error:
                    if "timeout" in msg.lower() or "timed out" in msg.lower():
                        self._on_error({"type": "timeout", "message": f"{op_name} timed out"})
                    else:
                        self._on_error({"type": "network", "message": msg})
            finally:
                self._queue.task_done()
