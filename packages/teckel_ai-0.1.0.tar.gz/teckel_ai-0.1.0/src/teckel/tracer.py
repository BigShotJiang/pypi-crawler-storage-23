"""TeckelTracer -- fire-and-forget trace collection for AI applications."""

from __future__ import annotations

import atexit
import logging
import sys
import threading
from collections.abc import Callable
from typing import Any
from urllib.parse import urlparse

from pydantic import ValidationError

from ._batch import BatchBuffer
from ._constants import (
    DEFAULT_ENDPOINT,
    DEFAULT_TIMEOUT_S,
)
from ._http import HttpClient
from ._token_utils import calculate_tokens_from_spans
from ._version import __version__
from ._worker import SendWorker
from .models import (
    BatchConfig,
    FeedbackData,
    TeckelError,
    TraceData,
)

logger = logging.getLogger("teckel")


class TeckelTracer:
    """Fire-and-forget trace collection.

    Usage::

        tracer = TeckelTracer(api_key="tk_live_...")
        tracer.trace({"query": "How do I...?", "response": "Go to Settings..."})
        tracer.flush()

    Or as a context manager::

        with TeckelTracer(api_key="tk_live_...") as tracer:
            tracer.trace(...)
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: str | None = None,
        debug: bool = False,
        timeout_s: float = DEFAULT_TIMEOUT_S,
        batch: BatchConfig | dict[str, Any] | None = None,
        on_error: Callable[[TeckelError], None] | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        if endpoint is not None:
            parsed = urlparse(endpoint)
            if parsed.scheme not in ("http", "https") or not parsed.netloc:
                raise ValueError("endpoint must be a valid URL")

        if timeout_s <= 0 or timeout_s > 60:
            raise ValueError("timeout_s must be between 0 and 60 seconds")

        if not api_key.startswith("tk_live_"):
            prefix = "tk_***" if api_key.startswith("tk_") else "invalid prefix"
            print(
                f'[Teckel] Invalid API key format. Expected "tk_live_***", got "{prefix}". '
                f"Get your key at https://app.teckel.ai/settings/api-keys",
                file=sys.stderr,
            )

        self._api_key = api_key
        self._endpoint = endpoint or DEFAULT_ENDPOINT
        self._debug = debug
        self._timeout_s = timeout_s
        self._on_error = on_error
        self._is_destroyed = False

        # Resolve batch config
        if batch is None:
            batch_cfg = BatchConfig()
        elif isinstance(batch, dict):
            batch_cfg = BatchConfig(**batch)
        else:
            batch_cfg = batch

        self._batch_config = batch_cfg

        # Internal components
        self._http = HttpClient(
            api_key=api_key,
            endpoint=self._endpoint,
            timeout_s=timeout_s,
        )
        self._buffer = BatchBuffer(
            max_size=batch_cfg.max_size,
            max_bytes=batch_cfg.max_bytes,
        )
        self._worker = SendWorker(on_error=self._handle_worker_error)

        # Periodic flush timer (self-rescheduling daemon Timer)
        self._timer_lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._start_flush_timer()

        # Best-effort flush on process exit
        atexit.register(self._atexit_flush)

        if self._debug:
            logger.debug(
                "[Teckel] Initialized endpoint=%s timeout_s=%s batch_max_size=%d",
                self._endpoint,
                self._timeout_s,
                batch_cfg.max_size,
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def trace(self, data: TraceData | dict[str, Any]) -> None:
        """Record a trace. Fire-and-forget -- call flush() before process exit."""
        if self._is_destroyed:
            if self._debug:
                logger.warning("[Teckel] Trace dropped - tracer destroyed")
            return

        try:
            # Accept raw dicts
            if isinstance(data, dict):
                trace_data = TraceData(**data)
            else:
                trace_data = data

            # Auto-calculate tokens from spans if spans provided but tokens not
            if trace_data.spans and len(trace_data.spans) > 0 and not trace_data.tokens:
                aggregated = calculate_tokens_from_spans(trace_data.spans)
                if aggregated.total > 0:
                    trace_data = trace_data.model_copy(update={"tokens": aggregated})
                    if self._debug:
                        logger.debug(
                            "[Teckel] Auto-aggregated tokens from spans: %s",
                            aggregated,
                        )

            # Serialize to camelCase dict for the wire
            trace_dict = trace_data.model_dump(by_alias=True, exclude_none=True)

            if self._debug:
                logger.debug(
                    "[Teckel] Queueing trace traceId=%s sessionId=%s",
                    trace_dict.get("traceId"),
                    trace_dict.get("sessionId"),
                )

            needs_flush = self._buffer.add(trace_dict)
            if needs_flush:
                self._flush_batch()

        except ValidationError as exc:
            partial = data if isinstance(data, dict) else None
            self._log_validation_error("Trace", exc, partial)
        except Exception as exc:
            if self._debug:
                logger.error("[Teckel] Trace dropped: %s", exc)

    def feedback(self, data: FeedbackData | dict[str, Any]) -> None:
        """Submit feedback for a trace or session. Sent immediately (not batched)."""
        if self._is_destroyed:
            if self._debug:
                logger.warning("[Teckel] Feedback dropped - tracer destroyed")
            return

        try:
            if isinstance(data, dict):
                fb = FeedbackData(**data)
            else:
                fb = data

            fb_dict = fb.model_dump(by_alias=True, exclude_none=True)

            if self._debug:
                logger.debug("[Teckel] Sending feedback type=%s", fb_dict.get("type"))

            def _send_feedback(d: dict[str, Any] = fb_dict) -> None:
                self._send("/sdk/feedback", d)

            self._worker.enqueue(_send_feedback, "feedback")

        except ValidationError as exc:
            self._log_validation_error("Feedback", exc)
        except Exception as exc:
            if self._debug:
                logger.error("[Teckel] Feedback dropped: %s", exc)

    def flush(self, timeout_s: float | None = None) -> None:
        """Block until all pending traces/feedback are sent (or timeout)."""
        ts = timeout_s if timeout_s is not None else self._timeout_s

        if not self._buffer.is_empty:
            self._flush_batch()

        if not self._worker.flush_with_timeout(ts):
            if self._debug:
                logger.warning("[Teckel] Flush timed out after %ss", ts)
            raise TimeoutError(f"Flush timeout after {ts}s")

    def destroy(self) -> None:
        """Stop timer, flush pending, close HTTP client, shutdown worker."""
        if self._is_destroyed:
            return

        self._is_destroyed = True
        self._stop_flush_timer()

        try:
            self.flush(timeout_s=self._timeout_s * 2)
        except (TimeoutError, Exception):
            if self._debug:
                logger.warning("[Teckel] Destroy: some traces may not have been sent")

        self._worker.shutdown(timeout_s=2.0)
        self._http.close()

    @property
    def pending_trace_count(self) -> int:
        return self._buffer.count

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> TeckelTracer:
        return self

    def __exit__(self, *_: Any) -> None:
        self.destroy()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _flush_batch(self) -> None:
        traces = self._buffer.drain()
        if not traces:
            return

        if self._debug:
            logger.debug("[Teckel] Flushing batch count=%d", len(traces))

        def _do_send_batch(t: list[dict[str, Any]] = traces) -> None:
            self._send_batch(t)

        self._worker.enqueue(_do_send_batch, "batch")

    def _send_batch(self, traces: list[dict[str, Any]]) -> None:
        resp = self._http.post("/sdk/traces", {"traces": traces})
        if not resp.is_success:
            self._log_http_error("/sdk/traces", resp.status_code)
            raise RuntimeError(f"HTTP {resp.status_code}")

        if self._debug:
            try:
                result = resp.json()
                logger.debug(
                    "[Teckel] Batch sent requested=%d succeeded=%d",
                    len(traces),
                    result.get("successCount", len(traces)),
                )
            except Exception:
                pass

    def _send(self, path: str, data: dict[str, Any]) -> None:
        resp = self._http.post(path, data)
        if not resp.is_success:
            self._log_http_error(path, resp.status_code)
            raise RuntimeError(f"HTTP {resp.status_code}")

    def _start_flush_timer(self) -> None:
        with self._timer_lock:
            if self._is_destroyed:
                return
            self._timer = threading.Timer(
                self._batch_config.flush_interval_s, self._timer_tick
            )
            self._timer.daemon = True
            self._timer.start()

    def _timer_tick(self) -> None:
        if self._is_destroyed:
            return
        if not self._buffer.is_empty:
            self._flush_batch()
        self._start_flush_timer()  # reschedule

    def _stop_flush_timer(self) -> None:
        with self._timer_lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None

    def _atexit_flush(self) -> None:
        if self._is_destroyed:
            return
        try:
            self.flush(timeout_s=2.0)
        except Exception:
            pass

    def _handle_worker_error(self, error: dict[str, Any]) -> None:
        if self._on_error:
            self._on_error(TeckelError(**error))

    def _log_validation_error(
        self,
        op: str,
        exc: ValidationError,
        partial_data: dict[str, Any] | None = None,
    ) -> None:
        issues: list[str] = []
        for err in exc.errors():
            path = ".".join(str(p) for p in err["loc"]) or "(root)"
            msg = err["msg"]
            hint = self._get_validation_hint(path, msg)
            if hint:
                issues.append(f"  - {path}: {msg}\n    Hint: {hint}")
            else:
                issues.append(f"  - {path}: {msg}")

        print(
            f"[Teckel] {op} dropped - validation failed:\n" + "\n".join(issues),
            file=sys.stderr,
        )

        if self._on_error:
            self._on_error(
                TeckelError(
                    type="validation",
                    message="; ".join(
                        f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}"
                        for e in exc.errors()
                    ),
                    context={
                        "issues": [
                            {"path": list(e["loc"]), "message": e["msg"]}
                            for e in exc.errors()
                        ]
                    },
                )
            )

        # Report dropped trace to server
        self._http.post_fire_and_forget(
            "/sdk/dropped",
            {
                "errorType": "validation_failed",
                "errorDetails": "; ".join(
                    f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}"
                    for e in exc.errors()
                )[:1000],
                "fieldPath": ".".join(str(p) for p in exc.errors()[0]["loc"])
                if exc.errors()
                else None,
                "agentName": partial_data.get("agentName") if partial_data else None,
                "sdkVersion": __version__,
            },
        )

    @staticmethod
    def _get_validation_hint(path: str, message: str) -> str | None:
        lower = message.lower()
        if "toolResult" in path and "object" in lower:
            return "Wrap array results in an object: {'items': [...]}"
        if "toolArguments" in path and "object" in lower:
            return "Wrap array arguments in an object: {'args': [...]}"
        if "exceeds" in lower or "limit" in lower:
            return "Reduce payload size or truncate large fields"
        if "uuid" in lower:
            return "Use uuid.uuid4() to generate valid UUIDs"
        if "startedAt" in path or "endedAt" in path:
            return "Use ISO 8601 format: datetime.utcnow().isoformat() + 'Z'"
        if "required" in lower:
            field = path.split(".")[-1]
            return f"Ensure {field} is provided and not empty"
        return None

    def _log_http_error(self, path: str, status: int) -> None:
        if path == "/sdk/traces":
            op = "Batch"
        elif "feedback" in path:
            op = "Feedback"
        else:
            op = "Request"

        messages: dict[int, str] = {
            401: f"{op} failed - invalid API key. Check https://app.teckel.ai/settings/api-keys",
            400: f"{op} failed - invalid request. Enable debug mode for details.",
            404: f"{op} failed - endpoint not found. Check your configuration.",
            429: f"{op} dropped - rate limit exceeded.",
        }

        if status in messages:
            msg = messages[status]
        elif status >= 500:
            msg = f"{op} dropped - server error ({status})"
        else:
            msg = f"{op} failed - HTTP {status}"

        print(f"[Teckel] {msg}", file=sys.stderr)

        if self._on_error:
            self._on_error(
                TeckelError(
                    type="http",
                    message=msg,
                    context={"status": status, "path": path},
                )
            )
