"""Token aggregation across spans."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import SpanData, TokenUsage


def calculate_tokens_from_spans(spans: list[SpanData]) -> TokenUsage:
    """Aggregate prompt_tokens and completion_tokens across all spans."""
    from .models import TokenUsage

    prompt = 0
    completion = 0

    for span in spans:
        if span.prompt_tokens is not None:
            prompt += span.prompt_tokens
        if span.completion_tokens is not None:
            completion += span.completion_tokens

    return TokenUsage(prompt=prompt, completion=completion, total=prompt + completion)
