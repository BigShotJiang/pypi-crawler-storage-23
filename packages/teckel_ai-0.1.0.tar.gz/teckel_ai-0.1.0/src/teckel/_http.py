"""HTTP client with retry logic, wrapping httpx."""

from __future__ import annotations

import math
import random
import time
from typing import Any

import httpx

from ._constants import RETRY_BASE_MS, RETRY_MAX_ATTEMPTS, RETRY_MAX_MS
from ._version import __version__


class HttpClient:
    """Thin wrapper around httpx.Client with exponential-backoff retry."""

    def __init__(self, *, api_key: str, endpoint: str, timeout_s: float) -> None:
        self._api_key = api_key
        self._endpoint = endpoint
        self._client = httpx.Client(
            timeout=timeout_s,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"teckel-python/{__version__}",
            },
        )

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def post(self, path: str, data: Any) -> httpx.Response:
        """POST with retry on 429 / 5xx. Raises on final failure."""
        url = f"{self._endpoint}{path}"

        for attempt in range(1, RETRY_MAX_ATTEMPTS + 1):
            try:
                resp = self._client.post(url, content=_json_bytes(data))

                if resp.is_success or attempt == RETRY_MAX_ATTEMPTS:
                    return resp

                if resp.status_code == 429 or resp.status_code >= 500:
                    self._backoff(attempt)
                    continue

                return resp  # 4xx (non-429): no retry

            except httpx.TransportError:
                if attempt == RETRY_MAX_ATTEMPTS:
                    raise
                self._backoff(attempt)

        raise RuntimeError("unreachable")  # pragma: no cover

    def post_fire_and_forget(self, path: str, data: Any) -> None:
        """POST ignoring all errors (used for /sdk/dropped)."""
        try:
            url = f"{self._endpoint}{path}"
            self._client.post(url, content=_json_bytes(data))
        except Exception:
            pass

    def close(self) -> None:
        self._client.close()

    # ------------------------------------------------------------------
    # Private
    # ------------------------------------------------------------------

    @staticmethod
    def _backoff(attempt: int) -> None:
        base = min(RETRY_BASE_MS * math.pow(2, attempt - 1), RETRY_MAX_MS)
        jitter = random.random() * 100  # noqa: S311
        time.sleep((base + jitter) / 1000)


def _json_bytes(obj: Any) -> bytes:
    """Serialize to compact JSON bytes (no spaces)."""
    import json

    return json.dumps(obj, separators=(",", ":")).encode()
