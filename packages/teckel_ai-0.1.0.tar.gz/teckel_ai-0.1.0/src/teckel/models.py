"""Pydantic v2 models -- ports types.ts + schemas.ts validation rules."""

from __future__ import annotations

import json
import re
from datetime import datetime
from enum import Enum
from typing import Any, Literal
from uuid import UUID

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from ._constants import (
    JSONB_MAX_BYTES,
    MAX_DOCUMENTS,
    MAX_SPANS,
    METADATA_MAX_BYTES,
    TRACE_MAX_BYTES,
)

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SpanType(str, Enum):
    LLM_CALL = "llm_call"
    TOOL_CALL = "tool_call"
    RETRIEVAL = "retrieval"
    AGENT = "agent"
    GUARDRAIL = "guardrail"
    CUSTOM = "custom"


class SpanStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    ERROR = "error"


class FeedbackType(str, Enum):
    THUMBS_UP = "thumbs_up"
    THUMBS_DOWN = "thumbs_down"
    FLAG = "flag"
    RATING = "rating"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def _jsonb_size_ok(obj: dict[str, Any] | None, limit: int = JSONB_MAX_BYTES) -> bool:
    if obj is None:
        return True
    return len(json.dumps(obj, separators=(",", ":"))) <= limit


def _check_jsonb(value: dict[str, Any] | None, field_name: str) -> dict[str, Any] | None:
    if value is not None and not _jsonb_size_ok(value):
        raise ValueError(f"{field_name} exceeds {JSONB_MAX_BYTES // 1000}KB limit")
    return value


def _check_iso_datetime_with_offset(value: str | None, field_name: str) -> str | None:
    if value is None:
        return None

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(
            f"{field_name} must be a valid ISO 8601 timestamp with timezone offset"
        ) from exc

    if parsed.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone offset")

    return value


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class Document(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    id: str = Field(min_length=1, max_length=500)
    name: str = Field(min_length=1, max_length=500)
    text: str = Field(min_length=1, max_length=50_000)
    last_updated: str | None = Field(default=None, alias="lastUpdated")
    url: str | None = Field(default=None, max_length=2000)
    source: str | None = Field(default=None, max_length=100)
    file_format: str | None = Field(default=None, alias="fileFormat", max_length=100)
    similarity: float | None = Field(default=None, ge=0, le=1)
    rank: int | None = Field(default=None, ge=0)
    owner_email: str | None = Field(default=None, alias="ownerEmail", max_length=254)

    @field_validator("last_updated")
    @classmethod
    def _validate_last_updated(cls, v: str | None) -> str | None:
        return _check_iso_datetime_with_offset(v, "lastUpdated")

    @field_validator("owner_email")
    @classmethod
    def _validate_owner_email(cls, v: str | None) -> str | None:
        if v is not None and not _EMAIL_RE.match(v):
            raise ValueError("ownerEmail must be a valid email address")
        return v


class TokenUsage(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    prompt: int = Field(ge=0)
    completion: int = Field(ge=0)
    total: int = Field(ge=0)


class SpanData(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    span_id: str | None = Field(default=None, alias="spanId", min_length=1, max_length=64)
    parent_span_id: str | None = Field(
        default=None, alias="parentSpanId", min_length=1, max_length=64
    )
    name: str = Field(min_length=1, max_length=200)
    type: SpanType = SpanType.CUSTOM
    started_at: str = Field(alias="startedAt")
    ended_at: str | None = Field(default=None, alias="endedAt")
    duration_ms: int | None = Field(default=None, alias="durationMs", ge=0, le=3_600_000)
    status: SpanStatus = SpanStatus.COMPLETED
    status_message: str | None = Field(default=None, alias="statusMessage", max_length=2000)
    tool_name: str | None = Field(default=None, alias="toolName", max_length=200)
    tool_arguments: dict[str, Any] | None = Field(default=None, alias="toolArguments")
    tool_result: dict[str, Any] | None = Field(default=None, alias="toolResult")
    model: str | None = Field(default=None, max_length=100)
    prompt_tokens: int | None = Field(default=None, alias="promptTokens", ge=0)
    completion_tokens: int | None = Field(default=None, alias="completionTokens", ge=0)
    cost_usd: float | None = Field(default=None, alias="costUsd", ge=0)
    input: dict[str, Any] | None = None
    output: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None

    @field_validator("started_at")
    @classmethod
    def _validate_started_at(cls, v: str) -> str:
        checked = _check_iso_datetime_with_offset(v, "startedAt")
        if checked is None:
            raise ValueError("startedAt is required")
        return checked

    @field_validator("ended_at")
    @classmethod
    def _validate_ended_at(cls, v: str | None) -> str | None:
        return _check_iso_datetime_with_offset(v, "endedAt")

    @field_validator("tool_arguments")
    @classmethod
    def _validate_tool_arguments(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _check_jsonb(v, "toolArguments")

    @field_validator("tool_result")
    @classmethod
    def _validate_tool_result(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _check_jsonb(v, "toolResult")

    @field_validator("input")
    @classmethod
    def _validate_input(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _check_jsonb(v, "input")

    @field_validator("output")
    @classmethod
    def _validate_output(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _check_jsonb(v, "output")

    @field_validator("metadata")
    @classmethod
    def _validate_metadata(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        return _check_jsonb(v, "metadata")

    @model_validator(mode="after")
    def _tool_call_requires_tool_name(self) -> SpanData:
        if self.type == SpanType.TOOL_CALL and not self.tool_name:
            raise ValueError("toolName is required for tool_call spans")
        return self


class TraceData(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    query: str = Field(min_length=1, max_length=10_000)
    response: str = Field(min_length=1, max_length=50_000)
    agent_name: str | None = Field(default=None, alias="agentName", min_length=1, max_length=200)
    model: str | None = Field(default=None, max_length=100)
    latency_ms: int | None = Field(default=None, alias="latencyMs", ge=0, le=600_000)
    tokens: TokenUsage | None = None
    cost_usd: float | None = Field(default=None, alias="costUsd", ge=0)
    documents: list[Document] | None = None
    spans: list[SpanData] | None = None
    session_id: str | None = Field(default=None, alias="sessionId", min_length=1, max_length=200)
    user_id: str | None = Field(default=None, alias="userId", min_length=1, max_length=255)
    trace_id: str | None = Field(default=None, alias="traceId")
    system_prompt: str | None = Field(default=None, alias="systemPrompt", max_length=50_000)
    metadata: dict[str, Any] | None = None

    @field_validator("trace_id")
    @classmethod
    def _validate_trace_id(cls, v: str | None) -> str | None:
        if v is not None:
            try:
                UUID(v)
            except ValueError:
                raise ValueError("traceId must be a valid UUID")
        return v

    @field_validator("documents")
    @classmethod
    def _validate_documents(cls, v: list[Document] | None) -> list[Document] | None:
        if v is not None and len(v) > MAX_DOCUMENTS:
            raise ValueError(f"Too many documents (max {MAX_DOCUMENTS})")
        return v

    @field_validator("spans")
    @classmethod
    def _validate_spans(cls, v: list[SpanData] | None) -> list[SpanData] | None:
        if v is not None and len(v) > MAX_SPANS:
            raise ValueError(f"Too many spans (max {MAX_SPANS})")
        return v

    @field_validator("metadata")
    @classmethod
    def _validate_metadata(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None:
            size = len(json.dumps(v, separators=(",", ":")))
            if size > METADATA_MAX_BYTES:
                raise ValueError(f"metadata exceeds {METADATA_MAX_BYTES // 1000}KB limit")
        return v

    @model_validator(mode="after")
    def _check_total_size(self) -> TraceData:
        size = len(self.model_dump_json(by_alias=True))
        if size > TRACE_MAX_BYTES:
            raise ValueError(
                f"trace payload exceeds {TRACE_MAX_BYTES // 1_000_000}MB limit"
            )
        return self


class FeedbackData(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    trace_id: str | None = Field(default=None, alias="traceId")
    session_id: str | None = Field(default=None, alias="sessionId", min_length=1, max_length=200)
    type: FeedbackType
    value: str | None = Field(default=None, min_length=1, max_length=10)
    comment: str | None = Field(default=None, max_length=2000)

    @field_validator("trace_id")
    @classmethod
    def _validate_trace_id(cls, v: str | None) -> str | None:
        if v is not None:
            try:
                UUID(v)
            except ValueError:
                raise ValueError("traceId must be a valid UUID")
        return v

    @model_validator(mode="after")
    def _require_target(self) -> FeedbackData:
        if not self.trace_id and not self.session_id:
            raise ValueError("Either traceId or sessionId is required")
        return self


class BatchConfig(BaseModel):
    model_config = ConfigDict(strict=False, populate_by_name=True)

    max_size: int = Field(default=100, alias="maxSize", ge=1, le=500)
    max_bytes: int = Field(default=5_000_000, alias="maxBytes", ge=1000, le=10_000_000)
    flush_interval_s: float = Field(default=0.1, alias="flushIntervalS", ge=0.01, le=10.0)


class TeckelError(BaseModel):
    """Structured error reported via on_error callback."""

    type: Literal["validation", "network", "timeout", "http"]
    message: str
    context: dict[str, Any] | None = None
