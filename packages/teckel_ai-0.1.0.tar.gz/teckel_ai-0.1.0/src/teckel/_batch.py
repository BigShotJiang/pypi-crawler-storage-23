"""Thread-safe batch buffer for trace accumulation."""

from __future__ import annotations

import json
import threading
from typing import Any


class BatchBuffer:
    """Accumulates trace dicts until size or byte thresholds are reached."""

    def __init__(self, *, max_size: int, max_bytes: int) -> None:
        self._max_size = max_size
        self._max_bytes = max_bytes
        self._lock = threading.Lock()
        self._buffer: list[dict[str, Any]] = []
        self._byte_count = 0

    def add(self, trace_dict: dict[str, Any]) -> bool:
        """Add a trace dict. Returns True if a flush is needed."""
        size = len(json.dumps(trace_dict, separators=(",", ":")))

        with self._lock:
            self._buffer.append(trace_dict)
            self._byte_count += size
            return (
                len(self._buffer) >= self._max_size
                or self._byte_count >= self._max_bytes
            )

    def drain(self) -> list[dict[str, Any]]:
        """Atomically return and clear the buffer."""
        with self._lock:
            items = self._buffer
            self._buffer = []
            self._byte_count = 0
            return items

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._buffer)

    @property
    def is_empty(self) -> bool:
        with self._lock:
            return len(self._buffer) == 0
