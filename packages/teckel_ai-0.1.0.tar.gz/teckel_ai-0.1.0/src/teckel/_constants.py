"""Size limits and defaults, ported from schemas.ts."""

# Trace payload limits
METADATA_MAX_BYTES = 10_000
TRACE_MAX_BYTES = 3_000_000
MAX_DOCUMENTS = 15

# Span limits
MAX_SPANS = 100
JSONB_MAX_BYTES = 512_000  # 500KB per JSONB field

# Batch defaults
DEFAULT_BATCH_MAX_SIZE = 100
DEFAULT_BATCH_MAX_BYTES = 5_000_000  # 5MB
DEFAULT_FLUSH_INTERVAL_S = 0.1  # 100ms

# HTTP defaults
DEFAULT_ENDPOINT = "https://app.teckel.ai/api"
DEFAULT_TIMEOUT_S = 5.0

# Retry
RETRY_BASE_MS = 250
RETRY_MAX_MS = 5000
RETRY_MAX_ATTEMPTS = 2
