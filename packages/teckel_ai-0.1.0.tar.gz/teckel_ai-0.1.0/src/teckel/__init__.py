"""teckel-ai -- Simple SDK for AI trace tracking and RAG observability."""

from ._token_utils import calculate_tokens_from_spans
from ._version import __version__
from .models import (
    BatchConfig,
    Document,
    FeedbackData,
    FeedbackType,
    SpanData,
    SpanStatus,
    SpanType,
    TeckelError,
    TokenUsage,
    TraceData,
)
from .tracer import TeckelTracer

__all__ = [
    "TeckelTracer",
    "calculate_tokens_from_spans",
    "BatchConfig",
    "Document",
    "FeedbackData",
    "FeedbackType",
    "SpanData",
    "SpanStatus",
    "SpanType",
    "TeckelError",
    "TokenUsage",
    "TraceData",
    "__version__",
]
