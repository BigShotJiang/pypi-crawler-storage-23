"""TeckelSpanProcessor - Auto-sends traces to Teckel from OTel spans.

Usage::

    from teckel.otel import TeckelSpanProcessor
    from opentelemetry.sdk.trace import TracerProvider

    provider = TracerProvider()
    provider.add_span_processor(TeckelSpanProcessor(
        api_key="tk_live_...",
    ))

    # AI SDK spans are auto-sent when root spans complete.
"""

from __future__ import annotations

import json
import logging
import threading
from typing import Any

from ..tracer import TeckelTracer
from ._utils import convert_to_teckel_span

logger = logging.getLogger("teckel.otel")

# Memory bounds to prevent unbounded growth if root spans never complete
MAX_PENDING_TRACES = 10_000
PENDING_TTL_S = 5 * 60  # 5 minutes


class TeckelSpanProcessor:
    """OpenTelemetry SpanProcessor that auto-sends traces to Teckel.

    Buffers spans by traceId and sends complete traces when root spans
    (``ai.generateText``, ``ai.streamText``, ``ai.generateObject``) complete.

    Requires ``opentelemetry-sdk``. Install with: ``pip install teckel-ai[otel]``
    """

    def __init__(
        self,
        api_key: str,
        *,
        endpoint: str | None = None,
        debug: bool = False,
    ) -> None:
        self._tracer = TeckelTracer(
            api_key=api_key,
            endpoint=endpoint,
            debug=debug,
            batch={"max_size": 1, "flush_interval_s": 0.01},
        )
        self._debug = debug
        self._pending: dict[str, _PendingTrace] = {}
        self._lock = threading.Lock()
        self._cleanup_timer: threading.Timer | None = None
        self._shutdown = False
        self._start_cleanup_timer()

    # ------------------------------------------------------------------
    # SpanProcessor interface
    # ------------------------------------------------------------------

    def on_start(self, span: Any, parent_context: Any = None) -> None:
        """Called when a span starts. No-op -- we process on end."""

    def on_end(self, span: Any) -> None:
        """Called when a span ends. Buffer and send if root span."""
        trace_id = format(span.context.trace_id, "032x")
        teckel_span = convert_to_teckel_span(span)
        now = _monotonic_s()
        is_root_span = self._is_root_span(span)
        spans: list[dict[str, Any]] | None = None

        with self._lock:
            # Enforce memory bounds
            if (
                len(self._pending) >= MAX_PENDING_TRACES
                and trace_id not in self._pending
            ):
                oldest_key = next(iter(self._pending))
                del self._pending[oldest_key]
                if self._debug:
                    logger.debug(
                        "[TeckelSpanProcessor] Evicted oldest pending trace: %s",
                        oldest_key,
                    )

            # Buffer span
            if trace_id in self._pending:
                self._pending[trace_id].spans.append(teckel_span)
            else:
                self._pending[trace_id] = _PendingTrace(
                    spans=[teckel_span], first_span_time=now
                )

            # If this is a root span, send the trace
            if is_root_span:
                entry = self._pending.pop(trace_id, None)
                if entry:
                    # Release lock before sending
                    spans = entry.spans

        # Send outside the lock
        if is_root_span and spans is not None:
            self._send_trace(trace_id, span, spans)

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Shutdown the processor."""
        self._shutdown = True
        if self._cleanup_timer:
            self._cleanup_timer.cancel()
            self._cleanup_timer = None
        self._tracer.destroy()

    def force_flush(self, timeout_millis: int = 30000) -> None:
        """Force flush pending traces."""
        self._tracer.flush(timeout_s=timeout_millis / 1000)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @staticmethod
    def _is_root_span(span: Any) -> bool:
        """Check if this is a root span (top-level AI SDK call)."""
        name: str = span.name
        return name in ("ai.generateText", "ai.streamText", "ai.generateObject")

    def _send_trace(
        self, trace_id: str, root_span: Any, spans: list[dict[str, Any]]
    ) -> None:
        attrs: dict[str, Any] = (
            dict(root_span.attributes) if root_span.attributes else {}
        )

        # Extract query and systemPrompt from prompt messages
        query = ""
        system_prompt: str | None = None
        prompt_messages = attrs.get("ai.prompt.messages")
        prompt = attrs.get("ai.prompt")

        if prompt_messages:
            try:
                messages = json.loads(str(prompt_messages))
                for msg in messages:
                    if msg.get("role") == "system":
                        system_prompt = msg.get("content")
                        break
                for i in range(len(messages) - 1, -1, -1):
                    if messages[i].get("role") == "user":
                        query = messages[i].get("content", "")
                        break
            except (json.JSONDecodeError, TypeError):
                query = str(prompt_messages)
        elif prompt:
            query = str(prompt)

        # Extract response
        response = str(attrs.get("ai.response.text", ""))

        # functionId becomes agentName
        agent_name = str(attrs.get("ai.telemetry.functionId", "unknown"))

        # Extract model
        model = attrs.get("gen_ai.request.model") or attrs.get("ai.model.id")
        if model:
            model = str(model)

        # Calculate duration
        start_time_ms = root_span.start_time / 1_000_000
        end_time_ms = root_span.end_time / 1_000_000
        latency_ms = round(end_time_ms - start_time_ms)

        # Fast-path token aggregation for high-volume workloads.
        tokens = _calculate_tokens_from_span_dicts(spans)

        # Extract metadata fields
        session_id = attrs.get("ai.telemetry.metadata.sessionId")
        user_id = attrs.get("ai.telemetry.metadata.userId")

        if session_id:
            session_id = str(session_id)
        if user_id:
            user_id = str(user_id)

        # Collect remaining metadata
        metadata: dict[str, Any] = {}
        for key, value in attrs.items():
            if key.startswith("ai.telemetry.metadata.") and key not in (
                "ai.telemetry.metadata.sessionId",
                "ai.telemetry.metadata.userId",
            ):
                meta_key = key.replace("ai.telemetry.metadata.", "")
                metadata[meta_key] = value

        if self._debug:
            logger.debug(
                "[TeckelSpanProcessor] Sending trace=%s agent=%s spans=%d tokens=%s",
                trace_id,
                agent_name,
                len(spans),
                tokens,
            )

        trace_data: dict[str, Any] = {
            "query": query,
            "response": response,
            "agentName": agent_name,
            "latencyMs": latency_ms,
            "spans": spans,
        }

        if model:
            trace_data["model"] = model
        if tokens["total"] > 0:
            trace_data["tokens"] = tokens
        if session_id:
            trace_data["sessionId"] = session_id
        if user_id:
            trace_data["userId"] = user_id
        if system_prompt:
            trace_data["systemPrompt"] = system_prompt
        if metadata:
            trace_data["metadata"] = metadata

        self._tracer.trace(trace_data)

    def _start_cleanup_timer(self) -> None:
        if self._shutdown:
            return
        self._cleanup_timer = threading.Timer(
            PENDING_TTL_S / 2, self._cleanup_stale_traces
        )
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    def _cleanup_stale_traces(self) -> None:
        if self._shutdown:
            return

        now = _monotonic_s()
        evicted = 0

        with self._lock:
            stale_keys = [
                tid
                for tid, entry in self._pending.items()
                if now - entry.first_span_time > PENDING_TTL_S
            ]
            for key in stale_keys:
                del self._pending[key]
                evicted += 1

        if evicted > 0 and self._debug:
            logger.debug(
                "[TeckelSpanProcessor] Evicted %d stale traces due to TTL", evicted
            )

        self._start_cleanup_timer()


class _PendingTrace:
    __slots__ = ("spans", "first_span_time")

    def __init__(self, spans: list[dict[str, Any]], first_span_time: float) -> None:
        self.spans = spans
        self.first_span_time = first_span_time


def _monotonic_s() -> float:
    """Monotonic time in seconds."""
    import time

    return time.monotonic()


def _calculate_tokens_from_span_dicts(spans: list[dict[str, Any]]) -> dict[str, int]:
    prompt = 0
    completion = 0

    for span in spans:
        prompt_tokens = span.get("promptTokens")
        completion_tokens = span.get("completionTokens")

        if isinstance(prompt_tokens, int):
            prompt += prompt_tokens

        if isinstance(completion_tokens, int):
            completion += completion_tokens

    return {
        "prompt": prompt,
        "completion": completion,
        "total": prompt + completion,
    }
