"""TeckelSpanCollector - Captures OpenTelemetry spans from AI SDK.

Usage::

    from teckel.otel import TeckelSpanCollector

    collector = TeckelSpanCollector()
    # Pass collector.get_tracer() to your OTel-instrumented library
    spans = collector.get_spans()
    collector.shutdown()
"""

from __future__ import annotations

import logging
from typing import Any

from ._utils import convert_to_teckel_span

logger = logging.getLogger("teckel.otel")


class TeckelSpanCollector:
    """Collects AI SDK telemetry spans in memory.

    Creates an isolated TracerProvider that captures spans without
    interfering with any global OpenTelemetry setup.

    Requires ``opentelemetry-api`` and ``opentelemetry-sdk`` as dependencies.
    Install with: ``pip install teckel-ai[otel]``
    """

    def __init__(
        self,
        *,
        register_global: bool = False,
        debug: bool = False,
    ) -> None:
        try:
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import (
                SimpleSpanProcessor,
                SpanExporter,
                SpanExportResult,
            )
            from opentelemetry.sdk.trace.sampling import ALWAYS_ON
        except ImportError as exc:
            raise ImportError(
                "TeckelSpanCollector requires opentelemetry-sdk. "
                "Install with: pip install teckel-ai[otel]"
            ) from exc

        self._debug = debug

        # In-memory exporter that collects spans
        class _CollectorExporter(SpanExporter):
            def __init__(self) -> None:
                self._spans: list[Any] = []
                self._debug = False

            def export(self, spans: Any) -> SpanExportResult:
                if self._debug:
                    logger.debug(
                        "[TeckelSpanCollector] Exporter.export called count=%d names=%s",
                        len(spans),
                        [s.name for s in spans],
                    )
                self._spans.extend(spans)
                return SpanExportResult.SUCCESS

            def shutdown(self) -> None:
                pass

            def force_flush(self, timeout_millis: int = 0) -> bool:
                return True

            def get_spans(self) -> list[Any]:
                return self._spans

            def clear(self) -> None:
                self._spans = []

        self._exporter = _CollectorExporter()
        if debug:
            self._exporter._debug = True
            logger.debug("[TeckelSpanCollector] Debug mode enabled")

        self._provider = TracerProvider(sampler=ALWAYS_ON)
        self._provider.add_span_processor(SimpleSpanProcessor(self._exporter))

        if register_global:
            from opentelemetry import trace

            trace.set_tracer_provider(self._provider)
            if debug:
                logger.debug(
                    "[TeckelSpanCollector] Registered as global tracer provider"
                )

        self._tracer = self._provider.get_tracer("teckel-ai-sdk")

    def get_tracer(self) -> Any:
        """Get the OTel Tracer instance to pass to instrumented libraries."""
        return self._tracer

    def force_flush(self) -> None:
        """Force flush the span processor."""
        self._provider.force_flush()

    def get_spans(self) -> list[dict[str, Any]]:
        """Get collected spans converted to Teckel format (camelCase dicts)."""
        return [convert_to_teckel_span(span) for span in self._exporter.get_spans()]

    def get_raw_spans(self) -> list[Any]:
        """Get raw OTel ReadableSpan objects."""
        return self._exporter.get_spans()

    def clear(self) -> None:
        """Clear all collected spans."""
        self._exporter.clear()

    def shutdown(self) -> None:
        """Shutdown the provider and clean up resources."""
        self._provider.shutdown()
