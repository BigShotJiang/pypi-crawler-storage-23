"""teckel.otel -- OpenTelemetry integration for Teckel AI SDK.

Two usage patterns:

Pattern 1: Auto-tracing
    from teckel.otel import TeckelSpanProcessor
    provider.add_span_processor(TeckelSpanProcessor(api_key="tk_live_..."))

Pattern 2: Manual collection
    from teckel.otel import TeckelSpanCollector, calculate_tokens_from_spans
    collector = TeckelSpanCollector()
    spans = collector.get_spans()
"""

from ._utils import (
    calculate_tokens_from_spans,
    convert_to_teckel_span,
    map_span_type,
    span_id_to_uuid,
    truncate_to_size,
)
from .collector import TeckelSpanCollector
from .processor import TeckelSpanProcessor

__all__ = [
    "TeckelSpanProcessor",
    "TeckelSpanCollector",
    "convert_to_teckel_span",
    "calculate_tokens_from_spans",
    "truncate_to_size",
    "map_span_type",
    "span_id_to_uuid",
]
