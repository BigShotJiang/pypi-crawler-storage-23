"""Shared utilities for OpenTelemetry span conversion."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

# Re-export from shared module
from .._token_utils import calculate_tokens_from_spans as calculate_tokens_from_spans

# Size limits for span fields (must match database constraints)
MAX_TOOL_RESULT_BYTES = 500 * 1024  # 500KB
MAX_TOOL_ARGS_BYTES = 500 * 1024  # 500KB

SPAN_STATUS_CODE_ERROR = 2


def truncate_to_size(obj: Any, max_bytes: int) -> Any:
    """Truncate object to fit within byte limit.

    For lists, keeps as many items as fit.
    For dicts, returns a truncation notice.
    """
    serialized = json.dumps(obj, separators=(",", ":"))
    if len(serialized) <= max_bytes:
        return obj

    if isinstance(obj, list):
        result: list[Any] = []
        current_size = 2  # []
        for item in obj:
            item_json = json.dumps(item, separators=(",", ":"))
            if current_size + len(item_json) + 1 > max_bytes - 50:
                break
            result.append(item)
            current_size += len(item_json) + 1
        return {
            "_truncated": True,
            "_originalCount": len(obj),
            "_keptCount": len(result),
            "items": result,
        }

    return {
        "_truncated": True,
        "_originalSizeBytes": len(serialized),
        "_maxSizeBytes": max_bytes,
        "_preview": serialized[:500],
    }


def map_span_type(span_name: str) -> str:
    """Map AI SDK span names to Teckel span types."""
    if span_name == "ai.toolCall":
        return "tool_call"
    if "doGenerate" in span_name or "doStream" in span_name:
        return "llm_call"
    if (
        span_name.startswith("ai.generateText")
        or span_name.startswith("ai.streamText")
        or span_name.startswith("ai.generateObject")
    ):
        return "agent"
    return "custom"


def span_id_to_uuid(span_id: str) -> str:
    """Convert OTel span ID (16-char hex) to UUID format.

    OTel: "1234567890abcdef" -> UUID: "12345678-90ab-cdef-0000-000000000000"
    """
    padded = span_id.ljust(32, "0")
    return (
        f"{padded[0:8]}-{padded[8:12]}-{padded[12:16]}-"
        f"{padded[16:20]}-{padded[20:32]}"
    )


def convert_to_teckel_span(span: Any) -> dict[str, Any]:
    """Convert an OpenTelemetry ReadableSpan to a Teckel span dict.

    Works with any object that has the ReadableSpan interface:
    - context.span_id, context.trace_id (hex strings via .to_bytes()/.hex())
    - parent (SpanContext | None)
    - name (str)
    - start_time, end_time (nanoseconds int)
    - status (Status with status_code)
    - attributes (dict)
    """
    attributes: dict[str, Any] = dict(span.attributes) if span.attributes else {}
    span_name: str = span.name
    span_type = map_span_type(span_name)

    # OTel Python stores times as nanoseconds (int)
    start_time_ms = span.start_time / 1_000_000
    end_time_ms = span.end_time / 1_000_000
    duration_ms = round(end_time_ms - start_time_ms)

    # Extract span IDs -- OTel Python SpanContext stores IDs as ints,
    # format_span_id/format_trace_id give hex strings
    span_context = span.context
    span_id_hex = format(span_context.span_id, "016x")

    parent_span_id: str | None = None
    if span.parent is not None:
        parent_span_id = span_id_to_uuid(format(span.parent.span_id, "016x"))

    # Determine status
    status_str = "completed"
    status_message: str | None = None
    if hasattr(span.status, "status_code"):
        if span.status.status_code.value == SPAN_STATUS_CODE_ERROR:
            status_str = "error"
        if span.status.description:
            status_message = span.status.description

    teckel_span: dict[str, Any] = {
        "spanId": span_id_to_uuid(span_id_hex),
        "name": span_name,
        "type": span_type,
        "startedAt": datetime.fromtimestamp(
            span.start_time / 1_000_000_000, tz=timezone.utc
        ).isoformat(),
        "endedAt": datetime.fromtimestamp(
            span.end_time / 1_000_000_000, tz=timezone.utc
        ).isoformat(),
        "durationMs": duration_ms,
        "status": status_str,
    }

    if parent_span_id:
        teckel_span["parentSpanId"] = parent_span_id

    if status_message:
        teckel_span["statusMessage"] = status_message

    # Tool call attributes
    if span_type == "tool_call":
        tool_name = attributes.get("ai.toolCall.name")
        if tool_name:
            teckel_span["toolName"] = str(tool_name)

        args_str = attributes.get("ai.toolCall.args")
        if args_str:
            try:
                parsed = json.loads(str(args_str))
                teckel_span["toolArguments"] = truncate_to_size(
                    parsed, MAX_TOOL_ARGS_BYTES
                )
            except (json.JSONDecodeError, TypeError):
                teckel_span["toolArguments"] = {
                    "raw": str(args_str)[:MAX_TOOL_ARGS_BYTES]
                }

        result_str = attributes.get("ai.toolCall.result")
        if result_str:
            try:
                parsed = json.loads(str(result_str))
                if isinstance(parsed, list):
                    normalized: dict[str, Any] = {"items": parsed}
                elif isinstance(parsed, dict):
                    normalized = parsed
                else:
                    normalized = {"value": parsed}
                teckel_span["toolResult"] = truncate_to_size(
                    normalized, MAX_TOOL_RESULT_BYTES
                )
            except (json.JSONDecodeError, TypeError):
                teckel_span["toolResult"] = {
                    "raw": str(result_str)[:MAX_TOOL_RESULT_BYTES]
                }

    # LLM call / agent attributes
    if span_type in ("llm_call", "agent"):
        model = attributes.get("gen_ai.request.model") or attributes.get(
            "ai.model.id"
        )
        if model:
            teckel_span["model"] = str(model)

        input_tokens = attributes.get("gen_ai.usage.input_tokens")
        output_tokens = attributes.get("gen_ai.usage.output_tokens")

        if input_tokens is not None:
            teckel_span["promptTokens"] = int(input_tokens)
        if output_tokens is not None:
            teckel_span["completionTokens"] = int(output_tokens)

    # Agent response text
    if span_type == "agent":
        response_text = attributes.get("ai.response.text")
        if response_text:
            teckel_span["output"] = {"text": str(response_text)}

    # Collect remaining attributes as metadata
    skip_prefixes = ("ai.toolCall.", "gen_ai.usage.")
    skip_keys = {"ai.response.text", "ai.model.id", "gen_ai.request.model"}

    metadata: dict[str, Any] = {}
    for key, value in attributes.items():
        if any(key.startswith(p) for p in skip_prefixes):
            continue
        if key in skip_keys:
            continue
        metadata[key] = value

    if metadata:
        teckel_span["metadata"] = metadata

    return teckel_span
