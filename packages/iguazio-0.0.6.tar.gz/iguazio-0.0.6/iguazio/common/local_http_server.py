# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import threading
import http.server


class LocalHTTPServer:
    """
    A simple HTTP server for running locally.

    Args:
        port (int): The port to bind the server to.
        handler_class: The handler class to handle requests.
        allow_reuse_address (bool, optional): Whether to allow address reuse for fast rebinds.
        timeout (int, optional): Timeout for the server in case the handler does not respond.
    """

    def __init__(self, port, handler_class, allow_reuse_address=True, timeout=None):
        """
        Initialize the Local HTTP server.

        Args:
            port (int): The port to bind the server to.
            handler_class: The handler class to handle requests.
            allow_reuse_address (bool, optional): Whether to allow address reuse for fast rebinds.
            timeout (int, optional): Timeout for the server in case the handler does not respond.
        """
        self.port = port
        self.handler_class = handler_class
        self.timeout = timeout
        self.server = http.server.HTTPServer(
            ("localhost", self.port), self.handler_class
        )
        # Allow address reuse for fast rebinds.
        # it is ok since we are running on localhost, and we control the handler and its shutdown
        self.server.allow_reuse_address = allow_reuse_address
        # Inject the local server into the http server to allow shutdown from the thread
        self.server.local_server = self

        self._thread = None
        self._shutdown_event = threading.Event()

    def start(self):
        """
        Start the HTTP server in a new thread.
        """
        self._thread = threading.Thread(target=self._serve_forever, daemon=True)
        self._thread.start()

    def shutdown(self):
        """
        Shutdown the server cleanly.
        """
        if self.server:
            # Tells serve_forever() to exit
            self.server.shutdown()
            # Closes the underlying socket
            self.server.server_close()
            # Prevent further requests
            self.server = None
        self._shutdown_event.set()

    def wait_for_shutdown(self):
        """
        Wait until the server shuts down or the timeout expires.

        Raises:
            RuntimeError: If the server thread is still alive after shutdown.
        """
        completed = self._shutdown_event.wait(timeout=self.timeout)
        if not completed:
            # If the server is still running after the timeout, we force shutdown
            self.shutdown()
            raise RuntimeError("Timeout waiting for server to shutdown.")

        # Wait a bit more for the thread to finish if it was started
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
            if self._thread.is_alive():
                raise RuntimeError(
                    "Server thread is still alive after shutdown, indicating a potential issue."
                )

    def _serve_forever(self):
        """
        Run the server forever until shutdown is called.
        """
        try:
            self.server.serve_forever()
        finally:
            self._shutdown_event.set()
