# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import pytest
import tests.unit

import iguazio.schemas.serializer as serializer
import iguazio.schemas.v1.resources.access_token as access_token_schema
import iguazio.schemas.v1.resources.user as user_schema
import iguazio.schemas.v1.resources.usergroup as usergroup_schema


class TestSerializer(tests.unit.BaseTestCase):
    def test_deserialize_optional_int_from_string(self):
        token_list_data = {
            "items": [
                {
                    "metadata": {
                        "sessionId": "session123",
                        "tokenType": "Bearer",
                        "issuedTokenType": "JWT",
                        "scope": "openid",
                    },
                    "spec": {
                        "accessToken": "access-token",
                        "idToken": "id-token",
                        "refreshToken": "refresh-token",
                    },
                    "status": {
                        "expiresIn": 3600,
                        "refreshExpiresIn": 7200,
                        "notBeforePolicy": "0",
                        "statusCode": 200,
                    },
                }
            ],
            "status": {"statusCode": 207},
        }

        token_list = serializer.deserialize(
            token_list_data, access_token_schema.AccessTokenList
        )

        assert token_list.items[0].status.expires_in == 3600
        assert isinstance(token_list.items[0].status.expires_in, int)
        assert token_list.items[0].status.refresh_expires_in == 7200
        assert isinstance(token_list.items[0].status.refresh_expires_in, int)
        assert token_list.items[0].status.not_before_policy == 0
        assert isinstance(token_list.items[0].status.not_before_policy, int)

    def test_deserialize_optional_int_invalid_string_raises(self):
        token_list_data = {
            "items": [
                {
                    "metadata": {
                        "sessionId": "session123",
                        "tokenType": "Bearer",
                        "issuedTokenType": "JWT",
                        "scope": "openid",
                    },
                    "spec": {
                        "accessToken": "access-token",
                        "idToken": "id-token",
                        "refreshToken": "refresh-token",
                    },
                    "status": {
                        "expiresIn": 3600,
                        "refreshExpiresIn": 7200,
                        "notBeforePolicy": "invalid",
                        "statusCode": 200,
                    },
                }
            ],
            "status": {"statusCode": 207},
        }

        with pytest.raises(TypeError):
            serializer.deserialize(token_list_data, access_token_schema.AccessTokenList)

    def test_deserialize_optional_nested_schema_from_dict(self):
        access_token_data = {
            "status": {
                "statusCode": 401,
                "errorMessage": "Invalid token",
            }
        }

        token = serializer.deserialize(
            access_token_data, access_token_schema.AccessToken
        )

        assert token.metadata is None
        assert token.spec is None
        assert token.status.status_code == 401
        assert token.status.error_message == "Invalid token"

    def test_round_trip_deserialize_and_serialize_user_response(self):
        user_data = {
            "metadata": {
                "id": "3747a0a7-9346-4e01-9f8d-597a4613ec36",
                "resourceType": "user",
                "username": "test-user",
            },
            "spec": {"email": "test@user.com", "firstName": "test", "lastName": "user"},
            "status": {
                "active": True,
                "createdAt": "2025-07-21T06:25:49.644123Z",
                "ctx": "930c4deb-6c52-4f0b-91e2-2701aa5d9046",
                "groupIds": ["2b3cec97-eb13-40d5-8349-6f6d59b664c1"],
                "statusCode": 200,
            },
            "relationships": [
                {
                    "@type": "type.googleapis.com/usergroup.Group",
                    "metadata": {
                        "id": "2b3cec97-eb13-40d5-8349-6f6d59b664c1",
                        "path": "/group1",
                    },
                    "spec": {"name": "group1"},
                    "status": {},
                }
            ],
        }
        user = serializer.deserialize(
            user_data,
            user_schema.User,
        )

        # Validate fields exist and are as expected
        assert user.metadata.id == user_data["metadata"]["id"]
        assert user.metadata.username == user_data["metadata"]["username"]
        assert user.status.active is user_data["status"]["active"]
        assert user.status.ctx == user_data["status"]["ctx"]
        assert user.status.group_ids == user_data["status"]["groupIds"]
        assert user.spec.email == user_data["spec"]["email"]
        assert user.spec.first_name == user_data["spec"]["firstName"]
        assert user.spec.last_name == user_data["spec"]["lastName"]
        assert user.relationships is not None
        assert len(user.relationships) == 1
        rel = user.relationships[0]
        assert rel.metadata.id == user_data["relationships"][0]["metadata"]["id"]
        assert rel.spec.name == user_data["relationships"][0]["spec"]["name"]

        serialized_user = serializer.serialize(user)
        assert serialized_user == user_data

    def test_missing_required_field_raises(self):
        # Remove required 'id' from metadata
        user_data = {
            "metadata": {
                "resourceType": "user",
                # "username": "missing",
            },
            "spec": {},
            "status": {},
        }
        with pytest.raises(TypeError):
            serializer.deserialize(user_data, user_schema.User)

    def test_invalid_type_raises(self):
        # createdAt should be a datetime string
        user_data = {
            "metadata": {
                "id": "user-id",
                "resourceType": "user",
                "username": "test-user",
            },
            "spec": {},
            "status": {
                "createdAt": 1234,
            },
        }
        with pytest.raises(Exception):
            serializer.deserialize(user_data, user_schema.User)

    def test_unknown_protobuf_type_raises(self):
        user_data = {
            "relationships": [
                {
                    "@type": "type.googleapis.com/unknown.UnknownType",
                    "metadata": {"id": "x", "path": "/"},
                    "spec": {"name": "a"},
                    "status": {},
                }
            ],
            "metadata": {"id": "1", "username": "u"},
            "spec": {},
            "status": {},
        }
        with pytest.raises(ImportError):
            serializer.deserialize(user_data, user_schema.User)

    def test_extra_fields_are_ignored(self):
        user_data = {
            "metadata": {
                "id": "1",
                "resourceType": "user",
                "username": "u",
                "extraField": "should be ignored",
            },
            "spec": {"email": "e@e.e", "firstName": "f", "lastName": "l", "extra": 123},
            "status": {"active": True, "createdAt": "2025-07-21T06:25:49.644Z"},
        }
        user = serializer.deserialize(user_data, user_schema.User)
        assert not hasattr(user.metadata, "extraField")
        assert not hasattr(user.spec, "extra")
        assert user.metadata.id == "1"
        assert user.spec.email == "e@e.e"
        assert user.status.active is True

    def test_partial_data_defaults(self):
        user_data = {
            "metadata": {
                "id": "1",
                "username": "u",
            },
            "spec": {},
            "status": {},
        }
        user = serializer.deserialize(user_data, user_schema.User)
        assert user.metadata.id == "1"
        assert user.metadata.username == "u"
        assert user.status.active is True  # default
        assert user.spec.email is None

    def test_custom_validator_invalid_email(self):
        user_data = {
            "metadata": {
                "id": "1",
                "username": "u",
            },
            "spec": {"email": "invalid-email"},
            "status": {},
        }
        with pytest.raises(ValueError, match="Invalid email format: invalid-email"):
            serializer.deserialize(user_data, user_schema.User)

    def test_repr_user(self):
        user = user_schema.User(
            metadata=user_schema.UserMetadata(
                id="id123", resource_type="user", username="repr-user"
            ),
            spec=user_schema.UserSpec(
                email="repr@user.com", first_name="Repr", last_name="User"
            ),
            status=user_schema.UserStatus(active=True, ctx="ctx123", status_code=200),
            relationships=[
                # Use a group as a relationship
                usergroup_schema.Group(
                    metadata=usergroup_schema.GroupMetadata(
                        id="gid", resource_type="group", path="/g"
                    ),
                    spec=usergroup_schema.GroupSpec(name="group1"),
                    status=usergroup_schema.GroupStatus(),
                )
            ],
        )
        rep = repr(user)
        assert "User(" in rep
        assert "metadata=UserMetadata(" in rep
        assert "username='repr-user'" in rep
        assert "spec=UserSpec(" in rep
        assert "email='repr@user.com'" in rep
        assert "status=UserStatus(" in rep
        assert "active=True" in rep
        assert "relationships=[" in rep
        assert "Group(" in rep

    def test_repr_metadata(self):
        metadata = user_schema.UserMetadata(
            id="id456", resource_type="user", username="meta-user"
        )
        rep = repr(metadata)
        assert "UserMetadata(" in rep
        assert "id='id456'" in rep
        assert "username='meta-user'" in rep

    def test_repr_nested_list(self):
        user_list = user_schema.UserList(
            items=[
                user_schema.User(
                    metadata=user_schema.UserMetadata(
                        id="id1", resource_type="user", username="user1"
                    ),
                    spec=user_schema.UserSpec(email="user1@e.com"),
                    status=user_schema.UserStatus(),
                ),
                user_schema.User(
                    metadata=user_schema.UserMetadata(
                        id="id2", resource_type="user", username="user2"
                    ),
                    spec=user_schema.UserSpec(email="user2@e.com"),
                    status=user_schema.UserStatus(),
                ),
            ],
            status=user_schema.UserListStatus(ctx="ctx-list", status_code=200, total=2),
        )
        rep = repr(user_list)
        assert "UserList(" in rep
        assert "items=[" in rep
        assert "User(" in rep
        assert "username='user1'" in rep
        assert "username='user2'" in rep
        assert "status=UserListStatus(" in rep
        assert "total=2" in rep
