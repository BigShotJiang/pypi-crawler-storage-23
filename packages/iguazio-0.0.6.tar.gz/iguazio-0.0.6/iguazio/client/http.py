# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import httpx
from http import HTTPStatus

import iguazio.logger as logger
import iguazio.common.constants as constants


class _BaseHTTPClient:
    def __init__(
        self,
        parent_logger: logger.Logger,
        api_url: str,
        *,
        timeout: int = constants._Defaults.request_timeout.value,
        retries: int = constants._Defaults.retries.value,
        verify: bool = True,
    ) -> None:
        super().__init__()
        self._logger = parent_logger.get_child("httpc")
        self._transport = httpx.HTTPTransport(verify=verify, retries=retries)
        self._cookies = httpx.Cookies()
        self._headers = constants._RequestHeaders.default_headers()
        self._api_url = api_url.rstrip("/")
        self._session = httpx.Client(
            base_url=self._api_url,
            timeout=timeout,
            mounts={
                "http://": self._transport,
                "https://": self._transport,
            },
            cookies=self._cookies,
        )

    def post(self, path, error_message: str = "", **kwargs) -> httpx.Response:
        return self.send_request("POST", path, error_message, **kwargs)

    def get(self, path, error_message: str = "", **kwargs) -> httpx.Response:
        return self.send_request("GET", path, error_message, **kwargs)

    def delete(self, path, error_message: str = "", **kwargs) -> httpx.Response:
        ignore_status_codes = []
        if kwargs.pop("ignore_missing", False):
            ignore_status_codes.append(HTTPStatus.NOT_FOUND)
        return self.send_request(
            "DELETE",
            path,
            error_message,
            ignore_status_codes=ignore_status_codes,
            **kwargs,
        )

    def put(self, path, error_message: str = "", **kwargs) -> httpx.Response:
        return self.send_request("PUT", path, error_message, **kwargs)

    def close(self):
        self._session.close()

    def send_request(
        self,
        method,
        path,
        error_message: str,
        version: str = "v1",
        full_path: bool = False,
        **kwargs,
    ) -> httpx.Response:
        endpoint, headers, expected_status_codes, ignore_status_codes = (
            self._prepare_request(
                kwargs,
                method,
                path,
                version,
                full_path,
            )
        )
        response = self._session.request(method, endpoint, headers=headers, **kwargs)
        self._handle_response(
            error_message,
            expected_status_codes,
            ignore_status_codes,
            kwargs,
            method,
            path,
            response,
        )

        return response

    def _handle_response(
        self,
        error_message,
        expected_status_codes,
        ignore_status_codes,
        kwargs,
        method,
        path,
        response,
    ):
        # Do not read the response body when streaming (e.g. log bundle download).
        if kwargs.get("stream"):
            ctx = None
        else:
            ctx = self._resolve_ctx_from_response(response)
        # updating the cookies jar with server-response
        self._cookies.update(response.cookies)
        self._logger.debug(
            "Received response", status_code=response.status_code, ctx=ctx
        )
        log_kwargs = copy.deepcopy(kwargs)
        log_kwargs.update(
            {
                "method": method,
                "path": path,
                "status_code": response.status_code,
                "ctx": ctx,
            }
        )
        if response.is_error and response.status_code not in ignore_status_codes:
            if kwargs.get("stream"):
                self._logger.warn("Request failed", **log_kwargs)
                self._close_response_and_raise(
                    response,
                    kwargs,
                    httpx.HTTPStatusError(
                        error_message,
                        request=response.request,
                        response=response,
                    ),
                )
            if response.content:
                errors = self._resolve_errors_from_response(response)
                if errors:
                    error_message = f"{error_message}: {str(errors)}"
                    log_kwargs.update({"errors": errors})
                else:
                    log_kwargs.update({"response_content": response.content})

            self._logger.warn("Request failed", **log_kwargs)

            # reraise with a custom error message to avoid the default one which
            # is not very customizable and friendly
            raise httpx.HTTPStatusError(
                error_message, request=response.request, response=response
            )

        if expected_status_codes and response.status_code not in expected_status_codes:
            self._logger.warn(
                "Unexpected status code",
                expected_status_codes=expected_status_codes,
                actual_status_code=response.status_code,
                **log_kwargs,
            )
            exc = httpx.HTTPStatusError(
                f"Unexpected status code: {response.status_code}",
                request=response.request,
                response=response,
            )
            self._close_response_and_raise(response, kwargs, exc)

    def _close_response_and_raise(self, response, kwargs, exc):
        """When stream=True, close response before raising to avoid leaking connections."""
        if kwargs.get("stream"):
            response.close()
        raise exc

    def _prepare_request(
        self,
        kwargs: dict,
        method: str,
        path: str,
        version: str = "v1",
        full_path: bool = False,
    ):
        endpoint = f"/{path.lstrip('/')}"
        if not full_path:
            endpoint = f"/api/{version}{endpoint}"
        if kwargs.get("timeout") is None:
            kwargs["timeout"] = constants._Defaults.request_timeout.value
        self._logger.debug(
            "Sending request", method=method, endpoint=endpoint, **kwargs
        )
        headers = copy.deepcopy(self._headers)
        headers.update(kwargs.pop("headers", {}))
        # setting the cookie jar to the session
        # this is mostly needed for first request onwards, but it's not harmful to set it every time
        self._session.cookies.update(self._cookies)
        ignore_status_codes = kwargs.pop("ignore_status_codes", [])
        expected_status_codes = kwargs.pop("expected_status_codes", [])
        return endpoint, headers, expected_status_codes, ignore_status_codes

    @staticmethod
    def _resolve_ctx_from_response(response: httpx.Response):
        try:
            return response.json().get("status", {}).get("ctx")
        except Exception:
            return None

    @staticmethod
    def _resolve_errors_from_response(response):
        try:
            return response.json().get("status", {}).get("errorMessage")
        except Exception:
            return None
