# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest

import requests
import requests.packages

import iguazio.client.auth
import iguazio.client.http
import tests.unit


# TODO: Create an integration base test class to handle setup and teardown
class TestAuthClient(tests.unit.BaseTestCase):
    def setup_class(self):
        super().setup_class()
        # TODO: Replace with actual base URL of the Iguazio API
        self.base_url = ""
        self.oauth_client = iguazio.client.auth._AuthClient(
            api_url=self.base_url,
            parent_logger=self.logger,
            http_client=iguazio.client.http._BaseHTTPClient(
                parent_logger=self.logger,
                api_url=self.base_url,
                timeout=30,
                retries=3,
                verify=False,
            ),
        )

    @unittest.skip("Skipping test_login_flow for manual testing")
    def test_login_flow(self):
        requests.packages.urllib3.disable_warnings()
        self.oauth_client.login()
        print("Access Token:", self.oauth_client.access_token)
        print("Refresh Token:", self.oauth_client.refresh_token)
        assert self.oauth_client.access_token is not None, (
            "Access token should not be None after login"
        )
        assert self.oauth_client.refresh_token is not None, (
            "Refresh token should not be None after login"
        )

        response = requests.get(
            f"{self.base_url}/api/v1/authentication/self",
            headers={"Authorization": f"Bearer {self.oauth_client.access_token}"},
            verify=False,
        )
        assert response.status_code == 200, (
            "API request should succeed with valid access token"
        )
        response_json = response.json()
        print("API Response:", response_json)
        assert "metadata" in response_json, "Response should contain 'metadata' field"
        assert "username" in response_json["metadata"], (
            "'metadata' should contain 'username' field"
        )
        assert "ctx" in response_json["status"], "'status' should contain 'ctx' field"

    @unittest.skip("Skipping test_refresh_token_flow for manual testing")
    def test_refresh_token_flow(self):
        requests.packages.urllib3.disable_warnings()
        self.oauth_client.login()
        original_access_token = self.oauth_client.access_token
        original_refresh_token = self.oauth_client.refresh_token
        print("Access Token:", self.oauth_client.access_token)
        print("Refresh Token:", self.oauth_client.refresh_token)
        assert original_access_token is not None, (
            "Original access token should not be None"
        )
        assert original_refresh_token is not None, (
            "Original refresh token should not be None"
        )

        # Refresh the access token
        self.oauth_client._refresh_access_token()

        assert self.oauth_client.access_token is not None, (
            "Access token should not be None after refresh"
        )
        assert self.oauth_client.access_token != original_access_token, (
            "Access token should be different after refresh"
        )
        assert self.oauth_client.refresh_token is not None, (
            "Refresh token should not be None after refresh"
        )
        assert self.oauth_client.refresh_token != original_refresh_token, (
            "Refresh token should be different after refresh"
        )


if __name__ == "__main__":
    unittest.main()
