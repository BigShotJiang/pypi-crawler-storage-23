# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import base64
import os.path
import threading
import time
import typing
import urllib.parse
import webbrowser
import http.server
import httpx
import json
import yaml

import iguazio.logger
import iguazio.common.constants
import iguazio.common.helpers
import iguazio.common.local_http_server
import iguazio.client.http as base_client


class _AuthClient:
    """
    The Auth Client handles the OAuth2 authentication flow for the Iguazio API, using the Iguazio backend services.
    """

    redirect_uri = f"http://localhost:{iguazio.common.constants._Defaults.local_auth_server_port.value}"

    def __init__(
        self,
        api_url: str,
        http_client: base_client._BaseHTTPClient,
        parent_logger: iguazio.logger.Logger = None,
        use_token_file: bool = True,
        auto_login: bool = True,
        token_file_path: typing.Optional[str] = None,
        token_name: typing.Optional[str] = None,
        service_account_token_file: typing.Optional[str] = None,
    ):
        self.api_url = api_url
        self.http_client = http_client
        self.logger = parent_logger.get_child("auth-client")
        self._auto_login = auto_login
        self._service_account_token_file = (
            service_account_token_file
            or iguazio.common.constants._Defaults.default_service_account_token_file_path.value
        )
        self._use_service_account_token = False
        if not use_token_file:
            self._use_service_account_token = os.path.exists(
                os.path.expanduser(self._service_account_token_file)
            )

        self._access_token = None
        self._refresh_token = None
        self._expires_at = None
        self._access_token_ttl = None
        self._resolved_token_name = None
        # Store the token file path and token name for later use (e.g., saving after login)
        self._token_file_path = (
            token_file_path
            if token_file_path
            else iguazio.common.constants._Defaults.default_token_file_path.value
        )
        self._token_name = (
            token_name
            if token_name
            else iguazio.common.constants._Defaults.default_token_name.value
        )
        if self._use_service_account_token:
            self._auto_login = False
            self._load_service_account_token_file(self._service_account_token_file)
        elif use_token_file:
            self._load_token_file(
                token_file_path=token_file_path, token_name=token_name
            )

    @property
    def access_token(self):
        """
        Returns the access token if available, otherwise None.
        """
        return self._access_token

    @property
    def refresh_token(self):
        """
        Returns the refresh token if available, otherwise None.
        """
        return self._refresh_token

    @property
    def resolved_token_name(self):
        """
        Returns the name of the token that was resolved during initialization.
        """
        return self._resolved_token_name

    def set_access_token(self, token: str, refresh_token: typing.Optional[str] = None):
        """
        Sets the access token and optionally the refresh token.
        This can be used to set the tokens manually, for example when using a different authentication method.
        If the access token is invalid, a ValueError will be raised and the previous tokens will be kept.

        Args:
            token (str): The access token to set.
            refresh_token (str, optional): The refresh token to set. If not provided, the existing refresh token will be kept.

        Raises:
            ValueError: If the provided access token is invalid.
        """
        previous_access_token = self._access_token
        previous_refresh_token = self._refresh_token
        self._access_token = token
        if refresh_token:
            self._refresh_token = refresh_token

        try:
            self._parse_access_token()
        except ValueError:
            # Revert to previous tokens if parsing failed
            self._access_token = previous_access_token
            self._refresh_token = previous_refresh_token
            raise

    def clear_access_token(self):
        """
        Clears the access token after logging out. Keeps the refresh token for future use if it's an offline session.
        """
        self._access_token = None
        self._expires_at = None
        self._access_token_ttl = None

    def login(
        self,
        offline_access: bool = True,
        token_name: typing.Optional[str] = None,
        output_token_file: typing.Optional[str] = None,
        no_browser: bool = False,
    ):
        """
        Initiates the OAuth2 login flow.

        Args:
            offline_access (bool): Whether to request offline access (refresh token).
            token_name (str, optional): The name of the token in the token file.
                If None, uses the name specified during client initialization.
            output_token_file (str, optional): The path to the token file.
                If None, uses the path specified during client initialization.
            no_browser (bool): If True, the user will be prompted to open a browser and enter the code manually. Defaults to False.
        """
        # Use the values from init if not explicitly provided
        # Update the stored values if new ones are provided for consistency
        self._token_file_path = output_token_file or self._token_file_path
        self._token_name = token_name or self._token_name

        if no_browser:
            self._login_manual_flow(
                offline_access, self._token_name, self._token_file_path
            )
        else:
            self._login_browser_flow(
                offline_access, self._token_name, self._token_file_path
            )

    def _login_browser_flow(
        self, offline_access: bool, token_name: str, output_token_file: str
    ):
        """
        Initiates the OAuth2 login flow by opening a web browser to the Iguazio login page.
        After successful login, the request is redirected to a local server, which handles the callback
        and retrieves the access and refresh tokens.
        """
        port = iguazio.common.constants._Defaults.local_auth_server_port.value

        # Inject the client instance into the handler class so the token can be set in the http callback
        handler_class = _AuthCallbackHandler
        handler_class.client = self

        # Start a temporary server to listen for the callback
        server = iguazio.common.local_http_server.LocalHTTPServer(
            port=port,
            handler_class=handler_class,
            timeout=iguazio.common.constants._Defaults.local_auth_server_timeout.value,
        )
        server.start()

        # Open the authentication URL in the default web browser, and redirect to the local server
        auth_request_url = f"{self.api_url}/api/v1/authentication/login?redirectUri={self.redirect_uri}"
        if offline_access:
            auth_request_url += "&access=offline"

        try:
            webbrowser.open(auth_request_url)

            # Wait for the server to handle the callback
            server.wait_for_shutdown()
        except KeyboardInterrupt:
            self.logger.warn("Login flow interrupted by user")
            server.shutdown()
            return
        except RuntimeError as exc:
            self.logger.error("Failed to authenticate", exc=str(exc))
            return

        # parse token for the TTLs
        self._parse_access_token()

        if offline_access:
            self._create_or_update_token_file(output_token_file, token_name)

        # Set the resolved token name so it can be retrieved later
        self._resolved_token_name = token_name
        self.logger.info("Successfully logged in")

    def _login_manual_flow(
        self, offline_access: bool, token_name: str, output_token_file: str
    ):
        """
        Initiates the manual login flow.
        Instructs the user to visit the Iguazio login page, which displays a manual login code.
        The user must copy the code and paste it into the prompt.
        """
        auth_request_url = f"{self.api_url}/api/v1/authentication/login"

        # Tell Keycloak to redirect back to our callback endpoint
        # This ensures the browser flow completes and the backend can display the code
        redirect_uri = f"{self.api_url}/api/v1/authentication/login-callback-manual"
        params = [f"redirectUri={redirect_uri}"]

        if offline_access:
            params.append("access=offline")

        if params:
            auth_request_url += "?" + "&".join(params)

        print(
            "You are logging in to Iguazio without access to a browser.\n"
            + "Please open the following URL in a browser and copy the output code to continue the authentication process."
            f"\n\n{auth_request_url}\n\n"
        )

        code = input("Enter the code from the browser: ").strip()
        if not code:
            self.logger.error("No code provided")
            return

        try:
            # Call login-callback with the manual code AND the redirectUri used
            # The backend needs the redirectUri to complete the token exchange with Keycloak
            response = self.http_client.get(
                f"authentication/login-callback-manual?code={code}&redirectUri={redirect_uri}",
                error_message="Failed to complete login flow",
            )
            response.raise_for_status()
            token_response = response.json()

            self._handle_token_response(token_response)

        except Exception as exc:
            self.logger.error("Failed to authenticate", exc=str(exc))
            return

        # parse token for the TTLs
        self._parse_access_token()

        if offline_access:
            self._create_or_update_token_file(output_token_file, token_name)

        # Set the resolved token name so it can be retrieved later
        self._resolved_token_name = token_name
        self.logger.info("Successfully logged in")

    def enrich_auth_headers(self, headers: dict):
        """
        Ensure that the provided headers contain the authorization header for the access token.
        If the provided headers already contain an authorization header, it will be preserved.
        If the access token is not available, it will refresh the token if possible.
        """

        # If the headers already contain an authorization header, return them as is (case-insensitive)
        if headers.get("Authorization") or headers.get("authorization"):
            return headers

        self._refresh_token_if_needed()
        if not self.access_token:
            raise ValueError("Access token is not available")

        headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def _refresh_token_if_needed(self):
        """
        Check if the access token is valid and refresh it if needed.

        :return: The access token if available, otherwise None.
        """
        login_required = False
        now = time.time()
        if self._access_token_needs_refresh(now):
            if self._use_service_account_token:
                self._load_service_account_token_file(self._service_account_token_file)
                return self._access_token
            if self._refresh_token:
                self.logger.debug("Refreshing access token")
                try:
                    self._refresh_access_token()
                except (ValueError, httpx.HTTPStatusError) as exc:
                    # If the refresh failed and the access token is still valid, we can continue using it
                    if self._expires_at is not None and now >= self._expires_at:
                        self.logger.warn(
                            "Access token expired and refresh failed, re-login required",
                            exc=str(exc),
                        )
                        self._access_token = None
                        self._refresh_token = None
                        self._expires_at = None
                        self._access_token_ttl = None
                    login_required = True
            else:
                self.logger.warn(
                    "Access token needs refresh but no refresh token is available"
                )
                login_required = True

        if login_required and self._auto_login:
            self.login()
        elif login_required:
            raise RuntimeError("No authentication is available, login required")

        return self._access_token

    def _access_token_needs_refresh(self, now: float = None) -> bool:
        now = now or time.time()
        # Refresh the access token if 50% of its TTL has passed
        return not self.access_token or (
            self.access_token
            and self._access_token_ttl
            and now >= self._expires_at - (self._access_token_ttl / 2)
        )

    def _refresh_access_token(self, suppress_errors: bool = False):
        """
        Refresh the access token using the refresh token.

        Args:
            suppress_errors: If True, suppresses warning logs for expected failures (e.g., 401).
        """
        if not self._refresh_token:
            raise ValueError("Refresh token is not available")

        kwargs = {
            "error_message": "Failed to refresh access token",
            "json": {"refreshToken": self._refresh_token},
        }
        if suppress_errors:
            kwargs["ignore_status_codes"] = [401]

        response = self.http_client.post(
            "authentication/refresh-access-token",
            **kwargs,
        )
        response.raise_for_status()
        token_response = response.json()

        self._handle_token_response(token_response)

    def _handle_token_response(self, token_response: dict):
        """
        Extracts tokens from the response and updates the client state.
        """
        # Extract the new tokens:
        access_token = token_response.get("spec", {}).get("accessToken")
        refresh_token = token_response.get("spec", {}).get("refreshToken")

        if not access_token or not refresh_token:
            raise ValueError("Failed to retrieve access token from response")

        # Update the access and refresh tokens
        self._access_token = access_token
        self._refresh_token = refresh_token
        self._parse_access_token()

    def _parse_access_token(self):
        """
        Parse the access token to extract the expiration time and TTL.
        """
        if not self._access_token:
            return

        # A JWT is just 3 base64-encoded JSON blobs, separated by dots: 'header.payload.signature'
        # We only need the payload part to extract the times
        token_parts = self._access_token.split(".")
        if len(token_parts) != 3:
            raise ValueError("Invalid JWT token format")

        # Decode the payload part and add padding if needed
        payload = token_parts[1]
        padding_needed = 4 - len(payload) % 4
        if padding_needed:
            payload += "=" * padding_needed
        decoded_payload = base64.urlsafe_b64decode(payload.encode("utf-8"))

        token_info = json.loads(decoded_payload.decode("utf-8"))

        # Extract the expiration time (exp) and issued at time (iat) and calculate the TTL
        self._access_token_ttl = token_info.get("exp", 0) - token_info.get("iat", 0)
        self._expires_at = token_info.get("exp", 0)

    def _load_service_account_token_file(self, token_file_path: str):
        """
        Load the service account access token from a file and set it as the access token.
        """
        token_file_path = (
            token_file_path
            or iguazio.common.constants._Defaults.default_service_account_token_file_path.value
        )
        token_file = os.path.expanduser(token_file_path)
        if not os.path.exists(token_file):
            raise FileNotFoundError(
                f"Service account token file not found at specified path: {token_file}"
            )
        with open(token_file, "r", encoding="utf-8") as token_file_obj:
            token = token_file_obj.read().strip()
        if not token:
            raise ValueError(
                f"Service account token file is empty or invalid: {token_file}"
            )
        self._refresh_token = None
        self.set_access_token(token)

    def _load_token_file(
        self,
        token_file_path: typing.Optional[str] = None,
        token_name: typing.Optional[str] = None,
    ):
        """
        Load the token file and find a valid token to use.

        If a specific token_name is provided, that exact token must exist and be valid,
        otherwise an error is raised.

        If token_name is None, resolution uses 'default' token if it exists,
        otherwise falls back to the first token in the file.

        Args:
            token_file_path (str, optional): The path to the token file.
                If None, uses the default path (~/.igz.yml).
            token_name (str, optional): The name of the token to load from the file.
                If None, resolves token automatically.

        Raises:
            FileNotFoundError: If a specific token_file_path is provided and file doesn't exist.
            ValueError: If token_name is specified and the token is not found or invalid.
            RuntimeError: If no valid tokens are found in the token file.
        """
        specific_file_requested = bool(token_file_path)
        specific_token_requested = bool(token_name)

        secret_tokens = self._read_token_file(
            token_file_path, specific_file_requested, specific_token_requested
        )
        if not secret_tokens:
            return

        if specific_token_requested:
            resolved_name, token_value = self._resolve_specific_token(
                secret_tokens, token_name
            )
        else:
            resolved_name, token_value = self._resolve_token(secret_tokens)

        self._validate_and_set_token(resolved_name, token_value)

    def _read_token_file(
        self,
        token_file_path: typing.Optional[str],
        specific_file_requested: bool,
        specific_token_requested: bool,
    ) -> typing.Optional[list]:
        """
        Read and validate the token file.

        Returns:
            List of token entries if successful, None if file should be skipped.

        Raises:
            FileNotFoundError: If specific file requested but doesn't exist.
            ValueError: If specific token requested but file format is invalid.
        """
        if not token_file_path:
            token_file_path = (
                iguazio.common.constants._Defaults.default_token_file_path.value
            )

        token_file = os.path.expanduser(token_file_path)

        # Check file existence
        if not os.path.exists(token_file):
            if specific_file_requested:
                raise FileNotFoundError(
                    f"Token file not found at specified path: {token_file}. "
                    "Please verify the path is correct, omit 'token_file_path' to use the default location, "
                    "or set 'use_token_file=False' to disable token file loading."
                )
            self.logger.info(
                f"Token file not found at default location ({token_file}), "
                "a new one will be created after login"
            )
            return None

        # Read file contents
        with open(token_file, "r", encoding="utf-8") as f:
            token_file_contents = yaml.safe_load(f)

        # Validate file format
        if not token_file_contents or "secretTokens" not in token_file_contents:
            if specific_token_requested:
                raise ValueError(
                    f"Invalid token file format: missing 'secretTokens' key in {token_file}"
                )
            return None

        secret_tokens = token_file_contents["secretTokens"]
        if not secret_tokens:
            if specific_token_requested:
                raise ValueError(f"No tokens found in token file: {token_file}")
            return None

        return secret_tokens

    def _resolve_specific_token(
        self, secret_tokens: list, token_name: str
    ) -> tuple[str, str]:
        """
        Resolve a specific token by name.

        Args:
            secret_tokens: List of token entries from the token file.
            token_name: The name of the token to find.

        Returns:
            Tuple of (token_name, token_value).

        Raises:
            ValueError: If token not found or has no value.
        """
        token_entry = next(
            (t for t in secret_tokens if t.get("name") == token_name), None
        )
        if not token_entry:
            raise ValueError(f"Token '{token_name}' not found in token file")

        token_value = token_entry.get("token", "")
        if not token_value:
            raise ValueError(f"Token '{token_name}' has no value")

        return token_name, token_value

    def _resolve_token(self, secret_tokens: list) -> tuple[str, str]:
        """
        Resolve a token from the token file.

        Resolution logic:
        1. Look for a token named 'default'.
        2. If found, it must be unique.
        3. If not found, fall back to the first token in the file.

        Args:
            secret_tokens: List of token entries from the token file.

        Returns:
            Tuple of (token_name, token_value).

        Raises:
            RuntimeError: If no tokens exist, duplicate 'default' entries found,
                          or token has no value.
        """
        if not secret_tokens:
            raise RuntimeError("No tokens found in token file")

        # Look for default token
        matches = [
            token
            for token in secret_tokens
            if token.get("name")
            == iguazio.common.constants._Defaults.default_token_name.value
        ]
        if len(matches) > 1:
            raise RuntimeError(
                f"Found {len(matches)} entries for 'default' token. "
                "Please ensure only one 'default' token exists in the token file."
            )

        # Use the first token in the file if no "default" token is found
        token_entry = matches[0] if matches else secret_tokens[0]

        token_name = token_entry.get("name", "")
        token_value = token_entry.get("token", "")

        if not token_value:
            raise RuntimeError(f"Resolved token {token_name!r} has no value")

        return token_name, token_value

    def _validate_and_set_token(self, token_name: str, token_value: str):
        """
        Validate a token with the server and set it as the active token.

        Args:
            token_name: The name of the token (for logging/error messages).
            token_value: The refresh token value to validate.

        Raises:
            RuntimeError: If token validation fails.
        """
        self._refresh_token = token_value
        self._resolved_token_name = token_name
        try:
            self._refresh_access_token(suppress_errors=True)
            self.logger.info(f"Using token: '{token_name}'")
        except Exception as exc:
            self._refresh_token = None
            self._resolved_token_name = None
            raise RuntimeError(
                f"Token '{token_name}' is not valid. "
                "Please login again or provide a valid token."
            ) from exc

    def _refresh_access_tokens(self, refresh_tokens: list[str]) -> dict:
        """
        Refresh multiple access tokens in a single batch request.

        Args:
            refresh_tokens: List of refresh token strings.

        Returns:
            dict: The raw response containing items with access tokens and their statuses.
        """
        response = self.http_client.post(
            "authentication/refresh-access-tokens",
            error_message="Failed to refresh access tokens",
            json={
                "refreshTokens": refresh_tokens,
                "mode": 2,
            },  # mode 2 = continue on errors
        )
        response.raise_for_status()
        return response.json()

    def _create_or_update_token_file(
        self,
        output_token_file: str = iguazio.common.constants._Defaults.default_token_file_path.value,
        token_name: str = iguazio.common.constants._Defaults.default_token_name.value,
    ):
        """
        Create or update the token file with the offline token.
        """

        # Early return if no refresh token is available, to avoid creating an empty token file or overwriting an existing file with empty tokens.
        if self._refresh_token is None:
            raise RuntimeError(
                "Refresh token is not available, cannot create or update token file"
            )

        output_token_file = os.path.expanduser(output_token_file)
        token_file_format = {
            "secretTokens": [],
        }

        # open existing file if it exists, otherwise create a new one
        if os.path.exists(output_token_file):
            with open(output_token_file, "r", encoding="utf-8") as f:
                token_file_format = yaml.safe_load(f)

        # Add the new token or update the existing one
        token_exists = False
        for token in token_file_format["secretTokens"]:
            if token.get("name") == token_name:
                token["token"] = self._refresh_token
                token_exists = True
                break

        if not token_exists:
            token_file_format["secretTokens"].append(
                {
                    "name": token_name,
                    "token": self._refresh_token,
                }
            )

        # Save the updated token file
        with open(output_token_file, "w", encoding="utf-8") as f:
            yaml.dump(
                token_file_format, f, default_flow_style=False, allow_unicode=True
            )

        self.logger.info(
            f"Tokens saved to {output_token_file}. You can use this file for offline access."
        )


class _AuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """
    Handles authorization callback requests from the Iguazio login page.
    Extracts the access and refresh tokens from the query parameters and sends a response to the browser.
    """

    client = None

    def do_GET(self):
        try:
            # Parse URL and query params
            parsed_url = urllib.parse.urlparse(self.path)
            query_params = urllib.parse.parse_qs(parsed_url.query)

            code = query_params.get("code", [None])[0]
            state = query_params.get("state", [None])[0]

            response = self.client.http_client.get(
                f"authentication/login-callback?redirectUri={self.client.redirect_uri}&code={code}&state={state}",
                error_message="Failed to complete login flow",
            )
            response.raise_for_status()
            token_response = response.json()

            # Handle the token response using the client's method
            self.client._handle_token_response(token_response)

            if not self.client._access_token:
                self.send_response(400)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                self.wfile.write(b"Error: No access token received.")
                return

            # Send a html response to the browser
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            html = self._get_successful_response_html()
            self.wfile.write(html.encode("utf-8"))
        finally:
            # Tell the server to shut down, so we can exit the thread
            threading.Thread(
                target=self.server.local_server.shutdown, daemon=True
            ).start()

    def log_message(self, format, *args):
        # Suppress HTTP server logs by overriding this method with a nop
        pass

    @staticmethod
    def _get_successful_response_html():
        """
        Returns the HTML response to be displayed after successful login, while injecting the logo as base64
        """
        logo_file_path = os.path.join(
            iguazio.common.helpers.get_base_sdk_path(), "client", "assets", "logo.png"
        )
        with open(logo_file_path, "rb") as f:
            logo_base64 = base64.b64encode(f.read()).decode("utf-8")

        html_template_path = os.path.join(
            iguazio.common.helpers.get_base_sdk_path(),
            "client",
            "assets",
            "login_success.html",
        )
        with open(html_template_path, "r", encoding="utf-8") as f:
            html_template = f.read()

        # Replace the logo placeholder with the base64-encoded image
        html = html_template.replace(
            '<img id="logo" alt="App Logo"/>',
            f'<img id="logo" src="data:image/png;base64,{logo_base64}" alt="App Logo" />',
        )
        return html
