# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import logging
import typing
import contextvars
import contextlib
import os

import iguazio.common.helpers as helpers
import iguazio.common.constants as constants
import iguazio.client.http as base_client
import iguazio.client.auth as auth_client
import iguazio.logger


class APIClient:
    """
    Client to communicate with the Iguazio API.

    Args:
        api_url (str): The system's API endpoint.
        timeout (int): Protocol timeout.
        retries (int): Number of retries for a request before failing.
        log_level (str): Log level for the client.
        logger (logging.Logger, optional): Logger instance to use.
        verify_ssl (bool): Whether to verify SSL certificates (default: True).
        auto_login (bool): Whether to automatically log in on unauthenticated requests (default: True).
        use_token_file (bool): Whether to load/save the token from/to a file (default: True).
        token_file_path (str, optional): The path to the token file. Defaults to ~/.igz.yml.
            If a specific path is provided and the file doesn't exist, a FileNotFoundError is raised.
            If using the default path and the file doesn't exist, it will be created after login.
            Used only if use_token_file is True.
        token_name (str, optional): The name of the token to load from the token file.
            If provided, that specific token must exist and be valid.
            If None (default), uses 'default' token if it exists, otherwise the first token.
        service_account_token_file (str, optional): Path to the service account token file.
            Defaults to the in-cluster Kubernetes service account token file.
            Environment variable: `IGUAZIO_SERVICE_ACCOUNT_TOKEN_FILE`.
            Auto-detection runs only when use_token_file is False.
    """

    __DEFAULT_EXTERNAL_VERSION_NUMBER = "4.0.0"

    def __init__(
        self,
        *,
        api_url: str = "",
        timeout: int = constants._Defaults.request_timeout.value,
        retries: int = constants._Defaults.retries.value,
        log_level: str = constants._Defaults.log_level.value,
        logger: typing.Optional[logging.Logger] = None,
        verify_ssl: bool = True,
        auto_login: bool = True,
        use_token_file: bool = True,
        token_file_path: typing.Optional[str] = None,
        token_name: typing.Optional[str] = None,
        service_account_token_file: typing.Optional[str] = None,
    ):
        self._logger = iguazio.logger.create_logger(
            level=log_level, name="client", logger=logger
        )
        api_url = helpers.get_endpoint(
            api_url, default_scheme=constants._Defaults.protocol_scheme.value
        )
        self._client = base_client._BaseHTTPClient(
            parent_logger=self._logger,
            api_url=api_url,
            timeout=timeout,
            retries=retries,
            verify=verify_ssl,
        )

        resolved_service_account_token_file = self._resolve_service_account_token_file(
            service_account_token_file
        )
        self._auth_client = auth_client._AuthClient(
            api_url=api_url,
            http_client=self._client,
            parent_logger=self._logger,
            use_token_file=use_token_file,
            auto_login=auto_login,
            token_file_path=token_file_path,
            token_name=token_name,
            service_account_token_file=resolved_service_account_token_file,
        )

        # TODO: get version and handle login
        self._version = None

    def _resolve_service_account_token_file(
        self, service_account_token_file: typing.Optional[str]
    ) -> str:
        """
        Resolve service account token file path from params or environment.
        """
        env_sa_token_file = os.getenv(
            constants._EnvVars.service_account_token_file.value
        )
        return (
            service_account_token_file
            or env_sa_token_file
            or constants._Defaults.default_service_account_token_file_path.value
        )

    def set_access_token(self, token: str, refresh_token: typing.Optional[str] = None):
        """
        Sets the access token for authentication.
        If the access token is invalid, a ValueError will be raised and the previous tokens will be kept.

        Args:
            token (str): The access token.
            refresh_token (str): The refresh token (optional).

        Raises:
            ValueError: If the token is invalid.
        """
        self._auth_client.set_access_token(token, refresh_token)

    def clear_access_token(self):
        """
        Clears the access token after logging out. Keeps the refresh token for future use if it's an offline session.
        """
        self._auth_client.clear_access_token()

    def login(
        self,
        offline_access: bool = True,
        token_name: typing.Optional[str] = None,
        output_token_file: typing.Optional[str] = None,
        no_browser: bool = False,
    ):
        """
        Authenticates to the API server using oauth2 flow.

        Args:
            offline_access (bool): Whether to request offline access.
            token_name (str, optional): Name of the token to save.
                If None, uses the name specified during client initialization.
            output_token_file (str, optional): Path to save the token file.
                If None, uses the path specified during client initialization.
            no_browser (bool): If True, the user will be prompted to open a browser and enter the code manually. Defaults to False.
        """
        self._auth_client.login(
            offline_access=offline_access,
            token_name=token_name,
            output_token_file=output_token_file,
            no_browser=no_browser,
        )

    def close(self):
        """
        Closes the client connection.
        """
        self._client.close()

    def request(
        self,
        method: str,
        path: str = "",
        authentication: bool = True,
        **kwargs,
    ):
        """
        Executes a request to the API server.

        Args:
            method (str): The request method.
            path (str): The request path.
            authentication (bool): Whether to include authentication headers in the request.
            **kwargs: Additional arguments to pass to the request (e.g. stream=True for streaming; returns raw httpx.Response, caller must close it).
        Returns:
            dict or list when response is JSON; httpx.Response when stream=True (caller must close it).
        """

        headers = kwargs.get("headers") or {}

        # Merge request-scoped headers (context manager) into this request.
        # Precedence: request-scoped headers < per-call headers < auth headers.
        context_headers = _RequestHeadersContext.get_request_context_headers()
        if context_headers:
            merged_headers = dict(context_headers)
            merged_headers.update(headers)
            headers = merged_headers

        if authentication:
            headers = self._auth_client.enrich_auth_headers(headers)

        kwargs["headers"] = headers
        stream = kwargs.pop("stream", False)

        response = self._client.send_request(
            method, path, "Failed to execute request", **kwargs
        )
        if stream:
            return response
        return json.loads(response.content)

    def with_headers(
        self, headers: dict[str, str]
    ) -> contextlib.AbstractContextManager:
        """
        Return a context manager that injects headers into all SDK requests executed
        within the context.

        This is useful for cross-cutting headers like request/correlation IDs.

        Example:

            with client.with_headers({"X-Request-ID": "123"}):
                client.v1.authorization.list_policies()
        """
        return _RequestHeadersContext(headers)


class _RequestHeadersContext(contextlib.AbstractContextManager):
    """
    Context manager to inject headers into all SDK requests executed within the context.

    This is useful for cross-cutting headers like request/correlation IDs.

    Example:

        with client.with_headers({"X-Request-ID": "123"}):
            client.list_policies()
    """

    _headers_var: contextvars.ContextVar[typing.Optional[dict[str, str]]] = (
        contextvars.ContextVar("iguazio_sdk_request_context_headers", default=None)
    )

    def __init__(self, headers: dict[str, str]):
        if not isinstance(headers, dict):
            raise TypeError("headers must be a dict[str, str]")

        # Copy defensively so the caller can reuse/mutate their dict safely.
        self._headers = dict(headers)
        self._token: typing.Optional[contextvars.Token] = None

    def __enter__(self):
        current_headers = self._headers_var.get() or {}
        merged_headers = dict(current_headers)
        merged_headers.update(self._headers)
        self._token = self._headers_var.set(merged_headers)
        return self

    def __exit__(self, exc_type, exc, tb):
        # Reset the headers so we don't leak them to other requests.
        if self._token is not None:
            self._headers_var.reset(self._token)
        # Always return False - even if an exception happens inside the with block,
        # we still reset the headers, and the exception continues to propagate.
        return False

    @staticmethod
    def get_request_context_headers() -> typing.Optional[dict[str, str]]:
        """
        Returns the current request context headers, or None if not set.
        """
        return _RequestHeadersContext._headers_var.get()
