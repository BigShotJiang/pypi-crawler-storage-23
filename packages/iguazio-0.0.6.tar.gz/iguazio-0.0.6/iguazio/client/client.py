# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import logging
import typing

import iguazio.client.api
import iguazio.client.clients.v1

import iguazio.common.constants as constants


class Client(iguazio.client.clients.v1.ClientV1):
    """
    Client for interacting with the Iguazio API.

    This class provides access to various API clients, including all versioned clients for different resources.
    It inherits from `ClientV1` so that all default operations are available from v1, while other versioned clients
    can be added and accessed as needed.

    Example usage::

        client = Client(api_url="https://api.example.com")
        user = client.get_user("username")  # Example operation to get a user

    Attributes:
        v1 (iguazio.client.clients.v1.ClientV1): Explicit access to the v1 client, which is the default versioned
            client for Iguazio API.

    Args:
        api_url (str): The base URL of the Iguazio API server.
        timeout (int, optional): The timeout for API requests in seconds. Defaults to 60 seconds.
        retries (int, optional): The number of retries for failed requests. Defaults to 3 retries.
        log_level (str, optional): The logging level for the client. Defaults to "INFO".
        logger (logging.Logger, optional): An optional custom logger to use for logging.
        verify_ssl (bool, optional): Whether to verify SSL certificates for HTTPS requests. Defaults to True.
        auto_login (bool, optional): Whether to automatically log in to the API server on unauthenticated requests.
            Defaults to True.
        use_token_file (bool, optional): Whether to load/save the token from/to a file. Defaults to True.
        token_file_path (str, optional): The path to use forthe token file. Defaults to ~/.igz.yml.
            If a specific path is provided and the file doesn't exist, a FileNotFoundError is raised.
            If using the default path and the file doesn't exist, it will be created after login.
            This path is also used as the default when saving tokens after login.
        token_name (str, optional): The name of the token to load from the token file.
            If provided, that specific token must exist and be valid, otherwise an error is raised.
            If None (default), uses 'default' token if it exists, otherwise the first token.
            Used only if use_token_file is True.
        service_account_token_file (str, optional): Path to the service account token file.
            Defaults to the in-cluster Kubernetes service account token file.
            Environment variable: `IGUAZIO_SERVICE_ACCOUNT_TOKEN_FILE`.
            Auto-detection runs only when use_token_file is False.
    """

    def __init__(
        self,
        *,
        api_url: str = "",
        timeout: int = constants._Defaults.request_timeout.value,
        retries: int = constants._Defaults.retries.value,
        log_level: str = constants._Defaults.log_level.value,
        logger: typing.Optional[logging.Logger] = None,
        verify_ssl: bool = True,
        auto_login: bool = True,
        use_token_file: bool = True,
        token_file_path: typing.Optional[str] = None,
        token_name: typing.Optional[str] = None,
        service_account_token_file: typing.Optional[str] = None,
    ):
        self._api_client = iguazio.client.api.APIClient(
            api_url=api_url,
            timeout=timeout,
            retries=retries,
            log_level=log_level,
            logger=logger,
            verify_ssl=verify_ssl,
            auto_login=auto_login,
            use_token_file=use_token_file,
            token_file_path=token_file_path,
            token_name=token_name,
            service_account_token_file=service_account_token_file,
        )

        self.v1 = iguazio.client.clients.v1.ClientV1(self._api_client)

    def set_access_token(self, token: str, refresh_token: typing.Optional[str] = None):
        """
        Sets the access token for authenticating API requests.
        If the access token is invalid, a ValueError will be raised and the previous tokens will be kept.

        Example usage::
            client = Client(api_url="https://api.example.com")
            client.set_access_token("your_access_token")
            client.list_users()

        Args:
            token (str): The access token to set.
            refresh_token (str, optional): An optional refresh token to set.

        Raises:
            ValueError: If the provided token is invalid.
        """
        self._api_client.set_access_token(token, refresh_token)

    def login(
        self,
        offline_access: bool = True,
        token_name: typing.Optional[str] = None,
        output_token_file: typing.Optional[str] = None,
        no_browser: bool = False,
    ):
        """
        Authenticates to the API server using oauth2 flow.

        Example usage::

            client = Client(api_url="https://api.example.com")
            client.login()

        Args:
            offline_access (bool, optional): Whether to request offline access. Defaults to True.
            token_name (str, optional): Name of the token to save. Defaults to the default token name.
            output_token_file (str, optional): Path to save the token file. Defaults to the default token file path.
            no_browser (bool, optional): If True, the user will be prompted to open a browser and enter the code manually. Defaults to False.
        """
        self._api_client.login(
            offline_access=offline_access,
            token_name=token_name,
            output_token_file=output_token_file,
            no_browser=no_browser,
        )

    def with_headers(self, headers: dict[str, str]):
        """
        Return a context manager that injects custom headers into all SDK requests
        executed within the context.

        This is useful for propagating request/correlation IDs.

        Example:

            with client.with_headers({"X-Request-ID": "123"}):
                client.list_policies()
        """
        return self._api_client.with_headers(headers)

    def get_access_token(self) -> str:
        """
        Returns the access token for the authenticated user.

        Example usage:
            client = Client(api_url="https://api.example.com")
            print(client.get_access_token())

        Returns:
            str: The access token for the authenticated user.

        Raises:
            RuntimeError: If the access token is not available and auto login is disabled.
        """
        self._api_client._auth_client._refresh_token_if_needed()
        return self._api_client._auth_client.access_token

    def get_refresh_token(
        self,
    ) -> typing.Optional[typing.Tuple[str, str]]:
        """
        Returns the refresh token that was resolved during client initialization.

        This token can be used for authentication in other contexts or stored for later use.

        Example usage::

            client = Client(api_url="https://api.example.com", use_token_file=True)
            result = client.get_refresh_token()
            if result:
                token_name, token_value = result
                print(f"Using token '{token_name}': {token_value}")

        Returns:
            tuple: A tuple of (token_name, token_value), or None if no token was loaded.
        """
        auth_client = self._api_client._auth_client
        if auth_client.refresh_token is None:
            return None
        return (auth_client.resolved_token_name, auth_client.refresh_token)
