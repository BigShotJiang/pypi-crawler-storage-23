# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.event_activation as event_activation_schema


class EventsClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio events API v1.

    This client provides methods for publishing events to the event system.
    """

    def publish_event(
        self, options: event_activation_schema.EventActivationSpec
    ) -> event_activation_schema.EventActivation:
        """
        Publish an event to the Iguazio event system.

        Events are used to track system activities, audit trails, and notifications.
        The event is persisted to the database and, if configured, published to a message queue
        for downstream processing.

        For catalog events (config_name exists in the event catalog):
        - kind, class, and severity are taken from the catalog configuration
        - Any values passed for these fields are ignored

        For custom events (config_name not in catalog):
        - kind, class, and severity use passed values or defaults
        - Event is only persisted to DB, not published to queue

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.EventActivationSpec(
                config_name="user_login",
                source="api-service",
                details={"username": "john", "ip": "192.168.1.1"}
            )
            event = client.publish_event(options)

        Args:
            options (iguazio.schemas.v1.resources.event_activation.EventActivationSpec):
                The event specification to publish.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivation:
                The created event activation with server-assigned timestamps.
        """
        response = self._request(
            "post",
            "/events/activations",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivation
        )

    def list_event_activations(
        self,
        options: event_activation_schema.ListEventActivationsOptions = None,
        get_all: bool = False,
        batch_size: int = 10000,
    ) -> event_activation_schema.EventActivationList:
        """
        List event activations in the Iguazio system.

        Events can be filtered by kind, name (substring), time range (since/until),
        severity (enum, multi-value), class (multi-value), source (multi-value),
        project_name (exact match), entity_name (substring), and visibility.
        Results can be returned in minimal or full mode.

        **Important: Pagination Limits**

        - Default limit when not specified: 1,000 activations per request
        - Maximum limit per request: 10,000 activations
        - If you have more than 10,000 activations, use ``get_all=True`` to automatically
          paginate through all results

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # List activations with default limit (1,000)
            activations = client.list_event_activations()

            # Get ALL activations automatically
            all_activations = client.list_event_activations(get_all=True)
            print(f"Total activations: {len(all_activations.items)}")

            # Get all with filters
            all_critical = client.list_event_activations(
                options=iguazio.schemas.ListEventActivationsOptions(
                    severity=[iguazio.schemas.Severity.CRITICAL]
                ),
                get_all=True
            )

            # Custom pagination control
            options = iguazio.schemas.ListEventActivationsOptions(
                kind="system",
                name="~login",  # Substring match
                mode="minimal",
                offset=0,
                limit=100
            )
            activations = client.list_event_activations(options)

            # List with time range and multi-value filters
            from datetime import datetime, timezone
            options = iguazio.schemas.ListEventActivationsOptions(
                kind="log",
                since=datetime(2024, 12, 31, tzinfo=timezone.utc),  # Upper boundary
                until=datetime(2024, 1, 1, tzinfo=timezone.utc),  # Lower boundary
                severity=[iguazio.schemas.Severity.INFO, iguazio.schemas.Severity.WARNING],
                class_=["authentication", "authorization"],
                source=["api-service", "auth-service"],
                project_name="my-project",  # Exact match
                entity_name="~user"  # Substring match
            )
            activations = client.list_event_activations(options)

        Args:
            options (iguazio.schemas.v1.resources.event_activation.ListEventActivationsOptions, optional):
                Options for listing event activations. If not provided, uses default pagination
                (offset=0, limit=1000). Maximum limit per request is 10,000.
            get_all (bool, optional):
                If True, automatically paginate through all results across multiple requests.
                This is useful when you have more than 10,000 activations. Defaults to False.
            batch_size (int, optional):
                When get_all=True, the number of activations to fetch per request.
                Defaults to 10,000 (maximum). Must be between 1 and 10,000.
                Ignored when get_all=False.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivationList:
                A list of event activations matching the criteria. When get_all=False,
                may contain fewer items than the total available if pagination limit is reached.
                When get_all=True, contains all matching activations.

        Raises:
            ValueError: If get_all=True and batch_size is not between 1 and 10,000.
        """
        # Initialize options if not provided
        options = options or event_activation_schema.ListEventActivationsOptions()
        if get_all:
            # Validate batch_size
            if batch_size < 1 or batch_size > 10000:
                raise ValueError(
                    f"batch_size must be between 1 and 10,000, got {batch_size}"
                )

            # Use the helper to paginate through all results
            all_items = self.fetch_all_pages(
                lambda batch_opts: self.list_event_activations(
                    options=batch_opts, get_all=False
                ),
                options,
                batch_size,
            )

            # Return combined result
            return event_activation_schema.EventActivationList(items=all_items)
        else:
            response = self._request(
                "get",
                "/events/activations",
                params=options.to_query_params(),
                expected_status_codes=[http.HTTPStatus.OK],
            )
            return iguazio.schemas.serializer.deserialize(
                response, event_activation_schema.EventActivationList
            )

    def get_event_activation(
        self,
        options: event_activation_schema.GetEventActivationOptions,
    ) -> event_activation_schema.EventActivation:
        """
        Get a single event activation by ID.

        Args:
            options (iguazio.schemas.v1.resources.event_activation.GetEventActivationOptions):
                Options for getting the event activation, including id.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivation:
                The event activation.
        """
        serialized_options = options.to_dict()
        # Extract id from options for path parameter
        activation_id = serialized_options.pop("id")
        # The gRPC proxy will extract {id} from the path and map it to the proto message
        response = self._request(
            "get",
            f"/events/activations/{activation_id}",
            params=serialized_options if serialized_options else None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivation
        )

    def get_event_activations_summary(
        self,
        options: event_activation_schema.GetEventActivationsSummaryOptions = None,
    ) -> event_activation_schema.EventActivationSummary:
        """
        Get event activations summary grouped by severity for the last 24 hours.

        Returns aggregated counts of event activations grouped by severity level
        (e.g., critical, major, warning, info, debug). Results can be filtered by event kind.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # Get summary for all events
            summary = client.get_event_activations_summary()

            # Get summary for system events only
            options = iguazio.schemas.GetEventActivationsSummaryOptions(
                kind="system"
            )
            summary = client.get_event_activations_summary(options)
            print(summary.status.counters_by_severity)  # {"critical": 5, "major": 10, ...}

        Args:
            options (iguazio.schemas.v1.resources.event_activation.GetEventActivationsSummaryOptions, optional):
                Options for filtering the summary. If not provided, returns summary for all events.

        Returns:
            iguazio.schemas.v1.resources.event_activation.EventActivationSummary:
                Summary with counters_by_severity map.
        """
        if options is None:
            options = event_activation_schema.GetEventActivationsSummaryOptions()
        response = self._request(
            "get",
            "/events/activations-summary",
            params=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, event_activation_schema.EventActivationSummary
        )
