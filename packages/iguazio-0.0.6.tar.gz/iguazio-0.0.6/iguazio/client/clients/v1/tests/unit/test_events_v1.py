# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.events as events_client
import iguazio.schemas.v1.resources.event_activation as event_activation_schema
import iguazio.schemas.serializer as serializer


class TestEventsClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = events_client.EventsClientV1(self.mock_api_client)

    def test_publish_event(self):
        """Test publishing an event."""
        options = event_activation_schema.EventActivationSpec(
            config_name="user_login",
            source="api-service",
            details={"username": "john"},
        )
        mock_response = self._generate_event_activation_json(
            config_name="user_login",
            source="api-service",
            kind="system",
            event_class="authentication",
            severity="info",
            details={"username": "john"},
        )
        self.mock_api_client.request.return_value = mock_response

        event = self.client.publish_event(options)

        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/events/activations",
            authentication=True,
            version="v1",
            json=options.to_dict(),
            expected_status_codes=[http.HTTPStatus.OK, http.HTTPStatus.CREATED],
        )
        self.assertEqual(event.metadata.id, "12345")
        self.assertEqual(event.spec.config_name, "user_login")
        self.assertEqual(event.spec.source, "api-service")
        self.assertEqual(event.spec.kind, "system")
        self.assertEqual(event.spec.class_, "authentication")
        self.assertEqual(event.spec.severity, event_activation_schema.Severity.INFO)
        self.assertIsNotNone(event.status.created_at)

    def test_publish_event_custom_event(self):
        """Test publishing a custom event (configName not in catalog)."""
        options = event_activation_schema.EventActivationSpec(
            config_name="my_custom_event",
            source="my-service",
            kind="system",
            class_="custom",
            severity=event_activation_schema.Severity.WARNING,
            details={"action": "test"},
        )
        mock_response = self._generate_event_activation_json(
            config_name="my_custom_event",
            source="my-service",
            kind="system",
            event_class="custom",
            severity="warning",
            details={"action": "test"},
        )
        self.mock_api_client.request.return_value = mock_response

        event = self.client.publish_event(options)

        self.mock_api_client.request.assert_called_once()
        self.assertEqual(event.spec.config_name, "my_custom_event")
        self.assertEqual(event.spec.kind, "system")
        self.assertEqual(event.spec.class_, "custom")
        self.assertEqual(event.spec.severity, event_activation_schema.Severity.WARNING)

    def test_publish_event_with_project_scope(self):
        """Test publishing an event scoped to a project."""
        options = event_activation_schema.EventActivationSpec(
            config_name="project_action",
            source="project-service",
            project_name="my-project",
            entity_name="user123",
        )
        mock_response = self._generate_event_activation_json(
            config_name="project_action",
            source="project-service",
            kind="audit",
            event_class="project",
            project_name="my-project",
            entity_name="user123",
        )
        self.mock_api_client.request.return_value = mock_response

        event = self.client.publish_event(options)

        self.assertEqual(event.spec.project_name, "my-project")
        self.assertEqual(event.spec.entity_name, "user123")

    def test_publish_event_with_trace_id(self):
        """Test publishing an event with distributed tracing ID."""
        options = event_activation_schema.EventActivationSpec(
            config_name="traced_event",
            source="traced-service",
            trace_id="abc123-trace-id",
        )
        mock_response = self._generate_event_activation_json(
            config_name="traced_event",
            source="traced-service",
            trace_id="abc123-trace-id",
        )
        self.mock_api_client.request.return_value = mock_response

        event = self.client.publish_event(options)

        self.assertEqual(event.spec.trace_id, "abc123-trace-id")

    def test_publish_event_with_all_severity_levels(self):
        """Test that all severity levels are correctly handled."""
        severity_cases = [
            ("debug", event_activation_schema.Severity.DEBUG),
            ("info", event_activation_schema.Severity.INFO),
            ("warning", event_activation_schema.Severity.WARNING),
            ("major", event_activation_schema.Severity.MAJOR),
            ("critical", event_activation_schema.Severity.CRITICAL),
        ]

        for severity_str, severity_enum in severity_cases:
            with self.subTest(severity=severity_str):
                self.mock_api_client.reset_mock()
                options = event_activation_schema.EventActivationSpec(
                    config_name="test_event",
                    source="test-source",
                )
                mock_response = self._generate_event_activation_json(
                    config_name="test_event",
                    source="test-source",
                    severity=severity_str,
                )
                self.mock_api_client.request.return_value = mock_response

                event = self.client.publish_event(options)

                self.assertEqual(event.spec.severity, severity_enum)

    def test_deserialize_event_activation(self):
        """Test deserialization of event activation response."""
        mock_response = self._generate_event_activation_json(
            config_name="test_event",
            source="test-source",
            kind="system",
            event_class="test",
            severity="info",
            details={"key": "value"},
        )

        event = serializer.deserialize(
            mock_response, event_activation_schema.EventActivation
        )

        self.assertEqual(event.metadata.id, "12345")
        self.assertEqual(event.spec.config_name, "test_event")
        self.assertEqual(event.spec.source, "test-source")
        self.assertEqual(event.spec.kind, "system")
        self.assertEqual(event.spec.class_, "test")
        self.assertEqual(event.spec.severity, event_activation_schema.Severity.INFO)
        self.assertEqual(event.spec.details, {"key": "value"})
        self.assertIsNotNone(event.status.created_at)

    def test_serialize_event_activation_spec(self):
        """Test serialization of event activation spec."""
        options = event_activation_schema.EventActivationSpec(
            config_name="test_event",
            source="test-source",
            class_="authentication",
            severity=event_activation_schema.Severity.CRITICAL,
            details={"key": "value"},
        )

        serialized = serializer.serialize(options)

        # Check key fields
        self.assertEqual(serialized["configName"], "test_event")
        self.assertEqual(serialized["source"], "test-source")
        self.assertEqual(serialized["severity"], "critical")  # Note: enum -> string
        self.assertEqual(serialized["class"], "authentication")  # Note: class_ -> class
        self.assertEqual(serialized["details"], {"key": "value"})

    def test_serialize_event_activation_spec_minimal(self):
        """Test serialization with only required fields."""
        options = event_activation_schema.EventActivationSpec(
            config_name="test",
            source="test-source",
        )

        serialized = serializer.serialize(options)

        self.assertEqual(serialized["configName"], "test")
        self.assertEqual(serialized["source"], "test-source")
        # Fields with default values are present
        self.assertEqual(serialized["severity"], "unspecified")
        self.assertEqual(serialized["kind"], "")
        self.assertEqual(serialized["projectName"], "")
        self.assertEqual(serialized["entityName"], "")
        self.assertEqual(serialized["traceId"], "")
        self.assertEqual(serialized["details"], {})
        # Optional field (None) should not be present
        self.assertNotIn("class", serialized)

    def test_event_activation_spec_validation_missing_config_name(self):
        """Test that missing config_name raises validation error."""
        with self.assertRaises(TypeError):
            event_activation_schema.EventActivationSpec(
                source="test-source",
            )

    def test_list_event_activations_with_options(self):
        """Test listing event activations with options."""
        options = event_activation_schema.ListEventActivationsOptions(
            kind="system",
            name="~test",
            mode="minimal",
            offset=0,
            limit=10,
        )
        mock_response = {
            "items": [
                self._generate_event_activation_json(
                    config_name="test_event",
                    activation_id="1",
                ),
            ],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_event_activations(options)

        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/events/activations",
            authentication=True,
            version="v1",
            params=options.to_query_params(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(result.items), 1)

    def test_list_event_activations_minimal_mode(self):
        """Test listing event activations in minimal mode."""
        options = event_activation_schema.ListEventActivationsOptions(
            mode="minimal",
            name="test_event",
        )
        mock_response = {
            "items": [
                {
                    "metadata": {
                        "id": "1",
                    },
                    "spec": {
                        "configName": "test_event",
                        "class": "test",
                        "severity": "info",
                        "entityName": "entity1",
                        "source": "test-service",
                        "description": "Test description",
                    },
                    "status": {
                        "createdAt": "2024-01-01T00:00:00.000000Z",
                    },
                },
            ],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_event_activations(options)

        self.assertEqual(len(result.items), 1)
        item = result.items[0]
        # Verify metadata with id is present in minimal mode
        self.assertIsNotNone(item.metadata)
        self.assertEqual(item.metadata.id, "1")
        self.assertEqual(item.spec.config_name, "test_event")
        self.assertEqual(item.spec.class_, "test")
        self.assertIsNotNone(item.status.created_at)
        # Verify source is present in minimal mode
        self.assertEqual(item.spec.source, "test-service")

    def test_list_event_activations_full_mode(self):
        """Test listing event activations in full mode."""
        options = event_activation_schema.ListEventActivationsOptions(
            mode="full",
        )
        mock_response = {
            "items": [
                self._generate_event_activation_json(
                    config_name="test_event",
                    activation_id="1",
                ),
            ],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_event_activations(options)

        self.assertEqual(len(result.items), 1)
        item = result.items[0]
        self.assertEqual(item.spec.config_name, "test_event")
        self.assertIsNotNone(item.metadata)
        self.assertEqual(item.metadata.id, "1")

    def test_list_event_activations_with_pagination(self):
        """Test listing event activations with pagination."""
        offset = 10
        limit = 20
        options = event_activation_schema.ListEventActivationsOptions(
            offset=offset,
            limit=limit,
        )
        mock_response = {
            "items": [],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_event_activations(options)

        params = options.to_dict()
        self.assertEqual(params["offset"], offset)
        self.assertEqual(params["limit"], limit)
        self.assertEqual(len(result.items), 0)

    def test_list_event_activations_get_all_multiple_pages(self):
        """Test list_event_activations with get_all=True paginates through multiple pages."""
        # Mock responses for multiple pages
        responses = [
            # First page - full batch
            {
                "items": [
                    self._generate_event_activation_json(
                        config_name=f"event_{i}", activation_id=str(i)
                    )
                    for i in range(100)
                ],
                "status": {},
            },
            # Second page - full batch
            {
                "items": [
                    self._generate_event_activation_json(
                        config_name=f"event_{i}", activation_id=str(i)
                    )
                    for i in range(100, 200)
                ],
                "status": {},
            },
            # Third page - partial batch (indicates end)
            {
                "items": [
                    self._generate_event_activation_json(
                        config_name=f"event_{i}", activation_id=str(i)
                    )
                    for i in range(200, 250)
                ],
                "status": {},
            },
        ]
        self.mock_api_client.request.side_effect = responses

        result = self.client.list_event_activations(get_all=True, batch_size=100)

        # Should make 3 requests
        self.assertEqual(self.mock_api_client.request.call_count, 3)
        # Should have all items combined
        self.assertEqual(len(result.items), 250)
        # Verify pagination parameters in requests
        calls = self.mock_api_client.request.call_args_list
        self.assertEqual(calls[0][1]["params"]["offset"], 0)
        self.assertEqual(calls[0][1]["params"]["limit"], 100)
        self.assertEqual(calls[1][1]["params"]["offset"], 100)
        self.assertEqual(calls[1][1]["params"]["limit"], 100)
        self.assertEqual(calls[2][1]["params"]["offset"], 200)
        self.assertEqual(calls[2][1]["params"]["limit"], 100)

    def test_list_event_activations_get_all_with_filters(self):
        """Test list_event_activations with get_all=True preserves filter options."""
        mock_response = {
            "items": [
                self._generate_event_activation_json(
                    config_name="test_event", activation_id="1", kind="system"
                ),
            ],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        options = event_activation_schema.ListEventActivationsOptions(
            kind="system",
            name="~test",
            mode="minimal",
        )
        result = self.client.list_event_activations(options, get_all=True)

        # Verify filters were applied
        call_params = self.mock_api_client.request.call_args[1]["params"]
        self.assertEqual(call_params["kind"], "system")
        self.assertEqual(call_params["name"], "~test")
        self.assertEqual(call_params["mode"], "minimal")
        self.assertEqual(len(result.items), 1)

    def test_list_event_activations_get_all_empty_result(self):
        """Test list_event_activations with get_all=True and no results."""
        mock_response = {
            "items": [],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        result = self.client.list_event_activations(get_all=True)

        self.assertEqual(self.mock_api_client.request.call_count, 1)
        self.assertEqual(len(result.items), 0)

    def test_list_event_activations_get_all_invalid_batch_size(self):
        """Test list_event_activations with get_all=True validates batch_size."""
        with self.assertRaises(ValueError) as context:
            self.client.list_event_activations(get_all=True, batch_size=0)
        self.assertIn("batch_size must be between 1 and 10,000", str(context.exception))

        with self.assertRaises(ValueError) as context:
            self.client.list_event_activations(get_all=True, batch_size=10001)
        self.assertIn("batch_size must be between 1 and 10,000", str(context.exception))

    def test_list_event_activations_get_all_default_batch_size(self):
        """Test list_event_activations with get_all=True uses correct default batch size."""
        mock_response = {
            "items": [],
            "status": {},
        }
        self.mock_api_client.request.return_value = mock_response

        self.client.list_event_activations(get_all=True)

        # Verify default batch size is 10000
        call_params = self.mock_api_client.request.call_args[1]["params"]
        self.assertEqual(call_params["limit"], 10000)

    def test_get_event_activation(self):
        """Test getting a single event activation by ID."""
        options = event_activation_schema.GetEventActivationOptions(id="12345")
        mock_response = self._generate_event_activation_json(
            config_name="test_event",
            source="test-source",
            activation_id="12345",
        )
        self.mock_api_client.request.return_value = mock_response

        event = self.client.get_event_activation(options)

        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/events/activations/12345",
            authentication=True,
            version="v1",
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(event.metadata.id, "12345")
        self.assertEqual(event.spec.config_name, "test_event")
        self.assertEqual(event.spec.source, "test-source")

    @staticmethod
    def _generate_event_activation_json(
        config_name="test_event",
        source="test-source",
        kind="system",
        event_class="test",
        severity="info",
        project_name=None,
        entity_name=None,
        trace_id=None,
        details=None,
        created_at="2024-01-01T00:00:00.000000Z",
        activation_id="12345",
    ):
        """Generate a mock event activation response JSON."""
        spec = {
            "configName": config_name,
            "source": source,
            "kind": kind,
            "class": event_class,
            "severity": severity,
        }
        if project_name:
            spec["projectName"] = project_name
        if entity_name:
            spec["entityName"] = entity_name
        if trace_id:
            spec["traceId"] = trace_id
        if details:
            spec["details"] = details

        return {
            "metadata": {
                "id": activation_id,
            },
            "spec": spec,
            "status": {
                "createdAt": created_at,
            },
        }


if __name__ == "__main__":
    unittest.main()
