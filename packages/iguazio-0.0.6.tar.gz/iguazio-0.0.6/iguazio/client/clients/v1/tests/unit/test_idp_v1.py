# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.idp as idp_client
import iguazio.schemas.v1.resources.sso_provider as sso_schema
import iguazio.schemas.serializer as serializer


TEST_SSO_IDP_TYPE = sso_schema.SsoProviderIdpType.okta
TEST_SSO_ALIAS = TEST_SSO_IDP_TYPE.value
TEST_SSO_DISPLAY_NAME = "Okta SSO"
TEST_SSO_PROVIDER_ID = "oidc"


class TestIdpClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = idp_client.IdpClientV1(self.mock_api_client)

    def test_create_sso_provider(self):
        options = sso_schema.CreateSsoProviderOptions(
            idp_type=TEST_SSO_IDP_TYPE,
            alias=TEST_SSO_ALIAS,
            display_name=TEST_SSO_DISPLAY_NAME,
            client_id=self._default_sso_config()["clientId"],
            client_secret=self._default_sso_config()["clientSecret"],
            discovery_endpoint="https://okta/.well-known/openid-configuration",
        )
        expected_payload = {
            "idpType": options.idp_type.value,
            "alias": options.alias,
            "displayName": options.display_name,
            "clientId": options.client_id,
            "clientSecret": options.client_secret,
            "discoveryEndpoint": options.discovery_endpoint,
            "createEmailMapper": True,
        }
        self.mock_api_client.request.return_value = self._okta_mock_response()

        sso_provider = self.client.create_sso_provider(options)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            "/idp/sso-providers",
            version="v1",
            authentication=True,
            json=expected_payload,
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        self._assert_sso_provider(sso_provider)

    def test_get_sso_provider(self):
        self.mock_api_client.request.return_value = self._okta_mock_response()

        sso_provider = self.client.get_sso_provider(TEST_SSO_ALIAS)
        self.mock_api_client.request.assert_called_once_with(
            "get",
            f"/idp/sso-providers/{TEST_SSO_ALIAS}",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self._assert_sso_provider(sso_provider)

    def test_list_sso_providers(self):
        mock_response = {
            "items": [
                self._okta_mock_response(),
                self._okta_mock_response(sso_provider_id="sso-provider-id-2"),
            ],
            "status": {"total": 2},
        }
        self.mock_api_client.request.return_value = mock_response

        sso_list = self.client.list_sso_providers()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/idp/sso-providers",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(sso_list.items), 2)
        self._assert_sso_provider(sso_list.items[0])
        self.assertEqual(sso_list.items[1].metadata.id, "sso-provider-id-2")
        self.assertEqual(sso_list.status.total, 2)

    def test_list_sso_providers_with_options(self):
        mock_response = {
            "items": [self._okta_mock_response()],
            "status": {"total": 1},
        }
        self.mock_api_client.request.return_value = mock_response

        sso_list = self.client.list_sso_providers()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/idp/sso-providers",
            version="v1",
            authentication=True,
            params=None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(len(sso_list.items), 1)
        self._assert_sso_provider(sso_list.items[0])

    def test_update_sso_provider(self):
        updated_config = {"clientId": "newcid", "clientSecret": "newsecret"}
        updated_display_name = "Updated Okta SSO"
        options = sso_schema.UpdateSsoProviderOptions(
            display_name=updated_display_name,
            client_id=updated_config["clientId"],
            client_secret=updated_config["clientSecret"],
        )
        expected_payload = {
            "displayName": options.display_name,
            "clientId": options.client_id,
            "clientSecret": options.client_secret,
        }
        self.mock_api_client.request.return_value = self._okta_mock_response(
            display_name=updated_display_name, config=updated_config
        )

        sso_provider = self.client.update_sso_provider(TEST_SSO_ALIAS, options)
        self.mock_api_client.request.assert_called_once_with(
            "put",
            f"/idp/sso-providers/{TEST_SSO_ALIAS}",
            version="v1",
            authentication=True,
            json=expected_payload,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self._assert_sso_provider(
            sso_provider,
            display_name="Updated Okta SSO",
            config=updated_config,
        )

    def test_create_sso_provider_email_mapper(self):
        self.client.create_sso_provider_email_mapper(TEST_SSO_ALIAS)
        self.mock_api_client.request.assert_called_once_with(
            "post",
            f"/idp/sso-providers/{TEST_SSO_ALIAS}/email-mapper",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.CREATED],
        )

    def test_delete_sso_provider_email_mapper(self):
        self.client.delete_sso_provider_email_mapper(TEST_SSO_ALIAS)
        self.mock_api_client.request.assert_called_once_with(
            "delete",
            f"/idp/sso-providers/{TEST_SSO_ALIAS}/email-mapper",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_delete_sso_provider(self):
        self.client.delete_sso_provider(TEST_SSO_ALIAS)
        self.mock_api_client.request.assert_called_once_with(
            "delete",
            f"/idp/sso-providers/{TEST_SSO_ALIAS}",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )

    def test_deserialize_sso_provider(self):
        sso_provider = serializer.deserialize(
            self._okta_mock_response(), sso_schema.SsoProvider
        )
        self._assert_sso_provider(sso_provider)

    def _okta_mock_response(
        self,
        sso_provider_id="sso-provider-id",
        display_name=TEST_SSO_DISPLAY_NAME,
        config=None,
    ):
        if config is None:
            config = self._default_sso_config()
        return {
            "metadata": {
                "id": sso_provider_id,
                "alias": TEST_SSO_ALIAS,
                "idpType": TEST_SSO_IDP_TYPE,
            },
            "spec": {
                "displayName": display_name,
                "providerId": "oidc",
                "config": config,
            },
            "status": {"enabled": True},
        }

    @staticmethod
    def _default_sso_config():
        return {
            "clientId": "client-id",
            "clientSecret": "client-secret",
        }

    def _assert_sso_provider(
        self,
        sso_provider,
        alias=TEST_SSO_ALIAS,
        display_name=TEST_SSO_DISPLAY_NAME,
        config=None,
        enabled=True,
    ):
        if config is None:
            config = self._default_sso_config()

        self.assertEqual(sso_provider.metadata.alias, alias)
        self.assertEqual(sso_provider.spec.display_name, display_name)
        self.assertEqual(sso_provider.spec.provider_id, TEST_SSO_PROVIDER_ID)
        self.assertEqual(sso_provider.spec.config, config)
        self.assertEqual(sso_provider.status.enabled, enabled)
