# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import unittest
from unittest.mock import MagicMock

import iguazio.client.clients.v1.info as info_client


class TestInfoClientV1(unittest.TestCase):
    def setUp(self):
        self.mock_api_client = MagicMock()
        self.client = info_client.InfoClientV1(self.mock_api_client)

    def test_get_system_info(self):
        test_iguazio_version = "test-iguazio-version-1.0.0"
        mock_response = self._generate_mock_system_info_response(
            iguazio_version=test_iguazio_version,
        )
        self.mock_api_client.request.return_value = mock_response

        system_info = self.client.get_system_info()
        self.mock_api_client.request.assert_called_once_with(
            "get",
            "/info/system",
            version="v1",
            authentication=True,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        self.assertEqual(
            system_info.metadata.version.iguazio_version, test_iguazio_version
        )

    def test_keycloak_redirect_uri(self):
        test_alias = "test-alias"
        test_host_address = "keycloak.host.url"
        test_realm = "keycloak-realm"
        mock_response = self._generate_mock_system_info_response(
            host_address=test_host_address,
            realm=test_realm,
        )
        self.mock_api_client.request.return_value = mock_response

        redirect_uri = self.client.keycloak_redirect_uri(alias=test_alias)
        expected_uri = (
            f"{test_host_address}/realms/{test_realm}/broker/{test_alias}/endpoint"
        )
        self.assertEqual(redirect_uri, expected_uri)

    @staticmethod
    def _generate_mock_system_info_response(
        iguazio_version="test-iguazio-version-1.0.0",
        host_address="keycloak.host.url",
        realm="keycloak-realm",
    ):
        return {
            "metadata": {
                "id": "systeminfo",
                "resourceType": "systeminfo",
                "domain": "test-domain",
                "namespace": "test-namespace",
                "version": {
                    "iguazioVersion": iguazio_version,
                },
                "keycloak": {
                    "hostAddress": host_address,
                    "realm": realm,
                },
                "registry": {
                    "user": "user.registry.url",
                    "system": "system.registry.url",
                },
            },
            "spec": {},
            "status": {
                "ctx": "1a1696a2-9342-4784-bd45-8184f3c5d900",
                "statusCode": 200,
                "services": {
                    "api": {"status": "SERVING"},
                    "identity": {"status": "SERVING"},
                },
            },
        }
