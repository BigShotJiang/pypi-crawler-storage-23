# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http
import os
import typing

import httpx

import iguazio.client.clients.base
import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.logs as logs_schema

# Match backend default (defaultStreamChunkSizeBytes in adapters/storage/streamer.go).
_LOG_BUNDLE_STREAM_CHUNK_SIZE = 32 * 1024  # 32KB


class LogsClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio logs API v1.

    This client provides methods for log bundles (e.g. list, get, download, create).
    """

    def create_log_bundle(self) -> logs_schema.LogBundle:
        """
        Start a new log bundle collection.

        Triggers the backend to collect logs from the cluster. The collection runs
        asynchronously; the returned bundle will have state "running". Poll the bundle
        status or use get_log_bundle to check when it completes.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            bundle = client.create_log_bundle()
            print(f"Started collection: {bundle.metadata.id}")

        Returns:
            iguazio.schemas.v1.resources.logs.LogBundle: The created log bundle with initial state.

        Raises:
            httpx.HTTPStatusError: If the server returns an error (e.g. 409 if a collection is already running).
        """
        response = self._request(
            "post",
            "/logs/bundles",
            expected_status_codes=[http.HTTPStatus.CREATED],
        )
        return iguazio.schemas.serializer.deserialize(response, logs_schema.LogBundle)

    def list_log_bundles(
        self,
        options: typing.Optional[logs_schema.ListLogBundlesOptions] = None,
        get_all: bool = False,
        batch_size: int = 1000,
    ) -> logs_schema.LogBundleList:
        """
        List log bundles in the Iguazio system.

        Log bundles can be filtered by state and creation time (since).
        Results are sorted by creation time (newest first).

        **Important: Pagination Limits**

        - Default limit when not specified: 100 bundles per request
        - Maximum limit per request: 1,000 bundles
        - If you have more than 1,000 bundles, use ``get_all=True`` to automatically
          paginate through all results

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")

            # List bundles with default limit (100)
            bundles = client.list_log_bundles()

            # Get ALL bundles automatically
            all_bundles = client.list_log_bundles(get_all=True)
            print(f"Total bundles: {len(all_bundles.items)}")

            # Get all completed bundles
            all_completed = client.list_log_bundles(
                options=iguazio.schemas.ListLogBundlesOptions(
                    state=iguazio.schemas.BundleState.completed
                ),
                get_all=True
            )

            # Custom pagination control
            options = iguazio.schemas.ListLogBundlesOptions(
                state=iguazio.schemas.BundleState.completed,
                offset=0,
                limit=50
            )
            bundles = client.list_log_bundles(options)

            # List with time range filter
            from datetime import datetime, timezone
            options = iguazio.schemas.ListLogBundlesOptions(
                since=datetime(2024, 1, 1, tzinfo=timezone.utc)
            )
            bundles = client.list_log_bundles(options)

        Args:
            options (iguazio.schemas.v1.resources.logs.ListLogBundlesOptions, optional):
                Options for listing log bundles. If not provided, uses default pagination
                (offset=0, limit=100). Maximum limit per request is 1,000.
            get_all (bool, optional):
                If True, automatically paginate through all results across multiple requests.
                This is useful when you have more than 1,000 bundles. Defaults to False.
            batch_size (int, optional):
                When get_all=True, the number of bundles to fetch per request.
                Defaults to 1,000 (maximum). Must be between 1 and 1,000.
                Ignored when get_all=False.

        Returns:
            iguazio.schemas.v1.resources.logs.LogBundleList:
                A list of log bundles matching the criteria. When get_all=False,
                may contain fewer items than the total available if pagination limit is reached.
                When get_all=True, contains all matching bundles.

        Raises:
            ValueError: If get_all=True and batch_size is not between 1 and 1,000.
        """
        # Initialize options if not provided
        options = options or logs_schema.ListLogBundlesOptions()
        if get_all:
            # Validate batch_size
            if batch_size < 1 or batch_size > 1000:
                raise ValueError(
                    f"batch_size must be between 1 and 1,000, got {batch_size}"
                )

            # Use the helper to paginate through all results
            all_items = self.fetch_all_pages(
                lambda batch_opts: self.list_log_bundles(
                    options=batch_opts, get_all=False
                ),
                options,
                batch_size,
            )

            # Return combined result
            return logs_schema.LogBundleList(items=all_items)

        response = self._request(
            "get",
            "/logs/bundles",
            params=options.to_query_params(),
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, logs_schema.LogBundleList
        )

    def get_log_bundle(
        self, options: logs_schema.GetLogBundleOptions
    ) -> logs_schema.LogBundle:
        """
        Get a specific log bundle by ID.

        Retrieves detailed information about a log bundle, including its state,
        creation time, completion time, and file path (if completed).

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            options = iguazio.schemas.GetLogBundleOptions(id="my-bundle-id")
            bundle = client.get_log_bundle(options)
            print(f"State: {bundle.status.state}")

        Args:
            options (iguazio.schemas.v1.resources.logs.GetLogBundleOptions):
                Options for getting the log bundle, including id.

        Returns:
            iguazio.schemas.v1.resources.logs.LogBundle: Log bundle details.

        Raises:
            ValueError: If options.id is missing or empty.
            httpx.HTTPStatusError: If the server returns an error (e.g. 404 bundle not found, 403 forbidden).
        """
        serialized_options = options.to_dict()
        # Extract id from options for path parameter
        bundle_id = serialized_options.pop("id", None)
        if not bundle_id:
            raise ValueError("Log bundle ID is required")
        # The gRPC proxy will extract {id} from the path and map it to the proto message
        response = self._request(
            "get",
            f"/logs/bundles/{bundle_id}",
            params=serialized_options if serialized_options else None,
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(response, logs_schema.LogBundle)

    def download_log_bundle_to_file(
        self,
        bundle_id: str,
        path: typing.Optional[str] = None,
    ) -> str:
        """
        Download a log bundle archive to a local file.

        Streams the response to disk so the full file is not kept in memory.
        If path is not given, uses ``log-bundle-{bundle_id}.tar.gz`` in the current directory.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            path = client.download_log_bundle_to_file("my-bundle-id")
            path = client.download_log_bundle_to_file("my-bundle-id", "custom.tar.gz")

        Args:
            bundle_id (str): Log bundle ID.
            path (str, optional): Local file path (relative or absolute). Defaults to ``log-bundle-{bundle_id}.tar.gz``.
                Resolved to an absolute path before writing; the returned path is always absolute.

        Returns:
            str: The path where the file was written.

        Raises:
            ValueError: If bundle_id is empty.
            httpx.HTTPStatusError: If the server returns an error (e.g. 404 bundle not found).
            OSError: If the file cannot be written (e.g. permission denied, path is a directory).
        """
        if not bundle_id or not bundle_id.strip():
            raise ValueError("bundle_id must be non-empty")

        if path is None:
            path = f"log-bundle-{bundle_id}.tar.gz"
        path = os.path.abspath(path)

        try:
            response = self._request(
                "get",
                f"/logs/bundles/{bundle_id}/download",
                expected_status_codes=[http.HTTPStatus.OK],
                stream=True,
            )
        except httpx.HTTPStatusError as exc:
            status = exc.response.status_code if exc.response is not None else None
            if status == http.HTTPStatus.NOT_FOUND:
                raise httpx.HTTPStatusError(
                    f"Log bundle not found: {bundle_id!r}. Check the bundle ID exists and is completed.",
                    request=exc.request,
                    response=exc.response,
                ) from exc
            if status == http.HTTPStatus.FORBIDDEN:
                raise httpx.HTTPStatusError(
                    f"Permission denied downloading log bundle {bundle_id!r}.",
                    request=exc.request,
                    response=exc.response,
                ) from exc
            raise

        try:
            with open(path, "wb") as f:
                for chunk in response.iter_bytes(
                    chunk_size=_LOG_BUNDLE_STREAM_CHUNK_SIZE
                ):
                    f.write(chunk)
        except OSError as exc:
            raise OSError(f"Failed to write log bundle to {path!r}: {exc}") from exc
        finally:
            response.close()
        return path
