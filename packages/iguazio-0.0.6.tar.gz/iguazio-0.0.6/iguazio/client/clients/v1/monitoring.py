# Copyright 2026 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import http

import iguazio.client.clients.base

import iguazio.schemas.serializer
import iguazio.schemas.v1.resources.service_health as service_health_schema


class MonitoringClientV1(iguazio.client.clients.base.BaseClient):
    """
    Client for interacting with the Iguazio monitoring API v1.

    This client provides methods for health checking and monitoring operations.
    """

    def check_health(self) -> service_health_schema.ServiceHealthList:
        """
        Perform a health check on the monitoring service.

        Returns the current status of all monitored services, including their
        health state, group, and resource information.

        Example usage::

            client = iguazio.Client(api_url="https://api.example.com")
            response = client.check_health()
            for service in response.items:
                print(f"{service.spec.name}: {service.status.state.value}")

        :returns: The service health list response.
        :rtype: iguazio.schemas.v1.resources.service_health.ServiceHealthList
        """
        response = self._request(
            "get",
            "/monitoring/health",
            expected_status_codes=[http.HTTPStatus.OK],
        )
        return iguazio.schemas.serializer.deserialize(
            response, service_health_schema.ServiceHealthList
        )
