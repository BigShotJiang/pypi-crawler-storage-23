# Copyright 2025 Iguazio
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import dataclasses
import http
import typing
import httpx
import iguazio.client.api


class BaseClient:
    """
    Base class for API clients in the Iguazio SDK.
    This class provides a common interface for making API requests
    and can be extended by specific API clients for different versions or services.
    It uses the iguazio.client.api.APIClient to handle the actual HTTP requests.
    """

    version = "v1"
    default_expected_status_codes = [http.HTTPStatus.OK]

    def __init__(self, api_client: iguazio.client.api.APIClient):
        self._api_client = api_client

    def _request(
        self,
        method: str,
        path: str,
        authentication: bool = True,
        expected_status_codes: typing.Optional[list[int]] = None,
        **kwargs,
    ):
        """
        Make an API request using the API client.

        Args:
            method (str): HTTP method (e.g., 'get', 'post', 'put', 'delete').
            path (str): API endpoint path.
            authentication (bool, optional): Whether to include authentication headers.
            expected_status_codes (list[int], optional): List of expected HTTP status codes.
            **kwargs: Additional parameters for the request (e.g. stream=True for raw response, caller must close it).

        Returns:
            dict or list when response is JSON; httpx.Response when stream=True (caller must close it).
        """
        expected_status_codes = (
            expected_status_codes or self.default_expected_status_codes
        )
        try:
            return self._api_client.request(
                method,
                path,
                authentication=authentication,
                version=self.version,
                expected_status_codes=expected_status_codes,
                **kwargs,
            )
        except httpx.HTTPError as exc:
            # allows to avoid a huge and redundant traceback
            raise exc.with_traceback(None) from None

    @property
    def logger(self):
        """Get the logger from the API client.

        Returns:
            logging.Logger: The logger instance.
        """
        return self._api_client.logger

    @staticmethod
    def fetch_all_pages(
        fetch_batch_fn: typing.Callable,
        options,
        batch_size: int,
    ) -> list:
        """
        Fetch all pages of results by automatically paginating through them.

        This method can be used by any client to automatically paginate through
        list results by repeatedly calling a fetch function with updated offset/limit.

        Args:
            fetch_batch_fn (Callable): Function that takes options and returns a batch result.
                The result must have an 'items' attribute containing the list of items.
            options: Options object to use for filtering (will be copied with updated offset/limit).
                Must be a dataclass with 'offset' and 'limit' fields.
            batch_size (int): Number of items to fetch per batch.

        Returns:
            list: All items combined from all batches.

        Example:
            def fetch_batch(batch_opts):
                return self.list_items(options=batch_opts, get_all=False)

            all_items = self.fetch_all_pages(fetch_batch, options, batch_size=10000)
        """
        all_items = []
        offset = 0

        while True:
            # Update only offset and limit, keeping all other filters
            batch_options = dataclasses.replace(
                options, offset=offset, limit=batch_size
            )

            # Fetch the batch
            batch = fetch_batch_fn(batch_options)
            all_items.extend(batch.items)

            # Check if we've fetched all available items
            if len(batch.items) < batch_size:
                break  # No more data to fetch

            offset += batch_size

        return all_items
