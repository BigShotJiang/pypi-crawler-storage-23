# iguazio - Management API SDK

Python SDK for Iguazio 4 Management API

## Installation

```console
pip install iguazio
```

## License

`iguazio` is distributed under the terms of the [Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) license.

## Documentation

TBD
