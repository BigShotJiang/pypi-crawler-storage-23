# LeetCode Progress

| Difficulty | Count |
|------------|--------|
| Easy       | 34 |
| Medium     | 32 |
| Hard       | 4 |
| Total      | 70 |
