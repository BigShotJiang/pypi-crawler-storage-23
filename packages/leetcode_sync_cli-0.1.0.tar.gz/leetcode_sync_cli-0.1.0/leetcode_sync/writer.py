import os
from .api import fetch_submission_code, fetch_difficulty
from .utils import create_folder, format_problem_folder, get_file_extension

BASE_DIR = "problems"

def save_submissions(sub):
    slug = sub["titleSlug"]
    lang = sub["lang"]

    difficulty = fetch_difficulty(slug)

    problem_folder = format_problem_folder(slug)
    problem_base_path = os.path.join(BASE_DIR, difficulty.lower(), problem_folder)

    create_folder(problem_base_path)

    generate_readme(problem_base_path, slug, difficulty, lang)

    code = fetch_submission_code(sub["id"])

    if not code:
        print(f"Skipping submission {sub['id']} (no code returned)")
        return
    
    ext = get_file_extension(lang)
    file_path = os.path.join(problem_base_path, f"solution.{ext}")

    with open(file_path, "w", encoding="utf-8") as f:
        f.write(code)
    print(f"Saved: {file_path}")

def generate_readme(folder_path, title, difficulty, lang):
    readme_path = os.path.join(folder_path, "README.md")

    if os.path.exists(readme_path):
        return # Don't overwrite existing README
    
    content = f"""# {title}

## Difficulty: 
{difficulty}

## Language:
{lang}

## Notes:
- Add any notes or explanations about your solution here.
"""
    with open(readme_path, "w", encoding="utf-8") as f:
        f.write(content)