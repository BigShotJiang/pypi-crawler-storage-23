import os
import re

def format_problem_folder(title_slung):
    return title_slung.replace("-", "_")

def create_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)

def get_file_extension(lang):
    mapping = {
        "python": "py",
        "python3": "py",
        "java": "java",
        "cpp": "cpp",
        "c++": "cpp",
        "c": "c",
        "typescript": "ts",
        "javascript": "js",
        "ruby": "rb",
        "swift": "swift",
        "go": "go",
        "csharp": "cs",
        # Add more mappings as needed
    }
    return mapping.get(lang.lower(), "txt")  # Default to txt if language is unknown