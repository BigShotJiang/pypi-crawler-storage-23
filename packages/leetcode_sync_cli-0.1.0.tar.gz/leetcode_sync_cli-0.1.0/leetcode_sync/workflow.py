import os
import click


WORKFLOW_CONTENT = """name: Daily LeetCode Sync

on:
  schedule:
    - cron: "0 20 * * *"
  workflow_dispatch:

jobs:
  sync:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v3

      - uses: actions/setup-python@v4
        with:
          python-version: "3.11"

      - name: Configure Git
        run: |
          git config --global user.name "leetcode-sync-bot"
          git config --global user.email "bot@users.noreply.github.com"

      - name: Install package
        run: pip install leetcode-sync-cli

      - name: Run sync
        env:
          LEETCODE_SESSION: ${{ secrets.LEETCODE_SESSION }}
          CSRFTOKEN: ${{ secrets.CSRFTOKEN }}
        run: leetcode-sync --sync --push
"""


def setup_autosync():
    workflow_dir = os.path.join(".github", "workflows")
    os.makedirs(workflow_dir, exist_ok=True)

    workflow_path = os.path.join(workflow_dir, "leetcode-sync.yml")

    if os.path.exists(workflow_path):
        click.echo("⚠️ Workflow already exists.")
        return

    with open(workflow_path, "w") as f:
        f.write(WORKFLOW_CONTENT)

    click.echo("✅ GitHub Actions workflow created at .github/workflows/")
    click.echo("🔐 Now add LEETCODE_SESSION and CSRFTOKEN to GitHub Secrets.")