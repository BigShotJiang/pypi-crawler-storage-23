import os
from pathlib import Path
from dotenv import load_dotenv
import click

CONFIG_DIR = Path.home() / ".leetcode_sync"
CONFIG_FILE = CONFIG_DIR / ".env"

GRAPHQL_URL = "https://leetcode.com/graphql"

def load_credentials():
    if CONFIG_FILE.exists():
        load_dotenv(CONFIG_FILE)

    session = os.getenv("LEETCODE_SESSION")
    csrf = os.getenv("CSRFTOKEN")

    return session, csrf

def save_credentials(session, csrf):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        f.write(f"LEETCODE_SESSION={session}\n")
        f.write(f"CSRFTOKEN={csrf}\n")

def prompt_for_credentials():
    click.echo("\n🔐 LeetCode credentials required.")
    session = click.prompt("Enter LEETCODE_SESSION")
    csrf = click.prompt("Enter CSRFTOKEN")
    save_credentials(session, csrf)
    return session, csrf

def get_headers():
    session, csrf = load_credentials()

    if not session or not csrf:
        session, csrf = prompt_for_credentials()

    return {
        "Content-Type": "application/json",
        "Referer": "https://leetcode.com",
        "x-csrftoken": csrf,
        "Cookie": f"LEETCODE_SESSION={session}; csrftoken={csrf}"
    }