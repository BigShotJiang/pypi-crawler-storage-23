import requests
from .queries import VALIDATE_QUERY

GRAPHQL_URL = "https://leetcode.com/graphql"

def validate_credentials(headers):
    response = requests.post(
        GRAPHQL_URL,
        json={"query": VALIDATE_QUERY},
        headers=headers
    )

    if response.status_code != 200:
        return False

    data = response.json()

    try:
        return data["data"]["userStatus"]["isSignedIn"]
    except:
        return False