import requests
from .config import get_headers, GRAPHQL_URL
from .queries import SUBMISSION_LIST_QUERY, SUBMISSION_DETAIL_QUERY, DIFFICULTY_QUERY, VALIDATE_QUERY
import json
from pathlib import Path

LIMIT = 20 # per request

CACHE_FILE = Path.home() / ".leetcode_sync" / "cache.json"

def load_cache():
    if CACHE_FILE.exists():
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    return {}

def save_cache(cache):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=2)

HEADERS = get_headers()

def safe_post(query, variables=None):
    headers = get_headers()

    response = requests.post(
        GRAPHQL_URL,
        json={"query": query, "variables": variables},
        headers=headers
    )

    if response.status_code == 401:
        from .config import reset_credentials
        reset_credentials()
        headers = get_headers()

        response = requests.post(
            GRAPHQL_URL,
            json={"query": query, "variables": variables},
            headers=headers
        )

    return response

def fetch_all_submissions():
    offset = 0
    all_submissions = []

    while True:
        response = safe_post(SUBMISSION_LIST_QUERY, {"offset": offset, "limit": LIMIT})
        data = response.json()
        # print("Data fetched:", data)  # Debugging line
        submissions = data["data"]["submissionList"]["submissions"]

        if not submissions:
            break

        #keep only accepted submissions
        accepted = [s for s in submissions if s["statusDisplay"] == "Accepted"]
        all_submissions.extend(accepted)

        offset += LIMIT
        print(f"Fetched {len(all_submissions)} submissions...")

    return all_submissions

def fetch_submission_code(submission_id):
    response = safe_post(SUBMISSION_DETAIL_QUERY, {"id": int(submission_id)})

    if response.status_code != 200:
        print("❌ GraphQL HTTP error:", response.text)
        return None

    data = response.json()

    if "data" not in data:
        print("⚠️ Unexpected response:", data)
        return None

    # Handle both possible keys
    detail = None

    if "submissionDetails" in data["data"]:
        detail = data["data"]["submissionDetails"]
    elif "submissionDetail" in data["data"]:
        detail = data["data"]["submissionDetail"]

    if detail is None:
        print(f"⚠️ No details found for submission {submission_id}")
        return None

    return detail.get("code")

def fetch_difficulty(slug):
    cache = load_cache()

    if slug in cache:
        return cache[slug]

    response = safe_post(DIFFICULTY_QUERY, {"titleSlug": slug})
    data = response.json()

    try:
        difficulty = data["data"]["question"]["difficulty"]
    except:
        difficulty = "Unknown"

    cache[slug] = difficulty
    save_cache(cache)

    return difficulty