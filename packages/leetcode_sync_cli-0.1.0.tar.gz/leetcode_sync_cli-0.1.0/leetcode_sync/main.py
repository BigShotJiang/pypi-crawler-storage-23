from .processor import run_sync

def main():
    run_sync()

if __name__ == "__main__":
    main()