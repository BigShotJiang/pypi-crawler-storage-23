from .api import fetch_all_submissions
from .writer import save_submissions
import os

def keep_latest_per_language(submissions):
    submissions.sort(key=lambda x: int(x['timestamp']), reverse=True)

    seen = set()
    filtered = []

    for sub in submissions:
        key = f"{sub['titleSlug']}_{sub['lang']}"
        if key not in seen:
            seen.add(key)
            filtered.append(sub)

    print(f"Filtered to {len(filtered)} unique language submissions.")
    return filtered

def run_sync():
    submissions = fetch_all_submissions()
    submissions = keep_latest_per_language(submissions)

    for sub in submissions:
        save_submissions(sub)
    generate_dashboard()

def generate_dashboard(base_dir="problems"):
    counts = {"easy": 0, "medium": 0, "hard": 0}

    for difficulty in counts:
        path = os.path.join(base_dir, difficulty)
        if os.path.exists(path):
            counts[difficulty] = len(os.listdir(path))

    total = sum(counts.values())

    content = f"""# LeetCode Progress

| Difficulty | Count |
|------------|--------|
| Easy       | {counts['easy']} |
| Medium     | {counts['medium']} |
| Hard       | {counts['hard']} |
| Total      | {total} |
"""

    with open("README.md", "w") as f:
        f.write(content)