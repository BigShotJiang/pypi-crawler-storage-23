import subprocess
import click


def run_git_command(command):
    result = subprocess.run(
        command,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        click.echo(f"❌ Git error: {' '.join(command)}")
        click.echo(result.stderr)
        return False

    return True


def git_push():
    click.echo("📦 Adding changes...")
    if not run_git_command(["git", "add", "."]):
        return

    click.echo("📝 Committing...")
    commit_result = subprocess.run(
        ["git", "commit", "-m", "Auto sync LeetCode submissions"],
        capture_output=True,
        text=True
    )

    # No changes case
    if "nothing to commit" in commit_result.stdout.lower():
        click.echo("ℹ️ Nothing to commit.")
        return

    if commit_result.returncode != 0:
        click.echo("❌ Commit failed.")
        click.echo(commit_result.stderr)
        return

    click.echo("🚀 Pushing...")
    if not run_git_command(["git", "push"]):
        return

    click.echo("✅ Push successful!")