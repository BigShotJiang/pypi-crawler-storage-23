import click
from .processor import run_sync
from .git_utils import git_push
from .config import get_headers, prompt_for_credentials, save_credentials
from .auth import validate_credentials
from .workflow import setup_autosync

@click.command()
@click.option("--sync", is_flag=True, help="Sync LeetCode submissions")
@click.option("--push", is_flag=True, help="Push changes to GitHub after sync")
@click.option("--setup-autosync", "setup_autosync_flag", is_flag=True, help="Setup GitHub Actions auto-sync")
def main(sync, push, setup_autosync_flag):
    if sync:
        headers = get_headers()

        if not validate_credentials(headers):
            click.echo("❌ Stored credentials invalid.")
            session, csrf = prompt_for_credentials()
            headers = get_headers()

            if not validate_credentials(headers):
                click.echo("❌ Invalid credentials again. Exiting.")
                return

        click.echo("Starting LeetCode sync...")
        run_sync()

        if push:
            click.echo("Pushing to GitHub...")
            git_push()

        click.echo("Done.")

    if setup_autosync_flag:
        setup_autosync()
        return