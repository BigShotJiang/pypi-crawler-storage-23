SUBMISSION_LIST_QUERY = """
query submissionList($offset: Int!, $limit: Int!) {
  submissionList(offset: $offset, limit: $limit) {
    submissions {
      id
      title
      titleSlug
      lang
      timestamp
      statusDisplay
      }
    }
}
"""

SUBMISSION_DETAIL_QUERY = """
query submissionDetails($id: Int!) {
    submissionDetails(submissionId: $id) {
        code
        runtime
        memory
    }
}
"""

DIFFICULTY_QUERY = """
query getProblem($titleSlug: String!) {
  question(titleSlug: $titleSlug) {
    difficulty
  }
}
"""

VALIDATE_QUERY = """
query {
  userStatus {
    isSignedIn
    username
  }
}
"""