"""
hegm._config -- Centralised configuration and logging.

All tunables are read from environment variables at import time.
"""

import os
import sys

# ---------------------------------------------------------------------------
# Environment-driven configuration
# ---------------------------------------------------------------------------

CHECKPOINT_PATH: str = os.environ.get(
    "HEGM_CHECKPOINT_PATH", "/checkpoint/latest.pt"
)

EXIT_CODE: int = int(os.environ.get("HEGM_EXIT_CODE", "99"))

# Logging verbosity: DEBUG, INFO (default), QUIET
LOG_LEVEL: str = os.environ.get("HEGM_LOG_LEVEL", "INFO").upper()

# ---------------------------------------------------------------------------
# Lightweight logger
# ---------------------------------------------------------------------------

_LEVELS = {"DEBUG": 0, "INFO": 1, "QUIET": 2}


def log(msg: str, *, level: str = "INFO") -> None:
    """Print a ``[HeGM]``-prefixed message if *level* >= configured threshold."""
    if _LEVELS.get(level, 1) >= _LEVELS.get(LOG_LEVEL, 1):
        print(f"[HeGM] {msg}", flush=True)


def warn(msg: str) -> None:
    """Print a warning to *stderr* (always shown, even in QUIET mode)."""
    print(f"[HeGM] WARNING -- {msg}", file=sys.stderr, flush=True)
