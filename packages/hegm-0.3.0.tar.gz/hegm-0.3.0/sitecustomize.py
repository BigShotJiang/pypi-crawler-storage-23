"""
sitecustomize.py -- HeGM bootstrap.

Automatically loaded by the Python interpreter when placed on PYTHONPATH.
Importing the ``hegm`` package installs import hooks, the SIGUSR1 signal
handler, and the ``hegm.global_step`` public API.
"""

import hegm  # noqa: F401
