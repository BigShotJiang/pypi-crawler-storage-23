# entry point for baxter
