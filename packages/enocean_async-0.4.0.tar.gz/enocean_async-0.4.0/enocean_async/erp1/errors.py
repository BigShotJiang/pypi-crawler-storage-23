class ERP1ParseError(Exception):
    pass
