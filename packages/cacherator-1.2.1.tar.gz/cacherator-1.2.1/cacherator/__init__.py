from .cacherator import JSONCache, Cached

__version__ = "1.2.1"
__all__ = ["JSONCache", "Cached"]