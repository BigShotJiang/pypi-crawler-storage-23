"""REST API serializers for nautobot_bgp_soo."""

from nautobot.apps.api import NautobotModelSerializer, TaggedModelSerializerMixin
from rest_framework import serializers

from nautobot_bgp_soo import models


class SiteOfOriginSerializer(NautobotModelSerializer, TaggedModelSerializerMixin):
    """REST API serializer for SiteOfOrigin records."""

    url = serializers.HyperlinkedIdentityField(view_name="plugins-api:nautobot_bgp_soo-api:siteoforigin-detail")

    class Meta:
        model = models.SiteOfOrigin
        fields = "__all__"


class SiteOfOriginRangeSerializer(NautobotModelSerializer, TaggedModelSerializerMixin):
    """REST API serializer for SiteOfOriginRange records."""

    url = serializers.HyperlinkedIdentityField(view_name="plugins-api:nautobot_bgp_soo-api:siteoforiginrange-detail")

    class Meta:
        model = models.SiteOfOriginRange
        fields = "__all__"
