"""REST API views for nautobot_bgp_soo."""

from nautobot.apps.api import NautobotModelViewSet

from nautobot_bgp_soo import filters, models
from nautobot_bgp_soo.api import serializers


class SiteOfOriginViewSet(NautobotModelViewSet):
    """REST API viewset for SiteOfOrigin records."""

    queryset = models.SiteOfOrigin.objects.all()
    serializer_class = serializers.SiteOfOriginSerializer
    filterset_class = filters.SiteOfOriginFilterSet


class SiteOfOriginRangeViewSet(NautobotModelViewSet):
    """REST API viewset for SiteOfOriginRange records."""

    queryset = models.SiteOfOriginRange.objects.all()
    serializer_class = serializers.SiteOfOriginRangeSerializer
    filterset_class = filters.SiteOfOriginRangeFilterSet
