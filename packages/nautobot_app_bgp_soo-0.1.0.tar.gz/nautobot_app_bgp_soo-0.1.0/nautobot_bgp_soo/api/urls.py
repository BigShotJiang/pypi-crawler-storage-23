"""REST API URL definitions for nautobot_bgp_soo."""

from nautobot.apps.api import OrderedDefaultRouter

from nautobot_bgp_soo.api import views

router = OrderedDefaultRouter()
router.register("site-of-origin", views.SiteOfOriginViewSet)
router.register("site-of-origin-ranges", views.SiteOfOriginRangeViewSet)

urlpatterns = router.urls
