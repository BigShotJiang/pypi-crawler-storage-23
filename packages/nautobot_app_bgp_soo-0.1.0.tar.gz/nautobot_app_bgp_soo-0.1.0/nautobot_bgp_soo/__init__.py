"""App declaration for nautobot_bgp_soo."""

from importlib import metadata

from django.db.models.signals import post_migrate
from nautobot.apps import NautobotAppConfig

__version__ = metadata.version("nautobot-app-bgp-soo")


class NautobotBGPSoOConfig(NautobotAppConfig):
    """App configuration for the nautobot_bgp_soo app."""

    name = "nautobot_bgp_soo"
    verbose_name = "BGP Site of Origin"
    version = __version__
    author = "EGATE Networks Inc."
    description = "Nautobot app for modeling BGP Site of Origin (SoO) extended communities."
    base_url = "bgp-soo"
    required_settings = []
    default_settings = {
        "default_statuses": {
            "SiteOfOrigin": ["Active", "Reserved", "Deprecated", "Planned"],
        }
    }
    searchable_models = ["siteoforigin", "siteoforiginrange"]

    def ready(self):
        """Callback invoked after the app is loaded."""
        super().ready()
        from .signals import post_migrate_create_statuses  # noqa: E402

        post_migrate.connect(post_migrate_create_statuses, sender=self)


config = NautobotBGPSoOConfig
