"""Signal handler functions for nautobot_bgp_soo."""

from django.apps import apps as global_apps
from django.conf import settings

PLUGIN_SETTINGS = settings.PLUGINS_CONFIG.get("nautobot_bgp_soo", {})


def post_migrate_create_statuses(sender, *, apps=global_apps, **kwargs):
    """Associate default Statuses with SiteOfOrigin after migration."""
    if not apps:
        return

    Status = apps.get_model("extras", "Status")
    ContentType = apps.get_model("contenttypes", "ContentType")

    for model_name, default_statuses in PLUGIN_SETTINGS.get("default_statuses", {}).items():
        model = sender.get_model(model_name)
        ct_model = ContentType.objects.get_for_model(model)
        for name in default_statuses:
            try:
                status = Status.objects.get(name=name)
            except Status.DoesNotExist:
                print(f"nautobot_bgp_soo: Unable to find status: {name} .. SKIPPING")
                continue

            if ct_model not in status.content_types.all():
                status.content_types.add(ct_model)
                status.save()

    _create_peerendpoint_relationship(apps)


def _create_peerendpoint_relationship(apps):
    """Create a Relationship linking PeerEndpoint to SiteOfOrigin."""
    try:
        Relationship = apps.get_model("extras", "Relationship")
        ContentType = apps.get_model("contenttypes", "ContentType")
    except LookupError:
        return

    try:
        peerendpoint_ct = ContentType.objects.get(app_label="nautobot_bgp_models", model="peerendpoint")
        soo_ct = ContentType.objects.get(app_label="nautobot_bgp_soo", model="siteoforigin")
    except ContentType.DoesNotExist:
        # nautobot_bgp_models not installed or not yet migrated
        return

    Relationship.objects.get_or_create(
        key="peer_endpoint_site_of_origin",
        defaults={
            "label": "Site of Origin",
            "type": "one-to-many",
            "source_type": soo_ct,
            "destination_type": peerendpoint_ct,
        },
    )
