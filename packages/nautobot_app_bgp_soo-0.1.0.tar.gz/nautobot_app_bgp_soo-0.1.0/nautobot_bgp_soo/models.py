"""Models for nautobot_bgp_soo."""

import ipaddress

from django.core.exceptions import ValidationError
from django.db import models
from nautobot.apps.models import PrimaryModel, extras_features
from nautobot.dcim.models import Location
from nautobot.extras.models import StatusField
from nautobot.tenancy.models import Tenant

from nautobot_bgp_soo.choices import SoOTypeChoices

TWO_BYTE_ASN_MAX = 65535
FOUR_BYTE_ASN_MAX = 4294967295
TWO_BYTE_AN_MAX = 65535
FOUR_BYTE_AN_MAX = 4294967295

AN_MAX_BY_TYPE = {
    SoOTypeChoices.TYPE_0: FOUR_BYTE_AN_MAX,
    SoOTypeChoices.TYPE_1: TWO_BYTE_AN_MAX,
    SoOTypeChoices.TYPE_2: TWO_BYTE_AN_MAX,
}

ASN_MAX_BY_TYPE = {
    SoOTypeChoices.TYPE_0: TWO_BYTE_ASN_MAX,
    SoOTypeChoices.TYPE_2: FOUR_BYTE_ASN_MAX,
}


def validate_administrator(soo_type, administrator):
    """Validate the administrator field based on soo_type. Raises ValidationError."""
    if soo_type in (SoOTypeChoices.TYPE_0, SoOTypeChoices.TYPE_2):
        max_value = ASN_MAX_BY_TYPE[soo_type]
        try:
            asn = int(administrator)
        except (ValueError, TypeError) as err:
            raise ValidationError(
                {"administrator": f"Administrator must be a valid integer for SoO type {soo_type}."}
            ) from err
        if asn < 0 or asn > max_value:
            raise ValidationError(
                {"administrator": f"Administrator ASN must be between 0 and {max_value} for SoO type {soo_type}."}
            )
    elif soo_type == SoOTypeChoices.TYPE_1:
        try:
            ipaddress.IPv4Address(administrator)
        except (ipaddress.AddressValueError, ValueError) as err:
            raise ValidationError(
                {"administrator": "Administrator must be a valid IPv4 address for SoO type 1."}
            ) from err


def validate_assigned_number(soo_type, value, field_name="assigned_number"):
    """Validate that an assigned number is within the allowed range for the type. Raises ValidationError."""
    max_value = AN_MAX_BY_TYPE.get(soo_type)
    if max_value is not None and value is not None and (value < 0 or value > max_value):
        raise ValidationError(
            {field_name: f"Assigned number must be between 0 and {max_value} for SoO type {soo_type}."}
        )


@extras_features(
    "custom_fields",
    "custom_links",
    "custom_validators",
    "export_templates",
    "graphql",
    "relationships",
    "statuses",
    "webhooks",
)
class SiteOfOrigin(PrimaryModel):
    """BGP Site of Origin (SoO) extended community."""

    soo_type = models.CharField(
        max_length=1,
        choices=SoOTypeChoices,
        verbose_name="SoO Type",
        help_text="Extended community type/format (0=2-byte ASN, 1=IPv4, 2=4-byte ASN)",
    )
    administrator = models.CharField(
        max_length=45,
        help_text="Administrator sub-field: ASN (types 0/2) or IPv4 address (type 1)",
    )
    assigned_number = models.PositiveBigIntegerField(
        verbose_name="Assigned Number",
        help_text="Assigned number sub-field",
    )
    description = models.CharField(max_length=255, blank=True)
    status = StatusField(null=True)
    tenant = models.ForeignKey(
        to=Tenant,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
    )
    locations = models.ManyToManyField(
        to=Location,
        blank=True,
        related_name="sites_of_origin",
    )

    class Meta:
        ordering = ["soo_type", "administrator", "assigned_number"]
        unique_together = [("soo_type", "administrator", "assigned_number")]
        verbose_name = "Site of Origin"
        verbose_name_plural = "Sites of Origin"

    def __str__(self):
        return f"SoO:{self.administrator}:{self.assigned_number}"

    def clean(self):
        super().clean()
        if not self.soo_type:
            return
        validate_administrator(self.soo_type, self.administrator)
        validate_assigned_number(self.soo_type, self.assigned_number)


@extras_features(
    "custom_fields",
    "custom_links",
    "custom_validators",
    "export_templates",
    "graphql",
    "relationships",
    "webhooks",
)
class SiteOfOriginRange(PrimaryModel):
    """A range of BGP Site of Origin (SoO) assigned numbers for pool allocation."""

    name = models.CharField(max_length=255, unique=True)
    soo_type = models.CharField(
        max_length=1,
        choices=SoOTypeChoices,
        verbose_name="SoO Type",
        help_text="Extended community type/format for this range",
    )
    administrator = models.CharField(
        max_length=45,
        help_text="Administrator sub-field: ASN (types 0/2) or IPv4 address (type 1)",
    )
    assigned_number_min = models.PositiveBigIntegerField(
        verbose_name="Start Assigned Number",
        help_text="First assigned number in the range",
    )
    assigned_number_max = models.PositiveBigIntegerField(
        verbose_name="End Assigned Number",
        help_text="Last assigned number in the range",
    )
    description = models.CharField(max_length=255, blank=True)
    tenant = models.ForeignKey(
        to=Tenant,
        on_delete=models.PROTECT,
        blank=True,
        null=True,
    )

    class Meta:
        ordering = ["soo_type", "administrator", "assigned_number_min"]
        unique_together = [("soo_type", "administrator", "assigned_number_min", "assigned_number_max")]
        verbose_name = "Site of Origin Range"

    def __str__(self):
        return f"SoO:{self.administrator}:{self.assigned_number_min}-{self.assigned_number_max}"

    def clean(self):
        super().clean()
        if not self.soo_type:
            return

        validate_administrator(self.soo_type, self.administrator)

        if self.assigned_number_min is not None and self.assigned_number_max is not None:
            if self.assigned_number_min >= self.assigned_number_max:
                raise ValidationError(
                    {"assigned_number_min": "Start assigned number must be less than end assigned number."}
                )

        validate_assigned_number(self.soo_type, self.assigned_number_min, "assigned_number_min")
        validate_assigned_number(self.soo_type, self.assigned_number_max, "assigned_number_max")

    @property
    def soos(self):
        """Return all SiteOfOrigin objects within this range."""
        return SiteOfOrigin.objects.filter(
            soo_type=self.soo_type,
            administrator=self.administrator,
            assigned_number__gte=self.assigned_number_min,
            assigned_number__lte=self.assigned_number_max,
        )

    def get_next_available_soo(self):
        """Return the first available assigned number in the range, or None."""
        used = set(self.soos.values_list("assigned_number", flat=True))
        for i in range(self.assigned_number_min, self.assigned_number_max + 1):
            if i not in used:
                return i
        return None
