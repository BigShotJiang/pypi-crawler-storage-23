"""Navigation menu items for nautobot_bgp_soo."""

from nautobot.apps.ui import (
    NavMenuAddButton,
    NavMenuGroup,
    NavMenuImportButton,
    NavMenuItem,
    NavMenuTab,
)

menu_items = (
    NavMenuTab(
        name="Routing",
        groups=(
            NavMenuGroup(
                name="BGP - Global",
                weight=100,
                items=(
                    NavMenuItem(
                        link="plugins:nautobot_bgp_soo:siteoforigin_list",
                        name="Sites of Origin",
                        weight=400,
                        permissions=["nautobot_bgp_soo.view_siteoforigin"],
                        buttons=(
                            NavMenuAddButton(
                                link="plugins:nautobot_bgp_soo:siteoforigin_add",
                                permissions=["nautobot_bgp_soo.add_siteoforigin"],
                            ),
                            NavMenuImportButton(
                                link="plugins:nautobot_bgp_soo:siteoforigin_import",
                                permissions=["nautobot_bgp_soo.add_siteoforigin"],
                            ),
                        ),
                    ),
                    NavMenuItem(
                        link="plugins:nautobot_bgp_soo:siteoforiginrange_list",
                        name="Site of Origin Ranges",
                        weight=500,
                        permissions=["nautobot_bgp_soo.view_siteoforiginrange"],
                        buttons=(
                            NavMenuAddButton(
                                link="plugins:nautobot_bgp_soo:siteoforiginrange_add",
                                permissions=["nautobot_bgp_soo.add_siteoforiginrange"],
                            ),
                            NavMenuImportButton(
                                link="plugins:nautobot_bgp_soo:siteoforiginrange_import",
                                permissions=["nautobot_bgp_soo.add_siteoforiginrange"],
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
)
