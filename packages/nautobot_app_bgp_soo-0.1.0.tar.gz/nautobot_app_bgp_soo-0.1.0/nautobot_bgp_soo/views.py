"""Views for nautobot_bgp_soo."""

from nautobot.apps.ui import (
    ObjectDetailContent,
    ObjectFieldsPanel,
    ObjectsTablePanel,
    SectionChoices,
)
from nautobot.apps.views import NautobotUIViewSet

from nautobot_bgp_soo import filters, forms, models, tables
from nautobot_bgp_soo.api import serializers


class SiteOfOriginUIViewSet(NautobotUIViewSet):
    """UIViewSet for SiteOfOrigin model."""

    bulk_update_form_class = forms.SiteOfOriginBulkEditForm
    filterset_class = filters.SiteOfOriginFilterSet
    filterset_form_class = forms.SiteOfOriginFilterForm
    form_class = forms.SiteOfOriginForm
    lookup_field = "pk"
    queryset = models.SiteOfOrigin.objects.all()
    serializer_class = serializers.SiteOfOriginSerializer
    table_class = tables.SiteOfOriginTable

    object_detail_content = ObjectDetailContent(
        panels=[
            ObjectFieldsPanel(
                weight=100,
                section=SectionChoices.LEFT_HALF,
                fields=[
                    "soo_type",
                    "administrator",
                    "assigned_number",
                    "status",
                    "description",
                ],
            ),
            ObjectFieldsPanel(
                weight=200,
                section=SectionChoices.RIGHT_HALF,
                fields=[
                    "tenant",
                    "locations",
                ],
            ),
        ],
    )


class SiteOfOriginRangeUIViewSet(NautobotUIViewSet):
    """UIViewSet for SiteOfOriginRange model."""

    bulk_update_form_class = forms.SiteOfOriginRangeBulkEditForm
    filterset_class = filters.SiteOfOriginRangeFilterSet
    filterset_form_class = forms.SiteOfOriginRangeFilterForm
    form_class = forms.SiteOfOriginRangeForm
    lookup_field = "pk"
    queryset = models.SiteOfOriginRange.objects.all()
    serializer_class = serializers.SiteOfOriginRangeSerializer
    table_class = tables.SiteOfOriginRangeTable

    object_detail_content = ObjectDetailContent(
        panels=[
            ObjectFieldsPanel(
                weight=100,
                section=SectionChoices.LEFT_HALF,
                fields=[
                    "name",
                    "soo_type",
                    "administrator",
                    "assigned_number_min",
                    "assigned_number_max",
                    "description",
                ],
            ),
            ObjectFieldsPanel(
                weight=200,
                section=SectionChoices.RIGHT_HALF,
                fields=[
                    "tenant",
                ],
            ),
            ObjectsTablePanel(
                weight=300,
                section=SectionChoices.FULL_WIDTH,
                context_table_key="soo_range_table",
                show_table_config_button=False,
                include_paginator=True,
                related_field_name="site_of_origin_range",
            ),
        ],
    )

    def get_extra_context(self, request, instance):
        """Populate the SoO table for the detail view."""
        context = super().get_extra_context(request, instance)
        if self.action == "retrieve":
            soos = instance.soos.order_by("assigned_number")
            soo_table = tables.SiteOfOriginTable(soos)
            context["soo_range_table"] = soo_table
        return context
