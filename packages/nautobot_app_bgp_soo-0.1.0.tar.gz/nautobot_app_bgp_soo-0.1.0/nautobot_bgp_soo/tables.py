"""Tables for nautobot_bgp_soo."""

import django_tables2 as tables
from nautobot.apps.tables import (
    BaseTable,
    ButtonsColumn,
    StatusTableMixin,
    TagColumn,
    ToggleColumn,
)

from nautobot_bgp_soo import models


class SiteOfOriginTable(StatusTableMixin, BaseTable):
    """Table for displaying SiteOfOrigin records."""

    pk = ToggleColumn()
    soo_type = tables.Column(verbose_name="Type")
    administrator = tables.Column(linkify=True)
    assigned_number = tables.Column()
    tenant = tables.Column(linkify=True)
    tags = TagColumn(url_name="plugins:nautobot_bgp_soo:siteoforigin_list")
    actions = ButtonsColumn(model=models.SiteOfOrigin)

    class Meta(BaseTable.Meta):
        model = models.SiteOfOrigin
        fields = (
            "pk",
            "soo_type",
            "administrator",
            "assigned_number",
            "status",
            "tenant",
            "description",
            "tags",
            "actions",
        )
        default_columns = (
            "pk",
            "soo_type",
            "administrator",
            "assigned_number",
            "status",
            "tenant",
            "actions",
        )


class SiteOfOriginRangeTable(BaseTable):
    """Table for displaying SiteOfOriginRange records."""

    pk = ToggleColumn()
    name = tables.Column(linkify=True)
    soo_type = tables.Column(verbose_name="Type")
    administrator = tables.Column()
    assigned_number_min = tables.Column(verbose_name="Start AN")
    assigned_number_max = tables.Column(verbose_name="End AN")
    tenant = tables.Column(linkify=True)
    tags = TagColumn(url_name="plugins:nautobot_bgp_soo:siteoforiginrange_list")
    actions = ButtonsColumn(model=models.SiteOfOriginRange)

    class Meta(BaseTable.Meta):
        model = models.SiteOfOriginRange
        fields = (
            "pk",
            "name",
            "soo_type",
            "administrator",
            "assigned_number_min",
            "assigned_number_max",
            "tenant",
            "description",
            "tags",
            "actions",
        )
        default_columns = (
            "pk",
            "name",
            "soo_type",
            "administrator",
            "assigned_number_min",
            "assigned_number_max",
            "tenant",
            "actions",
        )
