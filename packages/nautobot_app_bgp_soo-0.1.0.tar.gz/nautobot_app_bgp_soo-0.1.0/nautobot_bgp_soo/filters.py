"""Filters for nautobot_bgp_soo."""

import django_filters
from nautobot.apps.filters import (
    NaturalKeyOrPKMultipleChoiceFilter,
    NautobotFilterSet,
    SearchFilter,
    StatusModelFilterSetMixin,
)
from nautobot.dcim.models import Location
from nautobot.tenancy.models import Tenant

from nautobot_bgp_soo import models
from nautobot_bgp_soo.choices import SoOTypeChoices


class SiteOfOriginFilterSet(NautobotFilterSet, StatusModelFilterSetMixin):
    """Filtering of SiteOfOrigin records."""

    q = SearchFilter(
        filter_predicates={
            "administrator": "icontains",
            "description": "icontains",
        },
    )

    soo_type = django_filters.MultipleChoiceFilter(
        choices=SoOTypeChoices,
        label="SoO Type",
    )

    tenant = NaturalKeyOrPKMultipleChoiceFilter(
        queryset=Tenant.objects.all(),
        label="Tenant (name or ID)",
        to_field_name="name",
    )

    locations = NaturalKeyOrPKMultipleChoiceFilter(
        queryset=Location.objects.all(),
        label="Location (name or ID)",
        to_field_name="name",
    )

    class Meta:
        model = models.SiteOfOrigin
        fields = ["id", "soo_type", "administrator", "assigned_number", "status", "tenant", "locations", "tags"]


class SiteOfOriginRangeFilterSet(NautobotFilterSet):
    """Filtering of SiteOfOriginRange records."""

    q = SearchFilter(
        filter_predicates={
            "name": "icontains",
            "administrator": "icontains",
            "description": "icontains",
        },
    )

    soo_type = django_filters.MultipleChoiceFilter(
        choices=SoOTypeChoices,
        label="SoO Type",
    )

    tenant = NaturalKeyOrPKMultipleChoiceFilter(
        queryset=Tenant.objects.all(),
        label="Tenant (name or ID)",
        to_field_name="name",
    )

    class Meta:
        model = models.SiteOfOriginRange
        fields = [
            "id",
            "name",
            "soo_type",
            "administrator",
            "assigned_number_min",
            "assigned_number_max",
            "tenant",
            "tags",
        ]
