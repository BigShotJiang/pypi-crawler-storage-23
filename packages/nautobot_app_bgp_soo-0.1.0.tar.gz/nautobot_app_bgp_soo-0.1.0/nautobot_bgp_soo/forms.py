"""Forms for nautobot_bgp_soo."""

from django import forms
from nautobot.apps.forms import (
    DynamicModelChoiceField,
    DynamicModelMultipleChoiceField,
    NautobotBulkEditForm,
    NautobotFilterForm,
    NautobotModelForm,
    StatusModelBulkEditFormMixin,
    StatusModelFilterFormMixin,
    TagFilterField,
    TagsBulkEditFormMixin,
)
from nautobot.dcim.models import Location
from nautobot.extras.models import Tag
from nautobot.tenancy.models import Tenant

from nautobot_bgp_soo import models

# --- SiteOfOrigin Forms ---


class SiteOfOriginForm(NautobotModelForm):
    """Form for creating/editing SiteOfOrigin records."""

    tags = DynamicModelMultipleChoiceField(queryset=Tag.objects.all(), required=False)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)
    locations = DynamicModelMultipleChoiceField(queryset=Location.objects.all(), required=False)

    class Meta:
        model = models.SiteOfOrigin
        fields = (
            "soo_type",
            "administrator",
            "assigned_number",
            "description",
            "status",
            "tenant",
            "locations",
            "tags",
        )


class SiteOfOriginFilterForm(NautobotFilterForm, StatusModelFilterFormMixin):
    """Form for filtering SiteOfOrigin records."""

    model = models.SiteOfOrigin
    field_order = ["q", "soo_type", "administrator", "status", "tenant", "locations", "tags"]
    tags = TagFilterField(model)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)
    locations = DynamicModelMultipleChoiceField(queryset=Location.objects.all(), required=False)


class SiteOfOriginBulkEditForm(StatusModelBulkEditFormMixin, TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Form for bulk editing SiteOfOrigin records."""

    pk = DynamicModelMultipleChoiceField(queryset=models.SiteOfOrigin.objects.all(), widget=forms.MultipleHiddenInput)
    description = forms.CharField(max_length=255, required=False)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)

    class Meta:
        model = models.SiteOfOrigin
        nullable_fields = ["description", "tenant"]


# --- SiteOfOriginRange Forms ---


class SiteOfOriginRangeForm(NautobotModelForm):
    """Form for creating/editing SiteOfOriginRange records."""

    tags = DynamicModelMultipleChoiceField(queryset=Tag.objects.all(), required=False)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)

    class Meta:
        model = models.SiteOfOriginRange
        fields = (
            "name",
            "soo_type",
            "administrator",
            "assigned_number_min",
            "assigned_number_max",
            "description",
            "tenant",
            "tags",
        )


class SiteOfOriginRangeFilterForm(NautobotFilterForm):
    """Form for filtering SiteOfOriginRange records."""

    model = models.SiteOfOriginRange
    field_order = ["q", "soo_type", "administrator", "tenant", "tags"]
    tags = TagFilterField(model)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)


class SiteOfOriginRangeBulkEditForm(TagsBulkEditFormMixin, NautobotBulkEditForm):
    """Form for bulk editing SiteOfOriginRange records."""

    pk = DynamicModelMultipleChoiceField(
        queryset=models.SiteOfOriginRange.objects.all(), widget=forms.MultipleHiddenInput
    )
    description = forms.CharField(max_length=255, required=False)
    tenant = DynamicModelChoiceField(queryset=Tenant.objects.all(), required=False)

    class Meta:
        model = models.SiteOfOriginRange
        nullable_fields = ["description", "tenant"]
