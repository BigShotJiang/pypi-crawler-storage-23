"""Helper functions for nautobot_bgp_soo."""


def add_available_soos(instance, soos):
    """Create placeholder records for gaps between allocated SoOs in a range.

    Similar to nautobot_bgp_models.helpers.add_available_asns().
    """
    new_list = []
    last_an = None

    for soo in soos:
        an = soo.assigned_number
        if an == instance.assigned_number_min:
            new_list.append(soo)
            last_an = an
        elif last_an is None:
            new_list.append(
                {
                    "assigned_number": instance.assigned_number_min,
                    "available": an - instance.assigned_number_min,
                }
            )
            new_list.append(soo)
            last_an = an
        elif instance.assigned_number_min <= an <= instance.assigned_number_max:
            if an - last_an > 1:
                new_list.append({"assigned_number": last_an + 1, "available": an - last_an - 1})
            new_list.append(soo)
            last_an = an
        elif an == instance.assigned_number_max:
            new_list.append(soo)
            last_an = an

    if not soos:
        new_list.append(
            {
                "assigned_number": instance.assigned_number_min,
                "available": instance.assigned_number_max - instance.assigned_number_min + 1,
            }
        )
    elif last_an is not None and last_an < instance.assigned_number_max:
        new_list.append({"assigned_number": last_an + 1, "available": instance.assigned_number_max - last_an})

    return new_list
