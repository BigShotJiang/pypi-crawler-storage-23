"""URL definitions for nautobot_bgp_soo."""

from nautobot.apps.urls import NautobotUIViewSetRouter

from nautobot_bgp_soo import views

app_name = "nautobot_bgp_soo"

router = NautobotUIViewSetRouter()
router.register("site-of-origin", views.SiteOfOriginUIViewSet)
router.register("site-of-origin-ranges", views.SiteOfOriginRangeUIViewSet)

urlpatterns = router.urls
