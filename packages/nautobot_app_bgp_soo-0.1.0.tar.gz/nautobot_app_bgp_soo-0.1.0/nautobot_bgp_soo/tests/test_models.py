"""Tests for nautobot_bgp_soo models."""

from django.core.exceptions import ValidationError
from django.test import TestCase
from nautobot.extras.models import Status
from nautobot.tenancy.models import Tenant

from nautobot_bgp_soo.choices import SoOTypeChoices
from nautobot_bgp_soo.models import SiteOfOrigin, SiteOfOriginRange


class SiteOfOriginModelTest(TestCase):
    """Test the SiteOfOrigin model."""

    @classmethod
    def setUpTestData(cls):
        cls.status_active = Status.objects.get(name="Active")
        cls.tenant = Tenant.objects.create(name="Test Tenant")

    def test_create_type_0(self):
        """Test creating a Type 0 SoO (2-byte ASN : 4-byte AN)."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number=100,
            status=self.status_active,
        )
        soo.validated_save()
        self.assertEqual(str(soo), "SoO:65000:100")

    def test_create_type_1(self):
        """Test creating a Type 1 SoO (IPv4 : 2-byte AN)."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="10.0.0.1",
            assigned_number=100,
            status=self.status_active,
        )
        soo.validated_save()
        self.assertEqual(str(soo), "SoO:10.0.0.1:100")

    def test_create_type_2(self):
        """Test creating a Type 2 SoO (4-byte ASN : 2-byte AN)."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_2,
            administrator="4200000001",
            assigned_number=100,
            status=self.status_active,
        )
        soo.validated_save()
        self.assertEqual(str(soo), "SoO:4200000001:100")

    def test_tenant_association(self):
        """Test that SoO can be associated with a tenant."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65001",
            assigned_number=200,
            status=self.status_active,
            tenant=self.tenant,
        )
        soo.validated_save()
        self.assertEqual(soo.tenant, self.tenant)

    def test_tenant_optional(self):
        """Test that tenant is optional."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65002",
            assigned_number=300,
            status=self.status_active,
        )
        soo.validated_save()
        self.assertIsNone(soo.tenant)

    def test_unique_together(self):
        """Test that duplicate SoO values are rejected."""
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number=999,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo = SiteOfOrigin(
                soo_type=SoOTypeChoices.TYPE_0,
                administrator="65000",
                assigned_number=999,
                status=self.status_active,
            )
            soo.validated_save()

    def test_type_0_invalid_asn_too_large(self):
        """Test that Type 0 rejects ASN > 65535."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="70000",
            assigned_number=100,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo.validated_save()

    def test_type_0_invalid_asn_not_integer(self):
        """Test that Type 0 rejects non-integer administrator."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="not-a-number",
            assigned_number=100,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo.validated_save()

    def test_type_1_invalid_ip(self):
        """Test that Type 1 rejects invalid IPv4 address."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="999.999.999.999",
            assigned_number=100,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo.validated_save()

    def test_type_1_assigned_number_too_large(self):
        """Test that Type 1 rejects assigned number > 65535."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="10.0.0.1",
            assigned_number=70000,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo.validated_save()

    def test_type_2_max_asn(self):
        """Test that Type 2 accepts maximum 4-byte ASN."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_2,
            administrator="4294967295",
            assigned_number=0,
            status=self.status_active,
        )
        soo.validated_save()
        self.assertEqual(str(soo), "SoO:4294967295:0")

    def test_type_2_assigned_number_too_large(self):
        """Test that Type 2 rejects assigned number > 65535."""
        soo = SiteOfOrigin(
            soo_type=SoOTypeChoices.TYPE_2,
            administrator="100000",
            assigned_number=70000,
            status=self.status_active,
        )
        with self.assertRaises(ValidationError):
            soo.validated_save()


class SiteOfOriginRangeModelTest(TestCase):
    """Test the SiteOfOriginRange model."""

    @classmethod
    def setUpTestData(cls):
        cls.status_active = Status.objects.get(name="Active")
        cls.tenant = Tenant.objects.create(name="Range Test Tenant")

    def test_create_valid_range(self):
        """Test creating a valid SoO range."""
        soo_range = SiteOfOriginRange(
            name="Test Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=100,
            assigned_number_max=200,
        )
        soo_range.validated_save()
        self.assertEqual(str(soo_range), "SoO:65000:100-200")

    def test_tenant_association(self):
        """Test that a range can be associated with a tenant."""
        soo_range = SiteOfOriginRange(
            name="Tenant Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65001",
            assigned_number_min=1,
            assigned_number_max=10,
            tenant=self.tenant,
        )
        soo_range.validated_save()
        self.assertEqual(soo_range.tenant, self.tenant)

    def test_min_greater_than_max_rejected(self):
        """Test that assigned_number_min >= assigned_number_max is rejected."""
        soo_range = SiteOfOriginRange(
            name="Bad Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=200,
            assigned_number_max=100,
        )
        with self.assertRaises(ValidationError):
            soo_range.validated_save()

    def test_min_equals_max_rejected(self):
        """Test that assigned_number_min == assigned_number_max is rejected."""
        soo_range = SiteOfOriginRange(
            name="Equal Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=100,
            assigned_number_max=100,
        )
        with self.assertRaises(ValidationError):
            soo_range.validated_save()

    def test_invalid_administrator_rejected(self):
        """Test that an invalid administrator is rejected."""
        soo_range = SiteOfOriginRange(
            name="Invalid Admin Range",
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="not-an-ip",
            assigned_number_min=1,
            assigned_number_max=10,
        )
        with self.assertRaises(ValidationError):
            soo_range.validated_save()

    def test_soos_property(self):
        """Test that the soos property returns matching SiteOfOrigin objects."""
        soo_range = SiteOfOriginRange.objects.create(
            name="Soos Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65010",
            assigned_number_min=100,
            assigned_number_max=110,
        )
        soo_in = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65010",
            assigned_number=105,
            status=self.status_active,
        )
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65010",
            assigned_number=999,
            status=self.status_active,
        )
        self.assertIn(soo_in, soo_range.soos)
        self.assertEqual(soo_range.soos.count(), 1)

    def test_get_next_available_soo(self):
        """Test get_next_available_soo returns the first available number."""
        soo_range = SiteOfOriginRange.objects.create(
            name="Next Avail Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65020",
            assigned_number_min=1,
            assigned_number_max=5,
        )
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65020",
            assigned_number=1,
            status=self.status_active,
        )
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65020",
            assigned_number=2,
            status=self.status_active,
        )
        self.assertEqual(soo_range.get_next_available_soo(), 3)

    def test_get_next_available_soo_full(self):
        """Test get_next_available_soo returns None when range is full."""
        soo_range = SiteOfOriginRange.objects.create(
            name="Full Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65030",
            assigned_number_min=1,
            assigned_number_max=2,
        )
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65030",
            assigned_number=1,
            status=self.status_active,
        )
        SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65030",
            assigned_number=2,
            status=self.status_active,
        )
        self.assertIsNone(soo_range.get_next_available_soo())
