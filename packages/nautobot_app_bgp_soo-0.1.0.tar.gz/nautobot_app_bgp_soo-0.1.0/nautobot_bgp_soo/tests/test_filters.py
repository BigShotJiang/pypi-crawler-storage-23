"""Tests for nautobot_bgp_soo filters."""

from django.test import TestCase
from nautobot.extras.models import Status
from nautobot.tenancy.models import Tenant

from nautobot_bgp_soo.choices import SoOTypeChoices
from nautobot_bgp_soo.filters import SiteOfOriginFilterSet, SiteOfOriginRangeFilterSet
from nautobot_bgp_soo.models import SiteOfOrigin, SiteOfOriginRange


class SiteOfOriginFilterSetTest(TestCase):
    """Test SiteOfOriginFilterSet."""

    @classmethod
    def setUpTestData(cls):
        cls.status_active = Status.objects.get(name="Active")
        cls.tenant = Tenant.objects.create(name="Filter Test Tenant")

        cls.soo_type0 = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number=100,
            status=cls.status_active,
            tenant=cls.tenant,
        )
        cls.soo_type1 = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="10.0.0.1",
            assigned_number=200,
            status=cls.status_active,
        )
        cls.soo_type2 = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_2,
            administrator="4200000001",
            assigned_number=300,
            status=cls.status_active,
        )

    def test_filter_by_soo_type(self):
        filterset = SiteOfOriginFilterSet({"soo_type": [SoOTypeChoices.TYPE_0]}, SiteOfOrigin.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.soo_type0)

    def test_filter_by_tenant(self):
        filterset = SiteOfOriginFilterSet({"tenant": [self.tenant.name]}, SiteOfOrigin.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.soo_type0)

    def test_search_by_administrator(self):
        filterset = SiteOfOriginFilterSet({"q": "10.0.0"}, SiteOfOrigin.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.soo_type1)


class SiteOfOriginRangeFilterSetTest(TestCase):
    """Test SiteOfOriginRangeFilterSet."""

    @classmethod
    def setUpTestData(cls):
        cls.tenant = Tenant.objects.create(name="Range Filter Tenant")

        cls.range_type0 = SiteOfOriginRange.objects.create(
            name="Type 0 Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=100,
            assigned_number_max=200,
            tenant=cls.tenant,
        )
        cls.range_type1 = SiteOfOriginRange.objects.create(
            name="Type 1 Range",
            soo_type=SoOTypeChoices.TYPE_1,
            administrator="10.0.0.1",
            assigned_number_min=1,
            assigned_number_max=100,
        )

    def test_filter_by_soo_type(self):
        filterset = SiteOfOriginRangeFilterSet({"soo_type": [SoOTypeChoices.TYPE_0]}, SiteOfOriginRange.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.range_type0)

    def test_filter_by_tenant(self):
        filterset = SiteOfOriginRangeFilterSet({"tenant": [self.tenant.name]}, SiteOfOriginRange.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.range_type0)

    def test_search_by_name(self):
        filterset = SiteOfOriginRangeFilterSet({"q": "Type 1"}, SiteOfOriginRange.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.range_type1)

    def test_search_by_administrator(self):
        filterset = SiteOfOriginRangeFilterSet({"q": "10.0.0"}, SiteOfOriginRange.objects.all())
        self.assertEqual(filterset.qs.count(), 1)
        self.assertEqual(filterset.qs.first(), self.range_type1)
