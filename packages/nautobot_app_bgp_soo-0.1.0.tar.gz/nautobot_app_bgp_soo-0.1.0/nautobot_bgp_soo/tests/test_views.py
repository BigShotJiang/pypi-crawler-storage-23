"""Tests for nautobot_bgp_soo views."""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from nautobot.extras.models import Status

from nautobot_bgp_soo.choices import SoOTypeChoices
from nautobot_bgp_soo.models import SiteOfOrigin, SiteOfOriginRange

User = get_user_model()


class SiteOfOriginViewTest(TestCase):
    """Test SiteOfOrigin UI views."""

    @classmethod
    def setUpTestData(cls):
        cls.status_active = Status.objects.get(name="Active")
        cls.user = User.objects.create_superuser(username="testuser", password="testpass")
        cls.soo = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number=100,
            status=cls.status_active,
        )

    def setUp(self):
        self.client.force_login(self.user)

    def test_list_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforigin_list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "65000")

    def test_detail_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforigin", kwargs={"pk": self.soo.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_add_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforigin_add")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_edit_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforigin_edit", kwargs={"pk": self.soo.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)


class SiteOfOriginRangeViewTest(TestCase):
    """Test SiteOfOriginRange UI views."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="testuser2", password="testpass")
        cls.soo_range = SiteOfOriginRange.objects.create(
            name="View Test Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=100,
            assigned_number_max=200,
        )

    def setUp(self):
        self.client.force_login(self.user)

    def test_list_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforiginrange_list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "View Test Range")

    def test_detail_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforiginrange", kwargs={"pk": self.soo_range.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_add_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforiginrange_add")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_edit_view(self):
        url = reverse("plugins:nautobot_bgp_soo:siteoforiginrange_edit", kwargs={"pk": self.soo_range.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
