"""Tests for nautobot_bgp_soo REST API."""

from django.contrib.auth import get_user_model
from django.urls import reverse
from nautobot.extras.models import Status
from rest_framework import status
from rest_framework.test import APITestCase

from nautobot_bgp_soo.choices import SoOTypeChoices
from nautobot_bgp_soo.models import SiteOfOrigin, SiteOfOriginRange

User = get_user_model()


class SiteOfOriginAPITest(APITestCase):
    """Test SiteOfOrigin REST API endpoints."""

    @classmethod
    def setUpTestData(cls):
        cls.status_active = Status.objects.get(name="Active")
        cls.user = User.objects.create_superuser(username="testuser", password="testpass")
        cls.soo = SiteOfOrigin.objects.create(
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number=100,
            status=cls.status_active,
        )

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_list_endpoint(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforigin-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_detail_endpoint(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforigin-detail", kwargs={"pk": self.soo.pk})
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["administrator"], "65000")

    def test_create_endpoint(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforigin-list")
        data = {
            "soo_type": SoOTypeChoices.TYPE_1,
            "administrator": "192.168.1.1",
            "assigned_number": 200,
            "status": self.status_active.pk,
        }
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(SiteOfOrigin.objects.count(), 2)

    def test_create_invalid_rejects(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforigin-list")
        data = {
            "soo_type": SoOTypeChoices.TYPE_0,
            "administrator": "not-a-number",
            "assigned_number": 100,
            "status": self.status_active.pk,
        }
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)


class SiteOfOriginRangeAPITest(APITestCase):
    """Test SiteOfOriginRange REST API endpoints."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="testuser2", password="testpass")
        cls.soo_range = SiteOfOriginRange.objects.create(
            name="API Test Range",
            soo_type=SoOTypeChoices.TYPE_0,
            administrator="65000",
            assigned_number_min=100,
            assigned_number_max=200,
        )

    def setUp(self):
        self.client.force_authenticate(user=self.user)

    def test_list_endpoint(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforiginrange-list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["count"], 1)

    def test_detail_endpoint(self):
        url = reverse(
            "plugins-api:nautobot_bgp_soo-api:siteoforiginrange-detail",
            kwargs={"pk": self.soo_range.pk},
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["name"], "API Test Range")

    def test_create_endpoint(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforiginrange-list")
        data = {
            "name": "New Range",
            "soo_type": SoOTypeChoices.TYPE_0,
            "administrator": "65001",
            "assigned_number_min": 1,
            "assigned_number_max": 50,
        }
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(SiteOfOriginRange.objects.count(), 2)

    def test_create_invalid_rejects(self):
        url = reverse("plugins-api:nautobot_bgp_soo-api:siteoforiginrange-list")
        data = {
            "name": "Bad Range",
            "soo_type": SoOTypeChoices.TYPE_0,
            "administrator": "65000",
            "assigned_number_min": 200,
            "assigned_number_max": 100,
        }
        response = self.client.post(url, data, format="json")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
