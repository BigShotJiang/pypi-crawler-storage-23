"""Choice sets for nautobot_bgp_soo."""

from nautobot.apps.choices import ChoiceSet


class SoOTypeChoices(ChoiceSet):
    """Choices for SoO extended community type."""

    TYPE_0 = "0"
    TYPE_1 = "1"
    TYPE_2 = "2"

    CHOICES = (
        (TYPE_0, "Type 0 - 2-byte ASN : 4-byte AN"),
        (TYPE_1, "Type 1 - IPv4 Address : 2-byte AN"),
        (TYPE_2, "Type 2 - 4-byte ASN : 2-byte AN"),
    )
