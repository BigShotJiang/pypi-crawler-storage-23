# Nautobot BGP Site of Origin (SoO)

A [Nautobot](https://nautobot.com/) app for modeling BGP Site of Origin (SoO) extended communities.

## Overview

BGP Site of Origin (SoO) is an extended community attribute used in MPLS VPN environments to identify the site from which a route originated, preventing routing loops in multi-homed CE environments.

This app extends the [Nautobot BGP Models](https://github.com/nautobot/nautobot-app-bgp-models) app with two models:

### Site of Origin

Stores individual SoO values as their component parts:

| SoO Type | Administrator | Assigned Number | Example |
|----------|--------------|-----------------|---------|
| Type 0 | 2-byte ASN (0–65535) | 4-byte (0–4294967295) | `SoO:65000:100` |
| Type 1 | IPv4 Address | 2-byte (0–65535) | `SoO:10.0.0.1:42` |
| Type 2 | 4-byte ASN (0–4294967295) | 2-byte (0–65535) | `SoO:4200000001:100` |

Each SoO can optionally be associated with:

- A **Status** (Active, Reserved, Deprecated, Planned)
- A **Tenant**
- One or more **Locations**

### Site of Origin Range

Defines a pool of SoO assigned numbers for allocation, similar to ASN Ranges in the BGP Models app. Each range specifies:

- A **Name** for the range
- A fixed **SoO Type** and **Administrator**
- A **Start** and **End** assigned number defining the pool boundaries
- An optional **Tenant**

The range detail view displays all SoO objects that fall within the range. The `get_next_available_soo()` method returns the first unallocated assigned number in the range.

### PeerEndpoint Relationship

On installation, the app automatically creates a Nautobot **Relationship** linking BGP Models PeerEndpoints to Sites of Origin. This allows associating an SoO with a specific BGP peering endpoint.

## Requirements

- Nautobot >= 2.4.0
- nautobot-bgp-models >= 2.3.0

## Installation

Install from PyPI:

```bash
pip install nautobot-app-bgp-soo
```

This will automatically install `nautobot-app-bgp-models` as a dependency.

Add both plugins to your `nautobot_config.py`:

```python
PLUGINS = [
    "nautobot_bgp_models",
    "nautobot_bgp_soo",
]
```

Run database migrations:

```bash
nautobot-server migrate
```

## Usage

### Navigation

The app adds menu items under **Routing > BGP - Global**:

- **Sites of Origin** — list, create, import, bulk-edit individual SoO values
- **Site of Origin Ranges** — list, create, import, bulk-edit SoO ranges

### Creating a Site of Origin

1. Navigate to **Routing > BGP - Global > Sites of Origin**
2. Click the **+** button
3. Select the **SoO Type** (0, 1, or 2)
4. Enter the **Administrator** (ASN for types 0/2, IPv4 address for type 1)
5. Enter the **Assigned Number**
6. Optionally set a **Status**, **Tenant**, **Locations**, and **Description**

### Creating a Site of Origin Range

1. Navigate to **Routing > BGP - Global > Site of Origin Ranges**
2. Click the **+** button
3. Enter a **Name** for the range
4. Select the **SoO Type** and **Administrator** (all SoOs in the range share these)
5. Set the **Start** and **End** assigned numbers
6. Optionally set a **Tenant** and **Description**

The range detail page displays all existing SoO objects that fall within the range boundaries.

### Associating SoO with a PeerEndpoint

The app creates a Nautobot Relationship between PeerEndpoint and SiteOfOrigin. To use it:

1. Navigate to a BGP PeerEndpoint detail page
2. Under the **Relationships** section, associate a Site of Origin

### REST API

The following API endpoints are available:

| Endpoint | Description |
|----------|-------------|
| `/api/plugins/bgp-soo/site-of-origin/` | CRUD operations for Sites of Origin |
| `/api/plugins/bgp-soo/site-of-origin-ranges/` | CRUD operations for Site of Origin Ranges |

Standard Nautobot REST API conventions apply (filtering, pagination, bulk operations).

### GraphQL

Both models are available via the Nautobot GraphQL API as `site_of_origins` and `site_of_origin_ranges`.

## License

This project is licensed under the [Mozilla Public License 2.0](LICENSE).
