# TrueZmanim TUI

A Text User Interface (TUI) application for viewing Jewish prayer times (zmanim) based on the truezmanim.com API.

## Features

- Search for cities with autocomplete
- View zmanim (prayer times) for any city
- Toggle between English and Hebrew display
- Shows Hebrew date and weekly Parsha
- Settings persist between sessions

## Installation

```bash
pip install truezmanim-tui
```

## Usage

```bash
truezmanim
```

Or run directly:

```bash
python -m truezmanim_tui
```

## Development

```bash
# Clone the repository
git clone https://github.com/DrorMaor/TrueZmanim_TUI.git
cd truezmanim-tui

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -e .
```

## License

MIT
