from truezmanim_tui.app import ZmanimTUI

def main():
    app = ZmanimTUI()
    app.run()
