# Credits

## Maintainers
* Matthew Love <matthew.love@colorado.edu>

## Contributors
* Elliot Lim (@e1im)
* Christopher Amante (@camante)
* Michael McFerrin (@mmacferrin)
* Matt Fisher (@mfisher87)