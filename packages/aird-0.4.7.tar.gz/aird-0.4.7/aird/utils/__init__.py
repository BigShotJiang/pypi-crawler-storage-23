"""Utility functions for Aird."""






