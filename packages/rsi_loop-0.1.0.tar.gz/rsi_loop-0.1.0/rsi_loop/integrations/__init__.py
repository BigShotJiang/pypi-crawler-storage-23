"""RSI Loop integrations for various agent frameworks."""
