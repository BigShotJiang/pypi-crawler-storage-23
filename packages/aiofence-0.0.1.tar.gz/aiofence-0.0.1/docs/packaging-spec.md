# Packaging Spec

Prepare aiofence for PyPI publishing using modern uv + hatchling patterns.

## References

Research based on how these projects package for PyPI:

- **FastAPI** — pdm-backend, dynamic version from `__init__.py`, `uv build` + `uv publish` in CI, trusted publishing
- **Pydantic** — hatchling + `hatch-fancy-pypi-readme`, dynamic version from `version.py`, `uv publish` in CI, trusted publishing
- **HTTPX** — hatchling + `hatch-fancy-pypi-readme`, dynamic version from `__version__.py`, sdist includes tests
- **Litestar** — hatchling, static version in pyproject.toml, `[tool.uv] default-groups`
- **AnyIO** — setuptools + setuptools_scm, git-tag versioning, trusted publishing

Key docs:
- [uv — Building and publishing a package](https://docs.astral.sh/uv/guides/package/)
- [uv — Building distributions](https://docs.astral.sh/uv/concepts/projects/build/)
- [astral-sh/trusted-publishing-examples](https://github.com/astral-sh/trusted-publishing-examples)
- [PyPI Trusted Publishers](https://docs.pypi.org/trusted-publishers/)

---

## 1. Fix pyproject.toml metadata

### 1.1 Drop `v` prefix from version

PEP 440 versions are plain numbers. Current `version = "v0.0.0"` is non-standard.

```toml
version = "0.1.0"
```

### 1.2 Add missing PyPI fields

All reviewed projects include these. Without them PyPI page is bare.

```toml
readme = "README.md"
authors = [
    { name = "Stas" },
]

[project.urls]
Repository = "https://github.com/<owner>/aiofence"
```

### 1.3 Add `[tool.uv]` config

Used by Pydantic and Litestar. Tells `uv sync` which groups to install by default.

```toml
[tool.uv]
default-groups = ["dev"]
```

### 1.4 Control sdist contents

Pydantic, HTTPX, and Litestar all explicitly list what goes into the source distribution. Prevents shipping IDE configs, docs, CI files.

```toml
[tool.hatch.build.targets.sdist]
include = ["/aiofence", "/tests", "/README.md", "/LICENSE"]
```

---

## 2. Runtime version exposure

Use `importlib.metadata` — no duplication, always matches installed package. This is the standard approach (PEP 566). Used by FastAPI, Litestar, and recommended by packaging guides.

```python
# aiofence/__init__.py
from importlib.metadata import version

__version__ = version("aiofence")
```

Keep version static in `pyproject.toml` (not dynamic). This lets `uv version --bump patch/minor/major` work for releases.

Alternative considered and rejected:
- **Dynamic version from source file** (Pydantic/HTTPX pattern) — `uv version --bump` doesn't support dynamic versions yet ([uv#14137](https://github.com/astral-sh/uv/issues/14137))
- **Git-tag versioning** (AnyIO pattern via setuptools_scm / uv-dynamic-versioning) — extra build dependency, overkill for this project

---

## 3. GitHub Actions publish workflow

Consensus across FastAPI, Pydantic, AnyIO: tag-triggered workflow with PyPI Trusted Publishing (OIDC). No API tokens stored in secrets.

```yaml
# .github/workflows/publish.yml
name: Publish
on:
  push:
    tags: ["v*"]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv build
      - run: uv publish
```

### One-time PyPI setup

The project must exist on PyPI before trusted publishing can be configured. First publish is manual.

**Step 1 — Generate an API token**

Go to https://pypi.org/manage/account/token/ and create a token scoped to "entire account" (project-scoped tokens require the project to already exist).

**Step 2 — First manual publish**

```bash
uv build
uv publish --token pypi-<YOUR_API_TOKEN>
```

This creates the `aiofence` project on PyPI.

**Step 3 — Configure Trusted Publisher on PyPI**

Go to https://pypi.org/manage/project/aiofence/settings/publishing/ and click "Add a new publisher":

| Field | Value |
|-------|-------|
| Owner | `<github-username-or-org>` |
| Repository | `aiofence` |
| Workflow name | `publish.yml` |
| Environment name | `pypi` |

**Step 4 — Create GitHub environment**

In the GitHub repo: Settings → Environments → New environment → name it `pypi`. Optionally add deployment protection rules (require manual approval before publish).

**Step 5 — Delete the API token**

The token from Step 1 is no longer needed. Trusted publishing uses OIDC — no secrets stored anywhere. Delete it at https://pypi.org/manage/account/token/.

### Release flow

```bash
uv version --bump patch          # 0.1.0 -> 0.1.1
git add pyproject.toml uv.lock
git commit -m "chore: release v0.1.1"
git tag v0.1.1
git push && git push --tags      # triggers publish workflow
```

---

## 4. Build validation

Before first publish, verify the package builds correctly without uv-specific source overrides:

```bash
uv build --no-sources
```

This simulates what happens on PyPI where `[tool.uv.sources]` overrides are not available.

---

## Summary of changes

| File | Change |
|------|--------|
| `pyproject.toml` | Fix version, add readme/authors/urls, add `[tool.uv]`, add sdist include |
| `aiofence/__init__.py` | Add `__version__` via `importlib.metadata` |
| `.github/workflows/publish.yml` | New file — tag-triggered trusted publishing |