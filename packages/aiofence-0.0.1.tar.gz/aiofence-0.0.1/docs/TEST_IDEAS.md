# Test Ideas

## P0 — runtime trigger paths

- [x] Timeout fires during body — suppressed, `fence.cancelled=True`, counter balanced
- [x] Event fires during body — suppressed, `fence.cancelled=True`
- [x] Body catches `CancelledError` internally, exits normally — `uncancel()` still called, counter balanced
- [x] User calls `task.uncancel()` inside body — counter stays balanced despite double uncancel

## P1 — external cancellation interop

- [x] External `task.cancel()` during fence — `CancelledError` propagates (fence doesn't claim it)
- [x] External cancel + fence trigger both fire — fence suppresses its own, external propagates
- [x] External cancel with nested fences — propagates through all layers, neither fence claims it
- [x] `asyncio.timeout()` nested inside Fence — timeout raises `TimeoutError`, fence unaffected
- [x] `asyncio.timeout(0)` nested inside Fence — same behavior with zero timeout
- [x] Fence nested inside `asyncio.timeout()` — fence suppresses its own, timeout's `CancelledError` propagates
- [x] Fence with `timeout(0)` after prior cancel/uncancel cycle — counter protocol survives baseline offset
  [CPython: `test_timeout_after_cancellation`](https://github.com/python/cpython/pull/102923)
- [x] Fresh `task.cancel()` inside active fence body — `CancelledError` propagates, fence doesn't claim it
  [CPython: `test_cancel_in_timeout_after_cancellation`](https://github.com/python/cpython/pull/102923)
- [x] Child task cancelled inside fence body — `CancelledError` propagates, fence unaffected, parent counter balanced

## P2 — body exceptions during cancellation

- [x] Trigger fires + body raises `ValueError` — `ValueError` propagates, `fence.cancelled=True`, counter balanced

## P3 — nested fences

- [x] Inner timeout fires — outer unaffected
- [x] Outer timeout fires — inner doesn't claim
- [x] Deeply nested (3+ levels) — all counters stay balanced
- [x] Inner fence inside outer `asyncio.timeout()` — fence suppresses, outer timeout unaffected
- [x] Nested fences share same event trigger — both cancelled, body and post-inner code not reached

## P4 — edge cases

- [x] Negative timeout — same as zero: suppressed, `fence.cancelled=True`
- [x] Handle disarm after trigger already fired — no crash (idempotent)
- [x] Event set synchronously inside fence body — cancel fires, no spurious `CancelledError` after exit
- [x] Multiple triggers fire — `fence.reasons` records all reasons
