# Asyncio Testing & Debugging Patterns

Reference of patterns used by CPython and anyio for testing and debugging async internals.

## Debugging

### Debug Mode

```python
# Environment variable
PYTHONASYNCIODEBUG=1 python main.py

# In code
asyncio.run(main(), debug=True)

# At runtime
loop.set_debug(True)
```

What it enables:
- Slow callback warnings (>100ms, configurable via `loop.slow_callback_duration`)
- Thread-safety checks on non-threadsafe APIs
- Forgotten await detection (logs unawaited coroutines)
- Creation tracebacks on task exceptions

Enable the asyncio logger alongside:
```python
import logging
logging.getLogger("asyncio").setLevel(logging.DEBUG)
```

> Source: [Python docs — Developing with asyncio](https://docs.python.org/3/library/asyncio-dev.html)

### Task Introspection (runtime)

```python
for t in asyncio.all_tasks():
    if t is not asyncio.current_task():
        t.print_stack(limit=5)
```

Signal-triggered dump for stuck programs:
```python
import signal
signal.signal(signal.SIGUSR1, lambda *_: [
    t.print_stack() for t in asyncio.all_tasks()
])
```

### Python 3.14+ — `asyncio ps` / `pstree`

Zero-code introspection of a running process by PID:
```bash
python -m asyncio ps <PID>       # flat task table
python -m asyncio pstree <PID>   # hierarchical coroutine call tree
```

> Source: [Python 3.14 whatsnew](https://docs.python.org/3/whatsnew/3.14.html)

### Third-party Tools

| Tool | Purpose |
|---|---|
| [aiomonitor](https://github.com/aio-libs/aiomonitor) | Telnet/web console — list, inspect, cancel tasks, async REPL |
| [aiodebug](https://pypi.org/project/aiodebug/) | Always-on production monitoring — stack traces on event loop hangs |
| [aiomonitor-ng](https://pypi.org/project/aiomonitor/) | Extended aiomonitor with task creation chain and cancellation trace tracking |

---

## Testing Patterns

### 1. Nonlocal Counters / Markers

Track callback execution count or execution flow with `nonlocal`.

```python
count = 0

def callback():
    nonlocal count
    count += 1

loop.call_soon(callback)
run_once(loop)
assert count == 1
```

Execution flow tracking (anyio pattern):
```python
marker = None

async def dummy():
    nonlocal marker
    marker = 1
    await checkpoint()
    marker = 2  # should never reach if cancelled

tg.cancel_scope.cancel()
assert marker == 1
```

> Source: [CPython `test_base_events.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/test_base_events.py),
> [anyio `test_taskgroups.py`](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py)

### 2. `mock.Mock()` for Call Tracking

```python
loop._process_events = mock.Mock()
# ... run stuff ...
assert loop._process_events.call_count == 10
```

> Source: [CPython `test_base_events.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/test_base_events.py)

### 3. Method Spy with `wraps=`

Spy on internal methods without altering behavior — count calls to `_deliver_cancellation`:

```python
with mock.patch.object(
    scope, "_deliver_cancellation",
    wraps=getattr(scope, "_deliver_cancellation"),
) as cancel_spy:
    # ... trigger cancellation ...
    assert len(cancel_spy.call_args_list) < 10
    cancel_spy.assert_not_called()  # on shielded scope
```

> Source: [anyio `test_taskgroups.py` L265-303](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py)

### 4. Subclass with Counting

CPython's `CommonFuture` overrides methods to count invocations:

```python
class CommonFuture:
    def __init__(self, *args, **kwargs):
        self.calls = collections.defaultdict(lambda: 0)
        super().__init__(*args, **kwargs)

    def add_done_callback(self, *args, **kwargs):
        self.calls["add_done_callback"] += 1
        return super().add_done_callback(*args, **kwargs)
```

Then assert: `assert dict(task.calls) == {"add_done_callback": 2}`

> Source: [CPython `test_tasks.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/test_tasks.py)

### 5. Task Counting via Set-Diff

Snapshot before, diff after:

```python
existing_tasks = set(get_running_tasks())
tg.start_soon(task1)
tg.start_soon(task2)
new_tasks = set(get_running_tasks()) - existing_tasks
assert len(new_tasks) == 2
```

CPython uses `asyncio.all_tasks()` similarly:
```python
assert asyncio.all_tasks(loop=loop) == {task}
# ... after cleanup ...
assert asyncio.all_tasks(loop=loop) == set()  # no leaks
```

> Source: [anyio `test_debugging.py` L74-99](https://github.com/agronholm/anyio/blob/master/tests/test_debugging.py),
> [CPython `test_tasks.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/test_tasks.py)

### 6. Cancel Scope State Assertions

Anyio scopes expose boolean properties:

```python
with fail_after(0.1) as scope:
    await sleep(1)

assert scope.cancel_called
assert scope.cancelled_caught
```

Nested scope attribution:
```python
with move_on_after(0.1) as outer:
    with move_on_after(1) as inner:
        await sleep(2)

assert outer.cancel_called and outer.cancelled_caught
assert not inner.cancel_called and not inner.cancelled_caught
```

> Source: [anyio `test_taskgroups.py` L538-639](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py)

### 7. `task.cancelling()` Counter Checks (Python 3.11+)

Verify the cancel/uncancel balance is correct after scope exit:

```python
task = asyncio.current_task()
with CancelScope() as scope:
    scope.cancel()
    await checkpoint()

assert task.cancelling() == 0  # properly uncancelled
```

> Source: [anyio `test_taskgroups.py` L1399-1538](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py)

### 8. `wait_all_tasks_blocked()`

Anyio's most important test helper — deterministic synchronization without `sleep()`:

```python
async with create_task_group() as tg:
    tg.start_soon(child)
    await wait_all_tasks_blocked()  # child is definitely blocked now
    tg.cancel_scope.cancel()
```

> Source: used throughout [anyio tests](https://github.com/agronholm/anyio/tree/master/tests)

### 9. `.statistics()` on Primitives

Lock, Event, Semaphore, etc. expose a `.statistics()` method:

```python
event = Event()
tg.start_soon(waiter)
await wait_all_tasks_blocked()
assert event.statistics().tasks_waiting == 1
```

> Source: [anyio `test_synchronization.py`](https://github.com/agronholm/anyio/blob/master/tests/test_synchronization.py)

### 10. Unreachable Assertions

`pytest.fail()` as a "this code should never execute" marker:

```python
with fail_after(1):
    await sleep(2)
    pytest.fail("Execution should not reach this point")
```

> Source: [anyio `test_taskgroups.py` L984-1001](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py)

### 11. Queue Inspection (internal state)

```python
h = loop.call_soon(cb)
assert h in loop._ready       # in the ready queue
assert h in loop._scheduled   # or in the timer heap
```

> Source: [CPython `test_base_events.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/test_base_events.py)

---

## Leak Detection

### Reference Cycle Detection

```python
try:
    async with tg:
        raise _Done
except ExceptionGroup as exc:
    pass

assert gc.get_referrers(exc) == no_other_refs()
```

Where `no_other_refs()` is version-aware:
```python
if sys.version_info >= (3, 14):
    def no_other_refs(): return [sys._getframe(1).f_generator]
elif sys.version_info >= (3, 11):
    def no_other_refs(): return []
else:
    def no_other_refs(): return [sys._getframe(1)]
```

> Source: [anyio `test_taskgroups.py` L1601-1707](https://github.com/agronholm/anyio/blob/master/tests/test_taskgroups.py),
> [anyio `conftest.py` L160-172](https://github.com/agronholm/anyio/blob/master/tests/conftest.py)

### Thread Leak Detection

```python
@pytest.fixture
def no_thread_leaks():
    threads_before = threading.enumerate()
    yield
    leaked = set(threading.enumerate()) - set(threads_before)
    assert not leaked
```

> Source: [anyio `test_pytest_plugin.py`](https://github.com/agronholm/anyio/blob/master/tests/test_pytest_plugin.py)

### Blocking Call Detection (BlockBuster)

Autouse fixture that fails if blocking I/O happens from async code:

```python
@pytest.fixture(autouse=True)
def blockbuster():
    with blockbuster_ctx("anyio", excluded_modules=[...]) as bb:
        yield bb
```

> Source: [anyio `conftest.py` L90-109](https://github.com/agronholm/anyio/blob/master/tests/conftest.py)

---

## CPython Test Infrastructure

### `TestLoop` — Manual Time Control

```python
class TestLoop(base_events.BaseEventLoop):
    def __init__(self):
        self._time = 0
        self._timers = []
        self.reset_counters()
```

Allows advancing time manually and tracking reader/writer callbacks.

### `MockCallback`

```python
def MockCallback(**kwargs):
    return mock.Mock(spec=["__call__"], **kwargs)
```

### `MockPattern` — Regex-based Assertion

```python
class MockPattern(str):
    def __eq__(self, other):
        return bool(re.search(str(self), other, re.S))
```

> Source: [CPython `test_asyncio/utils.py`](https://github.com/python/cpython/blob/main/Lib/test/test_asyncio/utils.py)
