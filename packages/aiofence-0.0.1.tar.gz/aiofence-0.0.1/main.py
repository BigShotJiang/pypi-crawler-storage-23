import asyncio

from aiofence import Fence, TimeoutTrigger


async def main() -> None:
    event = asyncio.Event()

    try:
        with Fence(TimeoutTrigger(0)) as fence:
            await asyncio.sleep(0)
            reached = True
    except:
        pass

    print(reached)


asyncio.run(main(), debug=True)
