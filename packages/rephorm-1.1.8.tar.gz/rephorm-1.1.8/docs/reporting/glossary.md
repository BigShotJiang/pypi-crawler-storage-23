# Appendix C – Glossary

**Available page width:** The width of the page minus the margins

**Multiline Title:** A title that breaks into multiple lines of text, allowing for better readability or to fit longer titles.

