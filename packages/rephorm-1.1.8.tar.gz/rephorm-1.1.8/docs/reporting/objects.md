# Working with objects

In this section, we will explore two essential aspects of working with objects: creating instances and understanding the add method. This content is aimed at those who have minimal or no experience with coding. If you already have coding expertise, you might find this section basic and may opt to skip it.

## Object instantiation

**Instantiating an object** is like following a specific blueprint to assemble a model airplane. Once built (instantiated), each airplane is a real, tangible item that you can see and touch, just like an object in programming is a usable element you can work with.

Here, we will review how to instantiate a report object so we can work with it, such as adding other object instances to it and more. The process would look like this:

```python
report = Rephorm.Report(title="Hello", subtitle="world", orientation="L", format = "A4")
```

In this example, we have instantiated a report object with specific parameters: `title`, `subtitle`, `orientation`, and `format`. These values are passed inside the parentheses, which are called **object parameters**. These parameters vary depending on the type of object being created. (You can find all available parameters in the "Object Parameters" section).

---

The `report` variable now holds this object instance, allowing us to interact with it. For example, to add an object to the report, we would use the `add` method like this:

```python
report.add(...)
```
## `Add()` method

This method lets you attach one object to another, like adding pieces to a puzzle to build something bigger. 

Objects that can nest other objects have an `add()` method.

If you want to add a `grid` to the `report` object, you would:

* Instantiate the `grid` object:
    ```python
    small_grid = Rephorm.Grid(ncol=2, nrow=2)
    ```
* Add the `grid` to the `report` object:
    ```python
    report.add(small_grid)
    ```

The `add()` method can typically be used on any object that can contain other objects (i.e., objects that can have children). For instance, you would not find an `add()` method for a `Text` object because it is a final (edge) object—it cannot contain or nest other objects.

## Creating and adding objects directly (Embedding)

There are two ways to create and add objects, like a TableSeries, to a section (e.g., table_section):

**Direct Embedding:** 

* In this approach, the object is created and added directly within the add() method.
* The Rephorm.TableSeries() object is instantiated inline, and all its properties (like data, title, units, and styles) are specified in the same step.

```bash
 1. # Direct embedding: Create the TableSeries object inside .add() method
 2. table_section.add(
 3.     Rephorm.TableSeries(
 4.         H["l_ym"],
 5.         title="l_ym",
 6.         unit="level",
 7.         styles={"highlight_color": "#46b337"}
 8.     )
 9. )
```
**Instantiating the Object first:**

* In this approach, the TableSeries object is first instantiated and assigned to a variable. This variable is then passed to the add() method.

```bash
1. # Creating the object first (Reusable Object)
 2. # Create the TableSeries object
 3. table_series_1 = Rephorm.TableSeries(
 4.     H["l_ym"],
 5.     title="l_ym",
 6.     unit="level",
 7.     styles={"highlight_color": "#46b337"}
 8. )
 9. # Add the created object to the section
10. table_section.add(table_series_1)
```
Using the direct embedding reduces code length, but can decrease readability.

## Page break object

Rephorm follows the "one object per page" principle, meaning each time you add an object—such as a table or grid — directly to the report instance, it is placed on a new page. This automatic behavior applies only when objects are added to the main report object.

Page breaks can still be inserted if needed — but remember, each object added to the report automatically starts on a new page.

To add a page break to your report, use:


```bash
1. report.add(Rephorm.PageBreak())
``` 

Alternatively, you could instantiate page break as an object, at the beginning of the script:

```bash
1. page_break = Rephorm.PageBreak()
``` 

Reusing it later on, like so:

```bash
1. report.add(page_break)
``` 