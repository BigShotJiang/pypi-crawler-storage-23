# Possible marker symbols
These are all possible marker symbols for markers or lines+markers plots. They can be passed only to ChartSeries object as “marker_symbol” parameter.

![marketplace](assets/symbols.png)

