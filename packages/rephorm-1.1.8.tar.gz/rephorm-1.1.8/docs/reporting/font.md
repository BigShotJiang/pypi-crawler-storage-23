# Font
The fonts currently available in the Rephorm package include:

* Helvetica (Default)
* Times 
* Open Sans (Must be specified with space)
* Courier

For additional fonts, refer to the "Special Parameters" section under “font_loading.”


