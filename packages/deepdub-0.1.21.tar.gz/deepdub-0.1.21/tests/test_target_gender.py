"""
Integration test for target_gender parameter in async_tts.
Tests Hebrew TTS with target gender specification.
"""
import asyncio
import pytest
from deepdub import DeepdubClient

# Test credentials
API_KEY = "dd-2ITgT5gjSvv4QA2JmmIp4Pq4utF0z9jV138a126f"

# Hebrew test text
HEBREW_TEXT = "שלום, זהו טקסט לבדיקה בעברית"  # "Hello, this is a test text in Hebrew"

# Voice prompt ID - you may need to update this with a valid voice prompt ID
VOICE_PROMPT_ID = "5d3dc622-69bd-4c00-9513-05df47dbdea6_authoritative"


@pytest.mark.asyncio
async def test_async_tts_target_gender_male_hebrew():
    """Test async_tts with target_gender='male' and Hebrew text."""
    client = DeepdubClient(api_key=API_KEY)
    
    audio_chunks = []
    async with client.async_connect() as connection:
        async for chunk in connection.async_tts(
            text=HEBREW_TEXT,
            voice_prompt_id=VOICE_PROMPT_ID,
            locale="he-IL",
            target_gender="male"
        ):
            audio_chunks.append(chunk)
    
    # Verify we received audio data
    assert len(audio_chunks) > 0, "Expected to receive audio chunks"
    total_audio = b"".join(audio_chunks)
    assert len(total_audio) > 0, "Expected non-empty audio data"


@pytest.mark.asyncio
async def test_async_tts_target_gender_female_hebrew():
    """Test async_tts with target_gender='female' and Hebrew text."""
    client = DeepdubClient(api_key=API_KEY)
    
    audio_chunks = []
    async with client.async_connect() as connection:
        async for chunk in connection.async_tts(
            text=HEBREW_TEXT,
            voice_prompt_id=VOICE_PROMPT_ID,
            locale="he-IL",
            target_gender="female"
        ):
            audio_chunks.append(chunk)
    
    # Verify we received audio data
    assert len(audio_chunks) > 0, "Expected to receive audio chunks"
    total_audio = b"".join(audio_chunks)
    assert len(total_audio) > 0, "Expected non-empty audio data"


if __name__ == "__main__":
    # Run tests directly
    asyncio.run(test_async_tts_target_gender_male_hebrew())
    print("Male target_gender test passed!")
    
    asyncio.run(test_async_tts_target_gender_female_hebrew())
    print("Female target_gender test passed!")
