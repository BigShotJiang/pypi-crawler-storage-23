"""CLI interface for pymodelserve."""

from pymodelserve.cli.commands import main

__all__ = ["main"]
