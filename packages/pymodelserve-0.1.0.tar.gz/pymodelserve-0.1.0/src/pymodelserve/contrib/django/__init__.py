"""Django integration for pymodelserve."""

default_app_config = "pymodelserve.contrib.django.apps.PyModelServeConfig"
