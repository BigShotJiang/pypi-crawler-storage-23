# ML Model Serving Library - Analysis & Plan

## Library: `pymodelserve`

**Run ML models in isolated subprocess environments with automatic dependency management.**

Define your model once, and the library handles virtual environment creation, dependency installation, and inter-process communication via named pipes. Supports TensorFlow, PyTorch, or any Python ML framework with optional Django integration.

```bash
pip install pymodelserve
```

```python
from pymodelserve import ModelManager

with ModelManager.from_yaml("./models/fruit_classifier/model.yaml") as model:
    result = model.request("classify", {"image_path": "/path/to/image.jpg"})
```

---

## Executive Summary

This document analyzes the ML model serving implementations in **vegemi-app-backend** and **ml_model_base** repositories to plan a reusable Python library for serving ML models with minimal setup, isolated dependencies, and optional Django integration.

---

## 1. Repository Comparison

### 1.1 Core Architecture Similarities

Both repositories share the same fundamental architecture:

| Component | vegemi-app-backend | ml_model_base |
|-----------|-------------------|---------------|
| **IPC Mechanism** | Named pipes (FIFO) | Named pipes (FIFO) |
| **Process Model** | Subprocess per model | Subprocess per model |
| **Venv Isolation** | Per-model venv | Per-model venv |
| **Message Protocol** | JSON over pipes | JSON over pipes |
| **Health Check** | Ping/pong | Ping/pong |
| **Base Classes** | ModelManager + ModelClient | ModelManager + ModelClient |

### 1.2 Key Differences

| Aspect | vegemi-app-backend | ml_model_base |
|--------|-------------------|---------------|
| **Django Integration** | Deep (Wagtail, views, models) | None |
| **Data Labeling** | Full UI + workflow | None |
| **Training Pipeline** | Management commands | None |
| **Clarifai Fallback** | Yes | No |
| **Model Types** | 2 (fruit_model, simple_ic) | 2 (mobilenet, simple_ic) |
| **Class Names** | 22 fruit/veg classes | 21 fruit/veg classes |
| **Image Size** | 256x256 (fruit_model) | 224x224 |
| **Production Status** | In production | Development/testing |
| **Code Maturity** | More robust error handling | Cleaner, minimal |

### 1.3 File-by-File Comparison

#### Core Files (Nearly Identical)

| File | vegemi LOC | ml_model_base LOC | Similarity |
|------|------------|-------------------|------------|
| `model_manager.py` | ~350 | 341 | ~95% same logic |
| `model_client.py` | ~160 | 152 | ~95% same logic |

**Key differences in vegemi's model_manager.py:**
- Additional logging configuration
- Slightly different error messages
- Same IPC mechanism

#### Model Implementations

| Model | vegemi | ml_model_base |
|-------|--------|---------------|
| TensorFlow/Keras | `fruit_model/` (256x256, 22 classes) | `model_mobilenet/` (224x224, 21 classes) |
| PyTorch | `simple_ic_model/` | `simple_ic_model/` |

---

## 2. What Works Well (Keep)

### 2.1 Named Pipe IPC Pattern
- **Pros**: No network overhead, clean separation, no stdout pollution
- **Implementation**: Temp directory with `pipe_in` and `pipe_out` FIFOs
- **Recommendation**: Keep as primary IPC mechanism

### 2.2 Isolated Virtual Environments
- **Pros**: Dependency isolation, framework flexibility (TF vs PyTorch)
- **Implementation**: Auto-create venv, install from `requirements.txt`
- **Recommendation**: Keep, add caching/reuse optimizations

### 2.3 Handler-Based Message Dispatch
- **Pattern**: `handle_{message_type}()` methods
- **Pros**: Extensible, clean separation
- **Recommendation**: Keep, add decorator-based registration option

### 2.4 Health Check Protocol
- **Pattern**: Ping/pong on startup
- **Pros**: Verifies bidirectional communication
- **Recommendation**: Keep, add periodic health checks option

---

## 3. What Needs Improvement

### 3.1 Configuration
**Current State**: Hard-coded paths, model-specific managers
**Improvement**: Declarative configuration

```python
# Current (requires subclassing)
class FruitModelManager(ModelManager):
    def __init__(self):
        super().__init__(Path(__file__).parent)

# Proposed (configuration-based)
manager = ModelManager.from_config({
    "name": "fruit_classifier",
    "model_dir": "./models/fruit_model",
    "python_version": "3.11",
    "handlers": ["classify", "batch_classify"]
})
```

### 3.2 Model Discovery
**Current State**: Manual manager class per model
**Improvement**: Auto-discovery from directory structure

```
models/
├── fruit_classifier/
│   ├── model.yaml          # Configuration
│   ├── model.py            # Client implementation
│   ├── requirements.txt    # Dependencies
│   └── weights/            # Model files
```

### 3.3 Error Recovery
**Current State**: Process crash requires manual restart
**Improvement**: Automatic restart with backoff

### 3.4 Django Integration
**Current State**: Tightly coupled in vegemi
**Improvement**: Optional Django app as separate package

---

## 4. Proposed Library Architecture

### 4.1 Library Name: `pymodelserve`

**Chosen name**: `pymodelserve` (available on PyPI)

The name clearly conveys "Python model serving". Alternative names considered: `modelserving` (conflicts with `model-serving`), `isolateml`, `modelproc`, `pipedml`.

### 4.2 Package Structure

```
pymodelserve/
├── pyproject.toml
├── README.md
├── src/
│   └── pymodelserve/
│       ├── __init__.py
│       ├── core/
│       │   ├── __init__.py
│       │   ├── manager.py          # ModelManager base class
│       │   ├── client.py           # ModelClient base class
│       │   ├── ipc.py              # IPC abstraction (pipes, sockets)
│       │   └── venv.py             # Virtual environment management
│       ├── config/
│       │   ├── __init__.py
│       │   ├── schema.py           # Pydantic config models
│       │   └── loader.py           # YAML/TOML config loading
│       ├── discovery/
│       │   ├── __init__.py
│       │   └── finder.py           # Auto-discover models
│       ├── health/
│       │   ├── __init__.py
│       │   └── checker.py          # Health monitoring
│       ├── cli/
│       │   ├── __init__.py
│       │   └── commands.py         # CLI interface (entry point: `pml`)
│       └── contrib/
│           └── django/
│               ├── __init__.py
│               ├── apps.py         # Django app config
│               ├── views.py        # Generic API views
│               ├── management/
│               │   └── commands/
│               │       └── serve_models.py
│               └── settings.py     # Django settings integration
├── tests/
└── examples/
    ├── simple_classifier/
    ├── django_integration/
    └── multi_model/
```

### 4.3 Core API Design

#### Model Configuration (model.yaml)

```yaml
name: fruit_classifier
version: "1.0.0"
python: ">=3.11"

# Model client entry point
client:
  module: model
  class: FruitClassifierClient

# Dependencies
requirements: requirements.txt

# Handlers exposed by the model
handlers:
  - name: classify
    input:
      image_path: string
    output:
      class: string
      confidence: float
  - name: batch_classify
    input:
      image_paths: list[string]
    output:
      results: list[object]

# Health check configuration
health:
  interval: 30  # seconds
  timeout: 5    # seconds

# Resource limits (optional)
resources:
  memory_limit: 4G
  cpu_limit: 2
```

#### Python API

```python
from pymodelserve import ModelManager, ModelClient, handler

# === MANAGER SIDE (Parent Process) ===

# Option 1: Configuration-based
manager = ModelManager.from_yaml("./models/fruit_classifier/model.yaml")
manager.start()
result = manager.request("classify", {"image_path": "/path/to/image.jpg"})
manager.stop()

# Option 2: Context manager
with ModelManager.from_yaml("./models/fruit_classifier/model.yaml") as manager:
    result = manager.request("classify", {"image_path": "/path/to/image.jpg"})

# Option 3: Auto-discovery
from pymodelserve import discover_models

models = discover_models("./models/")
for name, manager in models.items():
    print(f"Found model: {name}")

# Option 4: Registry pattern
from pymodelserve import ModelRegistry

registry = ModelRegistry()
registry.register("fruit", "./models/fruit_classifier/")
registry.register("sentiment", "./models/sentiment/")
registry.start_all()

result = registry.get("fruit").request("classify", {"image_path": "..."})


# === CLIENT SIDE (Model Process) ===

class FruitClassifierClient(ModelClient):
    def __init__(self):
        super().__init__()
        self.model = self.load_model()

    def load_model(self):
        # Load your TensorFlow/PyTorch model
        import tensorflow as tf
        return tf.keras.models.load_model("weights/model.keras")

    @handler("classify")
    def classify(self, image_path: str) -> dict:
        image = self.preprocess(image_path)
        predictions = self.model.predict(image)
        return {
            "class": self.class_names[predictions.argmax()],
            "confidence": float(predictions.max())
        }

    @handler("batch_classify")
    def batch_classify(self, image_paths: list) -> dict:
        results = [self.classify(p) for p in image_paths]
        return {"results": results}

# Entry point
if __name__ == "__main__":
    FruitClassifierClient().run()
```

#### Django Integration

```python
# settings.py
INSTALLED_APPS = [
    ...
    'pymodelserve.contrib.django',
]

MLSERVE = {
    "models_dir": BASE_DIR / "ml_models",
    "auto_start": True,
    "health_check_interval": 30,
}

# views.py
from pymodelserve.contrib.django.views import ModelAPIView

class ClassifyImageView(ModelAPIView):
    model_name = "fruit_classifier"
    handler = "classify"

    def get_handler_input(self, request):
        # Save uploaded file and return path
        image = request.FILES["image"]
        path = save_uploaded_file(image)
        return {"image_path": str(path)}

# urls.py
urlpatterns = [
    path("api/classify/", ClassifyImageView.as_view()),
]

# Or use the generic endpoint
from pymodelserve.contrib.django.views import GenericModelView

urlpatterns = [
    path("api/models/<str:model_name>/<str:handler>/", GenericModelView.as_view()),
]
```

#### CLI Interface

The CLI command is `pml` (short for pymodelserve):

```bash
# Serve a single model
pml serve ./models/fruit_classifier/

# Serve all models in directory
pml serve ./models/ --all

# List discovered models
pml list ./models/

# Check model health
pml health ./models/fruit_classifier/

# Create new model scaffold
pml init my_new_model --framework tensorflow

# Run model tests
pml test ./models/fruit_classifier/
```

---

## 5. Implementation Plan

### Phase 1: Core Library (Week 1-2)

1. **Extract and refactor core classes**
   - Port `ModelManager` from vegemi (more robust)
   - Port `ModelClient` from vegemi
   - Add type hints throughout
   - Add comprehensive docstrings

2. **Implement configuration system**
   - Pydantic models for config validation
   - YAML/TOML loader
   - Environment variable overrides

3. **Implement IPC abstraction**
   - Named pipes (current, default)
   - Unix socket option (future)
   - Abstract interface for extensibility

4. **Implement venv management**
   - Create/reuse venvs
   - Install dependencies
   - Version checking

### Phase 2: Discovery & Registry (Week 2-3)

1. **Model discovery**
   - Scan directories for model.yaml
   - Validate configurations
   - Report errors clearly

2. **Model registry**
   - Register multiple models
   - Start/stop individual models
   - Batch operations

3. **Health monitoring**
   - Periodic health checks
   - Automatic restart on failure
   - Metrics collection (optional)

### Phase 3: CLI & Tooling (Week 3)

1. **CLI commands** (`pml` entry point)
   - `pml serve`, `pml list`, `pml health`, `pml init`, `pml test`
   - Rich terminal output
   - Configuration overrides

2. **Scaffolding**
   - Generate model template
   - Framework-specific templates (TF, PyTorch)

### Phase 4: Django Integration (Week 4)

1. **Django app**
   - Settings integration
   - Management commands
   - Generic views

2. **Wagtail integration** (optional)
   - Admin hooks
   - Snippet registration

### Phase 5: Testing & Documentation (Week 4-5)

1. **Test suite**
   - Unit tests for all components
   - Integration tests with real models
   - Performance benchmarks

2. **Documentation**
   - README with quickstart
   - Full API documentation
   - Example projects

---

## 6. Migration Path

### From vegemi-app-backend

```python
# Before (current vegemi)
from model_serving.services import FruitModelClient
result = FruitModelClient.get_classification(image_path)

# After (with pymodelserve)
from pymodelserve import ModelRegistry

registry = ModelRegistry.from_settings()  # Uses Django settings
result = registry.get("fruit_classifier").request("classify", {"image_path": image_path})

# Or with backward-compatible wrapper
from pymodelserve.contrib.django import get_model
result = get_model("fruit_classifier").classify(image_path)
```

### From ml_model_base

```python
# Before (current ml_model_base)
from models.model_mobilenet.ic_model_manager import ImageClassificationManager
manager = ImageClassificationManager()
manager.start()
result = manager.serve_request({"image_path": path})

# After (with pymodelserve)
from pymodelserve import ModelManager
manager = ModelManager.from_yaml("./models/model_mobilenet/model.yaml")
manager.start()
result = manager.request("classify", {"image_path": path})
```

---

## 7. Technical Decisions

### 7.1 IPC: Named Pipes vs Unix Sockets

| Aspect | Named Pipes | Unix Sockets |
|--------|-------------|--------------|
| **Simplicity** | Simpler | More complex |
| **Bidirectional** | Needs 2 pipes | Single socket |
| **Cross-platform** | Good (POSIX) | Good (POSIX) |
| **Performance** | Excellent | Excellent |
| **Connection handling** | Simple | Connection management needed |

**Decision**: Keep named pipes as default, add Unix socket as option.

### 7.2 Configuration Format

| Format | Pros | Cons |
|--------|------|------|
| **YAML** | Human-readable, widely used | Indentation sensitive |
| **TOML** | Python-native (pyproject.toml) | Less common for ML configs |
| **JSON** | Universal | No comments, verbose |
| **Python** | Full flexibility | Security concerns |

**Decision**: YAML as primary, support TOML and Python dict.

### 7.3 Dependency Management

| Approach | Pros | Cons |
|----------|------|------|
| **venv + pip** | Standard, reliable | Slower |
| **uv** | Fast | Newer, less tested |
| **conda** | ML ecosystem | Heavy, complex |
| **Docker** | Full isolation | Overhead |

**Decision**: venv + pip as default, uv as option, Docker for advanced use.

---

## 8. Open Questions

1. **Should the library support Windows?**
   - Named pipes work differently on Windows
   - Recommendation: POSIX-first, Windows support later

2. **Should we support GPU resource management?**
   - CUDA_VISIBLE_DEVICES, memory limits
   - Recommendation: Yes, as optional configuration

3. **Should we support model versioning?**
   - Multiple versions of same model
   - Recommendation: Yes, in Phase 2

4. **Should we support distributed deployment?**
   - Models on different machines
   - Recommendation: Out of scope for v1, design for extensibility

5. **Package name availability?**
   - ✅ Confirmed: `pymodelserve` is available on PyPI

---

## 9. Success Criteria

### For v1.0 Release

- [ ] Can serve a TensorFlow model with 3 lines of code
- [ ] Can serve a PyTorch model with 3 lines of code
- [ ] Automatic venv creation and dependency installation
- [ ] Health monitoring and automatic restart
- [ ] Django integration with minimal configuration
- [ ] CLI for common operations
- [ ] 90%+ test coverage
- [ ] Documentation with examples
- [ ] Published to PyPI

### Performance Targets

- Model startup: < 10 seconds (excluding venv creation)
- Request latency overhead: < 5ms (excluding model inference)
- Memory overhead: < 50MB per model process

---

## 10. Appendix: Code Samples from Both Repos

### vegemi-app-backend ModelManager (key excerpt)

```python
# djangoroot/model_serving/ml_models/model_manager.py
class ModelManager:
    def __init__(self, model_dir: Path):
        self.model_dir = model_dir
        self.model_process = None
        self.pipe_in_path = None
        self.pipe_out_path = None
        self.pipe_in = None
        self.pipe_out = None
        self.temp_dir = None

    def setup_environment(self):
        venv_dir = self.model_dir / "model_venv"
        if not venv_dir.exists():
            venv.create(venv_dir, with_pip=True)
            pip_path = venv_dir / "bin" / "pip"
            requirements = self.model_dir / "requirements.txt"
            subprocess.run([str(pip_path), "install", "-r", str(requirements)])
```

### ml_model_base ModelClient (key excerpt)

```python
# models/model_client.py
class ModelClient:
    def process(self):
        while True:
            line = self.pipe_in.readline()
            if not line:
                break
            request = json.loads(line)
            message = request.get("message")
            handler = getattr(self, f"handle_{message}", None)
            if handler:
                response = handler(request.get("data", {}))
            else:
                response = {"error": f"Unknown message: {message}"}
            self.pipe_out.write(json.dumps(response) + "\n")
            self.pipe_out.flush()
```

---

## 11. Next Steps

1. **Review this document** with stakeholders
2. **Finalize library name** and check PyPI availability
3. **Create repository** structure
4. **Begin Phase 1** implementation
5. **Set up CI/CD** for testing and publishing

---

*Document created: 2026-02-04*
*Based on analysis of vegemi-app-backend and ml_model_base repositories*