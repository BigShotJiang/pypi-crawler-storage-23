# Migration Guide: vegemi-app-backend to pymodelserve

This guide walks through migrating your ML model serving code from vegemi-app-backend's custom implementation to the `pymodelserve` library.

## Overview

vegemi-app-backend uses a custom `ModelManager` and `ModelClient` implementation for serving ML models in isolated subprocesses. `pymodelserve` extracts this pattern into a reusable library with additional features like configuration-based setup, auto-discovery, and health monitoring.

## Key Differences

| Aspect | vegemi-app-backend | pymodelserve |
|--------|-------------------|--------------|
| Configuration | Hard-coded in Python | YAML-based `model.yaml` |
| Manager setup | Subclass `ModelManager` | Use `ModelManager.from_yaml()` |
| Handler registration | `handle_*` methods only | `@handler` decorator + `handle_*` |
| Model discovery | Manual | Auto-discovery from directories |
| Health checks | Manual ping | Built-in `HealthChecker` |
| Django integration | Tight coupling | Optional `contrib.django` app |

## Step-by-Step Migration

### 1. Install pymodelserve

```bash
poetry add pymodelserve

# Or with Django support
poetry add pymodelserve[django]
```

### 2. Create model.yaml Configuration

**Before (vegemi-app-backend):**
```python
# djangoroot/model_serving/ml_models/fruit_model/fruit_model_manager.py
class FruitModelManager(ModelManager):
    def __init__(self):
        super().__init__(Path(__file__).parent)
```

**After (pymodelserve):**
Create `model.yaml` in your model directory:

```yaml
# ml_models/fruit_model/model.yaml
name: fruit_classifier
version: "1.0.0"
python: ">=3.11"

client:
  module: model_client  # Your existing client module
  class: FruitModelClient

requirements: requirements.txt

handlers:
  - name: classify
    input:
      image_path: string
    output:
      class_name: string
      confidence: float
      all_predictions: object

health:
  interval: 30
  timeout: 5
  max_failures: 3

resources:
  gpu_ids: [0]  # Optional: CUDA_VISIBLE_DEVICES
```

### 3. Update ModelClient Implementation

**Before (vegemi-app-backend):**
```python
# fruit_model/model_client.py
from model_serving.ml_models.model_client import ModelClient

class FruitModelClient(ModelClient):
    def __init__(self):
        super().__init__()
        self.model = None
        self.class_names = [...]

    def handle_classify(self, data):
        image_path = data.get("image_path")
        # ... classification logic ...
        return {
            "class_name": predicted_class,
            "confidence": confidence,
            "all_predictions": predictions_dict
        }

if __name__ == "__main__":
    client = FruitModelClient()
    client.process()
```

**After (pymodelserve):**
```python
# fruit_model/model_client.py
from pymodelserve import ModelClient, handler

class FruitModelClient(ModelClient):
    def setup(self):
        """Called once after IPC established, before processing requests."""
        import tensorflow as tf
        self.model = tf.keras.models.load_model(
            Path(__file__).parent / "weights" / "fruit_model.keras"
        )
        self.class_names = [...]

    @handler("classify")
    def classify(self, image_path: str) -> dict:
        """Classify an image.

        Args:
            image_path: Path to image file.

        Returns:
            Classification result with class_name, confidence, all_predictions.
        """
        # ... classification logic (same as before) ...
        return {
            "class_name": predicted_class,
            "confidence": confidence,
            "all_predictions": predictions_dict
        }

    # You can keep handle_* methods - they still work!
    def handle_batch_classify(self, image_paths: list) -> dict:
        results = [self.classify(p) for p in image_paths]
        return {"results": results}

if __name__ == "__main__":
    FruitModelClient().run()
```

**Key changes:**
- Import from `pymodelserve` instead of local module
- Use `setup()` instead of `__init__` for model loading
- Use `@handler` decorator (optional, `handle_*` still works)
- Handler receives kwargs directly, not a `data` dict
- Call `.run()` instead of `.process()`

### 4. Update Django Service Layer

**Before (vegemi-app-backend):**
```python
# model_serving/services.py
from model_serving.ml_models.fruit_model.fruit_model_manager import FruitModelManager

_fruit_model_manager = None

def get_fruit_model_manager():
    global _fruit_model_manager
    if _fruit_model_manager is None:
        _fruit_model_manager = FruitModelManager()
        _fruit_model_manager.start()
    return _fruit_model_manager

class FruitModelClient:
    @staticmethod
    def get_classification(image_path):
        manager = get_fruit_model_manager()
        result = manager.serve_request({
            "message": "classify",
            "data": {"image_path": str(image_path)}
        })
        return result
```

**After (pymodelserve):**

Option A: Using Django integration:

```python
# settings.py
INSTALLED_APPS = [
    ...
    'pymodelserve.contrib.django',
]

MLSERVE = {
    "models_dir": BASE_DIR / "ml_models",
    "auto_start": True,
    "health_check_interval": 30,
}
```

```python
# model_serving/services.py
from pymodelserve.contrib.django import get_model

class FruitModelClient:
    @staticmethod
    def get_classification(image_path):
        model = get_model("fruit_classifier")
        return model.request("classify", {"image_path": str(image_path)})
```

Option B: Manual registry (more control):

```python
# model_serving/services.py
from pathlib import Path
from pymodelserve import ModelRegistry

_registry = None

def get_registry():
    global _registry
    if _registry is None:
        _registry = ModelRegistry()
        _registry.register_from_dir(Path(__file__).parent / "ml_models")
        _registry.start_all()
    return _registry

class FruitModelClient:
    @staticmethod
    def get_classification(image_path):
        registry = get_registry()
        return registry.get("fruit_classifier").request(
            "classify",
            {"image_path": str(image_path)}
        )
```

### 5. Update Django Views

**Before (vegemi-app-backend):**
```python
# views.py
from model_serving.services import FruitModelClient

class ClassifyImageView(View):
    def post(self, request):
        image = request.FILES.get("image")
        path = save_uploaded_file(image)
        result = FruitModelClient.get_classification(path)
        return JsonResponse(result)
```

**After (pymodelserve):**

Option A: Keep your existing views (just update the service import):
```python
# views.py - minimal changes
from model_serving.services import FruitModelClient  # Updated service

class ClassifyImageView(View):
    def post(self, request):
        image = request.FILES.get("image")
        path = save_uploaded_file(image)
        result = FruitModelClient.get_classification(path)
        return JsonResponse(result)
```

Option B: Use pymodelserve's generic views:
```python
# views.py
from pymodelserve.contrib.django.views import ModelAPIView

class ClassifyImageView(ModelAPIView):
    model_name = "fruit_classifier"
    handler = "classify"

    def get_handler_input(self, request):
        image = request.FILES.get("image")
        path = save_uploaded_file(image)
        return {"image_path": str(path)}
```

Option C: Use fully generic endpoint:
```python
# urls.py
from pymodelserve.contrib.django.views import GenericModelView

urlpatterns = [
    path("api/models/<str:model_name>/<str:handler>/",
         GenericModelView.as_view()),
]
```

### 6. Update Management Commands

**Before (vegemi-app-backend):**
```python
# management/commands/start_model_servers.py
class Command(BaseCommand):
    def handle(self, *args, **options):
        from model_serving.services import get_fruit_model_manager
        manager = get_fruit_model_manager()
        # ...
```

**After (pymodelserve):**
```bash
# Use the built-in command
python manage.py serve_models

# Or with specific models
python manage.py serve_models --model fruit_classifier
```

### 7. Add Health Monitoring (New Feature!)

**After (pymodelserve):**
```python
# In your Django app startup or management command
from pymodelserve.contrib.django import get_registry
from pymodelserve.health import HealthChecker

registry = get_registry()
checker = HealthChecker(
    registry=registry,
    interval=30,
    max_failures=3,
    auto_restart=True,
    on_failure=lambda name, status: logger.warning(f"Model {name} unhealthy"),
    on_restart=lambda name: logger.info(f"Model {name} restarted"),
)
checker.start()
```

## Directory Structure Migration

**Before:**
```
djangoroot/
├── model_serving/
│   ├── ml_models/
│   │   ├── model_client.py      # Base class
│   │   ├── model_manager.py     # Base class
│   │   └── fruit_model/
│   │       ├── fruit_model_manager.py
│   │       ├── model_client.py
│   │       ├── requirements.txt
│   │       └── weights/
│   └── services.py
```

**After:**
```
djangoroot/
├── ml_models/
│   └── fruit_classifier/
│       ├── model.yaml           # NEW: Configuration
│       ├── model_client.py      # Updated imports
│       ├── requirements.txt     # Same
│       └── weights/             # Same
├── model_serving/
│   └── services.py              # Simplified
└── settings.py                  # Add MLSERVE config
```

## Backward Compatibility Wrapper

If you want to minimize changes to existing code, create a compatibility wrapper:

```python
# model_serving/compat.py
"""Backward compatibility layer for vegemi-app-backend."""

from pymodelserve.contrib.django import get_model

class LegacyModelClient:
    """Drop-in replacement for old FruitModelClient."""

    def __init__(self, model_name: str):
        self.model_name = model_name

    def get_classification(self, image_path):
        """Match the old API signature."""
        model = get_model(self.model_name)
        return model.request("classify", {"image_path": str(image_path)})


# Usage - change one import:
# Before: from model_serving.services import FruitModelClient
# After:  from model_serving.compat import LegacyModelClient as FruitModelClient
FruitModelClient = LegacyModelClient("fruit_classifier")
```

## Testing the Migration

1. **Test model client directly:**
```bash
pml test ./ml_models/fruit_classifier/
```

2. **Test via Python:**
```python
from pymodelserve import ModelManager

with ModelManager.from_yaml("./ml_models/fruit_classifier/model.yaml") as model:
    result = model.request("classify", {"image_path": "/path/to/test.jpg"})
    print(result)
```

3. **Test Django integration:**
```bash
python manage.py serve_models --model fruit_classifier
# In another terminal:
curl -X POST http://localhost:8000/api/classify/ -F "image=@test.jpg"
```

## Checklist

- [ ] Install pymodelserve: `pip install pymodelserve[django]`
- [ ] Create `model.yaml` for each model
- [ ] Update ModelClient imports and entry point
- [ ] Update Django settings with `MLSERVE` config
- [ ] Update service layer to use registry/get_model
- [ ] Test each model with `pml test`
- [ ] Run Django tests
- [ ] Remove old `model_manager.py` base class
- [ ] Remove old `model_client.py` base class
- [ ] Update deployment scripts

## Troubleshooting

### Model fails to start
```bash
# Check logs
pml test ./ml_models/fruit_classifier/ --verbose

# Verify venv creation
ls ./ml_models/fruit_classifier/model_venv/
```

### Import errors in model client
Make sure `pymodelserve` is in the model's `requirements.txt`:
```
pymodelserve>=0.1.0
tensorflow>=2.15
# ... other deps
```

### Handler not found
Verify handler is registered:
```python
# In model_client.py, check:
@handler("classify")  # Name must match request
def classify(self, image_path: str):  # Params must match request data keys
    ...
```

### IPC timeout
Increase timeout in model.yaml:
```yaml
health:
  timeout: 30  # Increase from default 5
```

## Benefits After Migration

1. **Simpler code** - No custom base classes to maintain
2. **Configuration-driven** - Change behavior without code changes
3. **Auto-discovery** - Add models by creating directories
4. **Health monitoring** - Automatic restart on failures
5. **CLI tools** - `pml serve`, `pml list`, `pml init`
6. **Better testing** - `pml test` validates models
7. **Type hints** - Full typing for IDE support
8. **Documentation** - Handlers documented in model.yaml
