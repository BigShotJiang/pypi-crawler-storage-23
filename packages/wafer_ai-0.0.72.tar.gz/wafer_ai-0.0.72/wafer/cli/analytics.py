"""PostHog analytics for Wafer CLI.
Tracks CLI command usage and user activity for product analytics.
Mirrors the analytics implementation in apps/wevin-extension/src/services/analytics.ts.
Usage:
    from .analytics import track_command, identify_user, shutdown_analytics

    track_command("evaluate", {"subcommand": "kernelbench", "outcome": "success"})

    identify_user("user-id", "user@example.com")
"""
import atexit
import base64
import importlib.metadata
import json
import platform
import uuid
from pathlib import Path
from typing import Any

# PostHog configuration - same as wevin-extension
POSTHOG_API_KEY = "phc_9eDjkY72ud9o4l1mA1Gr1dnRT1yx71rP3XY9z66teFh"
POSTHOG_HOST = "https://us.i.posthog.com"
# Anonymous ID storage
ANONYMOUS_ID_FILE = Path.home() / ".wafer" / ".analytics_id"
# Global state
_posthog_client: Any = None
_distinct_id: str | None = None
_initialized: bool = False


def _normalize_command_name(command: str) -> str:
    """Normalize command name for analytics classification."""
    return (command or "unknown").strip().lower()


def _is_agent_command(command: str) -> bool:
    """Return True when command should be classified as agent-related."""
    return _normalize_command_name(command) == "agent"


def _failure_scope(command: str) -> str:
    """Classify failure scope for PostHog alert filtering."""
    return "agent" if _is_agent_command(command) else "general"


def _sanitize_error_message(message: str | None, max_length: int = 500) -> str | None:
    """Trim noisy failure payloads while preserving enough debugging context."""
    if not message:
        return None
    sanitized = " ".join(message.strip().split())
    if not sanitized:
        return None
    if len(sanitized) <= max_length:
        return sanitized
    return f"{sanitized[:max_length]}..."


def _get_anonymous_id() -> str:
    """Get or create anonymous ID for users who aren't logged in."""
    if ANONYMOUS_ID_FILE.exists():
        return ANONYMOUS_ID_FILE.read_text().strip()
    # Generate new anonymous ID
    anonymous_id = f"anon_{uuid.uuid4().hex}"
    ANONYMOUS_ID_FILE.parent.mkdir(parents=True, exist_ok=True)
    ANONYMOUS_ID_FILE.write_text(anonymous_id)
    return anonymous_id


def _get_user_id_from_credentials() -> tuple[str | None, str | None]:
    """Get user ID and email from stored credentials.

    Decodes the JWT locally (no network call) to keep CLI startup fast.

    Returns:
        Tuple of (user_id, email), both may be None if not logged in.
    """
    import json as _json

    from .auth import load_credentials

    creds = load_credentials()
    if not creds:
        return None, None
    try:
        payload_b64 = creds.access_token.split(".")[1]
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload = _json.loads(base64.urlsafe_b64decode(padded))
        user_id = payload.get("sub")
        email = payload.get("email") or creds.email
        return user_id, email
    except (IndexError, base64.binascii.Error, json.JSONDecodeError, UnicodeDecodeError):
        return None, creds.email


def _is_analytics_enabled() -> bool:
    """Check if analytics is enabled via preferences.
    Returns True by default, respects user preference in config.
    """
    from .global_config import get_preferences
    try:
        prefs = get_preferences()
        return getattr(prefs, "analytics_enabled", True)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return True


def init_analytics() -> bool:
    """Initialize PostHog client.
    Returns:
        True if initialization succeeded, False otherwise.
    """
    global _posthog_client, _distinct_id, _initialized
    if _initialized:
        return _posthog_client is not None
    _initialized = True
    if not _is_analytics_enabled():
        return False
    try:
        from posthog import Posthog
        from posthog.consumer import Consumer as _PH_Consumer

        _orig_init = _PH_Consumer.__init__

        def _daemon_init(self, *a, **kw):
            _orig_init(self, *a, **kw)
            self.daemon = True

        _PH_Consumer.__init__ = _daemon_init  # type: ignore[method-assign]

        _original_atexit = atexit.register

        def _noop_atexit(func, *a, **kw):
            pass

        atexit.register = _noop_atexit  # type: ignore[assignment]
        try:
            _posthog_client = Posthog(
                project_api_key=POSTHOG_API_KEY,
                host=POSTHOG_HOST,
                flush_at=1,
                flush_interval=0.5,
                debug=False,
            )
        finally:
            atexit.register = _original_atexit
            _PH_Consumer.__init__ = _orig_init  # type: ignore[method-assign]

        user_id, email = _get_user_id_from_credentials()
        if user_id:
            _distinct_id = user_id
        else:
            _distinct_id = _get_anonymous_id()
        return True
    except ImportError:
        return False
    except (ConnectionError, ValueError, OSError):
        return False


def shutdown_analytics() -> None:
    """No-op: consumer is a daemon thread — events flush in the background
    and the thread dies automatically when the process exits.  This avoids
    blocking the CLI for 1-2 s waiting on PostHog network I/O."""
    pass


def identify_user(user_id: str, email: str | None = None) -> None:
    """Identify a user after login.
    Args:
        user_id: Supabase user ID
        email: User's email address
    """
    global _distinct_id
    if not init_analytics():
        return
    if _posthog_client is None:
        return
    _distinct_id = user_id
    try:
        properties: dict[str, Any] = {"auth_provider": "github"}
        if email:
            properties["email"] = email
        _posthog_client.identify(
            distinct_id=user_id,
            properties=properties,
        )
    except (ConnectionError, TimeoutError, ValueError, OSError):
        pass


def reset_user_identity() -> None:
    """Reset user identity after logout."""
    global _distinct_id
    _distinct_id = _get_anonymous_id()


def get_distinct_id() -> str:
    """Get current distinct ID for tracking."""
    global _distinct_id
    if _distinct_id is None:
        user_id, _ = _get_user_id_from_credentials()
        _distinct_id = user_id or _get_anonymous_id()
    return _distinct_id


def _get_cli_version() -> str:
    """Get CLI version from package metadata."""
    try:
        from importlib.metadata import version
        return version("wafer-ai")
    except (importlib.metadata.PackageNotFoundError,):
        return "unknown"


def _get_base_properties() -> dict[str, Any]:
    """Get base properties included with all events."""
    return {
        "platform": "cli",
        "tool_id": "cli",
        "cli_version": _get_cli_version(),
        "os": platform.system().lower(),
        "os_version": platform.release(),
        "python_version": platform.python_version(),
    }


def track_event(event_name: str, properties: dict[str, Any] | None = None) -> None:
    """Track a generic event.
    Args:
        event_name: Name of the event to track
        properties: Additional properties to include
    """
    if not init_analytics():
        return
    if _posthog_client is None:
        return
    try:
        event_properties = _get_base_properties()
        if properties:
            event_properties.update(properties)
        _posthog_client.capture(
            distinct_id=get_distinct_id(),
            event=event_name,
            properties=event_properties,
        )
    except (ConnectionError, TimeoutError, ValueError, OSError):
        pass


def track_command(
    command: str,
    subcommand: str | None = None,
    outcome: str = "success",
    duration_ms: int | None = None,
    properties: dict[str, Any] | None = None,
) -> None:
    """Track a CLI command execution.
    This event counts towards DAU in the internal dashboard.
    Args:
        command: The main command name (e.g., "evaluate", "agent")
        subcommand: Optional subcommand (e.g., "kernelbench")
        outcome: "success" or "error"
        duration_ms: Command execution time in milliseconds
        properties: Additional properties to include
    """
    event_properties: dict[str, Any] = {
        "command": command,
        "outcome": outcome,
        "is_agent_command": _is_agent_command(command),
        "failure_scope": _failure_scope(command),
    }
    if subcommand:
        event_properties["subcommand"] = subcommand
    if duration_ms is not None:
        event_properties["duration_ms"] = duration_ms
    if properties:
        event_properties.update(properties)
    track_event("cli_command_executed", event_properties)


def track_command_failure(
    command: str,
    subcommand: str | None = None,
    *,
    error_type: str | None = None,
    error_message: str | None = None,
    exit_code: int | None = None,
    duration_ms: int | None = None,
    properties: dict[str, Any] | None = None,
) -> None:
    """Track dedicated failure event for alerting and triage."""
    event_properties: dict[str, Any] = {
        "command": command,
        "outcome": "failure",
        "is_agent_command": _is_agent_command(command),
        "failure_scope": _failure_scope(command),
    }

    if subcommand:
        event_properties["subcommand"] = subcommand

    if error_type:
        event_properties["error_type"] = error_type

    sanitized_message = _sanitize_error_message(error_message)
    if sanitized_message:
        event_properties["error_message"] = sanitized_message

    if exit_code is not None:
        event_properties["exit_code"] = exit_code

    if duration_ms is not None:
        event_properties["duration_ms"] = duration_ms

    if properties:
        event_properties.update(properties)

    track_event("cli_command_failed", event_properties)


def track_login(user_id: str, email: str | None = None) -> None:
    """Track user login event.
    Args:
        user_id: Supabase user ID
        email: User's email address
    """
    # First identify the user
    identify_user(user_id, email)
    # Then track the login event
    track_event("cli_user_signed_in", {"user_id": user_id})


def track_logout() -> None:
    """Track user logout event."""
    track_event("cli_user_signed_out")
    reset_user_identity()
