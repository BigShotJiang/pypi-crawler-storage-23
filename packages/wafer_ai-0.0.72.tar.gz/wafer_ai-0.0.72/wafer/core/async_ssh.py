"""Async SSH client for remote GPU execution.
Uses asyncssh with trio-asyncio bridge for compatibility with trio.
"""
import asyncio
import asyncio.unix_events
import logging
import os
import threading
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass, field as dataclass_field
from pathlib import Path

import asyncssh
import trio
import trio_asyncio

logger = logging.getLogger(__name__)

_UPLOAD_EXCLUDES: frozenset[str] = frozenset([
    "__pycache__", "*.pyc", ".git", ".ruff_cache",
    ".pytest_cache", ".venv", "*.egg-info", "uv.lock",
])

# ---------------------------------------------------------------------------
# Persistent asyncio event loop for SyncSSHClient
# ---------------------------------------------------------------------------
# asyncssh connections bind their internal futures to the asyncio event loop
# that was active when they were created. Each `trio.run()` / `open_loop()`
# creates a DIFFERENT asyncio loop, so cached connections break with
# "Future attached to a different loop".
#
# Solution: run ONE persistent asyncio event loop in a background thread.
# SyncSSHClient dispatches all asyncssh operations to that loop via
# asyncio.run_coroutine_threadsafe(), keeping every connection on the same loop.
#
# IMPORTANT: trio_asyncio patches asyncio.new_event_loop() to return a
# SyncTrioEventLoop that lacks full asyncio API (no create_task, etc.).
# We bypass this by using the real _UnixSelectorEventLoop directly.
# ---------------------------------------------------------------------------
_RealEventLoop = asyncio.unix_events._UnixSelectorEventLoop


@dataclass
class _BackgroundLoopState:
    """Encapsulates the persistent asyncio event loop for SyncSSHClient."""
    loop: asyncio.AbstractEventLoop | None = None
    started: threading.Event = dataclass_field(default_factory=threading.Event)
    lock: threading.Lock = dataclass_field(default_factory=threading.Lock)
    thread: threading.Thread | None = None

    def _run_loop(self) -> None:
        """Run a persistent asyncio event loop in a background thread."""
        self.loop = _RealEventLoop()
        asyncio.set_event_loop(self.loop)
        self.started.set()
        self.loop.run_forever()

    def ensure_loop(self) -> asyncio.AbstractEventLoop:
        """Start the background asyncio loop (once) and return it."""
        if self.started.is_set():
            assert self.loop is not None
            return self.loop
        with self.lock:
            if self.started.is_set():
                assert self.loop is not None
                return self.loop
            self.thread = threading.Thread(target=self._run_loop, daemon=True, name="ssh-asyncio-loop")
            self.thread.start()
            self.started.wait(timeout=10)
            assert self.loop is not None, "Background asyncio loop failed to start"
        return self.loop


_bg_state = _BackgroundLoopState()


def _ensure_bg_loop() -> asyncio.AbstractEventLoop:
    """Start the background asyncio loop (once) and return it."""
    return _bg_state.ensure_loop()


def _truncate(s: str, max_len: int = 500) -> str:
    """Truncate string for logging, preserving start and end."""
    if len(s) <= max_len:
        return s
    half = (max_len - 5) // 2
    return f"{s[:half]}[...]{s[-half:]}"


def _trio_wrap(coro_func):
    """Wrap asyncio coroutine for trio-asyncio."""
    return trio_asyncio.aio_as_trio(coro_func)


class AsyncSSHError(Exception):
    """Base exception for async SSH operations."""
    pass


class ConnectionError(AsyncSSHError):
    """SSH connection failed."""
    pass


class TransferError(AsyncSSHError):
    """File transfer failed."""
    pass


@dataclass(frozen=True)
class ExecResult:
    """Result of command execution."""
    stdout: str
    stderr: str
    exit_code: int
    duration_ms: float = 0.0
    command: str = ""

    @property
    def success(self) -> bool:
        return self.exit_code == 0


@dataclass(frozen=True)
class CopyResult:
    """Result of file transfer operation.
    Includes debug_info for wide event logging - captures command details
    and raw output for debugging upload failures.
    """
    success: bool
    files_copied: int
    total_bytes: int
    duration_seconds: float
    error_message: str | None = None
    debug_info: dict | None = None  # rsync_cmd, stdout, stderr for debugging


class AsyncSSHClient:
    """Async SSH client for remote GPU execution.
    Uses asyncssh for true async I/O, bridged to trio via trio-asyncio.
    Example:
        async with AsyncSSHClient("user@host:22", "~/.ssh/id_ed25519") as client:
            result = await client.exec("nvidia-smi")
            print(result.stdout)
            async for line in client.exec_stream("python train.py"):
                print(line)
    """
    def __init__(
        self,
        ssh_target: str,
        ssh_key: str,
        timeout: int = 30,
    ) -> None:
        """Initialize async SSH client.
        Args:
            ssh_target: SSH target as "user@host:port" or "user@host" (default port 22)
            ssh_key: Path to SSH private key
            timeout: Connection timeout in seconds
        """
        from wafer.core.ssh_utils import parse_ssh_target

        # Normalize user@host to user@host:22 for parser
        if "@" in ssh_target and ":" not in ssh_target.split("@", 1)[1]:
            ssh_target = f"{ssh_target}:22"
        parsed = parse_ssh_target(ssh_target)
        self.user = parsed.user
        self.host = parsed.host
        self.port = parsed.port
        self.ssh_key = os.path.expanduser(ssh_key)
        self.timeout = timeout
        self._conn: asyncssh.SSHClientConnection | None = None

    async def _establish_connection(self) -> asyncssh.SSHClientConnection:
        """Establish SSH connection with retry logic."""
        max_attempts = 3
        delay = 2
        backoff = 2
        start_time = time.perf_counter()
        for attempt in range(max_attempts):
            attempt_start = time.perf_counter()
            try:
                conn = await _trio_wrap(asyncssh.connect)(
                    host=self.host,
                    port=self.port,
                    username=self.user,
                    client_keys=[self.ssh_key],
                    connect_timeout=self.timeout,
                    keepalive_interval=30,
                    known_hosts=None,
                )
                total_duration_ms = (time.perf_counter() - start_time) * 1000
                # Wide event for successful connection
                logger.info(
                    "ssh_connect",
                    extra={
                        "event": "ssh_connect",
                        "host": self.host,
                        "port": self.port,
                        "user": self.user,
                        "success": True,
                        "attempts": attempt + 1,
                        "duration_ms": round(total_duration_ms, 2),
                    },
                )
                return conn
            except Exception as e:
                attempt_duration_ms = (time.perf_counter() - attempt_start) * 1000
                if attempt < max_attempts - 1:
                    wait_time = delay * (backoff**attempt)
                    logger.info(
                        "ssh_connect_retry",
                        extra={
                            "event": "ssh_connect_retry",
                            "host": self.host,
                            "port": self.port,
                            "user": self.user,
                            "attempt": attempt + 1,
                            "max_attempts": max_attempts,
                            "attempt_duration_ms": round(attempt_duration_ms, 2),
                            "retry_delay_s": wait_time,
                            "error": str(e),
                            "error_type": type(e).__name__,
                        },
                    )
                    await trio.sleep(wait_time)
                else:
                    total_duration_ms = (time.perf_counter() - start_time) * 1000
                    # Wide event for failed connection
                    logger.error(
                        "ssh_connect_failed",
                        extra={
                            "event": "ssh_connect_failed",
                            "host": self.host,
                            "port": self.port,
                            "user": self.user,
                            "success": False,
                            "attempts": max_attempts,
                            "duration_ms": round(total_duration_ms, 2),
                            "error": str(e),
                            "error_type": type(e).__name__,
                        },
                    )
                    raise ConnectionError(
                        f"Failed to connect to {self.user}@{self.host}:{self.port} "
                        f"after {max_attempts} attempts: {e}"
                    ) from e
        raise ConnectionError(f"Failed to connect to {self.user}@{self.host}:{self.port}")

    async def _get_connection(self) -> asyncssh.SSHClientConnection:
        """Get or create SSH connection."""
        if self._conn is None:
            self._conn = await self._establish_connection()
            return self._conn
        if self._conn._transport.is_closing():
            logger.debug("SSH connection inactive, reconnecting...")
            self._conn = await self._establish_connection()
        return self._conn

    async def exec(
        self,
        command: str,
        working_dir: str | None = None,
    ) -> ExecResult:
        """Execute command on remote.
        Args:
            command: Command to execute
            working_dir: Optional working directory
        Returns:
            ExecResult with stdout, stderr, exit_code, duration_ms, command
        """
        conn = await self._get_connection()
        full_command = command
        if working_dir:
            full_command = f"cd {working_dir} && {command}"
        start_time = time.perf_counter()
        result = await _trio_wrap(conn.run)(full_command, check=False)
        duration_ms = (time.perf_counter() - start_time) * 1000
        stdout = result.stdout or ""
        stderr = result.stderr or ""
        exit_code = result.exit_status or 0
        # Wide event for SSH command execution
        logger.info(
            "ssh_exec",
            extra={
                "event": "ssh_exec",
                "host": self.host,
                "port": self.port,
                "user": self.user,
                "command": _truncate(full_command, 200),
                "working_dir": working_dir,
                "exit_code": exit_code,
                "duration_ms": round(duration_ms, 2),
                "stdout_len": len(stdout),
                "stderr_len": len(stderr),
                "stdout_preview": _truncate(stdout, 200) if stdout else None,
                "stderr_preview": _truncate(stderr, 200) if stderr else None,
            },
        )
        return ExecResult(
            stdout=stdout,
            stderr=stderr,
            exit_code=exit_code,
            duration_ms=duration_ms,
            command=full_command,
        )

    async def exec_stream(
        self,
        command: str,
        working_dir: str | None = None,
        allocate_pty: bool = True,
    ) -> AsyncIterator[str]:
        """Execute command and stream output line-by-line.
        Args:
            command: Command to execute
            working_dir: Optional working directory
            allocate_pty: If False, don't allocate a PTY (useful when the remote
                process must NOT see a tty, e.g. to suppress TUI rendering)
        Yields:
            Lines of output as they're produced
        """
        conn = await self._get_connection()
        full_command = command
        if working_dir:
            full_command = f"cd {working_dir} && {command}"
        # Wide event for stream start
        logger.info(
            "ssh_exec_stream_start",
            extra={
                "event": "ssh_exec_stream_start",
                "host": self.host,
                "port": self.port,
                "user": self.user,
                "command": _truncate(full_command, 200),
                "working_dir": working_dir,
            },
        )
        start_time = time.perf_counter()
        lines_yielded = 0
        pty_kwargs = {"term_type": "ansi"} if allocate_pty else {}
        process = await _trio_wrap(conn.create_process)(full_command, **pty_kwargs)
        try:
            while True:
                try:
                    line = await _trio_wrap(process.stdout.readline)()
                    if not line:
                        break
                    lines_yielded += 1
                    yield line.rstrip("\r\n")
                except EOFError:
                    break
        finally:
            process.close()
            duration_ms = (time.perf_counter() - start_time) * 1000
            # Wide event for stream completion
            logger.info(
                "ssh_exec_stream_end",
                extra={
                    "event": "ssh_exec_stream_end",
                    "host": self.host,
                    "port": self.port,
                    "user": self.user,
                    "command": _truncate(full_command, 200),
                    "duration_ms": round(duration_ms, 2),
                    "lines_yielded": lines_yielded,
                },
            )

    async def expand_path(self, path: str) -> str:
        """Expand ~ and env vars in path on remote."""
        result = await self.exec(f"echo {path}")
        return result.stdout.strip()

    async def upload_content(self, content: str, remote_path: str) -> None:
        """Upload string content to a remote file via SFTP."""
        conn = await self._get_connection()
        async with await _trio_wrap(conn.start_sftp_client)() as sftp:
            remote_dir = str(Path(remote_path).parent)
            if remote_dir and remote_dir != ".":
                try:
                    await _trio_wrap(sftp.makedirs)(remote_dir, exist_ok=True)
                except (OSError,):
                    pass
            import io
            data = content.encode("utf-8")
            await _trio_wrap(sftp.putfo)(io.BytesIO(data), remote_path)

    async def upload_bytes(self, data: bytes, remote_path: str) -> None:
        """Upload raw bytes to a remote file via SFTP."""
        import io
        conn = await self._get_connection()
        async with await _trio_wrap(conn.start_sftp_client)() as sftp:
            remote_dir = str(Path(remote_path).parent)
            if remote_dir and remote_dir != ".":
                try:
                    await _trio_wrap(sftp.makedirs)(remote_dir, exist_ok=True)
                except (OSError,):
                    pass
            await _trio_wrap(sftp.putfo)(io.BytesIO(data), remote_path)

    async def download_bytes(self, remote_path: str) -> bytes:
        """Download a remote file as raw bytes via SFTP."""
        import io
        conn = await self._get_connection()
        async with await _trio_wrap(conn.start_sftp_client)() as sftp:
            buf = io.BytesIO()
            await _trio_wrap(sftp.getfo)(remote_path, buf)
            return buf.getvalue()

    async def remove_file(self, remote_path: str) -> None:
        """Remove a remote file via SFTP. Ignores FileNotFoundError."""
        conn = await self._get_connection()
        async with await _trio_wrap(conn.start_sftp_client)() as sftp:
            try:
                await _trio_wrap(sftp.remove)(remote_path)
            except (FileNotFoundError, asyncssh.SFTPNoSuchFile):
                pass

    async def stat_file(self, remote_path: str) -> asyncssh.SFTPAttrs:
        """Stat a remote file via SFTP."""
        conn = await self._get_connection()
        async with await _trio_wrap(conn.start_sftp_client)() as sftp:
            return await _trio_wrap(sftp.stat)(remote_path)

    async def upload_files(
        self,
        local_path: str,
        remote_path: str,
        recursive: bool = False,
        exclude: list[str] | None = None,
        use_sftp: bool = False,
    ) -> CopyResult:
        """Upload files from local to remote.
        By default uses rsync for efficient delta transfers on directories.
        Set use_sftp=True to use SFTP through the existing asyncssh connection,
        which avoids spawning a new SSH subprocess (useful when rsync times out
        due to rate limiting or connection issues).
        Args:
            local_path: Local file or directory path
            remote_path: Remote destination path
            recursive: Upload directories recursively
            exclude: Patterns to exclude (default: __pycache__, *.pyc, .git, .venv, etc.)
            use_sftp: If True, use SFTP instead of rsync for directories.
                      SFTP is slower but uses the existing SSH connection.
        Returns:
            CopyResult with transfer statistics
        """
        import time
        start_time = time.time()
        local_path_obj = trio.Path(local_path)
        if not await local_path_obj.exists():
            raise TransferError(f"Local path not found: {local_path}")
        is_directory = await local_path_obj.is_dir()
        if is_directory and not recursive:
            raise TransferError(f"{local_path} is a directory. Use recursive=True")
        try:
            if is_directory:
                if use_sftp:
                    return await self._sftp_upload_directory(
                        local_path, remote_path, exclude, start_time
                    )
                else:
                    return await self._rsync_upload(local_path, remote_path, exclude, start_time)
            else:
                # For single files, always use SFTP (simpler)
                return await self._sftp_upload_file(local_path, remote_path, start_time)
        except Exception as e:
            duration = time.time() - start_time
            return CopyResult(
                success=False,
                files_copied=0,
                total_bytes=0,
                duration_seconds=duration,
                error_message=str(e),
            )

    async def _rsync_upload(
        self,
        local_path: str,
        remote_path: str,
        exclude: list[str] | None,
        start_time: float,
    ) -> CopyResult:
        """Upload directory using rsync over SSH."""
        import time
        if exclude is None:
            exclude = list(_UPLOAD_EXCLUDES)
        from wafer.core.ssh_utils import ssh_mux_opts

        ssh_opts = (
            f"ssh -i {self.ssh_key} -p {self.port} "
            f"-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
            f"-o ConnectTimeout=30 {ssh_mux_opts()}"
        )
        rsync_args = [
            "rsync",
            "-avz",  # archive mode + verbose + compression
            "--delete",  # remove files on remote that don't exist locally
            "--timeout=120",  # rsync-level timeout
            "-e",
            ssh_opts,
        ]
        for pattern in exclude:
            rsync_args.extend(["--exclude", pattern])
        rsync_args.append(f"{local_path}/")
        rsync_args.append(f"{self.user}@{self.host}:{remote_path}/")
        debug_info = {
            "rsync_cmd": " ".join(rsync_args),
            "local_path": local_path,
            "remote_path": remote_path,
            "remote_target": f"{self.user}@{self.host}:{self.port}",
            "exclude_patterns": exclude,
        }
        try:
            result = await trio.run_process(
                rsync_args,
                capture_stdout=True,
                capture_stderr=True,
                check=False,  # Don't raise on non-zero exit, we handle it below
            )
            duration = time.time() - start_time
            stdout = result.stdout.decode() if result.stdout else ""
            stderr = result.stderr.decode() if result.stderr else ""
            debug_info["stdout"] = stdout
            debug_info["stderr"] = stderr
            debug_info["returncode"] = result.returncode
            if result.returncode != 0:
                return CopyResult(
                    success=False,
                    files_copied=0,
                    total_bytes=0,
                    duration_seconds=duration,
                    error_message=f"rsync failed (exit {result.returncode}): {stderr}",
                    debug_info=debug_info,
                )
            # Count non-empty lines that look like file transfers
            lines = [
                line
                for line in stdout.strip().split("\n")
                if line and not line.startswith((" ", "sent", "total", "receiving", "building"))
            ]
            files_copied = len(lines)
            return CopyResult(
                success=True,
                files_copied=files_copied,
                total_bytes=0,  # rsync doesn't easily report this
                duration_seconds=duration,
                debug_info=debug_info,
            )
        except FileNotFoundError as e:
            raise TransferError("rsync not found. Install rsync to use directory upload.") from e

    async def _sftp_upload_file(
        self,
        local_path: str,
        remote_path: str,
        start_time: float,
    ) -> CopyResult:
        """Upload single file using SFTP."""
        import time
        conn = await self._get_connection()
        sftp = await _trio_wrap(conn.start_sftp_client)()
        try:
            # Ensure remote directory exists
            remote_dir = os.path.dirname(remote_path)
            if remote_dir and remote_dir != ".":
                await self._create_remote_dir(sftp, remote_dir)
            file_stat = await trio.Path(local_path).stat()
            await _trio_wrap(sftp.put)(local_path, remote_path)
            duration = time.time() - start_time
            return CopyResult(
                success=True,
                files_copied=1,
                total_bytes=file_stat.st_size,
                duration_seconds=duration,
            )
        finally:
            sftp.exit()

    async def _sftp_upload_directory(
        self,
        local_path: str,
        remote_path: str,
        exclude: list[str] | None,
        start_time: float,
    ) -> CopyResult:
        """Upload directory recursively using SFTP through existing asyncssh connection.
        This avoids spawning a new SSH subprocess (like rsync does), which can fail
        when the remote has rate limiting or connection restrictions.
        """
        import fnmatch
        import time
        if exclude is None:
            exclude = list(_UPLOAD_EXCLUDES)
        conn = await self._get_connection()
        sftp = await _trio_wrap(conn.start_sftp_client)()
        files_copied = 0
        total_bytes = 0
        errors: list[str] = []

        def should_exclude(path: trio.Path | Path, patterns: list[str]) -> bool:
            """Check if path matches any exclusion pattern."""
            name = path.name
            for pattern in patterns:
                if fnmatch.fnmatch(name, pattern):
                    return True
                # Also check full relative path for patterns like "dir/file"
                if fnmatch.fnmatch(str(path), pattern):
                    return True
            return False
        try:
            # Ensure remote base directory exists
            await self._create_remote_dir(sftp, remote_path)
            local_base = trio.Path(local_path)

            files_to_upload: list[tuple[trio.Path, str]] = []

            async def collect_files(local_dir: trio.Path, remote_dir: str) -> None:
                """Recursively collect files to upload."""
                entries = await local_dir.iterdir()
                for entry in entries:
                    if should_exclude(entry, exclude):
                        continue
                    rel_path = entry.relative_to(local_base)
                    remote_file_path = f"{remote_path}/{rel_path}"
                    if await entry.is_dir():
                        await collect_files(entry, remote_file_path)
                    else:
                        files_to_upload.append((entry, remote_file_path))
            await collect_files(local_base, remote_path)

            # Upload files with concurrency limit

            async def upload_one(local_file: trio.Path, remote_file: str) -> tuple[int, str | None]:
                """Upload a single file. Returns (bytes, error_or_none)."""
                try:
                    # Ensure parent directory exists
                    remote_dir = os.path.dirname(remote_file)
                    await self._create_remote_dir(sftp, remote_dir)
                    stat = await local_file.stat()
                    await _trio_wrap(sftp.put)(str(local_file), remote_file)
                    return stat.st_size, None
                except Exception as e:
                    return 0, f"{local_file}: {e}"
            # asyncssh handles multiplexing, but too many concurrent ops can still cause issues
            semaphore = trio.Semaphore(10)

            async def upload_with_limit(
                local_file: trio.Path, remote_file: str
            ) -> tuple[int, str | None]:
                async with semaphore:
                    return await upload_one(local_file, remote_file)
            async with trio.open_nursery() as nursery:
                results: list[tuple[int, str | None]] = []

                async def upload_and_collect(local_file: trio.Path, remote_file: str) -> None:
                    result = await upload_with_limit(local_file, remote_file)
                    results.append(result)
                for local_file, remote_file in files_to_upload:
                    nursery.start_soon(upload_and_collect, local_file, remote_file)
            # Aggregate results
            for bytes_uploaded, error in results:
                if error:
                    errors.append(error)
                else:
                    files_copied += 1
                    total_bytes += bytes_uploaded
            duration = time.time() - start_time
            debug_info = {
                "method": "sftp",
                "local_path": local_path,
                "remote_path": remote_path,
                "remote_target": f"{self.user}@{self.host}:{self.port}",
                "exclude_patterns": exclude,
                "files_attempted": len(files_to_upload),
                "files_copied": files_copied,
                "errors": errors[:10] if errors else None,  # Limit error list
            }
            if errors:
                return CopyResult(
                    success=False,
                    files_copied=files_copied,
                    total_bytes=total_bytes,
                    duration_seconds=duration,
                    error_message=f"Failed to upload {len(errors)} files: {errors[0]}",
                    debug_info=debug_info,
                )
            return CopyResult(
                success=True,
                files_copied=files_copied,
                total_bytes=total_bytes,
                duration_seconds=duration,
                debug_info=debug_info,
            )
        finally:
            sftp.exit()

    async def _create_remote_dir(self, sftp, remote_dir: str) -> None:
        """Create remote directory recursively."""
        try:
            await _trio_wrap(sftp.stat)(remote_dir)
        except (FileNotFoundError, asyncssh.SFTPNoSuchFile):
            parent_dir = os.path.dirname(remote_dir)
            if parent_dir and parent_dir != remote_dir:
                await self._create_remote_dir(sftp, parent_dir)
            try:
                await _trio_wrap(sftp.mkdir)(remote_dir)
            except (OSError, asyncssh.SFTPError):
                pass  # Directory might have been created by another process

    async def download_files(
        self,
        remote_path: str,
        local_path: str,
        recursive: bool = False,
    ) -> CopyResult:
        """Download files from remote to local.
        Args:
            remote_path: Remote file or directory path
            local_path: Local destination path
            recursive: Download directories recursively
        Returns:
            CopyResult with transfer statistics
        """
        import time
        start_time = time.time()
        try:
            conn = await self._get_connection()
            result = await self.exec(f"test -e {remote_path}")
            if result.exit_code != 0:
                raise TransferError(f"Remote path not found: {remote_path}")
            result = await self.exec(f"test -d {remote_path}")
            is_directory = result.exit_code == 0
            if is_directory and not recursive:
                raise TransferError(f"{remote_path} is a directory. Use recursive=True")
            sftp = await _trio_wrap(conn.start_sftp_client)()
            try:
                files_copied = 0
                total_bytes = 0
                if is_directory:
                    files_copied, total_bytes = await self._download_directory(
                        sftp, conn, remote_path, local_path
                    )
                else:
                    total_bytes = await self._download_file(sftp, remote_path, local_path)
                    files_copied = 1
                duration = time.time() - start_time
                return CopyResult(
                    success=True,
                    files_copied=files_copied,
                    total_bytes=total_bytes,
                    duration_seconds=duration,
                )
            finally:
                sftp.exit()
        except (ConnectionError, TransferError):
            raise
        except Exception as e:
            duration = time.time() - start_time
            return CopyResult(
                success=False,
                files_copied=0,
                total_bytes=0,
                duration_seconds=duration,
                error_message=str(e),
            )

    async def _download_file(self, sftp, remote_path: str, local_path: str) -> int:
        """Download single file and return bytes transferred."""
        local_dir = Path(local_path).parent
        local_dir.mkdir(parents=True, exist_ok=True)
        attrs = await _trio_wrap(sftp.stat)(remote_path)
        file_size = attrs.size
        await _trio_wrap(sftp.get)(remote_path, local_path)
        return file_size

    async def _download_directory(
        self, sftp, conn, remote_path: str, local_path: str
    ) -> tuple[int, int]:
        """Download directory recursively using parallel downloads."""
        result = await _trio_wrap(conn.run)(f"find {remote_path} -type f", check=True)
        file_list = [f.strip() for f in result.stdout.split("\n") if f.strip()]
        files_copied = 0
        total_bytes = 0

        async def download_one_file(remote_file: str) -> None:
            nonlocal files_copied, total_bytes
            rel_path = Path(remote_file).relative_to(remote_path)
            local_file = str(Path(local_path) / rel_path)
            try:
                file_bytes = await self._download_file(sftp, remote_file, local_file)
                files_copied += 1
                total_bytes += file_bytes
            except Exception as e:
                logger.warning(f"Failed to download {rel_path}: {e}")
        # Download files in parallel
        async with trio.open_nursery() as nursery:
            for remote_file in file_list:
                nursery.start_soon(download_one_file, remote_file)
        return files_copied, total_bytes

    async def close(self) -> None:
        """Close SSH connection."""
        if self._conn:
            self._conn.close()
            await _trio_wrap(self._conn.wait_closed)()
            self._conn = None

    async def __aenter__(self) -> "AsyncSSHClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()


class SyncSSHClient:
    """Synchronous SSH client using asyncssh on a persistent asyncio event loop.
    All asyncssh operations run on a shared background asyncio thread so that
    connections can be safely cached and reused (asyncssh futures are bound to
    the loop they were created on).
    """

    def __init__(
        self,
        ssh_connection: str,
        ssh_key_path: str,
        timeout: int = 30,
    ) -> None:
        from wafer.core.ssh_utils import parse_ssh_target
        if "@" in ssh_connection and ":" not in ssh_connection.split("@", 1)[1]:
            ssh_connection = f"{ssh_connection}:22"
        parsed = parse_ssh_target(ssh_connection)
        self.host = parsed.host
        self.port = parsed.port
        self.user = parsed.user
        self.ssh_key = os.path.expanduser(ssh_key_path)
        self.timeout = timeout
        self._conn: asyncssh.SSHClientConnection | None = None
        # Keep _async_client for ssh_pool liveness check (reads _conn._transport)
        self._async_client = type("_FakeAsyncClient", (), {"_conn": None})()

    def _run_coro(self, coro):
        """Submit an asyncio coroutine to the persistent background loop and block."""
        loop = _ensure_bg_loop()
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()

    def _ensure_connected(self) -> asyncssh.SSHClientConnection:
        if self._conn is not None and not self._conn._transport.is_closing():
            return self._conn

        async def _connect():
            max_attempts = 3
            delay = 2
            backoff = 2
            start_time = time.perf_counter()
            for attempt in range(max_attempts):
                attempt_start = time.perf_counter()
                try:
                    conn = await asyncssh.connect(
                        host=self.host,
                        port=self.port,
                        username=self.user,
                        client_keys=[self.ssh_key],
                        connect_timeout=self.timeout,
                        keepalive_interval=30,
                        known_hosts=None,
                    )
                    total_ms = (time.perf_counter() - start_time) * 1000
                    logger.info("ssh_connect", extra={
                        "event": "ssh_connect", "host": self.host, "port": self.port,
                        "user": self.user, "success": True, "attempts": attempt + 1,
                        "duration_ms": round(total_ms, 2),
                    })
                    return conn
                except Exception as e:
                    attempt_ms = (time.perf_counter() - attempt_start) * 1000
                    if attempt < max_attempts - 1:
                        wait_time = delay * (backoff ** attempt)
                        logger.info("ssh_connect_retry", extra={
                            "event": "ssh_connect_retry", "host": self.host,
                            "port": self.port, "user": self.user,
                            "attempt": attempt + 1, "max_attempts": max_attempts,
                            "attempt_duration_ms": round(attempt_ms, 2),
                            "retry_delay_s": wait_time, "error": str(e),
                            "error_type": type(e).__name__,
                        })
                        await asyncio.sleep(wait_time)
                    else:
                        total_ms = (time.perf_counter() - start_time) * 1000
                        logger.error("ssh_connect_failed", extra={
                            "event": "ssh_connect_failed", "host": self.host,
                            "port": self.port, "user": self.user,
                            "success": False, "attempts": max_attempts,
                            "duration_ms": round(total_ms, 2), "error": str(e),
                            "error_type": type(e).__name__,
                        })
                        raise ConnectionError(
                            f"Failed to connect to {self.user}@{self.host}:{self.port} "
                            f"after {max_attempts} attempts: {e}"
                        ) from e
            raise ConnectionError(f"Failed to connect to {self.user}@{self.host}:{self.port}")

        self._conn = self._run_coro(_connect())
        self._async_client._conn = self._conn
        return self._conn

    def exec(self, command: str, working_dir: str | None = None) -> ExecResult:
        """Execute command on remote."""
        conn = self._ensure_connected()
        full_command = f"cd {working_dir} && {command}" if working_dir else command

        async def _exec():
            start_time = time.perf_counter()
            result = await conn.run(full_command, check=False)
            duration_ms = (time.perf_counter() - start_time) * 1000
            stdout = result.stdout or ""
            stderr = result.stderr or ""
            exit_code = result.exit_status or 0
            logger.info("ssh_exec", extra={
                "event": "ssh_exec", "host": self.host, "port": self.port,
                "user": self.user, "command": _truncate(full_command, 200),
                "working_dir": working_dir, "exit_code": exit_code,
                "duration_ms": round(duration_ms, 2),
                "stdout_len": len(stdout), "stderr_len": len(stderr),
                "stdout_preview": _truncate(stdout, 200) if stdout else None,
                "stderr_preview": _truncate(stderr, 200) if stderr else None,
            })
            return ExecResult(
                stdout=stdout, stderr=stderr, exit_code=exit_code,
                duration_ms=duration_ms, command=full_command,
            )

        return self._run_coro(_exec())

    def exec_stream(self, command: str, working_dir: str | None = None):
        """Collect all output lines from a command."""
        result = self.exec(command, working_dir)
        return result.stdout.splitlines()

    def expand_path(self, path: str) -> str:
        """Expand ~ and env vars in path on remote."""
        result = self.exec(f"echo {path}")
        return result.stdout.strip()

    def upload_content(self, content: str, remote_path: str) -> None:
        """Upload string content to a remote file."""
        conn = self._ensure_connected()

        async def _upload():
            async with conn.start_sftp_client() as sftp:
                remote_dir = str(Path(remote_path).parent)
                if remote_dir and remote_dir != ".":
                    try:
                        await sftp.makedirs(remote_dir, exist_ok=True)
                    except (OSError,):
                        pass
                import io
                await sftp.putfo(io.BytesIO(content.encode("utf-8")), remote_path)

        self._run_coro(_upload())

    def upload_bytes(self, data: bytes, remote_path: str) -> None:
        """Upload raw bytes to a remote file via SFTP."""
        conn = self._ensure_connected()

        async def _upload():
            import io
            async with conn.start_sftp_client() as sftp:
                remote_dir = str(Path(remote_path).parent)
                if remote_dir and remote_dir != ".":
                    try:
                        await sftp.makedirs(remote_dir, exist_ok=True)
                    except (OSError,):
                        pass
                await sftp.putfo(io.BytesIO(data), remote_path)

        self._run_coro(_upload())

    def download_bytes(self, remote_path: str) -> bytes:
        """Download a remote file as raw bytes via SFTP."""
        conn = self._ensure_connected()

        async def _download():
            import io
            async with conn.start_sftp_client() as sftp:
                buf = io.BytesIO()
                await sftp.getfo(remote_path, buf)
                return buf.getvalue()

        return self._run_coro(_download())

    def remove_file(self, remote_path: str) -> None:
        """Remove a remote file via SFTP. Ignores FileNotFoundError."""
        conn = self._ensure_connected()

        async def _remove():
            async with conn.start_sftp_client() as sftp:
                try:
                    await sftp.remove(remote_path)
                except (FileNotFoundError, asyncssh.SFTPNoSuchFile):
                    pass

        self._run_coro(_remove())

    def stat_file(self, remote_path: str):
        """Stat a remote file via SFTP."""
        conn = self._ensure_connected()

        async def _stat():
            async with conn.start_sftp_client() as sftp:
                return await sftp.stat(remote_path)

        return self._run_coro(_stat())

    def upload_files(
        self,
        local_path: str,
        remote_path: str,
        recursive: bool = False,
        exclude: list[str] | None = None,
        respect_gitignore: bool = True,
    ) -> CopyResult:
        """Upload files via rsync over SSH, with SFTP fallback when rsync is unavailable."""
        import shutil
        if respect_gitignore:
            gitignore_excludes = _load_gitignore_excludes(local_path)
            exclude = (list(exclude) + gitignore_excludes) if exclude else gitignore_excludes
        if exclude is None:
            exclude = list(_UPLOAD_EXCLUDES)
        if not os.path.isdir(local_path) and not os.path.isfile(local_path):
            raise TransferError(f"Local path not found: {local_path}")
        is_dir = os.path.isdir(local_path)
        if is_dir and not recursive:
            raise TransferError(f"{local_path} is a directory. Use recursive=True")

        if is_dir:
            if shutil.which("rsync") is None:
                return self._sftp_upload_dir(local_path, remote_path, exclude)
            return self._rsync_upload(local_path, remote_path, exclude)
        else:
            start = time.time()
            conn = self._ensure_connected()

            async def _sftp_single():
                async with conn.start_sftp_client() as sftp:
                    remote_dir = os.path.dirname(remote_path)
                    if remote_dir and remote_dir != ".":
                        try:
                            await sftp.makedirs(remote_dir, exist_ok=True)
                        except (OSError,):
                            pass
                    await sftp.put(local_path, remote_path)

            self._run_coro(_sftp_single())
            duration = time.time() - start
            return CopyResult(success=True, files_copied=1, total_bytes=os.path.getsize(local_path),
                              duration_seconds=duration)

    def _rsync_upload(
        self,
        local_path: str,
        remote_path: str,
        exclude: list[str],
    ) -> CopyResult:
        """Upload directory via rsync. Retries once on auth failure after clearing stale mux sockets."""
        import subprocess as sp

        from wafer.core.ssh_utils import clear_mux_sockets, ssh_mux_opts

        def _build_args(use_mux: bool) -> list[str]:
            mux = ssh_mux_opts() if use_mux else ""
            ssh_opts = (
                f"ssh -i {self.ssh_key} -p {self.port} "
                f"-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
                f"-o ConnectTimeout=30 {mux}"
            )
            args = ["rsync", "-avz", "--delete", "--timeout=120", "-e", ssh_opts]
            for pat in exclude:
                args.extend(["--exclude", pat])
            args.append(f"{local_path}/")
            args.append(f"{self.user}@{self.host}:{remote_path}/")
            return args

        start = time.time()
        result = sp.run(_build_args(use_mux=True), capture_output=True, text=True)

        if result.returncode != 0 and "Permission denied" in result.stderr:
            cleared = clear_mux_sockets(user=self.user, host=self.host)
            if cleared == 0:
                clear_mux_sockets()
            result = sp.run(_build_args(use_mux=False), capture_output=True, text=True)

        duration = time.time() - start
        if result.returncode != 0:
            return CopyResult(
                success=False, files_copied=0, total_bytes=0,
                duration_seconds=duration,
                error_message=(
                    f"rsync failed: {result.stderr}\n"
                    f"SSH key: {self.ssh_key}\n"
                    f"Target: {self.user}@{self.host}:{self.port}\n"
                    f"Verify with: ssh -i {self.ssh_key} -p {self.port} {self.user}@{self.host} echo ok"
                ),
            )
        lines = [l for l in result.stdout.strip().split("\n")
                 if l and not l.startswith((" ", "sent", "total", "receiving", "building"))]
        return CopyResult(success=True, files_copied=len(lines), total_bytes=0, duration_seconds=duration)

    def _sftp_upload_dir(
        self,
        local_path: str,
        remote_path: str,
        exclude: list[str],
    ) -> CopyResult:
        """Upload directory recursively via SFTP (fallback when rsync unavailable)."""
        import fnmatch
        start = time.time()
        conn = self._ensure_connected()
        files_copied = 0

        async def _do_upload():
            nonlocal files_copied
            async with conn.start_sftp_client() as sftp:
                try:
                    await sftp.makedirs(remote_path, exist_ok=True)
                except (OSError,):
                    pass
                for root, dirs, files in os.walk(local_path):
                    rel_root = os.path.relpath(root, local_path)
                    skip_dirs = []
                    for d in dirs:
                        if any(fnmatch.fnmatch(d, p) for p in exclude):
                            skip_dirs.append(d)
                    for d in skip_dirs:
                        dirs.remove(d)
                    remote_dir = remote_path if rel_root == "." else f"{remote_path}/{rel_root}"
                    try:
                        await sftp.makedirs(remote_dir, exist_ok=True)
                    except (OSError,):
                        pass
                    for f in files:
                        if any(fnmatch.fnmatch(f, p) for p in exclude):
                            continue
                        local_file = os.path.join(root, f)
                        remote_file = f"{remote_dir}/{f}"
                        await sftp.put(local_file, remote_file)
                        files_copied += 1

        self._run_coro(_do_upload())
        duration = time.time() - start
        return CopyResult(success=True, files_copied=files_copied, total_bytes=0, duration_seconds=duration)

    def download_files(
        self,
        remote_path: str,
        local_path: str,
        recursive: bool = False,
    ) -> CopyResult:
        """Download files via rsync over SSH."""
        import subprocess as sp
        start = time.time()
        from wafer.core.ssh_utils import ssh_mux_opts

        ssh_opts = (
            f"ssh -i {self.ssh_key} -p {self.port} "
            f"-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null "
            f"-o ConnectTimeout=30 {ssh_mux_opts()}"
        )
        args = ["rsync", "-avz", "--timeout=120", "-e", ssh_opts]
        src = f"{self.user}@{self.host}:{remote_path}"
        if recursive:
            src += "/"
            local_path_dir = local_path + "/"
        else:
            local_path_dir = local_path
        args.extend([src, local_path_dir])
        result = sp.run(args, capture_output=True, text=True)
        duration = time.time() - start
        if result.returncode != 0:
            return CopyResult(success=False, files_copied=0, total_bytes=0,
                              duration_seconds=duration, error_message=f"rsync failed: {result.stderr}")
        return CopyResult(success=True, files_copied=1, total_bytes=0, duration_seconds=duration)

    def close(self) -> None:
        """Close SSH connection."""
        if self._conn is not None:
            try:
                self._conn.close()
            except (OSError,):
                pass
            self._conn = None

    def __enter__(self) -> "SyncSSHClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def _load_gitignore_excludes(local_path: str) -> list[str]:
    """Load .gitignore patterns as rsync-compatible exclude patterns."""
    import fnmatch as _fnmatch  # noqa: F811
    gitignore_path = Path(local_path) / ".gitignore"
    defaults = [
        ".git", "__pycache__", "*.pyc", ".venv", "node_modules",
        ".env", "*.egg-info", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ]
    patterns = list(defaults)
    if gitignore_path.exists():
        try:
            with open(gitignore_path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        patterns.append(line)
        except (OSError,):
            pass
    return patterns
