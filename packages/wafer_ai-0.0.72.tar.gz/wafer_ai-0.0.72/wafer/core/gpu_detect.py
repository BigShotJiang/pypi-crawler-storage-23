"""Accelerator detection and torch version selection.
Detects accelerator vendor (NVIDIA/AMD/Trainium/TPU) and driver version, then selects
compatible PyTorch packages.
Usage:
    info = detect_local_accelerator()
    info = await detect_remote_gpu(ssh_client)
    torch_reqs = get_torch_requirements(info)
"""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wafer.core.async_ssh import AsyncSSHClient


@dataclass(frozen=True)
class GPUInfo:
    """Detected accelerator information."""
    vendor: str  # nvidia, amd, trainium, tpu, other
    gpu_name: str  # e.g., "NVIDIA H100", "AMD Instinct MI300X", "AWS Trainium"
    driver_version: str  # CUDA/ROCm/Neuron version
    gpu_count: int = 1


@dataclass(frozen=True)
class TorchRequirements:
    """PyTorch installation requirements for a GPU."""
    packages: tuple[str, ...]  # e.g., ("torch==2.5.1+cu124", "torchvision==0.20.1+cu124")
    index_url: str  # e.g., "https://download.pytorch.org/whl/cu124"


# CUDA version -> PyTorch requirements
# Maps CUDA driver version to compatible torch wheels
CUDA_TORCH_VERSIONS: dict[str, TorchRequirements] = {
    "12.1": TorchRequirements(
        packages=(
            "torch==2.3.1+cu121",
            "torchvision==0.18.1+cu121",
            "torchaudio==2.3.1+cu121",
        ),
        index_url="https://download.pytorch.org/whl/cu121",
    ),
    "12.4": TorchRequirements(
        packages=(
            "torch==2.5.1+cu124",
            "torchvision==0.20.1+cu124",
            "torchaudio==2.5.1+cu124",
        ),
        index_url="https://download.pytorch.org/whl/cu124",
    ),
    "12.6": TorchRequirements(
        packages=(
            "torch==2.5.1+cu124",  # cu124 works with 12.6
            "torchvision==0.20.1+cu124",
            "torchaudio==2.5.1+cu124",
        ),
        index_url="https://download.pytorch.org/whl/cu124",
    ),
    "12.8": TorchRequirements(
        packages=(
            "torch>=2.6.0",
            "torchvision",
            "torchaudio",
        ),
        index_url="https://download.pytorch.org/whl/nightly/cu128",
    ),
    "13.0": TorchRequirements(
        packages=(
            "torch>=2.8.0",
            "torchvision",
            "torchaudio",
        ),
        index_url="https://download.pytorch.org/whl/nightly/cu130",
    ),
}
# ROCm version -> PyTorch requirements
ROCM_TORCH_VERSIONS: dict[str, TorchRequirements] = {
    "6.1": TorchRequirements(
        packages=(
            "torch==2.4.0+rocm6.1",
            "torchvision==0.19.0+rocm6.1",
            "torchaudio==2.4.0+rocm6.1",
        ),
        index_url="https://download.pytorch.org/whl/rocm6.1",
    ),
    "6.2": TorchRequirements(
        packages=(
            "torch==2.5.1+rocm6.2",
            "torchvision==0.20.1+rocm6.2",
            "torchaudio==2.5.1+rocm6.2",
        ),
        index_url="https://download.pytorch.org/whl/rocm6.2",
    ),
    "6.4": TorchRequirements(
        packages=(
            "torch==2.8.0+rocm6.4",
            "torchvision==0.21.0+rocm6.4",
            "torchaudio==2.8.0+rocm6.4",
        ),
        index_url="https://download.pytorch.org/whl/rocm6.4",
    ),
}
# Trainium (AWS Neuron) - torch-neuron
TRAINIUM_TORCH_VERSIONS: dict[str, TorchRequirements] = {
    "2.18": TorchRequirements(
        packages=("torch-neuron", "torchvision", "torchaudio"),
        index_url="https://pip.repos.neuron.amazonaws.com",
    ),
}
DEFAULT_TRAINIUM_VERSION = "2.18"

_NEURON_LS_CMDS = (
    "neuron-ls",
    "/opt/aws/neuron/bin/neuron-ls",
)

# TPU (XLA) - torch_xla
TPU_TORCH_VERSIONS: dict[str, TorchRequirements] = {
    "default": TorchRequirements(
        packages=("torch", "torch_xla"),
        index_url="https://download.pytorch.org/whl/cpu",
    ),
}

# Default fallbacks
DEFAULT_CUDA_VERSION = "12.4"
DEFAULT_ROCM_VERSION = "6.4"


def _parse_nvidia_smi(output: str) -> GPUInfo | None:
    """Parse nvidia-smi output to extract GPU info.
    Expected format from: nvidia-smi --query-gpu=name,driver_version --format=csv,noheader
    Example: "NVIDIA H100 80GB HBM3, 550.54.15"
    """
    lines = [line.strip() for line in output.strip().split("\n") if line.strip()]
    if not lines:
        return None
    first_line = lines[0]
    if "," not in first_line:
        return None
    parts = first_line.split(",")
    if len(parts) < 2:
        return None
    gpu_name = parts[0].strip()
    driver_version = parts[1].strip()
    # Driver 550.x supports CUDA 12.4, 535.x supports CUDA 12.2, etc.
    # We'll use nvidia-smi's reported CUDA version instead
    cuda_version = _get_cuda_version_from_driver(driver_version)
    return GPUInfo(
        vendor="nvidia",
        gpu_name=gpu_name,
        driver_version=cuda_version,
        gpu_count=len(lines),
    )


def _get_cuda_version_from_driver(driver_version: str) -> str:
    """Map NVIDIA driver version to CUDA version.
    This is approximate - nvidia-smi --query also reports CUDA version directly.
    """
    try:
        major = int(driver_version.split(".")[0])
    except (ValueError, IndexError):
        return DEFAULT_CUDA_VERSION
    if major >= 570:
        return "13.0"
    elif major >= 560:
        return "12.8"
    elif major >= 550:
        return "12.4"
    elif major >= 535:
        return "12.2"
    elif major >= 525:
        return "12.1"
    else:
        return "12.1"


def _parse_nvidia_smi_cuda_version(output: str) -> str | None:
    """Parse CUDA version from nvidia-smi output.
    Looks for "CUDA Version: X.Y" in the output.
    """
    match = re.search(r"CUDA Version:\s*(\d+\.\d+)", output)
    if match:
        return match.group(1)
    return None


_GFX_TO_GPU_NAME: dict[str, str] = {
    "gfx942": "AMD Instinct MI300X",
    "gfx941": "AMD Instinct MI300X",
    "gfx940": "AMD Instinct MI300X",
    "gfx950": "AMD Instinct MI350X",
    "gfx90a": "AMD Instinct MI250X",
    "gfx908": "AMD Instinct MI100",
}


def _normalize_rocm_gpu_name(raw: str) -> str:
    """Normalize raw rocm-smi product name to standard GPU model.
    Some hosts return 'GFX Version: \t\tgfx942' instead of 'AMD Instinct MI300X'.
    """
    if not raw:
        return raw
    match = re.search(r"gfx\d{2,3}[a-z]?", raw.lower())
    if match:
        gfx_id = match.group(0)
        return _GFX_TO_GPU_NAME.get(gfx_id, raw)
    return raw


def _parse_rocm_smi(output: str) -> GPUInfo | None:
    """Parse rocm-smi output to extract GPU info.
    Handles: rocm-smi --showproductname (text) and --json.
    Formats: GPU[0]: ..., GPU 0: ..., card0: ..., GFX Version: gfx942
    """
    stripped = output.strip()
    if not stripped:
        return None
    # Try JSON first (rocm-smi --showproductname --json)
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            data = json.loads(stripped)
            if isinstance(data, list):
                device_count = len(data)
                gpu_name = None
                for item in data:
                    if isinstance(item, dict):
                        name = (
                            item.get("Product Name")
                            or item.get("product_name")
                            or item.get("Name")
                            or item.get("name")
                        )
                        if name:
                            gpu_name = _normalize_rocm_gpu_name(str(name))
                            break
                if gpu_name and device_count > 0:
                    return GPUInfo(
                        vendor="amd",
                        gpu_name=gpu_name,
                        driver_version="unknown",
                        gpu_count=device_count,
                    )
            elif isinstance(data, dict):
                cards = data.get("card", {})
                if isinstance(cards, dict):
                    device_count = len(cards)
                elif isinstance(cards, list):
                    device_count = len(cards)
                else:
                    device_count = 1
                gpu_name = None
                for k, v in (cards.items() if isinstance(cards, dict) else enumerate(cards)):
                    if isinstance(v, dict):
                        name = v.get("Product Name") or v.get("product_name") or v.get("Name")
                        if name:
                            gpu_name = _normalize_rocm_gpu_name(str(name))
                            break
                if gpu_name and device_count > 0:
                    return GPUInfo(
                        vendor="amd",
                        gpu_name=gpu_name,
                        driver_version="unknown",
                        gpu_count=device_count,
                    )
        except (json.JSONDecodeError, TypeError, AttributeError) as exc:
            logging.debug("rocm-smi JSON parse failed: %s", exc)
    # Parse text format
    lines = [line.strip() for line in stripped.split("\n") if line.strip()]
    gpu_name = None
    device_ids: set[int] = set()
    for line in lines:
        # Match GPU[0], GPU[1], GPU 0:, GPU 1:, card0:, card1:
        match = re.search(r"(?:GPU\s*\[\s*(\d+)\s*\]|GPU\s+(\d+)|card\s*(\d+))", line, re.IGNORECASE)
        if match:
            idx = next((int(g) for g in match.groups() if g is not None), 0)
            device_ids.add(idx)
            if ":" in line:
                parts = line.split(":", 1)
                if len(parts) > 1:
                    gpu_name = parts[1].strip()
        elif "GPU" in line and ":" in line:
            device_ids.add(len(device_ids))
            parts = line.split(":", 1)
            if len(parts) > 1:
                gpu_name = parts[1].strip()
    gpu_count = len(device_ids) if device_ids else 0
    if not gpu_name:
        for line in lines:
            if "MI300" in line or "MI250" in line or "MI100" in line:
                gpu_name = "AMD Instinct MI300X" if "MI300" in line else "AMD Instinct MI250X" if "MI250" in line else "AMD Instinct MI100"
                gpu_count = max(gpu_count, 1)
                break
    if not gpu_name:
        for line in lines:
            normalized = _normalize_rocm_gpu_name(line)
            if normalized != line:
                gpu_name = normalized
                gpu_count = max(gpu_count, 1)
                break
    if not gpu_name:
        return None
    gpu_name = _normalize_rocm_gpu_name(gpu_name)
    return GPUInfo(
        vendor="amd",
        gpu_name=gpu_name,
        driver_version="unknown",
        gpu_count=max(gpu_count, 1),
    )


def _parse_rocm_version(output: str) -> str | None:
    """Parse ROCm version from /opt/rocm/.info/version or rocm-smi.
    Looks for version strings like "6.4.0" or "6.4.3".
    """
    # Try to find version pattern
    match = re.search(r"(\d+\.\d+)(?:\.\d+)?", output)
    if match:
        return match.group(1)  # Return major.minor only
    return None


def _parse_neuron_ls(output: str) -> GPUInfo | None:
    """Parse neuron-ls output to detect Trainium devices.
    neuron-ls lists Neuron devices (Trn1, Trn2, Trn3). Exit 0 + output = Trainium present.
    Counts devices from table rows (| 0 |, | 1 |, ...) or JSON array length.
    Infers Trainium2/3 from instance-type (trn2*, trn3*).
    """
    if not output.strip():
        return None
    gpu_name = "AWS Trainium"
    for line in output.split("\n"):
        if "instance-type:" in line.lower():
            it = line.split(":", 1)[-1].strip().lower()
            if "trn3" in it:
                gpu_name = "AWS Trainium3"
            elif "trn2" in it:
                gpu_name = "AWS Trainium2"
            elif "trn1" in it:
                gpu_name = "AWS Trainium"
            break
    # Try JSON first (neuron-ls -j) - most reliable
    stripped = output.strip()
    if stripped.startswith("["):
        try:
            devices = json.loads(stripped)
            device_count = len(devices) if isinstance(devices, list) else 1
            return GPUInfo(
                vendor="trainium",
                gpu_name=gpu_name,
                driver_version=DEFAULT_TRAINIUM_VERSION,
                gpu_count=max(device_count, 1),
            )
        except (json.JSONDecodeError, TypeError):
            pass
    # Parse table format: max device ID + 1 (devices are 0..N-1). Handles --show-all-procs.
    lines = [l for l in output.strip().split("\n") if l.strip()]
    max_device_id = -1
    for line in lines:
        if line.startswith("|") and "|" in line[1:]:
            parts = line.split("|")
            if len(parts) >= 2:
                first_cell = parts[1].strip()
                if first_cell.isdigit():
                    max_device_id = max(max_device_id, int(first_cell))
    device_count = max_device_id + 1 if max_device_id >= 0 else 1
    return GPUInfo(
        vendor="trainium",
        gpu_name=gpu_name,
        driver_version=DEFAULT_TRAINIUM_VERSION,
        gpu_count=device_count,
    )


def _detect_tpu_env() -> GPUInfo | None:
    """Detect TPU from environment (XLA_FLAGS, TPU_NAME, etc.)."""
    if os.getenv("TPU_NAME"):
        return GPUInfo(
            vendor="tpu",
            gpu_name="Google Cloud TPU",
            driver_version="default",
            gpu_count=1,
        )
    if os.getenv("XLA_FLAGS") and "xla_device" in os.getenv("XLA_FLAGS", "").lower():
        return GPUInfo(
            vendor="tpu",
            gpu_name="TPU",
            driver_version="default",
            gpu_count=1,
        )
    return None


def detect_local_accelerator() -> GPUInfo | None:
    """Detect accelerator on local machine.
    Tries: nvidia-smi -> rocm-smi -> neuron-ls -> TPU env.
    Returns:
        GPUInfo if accelerator detected, None otherwise
    """
    # Try NVIDIA first
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,driver_version", "--format=csv,noheader"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            gpu_info = _parse_nvidia_smi(result.stdout)
            if gpu_info:
                cuda_result = subprocess.run(
                    ["nvidia-smi"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if cuda_result.returncode == 0:
                    cuda_ver = _parse_nvidia_smi_cuda_version(cuda_result.stdout)
                    if cuda_ver:
                        return GPUInfo(
                            vendor=gpu_info.vendor,
                            gpu_name=gpu_info.gpu_name,
                            driver_version=cuda_ver,
                            gpu_count=gpu_info.gpu_count,
                        )
                return gpu_info
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    # Try AMD
    try:
        result = subprocess.run(
            ["rocm-smi", "--showproductname"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            gpu_info = _parse_rocm_smi(result.stdout)
            if gpu_info:
                try:
                    ver_result = subprocess.run(
                        ["cat", "/opt/rocm/.info/version"],
                        capture_output=True,
                        text=True,
                        timeout=5,
                    )
                    if ver_result.returncode == 0:
                        rocm_ver = _parse_rocm_version(ver_result.stdout)
                        if rocm_ver:
                            return GPUInfo(
                                vendor=gpu_info.vendor,
                                gpu_name=gpu_info.gpu_name,
                                driver_version=rocm_ver,
                                gpu_count=gpu_info.gpu_count,
                            )
                except (FileNotFoundError, subprocess.TimeoutExpired):
                    pass
                return gpu_info
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    # Try Trainium (neuron-ls). Binary may be at /opt/aws/neuron/bin/ on Neuron AMIs.
    for neuron_cmd in _NEURON_LS_CMDS:
        try:
            result = subprocess.run(
                [neuron_cmd],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                return _parse_neuron_ls(result.stdout)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue
    # Try TPU (env)
    tpu_info = _detect_tpu_env()
    if tpu_info:
        return tpu_info
    return None


async def detect_remote_gpu(client: AsyncSSHClient) -> GPUInfo | None:
    """Detect accelerator on remote machine via SSH.
    Args:
        client: Connected AsyncSSHClient
    Returns:
        GPUInfo if accelerator detected, None otherwise
    """
    # Try NVIDIA first
    result = await client.exec(
        "nvidia-smi --query-gpu=name,driver_version --format=csv,noheader 2>/dev/null"
    )
    if result.exit_code == 0 and result.stdout.strip():
        gpu_info = _parse_nvidia_smi(result.stdout)
        if gpu_info:
            cuda_result = await client.exec("nvidia-smi 2>/dev/null")
            if cuda_result.exit_code == 0:
                cuda_ver = _parse_nvidia_smi_cuda_version(cuda_result.stdout)
                if cuda_ver:
                    return GPUInfo(
                        vendor=gpu_info.vendor,
                        gpu_name=gpu_info.gpu_name,
                        driver_version=cuda_ver,
                        gpu_count=gpu_info.gpu_count,
                    )
            return gpu_info
    # Try AMD (prefer JSON for reliable device count)
    result = await client.exec("rocm-smi --showproductname --json 2>/dev/null")
    if result.exit_code != 0 or not result.stdout.strip():
        result = await client.exec("rocm-smi --showproductname 2>/dev/null")
    if result.exit_code == 0 and result.stdout.strip():
        gpu_info = _parse_rocm_smi(result.stdout)
        if gpu_info:
            ver_result = await client.exec("cat /opt/rocm/.info/version 2>/dev/null")
            if ver_result.exit_code == 0:
                rocm_ver = _parse_rocm_version(ver_result.stdout)
                if rocm_ver:
                    return GPUInfo(
                        vendor=gpu_info.vendor,
                        gpu_name=gpu_info.gpu_name,
                        driver_version=rocm_ver,
                        gpu_count=gpu_info.gpu_count,
                    )
            return gpu_info
    # Try Trainium (neuron-ls). Binary may be at /opt/aws/neuron/bin/ on Neuron AMIs.
    for neuron_cmd in _NEURON_LS_CMDS:
        result = await client.exec(f"{neuron_cmd} -j 2>/dev/null")
        if result.exit_code != 0 or not result.stdout.strip():
            result = await client.exec(f"{neuron_cmd} 2>/dev/null")
        if result.exit_code == 0 and result.stdout.strip():
            return _parse_neuron_ls(result.stdout)
    return None


def _best_match_version(
    version: str,
    known: dict[str, TorchRequirements],
    default_key: str,
) -> TorchRequirements:
    """Find best matching torch requirements for a version string.

    Exact match → major.minor match → highest known version ≤ requested → default.
    Handles unknown future versions (e.g. CUDA 13.1 falls back to 13.0 entry).
    """
    if version in known:
        return known[version]
    major_minor = ".".join(version.split(".")[:2])
    if major_minor in known:
        return known[major_minor]
    # Fall back to the highest known version that doesn't exceed the detected one
    sorted_keys = sorted(known.keys(), key=lambda k: [int(x) for x in k.split(".")])
    for key in reversed(sorted_keys):
        if key <= major_minor:
            return known[key]
    return known[default_key]


def get_torch_requirements(gpu_info: GPUInfo) -> TorchRequirements:
    """Get PyTorch requirements for detected accelerator.
    Args:
        gpu_info: Detected accelerator information
    Returns:
        TorchRequirements with packages and index URL
    """
    if gpu_info.vendor == "nvidia":
        return _best_match_version(
            gpu_info.driver_version, CUDA_TORCH_VERSIONS, DEFAULT_CUDA_VERSION
        )
    elif gpu_info.vendor == "amd":
        return _best_match_version(
            gpu_info.driver_version, ROCM_TORCH_VERSIONS, DEFAULT_ROCM_VERSION
        )
    elif gpu_info.vendor == "trainium":
        if gpu_info.driver_version in TRAINIUM_TORCH_VERSIONS:
            return TRAINIUM_TORCH_VERSIONS[gpu_info.driver_version]
        return TRAINIUM_TORCH_VERSIONS[DEFAULT_TRAINIUM_VERSION]
    elif gpu_info.vendor == "tpu":
        return TPU_TORCH_VERSIONS["default"]
    return TorchRequirements(
        packages=("torch", "torchvision", "torchaudio"),
        index_url="https://download.pytorch.org/whl/cpu",
    )


def get_compute_capability(gpu_info: GPUInfo) -> str:
    """Get compute capability string for accelerator.
    Args:
        gpu_info: Detected accelerator information
    Returns:
        Compute capability string (e.g., "9.0" for H100). "0.0" for Trainium/TPU/other.
    """
    if gpu_info.vendor in ("trainium", "tpu", "other"):
        return "0.0"
    gpu_name_lower = gpu_info.gpu_name.lower()
    # NVIDIA GPUs
    if "b200" in gpu_name_lower or "b100" in gpu_name_lower:
        return "10.0"  # Blackwell
    elif "h100" in gpu_name_lower or "h200" in gpu_name_lower:
        return "9.0"  # Hopper
    elif "a100" in gpu_name_lower:
        return "8.0"  # Ampere
    elif "4090" in gpu_name_lower or "4080" in gpu_name_lower:
        return "8.9"  # Ada Lovelace
    elif "5090" in gpu_name_lower or "5080" in gpu_name_lower:
        return "10.0"  # Blackwell consumer
    elif "3090" in gpu_name_lower or "3080" in gpu_name_lower:
        return "8.6"  # Ampere consumer
    elif "v100" in gpu_name_lower:
        return "7.0"  # Volta
    # AMD GPUs
    elif "mi300" in gpu_name_lower:
        return "9.4"  # gfx942
    elif "mi250" in gpu_name_lower:
        return "9.0"  # gfx90a
    elif "mi100" in gpu_name_lower:
        return "9.0"  # gfx908
    # Default
    return "8.0"


# Compute capability -> nvcc architecture mapping.
# Maps CC strings to the best sm_ arch for that generation.
_CC_TO_ARCH: dict[str, str] = {
    "10.0": "sm_100a",   # Blackwell (B200, B100, RTX 5090/5080)
    "10.1": "sm_101a",   # Blackwell (B300 etc.)
    "9.0": "sm_90a",     # Hopper (H100, H200)
    "8.9": "sm_89",      # Ada Lovelace (RTX 4090, 4080, L40)
    "8.6": "sm_86",      # Ampere consumer (RTX 3090, 3080)
    "8.7": "sm_87",      # Ampere (Jetson Orin)
    "8.0": "sm_80",      # Ampere (A100)
}


def compute_capability_to_arch(compute_capability: str) -> str:
    """Convert compute capability string to nvcc -arch flag.

    Args:
        compute_capability: CC string like "10.0", "9.0", "8.0"
    Returns:
        nvcc architecture string like "sm_100a", "sm_90a", "sm_80"
    """
    assert compute_capability, "compute_capability must be non-empty"
    arch = _CC_TO_ARCH.get(compute_capability)
    assert arch is not None, (
        f"Unknown compute capability '{compute_capability}'. "
        f"Known: {sorted(_CC_TO_ARCH.keys())}"
    )
    return arch
