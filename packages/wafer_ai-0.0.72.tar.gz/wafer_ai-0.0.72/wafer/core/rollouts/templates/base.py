"""Bash command allowlists and denylists for agent sandboxing."""
from __future__ import annotations

# Safe read-only commands with no side effects.
# Templates can extend this with task-specific commands.
# NOTE: The allowlist uses prefix matching, so "git branch" also allows
# "git branch -D" which is destructive. Only include truly read-only commands.
SAFE_BASH_COMMANDS: list[str] = [
    # File inspection
    "ls",
    "cat",
    "head",
    "tail",
    "less",
    "more",
    "file",
    "stat",
    "wc",
    # Search
    "find",
    "grep",
    "rg",
    "fd",
    # Navigation
    "pwd",
    "tree",
    "which",
    "whereis",
    # Comparison/processing
    "diff",
    "sort",
    "uniq",
    # Disk info
    "du",
    "df",
    # Git read-only (only commands with no destructive subcommands)
    "git status",
    "git log",
    "git diff",
    "git show",
    # Data processing
    "jq",
]

# Empty — sandboxes are ephemeral, so nothing needs to be blocked.
DANGEROUS_BASH_COMMANDS: list[str] = []
