"""MCP server for everyrow: agent ops at spreadsheet scale."""
