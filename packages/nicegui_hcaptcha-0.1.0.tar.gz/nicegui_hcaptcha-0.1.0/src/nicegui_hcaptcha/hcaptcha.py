"""
NiceGUI hCaptcha Element
------------------------

This module provides a NiceGUI `Element` wrapper for integrating
hCaptcha (https://www.hcaptcha.com/) into a NiceGUI application.

The `HCaptcha` element:

- Renders an hCaptcha widget on the page
- Retrieves the user response token
- Resets the widget when needed
- Verifies the token server-side using the hCaptcha API
- Extensible via hooks and subclassing
"""

from json import JSONDecodeError
from typing import Literal, Callable, Awaitable, Self

import httpx
from nicegui import ui
from nicegui.element import Element

from .result import HCaptchaResult


VerificationHook = Callable[[HCaptchaResult], Awaitable[None]]


class HCaptcha(Element):
    """
    NiceGUI element for embedding and verifying an hCaptcha widget.

    This class wraps the client-side hCaptcha widget and provides
    asynchronous helpers for:

    - Fetching the generated response token
    - Resetting the widget
    - Verifying the token against hCaptcha's `/siteverify` endpoint

    Parameters
    ----------
    site_key : str
        Public hCaptcha site key.
    lang : str, default="en"
        Language code for the widget.
    theme : Literal["light", "dark"], default="dark"
        Visual theme of the widget.
    timeout : float, default=5.0
        Timeout for verification API requests.

    Notes
    -----
    - The hCaptcha script is injected into the page head on each
      instantiation to avoid issues with persistent reload flags.
    """

    def __init__(
        self,
        site_key: str,
        *,
        lang: str = "en",
        theme: Literal["light", "dark"] = "dark",
        timeout: float = 5.0,
    ) -> None:
        """
        Initialize the hCaptcha widget element.

        This sets up the DOM element, injects the hCaptcha script,
        and schedules client-side rendering.
        """
        super().__init__()

        self._widget_id: int | None = None
        self._verify_handlers: list[VerificationHook] = []

        self.site_key = site_key
        self._http_client = httpx.AsyncClient(
            base_url="https://api.hcaptcha.com",
            timeout=timeout,
        )

        self.classes("h-captcha")
        self.props(f'data-sitekey="{site_key}"')
        self.props(f'data-theme="{theme}"')

        # The script must be re-added because an internal flag persists
        # between page reloads in some cases.
        ui.add_head_html(f'<script src="https://js.hcaptcha.com/1/api.js?render=explicit&hl={lang}" async defer></script>')

        # Delay rendering slightly to ensure the element exists in DOM
        ui.timer(0.2, self._render, once=True)

    def on_verified(self, callback: VerificationHook) -> Self:
        """
        Register an async callback triggered after verification.

        The callback receives an `HCaptchaResult`.
        """
        self._verify_handlers.append(callback)
        return self

    async def get_response(self) -> str | None:
        """
        Retrieve the current hCaptcha response token.

        Returns
        -------
        str | None
            The response token if the widget has been rendered and
            completed, otherwise None.

        Notes
        -----
        - If the widget is not yet rendered, this returns None.
        - The token must be verified server-side using `verified()`.
        """
        if self._widget_id is None:
            return None
        return await ui.run_javascript(f'hcaptcha.getResponse("{self._widget_id}");', timeout=3.0)

    async def reset(self) -> None:
        """
        Reset the hCaptcha widget.

        This clears the current challenge and response token,
        forcing the user to complete a new captcha.
        """
        if self._widget_id is not None:
            await ui.run_javascript(f'hcaptcha.reset("{self._widget_id}");')

    async def verify(self, secret: str) -> HCaptchaResult:
        """
        Verify the current captcha token with hCaptcha.

        Parameters
        ----------
        secret : str
            Private secret key from hCaptcha dashboard.

        Returns
        -------
        HCaptchaResult
            Structured verification result.
        """
        token = await self.get_response()

        if not token:
            result = HCaptchaResult(
                success=False,
                error_codes=["captcha-not-completed"],
            )
            await self._emit_verification(result)
            return result

        if self.client.environ is None:
            raise RuntimeError("Client not available")

        ip = self.client.environ["asgi.scope"]["client"][0]

        try:
            response = await self._http_client.post(
                "/siteverify",
                data={
                    "secret": secret,
                    "response": token,
                    "remoteip": ip,
                    "sitekey": self.site_key,
                },
            )
            data = response.json()
        except (httpx.HTTPError, JSONDecodeError, TypeError):
            result = HCaptchaResult(
                success=False,
                error_codes=["verification-request-failed"],
                token=token,
            )
            await self._emit_verification(result)
            return result

        result = HCaptchaResult(
            success=data.get("success", False),
            error_codes=data.get("error-codes"),
            token=token,
        )

        await self._emit_verification(result)
        await self.reset()
        return result

    async def _render(self) -> int | None:
        """
        Render the hCaptcha widget in the browser.

        This waits for the hCaptcha script to become available,
        then explicitly renders the widget using `hcaptcha.render()`.

        Returns
        -------
        int | None
            The widget ID returned by `hcaptcha.render()`, or None
            if rendering fails.

        Notes
        -----
        This method is scheduled automatically during initialization
        and should not typically be called manually.
        """
        widget_id = await ui.run_javascript(f"""
            (async () => {{
                // Wait until script is ready
                await new Promise(resolve => {{
                    if (window.hcaptcha) {{
                        return resolve();
                    }}
                    
                    const interval = setInterval(() => {{
                        if (window.hcaptcha) {{
                            clearInterval(interval);
                            resolve();
                        }}
                    }}, 2);
                }});
        
                const id = hcaptcha.render("{self.html_id}", {{
                    sitekey: "{self.site_key}",
                    theme: "{self._props.get('data-theme', 'dark')}"
                }});
                
                return id;
            }})();
        """)
        self._widget_id = widget_id
        return widget_id

    async def _emit_verification(self, result: HCaptchaResult) -> None:
        """
        Emit verification event to registered hooks and
        subclass handlers.
        """
        for callback in self._verify_handlers:
            await callback(result)

        if result.success:
            await self._on_verification_success(result)
        else:
            await self._on_verification_failure(result)

    async def _on_verification_success(self, result: HCaptchaResult) -> None:
        """
        Hook executed after successful verification.
        """
        pass

    async def _on_verification_failure(self, result: HCaptchaResult) -> None:
        """
        Hook executed after failed verification.
        """
        pass
