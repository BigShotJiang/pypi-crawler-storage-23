from dataclasses import dataclass
from typing import Sequence


@dataclass(slots=True)
class HCaptchaResult:
    """
    Result returned by `HCaptcha.verify`.

    Attributes
    ----------
    success : bool
        Whether verification succeeded.
    error_codes : Sequence[str] | None
        Error codes returned by hCaptcha (if any).
    token : str | None
        The raw captcha response token.
    """
    success: bool
    error_codes: Sequence[str] | None = None
    token: str | None = None
