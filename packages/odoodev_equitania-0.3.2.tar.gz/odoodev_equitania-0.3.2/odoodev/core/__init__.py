"""Core business logic modules for odoodev."""
