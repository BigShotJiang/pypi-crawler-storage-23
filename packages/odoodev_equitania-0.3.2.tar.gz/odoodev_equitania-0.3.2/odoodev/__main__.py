"""Allow running odoodev as a module: python -m odoodev."""

from odoodev.cli import cli

if __name__ == "__main__":
    cli()
