"""CLI command modules for odoodev."""
