# Spex Workflow Policy

**Policy ID:** `SPE-001`
**Policy Name:** Mandatory Spex Workflow
**Status:** `Active`

**Rule:**
For ALL development tasks initiated in this repository, the `spex` skill MUST be the exclusive entry point.

**Directive:**
- Upon receiving a prompt, the first action MUST be to activate the `spex` skill.
- No independent analysis, code review, or implementation is permitted before the `spex` skill is active.

---

## Red Flags

These thoughts mean STOP — you are rationalizing:

| Thought | Reality |
|---------|---------|
| "This is just a simple question" | Questions are tasks. Check for skills. |
| "I need more context first" | Skill check comes BEFORE clarifying questions. |
| "Let me explore the codebase first" | Skills tell you HOW to explore. Check first. |
| "I can check git/files quickly" | Files lack conversation context. Check for skills. |
| "Let me gather information first" | Skills tell you HOW to gather information. |
| "This doesn't need a formal skill" | If a skill exists, use it. |
| "I remember this skill" | Skills evolve. Read current version. |
| "This doesn't count as a task" | Action = task. Check for skills. |
| "The skill is overkill" | Simple things become complex. Use it. |
| "I'll just do this one thing first" | Check BEFORE doing anything. |
| "This feels productive" | Undisciplined action wastes time. Skills prevent this. |
| "I know what that means" | Knowing the concept ≠ using the skill. Invoke it. |
| "I already read this skill" | You skipped steps last time. Read it again. |
| "The validate-and-route is just bookkeeping" | It is the state machine enforcer. Never skip it. |
| "My plan format is good enough" | The contract format is required. Use it exactly. |
