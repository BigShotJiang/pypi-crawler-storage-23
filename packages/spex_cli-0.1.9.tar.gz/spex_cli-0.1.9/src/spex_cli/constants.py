"""Shared constants for spex."""

DECISION_ID_TRAILER = "decision-id"

REQUIREMENTS_FILE = ".spex/memory/requirements.jsonl"
DECISIONS_FILE = ".spex/memory/decisions.jsonl"
POLICIES_FILE = ".spex/memory/policies.jsonl"
PLANS_FILE = ".spex/memory/plans.jsonl"
TRACES_FILE = ".spex/memory/traces.jsonl"
APPS_FILE = ".spex/memory/apps.jsonl"
