"""Enable command — sets up a project with spex."""

import json
import shutil
import subprocess
import sys
from pathlib import Path

import questionary
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.text import Text

from spex_cli.agents import AGENT_CONFIG

console = Console()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _pkg_dir() -> Path:
    return Path(__file__).parent


def _skills_dir() -> Path:
    return _pkg_dir() / "skills"


def _hooks_src_dir() -> Path:
    return _pkg_dir() / "hooks"


def _hook_script_src() -> Path:
    return _hooks_src_dir() / "hook_trace_commit.py"


def _agent_settings_src(agent_key: str) -> Path | None:
    settings_file = AGENT_CONFIG[agent_key].get("settings_file")
    if not settings_file:
        return None
    path = _pkg_dir() / settings_file
    return path if path.exists() else None


# ---------------------------------------------------------------------------
# Step 1 – create .spex directory structure
# ---------------------------------------------------------------------------

def _create_spex_structure(repo_root: Path) -> None:
    spex_dir = repo_root / ".spex"

    for sub in ("memory", "hooks"):
        (spex_dir / sub).mkdir(parents=True, exist_ok=True)

    # init.md
    init_src = _skills_dir() / "init.md"
    init_dst = spex_dir / "init.md"
    if init_src.exists() and not init_dst.exists():
        shutil.copy2(init_src, init_dst)

    # post-commit hook
    post_commit_src = _hooks_src_dir() / "post-commit"
    post_commit_dst = spex_dir / "hooks" / "post-commit"
    if post_commit_src.exists():
        shutil.copy2(post_commit_src, post_commit_dst)
        post_commit_dst.chmod(0o755)

    # hook_trace_commit.py lives alongside post-commit in hooks/
    script_src = _hook_script_src()
    script_dst = spex_dir / "hooks" / "hook_trace_commit.py"
    if script_src.exists():
        shutil.copy2(script_src, script_dst)


# ---------------------------------------------------------------------------
# Step 2 – agent selection
# ---------------------------------------------------------------------------

def _select_agent() -> str:
    console.print()
    choices = [
        questionary.Choice(title=f"{cfg['name']}  ({key})", value=key)
        for key, cfg in AGENT_CONFIG.items()
    ]
    result = questionary.select(
        "Select your AI agent:",
        choices=choices,
        style=questionary.Style([
            ("question",        "bold"),
            ("pointer",         "fg:#8B5CF6 bold"),
            ("highlighted",     "fg:#FBBF24 bold"),
            ("selected",        "fg:#10B981 bold"),
        ]),
    ).ask()
    if result is None:          # user pressed Ctrl-C
        sys.exit(0)
    return result


# ---------------------------------------------------------------------------
# Step 3 – install skills
# ---------------------------------------------------------------------------

def _install_skills(repo_root: Path, agent_key: str) -> Path:
    agent_folder = repo_root / AGENT_CONFIG[agent_key]["folder"]
    dst_skills_dir = agent_folder / "skills"

    shutil.copytree(
        _skills_dir(),
        dst_skills_dir,
        dirs_exist_ok=True,
        ignore=shutil.ignore_patterns(".DS_Store", "init.md"),
    )
    return dst_skills_dir


# ---------------------------------------------------------------------------
# Step 4 – install git hooks
# ---------------------------------------------------------------------------

def _install_git_hooks(repo_root: Path) -> None:
    hooks_path = repo_root / ".spex" / "hooks"
    if not hooks_path.is_dir():
        raise RuntimeError(f"Hooks directory not found at {hooks_path}")

    subprocess.run(
        ["git", "config", "core.hooksPath", ".spex/hooks"],
        check=True,
        cwd=str(repo_root),
    )

    post_commit = hooks_path / "post-commit"
    if post_commit.exists():
        post_commit.chmod(0o755)


# ---------------------------------------------------------------------------
# Step 5 – merge Claude settings
# ---------------------------------------------------------------------------

def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for key, value in override.items():
        if key in result:
            if isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = _deep_merge(result[key], value)
            elif isinstance(result[key], list) and isinstance(value, list):
                seen = set()
                combined = []
                for item in result[key] + value:
                    serialised = json.dumps(item, sort_keys=True)
                    if serialised not in seen:
                        seen.add(serialised)
                        combined.append(item)
                result[key] = combined
            else:
                result[key] = value
        else:
            result[key] = value
    return result


def _merge_agent_settings(repo_root: Path, agent_key: str) -> None:
    src = _agent_settings_src(agent_key)
    if src is None:
        return

    agent_dir = repo_root / AGENT_CONFIG[agent_key]["folder"]
    agent_dir.mkdir(parents=True, exist_ok=True)

    dst = agent_dir / "settings.local.json"
    existing: dict = {}
    if dst.exists():
        with open(dst) as f:
            existing = json.load(f)

    with open(src) as f:
        spex_settings = json.load(f)

    merged = _deep_merge(existing, spex_settings)

    with open(dst, "w") as f:
        json.dump(merged, f, indent=2)
        f.write("\n")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_enable() -> None:
    # Resolve repo root
    try:
        repo_root = Path(
            subprocess.check_output(
                ["git", "rev-parse", "--show-toplevel"],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        )
    except subprocess.CalledProcessError:
        console.print(
            Panel(
                "[red]Not inside a git repository.[/red]\n"
                "Run [bold]spex enable[/bold] from within a git-tracked project.",
                border_style="red",
                title="Error",
            )
        )
        sys.exit(1)

    console.print(
        Panel(
            Text.assemble(
                ("Setting up Spex for this repository\n", "bold white"),
                (str(repo_root), "dim"),
            ),
            border_style="#8B5CF6",
            padding=(0, 2),
        )
    )

    # ── Interactive prompts (collected up front) ────────────────────────────
    console.print()
    console.print("[bold #FBBF24]Step 1[/bold #FBBF24]  Select your AI agent")
    agent_key = _select_agent()
    agent_name = AGENT_CONFIG[agent_key]["name"]

    agent_settings_src = _agent_settings_src(agent_key)
    use_default = False
    if agent_settings_src is not None:
        agent_folder = AGENT_CONFIG[agent_key]["folder"]
        console.print()
        console.print("[bold #FBBF24]Step 2[/bold #FBBF24]  Agent settings")
        use_default = Confirm.ask(
            f"  Activate spex as default workflow? "
            f"(merges into [bold]{agent_folder}settings.local.json[/bold])",
            default=True,
        )

    # ── Execution ────────────────────────────────────────────────────────────
    console.print()
    console.print("[bold #FBBF24]Step 3[/bold #FBBF24]  Creating [bold].spex[/bold] directory structure")
    _create_spex_structure(repo_root)
    console.print("  [green]✓[/green] [bold].spex/memory/[/bold]")
    console.print("  [green]✓[/green] [bold].spex/hooks/[/bold]")
    console.print("  [green]✓[/green] [bold].spex/init.md[/bold]")
    console.print("  [green]✓[/green] [bold].spex/hooks/post-commit[/bold]")
    console.print("  [green]✓[/green] [bold].spex/hooks/hook_trace_commit.py[/bold]")

    console.print()
    console.print(f"[bold #FBBF24]Step 4[/bold #FBBF24]  Installing skills for [bold]{agent_name}[/bold]")
    commands_dir = _install_skills(repo_root, agent_key)
    rel = commands_dir.relative_to(repo_root)
    console.print(f"  [green]✓[/green] [bold]{agent_name}[/bold] selected")
    console.print(f"  [green]✓[/green] Skills installed to [bold]{rel}/[/bold]")

    console.print()
    console.print("[bold #FBBF24]Step 5[/bold #FBBF24]  Configuring git hooks")
    _install_git_hooks(repo_root)
    console.print("  [green]✓[/green] [bold]core.hooksPath[/bold] → [bold].spex/hooks[/bold]")
    console.print("  [green]✓[/green] [bold].spex/hooks/post-commit[/bold] is executable")

    if use_default:
        _merge_agent_settings(repo_root, agent_key)
        agent_folder = AGENT_CONFIG[agent_key]["folder"]
        console.print()
        console.print("[bold #FBBF24]Step 6[/bold #FBBF24]  Agent settings")
        console.print(f"  [green]✓[/green] Merged into [bold]{agent_folder}settings.local.json[/bold]")

    # ── Done ────────────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            Text.assemble(
                ("Spex is ready!\n\n", "bold green"),
                ("Run ", "white"),
                ("spex healthcheck", "bold #FBBF24"),
                (" to verify the installation.", "white"),
            ),
            border_style="green",
            padding=(1, 2),
        )
    )
