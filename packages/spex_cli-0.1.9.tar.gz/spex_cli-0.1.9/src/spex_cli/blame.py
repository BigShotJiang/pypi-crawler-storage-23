"""blame - git blame to decision-id trailer resolution pipeline."""

import json
import subprocess
from pathlib import Path
from typing import List

from spex_cli.constants import DECISION_ID_TRAILER, DECISIONS_FILE, REQUIREMENTS_FILE, POLICIES_FILE
from spex_cli.utils import get_latest_active_jq, ValidationError

_STRIP_FIELDS = {'version', 'status', 'createdAt', 'author', 'source'}

_IMPORT_PREFIXES: dict[str, list[str]] = {
    ".py":   ["import ", "from "],
    ".js":   ["import ", "require("],
    ".ts":   ["import ", "require("],
    ".jsx":  ["import ", "require("],
    ".tsx":  ["import ", "require("],
    ".mjs":  ["import ", "require("],
    ".cjs":  ["import ", "require("],
    ".go":   ["import "],
    ".java": ["import "],
    ".scala":["import "],
    ".kt":   ["import "],
    ".rs":   ["use "],
    ".rb":   ["require"],
    ".php":  ["use ", "require", "include"],
    ".cs":   ["using "],
    ".cpp":  ["#include"],
    ".c":    ["#include"],
    ".h":    ["#include"],
    ".hpp":  ["#include"],
    ".cc":   ["#include"],
    ".swift":["import "],
}


def _compact(obj: dict) -> dict:
    return {k: v for k, v in obj.items() if k not in _STRIP_FIELDS and v is not None and v != []}


def _is_noise_line(content: str, file_ext: str) -> bool:
    """Return True if this blame line should be excluded from commit collection.

    A line is noise when it is empty or starts with an import/include keyword
    for the given file extension. Unknown extensions use only empty-line filtering.
    """
    stripped = content.strip()
    if not stripped:
        return True
    prefixes = _IMPORT_PREFIXES.get(file_ext, [])
    return any(stripped.startswith(p) for p in prefixes)


def parse_line_intervals(lines_str: str) -> List[tuple[int, int]]:
    """Parse line string like '10-20,30' into a list of (start, end) intervals."""
    if not lines_str:
        return []
    intervals = []
    for part in lines_str.split(','):
        if '-' in part:
            start, end = part.split('-')
            intervals.append((int(start), int(end)))
        else:
            line = int(part)
            intervals.append((line, line))
    return intervals


def get_decision_ids_from_commit(commit_hash: str) -> List[str]:
    """Extract decision-id trailer values from a commit message."""
    try:
        result = subprocess.run(
            ['git', 'log', '-1', f'--format=%(trailers:key={DECISION_ID_TRAILER},valueonly)', commit_hash],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            return [v.strip() for v in result.stdout.splitlines() if v.strip()]
    except Exception:
        pass
    return []


def collect_target_commits(targets: List[str]) -> tuple[dict, set]:
    """Phase 1: collect commit hashes touched by each target via git blame / git log.

    Returns (target_commits, all_commits) where target_commits maps each target
    string to the set of commit hashes that touch it.
    """
    all_commits: set = set()
    target_commits: dict = {}

    for target in targets:
        file_path = target
        target_intervals = []
        if ':' in target:
            file_path, lines_part = target.split(':', 1)
            try:
                target_intervals = parse_line_intervals(lines_part)
            except ValueError:
                raise ValidationError(f"Invalid line format in target: {target}")

        commits_found: set = set()
        file_ext = Path(file_path).suffix.lower()
        if target_intervals:
            for start, end in target_intervals:
                try:
                    res = subprocess.run(
                        ["git", "blame", "-L", f"{start},{end}", "-l", "-s", file_path],
                        capture_output=True, text=True
                    )
                    if res.returncode == 0:
                        for line in res.stdout.splitlines():
                            parts = line.split()
                            if not parts:
                                continue
                            content = line.split(')', 1)[1] if ')' in line else ''
                            if _is_noise_line(content, file_ext):
                                continue
                            commits_found.add(parts[0].lstrip('^'))
                except Exception:
                    pass
        else:
            try:
                res = subprocess.run(
                    ["git", "log", "-n", "10", "--format=%H", file_path],
                    capture_output=True, text=True
                )
                if res.returncode == 0:
                    for line in res.stdout.splitlines():
                        if line.strip():
                            commits_found.add(line.strip())
            except Exception:
                pass

        target_commits[target] = commits_found
        all_commits.update(commits_found)

    return target_commits, all_commits


def resolve_commit_decision_ids(all_commits: set) -> dict:
    """Phase 2: map each commit hash to its decision-id trailer values.

    Returns commit_hash -> [decision-id, ...].
    """
    commit_to_decision_ids: dict = {}
    for commit in all_commits:
        dec_ids = get_decision_ids_from_commit(commit)
        if dec_ids:
            commit_to_decision_ids[commit] = dec_ids
    return commit_to_decision_ids


def resolve_correlations_for_target(
    target: str,
    found_commits: set,
    commit_to_decision_ids: dict,
    resolved_decisions: dict,
    resolved_requirements: dict,
    resolved_policies: dict,
) -> list:
    """Phase 3: build correlation objects for a single target.

    Mutates the resolved_* caches to avoid redundant lookups across targets.
    Returns a list of correlation dicts.
    """
    dec_id_to_commits: dict = {}
    for commit in found_commits:
        for dec_id in commit_to_decision_ids.get(commit, []):
            dec_id_to_commits.setdefault(dec_id, []).append(commit)

    correlations = []
    for dec_id, carrying_commits in dec_id_to_commits.items():
        if dec_id not in resolved_decisions:
            resolved_decisions[dec_id] = get_latest_active_jq(dec_id, DECISIONS_FILE)

        decision = resolved_decisions.get(dec_id)
        if not decision:
            continue

        related_reqs = []
        seen_req_ids: set = set()
        for req_id in decision.get('satisfies', []):
            if req_id in seen_req_ids:
                continue
            seen_req_ids.add(req_id)
            if req_id not in resolved_requirements:
                resolved_requirements[req_id] = get_latest_active_jq(req_id, REQUIREMENTS_FILE)
            req = resolved_requirements.get(req_id)
            if req:
                related_reqs.append(req)

        related_pols = []
        seen_pol_ids: set = set()
        for pol_id in decision.get('satisfiesPolicies', []):
            if pol_id in seen_pol_ids:
                continue
            seen_pol_ids.add(pol_id)
            if pol_id not in resolved_policies:
                resolved_policies[pol_id] = get_latest_active_jq(pol_id, POLICIES_FILE)
            pol = resolved_policies.get(pol_id)
            if pol:
                related_pols.append(pol)

        correlations.append({
            "commitHashes": carrying_commits,
            "decision": _compact(decision),
            "requirements": [_compact(r) for r in related_reqs],
            "policies": [_compact(p) for p in related_pols],
        })

    return correlations


def blame_targets(args) -> None:
    """Find relevant context for files and line ranges via git blame → decision-id trailer → decision record."""
    targets = args.targets

    target_commits, all_commits = collect_target_commits(targets)

    if not all_commits:
        print(json.dumps([{"target": t, "correlations": []} for t in targets], separators=(',', ':')))
        return

    commit_to_decision_ids = resolve_commit_decision_ids(all_commits)

    resolved_decisions: dict = {}
    resolved_requirements: dict = {}
    resolved_policies: dict = {}

    results = []
    for target in targets:
        found_commits = target_commits.get(target, set())
        correlations = resolve_correlations_for_target(
            target,
            found_commits,
            commit_to_decision_ids,
            resolved_decisions,
            resolved_requirements,
            resolved_policies,
        )
        results.append({"target": target, "correlations": correlations})

    print(json.dumps(results, separators=(',', ':')))
