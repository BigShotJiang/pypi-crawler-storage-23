#!/usr/bin/env python3
"""
Data models for spex memory objects using Python dataclasses.
Provides type-safe structures for Requirements, Decisions, Policies, Plans, and Traces.
"""

from dataclasses import dataclass, field, asdict
from typing import Optional, List, Union, Dict, Any, Type, TypeVar


# Type variable for generic dataclass operations
T = TypeVar('T')


# Validation constants
VALID_REQUIREMENT_TYPES = {'FR', 'NFR', 'CR', 'UR'}
VALID_DECISION_CLASSES = {'architectural', 'structural', 'tactical'}
VALID_STATUSES = {'active', 'deprecated', 'obsolete', 'superseded'}
VALID_PLAN_STATUSES = {'draft', 'approved', 'executing', 'complete', 'abandoned'}


# Validation helper functions
def validate_requirement_type(req_type: str) -> None:
    """Validate  requirement type."""
    if req_type not in VALID_REQUIREMENT_TYPES:
        raise ValueError(f"Invalid requirement type: {req_type}. Must be one of {VALID_REQUIREMENT_TYPES}")



def validate_decision_class(decision_class: str) -> None:
    """Validate decision class."""
    if decision_class not in VALID_DECISION_CLASSES:
        raise ValueError(f"Invalid decision class: {decision_class}. Must be one of {VALID_DECISION_CLASSES}")


def validate_status(status: str, valid_statuses: set) -> None:
    """Validate status against allowed values."""
    if status not in valid_statuses:
        raise ValueError(f"Invalid status: {status}. Must be one of {valid_statuses}")


@dataclass
class BaseMemoryEntry:
    """Base class for all versioned memory entries."""
    id: str
    version: int
    status: str
    createdAt: str
    author: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert dataclass to dictionary."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls: Type[T], data: Dict[str, Any]) -> T:
        """Create instance from dictionary."""
        return cls(**data)





@dataclass
class Requirement(BaseMemoryEntry):
    """Represents a project requirement."""
    planId: Optional[str] = None
    type: str = ""
    description: str = ""
    source: str = ""
    acceptanceCriteria: str = ""
    deprecatedAt: Optional[str] = None
    deprecatedReason: Optional[str] = None
    supersededBy: Optional[str] = None
    scope: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate fields after initialization."""
        validate_requirement_type(self.type)
        validate_status(self.status, VALID_STATUSES)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Requirement':
        """Create instance from dictionary with validation."""
        # Extract base fields
        base_fields = {
            'id': data['id'],
            'version': data['version'],
            'status': data['status'],
            'createdAt': data['createdAt'],
            'author': data['author']
        }
        
        # Extract requirement-specific fields
        req_fields = {
            'planId': data.get('planId', ''),
            'type': data.get('type', ''),
            'description': data.get('description', ''),
            'source': data.get('source', ''),
            'acceptanceCriteria': data.get('acceptanceCriteria', ''),
            'deprecatedAt': data.get('deprecatedAt'),
            'deprecatedReason': data.get('deprecatedReason'),
            'supersededBy': data.get('supersededBy'),
            'scope': data.get('scope', [])
        }
        
        return cls(**base_fields, **req_fields)


@dataclass
class Decision(BaseMemoryEntry):
    """Represents an architectural or tactical decision."""
    proposal: str = ""
    rationale: str = ""
    alternatives: str = ""
    satisfies: List[str] = field(default_factory=list)
    satisfiesPolicies: List[str] = field(default_factory=list)
    impact: Union[str, Dict[str, Any]] = ""
    decisionClass: str = ""
    grounding: Optional[Dict[str, Any]] = None
    obsoleteAt: Optional[str] = None
    obsoleteReason: Optional[str] = None
    supersededBy: Optional[str] = None
    scope: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate fields after initialization."""
        validate_decision_class(self.decisionClass)
        validate_status(self.status, VALID_STATUSES)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Decision':
        """Create instance from dictionary with validation."""
        # Extract base fields
        base_fields = {
            'id': data['id'],
            'version': data['version'],
            'status': data['status'],
            'createdAt': data['createdAt'],
            'author': data['author']
        }
        
        # Extract decision-specific fields
        dec_fields = {
            'proposal': data.get('proposal', ''),
            'rationale': data.get('rationale', ''),
            'alternatives': data.get('alternatives', ''),
            'satisfies': data.get('satisfies', []),
            'satisfiesPolicies': data.get('satisfiesPolicies', []),
            'impact': data.get('impact', ''),
            'decisionClass': data.get('decisionClass', ''),
            'grounding': data.get('grounding'),
            'obsoleteAt': data.get('obsoleteAt'),
            'obsoleteReason': data.get('obsoleteReason'),
            'supersededBy': data.get('supersededBy'),
            'scope': data.get('scope', [])
        }
        
        return cls(**base_fields, **dec_fields)


@dataclass
class Policy(BaseMemoryEntry):
    """Represents a project policy or guideline."""
    planId: str = ""
    description: str = ""
    rationale: str = ""
    satisfies: List[str] = field(default_factory=list)
    deprecatedAt: Optional[str] = None
    deprecatedReason: Optional[str] = None
    supersededBy: Optional[str] = None
    scope: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate fields after initialization."""
        validate_status(self.status, VALID_STATUSES)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Policy':
        """Create instance from dictionary with validation."""
        # Extract base fields
        base_fields = {
            'id': data['id'],
            'version': data['version'],
            'status': data['status'],
            'createdAt': data['createdAt'],
            'author': data['author']
        }
        
        # Extract policy-specific fields
        pol_fields = {
            'planId': data.get('planId', ''),
            'description': data.get('description', ''),
            'rationale': data.get('rationale', ''),
            'satisfies': data.get('satisfies', []),
            'deprecatedAt': data.get('deprecatedAt'),
            'deprecatedReason': data.get('deprecatedReason'),
            'supersededBy': data.get('supersededBy'),
            'scope': data.get('scope', [])
        }
        
        return cls(**base_fields, **pol_fields)


@dataclass
class Plan(BaseMemoryEntry):
    """Represents a feature plan."""
    featureName: str = ""
    goal: str = ""
    context: str = ""
    approvedAt: Optional[str] = None
    completedAt: Optional[str] = None
    abandonedAt: Optional[str] = None
    abandonedReason: Optional[str] = None
    supersededBy: Optional[str] = None
    
    def __post_init__(self):
        """Validate fields after initialization."""
        validate_status(self.status, VALID_PLAN_STATUSES)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Plan':
        """Create instance from dictionary with validation."""
        # Extract base fields
        base_fields = {
            'id': data['id'],
            'version': data['version'],
            'status': data['status'],
            'createdAt': data['createdAt'],
            'author': data['author']
        }
        
        # Extract plan-specific fields
        plan_fields = {
            'featureName': data.get('featureName', ''),
            'goal': data.get('goal', ''),
            'context': data.get('context', ''),
            'approvedAt': data.get('approvedAt'),
            'completedAt': data.get('completedAt'),
            'abandonedAt': data.get('abandonedAt'),
            'abandonedReason': data.get('abandonedReason'),
            'supersededBy': data.get('supersededBy')
        }
        
        return cls(**base_fields, **plan_fields)


@dataclass
class Trace(BaseMemoryEntry):
    """Represents a trace linking a commit to a decision."""
    decisionId: str = ""
    commitHashes: List[str] = field(default_factory=list)
    timestamp: str = ""
    
    def __post_init__(self):
        """Validate fields after initialization."""
        # Traces don't have the same status validation as other entities
        pass
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Trace':
        """Create instance from dictionary with validation."""
        # Extract base fields (traces may not have all base fields in legacy data)
        base_fields = {
            'id': data.get('id', ''),
            'version': data.get('version', 1),
            'status': data.get('status', 'active'),
            'createdAt': data.get('createdAt', data.get('timestamp', '')),
            'author': data.get('author', '')
        }
        
        # Handle both single commitHash (legacy) and list of commitHashes
        commit_hashes = data.get('commitHashes', [])
        if not commit_hashes and 'commitHash' in data:
            commit_hashes = [data['commitHash']]
            
        trace_fields = {
            'decisionId': data.get('decisionId', ''),
            'commitHashes': commit_hashes,
            'timestamp': data.get('timestamp', '')
        }
        
        return cls(**base_fields, **trace_fields)


@dataclass
class App(BaseMemoryEntry):
    """Represents an application or library in the codebase."""
    name: str = ""
    type: str = ""  # 'application' or 'library'
    repository: str = ""  # Repository name or URL
    appType: Optional[str] = None  # 'frontend', 'backend', 'cli', 'service'
    packageManager: Optional[str] = None  # 'npm', 'pip', 'cargo', 'go', etc.
    filePath: str = ""  # Relative path from git root
    owner: str = ""  # Owner/maintainer of the app or library (optional)
    
    def __post_init__(self):
        """Validate fields after initialization."""
        if self.type not in ['application', 'library']:
            raise ValueError(f"Invalid app type: {self.type}. Must be 'application' or 'library'")
        validate_status(self.status, VALID_STATUSES)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'App':
        """Create instance from dictionary with validation."""
        # Extract base fields
        base_fields = {
            'id': data['id'],
            'version': data['version'],
            'status': data['status'],
            'createdAt': data['createdAt'],
            'author': data['author']
        }
        
        # Extract app-specific fields
        app_fields = {
            'name': data.get('name', ''),
            'type': data.get('type', ''),
            'repository': data.get('repository', ''),
            'appType': data.get('appType'),
            'packageManager': data.get('packageManager'),
            'filePath': data.get('filePath', ''),
            'owner': data.get('owner', '')
        }
        
        return cls(**base_fields, **app_fields)
