"""
Tests that decision_id git commit trailers survive rebase and squash operations.

The actual simulation logic lives in scripts/test_decision_id_trailers.sh.
This module is the pytest entry-point that executes it and reports results.
"""

import os
import subprocess

SCRIPT = os.path.join(os.path.dirname(__file__), "..", "scripts", "test_decision_id_trailers.sh")


def _git_available() -> bool:
    try:
        subprocess.run(["git", "--version"], check=True, capture_output=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def _run_simulation() -> subprocess.CompletedProcess:
    return subprocess.run(
        ["bash", os.path.abspath(SCRIPT)],
        capture_output=True,
        text=True,
    )


def test_decision_id_trailers_survive_rebase():
    """decision_id trailers remain in the canonical trailer block after rebase."""
    if not _git_available():
        raise RuntimeError("git is not available in this environment")

    result = _run_simulation()
    print(result.stdout)

    # The simulation prints per-test PASS/FAIL lines; isolate rebase evidence.
    rebase_lines = [
        line for line in result.stdout.splitlines()
        if "rebase" in line.lower() and ("PASS" in line or "FAIL" in line)
    ]
    assert rebase_lines, "Simulation produced no rebase test output"

    failing = [line for line in rebase_lines if "FAIL" in line]
    assert not failing, (
        "One or more rebase trailer tests failed:\n"
        + "\n".join(failing)
        + "\n\nFull output:\n"
        + result.stdout
    )


def test_decision_id_trailers_survive_squash():
    """All decision_id values appear in the combined message after a squash."""
    if not _git_available():
        raise RuntimeError("git is not available in this environment")

    result = _run_simulation()
    print(result.stdout)

    squash_lines = [
        line for line in result.stdout.splitlines()
        if "squash" in line.lower() and ("PASS" in line or "FAIL" in line)
    ]
    assert squash_lines, "Simulation produced no squash test output"

    failing = [line for line in squash_lines if "FAIL" in line]
    assert not failing, (
        "One or more squash trailer tests failed:\n"
        + "\n".join(failing)
        + "\n\nFull output:\n"
        + result.stdout
    )


def test_decision_id_trailers_survive_rebase_then_squash_chain():
    """
    Three commits each with a distinct decision_id are rebased onto a new base
    and then squashed into one — all three values must survive both operations.
    """
    if not _git_available():
        raise RuntimeError("git is not available in this environment")

    result = _run_simulation()
    print(result.stdout)

    chain_lines = [
        line for line in result.stdout.splitlines()
        if "DEC-030" in line and ("PASS" in line or "FAIL" in line)
    ]
    assert chain_lines, "Simulation produced no rebase+squash chain test output"

    failing = [line for line in chain_lines if "FAIL" in line]
    assert not failing, (
        "Rebase+squash chain trailer test failed:\n"
        + "\n".join(failing)
        + "\n\nFull output:\n"
        + result.stdout
    )


def test_decision_id_trailers_parallel_branches_no_contamination():
    """
    Parallel feature branches rebased onto an advanced main each retain only
    their own decision_id trailers — no cross-branch contamination.
    """
    if not _git_available():
        raise RuntimeError("git is not available in this environment")

    result = _run_simulation()
    print(result.stdout)

    parallel_lines = [
        line for line in result.stdout.splitlines()
        if ("contamination" in line.lower() or "parallel" in line.lower() or "alpha" in line.lower() or "beta" in line.lower())
        and ("PASS" in line or "FAIL" in line)
    ]
    assert parallel_lines, "Simulation produced no parallel-branch test output"

    failing = [line for line in parallel_lines if "FAIL" in line]
    assert not failing, (
        "Parallel-branch rebase test failed:\n"
        + "\n".join(failing)
        + "\n\nFull output:\n"
        + result.stdout
    )


def test_git_trailer_simulation_exits_clean():
    """
    End-to-end: the full simulation script must exit 0 with zero failures.
    This is the single authoritative gate used in CI.
    """
    if not _git_available():
        raise RuntimeError("git is not available in this environment")

    result = _run_simulation()
    print(result.stdout)
    if result.returncode != 0:
        print(result.stderr)

    assert result.returncode == 0, (
        "Git trailer simulation reported failures:\n"
        + result.stdout
        + result.stderr
    )
