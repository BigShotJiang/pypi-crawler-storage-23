# Spex Skills: A User Guide

The Spex ecosystem is designed to bring structure, traceability, and knowledge retention to your development process. It consists of two core skills: `spex-onboard` for initial setup and `spex` for orchestrating development tasks.

This guide will help you understand when and how to use each skill effectively.

## 1. `spex-onboard`: Setting Up Your Project

The `spex-onboard` skill is the first step to integrating your project with Spex. Its sole purpose is to analyze your codebase, identify all the distinct applications and reusable libraries within it, and create a record of them. This record is crucial for all future Spex operations.

### When to Use `spex-onboard`

You should use this skill in two primary scenarios:

1.  **Initial Project Setup:** When you first start using Spex on a new or existing codebase. This is a mandatory first step.
2.  **Major Codebase Restructuring:** If you add or remove entire applications or libraries (e.g., adding a new microservice, monolothic repo refactor).

**Example Invocation:**
```
spex-onboard analyze the codebase
```

### How It Works

When invoked, `spex-onboard` performs the following automated steps:

1.  **Detects Code:** It scans your project for common application and library indicators.
    *   **Supported Types:** Node.js (`package.json`), Python (`requirements.txt`, `pyproject.toml`), Rust (`Cargo.toml`), Go (`go.mod`), Docker (`Dockerfile`), Kubernetes manifests, and more.
2.  **Identifies Components:** It categorizes each finding as either an `application` (deployable service/site) or a `library` (reusable package).
3.  **Prompts for Owners (Interactive):** For each component found, it will pause and ask you: *"Who is the owner/maintainer?"*. You can provide a name/team or press Enter to skip.
4.  **Persists to Memory:** It saves this structural map to `.spex/memory/apps.jsonl`. This file is the "atlas" for all subsequent Spex operations.
5.  **Suggests Next Steps:** Finally, it identifies potential documentation files (e.g., `README.md`, `ARCHITECTURE.md`) and suggests using them to "teach" the agent (see **Section 4: Knowledge Capture**).

---

## 2. `spex`: Orchestrating Development Work

The `spex` skill is your day-to-day workhorse. It intelligently sizes up your request and directs it into one of two powerful workflows: a **Lightweight Flow** for small fixes or a **Full State Machine** for larger features.

### Choosing the Right Flow: Small vs. Large Requests

The `spex` skill automatically evaluates your request to decide which path to take. Here’s how it differentiates:

| Request Type | Criteria | Examples |
| :--- | :--- | :--- |
| **Small** | Affects a single file, is an unambiguous bug fix, or a minor cosmetic change with no architectural impact. | "Fix the typo on the login button."<br>"Adjust the margin on the user profile card."<br>"Refactor this function to be more readable." |
| **Large** | Involves multiple files, introduces new functionality, requires architectural decisions, or is ambiguous. | "Build a new settings page."<br>"Implement two-factor authentication."<br>"Redesign the data processing pipeline." |

### A. The Lightweight Flow (for Small Requests)

This flow is designed to be fast, efficient, and minimally intrusive for everyday tasks. It skips the heavy planning phase but ensures code quality and knowledge retention.

#### When to Use

You should use the lightweight flow for small, self-contained changes. Simply state your request directly.

**Example Invocations:**
*   `"Fix the bug where the user's name doesn't update in the header."`
*   `"Change the primary button color to the new brand blue."`
*   `"Add a loading spinner while the data is fetching."`

#### How It Works

1.  **Research Memory:** It checks Spex's memory for existing policies or decisions to ensure compliance.
2.  **Execute Directly:** It performs the change using Test-Driven Development (TDD) where applicable.
3.  **Memorize (Capture Knowledge):** After completion, it automatically extracts requirements and decisions and saves them to memory.

**Important:** This flow does **not** create a feature folder (`.spex/<feature-name>`). It keeps your repository clean for small, tactical changes.

### B. The Full State Machine (for Large Requests)

This is a structured, traceable workflow for building new features and handling complex changes. It ensures that all decisions are deliberate, grounded in evidence, and documented.

#### When to Use

You should use the full state machine for any significant piece of work.

**Example Invocations:**
*   `"spex, let's build a new feature: user-to-user direct messaging."`
*   `"I need to add support for Google authentication. Use spex for planning."`
*   `"Plan and implement a dashboard for viewing analytics."`

#### How It Works

The full flow moves through a series of states, creating a dedicated folder at `.spex/<feature-name>/` to track all artifacts.

1.  **`INIT` → `RESEARCH`:** The agent researches your current codebase and its own memory to gather all relevant context and identify potential conflicts.
2.  **`GENERATE_PLAN`:** Based on the research, it generates a detailed, step-by-step implementation plan.
3.  **`REVIEWING_PLAN` (Human Checkpoint):** You are presented with the plan for review. You have the final say and must approve it before work begins. This is where you make the key architectural and structural decisions.
4.  **`COMPILING_TASKS` → `EXECUTE`:** Once you approve the plan, the agent breaks it down into executable tasks and begins implementing them one by one.
5.  **`AUDITING`:** After each task, the agent audits the code changes against the approved plan to ensure there is no scope creep. **This step is mandatory and cannot be skipped.**
6.  **`COMPLETE`:** Once all tasks are executed and audited, the feature is complete. The agent proposes a final summary.

### C. (See Section 4 for Knowledge Capture)
This functionality has been promoted to its own main section below.

---

## 3. `spex-reflect`: Improving Future Work

The `spex-reflect` skill is a powerful tool for continuous improvement. It analyzes completed features to extract learnings and propose reusable policies.

### When to Use

You should use this skill **manually** after a feature has been marked as `COMPLETE` by the `spex` skill.

**Example Invocations:**
*   `"spex reflect"`
*   `"use spex to reflect on this feature"`
*   `"analyze this feature and propose policies"`

### How It Works

1.  **Gather Context:** It reviews the entire feature history: the plan, decisions made, audit results, and execution traces.
2.  **Analyze Learnings:** It identifies what went well (e.g., accurate planning) and what didn't (e.g., scope creep, conflicts).
3.  **Evaluate Decisions:** It assesses the architectural and structural decisions for quality and impact.
4.  **Propose Policies:** It identifies recurring patterns and proposes them as **Policies** (standing rules) to guide future development.
5.  **Persist:** Upon your approval, it saves these policies to Spex's memory, making the agent "smarter" for the next task.

---

## 4. Knowledge Capture: Teaching the Agent

Separate from feature development, you can use `spex` to "teach" the agent at any time. This captures Requirements, Decisions, and Policies directly into memory.

### A. Learning from Conversation

Capture decisions or requirements that emerge dynamically during a chat.

**When to Use:**
*   You just made a verbal decision in the chat (e.g., "Let's always use strict typing").
*   You want to record a requirement found during debugging.

**Example Invocations:**
*   `"spex memorize this conversation"`
*   `"capture this decision"`
*   `"spex, record that we decided to use red for all error states"`

**How It Works:**
The agent scans the recent conversation, extracts structured items (Requirements, Decisions), presents them for your review, and saves them.

### B. Learning from Documentation

Teach the agent by having it read existing files.

**When to Use:**
*   You have an `ARCHITECTURE.md` or `API_GUIDELINES.md` file.
*   You want to ingest a project spec or requirements document.

**Example Invocations:**
*   `"spex learn from docs/auth-flow.md"`
*   `"teach spex via README.md"`
*   `"analyze infrastructure.md for policies"`

**How It Works:**
1.  **Read:** The agent reads the specified file.
2.  **Extract:** It identifies User Requirements (UR), Functional Requirements (FR), Non-Functional Requirements (NFR), and technical Decisions.
3.  **Review:** It presents these items to you for confirmation.
4.  **Save:** Once approved, they are persisted to Spex memory, making that document's knowledge available to all future workflows.