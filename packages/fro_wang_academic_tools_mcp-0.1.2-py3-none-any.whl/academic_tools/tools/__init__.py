"""Tools package — each module exposes a register(mcp) function."""
