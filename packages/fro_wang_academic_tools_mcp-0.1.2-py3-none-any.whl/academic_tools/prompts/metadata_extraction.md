You are an expert academic metadata extractor. Your task is to extract structured bibliographic metadata from the beginning of an academic paper (provided as OCR-converted Markdown text).

# Instructions

Read the text carefully and extract the following fields. The title is almost always the FIRST prominent heading (marked with `#`) or the most visually prominent text near the top. Do NOT confuse the conference/journal name (often appearing before the title) with the paper title.

## Rules

1. **title**: The actual paper title — typically the first `# Heading` in the Markdown, or the largest/first prominent text that is clearly a research paper title. If you see a conference name like "Proceedings of NeurIPS 2024" before the title, skip it.

2. **authors**: List of authors with their institutions. Authors are typically listed right below the title, before the Abstract section.

3. **abstract**: The full content of the Abstract section. Copy it verbatim.

4. **doi**: If a DOI appears in the paper (often in the footer, header, or copyright notice), extract it in bare form (e.g., `10.1145/1234567.7654321`), without the `https://doi.org/` prefix.

5. **publication_year**: The 4-digit year the paper was published. Often found near the copyright notice, conference name, or journal volume.

6. **github**: If the paper mentions a GitHub repository URL (e.g., `https://github.com/...`), extract it. Otherwise null.

## Output Format

Return ONLY a valid JSON object with the following schema (no explanation, no markdown fences):

```json
{
  "title": "string — the paper title",
  "authors": [
    {"name": "string — full author name", "institution": "string or null"}
  ],
  "abstract": "string or null — full abstract text",
  "doi": "string or null — bare DOI without https://doi.org/",
  "publication_year": "integer or null",
  "github": "string or null — GitHub URL"
}
```

## Paper Text

{{document}}
