"""
Group Decision Making via the Combinatorial Method.

Aggregates pairwise comparison matrices from multiple experts,
weighted by their competence coefficients.
"""

from concurrent.futures import ProcessPoolExecutor
from typing import Callable, List

import numpy as np

from .aggregation import weighted_geometric_mean
from .combinatorial import (
    _process_prufer_range,
    calculate_work_distribution,
    smart_worker_count,
)
from .helpers import is_connected, is_full
from .llsm import llsm_incomplete


def group_combinatorial_method(
    matrices: List[np.ndarray],
    competences: List[float] | None = None,
    n_workers: int | Callable = smart_worker_count,
    aggregator: Callable = weighted_geometric_mean,
) -> np.ndarray:
    """
    Group combinatorial method aggregating multiple experts' matrices.

    Each expert's spanning-tree quality is scaled by their competence
    coefficient, then all vectors from all experts are aggregated together.

    Args:
        matrices: List of m expert pairwise comparison matrices (all n x n).
        competences: Weights per expert, summing to 1.0. If None, equal weights.
        n_workers: Number of parallel workers or a callable(n) -> int.
        aggregator: Function to aggregate (vector, quality) tuples.

    Returns:
        Final group priority vector.
    """
    m = len(matrices)
    if m == 0:
        raise ValueError("At least one matrix is required.")

    n = matrices[0].shape[0]
    for k, A in enumerate(matrices):
        if A.shape != (n, n):
            raise ValueError(
                f"Matrix {k} has shape {A.shape}, expected ({n}, {n})."
            )

    # Competence weights
    if competences is None:
        competences = [1.0 / m] * m
    else:
        if len(competences) != m:
            raise ValueError(
                f"competences length {len(competences)} != number of matrices {m}."
            )
        if any(c < 0 or c > 1 for c in competences):
            raise ValueError("Each competence must be in [0, 1].")
        if abs(sum(competences) - 1.0) > 1e-6:
            raise ValueError(
                f"competences must sum to 1.0, got {sum(competences):.6f}."
            )

    # Pre-process incomplete matrices
    processed: List[np.ndarray] = []
    for k, A in enumerate(matrices):
        if is_full(A):
            processed.append(A)
        else:
            if not is_connected(A):
                raise ValueError(
                    f"Matrix {k} is incomplete and not connected; cannot fill."
                )
            _, A_filled = llsm_incomplete(A)
            processed.append(A_filled)

    # Work distribution (same n for every matrix)
    num_workers = n_workers(n) if callable(n_workers) else n_workers
    work_distribution = calculate_work_distribution(n, num_workers)

    # Serialize matrices
    serialized = [A.astype(np.float64).tobytes() for A in processed]

    # Submit all tasks across all experts in a single pool
    all_results: list[tuple[np.ndarray, float]] = []

    if num_workers == 1:
        for k in range(m):
            c_k = competences[k]
            for prefixes in work_distribution:
                results = _process_prufer_range(prefixes, serialized[k], n, "default")
                for vec, quality in results:
                    all_results.append((vec, quality * c_k))
    else:
        with ProcessPoolExecutor(max_workers=num_workers) as executor:
            futures: list[tuple[int, object]] = []
            for k in range(m):
                for prefixes in work_distribution:
                    future = executor.submit(
                        _process_prufer_range, prefixes, serialized[k], n, "default"
                    )
                    futures.append((k, future))

            for k, future in futures:
                c_k = competences[k]
                results = future.result()
                for vec, quality in results:
                    all_results.append((vec, quality * c_k))

    return aggregator(all_results)
