__version__ = "0.0.1"

import os
from importlib import resources

from .launcher import UnityLauncher, UnityFinder
from .scene_builder import SceneBuilder


def deploy_template(filename: str, output_path: str) -> str:
    """Copy a bundled C# template to a Unity project.

    Parameters:
        filename: Template name inside ``unitytk/templates/`` (e.g. ``RenderOpacityController.cs``).
        output_path: Destination path (e.g. ``Assets/Scripts/RenderOpacityController.cs``).

    Returns:
        str: Absolute path of the written file.
    """
    ref = resources.files("unitytk.templates").joinpath(filename)
    content = ref.read_text(encoding="utf-8")

    output_dir = os.path.dirname(output_path)
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(content)

    return os.path.abspath(output_path)
