// ----------------------------------------------------------------------------
// IMPORTANT: Deploy to Assets/ root (or any non-Editor subfolder).
//            Placing this file in Assets/Editor/ will strip the MonoBehaviour
//            from the runtime assembly, breaking animation curve bindings.
// ----------------------------------------------------------------------------
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
using System;
using System.Collections.Generic;
#endif

/// <summary>
/// Drives per-object opacity from a Maya "RenderOpacity" FBX custom attribute.
///
/// Runtime behaviour:
///   - Applies <see cref="opacity"/> to the Renderer via MaterialPropertyBlock
///     (no material instances, SRP-Batcher safe).
///   - Disables the Renderer entirely when fully transparent (zero draw-call cost).
///   - Clears overrides automatically when the component is removed or disabled.
///
/// Editor automation (requires no extra setup):
///   - On FBX import: detects the "opacity" custom attribute, adds this
///     component, and rewires the animation curve to drive it.
///   - Menu: Tools &gt; Render Opacity &gt; Fix Scene Objects — retroactively
///     patches objects that were imported before this script existed.
/// </summary>
[AddComponentMenu("Rendering/Render Opacity Controller")]
[DisallowMultipleComponent]
[RequireComponent(typeof(Renderer))]
public class RenderOpacityController : MonoBehaviour
{
    // ------------------------------------------------------------------ Fields

    [Tooltip("Driven by the Animator via the FBX custom-property curve.")]
    [Range(0f, 1f)]
    public float opacity = 1f;

    [Tooltip("Shader color property whose alpha channel is overridden " +
             "(e.g. _BaseColor for URP/HDRP, _Color for Built-in).")]
    public string colorProperty = "_BaseColor";

    private Renderer _rend;
    private MaterialPropertyBlock _block;
    private int _propID;
    private float _prevOpacity = -1f;   // force first-frame update
    private bool _weDisabledRenderer;   // track ownership of enabled state

    // ----------------------------------------------------------- Lifecycle

    void OnEnable()
    {
        _rend = GetComponent<Renderer>();
        _block = new MaterialPropertyBlock();
        _propID = Shader.PropertyToID(colorProperty);
        _prevOpacity = -1f;
        _weDisabledRenderer = false;
    }

#if UNITY_EDITOR
    /// <summary>Auto-detect the correct color property for the assigned material.</summary>
    void Reset()
    {
        var mat = GetComponent<Renderer>()?.sharedMaterial;
        if (mat != null && mat.HasProperty("_Color") && !mat.HasProperty("_BaseColor"))
            colorProperty = "_Color";
    }
#endif

    void OnDisable()
    {
        ClearOverrides();
    }

    // ------------------------------------------------------------ Core Loop

    void LateUpdate()
    {
        if (_rend == null) return;

        // Clamp to valid range (Animator curves can overshoot)
        opacity = Mathf.Clamp01(opacity);

        // Skip work when nothing changed
        if (Mathf.Approximately(opacity, _prevOpacity)) return;
        _prevOpacity = opacity;

        // --- Auto-hide at zero opacity (matches Maya condition-node behaviour) ---
        if (opacity <= 0f)
        {
            if (_rend.enabled)
            {
                _rend.enabled = false;
                _weDisabledRenderer = true;
            }
            return;
        }

        // Restore visibility only if WE disabled it (don't fight other systems)
        if (_weDisabledRenderer)
        {
            _rend.enabled = true;
            _weDisabledRenderer = false;
        }

        // --- Apply alpha via PropertyBlock ---
        if (_rend.sharedMaterial == null || !_rend.sharedMaterial.HasProperty(_propID))
            return;

        _rend.GetPropertyBlock(_block);
        Color c = _rend.sharedMaterial.GetColor(_propID);
        c.a = opacity;
        _block.SetColor(_propID, c);
        _rend.SetPropertyBlock(_block);
    }

    // ----------------------------------------------------------- Cleanup

    /// <summary>Remove all overrides so the Renderer reverts to its original material state.</summary>
    private void ClearOverrides()
    {
        if (_rend == null) return;

        // Restore visibility if we hid it
        if (_weDisabledRenderer)
        {
            _rend.enabled = true;
            _weDisabledRenderer = false;
        }

        // Clear the PropertyBlock so the material's native alpha is restored
        _block?.Clear();
        _rend.SetPropertyBlock(_block);
    }
}

// ====================================================================
//  Editor-only: import automation and retroactive fix tools
// ====================================================================
#if UNITY_EDITOR

/// <summary>
/// Shared allowlist that controls which FBX files the importers process.
///
/// Place <c>maya_fbx_import_config.json</c> anywhere under <c>Assets/</c>
/// (e.g. <c>Assets/maya_fbx_import_config.json</c> or
/// <c>Assets/MyPackage/maya_fbx_import_config.json</c>).  The first copy
/// found wins.  Format:
/// <code>
/// {
///   "allowed_fbx": [
///     "C130_FCR_Speedrun_Assembly_copy.fbx",
///     "MyOtherScene.fbx"
///   ]
/// }
/// </code>
///
/// Rules:
///   - If the file is missing or empty, ALL .fbx files are processed (default).
///   - Entries are filename-only (no path), matched case-insensitively.
///   - Non-.fbx assets are always rejected.
/// </summary>
public static class ImportAllowlist
{
    const string CONFIG_FILENAME = "maya_fbx_import_config.json";

    static string[] _cache;
    static double _cacheTime;

    public static bool IsAllowed(string assetPath)
    {
        if (!assetPath.EndsWith(".fbx", System.StringComparison.OrdinalIgnoreCase))
            return false;

        var list = GetList();
        if (list == null || list.Length == 0)
            return true;  // no config → process everything

        string filename = System.IO.Path.GetFileName(assetPath);
        foreach (var entry in list)
        {
            if (string.Equals(entry, filename,
                    System.StringComparison.OrdinalIgnoreCase))
                return true;
        }
        return false;
    }

    /// <summary>
    /// Read and cache the allowlist.  Re-reads if the file changed
    /// (checked every 5 seconds to avoid disk thrash during batch imports).
    /// </summary>
    static string[] GetList()
    {
        double now = EditorApplication.timeSinceStartup;
        if (_cache != null && now - _cacheTime < 5.0)
            return _cache;

        _cacheTime = now;

        // Search anywhere under Assets/ for the config file
        string configPath = FindConfig();
        if (string.IsNullOrEmpty(configPath))
        {
            _cache = new string[0];
            return _cache;
        }

        try
        {
            string json = System.IO.File.ReadAllText(configPath);
            _cache = ParseAllowedFbx(json);
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"[ImportAllowlist] Failed to read {configPath}: {e.Message}");
            _cache = new string[0];
        }
        return _cache;
    }

    /// <summary>
    /// Locate the config file anywhere under Assets/.
    /// Returns the full filesystem path, or null if not found.
    /// </summary>
    static string FindConfig()
    {
        string projectRoot = System.IO.Directory.GetCurrentDirectory();
        string assetsDir = System.IO.Path.Combine(projectRoot, "Assets");

        // Quick check at Assets/ root first (most common location)
        string rootPath = System.IO.Path.Combine(assetsDir, CONFIG_FILENAME);
        if (System.IO.File.Exists(rootPath))
            return rootPath;

        // Recursive search under Assets/
        try
        {
            var matches = System.IO.Directory.GetFiles(
                assetsDir, CONFIG_FILENAME,
                System.IO.SearchOption.AllDirectories);
            if (matches.Length > 1)
                Debug.LogWarning(
                    $"[ImportAllowlist] Found {matches.Length} copies of "
                    + $"{CONFIG_FILENAME} — using {matches[0]}. "
                    + "Remove duplicates to avoid ambiguity.");
            if (matches.Length > 0)
                return matches[0];
        }
        catch (System.Exception) { }

        return null;
    }

    /// <summary>
    /// Extract string values from the "allowed_fbx" JSON array.
    /// Handles simple JSON without a full parser.
    /// </summary>
    static string[] ParseAllowedFbx(string json)
    {
        // Find the array after "allowed_fbx"
        int keyIdx = json.IndexOf("\"allowed_fbx\"",
            System.StringComparison.OrdinalIgnoreCase);
        if (keyIdx < 0) return new string[0];

        int bracketOpen = json.IndexOf('[', keyIdx);
        if (bracketOpen < 0) return new string[0];

        int bracketClose = json.IndexOf(']', bracketOpen);
        if (bracketClose < 0) return new string[0];

        string inner = json.Substring(bracketOpen + 1,
            bracketClose - bracketOpen - 1);

        var result = new System.Collections.Generic.List<string>();
        int i = 0;
        while (i < inner.Length)
        {
            int qOpen = inner.IndexOf('"', i);
            if (qOpen < 0) break;
            int qClose = inner.IndexOf('"', qOpen + 1);
            if (qClose < 0) break;

            string val = inner.Substring(qOpen + 1, qClose - qOpen - 1).Trim();
            if (val.Length > 0)
                result.Add(val);
            i = qClose + 1;
        }
        return result.ToArray();
    }

    /// <summary>Force re-read on next call (e.g. after editing the config).</summary>
    public static void InvalidateCache() { _cache = null; }
}

/// <summary>
/// AssetPostprocessor that fires on every FBX import.
/// Detects the Maya "opacity" custom attribute and wires it up automatically.
///
/// Unity limitation: importAnimatedCustomProperties imports all custom-property
/// animation curves with empty paths (bound to root Animator). When multiple
/// objects share the same attribute name ("opacity"), they collapse into
/// duplicate root-level bindings that cannot be distinguished per-object.
///
/// Workaround: Maya scenes typically wire opacity→condition→visibility, so the
/// FBX also contains per-object Visibility curves that Unity imports as
/// m_Enabled@Renderer with correct hierarchy paths. This importer reconstructs
/// smooth opacity fades from those boolean visibility transitions and binds them
/// to the correct child RenderOpacityController components.
/// </summary>
public class RenderOpacityImporter : AssetPostprocessor
{
    const string ATTR_NAME = "opacity";
    const float FADE_DURATION = 0.5f;  // seconds for synthesised 0→1 / 1→0 ramp

    /// <summary>Returns true when this asset should be processed.</summary>
    bool ShouldProcess() => ImportAllowlist.IsAllowed(assetPath);

    // Tracks transforms with the opacity attribute during import.
    // Keyed by assetPath to avoid cross-import contamination.
    // We store Transform refs (not paths) because go.transform.root is
    // unreliable during OnPostprocessGameObjectWithUserProperties.
    // Correct paths are computed later via the root parameter.
    static readonly Dictionary<string, HashSet<Transform>> _opacityTransforms =
        new Dictionary<string, HashSet<Transform>>();

    // --- Step 0: Enable animated custom-property import -----------------------

    void OnPreprocessModel()
    {
        if (!ShouldProcess()) return;

        var importer = assetImporter as ModelImporter;
        if (importer != null && !importer.importAnimatedCustomProperties)
            importer.importAnimatedCustomProperties = true;
    }

    // --- Step 1: Record opacity transforms ------------------------------------
    //
    // Just record the transform.  Component addition is deferred to
    // EnsureControllers (called in Step 2 / Step 3) because child Renderers
    // haven't been created yet at this stage.

    void OnPostprocessGameObjectWithUserProperties(
        GameObject go, string[] propNames, object[] values)
    {
        if (!ShouldProcess()) return;

        for (int i = 0; i < propNames.Length; i++)
        {
            if (!string.Equals(propNames[i], ATTR_NAME,
                    StringComparison.OrdinalIgnoreCase))
                continue;

            if (!_opacityTransforms.ContainsKey(assetPath))
                _opacityTransforms[assetPath] = new HashSet<Transform>();
            _opacityTransforms[assetPath].Add(go.transform);
            return;
        }
    }

    // --- Step 2: Rebuild per-object opacity curves ----------------------------
    //
    // Unity flattens custom-property curves to the root with empty paths.
    // We cannot reliably map those anonymous curves back to individual objects.
    // Instead, we:
    //   a) Remove the useless root-level opacity@Animator duplicates.
    //   b) For each m_Enabled@Renderer curve whose target is in our opacity
    //      path set, synthesise a smooth opacity fade from the boolean
    //      visibility transitions and bind it to RenderOpacityController.
    //   c) Remove the m_Enabled@Renderer curve for those objects (the
    //      controller handles visibility via its auto-hide-at-zero logic).

    void OnPostprocessAnimation(GameObject root, AnimationClip clip)
    {
        if (!ShouldProcess()) return;

        var opaPaths = EnsureControllers(assetPath, root.transform);
        if (opaPaths.Count == 0) return;

        var bindings = AnimationUtility.GetCurveBindings(clip);

        // --- (a) Remove all root-level opacity@Animator duplicates -----------
        int removedRoot = 0;
        foreach (var b in bindings)
        {
            if (b.propertyName == ATTR_NAME &&
                b.type != typeof(RenderOpacityController))
            {
                AnimationUtility.SetEditorCurve(clip, b, null);
                removedRoot++;
            }
        }

        // --- (b) + (c) Convert m_Enabled → smooth opacity --------------------
        bindings = AnimationUtility.GetCurveBindings(clip);
        int synthesised = 0;

        foreach (var b in bindings)
        {
            if (b.propertyName != "m_Enabled") continue;
            if (b.type != typeof(Renderer))    continue;

            // Direct match only — opaPaths contains every Renderer path
            // that descends from an opacity-attributed LOC.  Walk-up would
            // false-match non-opacity children of opacity ancestors.
            if (!opaPaths.Contains(b.path)) continue;

            var enabledCurve = AnimationUtility.GetEditorCurve(clip, b);
            if (enabledCurve == null || enabledCurve.length == 0) continue;

            var opacityCurve = BoolToFadeCurve(enabledCurve, FADE_DURATION);

            // Bind to the same object (it now has a RenderOpacityController)
            var newBinding = EditorCurveBinding.FloatCurve(
                b.path,
                typeof(RenderOpacityController),
                ATTR_NAME
            );
            AnimationUtility.SetEditorCurve(clip, newBinding, opacityCurve);
            AnimationUtility.SetEditorCurve(clip, b, null);
            synthesised++;
        }

        if (removedRoot > 0 || synthesised > 0)
        {
            Debug.Log($"[RenderOpacity] {assetPath}: removed {removedRoot} " +
                      $"root curves, synthesised {synthesised} fade curves " +
                      $"({opaPaths.Count} Renderers with controller).");
        }
    }

    // --- Step 3: Cleanup + fallback propagation for static models --------------

    void OnPostprocessModel(GameObject root)
    {
        if (!ShouldProcess()) { _opacityTransforms.Remove(assetPath); return; }

        // Ensure controllers exist even if the model had no animation clips
        // (OnPostprocessAnimation would not have fired in that case).
        EnsureControllers(assetPath, root.transform);
        _opacityTransforms.Remove(assetPath);
    }

    // ----------------------------------------------------------------- Helpers

    /// <summary>
    /// Add <see cref="RenderOpacityController"/> to every Renderer that
    /// descends from a recorded opacity transform.  Returns the set of
    /// animation-path strings for those Renderers.
    /// Idempotent — safe to call from both OnPostprocessAnimation and
    /// OnPostprocessModel.
    /// </summary>
    static HashSet<string> EnsureControllers(string asset, Transform root)
    {
        var paths = new HashSet<string>();
        if (!_opacityTransforms.TryGetValue(asset, out var transforms))
            return paths;

        // Snapshot to avoid issues if the set is ever mutated during iteration.
        foreach (var t in new List<Transform>(transforms))
        {
            // GetComponentsInChildren(true) includes 't' itself when it
            // has a Renderer, so LOCs with and without geometry are
            // handled uniformly — no if/else needed.
            foreach (var rend in t.GetComponentsInChildren<Renderer>(true))
            {
                if (rend.GetComponent<RenderOpacityController>() == null)
                    rend.gameObject.AddComponent<RenderOpacityController>();
                paths.Add(AnimationUtility.CalculateTransformPath(
                    rend.transform, root));
            }
        }
        return paths;
    }

    /// <summary>
    /// Convert a baked boolean m_Enabled curve (hundreds of 0/1 keys) into a
    /// minimal-key smooth fade curve.  Only emits keys at actual transitions
    /// (0→1 or 1→0), producing ~4-8 keys instead of ~580.
    /// Each transition is a linear ramp over <paramref name="fadeDuration"/>.
    /// </summary>
    static AnimationCurve BoolToFadeCurve(AnimationCurve enabled, float fadeDuration)
    {
        var keys = enabled.keys;
        if (keys.Length == 0) return new AnimationCurve();

        var result = new List<Keyframe>();

        // Initial value
        float prevV = keys[0].value > 0.5f ? 1f : 0f;
        result.Add(new Keyframe(keys[0].time, prevV));

        // Scan for transitions — skip all holds
        for (int i = 1; i < keys.Length; i++)
        {
            float v = keys[i].value > 0.5f ? 1f : 0f;
            if (v == prevV) continue;

            // Transition: insert a linear ramp.
            // If two transitions are closer than fadeDuration, rampStart is
            // clamped to just after the previous key — the ramp compresses
            // and may collapse to an instant jump, which is physically correct.
            float t = keys[i].time;
            float rampStart = Mathf.Max(
                t - fadeDuration,
                result[result.Count - 1].time + 0.001f);

            // Start of ramp at old value (suppressed if gap is < 0.001s)
            if (rampStart < t - 0.001f)
                result.Add(new Keyframe(rampStart, prevV));

            // End of ramp at new value
            result.Add(new Keyframe(t, v));
            prevV = v;
        }

        // Final hold key so the curve spans the full clip length
        float lastT = keys[keys.Length - 1].time;
        if (lastT - result[result.Count - 1].time > 0.001f)
            result.Add(new Keyframe(lastT, prevV));

        var curve = new AnimationCurve(result.ToArray());

        // Linear tangents for predictable fades
        for (int i = 0; i < curve.length; i++)
        {
            AnimationUtility.SetKeyLeftTangentMode(
                curve, i, AnimationUtility.TangentMode.Linear);
            AnimationUtility.SetKeyRightTangentMode(
                curve, i, AnimationUtility.TangentMode.Linear);
        }
        return curve;
    }
}

/// <summary>
/// Editor utilities for retroactive project fixes.
/// </summary>
public static class RenderOpacityTools
{
    // --- Fix Scene Objects (already placed in a scene) -------------------------

    [MenuItem("Tools/Render Opacity/Fix Scene Objects")]
    static void FixSceneObjects()
    {
        int count = 0;
        // Find every Renderer in the loaded scenes (including inactive objects)
        foreach (var rend in Resources.FindObjectsOfTypeAll<Renderer>())
        {
            // Skip assets, prefabs, and hidden objects
            if (EditorUtility.IsPersistent(rend)) continue;
            if (rend.gameObject.hideFlags != HideFlags.None) continue;
            if (rend.GetComponent<RenderOpacityController>() != null) continue;

            // Case 1: ancestor already has a controller — child propagation
            // was missed by an older version of the importer.
            if (rend.GetComponentInParent<RenderOpacityController>() != null)
            {
                rend.gameObject.AddComponent<RenderOpacityController>();
                count++;
                continue;
            }

            // Case 2: root object with an Animator (first-time fix)
            var animator = rend.GetComponent<Animator>();
            if (animator != null && animator.runtimeAnimatorController != null)
            {
                rend.gameObject.AddComponent<RenderOpacityController>();
                count++;
            }
        }

        Debug.Log($"[RenderOpacity] Added controller to {count} scene object(s).");
    }

    // --- Re-import Selected Models (regenerates animation bindings) ------------

    [MenuItem("Tools/Render Opacity/Reimport Selected Models")]
    static void ReimportSelected()
    {
        int count = 0;
        foreach (var obj in Selection.objects)
        {
            string path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) continue;

            // Only reimport model assets
            if (AssetImporter.GetAtPath(path) is ModelImporter)
            {
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
                count++;
            }
        }
        Debug.Log($"[RenderOpacity] Reimported {count} model(s).");
    }
}

#endif


