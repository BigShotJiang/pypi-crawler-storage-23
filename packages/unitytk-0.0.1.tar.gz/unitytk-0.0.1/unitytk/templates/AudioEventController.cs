// ----------------------------------------------------------------------------
// IMPORTANT: Deploy to Assets/ root (or any non-Editor subfolder).
//            Placing this file in Assets/Editor/ will strip the MonoBehaviour
//            from the runtime assembly, breaking animation curve bindings.
// ----------------------------------------------------------------------------
using UnityEngine;
using System.Collections.Generic;

#if UNITY_EDITOR
using UnityEditor;
using System;
using System.Linq;
#endif

/// <summary>
/// Plays audio clips triggered by baked event manifests from Maya.
///
/// Runtime behaviour:
///   - Receives <see cref="AnimationEvent"/> callbacks from the Animator.
///   - Looks up the event name in the clip dictionary and plays the match.
///   - Zero per-frame polling -- events fire only when keyed.
///
/// Editor automation (requires no extra setup):
///   - On FBX import: detects "audio_manifest" custom attribute
///     (baked by EventTriggers.bake_manifest with category="audio"),
///     adds this component, parses the manifest, injects native
///     AnimationEvents onto the clip, and auto-populates the clip list.
/// </summary>
[AddComponentMenu("Audio/Audio Event Controller")]
[DisallowMultipleComponent]
[RequireComponent(typeof(AudioSource))]
public class AudioEventController : MonoBehaviour
{
    // ------------------------------------------------------------------ Fields

    [Tooltip("Ordered list of AudioClips. Dictionary is built at runtime " +
             "from clip filenames for O(1) lookup.")]
    public List<AudioClip> clips = new List<AudioClip>();

    [Tooltip("Volume multiplier for all clips played by this controller.")]
    [Range(0f, 1f)]
    public float volume = 1f;

    private AudioSource _source;
    private Dictionary<string, AudioClip> _clipMap;

    // ----------------------------------------------------------- Lifecycle

    void OnEnable()
    {
        _source = GetComponent<AudioSource>();

        // Build name -> clip lookup from the clips list
        _clipMap = new Dictionary<string, AudioClip>(
            System.StringComparer.OrdinalIgnoreCase);
        foreach (var clip in clips)
        {
            if (clip != null && !_clipMap.ContainsKey(clip.name))
                _clipMap[clip.name] = clip;
        }
    }

#if UNITY_EDITOR
    /// <summary>Set sensible AudioSource defaults when the component is first added.</summary>
    void Reset()
    {
        var src = GetComponent<AudioSource>();
        if (src != null)
        {
            src.playOnAwake = false;
            src.spatialBlend = 1f;  // 3D by default
        }
    }
#endif

    // --------------------------------------------------- Animation Event

    /// <summary>
    /// Called by Unity's AnimationEvent system.  The event's
    /// <c>stringParameter</c> is the event name from the baked manifest.
    /// </summary>
    public void OnAudioEvent(string eventName)
    {
        if (string.IsNullOrEmpty(eventName) ||
            string.Equals(eventName, "None", System.StringComparison.OrdinalIgnoreCase))
            return;

        if (_clipMap != null && _clipMap.TryGetValue(eventName, out var clip))
        {
            _source.PlayOneShot(clip, volume);
        }
        else
        {
            Debug.LogWarning(
                $"[AudioEvent] No clip mapped for '{eventName}' on {gameObject.name}");
        }
    }
}

// ====================================================================
//  Editor-only: import automation
// ====================================================================
#if UNITY_EDITOR

/// <summary>
/// AssetPostprocessor that fires on every FBX import.
/// Detects the Maya "audio_manifest" baked string attribute
/// (created by EventTriggers.bake_manifest with category="audio")
/// and wires up AnimationEvents automatically.
///
/// Manifest format: "12:Footstep,24:Jump,48:Land"
///   - frame:eventName pairs, comma-separated
///   - frame is relative to the animation clip start
/// </summary>
public class AudioEventImporter : AssetPostprocessor
{
    const string ATTR_MANIFEST = "audio_manifest";

    // Well-known audio folder names (checked as siblings of the FBX,
    // then at Assets/ root, then whole-project fallback)
    static readonly string[] AUDIO_FOLDER_NAMES = new string[]
    {
        "Audio", "Sounds", "SFX",
    };

    /// <summary>
    /// Build the audio search directories dynamically so that all files
    /// can live in any subfolder together.
    ///
    /// Order: FBX's own folder → Audio/Sounds/SFX siblings of FBX
    ///      → Assets/Audio, Assets/Sounds, Assets/SFX
    ///      → Assets (whole project fallback)
    /// </summary>
    static string[] GetAudioSearchDirs(string fbxAssetPath)
    {
        var dirs = new System.Collections.Generic.List<string>();

        if (!string.IsNullOrEmpty(fbxAssetPath))
        {
            // Parent folder of the FBX (e.g. "Assets/C130_Package")
            string fbxDir = System.IO.Path.GetDirectoryName(fbxAssetPath)
                                         .Replace('\\', '/');
            if (AssetDatabase.IsValidFolder(fbxDir))
                dirs.Add(fbxDir);

            // Well-known audio sub-folders next to the FBX
            foreach (var name in AUDIO_FOLDER_NAMES)
            {
                string sibling = fbxDir + "/" + name;
                if (AssetDatabase.IsValidFolder(sibling))
                    dirs.Add(sibling);
            }
        }

        // Global well-known dirs at Assets/ root
        foreach (var name in AUDIO_FOLDER_NAMES)
        {
            string global = "Assets/" + name;
            if (!dirs.Contains(global) && AssetDatabase.IsValidFolder(global))
                dirs.Add(global);
        }

        // Whole-project fallback
        if (!dirs.Contains("Assets"))
            dirs.Add("Assets");

        return dirs.ToArray();
    }

    // --- Step 0: Enable user-property and animated-property import ------

    /// <summary>Returns true when this asset should be processed.</summary>
    bool ShouldProcess() => ImportAllowlist.IsAllowed(assetPath);

    void OnPreprocessModel()
    {
        if (!ShouldProcess()) return;

        var importer = assetImporter as ModelImporter;
        if (importer != null && !importer.importAnimatedCustomProperties)
            importer.importAnimatedCustomProperties = true;
    }

    // --- Step 1: Detect manifest and add component ----------------------

    void OnPostprocessGameObjectWithUserProperties(
        GameObject go, string[] propNames, object[] values)
    {
        if (!ShouldProcess()) return;

        string manifest = null;

        for (int i = 0; i < propNames.Length; i++)
        {
            if (string.Equals(propNames[i], ATTR_MANIFEST,
                    StringComparison.OrdinalIgnoreCase))
                manifest = values[i] as string;
        }

        if (string.IsNullOrEmpty(manifest)) return;

        // Ensure component exists
        var controller = go.GetComponent<AudioEventController>();
        if (controller == null)
            controller = go.AddComponent<AudioEventController>();

        // Parse manifest and populate clips
        var entries = ParseManifest(manifest);
        var uniqueNames = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
        if (controller.clips == null)
            controller.clips = new List<AudioClip>();
        controller.clips.Clear();

        foreach (var entry in entries)
        {
            if (uniqueNames.Add(entry.eventName))
            {
                AudioClip clip = FindAudioClip(entry.eventName, assetPath);
                controller.clips.Add(clip);

                if (clip != null)
                    Debug.Log($"[AudioEvent] Matched '{entry.eventName}' -> " +
                              $"{AssetDatabase.GetAssetPath(clip)}");
                else
                    Debug.LogWarning($"[AudioEvent] No AudioClip found for " +
                                    $"'{entry.eventName}' -- assign manually.");
            }
        }

        // Store parsed entries for OnPostprocessAnimation to consume.
        // Keyed by assetPath to prevent cross-import contamination when
        // Unity imports multiple FBX files simultaneously.
        if (!_pendingManifests.ContainsKey(assetPath))
            _pendingManifests[assetPath] = new Dictionary<int, List<ManifestEntry>>();
        _pendingManifests[assetPath][go.GetInstanceID()] = entries;
    }

    // --- Step 2: Inject AnimationEvents onto clips ----------------------

    // Temporary storage to pass data between postprocessor phases.
    // Outer key = assetPath, inner key = GameObject instance ID.
    // Cleaned up in OnPostprocessModel to prevent leaks when
    // OnPostprocessAnimation doesn't fire (e.g. static FBX).
    static readonly Dictionary<string, Dictionary<int, List<ManifestEntry>>>
        _pendingManifests =
            new Dictionary<string, Dictionary<int, List<ManifestEntry>>>();

    void OnPostprocessAnimation(GameObject root, AnimationClip clip)
    {
        if (!ShouldProcess()) return;

        // Check all children for pending manifests
        var controllers = root.GetComponentsInChildren<AudioEventController>(true);
        if (controllers == null || controllers.Length == 0) return;

        var existingEvents = new List<AnimationEvent>(
            AnimationUtility.GetAnimationEvents(clip));
        bool modified = false;

        foreach (var controller in controllers)
        {
            int id = controller.gameObject.GetInstanceID();
            Dictionary<int, List<ManifestEntry>> assetManifests;
            if (!_pendingManifests.TryGetValue(assetPath, out assetManifests))
                continue;
            if (!assetManifests.TryGetValue(id, out var entries))
                continue;

            float frameRate = clip.frameRate > 0 ? clip.frameRate : 30f;

            foreach (var entry in entries)
            {
                float time = entry.frame / frameRate;

                // Skip if event already exists at this time (case-insensitive
                // to match the runtime _clipMap lookup).
                bool duplicate = existingEvents.Exists(
                    e => Mathf.Approximately(e.time, time) &&
                         string.Equals(e.stringParameter, entry.eventName,
                             System.StringComparison.OrdinalIgnoreCase));
                if (duplicate) continue;

                var evt = new AnimationEvent
                {
                    time = time,
                    functionName = "OnAudioEvent",
                    stringParameter = entry.eventName,
                };
                existingEvents.Add(evt);
                modified = true;

                Debug.Log($"[AudioEvent] Added event '{entry.eventName}' " +
                          $"at frame {entry.frame} ({time:F3}s) on '{clip.name}'");
            }

            assetManifests.Remove(id);
        }

        if (modified)
        {
            AnimationUtility.SetAnimationEvents(
                clip, existingEvents.ToArray());
        }

        // Also remove any legacy audio_trigger curve bindings
        var bindings = AnimationUtility.GetCurveBindings(clip);
        foreach (var binding in bindings)
        {
            if (binding.propertyName == "audio_trigger")
            {
                AnimationUtility.SetEditorCurve(clip, binding, null);
                Debug.Log($"[AudioEvent] Removed legacy audio_trigger curve " +
                          $"from '{clip.name}'");
            }
        }
    }

    // --- Step 3: Cleanup static state for this asset --------------------

    void OnPostprocessModel(GameObject root)
    {
        if (!ShouldProcess()) { _pendingManifests.Remove(assetPath); return; }

        _pendingManifests.Remove(assetPath);
    }

    // --- Manifest parsing ------------------------------------------------

    struct ManifestEntry
    {
        public int frame;
        public string eventName;
    }

    static List<ManifestEntry> ParseManifest(string manifest)
    {
        var result = new List<ManifestEntry>();
        if (string.IsNullOrEmpty(manifest)) return result;

        // RemoveEmptyEntries handles trailing commas and double-commas
        var tokens = manifest.Split(
            new[] { ',' }, System.StringSplitOptions.RemoveEmptyEntries);

        foreach (var token in tokens)
        {
            var trimmed = token.Trim();
            int colonIdx = trimmed.IndexOf(':');
            if (colonIdx <= 0 || colonIdx >= trimmed.Length - 1) continue;

            var frameStr = trimmed.Substring(0, colonIdx);
            var eventName = trimmed.Substring(colonIdx + 1).Trim();

            if (int.TryParse(frameStr, out int frame) &&
                frame >= 0 &&
                !string.IsNullOrEmpty(eventName) &&
                !string.Equals(eventName, "None",
                    System.StringComparison.OrdinalIgnoreCase))
            {
                result.Add(new ManifestEntry { frame = frame, eventName = eventName });
            }
        }
        return result;
    }

    // --- Audio clip lookup -----------------------------------------------
    // Case-insensitive by default.  If the event name includes an
    // extension (e.g. "Footstep.wav"), both stem AND extension must
    // match.  Without an extension, any AudioClip whose stem matches
    // wins.  Set caseSensitive = true to require exact casing.

    static AudioClip FindAudioClip(string name, string fbxAssetPath = null,
                                     bool caseSensitive = false)
    {
        if (string.IsNullOrEmpty(name)) return null;
        if (string.Equals(name, "None", System.StringComparison.OrdinalIgnoreCase))
            return null;

        var cmp = caseSensitive
            ? System.StringComparison.Ordinal
            : System.StringComparison.OrdinalIgnoreCase;

        // Split off any extension the artist included (e.g. "Footstep.wav")
        string ext  = System.IO.Path.GetExtension(name);   // ".wav" or ""
        string stem = System.IO.Path.GetFileNameWithoutExtension(name);
        bool hasExt = !string.IsNullOrEmpty(ext);

        var searchDirs = GetAudioSearchDirs(fbxAssetPath);

        // Search by stem so Unity finds the asset regardless of extension
        string[] guids = AssetDatabase.FindAssets($"t:AudioClip {stem}", searchDirs);
        if (guids.Length == 0) return null;

        foreach (var guid in guids)
        {
            string path     = AssetDatabase.GUIDToAssetPath(guid);
            string fileStem = System.IO.Path.GetFileNameWithoutExtension(path);
            string fileExt  = System.IO.Path.GetExtension(path);

            bool stemMatch = string.Equals(fileStem, stem, cmp);

            if (hasExt)
            {
                // Stem AND extension must both match
                if (stemMatch && string.Equals(fileExt, ext, cmp))
                    return AssetDatabase.LoadAssetAtPath<AudioClip>(path);
            }
            else
            {
                // No extension: exact stem match wins immediately
                if (stemMatch)
                    return AssetDatabase.LoadAssetAtPath<AudioClip>(path);
            }
        }

        // No exact match found — return null so the artist assigns manually.
        // Partial/substring matches are intentionally NOT returned to avoid
        // silently wiring the wrong clip (e.g. "Land" -> "Landing").
        return null;
    }
}

/// <summary>
/// Editor utilities for retroactive project fixes.
/// </summary>
public static class AudioEventTools
{
    // --- Fix Scene Objects (already placed in a scene) -------------------------

    [MenuItem("Tools/Audio Events/Fix Scene Objects")]
    static void FixSceneObjects()
    {
        int count = 0;
        foreach (var animator in Resources.FindObjectsOfTypeAll<Animator>())
        {
            // Skip assets, prefabs, and hidden objects
            if (EditorUtility.IsPersistent(animator)) continue;
            if (animator.gameObject.hideFlags != HideFlags.None) continue;
            if (animator.runtimeAnimatorController == null) continue;
            if (animator.GetComponent<AudioEventController>() != null) continue;

            animator.gameObject.AddComponent<AudioEventController>();
            count++;
        }
        Debug.Log($"[AudioEvents] Added controller to {count} scene object(s)." +
            (count > 0 ? " Reimport FBX models to auto-populate clips," +
                " or assign AudioClips manually." : ""));
    }

    // --- Re-import Selected Models (regenerates animation bindings) ------------

    [MenuItem("Tools/Audio Events/Reimport Selected Models")]
    static void ReimportSelected()
    {
        int count = 0;
        foreach (var obj in Selection.objects)
        {
            string path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) continue;

            // Only reimport model assets
            if (AssetImporter.GetAtPath(path) is ModelImporter)
            {
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
                count++;
            }
        }
        Debug.Log($"[AudioEvents] Reimported {count} model(s).");
    }
}

#endif
