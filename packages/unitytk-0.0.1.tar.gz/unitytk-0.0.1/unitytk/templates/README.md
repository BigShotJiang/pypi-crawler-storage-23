# Maya → Unity FBX Import Templates

Two C# files that automatically wire up **opacity fades** and **audio events** when you import a Maya FBX into Unity. Zero configuration required.

---

## Setup (One Time)

1. Copy **all four files** into any folder under `Assets/` (e.g. `Assets/C130_Package/`):
   - `RenderOpacityController.cs`
   - `AudioEventController.cs`
   - `maya_fbx_import_config.json` *(optional — see below)*
   - Your FBX file(s)

2. Place audio files (MP3/WAV) either beside the FBX, in an `Audio/` subfolder next to it, or in `Assets/Audio/`.

3. **Do NOT** put the CS files in `Assets/Editor/` — they contain runtime components that must be in the build.

That's it. Everything can live in a single subfolder together.

### Optional: Limit to specific FBX files

By default the importers process **every FBX** in the project. To restrict them to only specific files, create `maya_fbx_import_config.json` **anywhere under `Assets/`** (it can be right next to the CS files):

```json
{
  "allowed_fbx": [
    "C130_FCR_Speedrun_Assembly_copy.fbx",
    "MyOtherScene.fbx"
  ]
}
```

- Entries are **filename only** (no folder path), matched case-insensitively.
- If the file is missing or the array is empty, all FBX files are processed (the default).
- Changes to the JSON are picked up automatically (no restart needed).

---

## Importing an FBX

1. Drop your FBX file into any folder under `Assets/`.
2. Drop the matching audio files (MP3/WAV) nearby — in the same folder, or an `Audio/` / `Sounds/` / `SFX/` subfolder next to the FBX.
3. Unity reimports automatically. When it finishes:
   - Objects with **opacity** attributes get a `RenderOpacityController` — they fade in/out during playback.
   - Objects with **audio_manifest** attributes get an `AudioEventController` — audio clips play at the keyed frames.

### How to verify it worked

1. Drag the FBX from the Project window into your Scene.
2. Select any child object — check the Inspector for:
   - **Render Opacity Controller** component (on objects that fade)
   - **Audio Event Controller** component (on objects that trigger audio)
3. Press **Play** — opacity fades and audio events should fire automatically.

---

## Retroactive Fix (Already-Imported FBX)

If the FBX was imported *before* these scripts existed in the project:

1. **Menu → Tools → Render Opacity → Reimport Selected Models**
   Select the FBX in the Project window first, then run this.

2. **Menu → Tools → Audio Events → Reimport Selected Models**
   Same — select the FBX, then run.

Or for objects already placed in a scene:

- **Menu → Tools → Render Opacity → Fix Scene Objects**
- **Menu → Tools → Audio Events → Fix Scene Objects**

---

## What These Files Do

| File | Runtime | On Import |
|---|---|---|
| `RenderOpacityController.cs` | Fades object alpha via MaterialPropertyBlock. Auto-hides at zero opacity. | Detects Maya `opacity` attribute, adds component, converts visibility curves to smooth fades. |
| `AudioEventController.cs` | Plays audio clips from AnimationEvent callbacks. | Detects Maya `audio_manifest` attribute, adds component, injects AnimationEvents, matches audio clips by name. |

### Maya Requirements

- **Opacity**: Objects need an `opacity` custom attribute (float, 0–1) wired through a condition node to visibility. Standard EventTriggers setup.
- **Audio**: Objects need an `audio_manifest` string attribute baked by `EventTriggers.bake_manifest(category="audio")`. Format: `"12:ClipName,24:OtherClip"` (frame:name pairs).

---

## Troubleshooting

| Problem | Fix |
|---|---|
| No components appear after import | Reimport: select FBX → Tools → Render Opacity → Reimport Selected Models |
| Audio clips show as "None" in Inspector | Make sure audio files are near the FBX (same folder, or `Audio/`/`Sounds/`/`SFX/` sibling folder) and file stems match the manifest event names exactly |
| Opacity doesn't fade (snaps on/off) | Check that the Maya scene has opacity→condition→visibility wiring, not just raw visibility keys |
| Objects invisible at start | Normal if opacity starts at 0 — they fade in at the keyed time during playback |
| Material alpha not changing | Check `colorProperty` on the component — should be `_BaseColor` (URP/HDRP) or `_Color` (Built-in) |
