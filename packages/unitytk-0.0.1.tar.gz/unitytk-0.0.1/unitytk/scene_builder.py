import os
import textwrap
import logging

logger = logging.getLogger(__name__)


class SceneBuilder:
    """
    Helper class to generate C# Editor scripts inside a Unity project.
    These scripts can then be executed via command line to build/setup scenes automatically.
    """

    CS_TEMPLATE = textwrap.dedent(
        r"""
    using UnityEngine;
    using UnityEditor;
    using UnityEditor.SceneManagement;
    using System.IO;

    public class {class_name}
    {{
        public static void Build()
        {{
            Debug.Log("Starting Scene Build...");
            
            // Create scene with default setup (Camera, Light)
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            
            // --- Custom Setup Code ---
            {custom_code}
            // -------------------------

            // Ensure directory exists
            string scenePath = "{scene_path}";
            Directory.CreateDirectory(Path.GetDirectoryName(scenePath));
            
            EditorSceneManager.SaveScene(scene, scenePath);
            Debug.Log($"Saved scene to: {{scenePath}}");
        }}
    }}
    """
    )

    def __init__(self, project_path: str):
        """
        Args:
            project_path: Absolute path to the Unity project root.
        """
        self.project_path = project_path
        self.editor_path = os.path.join(self.project_path, "Assets", "Editor")

    def install_builder_script(
        self,
        setup_code: str,
        scene_output_path: str = "Assets/Scenes/TestScene.unity",
        class_name: str = "AutoSceneBuilder",
    ) -> str:
        """
        Generates and saves a C# script to Assets/Editor/ that can build the scene.

        Args:
            setup_code: The C# code body to execute for scene setup.
            scene_output_path: Where the resulting .unity file should be saved (relative to Project).
            class_name: Name of the C# class (must be unique if multiple builders exist).

        Returns:
            str: The method signature to call via CLI (e.g. 'AutoSceneBuilder.Build').
        """
        if not os.path.exists(self.editor_path):
            os.makedirs(self.editor_path)

        script_content = self.CS_TEMPLATE.format(
            class_name=class_name, custom_code=setup_code, scene_path=scene_output_path
        )

        script_file = os.path.join(self.editor_path, f"{class_name}.cs")
        try:
            with open(script_file, "w") as f:
                f.write(script_content)
            logger.info(f"Installed builder script: {script_file}")
        except Exception as e:
            logger.error(f"Failed to write builder script: {e}")
            raise

        return f"{class_name}.Build"
