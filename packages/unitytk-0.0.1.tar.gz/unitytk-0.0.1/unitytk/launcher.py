import os
import platform
import glob
import logging
from typing import Optional, List, Dict, Union
import subprocess

try:
    from pythontk import AppLauncher
except ImportError:
    # Fallback for when pythontk is not fully bootstrapped or direct import needed
    from pythontk.core_utils.app_launcher import AppLauncher

logger = logging.getLogger(__name__)


class UnityFinder:
    """Helper class to locate Unity installations."""

    @staticmethod
    def get_hub_editor_path() -> Optional[str]:
        """Returns the default Unity Hub Editor installation directory."""
        system = platform.system().lower()
        if system == "windows":
            return r"C:\Program Files\Unity\Hub\Editor"
        elif system == "darwin":  # macOS
            return "/Applications/Unity/Hub/Editor"
        elif system == "linux":
            return os.path.expanduser("~/Unity/Hub/Editor")
        return None

    @staticmethod
    def find_editors() -> Dict[str, str]:
        """
        Scans default Hub locations for installed Unity Editors.

        Returns:
            Dict[str, str]: A dictionary of {version: executable_path}.
        """
        hub_path = UnityFinder.get_hub_editor_path()
        if not hub_path or not os.path.exists(hub_path):
            logger.warning(f"Unity Hub path not found: {hub_path}")
            return {}

        found_editors = {}
        system = platform.system().lower()

        # Look for subdirectories (versions)
        try:
            versions = [
                d
                for d in os.listdir(hub_path)
                if os.path.isdir(os.path.join(hub_path, d))
            ]
            for version in versions:
                editor_dir = os.path.join(hub_path, version)
                exe_path = None

                if system == "windows":
                    candidate = os.path.join(editor_dir, "Editor", "Unity.exe")
                    if os.path.exists(candidate):
                        exe_path = candidate
                elif system == "darwin":
                    candidate = os.path.join(
                        editor_dir, "Unity.app", "Contents", "MacOS", "Unity"
                    )
                    if os.path.exists(candidate):
                        exe_path = candidate
                elif system == "linux":
                    candidate = os.path.join(editor_dir, "Editor", "Unity")
                    if os.path.exists(candidate):
                        exe_path = candidate

                if exe_path:
                    found_editors[version] = exe_path
        except Exception as e:
            logger.error(f"Error scanning for Unity Editors: {e}")

        return found_editors

    @staticmethod
    def resolve_version(version_str: str) -> Optional[str]:
        """
        Tries to resolve a version string to an executable path.
        Can be a specific version (2022.3.4f1) or a path.
        """
        if os.path.exists(version_str) and os.path.isfile(version_str):
            return version_str

        editors = UnityFinder.find_editors()
        return editors.get(version_str)


class UnityLauncher:
    """
    Class to handle launching the Unity Editor or Standalone Players.
    """

    def __init__(self, executable_path: str = None, project_path: str = None):
        """
        Args:
            executable_path: Path to Unity.exe or specific version string (if found).
                             If None, tries to find the latest installed version.
            project_path: Path to the Unity project folder.
        """
        self.executable_path = executable_path
        self.project_path = project_path

        if self.executable_path and not os.path.exists(self.executable_path):
            # Try to resolve as version string
            resolved = UnityFinder.resolve_version(self.executable_path)
            if resolved:
                self.executable_path = resolved

        if not self.executable_path:
            # Auto-detect latest
            editors = UnityFinder.find_editors()
            if editors:
                # Sort by version (roughly)
                latest = sorted(editors.keys())[-1]
                self.executable_path = editors[latest]
                logger.info(f"Auto-selected Unity version: {latest}")

    def create_project(self, target_path: str, batch_mode: bool = True) -> bool:
        """
        Creates a new Unity project at the specified path.

        Args:
            target_path: Absolute path where the new project should be created.
            batch_mode: If True, runs in batch mode and quits after creation.

        Returns:
            bool: True if creation appears successful (directory exists).
        """
        if not self.executable_path:
            logger.error("No Unity executable configured.")
            return False

        if os.path.exists(target_path):
            logger.warning(f"Project path already exists: {target_path}")
            return True

        args = ["-createProject", target_path]

        if batch_mode:
            args.extend(["-batchmode", "-quit", "-nographics"])

        logger.info(f"Creating new Unity project at: {target_path}")

        # We process this synchronously to ensure it's done before proceeding
        proc = AppLauncher.launch(
            self.executable_path,
            args=args,
            cwd=os.path.dirname(target_path),
            detached=False,
        )

        if proc:
            proc.wait()  # Double check wait if AppLauncher detached=False doesn't imply strict wait

        return os.path.exists(target_path)

    def launch_editor(
        self,
        batch_mode: bool = False,
        execute_method: str = None,
        build_target: str = None,
        log_file: str = None,
        extra_args: List[str] = None,
        detached: bool = True,
    ) -> Optional[subprocess.Popen]:
        """
        Launches the Unity Editor with the configured project.

        Args:
            batch_mode: Run in batch mode (no graphics, no window).
            execute_method: Static method to execute (e.g. 'MyClass.Build').
            build_target: Switch active build target (e.g. 'Win64', 'Android').
            log_file: Path to redirect the editor log.
            extra_args: Additional arguments list.
            detached: Whether to launch as a detached process.

        Returns:
            subprocess.Popen: The process object.
        """
        if not self.executable_path:
            logger.error("No Unity executable configured.")
            return None

        args = []

        if self.project_path:
            args.extend(["-projectPath", self.project_path])

        if batch_mode:
            args.extend(["-batchmode", "-nographics"])

        if execute_method:
            args.extend(["-executeMethod", execute_method])

        if build_target:
            args.extend(["-buildTarget", build_target])

        if log_file:
            args.extend(["-logFile", log_file])

        if extra_args:
            args.extend(extra_args)

        logger.info(f"Launching Unity Editor: {self.executable_path}")
        return AppLauncher.launch(
            self.executable_path, args=args, cwd=self.project_path, detached=detached
        )

    def launch_player(
        self,
        player_executable_path: str,
        extra_args: List[str] = None,
        detached: bool = True,
    ) -> Optional[subprocess.Popen]:
        """
        Launches a standalone built player.
        """
        if not os.path.exists(player_executable_path):
            logger.error(f"Player executable not found: {player_executable_path}")
            return None

        logger.info(f"Launching Player: {player_executable_path}")
        return AppLauncher.launch(
            player_executable_path, args=extra_args, detached=detached
        )
