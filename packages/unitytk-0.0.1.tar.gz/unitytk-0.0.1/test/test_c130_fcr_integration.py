# !/usr/bin/python
# coding=utf-8
"""
Integration test: C-130H FCR FBX + Audio pipeline via unitytk.

Validates the full import pipeline with a real-world pre-baked FBX:
    0. Source validation: FBX binary-scanned for expected custom attributes
       (audio_manifest, opacity), audio directory verified.
    1. Unity project setup: create project, deploy C# templates, copy FBX
       + audio assets.
    2. Batch-mode verification: reimport FBX, verify auto-added components,
       animation curve bindings, AnimationEvent injection, clip matching.
    3. (Optional) GUI launch for manual inspection.

Source files:
    FBX:   O:\\Dropbox (Moth+Flame)\\...\\C130_FCR_Speedrun_Assembly_copy.fbx
    Audio: O:\\Dropbox (Moth+Flame)\\...\\C-130H FCR Audio Files\\  (73 MP3s)

The FBX contains:
    - ``audio_manifest`` string attributes on 3 objects (sections A, B, C)
      with frame:eventName pairs whose names match the MP3 stems.
    - ``audio_trigger`` animated float curves (15 occurrences).
    - ``opacity`` custom attributes on ~168 objects.

Requires:
    - Unity Hub with at least one editor installed.
    - Source FBX + audio files accessible on Dropbox.
"""
import os
import sys
import json
import glob
import shutil
import struct
import tempfile
import unittest
import subprocess
import logging
import re

logger = logging.getLogger(__name__)

scripts_dir = r"O:\Cloud\Code\_scripts"
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

from unitytk import UnityLauncher, UnityFinder, deploy_template

# ---------------------------------------------------------------------------
# Source paths
# ---------------------------------------------------------------------------

FBX_PATH = (
    r"O:\Dropbox (Moth+Flame)\Moth+Flame Dropbox\Ryan Simpson"
    r"\_tests\audio_files\C130_FCR_Speedrun_Assembly_copy.fbx"
)
AUDIO_DIR = (
    r"O:\Dropbox (Moth+Flame)\Moth+Flame Dropbox\Ryan Simpson"
    r"\_tests\audio_files\C-130H FCR Audio Files"
)

# Expected counts (from binary scan 2026-02-24)
EXPECTED_MANIFEST_COUNT = 3   # 3 objects carry audio_manifest
EXPECTED_AUDIO_FILE_COUNT = 71  # MP3 files in top-level audio dir
# Smoke-test floor for raw FBX binary scan — the byte pattern "opacity"
# appears in AnimCurveNode names, property definitions, and hierarchy.
# Much higher than the 33 actual opacity attributes.
EXPECTED_OPACITY_MIN = 50


def _sources_available() -> bool:
    return os.path.isfile(FBX_PATH) and os.path.isdir(AUDIO_DIR)


def _unity_available() -> bool:
    return bool(UnityFinder.find_editors())


# ---------------------------------------------------------------------------
# FBX binary helpers
# ---------------------------------------------------------------------------


def _fbx_magic_ok(path: str) -> bool:
    """Check that the file starts with the Kaydara FBX magic header."""
    try:
        with open(path, "rb") as f:
            header = f.read(23)
        return header.startswith(b"Kaydara FBX Binary")
    except Exception:
        return False


def _fbx_scan_keywords(path: str, keywords: list[str],
                       buf_size: int = 4 * 1024 * 1024) -> dict[str, int]:
    """Scan a binary FBX for keyword occurrence counts.

    Reads in 4 MB chunks with a 256-byte overlap to catch keywords
    that straddle buffer boundaries.  Returns {keyword: count}.
    """
    overlap = 256
    counts = {kw: 0 for kw in keywords}
    kw_bytes = {kw: kw.encode("ascii") for kw in keywords}

    with open(path, "rb") as f:
        carry = b""
        while True:
            chunk = f.read(buf_size)
            if not chunk:
                break
            data = carry + chunk
            for kw, kw_b in kw_bytes.items():
                counts[kw] += data.count(kw_b)
            # Keep last `overlap` bytes for straddled keywords
            carry = data[-overlap:] if len(data) > overlap else data

    return counts


def _fbx_extract_manifests(path: str,
                           buf_size: int = 4 * 1024 * 1024,
                           max_results: int = 10) -> list[str]:
    """Extract raw manifest string values from the binary FBX.

    Returns a list of manifest content strings (the frame:name CSV data).
    """
    marker = b"audio_manifest"
    overlap = 1024  # manifests can be long
    results: list[str] = []

    with open(path, "rb") as f:
        carry = b""
        while len(results) < max_results:
            chunk = f.read(buf_size)
            if not chunk:
                break
            data = carry + chunk
            idx = 0
            while idx < len(data) and len(results) < max_results:
                pos = data.find(marker, idx)
                if pos == -1:
                    break
                # The manifest value appears after some FBX framing bytes.
                # Look for the CSV content (digits, colons, commas, underscores,
                # letters) in the ~2 KB window after the marker.
                window = data[pos:pos + 2048]
                text = window.decode("ascii", errors="replace")
                # Find the first run of frame:Name,frame:Name,... pattern
                m = re.search(r"(\d+:[A-Za-z0-9_]+(?:,\d+:[A-Za-z0-9_]+)*)", text)
                if m:
                    results.append(m.group(1))
                idx = pos + len(marker)
            carry = data[-overlap:] if len(data) > overlap else data

    return results


def _collect_audio_files(audio_dir: str) -> list[str]:
    """Return sorted list of MP3 file stems (no extension) in audio_dir.

    Excludes the ``_maya_audio_cache`` subdirectory.
    """
    stems = []
    for f in os.listdir(audio_dir):
        full = os.path.join(audio_dir, f)
        if os.path.isfile(full) and f.lower().endswith(".mp3"):
            stems.append(os.path.splitext(f)[0])
    return sorted(stems)


# ---------------------------------------------------------------------------
# Unity C# verifier
# ---------------------------------------------------------------------------

UNITY_VERIFIER_CS = r"""
// C130FcrVerifier.cs — deployed to Assets/Editor/ during test setup.
// Runs in batch mode; writes JSON results and exits.
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class C130FcrVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";

        // --- Force reimport the FBX with custom properties enabled ---
        string fbxAsset = "Assets/C130_FCR_Speedrun_Assembly_copy.fbx";
        var importer = AssetImporter.GetAtPath(fbxAsset) as ModelImporter;
        if (importer != null)
        {
            // importAnimatedCustomProperties is set by RenderOpacityImporter's
            // OnPreprocessModel — do NOT set it here so the test verifies
            // that the importer handles it correctly.
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAsset);
            AssetDatabase.ImportAsset(fbxAsset,
                ImportAssetOptions.ForceUpdate |
                ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var results = new Dictionary<string, object>();

        // --- Instantiate the FBX prefab to inspect components ---
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        GameObject instance = null;
        int totalGameObjects = 0;
        int audioControllerCount = 0;
        int opacityControllerCount = 0;
        var audioControllerDetails = new List<string>();
        var opacityControllerDetails = new List<string>();

        // Track objects that got opacity user property but no Renderer
        int opacityWithRenderer = 0;
        int opacityWithoutRenderer = 0;
        var audioClipNameLists = new List<string>();  // per-controller clip names

        if (prefab != null)
        {
            instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            var allTransforms = instance.GetComponentsInChildren<Transform>(true);
            totalGameObjects = allTransforms.Length;

            // Audio Event Controllers — capture clip names
            var audioControllers = instance
                .GetComponentsInChildren<AudioEventController>(true);
            audioControllerCount = audioControllers.Length;
            foreach (var ac in audioControllers)
            {
                int matched = ac.clips != null
                    ? ac.clips.Count(c => c != null) : 0;
                int total   = ac.clips != null ? ac.clips.Count : 0;
                audioControllerDetails.Add(
                    ac.gameObject.name + ":" + matched + "/" + total);

                // Collect matched clip names for verification
                if (ac.clips != null)
                {
                    var names = ac.clips
                        .Where(c => c != null)
                        .Select(c => c.name)
                        .ToArray();
                    audioClipNameLists.Add(
                        ac.gameObject.name + "=" + string.Join("|", names));
                }
            }

            // Render Opacity Controllers — verify Renderer presence
            var opacityControllers = instance
                .GetComponentsInChildren<RenderOpacityController>(true);
            opacityControllerCount = opacityControllers.Length;
            foreach (var oc in opacityControllers)
            {
                var rend = oc.GetComponent<Renderer>();
                string hasRenderer = rend != null ? "Y" : "N";
                string matName = rend != null && rend.sharedMaterial != null
                    ? rend.sharedMaterial.name : "none";
                opacityControllerDetails.Add(
                    oc.gameObject.name + ":opacity=" + oc.opacity
                    + ",renderer=" + hasRenderer + ",mat=" + matName);
            }

            // Count all objects: has Renderer vs not (for opacity tracking)
            foreach (var t in allTransforms)
            {
                var oc2 = t.GetComponent<RenderOpacityController>();
                var rend2 = t.GetComponent<Renderer>();
                if (oc2 != null)
                {
                    if (rend2 != null) opacityWithRenderer++;
                    else opacityWithoutRenderer++;
                }
            }

            Object.DestroyImmediate(instance);
        }

        results["prefab_loaded"]             = prefab != null;
        results["total_game_objects"]         = totalGameObjects;
        results["audio_controller_count"]     = audioControllerCount;
        results["audio_controller_details"]   = audioControllerDetails.ToArray();
        results["audio_clip_names"]           = audioClipNameLists.ToArray();
        results["opacity_controller_count"]   = opacityControllerCount;
        results["opacity_controller_details"] = opacityControllerDetails.ToArray();
        results["opacity_with_renderer"]      = opacityWithRenderer;
        results["opacity_without_renderer"]   = opacityWithoutRenderer;

        // --- Animation clips: curve bindings and events ---
        var allAssets = AssetDatabase.LoadAllAssetsAtPath(fbxAsset);
        var clips = allAssets
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__"))
            .ToArray();

        results["animation_clip_count"] = clips.Length;

        var clipInfos = new List<string>();
        int totalAnimEvents = 0;
        int opacityCurves = 0;
        int audioTriggerCurves = 0;

        foreach (var clip in clips)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var events   = AnimationUtility.GetAnimationEvents(clip);
            totalAnimEvents += events.Length;

            int clipOpacityRebound = 0;  // opacity -> RenderOpacityController
            int clipOpacityAny = 0;     // opacity -> any type
            int clipAudio   = 0;
            var curveNames  = new List<string>();

            foreach (var b in bindings)
            {
                curveNames.Add(b.propertyName + "@" + b.type.Name);
                if (b.propertyName == "opacity")
                {
                    clipOpacityAny++;
                    if (b.type == typeof(RenderOpacityController))
                        clipOpacityRebound++;
                }
                if (b.propertyName == "audio_trigger")
                    clipAudio++;
            }

            opacityCurves      += clipOpacityRebound;
            audioTriggerCurves += clipAudio;

            // Sample opacity curves at various times to verify animation
            var opacitySamples = new List<string>();
            foreach (var b in bindings)
            {
                if (b.propertyName != "opacity") continue;
                var curve = AnimationUtility.GetEditorCurve(clip, b);
                if (curve == null || curve.length == 0) continue;
                // Sample first key, midpoint, last key
                float t0 = curve.keys[0].time;
                float tN = curve.keys[curve.length - 1].time;
                float tM = (t0 + tN) / 2f;
                opacitySamples.Add(b.path + ": " +
                    "keys=" + curve.length +
                    " t0=" + t0.ToString("F2") +
                    " v0=" + curve.keys[0].value.ToString("F3") +
                    " tM=" + tM.ToString("F2") +
                    " vM=" + curve.Evaluate(tM).ToString("F3") +
                    " tN=" + tN.ToString("F2") +
                    " vN=" + curve.keys[curve.length - 1].value.ToString("F3"));
                // Only sample first 20 to avoid huge output
                if (opacitySamples.Count >= 20) break;
            }

            // Animation events targeting OnAudioEvent — collect times
            int onAudioEvents = events.Count(
                e => e.functionName == "OnAudioEvent");
            var audioEventTimes = new List<string>();
            foreach (var e in events)
            {
                if (e.functionName == "OnAudioEvent")
                    audioEventTimes.Add(
                        e.time.ToString("F3") + ":" + e.stringParameter);
            }

            clipInfos.Add(clip.name
                + "|curves=" + bindings.Length
                + "|opacityCurvesRebound=" + clipOpacityRebound
                + "|opacityCurvesAny=" + clipOpacityAny
                + "|audioTriggerCurves=" + clipAudio
                + "|animEvents=" + events.Length
                + "|onAudioEvents=" + onAudioEvents);

            // Store detailed opacity and event data per clip
            if (opacitySamples.Count > 0)
                results["opacity_curve_samples_" + clip.name] =
                    opacitySamples.ToArray();
            if (audioEventTimes.Count > 0)
                results["audio_event_times_" + clip.name] =
                    audioEventTimes.ToArray();
        }

        // --- Curve binding frequency: every unique propertyName@type ---
        var bindingFreq = new Dictionary<string, int>();
        foreach (var clip in clips)
        {
            foreach (var b in AnimationUtility.GetCurveBindings(clip))
            {
                string key = b.propertyName + "@" + b.type.Name;
                if (!bindingFreq.ContainsKey(key)) bindingFreq[key] = 0;
                bindingFreq[key]++;
            }
        }
        // Sort descending and emit as array
        var freqList = new List<string>();
        foreach (var kv in bindingFreq.OrderByDescending(kv => kv.Value))
            freqList.Add(kv.Key + "=" + kv.Value);
        results["curve_binding_freq"] = freqList.ToArray();

        // --- Opacity bindings detail (path + type for each) ---
        var opacityBindingPaths = new List<string>();
        var rendererEnabledPaths = new List<string>();
        foreach (var clip in clips)
        {
            foreach (var b in AnimationUtility.GetCurveBindings(clip))
            {
                if (b.propertyName == "opacity")
                    opacityBindingPaths.Add(
                        b.path + "|" + b.type.Name + "|" + b.propertyName);
                if (b.propertyName == "m_Enabled" && b.type == typeof(Renderer))
                    rendererEnabledPaths.Add(b.path);
            }
        }
        results["opacity_binding_paths"] = opacityBindingPaths.ToArray();
        results["renderer_enabled_paths"] = rendererEnabledPaths.ToArray();

        results["clip_details"]               = clipInfos.ToArray();
        results["total_anim_events"]          = totalAnimEvents;
        results["opacity_curves_rebound"]     = opacityCurves;
        results["audio_trigger_curves"]       = audioTriggerCurves;

        // --- Audio clips discovered in Assets/Audio/ ---
        string[] audioGuids = AssetDatabase.FindAssets(
            "t:AudioClip", new[] { "Assets/Audio" });
        results["audio_assets_found"] = audioGuids.Length;

        // --- Reimport idempotency: reimport and verify no duplicates ---
        AssetDatabase.ImportAsset(fbxAsset,
            ImportAssetOptions.ForceUpdate |
            ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var riClips = AssetDatabase.LoadAllAssetsAtPath(fbxAsset)
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();
        int riEvents = 0, riOpacity = 0, riAudioTrigger = 0;
        foreach (var rc in riClips)
        {
            var rev = AnimationUtility.GetAnimationEvents(rc);
            riEvents += rev.Count(e => e.functionName == "OnAudioEvent");
            foreach (var rb in AnimationUtility.GetCurveBindings(rc))
            {
                if (rb.propertyName == "opacity" &&
                    rb.type == typeof(RenderOpacityController))
                    riOpacity++;
                if (rb.propertyName == "audio_trigger")
                    riAudioTrigger++;
            }
        }
        results["reimport_events"] = riEvents;
        results["reimport_opacity_curves"] = riOpacity;
        results["reimport_audio_trigger"] = riAudioTrigger;

        var riPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        if (riPrefab != null)
        {
            var riInst = (GameObject)PrefabUtility.InstantiatePrefab(riPrefab);
            results["reimport_opacity_controllers"] =
                riInst.GetComponentsInChildren<RenderOpacityController>(true).Length;
            results["reimport_audio_controllers"] =
                riInst.GetComponentsInChildren<AudioEventController>(true).Length;
            Object.DestroyImmediate(riInst);
        }

        // --- AnimationMode: prove curves drive component properties ---
        try
        {
            var animPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
            if (animPrefab != null && clips.Length > 0)
            {
                var animInst = (GameObject)PrefabUtility.InstantiatePrefab(animPrefab);
                var animClip = clips[0];
                var animOcs = animInst
                    .GetComponentsInChildren<RenderOpacityController>(true);

                AnimationMode.StartAnimationMode();

                // Sample at t=0
                AnimationMode.SampleAnimationClip(animInst, animClip, 0f);
                var vAt0 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt0[ai] = animOcs[ai].opacity;

                // Sample at t=15 (after 15-sec fade-in window)
                AnimationMode.SampleAnimationClip(animInst, animClip, 15f);
                var vAt15 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt15[ai] = animOcs[ai].opacity;

                // Sample at t=500 (mid-animation)
                AnimationMode.SampleAnimationClip(animInst, animClip, 500f);
                var vAt500 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt500[ai] = animOcs[ai].opacity;

                AnimationMode.StopAnimationMode();

                int changedBy15 = 0, changedBy500 = 0;
                for (int ai = 0; ai < animOcs.Length; ai++)
                {
                    if (Mathf.Abs(vAt0[ai] - vAt15[ai]) > 0.001f)
                        changedBy15++;
                    if (Mathf.Abs(vAt0[ai] - vAt500[ai]) > 0.001f)
                        changedBy500++;
                }

                results["anim_sample_count"] = animOcs.Length;
                results["anim_sample_changed_by_t15"] = changedBy15;
                results["anim_sample_changed_by_t500"] = changedBy500;

                var sampleDetails = new List<string>();
                for (int ai = 0; ai < Mathf.Min(animOcs.Length, 15); ai++)
                {
                    sampleDetails.Add(animOcs[ai].gameObject.name +
                        ":t0=" + vAt0[ai].ToString("F3") +
                        ",t15=" + vAt15[ai].ToString("F3") +
                        ",t500=" + vAt500[ai].ToString("F3"));
                }
                results["anim_sample_details"] = sampleDetails.ToArray();

                Object.DestroyImmediate(animInst);
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogWarning(
                "[C130FcrVerifier] AnimationMode sampling failed: " + ex.Message);
            results["anim_sample_error"] = ex.Message;
        }

        // --- Write JSON ---
        File.WriteAllText(resultsFile, DictToJson(results));
        Debug.Log("[C130FcrVerifier] Results written to: " + resultsFile);

        EditorApplication.Exit(0);
    }

    // Minimal JSON serializer (no Newtonsoft dependency)
    static string DictToJson(Dictionary<string, object> dict)
    {
        var parts = new List<string>();
        foreach (var kv in dict)
        {
            string val;
            if (kv.Value is string[] arr)
                val = "[" + string.Join(",",
                    System.Array.ConvertAll(arr,
                        s => "\"" + Esc(s) + "\"")) + "]";
            else if (kv.Value is string s)
                val = "\"" + Esc(s) + "\"";
            else if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + Esc(
                    kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("  \"" + Esc(kv.Key) + "\": " + val);
        }
        return "{\n" + string.Join(",\n", parts) + "\n}";
    }

    static string Esc(string s)
    {
        return s.Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\n", "\\n");
    }
}
"""

# C# postprocessor that captures user properties during FBX import
UNITY_POSTPROCESSOR_CS = r"""
// C130FcrPostprocessor.cs — captures user properties from FBX import.
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

public class C130FcrPostprocessor : AssetPostprocessor
{
    const string RESULTS_DIR = @"__RESULTS_DIR__";
    static int _callCount = 0;

    void OnPostprocessGameObjectWithUserProperties(
        GameObject go, string[] propNames, object[] values)
    {
        _callCount++;
        var entries = new List<string>();
        for (int i = 0; i < propNames.Length; i++)
        {
            string typeName = values[i] != null
                ? values[i].GetType().Name : "null";
            string valStr = values[i] != null
                ? values[i].ToString() : "null";
            // Truncate long values (manifests can be 1 KB+)
            if (valStr.Length > 500)
                valStr = valStr.Substring(0, 500) + "...(truncated)";
            entries.Add("    \"" + Esc(propNames[i]) + "\": {"
                + "\"type\": \"" + typeName + "\", "
                + "\"value\": \"" + Esc(valStr) + "\"}");
        }

        // Append to a JSONL-style file (one object per OnPostprocess call)
        string outPath = Path.Combine(RESULTS_DIR, "user_properties.jsonl");
        string json = "{\n  \"gameObject\": \"" + Esc(go.name) + "\",\n"
            + "  \"callIndex\": " + _callCount + ",\n"
            + string.Join(",\n", entries) + "\n}\n";
        File.AppendAllText(outPath, json);
    }

    static string Esc(string s)
    {
        return s.Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\n", "\\n");
    }
}
"""


# ======================================================================
# Test class
# ======================================================================


@unittest.skipUnless(_sources_available(), "C130 FBX/audio not accessible")
class TestC130FcrIntegration(unittest.TestCase):
    """Full pipeline: pre-baked C-130H FCR FBX → Unity import verification."""

    @classmethod
    def setUpClass(cls):
        # Use O: drive for temp dir — C: drive is often full
        _temp_base = r"O:\Cloud\Code\_scripts\test\temp_tests"
        os.makedirs(_temp_base, exist_ok=True)
        cls.temp_dir = tempfile.mkdtemp(prefix="c130_fcr_integ_", dir=_temp_base)
        cls.project_path = os.path.join(cls.temp_dir, "UnityProject")
        cls.unity_results = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        # Default: clean up multi-GB temp projects.
        # Set C130_PRESERVE=1 to keep for post-mortem / GUI inspection.
        if os.environ.get("C130_PRESERVE", "").strip() == "1":
            logger.info(
                f"Results preserved at: {cls.temp_dir}\n"
                f"  Unset C130_PRESERVE to auto-delete.")
        else:
            shutil.rmtree(cls.temp_dir, ignore_errors=True)
            logger.info(f"Cleaned up: {cls.temp_dir}")

    # ------------------------------------------------------------------
    # Step 0: Validate source FBX and audio files
    # ------------------------------------------------------------------

    def test_00_validate_sources(self):
        """Binary-scan the FBX for expected custom attributes;
        verify audio file count and naming consistency."""

        # --- FBX validity ---
        self.assertTrue(os.path.isfile(FBX_PATH), "FBX file not found")
        self.assertTrue(_fbx_magic_ok(FBX_PATH),
                        "FBX does not start with Kaydara magic header")

        size_mb = os.path.getsize(FBX_PATH) / (1024 * 1024)
        logger.info(f"FBX size: {size_mb:.1f} MB")

        # --- Keyword scan ---
        counts = _fbx_scan_keywords(
            FBX_PATH,
            ["audio_manifest", "audio_trigger", "opacity"],
        )
        logger.info(f"FBX keyword counts: {counts}")

        self.assertGreaterEqual(
            counts["audio_manifest"], EXPECTED_MANIFEST_COUNT,
            f"Expected >= {EXPECTED_MANIFEST_COUNT} audio_manifest hits, "
            f"got {counts['audio_manifest']}")
        self.assertGreater(
            counts["audio_trigger"], 0,
            "No audio_trigger curves found in FBX")
        self.assertGreaterEqual(
            counts["opacity"], EXPECTED_OPACITY_MIN,
            f"Expected >= {EXPECTED_OPACITY_MIN} opacity hits, "
            f"got {counts['opacity']}")

        # --- Extract and validate manifest content ---
        manifests = _fbx_extract_manifests(FBX_PATH)
        self.assertGreaterEqual(
            len(manifests), EXPECTED_MANIFEST_COUNT,
            f"Extracted {len(manifests)} manifests, "
            f"expected >= {EXPECTED_MANIFEST_COUNT}")

        all_event_names: set[str] = set()
        for manifest in manifests:
            entries = manifest.split(",")
            for entry in entries:
                parts = entry.split(":", 1)
                self.assertEqual(len(parts), 2,
                                 f"Bad manifest entry: {entry!r}")
                frame_str, event_name = parts
                self.assertTrue(frame_str.isdigit(),
                                f"Non-numeric frame: {frame_str!r}")
                self.assertTrue(len(event_name) > 0,
                                f"Empty event name at frame {frame_str}")
                all_event_names.add(event_name)

        logger.info(f"Manifest event names ({len(all_event_names)}): "
                     f"{sorted(all_event_names)[:10]}...")

        # --- Audio files ---
        audio_stems = _collect_audio_files(AUDIO_DIR)
        self.assertEqual(
            len(audio_stems), EXPECTED_AUDIO_FILE_COUNT,
            f"Expected {EXPECTED_AUDIO_FILE_COUNT} MP3s, "
            f"found {len(audio_stems)}")

        # Cross-check: every manifest event name should have a matching MP3
        missing = all_event_names - set(audio_stems)
        self.assertEqual(
            len(missing), 0,
            f"Manifest event names with no matching MP3: {sorted(missing)}")

        # Store for later steps
        self.__class__._validated_event_names = all_event_names
        self.__class__._audio_stems = audio_stems

    # ------------------------------------------------------------------
    # Step 1: Unity project setup + batch verification
    # ------------------------------------------------------------------

    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_01_unity_import(self):
        """Create Unity project, deploy templates, copy assets,
        run C# verifier in batch mode."""

        # --- Create project ---
        launcher = UnityLauncher()
        logger.info(f"Creating Unity project: {self.project_path}")
        created = launcher.create_project(self.project_path, batch_mode=True)
        self.assertTrue(created, "Failed to create Unity project")

        assets_dir = os.path.join(self.project_path, "Assets")
        self.assertTrue(os.path.isdir(assets_dir))

        # --- Deploy C# templates (NOT in Editor/ — runtime MonoBehaviours) ---
        scripts_dst = os.path.join(assets_dir, "Scripts")
        os.makedirs(scripts_dst, exist_ok=True)

        deploy_template(
            "RenderOpacityController.cs",
            os.path.join(scripts_dst, "RenderOpacityController.cs"),
        )
        deploy_template(
            "AudioEventController.cs",
            os.path.join(scripts_dst, "AudioEventController.cs"),
        )
        logger.info("Deployed RenderOpacityController.cs + AudioEventController.cs")

        # --- Copy FBX (731 MB — takes a moment) ---
        dest_fbx = os.path.join(assets_dir,
                                "C130_FCR_Speedrun_Assembly_copy.fbx")
        logger.info(f"Copying FBX ({os.path.getsize(FBX_PATH)/(1024*1024):.0f} MB)...")
        shutil.copy2(FBX_PATH, dest_fbx)
        self.assertTrue(os.path.isfile(dest_fbx))

        # --- Copy audio files (flatten into Assets/Audio/) ---
        audio_dst = os.path.join(assets_dir, "Audio")
        os.makedirs(audio_dst, exist_ok=True)

        copied = 0
        for f in os.listdir(AUDIO_DIR):
            src = os.path.join(AUDIO_DIR, f)
            if os.path.isfile(src) and f.lower().endswith(".mp3"):
                shutil.copy2(src, os.path.join(audio_dst, f))
                copied += 1
        logger.info(f"Copied {copied} audio files to Assets/Audio/")
        self.assertEqual(copied, EXPECTED_AUDIO_FILE_COUNT)

        # --- Deploy C# verifier + postprocessor into Assets/Editor/ ---
        editor_dir = os.path.join(assets_dir, "Editor")
        os.makedirs(editor_dir, exist_ok=True)

        results_path = os.path.join(self.temp_dir, "unity_results.json")
        results_esc = results_path.replace("\\", "\\\\")
        results_dir_esc = self.temp_dir.replace("\\", "\\\\")

        verifier_cs = UNITY_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_esc)
        with open(os.path.join(editor_dir, "C130FcrVerifier.cs"),
                  "w", encoding="utf-8") as f:
            f.write(verifier_cs)

        postproc_cs = UNITY_POSTPROCESSOR_CS.replace(
            "__RESULTS_DIR__", results_dir_esc)
        with open(os.path.join(editor_dir, "C130FcrPostprocessor.cs"),
                  "w", encoding="utf-8") as f:
            f.write(postproc_cs)

        # --- Launch Unity batch mode ---
        log_path = os.path.join(self.temp_dir, "unity_log.txt")
        launcher.project_path = self.project_path

        logger.info("Launching Unity batch-mode verification...")
        proc = launcher.launch_editor(
            batch_mode=True,
            execute_method="C130FcrVerifier.Verify",
            log_file=log_path,
            extra_args=["-quit"],
            detached=False,
        )

        if proc:
            try:
                proc.wait(timeout=600)  # 10 min — large FBX import
            except subprocess.TimeoutExpired:
                proc.kill()
                self.fail("Unity timed out after 600 s")

        # Log tail for debugging
        if os.path.exists(log_path):
            with open(log_path, encoding="utf-8", errors="replace") as f:
                log_tail = f.read()[-4000:]
            logger.info(f"Unity log tail:\n{log_tail}")

        # --- Read results ---
        self.assertTrue(
            os.path.isfile(results_path),
            f"unity_results.json not created — check {log_path}")

        with open(results_path, encoding="utf-8") as f:
            self.__class__.unity_results = json.load(f)

        logger.info("Unity results:\n"
                     + json.dumps(self.__class__.unity_results, indent=2))

    # ------------------------------------------------------------------
    # Step 2: Analyze Unity results
    # ------------------------------------------------------------------

    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_02_analyze(self):
        """Assert that components, curves, events, and clip matches
        are correct."""
        r = self.__class__.unity_results
        if not r:
            self.skipTest("Unity results not available — test_01 must pass")

        print("\n" + "=" * 70)
        print("  C-130H FCR INTEGRATION TEST RESULTS")
        print("=" * 70)

        # ================================================================
        # 1. Prefab loaded
        # ================================================================
        self.assertTrue(r.get("prefab_loaded"), "Prefab failed to load")
        total_go = r.get("total_game_objects", 0)
        print(f"  Prefab loaded:            YES  ({total_go} GameObjects)")
        self.assertGreater(total_go, 100,
                           f"Too few GameObjects ({total_go}) — FBX likely "
                           f"empty or failed to parse")

        # ================================================================
        # 2. AudioEventController — components, clip matching, clip names
        # ================================================================
        ac_count = r.get("audio_controller_count", 0)
        ac_details = r.get("audio_controller_details", [])
        ac_clip_names = r.get("audio_clip_names", [])
        print(f"\n  AudioEventControllers:    {ac_count}")
        for d in ac_details:
            print(f"    {d}")

        self.assertEqual(
            ac_count, EXPECTED_MANIFEST_COUNT,
            f"Expected exactly {EXPECTED_MANIFEST_COUNT} "
            f"AudioEventControllers, got {ac_count}")

        # Every controller must have 100% clip match rate
        total_audio_clips_matched = 0
        total_audio_clips_expected = 0
        for detail in ac_details:
            parts = detail.rsplit(":", 1)
            self.assertEqual(len(parts), 2, f"Bad detail format: {detail}")
            obj_name = parts[0]
            m_t = parts[1].split("/")
            self.assertEqual(len(m_t), 2, f"Bad matched/total: {parts[1]}")
            matched, total = int(m_t[0]), int(m_t[1])
            total_audio_clips_expected += total
            total_audio_clips_matched += matched
            self.assertEqual(
                matched, total,
                f"{obj_name}: only {matched}/{total} audio clips matched — "
                f"missing files in Assets/Audio/")

        self.assertEqual(
            total_audio_clips_matched, EXPECTED_AUDIO_FILE_COUNT,
            f"Total matched clips ({total_audio_clips_matched}) != "
            f"expected audio file count ({EXPECTED_AUDIO_FILE_COUNT})")
        print(f"    All clips matched: {total_audio_clips_matched}/"
              f"{total_audio_clips_expected}")

        # Verify clip names are actual audio stems from the source directory
        if ac_clip_names:
            audio_stems = set(_collect_audio_files(AUDIO_DIR))
            for entry in ac_clip_names:
                # Format: "OBJNAME=clip1|clip2|clip3"
                eq_idx = entry.index("=")
                obj_name = entry[:eq_idx]
                names = entry[eq_idx + 1:].split("|") if entry[eq_idx + 1:] else []
                for name in names:
                    self.assertIn(
                        name, audio_stems,
                        f"{obj_name}: clip '{name}' not in source audio dir")
            print(f"    Clip names verified against source audio directory")

        # ================================================================
        # 3. RenderOpacityController — components + Renderer gating
        # ================================================================
        oc_count = r.get("opacity_controller_count", 0)
        oc_details = r.get("opacity_controller_details", [])
        oc_with_rend = r.get("opacity_with_renderer", 0)
        oc_without_rend = r.get("opacity_without_renderer", 0)

        print(f"\n  RenderOpacityControllers: {oc_count}")
        print(f"    With Renderer:          {oc_with_rend}")
        print(f"    Without Renderer:       {oc_without_rend}")
        if oc_details:
            print(f"    Details (first 5):")
            for d in oc_details[:5]:
                print(f"      {d}")
            if len(oc_details) > 5:
                print(f"      ... and {len(oc_details) - 5} more")

        # All controllers MUST have a Renderer (RequireComponent enforces
        # this, but verify the importer only added to Renderer objects)
        EXPECTED_OPACITY_CONTROLLERS = 45  # 33 direct + 12 propagated children
        self.assertGreaterEqual(
            oc_count, EXPECTED_OPACITY_CONTROLLERS,
            f"Expected >= {EXPECTED_OPACITY_CONTROLLERS} opacity controllers, "
            f"got {oc_count} — child propagation may have regressed")
        self.assertEqual(
            oc_count, oc_with_rend,
            f"{oc_without_rend} opacity controllers lack a Renderer — "
            f"component should only be added to Renderer objects")

        # Verify material property names are present in details
        for detail in oc_details:
            self.assertIn("renderer=Y", detail,
                          f"Opacity controller missing Renderer: {detail}")

        # ================================================================
        # 4. Animation clips — existence and curve richness
        # ================================================================
        clip_count = r.get("animation_clip_count", 0)
        clip_details = r.get("clip_details", [])
        print(f"\n  Animation clips:          {clip_count}")
        for cd in clip_details:
            print(f"    {cd}")
        self.assertGreater(clip_count, 0, "No animation clips found")

        # ================================================================
        # 4b. Curve binding frequency — all unique propertyName@type
        # ================================================================
        binding_freq = r.get("curve_binding_freq", [])
        if binding_freq:
            print(f"\n  Curve binding frequency (top 20):")
            for entry in binding_freq[:20]:
                print(f"    {entry}")
            if len(binding_freq) > 20:
                print(f"    ... and {len(binding_freq) - 20} more types")

        # ================================================================
        # 4c. Opacity binding paths — every opacity curve path & type
        # ================================================================
        opacity_paths = r.get("opacity_binding_paths", [])
        print(f"\n  Opacity binding paths:    {len(opacity_paths)}")
        for op in opacity_paths[:20]:
            print(f"    {op}")
        if len(opacity_paths) > 20:
            print(f"    ... and {len(opacity_paths) - 20} more")

        # FBX has 33 opacity AnimCurveNodes.  After child-propagation the
        # importer synthesises one curve per descendant Renderer (≥33).
        EXPECTED_OPACITY_CURVES = 33
        self.assertGreaterEqual(
            len(opacity_paths), EXPECTED_OPACITY_CURVES,
            f"Only {len(opacity_paths)} opacity bindings in Unity vs "
            f"≥{EXPECTED_OPACITY_CURVES} expected (33 FBX opacity nodes + "
            f"child Renderers of MEDIA LOCs)"
        )

        # ================================================================
        # 4d. Renderer.m_Enabled paths — visibility curves from FBX
        # ================================================================
        renderer_paths = r.get("renderer_enabled_paths", [])
        print(f"\n  Renderer.m_Enabled paths: {len(renderer_paths)}")
        for rp in renderer_paths[:10]:
            print(f"    {rp}")
        if len(renderer_paths) > 10:
            print(f"    ... and {len(renderer_paths) - 10} more")

        # ================================================================
        # 5. Opacity curve bindings — rebound AND total
        # ================================================================
        oc_curves_rebound = r.get("opacity_curves_rebound", 0)
        print(f"\n  Opacity curves rebound:   {oc_curves_rebound}")

        # Parse clip details for opacityCurvesAny count
        for cd in clip_details:
            # Format: "...|opacityCurvesAny=N|..."
            m = re.search(r"opacityCurvesAny=(\d+)", cd)
            if m:
                any_count = int(m.group(1))
                print(f"  Opacity curves (any):     {any_count}")
                self.assertGreater(
                    any_count, 0,
                    "No opacity animation curves found in clip — "
                    "FBX may have lost them during import")

        # ================================================================
        # 6. Opacity curve keyframe samples — verify actual animation
        # ================================================================
        # Find keys like "opacity_curve_samples_Take 001"
        sample_keys = [k for k in r if k.startswith("opacity_curve_samples_")]
        if sample_keys:
            print(f"\n  Opacity curve samples:")
            for sk in sample_keys:
                samples = r[sk]
                print(f"    [{sk}] ({len(samples)} curves sampled)")
                for s in samples[:5]:
                    print(f"      {s}")
                if len(samples) > 5:
                    print(f"      ... and {len(samples) - 5} more")

                # At least one curve should have >1 keyframe
                # (otherwise it's a static value, not an animation)
                has_animation = False
                key_counts = []
                for s in samples:
                    m = re.search(r"keys=(\d+)", s)
                    if m:
                        kc = int(m.group(1))
                        key_counts.append(kc)
                        if kc > 1:
                            has_animation = True
                self.assertTrue(
                    has_animation,
                    f"No opacity curve in {sk} has >1 keyframe — "
                    f"opacity is not animated")

                # BoolToFadeCurve should emit only transition keys
                # (~4-12 per curve), NOT baked per-frame keys (~580).
                # Objects with many visibility toggles may reach ~22 keys.
                MAX_KEYS_PER_CURVE = 30
                bloated = [kc for kc in key_counts if kc > MAX_KEYS_PER_CURVE]
                self.assertEqual(
                    len(bloated), 0,
                    f"{len(bloated)} opacity curve(s) have >{MAX_KEYS_PER_CURVE}"
                    f" keys (max={max(key_counts) if key_counts else 0}) — "
                    f"BoolToFadeCurve may be emitting per-frame baked keys"
                )
        else:
            self.fail("No opacity curve samples found — "
                      "verifier didn't capture keyframe data")

        # ================================================================
        # 7. AudioEventController — AnimationEvent injection
        # ================================================================
        total_events = r.get("total_anim_events", 0)
        print(f"\n  Total AnimationEvents:    {total_events}")
        self.assertEqual(
            total_events, EXPECTED_AUDIO_FILE_COUNT,
            f"Expected {EXPECTED_AUDIO_FILE_COUNT} AnimationEvents, "
            f"got {total_events}")

        # Verify event times are non-negative and names match audio stems
        event_time_keys = [k for k in r if k.startswith("audio_event_times_")]
        audio_stems = set(_collect_audio_files(AUDIO_DIR))
        if event_time_keys:
            all_event_names_from_clip: set[str] = set()
            print(f"\n  Audio event times:")
            for etk in event_time_keys:
                events = r[etk]
                print(f"    [{etk}] {len(events)} events")
                for evt in events[:5]:
                    print(f"      {evt}")
                if len(events) > 5:
                    print(f"      ... and {len(events) - 5} more")

                for evt in events:
                    # Format: "16.667:A01_WelcomeToThe"
                    colon_idx = evt.index(":")
                    time_str = evt[:colon_idx]
                    event_name = evt[colon_idx + 1:]
                    time_val = float(time_str)
                    self.assertGreaterEqual(
                        time_val, 0,
                        f"Negative event time: {evt}")
                    self.assertIn(
                        event_name, audio_stems,
                        f"AnimationEvent name '{event_name}' has no "
                        f"matching audio file")
                    all_event_names_from_clip.add(event_name)

            # All audio files should be referenced by at least one event
            unreferenced = audio_stems - all_event_names_from_clip
            if unreferenced:
                logger.warning(
                    f"  Audio files not referenced by any event: "
                    f"{sorted(unreferenced)}")
            # Every manifest event should have a corresponding event
            self.assertEqual(
                len(all_event_names_from_clip), EXPECTED_AUDIO_FILE_COUNT,
                f"Expected {EXPECTED_AUDIO_FILE_COUNT} unique event names, "
                f"got {len(all_event_names_from_clip)}")
        else:
            self.fail("No audio event time data — "
                      "AudioEventImporter may not have injected events")

        # ================================================================
        # 8. Audio trigger curves should be absent (replaced by manifests)
        # ================================================================
        at_curves = r.get("audio_trigger_curves", 0)
        print(f"\n  Audio trigger curves:     {at_curves} (should be 0)")
        self.assertEqual(
            at_curves, 0,
            f"Legacy audio_trigger curves still present ({at_curves}) — "
            f"AudioEventImporter should have removed them")

        # ================================================================
        # 9. Audio assets in project
        # ================================================================
        audio_assets = r.get("audio_assets_found", 0)
        print(f"  Audio assets imported:    {audio_assets}")
        self.assertEqual(
            audio_assets, EXPECTED_AUDIO_FILE_COUNT,
            f"Expected {EXPECTED_AUDIO_FILE_COUNT} audio assets, "
            f"got {audio_assets}")

        # ================================================================
        # 10. User properties — opacity count from postprocessor
        # ================================================================
        props_path = os.path.join(self.temp_dir, "user_properties.jsonl")
        self.assertTrue(
            os.path.exists(props_path),
            "user_properties.jsonl missing — postprocessor didn't fire")

        with open(props_path, encoding="utf-8") as f:
            props_text = f.read()

        total_callbacks = props_text.count('"gameObject"')
        manifest_hits = props_text.count('"audio_manifest"')
        opacity_hits = props_text.count('"opacity"')

        print(f"\n  Postprocessor callbacks:  {total_callbacks} objects")
        print(f"  audio_manifest props:     {manifest_hits}")
        print(f"  opacity user props:       {opacity_hits}")

        self.assertGreaterEqual(
            manifest_hits, EXPECTED_MANIFEST_COUNT,
            f"Expected >= {EXPECTED_MANIFEST_COUNT} audio_manifest user "
            f"properties, got {manifest_hits} (may include key+value hits)")
        self.assertGreater(
            opacity_hits, oc_count,
            f"Expected more opacity user properties ({opacity_hits}) than "
            f"controllers ({oc_count}) — some objects without Renderers "
            f"should have opacity but no component. Got fewer props than "
            f"components, which suggests the importer is misbehaving.")

        # ================================================================
        # 11. Reimport idempotency — no duplicate events or curves
        # ================================================================
        ri_events = r.get("reimport_events", -1)
        ri_opacity = r.get("reimport_opacity_curves", -1)
        ri_at = r.get("reimport_audio_trigger", -1)
        ri_oc = r.get("reimport_opacity_controllers", -1)
        ri_ac = r.get("reimport_audio_controllers", -1)

        print(f"\n  Reimport idempotency:")
        print(f"    Events:        {total_events} -> {ri_events}")
        print(f"    Opa curves:    {oc_curves_rebound} -> {ri_opacity}")
        print(f"    audio_trigger: {at_curves} -> {ri_at}")
        print(f"    Opa ctrls:     {oc_count} -> {ri_oc}")
        print(f"    Audio ctrls:   {ac_count} -> {ri_ac}")

        self.assertEqual(
            ri_events, total_events,
            f"Reimport changed event count: {total_events} -> {ri_events} "
            f"— duplicate AnimationEvents injected!")
        self.assertEqual(
            ri_opacity, oc_curves_rebound,
            f"Reimport changed opacity curves: {oc_curves_rebound} -> "
            f"{ri_opacity} — duplicate curves synthesized!")
        self.assertEqual(
            ri_at, 0,
            f"Reimport resurrected {ri_at} audio_trigger curves")
        self.assertEqual(
            ri_oc, oc_count,
            f"Reimport changed opacity controllers: {oc_count} -> {ri_oc}")
        self.assertEqual(
            ri_ac, ac_count,
            f"Reimport changed audio controllers: {ac_count} -> {ri_ac}")

        # ================================================================
        # 12. AnimationMode runtime — curves drive component properties
        # ================================================================
        anim_error = r.get("anim_sample_error")
        if anim_error:
            self.fail(f"AnimationMode sampling failed: {anim_error}")

        anim_count = r.get("anim_sample_count", 0)
        changed_15 = r.get("anim_sample_changed_by_t15", 0)
        changed_500 = r.get("anim_sample_changed_by_t500", 0)
        anim_details = r.get("anim_sample_details", [])

        print(f"\n  AnimationMode runtime sampling:")
        print(f"    Controllers sampled: {anim_count}")
        print(f"    Changed by t=15s:    {changed_15}")
        print(f"    Changed by t=500s:   {changed_500}")
        if anim_details:
            for d in anim_details[:5]:
                print(f"      {d}")
            if len(anim_details) > 5:
                print(f"      ... and {len(anim_details) - 5} more")

        self.assertGreater(
            anim_count, 0,
            "No RenderOpacityControllers sampled via AnimationMode")
        self.assertGreater(
            changed_15 + changed_500, 0,
            f"No opacity values changed between t=0 and t=15s/t=500s — "
            f"curves may not be driving RenderOpacityController.opacity")

        print("=" * 70)
        print(f"  Temp dir: {self.temp_dir}")
        print("=" * 70 + "\n")

    # ------------------------------------------------------------------
    # Step 3: Optional GUI launch for manual inspection
    # ------------------------------------------------------------------

    @unittest.skipUnless(
        os.environ.get("C130_MANUAL", "").strip() == "1",
        "Set C130_MANUAL=1 to open Unity GUI for manual inspection")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_03_gui_launch(self):
        """Open the Unity Editor GUI for manual play-mode inspection.

        Run with: C130_MANUAL=1 python -m pytest <this_file> -k test_03
        """
        self.assertTrue(
            os.path.isdir(self.project_path),
            "Unity project not found — test_01 must run first")

        launcher = UnityLauncher()
        launcher.project_path = self.project_path

        logger.info(f"Opening Unity Editor at: {self.project_path}")
        proc = launcher.launch_editor(batch_mode=False, detached=True)
        self.assertIsNotNone(proc, "Failed to launch Unity Editor")

        print("\n" + "=" * 70)
        print("  MANUAL INSPECTION MODE")
        print("=" * 70)
        print(f"  Unity project: {self.project_path}")
        print(f"  FBX asset:     Assets/C130_FCR_Speedrun_Assembly_copy.fbx")
        print(f"  Audio:         Assets/Audio/ ({EXPECTED_AUDIO_FILE_COUNT} clips)")
        print()
        print("  To test:")
        print("    1. Drag the FBX into the scene hierarchy")
        print("    2. Select an object with AudioEventController")
        print("    3. Enter Play mode — audio should play at keyed frames")
        print("    4. Check opacity objects fade in/out during animation")
        print("=" * 70 + "\n")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    unittest.main()
