# !/usr/bin/python
# coding=utf-8
"""
Round-trip test: Maya custom attributes -> FBX -> Unity property readback.

Tests which attribute types and encoding strategies survive the
Maya -> FBX -> Unity pipeline, to inform the design of an audio trigger system.

Scenarios tested:
    1. Float attribute (baseline — known to work from opacity)
    2. Integer/Enum attribute (keyable enum -> does Unity see the int?)
    3. Static string attribute (non-keyed metadata -> does it arrive?)
    4. JSON-in-string attribute (structured data -> does quoting survive?)
    5. Animated enum with stepped tangents (does Unity get clean integers?)
    6. Multiple enum attrs on same object (can we layer triggers?)

Requires:
    - Maya 2025 installed (mayapy.exe)
    - Unity Hub with at least one editor installed
"""
import os
import sys
import json
import shutil
import tempfile
import unittest
import subprocess
import logging

logger = logging.getLogger(__name__)

scripts_dir = r"O:\Cloud\Code\_scripts"
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

from unitytk import UnityLauncher, UnityFinder

MAYAPY = r"C:\Program Files\Autodesk\Maya2025\bin\mayapy.exe"


def _maya_available() -> bool:
    return os.path.exists(MAYAPY)


def _unity_available() -> bool:
    return bool(UnityFinder.find_editors())


# ======================================================================
# Maya-side script — creates objects with various attribute types
# ======================================================================

MAYA_EXPORT_SCRIPT = r'''
"""
Executed inside mayapy.
Creates a cube with multiple custom attribute types and exports FBX.
Each attribute tests a different data-transport scenario.
"""
import sys, os, json

for pkg_dir in (r"O:\Cloud\Code\_scripts\mayatk", r"O:\Cloud\Code\_scripts\pythontk"):
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

import maya.standalone
maya.standalone.initialize(name="python")
import maya.cmds as cmds
import pymel.core as pm

output_dir = sys.argv[1]
fbx_path = os.path.join(output_dir, "audio_attr_test.fbx")

cmds.file(new=True, force=True)
pm.playbackOptions(min=1, max=60)

cube = pm.polyCube(name="AudioTestCube")[0]

# ---------------------------------------------------------------
# Scenario 1: Float attribute (baseline, should always work)
# ---------------------------------------------------------------
pm.addAttr(cube, ln="float_baseline", at="float", k=True, min=0, max=1, dv=0.5)
pm.setKeyframe(cube, attribute="float_baseline", time=1,  value=0.0)
pm.setKeyframe(cube, attribute="float_baseline", time=30, value=1.0)
pm.setKeyframe(cube, attribute="float_baseline", time=60, value=0.0)

# ---------------------------------------------------------------
# Scenario 2: Enum attribute (keyable)
# ---------------------------------------------------------------
pm.addAttr(cube, ln="audio_trigger", at="enum",
           en="None:Footstep:Jump:Land", k=True)

# ---------------------------------------------------------------
# Scenario 3: Static string attribute (non-animated metadata)
# ---------------------------------------------------------------
pm.addAttr(cube, ln="audio_manifest", dt="string")
cube.audio_manifest.set("None,Footstep,Jump,Land")

# ---------------------------------------------------------------
# Scenario 4: JSON-in-string (complex metadata)
# ---------------------------------------------------------------
pm.addAttr(cube, ln="audio_json", dt="string")
manifest = {
    "clips": {
        "Footstep": {"file": "sfx/footstep.wav", "duration": 0.45},
        "Jump":     {"file": "sfx/jump.wav",      "duration": 0.30},
        "Land":     {"file": "sfx/land.wav",       "duration": 0.60},
    }
}
cube.audio_json.set(json.dumps(manifest))

# ---------------------------------------------------------------
# Scenario 5: Animated enum with stepped tangents
# ---------------------------------------------------------------
pm.setKeyframe(cube, attribute="audio_trigger", time=1,  value=0, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=10, value=1, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=20, value=0, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=30, value=2, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=40, value=0, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=50, value=3, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger", time=60, value=0, itt="stepnext", ott="step")

# ---------------------------------------------------------------
# Scenario 6: Second enum on same object (layered triggers)
# ---------------------------------------------------------------
pm.addAttr(cube, ln="audio_trigger_2", at="enum",
           en="None:Ambient:Wind", k=True)
pm.setKeyframe(cube, attribute="audio_trigger_2", time=1,  value=0, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger_2", time=15, value=1, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger_2", time=45, value=2, itt="stepnext", ott="step")
pm.setKeyframe(cube, attribute="audio_trigger_2", time=60, value=0, itt="stepnext", ott="step")

# ---------------------------------------------------------------
# Carrier animation (required for FBX to include a Take)
# ---------------------------------------------------------------
pm.setKeyframe(cube, attribute="translateY", time=1,  value=0)
pm.setKeyframe(cube, attribute="translateY", time=60, value=3)

# ---------------------------------------------------------------
# Export FBX
# ---------------------------------------------------------------
pm.select(cube)
if not cmds.pluginInfo("fbxmaya", q=True, loaded=True):
    cmds.loadPlugin("fbxmaya")
pm.mel.eval("FBXResetExport")
pm.mel.eval("FBXExportBakeComplexAnimation -v true")
pm.mel.eval("FBXExportBakeComplexStart -v 1")
pm.mel.eval("FBXExportBakeComplexEnd -v 60")
pm.mel.eval('FBXProperty "Export|AdvOptGrp|UI|ShowWarningsManager" -v 0')
fbx_mel = fbx_path.replace("\\", "/")
pm.mel.eval(f'FBXExport -f "{fbx_mel}" -s')

# ---------------------------------------------------------------
# Also dump the raw FBX as ASCII for offline inspection
# ---------------------------------------------------------------
ascii_path = fbx_path.replace(".fbx", "_ascii.fbx")
pm.mel.eval("FBXExportFileVersion -v FBX201400")
pm.mel.eval("FBXExportInAscii -v true")
pm.mel.eval(f'FBXExport -f "{ascii_path.replace(chr(92), "/")}" -s')

# ---------------------------------------------------------------
# Collect Maya-side results
# ---------------------------------------------------------------
results = {
    "fbx_path": fbx_path,
    "fbx_exists": os.path.exists(fbx_path),
    "ascii_fbx_path": ascii_path,
    "ascii_fbx_exists": os.path.exists(ascii_path),
    "scenarios": {
        "1_float_baseline": {
            "attr": "float_baseline",
            "type": "float",
            "value": cube.float_baseline.get(),
        },
        "2_enum_animated": {
            "attr": "audio_trigger",
            "type": "enum",
            "enum_string": "None:Footstep:Jump:Land",
            "keyframes": {
                str(int(t)): int(v)
                for t, v in zip(
                    pm.keyframe(cube, at="audio_trigger", q=True, tc=True),
                    pm.keyframe(cube, at="audio_trigger", q=True, vc=True),
                )
            },
        },
        "3_static_string": {
            "attr": "audio_manifest",
            "type": "string",
            "value": cube.audio_manifest.get(),
        },
        "4_json_string": {
            "attr": "audio_json",
            "type": "string",
            "value": cube.audio_json.get(),
        },
        "5_animated_enum_stepped": {
            "attr": "audio_trigger",
            "note": "Same attr as scenario 2, testing stepped tangent export",
        },
        "6_second_enum": {
            "attr": "audio_trigger_2",
            "type": "enum",
            "enum_string": "None:Ambient:Wind",
            "keyframes": {
                str(int(t)): int(v)
                for t, v in zip(
                    pm.keyframe(cube, at="audio_trigger_2", q=True, tc=True),
                    pm.keyframe(cube, at="audio_trigger_2", q=True, vc=True),
                )
            },
        },
    },
}

with open(os.path.join(output_dir, "maya_results.json"), "w") as f:
    json.dump(results, f, indent=2)

print("MAYA EXPORT COMPLETE")
maya.standalone.uninitialize()
'''


# ======================================================================
# Unity-side C# verifier — reads back all attributes
# ======================================================================

UNITY_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class AudioAttrVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";
        string fbxAssetPath = "Assets/audio_attr_test.fbx";

        // ---- Step 1: Enable animated custom properties and reimport ----
        var importer = AssetImporter.GetAtPath(fbxAssetPath) as ModelImporter;
        if (importer != null)
        {
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            importer.importAnimatedCustomProperties = true;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAssetPath);
            AssetDatabase.ImportAsset(fbxAssetPath,
                ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh();

        // ---- Results container ----
        var results = new Dictionary<string, object>();

        // ---- Step 3: Check animation curves ----
        var clips = AssetDatabase.LoadAllAssetsAtPath(fbxAssetPath)
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__"))
            .ToArray();

        var curveReport = new Dictionary<string, object>();

        if (clips.Length > 0)
        {
            var clip = clips[0];
            var bindings = AnimationUtility.GetCurveBindings(clip);

            foreach (var binding in bindings)
            {
                var curve = AnimationUtility.GetEditorCurve(clip, binding);
                var keyInfo = new List<string>();
                if (curve != null)
                {
                    foreach (var key in curve.keys)
                    {
                        bool isStepped = (key.outTangent == float.PositiveInfinity ||
                                          key.outTangent == float.NegativeInfinity ||
                                          float.IsInfinity(key.outTangent));
                        keyInfo.Add("t=" + key.time.ToString("F2")
                            + " v=" + key.value.ToString("F4")
                            + " stepped=" + isStepped);
                    }
                }

                var entry = new Dictionary<string, object>();
                entry["path"] = binding.path;
                entry["type"] = binding.type.Name;
                entry["property"] = binding.propertyName;
                entry["key_count"] = curve != null ? curve.length : 0;
                entry["keys"] = keyInfo.ToArray();
                curveReport[binding.propertyName] = entry;
            }
        }
        results["clips_found"] = clips.Length;
        results["curves"] = curveReport;

        // ---- Step 4: User properties via postprocessor log ----
        string postprocResults = Path.Combine(
            Path.GetDirectoryName(resultsFile), "postprocessor_results.json");
        if (File.Exists(postprocResults))
        {
            results["user_properties"] = File.ReadAllText(postprocResults);
        }
        else
        {
            results["user_properties"] = "postprocessor did not fire (file not found)";
        }

        // ---- Step 5: Scenario verdicts ----
        var verdicts = new Dictionary<string, object>();

        // S1: Float baseline
        bool hasFloat = curveReport.ContainsKey("float_baseline");
        var v1 = new Dictionary<string, object>();
        v1["found_curve"] = hasFloat;
        v1["pass"] = hasFloat;
        verdicts["1_float_baseline"] = v1;

        // S2: Animated enum
        bool hasEnumCurve = curveReport.ContainsKey("audio_trigger");
        var v2 = new Dictionary<string, object>();
        v2["found_curve"] = hasEnumCurve;
        v2["pass"] = hasEnumCurve;
        verdicts["2_enum_animated"] = v2;

        // S5: Stepped tangents preserved
        bool steppedOk = false;
        if (hasEnumCurve)
        {
            var enumEntry = curveReport["audio_trigger"] as Dictionary<string, object>;
            if (enumEntry != null)
            {
                var keys = enumEntry["keys"] as string[];
                if (keys != null)
                {
                    steppedOk = keys.All(k => k.Contains("stepped=True"));
                }
            }
        }
        var v5 = new Dictionary<string, object>();
        v5["all_stepped"] = steppedOk;
        v5["pass"] = steppedOk;
        verdicts["5_stepped_tangents"] = v5;

        // S6: Second enum curve
        bool hasSecond = curveReport.ContainsKey("audio_trigger_2");
        var v6 = new Dictionary<string, object>();
        v6["found_curve"] = hasSecond;
        v6["pass"] = hasSecond;
        verdicts["6_second_enum"] = v6;

        results["verdicts"] = verdicts;

        // ---- Write results ----
        File.WriteAllText(resultsFile, DictToJson(results));
        Debug.Log("AUDIO ATTR VERIFICATION COMPLETE. Results at: " + resultsFile);

        EditorApplication.Exit(0);
    }

    // Minimal recursive dict-to-JSON (no external deps in Unity)
    static string DictToJson(Dictionary<string, object> dict)
    {
        var parts = new List<string>();
        foreach (var kv in dict)
        {
            string val;
            if (kv.Value is Dictionary<string, object> subDict)
                val = DictToJson(subDict);
            else if (kv.Value is string[] arr)
                val = "[" + string.Join(",", System.Array.ConvertAll(arr,
                    s => "\"" + Escape(s) + "\"")) + "]";
            else if (kv.Value is string s)
                val = "\"" + Escape(s) + "\"";
            else if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + Escape(kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("\"" + Escape(kv.Key) + "\": " + val);
        }
        return "{" + string.Join(",\n", parts) + "}";
    }

    static string Escape(string s)
    {
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n");
    }
}
"""

# ======================================================================
# Unity-side postprocessor — fires on FBX import to capture user properties
# ======================================================================

UNITY_POSTPROCESSOR_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;
using System.Linq;

public class AudioAttrPostprocessor : AssetPostprocessor
{
    const string RESULTS_DIR = @"__RESULTS_DIR__";

    // Enable animated custom property import BEFORE the model is processed
    void OnPreprocessModel()
    {
        var importer = assetImporter as ModelImporter;
        if (importer != null && !importer.importAnimatedCustomProperties)
        {
            importer.importAnimatedCustomProperties = true;
        }
    }

    void OnPostprocessGameObjectWithUserProperties(
        GameObject go, string[] propNames, object[] values)
    {
        // Capture everything the FBX gives us
        var entries = new List<string>();
        for (int i = 0; i < propNames.Length; i++)
        {
            string typeName = values[i] != null ? values[i].GetType().Name : "null";
            string valStr = values[i] != null ? values[i].ToString() : "null";
            entries.Add("  \"" + Escape(propNames[i]) + "\": {\"type\": \""
                + typeName + "\", \"value\": \"" + Escape(valStr) + "\"}");
        }

        // Write to disk immediately (postprocessor runs during import)
        string outPath = Path.Combine(RESULTS_DIR, "postprocessor_results.json");
        string json = "{\n  \"gameObject\": \"" + go.name + "\",\n"
            + string.Join(",\n", entries) + "\n}";
        File.WriteAllText(outPath, json);

        Debug.Log("[AudioAttrPostprocessor] Captured " + propNames.Length
            + " user properties on " + go.name);
    }

    static string Escape(string s)
    {
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n");
    }
}
"""

# ======================================================================
# Test class
# ======================================================================


class TestAudioTriggerRoundTrip(unittest.TestCase):
    """
    Full pipeline test: Maya attributes -> FBX -> Unity readback.

    Verifies which attribute types survive the round-trip to inform
    the audio trigger system design.
    """

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="audio_roundtrip_")
        cls.fbx_path = None
        cls.maya_results = None
        cls.unity_results = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        # Keep temp dir for inspection
        logger.info(f"Results preserved in: {cls.temp_dir}")

    # ------------------------------------------------------------------
    # Step 1: Maya export
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    def test_01_maya_export(self):
        """Create test object with all attribute scenarios, export FBX."""
        script_path = os.path.join(self.temp_dir, "maya_export.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(MAYA_EXPORT_SCRIPT)

        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join(
            [
                os.path.join(scripts_dir, "mayatk"),
                os.path.join(scripts_dir, "pythontk"),
            ]
        )
        env["PYTHONIOENCODING"] = "utf-8"

        proc = subprocess.run(
            [MAYAPY, script_path, self.temp_dir],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        if proc.stdout:
            logger.info(f"MAYAPY stdout:\n{proc.stdout[-2000:]}")
        if proc.stderr:
            logger.warning(f"MAYAPY stderr:\n{proc.stderr[-2000:]}")

        self.assertEqual(proc.returncode, 0, f"mayapy failed:\n{proc.stderr[-1000:]}")

        results_path = os.path.join(self.temp_dir, "maya_results.json")
        self.assertTrue(os.path.exists(results_path), "maya_results.json not created")

        with open(results_path) as f:
            self.__class__.maya_results = json.load(f)

        self.__class__.fbx_path = self.__class__.maya_results["fbx_path"]
        self.assertTrue(
            self.__class__.maya_results["fbx_exists"], "FBX file was not created"
        )

    # ------------------------------------------------------------------
    # Step 1b: Offline FBX ASCII inspection (no Unity needed)
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    def test_02_fbx_ascii_inspection(self):
        """Parse the ASCII FBX to see which properties made it into the file."""
        maya_results = self.__class__.maya_results
        if not maya_results:
            self.skipTest("Maya export not available — test_01 must run first")

        ascii_path = maya_results.get("ascii_fbx_path", "")
        if not os.path.exists(ascii_path):
            self.skipTest("ASCII FBX not created")

        with open(ascii_path, "r", encoding="utf-8", errors="replace") as f:
            fbx_text = f.read()

        # Check which of our attributes appear in the raw FBX text
        attrs_to_find = [
            "float_baseline",
            "audio_trigger",
            "audio_manifest",
            "audio_json",
            "audio_trigger_2",
        ]
        fbx_report = {}
        for attr in attrs_to_find:
            found = attr in fbx_text
            # Try to extract the P: line for this attribute
            pline = ""
            for line in fbx_text.split("\n"):
                if f'"{attr}"' in line and line.strip().startswith("P:"):
                    pline = line.strip()
                    break
            fbx_report[attr] = {"in_fbx": found, "p_line": pline}

        # Save report
        report_path = os.path.join(self.temp_dir, "fbx_ascii_report.json")
        with open(report_path, "w") as f:
            json.dump(fbx_report, f, indent=2)

        logger.info(f"FBX ASCII attribute report:\n{json.dumps(fbx_report, indent=2)}")

        # Float baseline must be present (known working pattern)
        self.assertTrue(
            fbx_report["float_baseline"]["in_fbx"],
            "float_baseline not found in ASCII FBX — export is broken",
        )

    # ------------------------------------------------------------------
    # Step 2: Unity import and readback
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_03_unity_import(self):
        """Import FBX into Unity, verify which attributes survived."""
        fbx_path = self.__class__.fbx_path
        if not fbx_path or not os.path.exists(fbx_path):
            self.skipTest("FBX not available — test_01 must run first")

        # -- Create temp Unity project --
        launcher = UnityLauncher()
        project_path = os.path.join(self.temp_dir, "UnityProject")

        logger.info(f"Creating Unity project: {project_path}")
        created = launcher.create_project(project_path, batch_mode=True)
        self.assertTrue(created, "Failed to create Unity project")

        # -- Copy FBX into Assets/ --
        assets_path = os.path.join(project_path, "Assets")
        dest_fbx = os.path.join(assets_path, "audio_attr_test.fbx")
        shutil.copy2(fbx_path, dest_fbx)

        # -- Deploy postprocessor (must exist BEFORE reimport) --
        editor_path = os.path.join(assets_path, "Editor")
        os.makedirs(editor_path, exist_ok=True)

        results_dir_escaped = self.temp_dir.replace("\\", "\\\\")
        postproc_cs = UNITY_POSTPROCESSOR_CS.replace(
            "__RESULTS_DIR__", results_dir_escaped
        )
        with open(
            os.path.join(editor_path, "AudioAttrPostprocessor.cs"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write(postproc_cs)

        # -- Deploy verifier --
        results_path = os.path.join(self.temp_dir, "unity_results.json")
        results_path_escaped = results_path.replace("\\", "\\\\")
        verifier_cs = UNITY_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path_escaped
        )
        with open(
            os.path.join(editor_path, "AudioAttrVerifier.cs"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write(verifier_cs)

        # -- Run Unity in batch mode --
        log_path = os.path.join(self.temp_dir, "unity_log.txt")
        launcher.project_path = project_path

        proc = launcher.launch_editor(
            batch_mode=True,
            execute_method="AudioAttrVerifier.Verify",
            log_file=log_path,
            extra_args=["-quit"],
            detached=False,
        )

        if proc:
            try:
                proc.wait(timeout=300)
            except subprocess.TimeoutExpired:
                proc.kill()
                raise TimeoutError("Unity timed out")

        # -- Read Unity log for debugging --
        if os.path.exists(log_path):
            with open(log_path) as f:
                log_tail = f.read()[-5000:]
            logger.info(f"Unity log tail:\n{log_tail}")

        # -- Read postprocessor results (user properties) --
        postproc_path = os.path.join(self.temp_dir, "postprocessor_results.json")
        if os.path.exists(postproc_path):
            with open(postproc_path) as f:
                postproc_data = json.load(f)
            logger.info(
                f"Postprocessor user properties:\n{json.dumps(postproc_data, indent=2)}"
            )
        else:
            postproc_data = None
            logger.warning(
                "Postprocessor results not found — callback may not have fired"
            )

        # -- Read verifier results (animation curves) --
        self.assertTrue(
            os.path.exists(results_path),
            f"unity_results.json not created — check {log_path}",
        )
        with open(results_path) as f:
            self.__class__.unity_results = json.load(f)

        logger.info(
            f"Unity curve results:\n"
            f"{json.dumps(self.__class__.unity_results, indent=2)}"
        )

    # ------------------------------------------------------------------
    # Step 3: Analyze results and produce verdict
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_04_analyze_results(self):
        """Produce a summary of what survived the round-trip."""
        unity = self.__class__.unity_results
        if not unity:
            self.skipTest("Unity results not available — test_03 must run first")

        verdicts = unity.get("verdicts", {})

        # Read postprocessor results if available
        postproc_path = os.path.join(self.temp_dir, "postprocessor_results.json")
        postproc = {}
        if os.path.exists(postproc_path):
            with open(postproc_path) as f:
                postproc = json.load(f)

        # Build final report
        report = {
            "scenario_1_float_baseline": {
                "description": "Float attr (0-1) — known working pattern from opacity",
                "curve_survived": verdicts.get("1_float_baseline", {}).get(
                    "found_curve", False
                ),
                "user_prop_received": "float_baseline" in postproc,
            },
            "scenario_2_enum_animated": {
                "description": "Enum attr keyed as stepped integers",
                "curve_survived": verdicts.get("2_enum_animated", {}).get(
                    "found_curve", False
                ),
                "user_prop_received": "audio_trigger" in postproc,
                "user_prop_type": postproc.get("audio_trigger", {}).get("type", "N/A"),
            },
            "scenario_3_static_string": {
                "description": "Non-animated string attr (clip name list)",
                "user_prop_received": "audio_manifest" in postproc,
                "user_prop_value": postproc.get("audio_manifest", {}).get(
                    "value", "NOT RECEIVED"
                ),
            },
            "scenario_4_json_string": {
                "description": "JSON blob in a string attr",
                "user_prop_received": "audio_json" in postproc,
                "user_prop_value_preview": postproc.get("audio_json", {}).get(
                    "value", "NOT RECEIVED"
                )[:100],
            },
            "scenario_5_stepped_tangents": {
                "description": "Enum curve keys are stepped (no interpolation)",
                "all_stepped": verdicts.get("5_stepped_tangents", {}).get(
                    "all_stepped", False
                ),
            },
            "scenario_6_second_enum": {
                "description": "Two independent enum curves on same object",
                "curve_survived": verdicts.get("6_second_enum", {}).get(
                    "found_curve", False
                ),
                "user_prop_received": "audio_trigger_2" in postproc,
            },
        }

        # Save final report
        report_path = os.path.join(self.temp_dir, "FINAL_REPORT.json")
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2)

        # Print summary
        print("\n" + "=" * 72)
        print("  AUDIO TRIGGER ROUND-TRIP TEST RESULTS")
        print("=" * 72)
        for name, data in report.items():
            status_parts = []
            if "curve_survived" in data:
                status_parts.append(
                    f"curve={'PASS' if data['curve_survived'] else 'FAIL'}"
                )
            if "user_prop_received" in data:
                status_parts.append(
                    f"user_prop={'PASS' if data['user_prop_received'] else 'FAIL'}"
                )
            if "all_stepped" in data:
                status_parts.append(
                    f"stepped={'PASS' if data['all_stepped'] else 'FAIL'}"
                )
            status = " | ".join(status_parts)
            print(f"\n  {name}:")
            print(f"    {data['description']}")
            print(f"    Result: {status}")
            if "user_prop_value" in data:
                print(f"    Value: {data['user_prop_value']}")
            if "user_prop_value_preview" in data:
                print(f"    Value: {data['user_prop_value_preview']}...")
        print("\n" + "=" * 72)
        print(f"  Full report: {report_path}")
        print(f"  Temp dir:    {self.temp_dir}")
        print("=" * 72 + "\n")

        # The float baseline MUST pass — it's our sanity check
        self.assertTrue(
            report["scenario_1_float_baseline"]["curve_survived"],
            "Float baseline curve did not survive — FBX pipeline is broken",
        )


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    unittest.main()
