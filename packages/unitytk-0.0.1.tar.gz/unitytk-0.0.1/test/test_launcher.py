import unittest
import os
import sys
from unittest.mock import patch, MagicMock

# Ensure unitytk and module imports work whether run directly or via runner
try:
    from .base_test import UnityTkTestCase
except ImportError:
    # If run directly from file, adjust path to find base_test
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from base_test import UnityTkTestCase

from unitytk.launcher import UnityFinder, UnityLauncher


class TestUnityLauncher(UnityTkTestCase):
    @patch("unitytk.launcher.UnityFinder.get_hub_editor_path")
    @patch("os.listdir")
    @patch("os.path.isdir")
    @patch("os.path.exists")
    @patch("platform.system")
    def test_find_editors_windows(
        self, mock_system, mock_exists, mock_isdir, mock_listdir, mock_get_hub
    ):
        """Verify that find_editors correctly identifies Unity executables on Windows."""
        mock_system.return_value = "windows"
        mock_get_hub.return_value = "C:\\Hub"
        mock_listdir.return_value = ["2021.1.0f1", "2022.2.0b1"]

        # Mock isdir behavior: return True if path contains the mocked versions
        mock_isdir.return_value = True

        # Mock existence: Hub exists, and the Unity.exe inside the version folders exist
        mock_exists.side_effect = lambda p: (
            True if p == "C:\\Hub" or "Unity.exe" in p else False
        )

        editors = UnityFinder.find_editors()

        self.assertIn("2021.1.0f1", editors)
        self.assertIn("2022.2.0b1", editors)
        self.assertEqual(
            editors["2021.1.0f1"],
            os.path.join("C:\\Hub", "2021.1.0f1", "Editor", "Unity.exe"),
        )

    @patch("unitytk.launcher.UnityFinder.find_editors")
    def test_launcher_auto_select(self, mock_find):
        """Verify that UnityLauncher automatically selects the latest version if none specified."""
        mock_find.return_value = {
            "2020.3.15f2": "path/2020/Unity.exe",
            "2022.1.0f1": "path/2022/Unity.exe",
        }

        # Test auto-selection
        launcher = UnityLauncher()
        self.assertEqual(launcher.executable_path, "path/2022/Unity.exe")

    @patch("os.path.exists")
    @patch("unitytk.launcher.UnityFinder.find_editors")
    def test_launcher_explicit_path(self, mock_find, mock_exists):
        """Verify that UnityLauncher respects an explicit executable path."""
        # Mock file existence so it accepts the path directly
        mock_exists.return_value = True

        # Even if find_editors fails or returns empty, strict path should be respected if it exists
        mock_find.return_value = {}

        launcher = UnityLauncher(executable_path="C:/Custom/Unity.exe")
        self.assertEqual(launcher.executable_path, "C:/Custom/Unity.exe")

    @patch("unitytk.launcher.AppLauncher.launch")
    def test_launch_batch_mode(self, mock_launch):
        """Verify arguments for batch mode launch."""
        launcher = UnityLauncher(executable_path="C:/Unity.exe", project_path="C:/Proj")
        launcher.launch_editor(
            batch_mode=True, execute_method="Build.Run", log_file="build.log"
        )

        args, kwargs = mock_launch.call_args
        command_args = kwargs["args"]

        self.assertIn("-batchmode", command_args)
        self.assertIn("-nographics", command_args)
        self.assertIn("-projectPath", command_args)
        self.assertIn("C:/Proj", command_args)
        self.assertIn("-executeMethod", command_args)
        self.assertIn("Build.Run", command_args)
        self.assertIn("-logFile", command_args)
        self.assertIn("build.log", command_args)


if __name__ == "__main__":
    unittest.main()
