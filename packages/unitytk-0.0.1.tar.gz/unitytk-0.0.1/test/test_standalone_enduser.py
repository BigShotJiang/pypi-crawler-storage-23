# !/usr/bin/python
# coding=utf-8
"""
Standalone end-user simulation test.

Proves that the two C# template files + FBX + audio = 100% working
with ZERO unitytk / Python dependency on the Unity side.

End-user workflow being validated:
    1. Create/open any Unity project
    2. Drop RenderOpacityController.cs + AudioEventController.cs into Assets/Scripts/
    3. Drop the FBX into Assets/
    4. Drop audio MP3s into Assets/Audio/
    5. Done — everything auto-wires on import

This test does NOT import unitytk.  It finds Unity, creates a project,
copies raw files, and verifies results using only stdlib + subprocess.
"""
import os
import sys
import json
import shutil
import tempfile
import unittest
import subprocess
import logging
import re
import glob

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Source paths (same FBX + audio the end-user would have)
# ---------------------------------------------------------------------------

FBX_PATH = (
    r"O:\Dropbox (Moth+Flame)\Moth+Flame Dropbox\Ryan Simpson"
    r"\_tests\audio_files\C130_FCR_Speedrun_Assembly_copy.fbx"
)
AUDIO_DIR = (
    r"O:\Dropbox (Moth+Flame)\Moth+Flame Dropbox\Ryan Simpson"
    r"\_tests\audio_files\C-130H FCR Audio Files"
)

# Template CS files — these are the ONLY deliverables
TEMPLATE_DIR = os.path.join(
    os.path.dirname(__file__), os.pardir, "unitytk", "templates"
)
CS_FILES = [
    "RenderOpacityController.cs",
    "AudioEventController.cs",
]

# Expected counts
EXPECTED_AUDIO_COUNT = 71
EXPECTED_MIN_OPACITY_CONTROLLERS = 45
EXPECTED_MIN_OPACITY_CURVES = 33
MAX_KEYS_PER_CURVE = 30


# ---------------------------------------------------------------------------
# Unity finder — no unitytk dependency
# ---------------------------------------------------------------------------


def _find_unity_exe() -> str:
    """Find the latest Unity Editor executable via Hub default path."""
    hub = r"C:\Program Files\Unity\Hub\Editor"
    if not os.path.isdir(hub):
        return ""
    versions = sorted(
        [d for d in os.listdir(hub) if os.path.isdir(os.path.join(hub, d))],
        reverse=True,
    )
    for v in versions:
        exe = os.path.join(hub, v, "Editor", "Unity.exe")
        if os.path.isfile(exe):
            return exe
    return ""


def _sources_ok() -> bool:
    return (
        os.path.isfile(FBX_PATH)
        and os.path.isdir(AUDIO_DIR)
        and all(os.path.isfile(os.path.join(TEMPLATE_DIR, f)) for f in CS_FILES)
    )


# ---------------------------------------------------------------------------
# Minimal C# verifier (deployed to Assets/Editor/ — NOT part of deliverables)
# ---------------------------------------------------------------------------

VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class StandaloneVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";

        // Force reimport — simulates "user drags FBX into project"
        string fbxAsset = "Assets/C130_FCR_Speedrun_Assembly_copy.fbx";
        var importer = AssetImporter.GetAtPath(fbxAsset) as ModelImporter;
        if (importer != null)
        {
            // DO NOT set importAnimatedCustomProperties here!
            // The whole point is to prove the importer handles it.
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAsset);
            AssetDatabase.ImportAsset(fbxAsset,
                ImportAssetOptions.ForceUpdate |
                ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var results = new Dictionary<string, object>();

        // --- Instantiate prefab ---
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        results["prefab_loaded"] = prefab != null;

        if (prefab != null)
        {
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            var allT = instance.GetComponentsInChildren<Transform>(true);
            results["total_objects"] = allT.Length;

            // Opacity controllers
            var ocs = instance.GetComponentsInChildren<RenderOpacityController>(true);
            results["opacity_controllers"] = ocs.Length;
            int withRend = 0;
            foreach (var oc in ocs)
                if (oc.GetComponent<Renderer>() != null) withRend++;
            results["opacity_with_renderer"] = withRend;

            // Audio controllers
            var acs = instance.GetComponentsInChildren<AudioEventController>(true);
            results["audio_controllers"] = acs.Length;
            int totalClips = 0;
            int matchedClips = 0;
            var details = new List<string>();
            foreach (var ac in acs)
            {
                int m = ac.clips != null ? ac.clips.Count(c => c != null) : 0;
                int t = ac.clips != null ? ac.clips.Count : 0;
                totalClips += t;
                matchedClips += m;
                details.Add(ac.gameObject.name + ":" + m + "/" + t);
            }
            results["audio_total_clips"] = totalClips;
            results["audio_matched_clips"] = matchedClips;
            results["audio_details"] = details.ToArray();

            Object.DestroyImmediate(instance);
        }

        // --- Animation curve analysis ---
        var allAssets = AssetDatabase.LoadAllAssetsAtPath(fbxAsset);
        var clips = allAssets.OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();

        int opacityCurves = 0;
        int mEnabledCurves = 0;
        int audioTriggerCurves = 0;
        int totalEvents = 0;
        int onAudioEvents = 0;
        var keyCounts = new List<int>();

        foreach (var clip in clips)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var events = AnimationUtility.GetAnimationEvents(clip);
            totalEvents += events.Length;
            onAudioEvents += events.Count(e => e.functionName == "OnAudioEvent");

            foreach (var b in bindings)
            {
                if (b.propertyName == "opacity" &&
                    b.type == typeof(RenderOpacityController))
                {
                    opacityCurves++;
                    var curve = AnimationUtility.GetEditorCurve(clip, b);
                    if (curve != null) keyCounts.Add(curve.length);
                }
                if (b.propertyName == "m_Enabled" &&
                    b.type == typeof(Renderer))
                    mEnabledCurves++;
                if (b.propertyName == "audio_trigger")
                    audioTriggerCurves++;
            }
        }

        results["opacity_curves"] = opacityCurves;
        results["m_enabled_curves"] = mEnabledCurves;
        results["audio_trigger_curves"] = audioTriggerCurves;
        results["total_anim_events"] = totalEvents;
        results["on_audio_events"] = onAudioEvents;
        results["opacity_key_counts"] = string.Join(",",
            keyCounts.Select(k => k.ToString()));
        results["max_keys"] = keyCounts.Count > 0 ? keyCounts.Max() : 0;

        // Audio assets discovered
        string[] guids = AssetDatabase.FindAssets(
            "t:AudioClip", new[] { "Assets/Audio" });
        results["audio_assets"] = guids.Length;

        // Check import settings — was importAnimatedCustomProperties set?
        var finalImporter = AssetImporter.GetAtPath(fbxAsset) as ModelImporter;
        results["custom_props_enabled"] = finalImporter != null &&
            finalImporter.importAnimatedCustomProperties;

        // --- Reimport idempotency: reimport and verify no duplicates ---
        AssetDatabase.ImportAsset(fbxAsset,
            ImportAssetOptions.ForceUpdate |
            ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var riClips = AssetDatabase.LoadAllAssetsAtPath(fbxAsset)
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();
        int riEvents = 0, riOpacity = 0, riAudioTrigger = 0;
        foreach (var rc in riClips)
        {
            var rev = AnimationUtility.GetAnimationEvents(rc);
            riEvents += rev.Count(e => e.functionName == "OnAudioEvent");
            foreach (var rb in AnimationUtility.GetCurveBindings(rc))
            {
                if (rb.propertyName == "opacity" &&
                    rb.type == typeof(RenderOpacityController))
                    riOpacity++;
                if (rb.propertyName == "audio_trigger")
                    riAudioTrigger++;
            }
        }
        results["reimport_events"] = riEvents;
        results["reimport_opacity_curves"] = riOpacity;
        results["reimport_audio_trigger"] = riAudioTrigger;

        var riPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        if (riPrefab != null)
        {
            var riInst = (GameObject)PrefabUtility.InstantiatePrefab(riPrefab);
            results["reimport_opacity_controllers"] =
                riInst.GetComponentsInChildren<RenderOpacityController>(true).Length;
            results["reimport_audio_controllers"] =
                riInst.GetComponentsInChildren<AudioEventController>(true).Length;
            Object.DestroyImmediate(riInst);
        }

        // --- AnimationMode: prove curves drive component properties ---
        try
        {
            var animPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
            if (animPrefab != null && clips.Length > 0)
            {
                var animInst = (GameObject)PrefabUtility.InstantiatePrefab(animPrefab);
                var animClip = clips[0];
                var animOcs = animInst
                    .GetComponentsInChildren<RenderOpacityController>(true);

                AnimationMode.StartAnimationMode();

                AnimationMode.SampleAnimationClip(animInst, animClip, 0f);
                var vAt0 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt0[ai] = animOcs[ai].opacity;

                AnimationMode.SampleAnimationClip(animInst, animClip, 15f);
                var vAt15 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt15[ai] = animOcs[ai].opacity;

                AnimationMode.SampleAnimationClip(animInst, animClip, 500f);
                var vAt500 = new float[animOcs.Length];
                for (int ai = 0; ai < animOcs.Length; ai++)
                    vAt500[ai] = animOcs[ai].opacity;

                AnimationMode.StopAnimationMode();

                int changedBy15 = 0, changedBy500 = 0;
                for (int ai = 0; ai < animOcs.Length; ai++)
                {
                    if (Mathf.Abs(vAt0[ai] - vAt15[ai]) > 0.001f)
                        changedBy15++;
                    if (Mathf.Abs(vAt0[ai] - vAt500[ai]) > 0.001f)
                        changedBy500++;
                }

                results["anim_sample_count"] = animOcs.Length;
                results["anim_sample_changed_by_t15"] = changedBy15;
                results["anim_sample_changed_by_t500"] = changedBy500;

                var sampleDetails = new List<string>();
                for (int ai = 0; ai < Mathf.Min(animOcs.Length, 15); ai++)
                {
                    sampleDetails.Add(animOcs[ai].gameObject.name +
                        ":t0=" + vAt0[ai].ToString("F3") +
                        ",t15=" + vAt15[ai].ToString("F3") +
                        ",t500=" + vAt500[ai].ToString("F3"));
                }
                results["anim_sample_details"] = sampleDetails.ToArray();

                Object.DestroyImmediate(animInst);
            }
        }
        catch (System.Exception ex)
        {
            Debug.LogWarning(
                "[StandaloneVerifier] AnimationMode sampling failed: " + ex.Message);
            results["anim_sample_error"] = ex.Message;
        }

        // --- Write JSON ---
        var parts = new List<string>();
        foreach (var kv in results)
        {
            string val;
            if (kv.Value is string[] arr)
                val = "[" + string.Join(",",
                    System.Array.ConvertAll(arr,
                        s => "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"")) + "]";
            else if (kv.Value is string s)
                val = "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"") + "\"";
            else if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + (kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("  \"" + kv.Key + "\": " + val);
        }
        File.WriteAllText(resultsFile,
            "{\n" + string.Join(",\n", parts) + "\n}");
        Debug.Log("[StandaloneVerifier] Done: " + resultsFile);
        EditorApplication.Exit(0);
    }
}
"""

# ---------------------------------------------------------------------------
# Order-test C# verifier: imports FBX with forced reimport, collects same
# metrics as StandaloneVerifier.  Used by test_audio_after_fbx.
# ---------------------------------------------------------------------------

ORDER_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class OrderVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";

        // Force reimport
        string fbxAsset = "Assets/C130_FCR_Speedrun_Assembly_copy.fbx";
        var importer = AssetImporter.GetAtPath(fbxAsset) as ModelImporter;
        if (importer != null)
        {
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAsset);
            AssetDatabase.ImportAsset(fbxAsset,
                ImportAssetOptions.ForceUpdate |
                ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var results = new Dictionary<string, object>();

        // Instantiate prefab
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        results["prefab_loaded"] = prefab != null;

        if (prefab != null)
        {
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            var allT = instance.GetComponentsInChildren<Transform>(true);
            results["total_objects"] = allT.Length;

            // Opacity controllers
            var ocs = instance.GetComponentsInChildren<RenderOpacityController>(true);
            results["opacity_controllers"] = ocs.Length;

            // Audio controllers
            var acs = instance.GetComponentsInChildren<AudioEventController>(true);
            results["audio_controllers"] = acs.Length;
            int totalClips = 0, matchedClips = 0;
            foreach (var ac in acs)
            {
                int m = ac.clips != null ? ac.clips.Count(c => c != null) : 0;
                int t = ac.clips != null ? ac.clips.Count : 0;
                totalClips += t;
                matchedClips += m;
            }
            results["audio_total_clips"] = totalClips;
            results["audio_matched_clips"] = matchedClips;

            Object.DestroyImmediate(instance);
        }

        // Animation analysis
        var allAssets = AssetDatabase.LoadAllAssetsAtPath(fbxAsset);
        var clips = allAssets.OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();

        int opacityCurves = 0, onAudioEvents = 0;
        foreach (var clip in clips)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var events = AnimationUtility.GetAnimationEvents(clip);
            onAudioEvents += events.Count(e => e.functionName == "OnAudioEvent");
            foreach (var b in bindings)
            {
                if (b.propertyName == "opacity" &&
                    b.type == typeof(RenderOpacityController))
                    opacityCurves++;
            }
        }
        results["opacity_curves"] = opacityCurves;
        results["on_audio_events"] = onAudioEvents;

        // Audio assets in project
        string[] guids = AssetDatabase.FindAssets(
            "t:AudioClip", new[] { "Assets/Audio" });
        results["audio_assets"] = guids.Length;

        // Write JSON
        var parts = new List<string>();
        foreach (var kv in results)
        {
            string val;
            if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + (kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("  \"" + kv.Key + "\": " + val);
        }
        File.WriteAllText(resultsFile,
            "{\n" + string.Join(",\n", parts) + "\n}");
        Debug.Log("[OrderVerifier] Done: " + resultsFile);
        EditorApplication.Exit(0);
    }
}
"""

# ---------------------------------------------------------------------------
# Allowlist verifier: checks two FBX files (allowed vs decoy) side-by-side
# ---------------------------------------------------------------------------

ALLOWLIST_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class AllowlistVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var results = new Dictionary<string, object>();

        // --- Check ALLOWED FBX ---
        string allowedAsset = "Assets/__ALLOWED_FBX__";
        CheckFbx(allowedAsset, "allowed", results);

        // --- Check DECOY FBX ---
        string decoyAsset = "Assets/__DECOY_FBX__";
        CheckFbx(decoyAsset, "decoy", results);

        // Write JSON
        var parts = new List<string>();
        foreach (var kv in results)
        {
            string val;
            if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + (kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("  \"" + kv.Key + "\": " + val);
        }
        File.WriteAllText(resultsFile,
            "{\n" + string.Join(",\n", parts) + "\n}");
        Debug.Log("[AllowlistVerifier] Done: " + resultsFile);
        EditorApplication.Exit(0);
    }

    static void CheckFbx(string fbxAsset, string prefix,
        Dictionary<string, object> results)
    {
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        if (prefab == null)
        {
            results[prefix + "_opacity_controllers"] = 0;
            results[prefix + "_audio_controllers"] = 0;
            results[prefix + "_opacity_curves"] = 0;
            results[prefix + "_on_audio_events"] = 0;
            return;
        }

        var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);

        var ocs = instance.GetComponentsInChildren<RenderOpacityController>(true);
        results[prefix + "_opacity_controllers"] = ocs.Length;

        var acs = instance.GetComponentsInChildren<AudioEventController>(true);
        results[prefix + "_audio_controllers"] = acs.Length;

        Object.DestroyImmediate(instance);

        // Animation analysis
        var allAssets = AssetDatabase.LoadAllAssetsAtPath(fbxAsset);
        var clips = allAssets.OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();

        int opacityCurves = 0, onAudioEvents = 0;
        foreach (var clip in clips)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var events = AnimationUtility.GetAnimationEvents(clip);
            onAudioEvents += events.Count(e => e.functionName == "OnAudioEvent");
            foreach (var b in bindings)
            {
                if (b.propertyName == "opacity" &&
                    b.type == typeof(RenderOpacityController))
                    opacityCurves++;
            }
        }
        results[prefix + "_opacity_curves"] = opacityCurves;
        results[prefix + "_on_audio_events"] = onAudioEvents;
    }
}
"""


# ---------------------------------------------------------------------------
# Subfolder verifier: everything in a single subfolder under Assets/
# ---------------------------------------------------------------------------

SUBFOLDER_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class SubfolderVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";
        string subfolder   = "__SUBFOLDER__";

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        string fbxAsset = subfolder + "/C130_FCR_Speedrun_Assembly_copy.fbx";

        // Force reimport
        var importer = AssetImporter.GetAtPath(fbxAsset) as ModelImporter;
        if (importer != null)
        {
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAsset);
            AssetDatabase.ImportAsset(fbxAsset,
                ImportAssetOptions.ForceUpdate |
                ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

        var results = new Dictionary<string, object>();

        // --- Instantiate prefab ---
        var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAsset);
        results["prefab_loaded"] = prefab != null;

        if (prefab != null)
        {
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab);

            var ocs = instance.GetComponentsInChildren<RenderOpacityController>(true);
            results["opacity_controllers"] = ocs.Length;

            var acs = instance.GetComponentsInChildren<AudioEventController>(true);
            results["audio_controllers"] = acs.Length;
            int totalClips = 0, matchedClips = 0;
            foreach (var ac in acs)
            {
                int m = ac.clips != null ? ac.clips.Count(c => c != null) : 0;
                int t = ac.clips != null ? ac.clips.Count : 0;
                totalClips += t;
                matchedClips += m;
            }
            results["audio_total_clips"] = totalClips;
            results["audio_matched_clips"] = matchedClips;

            Object.DestroyImmediate(instance);
        }

        // --- Animation analysis ---
        var allAssets = AssetDatabase.LoadAllAssetsAtPath(fbxAsset);
        var clips = allAssets.OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__")).ToArray();

        int opacityCurves = 0, onAudioEvents = 0;
        foreach (var clip in clips)
        {
            var bindings = AnimationUtility.GetCurveBindings(clip);
            var events = AnimationUtility.GetAnimationEvents(clip);
            onAudioEvents += events.Count(e => e.functionName == "OnAudioEvent");
            foreach (var b in bindings)
            {
                if (b.propertyName == "opacity" &&
                    b.type == typeof(RenderOpacityController))
                    opacityCurves++;
            }
        }
        results["opacity_curves"] = opacityCurves;
        results["on_audio_events"] = onAudioEvents;

        // Audio assets in subfolder
        string audioDir = subfolder + "/Audio";
        string[] guids = AssetDatabase.IsValidFolder(audioDir)
            ? AssetDatabase.FindAssets("t:AudioClip", new[] { audioDir })
            : new string[0];
        results["audio_assets"] = guids.Length;

        // Config discovery check — was the config found from the subfolder?
        results["config_found_subfolder"] =
            !AssetDatabase.IsValidFolder("Assets") ? false
            : !File.Exists(
                  Path.Combine(Directory.GetCurrentDirectory(),
                               "Assets", "maya_fbx_import_config.json"));

        // Write JSON
        var parts = new List<string>();
        foreach (var kv in results)
        {
            string val;
            if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + (kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("  \"" + kv.Key + "\": " + val);
        }
        File.WriteAllText(resultsFile,
            "{\n" + string.Join(",\n", parts) + "\n}");
        Debug.Log("[SubfolderVerifier] Done: " + resultsFile);
        EditorApplication.Exit(0);
    }
}
"""


# ======================================================================
# Test
# ======================================================================


@unittest.skipUnless(_sources_ok(), "Source FBX/audio/templates not accessible")
@unittest.skipUnless(_find_unity_exe(), "No Unity editor found")
class TestStandaloneEndUser(unittest.TestCase):
    """Prove end-user needs ONLY the two CS files + FBX + audio."""

    @classmethod
    def setUpClass(cls):
        _temp_base = r"O:\Cloud\Code\_scripts\test\temp_tests"
        os.makedirs(_temp_base, exist_ok=True)
        cls.temp_dir = tempfile.mkdtemp(prefix="standalone_enduser_", dir=_temp_base)
        cls.project_path = os.path.join(cls.temp_dir, "UnityProject")
        cls.results = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        if os.environ.get("C130_PRESERVE", "").strip() == "1":
            logger.info(f"Preserved: {cls.temp_dir}")
        else:
            shutil.rmtree(cls.temp_dir, ignore_errors=True)
            logger.info(f"Cleaned up: {cls.temp_dir}")

    # ------------------------------------------------------------------

    def test_enduser_workflow(self):
        """Simulate: drop CS files + FBX + audio into fresh Unity project."""

        unity_exe = _find_unity_exe()
        self.assertTrue(unity_exe, "Unity executable not found")

        # === Step 1: Create fresh Unity project (batch mode) ===
        logger.info(f"Creating Unity project: {self.project_path}")
        proc = subprocess.run(
            [
                unity_exe,
                "-createProject",
                self.project_path,
                "-batchmode",
                "-quit",
                "-nographics",
            ],
            timeout=300,
            capture_output=True,
        )
        assets = os.path.join(self.project_path, "Assets")
        self.assertTrue(os.path.isdir(assets), "Unity project creation failed")

        # === Step 2: Copy the TWO CS files (the only deliverables) ===
        scripts_dir = os.path.join(assets, "Scripts")
        os.makedirs(scripts_dir, exist_ok=True)
        for cs in CS_FILES:
            src = os.path.join(TEMPLATE_DIR, cs)
            dst = os.path.join(scripts_dir, cs)
            shutil.copy2(src, dst)
            self.assertTrue(os.path.isfile(dst), f"Failed to copy {cs}")
        logger.info(f"Copied {len(CS_FILES)} CS files to Assets/Scripts/")

        # === Step 3: Copy FBX ===
        dest_fbx = os.path.join(assets, "C130_FCR_Speedrun_Assembly_copy.fbx")
        logger.info("Copying FBX...")
        shutil.copy2(FBX_PATH, dest_fbx)
        self.assertTrue(os.path.isfile(dest_fbx))

        # === Step 3b: Deploy maya_fbx_import_config.json (allowlist) ===
        config_src = os.path.join(TEMPLATE_DIR, "maya_fbx_import_config.json")
        if os.path.isfile(config_src):
            shutil.copy2(config_src, os.path.join(assets, "maya_fbx_import_config.json"))
            logger.info("Deployed maya_fbx_import_config.json allowlist")

        # === Step 4: Copy audio files ===
        audio_dst = os.path.join(assets, "Audio")
        os.makedirs(audio_dst, exist_ok=True)
        copied = 0
        for f in os.listdir(AUDIO_DIR):
            if f.lower().endswith(".mp3"):
                shutil.copy2(os.path.join(AUDIO_DIR, f), os.path.join(audio_dst, f))
                copied += 1
        logger.info(f"Copied {copied} audio files")
        self.assertEqual(copied, EXPECTED_AUDIO_COUNT)

        # === Step 5: Deploy ONLY the test verifier (not a deliverable) ===
        editor_dir = os.path.join(assets, "Editor")
        os.makedirs(editor_dir, exist_ok=True)

        results_path = os.path.join(self.temp_dir, "results.json")
        verifier = VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path.replace("\\", "\\\\")
        )
        with open(
            os.path.join(editor_dir, "StandaloneVerifier.cs"), "w", encoding="utf-8"
        ) as f:
            f.write(verifier)

        # === Step 6: Launch Unity batch mode ===
        log_path = os.path.join(self.temp_dir, "unity.log")
        logger.info("Launching Unity batch-mode verification...")
        proc = subprocess.run(
            [
                unity_exe,
                "-projectPath",
                self.project_path,
                "-batchmode",
                "-nographics",
                "-executeMethod",
                "StandaloneVerifier.Verify",
                "-logFile",
                log_path,
                "-quit",
            ],
            timeout=600,
            capture_output=True,
        )

        # Show log tail on failure
        if os.path.exists(log_path):
            with open(log_path, encoding="utf-8", errors="replace") as f:
                tail = f.read()[-3000:]
            if not os.path.isfile(results_path):
                logger.error(f"Unity log tail:\n{tail}")

        # === Step 7: Assert results ===
        self.assertTrue(
            os.path.isfile(results_path),
            f"Verifier didn't write results — check {log_path}",
        )

        with open(results_path, encoding="utf-8") as f:
            r = json.load(f)
        self.__class__.results = r

        print("\n" + "=" * 70)
        print("  STANDALONE END-USER SIMULATION RESULTS")
        print("=" * 70)

        # Prefab
        self.assertTrue(r["prefab_loaded"], "Prefab failed to load")
        total = r["total_objects"]
        print(f"  GameObjects:              {total}")
        self.assertGreater(total, 100)

        # Import settings auto-configured
        self.assertTrue(
            r["custom_props_enabled"],
            "importAnimatedCustomProperties was NOT auto-enabled — "
            "OnPreprocessModel failed to fire!",
        )
        print(f"  importAnimatedCustomProps: AUTO-ENABLED (no manual config)")

        # Opacity controllers
        oc = r["opacity_controllers"]
        oc_rend = r["opacity_with_renderer"]
        print(f"  RenderOpacityControllers: {oc} (all with Renderer: {oc_rend})")
        self.assertGreaterEqual(
            oc,
            EXPECTED_MIN_OPACITY_CONTROLLERS,
            f"Only {oc} opacity controllers — expected >= "
            f"{EXPECTED_MIN_OPACITY_CONTROLLERS}",
        )
        self.assertEqual(oc, oc_rend, "Some controllers lack a Renderer")

        # Opacity curves
        curves = r["opacity_curves"]
        print(f"  Opacity curves:           {curves}")
        self.assertGreaterEqual(
            curves,
            EXPECTED_MIN_OPACITY_CURVES,
            f"Only {curves} opacity curves — expected >= "
            f"{EXPECTED_MIN_OPACITY_CURVES}",
        )

        # Key count sanity (BoolToFadeCurve not bloated)
        max_k = r["max_keys"]
        key_str = r.get("opacity_key_counts", "")
        key_list = [int(k) for k in key_str.split(",") if k]
        bloated = [k for k in key_list if k > MAX_KEYS_PER_CURVE]
        print(
            f"  Max keys per curve:       {max_k} "
            f"(bloated>{MAX_KEYS_PER_CURVE}: {len(bloated)})"
        )
        self.assertEqual(
            len(bloated),
            0,
            f"{len(bloated)} curves have >{MAX_KEYS_PER_CURVE} keys — "
            f"BoolToFadeCurve regression",
        )

        # m_Enabled residual (non-opacity visibility curves remain)
        m_en = r["m_enabled_curves"]
        print(f"  m_Enabled remaining:      {m_en}")
        self.assertGreater(
            m_en,
            0,
            "All m_Enabled curves removed — " "STANDs/CB_CHIPs should keep theirs",
        )

        # Audio controllers
        ac = r["audio_controllers"]
        ac_details = r.get("audio_details", [])
        print(f"  AudioEventControllers:    {ac}")
        for d in ac_details:
            print(f"    {d}")
        self.assertEqual(ac, 3, f"Expected 3 audio controllers, got {ac}")

        # Audio clip matching
        matched = r["audio_matched_clips"]
        total_c = r["audio_total_clips"]
        print(f"  Audio clips matched:      {matched}/{total_c}")
        self.assertEqual(matched, EXPECTED_AUDIO_COUNT)
        self.assertEqual(matched, total_c, "Not all clips matched")

        # Animation events
        events = r["on_audio_events"]
        print(f"  OnAudioEvent events:      {events}")
        self.assertEqual(events, EXPECTED_AUDIO_COUNT)

        # Legacy audio_trigger curves removed
        at = r["audio_trigger_curves"]
        print(f"  audio_trigger curves:     {at} (should be 0)")
        self.assertEqual(at, 0)

        # Audio assets imported
        aa = r["audio_assets"]
        print(f"  Audio assets imported:    {aa}")
        self.assertEqual(aa, EXPECTED_AUDIO_COUNT)

        # Reimport idempotency
        ri_events = r.get("reimport_events", -1)
        ri_opacity = r.get("reimport_opacity_curves", -1)
        ri_at = r.get("reimport_audio_trigger", -1)
        ri_oc = r.get("reimport_opacity_controllers", -1)
        ri_ac = r.get("reimport_audio_controllers", -1)

        print(f"  Reimport idempotency:")
        print(f"    Events:        {events} -> {ri_events}")
        print(f"    Opa curves:    {curves} -> {ri_opacity}")
        print(f"    audio_trigger: {at} -> {ri_at}")
        print(f"    Opa ctrls:     {oc} -> {ri_oc}")
        print(f"    Audio ctrls:   {ac} -> {ri_ac}")

        self.assertEqual(
            ri_events, events, f"Reimport duplicated events: {events} -> {ri_events}"
        )
        self.assertEqual(
            ri_opacity,
            curves,
            f"Reimport duplicated opacity curves: {curves} -> {ri_opacity}",
        )
        self.assertEqual(ri_at, 0, f"Reimport resurrected {ri_at} audio_trigger curves")
        self.assertEqual(
            ri_oc, oc, f"Reimport changed opacity controllers: {oc} -> {ri_oc}"
        )
        self.assertEqual(
            ri_ac, ac, f"Reimport changed audio controllers: {ac} -> {ri_ac}"
        )

        # AnimationMode runtime
        anim_error = r.get("anim_sample_error")
        if anim_error:
            self.fail(f"AnimationMode sampling failed: {anim_error}")

        anim_count = r.get("anim_sample_count", 0)
        changed_15 = r.get("anim_sample_changed_by_t15", 0)
        changed_500 = r.get("anim_sample_changed_by_t500", 0)
        anim_details = r.get("anim_sample_details", [])

        print(f"  AnimationMode sampling:")
        print(f"    Controllers sampled: {anim_count}")
        print(f"    Changed by t=15s:    {changed_15}")
        print(f"    Changed by t=500s:   {changed_500}")
        if anim_details:
            for d in anim_details[:5]:
                print(f"      {d}")
            if len(anim_details) > 5:
                print(f"      ... and {len(anim_details) - 5} more")

        self.assertGreater(anim_count, 0, "No controllers sampled via AnimationMode")
        self.assertGreater(
            changed_15 + changed_500,
            0,
            "No opacity values changed — curves not driving property",
        )

        print("=" * 70)
        print("  VERDICT: End-user needs ONLY the two CS files + FBX + audio.")
        print("           No unitytk. No Python. No manual import settings.")
        print("=" * 70 + "\n")

    # ------------------------------------------------------------------

    def test_audio_after_fbx(self):
        """Simulate: CS files + FBX imported first WITHOUT audio,
        then audio added and FBX reimported.

        This is the most likely out-of-order workflow:
          1. Developer drops CS files + FBX into project
          2. Unity imports — components added, events injected,
             but clip slots are null (audio not present yet)
          3. Developer drops audio into Assets/Audio/
          4. Developer reimports FBX (or Tools → Reimport)
          5. Clips should now be fully matched
        """

        unity_exe = _find_unity_exe()
        self.assertTrue(unity_exe, "Unity executable not found")

        # === Step 1: Create fresh Unity project ===
        project_path = os.path.join(self.temp_dir, "OrderTestProject")
        logger.info(f"Creating order-test project: {project_path}")
        proc = subprocess.run(
            [
                unity_exe,
                "-createProject",
                project_path,
                "-batchmode",
                "-quit",
                "-nographics",
            ],
            timeout=300,
            capture_output=True,
        )
        assets = os.path.join(project_path, "Assets")
        self.assertTrue(os.path.isdir(assets), "Unity project creation failed")

        # === Step 2: Copy CS files + FBX only (NO audio) ===
        scripts_dir = os.path.join(assets, "Scripts")
        os.makedirs(scripts_dir, exist_ok=True)
        for cs in CS_FILES:
            shutil.copy2(os.path.join(TEMPLATE_DIR, cs), os.path.join(scripts_dir, cs))

        dest_fbx = os.path.join(assets, "C130_FCR_Speedrun_Assembly_copy.fbx")
        logger.info("Copying FBX (without audio)...")
        shutil.copy2(FBX_PATH, dest_fbx)

        # Deploy maya_fbx_import_config.json (allowlist)
        config_src = os.path.join(TEMPLATE_DIR, "maya_fbx_import_config.json")
        if os.path.isfile(config_src):
            shutil.copy2(config_src, os.path.join(assets, "maya_fbx_import_config.json"))

        # === Step 3: Deploy the order-test verifier ===
        editor_dir = os.path.join(assets, "Editor")
        os.makedirs(editor_dir, exist_ok=True)

        results_phase1 = os.path.join(self.temp_dir, "order_phase1.json")
        results_phase2 = os.path.join(self.temp_dir, "order_phase2.json")

        # Phase-1 verifier: import FBX without audio, capture state
        verifier_cs = ORDER_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_phase1.replace("\\", "\\\\")
        )
        with open(
            os.path.join(editor_dir, "OrderVerifier.cs"), "w", encoding="utf-8"
        ) as f:
            f.write(verifier_cs)

        # === Step 4: Launch Unity — FBX imports WITHOUT audio ===
        log1 = os.path.join(self.temp_dir, "order_phase1.log")
        logger.info("Phase 1: Importing FBX without audio...")
        proc = subprocess.run(
            [
                unity_exe,
                "-projectPath",
                project_path,
                "-batchmode",
                "-nographics",
                "-executeMethod",
                "OrderVerifier.Verify",
                "-logFile",
                log1,
                "-quit",
            ],
            timeout=600,
            capture_output=True,
        )

        if os.path.exists(log1) and not os.path.isfile(results_phase1):
            with open(log1, encoding="utf-8", errors="replace") as f:
                logger.error(f"Phase 1 log tail:\n{f.read()[-3000:]}")

        self.assertTrue(
            os.path.isfile(results_phase1), f"Phase 1 verifier failed — check {log1}"
        )

        with open(results_phase1, encoding="utf-8") as f:
            p1 = json.load(f)

        # === Step 5: Now add audio files ===
        audio_dst = os.path.join(assets, "Audio")
        os.makedirs(audio_dst, exist_ok=True)
        copied = 0
        for af in os.listdir(AUDIO_DIR):
            if af.lower().endswith(".mp3"):
                shutil.copy2(os.path.join(AUDIO_DIR, af), os.path.join(audio_dst, af))
                copied += 1
        logger.info(f"Phase 2: Added {copied} audio files, reimporting...")
        self.assertEqual(copied, EXPECTED_AUDIO_COUNT)

        # === Step 6: Update verifier to write phase-2 results, relaunch ===
        verifier_cs = ORDER_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_phase2.replace("\\", "\\\\")
        )
        with open(
            os.path.join(editor_dir, "OrderVerifier.cs"), "w", encoding="utf-8"
        ) as f:
            f.write(verifier_cs)

        log2 = os.path.join(self.temp_dir, "order_phase2.log")
        proc = subprocess.run(
            [
                unity_exe,
                "-projectPath",
                project_path,
                "-batchmode",
                "-nographics",
                "-executeMethod",
                "OrderVerifier.Verify",
                "-logFile",
                log2,
                "-quit",
            ],
            timeout=600,
            capture_output=True,
        )

        if os.path.exists(log2) and not os.path.isfile(results_phase2):
            with open(log2, encoding="utf-8", errors="replace") as f:
                logger.error(f"Phase 2 log tail:\n{f.read()[-3000:]}")

        self.assertTrue(
            os.path.isfile(results_phase2), f"Phase 2 verifier failed — check {log2}"
        )

        with open(results_phase2, encoding="utf-8") as f:
            p2 = json.load(f)

        # === Step 7: Assert both phases ===
        print("\n" + "=" * 70)
        print("  AUDIO-AFTER-FBX ORDER TEST")
        print("=" * 70)

        # Phase 1: FBX without audio
        print("\n  Phase 1 (FBX only, no audio):")
        p1_ac = p1.get("audio_controllers", 0)
        p1_matched = p1.get("audio_matched_clips", 0)
        p1_total = p1.get("audio_total_clips", 0)
        p1_events = p1.get("on_audio_events", 0)
        p1_oc = p1.get("opacity_controllers", 0)
        p1_curves = p1.get("opacity_curves", 0)
        p1_audio_assets = p1.get("audio_assets", 0)

        print(f"    AudioEventControllers:  {p1_ac}")
        print(f"    Clips matched:          {p1_matched}/{p1_total}")
        print(f"    OnAudioEvent events:    {p1_events}")
        print(f"    Audio assets in project:{p1_audio_assets}")
        print(f"    OpacityControllers:     {p1_oc}")
        print(f"    Opacity curves:         {p1_curves}")

        # Components and events should exist even without audio
        self.assertEqual(
            p1_ac, 3, "AudioEventControllers should be added even without audio files"
        )
        self.assertEqual(
            p1_events,
            EXPECTED_AUDIO_COUNT,
            "AnimationEvents should be injected even without audio files",
        )
        # Clips should be unmatched (null) — audio isn't present yet
        self.assertEqual(
            p1_matched, 0, f"Expected 0 matched clips without audio, got {p1_matched}"
        )
        self.assertEqual(p1_audio_assets, 0, f"No audio assets should exist in phase 1")
        # Opacity should work regardless
        self.assertGreaterEqual(p1_oc, EXPECTED_MIN_OPACITY_CONTROLLERS)
        self.assertGreaterEqual(p1_curves, EXPECTED_MIN_OPACITY_CURVES)

        # Phase 2: Audio added + reimport
        print("\n  Phase 2 (audio added + reimport):")
        p2_ac = p2.get("audio_controllers", 0)
        p2_matched = p2.get("audio_matched_clips", 0)
        p2_total = p2.get("audio_total_clips", 0)
        p2_events = p2.get("on_audio_events", 0)
        p2_oc = p2.get("opacity_controllers", 0)
        p2_curves = p2.get("opacity_curves", 0)
        p2_audio_assets = p2.get("audio_assets", 0)

        print(f"    AudioEventControllers:  {p2_ac}")
        print(f"    Clips matched:          {p2_matched}/{p2_total}")
        print(f"    OnAudioEvent events:    {p2_events}")
        print(f"    Audio assets in project:{p2_audio_assets}")
        print(f"    OpacityControllers:     {p2_oc}")
        print(f"    Opacity curves:         {p2_curves}")

        # After reimport: everything should be fully wired
        self.assertEqual(p2_ac, 3)
        self.assertEqual(
            p2_matched,
            EXPECTED_AUDIO_COUNT,
            f"After reimport with audio: {p2_matched}/{p2_total} matched — "
            f"expected {EXPECTED_AUDIO_COUNT}",
        )
        self.assertEqual(p2_events, EXPECTED_AUDIO_COUNT)
        self.assertEqual(p2_audio_assets, EXPECTED_AUDIO_COUNT)
        self.assertGreaterEqual(p2_oc, EXPECTED_MIN_OPACITY_CONTROLLERS)
        self.assertGreaterEqual(p2_curves, EXPECTED_MIN_OPACITY_CURVES)

        # No duplication from the second import pass
        self.assertEqual(
            p2_events, p1_events, f"Events duplicated: {p1_events} -> {p2_events}"
        )
        self.assertEqual(
            p2_oc, p1_oc, f"Opacity controllers changed: {p1_oc} -> {p2_oc}"
        )

        print("\n  VERDICT: Audio-after-FBX works correctly.")
        print("           Phase 1: components + events present, clips=None.")
        print("           Phase 2: reimport resolves all clips.")
        print("=" * 70 + "\n")

    # ------------------------------------------------------------------

    def test_allowlist_blocks_unlisted_fbx(self):
        """Two identical FBX files imported side-by-side:
        one in the allowlist, one NOT.  The unlisted copy should get
        zero components, zero curves, zero events."""

        unity_exe = _find_unity_exe()
        self.assertTrue(unity_exe, "Unity executable not found")

        # === Create fresh project ===
        project_path = os.path.join(self.temp_dir, "AllowlistTestProject")
        logger.info(f"Creating allowlist-test project: {project_path}")
        subprocess.run(
            [unity_exe, "-createProject", project_path,
             "-batchmode", "-quit", "-nographics"],
            timeout=300, capture_output=True,
        )
        assets = os.path.join(project_path, "Assets")
        self.assertTrue(os.path.isdir(assets))

        # === Copy CS files ===
        scripts_dir = os.path.join(assets, "Scripts")
        os.makedirs(scripts_dir, exist_ok=True)
        for cs in CS_FILES:
            shutil.copy2(os.path.join(TEMPLATE_DIR, cs),
                         os.path.join(scripts_dir, cs))

        # === Copy the ALLOWED FBX ===
        allowed_name = "C130_FCR_Speedrun_Assembly_copy.fbx"
        shutil.copy2(FBX_PATH, os.path.join(assets, allowed_name))

        # === Copy the SAME FBX under an UNLISTED name ===
        decoy_name = "DecoyModel.fbx"
        shutil.copy2(FBX_PATH, os.path.join(assets, decoy_name))

        # === Deploy maya_fbx_import_config.json (does NOT list DecoyModel.fbx) ===
        config_src = os.path.join(TEMPLATE_DIR, "maya_fbx_import_config.json")
        shutil.copy2(config_src, os.path.join(assets, "maya_fbx_import_config.json"))

        # === Copy audio ===
        audio_dst = os.path.join(assets, "Audio")
        os.makedirs(audio_dst, exist_ok=True)
        for af in os.listdir(AUDIO_DIR):
            if af.lower().endswith(".mp3"):
                shutil.copy2(os.path.join(AUDIO_DIR, af),
                             os.path.join(audio_dst, af))

        # === Deploy verifier that checks BOTH FBX files ===
        editor_dir = os.path.join(assets, "Editor")
        os.makedirs(editor_dir, exist_ok=True)
        results_path = os.path.join(self.temp_dir, "allowlist_results.json")

        verifier_cs = ALLOWLIST_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path.replace("\\", "\\\\")
        ).replace(
            "__ALLOWED_FBX__", allowed_name
        ).replace(
            "__DECOY_FBX__", decoy_name
        )
        with open(os.path.join(editor_dir, "AllowlistVerifier.cs"),
                  "w", encoding="utf-8") as f:
            f.write(verifier_cs)

        # === Launch Unity ===
        log_path = os.path.join(self.temp_dir, "allowlist_test.log")
        logger.info("Importing both FBX files with allowlist active...")
        subprocess.run(
            [unity_exe, "-projectPath", project_path,
             "-batchmode", "-nographics",
             "-executeMethod", "AllowlistVerifier.Verify",
             "-logFile", log_path, "-quit"],
            timeout=600, capture_output=True,
        )

        if not os.path.isfile(results_path) and os.path.exists(log_path):
            with open(log_path, encoding="utf-8", errors="replace") as f:
                logger.error(f"Unity log tail:\n{f.read()[-3000:]}")

        self.assertTrue(os.path.isfile(results_path),
                        f"Verifier failed — check {log_path}")

        with open(results_path, encoding="utf-8") as f:
            r = json.load(f)

        # === Assert results ===
        print("\n" + "=" * 70)
        print("  ALLOWLIST FILTER TEST")
        print("=" * 70)

        # Allowed FBX — should have full processing
        a_oc = r.get("allowed_opacity_controllers", 0)
        a_ac = r.get("allowed_audio_controllers", 0)
        a_curves = r.get("allowed_opacity_curves", 0)
        a_events = r.get("allowed_on_audio_events", 0)

        print(f"\n  Allowed FBX ({allowed_name}):")
        print(f"    OpacityControllers:  {a_oc}")
        print(f"    AudioControllers:    {a_ac}")
        print(f"    Opacity curves:      {a_curves}")
        print(f"    OnAudioEvent events: {a_events}")

        self.assertGreaterEqual(a_oc, EXPECTED_MIN_OPACITY_CONTROLLERS)
        self.assertEqual(a_ac, 3)
        self.assertGreaterEqual(a_curves, EXPECTED_MIN_OPACITY_CURVES)
        self.assertEqual(a_events, EXPECTED_AUDIO_COUNT)

        # Decoy FBX — should have ZERO processing
        d_oc = r.get("decoy_opacity_controllers", 0)
        d_ac = r.get("decoy_audio_controllers", 0)
        d_curves = r.get("decoy_opacity_curves", 0)
        d_events = r.get("decoy_on_audio_events", 0)

        print(f"\n  Decoy FBX ({decoy_name}) — should be untouched:")
        print(f"    OpacityControllers:  {d_oc}")
        print(f"    AudioControllers:    {d_ac}")
        print(f"    Opacity curves:      {d_curves}")
        print(f"    OnAudioEvent events: {d_events}")

        self.assertEqual(d_oc, 0,
                         f"Decoy got {d_oc} opacity controllers — allowlist leaked!")
        self.assertEqual(d_ac, 0,
                         f"Decoy got {d_ac} audio controllers — allowlist leaked!")
        self.assertEqual(d_curves, 0,
                         f"Decoy got {d_curves} opacity curves — allowlist leaked!")
        self.assertEqual(d_events, 0,
                         f"Decoy got {d_events} audio events — allowlist leaked!")

        print("\n  VERDICT: Allowlist correctly blocks unlisted FBX.")
        print("=" * 70 + "\n")

    # ------------------------------------------------------------------

    def test_subfolder_deployment(self):
        """All deliverables in a single subfolder under Assets/.

        Layout:
            Assets/
              C130_Package/
                RenderOpacityController.cs
                AudioEventController.cs
                maya_fbx_import_config.json
                C130_FCR_Speedrun_Assembly_copy.fbx
                Audio/
                  *.mp3
              Editor/
                SubfolderVerifier.cs  (test-only)

        Exercises:
          - FindConfig() recursive discovery (config NOT at Assets/ root)
          - GetAudioSearchDirs() FBX-sibling Audio/ folder
        """

        unity_exe = _find_unity_exe()
        self.assertTrue(unity_exe, "Unity executable not found")

        # === Create fresh project ===
        project_path = os.path.join(self.temp_dir, "SubfolderTestProject")
        logger.info(f"Creating subfolder-test project: {project_path}")
        subprocess.run(
            [unity_exe, "-createProject", project_path,
             "-batchmode", "-quit", "-nographics"],
            timeout=300, capture_output=True,
        )
        assets = os.path.join(project_path, "Assets")
        self.assertTrue(os.path.isdir(assets))

        # === Create subfolder and deploy EVERYTHING into it ===
        subfolder_name = "C130_Package"
        pkg = os.path.join(assets, subfolder_name)
        os.makedirs(pkg, exist_ok=True)

        # CS files
        for cs in CS_FILES:
            shutil.copy2(os.path.join(TEMPLATE_DIR, cs), os.path.join(pkg, cs))

        # Config
        config_src = os.path.join(TEMPLATE_DIR, "maya_fbx_import_config.json")
        shutil.copy2(config_src, os.path.join(pkg, "maya_fbx_import_config.json"))

        # FBX
        shutil.copy2(FBX_PATH,
                      os.path.join(pkg, "C130_FCR_Speedrun_Assembly_copy.fbx"))

        # Audio — in a sibling Audio/ folder
        audio_dst = os.path.join(pkg, "Audio")
        os.makedirs(audio_dst, exist_ok=True)
        copied = 0
        for af in os.listdir(AUDIO_DIR):
            if af.lower().endswith(".mp3"):
                shutil.copy2(os.path.join(AUDIO_DIR, af),
                             os.path.join(audio_dst, af))
                copied += 1
        logger.info(f"Deployed {copied} audio files into {subfolder_name}/Audio/")
        self.assertEqual(copied, EXPECTED_AUDIO_COUNT)

        # Verify NO config at Assets/ root (the whole point of this test)
        self.assertFalse(
            os.path.isfile(os.path.join(assets, "maya_fbx_import_config.json")),
            "Config should NOT be at Assets/ root for this test")

        # === Deploy verifier (Editor-only, not a deliverable) ===
        editor_dir = os.path.join(assets, "Editor")
        os.makedirs(editor_dir, exist_ok=True)
        results_path = os.path.join(self.temp_dir, "subfolder_results.json")

        verifier_cs = SUBFOLDER_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path.replace("\\", "\\\\")
        ).replace(
            "__SUBFOLDER__", f"Assets/{subfolder_name}"
        )
        with open(os.path.join(editor_dir, "SubfolderVerifier.cs"),
                  "w", encoding="utf-8") as f:
            f.write(verifier_cs)

        # === Launch Unity ===
        log_path = os.path.join(self.temp_dir, "subfolder_test.log")
        logger.info("Importing from subfolder layout...")
        subprocess.run(
            [unity_exe, "-projectPath", project_path,
             "-batchmode", "-nographics",
             "-executeMethod", "SubfolderVerifier.Verify",
             "-logFile", log_path, "-quit"],
            timeout=600, capture_output=True,
        )

        if not os.path.isfile(results_path) and os.path.exists(log_path):
            with open(log_path, encoding="utf-8", errors="replace") as f:
                logger.error(f"Unity log tail:\n{f.read()[-3000:]}")

        self.assertTrue(os.path.isfile(results_path),
                        f"Verifier failed — check {log_path}")

        with open(results_path, encoding="utf-8") as f:
            r = json.load(f)

        # === Assert ===
        print("\n" + "=" * 70)
        print("  SUBFOLDER DEPLOYMENT TEST")
        print("=" * 70)

        self.assertTrue(r["prefab_loaded"], "Prefab failed to load from subfolder")

        oc = r.get("opacity_controllers", 0)
        ac = r.get("audio_controllers", 0)
        curves = r.get("opacity_curves", 0)
        events = r.get("on_audio_events", 0)
        matched = r.get("audio_matched_clips", 0)
        total_c = r.get("audio_total_clips", 0)
        audio_a = r.get("audio_assets", 0)
        cfg_sub = r.get("config_found_subfolder", False)

        print(f"  Layout: Assets/{subfolder_name}/  (all files here)")
        print(f"  Config at Assets/ root?: NO (recursive discovery)")
        print(f"  Config found from subfolder: {cfg_sub}")
        print(f"  OpacityControllers:  {oc}")
        print(f"  AudioControllers:    {ac}")
        print(f"  Opacity curves:      {curves}")
        print(f"  OnAudioEvent events: {events}")
        print(f"  Audio clips matched: {matched}/{total_c}")
        print(f"  Audio assets:        {audio_a}")

        # Config was discovered from subfolder (not Assets/ root)
        self.assertTrue(cfg_sub,
                        "Config was NOT found via recursive search — "
                        "FindConfig() subfolder discovery broken")

        # Full import pipeline worked from subfolder
        self.assertGreaterEqual(oc, EXPECTED_MIN_OPACITY_CONTROLLERS,
                                f"Only {oc} opacity controllers from subfolder")
        self.assertEqual(ac, 3,
                         f"Expected 3 audio controllers, got {ac}")
        self.assertGreaterEqual(curves, EXPECTED_MIN_OPACITY_CURVES,
                                f"Only {curves} opacity curves from subfolder")
        self.assertEqual(events, EXPECTED_AUDIO_COUNT,
                         f"Only {events} audio events from subfolder")

        # Audio matched via FBX-sibling Audio/ folder
        self.assertEqual(matched, EXPECTED_AUDIO_COUNT,
                         f"Only {matched}/{total_c} audio clips matched — "
                         f"GetAudioSearchDirs sibling lookup broken")
        self.assertEqual(audio_a, EXPECTED_AUDIO_COUNT)

        print("\n  VERDICT: All files in a single subfolder works correctly.")
        print("           Config found via recursive search.")
        print("           Audio found via FBX-sibling Audio/ folder.")
        print("=" * 70 + "\n")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    unittest.main()
