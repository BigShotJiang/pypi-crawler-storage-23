# !/usr/bin/python
# coding=utf-8
"""
Integration test: EventTriggers Maya module -> FBX -> Unity readback.

Validates the full pipeline using the EventTriggers module:
    1. Maya (mayapy): Create object, add event triggers via EventTriggers.create(),
       key events with EventTriggers.set_key(), export FBX.
    2. Unity (batchmode): Import FBX, verify the event_trigger curve exists
       and the event_manifest string property arrives intact.

Requires:
    - Maya 2025 installed (mayapy.exe)
    - Unity Hub with at least one editor installed
"""
import os
import sys
import json
import shutil
import tempfile
import unittest
import subprocess
import logging

logger = logging.getLogger(__name__)

scripts_dir = r"O:\Cloud\Code\_scripts"
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

from unitytk import UnityLauncher, UnityFinder

MAYAPY = r"C:\Program Files\Autodesk\Maya2025\bin\mayapy.exe"


def _maya_available() -> bool:
    return os.path.exists(MAYAPY)


def _unity_available() -> bool:
    return bool(UnityFinder.find_editors())


# ======================================================================
# Maya-side script — uses EventTriggers module
# ======================================================================

MAYA_EXPORT_SCRIPT = r'''
"""Executed inside mayapy — sets up event triggers via the EventTriggers API."""
import sys, os, json

for pkg_dir in (r"O:\Cloud\Code\_scripts\mayatk", r"O:\Cloud\Code\_scripts\pythontk"):
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

import maya.standalone
maya.standalone.initialize(name="python")
import maya.cmds as cmds
import pymel.core as pm

import mayatk
from mayatk import EventTriggers

output_dir = sys.argv[1]
fbx_path = os.path.join(output_dir, "audio_events_test.fbx")

cmds.file(new=True, force=True)
pm.playbackOptions(min=1, max=60)

cube = pm.polyCube(name="AudioCube")[0]
cube2 = pm.polyCube(name="VfxCube")[0]

# ================================================================
# Test ensure() — auto-detect create vs update
# ================================================================

# ensure() on a fresh object should create
result = EventTriggers.ensure(
    objects=[cube],
    category="audio",
    events=["Footstep", "Jump", "Land"],
)
assert cube.hasAttr("audio_trigger"), "ensure(create): audio_trigger not created"
events = EventTriggers.get_events(cube, category="audio")
assert events == ["None", "Footstep", "Jump", "Land"], f"ensure(create) bad events: {events}"
print(f"[PASS] ensure(create): {events}")

# ensure() on an existing attr should append (not recreate)
result2 = EventTriggers.ensure(
    objects=[cube],
    category="audio",
    events=["Slide"],
)
events2 = EventTriggers.get_events(cube, category="audio")
assert events2 == ["None", "Footstep", "Jump", "Land", "Slide"], f"ensure(update) bad events: {events2}"
print(f"[PASS] ensure(update): {events2}")

# ensure() with mixed objects (one new, one existing)
result3 = EventTriggers.ensure(
    objects=[cube, cube2],
    category="audio",
    events=["Footstep", "Jump"],
)
assert cube2.hasAttr("audio_trigger"), "ensure(mixed): cube2 should have attr"
events_cube2 = EventTriggers.get_events(cube2, category="audio")
assert "Footstep" in events_cube2, f"ensure(mixed) cube2 missing Footstep: {events_cube2}"
print(f"[PASS] ensure(mixed): cube={EventTriggers.get_events(cube, category='audio')}, cube2={events_cube2}")

# ================================================================
# Test multi-category support
# ================================================================

EventTriggers.ensure(
    objects=[cube],
    category="vfx",
    events=["Sparks", "Smoke"],
)
assert cube.hasAttr("vfx_trigger"), "vfx_trigger not created"
vfx_events = EventTriggers.get_events(cube, category="vfx")
assert vfx_events == ["None", "Sparks", "Smoke"], f"vfx bad events: {vfx_events}"
# audio_trigger should be unaffected
audio_events = EventTriggers.get_events(cube, category="audio")
assert "Footstep" in audio_events, f"audio events disturbed: {audio_events}"
print(f"[PASS] multi-category: audio={audio_events}, vfx={vfx_events}")

# ================================================================
# Key events on timeline (audio category on cube)
# ================================================================

EventTriggers.set_key(cube, event="Footstep", time=10, category="audio")
EventTriggers.set_key(cube, event="Jump",     time=30, category="audio")
EventTriggers.set_key(cube, event="Land",     time=45, category="audio")

key_count = pm.keyframe(cube, attribute="audio_trigger", q=True, keyframeCount=True)
assert key_count > 0, "No keyframes on audio_trigger"

val_at_10 = pm.keyframe(cube, attribute="audio_trigger", time=(10, 10), q=True, vc=True)
val_at_30 = pm.keyframe(cube, attribute="audio_trigger", time=(30, 30), q=True, vc=True)
val_at_45 = pm.keyframe(cube, attribute="audio_trigger", time=(45, 45), q=True, vc=True)
assert val_at_10 and val_at_10[0] == 1.0, f"Expected 1.0 at f10, got {val_at_10}"
assert val_at_30 and val_at_30[0] == 2.0, f"Expected 2.0 at f30, got {val_at_30}"
assert val_at_45 and val_at_45[0] == 3.0, f"Expected 3.0 at f45, got {val_at_45}"
print(f"[PASS] keyframes: f10={val_at_10[0]}, f30={val_at_30[0]}, f45={val_at_45[0]}")

# ================================================================
# Bake manifest (auto-bake already ran, but explicit call too)
# ================================================================

baked = EventTriggers.bake_manifest([cube], category="audio")
assert cube.hasAttr("audio_manifest"), "audio_manifest not created by bake"
manifest = cube.audio_manifest.get()
assert "10:Footstep" in manifest, f"Missing 10:Footstep in: {manifest}"
assert "30:Jump" in manifest, f"Missing 30:Jump in: {manifest}"
assert "45:Land" in manifest, f"Missing 45:Land in: {manifest}"
print(f"[PASS] baked manifest: {manifest}")

# VFX manifest (no keys yet — should be empty)
EventTriggers.bake_manifest([cube], category="vfx")
assert cube.hasAttr("vfx_manifest"), "vfx_manifest not created"
vfx_manifest = cube.vfx_manifest.get()
assert vfx_manifest == "", f"VFX manifest should be empty, got: {vfx_manifest}"
print(f"[PASS] vfx manifest (empty): '{vfx_manifest}'")

# Key a VFX event and re-bake
EventTriggers.set_key(cube, event="Sparks", time=15, category="vfx")
EventTriggers.bake_manifest([cube], category="vfx")
vfx_manifest = cube.vfx_manifest.get()
assert "15:Sparks" in vfx_manifest, f"Missing 15:Sparks in: {vfx_manifest}"
print(f"[PASS] vfx manifest after keying: {vfx_manifest}")

# ================================================================
# Test remove()
# ================================================================

# Remove VFX only — audio should survive
EventTriggers.remove([cube], category="vfx")
assert not cube.hasAttr("vfx_trigger"), "vfx_trigger should be removed"
assert not cube.hasAttr("vfx_manifest"), "vfx_manifest should be removed"
assert cube.hasAttr("audio_trigger"), "audio_trigger should survive vfx removal"
print(f"[PASS] remove(vfx): vfx gone, audio intact")

# Remove cube2 + all categories
EventTriggers.remove([cube2], category="*")
assert not cube2.hasAttr("audio_trigger"), "cube2 audio_trigger should be removed"
print(f"[PASS] remove(*, cube2): all triggers gone")

# ================================================================
# Carrier animation + FBX export
# ================================================================

pm.setKeyframe(cube, attribute="translateY", time=1,  value=0)
pm.setKeyframe(cube, attribute="translateY", time=60, value=3)

pm.select(cube)
if not cmds.pluginInfo("fbxmaya", q=True, loaded=True):
    cmds.loadPlugin("fbxmaya")
pm.mel.eval("FBXResetExport")
pm.mel.eval("FBXExportBakeComplexAnimation -v true")
pm.mel.eval("FBXExportBakeComplexStart -v 1")
pm.mel.eval("FBXExportBakeComplexEnd -v 60")
pm.mel.eval('FBXProperty "Export|AdvOptGrp|UI|ShowWarningsManager" -v 0')
fbx_mel = fbx_path.replace("\\", "/")
pm.mel.eval(f'FBXExport -f "{fbx_mel}" -s')

# ---- Collect results ----
all_keys = {}
for t, v in zip(
    pm.keyframe(cube, at="audio_trigger", q=True, tc=True),
    pm.keyframe(cube, at="audio_trigger", q=True, vc=True),
):
    all_keys[str(int(t))] = int(v)

results = {
    "fbx_path": fbx_path,
    "fbx_exists": os.path.exists(fbx_path),
    "baked_manifest": manifest,
    "events": list(EventTriggers.get_events(cube, category="audio")),
    "keyframes": all_keys,
    "ensure_tests_passed": True,
    "multi_category_passed": True,
    "remove_tests_passed": True,
}

with open(os.path.join(output_dir, "maya_results.json"), "w") as f:
    json.dump(results, f, indent=2)

print("\n" + "=" * 60)
print("MAYA EXPORT COMPLETE — ALL TESTS PASSED")
print("=" * 60)
maya.standalone.uninitialize()
'''


# ======================================================================
# Unity-side C# scripts
# ======================================================================

UNITY_POSTPROCESSOR_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

public class AudioEventTestPostprocessor : AssetPostprocessor
{
    const string RESULTS_DIR = @"__RESULTS_DIR__";

    void OnPreprocessModel()
    {
        var importer = assetImporter as ModelImporter;
        if (importer != null && !importer.importAnimatedCustomProperties)
            importer.importAnimatedCustomProperties = true;
    }

    void OnPostprocessGameObjectWithUserProperties(
        GameObject go, string[] propNames, object[] values)
    {
        var entries = new List<string>();
        for (int i = 0; i < propNames.Length; i++)
        {
            string typeName = values[i] != null ? values[i].GetType().Name : "null";
            string valStr = values[i] != null ? values[i].ToString() : "null";
            entries.Add("  \"" + Escape(propNames[i]) + "\": {\"type\": \""
                + typeName + "\", \"value\": \"" + Escape(valStr) + "\"}");
        }

        string outPath = Path.Combine(RESULTS_DIR, "postprocessor_results.json");
        string json = "{\n  \"gameObject\": \"" + go.name + "\",\n"
            + string.Join(",\n", entries) + "\n}";
        File.WriteAllText(outPath, json);

        Debug.Log("[AudioEventTest] Captured " + propNames.Length
            + " user properties on " + go.name);
    }

    static string Escape(string s)
    {
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n");
    }
}
"""

UNITY_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class AudioEventTestVerifier
{
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";
        string fbxAssetPath = "Assets/audio_events_test.fbx";

        // Reimport with custom properties enabled
        var importer = AssetImporter.GetAtPath(fbxAssetPath) as ModelImporter;
        if (importer != null)
        {
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            importer.importAnimatedCustomProperties = true;
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAssetPath);
            AssetDatabase.ImportAsset(fbxAssetPath,
                ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
        }
        AssetDatabase.Refresh();

        var results = new Dictionary<string, object>();

        // Check animation curves
        var clips = AssetDatabase.LoadAllAssetsAtPath(fbxAssetPath)
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__"))
            .ToArray();

        bool hasAudioEventCurve = false;
        int audioEventKeyCount = 0;
        var allCurveNames = new List<string>();

        if (clips.Length > 0)
        {
            var clip = clips[0];
            var bindings = AnimationUtility.GetCurveBindings(clip);

            foreach (var binding in bindings)
            {
                allCurveNames.Add(binding.propertyName);
                if (binding.propertyName == "audio_trigger")
                {
                    hasAudioEventCurve = true;
                    var curve = AnimationUtility.GetEditorCurve(clip, binding);
                    audioEventKeyCount = curve != null ? curve.length : 0;
                }
            }
        }

        results["clips_found"] = clips.Length;
        results["has_audio_event_curve"] = hasAudioEventCurve;
        results["audio_event_key_count"] = audioEventKeyCount;
        results["all_curve_names"] = allCurveNames.ToArray();

        // Read postprocessor results
        string postprocPath = Path.Combine(
            Path.GetDirectoryName(resultsFile), "postprocessor_results.json");
        results["postprocessor_fired"] = File.Exists(postprocPath);

        // Write results
        File.WriteAllText(resultsFile, DictToJson(results));
        Debug.Log("AUDIO EVENT TEST COMPLETE. Results at: " + resultsFile);

        EditorApplication.Exit(0);
    }

    static string DictToJson(Dictionary<string, object> dict)
    {
        var parts = new List<string>();
        foreach (var kv in dict)
        {
            string val;
            if (kv.Value is string[] arr)
                val = "[" + string.Join(",", System.Array.ConvertAll(arr,
                    s => "\"" + Escape(s) + "\"")) + "]";
            else if (kv.Value is string s)
                val = "\"" + Escape(s) + "\"";
            else if (kv.Value is bool b)
                val = b ? "true" : "false";
            else if (kv.Value is int i)
                val = i.ToString();
            else
                val = "\"" + Escape(kv.Value != null ? kv.Value.ToString() : "null") + "\"";
            parts.Add("\"" + Escape(kv.Key) + "\": " + val);
        }
        return "{" + string.Join(",\n", parts) + "}";
    }

    static string Escape(string s)
    {
        return s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n");
    }
}
"""


# ======================================================================
# Test class
# ======================================================================


class TestAudioEventsIntegration(unittest.TestCase):
    """Full pipeline: EventTriggers module -> FBX -> Unity verification."""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="audio_events_integ_")
        cls.fbx_path = None
        cls.maya_results = None
        cls.unity_results = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        logger.info(f"Results preserved in: {cls.temp_dir}")

    # ------------------------------------------------------------------
    # Step 1: Maya export using EventTriggers module
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    def test_01_maya_export(self):
        """Create event triggers via EventTriggers API, verify attrs, export FBX."""
        script_path = os.path.join(self.temp_dir, "maya_export.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(MAYA_EXPORT_SCRIPT)

        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join(
            [
                os.path.join(scripts_dir, "mayatk"),
                os.path.join(scripts_dir, "pythontk"),
            ]
        )
        env["PYTHONIOENCODING"] = "utf-8"

        proc = subprocess.run(
            [MAYAPY, script_path, self.temp_dir],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        if proc.stdout:
            logger.info(f"MAYAPY stdout:\n{proc.stdout[-2000:]}")
        if proc.stderr:
            logger.warning(f"MAYAPY stderr:\n{proc.stderr[-2000:]}")

        self.assertEqual(proc.returncode, 0, f"mayapy failed:\n{proc.stderr[-1000:]}")

        results_path = os.path.join(self.temp_dir, "maya_results.json")
        self.assertTrue(os.path.exists(results_path))

        with open(results_path) as f:
            self.__class__.maya_results = json.load(f)

        r = self.__class__.maya_results
        self.__class__.fbx_path = r["fbx_path"]
        self.assertTrue(r["fbx_exists"])
        self.assertIn("10:Footstep", r["baked_manifest"])
        self.assertIn("30:Jump", r["baked_manifest"])
        self.assertIn("45:Land", r["baked_manifest"])
        self.assertEqual(r["keyframes"]["10"], 1)  # Footstep
        self.assertEqual(r["keyframes"]["30"], 2)  # Jump
        self.assertEqual(r["keyframes"]["45"], 3)  # Land
        self.assertTrue(r["ensure_tests_passed"])
        self.assertTrue(r["multi_category_passed"])
        self.assertTrue(r["remove_tests_passed"])

    # ------------------------------------------------------------------
    # Step 2: Unity import and readback
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_02_unity_import(self):
        """Import FBX into Unity, verify curve and manifest survived."""
        fbx_path = self.__class__.fbx_path
        if not fbx_path or not os.path.exists(fbx_path):
            self.skipTest("FBX not available — test_01 must run first")

        launcher = UnityLauncher()
        project_path = os.path.join(self.temp_dir, "UnityProject")

        logger.info(f"Creating Unity project: {project_path}")
        created = launcher.create_project(project_path, batch_mode=True)
        self.assertTrue(created, "Failed to create Unity project")

        assets_path = os.path.join(project_path, "Assets")
        dest_fbx = os.path.join(assets_path, "audio_events_test.fbx")
        shutil.copy2(fbx_path, dest_fbx)

        editor_path = os.path.join(assets_path, "Editor")
        os.makedirs(editor_path, exist_ok=True)

        # Deploy postprocessor
        results_dir_escaped = self.temp_dir.replace("\\", "\\\\")
        postproc_cs = UNITY_POSTPROCESSOR_CS.replace(
            "__RESULTS_DIR__", results_dir_escaped
        )
        with open(
            os.path.join(editor_path, "AudioEventTestPostprocessor.cs"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write(postproc_cs)

        # Deploy verifier
        results_path = os.path.join(self.temp_dir, "unity_results.json")
        results_path_escaped = results_path.replace("\\", "\\\\")
        verifier_cs = UNITY_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path_escaped
        )
        with open(
            os.path.join(editor_path, "AudioEventTestVerifier.cs"),
            "w",
            encoding="utf-8",
        ) as f:
            f.write(verifier_cs)

        log_path = os.path.join(self.temp_dir, "unity_log.txt")
        launcher.project_path = project_path

        proc = launcher.launch_editor(
            batch_mode=True,
            execute_method="AudioEventTestVerifier.Verify",
            log_file=log_path,
            extra_args=["-quit"],
            detached=False,
        )

        if proc:
            try:
                proc.wait(timeout=300)
            except subprocess.TimeoutExpired:
                proc.kill()
                raise TimeoutError("Unity timed out")

        if os.path.exists(log_path):
            with open(log_path) as f:
                log_tail = f.read()[-3000:]
            logger.info(f"Unity log tail:\n{log_tail}")

        self.assertTrue(
            os.path.exists(results_path),
            f"unity_results.json not created — check {log_path}",
        )
        with open(results_path) as f:
            self.__class__.unity_results = json.load(f)

        logger.info(
            f"Unity results:\n{json.dumps(self.__class__.unity_results, indent=2)}"
        )

    # ------------------------------------------------------------------
    # Step 3: Analyze round-trip results
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_03_analyze(self):
        """Verify the event_trigger float curve and manifest string survived."""
        unity = self.__class__.unity_results
        if not unity:
            self.skipTest("Unity results not available")

        # Read postprocessor output
        postproc_path = os.path.join(self.temp_dir, "postprocessor_results.json")
        postproc = {}
        if os.path.exists(postproc_path):
            with open(postproc_path) as f:
                postproc = json.load(f)

        # ---- Verdicts ----
        print("\n" + "=" * 60)
        print("  EVENT TRIGGERS INTEGRATION TEST RESULTS")
        print("=" * 60)

        # Baked manifest survived as user property?
        has_manifest = "audio_manifest" in postproc
        manifest_value = postproc.get("audio_manifest", {}).get("value", "")
        print(f"\n  audio_manifest:       {'PASS' if has_manifest else 'FAIL'}")
        if has_manifest:
            print(f"    Value: {manifest_value}")

        # Postprocessor fired?
        print(
            f"  Postprocessor fired:  {'PASS' if unity.get('postprocessor_fired') else 'FAIL'}"
        )

        # All curves found (may include legacy float curve or enum curve)
        print(f"  All curves: {unity.get('all_curve_names', [])}")

        print("=" * 60)
        print(f"  Temp dir: {self.temp_dir}")
        print("=" * 60 + "\n")

        # Assertions — the baked manifest string is the sole transport now
        self.assertTrue(
            has_manifest, "audio_manifest string did not arrive as user property"
        )
        self.assertIn("Footstep", manifest_value)
        self.assertIn("Jump", manifest_value)
        self.assertIn("Land", manifest_value)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    unittest.main()
