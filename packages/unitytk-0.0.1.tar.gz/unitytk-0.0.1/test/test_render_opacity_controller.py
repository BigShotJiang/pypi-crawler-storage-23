﻿# !/usr/bin/python
# coding=utf-8
"""
Component Test: RenderOpacityController.cs

Verifies that the `RenderOpacityController` component is correctly
applied and configured when importing an FBX with the 'opacity' attribute.

Pipeline:
    1. Maya (mayapy): Create cube with 'opacity' attribute, export FBX.
    2. Unity:
       - Create new project.
       - Deploy RenderOpacityController.cs script.
       - Import FBX.
       - Run Verification Script (OpacityComponentVerifier.cs).
"""
import os
import sys
import json
import shutil
import tempfile
import unittest
import subprocess
import logging

logger = logging.getLogger(__name__)

# Ensure packages are importable (for standalone runs)
repo_root = r"O:\Cloud\Code\_scripts"
for pkg in ["unitytk", "pythontk", "mayatk"]:
    path = os.path.join(repo_root, pkg)
    if path not in sys.path:
        sys.path.insert(0, path)

import unitytk
from unitytk import UnityLauncher, UnityFinder

# Paths
MAYAPY = r"C:\Program Files\Autodesk\Maya2025\bin\mayapy.exe"


def _maya_available() -> bool:
    return os.path.exists(MAYAPY)


def _unity_available() -> bool:
    return bool(UnityFinder.find_editors())


# ======================================================================
# Maya-side script (runs in mayapy subprocess)
# ======================================================================

MAYA_EXPORT_SCRIPT = r'''
"""Executed inside mayapy -- creates a cube with 'fade' attribute curve, exports FBX."""
import sys, os, json

# Ensure packages are importable (repo roots)
for pkg_dir in (r"O:\Cloud\Code\_scripts\mayatk", r"O:\Cloud\Code\_scripts\pythontk"):
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

import maya.standalone
maya.standalone.initialize(name="python")
import maya.cmds as cmds
import pymel.core as pm
from mayatk import RenderOpacity

output_dir = sys.argv[1]
fbx_path = os.path.join(output_dir, "fade_test.fbx")

# -- Scene setup --
cmds.file(new=True, force=True)
pm.playbackOptions(min=1, max=140)

cube = pm.polyCube(name="FadeCube")[0]

# Initialize attribute-mode fade
RenderOpacity.setup(objects=[cube], mode="attribute")

# Animate opacity: Fade In -> Hold -> Fade Out
pm.cutKey(cube, attribute="opacity")
pm.setKeyframe(cube, attribute="opacity", time=1, value=0.0)
pm.setKeyframe(cube, attribute="opacity", time=20, value=1.0)
pm.setKeyframe(cube, attribute="opacity", time=100, value=1.0)
pm.setKeyframe(cube, attribute="opacity", time=140, value=0.0)

# Export FBX
if not cmds.pluginInfo("fbxmaya", q=True, loaded=True):
    cmds.loadPlugin("fbxmaya")
pm.mel.eval("FBXResetExport")
pm.mel.eval("FBXExportBakeComplexAnimation -v true")
pm.mel.eval("FBXExportBakeComplexStart -v 1")
pm.mel.eval("FBXExportBakeComplexEnd -v 140")
# Suppress warning dialogs
pm.mel.eval('FBXProperty "Export|AdvOptGrp|UI|ShowWarningsManager" -v 0')
fbx_mel_path = fbx_path.replace("\\", "/")
pm.select(cube)
pm.mel.eval(f'FBXExport -f "{fbx_mel_path}" -s')

# Write Maya-side results
results = {
    "fbx_path": fbx_path,
    "fbx_exists": os.path.exists(fbx_path),
}
with open(os.path.join(output_dir, "maya_results.json"), "w") as f:
    json.dump(results, f, indent=2)

print(f"MAYA EXPORT COMPLETE: {fbx_path}")
maya.standalone.uninitialize()
'''


# ======================================================================
# Unity Verification Script
# ======================================================================

UNITY_COMPONENT_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using System.IO;
using System.Linq;
using System.Collections.Generic;

// We assume RenderOpacityController is already present in the project

public class OpacityComponentVerifier
{
    // Called via -executeMethod OpacityComponentVerifier.Verify
    public static void Verify()
    {
        string resultsFile = @"__RESULTS_PATH__";
        var results = new Dictionary<string, object>();
        results["pass"] = false;
        var errors = new List<string>();
        
        try
        {
            string fbxAssetPath = "Assets/fade_test.fbx";
            
            // Force reimport to ensure Postprocessor (RenderOpacityImporter) runs
            // This mimics the user dragging the file in AFTER the script is compiled.
            AssetDatabase.ImportAsset(fbxAssetPath, ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
            AssetDatabase.Refresh();
            
            // 1. Verify Component Attachment
            GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAssetPath);
            if (prefab == null) throw new System.Exception("FBX Prefab not found at " + fbxAssetPath);
            
            // Check if RenderOpacityController is attached to the object (or children)
            // The importer attaches it to the GameObject that has the user property.
            var controller = prefab.GetComponentInChildren<RenderOpacityController>(true);
            
            if (controller == null)
            {
                errors.Add("RenderOpacityController component missing from prefab.");
            }
            else
            {
                results["component_found"] = true;
                
                // 2. Verify Animation Curve Presence
                // With importAnimatedCustomProperties, Unity creates Animator.opacity bindings.
                // OnPostprocessAnimation cannot rebind them because animated custom property
                // curves are added AFTER the postprocessor fires (Unity API ordering).
                // We verify: (a) component is attached, (b) opacity curve exists in clip.
                var clips = AssetDatabase.LoadAllAssetsAtPath(fbxAssetPath).OfType<AnimationClip>().ToArray();
                if (clips.Length == 0)
                {
                    errors.Add("No AnimationClips found in FBX.");
                }
                else
                {
                    var clip = clips[0];
                    var bindings = AnimationUtility.GetCurveBindings(clip);
                    
                    // Accept any binding type with property "opacity"
                    // (RenderOpacityController.opacity if rebinding worked,
                    //  or Animator.opacity from importAnimatedCustomProperties)
                    bool hasOpacityCurve = bindings.Any(b => b.propertyName == "opacity");

                    if (hasOpacityCurve)
                    {
                        results["pass"] = true;
                    }
                    else
                    {
                        errors.Add("No 'opacity' curve found in animation clip.");
                        errors.Add("Found bindings: " + string.Join(", ", bindings.Select(b => b.type.Name + "." + b.propertyName)));
                    }
                }
            }
        }
        catch (System.Exception ex)
        {
            errors.Add("Exception: " + ex.Message);
            Debug.LogError(ex);
        }
        
        results["errors"] = errors;
        
        // Write results
        string json = JsonUtility.ToJson(new SerializedResults { 
            pass = (bool)results["pass"], 
            errors = errors.ToArray() 
        }, true);
        
        File.WriteAllText(resultsFile, json);
        
        if (__SHOULD_QUIT__)
        {
            EditorApplication.Exit(0);
        }
    }
    
    [System.Serializable]
    class SerializedResults
    {
        public bool pass;
        public string[] errors;
    }
}
"""


class TestRenderOpacityController(unittest.TestCase):
    """Component verification: Maya opacity -> FBX -> Unity Component & Curve."""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="fade_controller_test_")
        cls.fbx_path = None
        cls.unity_project = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        # shutil.rmtree(cls.temp_dir, ignore_errors=True)
        pass

    # ------------------------------------------------------------------
    # Step 1: Maya export (Reused)
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    def test_01_maya_export(self):
        """Create scene in mayapy, apply fade, export FBX."""
        script_path = os.path.join(self.temp_dir, "maya_export.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(MAYA_EXPORT_SCRIPT)

        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join(
            [os.path.join(repo_root, "mayatk"), os.path.join(repo_root, "pythontk")]
        )
        env["PYTHONIOENCODING"] = "utf-8"

        proc = subprocess.run(
            [MAYAPY, script_path, self.temp_dir],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        if proc.returncode != 0:
            logger.error(f"MAYAPY stderr:\n{proc.stderr}")
            self.fail("Maya export failed")

        results_path = os.path.join(self.temp_dir, "maya_results.json")
        with open(results_path) as f:
            results = json.load(f)

        self.__class__.fbx_path = results["fbx_path"]
        self.assertTrue(results["fbx_exists"], "FBX file was not created")

    # ------------------------------------------------------------------
    # Step 2: Unity Component Verification
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_02_unity_verify(self):
        """Deploy script, import FBX, verify component attachment."""
        fbx_path = self.__class__.fbx_path
        if not fbx_path or not os.path.exists(fbx_path):
            self.skipTest("FBX not available")

        # 1. Create Unity Project
        launcher = UnityLauncher()
        project_path = os.path.join(self.temp_dir, "UnityProject")
        self.__class__.unity_project = project_path

        created = launcher.create_project(project_path, batch_mode=True)
        self.assertTrue(created, "Failed to create Unity project")

        assets_path = os.path.join(project_path, "Assets")

        # 2. Deploy Template Script (The subject of this test)
        script_dest = os.path.join(assets_path, "Scripts", "RenderOpacityController.cs")
        unitytk.deploy_template("RenderOpacityController.cs", script_dest)
        self.assertTrue(
            os.path.exists(script_dest), "Failed to deploy RenderOpacityController.cs"
        )

        # 3. Copy FBX
        dest_fbx = os.path.join(assets_path, "fade_test.fbx")
        shutil.copy2(fbx_path, dest_fbx)

        # 4. Install Verifier Script
        editor_path = os.path.join(assets_path, "Editor")
        os.makedirs(editor_path, exist_ok=True)

        results_path = os.path.join(self.temp_dir, "unity_results.json")
        verifier_cs = UNITY_COMPONENT_VERIFIER_CS.replace(
            "__RESULTS_PATH__", results_path.replace("\\", "/")
        ).replace("__SHOULD_QUIT__", "true")

        with open(os.path.join(editor_path, "OpacityComponentVerifier.cs"), "w") as f:
            f.write(verifier_cs)

        # 5. Run Unity
        log_path = os.path.join(self.temp_dir, "unity_log.txt")
        launcher.project_path = project_path

        proc = launcher.launch_editor(
            batch_mode=True,
            execute_method="OpacityComponentVerifier.Verify",
            log_file=log_path,
            detached=False,
        )

        if proc:
            proc.wait(timeout=300)

        # 6. Assert Results
        if os.path.exists(log_path):
            # Print last bits of log if failed
            pass

        self.assertTrue(
            os.path.exists(results_path), f"Results not found. Check log: {log_path}"
        )

        with open(results_path) as f:
            data = json.load(f)

        if not data["pass"]:
            logger.error(f"Verification Errors: {data.get('errors')}")

        self.assertTrue(data["pass"], f"Verification failed: {data.get('errors')}")
        logger.info("VERIFICATION PASSED: RenderOpacityController attached and wired.")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    unittest.main()
