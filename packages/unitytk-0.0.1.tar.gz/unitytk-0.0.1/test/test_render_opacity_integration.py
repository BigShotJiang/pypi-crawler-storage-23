# !/usr/bin/python
# coding=utf-8
"""
Integration test: Maya RenderOpacity -> FBX -> Unity AnimationClip verification.

End-to-end pipeline:
    1. Maya (mayapy): Create cube, add 'opacity' attribute, key it, export FBX.
    2. Unity (batchmode): Import the FBX, inspect the AnimationClip for
       the 'opacity' custom property curve, write pass/fail to a results file.

Requires:
    - Maya 2025 installed (mayapy.exe)
    - Unity Hub with at least one editor installed
    - mayatk, pythontk on PYTHONPATH
"""
import os
import sys
import json
import shutil
import tempfile
import unittest
import subprocess
import logging

logger = logging.getLogger(__name__)

# Set to True to keep Unity open after test (requires manual closing)
# Can be overridden by setting environment variable MANUAL_VERIFICATION=1
MANUAL_VERIFICATION = os.getenv("MANUAL_VERIFICATION", "0") == "1"

# Ensure packages are importable
scripts_dir = r"O:\Cloud\Code\_scripts"
if scripts_dir not in sys.path:
    sys.path.insert(0, scripts_dir)

from unitytk import UnityLauncher, UnityFinder

# Paths
MAYAPY = r"C:\Program Files\Autodesk\Maya2025\bin\mayapy.exe"


def _maya_available() -> bool:
    return os.path.exists(MAYAPY)


def _unity_available() -> bool:
    return bool(UnityFinder.find_editors())


# ======================================================================
# Maya-side script (runs in mayapy subprocess)
# ======================================================================

MAYA_EXPORT_SCRIPT = r'''
"""Executed inside mayapy -- creates a cube with 'fade' attribute curve, exports FBX."""
import sys, os, json

# Ensure packages are importable (repo roots, not monorepo root)
for pkg_dir in (r"O:\Cloud\Code\_scripts\mayatk", r"O:\Cloud\Code\_scripts\pythontk"):
    if pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

import maya.standalone
maya.standalone.initialize(name="python")
import maya.cmds as cmds
import pymel.core as pm

import mayatk  # bootstrap lazy-loader
from mayatk import RenderOpacity

output_dir = sys.argv[1]  # passed from the test
fbx_path = os.path.join(output_dir, "fade_test.fbx")

# -- Scene setup --
cmds.file(new=True, force=True)
pm.playbackOptions(min=1, max=140)

cube = pm.polyCube(name="FadeCube")[0]

# Initialize attribute-mode fade
result = RenderOpacity.setup(
    objects=[cube], mode="attribute"
)

# Three-phase animation sequence:
# Phase 1 (1-20):    Fade In   (0.0 -> 1.0) - cube becomes visible
# Phase 2 (20-100):  Hold/Animate (1.0) - cube visible + moving/rotating
# Phase 3 (100-140): Fade Out  (1.0 -> 0.0) - cube becomes invisible
pm.cutKey(cube, attribute="opacity")  # Clear setup keys
pm.setKeyframe(cube, attribute="opacity", time=1, value=0.0)
pm.setKeyframe(cube, attribute="opacity", time=20, value=1.0)
pm.setKeyframe(cube, attribute="opacity", time=100, value=1.0)
pm.setKeyframe(cube, attribute="opacity", time=140, value=0.0)

# Verify attribute exists before export
assert cube.hasAttr("opacity"), "opacity attribute was not created"
curves = pm.listConnections(cube.opacity, type="animCurve")
assert curves, "opacity attribute has no animation curve"

# Bake for clean FBX
# RenderOpacity.bake(objects=[cube], sample_by=1.0, optimize=True, mode="attribute")

# Add carrier keyframes spanning full 140-frame sequence:
# Animation occurs during phase 2 (20-100: visible + moving/rotating)
pm.setKeyframe(cube, attribute="translateY", time=1, value=0)
pm.setKeyframe(cube, attribute="translateY", time=20, value=0)
pm.setKeyframe(cube, attribute="translateY", time=60, value=5)  # Rise during animation
pm.setKeyframe(cube, attribute="translateY", time=100, value=0)
pm.setKeyframe(cube, attribute="translateY", time=140, value=0)

pm.setKeyframe(cube, attribute="rotateY", time=1, value=0)
pm.setKeyframe(cube, attribute="rotateY", time=20, value=0)
pm.setKeyframe(cube, attribute="rotateY", time=100, value=360)  # Full spin during animation
pm.setKeyframe(cube, attribute="rotateY", time=140, value=360)

# Select for export
pm.select(cube)

# Export FBX -- must enable custom properties
if not cmds.pluginInfo("fbxmaya", q=True, loaded=True):
    cmds.loadPlugin("fbxmaya")
pm.mel.eval("FBXResetExport")
pm.mel.eval("FBXExportBakeComplexAnimation -v true")
pm.mel.eval("FBXExportBakeComplexStart -v 1")
pm.mel.eval("FBXExportBakeComplexEnd -v 140")
# Suppress warning dialogs
pm.mel.eval('FBXProperty "Export|AdvOptGrp|UI|ShowWarningsManager" -v 0')
fbx_mel_path = fbx_path.replace("\\", "/")
pm.mel.eval(f'FBXExport -f "{fbx_mel_path}" -s')

# Determine keyed attributes manually for report since 'bake' is deprecated
keyed_attrs = pm.listAttr(cube, k=True) or []
actual_keys = []
for attr in keyed_attrs:
    if pm.keyframe(cube, attribute=attr, query=True, keyframeCount=True):
        actual_keys.append(attr)

# Explicitly check 'opacity' as it often gets missed in listAttr(k=True) for dynamic attrs
if "opacity" not in actual_keys and cube.hasAttr("opacity"):
    if pm.keyframe(cube, attribute="opacity", query=True, keyframeCount=True):
        actual_keys.append("opacity")

# Write Maya-side results
results = {
    "fbx_path": fbx_path,
    "fbx_exists": os.path.exists(fbx_path),
    "attrs_keyed": actual_keys,
}
with open(os.path.join(output_dir, "maya_results.json"), "w") as f:
    json.dump(results, f, indent=2)

print(f"MAYA EXPORT COMPLETE: {fbx_path}")
maya.standalone.uninitialize()
'''

# ======================================================================
# Unity-side C# Helper scripts
# ======================================================================

UNITY_VISUALIZER_CS = r"""
using UnityEngine;

[ExecuteAlways]
public class FadeVisualizer : MonoBehaviour
{
    [Range(0, 1)]
    public float opacity; // This will now be driven directly by the Animation Clip

    private Material _mat;

    void OnEnable()
    {
        Init();
    }


    void Init()
    {
        var renderer = GetComponent<Renderer>();
        if (renderer == null) return;

        // Reuse existing or create new
        if (renderer.sharedMaterial != null && renderer.sharedMaterial.name.StartsWith("FadeVisualizerMat"))
        {
             _mat = renderer.sharedMaterial;
        }
        else
        {
            _mat = new Material(Shader.Find("Standard"));
            _mat.name = "FadeVisualizerMat";
            _mat.SetFloat("_Mode", 2); // Fade
            _mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            _mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            _mat.SetInt("_ZWrite", 0);
            _mat.DisableKeyword("_ALPHATEST_ON");
            _mat.EnableKeyword("_ALPHABLEND_ON");
            _mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            _mat.renderQueue = 3000;
            
            if (renderer.sharedMaterial != null && renderer.sharedMaterial.HasProperty("_Color"))
            {
                _mat.color = renderer.sharedMaterial.color;
            }
            renderer.material = _mat;
        }
    }

    void Update()
    {
        if (_mat == null) Init();

        if (_mat)
        {
            // Direct drive from public field
            Color c = _mat.color;
            c.a = Mathf.Clamp01(opacity); 
            _mat.color = c;
        }
    }
}
"""

UNITY_VERIFIER_CS = r"""
using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using System.IO;
using System.Linq;

public class FadeVerifier
{{
    // Called via -executeMethod FadeVerifier.Verify
    public static void Verify()
    {{
        string resultsFile = @"{results_path}";
        string fbxAssetPath = "Assets/fade_test.fbx";
        bool manualVerification = {should_quit} == false;  // If not quitting, we're in manual mode

        // Enable animated custom properties import (off by default)
        var importer = AssetImporter.GetAtPath(fbxAssetPath) as ModelImporter;
        if (importer != null)
        {{
            importer.importAnimation = true;
            importer.animationType = ModelImporterAnimationType.Generic;
            importer.importAnimatedCustomProperties = true;

            // Write settings and reimport synchronously
            EditorUtility.SetDirty(importer);
            AssetDatabase.WriteImportSettingsIfDirty(fbxAssetPath);
            AssetDatabase.ImportAsset(fbxAssetPath,
                ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
        }}
        else
        {{
            Debug.LogError("Could not get ModelImporter for " + fbxAssetPath);
        }}

        // Refresh after reimport
        AssetDatabase.Refresh();

        // Get all animation clips from the FBX
        var clips = AssetDatabase.LoadAllAssetsAtPath(fbxAssetPath)
            .OfType<AnimationClip>()
            .Where(c => !c.name.StartsWith("__preview__"))
            .ToArray();

        bool hasFadeCurve = false;
        string[] curveNames = new string[0];

        if (clips.Length > 0)
        {{
            var bindings = AnimationUtility.GetCurveBindings(clips[0]);
            curveNames = bindings.Select(b => b.propertyName).ToArray();
            hasFadeCurve = bindings.Any(b => b.propertyName == "opacity");

            Debug.Log("Clip: " + clips[0].name + ", Bindings: " + string.Join(", ", curveNames));
            
            // If manual verification, set up scene for animation preview
            if (manualVerification)
            {{
                SetupAnimationPreview(fbxAssetPath, clips[0]);
            }}
        }}

        // Write results as JSON
        string json = "{{\n"
            + "  \"clips_found\": " + clips.Length + ",\n"
            + "  \"has_fade_curve\": " + hasFadeCurve.ToString().ToLower() + ",\n"
            + "  \"curve_names\": [\"" + string.Join("\", \"", curveNames) + "\"],\n"
            + "  \"pass\": " + hasFadeCurve.ToString().ToLower() + "\n"
            + "}}";

        File.WriteAllText(resultsFile, json);
        Debug.Log("FADE VERIFICATION: " + (hasFadeCurve ? "PASS" : "FAIL"));
        Debug.Log("Results written to: " + resultsFile);

        bool shouldQuit = {should_quit};
        if (shouldQuit)
        {{
            EditorApplication.Exit(hasFadeCurve ? 0 : 1);
        }}
    }}
    
    private static void SetupAnimationPreview(string fbxAssetPath, AnimationClip clip)
    {{
        Debug.Log("Setting up animation preview...");
        
        // Try to find or instantiate FadeCube
        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
        var rootObjects = scene.GetRootGameObjects();
        GameObject fadeCube = null;
        
        // Search for existing FadeCube
        foreach (var root in rootObjects)
        {{
            fadeCube = FindGameObjectRecursive(root, "FadeCube");
            if (fadeCube != null) break;
        }}
        
        // If not found, try to instantiate from FBX
        if (fadeCube == null)
        {{
            try
            {{
                // Load the model prefab
                var model = AssetDatabase.LoadAssetAtPath<GameObject>(fbxAssetPath);
                if (model != null)
                {{
                    // Use Editor instantiation
                    fadeCube = PrefabUtility.InstantiatePrefab(model) as GameObject;
                    if (fadeCube == null)
                    {{
                        // Fallback: simple instantiation
                        fadeCube = Object.Instantiate(model);
                    }}
                    if (fadeCube != null)
                    {{
                        fadeCube.name = "FadeCube";
                        Debug.Log("Instantiated FadeCube into scene");
                    }}
                }}
            }}
            catch (System.Exception e)
            {{
                Debug.LogWarning("Could not instantiate model: " + e.Message);
            }}
        }}
        
        if (fadeCube != null)
        {{
            // Ensure Animator component exists
            var animator = fadeCube.GetComponent<Animator>();
            if (animator == null)
            {{
                animator = fadeCube.AddComponent<Animator>();
                Debug.Log("Added Animator to FadeCube");
            }}

            // Create temporary controller to enable preview
            var controllerPath = "Assets/TempFadeController.controller";
            var controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
            // CRITICAL: Must add parameter matching the curve name for GetFloat("opacity") to work!
            controller.AddParameter("opacity", AnimatorControllerParameterType.Float);
            controller.AddMotion(clip);
            animator.runtimeAnimatorController = controller;
            
            // Add Visualizer helper for manual verification (maps opacity -> alpha)
            fadeCube.AddComponent<FadeVisualizer>();

            // KEY STEP: Rebind the "opacity" curve to the FadeVisualizer script
            // This ensures the Animation Window drives the public float 'opacity' directly
            var bindings = AnimationUtility.GetCurveBindings(clip);
            foreach (var binding in bindings)
            {{
                if (binding.propertyName == "opacity")
                {{
                    var curve = AnimationUtility.GetEditorCurve(clip, binding);
                    // Create new binding pointing to the MonoScript field
                    var newBinding = EditorCurveBinding.FloatCurve("", typeof(FadeVisualizer), "opacity");
                    AnimationUtility.SetEditorCurve(clip, newBinding, curve);
                    Debug.Log("Rebound 'opacity' curve to FadeVisualizer.opacity");
                }}
            }}

            // Select the object
            Selection.activeGameObject = fadeCube;
            
            // Highlight in hierarchy
            EditorGUIUtility.PingObject(fadeCube);
            
            Debug.Log("\n=================================================");
            Debug.Log("Animation Setup Complete!");
            Debug.Log("=================================================");
            Debug.Log("To preview the fade animation:");
            Debug.Log("  1. Select FadeCube in the Hierarchy (already selected)");
            Debug.Log("  2. In Project panel, find fade_test.fbx > Take 001");
            Debug.Log("  3. Double-click Take 001 to open in Animation window");
            Debug.Log("  4. Click the Play button [>] in Animation window");
            Debug.Log("\nWatch the 'opacity' value animate through 3 phases:");
            Debug.Log("  - 0-20:    Fade In   (0.0 to 1.0)");
            Debug.Log("  - 20-100:  Hold visible (1.0)");
            Debug.Log("  - 100-140: Fade Out  (1.0 to 0.0)");
            Debug.Log("=================================================");
        }}
        else
        {{
            Debug.LogWarning("Could not create FadeCube. Manual steps required.");
        }}
    }}
    
    private static GameObject FindGameObjectRecursive(GameObject parent, string targetName)
    {{
        if (parent.name == targetName)
            return parent;
        
        foreach (Transform child in parent.transform)
        {{
            var result = FindGameObjectRecursive(child.gameObject, targetName);
            if (result != null)
                return result;
        }}
        
        return null;
    }}
}}
"""


class TestRenderOpacityIntegration(unittest.TestCase):
    """Full pipeline: Maya fade -> FBX export -> Unity clip verification."""

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = tempfile.mkdtemp(prefix="fade_integration_")
        cls.fbx_path = None
        cls.unity_project = None
        logger.info(f"Temp dir: {cls.temp_dir}")

    @classmethod
    def tearDownClass(cls):
        # Keep temp dir for debugging if tests fail — comment out to auto-clean
        # shutil.rmtree(cls.temp_dir, ignore_errors=True)
        pass

    # ------------------------------------------------------------------
    # Step 1: Maya export
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    def test_01_maya_export(self):
        """Create scene in mayapy, apply fade, export FBX."""
        script_path = os.path.join(self.temp_dir, "maya_export.py")
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(MAYA_EXPORT_SCRIPT)

        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join(
            [
                os.path.join(scripts_dir, "mayatk"),
                os.path.join(scripts_dir, "pythontk"),
            ]
        )
        env["PYTHONIOENCODING"] = "utf-8"

        proc = subprocess.run(
            [MAYAPY, script_path, self.temp_dir],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        # Debug output
        if proc.stdout:
            logger.info(f"MAYAPY stdout:\n{proc.stdout[-2000:]}")
        if proc.stderr:
            logger.warning(f"MAYAPY stderr:\n{proc.stderr[-2000:]}")

        self.assertEqual(proc.returncode, 0, f"mayapy failed:\n{proc.stderr[-1000:]}")

        # Verify results file
        results_path = os.path.join(self.temp_dir, "maya_results.json")
        self.assertTrue(os.path.exists(results_path), "maya_results.json not created")

        with open(results_path) as f:
            results = json.load(f)

        self.__class__.fbx_path = results["fbx_path"]
        self.assertTrue(results["fbx_exists"], "FBX file was not created")
        self.assertTrue(
            any("opacity" in a for a in results["attrs_keyed"]),
            f"'opacity' not in keyed attrs: {results['attrs_keyed']}",
        )

    # ------------------------------------------------------------------
    # Step 2: Unity verification
    # ------------------------------------------------------------------

    @unittest.skipUnless(_maya_available(), "Maya 2025 not installed")
    @unittest.skipUnless(_unity_available(), "No Unity editor found")
    def test_02_unity_import(self):
        """Import FBX into Unity, verify AnimationClip contains 'fade' curve."""
        fbx_path = self.__class__.fbx_path
        if not fbx_path or not os.path.exists(fbx_path):
            self.skipTest("FBX not available — test_01 must run first")

        # -- Create a temporary Unity project --
        launcher = UnityLauncher()
        project_path = os.path.join(self.temp_dir, "UnityProject")
        self.__class__.unity_project = project_path

        logger.info(f"Creating Unity project: {project_path}")
        created = launcher.create_project(project_path, batch_mode=True)
        self.assertTrue(created, "Failed to create Unity project")

        # -- Copy FBX into Assets/ --
        assets_path = os.path.join(project_path, "Assets")
        dest_fbx = os.path.join(assets_path, "fade_test.fbx")
        shutil.copy2(fbx_path, dest_fbx)
        self.assertTrue(os.path.exists(dest_fbx))

        # -- Install verifier script (template in the results path) --
        editor_path = os.path.join(assets_path, "Editor")
        os.makedirs(editor_path, exist_ok=True)

        results_path = os.path.join(self.temp_dir, "unity_results.json")
        should_quit = "true" if not MANUAL_VERIFICATION else "false"
        verifier_cs = UNITY_VERIFIER_CS.format(
            results_path=results_path, should_quit=should_quit
        )
        verifier_path = os.path.join(editor_path, "FadeVerifier.cs")
        with open(verifier_path, "w", encoding="utf-8", errors="replace") as f:
            f.write(verifier_cs)

        # Write Visualizer helper for manual mode
        visualizer_path = os.path.join(assets_path, "FadeVisualizer.cs")
        with open(visualizer_path, "w", encoding="utf-8") as f:
            f.write(UNITY_VISUALIZER_CS)

        # -- Run Unity --
        log_path = os.path.join(self.temp_dir, "unity_log.txt")

        launcher.project_path = project_path

        # Manual verification: Show GUI, keep open
        batch_mode = not MANUAL_VERIFICATION
        extra_args = ["-quit"] if not MANUAL_VERIFICATION else []

        proc = launcher.launch_editor(
            batch_mode=batch_mode,
            execute_method="FadeVerifier.Verify",
            log_file=log_path,
            extra_args=extra_args,
            detached=False,
        )

        # Wait for completion
        if proc:
            # If manual, wait indefinitely until user closes Unity
            timeout = 300 if not MANUAL_VERIFICATION else None
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                raise TimeoutError("Unity timed out")

        # -- Read results --
        unity_results_path = os.path.join(self.temp_dir, "unity_results.json")

        # Unity log for debugging
        if os.path.exists(log_path):
            with open(log_path) as f:
                log_tail = f.read()[-3000:]
            logger.info(f"Unity log tail:\n{log_tail}")

        self.assertTrue(
            os.path.exists(unity_results_path),
            f"unity_results.json not created — check {log_path}",
        )

        with open(unity_results_path) as f:
            results = json.load(f)

        self.assertTrue(
            results.get("pass", False),
            f"Unity did NOT find 'fade' curve.\n"
            f"Clips found: {results.get('clips_found')}\n"
            f"Curve names: {results.get('curve_names')}",
        )
        logger.info(f"INTEGRATION TEST PASSED — fade curve verified in Unity")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    unittest.main()
