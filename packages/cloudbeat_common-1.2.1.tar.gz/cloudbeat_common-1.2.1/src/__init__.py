from cloudbeat_common import cb
