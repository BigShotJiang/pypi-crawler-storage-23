"""Firecracker microVM isolation support for agentcage."""
