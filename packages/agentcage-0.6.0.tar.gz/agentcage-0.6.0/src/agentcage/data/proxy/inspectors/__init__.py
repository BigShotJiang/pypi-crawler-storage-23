"""agentcage inspectors — pluggable traffic inspection framework."""

from inspectors.base import Inspector, InspectionResult, InspectionContext

__all__ = ["Inspector", "InspectionResult", "InspectionContext"]
