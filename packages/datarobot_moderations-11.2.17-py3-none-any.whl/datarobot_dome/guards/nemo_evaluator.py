#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import json
from functools import cached_property
from typing import Optional

from datarobot.enums import CustomMetricAggregationType
from datarobot.enums import CustomMetricDirectionality
from nemo_microservices import AsyncNeMoMicroservices
from nemo_microservices.types import EvaluationConfigParam
from nemo_microservices.types import EvaluationTargetParam
from nemo_microservices.types import MetricConfigParam
from nemo_microservices.types import TaskConfigParam
from opentelemetry import trace

from datarobot_dome.constants import CUSTOM_METRIC_DESCRIPTION_SUFFIX
from datarobot_dome.constants import SPAN_PREFIX
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.guard_helpers import get_datarobot_endpoint_and_token

from .base import Guard


class NeMoLiveEvaluationFailedError(Exception):
    def __init__(self):
        super().__init__("NeMo live evaluation failed.")


class NeMoLiveEvaluationNanScoreError(Exception):
    def __init__(self):
        super().__init__("NeMo live evaluation returned NaN as score.")


class NeMoLiveEvaluationMissingScoreError(Exception):
    pass


class NeMoEvaluatorGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

        # overall config (populated by pipeline object after creating guard object)
        self.timeout_sec = None
        self.nemo_evaluator_deployment_id = None

        # guard specific config
        self.nemo_evaluator_type = config["nemo_evaluator_type"]
        self._llm_type = config["llm_type"]
        self.llm_deployment_id = config.get("deployment_id")
        self.llm_gateway_model_id = config.get("llm_gateway_model_id")

    @cached_property
    def client(self) -> AsyncNeMoMicroservices:
        """Client for communication with NeMo Evaluator."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        url = f"{datarobot_endpoint}/endpoints/deployments/{self.nemo_evaluator_deployment_id}/"
        return AsyncNeMoMicroservices(
            base_url=url,
            timeout=self.timeout_sec,
            default_headers={"Authorization": f"Bearer {datarobot_api_token}"},
        )

    @cached_property
    def llm_judge_api_endpoint(self) -> dict:
        """LLM Judge API endpoint, to be passed to NeMo evaluator."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        if self.llm_type == GuardLLMType.DATAROBOT:
            url = f"{datarobot_endpoint}/deployments/{self.llm_deployment_id}/chat/completions"
            model_id = ""
        elif self.llm_type == GuardLLMType.LLM_GATEWAY:
            url = f"{datarobot_endpoint}/genai/llmgw/chat/completions"
            model_id = self.llm_gateway_model_id
        else:
            raise ValueError(
                f"LLM type {self.llm_type} is not supported by NeMo Evaluator based guards."
            )
        return {"url": url, "api_key": datarobot_api_token, "model_id": model_id}

    def has_average_score_custom_metric(self) -> bool:
        return True

    def get_average_score_metric(self, stage):
        return {
            "name": self.get_average_score_custom_metric_name(stage),
            "directionality": CustomMetricDirectionality.HIGHER_IS_BETTER,
            "units": "score",
            "type": CustomMetricAggregationType.AVERAGE,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_average_score_custom_metric_name(stage)}. "
                f" {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def get_span_column_name(self, _) -> str:
        return f"nemo_{self.nemo_evaluator_type}"

    def get_span_attribute_name(self, stage):
        return f"{SPAN_PREFIX}.{stage.lower()}.{self.get_span_column_name(stage)}"

    async def evaluate(
        self,
        *,
        prompt: Optional[str],
        response: Optional[str],
        retrieved_contexts: Optional[list[str]],
    ) -> float:
        raise NotImplementedError

    async def evaluate_and_get_score(
        self,
        config: EvaluationConfigParam,
        target: EvaluationTargetParam,
        extra_query: Optional[dict] = None,
    ) -> float:
        kwargs = {}
        if extra_query is not None:
            kwargs["extra_query"] = extra_query
        if self.timeout_sec is not None:
            kwargs["timeout"] = self.timeout_sec
        evaluation = await self.client.evaluation.live(config=config, target=target, **kwargs)

        # add otel event to current span
        attributes = {"status": evaluation.status}
        if status_details := evaluation.status_details:
            attributes["message"] = status_details.message
        if logs := evaluation.logs:
            attributes["logs"] = json.dumps(logs)
        trace.get_current_span().add_event("NeMo Live Evaluation", attributes)

        # handle failed evaluation
        if evaluation.status == "failed":
            raise NeMoLiveEvaluationFailedError()

        # extract score
        # note: NeMo evaluator would sometimes (especially on LLM judge) return 0 even
        # when NaN is the result, so using nan_count to check for NaN.
        task = evaluation.result.tasks[self.nemo_evaluator_type]
        metric = task.metrics[self.nemo_evaluator_type]
        if scores := list(metric.scores.values()):
            score = scores[0]
            if score.stats and score.stats.nan_count > 0:
                raise NeMoLiveEvaluationNanScoreError()
            return score.value
        else:
            raise NeMoLiveEvaluationMissingScoreError(
                f"Unable to find nemo evaluator metric score for {self.nemo_evaluator_type}. "
                f"All available score keys: {', '.join(metric.scores.keys())}."
            )


class NeMoLLMJudgeGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_llm_judge_config = config["nemo_llm_judge_config"]

    def get_average_score_metric(self, stage):
        return {
            "name": self.get_average_score_custom_metric_name(stage),
            "directionality": self.nemo_llm_judge_config["custom_metric_directionality"],
            "units": "score",
            "type": CustomMetricAggregationType.AVERAGE,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_average_score_custom_metric_name(stage)}. "
                f" {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    async def evaluate(self, *, prompt: str, response: Optional[str], **kwargs) -> float:
        system_prompt = self.nemo_llm_judge_config["system_prompt"]
        user_prompt = self.nemo_llm_judge_config["user_prompt"]
        score_parsing_regex = self.nemo_llm_judge_config["score_parsing_regex"]

        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type="llm-judge",
                            params={
                                "model": {"api_endpoint": self.llm_judge_api_endpoint},
                                "template": {
                                    "messages": [
                                        {"role": "system", "content": system_prompt},
                                        {"role": "user", "content": user_prompt},
                                    ]
                                },
                                "scores": {
                                    self.nemo_evaluator_type: {
                                        "type": "int",
                                        "parser": {"type": "regex", "pattern": score_parsing_regex},
                                    }
                                },
                            },
                        )
                    },
                )
            },
        )
        row = {"promptText": prompt}
        if response is not None:
            row["responseText"] = response
        target = EvaluationTargetParam(type="rows", rows=[row])

        # Note: NeMo Evaluator makes a chat completion request to the judge LLM with "Ping" and 1
        # as max token limit before actually ask the judge LLM to do the judging.
        # Some LLM (notably GPT) will reject the Ping request because of the token limit, since
        # without the limit it'd respond with "Pong, how can I help you?", so 1 isn't enough.
        # Skipping validation allows us to bypass this issue.
        return await self.evaluate_and_get_score(
            config, target, extra_query={"skip_validation_checks": True}
        )


class NeMoContextRelevanceGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, retrieved_contexts: list[str], **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[{"user_input": prompt, "retrieved_contexts": retrieved_contexts}],
        )
        return await self.evaluate_and_get_score(config, target)


class NeMoResponseGroundednessGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, response: str, retrieved_contexts: list[str], **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[{"response": response, "retrieved_contexts": retrieved_contexts}],
        )
        return await self.evaluate_and_get_score(config, target)


class NeMoTopicAdherenceGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_topic_adherence_config = config["nemo_topic_adherence_config"]

    async def evaluate(self, *, prompt: str, response: str, **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "metric_mode": self.nemo_topic_adherence_config["metric_mode"],
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[
                {
                    "user_input": [
                        {"content": prompt, "type": "human"},
                        {"content": response, "type": "ai"},
                    ],
                    "reference_topics": self.nemo_topic_adherence_config["reference_topics"],
                }
            ],
        )
        return await self.evaluate_and_get_score(config, target)


class NeMoAgentGoalAccuracyGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, response: str, **kwargs) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "use_reference": False,
                            },
                        )
                    },
                )
            },
        )
        target = EvaluationTargetParam(
            type="rows",
            rows=[
                {
                    "user_input": [
                        {"content": prompt, "type": "human"},
                        {"content": response, "type": "ai"},
                    ],
                }
            ],
        )
        return await self.evaluate_and_get_score(config, target)


class NeMoResponseRelevancyGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.response_relevancy_config = config["nemo_response_relevancy_config"]

    @cached_property
    def embedding_judge_api_endpoint(self) -> dict:
        """Embedding judge API endpoint, to be passed to NeMo evaluator."""
        datarobot_endpoint, datarobot_api_token = get_datarobot_endpoint_and_token()
        deployment_id = self.response_relevancy_config["embedding_deployment_id"]
        url = f"{datarobot_endpoint}/deployments/{deployment_id}/directAccess/nim/v1/"
        return {"url": url, "api_key": datarobot_api_token, "model_id": ""}

    async def evaluate(
        self, *, prompt: str, response: str, retrieved_contexts: Optional[list[str]]
    ) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                                "judge_embeddings": {
                                    "model": {"api_endpoint": self.embedding_judge_api_endpoint},
                                },
                            },
                        )
                    },
                )
            },
        )
        row = {"user_input": prompt, "response": response}
        if retrieved_contexts:
            row["retrieved_contexts"] = retrieved_contexts
        target = EvaluationTargetParam(type="rows", rows=[row])
        return await self.evaluate_and_get_score(config, target)


class NeMoFaithfulnessGuard(NeMoEvaluatorGuard):
    async def evaluate(self, *, prompt: str, response: str, retrieved_contexts: list[str]) -> float:
        config = EvaluationConfigParam(
            type="custom",
            tasks={
                self.nemo_evaluator_type: TaskConfigParam(
                    type="data",
                    metrics={
                        self.nemo_evaluator_type: MetricConfigParam(
                            type=self.nemo_evaluator_type,
                            params={
                                "judge": {"model": {"api_endpoint": self.llm_judge_api_endpoint}},
                            },
                        )
                    },
                )
            },
        )
        row = {"user_input": prompt, "response": response, "retrieved_contexts": retrieved_contexts}
        target = EvaluationTargetParam(type="rows", rows=[row])
        return await self.evaluate_and_get_score(config, target)
