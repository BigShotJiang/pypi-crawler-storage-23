#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2026.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import logging
import os

import datarobot as dr
from nemoguardrails import LLMRails
from nemoguardrails import RailsConfig

from datarobot_dome.constants import NEMO_GUARDRAILS_DIR
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardOperatorType
from datarobot_dome.guard_helpers import DEFAULT_OPEN_AI_API_VERSION
from datarobot_dome.guard_helpers import get_azure_openai_client
from datarobot_dome.guard_helpers import get_chat_nvidia_llm
from datarobot_dome.guard_helpers import get_datarobot_endpoint_and_token
from datarobot_dome.guard_helpers import get_llm_gateway_client
from datarobot_dome.guard_helpers import use_llm_gateway_inference
from datarobot_dome.guards.base import Guard
from datarobot_dome.guards.guard_llm_mixin import GuardLLMMixin

NEMO_THRESHOLD = "TRUE"


class NeMoGuard(Guard, GuardLLMMixin):
    def __init__(self, config: dict, stage=None, model_dir: str = os.getcwd()):
        super().__init__(config, stage)
        # NeMo guard only takes a boolean as threshold and equal to as comparator.
        # Threshold bool == TRUE is defined in the colang file as the output of
        # `bot should intervene`
        if self.intervention:
            if not self.intervention.threshold:
                self.intervention.threshold = NEMO_THRESHOLD
            if not self.intervention.comparator:
                self.intervention.comparator = GuardOperatorType.EQUALS

        # Default LLM Type for NeMo is set to OpenAI
        self._llm_type = config.get("llm_type", GuardLLMType.OPENAI)
        self.openai_api_base = config.get("openai_api_base")
        self.openai_deployment_id = config.get("openai_deployment_id")
        llm_id = None
        credentials = None
        use_llm_gateway = use_llm_gateway_inference(self._llm_type)
        try:
            self.openai_api_key = self.get_openai_api_key(config, self._llm_type)
            if self._llm_type != GuardLLMType.NIM and self.openai_api_key is None:
                raise ValueError("OpenAI API key is required for NeMo Guardrails")

            if self.llm_type == GuardLLMType.OPENAI:
                credentials = {
                    "credential_type": "openai",
                    "api_key": self.openai_api_key,
                }
                os.environ["OPENAI_API_KEY"] = self.openai_api_key
                llm = None
            elif self.llm_type == GuardLLMType.AZURE_OPENAI:
                if self.openai_api_base is None:
                    raise ValueError("Azure OpenAI API base url is required for LLM Guard")
                if self.openai_deployment_id is None:
                    raise ValueError("Azure OpenAI deployment ID is required for LLM Guard")
                credentials = {
                    "credential_type": "azure_openai",
                    "api_base": self.openai_api_base,
                    "api_version": DEFAULT_OPEN_AI_API_VERSION,
                    "api_key": self.openai_api_key,
                }
                azure_openai_client = get_azure_openai_client(
                    openai_api_key=self.openai_api_key,
                    openai_api_base=self.openai_api_base,
                    openai_deployment_id=self.openai_deployment_id,
                )
                llm = azure_openai_client
            elif self.llm_type == GuardLLMType.GOOGLE:
                # llm_id = config["google_model"]
                raise NotImplementedError
            elif self.llm_type == GuardLLMType.AMAZON:
                # llm_id = config["aws_model"]
                raise NotImplementedError
            elif self.llm_type == GuardLLMType.DATAROBOT:
                raise NotImplementedError
            elif self.llm_type == GuardLLMType.LLM_GATEWAY:
                raise NotImplementedError
            elif self.llm_type == GuardLLMType.NIM:
                if config.get("deployment_id") is None:
                    if self.openai_api_base is None:
                        raise ValueError("NIM DataRobot deployment id is required for NIM LLM Type")
                    else:
                        logging.warning(
                            "Using 'openai_api_base' is being deprecated and will be removed "
                            "in the next release.  Please configure NIM DataRobot deployment "
                            "using deployment_id"
                        )
                        if self.openai_api_key is None:
                            raise ValueError("OpenAI API key is required for NeMo Guardrails")
                else:
                    self.deployment = dr.Deployment.get(self._deployment_id)
                    datarobot_endpoint, self.openai_api_key = get_datarobot_endpoint_and_token()
                    self.openai_api_base = (
                        f"{datarobot_endpoint}/deployments/{str(self._deployment_id)}"
                    )
                llm = get_chat_nvidia_llm(
                    api_key=self.openai_api_key,
                    base_url=self.openai_api_base,
                )
            else:
                raise ValueError(f"Invalid LLMType: {self.llm_type}")

        except Exception as e:
            # no valid user credentials provided, raise if not using LLM Gateway
            credentials = None
            if not use_llm_gateway:
                raise e

        if use_llm_gateway:
            # Currently only OPENAI and AZURE_OPENAI are supported by NeMoGuard
            # For Bedrock and Vertex the model in the config is actually the LLM ID
            # For OpenAI we use the default model defined in get_llm_gateway_client
            # For Azure we use the deployment ID
            llm = get_llm_gateway_client(
                llm_id=llm_id,
                openai_deployment_id=self.openai_deployment_id,
                credentials=credentials,
            )

        # Use guard stage to determine whether to read from prompt/response subdirectory
        # for nemo configurations.  "nemo_guardrails" folder is at same level of custom.py
        # So, the config path becomes model_dir + "nemo_guardrails"
        nemo_config_path = os.path.join(model_dir, NEMO_GUARDRAILS_DIR)
        self.nemo_rails_config_path = os.path.join(nemo_config_path, self.stage)
        nemo_rails_config = RailsConfig.from_path(config_path=self.nemo_rails_config_path)
        self._nemo_llm_rails = LLMRails(nemo_rails_config, llm=llm)

    def has_average_score_custom_metric(self) -> bool:
        """No average score metrics for NemoGuard's"""
        return False

    @property
    def nemo_llm_rails(self):
        return self._nemo_llm_rails
