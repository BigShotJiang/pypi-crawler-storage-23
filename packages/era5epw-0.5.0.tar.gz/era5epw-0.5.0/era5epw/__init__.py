# Logging initialization is now handled explicitly in main functions
