# Upstream Source

- **Repo:** https://github.com/RichardQZeng/polygon_centerline
- **Commit:** 04d228aa3a83ae6b8268ac44b68025848d41f5bf
- **Version:** 2025.3.0
- **Date:** 2026-02-22
- **License:** MIT (license file copied verbatim from upstream)
- **Notes:** Embedded without cli.py. One import changed to relative in _src.py.
