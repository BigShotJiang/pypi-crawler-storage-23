"""CLI package for BERATools."""
