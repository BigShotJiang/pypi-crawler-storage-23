label.h
=======

.. literalinclude:: ../../include/gdstk/label.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
