property.h
==========

.. literalinclude:: ../../include/gdstk/property.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
