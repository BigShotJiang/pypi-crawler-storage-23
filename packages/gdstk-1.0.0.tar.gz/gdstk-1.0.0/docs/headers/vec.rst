vec.h
=====

.. literalinclude:: ../../include/gdstk/vec.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
