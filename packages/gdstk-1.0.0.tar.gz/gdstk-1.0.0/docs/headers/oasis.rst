oasis.h
=======

.. literalinclude:: ../../include/gdstk/oasis.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
