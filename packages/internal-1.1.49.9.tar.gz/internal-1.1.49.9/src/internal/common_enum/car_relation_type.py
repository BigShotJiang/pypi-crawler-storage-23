from enum import Enum


class CarRelationTypeEnum(str, Enum):
    OWNER = "owner"
    DRIVER = "driver"
    BUYER = "buyer"
    CLIENT = "client"

    @property
    def display_name(self) -> str:
        return {
            CarRelationTypeEnum.OWNER: "擁有人",
            CarRelationTypeEnum.DRIVER: "使用人",
            CarRelationTypeEnum.BUYER: "購買人",
            CarRelationTypeEnum.CLIENT: "聯絡人",
        }[self]