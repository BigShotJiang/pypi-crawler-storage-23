from enum import Enum


class PointTypeEnum(str, Enum):
    INVOICE_REWARD = "invoice_reward"
    ACTIVITY = "activity"
