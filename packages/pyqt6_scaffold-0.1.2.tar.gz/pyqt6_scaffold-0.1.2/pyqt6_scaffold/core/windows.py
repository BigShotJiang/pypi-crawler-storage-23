# SPDX-License-Identifier: LGPL-3.0-or-later

from PyQt6.QtWidgets import QMainWindow

class BaseWindow(QMainWindow):
    """
    Base class for all application windows.

    Provides a structured initialization sequence through four
    template methods that subclasses should override as needed.
    The composer and database are available via self._composer
    and self._db respectively.

    _define_widgets:  Create and initialize all widgets.
    _tune_layouts:    Arrange widgets into layouts.
    _connect_slots:   Connect signals to slots.
    _apply_windows_settings: Set window title, size, icons, and other properties.
    """
    def __init__(self, composer, db):
        super().__init__()
        self._db = db
        self._composer = composer

        self._define_widgets()
        self._tune_layouts()
        self._connect_slots()
        self._apply_windows_settings()

    def _define_widgets(self): pass
    def _tune_layouts(self): pass
    def _connect_slots(self): pass
    def _apply_windows_settings(self): pass