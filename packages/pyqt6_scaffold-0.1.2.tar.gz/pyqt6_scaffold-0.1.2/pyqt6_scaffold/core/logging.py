# SPDX-License-Identifier: LGPL-3.0-or-later

import logging

def setup_logger(name: str = "scaffold"):
    """
    Create and configure a logger with console output.

    Returns an existing logger if one with the given name
    already exists to avoid duplicate handlers.

    Args:
        name: Logger name, typically __name__.

    Returns:
        Configured logging.Logger instance.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        fmt="[%(asctime)s] %(levelname)-8s %(name)s: %(message)s",
        datefmt="%H:%M:%S"
    )

    console = logging.StreamHandler()
    console.setFormatter(formatter)

    logger.addHandler(console)
    return logger