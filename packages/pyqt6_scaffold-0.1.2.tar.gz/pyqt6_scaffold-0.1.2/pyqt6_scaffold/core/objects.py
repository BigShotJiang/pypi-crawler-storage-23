# SPDX-License-Identifier: LGPL-3.0-or-later

from typing import Any, Dict
from dataclasses import dataclass, field

@dataclass
class BaseUser:
    """
    Minimal user representation.

    id and role are typed as Any to support different
    authentication schemes (integer PK, UUID, custom role objects).
    """
    id: Any
    name: str
    role: Any

@dataclass
class NavigationContext:
    """
    Container for data passed between windows during navigation.
    """
    data: Dict[str, Any] = field(default_factory=dict)

@dataclass
class NavigateRequest:
    """
    Navigation event emitted by windows to request a screen transition.

    Attributes:
        target: Registered name of the destination window.
        context: Data to pass to the destination window.
    """
    target: str
    context: NavigationContext