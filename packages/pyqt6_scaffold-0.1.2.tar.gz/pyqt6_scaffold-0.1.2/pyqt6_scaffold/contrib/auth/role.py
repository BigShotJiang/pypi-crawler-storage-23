# SPDX-License-Identifier: LGPL-3.0-or-later

from enum import Enum
from dataclasses import dataclass

@dataclass
class Role:
    """
    Represents a user role with a hierarchical access level.

    Attributes:
        name: Human-readable role name.
        level: Numeric access level used for permission checks.
    """
    name: str
    level: int

class RoleLevel(Enum):
    """
    Predefined access levels for common roles.

    Use these constants when populating the permission table
    or comparing role levels in application logic.
    """
    GUEST = 0
    CLIENT = 25
    EMPLOYEE = 50
    MANAGER = 75
    ADMIN = 100