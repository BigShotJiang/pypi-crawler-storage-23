# SPDX-License-Identifier: LGPL-3.0-or-later

from pyqt6_scaffold.core.objects import BaseUser

class RBACMixin:
    """
    Role-Based Access Control mixin for AbstractDatabase subclasses.

    Provides a can() method that checks user permissions against
    a permission table in the database. Table and column names
    are configurable as class attributes.

    Expected table schema:
        permission_table (permission_column, level_column)

    Example:
        permission_map (perm VARCHAR, min_level INT)
    """
    permission_table: str = "permission_map"
    permission_column: str = "perm"
    level_column: str = "min_level"

    def can(self, user: BaseUser, permission: str) -> bool:
        """
        Check whether a user has the required permission level.

        Args:
            user: A BaseUser instance with a role.level attribute.
            permission: Permission identifier to look up in the database.

        Returns:
            True if user.role.level >= required level, False otherwise.
        """
        with self.execute(
            f"""
            SELECT {self.level_column}
            FROM {self.permission_table}
            WHERE {self.permission_column} = {self.placeholder}
            """,
            (permission,)
        ) as cursor:
            row = cursor.fetchone()
        if not row:
            return False
        return user.role.level >= row[0]