from lqs.client.admin.admin import Admin
