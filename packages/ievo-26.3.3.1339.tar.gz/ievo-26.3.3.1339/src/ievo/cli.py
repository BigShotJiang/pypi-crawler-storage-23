"""iEvo CLI — main entry point.

All PRs are reviewed by Eva before merging.
Evolutions are published to ievo.ai and Telegram.
"""

import typer

from ievo.commands import (
    add,
    config_cmd,
    deps,
    dev,
    init,
    learn,
    list_cmd,
    orchestrate,
    remove,
    run,
    team,
    update,
)

app = typer.Typer(
    name="ievo",
    help="Self-evolving AI agent framework.",
    no_args_is_help=False,
    invoke_without_command=True,
    rich_markup_mode="rich",
)

# ── Active commands ───────────────────────────────────────────
app.add_typer(config_cmd.app, name="config", help="Manage settings and credentials.")
app.command(name="update", help="Update ievo to the latest version.")(update.update)

# ── Deprecated commands ──────────────────────────────────────
app.command(name="init", help="[dim][DEPRECATED][/dim] Create project. Run 'ievo' instead.")(
    init.init
)
app.command(name="add", help="[dim][DEPRECATED][/dim] Install agent — managed by HR agent.")(
    add.add
)
app.command(name="remove", help="[dim][DEPRECATED][/dim] Remove agent — managed by HR agent.")(
    remove.remove
)
app.command(name="list", help="[dim][DEPRECATED][/dim] Show agents — use TUI dashboard.")(
    list_cmd.list_agents
)
app.command(name="run", help="[dim][DEPRECATED][/dim] Start agent session — use TUI.")(run.run)
app.command(name="team", help="[dim][DEPRECATED][/dim] Agent Teams — removed.")(team.team)
app.command(name="orchestrate", help="[dim][DEPRECATED][/dim] Automated loop — internal.")(
    orchestrate.orchestrate
)
app.add_typer(deps.app, name="deps", help="[dim][DEPRECATED][/dim] Agent dependencies.")
app.add_typer(learn.app, name="learn", help="[dim][DEPRECATED][/dim] Self-evolution — removed.")
app.add_typer(dev.app, name="dev", help="[dim][DEPRECATED][/dim] Agent development.")


def version_callback(value: bool) -> None:
    if value:
        from ievo import __version__

        typer.echo(f"ievo {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """iEvo — self-evolving AI agent framework.

    Install agents like packages. They learn from every mistake.
    """
    if ctx.invoked_subcommand is None:
        from ievo.core.config import ensure_home, find_project_root
        from ievo.core.startup import ensure_startup

        home = ensure_home()
        ensure_startup(home)

        if find_project_root() is None:
            if not typer.confirm("No iEvo project found. Initialize here?", default=True):
                from ievo.utils.console import info

                info("Run [bold]ievo[/bold] again when ready to initialize.")
                raise typer.Exit(0)
            init.init(name=".")

        from ievo.tui.app import run_tui

        run_tui()
