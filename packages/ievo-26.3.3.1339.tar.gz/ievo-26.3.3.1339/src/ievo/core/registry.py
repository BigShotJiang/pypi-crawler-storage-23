"""Marketplace registry operations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import httpx
import yaml

from ievo.core.config import CACHE_DIR, MARKETPLACE_RAW, REGISTRY_URL, ensure_home


@dataclass
class RegistryEntry:
    """A single agent entry from registry.yaml."""

    name: str
    version: str
    description: str
    model: str
    dependencies: list[str]
    category: str = "core"
    file: str = ""
    mandatory: bool = False


class Registry:
    """Interface to the ievo-marketplace registry."""

    def __init__(self, entries: dict[str, RegistryEntry] | None = None) -> None:
        self._entries = entries or {}

    @classmethod
    def _parse_registry_data(cls, data: dict) -> dict[str, RegistryEntry]:
        """Parse raw YAML data into RegistryEntry dict."""
        entries: dict[str, RegistryEntry] = {}
        for agent in data.get("agents", []):
            entries[agent["name"]] = RegistryEntry(
                name=agent["name"],
                version=agent.get("version", "0.1.0"),
                description=agent.get("description", ""),
                model=agent.get("model", "sonnet"),
                dependencies=agent.get("dependencies", []),
                category=agent.get("category", "core"),
                file=agent.get("file", ""),
                mandatory=agent.get("mandatory", False),
            )
        return entries

    @classmethod
    def _parse_registry_file(cls, path: Path) -> Registry:
        """Parse a registry YAML file into a Registry instance."""
        data = yaml.safe_load(path.read_text()) or {}
        return cls(cls._parse_registry_data(data))

    @classmethod
    def load_cached(cls) -> Registry:
        """Load from local cache, falling back to bundled registry.

        Priority: cache file (may be newer from fetch) -> bundled -> empty.
        """
        ensure_home()
        cache_path = CACHE_DIR / "registry.yaml"
        if cache_path.exists():
            return cls._parse_registry_file(cache_path)

        # Fallback to bundled registry
        from ievo.marketplace import bundled_registry_path

        bundled_path = bundled_registry_path()
        if bundled_path.exists():
            return cls._parse_registry_file(bundled_path)

        return cls()

    async def fetch(self) -> None:
        """Download fresh registry from marketplace."""
        ensure_home()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(REGISTRY_URL, timeout=15)
                resp.raise_for_status()
                (CACHE_DIR / "registry.yaml").write_text(resp.text)
                data = yaml.safe_load(resp.text) or {}
                self._entries = self._parse_registry_data(data)
        except httpx.HTTPError:
            pass  # Fallback to cached

    def get(self, name: str) -> RegistryEntry | None:
        return self._entries.get(name)

    def list_all(self) -> list[RegistryEntry]:
        return list(self._entries.values())

    def agent_download_url(self, name: str) -> str:
        """URL to download agent package tarball."""
        return f"{MARKETPLACE_RAW}/agents/{name}"

    async def download_agent_md(self, name: str, dest_dir: Path) -> bool:
        """Download a single agent ``.md`` file from the marketplace.

        Uses the ``file`` field from the registry entry to construct the URL.
        Falls back to ``agents/{name}.md`` if the field is empty.

        Returns True on success, False on any error.
        """
        entry = self.get(name)
        if not entry:
            return False

        file_path = entry.file or f"agents/{name}.md"
        url = f"{MARKETPLACE_RAW}/{file_path}"

        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(url)
                if resp.status_code != 200:
                    return False
                dest_dir.mkdir(parents=True, exist_ok=True)
                (dest_dir / f"{name}.md").write_text(resp.text)
                return True
        except httpx.HTTPError:
            return False

    async def download_agent(self, name: str, dest: Path) -> bool:
        """Download agent files from marketplace to local dir.

        Uses GitHub Contents API to discover all files dynamically,
        then downloads each one via its raw URL.
        """
        entry = self.get(name)
        if not entry:
            return False

        dest.mkdir(parents=True, exist_ok=True)
        api_base = f"https://api.github.com/repos/ievo-ai/marketplace/contents/agents/{name}"

        async with httpx.AsyncClient(timeout=15) as client:
            files = await self._list_files_recursive(client, api_base)
            if not files:
                return False

            for rel_path, download_url in files:
                try:
                    resp = await client.get(download_url)
                    if resp.status_code == 200:
                        file_dest = dest / rel_path
                        file_dest.parent.mkdir(parents=True, exist_ok=True)
                        file_dest.write_text(resp.text)
                except httpx.HTTPError:
                    pass

        return True

    @staticmethod
    async def _list_files_recursive(
        client: httpx.AsyncClient,  # noqa: F821
        api_url: str,
    ) -> list[tuple[str, str]]:
        """List all files under a GitHub directory via Contents API.

        Returns list of (relative_path, download_url) tuples.
        """
        result: list[tuple[str, str]] = []
        try:
            resp = await client.get(api_url)
            if resp.status_code != 200:
                return result
            items = resp.json()
            if not isinstance(items, list):
                return result
            for item in items:
                if item["type"] == "file":
                    # path from API is "agents/name/file" — extract relative part
                    parts = item["path"].split("/", 2)
                    rel = parts[2] if len(parts) > 2 else item["name"]
                    result.append((rel, item["download_url"]))
                elif item["type"] == "dir":
                    sub = await Registry._list_files_recursive(client, item["url"])
                    result.extend(sub)
        except Exception:
            pass
        return result
