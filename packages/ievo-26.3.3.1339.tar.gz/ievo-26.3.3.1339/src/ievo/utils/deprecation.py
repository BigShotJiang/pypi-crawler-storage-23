"""Deprecation warning utilities for CLI commands."""

from __future__ import annotations

from ievo.utils.console import warn


def deprecated_command(name: str, alternative: str | None = None) -> None:
    """Print a deprecation warning for a CLI command."""
    msg = f"[bold]{name}[/bold] is deprecated and will be removed in a future release."
    if alternative:
        msg += f" Use {alternative} instead."
    warn(msg)
