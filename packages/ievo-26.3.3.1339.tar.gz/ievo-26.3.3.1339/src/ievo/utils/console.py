"""Rich console helpers for consistent terminal output."""

from rich.console import Console
from rich.theme import Theme

ievo_theme = Theme(
    {
        "success": "green",
        "error": "red",
        "warn": "yellow",
        "info": "cyan",
        "dim": "dim",
        "agent": "magenta",
        "version": "dim cyan",
    }
)

console = Console(theme=ievo_theme)


def success(msg: str) -> None:
    console.print(f"[success]✓[/success] {msg}")


def error(msg: str) -> None:
    console.print(f"[error]✗[/error] {msg}")


def warn(msg: str) -> None:
    console.print(f"[warn]![/warn] {msg}")


def info(msg: str) -> None:
    console.print(f"[info]⚡[/info] {msg}")


def step(msg: str) -> None:
    console.print(f"  [dim]→[/dim] {msg}")
