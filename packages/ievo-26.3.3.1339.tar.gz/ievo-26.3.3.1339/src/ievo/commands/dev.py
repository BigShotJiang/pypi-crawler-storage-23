"""ievo dev — agent development commands."""

from __future__ import annotations

import typer

from ievo.utils.console import info, warn

app = typer.Typer(no_args_is_help=True)


@app.command(name="new")
def new(
    name: str = typer.Argument(help="Name for the new agent."),
) -> None:
    """[DEPRECATED] Scaffold a new agent from the SDK template."""
    from ievo.utils.deprecation import deprecated_command

    deprecated_command("ievo dev new")
    warn("Dev SDK not yet available. Creating local agent scaffold...")

    from pathlib import Path

    from ievo.commands.add import _create_placeholder_agent

    dest = Path.cwd() / name / f"{name}.md"
    dest.parent.mkdir(parents=True, exist_ok=True)
    _create_placeholder_agent(dest, name)
    info(f"Created agent scaffold at [bold]{dest}[/bold]")
    info("Edit the .md file to define agent behavior.")


@app.command(name="test")
def test(
    agent: str = typer.Argument(help="Agent name to test."),
) -> None:
    """[DEPRECATED] Run evaluation tests for an agent (Phase 2+)."""
    from ievo.utils.deprecation import deprecated_command

    deprecated_command("ievo dev test")
    warn("Agent eval suite not yet implemented (Phase 2).")
    info(f"Will run evals for [bold]{agent}[/bold] when ready.")


@app.command(name="publish")
def publish(
    agent: str = typer.Argument(help="Agent name to publish."),
) -> None:
    """[DEPRECATED] Publish agent to the marketplace (Phase 2+)."""
    from ievo.utils.deprecation import deprecated_command

    deprecated_command("ievo dev publish")
    warn("Publishing not yet implemented (Phase 2).")
    info(f"Will publish [bold]{agent}[/bold] to ievo-marketplace when ready.")
