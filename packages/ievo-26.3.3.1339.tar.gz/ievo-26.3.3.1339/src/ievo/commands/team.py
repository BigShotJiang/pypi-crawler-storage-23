"""ievo team — run Agent Teams with multiple agents."""

from __future__ import annotations

import typer

from ievo.utils.console import info, warn


def team(
    agents: list[str] = typer.Argument(help="Agent names to run as a team."),
) -> None:
    """[DEPRECATED] Run multiple agents as an Agent Team."""
    from ievo.utils.deprecation import deprecated_command

    deprecated_command("ievo team")
    warn("Agent Teams are not yet implemented (Phase 2).")
    info(f"Planned team: {', '.join(agents)}")
