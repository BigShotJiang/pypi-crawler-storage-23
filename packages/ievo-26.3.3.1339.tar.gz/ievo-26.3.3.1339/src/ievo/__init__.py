"""iEvo — Self-evolving AI agent framework."""

from ievo.version import __version__

__all__ = ["__version__"]
