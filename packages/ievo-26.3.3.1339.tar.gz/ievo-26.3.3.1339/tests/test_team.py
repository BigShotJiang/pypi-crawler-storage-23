"""Tests for ievo team command."""

from __future__ import annotations

from ievo.commands.team import team


def test_team_warns_not_implemented() -> None:
    # Should not raise, just print warnings
    team(agents=["spec-writer", "coder"])


def test_team_single_agent() -> None:
    team(agents=["spec-writer"])


def test_team_shows_deprecation_warning() -> None:
    from unittest.mock import patch

    with patch("ievo.utils.deprecation.warn") as mock_warn:
        team(agents=["spec-writer"])

    mock_warn.assert_called_once()
    assert "deprecated" in mock_warn.call_args[0][0]
