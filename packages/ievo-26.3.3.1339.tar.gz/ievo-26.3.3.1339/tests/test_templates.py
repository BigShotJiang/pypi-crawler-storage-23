"""Tests for init_templates and bundled marketplace templates."""

from __future__ import annotations

from ievo.commands.init_templates import (
    ARCHITECT_WORKFLOW,
    CLAUDE_MD,
    CODER_AGENT_WORKFLOW,
    GITIGNORE,
    ISSUE_TEMPLATE_CHANGE,
    ISSUE_TEMPLATE_FEATURE,
    PRIORITY_MD,
    SPEC_INDEX_MD,
    SPEC_WRITER_WORKFLOW,
)
from ievo.marketplace import bundled_template_path


def test_priority_md_has_formula() -> None:
    assert "score =" in PRIORITY_MD
    assert "priority_weight" in PRIORITY_MD
    assert "dependency_satisfaction" in PRIORITY_MD
    assert "blocking_count" in PRIORITY_MD
    assert "open_questions" in PRIORITY_MD


def test_priority_md_has_example() -> None:
    assert "REQ-001" in PRIORITY_MD
    assert "REQ-002" in PRIORITY_MD


def test_spec_index_has_status_legend() -> None:
    assert "Status Legend" in SPEC_INDEX_MD
    assert "draft" in SPEC_INDEX_MD
    assert "ready" in SPEC_INDEX_MD
    assert "implemented" in SPEC_INDEX_MD
    assert "blocked" in SPEC_INDEX_MD


def test_spec_index_has_dependency_rules() -> None:
    assert "Dependency Rules" in SPEC_INDEX_MD


def test_spec_writer_workflow_valid() -> None:
    assert "name: Spec Writer" in SPEC_WRITER_WORKFLOW
    assert "ANTHROPIC_API_KEY" in SPEC_WRITER_WORKFLOW
    assert "claude -p" in SPEC_WRITER_WORKFLOW


def test_coder_agent_workflow_valid() -> None:
    assert "name: Coder Agent" in CODER_AGENT_WORKFLOW
    assert "ANTHROPIC_API_KEY" in CODER_AGENT_WORKFLOW
    assert "ready" in CODER_AGENT_WORKFLOW


def test_issue_template_feature() -> None:
    assert "Feature" in ISSUE_TEMPLATE_FEATURE
    assert "labels: feature" in ISSUE_TEMPLATE_FEATURE


def test_issue_template_change() -> None:
    assert "Change" in ISSUE_TEMPLATE_CHANGE
    assert "labels: change" in ISSUE_TEMPLATE_CHANGE


def test_architect_workflow_valid() -> None:
    assert "name: Architect Agent" in ARCHITECT_WORKFLOW
    assert "ANTHROPIC_API_KEY" in ARCHITECT_WORKFLOW
    assert "plans/" in ARCHITECT_WORKFLOW


def test_gitignore_non_empty() -> None:
    assert ".env" in GITIGNORE
    assert "__pycache__" in GITIGNORE
    assert len(GITIGNORE.strip()) > 50


def test_claude_md_has_sections() -> None:
    assert "Tech stack" in CLAUDE_MD
    assert "Conventions" in CLAUDE_MD
    assert "{project_name}" in CLAUDE_MD
    assert "What this project is" in CLAUDE_MD
    assert "What NOT to do" in CLAUDE_MD


def test_all_templates_non_empty() -> None:
    for name, template in [
        ("PRIORITY_MD", PRIORITY_MD),
        ("SPEC_INDEX_MD", SPEC_INDEX_MD),
        ("SPEC_WRITER_WORKFLOW", SPEC_WRITER_WORKFLOW),
        ("CODER_AGENT_WORKFLOW", CODER_AGENT_WORKFLOW),
        ("ISSUE_TEMPLATE_FEATURE", ISSUE_TEMPLATE_FEATURE),
        ("ISSUE_TEMPLATE_CHANGE", ISSUE_TEMPLATE_CHANGE),
        ("ARCHITECT_WORKFLOW", ARCHITECT_WORKFLOW),
        ("CLAUDE_MD", CLAUDE_MD),
        ("GITIGNORE", GITIGNORE),
    ]:
        assert len(template.strip()) > 50, f"{name} is too short"


# ── Bundled marketplace template validation ──────────────────


def test_bundled_req_template_has_sections() -> None:
    """Bundled REQ_TEMPLATE.md has expected sections."""
    path = bundled_template_path("REQ_TEMPLATE.md")
    assert path is not None
    content = path.read_text()
    assert "Acceptance Criteria" in content
    assert "Metadata" in content


def test_bundled_cr_template_has_sections() -> None:
    """Bundled CHANGE_REQUEST_TEMPLATE.md has expected sections."""
    path = bundled_template_path("CHANGE_REQUEST_TEMPLATE.md")
    assert path is not None
    content = path.read_text()
    assert "What Changes" in content


def test_bundled_templates_removed_from_init_templates() -> None:
    """SPEC_REQ_TEMPLATE and SPEC_CR_TEMPLATE no longer in init_templates."""
    import ievo.commands.init_templates as tpl

    assert not hasattr(tpl, "SPEC_REQ_TEMPLATE")
    assert not hasattr(tpl, "SPEC_CR_TEMPLATE")
