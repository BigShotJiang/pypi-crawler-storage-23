"""Tests for ievo dev subcommands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from ievo.commands.dev import new, publish, test


def test_dev_new_creates_agent(tmp_path: Path) -> None:
    with patch("pathlib.Path.cwd", return_value=tmp_path):
        new(name="my-agent")
        dest = tmp_path / "my-agent" / "my-agent.md"
        assert dest.exists()
        content = dest.read_text()
        assert "my-agent" in content


def test_dev_test_stub() -> None:
    # Phase 2 stub — should not raise
    test(agent="spec-writer")


def test_dev_publish_stub() -> None:
    # Phase 2 stub — should not raise
    publish(agent="spec-writer")


def test_dev_new_shows_deprecation_warning(tmp_path: Path) -> None:
    with (
        patch("pathlib.Path.cwd", return_value=tmp_path),
        patch("ievo.utils.deprecation.warn") as mock_warn,
    ):
        new(name="my-agent")

    mock_warn.assert_called_once()
    assert "deprecated" in mock_warn.call_args[0][0]


def test_dev_test_shows_deprecation_warning() -> None:
    with patch("ievo.utils.deprecation.warn") as mock_warn:
        test(agent="spec-writer")

    mock_warn.assert_called_once()
    assert "deprecated" in mock_warn.call_args[0][0]


def test_dev_publish_shows_deprecation_warning() -> None:
    with patch("ievo.utils.deprecation.warn") as mock_warn:
        publish(agent="spec-writer")

    mock_warn.assert_called_once()
    assert "deprecated" in mock_warn.call_args[0][0]
