"""Tests for deprecation warning utility."""

from __future__ import annotations

from unittest.mock import patch

from ievo.utils.deprecation import deprecated_command


class TestDeprecatedCommand:
    def test_with_alternative(self) -> None:
        with patch("ievo.utils.deprecation.warn") as mock_warn:
            deprecated_command("ievo add", alternative="the HR agent")
            mock_warn.assert_called_once()
            msg = mock_warn.call_args[0][0]
            assert "ievo add" in msg
            assert "deprecated" in msg
            assert "HR agent" in msg

    def test_without_alternative(self) -> None:
        with patch("ievo.utils.deprecation.warn") as mock_warn:
            deprecated_command("ievo learn")
            mock_warn.assert_called_once()
            msg = mock_warn.call_args[0][0]
            assert "ievo learn" in msg
            assert "deprecated" in msg
            assert "instead" not in msg

    def test_message_mentions_future_removal(self) -> None:
        with patch("ievo.utils.deprecation.warn") as mock_warn:
            deprecated_command("ievo run")
            msg = mock_warn.call_args[0][0]
            assert "removed in a future release" in msg
