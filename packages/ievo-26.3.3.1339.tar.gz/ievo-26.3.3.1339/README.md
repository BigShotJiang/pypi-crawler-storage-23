```
 ██╗ ███████╗██╗   ██╗ ██████╗
 ╚═╝ ██╔════╝██║   ██║██╔═══██╗
 ██╗ █████╗  ██║   ██║██║   ██║
 ██║ ██╔══╝  ╚██╗ ██╔╝██║   ██║
 ██║ ███████╗ ╚████╔╝ ╚██████╔╝
 ╚═╝ ╚══════╝  ╚═══╝   ╚═════╝
```

# iEvo CLI

Self-evolving AI agent framework. Install agents like packages — they learn from every mistake.

## Install

```bash
# Recommended — run without install
uvx ievo --help

# Or install globally
uv tool install ievo

# Or with pip
pip install ievo
```

## Quick start

```bash
# Launch the TUI dashboard (auto-initializes project on first run)
ievo
```

All 12 agents are bundled in the package — no network required for setup.

## Development

```bash
git clone https://github.com/ievo-ai/cli.git
cd cli
uv sync

# Always use `uv run` — it runs your local code, not the globally installed version
uv run ievo --help
uv run ievo              # launch TUI from local source
uv run pytest --cov      # run tests

# Or install globally as editable (links to your local source)
uv tool install --editable .
```

## Docker sandbox

Agents run in isolated Docker containers by default — each with its own set of allowed tools.

```bash
# Build the sandbox image (first time)
docker build -t ievoai/sandbox:latest sandbox/

# Agents use Docker automatically
ievo run spec-writer -m "Build auth module"

# Skip Docker, run locally
ievo run spec-writer --local -m "Quick test"
```

Auto-fallback: if Docker is not available, agents run locally via Claude CLI.

## Commands

The primary interface is the **TUI dashboard** (`ievo` without args). CLI commands are available but deprecated:

| Command | Description |
|---------|-------------|
| `ievo` | Launch TUI dashboard (recommended) |
| `ievo update --self` | Update iEvo CLI to latest version |
| `ievo config` | View/set configuration |
| `ievo init` | Create a new project (deprecated — TUI auto-inits) |
| `ievo add <agent>` | Install agent (deprecated — use HR agent) |
| `ievo remove <agent>` | Remove an agent (deprecated — use HR agent) |
| `ievo list` | Show installed agents (deprecated — use TUI) |
| `ievo run <agent>` | Start agent session (deprecated) |

## Links

- [ievo.ai](https://ievo.ai)
- [Marketplace](https://github.com/ievo-ai/marketplace)
- [GitHub](https://github.com/ievo-ai)
