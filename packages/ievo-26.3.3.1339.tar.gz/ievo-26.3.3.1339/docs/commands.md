# CLI Command Reference

## Active Commands

### `ievo`

Launch the TUI dashboard — the primary entry point. On first run:

1. Checks Claude auth (prompts login if needed)
2. Checks telemetry opt-in (first run only)
3. If no project found: asks "Initialize here?" with confirmation
4. Opens interactive TUI dashboard (agents, pipeline, evolution, files)

```bash
ievo          # Launch TUI dashboard
ievo -v       # Show version
```

### `ievo config set/get/list/delete <key> [value]`

Manage global settings and encrypted credentials.

```bash
ievo config set ANTHROPIC_API_KEY sk-...   # Encrypted automatically
ievo config set default_model sonnet       # Plaintext config
ievo config get default_model
ievo config list                           # Show all keys
ievo config delete custom_key
```

Sensitive keys (API keys, tokens) are encrypted with RSA + AES-256-GCM.

### `ievo update`

Self-update ievo to the latest version from PyPI.

```bash
ievo update   # Check for updates and upgrade in-place
```

Behavior depends on how ievo was installed:

| Installer | Action |
|-----------|--------|
| `uv tool install ievo` | Runs `uv tool upgrade ievo` |
| `pip install ievo` | Runs `pip install --upgrade ievo` |
| `uvx ievo` | Informational message (uvx auto-fetches latest) |

On every startup, ievo also checks for a newer version (cached for 24 hours) and prints a notification if an update is available.

---

## Deprecated Commands

> These commands still work but print a deprecation warning.
> They will be removed in a future release.

### `ievo init [name]` — use `ievo` instead

Project initialization is now automatic when you run `ievo` in an uninitialized directory. The CLI will ask for confirmation before proceeding.

### `ievo add <agents...>` — managed by HR agent

Agent composition is now handled automatically by the HR agent (Claude Code subagent). The internal API `add_agents()` is available for programmatic use.

### `ievo remove <agent>` — managed by HR agent

### `ievo list [--marketplace]` — use TUI dashboard

Agent overview is visible in the TUI Agents tab.

### `ievo run <agent>` — use TUI dashboard

Agent sessions are launched from the TUI dashboard, not manually.

### `ievo orchestrate` — internal pipeline

The orchestration loop runs internally, not as a user-facing command.

### `ievo learn log/push/status` — removed

Evolution tracking is automatic and visible through the TUI Evolution tab.

### `ievo deps check/install/status` — removed

Dependency management is handled automatically during agent installation.

### `ievo dev new/test/publish` — removed

### `ievo team <agents...>` — removed
