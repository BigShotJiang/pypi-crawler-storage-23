"""
Parsers específicos para lojas de e-commerce.

Implementações concretas da interface StoresParserInterface para
diferentes lojas (Nike, Maze Shop, Beleza na Web, etc).
"""

import logging
import json
import html
from typing import Optional
from notify_utils.models import Product, ResponseData
from notify_utils.parsers.stores_parser_interface import StoresParserInterface
from notify_utils.parser import parse_price

logger = logging.getLogger(__name__)


class ParserError(Exception):
    """
    Exceção customizada para erros de parsing.

    Levantada quando:
    - Formato de dados inválido
    - Parser não suporta o tipo de dados (JSON/HTML)
    - Dados obrigatórios estão ausentes
    """
    pass

class NikeAPIGatewayJSONParser(StoresParserInterface):
    """
    Parser para API Gateway da Nike.

    Extrai produtos de respostas JSON da API Gateway da Nike.

    Exemplo:
        >>> parser = NikeAPIGatewayJSONParser()
        >>> products = parser.from_json(nike_api_response)
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Nike de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API Gateway da Nike

        Returns:
            Lista de objetos Product extraídos (implementação pendente)

        Note:
            Implementação ainda não finalizada - retorna lista vazia
        """
        # TODO: Implementar lógica de parsing para Nike API Gateway
        logger.warning("NikeAPIGatewayJSONParser.from_json() não implementado ainda")
        return []

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Nike API Gateway.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Nike API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for Nike API Gateway.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.
        Args:
            response: Objeto ResponseData contendo status e dados da resposta
        Returns:
            bool: True se for a última página, False caso contrário
        Raises:
            NotImplementedError: Se o método não for implementado
        """
        raise NotImplementedError("Pagination check is not implemented for Nike API Gateway yet.")


class MazeAPIJSONParser(StoresParserInterface):
    """
    Parser para API da Maze Shop.

    Extrai produtos de respostas JSON da API da Maze Shop, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual e promocional)
    - Estoque e disponibilidade
    - URLs (produto e imagem)
    - SKU

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Exemplo:
        >>> parser = MazeAPIJSONParser()
        >>> products = parser.from_json(maze_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Maze Shop de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da Maze Shop
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "idProduct": "123",
                                  "name": "Nome Produto",
                                  "price": 129.90,
                                  "pricePromotion": 99.90,
                                  "stock": 10,
                                  "urlFriendly": "produto-slug",
                                  "imageHome": "//cdn.maze.com.br/img.jpg",
                                  "code": "SKU123"
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'products' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se pricePromotion existe, é usado como current_price
            - Caso contrário, price é usado como current_price
            - URLs são automaticamente formatadas com prefixo da loja
        """
        products: list[Product] = []
        logger.debug("Parsing Maze Shop products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        for product_json in products_json:
            # Extrai preços com fallback seguro
            price_promotion = product_json.get("pricePromotion")
            price = product_json.get("price")
            available = product_json.get("stock", 0) > 0

            # Converte para float, tratando None e valores inválidos
            try:
                if price_promotion and float(price_promotion) > 0:
                    current_price = float(price_promotion)
                    old_price = float(price) if price else 0.0
                else:
                    current_price = float(price) if price else 0.0
                    old_price = 0.0  # Sem promoção: não há preço antigo diferente
            except (ValueError, TypeError):
                logger.warning(f"Preço inválido para produto {product_json.get('idProduct')}, pulando.")
                continue

            # Valida se o preço atual é válido (> 0)
            if current_price <= 0:
                logger.debug(f"Produto {product_json.get('idProduct')} tem preço atual inválido (R$ {current_price}), pulando.")
                continue

            url_friendly = product_json.get('urlFriendly', '') or ''
            image_home = product_json.get("imageHome", "") or ''

            product = Product(
                product_id=str(product_json.get("idProduct", "")),
                name=product_json.get("name", None),
                current_price_float=current_price,
                old_price_float=old_price,
                url=f"https://www.maze.com.br/{url_friendly}" if url_friendly else "",
                image_url=f"https:{image_home}" if image_home else "",
                sku=product_json.get("code", None),
                available=available,
                marketplace_name="Maze Shop",
                seller="Maze Shop"
            )

            products.append(product)
        return products

    def from_html(self, html_data: str) -> list[Product]:
        raise ParserError("HTML parsing is not supported for Maze API.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        if not response.is_json():
            logger.warning("Response is not JSON, cannot determine pagination.")
            return True
        
        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True
        

        json_data = response.to_json()
        if json_data is None:
            logger.warning("Falha ao parsear JSON da resposta, assumindo última página.")
            return True

        products = json_data.get("products", [])
        if not products:
            logger.info("No products found in response, assuming no more pages.")
            return True

        return False  # Assume there may be more pages if products are present


class SephoraAPIJSONParser(StoresParserInterface):
    """
    Parser para API Linx Impulse da Sephora Brasil.

    Extrai produtos de respostas JSON da API da Sephora (Linx Impulse),
    expandindo SKUs (variações de tamanho) em produtos individuais.

    Características:
    - Expande SKUs: 1 produto com N variações → N produtos únicos
    - Cada SKU vira um Product separado (ex: 36 produtos → 105 SKUs)
    - Nome combinado: "{nome_produto} - {tamanho}"
    - Validações: preço > 0, status == "AVAILABLE"

    Estrutura JSON esperada:
    ```json
    {
      "products": [
        {
          "id": "33990494",
          "name": "Perfume Carolina Herrera Good Girl Blush...",
          "brand": "CAROLINA HERRERA",
          "url": "/perfume-...",
          "skus": [
            {
              "sku": "657444",
              "specs": { "size": "30 ml" },
              "properties": {
                "price": 453.43,
                "oldPrice": 529,
                "url": "/perfume-...-657444.html",
                "status": "AVAILABLE",
                "images": { "default": "//www.sephora..." }
              }
            }
          ]
        }
      ]
    }
    ```

    Exemplo:
        >>> parser = SephoraAPIJSONParser()
        >>> products = parser.from_json(sephora_response)
        >>> print(f"Extraídos {len(products)} SKUs únicos")
        Extraídos 105 SKUs únicos
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Sephora de dados JSON, expandindo SKUs.

        Args:
            json_data: Dicionário contendo resposta JSON da API Sephora
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "id": "33990494",
                                  "name": "Perfume X",
                                  "brand": "Marca Y",
                                  "url": "/produto",
                                  "skus": [
                                      {
                                          "sku": "657444",
                                          "specs": {"size": "30 ml"},
                                          "properties": {
                                              "price": 453.43,
                                              "oldPrice": 529,
                                              "url": "/produto-657444.html",
                                              "status": "AVAILABLE",
                                              "images": {"default": "//..."}
                                          }
                                      }
                                  ]
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product expandidos (1 por SKU).
            Lista vazia se não houver produtos ou campo 'products' não existir.

        Note:
            - **Expande SKUs**: Cada SKU vira um Product individual
            - SKUs com `status != "AVAILABLE"` são ignorados
            - SKUs com `price <= 0` ou `None` são ignorados
            - Nome combinado: "{nome_produto} - {tamanho}"
            - URLs são convertidas para absolutas (https://www.sephora.com.br)
            - Imagens com protocolo relativo (`//cdn...`) ganham `https:`
            - oldPrice é opcional (default: 0.0)

        Example:
            >>> # 1 produto com 5 SKUs → 5 Products
            >>> parser = SephoraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price_float}")
        """
        products: list[Product] = []
        logger.debug("Parsing Sephora products from JSON (expanding SKUs)")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        total_skus_processed = 0
        total_skus_ignored = 0

        for product_json in products_json:
            product_id = product_json.get("id")
            product_name = product_json.get("name", "")
            brand = product_json.get("brand", "")
            skus = product_json.get("skus", [])

            if not skus:
                logger.debug(f"Product {product_id} has no SKUs, skipping.")
                continue

            # Expandir cada SKU em um Product individual
            for sku_data in skus:
                try:
                    sku = sku_data.get("sku")
                    if not sku:
                        logger.debug(f"SKU without ID in product {product_id}, skipping.")
                        total_skus_ignored += 1
                        continue

                    # Extrair specs (tamanho/variação)
                    specs = sku_data.get("specs", {})
                    size = specs.get("size", "")

                    # Extrair properties (preços, status, urls)
                    props = sku_data.get("properties", {})
                    status = props.get("status", "UNAVAILABLE")

                    # Validação 1: Status
                    if status != "AVAILABLE":
                        logger.debug(f"SKU {sku} is not available (status={status}), skipping.")
                        total_skus_ignored += 1
                        continue

                    # Extrair preços
                    try:
                        current_price = float(props.get("price", 0))
                        old_price = float(props.get("oldPrice", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for SKU {sku}: {e}, skipping.")
                        total_skus_ignored += 1
                        continue

                    # Validação 2: Preço válido
                    if current_price <= 0:
                        logger.debug(f"SKU {sku} has invalid price ({current_price}), skipping.")
                        total_skus_ignored += 1
                        continue

                    # Montar nome com tamanho
                    combined_name = f"{product_name} - {size}" if size else product_name

                    # URLs
                    sku_url = props.get("url", "")
                    absolute_url = self._make_absolute_url(sku_url)

                    # Imagem
                    images = props.get("images", {})
                    image_url = images.get("default", "")
                    if image_url and image_url.startswith("//"):
                        image_url = f"https:{image_url}"

                    # Criar Product
                    product = Product(
                        product_id=sku,  # SKU é o ID único
                        name=combined_name,
                        current_price_float=current_price,
                        old_price_float=old_price,
                        url=absolute_url,
                        image_url=image_url,
                        sku=sku,
                        available=True,  # Já validado acima
                        marketplace_name="Sephora Brasil",
                        seller="Sephora Brasil"
                    )

                    products.append(product)
                    total_skus_processed += 1

                except Exception as e:
                    logger.error(f"Unexpected error processing SKU in product {product_id}: {e}")
                    total_skus_ignored += 1
                    continue

        logger.info(
            f"Extracted {total_skus_processed} unique SKUs from {len(products_json)} products "
            f"({total_skus_ignored} SKUs ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Sephora API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Sephora API usa JSON, não HTML
        """
        raise ParserError("Sephora API usa JSON, não HTML. Use from_json().")

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo da Sephora
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.sephora.com.br{relative_url}"

        return f"https://www.sephora.com.br/{relative_url}"

    def is_last_page(self, response: ResponseData) -> bool:
        """Verifica se a resposta indica que não há mais páginas (404 Not Found)."""


        return response.is_not_found()

class BelezaNaWebHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Beleza na Web.

    Extrai produtos de páginas HTML da Beleza na Web (belezanaweb.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse híbrido: JSON embedded (data-event) + HTML estruturado
    - Deduplicação automática por SKU
    - Extrai: ID, nome, marca, preços (atual + antigo), URLs, desconto
    - Validações: ignora produtos sem SKU ou preço inválido

    Estrutura HTML esperada:
    - `<article class="showcase-item">` com atributo `data-event` (JSON)
    - Preço atual no JSON `data-event.price`
    - Preço antigo em `.item-price-max` (quando disponível)
    - URLs em `.showcase-card-link-overlay` e `img.showcase-image[data-src]`

    Exemplo:
        >>> parser = BelezaNaWebHTMLParser()
        >>> with open('beleza.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 36 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para BelezaNaWebHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Beleza na Web.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Beleza na Web usa HTML, não JSON
        """
        raise ParserError("Beleza na Web usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Beleza na Web de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <article class="showcase-item" data-event="{...}">
                          <a class="showcase-card-link-overlay" href="/produto">...</a>
                          <img class="showcase-image" data-src="https://...">
                          <div class="item-price-max">R$ 599,00</div>
                          <span class="price-value">R$ 138,00</span>
                      </article>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem SKU ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs relativas são convertidas para absolutas

        Example:
            >>> parser = BelezaNaWebHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Beleza na Web products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os artigos de produtos
        articles = soup.find_all('article', class_='showcase-item')
        logger.debug(f"Found {len(articles)} article elements in HTML")

        duplicates_count = 0

        for article in articles:
            try:
                # 1. Parse JSON do data-event
                data_event_str = article.get('data-event', '{}')
                if not data_event_str or data_event_str == '{}':
                    logger.debug("Article without data-event, skipping")
                    continue

                # Unescape HTML entities (&quot; → ")
                data_event_str = html.unescape(data_event_str)
                data_event = json.loads(data_event_str)

                # 2. Extrair SKU e verificar duplicata
                sku = data_event.get('sku')
                if not sku:
                    logger.warning("Product without SKU in data-event, skipping")
                    continue

                if sku in seen_skus:
                    duplicates_count += 1
                    continue  # Skip duplicata

                seen_skus.add(sku)

                # 3. Extrair dados do JSON embedded
                current_price = float(data_event.get('price', 0))
                product_name = data_event.get('productName', '')
                brand = data_event.get('brand', '')

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {sku} has invalid price ({current_price}), skipping")
                    continue

                # 4. Extrair URL do produto
                url_elem = article.find('a', class_='showcase-card-link-overlay')
                relative_url = url_elem.get('href', '') if url_elem else ''
                product_url = self._make_absolute_url(relative_url)

                # 5. Extrair URL da imagem
                img_elem = article.find('img', class_='showcase-image')
                image_url = img_elem.get('data-src', '') if img_elem else ''

                # 6. Extrair preço antigo (opcional)
                old_price = self._extract_old_price(article)

                # 7. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Beleza na Web",
                    seller="Beleza na Web"
                )

                products.append(product)

            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse data-event JSON: {e}")
                continue
            except (ValueError, TypeError) as e:
                logger.warning(f"Error processing product: {e}")
                continue
            except Exception as e:
                logger.error(f"Unexpected error processing article: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.belezanaweb.com.br{relative_url}"

        return f"https://www.belezanaweb.com.br/{relative_url}"

    def _extract_old_price(self, article) -> float:
        """
        Extrai preço antigo (preço "de") do HTML.

        Args:
            article: Elemento BeautifulSoup do article

        Returns:
            Preço antigo como float, ou 0.0 se não disponível
        """
        try:
            old_price_elem = article.find('div', class_='item-price-max')
            if old_price_elem:
                old_price_text = old_price_elem.get_text(strip=True)
                # Parse usando função do projeto (normaliza "R$ 599,00" → 599.0)
                return parse_price(old_price_text)
        except Exception as e:
            logger.debug(f"Could not extract old price: {e}")

        return 0.0

    def is_last_page(self, response: ResponseData) -> bool:
        """Verifica se a resposta indica que não há mais páginas (404 Not Found)."""
        return response.is_not_found()


class NewEraAPIJSONParser(StoresParserInterface):
    """
    Parser para API da New Era Brasil.

    Extrai produtos de respostas JSON da API da New Era Brasil.

    Características:
    - **NÃO expande SKUs**: Retorna 1 Product por id_Product
    - `available = True` se PELO MENOS 1 SKU tiver estoque (qt_Stock > 0 e fg_B2C == True)
    - `available = False` se TODOS os SKUs estiverem sem estoque ou indisponíveis
    - SKU usado: primeiro SKU disponível encontrado
    - Validações: preço > 0

    Estrutura JSON esperada:
    ```json
    {
      "products": [
        {
          "id_Product": 105789,
          "nm_Product_Ecomm": "Camiseta Manga Curta NBA Indiana Pacers",
          "nm_Product": "camiseta-manga-curta-nba-indiana-pacers-nbi21tsh066",
          "nm_Brand": "NBA",
          "productPrice": [
            {
              "vl_Price": 118.9,
              "vl_Full_Price": 169.9,
              "vl_Perc_Discount": 30.02
            }
          ],
          "productStock": [
            {
              "cd_SKU": "7899564468967",
              "nm_Size": "P",
              "nm_Color": "Mescla Cinza",
              "qt_Stock": 1,
              "fg_B2C": true,
              "nm_Store": "New Era Brasil"
            }
          ],
          "productImage": [
            {
              "ds_Path_Image": "https://smarterappblob.blob.core.windows.net/public/1/image/thumb/...",
              "vl_Order": 1
            }
          ]
        }
      ],
      "qtProducts": 2476,
      "loadMore": true
    }
    ```

    Exemplo:
        >>> parser = NewEraAPIJSONParser()
        >>> products = parser.from_json(newera_response)
        >>> print(f"Extraídos {len(products)} produtos")
        Extraídos 48 produtos
        >>> available_count = sum(1 for p in products if p.available)
        >>> print(f"{available_count} produtos com estoque disponível")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da New Era de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API New Era
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "id_Product": 105789,
                                  "nm_Product_Ecomm": "Nome do Produto",
                                  "nm_Product": "slug-produto",
                                  "nm_Brand": "Marca",
                                  "productPrice": [{"vl_Price": 99.90, "vl_Full_Price": 149.90}],
                                  "productStock": [
                                      {
                                          "cd_SKU": "123456789",
                                          "nm_Size": "M",
                                          "nm_Color": "Preto",
                                          "qt_Stock": 5,
                                          "fg_B2C": true,
                                          "nm_Store": "New Era Brasil"
                                      }
                                  ],
                                  "productImage": [{"ds_Path_Image": "https://..."}]
                              }
                          ],
                          "qtProducts": 2476,
                          "loadMore": true
                      }

        Returns:
            Lista de objetos Product (1 por id_Product).
            Lista vazia se não houver produtos ou campo 'products' não existir.

        Note:
            - **NÃO expande SKUs**: Retorna 1 Product por id_Product
            - `available = False` se TODOS os SKUs tiverem `qt_Stock <= 0` ou `fg_B2C == False`
            - `available = True` se PELO MENOS 1 SKU tiver `qt_Stock > 0` E `fg_B2C == True`
            - SKU usado: primeiro SKU disponível encontrado
            - Produtos com `vl_Price <= 0` são ignorados
            - URL: `https://www.neweracap.com.br/p/{nm_Product}`
            - Imagem: primeira imagem de `productImage` ordenada por `vl_Order`
            - Marketplace: "New Era Brasil"
            - Seller: extraído de `nm_Store` do primeiro SKU disponível

        Example:
            >>> parser = NewEraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - Disponível: {p.available}")
        """
        products: list[Product] = []
        logger.debug("Parsing New Era products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        total_products_processed = 0
        total_products_ignored = 0

        for product_json in products_json:
            try:
                product_id = product_json.get("id_Product")
                product_name = product_json.get("nm_Product_Ecomm", "")
                product_slug = product_json.get("nm_Product", "")

                # Extrair preços do primeiro item de productPrice
                product_prices = product_json.get("productPrice", [])
                if not product_prices:
                    logger.debug(f"Product {product_id} has no prices, skipping.")
                    total_products_ignored += 1
                    continue

                price_data = product_prices[0]
                try:
                    current_price = float(price_data.get("vl_Price", 0))
                    old_price = float(price_data.get("vl_Full_Price", 0))
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid price for product {product_id}: {e}, skipping.")
                    total_products_ignored += 1
                    continue

                # Validação: Preço válido
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid price ({current_price}), skipping.")
                    total_products_ignored += 1
                    continue

                # Extrair primeira imagem (ordenada por vl_Order)
                product_images = product_json.get("productImage", [])
                image_url = ""
                if product_images:
                    # Ordenar por vl_Order e pegar a primeira
                    sorted_images = sorted(product_images, key=lambda img: img.get("vl_Order", 999))
                    image_url = sorted_images[0].get("ds_Path_Image", "")

                # URL do produto
                product_url = f"https://www.neweracap.com.br/p/{product_slug}" if product_slug else ""

                # Verificar disponibilidade: pelo menos 1 SKU com estoque
                product_stocks = product_json.get("productStock", [])
                is_available = False
                first_available_sku = None
                first_seller = "New Era Brasil"

                for stock_data in product_stocks:
                    sku = stock_data.get("cd_SKU")
                    fg_b2c = stock_data.get("fg_B2C", False)
                    qt_stock = stock_data.get("qt_Stock", 0)

                    # Verifica se SKU está disponível
                    if sku and fg_b2c and qt_stock > 0:
                        is_available = True
                        if not first_available_sku:
                            first_available_sku = sku
                            first_seller = stock_data.get("nm_Store", "New Era Brasil")

                # Usar primeiro SKU disponível, ou primeiro SKU se nenhum disponível
                sku_to_use = first_available_sku
                if not sku_to_use and product_stocks:
                    # Se nenhum disponível, usar primeiro SKU mesmo assim
                    sku_to_use = product_stocks[0].get("cd_SKU", str(product_id))
                    first_seller = product_stocks[0].get("nm_Store", "New Era Brasil")
                elif not sku_to_use:
                    # Se não há stocks, usar id_Product como SKU
                    sku_to_use = str(product_id)

                # Criar Product
                product = Product(
                    product_id=str(product_id),
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku_to_use,
                    available=is_available,
                    marketplace_name="New Era Brasil",
                    seller=first_seller
                )

                products.append(product)
                total_products_processed += 1

            except Exception as e:
                logger.error(f"Unexpected error processing product {product_json.get('id_Product')}: {e}")
                total_products_ignored += 1
                continue

        logger.info(
            f"Extracted {total_products_processed} products from {len(products_json)} in response "
            f"({total_products_ignored} products ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para New Era API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - New Era API usa JSON, não HTML
        """
        raise ParserError("New Era API usa JSON, não HTML. Use from_json().")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página (loadMore == False ou sem produtos)

        Note:
            - Verifica campo `loadMore` no JSON
            - Também retorna True se não houver produtos na resposta
            - Retorna True se houver erro ao parsear JSON
        """
        # Verificar se é 404
        if response.is_not_found():
            return True

        # Tentar parsear JSON
        try:
            json_data = response.to_json()
            if not json_data:
                logger.debug("No JSON data in response, assuming last page.")
                return True

            # Verificar campo loadMore
            load_more = json_data.get("loadMore", False)
            if not load_more:
                logger.debug("loadMore is False, this is the last page.")
                return True

            # Verificar se há produtos
            products = json_data.get("products", [])
            if not products:
                logger.debug("No products in response, this is the last page.")
                return True

            return False

        except Exception as e:
            logger.warning(f"Error checking pagination: {e}, assuming last page.")
            return True


class HavanHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Havan.

    Extrai produtos de páginas HTML da Havan (havan.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse HTML estruturado Magento 2
    - Deduplicação automática por product_id
    - Extrai: ID, nome, preços (atual + antigo), URLs, imagens
    - Validações: ignora produtos sem ID ou preço inválido
    - Suporta produtos com e sem desconto

    Estrutura HTML esperada:
    - `<li class="item product product-item">` com `data-product-id`
    - Nome em `.product-item-name a[title]`
    - Preço atual em `span.special-price data-price-amount` ou primeiro `span[data-price-amount]`
    - Preço antigo em `span.old-price data-price-amount` (opcional)
    - Imagem em `picture img[src]`

    Exemplo:
        >>> parser = HavanHTMLParser()
        >>> with open('havan.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 60 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para HavanHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Havan.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Havan usa HTML, não JSON
        """
        raise ParserError("Havan usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Havan de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <li class="item product product-item">
                          <div class="product-item-info">
                              <a data-product-id="751923">
                              <strong class="product-item-name">
                                  <a href="URL" title="Nome">Nome</a>
                              </strong>
                              <picture><img src="https://..."></picture>
                              <div class="price-box">
                                  <span class="special-price">
                                      <span data-price-amount="2999.9">R$ 2.999,90</span>
                                  </span>
                                  <span class="old-price">
                                      <span data-price-amount="3899.9">R$ 3.899,90</span>
                                  </span>
                              </div>
                          </div>
                      </li>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por product_id).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem product_id ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs já vêm completas do HTML

        Example:
            >>> parser = HavanHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_ids: set[str] = set()
        logger.debug("Parsing Havan products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os itens de produtos
        product_items = soup.find_all('li', class_='product-item')
        logger.debug(f"Found {len(product_items)} product items in HTML")

        duplicates_count = 0

        for item in product_items:
            try:
                # 1. Extrair product_id (pode haver vários data-product-id no item)
                product_id_elem = item.find('a', attrs={'data-product-id': True})
                if not product_id_elem:
                    # Tentar no div.price-box
                    price_box = item.find('div', class_='price-box')
                    if price_box and price_box.get('data-product-id'):
                        product_id = str(price_box['data-product-id'])
                    else:
                        logger.warning("Product without ID, skipping")
                        continue
                else:
                    product_id = str(product_id_elem['data-product-id'])

                # 2. Verificar duplicata
                if product_id in seen_ids:
                    duplicates_count += 1
                    continue

                seen_ids.add(product_id)

                # 3. Extrair nome
                name_elem = item.find('strong', class_='product-item-name')
                if name_elem:
                    name_link = name_elem.find('a')
                    product_name = name_link.get('title', '') if name_link else ''
                else:
                    product_name = ''

                # 4. Extrair URL
                url_elem = item.find('strong', class_='product-item-name')
                if url_elem and url_elem.find('a'):
                    product_url = url_elem.find('a').get('href', '')
                else:
                    product_url = ''

                # 5. Extrair imagem
                img_elem = item.find('img', class_='img-default')
                if not img_elem:
                    # Fallback: qualquer img em picture
                    picture_elem = item.find('picture')
                    if picture_elem:
                        img_elem = picture_elem.find('img')

                image_url = img_elem.get('src', '') if img_elem else ''

                # 6. Extrair preços
                price_box = item.find('div', class_='price-box')
                if not price_box:
                    logger.warning(f"Product {product_id} has no price-box, skipping")
                    continue

                # Verificar se tem desconto (special-price + old-price)
                special_price_elem = price_box.find('span', class_='special-price')
                old_price_elem = price_box.find('span', class_='old-price')

                if special_price_elem and old_price_elem:
                    # Produto COM desconto
                    current_price_span = special_price_elem.find('span', attrs={'data-price-amount': True})
                    old_price_span = old_price_elem.find('span', attrs={'data-price-amount': True})

                    try:
                        current_price = float(current_price_span['data-price-amount']) if current_price_span else 0.0
                        old_price = float(old_price_span['data-price-amount']) if old_price_span else 0.0
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping")
                        continue
                else:
                    # Produto SEM desconto: usa primeiro data-price-amount
                    price_span = price_box.find('span', attrs={'data-price-amount': True})
                    if not price_span:
                        logger.warning(f"Product {product_id} has no price, skipping")
                        continue

                    try:
                        current_price = float(price_span['data-price-amount'])
                        old_price = 0.0
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping")
                        continue

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {product_id} has invalid price ({current_price}), skipping")
                    continue

                # 7. Criar objeto Product
                product = Product(
                    product_id=product_id,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=product_id,  # Usar product_id como SKU
                    available=True,  # Produtos exibidos estão disponíveis
                    marketplace_name="Havan",
                    seller="Havan"
                )

                products.append(product)

            except Exception as e:
                logger.error(f"Unexpected error processing product item: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se não há mais produtos (última página).

        Args:
            response: Objeto ResponseData contendo HTML

        Returns:
            True se for a última página, False caso contrário

        Note:
            Verifica:
            1. Mensagem "Não encontramos produtos para essa pesquisa"
            2. Lista de produtos vazia
            3. Nenhum elemento .product-item encontrado
        """
        if not response.is_html():
            logger.warning("Response is not HTML, assuming last page.")
            return True

        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True

        try:
            soup = self.BeautifulSoup(response.body, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(response.body, 'html.parser')

        # Verificar mensagem de vazio
        empty_msg = soup.find('div', class_='message info empty')
        if empty_msg:
            text = empty_msg.get_text()
            if 'Não encontramos produtos' in text or 'não encontramos produtos' in text:
                logger.info("Found 'no products' message, this is the last page.")
                return True

        # Verificar se há itens de produto
        product_items = soup.find_all('li', class_='product-item')
        if not product_items or len(product_items) == 0:
            logger.info("No product items found, this is the last page.")
            return True

        return False


class KabumAPIJSONParser(StoresParserInterface):
    """
    Parser para API da KaBuM!.

    Extrai produtos de respostas JSON da API pública da KaBuM!, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual, com desconto, ofertas especiais)
    - Estoque e disponibilidade
    - URLs (produto e imagens)
    - Marketplace e seller

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Trata ofertas especiais (campo 'offer')
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Lógica de preços:
    - COM offer: current_price = offer.price_with_discount, old_price = price
    - SEM offer: current_price = price_with_discount, old_price = old_price

    Exemplo:
        >>> parser = KabumAPIJSONParser()
        >>> products = parser.from_json(kabum_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    @staticmethod
    def _extract_coupon_code(stamps: dict) -> str:
        """
        Extrai código do cupom do campo stamps.

        Prioriza 'title' (formatado para usuário) sobre 'name' (técnico).

        Args:
            stamps: Dicionário com informações do cupom

        Returns:
            Código do cupom (ex: "CUPOM AOC10OFF" ou "cupom_aoc10off")

        Exemplo:
            >>> stamps = {"title": "CUPOM AOC10OFF", "name": "cupom_aoc10off"}
            >>> _extract_coupon_code(stamps)
            "CUPOM AOC10OFF"
        """
        return stamps.get("title", "") or stamps.get("name", "")

    @staticmethod
    def _extract_discount_value(description: str) -> float:
        """
        Extrai valor do desconto da descrição usando regex.

        Suporta padrões:
        - Percentuais: "10% OFF", "ganhe 10%", "10 % de desconto"
        - Valores fixos: "R$ 100 OFF", "ganhe R$ 50", "economize R$ 200"

        Args:
            description: Texto descritivo do cupom

        Returns:
            Valor do desconto (ex: 10.0 ou 100.0) ou 0.0 se não encontrar

        Exemplo:
            >>> _extract_discount_value("Use o cupom e ganhe 10% OFF")
            10.0
            >>> _extract_discount_value("Use o cupom KABUM100 e ganhe R$ 100 OFF")
            100.0
        """
        import re

        # Tentar extrair valor fixo em reais primeiro: "R$ 100 OFF"
        match_fixed = re.search(r'R\$\s*(\d+(?:[.,]\d+)?)', description)
        if match_fixed:
            # Converter vírgula para ponto se necessário
            value_str = match_fixed.group(1).replace(',', '.')
            return float(value_str)

        # Fallback: buscar percentual "10% OFF"
        match_percent = re.search(r'(\d+)\s*%', description)
        return float(match_percent.group(1)) if match_percent else 0.0

    @staticmethod
    def _extract_coupon_type(stamps: dict) -> str:
        """
        Determina o tipo do cupom baseado na descrição.

        Lógica:
        - Se descrição contém "R$" ou "reais": tipo "fixed"
        - Caso contrário: tipo "percentage" (padrão para KaBuM!)

        Args:
            stamps: Dicionário com informações do cupom

        Returns:
            Tipo do cupom: "percentage" ou "fixed"

        Exemplo:
            >>> stamps = {"description": "ganhe 10% OFF"}
            >>> _extract_coupon_type(stamps)
            "percentage"
        """
        description = stamps.get("description", "")
        if "R$" in description or "reais" in description.lower():
            return "fixed"
        return "percentage"

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da KaBuM! de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da KaBuM!
                      Estrutura esperada:
                      {
                          "meta": {
                              "total_items_count": 416,
                              "total_pages_count": 5,
                              "page": { "number": 1, "size": 100 }
                          },
                          "data": [
                              {
                                  "type": "product",
                                  "id": 170110,
                                  "attributes": {
                                      "title": "Nome Produto",
                                      "price": 99.90,
                                      "price_with_discount": 89.90,
                                      "old_price": 0.0,
                                      "offer": {
                                          "price": 79.90,
                                          "price_with_discount": 69.90
                                      },
                                      "product_link": "slug-produto",
                                      "photos": { "p": ["url1.jpg"] },
                                      "manufacturer": { "name": "Marca" },
                                      "available": true,
                                      "is_marketplace": false,
                                      "marketplace": {}
                                  }
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'data' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se offer existe, usa offer.price_with_discount como preço atual
            - URLs são automaticamente formatadas: https://www.kabum.com.br/produto/{id}/{slug}
            - Marketplace/seller extraídos de attributes.marketplace
        """
        products: list[Product] = []
        logger.debug("Parsing KaBuM! products from JSON")

        data_list = json_data.get("data", [])
        if not data_list:
            logger.warning("No products found in 'data' field.")
            return []

        total_processed = 0
        total_ignored = 0

        for item in data_list:
            try:
                product_id = item.get("id")
                if not product_id:
                    logger.debug("Product without ID, skipping.")
                    total_ignored += 1
                    continue

                attrs = item.get("attributes", {})
                if not attrs:
                    logger.debug(f"Product {product_id} has no attributes, skipping.")
                    total_ignored += 1
                    continue

                title = attrs.get("title", "")
                if not title:
                    logger.debug(f"Product {product_id} has no title, skipping.")
                    total_ignored += 1
                    continue

                # Lógica de preços: priorizar offer se existir
                offer = attrs.get("offer")
                if offer and isinstance(offer, dict):
                    # COM offer: usa offer.price_with_discount vs price regular
                    try:
                        current_price = float(offer.get("price_with_discount", 0))
                        old_price = float(attrs.get("price", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price in offer for product {product_id}: {e}, skipping.")
                        total_ignored += 1
                        continue
                else:
                    # SEM offer: usa price_with_discount vs old_price
                    try:
                        current_price = float(attrs.get("price_with_discount", 0))
                        old_price = float(attrs.get("old_price", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for product {product_id}: {e}, skipping.")
                        total_ignored += 1
                        continue

                # Validação: preço atual deve ser > 0
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid current_price ({current_price}), skipping.")
                    total_ignored += 1
                    continue

                # URL do produto
                product_link = attrs.get("product_link", "")
                product_url = f"https://www.kabum.com.br/produto/{product_id}/{product_link}" if product_link else ""

                # Imagem: primeira foto do array photos.p
                photos = attrs.get("photos", {})
                photos_list = photos.get("p", []) if isinstance(photos, dict) else []
                image_url = photos_list[0] if photos_list else ""

                # Seller/Marketplace
                is_marketplace = attrs.get("is_marketplace", False)
                marketplace = attrs.get("marketplace", {})
                if is_marketplace and isinstance(marketplace, dict):
                    seller = marketplace.get("seller_name", "KaBuM!")
                else:
                    seller = "KaBuM!"

                # Disponibilidade
                available = attrs.get("available", False)

                # Fabricante (opcional)
                manufacturer = attrs.get("manufacturer", {})
                manufacturer_name = manufacturer.get("name", "") if isinstance(manufacturer, dict) else ""

                # Cupons/Stamps (quando disponível)
                # IMPORTANTE: stamps é um dict (objeto único), não array!
                stamps = attrs.get("stamps")
                coupon = None
                coupon_text = stamps.get("description", "") if stamps and isinstance(stamps, dict) else ""
                if coupon_text:
                    logger.debug(f"Product {product_id} has coupon description: {coupon_text}")
                if stamps and isinstance(stamps, dict):
                    # Extrair informações do cupom usando métodos helper
                    code = self._extract_coupon_code(stamps)
                    description = stamps.get("description", "")
                    value = self._extract_discount_value(description)
                    coupon_type = self._extract_coupon_type(stamps)

                    # Só criar cupom se tiver código válido
                    if code:
                        from notify_utils.models import Coupon
                        coupon = Coupon(
                            code=code,                 # Ex: "CUPOM AOC10OFF"
                            discount_type=coupon_type, # Ex: "percentage"
                            discount_value=value,      # Ex: 10.0 (extraído via regex)
                            message=description        # Descrição completa do cupom
                        )

                product = Product(
                    product_id=str(product_id),
                    name=title,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=str(product_id),  # KaBuM! usa ID como identificador único
                    available=available,
                    marketplace_name="KaBuM!",
                    seller=seller,
                    coupon=coupon
                )

                products.append(product)
                total_processed += 1

            except Exception as e:
                logger.error(f"Error processing product {item.get('id', 'unknown')}: {e}")
                total_ignored += 1
                continue

        logger.info(f"KaBuM! parser: {total_processed} products extracted, {total_ignored} ignored.")
        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para KaBuM! API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - KaBuM! API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for KaBuM! API.")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Lógica:
        1. Se não for JSON ou for 404, assume última página
        2. Verifica meta.page.number >= meta.total_pages_count
        3. Verifica se data está vazio

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página, False caso contrário
        """
        if not response.is_json():
            logger.warning("Response is not JSON, cannot determine pagination.")
            return True

        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True

        json_data = response.to_json()
        if json_data is None:
            logger.warning("Failed to parse JSON response, assuming last page.")
            return True

        # Verificar se há produtos na resposta
        data_list = json_data.get("data", [])
        if not data_list:
            logger.info("No products found in response 'data', this is the last page.")
            return True

        # Verificar meta de paginação
        meta = json_data.get("meta", {})
        if meta:
            page_info = meta.get("page", {})
            current_page = page_info.get("number", 0)
            total_pages = meta.get("total_pages_count", 0)

            if current_page >= total_pages and total_pages > 0:
                logger.info(f"Current page ({current_page}) >= total pages ({total_pages}), this is the last page.")
                return True

        # Se chegou aqui, assume que há mais páginas
        return False


class DafitiJSONParser(StoresParserInterface):
    """
    Parser para API da Dafiti (dafiti.com.br).

    A API da Dafiti retorna uma resposta JSON onde o campo `body.products`
    contém uma string HTML com os produtos da página. Este parser suporta
    ambos os formatos:

    - `from_json()`: Aceita a resposta JSON completa da API e extrai o HTML
      interno de `body.products` automaticamente.
    - `from_html()`: Aceita diretamente a string HTML do campo `body.products`.

    Características:
    - Parse do HTML de `body.products` com BeautifulSoup
    - Deduplicação automática por SKU (`data-sku`)
    - Lógica de preços:
      - COM desconto (`is-special-price`): `current_price = product-box-price-to`,
        `old_price = product-box-price-from`
      - SEM desconto: `current_price = product-box-price-from`, `old_price = 0.0`
    - Seller extraído de `.product-box-seller span` (exibido mesmo quando oculto)
    - Detecção de última página via campo `noResults` ou ausência de produtos

    Estrutura JSON esperada:
    ```json
    {
      "body": {
        "products": "<div class=\\"product-box\\" data-sku=\\"SKU123\\">...</div>",
        "pageSize": 48,
        "total": 3448,
        "page": 1,
        "noResults": "",
        "moreProducts": ""
      }
    }
    ```

    Estrutura HTML esperada (dentro de `body.products`):
    ```html
    <div class="product-box" data-sku="AD126APF15KYU">
        <div class="product-box-image">
            <a href="https://www.dafiti.com.br/Produto-123.html"
               class="product-box-link"
               data-model-picture="https://static.dafiti.com.br/p/...jpg">
                <img alt="Nome do Produto" data-original="...jpg"/>
            </a>
        </div>
        <div class="product-box-detail">
            <div class="product-box-brand"><span>Marca</span></div>
            <p class="product-box-title">Nome do Produto</p>
            <!-- COM desconto -->
            <div class="product-box-price is-special-price">
                <span class="product-box-price-from">R$ 89,90</span>
                <span class="product-box-price-to">R$ 39,90</span>
            </div>
            <!-- SEM desconto -->
            <div class="product-box-price">
                <span class="product-box-price-from">R$ 49,99</span>
            </div>
            <div class="product-box-seller" style="display: none;">
                <span>Nome do Seller</span>
            </div>
        </div>
    </div>
    ```

    Exemplo:
        >>> parser = DafitiJSONParser()
        >>> import json
        >>> with open('dafiti_products.json', 'r') as f:
        ...     data = json.load(f)
        >>> products = parser.from_json(data)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 12 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para DafitiJSONParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Dafiti de resposta JSON da API.

        Extrai a string HTML do campo `body.products` e delega para `from_html()`.

        Args:
            json_data: Dicionário contendo a resposta JSON completa da API Dafiti.
                      Estrutura esperada:
                      {
                          "body": {
                              "products": "<html com produtos>",
                              "pageSize": 48,
                              "total": 3448,
                              "page": 1,
                              "noResults": "",
                          }
                      }

        Returns:
            Lista de objetos Product extraídos e deduplicados.
            Lista vazia se não houver produtos válidos.

        Raises:
            ParserError: Se o campo `body.products` não for encontrado no JSON.

        Example:
            >>> parser = DafitiJSONParser()
            >>> products = parser.from_json(api_response)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price_float:.2f}")
        """
        body = json_data.get("body", {})
        if not body:
            raise ParserError(
                "Campo 'body' não encontrado no JSON da Dafiti. "
                "Verifique se a resposta é da API correta."
            )

        # Prioridade: body.result.items (JSON estruturado, todos os produtos)
        result_items = body.get("result", {}).get("items", {})
        if result_items and isinstance(result_items, dict):
            logger.debug(f"Usando body.result.items: {len(result_items)} items encontrados")
            return self._parse_result_items(result_items)

        # Fallback: body.products (HTML, subconjunto dos produtos)
        html_products = body.get("products", "")
        if not html_products or not isinstance(html_products, str):
            logger.warning("Campo 'body.products' vazio ou não é string. Retornando lista vazia.")
            return []

        logger.debug("body.result.items não disponível, usando fallback HTML body.products")
        return self.from_html(html_products)

    def _parse_result_items(self, items: dict) -> list[Product]:
        """
        Extrai produtos do campo body.result.items da API da Dafiti.

        Cada chave do dicionário é um SKU de produto. Os dados estão em
        subcampos `meta`, `images`, `seller` e `link`.

        Args:
            items: Dicionário SKU → dados do produto de body.result.items.

        Returns:
            Lista de objetos Product extraídos e deduplicados.
        """
        products: list[Product] = []
        seen_skus: set[str] = set()

        for sku, item in items.items():
            try:
                if not sku or sku in seen_skus:
                    continue
                seen_skus.add(sku)

                meta = item.get("meta", {})

                name = meta.get("name", "").strip()
                if not name:
                    logger.warning(f"Produto {sku} sem nome, ignorando")
                    continue

                # Preços: special_price é o preço com desconto; price é o original
                price_raw = meta.get("price")
                special_raw = meta.get("special_price")

                try:
                    price_val = float(price_raw) if price_raw is not None else 0.0
                except (ValueError, TypeError):
                    price_val = 0.0

                try:
                    special_val = float(special_raw) if special_raw is not None else 0.0
                except (ValueError, TypeError):
                    special_val = 0.0

                if special_val > 0 and special_val < price_val:
                    # Desconto real: special menor que o preço original
                    current_price = special_val
                    old_price = price_val
                elif price_val > 0:
                    current_price = price_val
                    old_price = 0.0
                else:
                    logger.warning(f"Produto {sku} sem preço válido, ignorando")
                    continue

                # URL do produto (link relativo → absoluto)
                link = item.get("link", "")
                product_url = f"https://www.dafiti.com.br/{link}" if link else ""

                # Imagem (primeiro item do array images)
                image_url = ""
                images = item.get("images", [])
                if images and isinstance(images, list) and isinstance(images[0], dict):
                    image_url = images[0].get("url", "")

                # Seller
                seller_data = item.get("seller", {})
                seller = seller_data.get("shop_name", "") or seller_data.get("name", "") or "Dafiti"

                products.append(Product(
                    product_id=sku,
                    name=name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Dafiti",
                    seller=seller,
                ))

            except Exception as e:
                logger.error(f"Erro inesperado processando item {sku} da Dafiti: {e}")
                continue

        logger.info(f"Extraídos {len(products)} produtos únicos da Dafiti via result.items")
        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Dafiti de HTML (conteúdo de `body.products`).

        Args:
            html_data: String contendo o HTML do campo `body.products` da API Dafiti.
                      Estrutura esperada:
                      ```html
                      <div class="product-box" data-sku="AD126APF15KYU">
                          <div class="product-box-image">
                              <a href="URL" class="product-box-link"
                                 data-model-picture="https://static.dafiti.com.br/...">
                                  <img alt="Nome" data-original="..."/>
                              </a>
                          </div>
                          <div class="product-box-detail">
                              <div class="product-box-brand"><span>Marca</span></div>
                              <p class="product-box-title">Nome do Produto</p>
                              <div class="product-box-price is-special-price">
                                  <span class="product-box-price-from">R$ 89,90</span>
                                  <span class="product-box-price-to">R$ 39,90</span>
                              </div>
                              <div class="product-box-seller">
                                  <span>Nome do Seller</span>
                              </div>
                          </div>
                      </div>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados são automaticamente removidos via `seen_skus`
            - Produtos sem SKU ou preço inválido são ignorados com log de warning
            - Preço antigo é 0.0 quando não há desconto anunciado
            - Seller é extraído mesmo quando o elemento está oculto via CSS

        Example:
            >>> parser = DafitiJSONParser()
            >>> products = parser.from_html(html_products_string)
            >>> for p in products:
            ...     print(f"{p.sku}: {p.name} - R$ {p.current_price_float:.2f}")
        """
        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Dafiti products from HTML")

        try:
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml não disponível, usando html.parser")

        product_boxes = soup.find_all('div', class_='product-box')
        logger.debug(f"Encontrados {len(product_boxes)} blocos product-box no HTML")

        duplicates_count = 0

        for box in product_boxes:
            try:
                # 1. Extrair SKU (identificador do produto)
                sku = box.get('data-sku', '').strip()
                if not sku:
                    logger.warning("Produto sem data-sku encontrado, ignorando")
                    continue

                # 2. Verificar duplicata
                if sku in seen_skus:
                    duplicates_count += 1
                    continue
                seen_skus.add(sku)

                # 3. Extrair URL e imagem do link
                link_elem = box.find('a', class_='product-box-link')
                product_url = link_elem.get('href', '') if link_elem else ''
                image_url = link_elem.get('data-model-picture', '') if link_elem else ''

                # 4. Extrair nome do produto
                title_elem = box.find('p', class_='product-box-title')
                product_name = title_elem.get_text(strip=True) if title_elem else ''

                if not product_name:
                    # Fallback: usar alt da imagem
                    img_elem = box.find('img')
                    product_name = img_elem.get('alt', '') if img_elem else ''

                # 5. Extrair preços
                price_box = box.find('div', class_='product-box-price')
                if not price_box:
                    logger.warning(f"Produto {sku} sem div.product-box-price, ignorando")
                    continue

                price_to_elem = price_box.find('span', class_='product-box-price-to')
                price_from_elem = price_box.find('span', class_='product-box-price-from')

                try:
                    if price_to_elem and price_from_elem:
                        # Produto COM desconto: price-to = atual, price-from = antigo
                        current_price = parse_price(price_to_elem.get_text(strip=True))
                        old_price = parse_price(price_from_elem.get_text(strip=True))
                    elif price_from_elem:
                        # Produto SEM desconto: price-from = preço atual
                        current_price = parse_price(price_from_elem.get_text(strip=True))
                        old_price = 0.0
                    else:
                        logger.warning(f"Produto {sku} sem spans de preço, ignorando")
                        continue
                except (ValueError, TypeError) as e:
                    logger.warning(f"Preço inválido para produto {sku}: {e}, ignorando")
                    continue

                # 6. Validar preço atual
                if current_price <= 0:
                    logger.warning(f"Produto {sku} com preço inválido ({current_price}), ignorando")
                    continue

                # 7. Extrair seller (campo pode estar oculto via CSS)
                seller_div = box.find('div', class_='product-box-seller')
                seller = "Dafiti"
                if seller_div:
                    seller_span = seller_div.find('span')
                    if seller_span:
                        seller_text = seller_span.get_text(strip=True)
                        if seller_text:
                            seller = seller_text

                # 8. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Dafiti",
                    seller=seller
                )

                products.append(product)

            except Exception as e:
                logger.error(f"Erro inesperado processando produto da Dafiti: {e}")
                continue

        logger.info(
            f"Extraídos {len(products)} produtos únicos da Dafiti "
            f"({duplicates_count} duplicatas ignoradas)"
        )

        return products

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se não há mais produtos (última página da Dafiti).

        A Dafiti não retorna 404 na última página. Em vez disso, o campo
        `body.noResults` fica não-vazio OU o HTML de `body.products` não
        contém nenhum `div.product-box`.

        Lógica de verificação (em ordem):
        1. Se a resposta for 404, retorna True
        2. Tenta parsear JSON e verifica `body.noResults` (truthy = última)
        3. Verifica se `body.products` não contém `product-box`
        4. Se não for possível parsear, assume última página

        Args:
            response: Objeto ResponseData contendo a resposta HTTP da API Dafiti

        Returns:
            bool: True se for a última página, False caso contrário

        Note:
            A URL da API Dafiti usa o parâmetro `page` para paginação.
            Exemplo: `?page=2&ajax=true`
        """
        if response.is_not_found():
            logger.info("Resposta 404, assumindo última página da Dafiti.")
            return True
        
        
        
        try:
            json_data = json.loads(response.body)
        except Exception as e:
            logger.warning(f"Erro ao parsear JSON da Dafiti: {e}, assumindo última página.")
            return True

        body = json_data.get("body", {})
        if not body:
            logger.warning("Campo 'body' ausente na resposta da Dafiti, assumindo última página.")
            return True

        # Verificar campo noResults (truthy indica sem resultados)
        no_results = body.get("noResults", "")
        if no_results:
            logger.info(f"Campo noResults='{no_results}', esta é a última página da Dafiti.")
            return True

        # Verificar se body.result.items está vazio ou ausente
        result_items = body.get("result", {}).get("items", {})
        if result_items is not None and not result_items:
            logger.info("Campo body.result.items vazio, esta é a última página da Dafiti.")
            return True

        # Verificar se o HTML de produtos contém algum product-box
        html_products = body.get("products", "")
        if not html_products or 'product-box' not in html_products:
            logger.info("HTML de produtos sem 'product-box', esta é a última página da Dafiti.")
            return True

        return False