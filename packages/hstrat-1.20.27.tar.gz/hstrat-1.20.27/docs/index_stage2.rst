========
Overview
========

.. include:: readme.rst

.. toctree::
   :maxdepth: 1
   :hidden:

   index
   quickstart
   demo-ping
   mechanism
   policies
   api
   publications
   projects
   citing
   contributing
   authors
   history
   indices
