# Generate casts

This folder makes it possible to generate asciinema casts.
The solution was completely inspired by https://stackoverflow.com/a/63080929/1149326
It can only run on linux.

## Usage
```console
./generate-casts.sh
```
