:tocdepth: 1

.. _changes:

=========
Changelog
=========

.. include:: ../CHANGELOG.rst
