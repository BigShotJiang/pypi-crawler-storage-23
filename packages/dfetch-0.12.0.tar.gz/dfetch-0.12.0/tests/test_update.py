"""Test the check command."""

# mypy: ignore-errors
# flake8: noqa

import argparse
from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from dfetch.commands.update import Update
from dfetch.manifest.project import ProjectEntry
from tests.manifest_mock import mock_manifest

DEFAULT_ARGS = argparse.Namespace(no_recommendations=False)
DEFAULT_ARGS.force = False
DEFAULT_ARGS.projects = []


@pytest.mark.parametrize(
    "name, projects",
    [
        ("empty", []),
        ("single_project", [{"name": "my_project"}]),
        ("two_projects", [{"name": "first"}, {"name": "second"}]),
    ],
)
def test_update(name, projects):
    update = Update()

    fake_superproject = Mock()
    fake_superproject.manifest = mock_manifest(projects)
    fake_superproject.root_directory = Path("/tmp")

    with patch(
        "dfetch.commands.update.create_super_project", return_value=fake_superproject
    ):
        with patch(
            "dfetch.manifest.parse.get_childmanifests"
        ) as mocked_get_childmanifests:
            with patch("dfetch.project.create_sub_project") as mocked_create:
                with patch("os.path.exists"):
                    with patch("dfetch.commands.update.in_directory"):
                        with patch("dfetch.commands.update.Update._check_destination"):
                            mocked_get_childmanifests.return_value = []

                            update(DEFAULT_ARGS)

                            for _ in projects:
                                mocked_create.return_value.update.assert_called()


def test_forced_update():
    update = Update()

    fake_superproject = Mock()
    fake_superproject.manifest = mock_manifest([{"name": "some_project"}])
    fake_superproject.root_directory = Path("/tmp")
    fake_superproject.ignored_files.return_value = []

    with patch(
        "dfetch.commands.update.create_super_project", return_value=fake_superproject
    ):
        with patch(
            "dfetch.manifest.parse.get_childmanifests"
        ) as mocked_get_childmanifests:
            with patch("dfetch.project.create_sub_project") as mocked_create:
                with patch("os.path.exists"):
                    with patch("dfetch.commands.update.in_directory"):
                        with patch("dfetch.commands.update.Update._check_destination"):
                            mocked_get_childmanifests.return_value = []

                            args = argparse.Namespace(
                                no_recommendations=False,
                                force=True,
                                projects=[],
                            )

                            update(args)
                            mocked_create.return_value.update.assert_called_once_with(
                                force=True, files_to_ignore=[]
                            )


def test_create_menu():
    subparsers = argparse.ArgumentParser().add_subparsers()

    Update.create_menu(subparsers)

    assert "update" in subparsers.choices

    options = [
        ["-h", "--help"],
        ["-f", "--force"],
        ["-N", "--no-recommendations"],
    ]

    for action, expected_options in zip(
        [
            action
            for action in subparsers.choices["update"]._actions
            if action.option_strings
        ],
        options,
        # strict=True,
    ):
        assert action.option_strings == expected_options


@pytest.mark.parametrize(
    "name, real_path",
    [
        ("basic", "/somewhere"),
        ("root", "/"),
    ],
)
def test_check_path_traversal(name, real_path):
    with pytest.raises(RuntimeError):
        Update._check_path_traversal(
            ProjectEntry.from_yaml({"name": "a"}), real_path, "/somewhere/somewhere"
        )


@pytest.mark.parametrize(
    "name, real_path, destinations",
    [
        ("duplicate", "/somewhere", ["/somewhere", "/somewhere"]),
        ("sub-folder", "/somewhere", ["/somewhere/sub", "/somewhere"]),
        ("sub-folders", "/somewhere", ["/somewhere/sub/sub", "/somewhere/sub"]),
    ],
)
def test_check_overlapping_destinations(name, real_path, destinations):
    with pytest.raises(RuntimeError):
        Update._check_overlapping_destination(
            ProjectEntry.from_yaml({"name": "a"}), destinations, real_path
        )


@pytest.mark.parametrize(
    "name, real_path, destinations",
    [
        (
            "sub-folder",
            "/somewhere/sub",
            ["/somewhere/sub", "/somewhere/sub1", "/somewhere/sub2"],
        ),
        (
            "sub-folders",
            "/somewhere/sub1",
            ["/somewhere/sub1", "/somewhere/sub/sub1", "/somewhere/sub2"],
        ),
    ],
)
def test_check_non_overlapping_destinations(name, real_path, destinations):
    Update._check_overlapping_destination(
        ProjectEntry.from_yaml({"name": "a"}), destinations, real_path
    )
