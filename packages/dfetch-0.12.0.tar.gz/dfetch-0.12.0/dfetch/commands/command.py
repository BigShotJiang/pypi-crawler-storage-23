"""A generic command."""

import argparse
import re
import sys
from abc import ABC, abstractmethod
from argparse import ArgumentParser  # pylint: disable=unused-import
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING and sys.version_info >= (3, 10):
    from typing import TypeAlias

    SubparserActionType: TypeAlias = (
        "argparse._SubParsersAction[ArgumentParser]"  # pyright: ignore[reportPrivateUsage] #pylint: disable=protected-access
    )
else:
    SubparserActionType = (
        argparse._SubParsersAction  # pyright: ignore[reportPrivateUsage] #pylint: disable=protected-access
    )


def pascal_to_kebab(name: str) -> str:
    """Insert a dash before each uppercase letter (except the first) and lowercase everything."""
    s1 = re.sub(r"(?<!^)(?=[A-Z])", "-", name)
    return s1.lower()


class Command(ABC):
    """An abstract command that dfetch can perform.

    When adding a new command to dfetch this class should be sub-classed.
    That subclass should implement:

    - ``create_menu`` which should add an appropriate subparser.
        Likely calling parser is enough.
    - ``__call__`` which will be called when the user selects the command.
    """

    CHILD_TYPE = TypeVar("CHILD_TYPE", bound="Command")  # noqa

    @staticmethod
    @abstractmethod
    def create_menu(subparsers: SubparserActionType) -> None:
        """Add a sub-parser to the given parser.

        Args:
            subparsers (argparse._SubParsersAction): subparser that the parser should be added to.

        This method must be implemented by a subclass. It is called when the menu structure is built.
        """

    @abstractmethod
    def __call__(self, args: argparse.Namespace) -> None:
        """Perform the command.

        Args:
            args (argparse.Namespace): arguments as provided by the user.

        Raises:
            NotImplementedError: This is an abstract method that should be implemented by a subclass.
        """

    @staticmethod
    def parser(
        subparsers: SubparserActionType,
        command: type["Command.CHILD_TYPE"],
    ) -> "argparse.ArgumentParser":
        """Generate the parser.

        The name of the class will be used as command. The class docstring will be split into
        the help text, description and epilog.

        Args:
            subparsers: The subparser to add the command to.
            command: The command class that should be instantiated and called when this command is called.

        Raises:
            NotImplementedError: If the child class doesn't have a docstring.

        Returns:
            Command: A argparse.ArgumentParser that can be used to add arguments.
        """
        if not command.__doc__:
            raise NotImplementedError("Must add docstring to class")
        help_str, epilog = command.__doc__.split("\n", 1)

        parser = subparsers.add_parser(
            pascal_to_kebab(command.__name__),
            description=help_str,
            help=help_str,
            epilog=epilog,
        )

        parser.set_defaults(func=command())
        return parser
