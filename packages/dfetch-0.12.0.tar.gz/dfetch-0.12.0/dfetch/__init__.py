"""Dfetch."""

__version__ = "0.12.0"

DEFAULT_MANIFEST_NAME: str = "dfetch.yaml"
