"""Non domain specific utilities."""
