"""Manifest related items."""
