"""Core utility modules for internal CKVD operations."""

# These modules are for internal use by the core CKVD components
# and are not part of the public API
