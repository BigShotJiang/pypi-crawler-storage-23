# Surge Predictor MCP Server

这是一个 MCP (Model Context Protocol) 服务器，用于根据压缩机的进口参数（压力、温度、转速）预测喘振点的压比。它封装了一个基于 PySR 训练的机器学习模型，可以被任何支持 MCP 协议的客户端（如 Kimi Playground）调用。

## 安装

由于这是一个通过 `uvx` 运行的 MCP 服务器，你无需手动安装。客户端（如魔搭平台）会自动通过 `uvx` 从 PyPI 拉取并运行。

## 使用说明

部署后，你可以通过自然语言向支持 MCP 的 AI 助手提问，例如：

> “压缩机进口压力 8.5 MPa，温度 35°C，转速 为1 （100%额定转速），预测一下喘振点压比是多少？”

助手会自动调用本服务并返回结果。

## 工具列表

本服务器提供以下工具：

*   **`predict_surge`**: 根据压力、温度、转速预测喘振点压比。
    *   参数:
        *   `pressure` (float): 进口压力 (MPa)
        *   `temperature` (float): 进口温度 (°C)
        *   `speed` (float): 转速 (实际转速/额定转速 0-1)
    *   返回:
        *   (float): 预测的喘振点压比。

## 开发与构建

如果你想在本地修改或构建此项目：

1.  克隆仓库（如果适用）。
2.  确保已安装 Python 3.10 或更高版本。
## 本地开发
1. 确保 Python ≥ 3.10。
2. 克隆本仓库并进入目录。
3. 执行以下命令完成环境设置并启动服务：
   ```bash
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -e .
   python -m surge_predictor_mcp.server