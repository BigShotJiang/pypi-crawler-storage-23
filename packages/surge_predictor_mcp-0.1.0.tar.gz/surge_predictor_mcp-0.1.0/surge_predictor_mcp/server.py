import joblib
import numpy as np
import os
import sys
import traceback
import time
import logging
from fastmcp import FastMCP

# 配置日志（输出到 stderr，便于 uvx 和魔搭平台捕获）
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("surge_predictor")

# 模型文件放在与 server.py 同一目录
MODEL_FILENAME = 'my_surge_model.joblib'
current_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(current_dir, MODEL_FILENAME)

model = None

def get_model():
    global model
    if model is None:
        logger.info(f"loading model from {model_path}")
        try:
            loaded = joblib.load(model_path)
            logger.info(f"loaded type={type(loaded)}")
            if isinstance(loaded, dict):
                logger.info(f"keys: {list(loaded.keys())}")
                model = loaded['model']
            else:
                model = loaded
            logger.info(f"model loaded successfully, type={type(model)}")
        except Exception as e:
            logger.error(f"model load failed: {e}")
            traceback.print_exc()
            raise
    else:
        logger.info("model already loaded, reusing")
    return model

mcp = FastMCP("Compressor Surge Predictor")

@mcp.tool()
def predict_surge(pressure: float, temperature: float, speed: float) -> float:
    logger.info(f"predict_surge called with pressure={pressure}, temp={temperature}, speed={speed}")
    try:
        model_obj = get_model()
        input_features = np.array([[pressure, temperature, speed]])
        t0 = time.time()
        predicted_pr = model_obj.predict(input_features)[0]
        t1 = time.time()
        logger.info(f"predict done in {t1-t0:.3f}s, result={predicted_pr}")
        return float(predicted_pr)
    except Exception as e:
        logger.error(f"exception: {type(e).__name__}: {e}")
        traceback.print_exc()
        raise

def main():
    """命令行入口函数"""
    mcp.run()

if __name__ == "__main__":
    main()