import requests
import json
def fanyi(单词):
    y = "https://fanyi.baidu.com/sug"
    data = {'kw': 单词}
    t = requests.post(y, data=data)
    x = t.json()
    返回值=json.dumps(x, ensure_ascii=False, indent=2)
    return 返回值
