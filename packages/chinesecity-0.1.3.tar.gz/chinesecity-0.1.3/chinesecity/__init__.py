__version__ = "0.1.3"

from .devecho import dprint,fdprint,dinput,fdinput
from .devert import fanyi
from .devebox import password
