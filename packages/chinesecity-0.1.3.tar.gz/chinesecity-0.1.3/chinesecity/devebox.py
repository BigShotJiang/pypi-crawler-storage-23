def password(password):
    length = len(password)
    length_score = min(length * 3, 30)
    
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(not c.isalnum() for c in password)
    type_score = sum([has_upper, has_lower, has_digit, has_special]) * 10
    
    weak_passwords = ["123456", "password", "111111", "abcdef"]
    weak_score = 30 if password not in weak_passwords else 0
    
    total = length_score + type_score + weak_score
    total = min(total, 100)
    
    bar_length = 20
    filled = int(bar_length * total / 100)
    color = "\033[91m" if total < 40 else "\033[93m" if total < 80 else "\033[92m"
    reset = "\033[0m"
    bar = f"[{color}{'█'*filled}{' '*(bar_length-filled)}{reset}]"
    
    return f"密码安全分：{total}/100 {bar}"



