# pycb
一个 Python 综合库。

## 安装
```bash
pip install chinesecity

