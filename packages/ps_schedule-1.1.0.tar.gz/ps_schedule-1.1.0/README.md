![Python Version](https://img.shields.io/badge/python-3.9+-blue?logo=python&logoColor=white)
[![PyPI Version](https://img.shields.io/pypi/v/ps-schedule?color=blue&logo=pypi&logoColor=white)](https://pypi.org/project/ps-schedule/)

⚠️ Це неофіційний, студентський проєкт, який витягує (парсить) розклад з пакету програм ["ПС-Деканат"](https://www.politek-soft.kiev.ua/index.php?do=products), який використовується більшістю ВНЗ України.

Бібліотека буде працювати з більшостями доменів "ПС-Деканат". При розробці бібліотеки, функціонал тестувався на домені [ІФНТУНГ](https://dekanat.nung.edu.ua/cgi-bin/timetable.cgi?n=9), однак інші домени повинні також працювати.

## Швидкий старт:
### Встановлюємо бібліотеку з PyPI:
```bash
pip install ps-schedule
```

### Отримуємо домен розкладу:
Для цього просто копіюємо ось цю частину посилання на розклад вашого ВНЗ:
<img width="385" height="41" alt="image" src="https://github.com/user-attachments/assets/eb2639af-16b8-45eb-bf5f-85a84bc3a1e4" />

### Базовий код
Імпортуємо базові класи:
```python
from ps_schedule import Schedule, ScheduleParameters
```
Вставляємо домен у поле `domain` класу `Schedule` та задаємо параметри для отримання розкладу групи:
```python
schedule = Schedule(domain="https://dekanat.nung.edu.ua/", params=ScheduleParameters(group="ІП-24-1К")).get()
```
Обробляємо дані:
```python
# Отримуємо розклад на сьогодні (перший у списку)
table = schedule[0]

# Виводимо дату таблиці розкладу на сьогодні в консоль
print(f"===| {table.date} |===")

# Проходимось по парам на сьогодні
for lesson in table.lessons:
    
    # Перевіряємо чи є пара
    if lesson.description:
        
        # Виписуємо в консоль час початку пари, час кінця пари і її опис.
        print(f"[{lesson.start_time} - {lesson.end_time}]: {lesson.description}")
```

## Важливі нюанси:
Ця бібліотека використовує `BeautifulSoup` щоб парсити HTML з сторінки яку ви бачите коли заходите на розклад у браузері (тому що немає публічного API).
Якщо якимось чудом структура HTML поміняється або навіть відрізняється конкретно у вашого ВНЗ, то можливо парсер не буде парсити (це мало вірогідно, зазвичай ПС-Розклад однаковий для всіх).

**Дуже бажано не робити 1000 запитів на секунду, і робити тривалі паузи між ними, бо є два варіанти:**
1. Ви покладете картоплину на якій ця чудо система працює.
2. Сервер вас пошле 403-м кодом.

##

[**Документація**](docs/base.md)

Приємного користування 😊
