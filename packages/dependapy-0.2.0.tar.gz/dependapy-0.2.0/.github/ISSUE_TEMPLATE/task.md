---
name: Task
about: Submit a task to describe something that needs to get done.
---

### What is this task about?

…

### What needs to be done to complete this task?

- [ ] …
- [ ] …
- [ ] …

### What else should we know?

…
