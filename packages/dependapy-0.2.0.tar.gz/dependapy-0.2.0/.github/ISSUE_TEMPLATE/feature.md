---
name: Feature
about: Submit a feature to request or describe new functionality to be added.
---

### What is this feature about?

…

### What needs to be done to implement this feature?

- [ ] …
- [ ] …
- [ ] …

### What else should we know?

…
