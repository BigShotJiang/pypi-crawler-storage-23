# Application Layer — Use Case Orchestrierung
# Re-exporte von cross-cutting Result-Typen für die Presentation Layer
from dependapy.domain.result import Err, Ok, Result

__all__ = ["Err", "Ok", "Result"]
