# Presentation Layer — Entry Points (CLI, Webhook, etc.)
