"""Tests for the dependapy package"""
