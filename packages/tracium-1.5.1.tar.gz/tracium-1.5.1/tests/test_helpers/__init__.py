"""
Tests for helper modules.
"""
