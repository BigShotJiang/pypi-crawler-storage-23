"""Allow running as: python -m siglent_spd_mcp"""

from siglent_spd_mcp.server import main

main()
