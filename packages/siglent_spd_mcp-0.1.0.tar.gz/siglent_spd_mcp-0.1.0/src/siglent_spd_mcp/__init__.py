"""MCP server for Siglent SPD series power supplies."""

__version__ = "0.1.0"
