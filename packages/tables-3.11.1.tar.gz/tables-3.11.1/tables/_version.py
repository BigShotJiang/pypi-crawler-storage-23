__version__ = "3.11.1"
"""The PyTables version number."""
