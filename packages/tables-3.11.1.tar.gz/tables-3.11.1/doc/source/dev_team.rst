========================
PyTables Governance Team
========================

The PyTables team includes:

* Francesc Alted
* Ivan Vilata
* Scott Prater
* Vicent Mas
* Tom Hedley
* `Antonio Valentino`_
* Jeffrey Whitaker
* `Josh Moore`_
* `Anthony Scopatz`_
* `Andrea Bedini`_
* `Tom Kooij`_
* `Javier Sancho`_

.. _Anthony Scopatz: https://github.com/scopatz
.. _Antonio Valentino: https://github.com/avalentino
.. _Josh Moore: https://github.com/joshmoore
.. _Andrea Bedini: https://github.com/andreabedini
.. _Tom Kooij: https://github.com/tomkooij
.. _Javier Sancho: https://en.jsancho.org/
