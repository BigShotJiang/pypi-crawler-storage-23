.. _agave-renderer-label:

AgaveRenderer
-------------

.. autoclass:: agave_pyclient.agave.AgaveRenderer
   :members:
