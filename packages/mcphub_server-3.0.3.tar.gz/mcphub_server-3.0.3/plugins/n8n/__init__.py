"""n8n Automation Plugin - Workflow Management"""

from plugins.n8n.client import N8nClient
from plugins.n8n.plugin import N8nPlugin

__all__ = ["N8nPlugin", "N8nClient"]
