"""JavaScript language extractor."""

from __future__ import annotations

from .extractor import JavaScriptExtractor

__all__ = ["JavaScriptExtractor"]
