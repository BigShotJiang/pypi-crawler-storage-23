"""LLM-based parser for .shotgun/tasks.md files.

Uses a fast sub-agent model (like Haiku) with structured output to parse
tasks.md files more flexibly than regex patterns.
"""

import logging
from pathlib import Path

from pydantic_ai import Agent

from shotgun.agents.autopilot.models import (
    ParsedTasksOutput,
    Stage,
    StageStatus,
    Task,
)
from shotgun.agents.autopilot.tasks_parser import (
    ParsedTasksFile,
    merge_stages_with_parsed_tasks,
)
from shotgun.agents.config import get_provider_model

logger = logging.getLogger(__name__)


PARSER_SYSTEM_PROMPT = """You are a markdown parser that extracts stages and tasks from a tasks.md file.

Your job is to:
1. Find all stages in the document (usually marked with ## Stage N: or ### Stage N: headers)
2. For each stage, extract any "Depends on:" line listing stage dependencies
3. For each stage, extract all tasks (checkbox items like - [ ] or - [x])
4. Return structured data with stages, their dependencies, and their tasks

Rules:
- A stage header contains "Stage" followed by an identifier (numeric like 1, 2, 3 or alphanumeric like A, 1a, 2b) and a name
- The stage identifier should be extracted exactly as written (preserve letters, numbers, and case)
- A "Depends on:" line may appear after the stage header, listing stage identifiers (e.g. "Depends on: Stage 1, Stage 3")
- Extract only the stage identifiers from depends_on (e.g. ["1", "3"]), not the word "Stage"
- If no "Depends on:" line exists, or it says "None", depends_on should be an empty list
- Tasks are checkbox items: - [ ] means incomplete, - [x] or - [X] means complete
- Only extract actual tasks (checkboxes), not other bullet points or text
- Preserve the exact task text after the checkbox
- Stages should be in the order they appear in the document
- Ignore any content that isn't a stage header, depends_on line, or task checkbox

Be precise and extract all stages and tasks from the document."""


class LLMTasksParser:
    """LLM-based parser for tasks.md files.

    Uses a fast model with structured output for flexible parsing.
    """

    def __init__(self, working_directory: Path | None = None):
        """Initialize the parser.

        Args:
            working_directory: Base directory for resolving relative paths.
        """
        self.working_directory = working_directory or Path.cwd()
        self._agent: Agent[None, ParsedTasksOutput] | None = None

    async def _get_agent(self) -> Agent[None, ParsedTasksOutput]:
        """Get or create the parsing agent.

        Uses a fast sub-agent model for efficient parsing.
        """
        if self._agent is not None:
            return self._agent

        # Get a sub-agent model (cheaper/faster) with API key already configured
        try:
            model_config = await get_provider_model(for_sub_agent=True)
            model_instance = model_config.model_instance
            logger.debug("Using model for LLM parsing: %s", model_config.name)

        except Exception as e:
            logger.exception("Could not get model config for LLM parser")
            raise RuntimeError(f"Failed to initialize LLM parser: {e}") from e

        self._agent = Agent(
            model_instance,
            output_type=ParsedTasksOutput,
            system_prompt=PARSER_SYSTEM_PROMPT,
            retries=2,
        )

        return self._agent

    async def parse(
        self, file_path: str | Path = ".shotgun/tasks.md"
    ) -> ParsedTasksFile:
        """Parse a tasks.md file using the LLM.

        Args:
            file_path: Path to the tasks.md file (relative or absolute).

        Returns:
            ParsedTasksFile with stages and any parse errors.
        """
        # Resolve the file path
        if isinstance(file_path, str):
            file_path = Path(file_path)

        if not file_path.is_absolute():
            file_path = self.working_directory / file_path

        result = ParsedTasksFile(file_path=str(file_path))

        # Check if file exists
        if not file_path.exists():
            result.parse_errors.append(f"File not found: {file_path}")
            return result

        # Read the file content
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            result.parse_errors.append(f"Error reading file: {e}")
            return result

        # Parse using LLM
        try:
            result.stages = await self._parse_content(content)
        except Exception as e:
            logger.exception("LLM parsing failed")
            result.parse_errors.append(f"LLM parsing error: {e}")

        return result

    async def _parse_content(self, content: str) -> list[Stage]:
        """Parse content using the LLM.

        Args:
            content: The file content to parse.

        Returns:
            List of parsed Stage objects.
        """
        agent = await self._get_agent()

        # Run the agent with the content
        result = await agent.run(
            f"Parse the following tasks.md file and extract all stages and tasks:\n\n{content}"
        )

        # Convert to Stage objects
        stages: list[Stage] = []
        for parsed_stage in result.output.stages:
            tasks = [
                Task(
                    text=task.text,
                    completed=task.completed,
                    line_number=0,  # LLM doesn't track line numbers
                )
                for task in parsed_stage.tasks
            ]

            stage = Stage(
                number=parsed_stage.number,
                name=parsed_stage.name,
                depends_on=parsed_stage.depends_on,
                tasks=tasks,
                status=StageStatus.PENDING,
            )
            stages.append(stage)

        logger.info(
            "LLM parser found %d stages with %d total tasks",
            len(stages),
            sum(len(s.tasks) for s in stages),
        )

        return stages

    async def parse_content(self, content: str) -> ParsedTasksFile:
        """Parse tasks.md content directly (for testing).

        Args:
            content: The markdown content to parse.

        Returns:
            ParsedTasksFile with stages and any parse errors.
        """
        result = ParsedTasksFile(file_path="<string>")

        try:
            result.stages = await self._parse_content(content)
        except Exception as e:
            logger.exception("LLM parsing failed")
            result.parse_errors.append(f"LLM parsing error: {e}")

        return result

    async def refresh_stages(
        self,
        state_stages: list[Stage],
        file_path: str | Path = ".shotgun/tasks.md",
        claude_output: str | None = None,
    ) -> list[Stage]:
        """Re-parse the file using LLM and update task completion status.

        This is used after Claude Code runs to verify which tasks were completed.
        Uses the LLM parser for flexible parsing of any tasks.md format.

        Args:
            state_stages: Existing stages from AutopilotState.
            file_path: Path to the tasks.md file.
            claude_output: Optional final output from Claude Code for context.

        Returns:
            Updated list of stages with refreshed task completion status.
        """
        # Resolve the file path
        if isinstance(file_path, str):
            file_path = Path(file_path)

        if not file_path.is_absolute():
            file_path = self.working_directory / file_path

        # Read the file content
        if not file_path.exists():
            logger.warning(
                "tasks.md not found at %s, keeping original stages", file_path
            )
            return state_stages

        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception:
            logger.exception("Failed to read tasks.md for refresh")
            return state_stages

        # Build prompt with context
        prompt_parts = [
            "Parse the following tasks.md file and extract all stages and tasks.",
            "Pay close attention to which tasks are marked complete [x] vs incomplete [ ].",
            "",
            "## tasks.md content:",
            content,
        ]

        # Add Claude's output as context if available
        if claude_output:
            prompt_parts.extend(
                [
                    "",
                    "## Context from Claude Code's final output:",
                    "(Use this to help understand which tasks were completed)",
                    claude_output[:2000],  # Limit to avoid token issues
                ]
            )

        prompt = "\n".join(prompt_parts)

        # Parse using LLM
        try:
            agent = await self._get_agent()
            result = await agent.run(prompt)
            parsed_stages = result.output.stages
        except Exception:
            logger.exception("LLM refresh parsing failed")
            return state_stages

        logger.info(
            "LLM refresh: parsed %d stages from tasks.md",
            len(parsed_stages),
        )

        # Convert ParsedStage objects to Stage objects
        converted_stages = [
            Stage(
                number=ps.number,
                name=ps.name,
                depends_on=ps.depends_on,
                tasks=[
                    Task(text=t.text, completed=t.completed, line_number=0)
                    for t in ps.tasks
                ],
                status=StageStatus.PENDING,
            )
            for ps in parsed_stages
        ]

        # Use shared utility to merge with state stages
        return merge_stages_with_parsed_tasks(state_stages, converted_stages)
