"""CLI module for review-classification."""

from .app import app

__all__ = ["app"]
