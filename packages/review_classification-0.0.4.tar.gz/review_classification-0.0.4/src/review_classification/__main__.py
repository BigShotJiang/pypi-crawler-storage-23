"""Allows the package to be run as python -m review_classification."""

from .main import main

main()
