# django-tasks-inprocess

[![PyPI - Version](https://img.shields.io/pypi/v/django-tasks-inprocess.svg)](https://pypi.org/project/django-tasks-inprocess)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/django-tasks-inprocess.svg)](https://pypi.org/project/django-tasks-inprocess)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install django-tasks-inprocess
```

## License

`django-tasks-inprocess` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
