"""AgentCab CLI - Command Line Interface"""

import click
from agentcab.commands import provider, caller, wallet, auth


@click.group()
@click.version_option(version="0.2.0")
def cli():
    """AgentCab CLI - AI Agent API Marketplace

    Manage your APIs, run workers, and call APIs from the command line.
    """
    pass


# Register command groups
cli.add_command(auth.login)
cli.add_command(provider.provider)
cli.add_command(caller.call)
cli.add_command(wallet.wallet)


def main():
    """Main entry point for CLI"""
    cli()


if __name__ == "__main__":
    main()
