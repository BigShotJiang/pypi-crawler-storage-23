"""AgentCab Caller SDK"""

import time
import logging
from typing import Optional, Dict, Any, List

from .client import BaseClient
from .types import Skill, Call
from .exceptions import AgentCabError, TimeoutError as SDKTimeoutError


logger = logging.getLogger(__name__)


class CallerClient(BaseClient):
    """Client for Caller operations (call APIs, check status, etc.)"""

    def list_apis(
        self,
        query: Optional[str] = None,
        category: Optional[str] = None,
        status: str = "active",
        sort_by: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List available APIs

        Args:
            query: Search query for API name/description
            category: Filter by category
            status: Filter by status (default: "active")
            sort_by: Sort order - "popular", "newest", "price_low", "price_high", "rating"
            page: Page number (default: 1)
            page_size: Items per page (default: 20)

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {
            "q": query,
            "category": category,
            "status_filter": status,
            "sort_by": sort_by,
            "page": page,
            "page_size": page_size,
        }
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        return self.get("/skills", params=params)

    def get_api(self, api_id: str) -> Skill:
        """Get API details"""
        return self.get(f"/skills/{api_id}")

    def call_api(
        self,
        api_id: str,
        input: Dict[str, Any],
        max_cost: Optional[int] = None,
        wait: bool = False,
        wait_timeout: int = 60,
        poll_interval: int = 2,
    ) -> Call:
        """
        Call an API

        Args:
            api_id: API ID to call
            input: Input data for the API
            max_cost: Maximum credits willing to pay (optional)
            wait: Whether to wait for result (default: False)
            wait_timeout: Maximum seconds to wait for result (default: 60)
            poll_interval: Seconds between status checks (default: 2)

        Returns:
            Call object with status and output (if wait=True and completed)
        """
        payload = {"input": input}
        if max_cost is not None:
            payload["max_cost"] = max_cost

        result = self.post(f"/skills/{api_id}/call", json=payload)

        if not wait:
            return result

        # Wait for result
        call_id = result["call_id"]
        start_time = time.time()

        while time.time() - start_time < wait_timeout:
            call = self.get_call(call_id)

            if call["status"] in ["success", "failed", "timeout"]:
                return call

            time.sleep(poll_interval)

        raise SDKTimeoutError(f"Call {call_id} did not complete within {wait_timeout}s")

    def call_api_sync(
        self,
        api_id: str,
        input: Dict[str, Any],
        max_cost: Optional[int] = None,
        timeout: int = 60,
        poll_interval: int = 2,
    ) -> Call:
        """
        Call an API and wait for result (synchronous)

        This is a convenience method that calls call_api with wait=True.

        Args:
            api_id: API ID to call
            input: Input data for the API
            max_cost: Maximum credits willing to pay (optional)
            timeout: Maximum seconds to wait for result (default: 60)
            poll_interval: Seconds between status checks (default: 2)

        Returns:
            Call object with status and output
        """
        return self.call_api(
            api_id=api_id,
            input=input,
            max_cost=max_cost,
            wait=True,
            wait_timeout=timeout,
            poll_interval=poll_interval,
        )

    def get_call(self, call_id: str) -> Call:
        """Get call status and result"""
        return self.get(f"/calls/{call_id}")

    def list_my_calls(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        List my calls

        Returns:
            {
                "items": [...],
                "page": 1,
                "page_size": 20,
                "total": 100
            }
        """
        params = {"page": page, "page_size": page_size}
        return self.get("/calls", params=params)

    def get_wallet(self) -> Dict[str, Any]:
        """Get wallet balance"""
        return self.get("/wallet")

    def list_transactions(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        List wallet transactions

        Returns:
            List of transaction objects
        """
        return self.get("/wallet/transactions", params={"page": page, "page_size": page_size})

    @classmethod
    def from_credentials(
        cls,
        email: str,
        password: str,
        base_url: str = "https://www.agentcab.ai/v1",
    ) -> "CallerClient":
        """
        Create client from email/password credentials

        This will login and retrieve the API key.
        Note: Using API key directly is recommended for security.
        """
        import requests

        # Login to get token
        response = requests.post(
            f"{base_url}/auth/login",
            json={"email": email, "password": password}
        )
        response.raise_for_status()
        token = response.json()["data"]["access_token"]

        # Get user info to retrieve API key
        response = requests.get(
            f"{base_url}/auth/me",
            headers={"Authorization": f"Bearer {token}"}
        )
        response.raise_for_status()
        user_data = response.json()["data"]

        # Use API key if available, otherwise use token
        api_key = user_data.get("api_key_hash") or token

        return cls(api_key=api_key, base_url=base_url)
