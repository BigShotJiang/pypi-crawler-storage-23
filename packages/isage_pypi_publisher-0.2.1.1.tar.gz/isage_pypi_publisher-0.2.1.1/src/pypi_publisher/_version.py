"""Version information for pypi-publisher."""

__version__ = "0.2.1.1"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
