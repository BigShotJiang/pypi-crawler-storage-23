"""Thin shim for editable installs."""
from setuptools import setup

setup()
