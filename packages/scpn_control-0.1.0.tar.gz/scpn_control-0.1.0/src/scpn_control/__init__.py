"""scpn-control: Neuro-symbolic Stochastic Petri Net controller."""
__version__ = "0.1.0"
