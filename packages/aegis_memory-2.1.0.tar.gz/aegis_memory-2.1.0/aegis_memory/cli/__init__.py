"""
Aegis Memory CLI

Terminal-first interface for Aegis Memory operations.
"""

from aegis_memory.cli.main import app

__all__ = ["app"]
