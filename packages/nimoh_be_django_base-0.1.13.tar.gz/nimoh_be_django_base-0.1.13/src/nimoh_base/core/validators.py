"""
Custom validators.

This module provides security-focused validators including:
- Breached password checking against known compromised passwords
- JSON content validation to prevent XSS attacks
- Additional security validations
"""

import hashlib
import logging
import re
from typing import Any

import requests
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import gettext as _

logger = logging.getLogger(__name__)


class BreachedPasswordValidator:
    """
    Validate passwords against known data breaches using the HaveIBeenPwned API.

    Uses k-anonymity model - only sends first 5 chars of SHA-1 hash to API,
    which returns all matching hashes. We check locally for full match.
    """

    def __init__(self, threshold: int = 1):
        """
        Initialize validator.

        Args:
            threshold: Minimum breach count to reject (default: 1, reject any breach)
        """
        self.threshold = threshold
        self.api_url = "https://api.pwnedpasswords.com/range/"

    def validate(self, password: str, user=None):
        """
        Validate password has not been breached.

        Args:
            password: The password to validate
            user: Optional user instance (not used)

        Raises:
            ValidationError: If password found in breach database
        """
        # Hash the password
        # Note: SHA1 is required by HIBP API, not used for security
        sha1_hash = hashlib.sha1(password.encode("utf-8"), usedforsecurity=False).hexdigest().upper()
        prefix = sha1_hash[:5]
        suffix = sha1_hash[5:]

        try:
            # Query API with first 5 chars
            user_agent = getattr(settings, "NIMOH_BASE", {}).get(
                "PASSWORD_CHECKER_USER_AGENT", "Django-Password-Validator"
            )
            response = requests.get(f"{self.api_url}{prefix}", timeout=2, headers={"User-Agent": user_agent})

            if response.status_code == 200:
                # Check if our password hash suffix is in the results
                for line in response.text.splitlines():
                    hash_suffix, count = line.split(":")
                    if hash_suffix == suffix:
                        breach_count = int(count)
                        if breach_count >= self.threshold:
                            logger.warning(
                                f"Password found in {breach_count} breaches", extra={"breach_count": breach_count}
                            )
                            raise ValidationError(
                                _(
                                    "This password has been found in %(count)d data breaches. "
                                    "Please choose a different password."
                                ),
                                code="breached_password",
                                params={"count": breach_count},
                            )

            # Password not found in breaches or API error - allow it
            # (fail open for availability)

        except requests.RequestException as e:
            # Log error but don't block registration if API is down
            logger.warning(f"Failed to check password against breach database: {e}", extra={"error": str(e)})
            # Fail open - don't block user if API is unavailable

    def get_help_text(self):
        """Return help text for this validator."""
        return _("Your password must not have been previously exposed in a data breach.")


class JSONContentValidator:
    """
    Validator for JSON fields to prevent XSS and injection attacks.

    Scans JSON content for potentially malicious patterns including:
    - Script tags and event handlers
    - Data URIs with JavaScript
    - Suspicious HTML content
    """

    # Patterns that indicate potential XSS
    XSS_PATTERNS = [
        re.compile(r"<script[^>]*>.*?</script>", re.IGNORECASE | re.DOTALL),
        re.compile(r"javascript:", re.IGNORECASE),
        re.compile(r"on\w+\s*=", re.IGNORECASE),  # Event handlers
        re.compile(r"data:text/html", re.IGNORECASE),
        re.compile(r"<iframe", re.IGNORECASE),
        re.compile(r"<embed", re.IGNORECASE),
        re.compile(r"<object", re.IGNORECASE),
    ]

    @classmethod
    def validate_json_content(cls, value: Any, field_name: str = "field") -> None:
        """
        Validate JSON content for XSS patterns.

        Args:
            value: The value to validate (dict, list, or primitive)
            field_name: Name of the field being validated (for error messages)

        Raises:
            ValidationError: If suspicious content detected
        """
        if value is None:
            return

        # Convert to string for pattern matching
        if isinstance(value, dict):
            content_str = cls._dict_to_string(value)
        elif isinstance(value, list):
            content_str = cls._list_to_string(value)
        else:
            content_str = str(value)

        # Check for XSS patterns
        for pattern in cls.XSS_PATTERNS:
            if pattern.search(content_str):
                logger.warning(
                    f"Potential XSS detected in {field_name}", extra={"pattern": pattern.pattern, "field": field_name}
                )
                raise ValidationError(
                    _(f"Invalid content detected in {field_name}. Please remove any script tags or event handlers."),
                    code="xss_detected",
                )

    @classmethod
    def _dict_to_string(cls, d: dict[str, Any]) -> str:
        """Recursively convert dict to string for scanning."""
        result = []
        for key, value in d.items():
            result.append(str(key))
            if isinstance(value, dict):
                result.append(cls._dict_to_string(value))
            elif isinstance(value, list):
                result.append(cls._list_to_string(value))
            else:
                result.append(str(value))
        return " ".join(result)

    @classmethod
    def _list_to_string(cls, lst: list) -> str:
        """Recursively convert list to string for scanning."""
        result = []
        for item in lst:
            if isinstance(item, dict):
                result.append(cls._dict_to_string(item))
            elif isinstance(item, list):
                result.append(cls._list_to_string(item))
            else:
                result.append(str(item))
        return " ".join(result)


def get_json_depth(data, depth=0):
    """
    Calculate depth of nested JSON structure.

    Canonical implementation — use this instead of per-model copies.

    Args:
        data: The JSON data (dict, list, or scalar).
        depth: Current recursion depth (internal use).

    Returns:
        int: Maximum nesting depth of the structure.
    """
    if not isinstance(data, (dict, list)):
        return depth
    if isinstance(data, dict):
        return max([get_json_depth(v, depth + 1) for v in data.values()] or [depth])
    return max([get_json_depth(item, depth + 1) for item in data] or [depth])


def validate_json_fields(instance, *field_specs):
    """Validate one or more JSON fields for XSS content and optional depth/size limits.

    Each *field_spec* is a tuple of ``(field_name,)`` or
    ``(field_name, max_depth)`` or ``(field_name, max_depth, max_items)``.

    * **XSS scan** — always applied via ``JSONContentValidator``.
    * **max_depth** — if given, raises ``ValidationError`` when the
      nesting depth exceeds the limit (only checked on ``dict`` values).
    * **max_items** — if given, raises ``ValidationError`` when a
      ``list`` or ``dict`` exceeds the item count.

    Usage in a model ``clean()`` method::

        from nimoh_base.core.validators import validate_json_fields

        def clean(self):
            validate_json_fields(
                self,
                ('metadata',),                          # XSS only
                ('status_codes', 3),                     # XSS + depth ≤ 3
                ('ministry_interests', None, 50),        # XSS + max 50 items
            )
    """
    from django.core.exceptions import ValidationError

    for spec in field_specs:
        field_name = spec[0]
        max_depth = spec[1] if len(spec) > 1 else None
        max_items = spec[2] if len(spec) > 2 else None
        value = getattr(instance, field_name)

        # XSS scan
        JSONContentValidator.validate_json_content(value, field_name)

        # Depth check
        if max_depth is not None and isinstance(value, dict):
            if get_json_depth(value) > max_depth:
                raise ValidationError(f"{field_name} JSON depth exceeds maximum of {max_depth} levels")

        # Size check (list or dict)
        if max_items is not None and isinstance(value, (list, dict)):
            if len(value) > max_items:
                raise ValidationError(f"{field_name} exceeds maximum of {max_items} items")


class PasswordComplexityValidator:
    """
    Validate password meets complexity requirements.

    Requires at least:
    - One uppercase letter
    - One lowercase letter
    - One digit
    - One special character
    """

    def validate(self, password: str, user=None):
        """
        Validate password complexity.

        Args:
            password: The password to validate
            user: Optional user instance (not used)

        Raises:
            ValidationError: If password doesn't meet complexity requirements
        """
        errors = []

        if not re.search(r"[A-Z]", password):
            errors.append(_("at least one uppercase letter"))

        if not re.search(r"[a-z]", password):
            errors.append(_("at least one lowercase letter"))

        if not re.search(r"\d", password):
            errors.append(_("at least one digit"))

        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            errors.append(_("at least one special character (!@#$%^&*...)"))

        if errors:
            raise ValidationError(
                _("Password must contain %(requirements)s."),
                code="password_complexity",
                params={"requirements": ", ".join(errors)},
            )

    def get_help_text(self):
        """Return help text for this validator."""
        return _(
            "Your password must contain at least one uppercase letter, "
            "one lowercase letter, one digit, and one special character."
        )
