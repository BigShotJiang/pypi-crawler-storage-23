"""
Enhanced startup logging for the application.

Provides user-friendly, informative startup messages showing:
- Server configuration
- Database connection status
- Redis connection status
- Environment information
"""

import logging
import sys

from django.conf import settings
from django.db import connection
from django.db.utils import DatabaseError, OperationalError

# Create a custom logger for startup
logger = logging.getLogger("startup")


class ColoredFormatter(logging.Formatter):
    """
    Colored formatter for terminal output with emojis.
    Makes logs more readable and visually appealing.
    """

    # ANSI color codes
    COLORS = {
        "DEBUG": "\033[37m",  # White
        "INFO": "\033[34m",  # Blue
        "WARNING": "\033[33m",  # Yellow
        "ERROR": "\033[31m",  # Red
        "CRITICAL": "\033[31m",  # Red
        "RESET": "\033[0m",  # Reset (White)
        "BOLD": "\033[1m",  # Bold
    }

    # Emojis for different log types
    EMOJIS = {
        "DEBUG": "🔍",
        "INFO": "✅",
        "WARNING": "⚠️",
        "ERROR": "❌",
        "CRITICAL": "🚨",
    }

    def format(self, record):
        """Format log record with colors and emojis."""
        levelname = record.levelname
        emoji = self.EMOJIS.get(levelname, "📝")
        color = self.COLORS.get(levelname, self.COLORS["RESET"])
        reset = self.COLORS["RESET"]
        bold = self.COLORS["BOLD"]

        # Format the message with color and emoji
        # Don't include reset in levelname so color applies to entire message
        record.levelname = f"{emoji} {bold}{levelname}"
        formatted = super().format(record)

        # Add color to the entire message and reset at the end
        return f"{color}{formatted}{reset}"


def setup_startup_logging():
    """Configure logging for startup messages."""
    startup_logger = logging.getLogger("startup")
    startup_logger.setLevel(logging.INFO)

    # Remove existing handlers
    startup_logger.handlers = []

    # Create console handler with colored formatter
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)

    # Always use colored formatter (works in Docker logs too)
    formatter = ColoredFormatter("%(levelname)s %(message)s")

    handler.setFormatter(formatter)
    startup_logger.addHandler(handler)
    startup_logger.propagate = False

    return startup_logger


def print_banner():
    """Print application banner."""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     🚀 Django Backend Application Starting...                ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(banner)


def check_database_connection():
    """
    Check database connection and log details.

    Returns:
        bool: True if database is connected, False otherwise
    """
    logger = logging.getLogger("startup")

    try:
        # Get database configuration
        db_config = settings.DATABASES["default"]
        db_name = db_config.get("NAME", "Unknown")
        db_host = db_config.get("HOST", "localhost")
        db_port = db_config.get("PORT", "5432")
        db_engine = db_config.get("ENGINE", "").split(".")[-1]

        logger.info(f"🔌 Attempting to connect to {db_engine.upper()} database...")
        logger.info(f"   Database: {db_name}")
        logger.info(f"   Host: {db_host}:{db_port}")

        # Test connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT version();")
            version = cursor.fetchone()[0]

        logger.info("✅ Database connected successfully!")
        logger.info(f"   Version: {version.split(',')[0]}")

        # Check if PostGIS is enabled
        if "postgis" in db_engine:
            try:
                with connection.cursor() as cursor:
                    cursor.execute("SELECT PostGIS_Version();")
                    postgis_version = cursor.fetchone()[0]
                    logger.info(f"   PostGIS: {postgis_version}")
            except DatabaseError as e:
                logger.debug(f"PostGIS not available: {e}")

        return True

    except OperationalError as e:
        logger.error("❌ Database connection failed!")
        logger.error(f"   Error: {e!s}")
        return False
    except (KeyError, TypeError, DatabaseError) as e:
        logger.error(f"❌ Unexpected database error: {e!s}")
        return False


def check_redis_connection():
    """
    Check Redis connection and log details for all Redis instances.

    Returns:
        bool: True if at least one Redis connection works, False otherwise
    """
    logger = logging.getLogger("startup")

    redis_instances = {}
    all_ok = True

    # Check Django Cache Redis
    try:
        redis_url = getattr(settings, "REDIS_URL", None)
        cache_backend = settings.CACHES.get("default", {}).get("BACKEND", "")

        if "redis" in cache_backend.lower() or redis_url:
            logger.info("🔌 Checking Django Cache Redis...")

            if redis_url:
                logger.info(f"   URL: {redis_url.split('@')[-1] if '@' in redis_url else redis_url}")

            # Test connection using direct Redis client to avoid django-redis compatibility issues
            from urllib.parse import urlparse

            import redis

            parsed = urlparse(redis_url) if redis_url else None
            if parsed:
                r = redis.Redis(
                    host=parsed.hostname or "localhost",
                    port=parsed.port or 6379,
                    db=int(parsed.path.lstrip("/")) if parsed.path else 1,
                    socket_connect_timeout=2,
                )
                r.ping()
                logger.info("✅ Django Cache Redis connected!")
                redis_instances["cache"] = True

                # Try to get Redis info
                try:
                    info = r.info()
                    logger.info(f"   Version: {info.get('redis_version', 'Unknown')}")
                    logger.info(f"   DB: {parsed.path.lstrip('/')}")
                except redis.RedisError as e:
                    logger.debug(f"Failed to get Redis info: {e}")
            else:
                logger.warning("⚠️  Redis URL not configured")
        else:
            logger.warning("⚠️  Redis cache not configured (using local cache)")

    except (redis.RedisError, ValueError) as e:
        logger.error("❌ Django Cache Redis failed!")
        logger.error(f"   Error: {e!s}")
        redis_instances["cache"] = False
        all_ok = False

    # Check Celery Broker Redis
    try:
        broker_url = getattr(settings, "CELERY_BROKER_URL", "")
        if "redis" in broker_url.lower():
            logger.info("")
            logger.info("🔌 Checking Celery Broker Redis...")
            logger.info(f"   URL: {broker_url.split('@')[-1] if '@' in broker_url else broker_url}")

            # Try to connect to broker Redis
            from urllib.parse import urlparse

            import redis

            parsed = urlparse(broker_url)
            r = redis.Redis(
                host=parsed.hostname or "localhost",
                port=parsed.port or 6379,
                db=int(parsed.path.lstrip("/")) if parsed.path else 0,
                socket_connect_timeout=2,
            )
            r.ping()
            logger.info("✅ Celery Broker Redis connected!")
            logger.info(f"   DB: {parsed.path.lstrip('/')}")
            redis_instances["broker"] = True
    except (redis.RedisError, ValueError) as e:
        logger.error("❌ Celery Broker Redis failed!")
        logger.error(f"   Error: {e!s}")
        redis_instances["broker"] = False
        all_ok = False

    # Check Celery Result Backend Redis
    try:
        result_backend = getattr(settings, "CELERY_RESULT_BACKEND", "")
        if "redis" in result_backend.lower() and result_backend != broker_url:
            logger.info("")
            logger.info("🔌 Checking Celery Result Backend Redis...")
            logger.info(f"   URL: {result_backend.split('@')[-1] if '@' in result_backend else result_backend}")

            from urllib.parse import urlparse

            parsed = urlparse(result_backend)
            r = redis.Redis(
                host=parsed.hostname or "localhost",
                port=parsed.port or 6379,
                db=int(parsed.path.lstrip("/")) if parsed.path else 0,
                socket_connect_timeout=2,
            )
            r.ping()
            logger.info("✅ Celery Result Backend Redis connected!")
            logger.info(f"   DB: {parsed.path.lstrip('/')}")
            redis_instances["result"] = True
    except (redis.RedisError, ValueError) as e:
        logger.error("❌ Celery Result Backend Redis failed!")
        logger.error(f"   Error: {e!s}")
        redis_instances["result"] = False

    # Summary
    if redis_instances:
        logger.info("")
        connected = sum(1 for v in redis_instances.values() if v)
        total = len(redis_instances)
        logger.info(f"📊 Redis Summary: {connected}/{total} instances connected")

    return all_ok or len([v for v in redis_instances.values() if v]) > 0


def check_celery_broker():
    """
    Check Celery broker connection.

    Returns:
        bool: True if broker is accessible, False otherwise
    """
    logger = logging.getLogger("startup")

    try:
        broker_url = getattr(settings, "CELERY_BROKER_URL", None)

        if not broker_url:
            logger.warning("⚠️  Celery broker not configured")
            return True

        logger.info("🔌 Checking Celery broker...")

        # Extract broker type and location
        if broker_url.startswith("redis://"):
            logger.info("   Type: Redis")
            logger.info(f"   URL: {broker_url.split('@')[-1] if '@' in broker_url else broker_url}")
        elif broker_url.startswith("amqp://"):
            logger.info("   Type: RabbitMQ")

        logger.info("✅ Celery broker configured")
        return True

    except Exception as e:
        logger.error(f"❌ Celery broker check failed: {e!s}")
        return False


def display_environment_info():
    """Display environment and configuration information."""
    logger = logging.getLogger("startup")

    logger.info("\n" + "=" * 60)
    logger.info("🔧 Environment Configuration")
    logger.info("=" * 60)

    # Django settings
    logger.info(f"   Environment: {getattr(settings, 'DJANGO_ENVIRONMENT', 'development').upper()}")
    logger.info(f"   Debug Mode: {'ON' if settings.DEBUG else 'OFF'}")
    logger.info(f"   Secret Key: {'Configured' if settings.SECRET_KEY else 'Missing!'}")

    # Installed apps count
    custom_apps = [app for app in settings.INSTALLED_APPS if app.startswith("apps.")]
    logger.info(f"   Custom Apps: {len(custom_apps)}")

    # Middleware count
    logger.info(f"   Middleware: {len(settings.MIDDLEWARE)} configured")

    # Static files
    logger.info(f"   Static URL: {settings.STATIC_URL}")
    logger.info(f"   Static Root: {settings.STATIC_ROOT}")

    # Media files
    logger.info(f"   Media URL: {settings.MEDIA_URL}")
    logger.info(f"   Media Root: {settings.MEDIA_ROOT}")

    logger.info("=" * 60 + "\n")


def display_server_info(host="0.0.0.0", port=8004):  # nosec B104 - Intentional for containerized deployment
    """
    Display server startup information.

    Args:
        host: Server host (0.0.0.0 for containerized deployment)
        port: Server port
    """
    logger = logging.getLogger("startup")

    logger.info("\n" + "=" * 60)
    logger.info("🚀 Server Starting")
    logger.info("=" * 60)
    logger.info(f"   Host: {host}")
    logger.info(f"   Port: {port}")
    logger.info(f"   URL: http://{host}:{port}")
    logger.info(f"   Admin: http://{host}:{port}/admin/")
    logger.info(f"   API Docs: http://{host}:{port}/api/docs/")
    logger.info("=" * 60 + "\n")


def run_startup_checks():
    """
    Run all startup checks and display comprehensive information.

    Returns:
        bool: True if all critical checks pass, False otherwise
    """
    # Setup logging
    setup_startup_logging()

    # Print banner
    print_banner()

    # Display environment info
    display_environment_info()

    # Run checks
    logger.info("🔍 Running startup checks...\n")

    db_ok = check_database_connection()
    logger.info("")  # Add spacing

    redis_ok = check_redis_connection()
    logger.info("")  # Add spacing

    celery_ok = check_celery_broker()
    logger.info("")  # Add spacing

    # Summary
    logger.info("=" * 60)
    if db_ok and redis_ok and celery_ok:
        logger.info("✅ All startup checks passed!")
    else:
        logger.warning("⚠️  Some startup checks failed")
        if not db_ok:
            logger.error("   - Database connection failed")
        if not redis_ok:
            logger.error("   - Redis connection failed")
        if not celery_ok:
            logger.error("   - Celery broker check failed")
    logger.info("=" * 60 + "\n")

    return db_ok  # Database is critical


def log_startup_complete(port=8004):
    """
    Log startup completion message.

    Args:
        port: Server port
    """
    logging.getLogger("startup")

    success_banner = f"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     ✅ Application Ready!                                    ║
║                                                              ║
║     🌐 Server listening on port {port}                         ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(success_banner)
