# GCPAgentCreationSource

Creation source for GCP-discovered agents.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'GCP']
**gcp_project_id** | **str** | GCP project ID | 
**gcp_region** | **str** | GCP region | 
**gcp_reasoning_engine_id** | **str** | GCP Vertex AI Reasoning Engine ID | 
**service_names** | **List[str]** | Service names associated with this agent | [optional] 

## Example

```python
from arthur_client.api_bindings.models.gcp_agent_creation_source import GCPAgentCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of GCPAgentCreationSource from a JSON string
gcp_agent_creation_source_instance = GCPAgentCreationSource.from_json(json)
# print the JSON string representation of the object
print(GCPAgentCreationSource.to_json())

# convert the object into a dict
gcp_agent_creation_source_dict = gcp_agent_creation_source_instance.to_dict()
# create an instance of GCPAgentCreationSource from a dict
gcp_agent_creation_source_from_dict = GCPAgentCreationSource.from_dict(gcp_agent_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


