# LLMModelResponse

Response model for an LLM model with assigned ID.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | ID of the LLM model entry. | 
**name** | **str** | Name of the LLM model. | 

## Example

```python
from arthur_client.api_bindings.models.llm_model_response import LLMModelResponse

# TODO update the JSON string below
json = "{}"
# create an instance of LLMModelResponse from a JSON string
llm_model_response_instance = LLMModelResponse.from_json(json)
# print the JSON string representation of the object
print(LLMModelResponse.to_json())

# convert the object into a dict
llm_model_response_dict = llm_model_response_instance.to_dict()
# create an instance of LLMModelResponse from a dict
llm_model_response_from_dict = LLMModelResponse.from_dict(llm_model_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


