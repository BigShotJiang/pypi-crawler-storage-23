# openentropy-tests

Statistical randomness test battery used by OpenEntropy.

Includes a NIST SP 800-22 inspired suite and quality scoring utilities.

## Install

```toml
[dependencies]
openentropy-tests = "0.7"
```

## Repository

https://github.com/amenti-labs/openentropy
