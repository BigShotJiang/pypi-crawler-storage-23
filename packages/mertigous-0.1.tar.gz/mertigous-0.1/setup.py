from setuptools import setup, find_packages

setup(
    name='mertigous',                    # Your package name
    version='0.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='Mert Erdem',                   # Your name
    author_email='turgaymerterdem@gmail.com',# Your email
    description='Hello World',
    url='https://github.com/turgaymerterdem/my_package', # Your project URL
)
