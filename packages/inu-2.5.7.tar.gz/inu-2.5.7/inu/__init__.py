from inu.inu import *
from inu.inu import __doc__
