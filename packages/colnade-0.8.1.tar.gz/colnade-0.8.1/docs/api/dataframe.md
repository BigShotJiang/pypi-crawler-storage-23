# colnade.dataframe

DataFrame, LazyFrame, GroupBy, JoinedDataFrame, and JoinedLazyFrame.

## DataFrame

::: colnade.dataframe.DataFrame

## LazyFrame

::: colnade.dataframe.LazyFrame

## GroupBy

::: colnade.dataframe.GroupBy

## LazyGroupBy

::: colnade.dataframe.LazyGroupBy

## JoinedDataFrame

::: colnade.dataframe.JoinedDataFrame

## JoinedLazyFrame

::: colnade.dataframe.JoinedLazyFrame

## concat

::: colnade.dataframe.concat
