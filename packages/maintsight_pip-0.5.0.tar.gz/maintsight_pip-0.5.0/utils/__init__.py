"""Utility modules for MaintSight."""

from utils.logger import Logger

__all__ = [
    "Logger",
]
