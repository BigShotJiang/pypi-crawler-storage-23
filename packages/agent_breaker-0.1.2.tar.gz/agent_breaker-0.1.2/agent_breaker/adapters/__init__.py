"""
Adapters for different agent frameworks.
"""
from agent_breaker.adapters.langgraph import LangGraphTarget

__all__ = ["LangGraphTarget"]
