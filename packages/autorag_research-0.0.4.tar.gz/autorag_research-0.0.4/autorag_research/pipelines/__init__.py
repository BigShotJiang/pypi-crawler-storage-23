from .retrieval import BM25RetrievalPipeline

__all__ = ["BM25RetrievalPipeline"]
