# SDK Behavior Matrix (Python)

## Canonical Methods
- Create contract/envelope: `gateway.cel.create_envelope(...)`
- Set counterparty: `gateway.cel.set_counterparty(contract_id, {"name"?, "email"?})`
- Raw action escape hatch: `gateway.cel.advanced_action(...)`

## Deprecated Aliases
- `gateway.cel.set_counterparties(...)` is deprecated and mapped to singular counterparty payload.

## Error Code Parity
- `TEMPLATE_NOT_ENABLED_FOR_PROJECT`
- `BAD_JSON`
- `UPSTREAM_ERROR`
- `NOT_FOUND`
- `UNKNOWN_ERROR`

## Behavior Notes
- History pending: `operator.history.get(envelope_id)` returns a normalized pending shape when backend omits `history`.
- Template enable: `enabled_by_actor_id` is optional; if set, it must be an active actor id.
- Counterparty action drift: prefer singular helper. Use `advanced_action` for backend-specific payloads.
