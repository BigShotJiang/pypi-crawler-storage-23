# senseid-definitions
Contains definitions shared between different SenseID repositories
