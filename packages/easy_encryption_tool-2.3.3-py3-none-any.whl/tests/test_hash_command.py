#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Hash 命令单元测试。
"""
from __future__ import annotations

import hashlib

import pytest

from .conftest import strip_ansi
from click.testing import CliRunner

from easy_encryption_tool import hash_command


runner = CliRunner()


class TestHashCommandSha256:
    """SHA256 算法测试"""

    def test_hash_plaintext(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "hello", "-a", "sha256"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha256(b"hello").hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out

    def test_hash_base64_input(self):
        import base64
        data = b"hello"
        b64 = base64.b64encode(data).decode("utf-8")
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", b64, "-e", "-a", "sha256"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha256(data).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out


class TestHashCommandSha384:
    """SHA384 算法测试"""

    def test_hash_sha384(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "data", "-a", "sha384"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha384(b"data").hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out


class TestHashCommandSha512:
    """SHA512 算法测试"""

    def test_hash_sha512(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "data", "-a", "sha512"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha512(b"data").hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out


class TestHashCommandSm3:
    """SM3 算法测试（需 easy_gmssl）"""

    @pytest.mark.skipif(
        not getattr(hash_command, "EASY_GMSSL_AVAILABLE", False),
        reason="easy_gmssl not installed",
    )
    def test_hash_sm3(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "hello", "-a", "sm3"],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "hash" in out


class TestHashCommandValidation:
    """Hash 命令参数验证"""

    def test_b64_and_file_mutually_exclusive(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "x", "-e", "-f"],
        )
        out = strip_ansi(result.output).lower()
        assert "mutually" in out and "exclusive" in out

    def test_invalid_utf8_plaintext(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "test", "-a", "sha256"],  # 使用有效输入，无效 UTF-8 行为依赖环境
        )
        assert result.exit_code == 0


class TestComputeHashFixed:
    """_compute_hash_fixed 内部逻辑：100% 覆盖所有算法"""

    def test_sha256_via_command(self):
        data = b"test"
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "test", "-a", "sha256"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha256(data).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out

    def test_compute_hash_fixed_sha256_direct(self):
        """直接调用 _compute_hash_fixed 验证 SHA256"""
        from easy_encryption_tool.hash_command import _compute_hash_fixed

        data = b"direct test"
        result = _compute_hash_fixed("sha256", data)
        assert result == hashlib.sha256(data).digest()

    def test_compute_hash_fixed_sha384_direct(self):
        """直接调用 _compute_hash_fixed 验证 SHA384"""
        from easy_encryption_tool.hash_command import _compute_hash_fixed

        data = b"data"
        result = _compute_hash_fixed("sha384", data)
        assert result == hashlib.sha384(data).digest()

    def test_compute_hash_fixed_sha512_direct(self):
        """直接调用 _compute_hash_fixed 验证 SHA512"""
        from easy_encryption_tool.hash_command import _compute_hash_fixed

        data = b"data"
        result = _compute_hash_fixed("sha512", data)
        assert result == hashlib.sha512(data).digest()


class TestHashFileMode:
    """Hash 文件模式"""

    def test_hash_file(self, tmp_file):
        content = b"file content"
        path = tmp_file(content)
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", path, "-f", "-a", "sha256"],
        )
        assert result.exit_code == 0
        expected = hashlib.sha256(content).hexdigest()
        out = strip_ansi(result.output)
        assert expected in out or expected[:40] in out

    @pytest.mark.skipif(
        not getattr(hash_command, "EASY_GMSSL_AVAILABLE", False),
        reason="easy_gmssl not installed",
    )
    def test_hash_file_sm3(self, tmp_file):
        content = b"file for sm3"
        path = tmp_file(content)
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", path, "-f", "-a", "sm3"],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "hash" in out

    def test_hash_nonexistent_file_fails(self):
        result = runner.invoke(
            hash_command.hash_command,
            ["-i", "/nonexistent/file.txt", "-f", "-a", "sha256"],
        )
        assert result.exit_code != 0 or "exist" in strip_ansi(result.output).lower() or "readable" in strip_ansi(result.output).lower()
