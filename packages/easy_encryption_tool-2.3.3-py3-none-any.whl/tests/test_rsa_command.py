#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
RSA 命令单元测试。
"""
from __future__ import annotations

import base64
import os
import tempfile

import pytest
from click.testing import CliRunner

from .conftest import strip_ansi
from easy_encryption_tool import rsa_command


runner = CliRunner()


@pytest.fixture
def rsa_key_pair(tmp_path):
    """生成 RSA 密钥对"""
    pub_path = tmp_path / "rsa_public.pem"
    pri_path = tmp_path / "rsa_private.pem"
    result = runner.invoke(
        rsa_command.generate_key_pair,
        [
            "-s", "2048",
            "-f", str(tmp_path / "demo"),
        ],
    )
    assert result.exit_code == 0
    pub = tmp_path / "demo_rsa_public.pem"
    pri = tmp_path / "demo_rsa_private.pem"
    assert pub.exists() and pri.exists()
    return str(pub), str(pri)


class TestRsaGenerate:
    """RSA 密钥生成"""

    def test_generate_key_pair(self, tmp_path):
        result = runner.invoke(
            rsa_command.generate_key_pair,
            ["-s", "2048", "-f", str(tmp_path / "test")],
        )
        assert result.exit_code == 0
        assert (tmp_path / "test_rsa_public.pem").exists()
        assert (tmp_path / "test_rsa_private.pem").exists()

    def test_generate_with_password(self, tmp_path):
        result = runner.invoke(
            rsa_command.generate_key_pair,
            [
                "-s", "2048", "-f", str(tmp_path / "pwd"),
                "-p", "mypassword",
            ],
        )
        assert result.exit_code == 0


class TestRsaEncryptDecrypt:
    """RSA 加解密"""

    def test_rsa_encrypt_via_cli(self, rsa_key_pair):
        pub_path, pri_path = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_encrypt,
            ["-f", pub_path, "-i", "hello", "-m", "oaep", "-a", "sha256"],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "cipher" in out.lower()

    def test_rsa_encrypt_pkcs1v15_via_cli(self, rsa_key_pair):
        pub_path, pri_path = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_encrypt,
            ["-f", pub_path, "-i", "short", "-m", "pkcs1v15"],
        )
        assert result.exit_code == 0

    def test_rsa_encrypt_invalid_b64_fails(self, rsa_key_pair):
        pub_path, _ = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_encrypt,
            ["-f", pub_path, "-i", "!!!invalid!!!", "-e", "-m", "oaep", "-a", "sha256"],
        )
        assert result.exit_code != 0 or "invalid" in result.output.lower()

    def test_rsa_encrypt_plain_too_long_fails(self, rsa_key_pair):
        pub_path, _ = rsa_key_pair
        long_plain = "x" * 300
        result = runner.invoke(
            rsa_command.rsa_encrypt,
            ["-f", pub_path, "-i", long_plain, "-m", "oaep", "-a", "sha256"],
        )
        assert result.exit_code != 0 or "exceeds" in result.output.lower()

    def test_rsa_decrypt_invalid_b64_fails(self, rsa_key_pair):
        _, pri_path = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_decrypt,
            ["-f", pri_path, "-i", "!!!invalid!!!", "-m", "oaep"],
        )
        assert result.exit_code != 0 or "invalid" in result.output.lower()

    def test_rsa_sign_via_cli(self, rsa_key_pair):
        pub_path, pri_path = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_sign,
            ["-f", pri_path, "-i", "message", "-m", "pss", "-a", "sha256"],
        )
        assert result.exit_code == 0
        out = strip_ansi(result.output)
        assert "signature" in out.lower()

    def test_rsa_sign_pkcs1v15(self, rsa_key_pair):
        pub_path, pri_path = rsa_key_pair
        result = runner.invoke(
            rsa_command.rsa_sign,
            ["-f", pri_path, "-i", "msg", "-m", "pkcs1v15", "-a", "sha256"],
        )
        assert result.exit_code == 0

    def test_encrypt_decrypt_roundtrip(self, rsa_key_pair):
        """RSA OAEP 加解密往返（使用 cryptography 直接验证）"""
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        pub_path, pri_path = rsa_key_pair
        with open(pub_path, "rb") as f:
            pub_key = serialization.load_pem_public_key(f.read())
        with open(pri_path, "rb") as f:
            pri_key = serialization.load_pem_private_key(f.read(), password=None)
        plain = b"hello"
        cipher = pub_key.encrypt(
            plain,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )
        import base64
        cipher_b64 = base64.b64encode(cipher).decode("utf-8")
        dec = runner.invoke(
            rsa_command.rsa_decrypt,
            ["-f", pri_path, "-i", cipher_b64, "-m", "oaep", "-a", "sha256"],
        )
        assert dec.exit_code == 0
        assert "hello" in dec.output or "plain" in dec.output.lower()

    def test_encrypt_pkcs1v15_decrypt(self, rsa_key_pair):
        """RSA PKCS1v15 加解密往返"""
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        pub_path, pri_path = rsa_key_pair
        with open(pub_path, "rb") as f:
            pub_key = serialization.load_pem_public_key(f.read())
        plain = b"short"
        cipher = pub_key.encrypt(plain, padding.PKCS1v15())
        import base64
        cipher_b64 = base64.b64encode(cipher).decode("utf-8")
        dec = runner.invoke(
            rsa_command.rsa_decrypt,
            ["-f", pri_path, "-i", cipher_b64, "-m", "pkcs1v15"],
        )
        assert dec.exit_code == 0


class TestRsaSignVerify:
    """RSA 签名验签"""

    def test_sign_verify_roundtrip(self, rsa_key_pair):
        """RSA 签名验签往返（使用 cryptography 生成签名，CLI 验签）"""
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        import base64
        pub_path, pri_path = rsa_key_pair
        with open(pri_path, "rb") as f:
            pri_key = serialization.load_pem_private_key(f.read(), password=None)
        with open(pub_path, "rb") as f:
            pub_key = serialization.load_pem_public_key(f.read())
        msg = b"message to sign"
        sig = pri_key.sign(
            msg,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH,
            ),
            hashes.SHA256(),
        )
        sig_b64 = base64.b64encode(sig).decode("utf-8")
        verify_result = runner.invoke(
            rsa_command.rsa_verify,
            [
                "-f", pub_path,
                "-i", "message to sign",
                "-s", sig_b64,
                "-m", "pss",
                "-a", "sha256",
            ],
        )
        assert verify_result.exit_code == 0
        assert '"valid"' in verify_result.output and "true" in verify_result.output.lower()

    def test_sign_verify_pkcs1v15_cli_roundtrip(self, rsa_key_pair):
        """RSA PKCS1v15 签名验签 CLI 往返"""
        pub_path, pri_path = rsa_key_pair
        sign_result = runner.invoke(
            rsa_command.rsa_sign,
            ["-f", pri_path, "-i", "msg", "-m", "pkcs1v15", "-a", "sha384"],
        )
        assert sign_result.exit_code == 0
        out = strip_ansi(sign_result.output)
        import re
        sig_match = re.search(r"[A-Za-z0-9+/]{40,}=*", out)
        assert sig_match
        sig_b64 = sig_match.group(0)
        verify_result = runner.invoke(
            rsa_command.rsa_verify,
            ["-f", pub_path, "-i", "msg", "-s", sig_b64, "-m", "pkcs1v15", "-a", "sha384"],
        )
        assert verify_result.exit_code == 0


class TestRsaHelperFunctions:
    """RSA 辅助函数"""

    def test_combine_if_not_empty(self):
        from easy_encryption_tool.rsa_command import combine_if_not_empty
        assert combine_if_not_empty("sha256", "oaep") == "oaep-sha256"
        assert combine_if_not_empty("", "oaep") == "oaep"

    def test_get_encryption_max_plain_length(self):
        from easy_encryption_tool.rsa_command import get_encryption_max_plain_length
        key_len = 256  # 2048 bits
        hash_len = 32  # SHA256
        assert get_encryption_max_plain_length("oaep", key_len, hash_len) == 190
        assert get_encryption_max_plain_length("pkcs1v15", key_len, 0) == 245

    def test_combine_if_not_empty_empty_hash(self):
        from easy_encryption_tool.rsa_command import combine_if_not_empty
        assert combine_if_not_empty("", "pkcs1v15") == "pkcs1v15"
