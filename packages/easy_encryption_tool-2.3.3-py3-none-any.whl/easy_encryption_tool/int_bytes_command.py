#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
整数与大小端十六进制字符串的双向转换。
"""
from __future__ import annotations

import time

import click

from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error


def _int_to_bytes_big_endian(n: int, width: int) -> bytes:
    """将整数转为大端序字节流，固定宽度。"""
    return n.to_bytes(width, byteorder="big", signed=False)


def _int_to_bytes_little_endian(n: int, width: int) -> bytes:
    """将整数转为小端序字节流，固定宽度。"""
    return n.to_bytes(width, byteorder="little", signed=False)


@click.group(name="int-to-bytes", short_help="Integer ↔ big/little endian hex")
def int_bytes_group():
    """整数与大小端十六进制字符串的双向转换。"""
    pass


@int_bytes_group.command(name="to-hex", short_help="Integer to big/little endian hex")
@click.option(
    "-i",
    "--input-data",
    "num_input",
    required=True,
    type=click.STRING,
    help="输入：非负整数或整数字符串",
)
@click.option(
    "-w",
    "--width",
    required=False,
    type=click.Choice(["4", "8", "16"]),
    default="8",
    show_default=True,
    help="字节宽度：4=32 位、8=64 位、16=128 位",
)
@output_format_options
def int_to_hex(
    num_input: str,
    width: str,
    output_format: str | None,
):
    """将整数转为字节流，同时展示大端序和小端序的 Hex 字符串。"""
    request_id = create_request_id()
    start = time.perf_counter()

    try:
        n = int(num_input.strip())
    except ValueError:
        error("输入必须是有效的整数")
        return

    if n < 0:
        error("暂不支持负数，请输入非负整数")
        return

    w = int(width)
    max_val = (1 << (w * 8)) - 1
    if n > max_val:
        error("数值 {} 超出 {} 字节可表示范围（0 ~ {}）".format(n, w, max_val))
        return

    be_bytes = _int_to_bytes_big_endian(n, w)
    le_bytes = _int_to_bytes_little_endian(n, w)
    big_endian_hex = be_bytes.hex()
    little_endian_hex = le_bytes.hex()

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="int-to-hex",
        algorithm="byte-order-convert",
        encoding="hex",
        input_type="text",
        input_size=0,
        parameters={"width_bytes": w, "input_value": n},
    )
    result = build_result(
        big_endian_hex=big_endian_hex,
        little_endian_hex=little_endian_hex,
        value=n,
    )
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )

    mode = resolve_output_format(output_format)
    if mode == "raw":
        print("big_endian:    {}".format(big_endian_hex))
        print("little_endian: {}".format(little_endian_hex))
        return

    render(output, mode=mode, primary_key="big_endian_hex")


@int_bytes_group.command(name="from-hex", short_help="Big/little endian hex to integer")
@click.option(
    "-i",
    "--input-data",
    "hex_input",
    required=True,
    type=click.STRING,
    help="输入：十六进制字符串（偶数长度，仅含 0-9a-fA-F）",
)
@click.option(
    "-e",
    "--byte-order",
    "byte_order",
    required=True,
    type=click.Choice(["big", "little"]),
    help="字节序：big=大端序、little=小端序",
)
@output_format_options
def hex_to_int(
    hex_input: str,
    byte_order: str,
    output_format: str | None,
):
    """将大小端十六进制字符串转换为整数。"""
    request_id = create_request_id()
    start = time.perf_counter()

    hex_clean = hex_input.strip().replace(" ", "").replace("\n", "").replace("\r", "")
    if len(hex_clean) % 2 != 0:
        error("Hex 字符串长度必须为偶数")
        return
    try:
        raw_bytes = bytes.fromhex(hex_clean)
    except ValueError as e:
        error("Hex 解码失败: {}".format(e))
        return

    n = int.from_bytes(raw_bytes, byteorder=byte_order, signed=False)
    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="hex-to-int",
        algorithm="byte-order-convert",
        encoding="utf-8",
        input_type="hex",
        input_size=len(hex_clean) // 2,
        parameters={"byte_order": byte_order, "input_hex": hex_clean},
    )
    result = build_result(value=n, byte_order=byte_order, input_hex=hex_clean)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )

    render(output, mode=resolve_output_format(output_format), primary_key="value")


if __name__ == "__main__":
    int_bytes_group()
