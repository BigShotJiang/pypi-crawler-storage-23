#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
秒级时间戳与带时区时间字符串的相互转换。
"""
from __future__ import annotations

import re
import time
from datetime import datetime, timezone, timedelta

import click

from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

# 北京时间 = UTC+8
BEIJING_TZ = timezone(timedelta(hours=8))

# 尝试使用 zoneinfo 支持 IANA 时区名（Python 3.9+）
try:
    from zoneinfo import ZoneInfo
    import zoneinfo as _zoneinfo_mod

    def _get_tz(name: str):
        return ZoneInfo(name)

    HAS_ZONEINFO = True
except ImportError:
    HAS_ZONEINFO = False

    def _get_tz(name: str):
        return None


def _resolve_timezone(tz_str: str):
    """
    解析时区字符串，返回 datetime.tzinfo。
    - 默认/Asia/Shanghai/Beijing -> UTC+8
    - +08:00, -05:00 等固定偏移
    - IANA 名如 America/New_York（需 Python 3.9+）
    """
    if not tz_str or tz_str.strip() == "":
        return BEIJING_TZ
    tz_str = tz_str.strip()
    # 别名
    if tz_str.lower() in ("beijing", "asia/shanghai", "shanghai", "cst"):
        return BEIJING_TZ
    # 固定偏移: +08:00, -05:30, +00:00
    m = re.match(r"^([+-])(\d{1,2}):(\d{2})$", tz_str)
    if m:
        sign = 1 if m.group(1) == "+" else -1
        h, mn = int(m.group(2)), int(m.group(3))
        return timezone(timedelta(hours=sign * h, minutes=sign * mn))
    # IANA 时区名
    if HAS_ZONEINFO:
        try:
            return ZoneInfo(tz_str)
        except Exception:
            pass
    return None


@click.group(name="ts", short_help="Timestamp conversion (seconds)")
def ts_group():
    """秒级时间戳与带时区时间字符串的相互转换。"""
    pass


@ts_group.command(name="to-datetime", short_help="Timestamp to datetime string")
@click.option(
    "-i",
    "--input-data",
    "ts_input",
    required=True,
    type=click.STRING,
    help="输入：秒级时间戳（整数或整数字符串）",
)
@click.option(
    "-z",
    "--timezone",
    "tz_str",
    required=False,
    type=click.STRING,
    default="Asia/Shanghai",
    show_default=True,
    help="时区：Asia/Shanghai、+08:00、America/New_York 等，默认为北京时间",
)
@output_format_options
def ts_to_datetime(ts_input: str, tz_str: str, output_format: str | None):
    """将秒级时间戳转换为带时区的时间字符串（ISO 8601 格式）。"""
    request_id = create_request_id()
    start = time.perf_counter()

    try:
        ts = int(ts_input.strip())
    except ValueError:
        error("输入必须是有效的整数时间戳")
        return

    if ts < 0:
        error("时间戳不能为负数")
        return
    # 合理范围：1970-2100
    if ts > 4102444800:  # 2100-01-01 00:00:00 UTC
        error("时间戳超出合理范围（建议 0 ~ 4102444800）")
        return

    tz = _resolve_timezone(tz_str)
    if tz is None:
        error("无法解析时区 '{}'，请使用 Asia/Shanghai、+08:00 或 IANA 时区名".format(tz_str))
        return

    dt = datetime.fromtimestamp(ts, tz=tz)
    value = dt.isoformat()
    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="ts-to-datetime",
        algorithm="timestamp-convert",
        encoding="utf-8",
        input_type="timestamp",
        input_size=0,
        parameters={"timezone": str(tz), "input_timestamp": ts},
    )
    result = build_result(value=value, timestamp=ts, timezone=str(tz))
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


@ts_group.command(name="to-ts", short_help="Datetime string to timestamp")
@click.option(
    "-i",
    "--input-data",
    "dt_input",
    required=True,
    type=click.STRING,
    help="输入：带时区的时间字符串（ISO 8601，如 2024-02-21T12:00:00+08:00）",
)
@click.option(
    "-z",
    "--timezone",
    "tz_str",
    required=False,
    type=click.STRING,
    default="Asia/Shanghai",
    show_default=True,
    help="当输入字符串无时区信息时使用的时区，默认为北京时间",
)
@output_format_options
def datetime_to_ts(dt_input: str, tz_str: str, output_format: str | None):
    """将带时区的时间字符串转换为秒级时间戳。若输入无时区则使用 -z 指定的时区。"""
    request_id = create_request_id()
    start = time.perf_counter()

    dt_input = dt_input.strip()
    tz = _resolve_timezone(tz_str)
    if tz is None:
        error("无法解析时区 '{}'，请使用 Asia/Shanghai、+08:00 或 IANA 时区名".format(tz_str))
        return

    # strptime %z 需要 +0800 格式，将 ISO 8601 的 +08:00 转为 +0800
    dt_normalized = re.sub(r"([+-])(\d{2}):(\d{2})$", r"\1\2\3", dt_input)

    # 尝试解析 ISO 8601 格式
    # 支持: 2024-02-21T12:00:00+08:00, 2024-02-21 12:00:00+0800, 2024-02-21T12:00:00
    for fmt in (
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%d %H:%M:%S%z",
        "%Y-%m-%d %H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
    ):
        try:
            dt = datetime.strptime(dt_normalized, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=tz)
            ts = int(dt.timestamp())
            break
        except ValueError:
            continue
    else:
        error("无法解析时间字符串 '{}'，请使用 ISO 8601 格式（如 2024-02-21T12:00:00+08:00）".format(dt_input))
        return

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="datetime-to-ts",
        algorithm="timestamp-convert",
        encoding="utf-8",
        input_type="text",
        input_size=len(dt_input),
        parameters={"timezone": str(tz), "output_timestamp": ts},
    )
    result = build_result(value=ts, timestamp=ts, datetime_str=dt_input)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


def _get_timezone_list():
    """获取可用的主要时区列表。有 zoneinfo 时使用主要时区；否则返回固定偏移。"""
    if not HAS_ZONEINFO:
        return [
            ("UTC", timezone(timedelta(0))),
            ("Asia/Shanghai (UTC+8)", BEIJING_TZ),
            ("UTC-05:00", timezone(timedelta(hours=-5))),
            ("UTC-08:00", timezone(timedelta(hours=-8))),
        ]
    result = []
    available = _zoneinfo_mod.available_timezones()
    major = [
        "Asia/Shanghai", "Asia/Hong_Kong", "Asia/Tokyo", "Asia/Seoul", "Asia/Singapore",
        "Asia/Bangkok", "Asia/Jakarta", "Asia/Kolkata", "Asia/Dubai", "Asia/Tehran",
        "Asia/Jerusalem", "Asia/Riyadh", "Asia/Kuala_Lumpur", "Asia/Manila",
        "Asia/Ho_Chi_Minh", "Asia/Taipei",
        "Europe/London", "Europe/Paris", "Europe/Berlin", "Europe/Moscow",
        "Europe/Amsterdam", "Europe/Rome", "Europe/Madrid", "Europe/Stockholm",
        "Europe/Zurich", "Europe/Athens", "Europe/Istanbul", "Europe/Warsaw",
        "Europe/Prague",
        "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles",
        "America/Toronto", "America/Vancouver", "America/Mexico_City", "America/Sao_Paulo",
        "America/Buenos_Aires", "America/Bogota", "America/Lima", "America/Santiago",
        "America/Caracas",
        "Pacific/Auckland", "Pacific/Sydney", "Pacific/Melbourne", "Pacific/Honolulu",
        "Pacific/Fiji", "Pacific/Guam",
        "UTC", "Africa/Cairo", "Africa/Johannesburg", "Africa/Lagos",
        "Australia/Perth", "Australia/Adelaide", "Australia/Brisbane",
    ]
    for name in sorted(major):
        if name in available:
            try:
                result.append((name, ZoneInfo(name)))
            except Exception:
                pass
    return sorted(result, key=lambda x: x[0])


@ts_group.command(name="list-timezones", short_help="List major timezones")
@click.option(
    "-i",
    "--input-data",
    "ts_input",
    required=False,
    type=click.STRING,
    default=None,
    help="可选：秒级时间戳，用于显示各时区当前时间；不指定则使用当前时间",
)
@output_format_options
def list_timezones(ts_input: str | None, output_format: str | None):
    """列出主要时区及其 UTC 偏移与当前时间。"""
    request_id = create_request_id()
    start = time.perf_counter()

    if ts_input is not None:
        try:
            ts = int(ts_input.strip())
        except ValueError:
            error("时间戳必须是有效整数")
            return
    else:
        ts = int(time.time())

    tz_list = _get_timezone_list()
    rows = []
    for name, tz in tz_list:
        dt = datetime.fromtimestamp(ts, tz=tz)
        offset = dt.strftime("%z")
        if offset:
            offset_str = "UTC{}{}:{}".format(
                "+" if offset[0] == "+" else "-",
                offset[1:3],
                offset[3:5],
            )
        else:
            offset_str = "UTC"
        rows.append({
            "timezone": name,
            "utc_offset": offset_str,
            "datetime": dt.isoformat(),
        })

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="list-timezones",
        algorithm="timezone-list",
        encoding="utf-8",
        input_type="timestamp" if ts_input else "current",
        input_size=0,
        parameters={"timestamp": ts, "count": len(rows)},
    )
    result = build_result(timezones=rows, count=len(rows))
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )

    mode = resolve_output_format(output_format)
    if mode == "raw":
        for r in rows:
            print("{}  {}  {}".format(r["timezone"].ljust(28), r["utc_offset"].ljust(9), r["datetime"]))
        return

    render(output, mode=mode, primary_key="timezones")


if __name__ == "__main__":
    ts_group()
