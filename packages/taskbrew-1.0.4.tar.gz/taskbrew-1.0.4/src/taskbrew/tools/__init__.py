"""Custom MCP tools for agents."""
