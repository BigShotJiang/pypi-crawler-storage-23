import __init__ # important to make easy_utils_dev importable
from flask import request
from easy_utils_dev import utils
from easy_utils_dev.uiserver import WebServer

server = WebServer(
    address='127.0.0.1',
    port=3001,
)

app = server.app

@app.route('/api/users' , methods=['GET'])
def _api_get_users():
    return server.Response.ok(users=[{'name': 'John Doe', 'age': 30}, {'name': 'Jane Doe', 'age': 25}])

@app.route('/api/checktoken' , methods=['GET'])
def api_checktoken():
    print(request.headers.get('Authorization'))
    return server.Response.ok()

@app.route('/api/notify' , methods=['GET'])
def api_notify_test():
    return server.Response.ok(toast=True , message=utils.getTimestamp())


if __name__ == "__main__":
    server.startUi(block=True)