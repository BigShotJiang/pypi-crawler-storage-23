# Add the parent directory to sys.path to allow importing easy_utils_dev
import sys , os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
