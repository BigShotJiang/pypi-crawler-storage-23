import threading
import ctypes
import time

class BgProcess(threading.Thread):
    def __init__(self, target=None, name=None, daemon=True, args=(), kwargs=None):
        """
        Initializes the BgProcess thread. By default, it sets the thread to be a daemon
        so that it doesn't block the main program from exiting.
        """
        super().__init__(target=target, name=name, daemon=daemon, args=args, kwargs=kwargs or {})

    def terminate(self):
        """
        Forcefully kills this thread using Windows API (TerminateThread).
        WARNING: This is very unsafe because it forcibly terminates the thread without
        allowing it to clean up resources, release locks, etc. 
        However, it achieves an immediate force-kill even during a deep sleep.
        """
        if not self.is_alive():
            return False

        native_id = self.native_id
        if native_id is None:
            return False

        if hasattr(self, 'ident') and self.ident is None:
            return False

        # Attempt OS-level thread termination
        success = False
        import sys
        if sys.platform == 'win32':
            # Windows API constant to terminate a thread
            THREAD_TERMINATE = 1
            
            try:
                # Open thread with THREAD_TERMINATE access right
                handle = ctypes.windll.kernel32.OpenThread(THREAD_TERMINATE, False, native_id)
                if handle:
                    # Terminate the thread abruptly (0 is the exit code)
                    success = bool(ctypes.windll.kernel32.TerminateThread(handle, 0))
                    ctypes.windll.kernel32.CloseHandle(handle)
            except AttributeError:
                pass
        else:
            # Linux/POSIX implementation using pthread_kill or pthread_cancel
            # Python threading.Thread.ident is the pthread_t ID on POSIX systems
            thread_id = ctypes.c_long(self.ident)
            try:
                import ctypes.util as cutil
                libc_path = cutil.find_library('c')
                if libc_path:
                    libc = ctypes.CDLL(libc_path)
                    res = libc.pthread_cancel(thread_id)
                    if res == 0:
                        success = True
            except Exception:
                pass
            
        if success:
            # Clean up the internal Python state so `is_alive()` works properly
            self.cleanup()
            return True
        else:
            return False

    def cleanup(self):
        """
        Checks if a forcefully terminated thread needs internal Python cleanup and performs it.
        When a thread is killed via the OS (TerminateThread), Python's internal thread
        state remains locked. This function manually unlocks the internal state so that
        `.is_alive()` and `.join()` function correctly.
        """
        needs_cleanup = False
        
        # Python 3.13+ uses _handle instead of _tstate_lock
        if hasattr(self, '_handle') and self._handle is not None:
            if not self._handle.is_done():
                needs_cleanup = True
                try:
                    if hasattr(self._handle, '_set_done'):
                        self._handle._set_done()
                except Exception:
                    pass
                    
        # Python 3.12 and below use _tstate_lock
        if hasattr(self, '_tstate_lock') and self._tstate_lock is not None:
            if self._tstate_lock.locked():
                needs_cleanup = True
                
                # Forcibly release the internal lock
                try:
                    self._tstate_lock.release()
                except Exception:
                    pass
                    
                # Manually mark the thread as stopped for older Python versions
                if hasattr(self, '_stop'):
                    self._stop()
                elif hasattr(self, '_is_stopped'):
                    self._is_stopped = True
            
        return needs_cleanup
