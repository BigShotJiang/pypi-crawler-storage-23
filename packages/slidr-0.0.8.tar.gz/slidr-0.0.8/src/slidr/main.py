"""Main entry point for the slidr CLI."""

from .cli import main

if __name__ == "__main__":
    import sys

    sys.exit(main())
