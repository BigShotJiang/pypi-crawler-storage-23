This module is a containers of migration script to migrate from 18.0 to
19.0 version.
