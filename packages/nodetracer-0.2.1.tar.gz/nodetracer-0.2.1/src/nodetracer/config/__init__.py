"""Configuration package — retained for backward compatibility."""
