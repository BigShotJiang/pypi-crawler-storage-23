from typing import Any, Dict
from ddans.descriptor.singleton import SingletonMeta


class SManager(metaclass=SingletonMeta):
    def __init__(self) -> None:
        super()
        self._data: Dict[str, Any] = {}

    def set_data(self, key: str, value: Any) -> None:
        self._data[key] = value

    def get_data(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def remove_data(self, key: str) -> None:
        if key in self._data:
            del self._data[key]

    def clear_data(self) -> None:
        self._data.clear()
