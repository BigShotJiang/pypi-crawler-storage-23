"""Domain module"""

from . import fconvert
from . import format
from . import regex

__all__ = ["fconvert", "format", "regex"]
