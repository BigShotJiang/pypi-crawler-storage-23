# -*- coding: utf-8 -*-
from typing import Literal


class DBField:

    def __init__(self,
                 field_type: Literal['INTEGER', 'TEXT', 'TIMESTAMP', 'LONG'],
                 primary_key=False,
                 nullable=True,
                 default=None,
                 autoincrement=False):
        self.field_type = field_type
        self.primary_key = primary_key
        self.nullable = nullable
        self.default = default if default is not None else "''" \
            if field_type == 'TEXT' else None
        self.autoincrement = autoincrement
