# -*- coding: utf-8 -*-
from ddans.dbase.dbase import DBase
from ddans.dbase.field import DBField


class DBTest(DBase):
    _fields = {**DBase._fields, 'admin_level': DBField('INTEGER', default=1)}
