"""Descriptor module"""

from . import singleton
from . import static

__all__ = [
    "singleton",
    "static",
]
