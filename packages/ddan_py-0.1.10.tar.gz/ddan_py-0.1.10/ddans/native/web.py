# -*- coding: utf-8 -*-
import urllib.request
import webbrowser
from ddans.native.hook import NHook
from ddans.native.system import NSystem
from ddans.native.url import NUrl


class NWeb:
    @staticmethod
    def get_proxies():
        return urllib.request.getproxies()

    @staticmethod
    def get_proxy(url: str = None):
        try:
            proxies = NWeb.get_proxies()
            if proxies is None:
                proxy = NSystem.get_proxy()
                if NHook.isvalid_str(proxy):
                    return f'http://{proxy}'
                return None
            scheme = "https"
            if NHook.isvalid_str(url):
                info = NUrl.url_parse(url)
                if info is not None:
                    scheme = info.scheme or "https"
            return proxies.get(scheme)
        except Exception:
            return None

    @staticmethod
    def open(url: str = None):
        try:
            if not NHook.isvalid_str(url):
                return False
            return webbrowser.open(url)
        except Exception:
            return False
