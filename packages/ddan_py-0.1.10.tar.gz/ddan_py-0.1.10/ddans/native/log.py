# -*- coding: utf-8 -*-
from ddans.data.color import DColor
from ddans.dfunc import prints
from ddans.domain.format import Format


class NLog():

    @staticmethod
    def log(*args):
        prints(Format.color_string(Format.date_tips(), *args))

    @staticmethod
    def debug(*args):
        prints(Format.color_string(Format.date_tips(), *args))

    @staticmethod
    def info(*args):
        prints(Format.color_string(Format.date_tips(), *args,
                                   fc=DColor.yellow))

    @staticmethod
    def warning(*args):
        prints(Format.color_string(Format.date_tips(), *args,
                                   fc=DColor.yellow))

    @staticmethod
    def error(*args):
        prints(Format.color_string(Format.date_tips(), *args, fc=DColor.red))

    @staticmethod
    def success(*args):
        prints(Format.color_string(Format.date_tips(), *args, fc=DColor.green))

    @staticmethod
    def printf(*args, fc: int = None, date=False):
        if date:
            prints(Format.date_desc(*args, fc=fc))
        else:
            prints(Format.desc(*args, fc=fc))

    @staticmethod
    def tips(*args, bc=DColor.bg_green, date=False):
        prints(Format.tips(*args, bc=bc, date=date))
