from setuptools import setup, find_packages

setup(
    name="ddan-py",
    version="0.1.10",
    packages=find_packages(),
    include_package_data=True,
    description="DDANs project library",
    long_description=open("README.md").read()
    if __name__ == "__main__" else "",
    long_description_content_type="text/markdown",
    author="yury",
    author_email="yry2580@qq.com",
    url="https://github.com/yry2580/ddan-tools",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pygtrans", "requests", "urllib3", "tqdm", "ffmpeg-python"
    ],
    extras_require={
        "test": [
            "pytest",
        ],
    },
)
