# knoteboard

**knoteboard** is a small command-line personal ticket management tool that
provides a Kanban-style board.

Upstream at: https://github.com/rmind/knoteboard

## Introduction

The tool is intended to be very minimalistic, but fast to operate.  It may
be used for **sticky notes** with reminders or it may be used as a basic
**Kanban-style board**.  It supports **Vi-style key bindings**.

## Usage

Local:
```shell
uv run python -m knoteboard
```
