from .lib import fastapi

from fastapi import * # type: ignore
