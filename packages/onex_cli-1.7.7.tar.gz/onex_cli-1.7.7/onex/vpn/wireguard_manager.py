"""
WireGuard VPN management operations
"""

import os
import subprocess
import re
from pathlib import Path
from typing import Optional, Dict
from .platform_detector import (
    detect_os,
    get_config_directory,
    get_install_command,
    check_wireguard_installed,
    check_homebrew_installed
)


class WireGuardError(Exception):
    """WireGuard operation error"""
    pass


def install_wireguard() -> bool:
    """
    Install WireGuard on the current system

    Returns:
        True if installed successfully or already installed

    Raises:
        WireGuardError: If installation fails
    """
    # Check if already installed
    if check_wireguard_installed():
        return True

    os_type = detect_os()

    if os_type == 'macos':
        # Check if Homebrew is installed
        if not check_homebrew_installed():
            raise WireGuardError(
                "Homebrew is not installed. "
                "Install from https://brew.sh/ and try again."
            )

        # Install via Homebrew
        try:
            result = subprocess.run(
                ['brew', 'install', 'wireguard-tools'],
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes
            )

            if result.returncode != 0:
                raise WireGuardError(f"Homebrew install failed: {result.stderr}")

            return True

        except subprocess.TimeoutExpired:
            raise WireGuardError("Installation timed out")
        except Exception as e:
            raise WireGuardError(f"Installation failed: {str(e)}")

    elif os_type == 'linux':
        # Installation command depends on distro
        install_cmd = get_install_command()

        try:
            # Run installation command
            result = subprocess.run(
                install_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes
            )

            if result.returncode != 0:
                raise WireGuardError(f"Installation failed: {result.stderr}")

            return True

        except subprocess.TimeoutExpired:
            raise WireGuardError("Installation timed out")
        except Exception as e:
            raise WireGuardError(f"Installation failed: {str(e)}")

    elif os_type == 'windows':
        raise WireGuardError(
            "WireGuard is not installed and automatic installation failed.\n"
            "Automatic installation on Windows is not supported.\n\n"
            "Please install WireGuard manually:\n"
            "1. Download WireGuard from: https://www.wireguard.com/install/\n"
            "2. Install the downloaded MSI package\n"
            "3. Open WireGuard GUI application\n"
            "4. Click 'Import tunnel(s) from file' and select your config file\n"
            "5. Click 'Activate' to connect\n\n"
            "After installation, run: onex init --skip-vpn\n"
            "(The CLI will detect your WireGuard connection automatically)"
        )

    return False


def decrypt_dpapi_config(dpapi_path: str) -> str:
    """
    Decrypt WireGuard DPAPI-encrypted config file (Windows only)

    WireGuard for Windows stores configs in DPAPI-encrypted format at:
    C:\\Program Files\\WireGuard\\Data\\Configurations\\*.conf.dpapi

    This function uses Windows CryptUnprotectData to decrypt the config.

    Args:
        dpapi_path: Path to .conf.dpapi file

    Returns:
        Decrypted config content as string

    Raises:
        WireGuardError: If decryption fails or not on Windows
    """
    os_type = detect_os()

    if os_type != 'windows':
        raise WireGuardError(
            "DPAPI decryption is only supported on Windows. "
            f"This appears to be a {os_type} system."
        )

    try:
        # Import win32crypt (only available on Windows)
        import win32crypt
    except ImportError:
        raise WireGuardError(
            "pywin32 package is required for DPAPI decryption on Windows.\n"
            "Install with: pip install pywin32"
        )

    if not os.path.exists(dpapi_path):
        raise WireGuardError(f"DPAPI config file not found: {dpapi_path}")

    try:
        # Read encrypted data
        with open(dpapi_path, 'rb') as f:
            encrypted_data = f.read()

        # Decrypt using Windows DPAPI
        # CryptUnprotectData returns (description, decrypted_data)
        _, decrypted_data = win32crypt.CryptUnprotectData(
            encrypted_data,
            None,  # Optional entropy (WireGuard doesn't use this)
            None,  # Reserved
            None,  # Reserved
            None,  # Prompt struct
            0      # Flags
        )

        # Convert bytes to string (WireGuard configs are UTF-8)
        config_content = decrypted_data.decode('utf-8')

        return config_content

    except PermissionError:
        raise WireGuardError(
            f"Permission denied reading DPAPI config file.\n"
            f"Path: {dpapi_path}\n\n"
            f"WireGuard stores configs with restricted permissions.\n"
            f"Try running as administrator or use a plain text config with --config-file."
        )
    except Exception as e:
        raise WireGuardError(
            f"Failed to decrypt DPAPI config file: {str(e)}\n"
            f"Path: {dpapi_path}\n\n"
            f"This may happen if:\n"
            f"  1. Config was encrypted by a different Windows user\n"
            f"  2. File is corrupted\n"
            f"  3. Not a valid DPAPI file\n\n"
            f"Alternative: Export plain text config from WireGuard GUI and use --config-file."
        )


def parse_config(config_path: str) -> Dict[str, str]:
    """
    Parse WireGuard config file to extract information

    Supports both plain text .conf files and DPAPI-encrypted .conf.dpapi files (Windows).

    Args:
        config_path: Path to config file (.conf or .conf.dpapi)

    Returns:
        Dict with 'vpn_ip', 'private_key', 'endpoint', etc.
        Also includes 'platform_credentials' dict if embedded in config comments

    Raises:
        WireGuardError: If config is invalid
    """
    if not os.path.exists(config_path):
        raise WireGuardError(f"Config file not found: {config_path}")

    config = {
        'vpn_ip': None,
        'private_key': None,
        'endpoint': None,
        'public_key': None,
        'allowed_ips': None,
        'platform_credentials': None
    }

    try:
        # Check if this is a DPAPI-encrypted config (Windows)
        if config_path.endswith('.dpapi'):
            # Decrypt DPAPI file first
            content = decrypt_dpapi_config(config_path)
        else:
            # Read plain text config
            with open(config_path, 'r') as f:
                content = f.read()

            # Extract VPN IP from Address
            address_match = re.search(r'Address\s*=\s*([0-9.]+)/\d+', content)
            if address_match:
                config['vpn_ip'] = address_match.group(1)

            # Extract Private Key
            privkey_match = re.search(r'PrivateKey\s*=\s*(\S+)', content)
            if privkey_match:
                config['private_key'] = privkey_match.group(1)

            # Extract Endpoint
            endpoint_match = re.search(r'Endpoint\s*=\s*(\S+)', content)
            if endpoint_match:
                config['endpoint'] = endpoint_match.group(1)

            # Extract Public Key
            pubkey_match = re.search(r'PublicKey\s*=\s*(\S+)', content)
            if pubkey_match:
                config['public_key'] = pubkey_match.group(1)

            # Extract Allowed IPs
            allowed_match = re.search(r'AllowedIPs\s*=\s*([^\n]+)', content)
            if allowed_match:
                config['allowed_ips'] = allowed_match.group(1).strip()

            # Extract platform credentials from comments (if present)
            # Format:
            # # ===== PLATFORM CREDENTIALS =====
            # # Email:       user@example.com
            # # Password:    securepassword
            # # Role:        DEVELOPER
            # # Platform:    http://10.0.0.1:8000 (requires VPN)
            # # Auth:        http://10.0.0.1:8100 (requires VPN)
            # # Public Auth: http://103.17.141.76:8100 (public access)
            # # ================================
            creds_section = re.search(
                r'#\s*=+\s*PLATFORM CREDENTIALS\s*=+\s*\n'
                r'#\s*Email:\s*(\S+)\s*\n'
                r'#\s*Password:\s*(\S+)\s*\n'
                r'#\s*Role:\s*(\S+)\s*\n'
                r'#\s*Platform:\s*(\S+)(?:\s*\(requires VPN\))?\s*\n'
                r'#\s*Auth:\s*(\S+)(?:\s*\(requires VPN\))?\s*\n'
                r'(?:#\s*Public Auth:\s*(\S+)(?:\s*\(public access\))?\s*\n)?',  # Optional public auth
                content
            )

            if creds_section:
                platform_url = creds_section.group(4)
                auth_url = creds_section.group(5)
                public_auth_url = creds_section.group(6) if len(creds_section.groups()) >= 6 else None

                # NOTE: Do NOT auto-generate public_auth_url from endpoint
                # If public auth is not explicitly configured in the VPN config, leave it None
                # This ensures the CLI uses the VPN auth service instead of trying to reach
                # the public endpoint which may not be available

                config['platform_credentials'] = {
                    'email': creds_section.group(1),
                    'password': creds_section.group(2),
                    'role': creds_section.group(3),
                    'platform_url': platform_url,  # Private URL (10.0.0.1:8000)
                    'auth_url': auth_url,  # Private URL (10.0.0.1:8100)
                    'public_auth_url': public_auth_url  # Only set if explicitly in config
                }

    except Exception as e:
        raise WireGuardError(f"Failed to parse config: {str(e)}")

    # Validate required fields
    if not config['vpn_ip']:
        raise WireGuardError("Config missing VPN IP address (Address field)")

    return config


def find_wireguard_gui_configs() -> list:
    """
    Find WireGuard GUI DPAPI-encrypted config files on Windows

    Returns:
        List of paths to .conf.dpapi files

    Raises:
        WireGuardError: If not on Windows
    """
    os_type = detect_os()

    if os_type != 'windows':
        return []

    # WireGuard GUI stores configs here
    config_dir = r'C:\Program Files\WireGuard\Data\Configurations'

    if not os.path.exists(config_dir):
        return []

    try:
        # Find all .conf.dpapi files
        import glob
        pattern = os.path.join(config_dir, '*.conf.dpapi')
        dpapi_files = glob.glob(pattern)
        return dpapi_files
    except Exception:
        return []


def import_config(config_path: str, interface_name: str) -> bool:
    """
    Import WireGuard config file

    Args:
        config_path: Path to config file
        interface_name: Interface name (e.g., 'wg-onex-dev')

    Returns:
        True if imported successfully

    Raises:
        WireGuardError: If import fails
    """
    # Parse and validate config first
    config = parse_config(config_path)

    os_type = detect_os()
    config_dir = get_config_directory()

    # Create config directory if it doesn't exist
    try:
        os.makedirs(config_dir, mode=0o755, exist_ok=True)
    except PermissionError:
        raise WireGuardError(
            f"Permission denied creating {config_dir}. Try running with sudo."
        )

    # Destination config file
    dest_config = os.path.join(config_dir, f"{interface_name}.conf")

    # Check if config already exists
    if os.path.exists(dest_config):
        print(f"ℹ️  Config already exists: {dest_config}")
        print(f"ℹ️  Replacing with new config...")

        # Remove existing config
        try:
            subprocess.run(
                ['sudo', 'rm', dest_config],
                check=True,
                capture_output=True,
                timeout=5
            )
        except subprocess.CalledProcessError as e:
            raise WireGuardError(f"Failed to remove existing config: {e.stderr}")
        except subprocess.TimeoutExpired:
            raise WireGuardError("Timeout removing existing config")

    # Copy config file
    try:
        # Read source config
        with open(config_path, 'r') as src:
            config_content = src.read()

        # Write to destination (requires sudo)
        if os_type in ['macos', 'linux']:
            print(f"ℹ️  Writing config to: {dest_config}")

            # Use sudo to write file
            process = subprocess.Popen(
                ['sudo', 'tee', dest_config],
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True
            )
            _, stderr = process.communicate(input=config_content)

            if process.returncode != 0:
                raise WireGuardError(f"Failed to write config: {stderr}")

            # Set correct permissions (600)
            subprocess.run(
                ['sudo', 'chmod', '600', dest_config],
                check=True,
                capture_output=True
            )

            # Verify file was created and is readable by wg-quick
            print(f"ℹ️  Verifying config is readable by wg-quick...")

            # Use full path for validation since interface name might not resolve immediately
            verify_result = subprocess.run(
                ['sudo', 'wg-quick', 'strip', dest_config],
                capture_output=True,
                text=True,
                timeout=10
            )

            if verify_result.returncode != 0:
                # Validation failed - provide diagnostics
                print(f"⚠️  wg-quick strip validation failed, checking file directly...")

                # Try to read the file directly to verify it exists and is valid
                try:
                    with open(dest_config, 'r') as f:
                        content = f.read()
                        if '[Interface]' in content and '[Peer]' in content:
                            # File exists and has basic WireGuard structure
                            print(f"✅ Config file exists and has valid structure")
                            print(f"ℹ️  Note: wg-quick validation skipped (may work during connection)")
                        else:
                            raise WireGuardError(
                                f"Config file created but appears invalid:\n"
                                f"  Path: {dest_config}\n"
                                f"  Missing [Interface] or [Peer] sections"
                            )
                except PermissionError:
                    # Can't read file (600 permissions), but it exists
                    print(f"✅ Config file created with restricted permissions (600)")
                    print(f"ℹ️  Note: File readable by root only (expected)")
                except Exception as e:
                    raise WireGuardError(
                        f"Config file validation failed:\n"
                        f"  Path: {dest_config}\n"
                        f"  wg-quick error: {verify_result.stderr}\n"
                        f"  File check error: {str(e)}"
                    )
            else:
                print(f"✅ Config validated successfully")

        elif os_type == 'windows':
            # Windows: WireGuard installation directory requires admin privileges
            # Guide users to import via GUI instead
            import shutil
            try:
                shutil.copy2(config_path, dest_config)
            except PermissionError:
                # Can't copy to Program Files - suggest GUI import
                raise WireGuardError(
                    f"Cannot import config automatically (requires admin privileges).\n\n"
                    f"Please import using WireGuard GUI:\n"
                    f"1. Open WireGuard application\n"
                    f"2. Click 'Import tunnel(s) from file'\n"
                    f"3. Select: {config_path}\n"
                    f"4. Click 'Activate' to connect\n\n"
                    f"After importing, run: onex init --skip-vpn\n"
                    f"(The CLI will detect your active WireGuard connection automatically)"
                )

        return True

    except subprocess.CalledProcessError as e:
        raise WireGuardError(f"Failed to import config: {e.stderr}")
    except subprocess.TimeoutExpired:
        raise WireGuardError("Timeout during config import")
    except PermissionError as e:
        # Windows permission error - already handled above, but catch any others
        raise WireGuardError(
            f"Permission denied. On Windows, please import via WireGuard GUI:\n"
            f"1. Open WireGuard application\n"
            f"2. Import tunnel(s) from file: {config_path}\n"
            f"3. Activate the connection\n"
            f"4. Run: onex init --skip-vpn"
        )
    except Exception as e:
        raise WireGuardError(f"Failed to import config: {str(e)}")


def connect(interface_name: str) -> bool:
    """
    Connect to WireGuard VPN

    Args:
        interface_name: Interface name (e.g., 'wg-onex-dev')

    Returns:
        True if connected successfully

    Raises:
        WireGuardError: If connection fails
    """
    os_type = detect_os()

    # Don't pre-check config file existence - let wg-quick search all standard locations:
    # /etc/wireguard, /usr/local/etc/wireguard, /opt/homebrew/etc/wireguard
    print(f"ℹ️  Connecting to VPN: {interface_name}")

    try:
        if os_type == 'macos':
            # macOS: Use wg-quick with interface name
            # wg-quick searches: /etc/wireguard, /usr/local/etc/wireguard, /opt/homebrew/etc/wireguard
            # Note: Interface name must use underscores (not hyphens) to follow Linux naming rules
            print(f"ℹ️  Executing: sudo wg-quick up {interface_name}")

            result = subprocess.run(
                ['sudo', 'wg-quick', 'up', interface_name],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode != 0:
                # Check if already connected
                if 'already exists' in result.stderr.lower():
                    print(f"ℹ️  VPN interface already exists (may already be connected)")
                    return True

                # Enhanced error message with diagnostics
                raise WireGuardError(
                    f"Connection failed:\n"
                    f"  Interface: {interface_name}\n"
                    f"  Error: {result.stderr.strip()}\n"
                    f"\n"
                    f"  Expected config locations:\n"
                    f"    • /etc/wireguard/{interface_name}.conf\n"
                    f"    • /usr/local/etc/wireguard/{interface_name}.conf\n"
                    f"    • /opt/homebrew/etc/wireguard/{interface_name}.conf\n"
                    f"\n"
                    f"  Troubleshooting:\n"
                    f"    • Check configs: ls -la /usr/local/etc/wireguard/{interface_name}.conf\n"
                    f"    • Validate config: sudo wg-quick strip {interface_name}\n"
                    f"    • Manual connection: sudo wg-quick up {interface_name}\n"
                    f"    • Check status: sudo wg show\n"
                )

        elif os_type == 'linux':
            # Linux: Use systemd
            print(f"ℹ️  Executing: sudo systemctl start wg-quick@{interface_name}")

            # Enable service
            subprocess.run(
                ['sudo', 'systemctl', 'enable', f'wg-quick@{interface_name}'],
                capture_output=True,
                timeout=10
            )

            # Start service
            result = subprocess.run(
                ['sudo', 'systemctl', 'start', f'wg-quick@{interface_name}'],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode != 0:
                # Check if already running
                status_result = subprocess.run(
                    ['sudo', 'systemctl', 'is-active', f'wg-quick@{interface_name}'],
                    capture_output=True,
                    text=True
                )
                if status_result.stdout.strip() == 'active':
                    print(f"ℹ️  VPN service already active")
                    return True

                # Enhanced error message with diagnostics
                raise WireGuardError(
                    f"Connection failed:\n"
                    f"  Interface: {interface_name}\n"
                    f"  Error: {result.stderr.strip()}\n"
                    f"\n"
                    f"  Troubleshooting:\n"
                    f"    • Check config: ls -la /etc/wireguard/{interface_name}.conf\n"
                    f"    • Check systemd status: sudo systemctl status wg-quick@{interface_name}\n"
                    f"    • Check logs: sudo journalctl -u wg-quick@{interface_name}\n"
                    f"    • Manual start: sudo systemctl start wg-quick@{interface_name}\n"
                )

        elif os_type == 'windows':
            raise WireGuardError(
                "Automatic connection on Windows is not supported.\n"
                "Please activate the tunnel using the WireGuard GUI app."
            )

        return True

    except subprocess.TimeoutExpired:
        raise WireGuardError("Connection timed out")
    except Exception as e:
        raise WireGuardError(f"Connection failed: {str(e)}")


def disconnect(interface_name: str) -> bool:
    """
    Disconnect from WireGuard VPN

    Args:
        interface_name: Interface name (e.g., 'wg-onex-dev')

    Returns:
        True if disconnected successfully

    Raises:
        WireGuardError: If disconnection fails
    """
    os_type = detect_os()
    config_dir = get_config_directory()
    config_file = os.path.join(config_dir, f"{interface_name}.conf")

    try:
        if os_type == 'macos':
            # macOS: Use wg-quick with interface name
            result = subprocess.run(
                ['sudo', 'wg-quick', 'down', interface_name],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode != 0:
                # Check if already disconnected
                if 'does not exist' in result.stderr.lower() or 'not found' in result.stderr.lower():
                    return True
                raise WireGuardError(f"Disconnection failed: {result.stderr}")

        elif os_type == 'linux':
            # Linux: Use systemd
            result = subprocess.run(
                ['sudo', 'systemctl', 'stop', f'wg-quick@{interface_name}'],
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode != 0:
                # Check if already stopped
                status_result = subprocess.run(
                    ['sudo', 'systemctl', 'is-active', f'wg-quick@{interface_name}'],
                    capture_output=True,
                    text=True
                )
                if status_result.stdout.strip() != 'active':
                    return True

                raise WireGuardError(f"Disconnection failed: {result.stderr}")

        elif os_type == 'windows':
            raise WireGuardError(
                "Automatic disconnection on Windows is not supported.\n"
                "Please deactivate the tunnel using the WireGuard GUI app."
            )

        return True

    except subprocess.TimeoutExpired:
        raise WireGuardError("Disconnection timed out")
    except Exception as e:
        raise WireGuardError(f"Disconnection failed: {str(e)}")


def get_status(interface_name: str) -> Optional[Dict[str, any]]:
    """
    Get WireGuard VPN status

    Args:
        interface_name: Interface name (e.g., 'wg-onex-dev')

    Returns:
        Dict with status info, or None if not connected
    """
    try:
        result = subprocess.run(
            ['sudo', 'wg', 'show', interface_name],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0:
            return None

        output = result.stdout

        # Parse output
        status = {
            'interface': interface_name,
            'connected': True,
            'public_key': None,
            'endpoint': None,
            'latest_handshake': None,
            'transfer': {'rx': 0, 'tx': 0}
        }

        # Extract public key
        pubkey_match = re.search(r'public key:\s*(\S+)', output)
        if pubkey_match:
            status['public_key'] = pubkey_match.group(1)

        # Extract endpoint
        endpoint_match = re.search(r'endpoint:\s*(\S+)', output)
        if endpoint_match:
            status['endpoint'] = endpoint_match.group(1)

        # Extract latest handshake
        handshake_match = re.search(r'latest handshake:\s*([^\n]+)', output)
        if handshake_match:
            status['latest_handshake'] = handshake_match.group(1).strip()

        # Extract transfer stats
        transfer_match = re.search(r'transfer:\s*([0-9.]+\s*\w+)\s+received,\s*([0-9.]+\s*\w+)\s+sent', output)
        if transfer_match:
            status['transfer']['rx'] = transfer_match.group(1)
            status['transfer']['tx'] = transfer_match.group(2)

        return status

    except:
        return None


def verify_connectivity(gateway_ip: str, timeout: int = 5) -> bool:
    """
    Verify connectivity to platform gateway

    Args:
        gateway_ip: Gateway IP address (e.g., '10.0.0.1')
        timeout: Timeout in seconds

    Returns:
        True if gateway is reachable
    """
    import requests

    try:
        # Try HTTP health check first
        response = requests.get(
            f"http://{gateway_ip}:8000/health",
            timeout=timeout
        )
        return response.status_code == 200

    except:
        # Fallback to ping
        try:
            result = subprocess.run(
                ['ping', '-c', '1', '-W', str(timeout), gateway_ip],
                capture_output=True,
                timeout=timeout + 1
            )
            return result.returncode == 0
        except:
            return False
