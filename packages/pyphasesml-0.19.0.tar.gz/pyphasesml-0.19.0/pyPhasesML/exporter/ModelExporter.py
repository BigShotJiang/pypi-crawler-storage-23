import importlib
import os
from pathlib import Path

from pyPhases import classLogger
from pyPhases.Data import DataNotFound
from pyPhases.exporter.DataExporter import DataExporter

from ..Model import Model

@classLogger
class BaseModelExporter(DataExporter):
    includesStorage = True
    registry = {}

    @staticmethod
    def registerModel(dataId, repository):
        BaseModelExporter.registry[dataId] = repository

    def downloadModel(self, dataId, options={}):
        if dataId not in self.registry:
            raise DataNotFound("The model '%s' is not registered in the ModelExporter registry" % dataId)
        
        self.log("Downloading model '%s' from repository '%s'" % (dataId, self.registry[dataId]))

        if not importlib.util.find_spec("huggingface_hub"):
            self.logError("hf_hub_download is required for downloading models please install it using: pip install hf_hub_download")
            raise DataNotFound("The model '%s' is not registered in the ModelExporter registry" % dataId)

        from huggingface_hub import hf_hub_download

        registry = self.registry[dataId]
        hf_hub_download(
            repo_id=registry,
            filename=dataId,
            local_dir="./data",
        )

    def initialOptions(self):
        return {"basePath": "data/"}

    def getPath(self, dataId):
        return self.getOption("basePath") + dataId


if importlib.util.find_spec("tensorflow"):

    if importlib.util.find_spec("torch"):
        print(
            "\033[31;1;4m%s\033[0m"
            % "Tensorflow and PyTorch are installed in the same enviroment, only one model (Tensorflow) can be handled"
        )

    if importlib.util.find_spec("tensorflow.keras"):
        import tensorflow
        from tensorflow.keras import models
        from tensorflow.python.keras.engine.functional import Functional

    elif importlib.util.find_spec("keras"):
        from keras import models

        Functional = False

    class ModelExporter(BaseModelExporter):

        def checkType(self, expectedType):
            funcCheck = issubclass(expectedType, Functional) if Functional is not None else False
            return issubclass(expectedType, models.Sequential) or issubclass(expectedType, tensorflow.keras.Model) or issubclass(expectedType, Model) or funcCheck

        def read(self, dataId, options={}):
            path = self.getPath(dataId)
            if not Path("%s.index" % path).exists():
                self.downloadModel(dataId, options)
                self.read(dataId, options)
            return path

        def write(self, dataId, model, options={}):
            model.save_weights(self.getPath(dataId))

elif importlib.util.find_spec("torch"):
    
    class ModelExporter(BaseModelExporter):

        def checkType(self, expectedType):
            import torch

            return issubclass(expectedType, torch.nn.Module) or issubclass(expectedType, Model)

        def read(self, dataId, options={}):
            import torch
            
            try:
                deviceName = "cuda" if torch.cuda.is_available() else "cpu"
                return torch.load(self.getPath(dataId), map_location=torch.device(deviceName), weights_only=True)
            except FileNotFoundError:
                self.downloadModel(dataId, options)
                return self.read(dataId, options)

        def write(self, dataId, model, options={}):
            import torch
            
            torch.save(model.state_dict(), self.getPath(dataId))

else:
    # ability to ignore missing model exporter for testing purposes
    if os.environ.get("PYPHASESML_IGNORE_MISSING_MODEL_EXPORTER", 0) == 1:
        raise Exception("No supported ModelExporter located (Supported: pytorch/tensorflow)")
    else:

        class ModelExporter(BaseModelExporter):

            def checkType(self, expectedType):
                return False

            def read(self, path, data, options={}):
                raise Exception("ModelExporter is only as stub, please install tensorflow or pytorch to use the ModelExporter")

            def write(self, path, data, model, options={}):
                raise Exception("ModelExporter is only as stub, please install tensorflow or pytorch to use the ModelExporter")
