ENDPOINT = "https://www.tofupilot.app"

SECONDS_BEFORE_TIMEOUT = 60
