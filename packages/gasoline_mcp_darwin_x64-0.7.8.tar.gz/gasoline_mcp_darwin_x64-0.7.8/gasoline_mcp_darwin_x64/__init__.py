"""Platform-specific Gasoline binary for darwin-x64."""

__version__ = "0.7.8"
