import{l as o,a as r}from"../chunks/66khk4fz.js";export{o as load_css,r as start};
