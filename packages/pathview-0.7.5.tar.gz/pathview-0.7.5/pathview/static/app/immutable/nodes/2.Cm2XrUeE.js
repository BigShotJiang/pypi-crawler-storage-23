import{a as e}from"../chunks/l7uptRlM.js";export{e as component};
