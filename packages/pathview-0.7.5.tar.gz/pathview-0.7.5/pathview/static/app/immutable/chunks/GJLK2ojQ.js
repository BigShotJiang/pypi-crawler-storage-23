const s=globalThis.__sveltekit_ffg7ug?.base??"",a=globalThis.__sveltekit_ffg7ug?.assets??s??"";export{a,s as b};
