import{b as p,E as t}from"./WhGNZ2BR.js";import{B as c}from"./jHqPq_a7.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
