"""Entry point for: python -m pathview"""

from pathview.cli import main

if __name__ == "__main__":
    main()
