"""
Modelos de Redes Neurais Convolucionais (CNN)
"""

import torch
import torch.nn as nn
import torchvision.models as models
from typing import Dict, Any, Optional

from datatunner.models.base import BaseModel


class ResNetClassifier(BaseModel):
    """Classificador baseado em ResNet"""
    
    def __init__(
        self,
        num_classes: int,
        architecture: str = "resnet18",
        pretrained: bool = True,
        freeze_backbone: bool = False
    ):
        """
        Args:
            num_classes: Número de classes
            architecture: Arquitetura ResNet (resnet18, resnet34, resnet50, resnet101)
            pretrained: Se deve usar pesos pré-treinados
            freeze_backbone: Se deve congelar backbone
        """
        super().__init__()
        
        self.num_classes = num_classes
        self.architecture = architecture
        self.model_name = f"ResNet-{architecture}"
        
        # Carregar modelo base
        if architecture == "resnet18":
            self.backbone = models.resnet18(pretrained=pretrained)
        elif architecture == "resnet34":
            self.backbone = models.resnet34(pretrained=pretrained)
        elif architecture == "resnet50":
            self.backbone = models.resnet50(pretrained=pretrained)
        elif architecture == "resnet101":
            self.backbone = models.resnet101(pretrained=pretrained)
        else:
            raise ValueError(f"Arquitetura não suportada: {architecture}")
        
        # Substituir camada final
        num_features = self.backbone.fc.in_features
        self.backbone.fc = nn.Linear(num_features, num_classes)
        
        # Congelar backbone se necessário
        if freeze_backbone:
            self.freeze_layers()
    
    def forward(self, x):
        return self.backbone(x)
    
    def get_model_info(self) -> Dict[str, Any]:
        return {
            "model_name": self.model_name,
            "architecture": self.architecture,
            "num_classes": self.num_classes,
            "num_parameters": self.count_parameters()
        }
    
    def freeze_layers(self, num_layers: int = 0):
        """Congela camadas do backbone"""
        for param in self.backbone.parameters():
            param.requires_grad = False
        
        # Manter última camada treinável
        for param in self.backbone.fc.parameters():
            param.requires_grad = True


class VGGClassifier(BaseModel):
    """Classificador baseado em VGG"""
    
    def __init__(
        self,
        num_classes: int,
        architecture: str = "vgg16",
        pretrained: bool = True,
        freeze_backbone: bool = False
    ):
        """
        Args:
            num_classes: Número de classes
            architecture: Arquitetura VGG (vgg11, vgg13, vgg16, vgg19)
            pretrained: Se deve usar pesos pré-treinados
            freeze_backbone: Se deve congelar backbone
        """
        super().__init__()
        
        self.num_classes = num_classes
        self.architecture = architecture
        self.model_name = f"VGG-{architecture}"
        
        # Carregar modelo base
        if architecture == "vgg11":
            self.backbone = models.vgg11(pretrained=pretrained)
        elif architecture == "vgg13":
            self.backbone = models.vgg13(pretrained=pretrained)
        elif architecture == "vgg16":
            self.backbone = models.vgg16(pretrained=pretrained)
        elif architecture == "vgg19":
            self.backbone = models.vgg19(pretrained=pretrained)
        else:
            raise ValueError(f"Arquitetura não suportada: {architecture}")
        
        # Substituir camada final
        num_features = self.backbone.classifier[6].in_features
        self.backbone.classifier[6] = nn.Linear(num_features, num_classes)
        
        if freeze_backbone:
            self.freeze_layers()
    
    def forward(self, x):
        return self.backbone(x)
    
    def get_model_info(self) -> Dict[str, Any]:
        return {
            "model_name": self.model_name,
            "architecture": self.architecture,
            "num_classes": self.num_classes,
            "num_parameters": self.count_parameters()
        }


class MobileNetClassifier(BaseModel):
    """Classificador baseado em MobileNet"""
    
    def __init__(
        self,
        num_classes: int,
        architecture: str = "mobilenet_v2",
        pretrained: bool = True,
        freeze_backbone: bool = False
    ):
        """
        Args:
            num_classes: Número de classes
            architecture: Arquitetura (mobilenet_v2, mobilenet_v3_small, mobilenet_v3_large)
            pretrained: Se deve usar pesos pré-treinados
            freeze_backbone: Se deve congelar backbone
        """
        super().__init__()
        
        self.num_classes = num_classes
        self.architecture = architecture
        self.model_name = f"MobileNet-{architecture}"
        
        # Carregar modelo base
        if architecture == "mobilenet_v2":
            self.backbone = models.mobilenet_v2(pretrained=pretrained)
            num_features = self.backbone.classifier[1].in_features
            self.backbone.classifier[1] = nn.Linear(num_features, num_classes)
        elif architecture == "mobilenet_v3_small":
            self.backbone = models.mobilenet_v3_small(pretrained=pretrained)
            num_features = self.backbone.classifier[3].in_features
            self.backbone.classifier[3] = nn.Linear(num_features, num_classes)
        elif architecture == "mobilenet_v3_large":
            self.backbone = models.mobilenet_v3_large(pretrained=pretrained)
            num_features = self.backbone.classifier[3].in_features
            self.backbone.classifier[3] = nn.Linear(num_features, num_classes)
        else:
            raise ValueError(f"Arquitetura não suportada: {architecture}")
        
        if freeze_backbone:
            self.freeze_layers()
    
    def forward(self, x):
        return self.backbone(x)
    
    def get_model_info(self) -> Dict[str, Any]:
        return {
            "model_name": self.model_name,
            "architecture": self.architecture,
            "num_classes": self.num_classes,
            "num_parameters": self.count_parameters()
        }


class CustomCNN(BaseModel):
    """CNN customizada simples"""
    
    def __init__(
        self,
        num_classes: int,
        input_channels: int = 3,
        dropout: float = 0.5
    ):
        """
        Args:
            num_classes: Número de classes
            input_channels: Número de canais de entrada
            dropout: Taxa de dropout
        """
        super().__init__()
        
        self.num_classes = num_classes
        self.model_name = "CustomCNN"
        
        self.features = nn.Sequential(
            nn.Conv2d(input_channels, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1))
        )
        
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes)
        )
    
    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x
    
    def get_model_info(self) -> Dict[str, Any]:
        return {
            "model_name": self.model_name,
            "num_classes": self.num_classes,
            "num_parameters": self.count_parameters()
        }
