"""
Testes para os modelos
"""

import pytest
import torch

from datatunner.models.cnn import ResNetClassifier, VGGClassifier, CustomCNN
from datatunner.models.mlp import MLPClassifier, MLPRegressor


class TestCNNModels:
    """Testes para modelos CNN"""
    
    def test_resnet_initialization(self):
        """Testa inicialização do ResNet"""
        model = ResNetClassifier(num_classes=10, architecture='resnet18')
        
        assert model.num_classes == 10
        assert model.architecture == 'resnet18'
        assert model.count_parameters() > 0
    
    def test_resnet_forward(self):
        """Testa forward pass do ResNet"""
        model = ResNetClassifier(num_classes=10, architecture='resnet18')
        x = torch.randn(2, 3, 224, 224)
        
        output = model(x)
        
        assert output.shape == (2, 10)
    
    def test_vgg_initialization(self):
        """Testa inicialização do VGG"""
        model = VGGClassifier(num_classes=10, architecture='vgg16')
        
        assert model.num_classes == 10
        assert model.count_parameters() > 0
    
    def test_custom_cnn(self):
        """Testa CNN customizada"""
        model = CustomCNN(num_classes=10)
        x = torch.randn(2, 3, 224, 224)
        
        output = model(x)
        
        assert output.shape == (2, 10)


class TestMLPModels:
    """Testes para modelos MLP"""
    
    def test_mlp_classifier(self):
        """Testa MLP classificador"""
        model = MLPClassifier(
            input_dim=20,
            num_classes=5,
            hidden_layers=[64, 32]
        )
        
        x = torch.randn(10, 20)
        output = model(x)
        
        assert output.shape == (10, 5)
    
    def test_mlp_regressor(self):
        """Testa MLP regressor"""
        model = MLPRegressor(
            input_dim=20,
            output_dim=1,
            hidden_layers=[64, 32]
        )
        
        x = torch.randn(10, 20)
        output = model(x)
        
        assert output.shape == (10, 1)
    
    def test_model_info(self):
        """Testa get_model_info"""
        model = MLPClassifier(input_dim=20, num_classes=5)
        info = model.get_model_info()
        
        assert 'model_name' in info
        assert 'num_parameters' in info
        assert info['input_dim'] == 20
        assert info['num_classes'] == 5
