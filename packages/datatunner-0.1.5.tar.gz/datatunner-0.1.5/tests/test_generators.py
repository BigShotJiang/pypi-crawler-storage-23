"""
Testes para os geradores de dados sintéticos
"""

import pytest
import numpy as np
from PIL import Image
import tempfile
from pathlib import Path

from datatunner.generators.augmentation import ImageAugmentation
from datatunner.generators.smote import SMOTEGenerator, GaussianNoiseGenerator


class TestImageAugmentation:
    """Testes para ImageAugmentation"""
    
    def setup_method(self):
        """Setup antes de cada teste"""
        self.random_seed = 42
        self.generator = ImageAugmentation(random_seed=self.random_seed)
    
    def test_initialization(self):
        """Testa inicialização"""
        assert self.generator.generator_name == "ImageAugmentation"
        assert self.generator.random_seed == self.random_seed
    
    def test_augmentation_strengths(self):
        """Testa diferentes níveis de augmentation"""
        strengths = ["light", "medium", "heavy"]
        
        for strength in strengths:
            gen = ImageAugmentation(augmentation_strength=strength)
            assert gen.augmentation_strength == strength
    
    def test_invalid_strength(self):
        """Testa força de augmentation inválida"""
        with pytest.raises(ValueError):
            ImageAugmentation(augmentation_strength="invalid")


class TestSMOTEGenerator:
    """Testes para SMOTEGenerator"""
    
    def setup_method(self):
        """Setup antes de cada teste"""
        self.random_seed = 42
        
        # Criar dados de teste sintéticos
        np.random.seed(self.random_seed)
        self.X_train = np.random.randn(100, 10)
        self.y_train = np.random.randint(0, 2, 100)
    
    def test_initialization(self):
        """Testa inicialização"""
        generator = SMOTEGenerator(k_neighbors=5, random_seed=self.random_seed)
        
        assert generator.k_neighbors == 5
        assert generator.random_seed == self.random_seed
    
    def test_fit(self):
        """Testa ajuste do gerador"""
        generator = SMOTEGenerator(random_seed=self.random_seed)
        generator.fit(self.X_train, self.y_train)
        
        assert generator.X_train is not None
        assert generator.y_train is not None
    
    def test_generate(self):
        """Testa geração de dados"""
        generator = SMOTEGenerator(random_seed=self.random_seed)
        generator.fit(self.X_train, self.y_train)
        
        X_synthetic, y_synthetic = generator.generate()
        
        assert len(X_synthetic) > 0
        assert len(y_synthetic) > 0
        assert X_synthetic.shape[1] == self.X_train.shape[1]


class TestGaussianNoiseGenerator:
    """Testes para GaussianNoiseGenerator"""
    
    def setup_method(self):
        """Setup"""
        self.random_seed = 42
        np.random.seed(self.random_seed)
        self.X_train = np.random.randn(100, 10)
        self.y_train = np.random.randint(0, 2, 100)
    
    def test_generation(self):
        """Testa geração com ruído Gaussiano"""
        generator = GaussianNoiseGenerator(
            noise_level=0.1,
            random_seed=self.random_seed
        )
        generator.fit(self.X_train, self.y_train)
        
        X_synthetic, y_synthetic = generator.generate(n_samples=50)
        
        assert len(X_synthetic) == 50
        assert len(y_synthetic) == 50
        assert X_synthetic.shape[1] == self.X_train.shape[1]
