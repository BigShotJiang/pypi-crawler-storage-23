"""
Testes para o módulo optimizer
"""

import pytest
import torch
import numpy as np
from pathlib import Path
import tempfile

from datatunner.core.optimizer import DataTunner
from datatunner.models.cnn import ResNetClassifier


class TestDataTunner:
    """Testes para a classe DataTunner"""
    
    def setup_method(self):
        """Setup antes de cada teste"""
        self.temp_dir = tempfile.mkdtemp()
        self.random_seed = 42
    
    def test_initialization(self):
        """Testa inicialização do DataTunner"""
        tunner = DataTunner(
            data_type='image',
            output_dir=self.temp_dir,
            random_seed=self.random_seed
        )
        
        assert tunner.data_type == 'image'
        assert tunner.random_seed == self.random_seed
        assert tunner.output_dir == Path(self.temp_dir)
    
    def test_invalid_data_type(self):
        """Testa tipo de dados inválido"""
        with pytest.raises(ValueError):
            tunner = DataTunner(
                data_type='invalid',
                output_dir=self.temp_dir
            )
            tunner._load_data()
    
    def test_configuration(self):
        """Testa configuração customizada"""
        custom_config = {
            'batch_size': 64,
            'epochs': 100
        }
        
        tunner = DataTunner(
            data_type='image',
            output_dir=self.temp_dir,
            config=custom_config
        )
        
        assert tunner.config['batch_size'] == 64
        assert tunner.config['epochs'] == 100


class TestDataTunnerIntegration:
    """Testes de integração (requerem dados)"""
    
    @pytest.mark.skipif(not Path("data/test").exists(), reason="Dados de teste não disponíveis")
    def test_full_pipeline(self):
        """Testa pipeline completo (se dados disponíveis)"""
        # Este teste só roda se houver dados de teste
        pass
