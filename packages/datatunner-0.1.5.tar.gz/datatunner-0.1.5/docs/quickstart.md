# Quick Start Guide

This guide will help you get started with DataTunner quickly.

## Basic Workflow

1. Prepare your data (real + synthetic)
2. Configure DataTunner
3. Define your model
4. Run optimization
5. Analyze results

## Example: Image Classification

```python
from datatunner import DataTunner
from datatunner.models.cnn import ResNetClassifier

# 1. Configure DataTunner
tunner = DataTunner(
    data_type='image',
    real_data_path='data/train',
    synthetic_data_path='data/synthetic',
    test_data_path='data/test',
    output_dir='results',
    random_seed=42
)

# 2. Define model
model = ResNetClassifier(
    num_classes=10,
    architecture='resnet18',
    pretrained=True
)

# 3. Run optimization
results = tunner.optimize(
    model=model,
    proportions=[0.0, 0.1, 0.2, 0.3, 0.5],
    epochs=30,
    batch_size=64,
    learning_rate=0.001
)

# 4. Visualize results
tunner.plot_results()
tunner.generate_report()

print(f"Best proportion: {results['best_proportion']:.1%}")
print(f"Best accuracy: {results['best_metrics']['accuracy']:.4f}")
```

## Example: Tabular Data

```python
from datatunner import DataTunner
from datatunner.models.mlp import MLPClassifier
from datatunner.generators.smote import SMOTEGenerator

# Generate synthetic data
generator = SMOTEGenerator(k_neighbors=5)
generator.fit(X_train, y_train)
X_synthetic, y_synthetic = generator.generate(n_samples=5000)

# Configure DataTunner
tunner = DataTunner(
    data_type='tabular',
    output_dir='results/tabular'
)

# Define model
model = MLPClassifier(
    input_dim=X_train.shape[1],
    num_classes=len(np.unique(y_train)),
    hidden_layers=[128, 64, 32]
)

# Run optimization
results = tunner.optimize(
    model=model,
    synthetic_data=(X_synthetic, y_synthetic),
    proportions=[0.0, 0.2, 0.5, 0.7, 1.0],
    epochs=100,
    batch_size=128
)
```

## Understanding Results

DataTunner generates:

- **Plots**: Metric vs proportion graphs
- **Reports**: HTML summary with all results
- **JSON**: Detailed metrics for each proportion
- **Checkpoints**: Saved models for each experiment

## Next Steps

- Explore [Examples](../examples/)
- Read the [API Documentation](api_reference.md)
- Check [Best Practices](best_practices.md)
