# Installation Guide

## Prerequisites

- Python 3.8 or higher
- pip package manager
- (Optional) CUDA-capable GPU for faster training

## Installation Options

### Option 1: Install from PyPI (when published)

```bash
pip install datatunner
```

### Option 2: Install from Source

1. Clone the repository:
```bash
git clone https://github.com/leandro-rocha/datatunner.git
cd datatunner
```

2. Create a virtual environment:
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

3. Install the package:
```bash
pip install -e .
```

### Option 3: Development Installation

For development with all extras:

```bash
pip install -e ".[dev,docs]"
```

## Verifying Installation

Test your installation:

```python
import datatunner
print(datatunner.__version__)
```

## GPU Support

For GPU acceleration (NVIDIA CUDA):

1. Install PyTorch with CUDA support:
```bash
# Example for CUDA 11.8
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
```

2. Verify CUDA availability:
```python
import torch
print(torch.cuda.is_available())
```

## Troubleshooting

### Common Issues

**Issue**: Import errors after installation
**Solution**: Make sure you activated the virtual environment

**Issue**: CUDA not detected
**Solution**: Install correct PyTorch version for your CUDA version

**Issue**: Dependencies conflicts
**Solution**: Use a fresh virtual environment

## Next Steps

- Read the [Quick Start Guide](quickstart.md)
- Check out [Examples](../examples/)
- Read the [API Reference](api_reference.md)
