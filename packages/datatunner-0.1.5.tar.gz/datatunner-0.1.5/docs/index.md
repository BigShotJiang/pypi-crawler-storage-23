# DataTunner Documentation

Welcome to DataTunner documentation!

## What is DataTunner?

DataTunner is a Python library for automatically determining the optimal proportion of synthetic data to maximize the performance of deep learning models.

## Key Features

- 🔄 Automatic optimization of synthetic data proportions
- 🖼️ Support for image datasets (CNNs)
- 📊 Support for tabular datasets (MLPs)
- 📈 Comprehensive metrics and visualizations
- 🎨 Multiple synthetic data generators (Augmentation, SMOTE, CTGAN)
- ⚡ GPU acceleration support
- 🔬 Reproducible experiments with fixed seeds

## Why DataTunner?

Traditional approaches to using synthetic data rely on empirical trial-and-error. DataTunner provides:

1. **Systematic methodology** for testing multiple proportions
2. **Automated evaluation** across different metrics
3. **Reproducible results** with controlled randomness
4. **Visual analysis** of the impact of synthetic data
5. **Best practices** built-in

## Quick Links

- [Installation](installation.md)
- [Quick Start](quickstart.md)
- [API Reference](api_reference.md)
- [Examples](../examples/)

## Citation

If you use DataTunner in your research, please cite:

```bibtex
@software{datatunner2026,
  author = {Rocha, Leandro},
  title = {DataTunner: Otimização de Proporções de Dados Sintéticos},
  year = {2026},
  url = {https://github.com/leandro-rocha/datatunner}
}
```

## Support

- GitHub Issues: [Report bugs](https://github.com/leandro-rocha/datatunner/issues)
- Documentation: [Read the docs](https://datatunner.readthedocs.io)

## License

DataTunner is released under the MIT License. See [LICENSE](../LICENSE) for details.
