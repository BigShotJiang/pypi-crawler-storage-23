"""
============================================================================
🎯 Fashion MNIST - Exemplo Usando DataTunner (API Completa)
============================================================================

Este exemplo demonstra como usar o pacote datatunner instalado via PyPI
para otimizar proporções de dados augmentados em imagens.

INSTALAÇÃO:
    pip install datatunner

USO NO GOOGLE COLAB:
    !pip install datatunner torch torchvision scikit-learn matplotlib seaborn

EXECUÇÃO:
    1. Instale as dependências
    2. Execute este script
    3. Aguarde ~5-10 minutos
    
============================================================================
"""

# ============================================================================
# 1. INSTALAÇÃO (Descomente no Google Colab)
# ============================================================================
# !pip install -q datatunner torch torchvision scikit-learn matplotlib seaborn albumentations

print("📦 Importando bibliotecas...")

import os
import sys
import numpy as np
import torch
from torchvision import datasets
from PIL import Image
from pathlib import Path

# Adicionar raiz do projeto ao path (compatível com execução local e Google Colab/Jupyter)
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
except NameError:
    # No Google Colab / Jupyter, __file__ não existe. Usa diretório atual.
    sys.path.insert(0, os.getcwd())

# IMPORTAR DATATUNNER - A API REAL!
from datatunner import DataTunner
from datatunner.models.cnn import CustomCNN
from datatunner.generators.augmentation import ImageAugmentation

import matplotlib
matplotlib.use('Agg')

import datatunner
print(f"✅ Bibliotecas importadas! (DataTunner v{datatunner.__version__})\n")

# Forçar estilo seguro se houver problemas residuais no ambiente
import matplotlib.pyplot as plt
try:
    if 'seaborn-v0_8' in plt.style.available:
        plt.style.use('seaborn-v0_8')
    elif 'ggplot' in plt.style.available:
        plt.style.use('ggplot')
    else:
        plt.style.use('default')
except:
    pass

# ============================================================================
# 2. CONFIGURAÇÕES
# ============================================================================
print("=" * 70)
print("🎯 FASHION MNIST COM DATATUNNER (API REAL)")
print("=" * 70)

RANDOM_SEED = 42
SUBSET_SIZE = 500       # Amostras por classe (reduzido para demo rápida)
TEST_SUBSET = 100       # Amostras de teste por classe
OUTPUT_DIR = "results/fashion_mnist"
DATA_DIR = "data/fashion_mnist_images"
NUM_CLASSES = 10
EPOCHS = 5              # Reduzido para demo rápida
BATCH_SIZE = 32
LEARNING_RATE = 0.001

np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\n🖥️  Dispositivo: {device}")

# Nomes das classes Fashion MNIST
CLASS_NAMES = [
    'T-shirt_top', 'Trouser', 'Pullover', 'Dress', 'Coat',
    'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle_boot'
]

# ============================================================================
# 3. PREPARAR DADOS - Salvar Fashion MNIST como imagens em disco
# ============================================================================
print("\n📂 Carregando Fashion MNIST...")

# Download do dataset
train_dataset = datasets.FashionMNIST(
    root='./data', train=True, download=True
)
test_dataset = datasets.FashionMNIST(
    root='./data', train=False, download=True
)

print(f"   Dataset original: {len(train_dataset)} treino, {len(test_dataset)} teste")

# ============================================================================
# 3.1 Salvar imagens em disco (estrutura de diretórios por classe)
# ============================================================================
# O DataTunner espera:
#   data_dir/
#       class_0/
#           img1.png
#       class_1/
#           img2.png
#       ...

REAL_DIR = os.path.join(DATA_DIR, 'real')
SYNTH_DIR = os.path.join(DATA_DIR, 'synthetic')
TEST_DIR = os.path.join(DATA_DIR, 'test')


def save_mnist_to_disk(dataset, base_dir, samples_per_class, name="dataset"):
    """Salva imagens MNIST em disco com estrutura de diretórios por classe"""
    paths = []
    labels = []

    # Contar amostras por classe
    class_counts = {i: 0 for i in range(NUM_CLASSES)}

    for idx in range(len(dataset)):
        img, label = dataset[idx]
        label = int(label)

        if class_counts[label] >= samples_per_class:
            continue

        # Criar diretório da classe
        class_name = CLASS_NAMES[label]
        class_dir = os.path.join(base_dir, class_name)
        os.makedirs(class_dir, exist_ok=True)

        # Converter para RGB (Fashion MNIST é grayscale)
        if isinstance(img, torch.Tensor):
            img = img.numpy()
        if isinstance(img, np.ndarray):
            img = Image.fromarray(img)

        img_rgb = img.convert('RGB')

        # Salvar
        img_path = os.path.join(class_dir, f'{class_name}_{class_counts[label]:04d}.png')
        img_rgb.save(img_path)

        paths.append(img_path)
        labels.append(label)
        class_counts[label] += 1

        # Verificar se já temos suficiente de todas as classes
        if all(c >= samples_per_class for c in class_counts.values()):
            break

    total = sum(class_counts.values())
    print(f"   {name}: {total} imagens ({samples_per_class}/classe)")
    return paths, labels


print("\n📁 Salvando imagens em disco...")
real_paths, real_labels = save_mnist_to_disk(
    train_dataset, REAL_DIR, SUBSET_SIZE, "Treino (real)"
)
test_paths, test_labels = save_mnist_to_disk(
    test_dataset, TEST_DIR, TEST_SUBSET, "Teste"
)

print(f"   Classes: {CLASS_NAMES}")
print(f"   Total treino: {len(real_paths)} | Total teste: {len(test_paths)}")

# ============================================================================
# 4. CONFIGURAR GERADOR DE DADOS SINTÉTICOS
# ============================================================================
print("\n🔄 Configurando Data Augmentation...")

generator = ImageAugmentation(
    random_seed=RANDOM_SEED,
    augmentation_strength='medium'       # light, medium ou heavy
)

# Fit: informar ao gerador quais são as imagens reais
generator.fit(real_paths, real_labels)

print("✅ Gerador configurado!")
print(f"   Tipo: {generator.__class__.__name__}")
print(f"   Intensidade: {generator.augmentation_strength}")
print(f"   Info: {generator.get_generator_info()}")

# ============================================================================
# 5. GERAR DADOS SINTÉTICOS (AUGMENTATION)
# ============================================================================
print("\n🔧 Gerando dados augmentados...")

n_synthetic = len(real_paths)  # Gerar mesma quantidade que os reais
synth_paths, synth_labels = generator.generate(
    n_samples=n_synthetic,
    output_dir=SYNTH_DIR,
    save_images=True
)

print(f"✅ Gerado: {len(synth_paths)} imagens augmentadas (diretório plano)")

# ============================================================================
# 5.1 Reorganizar imagens sintéticas em subpastas por classe
# ============================================================================
# O DataTunner espera: synthetic/class_name/img.png
# Mas ImageAugmentation gera: synthetic/aug_0_Class_0001.png
print("\n📂 Reorganizando imagens sintéticas por classe...")

import shutil

SYNTH_ORGANIZED_DIR = os.path.join(DATA_DIR, 'synthetic_organized')

# Criar diretórios por classe
for class_name in CLASS_NAMES:
    os.makedirs(os.path.join(SYNTH_ORGANIZED_DIR, class_name), exist_ok=True)

# Mover imagens para suas respectivas pastas
moved_paths = []
for img_path, label in zip(synth_paths, synth_labels):
    class_name = CLASS_NAMES[label]
    dest_dir = os.path.join(SYNTH_ORGANIZED_DIR, class_name)
    dest_path = os.path.join(dest_dir, os.path.basename(img_path))
    
    shutil.copy2(img_path, dest_path)
    moved_paths.append(dest_path)

print(f"✅ Imagens reorganizadas em: {SYNTH_ORGANIZED_DIR}")
print(f"   Estrutura: class_name/img.png")

# Atualizar SYNTH_DIR para o diretório organizado
SYNTH_DIR = SYNTH_ORGANIZED_DIR

# ============================================================================
# 6. CONFIGURAR MODELO CNN
# ============================================================================
print("\n🧠 Configurando modelo CNN...")

model = CustomCNN(
    num_classes=NUM_CLASSES,
    input_channels=3,       # RGB (Fashion MNIST convertido para RGB)
    dropout=0.25
)

total_params = sum(p.numel() for p in model.parameters())
print("✅ Modelo configurado!")
print(f"   Arquitetura: CustomCNN")
print(f"   Parâmetros: {total_params:,}")
print(f"   Input: 3 canais (RGB)")
print(f"   Output: {NUM_CLASSES} classes")

# ============================================================================
# 7. CONFIGURAR DATATUNNER
# ============================================================================
print("\n⚙️  Configurando DataTunner...")

tunner = DataTunner(
    data_type='image',
    real_data_path=REAL_DIR,
    synthetic_data_path=SYNTH_DIR,
    test_data_path=TEST_DIR,
    output_dir=OUTPUT_DIR,
    random_seed=RANDOM_SEED
)

print("✅ DataTunner configurado!")
print(f"   Dados reais: {REAL_DIR}")
print(f"   Dados sintéticos: {SYNTH_DIR}")
print(f"   Dados teste: {TEST_DIR}")
print(f"   Saída: {OUTPUT_DIR}")

# ============================================================================
# 8. EXECUTAR OTIMIZAÇÃO
# ============================================================================
print("\n🚀 Iniciando otimização...")
print("   (Testando 5 proporções diferentes)")
print("   (Aguarde alguns minutos...)\n")

print("📊 Lógica de Mistura:")
print("   D_hybrid = D_real ∪ sample(D_syn, α · |D_real|)")
print("   - α = proporção de dados augmentados a ADICIONAR")
print("   - Sempre usa TODOS os dados reais\n")

# Definir proporções a testar
proportions = [0.0, 0.25, 0.5, 0.75, 0.95]

# USAR A API DO DATATUNNER!
results = tunner.optimize(
    model=model,
    proportions=proportions,
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    learning_rate=LEARNING_RATE,
    n_trials=1,              # Aumente para maior robustez (3-5 recomendado)
    balance_classes=True,
)

# ============================================================================
# 9. VISUALIZAR RESULTADOS
# ============================================================================
print("\n📈 Gerando visualizações...\n")

# Plot principal - Acurácia vs Proporção
tunner.plot_results(metric='accuracy')

# Múltiplas métricas
tunner.plot_multiple_metrics(
    metrics=['accuracy', 'f1_score', 'precision', 'recall']
)

# Gráfico interativo (Plotly)
tunner.create_interactive_plot()

print("💾 Visualizações salvas em:", OUTPUT_DIR)

# ============================================================================
# 10. GERAR RELATÓRIO
# ============================================================================
print("\n📄 Gerando relatório HTML...")

tunner.generate_report(format='html')

print(f"💾 Relatório salvo: {OUTPUT_DIR}/summary_report.html")

# ============================================================================
# 11. RESULTADOS FINAIS
# ============================================================================
print("\n" + "=" * 70)
print("📊 RESULTADOS FINAIS")
print("=" * 70)

best_prop = results['best_proportion']
best_metrics = results['best_metrics']
all_results = results['results']
baseline_metrics = all_results[0.0]

print(f"""
✅ BASELINE (α=0.0 - Apenas dados reais):
   - Acurácia: {baseline_metrics['accuracy']:.4f}
   - F1-Score: {baseline_metrics['f1_score']:.4f}
   - Precision: {baseline_metrics['precision']:.4f}
   - Recall: {baseline_metrics['recall']:.4f}

🏆 MELHOR MODELO (α={best_prop:.2f}):
   - Acurácia: {best_metrics['accuracy']:.4f} ({(best_metrics['accuracy']-baseline_metrics['accuracy'])*100:+.2f}%)
   - F1-Score: {best_metrics['f1_score']:.4f} ({(best_metrics['f1_score']-baseline_metrics['f1_score'])*100:+.2f}%)
   - Precision: {best_metrics['precision']:.4f}
   - Recall: {best_metrics['recall']:.4f}

📈 GANHO COM DATA AUGMENTATION:
   - Acurácia: {(best_metrics['accuracy']-baseline_metrics['accuracy'])*100:+.2f}%
   - F1-Score: {(best_metrics['f1_score']-baseline_metrics['f1_score'])*100:+.2f}%

🔬 CONFIGURAÇÕES:
   - Dataset: Fashion MNIST ({len(real_paths)} treino / {len(test_paths)} teste)
   - Modelo: CustomCNN ({total_params:,} parâmetros)
   - Gerador: ImageAugmentation ({generator.augmentation_strength})
   - Épocas: {EPOCHS}
   - Batch size: {BATCH_SIZE}
   - Learning rate: {LEARNING_RATE}

💡 INTERPRETAÇÃO:
   α={best_prop:.2f} oferece melhor equilíbrio entre:
   - Diversidade de dados (augmentation)
   - Generalização do modelo
   - Tempo de treinamento

📚 ARQUIVOS GERADOS:
   - {OUTPUT_DIR}/accuracy_vs_proportion.png
   - {OUTPUT_DIR}/all_metrics.png
   - {OUTPUT_DIR}/interactive_plot.html
   - {OUTPUT_DIR}/summary_report.html

🔗 DATATUNNER:
   - PyPI: https://pypi.org/project/datatunner/
   - GitHub: https://github.com/leandrocrx/datatunner
   - Autor: Leandro Costa Rocha
     - Instagram: @leandrocr.adv
     - LinkedIn: linkedin.com/in/leandro-costa-rocha-b40189b0
""")

print("=" * 70)
print("✅ OTIMIZAÇÃO CONCLUÍDA!")
print("=" * 70)
print(f"\n📁 Todos os resultados em: {OUTPUT_DIR}/")
