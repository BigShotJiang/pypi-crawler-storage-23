"""
Teste rápido da API DataTunner para dados tabulares.
Valida: SMOTEGenerator, GaussianNoiseGenerator, MLPClassifier, 
        ModelEvaluator, DataMixer, ResultsVisualizer
"""
import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

# Imports do DataTunner
from datatunner.generators.smote import SMOTEGenerator, GaussianNoiseGenerator
from datatunner.models.mlp import MLPClassifier
from datatunner.core.evaluator import ModelEvaluator
from datatunner.core.mixer import DataMixer
from datatunner.utils.visualization import ResultsVisualizer

print("=" * 60)
print("TESTE RÁPIDO - API TABULAR DO DATATUNNER")
print("=" * 60)

# 1. Gerar dados
np.random.seed(42)
torch.manual_seed(42)

X, y = make_classification(
    n_samples=300, n_features=20, n_informative=15,
    n_redundant=3, n_classes=3, random_state=42
)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)
print(f"\n1. Dados: train={X_train.shape}, test={X_test.shape}")

# 2. Testar SMOTE
generator = SMOTEGenerator(k_neighbors=3, random_seed=42)
generator.fit(X_train, y_train)
X_syn, y_syn = generator.generate(n_samples=100)
print(f"2. SMOTE: gerou {X_syn.shape[0]} amostras sintéticas")

# 3. Testar GaussianNoise
gn = GaussianNoiseGenerator(noise_level=0.1, random_seed=42)
gn.fit(X_train, y_train)
X_gn, y_gn = gn.generate(n_samples=50)
print(f"3. GaussianNoise: gerou {X_gn.shape[0]} amostras")

# 4. Testar DataMixer
mixer = DataMixer(random_seed=42)
X_mixed, y_mixed = mixer.mix_tabular_data(
    X_train, y_train, X_syn, y_syn,
    proportion=0.5, balance_classes=True
)
print(f"4. DataMixer: {X_train.shape[0]} reais + sintéticos = {X_mixed.shape[0]} total")

# 5. Testar MLP
model = MLPClassifier(
    input_dim=X_train.shape[1], num_classes=3,
    hidden_layers=[64, 32], dropout=0.3
)
print(f"5. MLP: {model.count_parameters()} parâmetros")

# 6. Treinar e avaliar com ModelEvaluator
evaluator = ModelEvaluator(device='cpu', task_type='classification')

# Criar DataLoaders
def make_loader(X, y, batch_size=32, shuffle=True):
    ds = TensorDataset(torch.FloatTensor(X), torch.LongTensor(y))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle)

train_loader = make_loader(X_train, y_train)
test_loader = make_loader(X_test, y_test, shuffle=False)

optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.CrossEntropyLoss()

print("\n6. Treinando MLP (5 épocas)...")
test_metrics, history = evaluator.train_and_evaluate(
    model=model,
    train_loader=train_loader,
    val_loader=test_loader,
    test_loader=test_loader,
    optimizer=optimizer,
    criterion=criterion,
    epochs=5,
    early_stopping_patience=3
)
print(f"   Accuracy: {test_metrics['accuracy']:.4f}")
print(f"   F1-Score: {test_metrics['f1_score']:.4f}")

# 7. Testar fluxo de otimização manual (simula optimize)
print("\n7. Simulando otimização de proporções...")
results = {}
proportions = [0.0, 0.25, 0.5, 0.75, 1.0]

for prop in proportions:
    # Misturar dados
    if prop > 0:
        X_mix, y_mix = mixer.mix_tabular_data(
            X_train, y_train, X_syn, y_syn,
            proportion=prop, balance_classes=True
        )
    else:
        X_mix, y_mix = X_train.copy(), y_train.copy()
    
    # Reset modelo
    m = MLPClassifier(input_dim=20, num_classes=3,
                      hidden_layers=[64, 32], dropout=0.3)
    opt = torch.optim.Adam(m.parameters(), lr=0.001)
    mix_loader = make_loader(X_mix, y_mix)
    
    metrics, _ = evaluator.train_and_evaluate(
        model=m, train_loader=mix_loader, val_loader=test_loader,
        test_loader=test_loader, optimizer=opt, criterion=criterion,
        epochs=5, early_stopping_patience=3
    )
    results[prop] = metrics
    print(f"   a={prop:.2f}: acc={metrics['accuracy']:.4f}, f1={metrics['f1_score']:.4f}")

# Encontrar melhor
best_prop = max(results, key=lambda p: results[p]['accuracy'])
print(f"\n   Melhor proporcao: a={best_prop:.2f} (acc={results[best_prop]['accuracy']:.4f})")

# 8. Testar Visualizador
os.makedirs('results/test_tabular_api', exist_ok=True)
viz = ResultsVisualizer(output_dir='results/test_tabular_api')
# Não plotar interativamente (headless)
import matplotlib
matplotlib.use('Agg')
viz.plot_proportion_vs_metric(results, metric='accuracy', save_name='accuracy.png')
viz.plot_multiple_metrics(results, save_name='all_metrics.png')
viz.generate_summary_report(
    results, best_prop,
    {'data_type': 'tabular', 'model_name': 'MLP', 'epochs': 5, 'batch_size': 32},
    save_name='report.html'
)
print("\n8. Visualizações salvas em results/test_tabular_api/")

print("\n" + "=" * 60)
print("✅ TODOS OS TESTES PASSARAM!")
print("=" * 60)
