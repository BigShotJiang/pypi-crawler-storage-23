"""
Exemplo de uso do DataTunner com CTGAN para dados tabulares

Este exemplo demonstra como usar o DataTunner com CTGAN para gerar
dados sintéticos tabulares de alta qualidade.
"""

import numpy as np
import pandas as pd
from pathlib import Path

from datatunner.generators.ctgan import CTGANGenerator
from datatunner.models.classical import RandomForestClassifier, XGBoostClassifier
from datatunner.utils.metrics import MetricsCalculator


def main():
    """Exemplo principal"""
    
    random_seed = 42
    np.random.seed(random_seed)
    
    print("="*60)
    print("DataTunner - Exemplo CTGAN + XGBoost")
    print("="*60)
    
    # NOTA: Este exemplo requer dados reais
    # Aqui mostramos o workflow completo
    
    print("""
    WORKFLOW COMPLETO COM CTGAN:
    
    1. Carregar dados tabulares
    ----------------------------
    ```python
    # Exemplo com Adult dataset ou similar
    data = pd.read_csv('data/adult_train.csv')
    X = data.drop(columns=['income'])
    y = data['income'].map({'<=50K': 0, '>50K': 1})
    
    # Separar treino e teste
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    ```
    
    2. Treinar CTGAN
    ----------------
    ```python
    from datatunner.generators.ctgan import CTGANGenerator
    
    # Criar gerador
    ctgan = CTGANGenerator(
        epochs=300,
        batch_size=500,
        generator_dim=(256, 256),
        discriminator_dim=(256, 256)
    )
    
    # Especificar colunas categóricas
    categorical_cols = ['workclass', 'education', 'marital-status', 
                       'occupation', 'relationship', 'race', 'sex', 'native-country']
    
    # Preparar dados com target
    train_data = X_train.copy()
    train_data['target'] = y_train
    
    # Treinar
    ctgan.fit(train_data, categorical_columns=categorical_cols)
    ```
    
    3. Gerar Dados Sintéticos
    --------------------------
    ```python
    # Gerar dados balanceados
    X_synthetic, y_synthetic = ctgan.generate_balanced(
        n_samples_per_class=5000
    )
    
    # Ou gerar condicionalmente
    X_syn_class0, y_syn_class0 = ctgan.generate(
        n_samples=5000,
        conditions={'target': 0}
    )
    ```
    
    4. Testar com Modelos Clássicos
    --------------------------------
    ```python
    from datatunner.models.classical import XGBoostClassifier
    
    # Baseline: apenas dados reais
    model_real = XGBoostClassifier(n_estimators=100)
    model_real.fit(X_train, y_train)
    y_pred_real = model_real.predict(X_test)
    
    # Com dados sintéticos (50% mix)
    X_mixed = pd.concat([X_train, X_synthetic[:len(X_train)//2]])
    y_mixed = np.concatenate([y_train, y_synthetic[:len(y_train)//2]])
    
    model_mixed = XGBoostClassifier(n_estimators=100)
    model_mixed.fit(X_mixed, y_mixed)
    y_pred_mixed = model_mixed.predict(X_test)
    
    # Comparar
    from datatunner.utils.metrics import MetricsCalculator
    
    metrics_real = MetricsCalculator.compute_metrics(y_test, y_pred_real)
    metrics_mixed = MetricsCalculator.compute_metrics(y_test, y_pred_mixed)
    
    print("Apenas Dados Reais:")
    print(f"  Accuracy: {metrics_real['accuracy']:.4f}")
    print(f"  F1-Score: {metrics_real['f1_score']:.4f}")
    
    print("\\nCom Dados Sintéticos (50%):")
    print(f"  Accuracy: {metrics_mixed['accuracy']:.4f}")
    print(f"  F1-Score: {metrics_mixed['f1_score']:.4f}")
    ```
    
    5. Salvar Modelo CTGAN
    ----------------------
    ```python
    ctgan.save_model('models/ctgan_adult.pkl')
    
    # Recarregar depois
    ctgan_loaded = CTGANGenerator()
    ctgan_loaded.load_model('models/ctgan_adult.pkl')
    ```
    
    MODELOS CLÁSSICOS DISPONÍVEIS:
    ------------------------------
    - DecisionTreeClassifier
    - RandomForestClassifier (✓ recomendado)
    - XGBoostClassifier (✓ recomendado)
    - LightGBMClassifier (✓ recomendado para datasets grandes)
    - CatBoostClassifier (✓ ótimo para categóricas)
    - SVMClassifier
    - LogisticRegressionClassifier
    - NaiveBayesClassifier
    - KNNClassifier
    
    DICAS:
    ------
    1. CTGAN funciona melhor com 10k+ amostras de treino
    2. Use 300-500 epochs para melhor qualidade
    3. Para datasets menores, considere TVAE:
       from datatunner.generators.ctgan import TVAEGenerator
    4. Sempre valide a qualidade dos dados sintéticos antes de usar
    5. Use geração condicional para balancear classes
    ```
    
    Consulte a documentação completa em docs/
    """)
    
    print("\n" + "="*60)
    print("IMPLEMENTAÇÃO REQUER DADOS REAIS")
    print("="*60)
    print("Siga o exemplo acima com seus dados")
    print("="*60)


if __name__ == "__main__":
    main()
