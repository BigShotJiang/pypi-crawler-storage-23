"""
DataTunner - Exemplo Tabular com CTGAN e TVAE
==============================================

Demonstra o uso do DataTunner para dados tabulares usando GANs:
  - CTGANGenerator: Conditional Tabular GAN
  - TVAEGenerator: Tabular Variational AutoEncoder

Dataset: Adult Income (sklearn - make_classification simulado)
Modelos: MLPClassifier, DeepMLP

Instalacao:
    pip install datatunner sdv

Uso:
    python example_tabular_ctgan.py

NOTA: Requer a biblioteca SDV (pip install sdv>=1.2.0)
"""

import os
import sys
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ============================================================
# SETUP
# ============================================================
# Adicionar path se executando localmente (compatível com Colab/Jupyter)
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
except NameError:
    sys.path.insert(0, os.getcwd())

from datatunner.models.mlp import MLPClassifier, DeepMLP
from datatunner.core.evaluator import ModelEvaluator
from datatunner.core.mixer import DataMixer
from datatunner.utils.visualization import ResultsVisualizer
from datatunner.generators.smote import SMOTEGenerator

# Verificar se CTGAN esta disponivel
try:
    from datatunner.generators.ctgan import CTGANGenerator, TVAEGenerator
    CTGAN_AVAILABLE = True
    print("SDV/CTGAN encontrado!")
except (ImportError, TypeError):
    CTGAN_AVAILABLE = False
    print("AVISO: SDV nao encontrado. Usando SMOTE como fallback.")
    print("Para usar CTGAN: pip install sdv>=1.2.0")

# ============================================================
# CONFIGURACAO
# ============================================================
RANDOM_SEED = 42
EPOCHS = 15
BATCH_SIZE = 32
LEARNING_RATE = 0.001
PROPORTIONS = [0.0, 0.25, 0.5, 0.75, 1.0]
OUTPUT_DIR = 'results/tabular_ctgan'

os.makedirs(OUTPUT_DIR, exist_ok=True)
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def make_loader(X, y, batch_size=BATCH_SIZE, shuffle=True):
    ds = TensorDataset(torch.FloatTensor(X), torch.LongTensor(y))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=shuffle)


# ============================================================
# 1. GERAR DATASET TABULAR COMPLEXO
# ============================================================
print("\n" + "=" * 60)
print("DATATUNNER - Exemplo Tabular com CTGAN/TVAE")
print("=" * 60)

print("\n1. Gerando dataset tabular complexo...")

# Dataset com 10 features, 3 classes
X, y = make_classification(
    n_samples=500,
    n_features=15,
    n_informative=10,
    n_redundant=3,
    n_clusters_per_class=2,
    n_classes=3,
    class_sep=1.0,
    random_state=RANDOM_SEED,
    flip_y=0.05  # 5% de ruido nos labels
)

# Criar DataFrame com nomes descritivos
feature_names = [f'feature_{i}' for i in range(X.shape[1])]
df = pd.DataFrame(X, columns=feature_names)
df['target'] = y

# Normalizar
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=RANDOM_SEED, stratify=y
)

print(f"   Features: {X.shape[1]}")
print(f"   Classes: {len(np.unique(y))}")
print(f"   Treino: {X_train.shape[0]} amostras")
print(f"   Teste:  {X_test.shape[0]} amostras")
print(f"   Distribuicao: {np.bincount(y_train)}")


# ============================================================
# 2. GERAR DADOS SINTETICOS
# ============================================================
print("\n2. Gerando dados sinteticos...")

generators = {}

# Gerador 1: SMOTE (sempre disponivel)
print("\n   [SMOTE]")
smote_gen = SMOTEGenerator(k_neighbors=5, random_seed=RANDOM_SEED)
smote_gen.fit(X_train, y_train)
X_smote, y_smote = smote_gen.generate()
generators['SMOTE'] = (X_smote, y_smote, smote_gen)
print(f"   Gerado: {X_smote.shape[0]} amostras")

# Gerador 2: CTGAN (se disponivel)
if CTGAN_AVAILABLE:
    print("\n   [CTGAN]")
    try:
        # Criar DataFrame de treino
        df_train = pd.DataFrame(X_train, columns=feature_names)
        df_train['target'] = y_train

        ctgan_gen = CTGANGenerator(
            epochs=50,           # Mais epochs = melhor qualidade
            batch_size=100,
            generator_dim=(128, 128),
            discriminator_dim=(128, 128),
            random_seed=RANDOM_SEED,
            verbose=True
        )
        ctgan_gen.fit(df_train, labels=y_train, categorical_columns=['target'])
        X_ctgan, y_ctgan = ctgan_gen.generate(n_samples=len(X_train))

        generators['CTGAN'] = (X_ctgan, y_ctgan, ctgan_gen)
        print(f"   Gerado: {X_ctgan.shape[0]} amostras")
    except Exception as e:
        print(f"   CTGAN falhou: {e}")
        print("   Usando SMOTE como fallback")

# Gerador 3: TVAE (se disponivel)
if CTGAN_AVAILABLE:
    print("\n   [TVAE]")
    try:
        df_train = pd.DataFrame(X_train, columns=feature_names)
        df_train['target'] = y_train

        tvae_gen = TVAEGenerator(
            epochs=100,
            batch_size=200,
            embedding_dim=128,
            random_seed=RANDOM_SEED,
            verbose=True
        )
        tvae_gen.fit(df_train, labels=y_train, categorical_columns=['target'])
        X_tvae, y_tvae = tvae_gen.generate(n_samples=len(X_train))

        generators['TVAE'] = (X_tvae, y_tvae, tvae_gen)
        print(f"   Gerado: {X_tvae.shape[0]} amostras")
    except Exception as e:
        print(f"   TVAE falhou: {e}")

print(f"\n   Geradores disponiveis: {list(generators.keys())}")


# ============================================================
# 3. OTIMIZACAO DE PROPORCAO POR GERADOR
# ============================================================
print("\n3. Otimizando proporcoes por gerador...")

mixer = DataMixer(random_seed=RANDOM_SEED)
evaluator = ModelEvaluator(device='cpu', task_type='classification')
test_loader = make_loader(X_test, y_test, shuffle=False)
criterion = nn.CrossEntropyLoss()

all_results = {}

for gen_name, (X_syn, y_syn, gen) in generators.items():
    print(f"\n   === {gen_name} ===")
    results = {}

    for prop in PROPORTIONS:
        # Misturar
        if prop > 0 and len(X_syn) > 0:
            X_mix, y_mix = mixer.mix_tabular_data(
                X_train, y_train, X_syn, y_syn,
                proportion=prop, balance_classes=True
            )
        else:
            X_mix, y_mix = X_train.copy(), y_train.copy()

        # Modelo MLP
        model = MLPClassifier(
            input_dim=X_train.shape[1],
            num_classes=3,
            hidden_layers=[128, 64, 32],
            dropout=0.3
        )
        opt = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
        train_loader = make_loader(X_mix, y_mix)

        metrics, _ = evaluator.train_and_evaluate(
            model=model,
            train_loader=train_loader,
            val_loader=test_loader,
            test_loader=test_loader,
            optimizer=opt,
            criterion=criterion,
            epochs=EPOCHS,
            early_stopping_patience=5
        )
        results[prop] = metrics
        print(f"   a={prop:.2f}: acc={metrics['accuracy']:.4f}, f1={metrics['f1_score']:.4f}")

    all_results[gen_name] = results

    best_prop = max(results, key=lambda p: results[p]['accuracy'])
    print(f"   >> MELHOR a={best_prop:.2f}, acc={results[best_prop]['accuracy']:.4f}")


# ============================================================
# 4. COMPARACAO COM DEEPMLP
# ============================================================
print("\n4. Comparando MLP vs DeepMLP (melhor proporcao SMOTE)...")

best_smote_prop = max(all_results['SMOTE'], key=lambda p: all_results['SMOTE'][p]['accuracy'])
X_syn_best, y_syn_best = generators['SMOTE'][0], generators['SMOTE'][1]

if best_smote_prop > 0 and len(X_syn_best) > 0:
    X_mix, y_mix = mixer.mix_tabular_data(
        X_train, y_train, X_syn_best, y_syn_best,
        proportion=best_smote_prop, balance_classes=True
    )
else:
    X_mix, y_mix = X_train.copy(), y_train.copy()

# DeepMLP com residual connections
deep_model = DeepMLP(
    input_dim=X_train.shape[1],
    num_classes=3,
    hidden_layers=[256, 256, 128, 128, 64],
    dropout=0.3,
    use_residual=True
)
opt = torch.optim.Adam(deep_model.parameters(), lr=LEARNING_RATE)
train_loader = make_loader(X_mix, y_mix)

deep_metrics, _ = evaluator.train_and_evaluate(
    model=deep_model, train_loader=train_loader,
    val_loader=test_loader, test_loader=test_loader,
    optimizer=opt, criterion=criterion,
    epochs=EPOCHS, early_stopping_patience=5
)

print(f"   DeepMLP: acc={deep_metrics['accuracy']:.4f}, f1={deep_metrics['f1_score']:.4f}")
print(f"   MLP:     acc={all_results['SMOTE'][best_smote_prop]['accuracy']:.4f}")


# ============================================================
# 5. VISUALIZACOES
# ============================================================
print("\n5. Gerando visualizacoes...")

# Grafico comparativo de geradores
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

for gen_name, results in all_results.items():
    props = sorted(results.keys())
    accs = [results[p]['accuracy'] for p in props]
    f1s = [results[p]['f1_score'] for p in props]

    axes[0].plot(props, accs, 'o-', label=gen_name, linewidth=2, markersize=8)
    axes[1].plot(props, f1s, 'o-', label=gen_name, linewidth=2, markersize=8)

axes[0].set_xlabel('Proporcao (a)', fontsize=12)
axes[0].set_ylabel('Accuracy', fontsize=12)
axes[0].set_title('Accuracy vs Proporcao', fontsize=14)
axes[0].legend(fontsize=11)
axes[0].grid(True, alpha=0.3)

axes[1].set_xlabel('Proporcao (a)', fontsize=12)
axes[1].set_ylabel('F1-Score', fontsize=12)
axes[1].set_title('F1-Score vs Proporcao', fontsize=14)
axes[1].legend(fontsize=11)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'comparacao_geradores.png'), dpi=150)
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/comparacao_geradores.png")

# Relatorio HTML para cada gerador
viz = ResultsVisualizer(output_dir=OUTPUT_DIR)
for gen_name, results in all_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    viz.generate_summary_report(
        results=results,
        best_proportion=best,
        experiment_info={
            'data_type': 'tabular',
            'model_name': 'MLPClassifier [128, 64, 32]',
            'epochs': EPOCHS,
            'batch_size': BATCH_SIZE,
            'generator': gen_name,
            'dataset': 'Tabular simulado (15 features, 3 classes)'
        },
        save_name=f'relatorio_{gen_name.lower()}.html'
    )


# ============================================================
# 6. RESUMO FINAL
# ============================================================
print("\n" + "=" * 60)
print("RESUMO FINAL")
print("=" * 60)

print(f"\nDataset: 500 amostras, {X.shape[1]} features, 3 classes")
print(f"Treino: {X_train.shape[0]} | Teste: {X_test.shape[0]}")
print(f"\nResultados por gerador:")

for gen_name, results in all_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    print(f"\n  {gen_name}:")
    print(f"    Melhor a = {best:.2f}")
    print(f"    Accuracy: {results[best]['accuracy']:.4f}")
    print(f"    F1-Score: {results[best]['f1_score']:.4f}")

print(f"\nDeepMLP (a={best_smote_prop:.2f}):")
print(f"    Accuracy: {deep_metrics['accuracy']:.4f}")
print(f"    F1-Score: {deep_metrics['f1_score']:.4f}")

print(f"\nArquivos gerados em: {OUTPUT_DIR}/")
print("\n" + "=" * 60)
print("Exemplo concluido com sucesso!")
print("=" * 60)
