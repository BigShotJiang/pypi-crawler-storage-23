"""
DataTunner - Exemplo de Imagem com Data Augmentation
=====================================================

Demonstra o uso do DataTunner para dados de imagem usando
ImageAugmentation como gerador de dados sinteticos.

Dataset: CIFAR-10 (subset de 2 classes)
Gerador: ImageAugmentation (light, medium, heavy)
Modelos: CustomCNN, ResNetClassifier

Instalacao:
    pip install datatunner torch torchvision albumentations

Uso:
    python example_image_augmentation.py

NOTA: Gera um dataset de imagens em disco para simular cenario real.
"""

import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from PIL import Image
from pathlib import Path

# ============================================================
# SETUP
# ============================================================
# Adicionar path se executando localmente (compatível com Colab/Jupyter)
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
except NameError:
    sys.path.insert(0, os.getcwd())

from datatunner.generators.augmentation import ImageAugmentation
from datatunner.models.cnn import CustomCNN, ResNetClassifier
from datatunner.core.evaluator import ModelEvaluator
from datatunner.core.mixer import DataMixer
from datatunner.utils.visualization import ResultsVisualizer
from datatunner.utils.data_loader import ImageDataset, DataLoader as DTDataLoader

# ============================================================
# CONFIGURACAO
# ============================================================
RANDOM_SEED = 42
EPOCHS = 5        # Reduzido para demo rapida
BATCH_SIZE = 32
LEARNING_RATE = 0.001
PROPORTIONS = [0.0, 0.25, 0.5, 0.75, 1.0]
IMAGE_SIZE = (64, 64)   # Tamanho das imagens
NUM_SAMPLES = 50         # Amostras por classe (reduzido para rapidez)
NUM_CLASSES = 3
OUTPUT_DIR = 'results/image_augmentation'

DATA_DIR = 'data/synthetic_shapes'
REAL_DIR = os.path.join(DATA_DIR, 'real')
SYNTH_DIR = os.path.join(DATA_DIR, 'synthetic')
TEST_DIR = os.path.join(DATA_DIR, 'test')

os.makedirs(OUTPUT_DIR, exist_ok=True)

np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# ============================================================
# 1. GERAR DATASET DE IMAGENS SINTETICAS
# ============================================================
print("=" * 60)
print("DATATUNNER - Exemplo de Imagem com Data Augmentation")
print("=" * 60)

print("\n1. Gerando dataset de imagens sinteticas...")

CLASS_NAMES = ['circulo', 'quadrado', 'triangulo']
CLASS_COLORS = [(255, 100, 100), (100, 255, 100), (100, 100, 255)]


def generate_shape_image(shape_type, size=64, variation=True):
    """Gera imagem de forma geometrica com variacao"""
    from PIL import ImageDraw

    img = Image.new('RGB', (size, size), (20, 20, 30))
    draw = ImageDraw.Draw(img)
    margin = size // 6

    # Variacao aleatoria
    if variation:
        offset_x = np.random.randint(-5, 5)
        offset_y = np.random.randint(-5, 5)
        color_var = np.random.randint(-30, 30)
    else:
        offset_x = offset_y = color_var = 0

    color = tuple(max(0, min(255, c + color_var)) for c in CLASS_COLORS[shape_type])

    if shape_type == 0:  # Circulo
        draw.ellipse(
            [margin + offset_x, margin + offset_y,
             size - margin + offset_x, size - margin + offset_y],
            fill=color
        )
    elif shape_type == 1:  # Quadrado
        draw.rectangle(
            [margin + offset_x, margin + offset_y,
             size - margin + offset_x, size - margin + offset_y],
            fill=color
        )
    elif shape_type == 2:  # Triangulo
        points = [
            (size // 2 + offset_x, margin + offset_y),
            (margin + offset_x, size - margin + offset_y),
            (size - margin + offset_x, size - margin + offset_y)
        ]
        draw.polygon(points, fill=color)

    return img


def generate_dataset(base_dir, n_per_class=50, name="dataset"):
    """Gera dataset de formas e salva em disco"""
    paths = []
    labels = []

    for class_idx, class_name in enumerate(CLASS_NAMES):
        class_dir = os.path.join(base_dir, class_name)
        os.makedirs(class_dir, exist_ok=True)

        for i in range(n_per_class):
            img = generate_shape_image(class_idx, size=IMAGE_SIZE[0], variation=True)
            img_path = os.path.join(class_dir, f'{class_name}_{i:04d}.png')
            img.save(img_path)

            paths.append(img_path)
            labels.append(class_idx)

    print(f"   {name}: {len(paths)} imagens ({n_per_class}/classe)")
    return paths, labels


# Gerar datasets
real_paths, real_labels = generate_dataset(REAL_DIR, NUM_SAMPLES, "Treino (real)")
test_paths, test_labels = generate_dataset(TEST_DIR, NUM_SAMPLES // 2, "Teste")

print(f"   Classes: {CLASS_NAMES}")
print(f"   Tamanho: {IMAGE_SIZE}")


# ============================================================
# 2. GERAR DADOS SINTETICOS COM AUGMENTATION
# ============================================================
print("\n2. Gerando dados sinteticos com Data Augmentation...")

strengths = ['light', 'medium', 'heavy']
aug_results = {}

for strength in strengths:
    print(f"\n   [{strength.upper()}]")

    augmentor = ImageAugmentation(
        random_seed=RANDOM_SEED,
        augmentation_strength=strength
    )
    augmentor.fit(real_paths, real_labels)

    # Gerar imagens augmentadas e salvar
    synth_dir = os.path.join(SYNTH_DIR, strength)
    aug_paths, aug_labels = augmentor.generate(
        n_samples=NUM_SAMPLES * NUM_CLASSES,
        output_dir=synth_dir,
        save_images=True
    )

    aug_results[strength] = {
        'paths': aug_paths,
        'labels': aug_labels if isinstance(aug_labels, list) else list(aug_labels),
        'generator': augmentor
    }
    print(f"   Gerado: {len(aug_paths)} imagens augmentadas")
    print(f"   Info: {augmentor.get_generator_info()}")


# ============================================================
# 3. VISUALIZAR AUGMENTATIONS
# ============================================================
print("\n3. Visualizando augmentations...")

fig, axes = plt.subplots(len(strengths) + 1, 5, figsize=(15, 3 * (len(strengths) + 1)))

# Originais
for i in range(5):
    img = Image.open(real_paths[i])
    axes[0, i].imshow(img)
    axes[0, i].axis('off')
    if i == 0:
        axes[0, i].set_title('Original', fontsize=12, fontweight='bold')

# Augmentados por intensidade
for s_idx, strength in enumerate(strengths):
    aug_data = aug_results[strength]
    for i in range(min(5, len(aug_data['paths']))):
        try:
            img = Image.open(aug_data['paths'][i])
            axes[s_idx + 1, i].imshow(img)
        except Exception:
            pass
        axes[s_idx + 1, i].axis('off')
        if i == 0:
            axes[s_idx + 1, i].set_title(f'{strength.capitalize()}', fontsize=12, fontweight='bold')

plt.suptitle('Data Augmentation: Original vs Augmentado', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'augmentation_samples.png'), dpi=150)
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/augmentation_samples.png")


# ============================================================
# 4. OTIMIZACAO COM CUSTOMCNN
# ============================================================
print("\n4. Otimizando proporcoes com CustomCNN...")

evaluator = ModelEvaluator(device='cpu', task_type='classification')
criterion = nn.CrossEntropyLoss()

# Get transforms
transforms = DTDataLoader.get_image_transforms(
    image_size=IMAGE_SIZE, augment=False, normalize=True
)

# Test dataset
test_dataset = ImageDataset(test_paths, np.array(test_labels), transform=transforms)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

mixer = DataMixer(random_seed=RANDOM_SEED)
all_strength_results = {}

for strength in strengths:
    print(f"\n   === Augmentation: {strength} ===")

    aug_data = aug_results[strength]
    synth_paths = aug_data['paths']
    synth_labels = aug_data['labels']

    results = {}

    for prop in PROPORTIONS:
        # Misturar paths
        if prop > 0:
            mixed_paths, mixed_labels = mixer.mix_image_data(
                real_paths, real_labels,
                synth_paths, synth_labels,
                proportion=prop, balance_classes=True
            )
        else:
            mixed_paths = list(real_paths)
            mixed_labels = list(real_labels)

        # Criar dataset e loader
        train_dataset = ImageDataset(mixed_paths, np.array(mixed_labels), transform=transforms)
        train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

        # Modelo novo
        model = CustomCNN(
            num_classes=NUM_CLASSES,
            input_channels=3,
            dropout=0.3
        )
        optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

        # Treinar
        metrics, _ = evaluator.train_and_evaluate(
            model=model,
            train_loader=train_loader,
            val_loader=test_loader,
            test_loader=test_loader,
            optimizer=optimizer,
            criterion=criterion,
            epochs=EPOCHS,
            early_stopping_patience=3,
            class_names=CLASS_NAMES
        )

        results[prop] = metrics
        print(f"   a={prop:.2f}: acc={metrics['accuracy']:.4f}")

    all_strength_results[strength] = results

    best_prop = max(results, key=lambda p: results[p]['accuracy'])
    print(f"   >> MELHOR a={best_prop:.2f}, acc={results[best_prop]['accuracy']:.4f}")


# ============================================================
# 5. COMPARACAO COM RESNET
# ============================================================
print("\n5. Comparando com ResNet18 (melhor augmentation)...")

# Encontrar melhor strength
best_strength = max(
    all_strength_results,
    key=lambda s: max(all_strength_results[s][p]['accuracy'] for p in PROPORTIONS)
)
best_prop_overall = max(
    all_strength_results[best_strength],
    key=lambda p: all_strength_results[best_strength][p]['accuracy']
)

print(f"   Melhor augmentation: {best_strength}")
print(f"   Melhor proporcao: {best_prop_overall}")

# Preparar dados com melhor configuracao
aug_data = aug_results[best_strength]
if best_prop_overall > 0:
    mixed_paths, mixed_labels = mixer.mix_image_data(
        real_paths, real_labels,
        aug_data['paths'], aug_data['labels'],
        proportion=best_prop_overall, balance_classes=True
    )
else:
    mixed_paths = list(real_paths)
    mixed_labels = list(real_labels)

# ResNet precisa de imagens 224x224
resnet_transforms = DTDataLoader.get_image_transforms(
    image_size=(224, 224), augment=False, normalize=True
)

train_dataset_resnet = ImageDataset(mixed_paths, np.array(mixed_labels), transform=resnet_transforms)
train_loader_resnet = DataLoader(train_dataset_resnet, batch_size=BATCH_SIZE, shuffle=True)

test_dataset_resnet = ImageDataset(test_paths, np.array(test_labels), transform=resnet_transforms)
test_loader_resnet = DataLoader(test_dataset_resnet, batch_size=BATCH_SIZE, shuffle=False)

resnet_model = ResNetClassifier(
    num_classes=NUM_CLASSES,
    architecture='resnet18',
    pretrained=True,
    freeze_backbone=True
)
opt_resnet = torch.optim.Adam(
    filter(lambda p: p.requires_grad, resnet_model.parameters()),
    lr=LEARNING_RATE
)

resnet_metrics, _ = evaluator.train_and_evaluate(
    model=resnet_model,
    train_loader=train_loader_resnet,
    val_loader=test_loader_resnet,
    test_loader=test_loader_resnet,
    optimizer=opt_resnet,
    criterion=criterion,
    epochs=EPOCHS,
    early_stopping_patience=3,
    class_names=CLASS_NAMES
)

print(f"   ResNet18: acc={resnet_metrics['accuracy']:.4f}, f1={resnet_metrics['f1_score']:.4f}")
best_cnn_acc = all_strength_results[best_strength][best_prop_overall]['accuracy']
print(f"   CustomCNN: acc={best_cnn_acc:.4f}")


# ============================================================
# 6. VISUALIZACOES
# ============================================================
print("\n6. Gerando graficos...")

# Comparacao por intensidade
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

for strength, results in all_strength_results.items():
    props = sorted(results.keys())
    accs = [results[p]['accuracy'] for p in props]
    f1s = [results[p]['f1_score'] for p in props]

    axes[0].plot(props, accs, 'o-', label=f'{strength.capitalize()}', linewidth=2, markersize=8)
    axes[1].plot(props, f1s, 'o-', label=f'{strength.capitalize()}', linewidth=2, markersize=8)

axes[0].set_xlabel('Proporcao (a)', fontsize=12)
axes[0].set_ylabel('Accuracy', fontsize=12)
axes[0].set_title('Accuracy por Intensidade de Augmentation', fontsize=14)
axes[0].legend(fontsize=11)
axes[0].grid(True, alpha=0.3)

axes[1].set_xlabel('Proporcao (a)', fontsize=12)
axes[1].set_ylabel('F1-Score', fontsize=12)
axes[1].set_title('F1-Score por Intensidade de Augmentation', fontsize=14)
axes[1].legend(fontsize=11)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'comparacao_augmentation.png'), dpi=150)
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/comparacao_augmentation.png")

# Relatorios
viz = ResultsVisualizer(output_dir=OUTPUT_DIR)
for strength, results in all_strength_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    viz.generate_summary_report(
        results=results,
        best_proportion=best,
        experiment_info={
            'data_type': 'image',
            'model_name': 'CustomCNN',
            'epochs': EPOCHS,
            'batch_size': BATCH_SIZE,
            'generator': f'ImageAugmentation ({strength})',
            'dataset': f'Formas Geometricas ({IMAGE_SIZE[0]}x{IMAGE_SIZE[1]})'
        },
        save_name=f'relatorio_aug_{strength}.html'
    )


# ============================================================
# 7. RESUMO FINAL
# ============================================================
print("\n" + "=" * 60)
print("RESUMO FINAL")
print("=" * 60)

print(f"""
Dataset: Formas Geometricas ({IMAGE_SIZE[0]}x{IMAGE_SIZE[1]})
  Classes: {CLASS_NAMES}
  Treino: {len(real_paths)} imagens | Teste: {len(test_paths)} imagens

Resultados por intensidade de Augmentation:""")

for strength, results in all_strength_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    print(f"\n  {strength.upper()}:")
    print(f"    Melhor a = {best:.2f}")
    print(f"    Accuracy: {results[best]['accuracy']:.4f}")
    print(f"    F1-Score: {results[best]['f1_score']:.4f}")

print(f"""
ResNet18 (pretrained, a={best_prop_overall:.2f}):
    Accuracy: {resnet_metrics['accuracy']:.4f}
    F1-Score: {resnet_metrics['f1_score']:.4f}

Arquivos gerados em: {OUTPUT_DIR}/
""")

print("=" * 60)
print("Exemplo concluido com sucesso!")
print("=" * 60)
