"""
============================================================================
🎯 CIFAR-10 - Exemplo Funcional Usando DataTunner (pypi-style)
============================================================================

Este script é auto-contido e realiza:
1. Instalação do datatunner (se necessário).
2. Download e preparação de um subset do CIFAR-10.
3. Geração de dados de augmentation (sintéticos).
4. Otimização de proporção usando ResNet18.

USO NO GOOGLE COLAB:
Capie e cole todo este conteúdo em uma célula e execute.
Lembre-se de reiniciar o runtime após a primeira instalação!
============================================================================
"""

import os
import sys
import subprocess

# 1. Instalação Automática (Opcional, mas útil)
def install_datatunner():
    try:
        import datatunner
        print(f"✅ DataTunner v{datatunner.__version__} já está instalado.")
    except ImportError:
        print("📦 Instalando DataTunner...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-U", "datatunner"])
        print("✅ Instalado! Por favor, REINICIE O RUNTIME se for a primeira vez.")
    
    # Verificação de versão mínima para robustez
    import datatunner
    from packaging import version
    if version.parse(datatunner.__version__) < version.parse("0.1.5"):
        print(f"⚠️ Sua versão ({datatunner.__version__}) é antiga. Atualizando para v0.1.5+...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-U", "datatunner"])
        print("✅ Atualizado! Por favor, REINICIE O RUNTIME para aplicar as correções.")

# Comente a linha abaixo se preferir instalar manualmente
# install_datatunner()

import torch
import numpy as np
from torchvision import datasets, transforms
from PIL import Image
from pathlib import Path
import matplotlib.pyplot as plt

# Importar DataTunner
try:
    from datatunner import DataTunner
    from datatunner.models.cnn import ResNetClassifier
    from datatunner.generators.augmentation import ImageAugmentation
except ImportError:
    print("❌ Erro ao importar datatunner. Certifique-se de que instalou e reiniciou o runtime.")
    sys.exit(1)

# ============================================================================
# 2. CONFIGURAÇÕES
# ============================================================================
print("\n" + "=" * 70)
print("🎯 EXEMPLO CIFAR-10 COM DATATUNNER")
print("=" * 70)

RANDOM_SEED = 42
SUBSET_SIZE = 500       # Imagens reais por classe
SYNTH_SIZE = 500        # Imagens sintéticas por classe
OUTPUT_DIR = "results/cifar10"
DATA_DIR = "data/cifar10"
NUM_CLASSES = 10

np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🖥️  Dispositivo: {device}")

# ============================================================================
# 3. PREPARAR DADOS (Download e salvamento em disco)
# ============================================================================
def prepare_data():
    print("\n📂 Preparando CIFAR-10...")
    
    os.makedirs(f"{DATA_DIR}/real", exist_ok=True)
    os.makedirs(f"{DATA_DIR}/test", exist_ok=True)
    os.makedirs(f"{DATA_DIR}/synthetic", exist_ok=True)
    
    # Download
    train_set = datasets.CIFAR10(root='./data', train=True, download=True)
    test_set = datasets.CIFAR10(root='./data', train=False, download=True)
    
    classes = train_set.classes
    
    # Salvar Real (Subset)
    print(f"💾 Salvando {SUBSET_SIZE} imagens reais/classe em {DATA_DIR}/real...")
    for class_idx, class_name in enumerate(classes):
        class_path = Path(DATA_DIR) / "real" / class_name
        class_path.mkdir(parents=True, exist_ok=True)
        
        # Filtrar índices desta classe
        indices = [i for i, label in enumerate(train_set.targets) if label == class_idx]
        subset_indices = indices[:SUBSET_SIZE]
        
        for i, idx in enumerate(subset_indices):
            img, _ = train_set[idx]
            img.save(class_path / f"img_{i}.png")
            
    # Salvar Teste (Subset)
    print(f"💾 Salvando 100 imagens de teste/classe em {DATA_DIR}/test...")
    for class_idx, class_name in enumerate(classes):
        class_path = Path(DATA_DIR) / "test" / class_name
        class_path.mkdir(parents=True, exist_ok=True)
        
        indices = [i for i, label in enumerate(test_set.targets) if label == class_idx]
        for i, idx in enumerate(indices[:100]):
            img, _ = test_set[idx]
            img.save(class_path / f"img_{i}.png")

    # ============================================================================
    # 4. GERAR DADOS SINTÉTICOS (Augmentation)
    # ============================================================================
    print("\n🔄 Gerando dados sintéticos (Data Augmentation)...")
    augmenter = ImageAugmentation(augmentation_strength="medium")
    
    # Gerar a partir do diretório de reais e salvar no diretório de sintéticos
    augmenter.generate_to_directory(
        input_dir=f"{DATA_DIR}/real",
        output_dir=f"{DATA_DIR}/synthetic",
        samples_per_image=1,
        max_samples_per_class=SYNTH_SIZE
    )
    print(f"✅ Sintéticos gerados em {DATA_DIR}/synthetic")

# Só rodar preparação se os dados não existirem
if not os.path.exists(f"{DATA_DIR}/real"):
    prepare_data()

# ============================================================================
# 5. CONFIGURAR E EXECUTAR DATATUNNER
# ============================================================================
print("\n⚙️  Configurando DataTunner...")

tunner = DataTunner(
    data_type='image',
    real_data_path=f"{DATA_DIR}/real",
    synthetic_data_path=f"{DATA_DIR}/synthetic",
    test_data_path=f"{DATA_DIR}/test",
    output_dir=OUTPUT_DIR,
    random_seed=RANDOM_SEED
)

# Definir modelo
print("\n🧠 Definindo Modelo (ResNet18)...")
model = ResNetClassifier(num_classes=NUM_CLASSES, architecture='resnet18')

# Executar otimização
print("\n🚀 Iniciando otimização...")
results = tunner.optimize(
    model=model,
    proportions=[0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9],
    epochs=10,        # Ajustado para teste mais rápido
    batch_size=64,
    n_trials=1        # Use 3 para maior robustez acadêmica
)

# Visualizar resultados
print("\n📊 Gerando resultados...")
tunner.plot_results()
print(f"\n✅ Melhor proporção: {results['best_proportion']:.1%}")
print(f"✅ Accuracy na melhor proporção: {results['best_metrics']['accuracy']:.4f}")

print("\n" + "=" * 70)
print(f"🚀 FIM DO EXEMPLO. Resultados salvos em: {OUTPUT_DIR}")
print("=" * 70)
