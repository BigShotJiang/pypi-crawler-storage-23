"""
DataTunner - Exemplo Tabular com SMOTE
======================================

Demonstra o uso do DataTunner para dados tabulares usando SMOTE
como gerador de dados sinteticos.

Dataset: Iris (sklearn)
Gerador: SMOTEGenerator (standard, borderline, adasyn)
Modelo: MLPClassifier

Instalacao:
    pip install datatunner scikit-learn

Uso:
    python example_tabular_smote.py
"""

import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ============================================================
# SETUP DO DATATUNNER
# ============================================================
# Adicionar path se executando localmente (compatível com Colab/Jupyter)
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
except NameError:
    sys.path.insert(0, os.getcwd())

from datatunner.generators.smote import SMOTEGenerator, GaussianNoiseGenerator
from datatunner.models.mlp import MLPClassifier
from datatunner.core.evaluator import ModelEvaluator
from datatunner.core.mixer import DataMixer
from datatunner.utils.visualization import ResultsVisualizer
from datatunner.utils.metrics import compute_metrics

# ============================================================
# CONFIGURACAO
# ============================================================
RANDOM_SEED = 42
EPOCHS = 20
BATCH_SIZE = 16
LEARNING_RATE = 0.001
PROPORTIONS = [0.0, 0.25, 0.5, 0.75, 1.0]
OUTPUT_DIR = 'results/tabular_smote'

os.makedirs(OUTPUT_DIR, exist_ok=True)

np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

# Usar backend nao-interativo para salvar graficos
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def make_loader(X, y, batch_size=BATCH_SIZE, shuffle=True):
    """Cria DataLoader PyTorch a partir de arrays numpy"""
    ds = TensorDataset(torch.FloatTensor(X), torch.LongTensor(y))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=shuffle)


# ============================================================
# 1. CARREGAR E PREPARAR DADOS
# ============================================================
print("=" * 60)
print("DATATUNNER - Exemplo Tabular com SMOTE")
print("=" * 60)

print("\n1. Carregando dataset Iris...")
iris = load_iris()
X, y = iris.data, iris.target
class_names = list(iris.target_names)

# Normalizar features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split treino/teste
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=RANDOM_SEED, stratify=y
)

print(f"   Dataset: Iris ({X.shape[1]} features, {len(class_names)} classes)")
print(f"   Classes: {class_names}")
print(f"   Treino: {X_train.shape[0]} amostras")
print(f"   Teste:  {X_test.shape[0]} amostras")
print(f"   Distribuicao treino: {np.bincount(y_train)}")


# ============================================================
# 2. GERAR DADOS SINTETICOS COM SMOTE
# ============================================================
print("\n2. Gerando dados sinteticos com SMOTE...")

generator = SMOTEGenerator(
    k_neighbors=5,
    random_seed=RANDOM_SEED,
    variant='standard'   # Opcoes: 'standard', 'borderline', 'adasyn'
)
generator.fit(X_train, y_train)
X_synthetic, y_synthetic = generator.generate()

print(f"   Gerador: {generator.generator_name}")
print(f"   Dados sinteticos: {X_synthetic.shape[0]} amostras")
print(f"   Distribuicao sintetica: {np.bincount(y_synthetic) if len(y_synthetic) > 0 else 'vazio'}")


# ============================================================
# 3. GERAR DADOS COM RUIDO GAUSSIANO (comparacao)
# ============================================================
print("\n3. Gerando dados com Ruido Gaussiano...")

gn_generator = GaussianNoiseGenerator(noise_level=0.1, random_seed=RANDOM_SEED)
gn_generator.fit(X_train, y_train)
X_gauss, y_gauss = gn_generator.generate(n_samples=len(X_train))

print(f"   Gerador: {gn_generator.generator_name}")
print(f"   Dados sinteticos: {X_gauss.shape[0]} amostras")


# ============================================================
# 4. OTIMIZACAO DE PROPORCAO - SMOTE
# ============================================================
print("\n4. Otimizando proporcao com SMOTE...")
print(f"   Proporcoes: {PROPORTIONS}")
print(f"   Epocas: {EPOCHS}")
print(f"   Batch size: {BATCH_SIZE}")

mixer = DataMixer(random_seed=RANDOM_SEED)
evaluator = ModelEvaluator(device='cpu', task_type='classification')
test_loader = make_loader(X_test, y_test, shuffle=False)
criterion = nn.CrossEntropyLoss()

results_smote = {}

for prop in PROPORTIONS:
    print(f"\n   --- Proporcao a={prop:.2f} ---")

    # Misturar dados
    if prop > 0 and len(X_synthetic) > 0:
        X_mix, y_mix = mixer.mix_tabular_data(
            X_train, y_train, X_synthetic, y_synthetic,
            proportion=prop, balance_classes=True
        )
    else:
        X_mix, y_mix = X_train.copy(), y_train.copy()

    print(f"   Dataset: {X_mix.shape[0]} amostras (real + sintetico)")

    # Criar modelo novo
    model = MLPClassifier(
        input_dim=X_train.shape[1],
        num_classes=len(class_names),
        hidden_layers=[64, 32],
        dropout=0.3
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    train_loader = make_loader(X_mix, y_mix)

    # Treinar e avaliar
    metrics, history = evaluator.train_and_evaluate(
        model=model,
        train_loader=train_loader,
        val_loader=test_loader,
        test_loader=test_loader,
        optimizer=optimizer,
        criterion=criterion,
        epochs=EPOCHS,
        early_stopping_patience=5
    )

    results_smote[prop] = metrics
    print(f"   Accuracy: {metrics['accuracy']:.4f}")
    print(f"   F1-Score: {metrics['f1_score']:.4f}")

# Melhor proporcao SMOTE
best_smote = max(results_smote, key=lambda p: results_smote[p]['accuracy'])
print(f"\n   >> MELHOR a (SMOTE) = {best_smote:.2f}")
print(f"   >> Accuracy = {results_smote[best_smote]['accuracy']:.4f}")


# ============================================================
# 5. OTIMIZACAO DE PROPORCAO - GAUSSIAN NOISE
# ============================================================
print("\n5. Otimizando proporcao com Gaussian Noise...")

results_gauss = {}

for prop in PROPORTIONS:
    if prop > 0:
        X_mix, y_mix = mixer.mix_tabular_data(
            X_train, y_train, X_gauss, y_gauss,
            proportion=prop, balance_classes=True
        )
    else:
        X_mix, y_mix = X_train.copy(), y_train.copy()

    model = MLPClassifier(
        input_dim=X_train.shape[1],
        num_classes=len(class_names),
        hidden_layers=[64, 32],
        dropout=0.3
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    train_loader = make_loader(X_mix, y_mix)

    metrics, _ = evaluator.train_and_evaluate(
        model=model,
        train_loader=train_loader,
        val_loader=test_loader,
        test_loader=test_loader,
        optimizer=optimizer,
        criterion=criterion,
        epochs=EPOCHS,
        early_stopping_patience=5
    )

    results_gauss[prop] = metrics

best_gauss = max(results_gauss, key=lambda p: results_gauss[p]['accuracy'])
print(f"\n   >> MELHOR a (GaussianNoise) = {best_gauss:.2f}")
print(f"   >> Accuracy = {results_gauss[best_gauss]['accuracy']:.4f}")


# ============================================================
# 6. COMPARACAO E VISUALIZACAO
# ============================================================
print("\n6. Gerando graficos comparativos...")

# Grafico 1: Accuracy vs Proporcao
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# SMOTE
props = sorted(results_smote.keys())
accs_smote = [results_smote[p]['accuracy'] for p in props]
f1s_smote = [results_smote[p]['f1_score'] for p in props]

# Gaussian
accs_gauss = [results_gauss[p]['accuracy'] for p in props]
f1s_gauss = [results_gauss[p]['f1_score'] for p in props]

# Plot Accuracy
axes[0].plot(props, accs_smote, 'o-', label='SMOTE', linewidth=2, markersize=8)
axes[0].plot(props, accs_gauss, 's--', label='Gaussian Noise', linewidth=2, markersize=8)
axes[0].set_xlabel('Proporcao (a)', fontsize=12)
axes[0].set_ylabel('Accuracy', fontsize=12)
axes[0].set_title('Accuracy vs Proporcao de Dados Sinteticos', fontsize=14)
axes[0].legend(fontsize=11)
axes[0].grid(True, alpha=0.3)

# Plot F1-Score
axes[1].plot(props, f1s_smote, 'o-', label='SMOTE', linewidth=2, markersize=8)
axes[1].plot(props, f1s_gauss, 's--', label='Gaussian Noise', linewidth=2, markersize=8)
axes[1].set_xlabel('Proporcao (a)', fontsize=12)
axes[1].set_ylabel('F1-Score', fontsize=12)
axes[1].set_title('F1-Score vs Proporcao de Dados Sinteticos', fontsize=14)
axes[1].legend(fontsize=11)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'comparacao_geradores.png'), dpi=150)
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/comparacao_geradores.png")

# Grafico 2: Tabela de resultados
fig, ax = plt.subplots(figsize=(12, 4))
ax.axis('off')

table_data = [['Proporcao', 'SMOTE Acc', 'SMOTE F1', 'Gauss Acc', 'Gauss F1']]
for p in props:
    table_data.append([
        f'{p:.2f}',
        f'{results_smote[p]["accuracy"]:.4f}',
        f'{results_smote[p]["f1_score"]:.4f}',
        f'{results_gauss[p]["accuracy"]:.4f}',
        f'{results_gauss[p]["f1_score"]:.4f}'
    ])

table = ax.table(cellText=table_data[1:], colLabels=table_data[0],
                 loc='center', cellLoc='center')
table.auto_set_font_size(False)
table.set_fontsize(11)
table.scale(1.2, 1.5)
plt.title('Resultados: SMOTE vs Gaussian Noise', fontsize=14, pad=20)
plt.savefig(os.path.join(OUTPUT_DIR, 'tabela_resultados.png'), dpi=150, bbox_inches='tight')
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/tabela_resultados.png")


# ============================================================
# 7. RELATORIO HTML
# ============================================================
print("\n7. Gerando relatorio HTML...")

viz = ResultsVisualizer(output_dir=OUTPUT_DIR)
viz.generate_summary_report(
    results=results_smote,
    best_proportion=best_smote,
    experiment_info={
        'data_type': 'tabular',
        'model_name': 'MLPClassifier [64, 32]',
        'epochs': EPOCHS,
        'batch_size': BATCH_SIZE,
        'dataset': 'Iris',
        'generator': 'SMOTE (standard)'
    },
    save_name='relatorio_smote.html'
)

viz.generate_summary_report(
    results=results_gauss,
    best_proportion=best_gauss,
    experiment_info={
        'data_type': 'tabular',
        'model_name': 'MLPClassifier [64, 32]',
        'epochs': EPOCHS,
        'batch_size': BATCH_SIZE,
        'dataset': 'Iris',
        'generator': 'GaussianNoise (0.1)'
    },
    save_name='relatorio_gaussnoise.html'
)


# ============================================================
# 8. RESUMO FINAL
# ============================================================
print("\n" + "=" * 60)
print("RESUMO FINAL")
print("=" * 60)

print(f"""
Dataset: Iris (150 amostras, 4 features, 3 classes)
Treino: {X_train.shape[0]} amostras | Teste: {X_test.shape[0]} amostras

Resultados SMOTE:
  Melhor proporcao: a = {best_smote:.2f}
  Accuracy:  {results_smote[best_smote]['accuracy']:.4f}
  F1-Score:  {results_smote[best_smote]['f1_score']:.4f}
  Precision: {results_smote[best_smote].get('precision', 0):.4f}
  Recall:    {results_smote[best_smote].get('recall', 0):.4f}

Resultados Gaussian Noise:
  Melhor proporcao: a = {best_gauss:.2f}
  Accuracy:  {results_gauss[best_gauss]['accuracy']:.4f}
  F1-Score:  {results_gauss[best_gauss]['f1_score']:.4f}

Arquivos gerados:
  - {OUTPUT_DIR}/comparacao_geradores.png
  - {OUTPUT_DIR}/tabela_resultados.png
  - {OUTPUT_DIR}/relatorio_smote.html
  - {OUTPUT_DIR}/relatorio_gaussnoise.html
""")

print("=" * 60)
print("Exemplo concluido com sucesso!")
print("=" * 60)
