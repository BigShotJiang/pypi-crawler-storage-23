"""mcp-print: MCP server for professional print and color workflows."""

__version__ = "0.3.0"
