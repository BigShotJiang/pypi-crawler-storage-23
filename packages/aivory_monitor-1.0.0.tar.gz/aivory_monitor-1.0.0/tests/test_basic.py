"""Basic tests for AIVory Monitor Python agent."""


def test_import():
    """Test that the module can be imported."""
    import aivory_monitor
    assert aivory_monitor is not None
