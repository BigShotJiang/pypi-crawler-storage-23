"""Tests for huntpdf.resolvers.pmc."""

from pathlib import Path
from unittest.mock import MagicMock

from huntpdf.resolvers.pmc import resolve_pmc


class TestResolvePmc:
    def test_success(self, monkeypatch, tmp_path):
        mock_download = MagicMock(return_value=tmp_path / "PMC7654321.pdf")
        monkeypatch.setattr("huntpdf.resolvers.pmc.download_pdf", mock_download)

        result = resolve_pmc("PMC7654321", tmp_path / "PMC7654321.pdf")
        assert result == tmp_path / "PMC7654321.pdf"
        mock_download.assert_called_once_with(
            "https://pmc.ncbi.nlm.nih.gov/articles/PMC7654321/pdf/",
            tmp_path / "PMC7654321.pdf",
        )

    def test_default_filename(self, monkeypatch, tmp_path):
        mock_download = MagicMock(return_value=tmp_path / "PMC7654321.pdf")
        monkeypatch.setattr("huntpdf.resolvers.pmc.download_pdf", mock_download)
        monkeypatch.chdir(tmp_path)

        resolve_pmc("PMC7654321")
        call_args = mock_download.call_args
        assert call_args[0][1].name == "PMC7654321.pdf"

    def test_custom_output_path(self, monkeypatch, tmp_path):
        custom_path = tmp_path / "subdir" / "custom.pdf"
        mock_download = MagicMock(return_value=custom_path)
        monkeypatch.setattr("huntpdf.resolvers.pmc.download_pdf", mock_download)

        result = resolve_pmc("PMC1234567", custom_path)
        assert result == custom_path
        mock_download.assert_called_once_with(
            "https://pmc.ncbi.nlm.nih.gov/articles/PMC1234567/pdf/",
            custom_path,
        )
