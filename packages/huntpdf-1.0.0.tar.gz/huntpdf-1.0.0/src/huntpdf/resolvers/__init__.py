"""Resolver modules for different input types."""
