"""Resolve PMC IDs to PDF files."""

from pathlib import Path

from huntpdf.download import download_pdf

_PMC_PDF_URL = "https://pmc.ncbi.nlm.nih.gov/articles/{pmc_id}/pdf/"


def resolve_pmc(pmc_id: str, output: Path | None = None) -> Path:
    """Download the PDF for a PubMed Central article.

    Args:
        pmc_id: A PMC identifier (e.g. "PMC7654321").
        output: Optional destination path. Defaults to current directory.

    Returns:
        Path to the downloaded PDF.

    Raises:
        PDFNotFound: If the PMC article PDF cannot be retrieved.
    """
    url = _PMC_PDF_URL.format(pmc_id=pmc_id)

    if output is None:
        output = Path.cwd() / f"{pmc_id}.pdf"

    return download_pdf(url, output)
