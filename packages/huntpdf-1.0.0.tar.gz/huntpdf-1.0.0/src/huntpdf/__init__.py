"""huntpdf — fetch PDFs of arxiv, DOI, and PubMed articles."""
