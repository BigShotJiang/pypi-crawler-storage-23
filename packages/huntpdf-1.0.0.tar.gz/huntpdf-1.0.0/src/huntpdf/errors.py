"""Exceptions for huntpdf."""


class HuntPDFError(Exception):
    """Base exception for huntpdf."""


class InputNotRecognized(HuntPDFError):
    """Raised when the input query cannot be classified."""


class PDFNotFound(HuntPDFError):
    """Raised when a PDF cannot be located for the given identifier."""


class DownloadFailed(HuntPDFError):
    """Raised when a PDF download fails after all attempts."""
