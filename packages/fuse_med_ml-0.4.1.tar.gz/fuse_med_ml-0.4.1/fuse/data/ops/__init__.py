from fuse.data.ops.caching_tools import get_function_call_str
