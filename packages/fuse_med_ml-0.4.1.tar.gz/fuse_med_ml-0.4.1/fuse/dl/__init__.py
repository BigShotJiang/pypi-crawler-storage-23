# version
from fuse.version import __version__
