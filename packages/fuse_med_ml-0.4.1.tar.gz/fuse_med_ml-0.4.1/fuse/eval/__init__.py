# version
# shortcuts
from fuse.eval.metrics.metrics_common import (
    MetricBase,
    MetricCollector,
    MetricWithCollectorBase,
)
from fuse.version import __version__
