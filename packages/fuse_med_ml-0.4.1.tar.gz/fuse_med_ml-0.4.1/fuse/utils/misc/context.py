# type: ignore
class DummyContext:
    def __init__(self, *args, **kwargs) -> None:
        pass

    def __enter__(self, *args, **kwargs):
        pass

    def __exit__(self, *args, **kwargs):
        pass
