from fuse.utils.cpu_profiling.profiler import Profiler
from fuse.utils.cpu_profiling.timer import Timer
