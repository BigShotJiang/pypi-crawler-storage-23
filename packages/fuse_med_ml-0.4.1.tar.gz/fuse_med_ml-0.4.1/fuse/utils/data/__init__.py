from fuse.utils.data.collate import CollateToBatchList
