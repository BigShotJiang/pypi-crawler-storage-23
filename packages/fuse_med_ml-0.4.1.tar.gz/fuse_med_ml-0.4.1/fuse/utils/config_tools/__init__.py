from fuse.utils.config_tools.config_tools import Config, get_config_function
