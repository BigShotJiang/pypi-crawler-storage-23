def load_config(config: dict) -> dict:
    config["banana"] = 12
    config["dvivonim"] = 10
    return config
