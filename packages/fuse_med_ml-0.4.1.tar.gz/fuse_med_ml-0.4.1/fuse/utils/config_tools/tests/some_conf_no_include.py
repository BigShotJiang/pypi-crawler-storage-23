def load_config(config: dict) -> dict:
    config["banana"] = 123
    return config
