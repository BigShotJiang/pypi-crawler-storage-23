from enum import Enum

_SYNTH_MAPPING = {
    'mwem': 'mwem.MWEM',
    'dpctgan': 'pytorch.nn.dpctgan.DPCTGAN',
}

