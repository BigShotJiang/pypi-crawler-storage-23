"""
chuk-mcp-her: Historic Environment Records MCP Server

Provides structured access to Historic Environment Records and national
heritage databases via ArcGIS REST APIs and web services. Extensible
across jurisdictions — England first (Historic England NHLE, AIM,
Heritage Gateway), with a source registry pattern for adding Scotland,
Wales, Ireland, and other countries as additional adapters.
"""
