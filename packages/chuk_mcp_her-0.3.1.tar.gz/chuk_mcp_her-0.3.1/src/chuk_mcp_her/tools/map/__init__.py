"""Map visualisation tools for chuk-mcp-her."""
