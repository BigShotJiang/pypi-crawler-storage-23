"""Scotland (Historic Environment Scotland) tools."""

from .api import register_scotland_tools

__all__ = ["register_scotland_tools"]
