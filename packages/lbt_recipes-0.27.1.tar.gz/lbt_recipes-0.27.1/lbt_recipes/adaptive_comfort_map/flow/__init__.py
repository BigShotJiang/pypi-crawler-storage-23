from threading import Lock

_queenbee_status_lock_ = Lock()
