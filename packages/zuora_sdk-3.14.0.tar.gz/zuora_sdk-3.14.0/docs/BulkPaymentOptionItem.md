# BulkPaymentOptionItem

Payment profile item containing subscription identifier and payment profile details. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscription_id** | **str** | The ID of the subscription for which the payment profile will be created or updated.  | 
**payment_gateway_id** | **str** | Specifies by ID the payment gateway to be assigned to the subscription.  | [optional] 
**payment_method_id** | **str** | Specifies by ID the payment method to be assigned to the subscription.  | [optional] 

## Example

```python
from zuora_sdk.models.bulk_payment_option_item import BulkPaymentOptionItem

# TODO update the JSON string below
json = "{}"
# create an instance of BulkPaymentOptionItem from a JSON string
bulk_payment_option_item_instance = BulkPaymentOptionItem.from_json(json)
# print the JSON string representation of the object
print(BulkPaymentOptionItem.to_json())

# convert the object into a dict
bulk_payment_option_item_dict = bulk_payment_option_item_instance.to_dict()
# create an instance of BulkPaymentOptionItem from a dict
bulk_payment_option_item_from_dict = BulkPaymentOptionItem.from_dict(bulk_payment_option_item_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


