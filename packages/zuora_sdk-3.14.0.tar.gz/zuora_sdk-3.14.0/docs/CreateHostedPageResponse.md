# CreateHostedPageResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**process_id** | **str** | The Id of the process that handle the operation.  | [optional] 
**request_id** | **str** | Unique request identifier. If you need to contact us about a specific request, providing the request identifier will ensure the fastest possible resolution.  | [optional] 
**reasons** | [**List[FailedReason]**](FailedReason.md) |  | [optional] 
**success** | **bool** | Indicates whether the call succeeded.  | [optional] [default to True]
**id** | **str** | Unique identifier of the Payment Page that Zuora assigns when it is created.  | [optional] 
**page_name** | **str** | Name of the Payment Page that was specified during the page configuration.  | [optional] 
**page_type** | **str** | Payment method type of this Payment Page.  Valid values: - &#x60;Credit Card&#x60; - For credit card payments - &#x60;ACH&#x60; - For ACH (Automated Clearing House) payments   - &#x60;Bank Transfer&#x60; - For bank transfer payments  | [optional] 
**page_version** | **int** | Version of the Payment Page. Always 2 for Payment Pages 2.0.  | [optional] 
**domain** | **str** | The domain where the hosted payment page is accessible.  | [optional] 
**callback_path** | **str** | The callback URL path that is used after payment processing is completed.  | [optional] 
**gateway** | **str** | The name or identifier of the payment gateway that processes payments from this hosted page.  | [optional] 
**allow_sub_domain** | **bool** | Indicates whether the hosted page can be accessed from subdomains of the specified domain.  | [optional] 

## Example

```python
from zuora_sdk.models.create_hosted_page_response import CreateHostedPageResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CreateHostedPageResponse from a JSON string
create_hosted_page_response_instance = CreateHostedPageResponse.from_json(json)
# print the JSON string representation of the object
print(CreateHostedPageResponse.to_json())

# convert the object into a dict
create_hosted_page_response_dict = create_hosted_page_response_instance.to_dict()
# create an instance of CreateHostedPageResponse from a dict
create_hosted_page_response_from_dict = CreateHostedPageResponse.from_dict(create_hosted_page_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


