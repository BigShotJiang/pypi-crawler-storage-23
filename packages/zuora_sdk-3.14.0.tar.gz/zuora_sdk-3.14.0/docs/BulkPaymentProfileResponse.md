# BulkPaymentProfileResponse

Response from bulk payment profile create or update operation.  For successful operations (200), returns only `{ \"success\": true }`.  For client errors (4XX), returns `success: false` with `processId`, `requestId`, and `reasons`.  For server errors (500), returns only `reasons` array. 

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **bool** | Indicates whether the overall bulk operation was successful. Returns &#x60;true&#x60; if all payment profiles were processed successfully. Returns &#x60;false&#x60; if any payment profile failed to process.  Note: This field is only present in 200 and 4XX responses, not in 500 errors.  | [optional] 
**process_id** | **str** | Process ID for tracking the request (only present in error responses).  | [optional] 
**request_id** | **str** | Request ID for tracking the request (only present in error responses).  | [optional] 
**reasons** | [**List[BulkPaymentProfileResponseReasonsInner]**](BulkPaymentProfileResponseReasonsInner.md) | Error reasons if the operation failed. Present in both 4XX and 500 error responses.  | [optional] 

## Example

```python
from zuora_sdk.models.bulk_payment_profile_response import BulkPaymentProfileResponse

# TODO update the JSON string below
json = "{}"
# create an instance of BulkPaymentProfileResponse from a JSON string
bulk_payment_profile_response_instance = BulkPaymentProfileResponse.from_json(json)
# print the JSON string representation of the object
print(BulkPaymentProfileResponse.to_json())

# convert the object into a dict
bulk_payment_profile_response_dict = bulk_payment_profile_response_instance.to_dict()
# create an instance of BulkPaymentProfileResponse from a dict
bulk_payment_profile_response_from_dict = BulkPaymentProfileResponse.from_dict(bulk_payment_profile_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


