# ChargeRemoval

The JSON object containing information for removing a charge in the 'UpdateProduct' type order action.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**charge_number** | **str** | The number of the charge to be removed. This must be an optional charge in a bundle rate plan.  **Note:** This field requires the EnableHardBundle permission to be enabled.  | 
**description** | **str** | Description of why the charge is being removed.  **Note:** This field does not accept JavaScript or HTML script content for security reasons.  | [optional] 

## Example

```python
from zuora_sdk.models.charge_removal import ChargeRemoval

# TODO update the JSON string below
json = "{}"
# create an instance of ChargeRemoval from a JSON string
charge_removal_instance = ChargeRemoval.from_json(json)
# print the JSON string representation of the object
print(ChargeRemoval.to_json())

# convert the object into a dict
charge_removal_dict = charge_removal_instance.to_dict()
# create an instance of ChargeRemoval from a dict
charge_removal_from_dict = ChargeRemoval.from_dict(charge_removal_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


