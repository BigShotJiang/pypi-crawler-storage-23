# CreatePaymentSchedulesResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**process_id** | **str** | The Id of the process that handle the operation.  | [optional] 
**request_id** | **str** | Unique request identifier. If you need to contact us about a specific request, providing the request identifier will ensure the fastest possible resolution.  | [optional] 
**reasons** | [**List[FailedReason]**](FailedReason.md) |  | [optional] 
**success** | **bool** | Indicates whether the call succeeded.  | [optional] [default to True]
**payment_schedules** | [**List[CreatePaymentSchedulesResponseItems]**](CreatePaymentSchedulesResponseItems.md) | Container for payment schedules.  | [optional] 

## Example

```python
from zuora_sdk.models.create_payment_schedules_response import CreatePaymentSchedulesResponse

# TODO update the JSON string below
json = "{}"
# create an instance of CreatePaymentSchedulesResponse from a JSON string
create_payment_schedules_response_instance = CreatePaymentSchedulesResponse.from_json(json)
# print the JSON string representation of the object
print(CreatePaymentSchedulesResponse.to_json())

# convert the object into a dict
create_payment_schedules_response_dict = create_payment_schedules_response_instance.to_dict()
# create an instance of CreatePaymentSchedulesResponse from a dict
create_payment_schedules_response_from_dict = CreatePaymentSchedulesResponse.from_dict(create_payment_schedules_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


