from datetime import datetime
from typing import Any

from pydantic import BaseModel
from sqlalchemy.orm import Session

import sunpeek.components as cmp
from sunpeek.core_methods import virtuals
from sunpeek.components.physical import convert_to_concrete_components, MountingFixed, MountingSingleAxis


def prepare_array_data(array_data: dict) -> dict:
    """Prepare array data from API for ORM Array creation.

    Handles conversion of mounting data from API format to ORM objects:
    - mounting dict with 'mounting_type' key → MountingFixed or MountingSingleAxis
    - Legacy tilt/azim parameters → MountingFixed (REST API backward compatibility)
    """
    data = dict(array_data)

    mounting = data.get('mounting')
    if isinstance(mounting, dict):
        mounting_type = mounting.get('mounting_type')
        if mounting_type == 'fixed':
            data['mounting'] = MountingFixed(
                surface_tilt=mounting.get('surface_tilt'),
                surface_azimuth=mounting.get('surface_azimuth'),
                name=mounting.get('name')
            )
        elif mounting_type == 'single_axis':
            data['mounting'] = MountingSingleAxis(
                axis_azimuth=mounting.get('axis_azimuth'),
                max_angle=mounting.get('max_angle'),
                name=mounting.get('name')
            )
        else:
            raise ValueError(f"Unknown mounting_type: {mounting_type}. Expected 'fixed' or 'single_axis'.")

    elif 'tilt' in data or 'azim' in data:
        tilt = data.pop('tilt', None)
        azim = data.pop('azim', None)
        data['mounting'] = MountingFixed(surface_tilt=tilt, surface_azimuth=azim)

    return data


def update_obj(obj: Any, update_model: BaseModel) -> Any:
    update_dict = update_model.model_dump(exclude_unset=True)

    for key, val in update_dict.items():
        if val != getattr(obj, key):
            setattr(obj, key, val)

    return obj


def update_plant(
    plant: cmp.Plant, update_model: BaseModel | None = None, session: Session | None = None
) -> cmp.Plant:
    """For a plant, update the plant including config-dependent virtual sensors state."""
    if update_model is not None:
        update_obj(plant, update_model)

    if session is not None:
        convert_to_concrete_components(session, plant)
    virtuals.config_virtuals(plant)

    return plant


def recalculate_plant(
    plant: cmp.Plant, eval_start: datetime | None, eval_end: datetime | None
) -> cmp.Plant:
    """For a plant, recalculate virtual sensors, set context and flush results to parquet."""
    plant.context.set_eval_interval(eval_start=eval_start, eval_end=eval_end)
    virtuals.calculate_virtuals(plant)
    plant.context.flush_virtuals_to_parquet()

    return plant
