import pickle
import weakref
from collections.abc import MutableMapping
from typing import TypeVar

from redis import Redis

K = TypeVar("K")
V = TypeVar("V")


class RedisDict(MutableMapping[K, V]):
    def __init__(self, redis: Redis, redis_key: str = None, persist: bool = False, overwrite: bool = True,
                 ttl: int = None, default_item_ttl: int = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.redis = redis
        self.redis_key = \
            (redis_key if ":" in redis_key else f"redis_dict:{redis_key}") \
            if redis_key is not None else f"redis_dict:{id(self)}"
        self.ttl = ttl
        self.default_item_ttl = default_item_ttl

        if self.redis.exists(self.redis_key):
            if overwrite:
                self.redis.delete(self.redis_key)
            else:
                raise ValueError(f"Redis key '{self.redis_key}' already exists and overwrite is set to False.")
        if not persist:
            weakref.finalize(self, self.redis.delete, self.redis_key)

    @staticmethod
    def __key(key: K) -> bytes:
        return pickle.dumps(key)

    @staticmethod
    def __value(value: V) -> bytes:
        return pickle.dumps(value)

    @staticmethod
    def __decode_key(key: bytes) -> K:
        return pickle.loads(key)

    @staticmethod
    def __decode_value(value: bytes) -> V:
        return pickle.loads(value)

    def set(self, key: K, value: V, ex: int = None):
        key = self.__key(key)
        self.redis.hset(self.redis_key, key, self.__value(value))

        if self.ttl is not None:
            self.redis.expire(self.redis_key, self.ttl)
        if ex is not None:
            self.redis.hexpire(self.redis_key, ex, key)

    def __setitem__(self, key: K, value: V):
        self.set(key, value, ex=self.default_item_ttl)

    def __delitem__(self, key: K):
        self.redis.hdel(self.redis_key, self.__key(key))

    def __getitem__(self, key: K) -> V:
        value = self.redis.hget(self.redis_key, self.__key(key))
        if value is None:
            raise KeyError(key)
        return self.__decode_value(value)

    def __contains__(self, key: K) -> bool:
        return self.redis.hexists(self.redis_key, self.__key(key))

    def __len__(self):
        return self.redis.hlen(self.redis_key)

    def __iter__(self):
        for key in self.redis.hkeys(self.redis_key):
            yield self.__decode_key(key)

    def __repr__(self):
        return f"RedisDict(redis_key={self.redis_key}) [{', '.join(f'{k}: {v}' for k, v in self.items())}]"
