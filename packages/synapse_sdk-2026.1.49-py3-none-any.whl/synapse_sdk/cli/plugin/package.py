"""Plugin package command implementation for offline/air-gapped environments."""

from __future__ import annotations

import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from rich.console import Console

# Supported package file extensions for pip download output
_PACKAGE_EXTENSIONS = ('*.whl', '*.tar.gz', '*.zip')


@dataclass
class PackageResult:
    """Result of plugin package operation."""

    wheel_count: int
    wheel_dir: Path
    requirements_modified: bool


def package_plugin(
    *,
    path: Path,
    output: Path,
    console: Console,
    platform: str | None = None,
    python_version: str | None = None,
) -> PackageResult:
    """Download wheels and modify requirements.txt for offline installation.

    Args:
        path: Plugin directory containing requirements.txt.
        output: Directory to store downloaded wheel files.
        console: Rich console for output.
        platform: Target platform for pip download (e.g., 'manylinux2014_x86_64').
        python_version: Target Python version (e.g., '3.12').

    Returns:
        PackageResult with download stats.

    Raises:
        FileNotFoundError: If requirements.txt is missing.
        RuntimeError: If pip download fails.
    """
    requirements_path = path / 'requirements.txt'
    if not requirements_path.exists():
        raise FileNotFoundError(f'requirements.txt not found in {path}')

    # Create output directory
    output.mkdir(parents=True, exist_ok=True)

    # Strip --no-index / --find-links from requirements before pip download
    # This ensures repeated runs work correctly (previous run may have added these)
    original_lines = requirements_path.read_text().splitlines()
    clean_lines = [line for line in original_lines if not line.strip().startswith(('--no-index', '--find-links'))]

    # Use a temp file for pip download to avoid modifying original prematurely
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tmp:
        tmp.write('\n'.join(clean_lines) + '\n')
        tmp_path = tmp.name

    # Build pip download command
    cmd = ['pip', 'download', '-r', tmp_path, '-d', str(output)]
    if platform:
        cmd.extend(['--platform', platform, '--only-binary=:all:'])
    if python_version:
        cmd.extend(['--python-version', python_version])

    console.print(f'[bold]Downloading wheels to [cyan]{output}[/cyan]...[/bold]')

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
    finally:
        Path(tmp_path).unlink(missing_ok=True)

    if result.returncode != 0:
        raise RuntimeError(f'pip download failed:\n{result.stderr}')

    if result.stdout:
        console.print(f'[dim]{result.stdout.strip()}[/dim]')

    # Count downloaded packages (.whl, .tar.gz, .zip)
    package_files: list[Path] = []
    for ext in _PACKAGE_EXTENSIONS:
        package_files.extend(output.glob(ext))

    # Modify requirements.txt
    _modify_requirements(requirements_path, output, package_files)

    return PackageResult(
        wheel_count=len(package_files),
        wheel_dir=output,
        requirements_modified=True,
    )


def _extract_package_name(filename: str) -> str | None:
    """Extract package name from a downloaded package filename.

    Handles formats:
        - wheel: ultralytics-8.0.0-py3-none-any.whl → ultralytics
        - sdist: SAM-2-1.0.tar.gz → SAM-2
        - zip:   SAM-2-1.0.zip → SAM-2

    Args:
        filename: Package filename.

    Returns:
        Normalized package name (lowercase, hyphens to dashes) or None.
    """
    # Wheel: {name}-{version}(-{build})?-{python}-{abi}-{platform}.whl
    if filename.endswith('.whl'):
        parts = filename.split('-')
        if len(parts) >= 2:
            return parts[0].lower().replace('_', '-')

    # sdist/zip: {name}-{version}.tar.gz or {name}-{version}.zip
    name = filename
    for suffix in ('.tar.gz', '.zip'):
        if name.endswith(suffix):
            name = name[: -len(suffix)]
            break

    # Version pattern: digit followed by dot (e.g., 1.0, 2.3.1)
    # Greedy match for name ensures "SAM-2-1.0" → name="SAM-2", version="1.0"
    match = re.match(r'^(.+)-(\d+\..*)$', name)
    if match:
        return match.group(1).lower().replace('_', '-')

    return None


def _is_git_requirement(line: str) -> bool:
    """Check if a requirement line is a git+https:// or git+ssh:// URL."""
    stripped = line.strip()
    return stripped.startswith(('git+https://', 'git+ssh://', 'git+http://'))


def _modify_requirements(
    requirements_path: Path,
    wheel_dir: Path,
    package_files: list[Path],
) -> None:
    """Add --no-index and --find-links, replacing git URLs with package names.

    For git+https:// dependencies, pip download saves them as .zip/.tar.gz.
    Since --no-index blocks network access, these git URLs must be replaced
    with the actual package name so pip can resolve from --find-links.

    Args:
        requirements_path: Path to requirements.txt.
        wheel_dir: Directory containing downloaded packages.
        package_files: List of downloaded package file paths.
    """
    original = requirements_path.read_text()
    lines = original.splitlines()

    # Build lookup: normalized package name → filename
    downloaded_names = {}
    for pkg_file in package_files:
        name = _extract_package_name(pkg_file.name)
        if name:
            downloaded_names[name] = pkg_file.name

    # Remove existing --no-index / --find-links lines
    cleaned = [line for line in lines if not line.strip().startswith(('--no-index', '--find-links'))]

    # Replace git+https:// lines with package names
    result_lines = []
    for line in cleaned:
        if _is_git_requirement(line):
            pkg_name = _resolve_git_package_name(line, downloaded_names)
            if pkg_name:
                result_lines.append(pkg_name)
            else:
                # Cannot resolve — keep original as comment + warning
                result_lines.append(f'# WARNING: could not resolve offline package for: {line.strip()}')
                result_lines.append(line)
        else:
            result_lines.append(line)

    # Compute relative path from requirements.txt to wheel dir
    try:
        rel_path = wheel_dir.resolve().relative_to(requirements_path.parent.resolve())
    except ValueError:
        rel_path = wheel_dir.resolve()

    header = ['--no-index', f'--find-links {rel_path}']
    new_content = '\n'.join(header + result_lines) + '\n'

    requirements_path.write_text(new_content)


def _resolve_git_package_name(git_line: str, downloaded_names: dict[str, str]) -> str | None:
    """Resolve a git+https:// line to a package name from downloaded files.

    Tries multiple strategies:
    1. #egg=PackageName fragment in the URL
    2. Match repo name against downloaded filenames

    Args:
        git_line: The git+https:// requirement line.
        downloaded_names: Map of normalized package names to filenames.

    Returns:
        Package name string or None if unresolvable.
    """
    stripped = git_line.strip()

    # Strategy 1: #egg=PackageName
    if '#egg=' in stripped:
        egg_name = stripped.split('#egg=')[-1].split('&')[0]
        return egg_name

    # Strategy 2: match repo name to downloaded package names
    # git+https://github.com/org/repo-name.git → repo-name
    url_part = stripped.split('+', 1)[-1]  # remove git+ prefix
    url_part = url_part.split('#')[0].split('@')[0]  # remove fragment/ref
    repo_name = url_part.rstrip('/').rstrip('.git').rsplit('/', 1)[-1]
    repo_normalized = repo_name.lower().replace('_', '-')

    # Compare with hyphens/underscores stripped for fuzzy match
    # e.g., repo "sam2" → "sam2", package "sam-2" → "sam2"
    repo_stripped = repo_normalized.replace('-', '').replace('_', '')
    for pkg_name in downloaded_names:
        pkg_stripped = pkg_name.replace('-', '').replace('_', '')
        if repo_stripped == pkg_stripped or repo_stripped in pkg_stripped or pkg_stripped in repo_stripped:
            return pkg_name

    return None
