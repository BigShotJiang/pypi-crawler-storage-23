"""CSV file processing utilities with security validation.

Provides utilities for safely processing CSV files with configurable
security limits to prevent resource exhaustion attacks.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field, model_validator

if TYPE_CHECKING:
    from collections.abc import Callable


# ============================================================================
# Exceptions
# ============================================================================


class CsvSecurityError(Exception):
    """Exception raised when CSV file security validation fails."""

    def __init__(
        self,
        message: str,
        violation_type: str | None = None,
        limit: int | None = None,
        actual: int | None = None,
    ):
        super().__init__(message)
        self.message = message
        self.violation_type = violation_type
        self.limit = limit
        self.actual = actual


class CsvParsingError(Exception):
    """Exception raised when CSV file parsing encounters errors."""

    def __init__(
        self,
        message: str,
        file_path: str | None = None,
        original_error: Exception | None = None,
    ):
        super().__init__(message)
        self.message = message
        self.file_path = file_path
        self.original_error = original_error


# ============================================================================
# Configuration Model
# ============================================================================


class CsvSecurityConfig(BaseModel):
    """Security configuration for CSV file processing.

    Defines essential security limits for CSV file processing to prevent
    resource exhaustion attacks.
    """

    max_file_size_mb: int = Field(default=10, ge=1, le=1000)
    max_rows: int = Field(default=100000, ge=1, le=100000)
    max_columns: int = Field(default=50, ge=1, le=16384)
    max_filename_length: int = Field(default=255, ge=1, le=1000)
    max_column_name_length: int = Field(default=100, ge=1, le=500)
    max_metadata_value_length: int = Field(default=1000, ge=1, le=10000)
    encoding: str = Field(default='utf-8-sig')  # BOM auto-handling
    delimiter: str = Field(default=',')

    model_config = {'validate_assignment': True, 'extra': 'forbid'}

    @model_validator(mode='after')
    def validate_resource_limits(self) -> 'CsvSecurityConfig':
        """Validate that resource limits are reasonable."""
        estimated_cells = self.max_rows * self.max_columns
        if estimated_cells > 50_000_000:
            raise ValueError(
                f'Combination of max_rows ({self.max_rows}) and max_columns ({self.max_columns}) '
                f'would allow too many cells ({estimated_cells:,})'
            )
        return self

    @property
    def max_file_size_bytes(self) -> int:
        """Get maximum file size in bytes."""
        return self.max_file_size_mb * 1024 * 1024

    @classmethod
    def from_action_config(cls, action_config: dict[str, Any] | None) -> 'CsvSecurityConfig':
        """Create CsvSecurityConfig from plugin action configuration."""
        if not action_config or 'csv_config' not in action_config:
            return cls()
        csv_config = action_config['csv_config']
        return cls(**{k: v for k, v in csv_config.items() if k in cls.model_fields})


# ============================================================================
# Utility Classes
# ============================================================================


class CsvMetadataUtils:
    """Utility class for CSV metadata processing with security validation.

    Provides methods for validating CSV file constraints and processing
    metadata values with length limits.

    Attributes:
        config: CsvSecurityConfig instance defining security limits.

    Example:
        >>> config = CsvSecurityConfig(max_filename_length=100)
        >>> utils = CsvMetadataUtils(config)
        >>> utils.is_valid_filename_length("short_name.csv")
        True
        >>> utils.is_valid_filename_length("a" * 200 + ".csv")
        False
    """

    def __init__(self, config: CsvSecurityConfig):
        """Initialize with CSV security configuration.

        Args:
            config: CsvSecurityConfig instance defining security limits.
        """
        self.config = config

    def is_valid_filename_length(self, filename: str) -> bool:
        """Check if filename length is within limits.

        Args:
            filename: The filename to validate.

        Returns:
            True if filename length is within the configured limit.
        """
        return len(filename) <= self.config.max_filename_length

    def validate_and_truncate_string(self, value: str, max_length: int) -> str:
        """Validate and truncate string to maximum length.

        Args:
            value: The string value to process.
            max_length: Maximum allowed length.

        Returns:
            The processed string, stripped and truncated if necessary.
        """
        if not isinstance(value, str):
            value = str(value)

        # Strip whitespace
        value = value.strip()

        # Truncate if too long
        if len(value) > max_length:
            value = value[:max_length]

        return value

    def is_valid_column_name(self, column_name: str) -> bool:
        """Check if column name is valid.

        Args:
            column_name: The column name to validate.

        Returns:
            True if column name is non-empty and within length limit.
        """
        if not column_name or not isinstance(column_name, str):
            return False
        return len(column_name.strip()) <= self.config.max_column_name_length

    def is_valid_metadata_value(self, value: str | None) -> bool:
        """Check if metadata value is valid.

        Args:
            value: The metadata value to validate.

        Returns:
            True if value is None or within length limit.
        """
        if value is None:
            return True
        if not isinstance(value, str):
            value = str(value)
        return len(value) <= self.config.max_metadata_value_length


def validate_csv_file_security(
    file_path: Path,
    config: CsvSecurityConfig,
    *,
    on_log: Callable[[str, Any], None] | None = None,
) -> None:
    """Validate CSV file against security constraints.

    Checks file size before allowing processing.

    Args:
        file_path: Path to the CSV file.
        config: Security configuration with limits.
        on_log: Optional callback for logging events.

    Raises:
        CsvSecurityError: If any security constraint is violated.
        FileNotFoundError: If the file doesn't exist.

    Example:
        >>> config = CsvSecurityConfig(max_file_size_mb=10)
        >>> validate_csv_file_security(Path("data.csv"), config)
    """
    if not file_path.exists():
        raise FileNotFoundError(f'CSV file not found: {file_path}')

    file_size = file_path.stat().st_size

    if on_log:
        on_log('security_validation_started', {'file_size': file_size})

    # Check file size
    if file_size > config.max_file_size_bytes:
        raise CsvSecurityError(
            f'CSV file size ({file_size:,} bytes) exceeds limit ({config.max_file_size_bytes:,} bytes)',
            violation_type='file_size',
            limit=config.max_file_size_bytes,
            actual=file_size,
        )


def load_csv_metadata(
    file_path: Path,
    config: CsvSecurityConfig,
    *,
    filename_column: str = 'filename',
    on_log: Callable[[str, Any], None] | None = None,
) -> dict[str, dict[str, Any]]:
    """Load metadata from a CSV file with security validation.

    Reads a CSV file and extracts metadata as a dictionary keyed by filename.
    Performs security validation before processing.

    Args:
        file_path: Path to the CSV file.
        config: Security configuration with limits.
        filename_column: Column name containing filenames. Default is 'filename'.
        on_log: Optional callback for logging events.

    Returns:
        Dictionary mapping filenames to their metadata dictionaries.

    Raises:
        CsvSecurityError: If security constraints are violated.
        CsvParsingError: If the file cannot be parsed.

    Example:
        >>> config = CsvSecurityConfig()
        >>> metadata = load_csv_metadata(Path("metadata.csv"), config)
        >>> metadata["image_001.jpg"]
        {'label': 'cat', 'confidence': '0.95'}
    """
    # Validate security constraints
    validate_csv_file_security(file_path, config, on_log=on_log)

    utils = CsvMetadataUtils(config)
    metadata: dict[str, dict[str, Any]] = {}

    try:
        with file_path.open(encoding=config.encoding, newline='') as csvfile:
            if on_log:
                on_log('csv_file_opened', {'file': str(file_path)})

            reader = csv.reader(csvfile, delimiter=config.delimiter)

            # Read header row
            try:
                header = next(reader)
            except StopIteration:
                raise CsvParsingError(
                    'CSV file is empty or has no header row',
                    file_path=str(file_path),
                )

            # Validate header
            if not header or all(h.strip() == '' for h in header):
                raise CsvParsingError(
                    'CSV file has empty header row',
                    file_path=str(file_path),
                )

            # Normalize header names
            header_list = [h.strip() for h in header]

            # Find filename column index (case-insensitive)
            filename_idx = None
            valid_filename_headers = {'filename', 'file_name'}
            for idx, col_name in enumerate(header_list):
                if col_name.lower() in valid_filename_headers:
                    filename_idx = idx
                    break

            if filename_idx is None:
                raise CsvParsingError(
                    f'Filename column not found in header. '
                    f'Expected one of: {", ".join(valid_filename_headers)}. '
                    f'Available columns: {header_list}',
                    file_path=str(file_path),
                )

            # Validate column count
            if len(header_list) > config.max_columns:
                raise CsvSecurityError(
                    f'Too many columns ({len(header_list)}) exceeds limit ({config.max_columns})',
                    violation_type='columns',
                    limit=config.max_columns,
                    actual=len(header_list),
                )

            # Build valid columns list
            valid_columns: list[tuple[int, str]] = []
            for i, col_name in enumerate(header_list):
                if col_name and utils.is_valid_column_name(col_name):
                    valid_columns.append((i, col_name))

            # Process rows
            row_count = 0
            for row in reader:
                row_count += 1

                # Check row limit
                if row_count > config.max_rows:
                    raise CsvSecurityError(
                        f'Too many rows ({row_count}) exceeds limit ({config.max_rows})',
                        violation_type='rows',
                        limit=config.max_rows,
                        actual=row_count,
                    )

                # Skip empty rows
                if not row or all(cell.strip() == '' for cell in row):
                    continue

                # Get filename
                if filename_idx >= len(row):
                    continue

                filename_value = row[filename_idx].strip()
                if not filename_value:
                    continue

                # Check filename length
                if not utils.is_valid_filename_length(filename_value):
                    if on_log:
                        on_log('filename_too_long', {'filename': filename_value[:50]})
                    continue

                # Extract metadata from other columns
                row_metadata: dict[str, Any] = {}
                for col_idx, col_name in valid_columns:
                    if col_idx == filename_idx:
                        continue

                    if col_idx < len(row):
                        value = row[col_idx].strip()
                        if value and utils.is_valid_metadata_value(value):
                            # Truncate if needed
                            value = utils.validate_and_truncate_string(
                                value,
                                config.max_metadata_value_length,
                            )
                            row_metadata[col_name] = value

                metadata[filename_value] = row_metadata

            if on_log:
                on_log('metadata_loaded', {'file_count': len(metadata)})

            return metadata

    except UnicodeDecodeError as e:
        raise CsvParsingError(
            f'CSV encoding error: {e}. Try a different encoding (current: {config.encoding})',
            file_path=str(file_path),
            original_error=e,
        )
    except csv.Error as e:
        raise CsvParsingError(
            f'CSV parsing error: {e}',
            file_path=str(file_path),
            original_error=e,
        )
    except CsvSecurityError:
        raise
    except CsvParsingError:
        raise
    except Exception as e:
        raise CsvParsingError(
            f'Unexpected error reading CSV file: {e}',
            file_path=str(file_path),
            original_error=e,
        )


__all__ = [
    # Exceptions
    'CsvSecurityError',
    'CsvParsingError',
    # Configuration
    'CsvSecurityConfig',
    # Utilities
    'CsvMetadataUtils',
    'validate_csv_file_security',
    'load_csv_metadata',
]
