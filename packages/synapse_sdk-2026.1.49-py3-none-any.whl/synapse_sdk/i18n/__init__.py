"""Internationalization (i18n) support for Synapse SDK log messages.

This module provides multi-language support for log messages.

Quick Start:

    # For plugin developers - custom i18n messages
    from synapse_sdk.i18n import LocalizedMessage

    msg = LocalizedMessage(
        en='Processing {count} items',
        ko='{count}개 항목 처리 중',
    )
    ctx.log_message(msg, count=10)

    # Or using dict-based format
    ctx.log_message({
        'en': 'Upload complete',
        'ko': '업로드 완료',
    })

Configuration:

    # Set language via environment variable
    SYNAPSE_LANGUAGE=ko

    # Or via executor
    executor = LocalExecutor(language='ko')

    # Or via run_plugin
    result = run_plugin('plugin', 'action', params, language='ko')

Language Codes:
    Uses ISO 639-1 two-letter codes: en, ko, ja, etc.
    Default language is 'en' (English).
"""

from __future__ import annotations

from synapse_sdk.i18n.translator import Translator, get_translator, reset_translator
from synapse_sdk.i18n.types import LocalizedDict, LocalizedMessage


def set_language(language: str) -> None:
    """Set global language for log messages.

    Args:
        language: Language code (ISO 639-1), e.g., 'en', 'ko'.

    Example:
        >>> set_language('ko')
    """
    get_translator().set_language(language)


def get_language() -> str:
    """Get current global language.

    Returns:
        Current language code.

    Example:
        >>> get_language()
        'en'
    """
    return get_translator().language


def translate(key: str, language: str | None = None, **kwargs: object) -> str:
    """Translate a message key.

    Args:
        key: Message key (e.g., 'UPLOAD_COMPLETE').
        language: Target language (None = use current language).
        **kwargs: Format parameters for the message.

    Returns:
        Translated and formatted message.

    Example:
        >>> translate('UPLOAD_FILES_COMPLETED', success=10)
        'Upload complete: 10 files uploaded'
    """
    return get_translator().translate(key, language, **kwargs)


def register_translations(language: str, translations: dict[str, str]) -> None:
    """Register translations for a language.

    Allows plugins to add their own translations.

    Args:
        language: Language code (ISO 639-1).
        translations: Mapping of message key to template.

    Example:
        >>> register_translations('ko', {
        ...     'MY_CUSTOM_MSG': '커스텀 메시지',
        ... })
    """
    get_translator().register(language, translations)


__all__ = [
    # Classes
    'LocalizedMessage',
    'Translator',
    # Type aliases
    'LocalizedDict',
    # Functions
    'get_language',
    'get_translator',
    'register_translations',
    'reset_translator',
    'set_language',
    'translate',
]
