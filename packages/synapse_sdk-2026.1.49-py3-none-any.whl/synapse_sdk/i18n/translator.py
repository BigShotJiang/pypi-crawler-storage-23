"""Thread-safe translator for log messages."""

from __future__ import annotations

import threading
from typing import Any


class Translator:
    """Thread-safe translator for log messages.

    Manages language translations with fallback support.
    Uses ISO 639-1 language codes (en, ko, ja, etc.).

    Example:
        >>> translator = Translator(language='ko')
        >>> translator.register('en', {'HELLO': 'Hello'})
        >>> translator.register('ko', {'HELLO': '안녕하세요'})
        >>> translator.translate('HELLO')
        '안녕하세요'
        >>> translator.translate('HELLO', language='en')
        'Hello'
    """

    DEFAULT_LANGUAGE = 'en'

    def __init__(self, language: str = DEFAULT_LANGUAGE) -> None:
        """Initialize translator.

        Args:
            language: Current language code (ISO 639-1). Default is 'en'.
        """
        self._language = language
        self._lock = threading.RLock()
        # Structure: {language: {message_key: template}}
        self._translations: dict[str, dict[str, str]] = {}

    @property
    def language(self) -> str:
        """Get current language."""
        with self._lock:
            return self._language

    def set_language(self, language: str) -> None:
        """Set current language.

        Args:
            language: Language code (ISO 639-1).
        """
        with self._lock:
            self._language = language

    def register(self, language: str, translations: dict[str, str]) -> None:
        """Register translations for a language.

        Merges with existing translations for the language.
        Invalid (non-string) values are skipped with a warning log.

        Args:
            language: Language code (ISO 639-1).
            translations: Mapping of message key to template string.

        Example:
            >>> translator.register('ko', {
            ...     'UPLOAD_COMPLETE': '업로드 완료',
            ...     'UPLOAD_FAILED': '업로드 실패',
            ... })
        """
        import logging

        with self._lock:
            if language not in self._translations:
                self._translations[language] = {}
            # Validate and register only string values
            for key, value in translations.items():
                if not isinstance(value, str):
                    logging.warning(
                        f"Skipping invalid translation for key '{key}': "
                        f'expected str, got {type(value).__name__}: {value!r}'
                    )
                    continue
                self._translations[language][key] = value

    def get_template(self, key: str, language: str | None = None) -> str | None:
        """Get template for a key with fallback to default language.

        Fallback order:
        1. Requested language
        2. Default language (en)
        3. None

        Args:
            key: Message key.
            language: Target language (None = use current language).

        Returns:
            Template string or None if not found.
        """
        with self._lock:
            lang = language or self._language

            # Try requested language first
            if lang in self._translations and key in self._translations[lang]:
                return self._translations[lang][key]

            # Fallback to default language
            if lang != self.DEFAULT_LANGUAGE and self.DEFAULT_LANGUAGE in self._translations:
                return self._translations[self.DEFAULT_LANGUAGE].get(key)

            return None

    def translate(self, key: str, language: str | None = None, **kwargs: Any) -> str:
        """Translate and format a message.

        Fallback order:
        1. Requested language
        2. Default language (en)
        3. Key itself (for debugging missing translations)

        Args:
            key: Message key.
            language: Target language (None = use current language).
            **kwargs: Format parameters for the template.

        Returns:
            Formatted message string.

        Example:
            >>> translator.translate('UPLOAD_COUNT', count=10)
            '10개 파일 업로드됨'
        """
        template = self.get_template(key, language)

        if template is None:
            # Return key as-is for debugging (per design decision)
            return key

        # Defensive check: ensure template is a string
        if not isinstance(template, str):
            # This should never happen, but if it does, log and return key
            import logging

            logging.warning(
                f"Translation for key '{key}' is not a string: {type(template).__name__}. "
                'This indicates a bug in translation registration.'
            )
            return key

        try:
            return template.format(**kwargs) if kwargs else template
        except KeyError:
            # Missing format parameter - return template as-is
            return template

    def has_translation(self, key: str, language: str | None = None) -> bool:
        """Check if a translation exists for a key.

        Args:
            key: Message key.
            language: Target language (None = use current language).

        Returns:
            True if translation exists.
        """
        with self._lock:
            lang = language or self._language
            if lang in self._translations and key in self._translations[lang]:
                return True
            if lang != self.DEFAULT_LANGUAGE and self.DEFAULT_LANGUAGE in self._translations:
                return key in self._translations[self.DEFAULT_LANGUAGE]
            return False

    def get_supported_languages(self) -> list[str]:
        """Get list of registered language codes.

        Returns:
            List of language codes.
        """
        with self._lock:
            return list(self._translations.keys())

    def clear(self) -> None:
        """Clear all registered translations."""
        with self._lock:
            self._translations.clear()


# Global translator instance
_translator: Translator | None = None
_translator_lock = threading.Lock()


def get_translator() -> Translator:
    """Get global translator instance.

    Returns:
        Global Translator instance.
    """
    global _translator
    if _translator is None:
        with _translator_lock:
            if _translator is None:
                _translator = Translator()
                # Load built-in messages
                _load_builtin_messages(_translator)
    return _translator


def _load_builtin_messages(translator: Translator) -> None:
    """Load built-in message translations."""
    try:
        from synapse_sdk.i18n.messages import en, ko

        translator.register('en', en.MESSAGES)
        translator.register('ko', ko.MESSAGES)
    except ImportError:
        # Messages not yet created - that's OK during development
        pass


def reset_translator() -> None:
    """Reset global translator (for testing)."""
    global _translator
    with _translator_lock:
        _translator = None


__all__ = ['Translator', 'get_translator', 'reset_translator']
