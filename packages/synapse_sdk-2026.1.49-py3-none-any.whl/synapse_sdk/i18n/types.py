"""i18n type definitions for log messages."""

from __future__ import annotations

from typing import Any


class LocalizedMessage:
    """Immutable container for localized message templates.

    Allows plugin developers to define messages with multiple language translations.

    Example:
        >>> msg = LocalizedMessage(
        ...     en='Processing {count} items',
        ...     ko='{count}개 항목 처리 중',
        ... )
        >>> msg.get('ko')
        '{count}개 항목 처리 중'
        >>> msg.format('ko', count=10)
        '10개 항목 처리 중'
    """

    __slots__ = ('_translations',)

    def __init__(self, **translations: str) -> None:
        """Initialize with language translations.

        Args:
            **translations: Language code to template mapping.
                Example: en='Hello', ko='안녕하세요'
        """
        self._translations: dict[str, str] = dict(translations)

    @property
    def translations(self) -> dict[str, str]:
        """Get all translations as a dictionary."""
        return dict(self._translations)

    def get(self, language: str, default_language: str = 'en') -> str | None:
        """Get template for language with fallback.

        Args:
            language: Target language code (ISO 639-1).
            default_language: Fallback language if target not found.

        Returns:
            Template string or None if neither language found.
        """
        return self._translations.get(language) or self._translations.get(default_language)

    def format(self, language: str, default_language: str = 'en', **kwargs: Any) -> str:
        """Get and format template with parameters.

        Args:
            language: Target language code (ISO 639-1).
            default_language: Fallback language if target not found.
            **kwargs: Format parameters for the template.

        Returns:
            Formatted message string, or empty string if no template found.
        """
        template = self.get(language, default_language)
        if template is None:
            return ''
        return template.format(**kwargs) if kwargs else template

    def __repr__(self) -> str:
        langs = ', '.join(self._translations.keys())
        return f'LocalizedMessage({langs})'


# Type alias for dict-based localization
LocalizedDict = dict[str, str]  # {language_code: template}


__all__ = ['LocalizedDict', 'LocalizedMessage']
