"""Korean translations for Synapse SDK log messages."""

from __future__ import annotations

MESSAGES: dict[str, str] = {
    # ==========================================================================
    # Common (synapse_sdk/plugins/log_messages.py)
    # ==========================================================================
    'PLUGIN_RUN_COMPLETE': '플러그인 실행이 완료되었습니다.',
    # ==========================================================================
    # Upload (synapse_sdk/plugins/actions/upload/log_messages.py)
    # ==========================================================================
    'UPLOAD_INITIALIZED': '스토리지 및 경로가 초기화되었습니다',
    'UPLOAD_METADATA_LOADED': '{count}개 파일의 메타데이터를 로드했습니다',
    'UPLOAD_METADATA_INVALID_HEADER': (
        '유효하지 않은 메타데이터 파일: 첫 번째 열은 "filename" 또는 "file_name"이어야 하는데, "{header}"입니다'
    ),
    'UPLOAD_COLLECTION_ANALYZED': '데이터 컬렉션 분석 완료: {count}개 파일 명세',
    'UPLOAD_FILES_ORGANIZED': '{count}개 파일 그룹으로 정리되었습니다',
    'UPLOAD_NO_FILES_FOUND': '정리할 파일을 찾지 못했습니다',
    'UPLOAD_VALIDATION_PASSED': '유효성 검사 통과: {count}개 파일 그룹',
    'UPLOAD_FILES_UPLOADING': '{count}개 파일 업로드 중',
    'UPLOAD_FILES_COMPLETED': '업로드 완료: {success}개 파일 업로드됨',
    'UPLOAD_FILES_COMPLETED_WITH_FAILURES': '업로드 완료: {success}개 성공, {failed}개 실패',
    'UPLOAD_DATA_UNITS_CREATING': '{count}개 데이터 유닛 생성 중',
    'UPLOAD_DATA_UNITS_COMPLETED': '{count}개 데이터 유닛이 생성되었습니다',
    'UPLOAD_DATA_UNITS_COMPLETED_WITH_FAILURES': '데이터 유닛 생성 완료: {success}개 성공, {failed}개 실패',
    'UPLOAD_COMPLETED': '업로드 완료: {files}개 파일, {data_units}개 데이터 유닛',
    # ==========================================================================
    # Train (synapse_sdk/plugins/actions/train/log_messages.py)
    # ==========================================================================
    'TRAIN_STARTING': '{epochs} 에포크 학습을 시작합니다',
    'TRAIN_EPOCH_PROGRESS': '학습 에포크 {epoch}/{total_epochs}',
    'TRAIN_VALIDATION_METRICS': '검증 mAP50: {map50:.3f}, mAP50-95: {map50_95:.3f}',
    'TRAIN_COMPLETED': '학습 완료, 모델 업로드 중...',
    'TRAIN_MODEL_SAVED': '모델 가중치가 저장되었습니다',
    'TRAIN_MODEL_UPLOADED': '모델 업로드가 완료되었습니다',
    # ==========================================================================
    # Export (synapse_sdk/plugins/actions/export/log_messages.py)
    # ==========================================================================
    'EXPORT_INITIALIZED': '내보내기 스토리지 및 경로가 초기화되었습니다',
    'EXPORT_NO_RESULTS': '내보낼 결과를 찾지 못했습니다',
    'EXPORT_RESULTS_FETCHED': '내보내기 대상 {count}개 결과를 가져왔습니다',
    'EXPORT_CONVERTING': '{count}개 항목 변환 중',
    'EXPORT_CONVERTED': '{count}개 항목 변환 완료',
    'EXPORT_SAVING_FILES': '{count}개 파일 저장 중',
    'EXPORT_FILES_SAVED': '{count}개 파일 저장 완료',
    'EXPORT_FILES_SAVED_WITH_FAILURES': '{success}개 파일 저장 완료, {failed}개 실패',
    'EXPORT_COMPLETED': '내보내기 완료: {count}개 항목',
    'EXPORT_COMPLETED_WITH_FAILURES': '내보내기 완료: {exported}개 완료, {failed}개 실패',
    'EXPORT_SAVING_ORIGINAL': '원본 파일 저장 중.',
    'EXPORT_SAVING_JSON': 'JSON 파일 저장 중.',
    'EXPORT_STARTING': '내보내기 프로세스 시작.',
    'EXPORT_CONVERTING_DATASET': '데이터셋 변환 중.',
    # ==========================================================================
    # ToTask (synapse_sdk/plugins/actions/to_task/log_messages.py)
    # ==========================================================================
    # Initialization
    'TASK_INITIALIZING': 'to_task 워크플로우 초기화 중',
    'TASK_DATA_COLLECTION_LOADED': '데이터 컬렉션이 성공적으로 로드되었습니다',
    # Preparation
    'TASK_PREPARING_FILE_METHOD': '파일 기반 어노테이션 준비 중',
    'TASK_PREPARING_INFERENCE_METHOD': '추론 기반 어노테이션 준비 중',
    'TASK_SPECIFICATION_VALIDATED': '대상 스펙이 검증되었습니다',
    'TASK_INFERENCE_PARAMS_VALIDATING': '추론 파라미터 검증 중',
    'TASK_INFERENCE_PARAMS_VALIDATED': '파라미터 검증 완료: {pre_processor}, {model}',
    'TASK_PREPROCESSOR_RELEASE_FETCHING': '전처리기 가져오는 중: {pre_processor}',
    'TASK_PREPROCESSOR_RELEASE_FETCHED': '릴리스 가져옴: {plugin_code} v{version}',
    'TASK_PREPROCESSOR_CHECKING': '전처리기 상태 확인 중',
    'TASK_PREPROCESSOR_ALREADY_RUNNING': '전처리기가 이미 실행 중입니다',
    'TASK_DATA_PREPROCESSOR_DEPLOYING': '전처리기 배포 시작',
    'TASK_PREPROCESSOR_WAITING': '전처리기 준비 대기 중',
    'TASK_PREPROCESSOR_WAITING_PROGRESS': '대기 중... ({elapsed_seconds}초 경과)',
    'TASK_PREPROCESSOR_READY': '전처리기가 준비되었습니다',
    'TASK_INFERENCE_CONTEXT_READY': '추론 컨텍스트가 성공적으로 준비되었습니다',
    # Fetching
    'TASK_FETCHING_TASKS': '작업 목록 가져오는 중',
    'TASK_TASKS_FETCHED': '어노테이션 대상 {count}개 작업을 가져왔습니다',
    # Processing
    'TASK_DATA_ANNOTATING': '{count}개 작업 어노테이션 중 ({method} 방식)',
    'TASK_DATA_COMPLETED': '어노테이션 완료: {count}개 작업 처리됨',
    'TASK_DATA_COMPLETED_WITH_FAILURES': '어노테이션 완료: {success}개 성공, {failed}개 실패',
    # Finalization
    'TASK_FINALIZING': '어노테이션 결과 마무리 중',
    # ==========================================================================
    # Dataset (synapse_sdk/plugins/actions/dataset/log_messages.py)
    # ==========================================================================
    'DATASET_DOWNLOAD_STARTING': '데이터셋 다운로드 시작 (ID: {dataset_id})',
    'DATASET_SPLIT_DOWNLOADED': '{split_name} 분할 다운로드 완료: {count}개 항목',
    'DATASET_DOWNLOAD_COMPLETED': '데이터셋 다운로드 완료: {count}개 항목',
    'DATASET_GT_EVENTS_FOUND': '{count}개 정답 이벤트 발견',
    'DATASET_DOWNLOAD_PARTIAL': '{downloaded}개 항목 다운로드됨 ({missing}개 이미지 누락)',
    'DATASET_CONVERTING': '데이터셋 변환 중: {source} → {target}',
    'DATASET_CONVERSION_COMPLETED': '데이터셋 변환 완료',
}

__all__ = ['MESSAGES']
