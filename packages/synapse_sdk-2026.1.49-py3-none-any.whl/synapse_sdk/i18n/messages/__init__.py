"""Built-in message translations for Synapse SDK.

This package contains translation dictionaries for built-in log messages.
Each language module exports a MESSAGES dict mapping message keys to templates.

To add a new language:
1. Create a new file (e.g., ja.py for Japanese)
2. Define MESSAGES dict with translations
3. Register it in synapse_sdk/i18n/translator.py's _load_builtin_messages()
"""

from __future__ import annotations

__all__: list[str] = []
