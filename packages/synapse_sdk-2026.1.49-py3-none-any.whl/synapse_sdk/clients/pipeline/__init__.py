"""Pipeline service client for dev-api communication."""

from synapse_sdk.clients.pipeline.client import PipelineServiceClient

__all__ = ['PipelineServiceClient']
