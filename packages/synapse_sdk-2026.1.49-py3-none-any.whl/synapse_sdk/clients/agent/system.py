from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from synapse_sdk.clients.protocols import ClientProtocol


class SystemClientMixin:
    """Mixin for system management endpoints (update, restart)."""

    def get_compose_config(self: ClientProtocol) -> dict:
        """Get the detected Docker Compose configuration.

        Returns the compose configuration detected from the running container labels.
        Useful for debugging and verification.

        Returns:
            dict: Compose configuration with keys:
                - working_dir: Host directory containing docker-compose files
                - config_files: List of compose files used
                - is_gpu_mode: Whether GPU mode is detected
        """
        return self._get('system/compose-config/')

    def get_system_status(self: ClientProtocol) -> dict:
        """Get the current system operation status.

        Returns whether an update/restart operation is currently in progress.
        Useful for polling to check when an operation completes.

        Returns:
            dict: Status with keys:
                - in_progress: Whether an operation is running
                - operation: 'update' or 'restart' if in progress, else None
                - started_at: ISO timestamp when operation started, else None
                - api_tag: Target API tag if update in progress
                - worker_tag: Target worker tag if update in progress
        """
        return self._get('system/status/')

    def wait_for_system_ready(
        self: ClientProtocol,
        *,
        timeout: float = 120,
        poll_interval: float = 2,
    ) -> bool:
        """Wait for the system to become ready after an update/restart.

        Polls the health endpoint until the system responds successfully.

        Args:
            timeout: Maximum time to wait in seconds (default: 120).
            poll_interval: Time between health checks in seconds (default: 2).

        Returns:
            bool: True if system is ready, False if timeout reached.
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                self.health_check()
                return True
            except Exception:
                pass
            time.sleep(poll_interval)
        return False

    def update_system(
        self: ClientProtocol,
        *,
        api_tag: str | None = None,
        worker_tag: str | None = None,
        wait: bool = False,
        timeout: float = 120,
        poll_interval: float = 2,
    ) -> dict:
        """Pull new images and restart the system containers.

        This operation:
        1. Detects the compose configuration from container labels
        2. Pulls new images with the specified tags (or 'latest' if not specified)
        3. Recreates containers with the new images

        Note: The API container will restart after this call. If wait=False,
        the response may not be received if successful.

        Args:
            api_tag: Tag for the API container image. Defaults to 'latest'.
            worker_tag: Tag for the worker container image.
                Defaults to 'latest' (or 'latest-gpu' for GPU mode).
            wait: If True, wait for the system to come back online after restart.
            timeout: Maximum time to wait for system ready in seconds (default: 120).
                Only used when wait=True.
            poll_interval: Time between health checks in seconds (default: 2).
                Only used when wait=True.

        Returns:
            dict: Response with keys:
                - status: 'success', 'error', or 'in_progress' (if 409)
                - message: Human-readable status message
                - pull_output: Output from docker compose pull (on success)
                - up_output: Output from docker compose up (on success)

        Raises:
            ClientError: If operation fails or returns 409 (already in progress).
        """
        data = {}
        if api_tag is not None:
            data['api_tag'] = api_tag
        if worker_tag is not None:
            data['worker_tag'] = worker_tag

        try:
            result = self._post('system/update/', data=data if data else None)
        except Exception as e:
            # If we get a connection error after initiating, the restart started
            if wait:
                time.sleep(poll_interval)  # Give it a moment to start restarting
                if self.wait_for_system_ready(timeout=timeout, poll_interval=poll_interval):
                    return {'status': 'success', 'message': 'System updated and ready'}
            raise e

        if wait and result.get('status') == 'success':
            time.sleep(poll_interval)  # Give it a moment to start restarting
            if self.wait_for_system_ready(timeout=timeout, poll_interval=poll_interval):
                result['message'] = 'System updated and ready'

        return result

    def restart_system(
        self: ClientProtocol,
        *,
        wait: bool = False,
        timeout: float = 120,
        poll_interval: float = 2,
    ) -> dict:
        """Restart the system containers without pulling new images.

        This operation recreates the containers using the current images.
        Useful for applying configuration changes or recovering from issues.

        Note: The API container will restart after this call. If wait=False,
        the response may not be received if successful.

        Args:
            wait: If True, wait for the system to come back online after restart.
            timeout: Maximum time to wait for system ready in seconds (default: 120).
                Only used when wait=True.
            poll_interval: Time between health checks in seconds (default: 2).
                Only used when wait=True.

        Returns:
            dict: Response with keys:
                - status: 'success', 'error', or 'in_progress' (if 409)
                - message: Human-readable status message
                - up_output: Output from docker compose up (on success)

        Raises:
            ClientError: If operation fails or returns 409 (already in progress).
        """
        try:
            result = self._post('system/restart/')
        except Exception as e:
            # If we get a connection error after initiating, the restart started
            if wait:
                time.sleep(poll_interval)  # Give it a moment to start restarting
                if self.wait_for_system_ready(timeout=timeout, poll_interval=poll_interval):
                    return {'status': 'success', 'message': 'System restarted and ready'}
            raise e

        if wait and result.get('status') == 'success':
            time.sleep(poll_interval)  # Give it a moment to start restarting
            if self.wait_for_system_ready(timeout=timeout, poll_interval=poll_interval):
                result['message'] = 'System restarted and ready'

        return result
