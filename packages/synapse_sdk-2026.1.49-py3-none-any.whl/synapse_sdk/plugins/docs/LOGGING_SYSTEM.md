# Logging System

Comprehensive logging system for progress tracking, metrics collection, and event logging across the Synapse SDK plugin system.

## Architecture

```mermaid
flowchart TB
    subgraph Loggers["Logger Implementations"]
        base["BaseLogger<br/>(Abstract)"]
        console["ConsoleLogger<br/>- Python logging"]
        backend["BackendLogger<br/>- Remote sync"]
        noop["NoOpLogger<br/>- Silent"]
    end

    subgraph Models["Data Models"]
        loglevel["LogLevel<br/>DEBUG|INFO|WARNING|ERROR|CRITICAL"]
        progress["ProgressData<br/>- percent<br/>- time_remaining<br/>- elapsed_time"]
        logentry["LogEntry<br/>- event<br/>- data<br/>- step<br/>- level"]
    end

    subgraph Integration["Integration Points"]
        context["RuntimeContext<br/>- logger property"]
        stepctx["BaseStepContext<br/>- logger property"]
        action["BaseAction<br/>- self.log()<br/>- self.set_progress()"]
    end

    base --> console
    base --> backend
    base --> noop

    loglevel --> base
    progress --> base
    logentry --> backend

    context --> base
    stepctx --> base
    action --> context

    style Loggers fill:#e1f5fe
    style Models fill:#f3e5f5
    style Integration fill:#fff3e0
```

## Core Components

### BaseLogger (Abstract)

Location: `synapse_sdk/loggers.py`

Abstract base class providing the logging interface. All logging state is instance-level to prevent cross-instance contamination.

```python
from synapse_sdk.loggers import BaseLogger
from synapse_sdk.plugins.models.logger import LogLevel

class CustomLogger(BaseLogger):
    def _log_impl(
        self,
        event: str,
        data: dict[str, Any],
        file: str | None,
        step: str | None,
        level: LogLevel | None = None,
    ) -> None:
        # Custom implementation
        print(f"[{level.value}] {event}: {data}")
```

**Key Methods:**

| Method | Description |
|--------|-------------|
| `log(level, event, data, file, step)` | Log an event with structured data |
| `info(message)` | Log info-level message |
| `debug(message)` | Log debug-level message |
| `warning(message)` | Log warning-level message |
| `error(message)` | Log error-level message |
| `critical(message)` | Log critical-level message |
| `set_progress(current, total, step)` | Update progress with ETA calculation |
| `set_progress_failed(step)` | Mark progress as failed |
| `set_metrics(value, step)` | Record metrics for a step |
| `set_step(step, order=None)` | Set current step context (with optional 0-based order) |
| `get_step()` | Get current step name |
| `get_step_order()` | Get current step order (0-based int or None) |
| `get_progress(step)` | Retrieve progress data |
| `get_metrics(step)` | Retrieve recorded metrics |
| `finish()` | Mark logger as complete |

**Extension Hooks:**

```python
class CustomLogger(BaseLogger):
    def _log_impl(self, event, data, file, step, level):
        """Required: Handle log events."""
        pass

    def _on_progress(self, progress: ProgressData, step: str | None):
        """Optional: Called when progress updates."""
        pass

    def _on_metrics(self, step: str, metrics: dict[str, Any]):
        """Optional: Called when metrics update."""
        pass

    def _on_finish(self):
        """Optional: Called when logger finishes."""
        pass
```

### LogLevel

Location: `synapse_sdk/plugins/models/logger.py`

Enumeration for log severity levels:

```python
from synapse_sdk.plugins.models.logger import LogLevel

class LogLevel(str, Enum):
    DEBUG = 'debug'      # Detailed debugging information
    INFO = 'info'        # General operational messages
    WARNING = 'warning'  # Warning conditions
    ERROR = 'error'      # Error conditions
    CRITICAL = 'critical' # Critical failures
```

**Python Logging Level Mapping:**

| LogLevel | Python Level |
|----------|--------------|
| `DEBUG` | `logging.DEBUG` (10) |
| `INFO` | `logging.INFO` (20) |
| `WARNING` | `logging.WARNING` (30) |
| `ERROR` | `logging.ERROR` (40) |
| `CRITICAL` | `logging.CRITICAL` (50) |

### ProgressData

Immutable snapshot of progress state:

```python
from synapse_sdk.loggers import ProgressData

@dataclass
class ProgressData:
    percent: float           # Progress percentage (0-100)
    time_remaining: float | None  # Estimated seconds remaining
    elapsed_time: float | None    # Seconds elapsed
    status: str = 'running'       # 'running' or 'failed'
```

**Automatic ETA Calculation:**

```python
logger.set_progress(50, 100, step='training')
progress = logger.get_progress('training')
# progress.percent = 50.0
# progress.time_remaining = estimated based on elapsed/progress rate
# progress.elapsed_time = seconds since first progress call
```

### LogEntry

Structured log entry with metadata:

```python
from synapse_sdk.loggers import LogEntry

@dataclass
class LogEntry:
    event: str              # Event name/type
    data: dict[str, Any]    # Event payload
    timestamp: float        # Unix timestamp
    file: str | None        # Associated file path
    step: str | None        # Step context
    level: LogLevel | None  # Log level

    def to_dict(self) -> dict[str, Any]:
        """Serialize for API transmission."""
```

### MessageLogData

TypedDict for `event='message'` or `event='debug'` log entries:

```python
from synapse_sdk.loggers import MessageLogData

# Basic message data
data: MessageLogData = {'content': 'Training started'}

# With LogMessageCode key (set automatically when using LogMessageCode)
data: MessageLogData = {'content': 'Uploading 10 files', 'key': 'UPLOAD_FILES_UPLOADING'}
```

**Fields:**
- `content`: The message text displayed to users
- `key` (optional): LogMessageCode value when message was created from a template

> **Note**: The `data.context` field has been removed. Level information is now stored in `log_entry['level']`.

---

## Internationalization (i18n) Support

The logging system supports internationalized messages through the `i18n` module. This enables plugins to display log messages in the user's preferred language.

### LocalizedMessage

`LocalizedMessage` is a dict-based type for defining multi-language messages:

```python
from synapse_sdk.i18n import LocalizedMessage

# Define message with translations
message: LocalizedMessage = {
    'en': 'Processing {count} files',
    'ko': '{count}개 파일 처리 중',
}
```

### Using RuntimeContext for i18n Logging

`RuntimeContext` provides the `log_message()` method that automatically handles translation:

```python
from synapse_sdk.plugins import BaseAction
from synapse_sdk.i18n import LocalizedMessage
from synapse_sdk.plugins.models.logger import LogLevel

class MyAction(BaseAction[MyParams]):
    def execute(self) -> dict:
        # Define localized message
        message: LocalizedMessage = {
            'en': 'Starting training with {epochs} epochs',
            'ko': '{epochs} 에폭으로 학습 시작',
        }

        # Log with i18n support - uses ctx.language for translation
        self.ctx.log_message(message, LogLevel.INFO, epochs=self.params.epochs)

        # You can also pass a simple string (no translation)
        self.ctx.log_message('Training complete!', LogLevel.SUCCESS)

        return {'status': 'done'}
```

### translate() Function

Use `translate()` for standalone message translation:

```python
from synapse_sdk.i18n import translate, LocalizedMessage

message: LocalizedMessage = {
    'en': 'Processing {count} files',
    'ko': '{count}개 파일 처리 중',
}

# Translate with current language
translated = translate(message, language='ko', count=10)
# Result: '10개 파일 처리 중'
```

### Language Configuration

Language is configured at the execution level and flows through `RuntimeContext`:

```python
# CLI with --lang option
# synapse plugin test train --lang=ko

# LocalExecutor
from synapse_sdk.plugins.executors.local import LocalExecutor
executor = LocalExecutor(language='ko')
result = executor.execute(MyAction, params)

# RayActorExecutor
from synapse_sdk.plugins.executors.ray.task import RayActorExecutor
executor = RayActorExecutor(working_dir='/path', language='ko')

# RayJobsApiExecutor (passes SYNAPSE_LANGUAGE env var)
from synapse_sdk.plugins.executors.ray.jobs_api import RayJobsApiExecutor
executor = RayJobsApiExecutor(dashboard_address='http://localhost:8265', language='ko')
```

### LogMessageCode (Built-in Messages)

For common SDK log messages, use the appropriate `LogMessageCode` subclass. Each action type has its own subclass with pre-defined translations:

```python
from synapse_sdk.plugins.actions.upload.log_messages import UploadLogMessageCode

class MyAction(BaseAction[MyParams]):
    def execute(self) -> dict:
        # Use built-in message codes
        self.ctx.log_message(UploadLogMessageCode.UPLOAD_FILES_UPLOADING, count=10)

        return {'status': 'done'}
```

**Available LogMessageCode Subclasses:**

| Subclass | Module | Example Codes |
|----------|--------|---------------|
| `UploadLogMessageCode` | `synapse_sdk.plugins.actions.upload.log_messages` | `UPLOAD_FILES_UPLOADING`, `UPLOAD_COMPLETED` |
| `ExportLogMessageCode` | `synapse_sdk.plugins.actions.export.log_messages` | `EXPORT_INITIALIZED`, `EXPORT_COMPLETED` |
| `TrainLogMessageCode` | `synapse_sdk.plugins.actions.train.log_messages` | `TRAIN_STARTING`, `TRAIN_COMPLETED` |
| `DatasetLogMessageCode` | `synapse_sdk.plugins.actions.dataset.log_messages` | `DATASET_DOWNLOAD_STARTING`, `DATASET_DOWNLOAD_COMPLETED` |
| `ToTaskLogMessageCode` | `synapse_sdk.plugins.actions.to_task.log_messages` | `TASK_INITIALIZING`, `TASK_DATA_COMPLETED` |
| `CommonLogMessageCode` | `synapse_sdk.plugins.log_messages` | `PLUGIN_RUN_COMPLETE` |

### Fallback Behavior

The translation system uses a fallback chain:

1. Requested language (e.g., `'ko'`)
2. English (`'en'`) as default fallback
3. First available translation
4. Original message if no translation found

```python
message: LocalizedMessage = {
    'en': 'Hello',
    'ko': '안녕하세요',
}

# Request Japanese (not available) - falls back to English
translate(message, language='ja')  # Returns: 'Hello'
```

### Creating Custom LogMessageCode for Plugins

Plugin developers can define their own `LogMessageCode` subclass with custom translated messages.

**Step 1: Create a log_messages.py file in your plugin:**

```python
# plugin/log_messages.py
from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class MyPluginLogMessageCode(LogMessageCode):
    """Log message codes for my plugin."""

    # Define message codes with (code_name, log_level) tuple
    CONVERSION_STARTED = ('CONVERSION_STARTED', LogLevel.INFO)
    CONVERSION_COMPLETED = ('CONVERSION_COMPLETED', LogLevel.SUCCESS)
    CONVERSION_FAILED = ('CONVERSION_FAILED', LogLevel.ERROR)
    PROCESSING_FORMAT = ('PROCESSING_FORMAT', LogLevel.INFO)


# Register translations for each code
register_log_messages({
    MyPluginLogMessageCode.CONVERSION_STARTED: {
        'en': 'Starting conversion process',
        'ko': '변환 프로세스 시작',
    },
    MyPluginLogMessageCode.CONVERSION_COMPLETED: {
        'en': 'Conversion completed successfully',
        'ko': '변환이 성공적으로 완료되었습니다',
    },
    MyPluginLogMessageCode.CONVERSION_FAILED: {
        'en': 'Conversion failed: {error}',
        'ko': '변환 실패: {error}',
    },
    MyPluginLogMessageCode.PROCESSING_FORMAT: {
        'en': 'Processing {format} format annotations',
        'ko': '{format} 형식 어노테이션 처리 중',
    },
})
```

**Step 2: Use the custom codes in your action:**

```python
# plugin/action.py
from synapse_sdk.plugins import BaseAction
from .log_messages import MyPluginLogMessageCode


class MyAction(BaseAction[MyParams]):
    def execute(self) -> dict:
        # Log with custom message code
        self.ctx.log_message(MyPluginLogMessageCode.CONVERSION_STARTED)

        try:
            # Log with parameters
            self.ctx.log_message(
                MyPluginLogMessageCode.PROCESSING_FORMAT,
                format='YOLO',
            )

            result = self.process_data()

            self.ctx.log_message(MyPluginLogMessageCode.CONVERSION_COMPLETED)
            return result

        except Exception as e:
            self.ctx.log_message(
                MyPluginLogMessageCode.CONVERSION_FAILED,
                error=str(e),
            )
            raise
```

**Best Practices for Custom Log Messages:**

1. **Use descriptive code names**: `CONVERSION_STARTED` is better than `MSG1`
2. **Include appropriate LogLevel**: Use `SUCCESS` for completion, `ERROR` for failures
3. **Support placeholders**: Use `{param}` syntax for dynamic values
4. **Provide both languages**: Always include `en` and `ko` translations
5. **Keep messages user-friendly**: These messages are shown in the UI

---

## Logger Implementations

### ConsoleLogger

Prints logs to console using Python's `logging` module. Best for development and debugging.

```python
from synapse_sdk.loggers import ConsoleLogger
from synapse_sdk.plugins.models.logger import LogLevel

logger = ConsoleLogger()

# Log messages at different levels
logger.info("Starting process")
logger.debug("Processing item 1")
logger.warning("Slow performance detected")
logger.error("Failed to connect")

# Structured logging
logger.log(LogLevel.INFO, 'model_loaded', {'path': '/models/yolo.pt'})

# Progress tracking
logger.set_step('training')
for epoch in range(100):
    logger.set_progress(epoch + 1, 100)
    # Output: [training] Progress: 50% | ETA: 30.5s

# Metrics
logger.set_metrics({'loss': 0.05, 'accuracy': 0.95}, step='training')
# Output: [training] Metrics: {'loss': 0.05, 'accuracy': 0.95}

logger.finish()
```

**Output Format:**

```
INFO:synapse_sdk.loggers:[training] model_loaded {'path': '/models/yolo.pt'}
INFO:synapse_sdk.loggers:[training] Progress: 50.0% | ETA: 30.5s
INFO:synapse_sdk.loggers:[training] Metrics: {'loss': 0.05, 'accuracy': 0.95}
```

### BackendLogger

Synchronizes logs with a remote backend service. Used in production environments for centralized monitoring.

```python
from synapse_sdk.loggers import BackendLogger, LoggerBackend

class MyBackend(LoggerBackend):
    def publish_progress(self, job_id: str, progress: ProgressData) -> None:
        # Send to backend API
        requests.post(f'/api/jobs/{job_id}/progress', json=progress.__dict__)

    def publish_metrics(self, job_id: str, metrics: dict[str, Any]) -> None:
        requests.post(f'/api/jobs/{job_id}/metrics', json=metrics)

    def publish_log(self, job_id: str, log_entry: LogEntry) -> None:
        requests.post(f'/api/jobs/{job_id}/logs', json=log_entry.to_dict())

# Initialize with backend
backend = MyBackend()
logger = BackendLogger(backend=backend, job_id='job-123')

# All logging operations sync to backend
logger.set_progress(50, 100, step='training')
logger.set_metrics({'loss': 0.05}, step='training')
logger.log(LogLevel.INFO, 'checkpoint', {'epoch': 5})

logger.finish()  # Flushes remaining logs
```

**Error Handling:**

BackendLogger silently logs errors without raising exceptions:

```python
# If backend.publish_progress() fails:
# ERROR:synapse_sdk.loggers:Failed to publish progress: ConnectionError
```

### NoOpLogger

Silent logger for testing or disabled logging scenarios:

```python
from synapse_sdk.loggers import NoOpLogger

logger = NoOpLogger()

# All operations are no-ops
logger.info("This goes nowhere")
logger.set_progress(50, 100)
logger.set_metrics({'loss': 0.05}, step='train')
logger.finish()  # Does nothing
```

---

## LoggerBackend Protocol

Protocol interface for implementing custom backend integrations:

```python
from synapse_sdk.loggers import LoggerBackend, ProgressData, LogEntry

class LoggerBackend(Protocol):
    """Protocol for logger backends that handle data synchronization."""

    def publish_progress(self, job_id: str, progress: ProgressData) -> None:
        """Publish progress update to backend."""
        ...

    def publish_metrics(self, job_id: str, metrics: dict[str, Any]) -> None:
        """Publish metrics to backend."""
        ...

    def publish_log(self, job_id: str, log_entry: LogEntry) -> None:
        """Publish log entry to backend."""
        ...
```

**Implementation Example:**

```python
import httpx
from synapse_sdk.loggers import LoggerBackend, ProgressData, LogEntry

class HTTPBackend:
    """HTTP-based backend implementation."""

    def __init__(self, base_url: str, api_key: str):
        self.client = httpx.Client(
            base_url=base_url,
            headers={'Authorization': f'Bearer {api_key}'},
        )

    def publish_progress(self, job_id: str, progress: ProgressData) -> None:
        self.client.post(f'/jobs/{job_id}/progress', json={
            'percent': progress.percent,
            'time_remaining': progress.time_remaining,
            'elapsed_time': progress.elapsed_time,
            'status': progress.status,
        })

    def publish_metrics(self, job_id: str, metrics: dict[str, Any]) -> None:
        self.client.post(f'/jobs/{job_id}/metrics', json=metrics)

    def publish_log(self, job_id: str, log_entry: LogEntry) -> None:
        self.client.post(f'/jobs/{job_id}/logs', json=log_entry.to_dict())
```

---

## Integration with Actions

### RuntimeContext

Actions access logging through `RuntimeContext`:

```python
from synapse_sdk.plugins import BaseAction
from synapse_sdk.plugins.context import RuntimeContext

class MyAction(BaseAction[MyParams]):
    def execute(self) -> dict:
        # Access logger via context
        self.ctx.logger.info("Starting execution")

        # Convenience methods on context
        self.ctx.set_progress(50, 100)
        self.ctx.set_metrics({'items': 100}, step='process')
        self.ctx.log('custom_event', {'data': 'value'})

        # User-facing messages
        from synapse_sdk.plugins.models.logger import LogLevel
        self.ctx.log_message("Processing complete!", LogLevel.SUCCESS)

        # Developer debug events
        self.ctx.log_dev_event("Checkpoint saved", {'path': '/tmp/ckpt'})

        return {'status': 'done'}
```

**RuntimeContext Methods:**

| Method | Description |
|--------|-------------|
| `log(event, data, file)` | Log structured event |
| `set_progress(current, total, step)` | Update progress |
| `set_metrics(value, step)` | Record metrics |
| `log_message(message, level)` | User-facing message (LogLevel enum) |
| `log_dev_event(message, data)` | Developer debug event |
| `end_log()` | Signal execution complete |

### BaseAction Shortcuts

`BaseAction` provides convenience methods that delegate to the logger:

```python
class TrainAction(BaseAction[TrainParams]):
    def execute(self) -> dict:
        # Direct logging methods
        self.log('epoch_start', {'epoch': 1})
        self.set_progress(1, 100)
        self.set_metrics({'loss': 0.5}, step='train')

        # These call self.ctx.logger internally
        return {'status': 'done'}
```

---

## Integration with Steps

### BaseStepContext

Steps access logging through `BaseStepContext`:

```python
from dataclasses import dataclass
from synapse_sdk.plugins.steps import BaseStep, StepResult, BaseStepContext

@dataclass
class MyContext(BaseStepContext):
    data: list[str] = field(default_factory=list)

class ProcessStep(BaseStep[MyContext]):
    @property
    def name(self) -> str:
        return 'process'

    @property
    def progress_weight(self) -> float:
        return 0.5

    def execute(self, context: MyContext) -> StepResult:
        # Log through context
        context.log('process_start', {'count': len(context.data)})

        for i, item in enumerate(context.data):
            context.set_progress(i + 1, len(context.data))
            # Process item...

        context.set_metrics({'processed': len(context.data)})

        return StepResult(success=True)
```

### LoggingStep Wrapper

Wrap any step with automatic timing and logging:

```python
from synapse_sdk.plugins.steps.utils import LoggingStep

# Wrap step with logging
logged_step = LoggingStep(ProcessStep())
registry.register(logged_step)

# Execution logs:
# step_start {'step': 'process'}
# step_end {'step': 'process', 'elapsed': 1.234, 'success': True}
```

---

## Progress Tracking

### Step-Based Progress

Modern API using step names for progress categorization:

```python
logger = ConsoleLogger()

# Set current step context
logger.set_step('download')
logger.set_progress(50, 100)  # Uses current step

# Or specify step explicitly
logger.set_progress(50, 100, step='training')

# Multiple concurrent progress tracks
logger.set_progress(100, 100, step='download')  # Complete
logger.set_progress(25, 100, step='training')   # 25%
```

### Step Parameter

Progress and metrics are organized by step name:

```python
# Specify step explicitly
logger.set_progress(50, 100, step='train')

# Or use current step from set_step()
logger.set_step('training')
logger.set_progress(50, 100)  # Uses current step
```

**Priority Order:**
1. Explicit `step` parameter
2. Current step from `set_step()`
3. `__default__` key

### ETA Calculation

Automatic time remaining estimation:

```python
logger.set_step('training')

# First call initializes timer
logger.set_progress(0, 100)
time.sleep(1)

# Subsequent calls calculate ETA
logger.set_progress(10, 100)
progress = logger.get_progress('training')
# progress.percent = 10.0
# progress.elapsed_time = 1.0  # seconds
# progress.time_remaining = 9.0  # estimated

# Reset timer by setting current=0
logger.set_progress(0, 100)  # Timer resets
```

### Failed Progress

Mark progress as failed:

```python
try:
    for i in range(100):
        logger.set_progress(i + 1, 100, step='process')
        process_item(i)
except Exception:
    logger.set_progress_failed('process')
    # progress.status = 'failed'
    raise
```

---

## Pipeline Progress Models

### ActionProgress

Track progress for a single action in a pipeline:

```python
from synapse_sdk.plugins.models.logger import ActionProgress
from synapse_sdk.plugins.models.pipeline import ActionStatus

action_progress = ActionProgress(
    name='train',
    status=ActionStatus.RUNNING,
    progress=75.5,
    progress_category='epoch',
    message='Training epoch 75/100',
    metrics={'loss': 0.05, 'accuracy': 0.95},
    started_at=datetime.now(),
)

# Serialize for API
data = action_progress.to_dict()
```

### PipelineProgress

Overall pipeline state tracking:

```python
from synapse_sdk.plugins.models.logger import PipelineProgress, ActionProgress
from synapse_sdk.plugins.models.pipeline import RunStatus

pipeline_progress = PipelineProgress(
    run_id='run-123',
    status=RunStatus.RUNNING,
    current_action='train',
    started_at=datetime.now(),
)

# Add action progress
pipeline_progress.actions['download'] = ActionProgress(
    name='download',
    status=ActionStatus.COMPLETED,
    progress=100.0,
)
pipeline_progress.actions['train'] = ActionProgress(
    name='train',
    status=ActionStatus.RUNNING,
    progress=50.0,
)

# Calculate overall progress
print(pipeline_progress.overall_progress)  # 75.0 (average)
print(pipeline_progress.completed_actions)  # 1
```

---

## Best Practices

### Use Step Context

Always set step context for organized logging:

```python
def execute(self) -> dict:
    # Set step for automatic categorization
    self.ctx.logger.set_step('download')

    for i in range(100):
        self.ctx.set_progress(i + 1, 100)
        # Progress automatically associated with 'download'

    self.ctx.logger.set_step('process')
    # Subsequent logs go to 'process'
```

### Structured Event Names

Use consistent, descriptive event names:

```python
# Good: specific, actionable names
logger.log(LogLevel.INFO, 'model_checkpoint_saved', {'path': path, 'epoch': 5})
logger.log(LogLevel.ERROR, 'dataset_validation_failed', {'errors': errors})
logger.log(LogLevel.DEBUG, 'batch_processed', {'batch_id': i, 'items': 32})

# Avoid: vague or generic names
logger.log(LogLevel.INFO, 'done', {})
logger.log(LogLevel.INFO, 'step1', {'data': data})
```

### Include Relevant Data

Log actionable information:

```python
# Good: includes context for debugging
logger.log(LogLevel.ERROR, 'file_not_found', {
    'path': '/data/train.csv',
    'checked_paths': ['/data', '/tmp/data'],
    'suggestion': 'Ensure dataset is downloaded',
})

# Avoid: minimal information
logger.log(LogLevel.ERROR, 'error', {'msg': 'not found'})
```

### Handle Logger Lifecycle

Always finish the logger:

```python
logger = ConsoleLogger()
try:
    # ... operations ...
    logger.set_progress(100, 100)
except Exception:
    logger.set_progress_failed()
    raise
finally:
    logger.finish()  # Always call finish
```

### Guard Against Finished Logger

```python
logger.finish()

try:
    logger.info("After finish")
except RuntimeError as e:
    # "Cannot log to a finished logger"
    pass
```

---

## Module Reference

| Module | Classes | Purpose |
|--------|---------|---------|
| `synapse_sdk.loggers` | `BaseLogger`, `ConsoleLogger`, `BackendLogger`, `NoOpLogger`, `LoggerBackend`, `MessageLogData`, `ProgressData`, `LogEntry` | Core logging system |
| `synapse_sdk.plugins.models.logger` | `LogLevel`, `ActionProgress`, `PipelineProgress`, `Checkpoint` | Progress models and enums |
| `synapse_sdk.plugins.steps.utils.logging` | `LoggingStep` | Step wrapper with timing |
| `synapse_sdk.plugins.context` | `RuntimeContext` | Action context with logger |
| `synapse_sdk.i18n` | `Translator`, `LocalizedMessage`, `translate` | Internationalization support |
| `synapse_sdk.i18n.messages` | `LogMessageCode` | Built-in localized message codes |

---

## Related Documentation

- **[OVERVIEW.md](OVERVIEW.md)** - Plugin system introduction
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Technical architecture
- **[STEP.md](STEP.md)** - Step implementations
- **[README.md](README.md)** - Quick reference
