# Upload Action Architecture

This document describes the architecture and implementation of the Upload Action in the Synapse SDK.

## Overview

The Upload Action provides a complete workflow for uploading files to Synapse storage and creating data units. It uses a step-based architecture with pluggable strategies for maximum flexibility.

## Architecture Diagram

```mermaid
flowchart TB
    subgraph BaseAction["BaseUploadAction"]
        BA1["setup_steps(): Register workflow steps"]
        BA2["get_allowed_extensions(): Define file type restrictions"]
        BA3["create_context(): Create UploadContext"]
        BA4["execute(): Run the orchestrator"]
    end

    subgraph DefaultAction["DefaultUploadAction"]
        DA["Standard 8-step workflow<br/>with default configurations"]
    end

    subgraph Orch["Orchestrator"]
        OR["Executes steps in order<br/>with progress tracking and rollback"]
    end

    subgraph Steps["Workflow Steps"]
        direction LR
        S1["Step 1-4<br/>Preparation"]
        S2["Step 5-6<br/>Upload"]
        S3["Step 7-8<br/>Finalization"]
    end

    BaseAction --> DefaultAction
    DefaultAction --> Orch
    Orch --> S1
    Orch --> S2
    Orch --> S3

    style BaseAction fill:#e3f2fd
    style DefaultAction fill:#e8f5e9
    style Orch fill:#fff3e0
    style Steps fill:#fce4ec
```

## Directory Structure

```
synapse_sdk/plugins/actions/upload/
├── __init__.py           # Public exports
├── action.py             # BaseUploadAction, DefaultUploadAction
├── context.py            # UploadContext (shared state)
├── enums.py              # LogCode, UploadStatus, LogLevel
├── exceptions.py         # Custom exceptions
├── log_messages.py       # Log message definitions
├── models.py             # UploadParams, AssetConfig
├── steps/                # Workflow steps
│   ├── __init__.py
│   ├── initialize.py     # Step 1: InitializeStep
│   ├── process_metadata.py # Step 2: ProcessMetadataStep
│   ├── analyze_collection.py # Step 3: AnalyzeCollectionStep
│   ├── organize.py       # Step 4: OrganizeFilesStep
│   ├── validate.py       # Step 5: ValidateFilesStep
│   ├── upload.py         # Step 6: UploadFilesStep
│   ├── generate.py       # Step 7: GenerateDataUnitsStep
│   └── cleanup.py        # Step 8: CleanupStep
└── strategies/           # Pluggable strategies
    ├── __init__.py
    ├── base.py           # Abstract interfaces
    ├── file_discovery.py # File discovery strategies
    ├── metadata.py       # Metadata extraction strategies
    ├── validation.py     # Validation strategies
    ├── upload_strategy.py # Upload strategies
    └── data_unit.py      # Data unit generation strategies
```

## Workflow Steps

The default upload workflow consists of 8 steps executed in order:

| Step | Name | Weight | Description |
|------|------|--------|-------------|
| 1 | `initialize` | 5% | Setup storage and working directory paths |
| 2 | `process_metadata` | 10% | Load metadata from Excel/CSV files |
| 3 | `analyze_collection` | 5% | Retrieve file specifications from data collection |
| 4 | `organize_files` | 15% | Discover and group files by stem |
| 5 | `validate_files` | 10% | Validate files against specifications |
| 6 | `upload_files` | 30% | Upload files to storage |
| 7 | `generate_data_units` | 20% | Create data units from uploaded files |
| 8 | `cleanup` | 5% | Cleanup temporary resources and log completion |

### Step Details

#### 1. InitializeStep

Initializes the upload workflow by setting up storage and paths.

**Responsibilities:**
- Validates and retrieves storage configuration from API
- Sets up working directory path (single-path mode)
- Prepares context for subsequent steps

**Key Code:**
```python
storage = context.client.get_storage(storage_id)
context.storage = storage

if use_single_path:
    pathlib_cwd = get_pathlib(storage_config, path)
    context.pathlib_cwd = pathlib_cwd
```

#### 2. ProcessMetadataStep

Processes metadata from Excel or CSV files.

**Supported Formats:**
- Excel: `.xlsx`, `.xls`
- CSV: `.csv`

**Path Resolution Order:**
1. Absolute path
2. Relative to storage default path
3. Relative to working directory (single-path mode)

**Default Metadata Files:**
When no path is specified, searches for: `meta.xlsx` > `meta.xls` > `meta.csv`

**Strategies:**
- `ExcelMetadataStrategy`: Extract from Excel files
- `CsvMetadataStrategy`: Extract from CSV files
- `NoneMetadataStrategy`: No-op for uploads without metadata

#### 3. AnalyzeCollectionStep

Retrieves file specifications from the data collection.

**Output:**
- `context.data_collection`: Full collection data
- `file_specifications`: List of file specs with `name`, `is_required`, `file_type`, `extensions`

#### 4. OrganizeFilesStep

Discovers and organizes files according to specifications.

**Modes:**
- **Single-path mode**: All files from one base directory
- **Multi-path mode**: Different paths per file specification

**Organization Logic:**
1. Discover files in type directories (spec_name as folder)
2. Group files by stem (e.g., `image_001.jpg` and `image_001.json` grouped together)
3. Match files with metadata by filename

**Strategies:**
- `FlatFileDiscoveryStrategy`: Non-recursive discovery
- `RecursiveFileDiscoveryStrategy`: Recursive discovery (default)

**Excluded Directories:**
```python
EXCLUDED_DIRS = {'@eaDir', '.@__thumb', '@Recycle', '#recycle',
                 '.DS_Store', 'Thumbs.db', '.synology', '__pycache__', '.git'}
```

#### 5. ValidateFilesStep

Validates organized files against specifications.

**Validations:**
- Files with allowed extensions (if configured via `get_allowed_extensions()`)
- Required file types are present in each group
- File extensions match specification expectations

**Strategies:**
- `DefaultValidationStrategy`: Standard validation rules

#### 6. UploadFilesStep

Uploads files to storage.

**Upload Methods:**
1. **Presigned URL Upload**: Direct upload to storage (S3, MinIO, GCS, Azure)
2. **Traditional Upload**: Through API server (fallback)

**Configuration:**
```python
UploadConfig(
    chunked_threshold_mb=50,  # Chunked upload for large files
    batch_size=1,
    max_workers=32,
    use_presigned=True
)
```

**Strategies:**
- `SyncUploadStrategy`: Synchronous upload with automatic presigned/traditional selection

**Features:**
- Automatic filtering of invalid non-required files (empty/missing)
- Progress tracking per file
- Metrics tracking (success/failed counts)

#### 7. GenerateDataUnitsStep

Creates data units from uploaded files.

**Strategies:**
- `SingleDataUnitStrategy`: Create one at a time (max control)
- `BatchDataUnitStrategy`: Create in batches (better performance)

**Output:**
```python
context.data_units = [
    {'id': 123, 'meta': {...}, 'files': {...}},
    ...
]
```

#### 8. CleanupStep

Finalizes the workflow.

**Responsibilities:**
- Clean up temporary directories (if configured)
- Log completion statistics
- Report final metrics

## Context (UploadContext)

The `UploadContext` carries state between workflow steps:

```python
@dataclass
class UploadContext(BaseStepContext):
    # Input parameters
    params: dict[str, Any]
    allowed_extensions: dict[str, list[str]] | None

    # Processing state (populated by steps)
    storage: Any | None
    data_collection: Any | None
    project: Any | None
    pathlib_cwd: Path | None
    organized_files: list[dict[str, Any]]
    uploaded_files: list[dict[str, Any]]
    data_units: list[dict[str, Any]]
    excel_metadata: dict[str, Any] | None
```

**Key Properties:**
- `use_single_path`: Mode selector (True = single path, False = multi-path)
- `upload_name`: Human-readable upload name
- `max_file_size_bytes`: Max file size limit
- `batch_size`: Data unit creation batch size
- `use_async_upload`: Async upload flag

## Parameters (UploadParams)

```python
class UploadParams(BaseModel):
    name: str                          # Upload operation name
    description: str | None = None

    # Mode selection
    use_single_path: bool = True       # True = single-path, False = multi-path

    # Single-path mode
    path: str | None = None            # Base path (required if use_single_path=True)
    is_recursive: bool = True

    # Multi-path mode
    assets: dict[str, AssetConfig] | None = None  # Per-spec paths

    # Required resources
    storage: int                       # Storage ID
    data_collection: int               # Data collection ID
    project: int | None = None

    # Metadata
    excel_metadata_path: str | None = None

    # Limits
    max_file_size_mb: int = 50
    creating_data_unit_batch_size: int = 1
    use_async_upload: bool = True
    extra_params: dict[str, Any] | None = None
```

## Operational Modes

### Single-Path Mode (Default)

All file specifications share one base directory. Files are organized into subdirectories named after each spec.

```
/data/upload/
├── image_1/          # Required spec
│   ├── 001.jpg
│   └── 002.jpg
├── json_1/           # Optional spec
│   └── 001.json
└── meta.xlsx         # Metadata file
```

**Usage:**
```python
params = UploadParams(
    name="Standard Upload",
    use_single_path=True,
    path="/data/upload",
    is_recursive=True,
    storage=1,
    data_collection=5
)
```

### Multi-Path Mode

Each file specification has its own path configuration.

```
/sensors/camera/      # image_1 spec
├── 001.jpg
└── 002.jpg

/sensors/lidar/       # pcd_1 spec
├── 001.pcd
└── 002.pcd
```

**Usage:**
```python
params = UploadParams(
    name="Multi-Source Upload",
    use_single_path=False,
    assets={
        "image_1": AssetConfig(path="/sensors/camera", is_recursive=True),
        "pcd_1": AssetConfig(path="/sensors/lidar", is_recursive=False)
    },
    storage=1,
    data_collection=5
)
```

## Strategy Pattern

All major components use the Strategy pattern for extensibility:

### Strategy Interfaces

```python
class FileDiscoveryStrategy(ABC):
    def discover(self, path: Path, recursive: bool) -> list[Path]: ...
    def organize(self, files, specs, metadata, type_dirs) -> list[dict]: ...

class MetadataStrategy(ABC):
    def extract(self, source_path: Path) -> dict[str, dict[str, Any]]: ...
    def validate(self, metadata) -> ValidationResult: ...

class ValidationStrategy(ABC):
    def validate_params(self, params) -> ValidationResult: ...
    def validate_files(self, files, specs) -> ValidationResult: ...

class UploadStrategy(ABC):
    def upload(self, files, config) -> list[dict]: ...

class DataUnitStrategy(ABC):
    def generate(self, uploaded_files, batch_size) -> list[dict]: ...
```

### Available Implementations

| Interface | Implementations |
|-----------|-----------------|
| FileDiscoveryStrategy | `FlatFileDiscoveryStrategy`, `RecursiveFileDiscoveryStrategy` |
| MetadataStrategy | `ExcelMetadataStrategy`, `CsvMetadataStrategy`, `NoneMetadataStrategy` |
| ValidationStrategy | `DefaultValidationStrategy` |
| UploadStrategy | `SyncUploadStrategy` |
| DataUnitStrategy | `SingleDataUnitStrategy`, `BatchDataUnitStrategy` |

## Customization

### Custom Upload Action

```python
from synapse_sdk.plugins.actions.upload import (
    BaseUploadAction,
    UploadParams,
    UploadContext,
)
from synapse_sdk.plugins.steps import StepRegistry

class MyUploadAction(BaseUploadAction[UploadParams]):
    action_name = 'upload'
    params_model = UploadParams

    def setup_steps(self, registry: StepRegistry[UploadContext]) -> None:
        # Register only needed steps
        registry.register(InitializeStep())
        registry.register(OrganizeFilesStep())
        registry.register(UploadFilesStep())
        registry.register(CleanupStep())

    def get_allowed_extensions(self) -> dict[str, list[str]] | None:
        # Restrict to specific file types
        return {
            'video': ['.mp4', '.avi', '.mov'],
            'image': ['.jpg', '.jpeg', '.png'],
        }
```

### Custom Strategy

```python
from synapse_sdk.plugins.actions.upload.strategies import (
    FileDiscoveryStrategy,
    ValidationResult,
)

class CustomDiscoveryStrategy(FileDiscoveryStrategy):
    def discover(self, path: Path, recursive: bool = True) -> list[Path]:
        # Custom discovery logic
        return list(path.rglob('*.custom'))

    def organize(self, files, specs, metadata, type_dirs=None):
        # Custom organization logic
        return [{'files': {...}, 'meta': {...}}]
```

## Logging

### Log Codes

The upload action uses structured logging with predefined codes:

```python
class LogCode(str, Enum):
    # Validation
    VALIDATION_FAILED = 'VALIDATION_FAILED'

    # File discovery
    FILES_DISCOVERED = 'FILES_DISCOVERED'
    NO_FILES_FOUND = 'NO_FILES_FOUND'

    # Upload progress
    UPLOADING_DATA_FILES = 'UPLOADING_DATA_FILES'
    FILE_UPLOAD_FAILED = 'FILE_UPLOAD_FAILED'

    # Data units
    GENERATING_DATA_UNITS = 'GENERATING_DATA_UNITS'
    DATA_UNIT_CREATED = 'DATA_UNIT_CREATED'

    # Step lifecycle
    STEP_STARTING = 'STEP_STARTING'
    STEP_COMPLETED = 'STEP_COMPLETED'
    STEP_FAILED = 'STEP_FAILED'

    # Rollback
    ROLLBACK_STARTING = 'ROLLBACK_STARTING'
    ROLLBACK_COMPLETED = 'ROLLBACK_COMPLETED'
```

### Log Levels

```python
class LogLevel(str, Enum):
    INFO = 'info'       # General information
    SUCCESS = 'success' # Positive outcomes
    WARNING = 'warning' # Non-critical issues
    DANGER = 'danger'   # Critical failures
    DEBUG = 'debug'     # Development messages
```

## Error Handling

### Rollback Support

Each step implements a `rollback()` method that is called automatically on failure:

```python
class MyStep(BaseStep[UploadContext]):
    def execute(self, context: UploadContext) -> StepResult:
        # ... execution logic
        return StepResult(
            success=True,
            data={'key': 'value'},
            rollback_data={'saved_state': state}
        )

    def rollback(self, context: UploadContext, result: StepResult) -> None:
        # Cleanup using result.rollback_data
        saved_state = result.rollback_data.get('saved_state')
        # ... rollback logic
```

### Exception Hierarchy

```
Exception
├── ExcelSecurityError    # Excel security violations
├── ExcelParsingError     # Excel parsing failures
├── CsvSecurityError      # CSV security violations
└── CsvParsingError       # CSV parsing failures
```

## Security

### Excel File Security

```python
class ExcelSecurityConfig:
    max_file_size_bytes: int = 50 * 1024 * 1024  # 50MB
    max_memory_usage_bytes: int = 150 * 1024 * 1024  # 150MB
    max_rows: int = 100000
    max_columns: int = 100
    max_filename_length: int = 255
    max_column_name_length: int = 100
    max_metadata_value_length: int = 10000
```

### CSV File Security

```python
class CsvSecurityConfig:
    max_file_size_bytes: int = 50 * 1024 * 1024
    max_rows: int = 100000
    max_columns: int = 100
    max_filename_length: int = 255
    encoding: str = 'utf-8'
    delimiter: str = ','
```

## Usage Example

```python
from synapse_sdk.plugins.actions.upload import (
    DefaultUploadAction,
    UploadParams,
)

class MyPlugin:
    class UploadAction(DefaultUploadAction[UploadParams]):
        action_name = 'upload'
        params_model = UploadParams

# Execute
action = MyPlugin.UploadAction()
result = action.execute()

print(f"Uploaded files: {result['uploaded_files']}")
print(f"Data units: {result['data_units']}")
```
