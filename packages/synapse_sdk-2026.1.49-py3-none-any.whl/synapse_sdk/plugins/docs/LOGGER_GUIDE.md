# Logger Guide

This guide explains the different logger types available in the Synapse SDK and when to use each one.

## Available Loggers

### 1. ConsoleLogger

**Use case**: Basic console output with colored messages

**Features**:
- Prints logs to console with ANSI color codes
- Simple progress reporting (text-based)
- Suitable for basic scripts and debugging

**Example**:
```python
from synapse_sdk.loggers import ConsoleLogger

logger = ConsoleLogger()
logger.info('Processing started')
logger.set_progress(50, 100, step='processing')
logger.finish()
```

---

### 2. TqdmLogger ⭐ NEW

**Use case**: Visual progress tracking with tqdm progress bars

**Features**:
- Creates visual progress bars using tqdm
- Supports multiple concurrent progress bars for different steps
- Automatically manages bar lifecycle (create, update, close)
- Falls back to ConsoleLogger if tqdm is not available
- Inherits all ConsoleLogger functionality (colored logs)

**Example**:
```python
from synapse_sdk.loggers import TqdmLogger

logger = TqdmLogger()

# Single progress bar
for i in range(101):
    logger.set_progress(i, 100, step='download')

# Multiple steps with separate progress bars
for step in ['preprocess', 'train', 'evaluate']:
    for i in range(101):
        logger.set_progress(i, 100, step=step)

logger.finish()
```

**Visual Output**:
```
[download]: 100%|██████████| [00:02<00:00]
[preprocess]: 100%|██████████| [00:01<00:00]
[train]: 100%|██████████| [00:05<00:00]
```

---

### 3. JobLogger

**Use case**: Production jobs that need to sync with Synapse backend

**Features**:
- Prints to console AND sends data to backend API
- Tracks progress, metrics, and logs
- Used by Synapse platform for job monitoring
- Supports step proportions for overall progress calculation

**Example**:
```python
from synapse_sdk.loggers import JobLogger

logger = JobLogger(
    client=backend_client,
    job_id='job-123',
    step_proportions={'train': 80, 'upload': 20}
)

logger.set_progress(50, 100, step='train')
logger.set_metrics({'loss': 0.5, 'accuracy': 0.95}, step='train')
logger.finish()
```

---

### 4. BackendLogger

**Use case**: Sync with remote backend only (no console output)

**Features**:
- Sends data to backend via LoggerBackend protocol
- No console output
- Suitable for headless/silent operations

---

### 5. NoOpLogger

**Use case**: Testing or disabled logging

**Features**:
- Does nothing - all methods are no-ops
- Useful for tests or when logging should be disabled
- Zero overhead

---

## Logger Comparison

| Logger | Console Output | Progress Bars | Backend Sync | Use Case |
|--------|---------------|---------------|--------------|----------|
| ConsoleLogger | ✅ | ❌ | ❌ | Basic scripts |
| TqdmLogger | ✅ | ✅ | ❌ | Visual progress tracking |
| JobLogger | ✅ | ❌ | ✅ | Production jobs |
| BackendLogger | ❌ | ❌ | ✅ | Headless backend sync |
| NoOpLogger | ❌ | ❌ | ❌ | Testing/disabled |

---

## Choosing the Right Logger

- **Local development/scripts**: Use `TqdmLogger` for visual feedback, or `ConsoleLogger` for simple output
- **Synapse platform jobs**: Use `JobLogger` (configured automatically by the SDK)
- **Testing**: Use `NoOpLogger` or mock loggers
- **Silent operations**: Use `BackendLogger` or `NoOpLogger`

---

## Internationalization (i18n) Support

All loggers support internationalized messages through integration with the `i18n` module. This enables displaying log messages in the user's preferred language.

### LocalizedMessage

Use `LocalizedMessage` to define multi-language messages:

```python
from synapse_sdk.i18n import LocalizedMessage

# Define message with multiple translations
message: LocalizedMessage = {
    'en': 'Processing {count} items',
    'ko': '{count}개 항목 처리 중',
}
```

### Using i18n with RuntimeContext

When using actions, `RuntimeContext.log_message()` handles translation automatically based on `ctx.language`:

```python
from synapse_sdk.i18n import LocalizedMessage
from synapse_sdk.plugins.models.logger import LogLevel

class MyAction(BaseAction[MyParams]):
    def execute(self) -> dict:
        message: LocalizedMessage = {
            'en': 'Training epoch {epoch}/{total}',
            'ko': '학습 에폭 {epoch}/{total}',
        }

        # Automatically uses ctx.language for translation
        self.ctx.log_message(message, LogLevel.INFO, epoch=1, total=100)

        return {'status': 'done'}
```

### Language Configuration

Language is specified when creating executors:

```python
# LocalExecutor with Korean
from synapse_sdk.plugins.executors.local import LocalExecutor
executor = LocalExecutor(language='ko')

# RayActorExecutor with language
from synapse_sdk.plugins.executors.ray.task import RayActorExecutor
executor = RayActorExecutor(working_dir='/path', language='ko')

# CLI with --lang option
# synapse plugin test train --lang=ko
```

### LogMessageCode (Built-in Messages)

For common SDK messages, use pre-defined `LogMessageCode` subclass values. Each action type has its own subclass:

```python
from synapse_sdk.plugins.actions.upload.log_messages import UploadLogMessageCode

# Use with RuntimeContext
self.ctx.log_message(UploadLogMessageCode.UPLOAD_FILES_UPLOADING, count=10)
```

See [LOGGING_SYSTEM.md](LOGGING_SYSTEM.md#internationalization-i18n-support) for detailed i18n documentation.

---

## Progress Tracking Best Practices

### Using set_progress()

```python
# Basic usage
logger.set_progress(current=50, total=100, step='processing')

# With multiple steps
for step_name in ['step1', 'step2', 'step3']:
    for i in range(total):
        logger.set_progress(i, total, step=step_name)
```

### Step Organization

```python
# Define steps upfront for better organization
STEPS = {
    'initialize': 'Initializing...',
    'download': 'Downloading data...',
    'process': 'Processing...',
    'upload': 'Uploading results...',
}

logger = TqdmLogger()

for step_name, description in STEPS.items():
    logger.info(description)
    for i in range(101):
        logger.set_progress(i, 100, step=step_name)
        # ... do work ...
```

---

## API Reference

### Common Methods (All Loggers)

```python
# Logging
logger.info(message: str)
logger.debug(message: str)
logger.warning(message: str)
logger.error(message: str)
logger.critical(message: str)

# Progress tracking
logger.set_progress(current: int, total: int, step: str | None = None)
logger.set_progress_failed(step: str | None = None)

# Metrics
logger.set_metrics(value: dict[str, Any], step: str | None = None)

# Lifecycle
logger.set_step(step: str | None, order: int | None = None)
logger.get_step() -> str | None
logger.get_step_order() -> int | None
logger.finish()
```

### TqdmLogger Specific

The `TqdmLogger` doesn't add new methods - it enhances `set_progress()` to use tqdm bars:

- Automatically creates a new progress bar when a new step is encountered
- Updates the bar as progress advances
- Closes the bar when progress reaches 100%
- Supports multiple concurrent bars (stacked vertically)

---

## Examples

See the `examples/tqdm_logger_example.py` file for a complete working example.

Run the test suite:
```bash
python test_tqdm_logger.py
```
