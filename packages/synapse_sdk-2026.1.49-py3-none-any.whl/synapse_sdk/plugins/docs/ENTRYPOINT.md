# Plugin Entrypoint Module

Location: `synapse_sdk/plugins/entrypoint.py`

The entrypoint module is the bridge between Ray Jobs API and the Synapse plugin system. It handles action dispatch, context creation, and result serialization when plugins are executed remotely on Ray clusters.

---

## Overview

When the `RayJobsApiExecutor` submits a job, it runs the entrypoint module as the job command:

```bash
python -m synapse_sdk.plugins.entrypoint
```

The entrypoint reads configuration from environment variables and orchestrates action execution.

---

## Execution Flow

```mermaid
flowchart TD
    A["Ray Job Submitted"] --> B["python -m synapse_sdk.plugins.entrypoint"]
    B --> C["Read Environment Variables"]
    C --> D["Load Action Parameters"]
    D --> E["Import Action Class"]
    E --> F["Create RuntimeContext"]
    F --> G["action_cls.dispatch(params, ctx)"]
    G --> H["action.run()"]
    H --> I["Serialize Result"]
    I --> J["Print JSON with Markers"]
    J --> K["Ray Job Completes"]

    style A fill:#e8f5e9
    style K fill:#e8f5e9
    style I fill:#fff9c4
```

---

## Environment Variables

The entrypoint reads the following environment variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `SYNAPSE_ACTION_ENTRYPOINT` | Yes | Module path to action class (e.g., `mymodule.MyAction`) |
| `SYNAPSE_ACTION_PARAMS` | One of these | JSON string of action parameters |
| `SYNAPSE_ACTION_PARAMS_FILE` | One of these | Path to JSON file with parameters |
| `SYNAPSE_JOB_ID` | No | Job ID for tracking (falls back to `RAY_JOB_ID`) |
| `SYNAPSE_HOST` | No | Backend host URL for API calls |
| `SYNAPSE_ACCESS_TOKEN` | No | Authentication token for backend |

### Parameter Loading Priority

1. `SYNAPSE_ACTION_PARAMS` - Direct JSON string
2. `SYNAPSE_ACTION_PARAMS_FILE` - Path to JSON file (used if params not in env)

---

## Result Serialization

The entrypoint handles three types of action results:

### 1. Pydantic BaseModel Results

Actions that define a `result_model` return Pydantic models:

```python
class ToTaskResult(BaseModel):
    status: JobStatus
    processed_count: int
    error_count: int

class ToTaskAction(BaseAction[ToTaskParams]):
    result_model = ToTaskResult

    def run(self) -> ToTaskResult:
        return ToTaskResult(status=JobStatus.SUCCEEDED, ...)
```

The entrypoint converts these using `model_dump(mode='json')`:

```python
if isinstance(result, BaseModel):
    result_json = result.model_dump(mode='json')
```

**Why `mode='json'`?**
- Enums → string values (e.g., `JobStatus.SUCCEEDED` → `"succeeded"`)
- Datetimes → ISO format strings
- Nested models → recursively converted
- All values guaranteed JSON-serializable

### 2. Dictionary Results

Actions returning plain dictionaries are used directly:

```python
def run(self) -> dict:
    return {'status': 'success', 'count': 100}
```

### 3. Other Results

Any other result types are wrapped:

```python
def run(self) -> str:
    return 'completed'

# Serialized as: {'result': 'completed'}
```

---

## Result Output Format

Results are printed with markers for reliable parsing:

```
__SYNAPSE_RESULT_START__
{"status": "succeeded", "processed_count": 100, "error_count": 0}
__SYNAPSE_RESULT_END__
```

The `RayJobsApiExecutor.get_result()` method parses these markers from job logs.

---

## Logger Selection

The entrypoint automatically selects the appropriate logger:

```python
if client and job_id:
    # Production: Reports progress to Synapse backend
    logger = JobLogger(client=client, job_id=job_id)
else:
    # Development: Console output only
    logger = ConsoleLogger()
```

### JobLogger Features
- Reports progress updates to backend API
- Sends structured log events
- Updates job metrics in real-time

### ConsoleLogger Features
- Prints to stdout/stderr
- No backend communication required
- Useful for local development

---

## RuntimeContext Creation

The entrypoint creates a `RuntimeContext` with all required services:

```python
ctx = RuntimeContext(
    logger=logger,           # JobLogger or ConsoleLogger
    env=PluginEnvironment.from_environ(),  # Environment config
    job_id=job_id,           # Job tracking ID
    client=client,           # BackendClient for API calls
)
```

---

## Error Handling

### Missing Parameters

```python
if not params_json:
    raise ValueError('No params provided via SYNAPSE_ACTION_PARAMS or SYNAPSE_ACTION_PARAMS_FILE')
```

### Missing Entrypoint

```python
if not entrypoint:
    raise ValueError('SYNAPSE_ACTION_ENTRYPOINT not set')
```

### Action Execution Errors

Action errors propagate as-is, causing the Ray job to fail with error logs.

---

## Code Reference

### Module Structure

The entrypoint module is organized into focused helper functions for maintainability and testability:

```
entrypoint.py
├── _configure_logging()      # Setup logging format
├── _setup_sys_path()         # Add cwd to sys.path
├── _load_params()            # Load params from env/file
├── _load_action_class()      # Import action class
├── _create_logger()          # Create JobLogger or ConsoleLogger
├── _output_result()          # Format and print result JSON
└── main()                    # Orchestrator function
```

### Helper Functions

#### `_configure_logging()`
```python
def _configure_logging() -> None:
    """Configure logging for plugin execution."""
```

#### `_setup_sys_path()`
```python
def _setup_sys_path() -> None:
    """Add current working directory to sys.path for module imports."""
```

#### `_load_params()`
```python
def _load_params() -> dict[str, Any]:
    """Load action parameters from environment variable or file.

    Returns:
        Parsed action parameters as a dictionary.

    Raises:
        ValueError: If no parameters are provided.
    """
```

#### `_load_action_class()`
```python
def _load_action_class() -> type[BaseAction]:
    """Load action class from entrypoint environment variable.

    Returns:
        The action class to execute.

    Raises:
        ValueError: If SYNAPSE_ACTION_ENTRYPOINT is not set.
    """
```

#### `_create_logger()`
```python
def _create_logger(client: BackendClient | None, job_id: str | None) -> BaseLogger:
    """Create appropriate logger based on available context.

    Args:
        client: Backend client for API communication.
        job_id: Job ID for tracking.

    Returns:
        JobLogger if client and job_id available, else ConsoleLogger.
    """
```

#### `_output_result()`
```python
def _output_result(result: Any) -> None:
    """Output result as JSON with markers for capture.

    Args:
        result: Action result (dict, BaseModel, or other).
    """
```

### Main Function

```python
def main() -> dict[str, Any] | BaseModel:
    """Run a plugin action based on environment configuration.

    Environment Variables:
        SYNAPSE_ACTION_ENTRYPOINT: Module path to action class
        SYNAPSE_ACTION_PARAMS: JSON string of action parameters
        SYNAPSE_ACTION_PARAMS_FILE: Alternative path to JSON file
        SYNAPSE_JOB_ID: Optional job ID (falls back to RAY_JOB_ID)

    Returns:
        Action result (dict or Pydantic BaseModel).

    Raises:
        ValueError: If required environment variables are missing.
    """
```

### Complete Flow

```python
def main() -> dict[str, Any] | BaseModel:
    # 1. Configure logging
    _configure_logging()

    # 2. Add working directory to path
    _setup_sys_path()

    # 3. Load parameters from env or file
    params = _load_params()

    # 4. Import action class dynamically
    action_cls = _load_action_class()

    # 5. Create context dependencies
    client = create_backend_client()
    job_id = os.environ.get('SYNAPSE_JOB_ID') or os.environ.get('RAY_JOB_ID')
    logger = _create_logger(client, job_id)

    ctx = RuntimeContext(
        logger=logger,
        env=PluginEnvironment.from_environ(),
        job_id=job_id,
        client=client,
    )

    # 6. Execute action
    result = action_cls.dispatch(params, ctx)
    logger.finish()

    # 7. Output result
    _output_result(result)
    return result
```

---

## Integration with RayJobsApiExecutor

The executor sets up environment variables and submits the job:

```python
# RayJobsApiExecutor.submit()
runtime_env = {
    'env_vars': {
        'SYNAPSE_ACTION_ENTRYPOINT': 'mymodule.MyAction',
        'SYNAPSE_ACTION_PARAMS': json.dumps(params),
        'SYNAPSE_JOB_ID': job_id,
        'SYNAPSE_HOST': os.environ.get('SYNAPSE_HOST'),
        'SYNAPSE_ACCESS_TOKEN': os.environ.get('SYNAPSE_ACCESS_TOKEN'),
    },
    'working_dir': working_dir,
    'pip': requirements,
}

# Submit to Ray Jobs API
client.submit_job(
    entrypoint='python -m synapse_sdk.plugins.entrypoint',
    runtime_env=runtime_env,
    job_id=job_id,
)
```

---

## Troubleshooting

### Job Status FAILED but Steps Succeeded

**Symptom**: All workflow steps complete successfully, but backend shows FAILED.

**Cause**: Result serialization error (e.g., `TypeError: Object of type ToTaskResult is not JSON serializable`).

**Solution**: Ensure the entrypoint handles Pydantic models with `model_dump(mode='json')`.

### Missing Result in Logs

**Symptom**: Job completes but `get_result()` returns None or raises error.

**Cause**: Result markers not found in logs.

**Check**:
1. Verify `__SYNAPSE_RESULT_START__` and `__SYNAPSE_RESULT_END__` markers exist
2. Check for exceptions before result printing
3. Verify JSON serialization succeeded

### Environment Variable Not Found

**Symptom**: `ValueError: SYNAPSE_ACTION_ENTRYPOINT not set`

**Cause**: Environment variables not passed through runtime_env.

**Solution**: Verify `runtime_env['env_vars']` includes all required variables.

---

## Related Documentation

- [Ray Execution](../../docs/docs/plugins/execution/ray-execution.md) - RayJobsApiExecutor usage
- [ARCHITECTURE.md](ARCHITECTURE.md) - Plugin system architecture
- [ACTION_DEV_GUIDE.md](ACTION_DEV_GUIDE.md) - Action development guide
