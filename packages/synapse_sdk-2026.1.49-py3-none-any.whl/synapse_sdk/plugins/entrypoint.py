"""Entrypoint module for running plugin actions via Ray Jobs API.

Usage: python -m synapse_sdk.plugins.entrypoint

This module is invoked by the RayJobsApiExecutor to run plugin actions.
It reads configuration from environment variables and dispatches the action.
"""

from __future__ import annotations

import importlib
import json
import logging
import os
import sys
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pydantic import BaseModel

    from synapse_sdk.clients.backend import BackendClient
    from synapse_sdk.loggers import BaseLogger
    from synapse_sdk.plugins.action import BaseAction


def _configure_logging() -> None:
    """Configure logging for plugin execution."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        force=True,
    )


def _setup_sys_path() -> None:
    """Add current working directory to sys.path for module imports."""
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)


def _load_params() -> dict[str, Any]:
    """Load action parameters from environment variable or file.

    Returns:
        Parsed action parameters as a dictionary.

    Raises:
        ValueError: If no parameters are provided.
    """
    params_json = os.environ.get('SYNAPSE_ACTION_PARAMS')

    if not params_json:
        params_file = os.environ.get('SYNAPSE_ACTION_PARAMS_FILE')
        if params_file and os.path.exists(params_file):
            with open(params_file) as f:
                params_json = f.read()

    if not params_json:
        raise ValueError('No params provided via SYNAPSE_ACTION_PARAMS or SYNAPSE_ACTION_PARAMS_FILE')

    return json.loads(params_json)


def _load_action_class() -> type[BaseAction]:
    """Load action class from entrypoint environment variable.

    Returns:
        The action class to execute.

    Raises:
        ValueError: If SYNAPSE_ACTION_ENTRYPOINT is not set.
    """
    entrypoint = os.environ.get('SYNAPSE_ACTION_ENTRYPOINT')
    if not entrypoint:
        raise ValueError('SYNAPSE_ACTION_ENTRYPOINT not set')

    module_path, class_name = entrypoint.rsplit('.', 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def _create_logger(client: BackendClient | None, job_id: str | None) -> BaseLogger:
    """Create appropriate logger based on available context.

    Args:
        client: Backend client for API communication.
        job_id: Job ID for tracking.

    Returns:
        JobLogger if client and job_id available, else ConsoleLogger.
    """
    if client and job_id:
        from synapse_sdk.loggers import JobLogger

        logger = JobLogger(client=client, job_id=job_id)
        print(f'INFO: Using JobLogger with job_id={job_id}', flush=True)
    else:
        from synapse_sdk.loggers import ConsoleLogger

        logger = ConsoleLogger()
        print(f'INFO: Using ConsoleLogger (client={"set" if client else "None"}, job_id={job_id})', flush=True)

    return logger


def _serialize_result(result: Any) -> dict[str, Any] | list[Any]:
    """Serialize action result to JSON-compatible format.

    Args:
        result: Action result (dict, BaseModel, or other).

    Returns:
        JSON-serializable result data.
    """
    from pydantic import BaseModel

    if isinstance(result, BaseModel):
        return result.model_dump(mode='json')
    elif isinstance(result, dict):
        return result
    else:
        return {'result': result}


def _output_result(result: Any) -> None:
    """Output result as JSON with markers for capture.

    Args:
        result: Action result (dict, BaseModel, or other).
    """
    result_json = _serialize_result(result)
    print('__SYNAPSE_RESULT_START__')
    print(json.dumps(result_json))
    print('__SYNAPSE_RESULT_END__')


def _update_job_status(
    client: BackendClient | None,
    job_id: str | None,
    status: str,
    result: Any = None,
    error: str | None = None,
) -> None:
    """Update job status and result in the backend.

    Silently handles errors to avoid disrupting the main execution flow.
    Only called in JOB mode (entrypoint.py).

    Args:
        client: Backend client instance (may be None).
        job_id: Job ID string (may be None).
        status: Job status (SUCCEEDED, FAILED, etc.).
        result: Action result to store (optional).
        error: Error message for failed jobs (optional).
    """
    if not client or not job_id:
        return

    try:
        update_data: dict[str, Any] = {'status': status}
        if result is not None:
            update_data['result'] = _serialize_result(result)
        if error is not None:
            update_data['result'] = {'error': error}
        client.update_job(job_id, update_data)
    except Exception:
        print(
            f'WARNING: Failed to update job status for job_id={job_id}',
            flush=True,
        )


def main() -> dict[str, Any] | BaseModel:
    """Run a plugin action based on environment configuration.

    Environment Variables:
        SYNAPSE_ACTION_ENTRYPOINT: Module path to action class (e.g., 'mymodule.MyAction')
        SYNAPSE_ACTION_PARAMS: JSON string of action parameters
        SYNAPSE_ACTION_PARAMS_FILE: Alternative: path to JSON file with parameters
        SYNAPSE_JOB_ID: Optional job ID (falls back to RAY_JOB_ID)
        SYNAPSE_LANGUAGE: Optional language code for i18n log messages (ISO 639-1, e.g., 'en', 'ko')

    Returns:
        Action result (dict or Pydantic BaseModel).

    Raises:
        ValueError: If required environment variables are missing.
    """
    _configure_logging()
    _setup_sys_path()

    params = _load_params()
    action_cls = _load_action_class()

    # Create context dependencies
    from synapse_sdk.plugins.context import RuntimeContext
    from synapse_sdk.plugins.context.env import PluginEnvironment
    from synapse_sdk.utils.auth import create_backend_client

    client = create_backend_client()
    job_id = os.environ.get('SYNAPSE_JOB_ID') or os.environ.get('RAY_JOB_ID')
    language = os.environ.get('SYNAPSE_LANGUAGE')
    logger = _create_logger(client, job_id)

    ctx = RuntimeContext(
        logger=logger,
        env=PluginEnvironment.from_environ(),
        job_id=job_id,
        client=client,
        language=language,
    )

    # Execute action with status updates
    try:
        result = action_cls.dispatch(params, ctx)
        logger.finish()

        _update_job_status(client, job_id, 'SUCCEEDED', result=result)
        _output_result(result)
        return result
    except Exception as e:
        logger.finish()
        _update_job_status(client, job_id, 'FAILED', error=str(e))
        raise


if __name__ == '__main__':
    main()
