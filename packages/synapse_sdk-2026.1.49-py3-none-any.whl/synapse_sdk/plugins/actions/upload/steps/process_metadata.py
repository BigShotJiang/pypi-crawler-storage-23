"""Process metadata step for upload workflow."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from synapse_sdk.plugins.actions.upload.context import UploadContext
from synapse_sdk.plugins.actions.upload.enums import LogCode
from synapse_sdk.plugins.actions.upload.log_messages import UploadLogMessageCode
from synapse_sdk.plugins.actions.upload.strategies import (
    CsvMetadataStrategy,
    ExcelMetadataStrategy,
    MetadataStrategy,
)
from synapse_sdk.plugins.steps import BaseStep, StepResult
from synapse_sdk.utils.csv import CsvParsingError, CsvSecurityError
from synapse_sdk.utils.excel import ExcelParsingError, ExcelSecurityError
from synapse_sdk.utils.storage import get_pathlib

# Pattern to extract invalid header from error message
_INVALID_HEADER_PATTERN = re.compile(r'got:\s*"([^"]*)"')


# Supported metadata file types
METADATA_FILE_TYPE_EXCEL = 'excel'
METADATA_FILE_TYPE_CSV = 'csv'


class ProcessMetadataStep(BaseStep[UploadContext]):
    """Process metadata from Excel or CSV files.

    This step handles metadata file processing:
    1. Resolves metadata file path (absolute, storage-relative, or cwd-relative)
    2. Selects appropriate strategy based on file extension (Excel or CSV)
    3. Extracts metadata using the selected strategy
    4. Validates the extracted metadata

    Supported formats:
    - Excel: .xlsx, .xls
    - CSV: .csv

    Progress weight: 0.10 (10%)
    """

    def __init__(self, metadata_strategy: MetadataStrategy | None = None):
        """Initialize with optional metadata strategy.

        Args:
            metadata_strategy: Strategy for metadata extraction.
                If provided, this strategy will be used regardless of file type.
                If not provided, strategy is auto-selected based on file extension.
        """
        self._metadata_strategy = metadata_strategy

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'process_metadata'

    @property
    def progress_weight(self) -> float:
        """Relative progress weight."""
        return 0.10

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (10%)."""
        return 10

    def execute(self, context: UploadContext) -> StepResult:
        """Execute metadata processing step.

        Args:
            context: Upload context with params and storage.

        Returns:
            StepResult with extracted metadata in data.
        """
        context.set_progress(0, 1)
        extracted_metadata: dict[str, dict[str, Any]] = {}

        try:
            metadata_path_param = context.params.get('excel_metadata_path')

            if metadata_path_param:
                # Resolve and process specified metadata file
                metadata_path = self._resolve_metadata_path(metadata_path_param, context)

                if not metadata_path or not metadata_path.exists():
                    context.log(
                        LogCode.EXCEL_FILE_NOT_FOUND_PATH.value,
                        {
                            'path': metadata_path_param,
                        },
                    )
                    return StepResult(
                        success=True,
                        data={'metadata': {}},
                    )

                # Get strategy based on file type
                strategy = self._get_strategy_for_file(metadata_path)
                extracted_metadata = strategy.extract(metadata_path)
            else:
                # Look for default metadata files (single-path mode only)
                if context.pathlib_cwd:
                    metadata_path, file_type = self._find_default_metadata_file(context.pathlib_cwd)
                    if metadata_path:
                        strategy = self._get_strategy_for_type(file_type)
                        extracted_metadata = strategy.extract(metadata_path)
                else:
                    context.log(LogCode.NO_METADATA_STRATEGY.value, {})

            # Validate extracted metadata
            if extracted_metadata:
                # Use the strategy that was used for extraction
                strategy = self._get_strategy_for_file(metadata_path) if metadata_path else ExcelMetadataStrategy()
                validation = strategy.validate(extracted_metadata)
                if not validation.valid:
                    return StepResult(
                        success=False,
                        error=f'Metadata validation failed: {", ".join(validation.errors)}',
                    )

                context.log(
                    LogCode.EXCEL_METADATA_LOADED.value,
                    {
                        'file_count': len(extracted_metadata),
                    },
                )
                context.log_message(UploadLogMessageCode.UPLOAD_METADATA_LOADED, count=len(extracted_metadata))

            # Store in context
            context.excel_metadata = extracted_metadata
            context.set_progress(1, 1)

            return StepResult(
                success=True,
                data={'metadata': extracted_metadata},
                rollback_data={'metadata_processed': len(extracted_metadata) > 0},
            )

        except ExcelSecurityError as e:
            context.log(LogCode.EXCEL_SECURITY_VIOLATION.value, {'error': str(e)})
            return StepResult(
                success=False,
                error=f'Excel security violation: {e}',
            )

        except ExcelParsingError as e:
            error_str = str(e)
            context.log(LogCode.EXCEL_PARSING_ERROR.value, {'error': error_str})

            # Check if this is an invalid header error and notify user
            if 'First column header must be' in error_str:
                match = _INVALID_HEADER_PATTERN.search(error_str)
                header = match.group(1) if match else 'unknown'
                context.log_message(UploadLogMessageCode.UPLOAD_METADATA_INVALID_HEADER, header=header)

            # If path was explicitly specified, it's an error
            if context.params.get('excel_metadata_path'):
                return StepResult(
                    success=False,
                    error=f'Excel parsing error: {e}',
                )
            # Otherwise, just skip with empty metadata
            return StepResult(
                success=True,
                data={'metadata': {}},
            )

        except CsvSecurityError as e:
            context.log(LogCode.CSV_SECURITY_VIOLATION.value, {'error': str(e)})
            return StepResult(
                success=False,
                error=f'CSV security violation: {e}',
            )

        except CsvParsingError as e:
            error_str = str(e)
            context.log(LogCode.CSV_PARSING_ERROR.value, {'error': error_str})

            # Check if this is an invalid header error and notify user
            if 'First column header must be' in error_str:
                match = _INVALID_HEADER_PATTERN.search(error_str)
                header = match.group(1) if match else 'unknown'
                context.log_message(UploadLogMessageCode.UPLOAD_METADATA_INVALID_HEADER, header=header)

            # If path was explicitly specified, it's an error
            if context.params.get('excel_metadata_path'):
                return StepResult(
                    success=False,
                    error=f'CSV parsing error: {e}',
                )
            # Otherwise, just skip with empty metadata
            return StepResult(
                success=True,
                data={'metadata': {}},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Unexpected error processing metadata: {e}',
            )

    def can_skip(self, context: UploadContext) -> bool:
        """Skip if no metadata path and no default file found."""
        if context.params.get('excel_metadata_path'):
            return False
        if context.pathlib_cwd:
            default_path, _ = self._find_default_metadata_file(context.pathlib_cwd)
            return default_path is None
        return True

    def rollback(self, context: UploadContext, result: StepResult) -> None:
        """Rollback metadata processing."""
        context.excel_metadata = None

    def _get_strategy_for_file(self, file_path: Path) -> MetadataStrategy:
        """Get appropriate metadata strategy based on file extension.

        Args:
            file_path: Path to the metadata file.

        Returns:
            MetadataStrategy instance for the file type.
        """
        if self._metadata_strategy:
            return self._metadata_strategy

        suffix = file_path.suffix.lower()
        if suffix == '.csv':
            return CsvMetadataStrategy()
        elif suffix in ('.xlsx', '.xls'):
            return ExcelMetadataStrategy()
        else:
            # Default to Excel for backward compatibility
            return ExcelMetadataStrategy()

    def _get_strategy_for_type(self, file_type: str | None) -> MetadataStrategy:
        """Get appropriate metadata strategy based on file type string.

        Args:
            file_type: Type string ('excel' or 'csv').

        Returns:
            MetadataStrategy instance for the file type.
        """
        if self._metadata_strategy:
            return self._metadata_strategy

        if file_type == METADATA_FILE_TYPE_CSV:
            return CsvMetadataStrategy()
        else:
            return ExcelMetadataStrategy()

    def _resolve_metadata_path(
        self,
        metadata_path_str: str,
        context: UploadContext,
    ) -> Path | None:
        """Resolve metadata file path from string.

        Tries in order:
        1. Absolute path
        2. Relative to storage default path
        3. Relative to working directory (single-path mode)
        """
        # Try absolute path
        path = Path(metadata_path_str)
        if path.exists() and path.is_file():
            return path

        # Try relative to storage
        if context.storage:
            try:
                storage_config = {
                    'provider': context.storage.provider,
                    'configuration': context.storage.configuration,
                }
                storage_path = get_pathlib(storage_config, metadata_path_str)
                if storage_path.exists() and storage_path.is_file():
                    context.log(
                        LogCode.EXCEL_PATH_RESOLVED_STORAGE.value,
                        {
                            'path': str(storage_path),
                        },
                    )
                    return storage_path
            except (FileNotFoundError, PermissionError) as e:
                context.log(
                    LogCode.EXCEL_PATH_RESOLUTION_FAILED.value,
                    {
                        'error_type': type(e).__name__,
                        'error': str(e),
                    },
                )
            except Exception as e:
                context.log(
                    LogCode.EXCEL_PATH_RESOLUTION_ERROR.value,
                    {
                        'error_type': type(e).__name__,
                        'error': str(e),
                    },
                )

        # Try relative to cwd (single-path mode)
        if context.pathlib_cwd:
            path = context.pathlib_cwd / metadata_path_str
            if path.exists() and path.is_file():
                return path

        return None

    def _find_default_metadata_file(self, pathlib_cwd: Path) -> tuple[Path | None, str | None]:
        """Find default metadata file in working directory.

        Searches for metadata files in order of priority:
        1. meta.xlsx (Excel, most common)
        2. meta.xls (Excel, legacy)
        3. meta.csv (CSV)

        Args:
            pathlib_cwd: Working directory path.

        Returns:
            Tuple of (file_path, file_type) where file_type is 'excel' or 'csv'.
            Returns (None, None) if no metadata file is found.
        """
        if not pathlib_cwd:
            return None, None

        # Define search order: xlsx > xls > csv
        search_files = [
            ('meta.xlsx', METADATA_FILE_TYPE_EXCEL),
            ('meta.xls', METADATA_FILE_TYPE_EXCEL),
            ('meta.csv', METADATA_FILE_TYPE_CSV),
        ]

        for filename, file_type in search_files:
            path = pathlib_cwd / filename
            if path.exists():
                return path, file_type

        return None, None
