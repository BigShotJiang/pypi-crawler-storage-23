"""File discovery strategies for upload operations.

Provides strategies for discovering and organizing files:
    - FlatFileDiscoveryStrategy: Non-recursive file discovery
    - RecursiveFileDiscoveryStrategy: Recursive file discovery
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

from synapse_sdk.plugins.actions.upload.strategies.base import FileDiscoveryStrategy

# Pattern to match transformed file stems: original_stem + _digits
# Examples: "0101_0000", "video_000123", "document_0001"
TRANSFORMED_STEM_PATTERN = re.compile(r'^(.+?)_(\d+)$')

# System directories to exclude from file discovery
EXCLUDED_DIRS = frozenset({
    '@eaDir',  # Synology metadata
    '.@__thumb',  # Synology thumbnails
    '@Recycle',  # Synology recycle
    '#recycle',  # SMB recycle
    '.DS_Store',  # macOS
    'Thumbs.db',  # Windows
    '.synology',  # Synology
    '__pycache__',  # Python cache
    '.git',  # Git
})

# Files to exclude from file discovery
EXCLUDED_FILES = frozenset({
    '.DS_Store',
    'Thumbs.db',
    'desktop.ini',
    '.gitkeep',
})


class FlatFileDiscoveryStrategy(FileDiscoveryStrategy):
    """Flat (non-recursive) file discovery strategy.

    Discovers files only in the immediate directory without
    traversing subdirectories.

    Example:
        >>> strategy = FlatFileDiscoveryStrategy()
        >>> files = strategy.discover(Path("/data/images"), recursive=False)
    """

    def discover(self, path: Path, recursive: bool = False) -> list[Path]:
        """Discover files in the given path.

        Args:
            path: Directory path to search.
            recursive: If True, uses recursive search. Default is False.

        Returns:
            List of discovered file paths.
        """
        if recursive:
            return self._discover_recursive(path)
        return self._discover_flat(path)

    def _discover_flat(self, path: Path) -> list[Path]:
        """Discover files non-recursively."""
        if not path.exists() or not path.is_dir():
            return []

        return [
            file_path for file_path in path.glob('*') if file_path.is_file() and file_path.name not in EXCLUDED_FILES
        ]

    def _discover_recursive(self, path: Path) -> list[Path]:
        """Discover files recursively."""
        if not path.exists() or not path.is_dir():
            return []

        def is_excluded(file_path: Path) -> bool:
            """Check if file path contains excluded directories."""
            return any(excluded in file_path.parts for excluded in EXCLUDED_DIRS)

        return [
            file_path
            for file_path in path.rglob('*')
            if file_path.is_file() and not is_excluded(file_path) and file_path.name not in EXCLUDED_FILES
        ]

    def organize(
        self,
        files: list[Path],
        specs: list[dict[str, Any]],
        metadata: dict[str, dict[str, Any]],
        type_dirs: dict[str, Path] | None = None,
    ) -> list[dict[str, Any]]:
        """Organize files according to specifications.

        Uses stem-based grouping to match files with specifications.

        Args:
            files: List of discovered file paths.
            specs: File specifications from data collection.
            metadata: Metadata dictionary keyed by filename.
            type_dirs: Mapping of spec names to directories.

        Returns:
            List of organized file dictionaries.
        """
        if type_dirs is None:
            type_dirs = self._build_type_dirs(files, specs)

        if not type_dirs:
            return []

        # Build metadata index for faster lookups
        metadata_index = self._build_metadata_index(metadata)

        # Group files by dataset key (stem-based)
        dataset_files = self._group_files_by_stem(files, specs, type_dirs)

        # Create organized files from groups with all required files
        return self._create_organized_files(dataset_files, specs, metadata_index)

    def _build_type_dirs(
        self,
        files: list[Path],
        specs: list[dict[str, Any]],
    ) -> dict[str, Path]:
        """Build type directories mapping from file paths and specs."""
        type_dirs: dict[str, Path] = {}

        for spec in specs:
            spec_name = spec.get('name', '')
            if not spec_name:
                continue

            # Find directory containing spec name in file paths
            for file_path in files:
                if spec_name in file_path.parts:
                    spec_index = file_path.parts.index(spec_name)
                    spec_dir = Path(*file_path.parts[: spec_index + 1])
                    if spec_dir.exists() and spec_dir.is_dir():
                        type_dirs[spec_name] = spec_dir
                        break

        return type_dirs

    def _build_metadata_index(
        self,
        metadata: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        """Build metadata index for faster lookups.

        Creates multiple indexes for efficient metadata matching.

        Args:
            metadata: Dictionary of metadata keyed by filename.

        Returns:
            dict[str, dict[str, Any]]: Index dictionary containing:
                - exact_stem: Exact match by file stem.
                - exact_name: Exact match by full filename.
                - origin_stems: For matching transformed files to original stems.
                - partial_paths: Partial path matching as fallback.
        """
        if not metadata:
            return {}

        index: dict[str, dict[str, Any]] = {
            'exact_stem': {},
            'exact_name': {},
            'origin_stems': {},  # For transformed file matching
            'partial_paths': {},
        }

        for meta_key, meta_value in metadata.items():
            meta_path = Path(meta_key)

            # Index by stem
            stem = meta_path.stem
            if stem:
                index['exact_stem'][stem] = meta_value
                # Also index for origin stem matching (used by transformed files)
                index['origin_stems'][stem] = meta_value

            # Index by full name
            name = meta_path.name
            if name:
                index['exact_name'][name] = meta_value

            # Index for partial path matching
            index['partial_paths'][meta_key] = meta_value

        return index

    def _group_files_by_stem(
        self,
        files: list[Path],
        specs: list[dict[str, Any]],
        type_dirs: dict[str, Path],
    ) -> dict[str, dict[str, Path]]:
        """Group files by their stem for data unit creation."""
        dataset_files: dict[str, dict[str, Path]] = {}

        for file_path in files:
            # Find matching spec directory
            matched_spec = self._find_matching_spec(file_path, type_dirs)
            if not matched_spec:
                continue

            spec_name, dir_path, relative_path = matched_spec

            # Create dataset key from relative path and stem
            if relative_path.parent != Path('.'):
                dataset_key = f'{relative_path.parent}_{file_path.stem}'
            else:
                dataset_key = file_path.stem

            # Add to group
            if dataset_key not in dataset_files:
                dataset_files[dataset_key] = {}

            if spec_name not in dataset_files[dataset_key]:
                dataset_files[dataset_key][spec_name] = file_path
            else:
                # Keep the most recent file
                existing = dataset_files[dataset_key][spec_name]
                try:
                    if file_path.stat().st_mtime > existing.stat().st_mtime:
                        dataset_files[dataset_key][spec_name] = file_path
                except (OSError, IOError):
                    pass

        return dataset_files

    def _find_matching_spec(
        self,
        file_path: Path,
        type_dirs: dict[str, Path],
    ) -> tuple[str, Path, Path] | None:
        """Find the matching spec for a file path."""
        matched_specs = []

        for spec_name, dir_path in type_dirs.items():
            try:
                relative_path = file_path.relative_to(dir_path)
                matched_specs.append((spec_name, dir_path, relative_path))
            except ValueError:
                continue

        if not matched_specs:
            return None

        # Return the most specific (deepest) match
        return max(matched_specs, key=lambda x: len(x[1].parts))

    def _create_organized_files(
        self,
        dataset_files: dict[str, dict[str, Path]],
        specs: list[dict[str, Any]],
        metadata_index: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Create organized file entries from grouped files."""
        organized_files = []
        required_specs = [spec['name'] for spec in specs if spec.get('is_required', False)]

        for dataset_key, files_dict in sorted(dataset_files.items()):
            # Check if all required files are present
            has_all_required = all(req in files_dict for req in required_specs)

            if not has_all_required:
                continue

            # Extract file stems and extensions
            file_stems = {}
            file_extensions = {}

            for file_path in files_dict.values():
                stem = file_path.stem
                ext = file_path.suffix.lower()

                if stem:
                    file_stems[stem] = file_stems.get(stem, 0) + 1
                if ext:
                    file_extensions[ext] = file_extensions.get(ext, 0) + 1

            # Use most common stem
            original_stem = max(file_stems, key=file_stems.get) if file_stems else dataset_key
            origin_extension = max(file_extensions, key=file_extensions.get) if file_extensions else ''

            # Build metadata
            meta_data = {
                'origin_file_stem': original_stem,
                'origin_file_extension': origin_extension,
                'created_at': datetime.now().isoformat(),
                'dataset_key': dataset_key,
            }

            # Add matched metadata
            if metadata_index:
                matched = self._find_matching_metadata(original_stem, files_dict, metadata_index)
                if matched:
                    meta_data.update(matched)

            organized_files.append({
                'files': files_dict,
                'meta': meta_data,
            })

        return organized_files

    def _find_matching_metadata(
        self,
        file_stem: str,
        files_dict: dict[str, Path],
        metadata_index: dict[str, Any],
    ) -> dict[str, Any]:
        """Find matching metadata using index lookups.

        Applies matching strategies in order of specificity:
            1. Exact stem match
            2. Exact filename match
            3. Origin stem match (for transformed files like "stem_0001")
            4. Partial path matching

        For origin stem matching, extracts the original stem from transformed
        file names (e.g., "0101_0000" -> "0101") and finds the longest matching
        origin stem to avoid false matches.

        Args:
            file_stem: The file stem to match.
            files_dict: Dictionary of spec names to file paths.
            metadata_index: Pre-built metadata index from _build_metadata_index.

        Returns:
            dict[str, Any]: Matched metadata dict, or empty dict if no match.
        """
        if not metadata_index:
            return {}

        # Strategy 1: Exact stem match
        if file_stem in metadata_index.get('exact_stem', {}):
            return metadata_index['exact_stem'][file_stem]

        # Strategy 2: Exact filename match
        sample_file = next(iter(files_dict.values()), None)
        if sample_file:
            full_filename = f'{file_stem}{sample_file.suffix}'
            if full_filename in metadata_index.get('exact_name', {}):
                return metadata_index['exact_name'][full_filename]

            if sample_file.name in metadata_index.get('exact_name', {}):
                return metadata_index['exact_name'][sample_file.name]

        # Strategy 3: Origin stem match (for transformed files)
        origin_stems = metadata_index.get('origin_stems', {})
        if origin_stems:
            matched_metadata = self._find_origin_stem_metadata(file_stem, origin_stems)
            if matched_metadata:
                return matched_metadata

        # Strategy 4: Partial path matching
        if sample_file:
            file_path_str = str(sample_file)
            file_path_posix = sample_file.as_posix()

            for meta_key, meta_value in metadata_index.get('partial_paths', {}).items():
                if (
                    meta_key in file_path_str
                    or meta_key in file_path_posix
                    or file_path_str in meta_key
                    or file_path_posix in meta_key
                ):
                    return meta_value

        return {}

    def _find_origin_stem_metadata(
        self,
        file_stem: str,
        origin_stems: dict[str, dict[str, Any]],
    ) -> dict[str, Any] | None:
        """Find metadata by matching transformed file stem to origin stem.

        For transformed files (e.g., "document_0001", "video_000123"), extracts
        the original stem and finds matching metadata.

        Uses longest-match-first strategy to avoid false positives:
            - "0101_0000" matches "0101" (not "01" or "010")
            - "010101_0000" matches "010101" (not "0101" or "01")

        Args:
            file_stem: The file stem to match (may be transformed).
            origin_stems: Dictionary of origin stems to metadata.

        Returns:
            dict[str, Any] | None: Matched metadata dict, or None if no match.
        """
        # Check if file_stem looks like a transformed stem (ends with _digits)
        match = TRANSFORMED_STEM_PATTERN.match(file_stem)
        if not match:
            return None

        potential_origin = match.group(1)

        # Find all matching origin stems (those that are prefixes of potential_origin
        # or exactly match potential_origin)
        candidates: list[tuple[str, dict[str, Any]]] = []

        for origin_stem, meta_value in origin_stems.items():
            # Check if origin_stem is an exact match or valid prefix
            if potential_origin == origin_stem:
                # Exact match - highest priority
                return meta_value
            elif potential_origin.startswith(origin_stem + '_'):
                # Could be a nested transformation (rare case)
                # e.g., origin "doc", file "doc_part1_0001"
                candidates.append((origin_stem, meta_value))

        # If we have candidates, return the longest matching stem
        # This ensures "010101" matches before "0101" for "010101_0000"
        if candidates:
            # Sort by stem length (longest first) for most specific match
            candidates.sort(key=lambda x: len(x[0]), reverse=True)
            return candidates[0][1]

        return None


class RecursiveFileDiscoveryStrategy(FlatFileDiscoveryStrategy):
    """Recursive file discovery strategy.

    Extends FlatFileDiscoveryStrategy with recursive search as default.

    Example:
        >>> strategy = RecursiveFileDiscoveryStrategy()
        >>> files = strategy.discover(Path("/data/images"))  # recursive by default
    """

    def discover(self, path: Path, recursive: bool = True) -> list[Path]:
        """Discover files recursively in the given path.

        Args:
            path: Directory path to search.
            recursive: Whether to search recursively. Default is True.

        Returns:
            List of discovered file paths.
        """
        return super().discover(path, recursive=recursive)


def extract_origin_stem(file_stem: str) -> str | None:
    """Extract the original stem from a transformed file stem.

    Transformed files follow the pattern: original_stem + _digits

    Args:
        file_stem: The file stem to extract from.

    Returns:
        str | None: The original stem if the file appears to be transformed,
            None otherwise.

    Examples:
        >>> extract_origin_stem("0101_0000")
        '0101'
        >>> extract_origin_stem("document_0001")
        'document'
        >>> extract_origin_stem("video_000123")
        'video'
        >>> extract_origin_stem("original")
        None
    """
    match = TRANSFORMED_STEM_PATTERN.match(file_stem)
    if match:
        return match.group(1)
    return None


def find_metadata_for_transformed_file(
    file_stem: str,
    metadata: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    """Find metadata for a transformed file by extracting its origin stem.

    This function is useful for transform plugins that need to match metadata
    to transformed files. It extracts the original stem from the file name
    and finds matching metadata.

    Uses longest-match-first strategy to avoid false positives when similar
    stems exist (e.g., "0101" vs "010101").

    Args:
        file_stem: The transformed file's stem (e.g., "0101_0000").
        metadata: Dictionary of metadata keyed by filename or stem.

    Returns:
        dict[str, Any] | None: Matched metadata dict, or None if no match found.

    Examples:
        >>> metadata = {"0101.pdf": {"label": "doc1"}, "010101.pdf": {"label": "doc2"}}
        >>> find_metadata_for_transformed_file("0101_0000", metadata)
        {'label': 'doc1'}
        >>> find_metadata_for_transformed_file("010101_0001", metadata)
        {'label': 'doc2'}
    """
    if not metadata:
        return None

    # First try exact match
    if file_stem in metadata:
        return metadata[file_stem]

    # Build origin stems index
    origin_stems: dict[str, dict[str, Any]] = {}
    for meta_key, meta_value in metadata.items():
        meta_path = Path(meta_key)
        stem = meta_path.stem
        if stem:
            origin_stems[stem] = meta_value

    # Check if this is a transformed stem
    match = TRANSFORMED_STEM_PATTERN.match(file_stem)
    if not match:
        return None

    potential_origin = match.group(1)

    # Find exact match first
    if potential_origin in origin_stems:
        return origin_stems[potential_origin]

    # Find candidates (origin stems that are prefixes)
    candidates: list[tuple[str, dict[str, Any]]] = []
    for origin_stem, meta_value in origin_stems.items():
        if potential_origin.startswith(origin_stem + '_'):
            candidates.append((origin_stem, meta_value))

    # Return longest matching stem
    if candidates:
        candidates.sort(key=lambda x: len(x[0]), reverse=True)
        return candidates[0][1]

    return None


__all__ = [
    'EXCLUDED_DIRS',
    'EXCLUDED_FILES',
    'FlatFileDiscoveryStrategy',
    'RecursiveFileDiscoveryStrategy',
    'TRANSFORMED_STEM_PATTERN',
    'extract_origin_stem',
    'find_metadata_for_transformed_file',
]
