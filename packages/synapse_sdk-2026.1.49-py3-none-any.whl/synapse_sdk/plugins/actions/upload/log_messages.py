"""Upload log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class UploadLogMessageCode(LogMessageCode):
    """Log message codes for upload workflows."""

    UPLOAD_INITIALIZED = ('UPLOAD_INITIALIZED', LogLevel.INFO)
    UPLOAD_METADATA_LOADED = ('UPLOAD_METADATA_LOADED', LogLevel.INFO)
    UPLOAD_METADATA_INVALID_HEADER = ('UPLOAD_METADATA_INVALID_HEADER', LogLevel.ERROR)
    UPLOAD_COLLECTION_ANALYZED = ('UPLOAD_COLLECTION_ANALYZED', LogLevel.INFO)
    UPLOAD_FILES_ORGANIZED = ('UPLOAD_FILES_ORGANIZED', LogLevel.INFO)
    UPLOAD_NO_FILES_FOUND = ('UPLOAD_NO_FILES_FOUND', LogLevel.WARNING)
    UPLOAD_VALIDATION_PASSED = ('UPLOAD_VALIDATION_PASSED', LogLevel.INFO)
    UPLOAD_FILES_UPLOADING = ('UPLOAD_FILES_UPLOADING', LogLevel.INFO)
    UPLOAD_FILES_COMPLETED = ('UPLOAD_FILES_COMPLETED', LogLevel.SUCCESS)
    UPLOAD_FILES_COMPLETED_WITH_FAILURES = ('UPLOAD_FILES_COMPLETED_WITH_FAILURES', LogLevel.WARNING)
    UPLOAD_DATA_UNITS_CREATING = ('UPLOAD_DATA_UNITS_CREATING', LogLevel.INFO)
    UPLOAD_DATA_UNITS_COMPLETED = ('UPLOAD_DATA_UNITS_COMPLETED', LogLevel.SUCCESS)
    UPLOAD_DATA_UNITS_COMPLETED_WITH_FAILURES = ('UPLOAD_DATA_UNITS_COMPLETED_WITH_FAILURES', LogLevel.WARNING)
    UPLOAD_COMPLETED = ('UPLOAD_COMPLETED', LogLevel.SUCCESS)


register_log_messages({
    UploadLogMessageCode.UPLOAD_INITIALIZED: {
        'en': 'Storage and paths initialized',
        'ko': '스토리지 및 경로가 초기화되었습니다',
    },
    UploadLogMessageCode.UPLOAD_METADATA_LOADED: {
        'en': 'Loaded metadata for {count} files',
        'ko': '{count}개 파일의 메타데이터를 로드했습니다',
    },
    UploadLogMessageCode.UPLOAD_METADATA_INVALID_HEADER: {
        'en': 'Invalid metadata file: First column must be "filename" or "file_name", got "{header}"',
        'ko': '유효하지 않은 메타데이터 파일: 첫 번째 열은 "filename" 또는 "file_name"이어야 하는데, "{header}"입니다',
    },
    UploadLogMessageCode.UPLOAD_COLLECTION_ANALYZED: {
        'en': 'Data collection analyzed: {count} file specifications',
        'ko': '데이터 컬렉션 분석 완료: {count}개 파일 명세',
    },
    UploadLogMessageCode.UPLOAD_FILES_ORGANIZED: {
        'en': 'Organized {count} file groups',
        'ko': '{count}개 파일 그룹으로 정리되었습니다',
    },
    UploadLogMessageCode.UPLOAD_NO_FILES_FOUND: {
        'en': 'No files found to organize',
        'ko': '정리할 파일을 찾지 못했습니다',
    },
    UploadLogMessageCode.UPLOAD_VALIDATION_PASSED: {
        'en': 'Validation passed: {count} file groups',
        'ko': '유효성 검사 통과: {count}개 파일 그룹',
    },
    UploadLogMessageCode.UPLOAD_FILES_UPLOADING: {
        'en': 'Uploading {count} files',
        'ko': '{count}개 파일 업로드 중',
    },
    UploadLogMessageCode.UPLOAD_FILES_COMPLETED: {
        'en': 'Upload complete: {success} files uploaded',
        'ko': '업로드 완료: {success}개 파일 업로드됨',
    },
    UploadLogMessageCode.UPLOAD_FILES_COMPLETED_WITH_FAILURES: {
        'en': 'Upload complete: {success} succeeded, {failed} failed',
        'ko': '업로드 완료: {success}개 성공, {failed}개 실패',
    },
    UploadLogMessageCode.UPLOAD_DATA_UNITS_CREATING: {
        'en': 'Creating {count} data units',
        'ko': '{count}개 데이터 유닛 생성 중',
    },
    UploadLogMessageCode.UPLOAD_DATA_UNITS_COMPLETED: {
        'en': '{count} data units created',
        'ko': '{count}개 데이터 유닛이 생성되었습니다',
    },
    UploadLogMessageCode.UPLOAD_DATA_UNITS_COMPLETED_WITH_FAILURES: {
        'en': 'Data units created: {success} succeeded, {failed} failed',
        'ko': '데이터 유닛 생성 완료: {success}개 성공, {failed}개 실패',
    },
    UploadLogMessageCode.UPLOAD_COMPLETED: {
        'en': 'Upload complete: {files} files, {data_units} data units',
        'ko': '업로드 완료: {files}개 파일, {data_units}개 데이터 유닛',
    },
})


__all__ = ['UploadLogMessageCode']
