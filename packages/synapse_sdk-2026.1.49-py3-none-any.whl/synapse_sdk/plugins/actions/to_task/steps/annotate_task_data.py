"""Annotate task data step for to_task workflow."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Iterable

from synapse_sdk.plugins.actions.to_task.action import (
    AnnotateTaskEvent,
    TaskInfo,
    TaskProcessStatus,
    ToTaskMethod,
)
from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.steps import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient
    from synapse_sdk.plugins.actions.to_task.action import ToTaskAction


class AnnotateTaskDataStep(BaseStep[ToTaskContext]):
    """Process and annotate all tasks.

    This step:
    1. Iterates through task IDs
    2. Fetches task data with data_unit
    3. Processes based on method (FILE or INFERENCE)
    4. Tracks success/failure counts
    5. Updates progress per task

    Progress weight:
    - FILE: 0.70 (70%)
    - INFERENCE: 0.60 (60%)
    """

    def __init__(self, action: ToTaskAction, method: ToTaskMethod) -> None:
        """Initialize annotate task data step.

        Args:
            action: Parent ToTaskAction instance (for convert methods).
            method: ToTaskMethod (FILE or INFERENCE).

        Raises:
            TypeError: If action is not a valid ToTaskAction instance or mock.
        """
        # Validate that action has the required convert methods
        if not hasattr(action, 'convert_data_from_file') or not hasattr(action, 'convert_data_from_inference'):
            raise TypeError(
                f'action must be a ToTaskAction instance with convert_data methods, got {type(action).__name__}'
            )

        self._action = action
        self._method = method

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'annotate_task_data'  # Changed from 'process_tasks' for backward compatibility

    @property
    def progress_weight(self) -> float:
        """Relative progress weight based on method."""
        return 0.70 if self._method == ToTaskMethod.FILE else 0.60

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress."""
        return 70 if self._method == ToTaskMethod.FILE else 60

    def execute(self, context: ToTaskContext) -> StepResult:
        """Execute task processing.

        Args:
            context: To-task context with task IDs and configuration.

        Returns:
            StepResult with processing statistics.
        """
        try:
            client: BackendClient | None = context.runtime_ctx.client
            if client is None:
                return StepResult(
                    success=False,
                    error='No backend client in context',
                )

            # Initialize counters
            context.success_count = 0
            context.failed_count = 0
            context.failures = []

            total_tasks = context.total_tasks

            # Log start
            context.log_message(
                ToTaskLogMessageCode.TASK_DATA_ANNOTATING,
                count=total_tasks,
                method=self._method.value,
            )

            # Process each task
            for index, task_id in enumerate(context.task_ids, start=1):
                try:
                    # Fetch task
                    task_data = self._fetch_task(client, task_id)

                    # Process based on method
                    if self._method == ToTaskMethod.FILE:
                        self._process_file_task(client, context, task_id, task_data)
                    else:
                        self._process_inference_task(client, context, task_id, task_data)

                    context.success_count += 1

                    # Log successful task processing
                    event = AnnotateTaskEvent(
                        task_info=TaskInfo(task_id=task_id),
                        status=TaskProcessStatus.SUCCESS.value,
                        method=self._method.value,
                        index=index,
                        total=total_tasks,
                        created=datetime.now(timezone.utc).isoformat(),
                    )
                    context.log(self.name, event.to_dict())

                except Exception as exc:  # noqa: BLE001
                    context.failed_count += 1
                    context.failures.append({
                        'task_id': task_id,
                        'error': str(exc),
                    })

                    # Log failed task processing
                    event = AnnotateTaskEvent(
                        task_info=TaskInfo(task_id=task_id),
                        status=TaskProcessStatus.FAILED.value,
                        method=self._method.value,
                        index=index,
                        total=total_tasks,
                        created=datetime.now(timezone.utc).isoformat(),
                        error=str(exc),
                    )
                    context.log(self.name, event.to_dict())

                    context.runtime_ctx.logger.error(f'Task {task_id} failed: {exc}')

                # Update progress
                context.set_progress(index, total_tasks)
                remaining = max(total_tasks - index, 0)
                # Omit category to use context.current_step automatically ('annotate_task_data')
                context.set_metrics(
                    {
                        'success': context.success_count,
                        'failed': context.failed_count,
                        'stand_by': remaining,
                    },
                )

            return StepResult(
                success=True,
                data={
                    'success_count': context.success_count,
                    'failed_count': context.failed_count,
                },
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to process tasks: {e}',
            )

    def _fetch_task(self, client: BackendClient, task_id: int) -> dict[str, Any]:
        """Fetch task with required fields.

        Args:
            client: Backend client.
            task_id: Task identifier.

        Returns:
            Task payload with data_unit expanded.

        Raises:
            ValueError: If response is not a dict.
        """
        task = client.get_task(
            task_id,
            params={'fields': 'id,data,data_unit', 'expand': 'data_unit'},
        )
        if not isinstance(task, dict):
            raise ValueError('Invalid task response')
        return task

    def _process_file_task(
        self,
        client: BackendClient,
        context: ToTaskContext,
        task_id: int,
        task_data: dict[str, Any],
    ) -> None:
        """Process a task using file-based annotation.

        Args:
            client: Backend client.
            context: To-task context.
            task_id: Task identifier.
            task_data: Task data with data_unit.

        Raises:
            ValueError: If required files are missing.
        """
        # Get task files
        files = self._get_task_files(client, task_data)

        # Extract primary file
        primary_url, primary_name = self._extract_primary_file(files)
        if not primary_url:
            raise ValueError('Primary file URL not found for task')

        # Find target specification file
        target_spec = context.params.get('target_specification_name')
        target_file = self._find_file_by_spec(files, target_spec)
        if not target_file:
            raise ValueError('Target specification file not found for task')

        data_file_url = target_file.get('url')
        if not data_file_url:
            raise ValueError('Target specification URL not found for task')

        data_file_name = self._get_file_name(target_file)

        # Convert data using action's method
        try:
            converted = self._action.convert_data_from_file(
                primary_url,
                primary_name,
                data_file_url,
                data_file_name,
                task_data=task_data,
            )
        except AttributeError as e:
            if "'function' object has no attribute" in str(e):
                raise AttributeError(
                    f'Error in convert_data_from_file: {e}. '
                    f"Make sure you're not trying to access attributes on function objects. "
                    f"If you need to access the action's context, use self.context in your ToTaskAction subclass."
                ) from e
            raise

        # Submit task data
        self._submit_task_data(client, task_id, converted)

    def _process_inference_task(
        self,
        client: BackendClient,
        context: ToTaskContext,
        task_id: int,
        task_data: dict[str, Any],
    ) -> None:
        """Process a task using inference-based annotation.

        Args:
            client: Backend client.
            context: To-task context.
            task_id: Task identifier.
            task_data: Task data with data_unit.

        Raises:
            ValueError: If required files are missing or inference context not set.
        """
        if context.inference is None:
            raise ValueError('Inference context not initialized')

        # Get task files
        files = self._get_task_files(client, task_data)

        # Extract primary file
        primary_url, primary_name = self._extract_primary_file(files)
        if not primary_url:
            raise ValueError('Primary file URL not found for task')

        # Extract non-primary data files
        data_files = self._extract_data_files(files)

        # Run inference
        inference_data = self._run_inference(
            client,
            context,
            primary_url,
            primary_name,
            data_files,
            task_data,
        )

        # Convert data using action's method
        try:
            converted = self._action.convert_data_from_inference(
                inference_data,
                task_data=task_data,
            )
        except AttributeError as e:
            if "'function' object has no attribute" in str(e):
                raise AttributeError(
                    f'Error in convert_data_from_inference: {e}. '
                    f"Make sure you're not trying to access attributes on function objects. "
                    f"If you need to access the action's context, use self.context in your ToTaskAction subclass."
                ) from e
            raise

        # Submit task data
        self._submit_task_data(client, task_id, converted)

    def _run_inference(
        self,
        client: BackendClient,
        context: ToTaskContext,
        primary_file_url: str,
        primary_file_name: str | None,
        data_files: list[dict[str, Any]],
        task_data: dict[str, Any] | None = None,
    ) -> Any:
        """Run inference through pre-processor.

        Args:
            client: Backend client.
            context: To-task context with inference info.
            primary_file_url: URL of primary file to process.
            primary_file_name: Original name of the primary file.
            data_files: Non-primary file info list from _extract_data_files.
            task_data: Optional task payload for additional context.

        Returns:
            Inference result data.

        Raises:
            ValueError: If inference returns no data or inference context not set.
        """
        if context.inference is None:
            raise ValueError('Inference context not initialized')

        # setup_inference_params builds the entire payload['params']
        params = self._action.setup_inference_params(
            primary_file_url,
            primary_file_name,
            data_files,
            model_id=context.params.get('model'),
            pre_processor_params=dict(context.params.get('pre_processor_params', {}) or {}),
            pre_processor_config=context.inference.get('config'),
            task_data=task_data,
        )

        payload = {
            'agent': context.params.get('agent'),
            'action': 'inference',
            'version': context.inference['version'],
            'params': params,
        }

        result = client.run_plugin(context.inference['code'], payload)
        if result is None:
            raise ValueError('Inference returned no data')
        return result

    def _submit_task_data(self, client: BackendClient, task_id: int, data: dict[str, Any]) -> None:
        """Submit converted task data to backend.

        Args:
            client: Backend client.
            task_id: Task identifier.
            data: Converted task data to submit.
        """
        client.annotate_task_data(task_id, data={'action': 'submit', 'data': data})

    def _get_task_files(
        self,
        client: BackendClient,
        task_data: dict[str, Any],
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """Retrieve files from task data unit.

        Args:
            client: Backend client.
            task_data: Task data with data_unit.

        Returns:
            Files dict or list.

        Raises:
            ValueError: If data unit or files are missing.
        """
        data_unit = task_data.get('data_unit')
        if not isinstance(data_unit, dict):
            raise ValueError('Task does not have a data unit')

        files = data_unit.get('files')
        if not files and data_unit.get('id'):
            data_unit = client.get_data_unit(data_unit['id'], params={'expand': 'files'})
            if isinstance(data_unit, dict):
                files = data_unit.get('files')

        if not files:
            raise ValueError('Data unit does not have files')
        return files

    def _extract_primary_file(
        self,
        files: dict[str, Any] | list[dict[str, Any]],
    ) -> tuple[str | None, str | None]:
        """Extract primary file URL and name.

        Args:
            files: Files dict or list from data unit.

        Returns:
            Tuple of (primary_url, primary_name).
        """
        for file_info in self._iter_files(files):
            if file_info.get('is_primary') and file_info.get('url'):
                return file_info.get('url'), self._get_file_name(file_info)
        return None, None

    def _extract_data_files(
        self,
        files: dict[str, Any] | list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Extract non-primary file info for inference.

        Handles both dict-keyed files (key = specification name) and
        list-based files. Does not use _iter_files, because dict keys
        carry the specification name which _iter_files discards.

        Args:
            files: Files dict or list from data unit.

        Returns:
            List of dicts with url, file_name, specification_name for each non-primary file.
        """
        data_files: list[dict[str, Any]] = []
        if isinstance(files, dict):
            for spec_name, file_info in files.items():
                if not isinstance(file_info, dict) or file_info.get('is_primary'):
                    continue
                url = file_info.get('url')
                if url:
                    data_files.append({
                        'url': url,
                        'file_name': self._get_file_name(file_info),
                        'specification_name': spec_name,
                    })
        elif isinstance(files, list):
            for file_info in files:
                if not isinstance(file_info, dict) or file_info.get('is_primary'):
                    continue
                url = file_info.get('url')
                if url:
                    data_files.append({
                        'url': url,
                        'file_name': self._get_file_name(file_info),
                        'specification_name': file_info.get('specification')
                        or file_info.get('specification_name')
                        or file_info.get('name'),
                    })
        return data_files

    def _find_file_by_spec(
        self,
        files: dict[str, Any] | list[dict[str, Any]],
        spec_name: str | None,
    ) -> dict[str, Any] | None:
        """Find file matching specification name.

        Args:
            files: Files dict or list from data unit.
            spec_name: Specification name to find.

        Returns:
            File dict if found, None otherwise.
        """
        if not spec_name:
            return None

        if isinstance(files, dict):
            candidate = files.get(spec_name)
            if isinstance(candidate, dict):
                return candidate

        for file_info in self._iter_files(files):
            for key in ('specification', 'specification_name', 'name'):
                if file_info.get(key) == spec_name:
                    return file_info

        return None

    def _iter_files(self, files: dict[str, Any] | list[dict[str, Any]]) -> Iterable[dict[str, Any]]:
        """Iterate over file dicts.

        Args:
            files: Files dict or list from data unit.

        Yields:
            File info dicts.
        """
        if isinstance(files, dict):
            for value in files.values():
                if isinstance(value, dict):
                    yield value
        elif isinstance(files, list):
            for item in files:
                if isinstance(item, dict):
                    yield item

    def _get_file_name(self, file_info: dict[str, Any]) -> str | None:
        """Extract filename from file info.

        Args:
            file_info: File metadata dict.

        Returns:
            Filename string if found, None otherwise.
        """
        for key in ('file_name_original', 'filename', 'name'):
            value = file_info.get(key)
            if value:
                return str(value)
        return None

    def can_skip(self, context: ToTaskContext) -> bool:
        """Core processing step, never skip.

        Args:
            context: To-task context.

        Returns:
            False (never skip).
        """
        return False

    def rollback(self, context: ToTaskContext, result: StepResult) -> None:
        """No rollback for processing step.

        Args:
            context: To-task context.
            result: Step result with rollback data.
        """
        pass  # Individual failures tracked, no global rollback
