"""Fetch tasks step for to_task workflow."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterable

from synapse_sdk.plugins.actions.to_task.context import ToTaskContext
from synapse_sdk.plugins.actions.to_task.log_messages import ToTaskLogMessageCode
from synapse_sdk.plugins.steps import BaseStep, StepResult

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient


class FetchTasksStep(BaseStep[ToTaskContext]):
    """Fetch task IDs to process.

    This step:
    1. Builds task filter parameters
    2. Calls list_tasks with filters
    3. Extracts task IDs
    4. Validates count > 0

    Progress weight: 0.10 (10%) for both methods
    """

    @property
    def name(self) -> str:
        """Step identifier."""
        return 'fetch_tasks'

    @property
    def progress_weight(self) -> float:
        """Relative progress weight."""
        return 0.10

    @property
    def progress_proportion(self) -> int:
        """Proportion for overall job progress (10%)."""
        return 10

    def execute(self, context: ToTaskContext) -> StepResult:
        """Execute task fetching.

        Args:
            context: To-task context with params and client.

        Returns:
            StepResult with task count info.
        """
        try:
            # Set initial progress
            context.set_progress(0, 100)

            client: BackendClient | None = context.runtime_ctx.client
            if client is None:
                return StepResult(
                    success=False,
                    error='No backend client in context',
                )

            # Build filter parameters
            params = dict(context.params.get('task_filters', {}) or {})
            params['fields'] = 'id'
            params['project'] = context.params.get('project')

            context.set_progress(30, 100)

            # Fetch tasks
            context.log_message(ToTaskLogMessageCode.TASK_FETCHING_TASKS)

            response = client.list_tasks(params=params, list_all=True)
            task_ids, count = self._extract_task_ids_and_count(response)

            context.set_progress(70, 100)

            # Validate count
            if count <= 0:
                return StepResult(
                    success=False,
                    error='No tasks found to annotate',
                )

            # Store in context
            context.task_ids = list(task_ids)

            # Log success
            context.log_message(
                ToTaskLogMessageCode.TASK_TASKS_FETCHED,
                count=count,
            )

            # Set completion progress
            context.set_progress(100, 100)

            return StepResult(
                success=True,
                data={'task_count': count},
                rollback_data={},
            )

        except Exception as e:
            return StepResult(
                success=False,
                error=f'Failed to fetch tasks: {e}',
            )

    def _extract_task_ids_and_count(self, response: Any) -> tuple[Iterable[int], int]:
        """Extract task IDs and count from response.

        Args:
            response: API response from list_tasks.

        Returns:
            Tuple of (task_ids_iterator, total_count).

        Raises:
            ValueError: If response format is unexpected.
        """
        if isinstance(response, tuple):
            items, count = response
            return self._extract_task_ids(items), count

        if isinstance(response, dict):
            results = response.get('results', [])
            count = response.get('count', len(results))
            return self._extract_task_ids(results), count

        if isinstance(response, list):
            return self._extract_task_ids(response), len(response)

        raise ValueError('Unexpected task list response')

    def _extract_task_ids(self, items: Iterable[Any]) -> Iterable[int]:
        """Extract integer task IDs from items.

        Args:
            items: Iterable of task records.

        Yields:
            int: Task ID values.
        """
        for item in items:
            if isinstance(item, dict) and item.get('id') is not None:
                yield int(item['id'])

    def can_skip(self, context: ToTaskContext) -> bool:
        """Can skip if task IDs already fetched.

        Args:
            context: To-task context.

        Returns:
            True if task IDs already in context.
        """
        return len(context.task_ids) > 0

    def rollback(self, context: ToTaskContext, result: StepResult) -> None:
        """Rollback by clearing task IDs.

        Args:
            context: To-task context.
            result: Step result with rollback data.
        """
        context.task_ids = []
        context.runtime_ctx.logger.info('Rolled back: cleared task IDs')
