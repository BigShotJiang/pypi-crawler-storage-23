"""To-task log message codes for user-facing UI messages."""

from __future__ import annotations

from synapse_sdk.plugins.log_messages import LogMessageCode, register_log_messages
from synapse_sdk.plugins.models.logger import LogLevel


class ToTaskLogMessageCode(LogMessageCode):
    """Log message codes for to-task workflows."""

    # Initialization
    TASK_INITIALIZING = ('TASK_INITIALIZING', LogLevel.INFO)
    TASK_DATA_COLLECTION_LOADED = ('TASK_DATA_COLLECTION_LOADED', LogLevel.INFO)

    # Preparation
    TASK_PREPARING_FILE_METHOD = ('TASK_PREPARING_FILE_METHOD', LogLevel.INFO)
    TASK_PREPARING_INFERENCE_METHOD = ('TASK_PREPARING_INFERENCE_METHOD', LogLevel.INFO)
    TASK_SPECIFICATION_VALIDATED = ('TASK_SPECIFICATION_VALIDATED', LogLevel.INFO)
    TASK_INFERENCE_PARAMS_VALIDATING = ('TASK_INFERENCE_PARAMS_VALIDATING', LogLevel.INFO)
    TASK_INFERENCE_PARAMS_VALIDATED = ('TASK_INFERENCE_PARAMS_VALIDATED', LogLevel.INFO)
    TASK_PREPROCESSOR_RELEASE_FETCHING = ('TASK_PREPROCESSOR_RELEASE_FETCHING', LogLevel.INFO)
    TASK_PREPROCESSOR_RELEASE_FETCHED = ('TASK_PREPROCESSOR_RELEASE_FETCHED', LogLevel.INFO)
    TASK_PREPROCESSOR_CHECKING = ('TASK_PREPROCESSOR_CHECKING', LogLevel.INFO)
    TASK_PREPROCESSOR_ALREADY_RUNNING = ('TASK_PREPROCESSOR_ALREADY_RUNNING', LogLevel.INFO)
    TASK_DATA_PREPROCESSOR_DEPLOYING = ('TASK_DATA_PREPROCESSOR_DEPLOYING', LogLevel.WARNING)
    TASK_PREPROCESSOR_WAITING = ('TASK_PREPROCESSOR_WAITING', LogLevel.INFO)
    TASK_PREPROCESSOR_WAITING_PROGRESS = ('TASK_PREPROCESSOR_WAITING_PROGRESS', LogLevel.INFO)
    TASK_PREPROCESSOR_READY = ('TASK_PREPROCESSOR_READY', LogLevel.SUCCESS)
    TASK_INFERENCE_CONTEXT_READY = ('TASK_INFERENCE_CONTEXT_READY', LogLevel.SUCCESS)

    # Fetching
    TASK_FETCHING_TASKS = ('TASK_FETCHING_TASKS', LogLevel.INFO)
    TASK_TASKS_FETCHED = ('TASK_TASKS_FETCHED', LogLevel.INFO)

    # Processing
    TASK_DATA_ANNOTATING = ('TASK_DATA_ANNOTATING', LogLevel.INFO)
    TASK_DATA_COMPLETED = ('TASK_DATA_COMPLETED', LogLevel.SUCCESS)
    TASK_DATA_COMPLETED_WITH_FAILURES = ('TASK_DATA_COMPLETED_WITH_FAILURES', LogLevel.WARNING)

    # Finalization
    TASK_FINALIZING = ('TASK_FINALIZING', LogLevel.INFO)


register_log_messages({
    # Initialization
    ToTaskLogMessageCode.TASK_INITIALIZING: {
        'en': 'Initializing to_task workflow',
        'ko': 'to_task 워크플로우 초기화 중',
    },
    ToTaskLogMessageCode.TASK_DATA_COLLECTION_LOADED: {
        'en': 'Data collection loaded successfully',
        'ko': '데이터 컬렉션이 성공적으로 로드되었습니다',
    },
    # Preparation
    ToTaskLogMessageCode.TASK_PREPARING_FILE_METHOD: {
        'en': 'Preparing file-based annotation',
        'ko': '파일 기반 어노테이션 준비 중',
    },
    ToTaskLogMessageCode.TASK_PREPARING_INFERENCE_METHOD: {
        'en': 'Preparing inference-based annotation',
        'ko': '추론 기반 어노테이션 준비 중',
    },
    ToTaskLogMessageCode.TASK_SPECIFICATION_VALIDATED: {
        'en': 'Target specification validated',
        'ko': '대상 스펙이 검증되었습니다',
    },
    ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATING: {
        'en': 'Validating inference parameters',
        'ko': '추론 파라미터 검증 중',
    },
    ToTaskLogMessageCode.TASK_INFERENCE_PARAMS_VALIDATED: {
        'en': 'Parameters validated: {pre_processor}, {model}',
        'ko': '파라미터 검증 완료: {pre_processor}, {model}',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHING: {
        'en': 'Fetching pre-processor: {pre_processor}',
        'ko': '전처리기 가져오는 중: {pre_processor}',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_RELEASE_FETCHED: {
        'en': 'Release fetched: {plugin_code} v{version}',
        'ko': '릴리스 가져옴: {plugin_code} v{version}',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_CHECKING: {
        'en': 'Checking pre-processor status',
        'ko': '전처리기 상태 확인 중',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_ALREADY_RUNNING: {
        'en': 'Pre-processor already running',
        'ko': '전처리기가 이미 실행 중입니다',
    },
    ToTaskLogMessageCode.TASK_DATA_PREPROCESSOR_DEPLOYING: {
        'en': 'Starting pre-processor deployment',
        'ko': '전처리기 배포 시작',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING: {
        'en': 'Waiting for pre-processor to be ready',
        'ko': '전처리기 준비 대기 중',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_WAITING_PROGRESS: {
        'en': 'Still waiting... ({elapsed_seconds}s elapsed)',
        'ko': '대기 중... ({elapsed_seconds}초 경과)',
    },
    ToTaskLogMessageCode.TASK_PREPROCESSOR_READY: {
        'en': 'Pre-processor is ready',
        'ko': '전처리기가 준비되었습니다',
    },
    ToTaskLogMessageCode.TASK_INFERENCE_CONTEXT_READY: {
        'en': 'Inference context prepared successfully',
        'ko': '추론 컨텍스트가 성공적으로 준비되었습니다',
    },
    # Fetching
    ToTaskLogMessageCode.TASK_FETCHING_TASKS: {
        'en': 'Fetching task list',
        'ko': '작업 목록 가져오는 중',
    },
    ToTaskLogMessageCode.TASK_TASKS_FETCHED: {
        'en': 'Fetched {count} tasks for annotation',
        'ko': '어노테이션 대상 {count}개 작업을 가져왔습니다',
    },
    # Processing
    ToTaskLogMessageCode.TASK_DATA_ANNOTATING: {
        'en': 'Annotating {count} tasks ({method} method)',
        'ko': '{count}개 작업 어노테이션 중 ({method} 방식)',
    },
    ToTaskLogMessageCode.TASK_DATA_COMPLETED: {
        'en': 'Annotation complete: {count} tasks annotated',
        'ko': '어노테이션 완료: {count}개 작업 처리됨',
    },
    ToTaskLogMessageCode.TASK_DATA_COMPLETED_WITH_FAILURES: {
        'en': 'Annotation complete: {success} succeeded, {failed} failed',
        'ko': '어노테이션 완료: {success}개 성공, {failed}개 실패',
    },
    # Finalization
    ToTaskLogMessageCode.TASK_FINALIZING: {
        'en': 'Finalizing annotation results',
        'ko': '어노테이션 결과 마무리 중',
    },
})


__all__ = ['ToTaskLogMessageCode']
