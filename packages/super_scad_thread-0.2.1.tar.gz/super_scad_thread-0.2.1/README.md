# SuperSCAD: Thread

SuperSCAD widgets for threads.

<table>
<thead>
<tr>
<th>Legal</th>
<th>Release</th>
<th>Code</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<a href="https://pypi.org/project/Super-SCAD-Thread/" target="_blank"><img alt="PyPI - License" src="https://img.shields.io/pypi/l/Super-SCAD-Thread">
</a>
</td>
<td>
<a href="https://badge.fury.io/py/Super-SCAD-Thread" target="_blank"><img src="https://badge.fury.io/py/Super-SCAD-Thread.svg" alt="Latest Stable Version"/></a><br/>
</td>
<td>
<a href="https://codecov.io/gh/SuperSCAD/Thread" target="_blank"><img src="https://codecov.io/gh/SuperSCAD/Thread/graph/badge.svg?token=7D8V8RRY11" alt="Code Coverage"/></a>
<a href="https://github.com/SuperSCAD/Thread/actions/workflows/unit.yml"><img src="https://github.com/SuperSCAD/Thread/actions/workflows/unit.yml/badge.svg" alt="unit Tests"/></a>
</td>
</tr>
</tbody>
</table>

# License

This project is licensed under the terms of the [MIT license](LICENSE).

