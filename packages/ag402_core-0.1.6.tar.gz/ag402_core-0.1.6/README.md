# ag402-core

Payment engine for AI Agents — automatic HTTP 402 payment with Solana USDC.
