# Code of Conduct

## 1. Our Commitment

We are committed to providing a welcoming, inclusive, and respectful environment for all contributors and participants in the Veramem project.

Veramem is an open, scientific, and collaborative effort.  
We value diversity of thought, background, and expertise, and we believe that respectful discourse is essential for building trustworthy and resilient systems.

---

## 2. Expected Behavior

All participants are expected to:

- Be respectful and constructive in discussions.
- Focus on ideas, evidence, and technical reasoning.
- Communicate clearly and professionally.
- Welcome new contributors and diverse perspectives.
- Provide and accept feedback in good faith.
- Acknowledge uncertainty and complexity in scientific and technical debates.

This includes all project spaces:

- GitHub issues and pull requests
- Discussions and mailing lists
- Conferences, workshops, and public events
- Community platforms and chat channels

---

## 3. Unacceptable Behavior

The following behaviors are not tolerated:

- Harassment, discrimination, or intimidation.
- Personal attacks or insults.
- Threats or abusive language.
- Trolling or deliberate disruption.
- Publishing private or sensitive information without consent.
- Any form of exclusion based on:
  - race,
  - ethnicity,
  - nationality,
  - gender,
  - sexual orientation,
  - disability,
  - religion,
  - or other protected characteristics.

Scientific or technical disagreement is acceptable and encouraged, but must remain professional and respectful.

---

## 4. Scientific and Technical Integrity

Because Veramem is a research-oriented and security-critical system, we expect:

- Honest reporting of results.
- Transparent methodology.
- Clear disclosure of assumptions.
- Responsible communication of vulnerabilities.
- Respect for peer review and verification.

Misrepresentation of research or security findings is considered a serious violation.

---

## 5. Collaboration Principles

We aim to foster:

- Open and rigorous debate.
- Evidence-based reasoning.
- Long-term trust and reliability.
- Interdisciplinary collaboration.
- Global participation.

We encourage contributions from:

- researchers,
- engineers,
- cryptographers,
- distributed systems experts,
- privacy and security practitioners.

---

## 6. Reporting Violations

If you experience or witness unacceptable behavior, please report it:

- Email: jlefauconnier@proton.me
- Subject: `[VERAMEM CONDUCT]`

All reports will be:

- handled confidentially,
- investigated fairly,
- treated with respect and care.

---

## 7. Enforcement

Project maintainers are responsible for enforcing this code of conduct.

Possible actions include:

- Warning.
- Temporary or permanent ban.
- Removal of contributions.
- Restriction of participation in project spaces.

Decisions will be made based on:

- severity,
- context,
- repeated behavior.

---

## 8. Scope

This code applies to:

- official project spaces,
- events and collaborations,
- interactions representing the project.

---

## 9. Acknowledgment

By participating in Veramem, you agree to uphold this Code of Conduct.

We are committed to building a community grounded in:

- respect,
- integrity,
- scientific rigor,
- and long-term trust.

---

## 10. Inspiration

This Code of Conduct is inspired by widely adopted open-source and research community standards, including those used by major foundations and scientific organizations.
