# veramem_kernel/signals/canonical/specs/__init__.py
# Empty init — specs are imported explicitly