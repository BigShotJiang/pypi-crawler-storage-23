# veramem_kernel/signals/canonical/specs/memory_long.py

"""
Canonical Signal Specifications — Memory Long Domain
Version 1.1.7 — Placeholder for future extraction
"""

from veramem_kernel.signals.canonical.canonical_signal_registry import CanonicalSignalRegistry


def register_memory_long_signals() -> None:
    """Register Memory Long projected signals (currently in timeline specs)."""
    # For now, handled in timeline specs
    pass