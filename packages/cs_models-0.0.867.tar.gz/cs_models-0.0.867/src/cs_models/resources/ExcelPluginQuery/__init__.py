"""ExcelPluginQuery resource."""
