"""FastAPI service layer for dna-rag."""
