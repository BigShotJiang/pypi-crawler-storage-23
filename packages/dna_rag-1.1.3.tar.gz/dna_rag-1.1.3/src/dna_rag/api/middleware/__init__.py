"""API middleware (auth, rate-limit, request-id)."""
