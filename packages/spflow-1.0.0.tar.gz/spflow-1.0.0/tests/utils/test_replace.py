"""Unit tests for method replacement context manager."""

from typing import Optional

import numpy as np
import pytest
import torch
from torch import nn

from spflow.meta import Scope
from spflow.modules.module import Module
from spflow.utils.cache import Cache, cached
from spflow.utils.replace import replace
from spflow.modules.module_shape import ModuleShape
from spflow.modules.module_shape import ModuleShape


class MockModule(Module):
    """Simple mock module for testing replace functionality."""

    def __init__(self, name: str = "mock"):
        super().__init__()
        self._scope = Scope([0])
        self.name = name
        self.call_count = 0
        self._out_shape = ModuleShape(1, 1, 1)

    @property
    def feature_to_scope(self) -> np.ndarray:
        """Return list of scopes per feature."""
        return np.array([Scope([0])]).view(-1, 1)

    @cached
    def log_likelihood(self, data, cache: Optional[Cache] = None):
        """Mock log_likelihood method with caching."""
        self.call_count += 1
        return torch.tensor([1.0, 2.0, 3.0])

    def sample(self, num_samples=None, data=None, is_mpe=False, cache=None):
        """Mock sample method."""
        return torch.randn(num_samples or 1, 1)

    def _sample(self, data, sampling_ctx, cache):
        del sampling_ctx
        del cache
        return data

    def marginalize(self, marg_rvs, prune=True, cache=None):
        """Mock marginalize method."""
        return None

    def non_cached_method(self):
        """Method without @cached decorator."""
        return "original"


class StubModule(Module):
    """Stub module with configurable output for testing replace() with different module types."""

    def __init__(self, scope: Scope, out_channels: int = 1):
        super().__init__()
        self._scope = scope
        self._out_channels_val = out_channels
        self._out_shape = ModuleShape(len(self._scope.query), self._out_channels_val, 1)

    @property
    def feature_to_scope(self) -> np.ndarray:
        """Return scopes for each feature."""
        scopes = [[Scope([rv])] for rv in self._scope.query]
        return np.array(scopes)

    def log_likelihood(self, data, cache: Optional[Cache] = None):
        """Return fake log-likelihood with appropriate shape."""
        batch_size = data.shape[0]
        # Baseline zeros make replacement outputs easy to detect in assertions.
        return torch.zeros(batch_size, self.out_shape.channels, 1)

    def sample(self, num_samples=None, data=None, is_mpe=False, cache=None):
        """Return fake samples."""
        return torch.randn(num_samples or 1, len(self._scope.query))

    def _sample(self, data, sampling_ctx, cache):
        del sampling_ctx
        del cache
        return data

    def marginalize(self, marg_rvs, prune=True, cache=None):
        """Return marginalized version."""
        return self


class StubProduct(StubModule):
    """Stub product module that accepts inputs."""

    def __init__(self, inputs, out_channels: int = 1):
        if isinstance(inputs, list):
            scope = inputs[0]._scope
        else:
            scope = inputs._scope
        super().__init__(scope, out_channels)
        if isinstance(inputs, list):
            self.inputs = nn.ModuleList(inputs)
        else:
            self.inputs = inputs

    def log_likelihood(self, data, cache: Optional[Cache] = None):
        """Call input's log_likelihood and return combined result."""
        if isinstance(self.inputs, nn.ModuleList):
            return self.inputs[0].log_likelihood(data, cache)
        else:
            return self.inputs.log_likelihood(data, cache)


class StubSum(StubModule):
    """Stub sum module that accepts inputs."""

    def __init__(self, inputs, out_channels: int = 1):
        if isinstance(inputs, list):
            scope = inputs[0]._scope
        else:
            scope = inputs._scope
        super().__init__(scope, out_channels)
        if isinstance(inputs, list):
            self.inputs = nn.ModuleList(inputs)
        else:
            self.inputs = inputs

    def log_likelihood(self, data, cache: Optional[Cache] = None):
        """Call input's log_likelihood and return result."""
        if isinstance(self.inputs, nn.ModuleList):
            return self.inputs[0].log_likelihood(data, cache)
        else:
            return self.inputs.log_likelihood(data, cache)


class StubCat(StubModule):
    """Stub concatenation module that accepts list of inputs."""

    def __init__(self, inputs, dim: int = 0):
        # Mirror Cat semantics so hierarchy tests keep realistic scopes.
        all_query = set()
        for inp in inputs:
            all_query.update(inp._scope.query)
        scope = Scope(sorted(all_query))
        out_channels = sum(inp.out_shape.channels for inp in inputs)
        super().__init__(scope, out_channels)
        self.inputs = nn.ModuleList(inputs)

    def log_likelihood(self, data, cache: Optional[Cache] = None):
        """Call all inputs' log_likelihood and aggregate results."""
        results = []
        for inp in self.inputs:
            results.append(inp.log_likelihood(data, cache))
        # Preserve per-input identity so tests can observe both branches.
        return torch.stack(results, dim=1)


class TestBasicReplacement:
    """Tests for basic method replacement."""

    def test_replace_undecorated_method(self):
        """Test replacing a method without @cached decorator."""

        def custom_method(self):
            return "custom"

        mock = MockModule()

        # Verify context manager fully restores patched methods on exit.
        assert mock.non_cached_method() == "original"

        with replace(MockModule.non_cached_method, custom_method):
            assert mock.non_cached_method() == "custom"

        assert mock.non_cached_method() == "original"

    def test_replace_cached_method(self):
        """Test replacing a @cached decorated method."""

        def custom_ll(self, data, cache=None):
            return torch.tensor([4.0, 5.0, 6.0])

        mock = MockModule()

        # Baseline proves the test is not accidentally using custom output already.
        result_before = mock.log_likelihood(torch.tensor([1.0]))
        assert torch.equal(result_before, torch.tensor([1.0, 2.0, 3.0]))

        with replace(MockModule.log_likelihood, custom_ll):
            result_custom = mock.log_likelihood(torch.tensor([1.0]))
            assert torch.equal(result_custom, torch.tensor([4.0, 5.0, 6.0]))

        result_after = mock.log_likelihood(torch.tensor([1.0]))
        assert torch.equal(result_after, torch.tensor([1.0, 2.0, 3.0]))

    def test_replacement_affects_all_instances(self):
        """Test that class-level replacement affects all instances."""

        def custom_ll(self, data, cache=None):
            return torch.tensor([7.0, 8.0, 9.0])

        mock1 = MockModule("mock1")
        mock2 = MockModule("mock2")

        # Replacement is class-level, so both instances must move together.
        result1_before = mock1.log_likelihood(torch.tensor([1.0]))
        result2_before = mock2.log_likelihood(torch.tensor([1.0]))
        assert torch.equal(result1_before, torch.tensor([1.0, 2.0, 3.0]))
        assert torch.equal(result2_before, torch.tensor([1.0, 2.0, 3.0]))

        with replace(MockModule.log_likelihood, custom_ll):
            result1_custom = mock1.log_likelihood(torch.tensor([1.0]))
            result2_custom = mock2.log_likelihood(torch.tensor([1.0]))
            assert torch.equal(result1_custom, torch.tensor([7.0, 8.0, 9.0]))
            assert torch.equal(result2_custom, torch.tensor([7.0, 8.0, 9.0]))


class TestCachingBehavior:
    """Tests for caching with replacement."""

    def test_replacement_preserves_caching(self):
        """Test that replaced cached method still uses caching."""

        call_count = 0

        def custom_ll(self, data, cache=None):
            nonlocal call_count
            call_count += 1
            return torch.tensor([10.0])

        cache = Cache()
        mock = MockModule()

        with replace(MockModule.log_likelihood, custom_ll):
            # First call warms cache; second call confirms wrapper remains cache-aware.
            result1 = mock.log_likelihood(torch.tensor([1.0]), cache=cache)
            assert call_count == 1

            result2 = mock.log_likelihood(torch.tensor([1.0]), cache=cache)
            assert call_count == 1
            assert result1 is result2

    def test_cache_key_with_replacement(self):
        """Test that cache keys work correctly with replaced methods."""

        def custom_ll(self, data, cache=None):
            return torch.tensor([11.0])

        cache = Cache()
        mock = MockModule()

        with replace(MockModule.log_likelihood, custom_ll):
            result1 = mock.log_likelihood(torch.tensor([1.0]), cache=cache)

            # Identity check guards that cache key generation is unchanged by replacement.
            result2 = mock.log_likelihood(torch.tensor([1.0]), cache=cache)

            assert result1 is result2
            assert torch.equal(result1, torch.tensor([11.0]))


class TestRestorationAndCleanup:
    """Tests for proper restoration of original methods."""

    def test_original_restored_on_normal_exit(self):
        """Test that original method is restored after context exit."""

        def custom_method(self):
            return "custom"

        mock = MockModule()

        # Exercise no-op body: restoration must not depend on method invocation.
        with replace(MockModule.non_cached_method, custom_method):
            pass

        assert mock.non_cached_method() == "original"

    def test_original_restored_on_exception(self):
        """Test that original method is restored even when exception occurs."""

        def custom_method(self):
            return "custom"

        mock = MockModule()

        with pytest.raises(ValueError):
            with replace(MockModule.non_cached_method, custom_method):
                assert mock.non_cached_method() == "custom"
                raise ValueError("Test exception")

        # Exception safety is the main contract of the context manager.
        assert mock.non_cached_method() == "original"

    def test_multiple_sequential_replacements(self):
        """Test sequential replacements work correctly."""

        def custom1(self):
            return "custom1"

        def custom2(self):
            return "custom2"

        mock = MockModule()

        # Sequential contexts should not leak previous replacements.
        with replace(MockModule.non_cached_method, custom1):
            assert mock.non_cached_method() == "custom1"

        with replace(MockModule.non_cached_method, custom2):
            assert mock.non_cached_method() == "custom2"

        assert mock.non_cached_method() == "original"


class TestErrorHandling:
    """Tests for error handling in replace()."""

    def test_invalid_method_reference_non_callable(self):
        """Test error when passing non-callable as method reference."""
        with pytest.raises(TypeError):
            with replace("not_a_method", lambda self: None):
                pass

    def test_invalid_method_reference_no_name(self):
        """Test error when method reference has no __name__."""

        # Use callable object to hit the branch where __name__ metadata is missing.
        class NoName:
            def __call__(self):
                pass

        obj = NoName()
        # Keep setup robust if runtime injects __name__ dynamically.
        if hasattr(obj, "__name__"):
            delattr(obj, "__name__")

        with pytest.raises(TypeError):
            with replace(obj, lambda self: None):
                pass

    def test_invalid_method_reference_no_qualname(self):
        """Test error when method reference has no __qualname__."""

        def func():
            pass

        # This branch is intentionally hard to reach on real functions.
        if hasattr(func, "__qualname__"):
            # Document intent without mutating interpreter-level function metadata.
            pass


class TestIntegrationWithModuleStubs:
    """Integration tests with stub modules to verify replace() works across module hierarchies."""

    def test_replace_sum_log_likelihood(self):
        """Test replacing log_likelihood on Sum module."""
        # Small hierarchy keeps assertions focused on replacement behavior.
        scope = Scope([0, 1])
        stub = StubModule(scope=scope, out_channels=2)
        sum_module = StubSum(inputs=stub, out_channels=2)

        def custom_ll(self, data, cache=None):
            # Distinct output confirms the patched implementation is active.
            batch_size = data.shape[0]
            return torch.ones(batch_size, 2, 1)

        data = torch.randn(3, 2)

        # Preserve baseline to verify full restoration after context exit.
        original_result = sum_module.log_likelihood(data)
        original_shape = original_result.shape
        assert original_shape[0] == 3

        with replace(StubSum.log_likelihood, custom_ll):
            custom_result = sum_module.log_likelihood(data)
            assert custom_result.shape[0] == 3
            assert torch.equal(custom_result, torch.ones(3, 2, 1))

        restored_result = sum_module.log_likelihood(data)
        assert torch.equal(restored_result, original_result)

    def test_replace_in_nested_structure(self):
        """Test replacement works in a nested structure with multiple module types."""
        scope = Scope([0, 1])
        stub = StubModule(scope=scope, out_channels=2)
        sum_module = StubSum(inputs=stub, out_channels=2)
        product_module = StubProduct(inputs=sum_module)

        call_count = 0

        def custom_sum_ll(self, data, cache=None):
            nonlocal call_count
            call_count += 1
            # Keep shape valid so failures point to replacement dispatch, not broadcasting.
            batch_size = data.shape[0]
            return torch.ones(batch_size, 2, 1)

        data = torch.randn(2, 2)

        # Baseline comparison ensures the patched path actually changes behavior.
        original_result = product_module.log_likelihood(data)

        with replace(StubSum.log_likelihood, custom_sum_ll):
            custom_result = product_module.log_likelihood(data)
            assert call_count == 1

        assert not torch.equal(custom_result, original_result)

    def test_replace_multiple_instances_same_class(self):
        """Test that replacement affects all instances of a class in a hierarchy."""
        scope1 = Scope([0, 1])
        scope2 = Scope([2, 3])

        # Two Sum instances verify class-level patching across sibling branches.
        stub1 = StubModule(scope=scope1, out_channels=2)
        sum1 = StubSum(inputs=stub1, out_channels=2)

        stub2 = StubModule(scope=scope2, out_channels=2)
        sum2 = StubSum(inputs=stub2, out_channels=2)

        # Cat forces traversal through both children in one forward pass.
        combined = StubCat(inputs=[sum1, sum2], dim=1)

        call_count = 0

        def custom_ll(self, data, cache=None):
            nonlocal call_count
            call_count += 1
            # Shape compatibility keeps this a dispatch test rather than shape test.
            batch_size = data.shape[0]
            return torch.zeros(batch_size, 2, 1)

        data = torch.randn(2, 4)

        with replace(StubSum.log_likelihood, custom_ll):
            combined.log_likelihood(data)
            assert call_count == 2


class TestEdgeCases:
    """Tests for edge cases and special scenarios."""

    def test_replacement_with_different_signature(self):
        """Test that custom function can have different implementation details."""

        def custom_ll(self, data, cache=None):
            # Branching here proves custom logic can diverge from original implementation.
            if data.shape[0] > 1:
                return torch.tensor([100.0])
            else:
                return torch.tensor([200.0])

        mock = MockModule()

        with replace(MockModule.log_likelihood, custom_ll):
            result1 = mock.log_likelihood(torch.randn(1, 2))
            result2 = mock.log_likelihood(torch.randn(2, 2))

            assert torch.equal(result1, torch.tensor([200.0]))
            assert torch.equal(result2, torch.tensor([100.0]))

    def test_replacement_modifying_self_state(self):
        """Test that replacement can modify module state."""

        def custom_ll(self, data, cache=None):
            self.call_count += 10  # Modify state
            return torch.tensor([50.0])

        mock = MockModule()
        assert mock.call_count == 0

        with replace(MockModule.log_likelihood, custom_ll):
            mock.log_likelihood(torch.tensor([1.0]))
            assert mock.call_count == 10

        # replace() restores methods only; it must not roll back side effects on state.
        assert mock.call_count == 10

    def test_empty_context(self):
        """Test that empty replace context works (no calls to method)."""

        def custom_method(self):
            return "custom"

        mock = MockModule()

        # Ensure context enter/exit itself is safe when patched method is unused.
        with replace(MockModule.non_cached_method, custom_method):
            pass

        assert mock.non_cached_method() == "original"
