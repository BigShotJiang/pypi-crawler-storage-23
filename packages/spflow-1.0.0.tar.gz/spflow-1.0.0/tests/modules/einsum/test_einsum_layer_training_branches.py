"""Training and branch coverage tests for EinsumLayer."""

from itertools import product

import pytest
import torch

from spflow.exceptions import MissingCacheError
from spflow.learn import expectation_maximization
from spflow.meta import Scope
from spflow.modules.einsum import EinsumLayer
from spflow.modules.ops.split import SplitMode
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import SamplingContext, to_one_hot
from tests.modules.einsum.layer_test_utils import make_einsum_single_input, make_einsum_two_inputs
from tests.utils.leaves import CachingDummyInput, DummyLeaf, make_leaf, make_normal_data, make_normal_leaf


class TestEinsumLayerEMTwoInputs:
    def make_einsum_with_caching_inputs(
        self, in_channels: int, out_channels: int, in_features: int, num_reps: int
    ) -> EinsumLayer:
        left_scope = Scope(list(range(0, in_features)))
        right_scope = Scope(list(range(in_features, in_features * 2)))

        left_input = CachingDummyInput(
            out_channels=in_channels,
            num_repetitions=num_reps,
            out_features=in_features,
            scope=left_scope,
        )
        right_input = CachingDummyInput(
            out_channels=in_channels,
            num_repetitions=num_reps,
            out_features=in_features,
            scope=right_scope,
        )

        return EinsumLayer(
            inputs=[left_input, right_input], out_channels=out_channels, num_repetitions=num_reps
        )

    @pytest.mark.parametrize(
        "in_channels,out_channels,in_features,num_reps",
        product([2], [3], [4], [1, 2]),
    )
    def test_em_updates_weights_two_inputs(
        self, in_channels: int, out_channels: int, in_features: int, num_reps: int
    ):
        module = self.make_einsum_with_caching_inputs(in_channels, out_channels, in_features, num_reps)
        total_features = in_features * 2
        data = torch.randn(50, total_features)

        original_weights = module.weights.clone()

        ll_history = expectation_maximization(module, data, max_steps=5)

        # Use exact inequality so we catch no-op EM updates, not just tiny floating drift.
        assert not torch.allclose(module.weights, original_weights, rtol=0.0, atol=0.0)
        assert len(ll_history) >= 1
        assert torch.isfinite(ll_history).all()

    @pytest.mark.parametrize(
        "in_channels,out_channels,in_features,num_reps",
        product([2], [3], [4], [1, 2]),
    )
    def test_em_weights_normalized_two_inputs(
        self, in_channels: int, out_channels: int, in_features: int, num_reps: int
    ):
        module = self.make_einsum_with_caching_inputs(in_channels, out_channels, in_features, num_reps)
        total_features = in_features * 2
        data = torch.randn(50, total_features)

        expectation_maximization(module, data, max_steps=3)

        weights = module.weights
        # Einsum normalizes over both parent-channel axes per (feature, out_channel, repetition).
        sums = weights.sum(dim=(-2, -1))
        torch.testing.assert_close(sums, torch.ones_like(sums), rtol=1e-5, atol=1e-5)

    def test_em_two_inputs_asymmetric_channels(self):
        left_scope = Scope([0, 1])
        right_scope = Scope([2, 3])

        left_input = CachingDummyInput(out_channels=2, num_repetitions=1, out_features=2, scope=left_scope)
        right_input = CachingDummyInput(out_channels=3, num_repetitions=1, out_features=2, scope=right_scope)

        module = EinsumLayer(inputs=[left_input, right_input], out_channels=4, num_repetitions=1)
        data = torch.randn(50, 4)

        original_weights = module.weights.clone()

        ll_history = expectation_maximization(module, data, max_steps=3)

        # Regression guard: asymmetric channel support is Einsum-specific and must train end-to-end.
        assert not torch.allclose(module.weights, original_weights, rtol=0.0, atol=0.0)
        assert module.weights.shape == (2, 4, 1, 2, 3)

    def test_em_raises_without_cache(self):
        module = self.make_einsum_with_caching_inputs(2, 3, 4, 1)
        data = torch.randn(10, 8)
        cache = Cache()

        with pytest.raises(ValueError):
            module._expectation_maximization_step(data, cache=cache)


class TestEinsumLayerCoverageBranches:
    def test_invalid_input_list_length_raises(self):
        leaf = make_normal_leaf(out_features=4, out_channels=2, num_repetitions=1)
        with pytest.raises(ValueError):
            EinsumLayer(inputs=[leaf], out_channels=2)

    def test_invalid_two_inputs_feature_mismatch_raises(self):
        left = make_leaf(cls=DummyLeaf, out_channels=2, scope=Scope([0, 1]), num_repetitions=1)
        right = make_leaf(cls=DummyLeaf, out_channels=2, scope=Scope([2, 3, 4]), num_repetitions=1)
        with pytest.raises(ValueError):
            EinsumLayer(inputs=[left, right], out_channels=2)

    def test_invalid_two_inputs_repetition_mismatch_raises(self):
        left = make_leaf(cls=DummyLeaf, out_channels=2, scope=Scope([0, 1]), num_repetitions=1)
        right = make_leaf(cls=DummyLeaf, out_channels=2, scope=Scope([2, 3]), num_repetitions=2)
        with pytest.raises(ValueError):
            EinsumLayer(inputs=[left, right], out_channels=2)

    def test_invalid_out_channels_raises(self):
        inputs = make_normal_leaf(out_features=4, out_channels=2, num_repetitions=1)
        with pytest.raises(ValueError):
            EinsumLayer(inputs=inputs, out_channels=0)

    def test_invalid_init_weight_shape_raises(self):
        inputs = make_normal_leaf(out_features=4, out_channels=2, num_repetitions=1)
        with pytest.raises(ValueError):
            EinsumLayer(inputs=inputs, out_channels=3, weights=torch.rand(1, 2, 3))

    def test_set_non_positive_weights_raises(self):
        module = make_einsum_single_input(2, 3, 4, 1)
        invalid = module.weights.clone()
        invalid[0, 0, 0, 0, 0] = 0.0
        invalid[0, 0, 0, 0, 1] = 1.0
        invalid[0, 0, 0, 1, 0] = 1e-8
        invalid[0, 0, 0, 1, 1] = 1e-8
        invalid = invalid / invalid.sum(dim=(-2, -1), keepdim=True)
        with pytest.raises(ValueError):
            module.weights = invalid

    def test_set_invalid_log_weights_shape_raises(self):
        module = make_einsum_single_input(2, 3, 4, 1)
        with pytest.raises(ValueError):
            module.log_weights = torch.zeros(1, 2, 3)

    def test_feature_to_scope_single_input(self):
        module = make_einsum_single_input(2, 3, 4, 1)
        mapping = module.feature_to_scope
        assert mapping.shape == (2, 1)
        assert set(mapping[0, 0].query) == {0, 1}
        assert set(mapping[1, 0].query) == {2, 3}

    def test_feature_to_scope_two_inputs(self):
        module = make_einsum_two_inputs(2, 3, 2, 1)
        mapping = module.feature_to_scope
        assert mapping.shape == (2, 1)
        assert set(mapping[0, 0].query) == {0, 2}
        assert set(mapping[1, 0].query) == {1, 3}

    def test_sample_two_inputs_uses_cached_log_likelihoods(self):
        module = make_einsum_two_inputs(2, 3, 4, 2)
        batch_size = 8
        data = torch.full((batch_size, 8), torch.nan)
        channel_index = torch.randint(0, module.out_shape.channels, (batch_size, module.out_shape.features))
        mask = torch.ones((batch_size, module.out_shape.features), dtype=torch.bool)
        repetition_index = torch.randint(0, module.out_shape.repetitions, (batch_size,))
        sampling_ctx = SamplingContext(
            channel_index=channel_index,
            mask=mask,
            repetition_index=repetition_index,
            is_mpe=True,
        )

        left_ll = torch.randn(
            batch_size, module.out_shape.features, module._left_channels, module.out_shape.repetitions
        )
        right_ll = torch.randn(
            batch_size, module.out_shape.features, module._right_channels, module.out_shape.repetitions
        )
        cache = Cache()
        cache["log_likelihood"][module.inputs[0]] = left_ll
        cache["log_likelihood"][module.inputs[1]] = right_ll

        samples = module._sample(data=data, cache=cache, sampling_ctx=sampling_ctx)
        assert samples.shape == data.shape
        assert torch.isfinite(samples[:, module.scope.query]).all()

    def test_sample_two_inputs_uses_cached_log_likelihoods_differentiable(self):
        module = make_einsum_two_inputs(2, 3, 4, 2)
        batch_size = 8
        data = torch.full((batch_size, 8), torch.nan)
        channel_index = torch.randint(0, module.out_shape.channels, (batch_size, module.out_shape.features))
        repetition_index = torch.randint(0, module.out_shape.repetitions, (batch_size,))
        sampling_ctx = SamplingContext(
            channel_index=to_one_hot(channel_index, dim=-1, dim_size=module.out_shape.channels),
            mask=torch.ones((batch_size, module.out_shape.features), dtype=torch.bool),
            repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=module.out_shape.repetitions),
            is_differentiable=True,
        )

        left_ll = torch.randn(
            batch_size, module.out_shape.features, module._left_channels, module.out_shape.repetitions
        )
        right_ll = torch.randn(
            batch_size, module.out_shape.features, module._right_channels, module.out_shape.repetitions
        )
        cache = Cache()
        cache["log_likelihood"][module.inputs[0]] = left_ll
        cache["log_likelihood"][module.inputs[1]] = right_ll

        samples = module._sample(data=data, cache=cache, sampling_ctx=sampling_ctx)
        assert samples.shape == data.shape
        assert torch.isfinite(samples[:, module.scope.query]).all()

    def test_expectation_maximization_requires_cached_module_ll(self):
        module = make_einsum_single_input(2, 3, 4, 1)
        data = make_normal_data(out_features=4, num_samples=6)
        cache = Cache()
        # The EM step consumes this module's cached responsibilities from the E-step.
        with pytest.raises(MissingCacheError):
            module._expectation_maximization_step(data, cache=cache)

    def test_mle_is_unavailable(self):
        module = make_einsum_single_input(2, 3, 4, 1)
        data = make_normal_data(out_features=4, num_samples=4)
        with pytest.raises(AttributeError):
            module.maximum_likelihood_estimation(data, bias_correction=False)

    def test_marginalize_two_inputs_branch_outcomes(self, monkeypatch):
        module = make_einsum_two_inputs(2, 3, 4, 1)
        # Exercise all branch outcomes: both dropped, right-only, left-only, and full rebuild.
        monkeypatch.setattr(module.inputs[0], "marginalize", lambda *args, **kwargs: None)
        monkeypatch.setattr(module.inputs[1], "marginalize", lambda *args, **kwargs: None)
        assert module.marginalize([0]) is None

        module = make_einsum_two_inputs(2, 3, 4, 1)
        right_keep = module.inputs[1]
        monkeypatch.setattr(module.inputs[0], "marginalize", lambda *args, **kwargs: None)
        monkeypatch.setattr(module.inputs[1], "marginalize", lambda *args, **kwargs: right_keep)
        assert module.marginalize([0]) is right_keep

        module = make_einsum_two_inputs(2, 3, 4, 1)
        left_keep = module.inputs[0]
        monkeypatch.setattr(module.inputs[0], "marginalize", lambda *args, **kwargs: left_keep)
        monkeypatch.setattr(module.inputs[1], "marginalize", lambda *args, **kwargs: None)
        assert module.marginalize([0]) is left_keep

        module = make_einsum_two_inputs(2, 3, 4, 1)
        monkeypatch.setattr(module.inputs[0], "marginalize", lambda *args, **kwargs: module.inputs[0])
        monkeypatch.setattr(module.inputs[1], "marginalize", lambda *args, **kwargs: module.inputs[1])
        rebuilt = module.marginalize([0])
        assert isinstance(rebuilt, EinsumLayer)
        assert rebuilt._two_inputs

    def test_marginalize_single_input_branch_outcomes(self, monkeypatch):
        module = make_einsum_single_input(2, 3, 4, 1)
        monkeypatch.setattr(module.inputs.inputs, "marginalize", lambda *args, **kwargs: None)
        assert module.marginalize([0]) is None

        module = make_einsum_single_input(2, 3, 4, 1)
        small_input = make_normal_leaf(out_features=1, out_channels=2, num_repetitions=1)
        monkeypatch.setattr(module.inputs.inputs, "marginalize", lambda *args, **kwargs: small_input)
        assert module.marginalize([0]) is small_input

        module = make_einsum_single_input(2, 3, 6, 1)
        even_input = make_normal_leaf(out_features=4, out_channels=2, num_repetitions=1)
        monkeypatch.setattr(module.inputs.inputs, "marginalize", lambda *args, **kwargs: even_input)
        rebuilt = module.marginalize([0])
        assert isinstance(rebuilt, EinsumLayer)

    def test_split_mode_factory_path_is_used(self):
        leaf = make_normal_leaf(out_features=4, out_channels=2, num_repetitions=1)
        module = EinsumLayer(inputs=leaf, out_channels=3, split_mode=SplitMode.interleaved(num_splits=2))
        from spflow.modules.ops.split_interleaved import SplitInterleaved

        assert isinstance(module.inputs, SplitInterleaved)
