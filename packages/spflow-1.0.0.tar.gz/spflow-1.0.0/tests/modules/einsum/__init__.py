"""Tests for einsum module."""
