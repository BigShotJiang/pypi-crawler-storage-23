import numpy as np
import pytest
import torch

from spflow.exceptions import InvalidParameterCombinationError
from spflow.meta import Scope
from spflow.modules.module import Module
from spflow.modules.sums.repetition_mixing_layer import RepetitionMixingLayer
from spflow.modules.module_shape import ModuleShape


class DummyInput(Module):
    """Minimal input module to drive MixingLayer behavior."""

    def __init__(self, out_channels: int = 2, num_repetitions: int = 2, out_features: int = 1):
        super().__init__()
        self.scope = Scope(list(range(out_features)))
        # Explicit Scope objects let delegation assertions fail clearly on regressions.
        self._feature_to_scope = np.array([[Scope(i)] for i in range(out_features)], dtype=object)
        self._in_shape = ModuleShape(out_features, 1, 1)
        self._out_shape = ModuleShape(out_features, out_channels, num_repetitions)

    @property
    def feature_to_scope(self):
        return self._feature_to_scope

    @property
    def out_features(self) -> int:
        return self._out_features

    @property
    def out_channels(self) -> int:
        return self._out_channels

    def log_likelihood(self, data, cache=None):
        batch = data.shape[0]
        # Keep canonical axis order so failures point to the layer, not this fixture.
        return torch.zeros(
            batch, self.out_shape.features, self.out_shape.channels, self.out_shape.repetitions
        )

    def sample(self, *args, **kwargs):
        data = kwargs.get("data")
        if data is None:
            data = torch.full((1, len(self.scope.query)), torch.nan)
        data[:, self.scope.query] = 0.0
        return data

    def _sample(self, data: torch.Tensor, sampling_ctx, cache):
        del sampling_ctx
        del cache
        data[:, self.scope.query] = 0.0
        return data

    def expectation_maximization(self, data, cache=None):
        return None

    def maximum_likelihood_estimation(self, data, weights=None, cache=None):
        return None

    def marginalize(self, marg_rvs, prune=True, cache=None):
        return self


def test_mixing_layer_initialization_validates():
    inputs = DummyInput(out_channels=2, num_repetitions=2)
    layer = RepetitionMixingLayer(inputs=inputs, out_channels=2, num_repetitions=2)

    assert layer.out_shape.channels == 2
    assert layer.out_shape.features == 1
    assert layer.out_shape.repetitions == 2


def test_mixing_layer_rejects_out_channel_mismatch():
    inputs = DummyInput(out_channels=2, num_repetitions=1)
    with pytest.raises(ValueError):
        RepetitionMixingLayer(inputs=inputs, out_channels=3, num_repetitions=1)


def test_mixing_layer_log_likelihood_shape():
    inputs = DummyInput(out_channels=2, num_repetitions=2)
    layer = RepetitionMixingLayer(inputs=inputs, out_channels=2, num_repetitions=2)
    data = torch.randn(4, 1)

    ll = layer.log_likelihood(data)

    assert ll.shape == (data.shape[0], layer.out_shape.features, layer.out_shape.channels, 1)
    assert torch.isfinite(ll).all()


def test_mixing_layer_sample_uses_cached_posterior():
    inputs = DummyInput(out_channels=1, num_repetitions=1)
    layer = RepetitionMixingLayer(inputs=inputs, out_channels=1, num_repetitions=1)
    data = torch.full((1, 1), torch.nan)

    cache = {"log_likelihood": {inputs: torch.zeros(1, 1, 1, 1)}}

    sampled = layer.sample(data=data, cache=cache)

    assert sampled.shape == data.shape
    assert torch.isfinite(sampled).all()


def test_mixing_layer_rejects_missing_inputs():
    with pytest.raises(ValueError):
        RepetitionMixingLayer(inputs=None, out_channels=1, num_repetitions=1)  # type: ignore[arg-type]


def test_mixing_layer_rejects_nonpositive_out_channels():
    inputs = DummyInput(out_channels=1, num_repetitions=1)
    with pytest.raises(ValueError):
        RepetitionMixingLayer(inputs=inputs, out_channels=0, num_repetitions=1)


def test_mixing_layer_supports_multiple_features():
    inputs = DummyInput(out_channels=1, num_repetitions=1, out_features=2)
    layer = RepetitionMixingLayer(inputs=inputs, out_channels=1, num_repetitions=1)

    data = torch.randn(3, inputs.out_shape.features)
    ll = layer.log_likelihood(data)

    assert layer.out_shape.features == inputs.out_shape.features
    assert ll.shape == (data.shape[0], inputs.out_shape.features, layer.out_shape.channels, 1)


def test_mixing_layer_conflicting_weights_and_out_channels():
    inputs = DummyInput(out_channels=1, num_repetitions=1)
    weights = torch.ones((1, 1, 1))
    with pytest.raises(InvalidParameterCombinationError):
        RepetitionMixingLayer(inputs=inputs, out_channels=2, num_repetitions=1, weights=weights)


def test_mixing_layer_feature_to_scope():
    """Test feature_to_scope delegates correctly to input module."""
    inputs = DummyInput(out_channels=2, num_repetitions=2, out_features=1)
    layer = RepetitionMixingLayer(inputs=inputs, out_channels=2, num_repetitions=2)

    feature_scopes = layer.feature_to_scope
    input_scopes = inputs.feature_to_scope

    # Repetition mixing should not change which variables each feature represents.
    assert np.array_equal(feature_scopes, input_scopes)
    assert feature_scopes.shape == (1, 1)

    assert isinstance(feature_scopes[0, 0], Scope)
    assert feature_scopes[0, 0] == Scope(0)


def test_mixing_layer_feature_to_scope_various_channels():
    """Test feature_to_scope with different channel configurations."""
    for out_channels in [1, 2, 5]:
        inputs = DummyInput(out_channels=out_channels, num_repetitions=2, out_features=1)
        layer = RepetitionMixingLayer(inputs=inputs, out_channels=out_channels, num_repetitions=2)

        feature_scopes = layer.feature_to_scope
        input_scopes = inputs.feature_to_scope

        assert np.array_equal(feature_scopes, input_scopes)
        assert feature_scopes.shape == (1, 1)

        assert isinstance(feature_scopes[0, 0], Scope)
        assert feature_scopes[0, 0] == Scope(0)


def test_mixing_layer_feature_to_scope_various_repetitions():
    """Test feature_to_scope works with different num_repetitions."""
    for num_reps in [1, 2, 5]:
        inputs = DummyInput(out_channels=2, num_repetitions=num_reps, out_features=1)
        layer = RepetitionMixingLayer(inputs=inputs, out_channels=2, num_repetitions=num_reps)

        feature_scopes = layer.feature_to_scope

        # Changing repetition count must not alter scope metadata.
        assert np.array_equal(feature_scopes, inputs.feature_to_scope)
        assert feature_scopes.shape == (1, 1)

        assert isinstance(feature_scopes[0, 0], Scope)
