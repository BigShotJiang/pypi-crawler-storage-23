import numpy as np
import pytest
import torch

from spflow.exceptions import ShapeError
from spflow.meta import Scope
from spflow.modules.ops import SplitConsecutive
from spflow.modules.ops import SplitInterleaved
from spflow.modules.products import ElementwiseProduct
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import SamplingContext, to_one_hot
from tests.utils.leaves import make_normal_leaf, make_normal_data


@pytest.mark.parametrize("num_repetitions", [1, 5])
def test_split_result(num_repetitions: int):
    out_channels = 10
    num_features = 6
    scope = Scope(list(range(0, num_features)))

    scope_1 = Scope(list(range(0, num_features))[0::2])
    scope_2 = Scope(list(range(0, num_features))[1::2])
    mean = torch.randn(num_features, out_channels, num_repetitions)
    mean_1 = mean[0::2]
    mean_2 = mean[1::2]
    std = torch.rand(num_features, out_channels, num_repetitions)
    std_1 = std[0::2]
    std_2 = std[1::2]
    leaf = make_normal_leaf(scope=scope, mean=mean, std=std)
    leaf_half_1 = make_normal_leaf(scope=scope_1, mean=mean_1, std=std_1)
    leaf_half_2 = make_normal_leaf(scope=scope_2, mean=mean_2, std=std_2)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)
    # Equivalent manual construction verifies even/odd routing semantics directly.
    spn1 = ElementwiseProduct(inputs=split)
    spn2 = ElementwiseProduct(inputs=[leaf_half_1, leaf_half_2])
    assert spn1.out_shape.channels == spn2.out_shape.channels
    assert spn1.out_shape.features == spn2.out_shape.features
    data = make_normal_data(out_features=num_features)
    ll_1 = spn1.log_likelihood(data)
    ll_2 = spn2.log_likelihood(data)
    torch.testing.assert_close(ll_1, ll_2, rtol=1e-5, atol=1e-6)


def test_split_alternate_extra_repr():
    """Test string representation of SplitInterleaved."""
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    repr_str = split.extra_repr()
    assert isinstance(repr_str, str)
    assert "dim=1" in repr_str


def test_split_alternate_feature_mapping():
    """Test feature_to_scope mapping delegates to input."""
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    feature_scopes = split.feature_to_scope

    # Exact mapping equality protects downstream modules that index by RV identity.
    assert feature_scopes.shape == (3, 2, 1)

    assert np.array_equal(
        feature_scopes,
        np.array([[Scope(0), Scope(2), Scope(4)], [Scope(1), Scope(3), Scope(5)]]).reshape(3, 2, 1),
    )

    assert all(isinstance(scope_obj, Scope) for scope_obj in feature_scopes.flatten())


def test_split_alternate_num_splits_one():
    """Test with num_splits=1 (edge case - all features in one group)."""
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=1, dim=1)

    data = make_normal_data(out_features=6)
    lls = split.log_likelihood(data)

    assert len(lls) == 1
    assert lls[0].shape == (data.shape[0], 6, 3, 1)


def test_split_alternate_num_splits_two():
    """Test optimized path for num_splits=2."""
    scope = Scope(list(range(0, 8)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=8)
    lls = split.log_likelihood(data)

    assert len(lls) == 2
    # Explicit sizes pin the even/odd partition contract for alternating splits.
    assert lls[0].shape == (data.shape[0], 4, 2, 1)
    assert lls[1].shape == (data.shape[0], 4, 2, 1)


def test_split_alternate_num_splits_three():
    """Test optimized path for num_splits=3."""
    scope = Scope(list(range(0, 9)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=3, dim=1)

    data = make_normal_data(out_features=9)
    lls = split.log_likelihood(data)

    assert len(lls) == 3
    for ll in lls:
        assert ll.shape == (data.shape[0], 3, 2, 1)


def test_split_alternate_num_splits_four():
    """Test general path for num_splits=4 (uses split_masks)."""
    scope = Scope(list(range(0, 12)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=4, dim=1)

    data = make_normal_data(out_features=12)
    lls = split.log_likelihood(data)

    assert len(lls) == 4
    for ll in lls:
        assert ll.shape == (data.shape[0], 3, 2, 1)


def test_split_alternate_consistency():
    """Test output shapes and values are consistent."""
    scope = Scope(list(range(0, 10)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=2)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=10)
    lls1 = split.log_likelihood(data)
    lls2 = split.log_likelihood(data)

    # Determinism here catches accidental stateful behavior inside split kernels.
    assert len(lls1) == len(lls2)
    for ll1, ll2 in zip(lls1, lls2):
        torch.testing.assert_close(ll1, ll2, rtol=0.0, atol=0.0)


def test_split_alternate_sampling():
    """Test sampling works correctly with alternating splits."""
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=2)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    n_samples = 20
    data = torch.full((n_samples, 6), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, 6))
    mask = torch.ones((n_samples, 6), dtype=torch.bool)
    rep_index = torch.randint(0, 2, size=(n_samples,))
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=rep_index)
    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())

    assert samples.shape == (n_samples, 6)
    assert torch.isfinite(samples).all()


def test_split_alternate_sampling_accepts_split_sized_context():
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    n_samples = 12
    data = torch.full((n_samples, 6), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, 3))
    mask = torch.ones((n_samples, 3), dtype=torch.bool)
    sampling_ctx = SamplingContext(
        channel_index=channel_index,
        mask=mask,
        repetition_index=torch.zeros(n_samples, dtype=torch.long),
    )
    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert samples.shape == (n_samples, 6)
    assert torch.isfinite(samples).all()


def test_split_alternate_sampling_accepts_split_sized_context_differentiable():
    scope = Scope(list(range(0, 6)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    n_samples = 10
    data = torch.full((n_samples, 6), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, 3))
    sampling_ctx = SamplingContext(
        channel_index=to_one_hot(channel_index, dim=-1, dim_size=3),
        mask=torch.ones((n_samples, 3), dtype=torch.bool),
        repetition_index=to_one_hot(torch.zeros((n_samples,), dtype=torch.long), dim=-1, dim_size=1),
        is_differentiable=True,
    )
    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert samples.shape == (n_samples, 6)
    assert torch.isfinite(samples).all()


def test_split_alternate_differentiable_equals_non_diff_sampling():
    scope = Scope(list(range(0, 6)))
    mean = torch.arange(6 * 3, dtype=torch.get_default_dtype()).reshape(6, 3, 1)
    std = torch.full_like(mean, 1e-6)
    leaf = make_normal_leaf(scope=scope, mean=mean, std=std)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    n_samples = 12
    channel_index = torch.randint(0, 3, size=(n_samples, 3))
    mask = torch.ones((n_samples, 3), dtype=torch.bool)
    repetition_index = torch.zeros((n_samples,), dtype=torch.long)
    sampling_ctx_a = SamplingContext(
        channel_index=channel_index.clone(),
        mask=mask.clone(),
        repetition_index=repetition_index.clone(),
    )
    sampling_ctx_b = SamplingContext(
        channel_index=to_one_hot(channel_index, dim=-1, dim_size=3),
        mask=mask.clone(),
        repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=1),
        is_differentiable=True,
    )

    samples_a = split._sample(
        data=torch.full((n_samples, 6), torch.nan),
        sampling_ctx=sampling_ctx_a,
        cache=Cache(),
    )
    samples_b = split._sample(
        data=torch.full((n_samples, 6), torch.nan),
        sampling_ctx=sampling_ctx_b,
        cache=Cache(),
    )

    # Differentiable one-hot routing should be numerically equivalent to integer routing.
    torch.testing.assert_close(samples_a, samples_b, rtol=0.0, atol=1e-4)


def test_split_alternate_sampling_rejects_incompatible_split_sized_context_internal_context():
    scope = Scope(list(range(0, 5)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)
    data = torch.full((4, 5), torch.nan)
    sampling_ctx = SamplingContext(
        channel_index=torch.randint(0, 2, size=(4, 2)),
        mask=torch.ones((4, 2), dtype=torch.bool),
        repetition_index=torch.zeros(4, dtype=torch.long),
    )

    with pytest.raises(ShapeError, match="not divisible by num_splits"):
        split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())


@pytest.mark.parametrize("num_features", [5, 7, 11])
def test_split_alternate_uneven_features(num_features):
    """Test alternating split with features that don't divide evenly."""
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=num_features)
    lls = split.log_likelihood(data)

    assert len(lls) == 2
    # Ceiling/floor balance is the key invariant for odd feature counts.
    expected_size_0 = (num_features + 1) // 2  # Ceiling division
    expected_size_1 = num_features // 2  # Floor division
    assert lls[0].shape[1] == expected_size_0
    assert lls[1].shape[1] == expected_size_1


def test_split_alternate_masks_correctness():
    """Test that split_masks are constructed correctly."""
    scope = Scope(list(range(0, 8)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    assert len(split.split_masks) == 2
    mask_0 = split.split_masks[0]
    mask_1 = split.split_masks[1]

    # Disjoint + full coverage is required for lossless recomposition after splitting.
    assert mask_0.sum() == 4
    assert mask_1.sum() == 4

    assert (mask_0 & mask_1).sum() == 0
    assert (mask_0 | mask_1).sum() == 8
