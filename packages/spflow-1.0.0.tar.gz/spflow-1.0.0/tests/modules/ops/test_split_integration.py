"""Integration tests for split operations.

Tests interactions between different split types and with other modules.
"""

import pytest
import torch

from spflow.meta import Scope
from spflow.modules.ops import SplitInterleaved, SplitConsecutive
from spflow.modules.products import ElementwiseProduct, OuterProduct
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import SamplingContext
from tests.utils.leaves import make_normal_leaf, make_normal_data


def test_split_operations_log_likelihood_consistency():
    """Test log_likelihood consistent across split types with products."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    out_channels = 3
    num_repetitions = 2

    # Shared parameters isolate split strategy effects from leaf randomness.
    mean = torch.randn(num_features, out_channels, num_repetitions)
    std = torch.rand(num_features, out_channels, num_repetitions) + 0.1

    leaf1 = make_normal_leaf(scope, mean=mean, std=std)
    leaf2 = make_normal_leaf(scope, mean=mean, std=std)

    split_consecutive = SplitConsecutive(inputs=leaf1, num_splits=2, dim=1)
    split_interleaved = SplitInterleaved(inputs=leaf2, num_splits=2, dim=1)

    prod1 = ElementwiseProduct(inputs=split_consecutive)
    prod2 = ElementwiseProduct(inputs=split_interleaved)

    data = make_normal_data(out_features=num_features)

    ll1 = prod1.log_likelihood(data)
    ll2 = prod2.log_likelihood(data)

    assert ll1.shape == ll2.shape
    assert torch.isfinite(ll1).all()
    assert torch.isfinite(ll2).all()


def test_split_operations_sampling():
    """Test sampling from split operations."""
    num_features = 8
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=2)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    n_samples = 50
    data = torch.full((n_samples, num_features), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, num_features))
    mask = torch.ones((n_samples, num_features), dtype=torch.bool)
    rep_index = torch.randint(0, 2, size=(n_samples,))
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=rep_index)
    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())

    assert samples.shape == (n_samples, num_features)
    assert torch.isfinite(samples).all()
    # Nonzero variance catches degenerate broadcasting/fill bugs.
    assert samples.std() > 0


def test_split_operations_gradients():
    """Test gradients flow through split operations."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    # Product node gives a compact scalar objective for backprop wiring checks.
    prod = ElementwiseProduct(inputs=split)

    data = make_normal_data(out_features=num_features)
    ll = prod.log_likelihood(data)

    loss = ll.sum()

    loss.backward()

    for param in leaf.parameters():
        if param.requires_grad:
            assert param.grad is not None


def test_split_operations_batched():
    """Test split operations with batched inputs."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitInterleaved(inputs=leaf, num_splits=3, dim=1)

    batch_sizes = [1, 10, 50]

    for batch_size in batch_sizes:
        data = make_normal_data(num_samples=batch_size, out_features=num_features)
        lls = split.log_likelihood(data)

        assert len(lls) == 3
        for ll in lls:
            assert ll.shape[0] == batch_size


def test_split_operations_with_products():
    """Test split operations work correctly with products."""
    num_features = 12
    scope1 = Scope(list(range(0, 6)))
    scope2 = Scope(list(range(6, 12)))

    leaf1 = make_normal_leaf(scope1, out_channels=3, num_repetitions=1)
    leaf2 = make_normal_leaf(scope2, out_channels=3, num_repetitions=1)

    # Separate scopes avoid confounding split internals with product broadcasting quirks.
    prod = ElementwiseProduct(inputs=[leaf1, leaf2])

    data = make_normal_data(out_features=num_features)
    ll = prod.log_likelihood(data)

    assert torch.isfinite(ll).all()
    assert ll.shape[0] == data.shape[0]


def test_split_with_outer_product():
    """Test split operations with OuterProduct."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    outer_prod = OuterProduct(inputs=split)

    data = make_normal_data(out_features=num_features)
    ll = outer_prod.log_likelihood(data)

    assert torch.isfinite(ll).all()
    # Channel expansion verifies compatibility with combinatorial product semantics.
    assert outer_prod.out_shape.channels > split.out_shape.channels


def test_split_alternating_pattern_verification():
    """Verify alternating split pattern is correct."""
    num_features = 8
    scope = Scope(list(range(0, num_features)))

    # Monotonic means make feature-order mistakes easy to spot during debugging.
    mean = torch.arange(num_features).float().reshape(num_features, 1, 1)
    std = torch.ones(num_features, 1, 1) * 0.1

    leaf = make_normal_leaf(scope, mean=mean, std=std)
    split = SplitInterleaved(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=num_features)
    lls = split.log_likelihood(data)

    # Explicit partition sizes guard the even/odd routing contract.
    assert lls[0].shape[1] == 4
    assert lls[1].shape[1] == 4


def test_split_consecutive_pattern_verification():
    """Verify halves split pattern is correct."""
    num_features = 8
    scope = Scope(list(range(0, num_features)))

    mean = torch.arange(num_features).float().reshape(num_features, 1, 1)
    std = torch.ones(num_features, 1, 1) * 0.1

    leaf = make_normal_leaf(scope, mean=mean, std=std)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=num_features)
    lls = split.log_likelihood(data)

    # Half-and-half widths encode the intended consecutive partition behavior.
    assert lls[0].shape[1] == 4
    assert lls[1].shape[1] == 4


@pytest.mark.parametrize("split_type", [SplitConsecutive, SplitInterleaved])
def test_split_sampling_mpe_mode(split_type):
    """Test sampling in MPE (Most Probable Explanation) mode."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=2)
    split = split_type(inputs=leaf, num_splits=2, dim=1)

    n_samples = 20
    data = torch.full((n_samples, num_features), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, num_features))
    mask = torch.ones((n_samples, num_features), dtype=torch.bool)
    rep_index = torch.randint(0, 2, size=(n_samples,))
    sampling_ctx = SamplingContext(
        channel_index=channel_index,
        mask=mask,
        repetition_index=rep_index,
        is_mpe=True,
    )

    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())

    assert samples.shape == (n_samples, num_features)
    assert torch.isfinite(samples).all()


def test_split_consistent_results():
    """Test that splits produce consistent results across multiple calls."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    data = make_normal_data(out_features=num_features)

    # Determinism is important for reproducible structure-level debugging.
    lls1 = split.log_likelihood(data)
    lls2 = split.log_likelihood(data)

    assert len(lls1) == len(lls2)
    for ll1, ll2 in zip(lls1, lls2):
        torch.testing.assert_close(ll1, ll2, rtol=0.0, atol=0.0)


@pytest.mark.parametrize("num_splits", [2, 3, 4])
def test_split_different_num_splits(num_splits):
    """Test splits work with different number of splits."""
    num_features = num_splits * 3  # Ensure even division
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)

    split_consecutive = SplitConsecutive(inputs=leaf, num_splits=num_splits, dim=1)
    split_alt = SplitInterleaved(inputs=leaf, num_splits=num_splits, dim=1)

    data = make_normal_data(out_features=num_features)

    lls_halves = split_consecutive.log_likelihood(data)
    lls_alt = split_alt.log_likelihood(data)

    assert len(lls_halves) == num_splits
    assert len(lls_alt) == num_splits


def test_split_scope_inheritance():
    """Test scope is correctly inherited from input."""
    scope = Scope(list(range(0, 8)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    # Scope inheritance is a hard requirement for correct variable bookkeeping.
    assert split.scope == leaf.scope
    assert len(split.scope.query) == 8

    data = make_normal_data(out_features=8)
    lls = split.log_likelihood(data)
    assert len(lls) >= 1


def test_split_with_partial_mask_sampling():
    """Test sampling with partial masking."""
    num_features = 6
    scope = Scope(list(range(0, num_features)))
    leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
    split = SplitConsecutive(inputs=leaf, num_splits=2, dim=1)

    n_samples = 10
    data = torch.full((n_samples, num_features), torch.nan)
    channel_index = torch.randint(0, 3, size=(n_samples, num_features))
    mask = torch.ones((n_samples, num_features), dtype=torch.bool)
    mask[:, ::2] = False
    rep_index = torch.zeros(n_samples, dtype=torch.long)
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=rep_index)
    samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert torch.isnan(samples[:, ::2]).any()
    assert torch.isfinite(samples[:, 1::2]).all()
