"""Tests for SplitByIndex module."""

from itertools import product

import pytest
import torch

from spflow.meta import Scope
from spflow.modules.ops import SplitByIndex, SplitMode
from spflow.modules.products import ElementwiseProduct, OuterProduct
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import SamplingContext, to_one_hot
from tests.utils.leaves import make_normal_leaf, make_normal_data
from tests.utils.sampling_context_helpers import assert_nonzero_finite_grad, make_diff_routing_from_logits


class TestSplitByIndexBasic:
    """Basic tests for SplitByIndex functionality."""

    def test_create_split_by_index(self):
        """Test basic SplitByIndex creation."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])

        assert split.num_splits == 2
        assert split.indices == [[0, 1, 2], [3, 4, 5]]
        assert split.scope == leaf.scope

    def test_uneven_splits(self):
        """Test SplitByIndex with uneven split sizes."""
        scope = Scope(list(range(0, 8)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        # Uneven groups are common in hand-crafted structures and must validate cleanly.
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3, 4], [5, 6, 7]])

        assert split.num_splits == 3
        assert split.indices == [[0, 1], [2, 3, 4], [5, 6, 7]]

    def test_non_contiguous_indices(self):
        """Test SplitByIndex with non-contiguous indices."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        # Non-contiguous routing is the core capability this module adds.
        split = SplitByIndex(inputs=leaf, indices=[[0, 2, 4], [1, 3, 5]])

        assert split.num_splits == 2
        assert split.indices == [[0, 2, 4], [1, 3, 5]]


class TestSplitByIndexValidation:
    """Tests for SplitByIndex validation."""

    def test_overlapping_indices_raises(self):
        """Test that overlapping indices raise ValueError."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        # Each RV must map to exactly one split; overlaps make routing ambiguous.
        with pytest.raises(ValueError):
            SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [2, 3, 4, 5]])

    def test_missing_indices_raises(self):
        """Test that missing indices raise ValueError."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        with pytest.raises(ValueError):
            SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4]])  # Missing 5

    def test_out_of_bounds_raises(self):
        """Test that out of bounds indices raise ValueError."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        with pytest.raises(ValueError):
            SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 10]])

    def test_negative_indices_raises(self):
        """Test that negative indices raise ValueError."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        with pytest.raises(ValueError):
            SplitByIndex(inputs=leaf, indices=[[0, 1, -1], [3, 4, 5]])

    def test_none_indices_raises(self):
        """Test that None indices raise ValueError."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        with pytest.raises(ValueError):
            SplitByIndex(inputs=leaf, indices=None)


class TestSplitByIndexLogLikelihood:
    """Tests for SplitByIndex log_likelihood computation."""

    def test_log_likelihood_shape(self):
        """Test log_likelihood returns correct shapes."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=2)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])

        data = make_normal_data(out_features=6)
        lls = split.log_likelihood(data)

        assert len(lls) == 2
        assert lls[0].shape == (data.shape[0], 3, 3, 2)
        assert lls[1].shape == (data.shape[0], 3, 3, 2)

    def test_log_likelihood_uneven_splits(self):
        """Test log_likelihood with uneven split sizes."""
        scope = Scope(list(range(0, 8)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3, 4, 5, 6, 7]])

        data = make_normal_data(out_features=8)
        lls = split.log_likelihood(data)

        assert len(lls) == 2
        assert lls[0].shape == (data.shape[0], 2, 3, 1)
        assert lls[1].shape == (data.shape[0], 6, 3, 1)

    def test_log_likelihood_correct_indices(self):
        """Test that log_likelihood selects correct features."""
        scope = Scope(list(range(0, 4)))

        # Distinct means per feature make misrouted indices immediately visible.
        mean = torch.arange(4).float().reshape(4, 1, 1)
        std = torch.ones(4, 1, 1) * 10.0
        leaf = make_normal_leaf(scope, mean=mean, std=std)

        split = SplitByIndex(inputs=leaf, indices=[[0, 2], [1, 3]])

        data = mean.squeeze().reshape(1, 4)
        lls = split.log_likelihood(data)

        # Shape checks enforce that each group keeps exactly its assigned RVs.
        assert len(lls) == 2
        assert lls[0].shape[1] == 2  # features 0, 2
        assert lls[1].shape[1] == 2  # features 1, 3


class TestSplitByIndexSampling:
    """Tests for SplitByIndex sampling."""

    @pytest.mark.parametrize("num_reps", [1, 3])
    def test_sample_basic(self, num_reps):
        """Test basic sampling functionality."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=num_reps)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])

        n_samples = 20
        data = torch.full((n_samples, 6), torch.nan)
        channel_index = torch.randint(0, 3, size=(n_samples, 6))
        mask = torch.ones((n_samples, 6), dtype=torch.bool)
        rep_index = torch.randint(0, num_reps, size=(n_samples,))
        sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=rep_index)
        samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())

        assert samples.shape == (n_samples, 6)
        assert torch.isfinite(samples).all()

    def test_sample_non_contiguous(self):
        """Test sampling with non-contiguous indices."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 2, 4], [1, 3, 5]])

        n_samples = 20
        data = torch.full((n_samples, 6), torch.nan)
        channel_index = torch.randint(0, 3, size=(n_samples, 6))
        mask = torch.ones((n_samples, 6), dtype=torch.bool)
        rep_index = torch.zeros(n_samples, dtype=torch.long)
        sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=rep_index)
        samples = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())

        assert samples.shape == (n_samples, 6)
        assert torch.isfinite(samples).all()


class TestSplitByIndexMerge:
    """Tests for SplitByIndex merge_split_indices method."""

    def test_merge_contiguous(self):
        """Test merge_split_indices with contiguous splits."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])

        batch_size = 5
        left_indices = torch.arange(3).unsqueeze(0).expand(batch_size, -1)
        right_indices = torch.arange(3, 6).unsqueeze(0).expand(batch_size, -1)

        merged = split.merge_split_indices(left_indices, right_indices)

        assert merged.shape == (batch_size, 6)
        expected = torch.arange(6).unsqueeze(0).expand(batch_size, -1)
        assert torch.equal(merged, expected)

    def test_merge_non_contiguous(self):
        """Test merge_split_indices with non-contiguous splits."""
        scope = Scope(list(range(0, 4)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 2], [1, 3]])

        batch_size = 3
        # Asymmetric values expose whether merge restores original feature order.
        first_split = torch.tensor([[10, 20], [10, 20], [10, 20]])
        second_split = torch.tensor([[30, 40], [30, 40], [30, 40]])

        merged = split.merge_split_indices(first_split, second_split)

        expected = torch.tensor([[10, 30, 20, 40], [10, 30, 20, 40], [10, 30, 20, 40]])
        assert torch.equal(merged, expected)


class TestSplitModeByIndex:
    """Tests for SplitMode.by_index factory method."""

    def test_split_mode_by_index_creation(self):
        """Test SplitMode.by_index creates correct configuration."""
        mode = SplitMode.by_index(indices=[[0, 1], [2, 3, 4], [5]])

        assert mode.split_type == "by_index"
        assert mode.num_splits == 3
        assert mode.indices == [[0, 1], [2, 3, 4], [5]]

    def test_split_mode_by_index_create(self):
        """Test SplitMode.by_index.create() produces SplitByIndex module."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)

        mode = SplitMode.by_index(indices=[[0, 1, 2], [3, 4, 5]])
        split = mode.create(leaf)

        assert isinstance(split, SplitByIndex)
        assert split.indices == [[0, 1, 2], [3, 4, 5]]

    def test_split_mode_by_index_repr(self):
        """Test SplitMode.by_index repr."""
        mode = SplitMode.by_index(indices=[[0, 1], [2, 3]])
        assert "by_index" in repr(mode)
        assert "[[0, 1], [2, 3]]" in repr(mode)


class TestSplitByIndexIntegration:
    """Integration tests for SplitByIndex with other modules."""

    def test_with_elementwise_product(self):
        """Test SplitByIndex works with ElementwiseProduct."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])
        prod = ElementwiseProduct(inputs=split)

        data = make_normal_data(out_features=6)
        ll = prod.log_likelihood(data)

        assert torch.isfinite(ll).all()
        assert ll.shape[0] == data.shape[0]

    def test_with_outer_product(self):
        """Test SplitByIndex works with OuterProduct."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])
        prod = OuterProduct(inputs=split)

        data = make_normal_data(out_features=6)
        ll = prod.log_likelihood(data)

        assert torch.isfinite(ll).all()
        # Channel growth confirms SplitByIndex output is structurally valid for OuterProduct.
        assert prod.out_shape.channels > split.out_shape.channels

    def test_gradients_flow(self):
        """Test gradients flow through SplitByIndex."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2], [3, 4, 5]])
        prod = ElementwiseProduct(inputs=split)

        data = make_normal_data(out_features=6)
        ll = prod.log_likelihood(data)
        loss = ll.sum()
        loss.backward()

        # Non-None grads verify split indexing does not detach leaf parameters.
        for param in leaf.parameters():
            if param.requires_grad:
                assert param.grad is not None


class TestSplitByIndexProperties:
    """Tests for SplitByIndex property methods."""

    def test_scope_inherited(self):
        """Test that scope is correctly inherited from input."""
        scope = Scope(list(range(0, 8)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1, 2, 3], [4, 5, 6, 7]])

        assert split.scope == leaf.scope
        assert len(split.scope.query) == 8

    def test_out_shape_inherited(self):
        """Test that out_shape is correctly computed."""
        scope = Scope(list(range(0, 6)))
        leaf = make_normal_leaf(scope, out_channels=5, num_repetitions=3)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3], [4, 5]])

        # Keeping out_shape invariant avoids downstream shape bookkeeping errors.
        assert split.out_shape.features == 6
        assert split.out_shape.channels == 5
        assert split.out_shape.repetitions == 3

    def test_extra_repr(self):
        """Test extra_repr includes indices."""
        scope = Scope(list(range(0, 4)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3]])

        repr_str = split.extra_repr()
        assert "indices" in repr_str
        assert "[[0, 1], [2, 3]]" in repr_str

    def test_feature_to_scope_with_padding_and_repetitions(self):
        """Test feature_to_scope shape and padding for uneven splits."""
        scope = Scope(list(range(0, 5)))
        leaf = make_normal_leaf(scope, out_channels=2, num_repetitions=2)
        split = SplitByIndex(inputs=leaf, indices=[[0, 2, 4], [1, 3]])

        f2s = split.feature_to_scope
        assert f2s.shape == (3, 2, 2)
        # -1 padding is a sentinel for missing slots in ragged groups.
        assert f2s[2, 1, 0] == -1
        assert f2s[2, 1, 1] == -1


class TestSplitByIndexSamplingContextExpansion:
    def test_sample_expands_split_sized_context_by_repeat(self):
        scope = Scope(list(range(0, 4)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3]])

        n = 6
        data = torch.full((n, 4), torch.nan)
        sampling_ctx = SamplingContext(
            channel_index=torch.zeros((n, 2), dtype=torch.long),
            mask=torch.ones((n, 2), dtype=torch.bool),
            repetition_index=torch.zeros(n, dtype=torch.long),
        )
        out = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
        assert out.shape == (n, 4)
        # In-place expansion keeps caller context reusable by downstream samplers.
        assert sampling_ctx.channel_index.shape == (n, 4)
        assert sampling_ctx.mask.shape == (n, 4)

    def test_sample_accepts_singleton_context_width_internal_context(self):
        scope = Scope(list(range(0, 4)))
        leaf = make_normal_leaf(scope, out_channels=3, num_repetitions=1)
        split = SplitByIndex(inputs=leaf, indices=[[0, 1], [2, 3]])
        data = torch.full((5, 4), torch.nan)
        sampling_ctx = SamplingContext(
            channel_index=torch.ones((5, 1), dtype=torch.long),
            mask=torch.ones((5, 1), dtype=torch.bool),
            repetition_index=torch.zeros(5, dtype=torch.long),
        )

        out = split._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
        assert out.shape == data.shape
        assert torch.isfinite(out[:, split.scope.query]).all()

    def test_sample_differentiable_equals_non_diff_sampling(self):
        scope = Scope(list(range(0, 6)))
        num_reps = 3
        split = SplitByIndex(
            inputs=make_normal_leaf(scope, out_channels=3, num_repetitions=num_reps),
            indices=[[0, 2, 4], [1, 3, 5]],
        )
        n = 12
        channel_index = torch.randint(0, 3, size=(n, 3))
        mask = torch.ones((n, 3), dtype=torch.bool)
        repetition_index = torch.randint(low=0, high=num_reps, size=(n,))
        sampling_ctx_a = SamplingContext(
            channel_index=channel_index.clone(),
            mask=mask.clone(),
            repetition_index=repetition_index.clone(),
        )
        sampling_ctx_b = SamplingContext(
            channel_index=to_one_hot(channel_index, dim=-1, dim_size=3),
            mask=mask.clone(),
            repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=num_reps),
            is_differentiable=True,
            )

        torch.manual_seed(1337)
        samples_a = split._sample(
            data=torch.full((n, 6), torch.nan),
            sampling_ctx=sampling_ctx_a,
            cache=Cache(),
        )
        torch.manual_seed(1337)
        samples_b = split._sample(
            data=torch.full((n, 6), torch.nan),
            sampling_ctx=sampling_ctx_b,
            cache=Cache(),
        )

        torch.testing.assert_close(samples_a, samples_b, rtol=1e-6, atol=1e-6)
        torch.testing.assert_close(
            sampling_ctx_b.channel_index,
            to_one_hot(sampling_ctx_a.channel_index, dim=-1, dim_size=3),
            rtol=0.0,
            atol=0.0,
        )

    def test_sample_differentiable_gradients_flow(self):
        scope = Scope(list(range(0, 6)))
        num_reps = 3
        split = SplitByIndex(
            inputs=make_normal_leaf(scope, out_channels=3, num_repetitions=num_reps),
            indices=[[0, 2, 4], [1, 3, 5]],
        )
        n = 10
        channel_logits, repetition_logits, channel_index, repetition_index = make_diff_routing_from_logits(
            num_samples=n,
            num_features=3,
            num_channels=3,
            num_repetitions=num_reps,
        )
        sampling_ctx = SamplingContext(
            channel_index=channel_index,
            mask=torch.ones((n, 3), dtype=torch.bool),
            repetition_index=repetition_index,
            is_differentiable=True,
            )
        out = split._sample(
            data=torch.full((n, 6), torch.nan),
            sampling_ctx=sampling_ctx,
            cache=Cache(),
        )
        loss = torch.nan_to_num(out).sum()
        loss.backward()

        assert_nonzero_finite_grad(channel_logits, "channel_logits")
        assert_nonzero_finite_grad(repetition_logits, "repetition_logits")
