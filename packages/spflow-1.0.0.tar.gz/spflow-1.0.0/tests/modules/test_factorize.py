from itertools import product

import pytest
import torch

from spflow.exceptions import StructureError
from spflow.learn import expectation_maximization
from spflow.meta.data.scope import Scope
from spflow.modules.rat import Factorize
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import SamplingContext, to_one_hot
from tests.utils.leaves import DummyLeaf, make_data, make_leaf, make_normal_data, make_normal_leaf

# Constants
in_channels_values = [1, 3]
out_features_values = [4, 8]
num_repetitions = [5]
depth_values = [1, 2]
params = list(product(in_channels_values, out_features_values, num_repetitions, depth_values))


def make_product(in_channels=None, out_features=None, inputs=None, num_repetitions=None, depth=1):
    if inputs is None:
        inputs = make_normal_leaf(
            out_features=out_features, out_channels=in_channels, num_repetitions=num_repetitions
        )
    return Factorize(inputs=[inputs], depth=depth, num_repetitions=num_repetitions)


@pytest.mark.parametrize("in_channels,out_features,num_reps,depth", params)
def test_log_likelihood(in_channels: int, out_features: int, num_reps, depth):
    factorization_layer = make_product(
        in_channels=in_channels, out_features=out_features, num_repetitions=num_reps, depth=depth
    )
    data = make_normal_data(out_features=out_features)
    lls = factorization_layer.log_likelihood(data)
    if num_reps is None:
        assert lls.shape == (
            data.shape[0],
            factorization_layer.out_shape.features,
            factorization_layer.out_shape.channels,
        )
    else:
        assert lls.shape == (
            data.shape[0],
            factorization_layer.out_shape.features,
            factorization_layer.out_shape.channels,
            num_reps,
        )


@pytest.mark.parametrize("in_channels,out_features,num_reps, depth", params)
def test_sample(in_channels: int, out_features: int, num_reps, depth):
    n_samples = 10
    factorization_layer = make_product(
        in_channels=in_channels, out_features=out_features, num_repetitions=num_reps, depth=depth
    )

    data = torch.full((n_samples, out_features), torch.nan)
    channel_index = torch.randint(
        low=0,
        high=factorization_layer.out_shape.channels,
        size=(n_samples, factorization_layer.out_shape.features),
    )
    mask = torch.full((n_samples, factorization_layer.out_shape.features), True, dtype=torch.bool)
    repetition_index = torch.randint(low=0, high=num_reps, size=(n_samples,))
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=repetition_index)
    samples = factorization_layer._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert samples.shape == data.shape
    samples_query = samples[:, factorization_layer.scope.query]
    assert torch.isfinite(samples_query).all()


def test_sample_differentiable():
    n_samples = 12
    out_features = 8
    num_reps = 4
    factorization_layer = make_product(
        in_channels=3,
        out_features=out_features,
        num_repetitions=num_reps,
        depth=2,
    )

    data = torch.full((n_samples, out_features), torch.nan)
    channel_index = torch.randint(
        low=0,
        high=factorization_layer.out_shape.channels,
        size=(n_samples, factorization_layer.out_shape.features),
    )
    repetition_index = torch.randint(low=0, high=num_reps, size=(n_samples,))
    sampling_ctx = SamplingContext(
        channel_index=to_one_hot(channel_index, dim=-1, dim_size=factorization_layer.out_shape.channels),
        mask=torch.ones((n_samples, factorization_layer.out_shape.features), dtype=torch.bool),
        repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=num_reps),
        is_differentiable=True,
    )
    samples = factorization_layer._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert samples.shape == data.shape
    assert torch.isfinite(samples[:, factorization_layer.scope.query]).all()


def test_sample_differentiable_with_conditional_cache():
    n_samples = 10
    out_features = 8
    num_reps = 3
    factorization_layer = make_product(
        in_channels=3,
        out_features=out_features,
        num_repetitions=num_reps,
        depth=2,
    )

    evidence = make_normal_data(out_features=out_features)
    cache = Cache()
    factorization_layer.log_likelihood(evidence, cache=cache)

    channel_index = torch.randint(
        low=0,
        high=factorization_layer.out_shape.channels,
        size=(n_samples, factorization_layer.out_shape.features),
    )
    repetition_index = torch.randint(low=0, high=num_reps, size=(n_samples,))
    sampling_ctx = SamplingContext(
        channel_index=to_one_hot(channel_index, dim=-1, dim_size=factorization_layer.out_shape.channels),
        mask=torch.ones((n_samples, factorization_layer.out_shape.features), dtype=torch.bool),
        repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=num_reps),
        is_differentiable=True,
    )
    samples = factorization_layer._sample(
        data=torch.full((n_samples, out_features), torch.nan),
        sampling_ctx=sampling_ctx,
        cache=cache,
    )
    assert samples.shape == (n_samples, out_features)
    assert torch.isfinite(samples[:, factorization_layer.scope.query]).all()


def test_sample_differentiable_equals_non_diff_sampling():
    n_samples = 14
    out_features = 8
    num_reps = 4
    factorization_layer = make_product(
        in_channels=3,
        out_features=out_features,
        num_repetitions=num_reps,
        depth=2,
    )

    channel_index = torch.randint(
        low=0,
        high=factorization_layer.out_shape.channels,
        size=(n_samples, factorization_layer.out_shape.features),
    )
    repetition_index = torch.randint(low=0, high=num_reps, size=(n_samples,))
    mask = torch.ones((n_samples, factorization_layer.out_shape.features), dtype=torch.bool)
    sampling_ctx_a = SamplingContext(
        channel_index=channel_index.clone(),
        mask=mask.clone(),
        repetition_index=repetition_index.clone(),
    )
    sampling_ctx_b = SamplingContext(
        channel_index=to_one_hot(channel_index, dim=-1, dim_size=factorization_layer.out_shape.channels),
        mask=mask.clone(),
        repetition_index=to_one_hot(repetition_index, dim=-1, dim_size=num_reps),
        is_differentiable=True,
    )

    torch.manual_seed(1337)
    samples_a = factorization_layer._sample(
        data=torch.full((n_samples, out_features), torch.nan),
        sampling_ctx=sampling_ctx_a,
        cache=Cache(),
    )
    torch.manual_seed(1337)
    samples_b = factorization_layer._sample(
        data=torch.full((n_samples, out_features), torch.nan),
        sampling_ctx=sampling_ctx_b,
        cache=Cache(),
    )

    torch.testing.assert_close(samples_a, samples_b, rtol=1e-6, atol=1e-6)


def test_sample_accepts_column_vector_repetition_idx():
    """Sampling accepts repetition indices with shape (batch, 1)."""
    n_samples = 6
    num_reps = 4
    factorization_layer = make_product(in_channels=3, out_features=8, num_repetitions=num_reps, depth=2)

    data = torch.full((n_samples, 8), torch.nan)
    channel_index = torch.randint(
        low=0,
        high=factorization_layer.out_shape.channels,
        size=(n_samples, factorization_layer.out_shape.features),
    )
    mask = torch.full((n_samples, factorization_layer.out_shape.features), True, dtype=torch.bool)
    repetition_index = torch.randint(low=0, high=num_reps, size=(n_samples, 1))
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=repetition_index)

    samples = factorization_layer._sample(data=data, sampling_ctx=sampling_ctx, cache=Cache())
    assert samples.shape == data.shape
    assert torch.isfinite(samples[:, factorization_layer.scope.query]).all()


def test_factorization():
    data = make_normal_data(out_features=4)
    factorization = make_product(in_channels=3, out_features=4, num_repetitions=5)
    factorization = expectation_maximization(factorization, data, max_steps=10)
    assert factorization is not None


def test_feature_to_scope_basic():
    """Factorize groups input scopes according to indices."""
    out_features = 4
    num_reps = 1
    leaf = make_normal_leaf(out_features=out_features, out_channels=1, num_repetitions=num_reps)
    module = Factorize(inputs=[leaf], depth=1, num_repetitions=num_reps)

    # Force deterministic grouping: outputs are {0,1} and {2,3}
    indices = torch.zeros(out_features, module.out_shape.features, num_reps)
    indices[0:2, 0, 0] = 1
    indices[2:4, 1, 0] = 1
    module.indices = indices

    feature_scopes = module.feature_to_scope

    assert feature_scopes.shape == (module.out_shape.features, num_reps)
    expected_scope_0 = Scope.join_all([leaf.feature_to_scope[0, 0], leaf.feature_to_scope[1, 0]])
    expected_scope_1 = Scope.join_all([leaf.feature_to_scope[2, 0], leaf.feature_to_scope[3, 0]])
    assert feature_scopes[0, 0] == expected_scope_0
    assert feature_scopes[1, 0] == expected_scope_1
    assert all(isinstance(s, Scope) for s in feature_scopes.flatten())


def test_feature_to_scope_multiple_repetitions():
    """Each repetition uses its own factorization pattern."""
    out_features = 4
    num_reps = 2
    leaf = make_normal_leaf(out_features=out_features, out_channels=1, num_repetitions=num_reps)
    module = Factorize(inputs=[leaf], depth=1, num_repetitions=num_reps)

    # rep 0: {0,1}, {2,3}; rep 1: {0,2}, {1,3}
    indices = torch.zeros(out_features, module.out_shape.features, num_reps)
    indices[0:2, 0, 0] = 1
    indices[2:4, 1, 0] = 1
    indices[[0, 2], 0, 1] = 1
    indices[[1, 3], 1, 1] = 1
    module.indices = indices

    feature_scopes = module.feature_to_scope

    assert feature_scopes.shape == (module.out_shape.features, num_reps)
    expected_rep0 = [
        Scope.join_all([leaf.feature_to_scope[0, 0], leaf.feature_to_scope[1, 0]]),
        Scope.join_all([leaf.feature_to_scope[2, 0], leaf.feature_to_scope[3, 0]]),
    ]
    expected_rep1 = [
        Scope.join_all([leaf.feature_to_scope[0, 1], leaf.feature_to_scope[2, 1]]),
        Scope.join_all([leaf.feature_to_scope[1, 1], leaf.feature_to_scope[3, 1]]),
    ]

    assert feature_scopes[0, 0] == expected_rep0[0]
    assert feature_scopes[1, 0] == expected_rep0[1]
    assert feature_scopes[0, 1] == expected_rep1[0]
    assert feature_scopes[1, 1] == expected_rep1[1]
    assert all(isinstance(s, Scope) for s in feature_scopes.flatten())


@pytest.mark.parametrize(
    "prune,in_channels,marg_rvs,num_reps",
    product(
        [True, False],
        in_channels_values,
        [[0], [1], [2], [0, 1], [1, 2], [0, 2], [0, 1, 2]],
        num_repetitions,
    ),
)
def test_marginalize(prune, in_channels: int, marg_rvs: list[int], num_reps):
    out_features = 6
    module = make_product(in_channels=in_channels, out_features=out_features, num_repetitions=num_reps)

    # Marginalize scope
    marginalized_module = module.marginalize(marg_rvs, prune=prune)

    if len(marg_rvs) == out_features:
        assert marginalized_module is None
        return

    if prune and len(marg_rvs) == (out_features - 1):
        # If pruning is active and only one scope is left, the (pruned) input module should be returned
        assert isinstance(marginalized_module, type(module.inputs))

    # Scope query should not contain marginalized rv
    assert len(set(marginalized_module.scope.query).intersection(marg_rvs)) == 0


def test_multidistribution_input():
    out_channels = 3
    num_reps = 5
    out_features_1 = 8
    out_features_2 = 10

    scope_1 = Scope(list(range(0, out_features_1)))
    scope_2 = Scope(list(range(out_features_1, out_features_1 + out_features_2)))

    cls_1 = DummyLeaf
    cls_2 = DummyLeaf

    module_1 = make_leaf(cls=cls_1, out_channels=out_channels, scope=scope_1, num_repetitions=num_reps)
    data_1 = make_data(cls=cls_1, out_features=out_features_1, n_samples=5)

    module_2 = make_leaf(cls=cls_2, out_channels=out_channels, scope=scope_2, num_repetitions=num_reps)
    data_2 = make_data(cls=cls_2, out_features=out_features_2, n_samples=5)

    module = Factorize(inputs=[module_1, module_2], depth=2, num_repetitions=num_reps)

    data = torch.cat((data_1, data_2), dim=1)
    lls = module.log_likelihood(data)

    assert lls.shape == (data.shape[0], module.out_shape.features, module.out_shape.channels, num_reps)

    # Create data tensor to populate with samples
    data_to_sample = torch.full((1, out_features_1 + out_features_2), torch.nan)
    channel_index = torch.randint(
        low=0, high=module.out_shape.channels, size=(1, module.out_shape.features)
    )
    mask = torch.full((1, module.out_shape.features), True, dtype=torch.bool)
    repetition_index = torch.randint(low=0, high=num_reps, size=(1,))
    sampling_ctx = SamplingContext(channel_index=channel_index, mask=mask, repetition_index=repetition_index)
    samples = module._sample(data=data_to_sample, sampling_ctx=sampling_ctx, cache=Cache())

    assert samples.shape == (1, out_features_1 + out_features_2)


def test_insufficient_features_for_depth():
    """Test that StructureError is raised when depth requires more features than available."""
    # Create a leaves with only 4 features
    out_features = 4
    num_reps = 5
    leaf = make_normal_leaf(out_features=out_features, out_channels=1, num_repetitions=num_reps)

    # Try to create a Factorize with depth=3 (requires 2^3 = 8 features, but only have 4)
    with pytest.raises(StructureError):
        Factorize(inputs=[leaf], depth=3, num_repetitions=num_reps)


def test_exact_feature_count_for_depth():
    """Test that Factorize works when features exactly match required count for depth."""
    # Create a leaves with exactly 8 features
    out_features = 8
    num_reps = 5
    leaf = make_normal_leaf(out_features=out_features, out_channels=1, num_repetitions=num_reps)

    # This should work fine: depth=3 requires 2^3 = 8 features
    factorize = Factorize(inputs=[leaf], depth=3, num_repetitions=num_reps)
    assert factorize.out_shape.features == 8


def test_excess_features_for_depth():
    """Test that Factorize works when features exceed required count for depth."""
    # Create a leaves with 10 features
    out_features = 10
    num_reps = 5
    leaf = make_normal_leaf(out_features=out_features, out_channels=1, num_repetitions=num_reps)

    factorize = Factorize(inputs=[leaf], depth=2, num_repetitions=num_reps)
    assert factorize.out_shape.features == 4


def test_factorize_list_input():
    """Test that Factorize handles list of modules by concatenating them."""
    out_features = 4
    num_reps = 1
    # Create two leaves, each with 2 features
    leaf1 = make_normal_leaf(out_features=2, out_channels=1, num_repetitions=num_reps)
    leaf2 = make_normal_leaf(out_features=2, out_channels=1, num_repetitions=num_reps)

    # Ensure they have disjoint scopes (required for Cat on dim=1)
    # Actually make_normal_leaf usually creates default scope 0..n-1.
    # We need to manually set scopes.
    leaf1.scope = Scope([0, 1])
    leaf2.scope = Scope([2, 3])

    # Pass list of modules
    factorize = Factorize(inputs=[leaf1, leaf2], depth=2, num_repetitions=num_reps)

    # Check if it concatenated correctly
    # Concatenation of 2 features + 2 features = 4 features.
    # Depth=2 => 2^2 = 4 output features.
    assert factorize.out_shape.features == 4

    # Check if inputs is wrapped Cat module
    # self.inputs is ModuleList, so [0] is the input module
    from spflow.modules.ops.cat import Cat

    assert isinstance(factorize.inputs[0], Cat)
    assert len(factorize.inputs[0].inputs) == 2

    # Test execution (log likelihood)
    data = make_normal_data(out_features=4)
    ll = factorize.log_likelihood(data)
    assert ll.shape == (data.shape[0], 4, 1, 1)  # (batch, out_features, channels, repetitions)
