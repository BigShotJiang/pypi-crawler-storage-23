import torch
import pytest
from typing import Optional
from torch_l1_snr import (
    dbrms,
    L1SNRLoss,
    L1SNRDBLoss,
    STFTL1SNRDBLoss,
    MultiL1SNRDBLoss,
)

# --- Test Helper: Stem Wrapper ---
class StemWrappedLoss(torch.nn.Module):
    """Test helper matching user's pipL1SNRLoss wrapper pattern."""
    def __init__(self, base_loss, stem_dimension: Optional[int] = None):
        super().__init__()
        self.base_loss = base_loss
        self.stem_dimension = stem_dimension
    
    def forward(self, estimates, actuals, *args, **kwargs):
        if self.stem_dimension is not None:
            # Handle both [B,S,T] and [B,S,C,T] shapes
            if estimates.ndim == 3:  # [B, S, T]
                est_source = estimates[:, self.stem_dimension, :]
                act_source = actuals[:, self.stem_dimension, :]
            else:  # [B, S, C, T]
                est_source = estimates[:, self.stem_dimension, :, :]
                act_source = actuals[:, self.stem_dimension, :, :]
            return self.base_loss(est_source, act_source, *args, **kwargs)
        else:
            return self.base_loss(estimates, actuals, *args, **kwargs)

# --- Test Fixtures ---
@pytest.fixture
def dummy_audio():
    """Provides a batch of dummy audio signals."""
    estimates = torch.randn(2, 16000)
    actuals = torch.randn(2, 16000)
    # Ensure actuals are not all zero to avoid division by zero in loss
    actuals[0, :100] += 0.1 
    return estimates, actuals

@pytest.fixture
def dummy_stems():
    """Provides a batch of dummy multi-stem signals."""
    estimates = torch.randn(2, 4, 1, 16000) # batch, stems, channels, samples
    actuals = torch.randn(2, 4, 1, 16000)
    actuals[:, 0, :, :100] += 0.1 # Ensure not all zero
    return estimates, actuals

@pytest.fixture
def dummy_stems_3d():
    """Multi-stem signals: [B, S, T]"""
    estimates = torch.randn(2, 4, 16000)
    actuals = torch.randn(2, 4, 16000)
    actuals[:, 0, :100] += 0.1  # Ensure not all zero
    return estimates, actuals

@pytest.fixture
def dummy_stems_4d():
    """Multi-stem signals: [B, S, C, T]"""
    estimates = torch.randn(2, 4, 1, 16000)
    actuals = torch.randn(2, 4, 1, 16000)
    actuals[:, 0, :, :100] += 0.1
    return estimates, actuals

# --- Test Functions ---

def test_dbrms():
    signal = torch.ones(2, 1000) * 0.1
    # RMS of 0.1 is -20 dB
    assert torch.allclose(dbrms(signal), torch.tensor([-20.0, -20.0]), atol=1e-4)
    
    zeros = torch.zeros(2, 1000)
    # dbrms of zero should be -80dB with default eps=1e-8
    assert torch.allclose(dbrms(zeros), torch.tensor([-80.0, -80.0]), atol=1e-4)

def test_l1snr_loss(dummy_audio):
    estimates, actuals = dummy_audio
    loss_fn = L1SNRLoss(name="test")
    loss = loss_fn(estimates, actuals)
    
    assert isinstance(loss, torch.Tensor)
    assert loss.ndim == 0
    assert not torch.isnan(loss)
    assert not torch.isinf(loss)

def test_l1snrdb_loss_time(dummy_audio):
    estimates, actuals = dummy_audio
    
    # Test with default settings (L1SNR + Regularization)
    loss_fn = L1SNRDBLoss(name="test", use_regularization=True, l1_weight=0.0)
    loss = loss_fn(estimates, actuals)
    assert loss.ndim == 0 and not torch.isnan(loss)

    # Test without regularization
    loss_fn_no_reg = L1SNRDBLoss(name="test_no_reg", use_regularization=False, l1_weight=0.0)
    loss_no_reg = loss_fn_no_reg(estimates, actuals)
    assert loss_no_reg.ndim == 0 and not torch.isnan(loss_no_reg)

    # Test with L1 loss component
    loss_fn_l1 = L1SNRDBLoss(name="test_l1", l1_weight=0.2)
    loss_l1 = loss_fn_l1(estimates, actuals)
    assert loss_l1.ndim == 0 and not torch.isnan(loss_l1)
    
    # Test pure L1 loss mode
    loss_fn_pure_l1 = L1SNRDBLoss(name="test_pure_l1", l1_weight=1.0)
    pure_l1_loss = loss_fn_pure_l1(estimates, actuals)
    # Pure L1 mode uses torch.nn.L1Loss, so compare with manual L1 calculation
    l1_loss_manual = torch.nn.L1Loss()(
        estimates.reshape(estimates.shape[0], -1),
        actuals.reshape(actuals.shape[0], -1)
    )
    assert torch.allclose(pure_l1_loss, l1_loss_manual)

def test_stft_l1snrdb_loss(dummy_audio):
    estimates, actuals = dummy_audio
    
    # Test with default settings
    loss_fn = STFTL1SNRDBLoss(name="test", l1_weight=0.0)
    loss = loss_fn(estimates, actuals)
    assert loss.ndim == 0 and not torch.isnan(loss) and not torch.isinf(loss)
    
    # Test pure L1 mode
    loss_fn_pure_l1 = STFTL1SNRDBLoss(name="test_pure_l1", l1_weight=1.0)
    l1_loss = loss_fn_pure_l1(estimates, actuals)
    assert l1_loss.ndim == 0 and not torch.isnan(l1_loss) and not torch.isinf(l1_loss)

    # Test with very short audio
    short_estimates = estimates[:, :500]
    short_actuals = actuals[:, :500]
    loss_short = loss_fn(short_estimates, short_actuals)
    # min_audio_length is 512, so this should fallback to time-domain loss
    assert loss_short.ndim == 0 and not torch.isnan(loss_short)

def test_stem_multi_loss(dummy_stems):
    estimates, actuals = dummy_stems

    # Test with a specific stem - users now manage stems manually by slicing
    # Extract stem 1 (second stem) manually
    est_stem = estimates[:, 1, ...]  # Shape: [batch, channels, samples]
    act_stem = actuals[:, 1, ...]
    loss_fn_stem = MultiL1SNRDBLoss(
        name="test_loss_stem",
        spec_weight=0.5,
        l1_weight=0.1
    )
    loss = loss_fn_stem(est_stem, act_stem)
    assert loss.ndim == 0 and not torch.isnan(loss)

    # Test with all stems jointly - flatten all stems together
    # Reshape to [batch, -1] to process all stems at once
    est_all = estimates.reshape(estimates.shape[0], -1)
    act_all = actuals.reshape(actuals.shape[0], -1)
    loss_fn_all = MultiL1SNRDBLoss(
        name="test_loss_all",
        spec_weight=0.5,
        l1_weight=0.1
    )
    loss_all = loss_fn_all(est_all, act_all)
    assert loss_all.ndim == 0 and not torch.isnan(loss_all)
    
    # Test pure L1 mode on all stems
    loss_fn_l1 = MultiL1SNRDBLoss(name="l1_only", l1_weight=1.0)
    l1_loss = loss_fn_l1(est_all, act_all)
    
    # Can't easily compute multi-res STFT L1 here, but can check it's not nan
    assert l1_loss.ndim == 0 and not torch.isnan(l1_loss)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
def test_loss_variants(dummy_audio, l1_weight):
    """Test L1SNRDBLoss and STFTL1SNRDBLoss with different l1_weights."""
    estimates, actuals = dummy_audio
    
    time_loss_fn = L1SNRDBLoss(name=f"test_time_{l1_weight}", l1_weight=l1_weight)
    time_loss = time_loss_fn(estimates, actuals)
    assert not torch.isnan(time_loss) and not torch.isinf(time_loss)

    spec_loss_fn = STFTL1SNRDBLoss(name=f"test_spec_{l1_weight}", l1_weight=l1_weight)
    spec_loss = spec_loss_fn(estimates, actuals)
    assert not torch.isnan(spec_loss) and not torch.isinf(spec_loss)

# --- Wrapper-Paradigm Tests ---

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
def test_l1snr_wrapper_all_stems_3d(dummy_stems_3d, l1_weight):
    """Test L1SNRLoss wrapper with stem_dimension=None on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = L1SNRLoss(name="test", weight=1.0, l1_weight=l1_weight)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
def test_l1snr_wrapper_all_stems_4d(dummy_stems_4d, l1_weight):
    """Test L1SNRLoss wrapper with stem_dimension=None on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = L1SNRLoss(name="test", weight=1.0, l1_weight=l1_weight)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_l1snr_wrapper_single_stem_3d(dummy_stems_3d, l1_weight, stem_idx):
    """Test L1SNRLoss wrapper with stem_dimension=k on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = L1SNRLoss(name="test", weight=1.0, l1_weight=l1_weight)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :]
    act_slice = actuals[:, stem_idx, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_l1snr_wrapper_single_stem_4d(dummy_stems_4d, l1_weight, stem_idx):
    """Test L1SNRLoss wrapper with stem_dimension=k on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = L1SNRLoss(name="test", weight=1.0, l1_weight=l1_weight)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :, :]
    act_slice = actuals[:, stem_idx, :, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_reg", [True, False])
def test_l1snrdb_wrapper_all_stems_3d(dummy_stems_3d, l1_weight, use_reg):
    """Test L1SNRDBLoss wrapper with stem_dimension=None on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = L1SNRDBLoss(name="test", weight=1.0, l1_weight=l1_weight, use_regularization=use_reg)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_reg", [True, False])
def test_l1snrdb_wrapper_all_stems_4d(dummy_stems_4d, l1_weight, use_reg):
    """Test L1SNRDBLoss wrapper with stem_dimension=None on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = L1SNRDBLoss(name="test", weight=1.0, l1_weight=l1_weight, use_regularization=use_reg)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_reg", [True, False])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_l1snrdb_wrapper_single_stem_3d(dummy_stems_3d, l1_weight, use_reg, stem_idx):
    """Test L1SNRDBLoss wrapper with stem_dimension=k on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = L1SNRDBLoss(name="test", weight=1.0, l1_weight=l1_weight, use_regularization=use_reg)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :]
    act_slice = actuals[:, stem_idx, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_reg", [True, False])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_l1snrdb_wrapper_single_stem_4d(dummy_stems_4d, l1_weight, use_reg, stem_idx):
    """Test L1SNRDBLoss wrapper with stem_dimension=k on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = L1SNRDBLoss(name="test", weight=1.0, l1_weight=l1_weight, use_regularization=use_reg)
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :, :]
    act_slice = actuals[:, stem_idx, :, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
def test_stft_wrapper_all_stems_3d(dummy_stems_3d, l1_weight):
    """Test STFTL1SNRDBLoss wrapper with stem_dimension=None on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
def test_stft_wrapper_all_stems_4d(dummy_stems_4d, l1_weight):
    """Test STFTL1SNRDBLoss wrapper with stem_dimension=None on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_stft_wrapper_single_stem_3d(dummy_stems_3d, l1_weight, stem_idx):
    """Test STFTL1SNRDBLoss wrapper with stem_dimension=k on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :]
    act_slice = actuals[:, stem_idx, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_stft_wrapper_single_stem_4d(dummy_stems_4d, l1_weight, stem_idx):
    """Test STFTL1SNRDBLoss wrapper with stem_dimension=k on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :, :]
    act_slice = actuals[:, stem_idx, :, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

def test_stft_wrapper_short_audio_3d():
    """Test STFTL1SNRDBLoss wrapper fallback path with short audio [B,S,T]."""
    estimates = torch.randn(2, 4, 400)  # Short audio
    actuals = torch.randn(2, 4, 400)
    actuals[:, 0, :100] += 0.1
    
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=0.0,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=512
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

def test_stft_wrapper_short_audio_4d():
    """Test STFTL1SNRDBLoss wrapper fallback path with short audio [B,S,C,T]."""
    estimates = torch.randn(2, 4, 1, 400)  # Short audio
    actuals = torch.randn(2, 4, 1, 400)
    actuals[:, 0, :, :100] += 0.1
    
    base_loss = STFTL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=0.0,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=512
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_time_reg", [True, False])
def test_multi_wrapper_all_stems_3d(dummy_stems_3d, l1_weight, use_time_reg):
    """Test MultiL1SNRDBLoss wrapper with stem_dimension=None on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        use_time_regularization=use_time_reg, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_time_reg", [True, False])
def test_multi_wrapper_all_stems_4d(dummy_stems_4d, l1_weight, use_time_reg):
    """Test MultiL1SNRDBLoss wrapper with stem_dimension=None on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        use_time_regularization=use_time_reg, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_time_reg", [True, False])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_multi_wrapper_single_stem_3d(dummy_stems_3d, l1_weight, use_time_reg, stem_idx):
    """Test MultiL1SNRDBLoss wrapper with stem_dimension=k on [B,S,T]."""
    estimates, actuals = dummy_stems_3d
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        use_time_regularization=use_time_reg, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :]
    act_slice = actuals[:, stem_idx, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

@pytest.mark.parametrize("l1_weight", [0.0, 0.5, 1.0])
@pytest.mark.parametrize("use_time_reg", [True, False])
@pytest.mark.parametrize("stem_idx", [0, 3])
def test_multi_wrapper_single_stem_4d(dummy_stems_4d, l1_weight, use_time_reg, stem_idx):
    """Test MultiL1SNRDBLoss wrapper with stem_dimension=k on [B,S,C,T]."""
    estimates, actuals = dummy_stems_4d
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=l1_weight,
        use_time_regularization=use_time_reg, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=stem_idx)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    est_slice = estimates[:, stem_idx, :, :]
    act_slice = actuals[:, stem_idx, :, :]
    direct_result = base_loss(est_slice, act_slice)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

def test_multi_wrapper_short_audio_3d():
    """Test MultiL1SNRDBLoss wrapper fallback path with short audio [B,S,T]."""
    estimates = torch.randn(2, 4, 400)  # Short audio
    actuals = torch.randn(2, 4, 400)
    actuals[:, 0, :100] += 0.1
    
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=0.0,
        use_time_regularization=True, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=512
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)

def test_multi_wrapper_short_audio_4d():
    """Test MultiL1SNRDBLoss wrapper fallback path with short audio [B,S,C,T]."""
    estimates = torch.randn(2, 4, 1, 400)  # Short audio
    actuals = torch.randn(2, 4, 1, 400)
    actuals[:, 0, :, :100] += 0.1
    
    base_loss = MultiL1SNRDBLoss(
        name="test", weight=1.0, l1_weight=0.0,
        use_time_regularization=True, use_spec_regularization=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=512
    )
    wrapped_loss = StemWrappedLoss(base_loss, stem_dimension=None)
    
    wrapped_result = wrapped_loss(estimates, actuals)
    direct_result = base_loss(estimates, actuals)
    
    assert torch.allclose(wrapped_result, direct_result, atol=1e-6)
    assert wrapped_result.ndim == 0
    assert not torch.isnan(wrapped_result) and not torch.isinf(wrapped_result)


# --- Gradient Behavior Tests ---
def test_gradient_distinction_l1snr_vs_l1():
    """
    Verify L1SNR and L1 have distinct gradient behaviors.
    L1SNR: inverse-error scaling (larger updates for small errors)
    L1: uniform gradients regardless of error magnitude
    """
    torch.manual_seed(42)

    actuals = torch.tensor([[1.0] * 100, [1.0] * 100])
    estimates = actuals.clone()
    estimates[0] += 0.01  # small error
    estimates[1] += 0.5   # large error

    # Pure L1SNR (l1_weight=0)
    est_snr = estimates.clone().requires_grad_(True)
    loss_snr = L1SNRLoss("test", l1_weight=0.0)(est_snr, actuals)
    loss_snr.backward()
    ratio_snr = est_snr.grad[0].abs().mean() / est_snr.grad[1].abs().mean()

    # Pure L1 (l1_weight=1)
    est_l1 = estimates.clone().requires_grad_(True)
    loss_l1 = L1SNRLoss("test", l1_weight=1.0)(est_l1, actuals)
    loss_l1.backward()
    ratio_l1 = est_l1.grad[0].abs().mean() / est_l1.grad[1].abs().mean()

    # L1SNR: larger gradient for small error sample (ratio >> 1)
    assert ratio_snr > 10.0, f"L1SNR gradient ratio should be >> 1, got {ratio_snr}"
    # L1: uniform gradients (ratio ~ 1)
    assert 0.9 < ratio_l1 < 1.1, f"L1 gradient ratio should be ~1, got {ratio_l1}"


def test_l1_weight_interpolation():
    """
    Verify l1_weight actually affects gradient behavior.
    Gradient ratio should decrease as l1_weight increases (from inverse-error toward uniform).
    """
    torch.manual_seed(42)

    actuals = torch.tensor([[1.0] * 100, [1.0] * 100])
    estimates = actuals.clone()
    estimates[0] += 0.01  # small error
    estimates[1] += 0.5   # large error

    ratios = []
    for w in [0.0, 0.5, 1.0]:
        est = estimates.clone().requires_grad_(True)
        loss = L1SNRLoss("test", l1_weight=w)(est, actuals)
        loss.backward()
        ratio = (est.grad[0].abs().mean() / est.grad[1].abs().mean()).item()
        ratios.append(ratio)

    # Gradient ratio should monotonically decrease as l1_weight increases
    assert ratios[0] > ratios[1] > ratios[2], \
        f"Gradient ratios should decrease with l1_weight: {ratios}"


def test_stft_gradient_distinction():
    """
    Same gradient distinction test for STFTL1SNRDBLoss.
    """
    torch.manual_seed(42)

    # Need longer audio for STFT
    actuals = torch.tensor([[1.0] * 4096, [1.0] * 4096])
    estimates = actuals.clone()
    estimates[0] += 0.01  # small error
    estimates[1] += 0.5   # large error

    # Pure L1SNR (l1_weight=0)
    est_snr = estimates.clone().requires_grad_(True)
    loss_fn_snr = STFTL1SNRDBLoss("test", l1_weight=0.0, n_ffts=[512], hop_lengths=[128], win_lengths=[512])
    loss_snr = loss_fn_snr(est_snr, actuals)
    loss_snr.backward()
    ratio_snr = est_snr.grad[0].abs().mean() / est_snr.grad[1].abs().mean()

    # Pure L1 (l1_weight=1)
    est_l1 = estimates.clone().requires_grad_(True)
    loss_fn_l1 = STFTL1SNRDBLoss("test", l1_weight=1.0, n_ffts=[512], hop_lengths=[128], win_lengths=[512])
    loss_l1 = loss_fn_l1(est_l1, actuals)
    loss_l1.backward()
    ratio_l1 = est_l1.grad[0].abs().mean() / est_l1.grad[1].abs().mean()

    # STFT processing smooths out per-sample differences, so ratios are smaller
    # Key check: L1SNR ratio > L1 ratio (gradient behaviors differ)
    assert ratio_snr > ratio_l1, f"STFT L1SNR ratio ({ratio_snr}) should be > L1 ratio ({ratio_l1})"
    # L1: more uniform gradients (ratio closer to 1)
    assert ratio_l1 < ratio_snr, f"STFT L1 should have more uniform gradients"


def test_mps_cpu_fallback_gradient_correctness():
    """
    Verify mps_cpu_fallback produces correct gradients by comparing
    CPU-with-fallback vs CPU-without-fallback (should be identical).
    On MPS, also verify gradients are finite and reasonably scaled.
    """
    torch.manual_seed(42)
    actuals = torch.randn(2, 4096)
    estimates = actuals.clone() + 0.1 * torch.randn_like(actuals)

    # CPU reference (fallback has no effect on CPU)
    est_ref = estimates.clone().requires_grad_(True)
    loss_fn_ref = STFTL1SNRDBLoss(
        "ref", n_ffts=[512], hop_lengths=[128], win_lengths=[512],
        mps_cpu_fallback=False,
    )
    loss_ref = loss_fn_ref(est_ref, actuals)
    loss_ref.backward()

    # CPU with fallback enabled (should be identical since not on MPS)
    est_fb = estimates.clone().requires_grad_(True)
    loss_fn_fb = STFTL1SNRDBLoss(
        "fb", n_ffts=[512], hop_lengths=[128], win_lengths=[512],
        mps_cpu_fallback=True,
    )
    loss_fb = loss_fn_fb(est_fb, actuals)
    loss_fb.backward()

    # Losses and gradients should be identical on CPU regardless of fallback flag
    assert torch.allclose(loss_ref, loss_fb, atol=1e-6), \
        f"Fallback should not change CPU loss: {loss_ref.item()} vs {loss_fb.item()}"
    assert torch.allclose(est_ref.grad, est_fb.grad, atol=1e-6), \
        "Fallback should not change CPU gradients"

    # If MPS is available, verify the fallback produces finite, sane gradients
    if torch.backends.mps.is_available():
        mps = torch.device("mps")
        est_mps = estimates.clone().to(mps).requires_grad_(True)
        act_mps = actuals.clone().to(mps)
        loss_fn_mps = STFTL1SNRDBLoss(
            "mps", n_ffts=[512], hop_lengths=[128], win_lengths=[512],
            mps_cpu_fallback=True,
        ).to(mps)
        loss_mps = loss_fn_mps(est_mps, act_mps)
        loss_mps.backward()

        assert not torch.isnan(est_mps.grad).any(), "MPS fallback grads should have no NaN"
        assert not torch.isinf(est_mps.grad).any(), "MPS fallback grads should have no Inf"
        # Grad norm should be in a reasonable range (CPU ref norm as baseline)
        cpu_norm = est_ref.grad.norm().item()
        mps_norm = est_mps.grad.cpu().norm().item()
        ratio = mps_norm / (cpu_norm + 1e-12)
        assert 0.1 < ratio < 10.0, \
            f"MPS fallback grad norm ({mps_norm:.4f}) should be close to CPU ({cpu_norm:.4f}), ratio={ratio:.2f}"


def test_mps_cpu_fallback_disabled():
    """Verify mps_cpu_fallback=False skips the CPU routing."""
    torch.manual_seed(42)
    estimates = torch.randn(2, 4096)
    actuals = torch.randn(2, 4096)

    loss_fn = STFTL1SNRDBLoss(
        "test", n_ffts=[512], hop_lengths=[128], win_lengths=[512],
        mps_cpu_fallback=False,
    )
    # On CPU this should just work normally
    est = estimates.clone().requires_grad_(True)
    loss = loss_fn(est, actuals)
    loss.backward()
    assert not torch.isnan(loss)
    assert est.grad is not None


def test_multi_mps_cpu_fallback_passthrough():
    """Verify MultiL1SNRDBLoss passes mps_cpu_fallback to STFTL1SNRDBLoss."""
    loss_fn = MultiL1SNRDBLoss(
        "test", mps_cpu_fallback=True,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256,
    )
    assert loss_fn.spec_loss.mps_cpu_fallback is True

    loss_fn_off = MultiL1SNRDBLoss(
        "test", mps_cpu_fallback=False,
        n_ffts=[256], hop_lengths=[64], win_lengths=[256], min_audio_length=256,
    )
    assert loss_fn_off.spec_loss.mps_cpu_fallback is False


def test_stft_l1_weight_interpolation():
    """
    Verify l1_weight interpolation works for STFTL1SNRDBLoss.
    L1 weighting should make gradients more uniform compared to pure SNR.
    """
    torch.manual_seed(42)

    actuals = torch.tensor([[1.0] * 4096, [1.0] * 4096])
    estimates = actuals.clone()
    estimates[0] += 0.01
    estimates[1] += 0.5

    ratios = []
    for w in [0.0, 0.5, 1.0]:
        est = estimates.clone().requires_grad_(True)
        loss_fn = STFTL1SNRDBLoss("test", l1_weight=w, n_ffts=[512], hop_lengths=[128], win_lengths=[512])
        loss = loss_fn(est, actuals)
        loss.backward()
        ratio = (est.grad[0].abs().mean() / est.grad[1].abs().mean()).item()
        ratios.append(ratio)

    # L1 weighting should make gradients more uniform (ratio closer to 1)
    # Pure L1 (l1_weight=1.0) should have more uniform gradients than pure SNR (l1_weight=0.0)
    assert ratios[2] < ratios[0], \
        f"L1 weighting should make gradients more uniform: SNR ratio {ratios[0]} should be > L1 ratio {ratios[2]}"

    # All ratios should be > 1 (signal with larger error should have larger gradients)
    assert all(r > 1.0 for r in ratios), f"All gradient ratios should be > 1.0: {ratios}"