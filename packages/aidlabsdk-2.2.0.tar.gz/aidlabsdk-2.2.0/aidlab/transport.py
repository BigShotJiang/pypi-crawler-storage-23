from __future__ import annotations

from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol


@dataclass(frozen=True)
class DeviceInfo:
    address: str
    name: str | None = None
    metadata: Any = None


class AidlabTransport(Protocol):
    @property
    def mtu_size(self) -> int: ...

    async def connect(self) -> None: ...

    async def disconnect(self) -> None: ...

    async def read_char(self, uuid: str) -> bytes: ...

    async def write_char(self, uuid: str, data: bytes, response: bool = True) -> None: ...

    async def notifications(self, uuid: str) -> AsyncIterator[bytes]: ...

    async def disconnections(self) -> AsyncIterator[None]: ...


class AidlabScanner(Protocol):
    async def scan(self, timeout: float = 10.0) -> list[DeviceInfo]: ...


class AidlabTransportFactory(Protocol):
    def create(self, device: DeviceInfo) -> AidlabTransport: ...
