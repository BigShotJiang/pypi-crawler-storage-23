"""
Aidlab Python SDK
"""

from .activity_type import ActivityType
from .aidlab_manager import AidlabManager
from .body_position import BodyPosition
from .data_type import DataType
from .device import Device
from .device_delegate import DeviceDelegate
from .transport import AidlabScanner, AidlabTransport, AidlabTransportFactory, DeviceInfo
from .wear_state import WearState

try:
    from . import bleak_adapter as _bleak_adapter
except ImportError:
    _bleak_exports = []
else:
    BleakAidlabScanner = _bleak_adapter.BleakAidlabScanner
    BleakTransport = _bleak_adapter.BleakTransport
    BleakTransportFactory = _bleak_adapter.BleakTransportFactory
    _bleak_exports = ["BleakAidlabScanner", "BleakTransport", "BleakTransportFactory"]

__all__ = [
    "ActivityType",
    "AidlabManager",
    "AidlabScanner",
    "AidlabTransport",
    "AidlabTransportFactory",
    "BodyPosition",
    "DataType",
    "Device",
    "DeviceDelegate",
    "DeviceInfo",
    "WearState",
] + _bleak_exports
