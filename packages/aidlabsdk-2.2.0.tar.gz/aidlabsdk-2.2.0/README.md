Aidlab SDK simplifies the communication process with Aidlab and Aidmed One. The SDK also provides algorithms to manipulate received data so you don’t have to reinvent the wheel.

## Transport architecture

The Python SDK now supports two connection modes:

1. Default mode (Aidlab-managed BLE scanner + transport)
2. Custom mode (your own scanner/transport implementation)

### Default mode

```python
from aidlab import AidlabManager

devices = await AidlabManager().scan()
await devices[0].connect(delegate)
```

### Custom mode

```python
from aidlab import Device

device = Device(
    address="AA:BB:CC:DD:EE:FF",
    name="Aidlab 2",
    transport=my_transport,  # implements AidlabTransport
)
await device.connect(delegate)
```
