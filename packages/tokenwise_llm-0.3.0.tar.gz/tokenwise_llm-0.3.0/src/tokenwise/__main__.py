"""Allow running as `python -m tokenwise`."""

from tokenwise.cli import app

app()
