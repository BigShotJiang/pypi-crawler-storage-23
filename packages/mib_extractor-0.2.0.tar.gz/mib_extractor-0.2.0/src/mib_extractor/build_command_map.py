from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

from .telecommand_definition import Telecommand


def build_command_map_table(mib: object, apid: int) -> pd.DataFrame:
    """Build a serializable command table for one APID using CCF and CDF."""
    from .mib_reader import get_commands_by_apid

    return get_commands_by_apid(mib=mib, apid=apid)


def build_telecommands(mib: object, apid: int) -> list[Telecommand]:
    from .telecommand_loader import dataframe_to_telecommands

    command_table = build_command_map_table(mib=mib, apid=apid)
    return dataframe_to_telecommands(command_table)


def save_command_map_table(
    command_table: pd.DataFrame,
    output_file: Path,
    output_format: str,
) -> Path:
    """Persist command definition table in parquet or pickle format."""
    fmt = output_format.lower()
    if fmt not in {"parquet", "pickle"}:
        raise ValueError("Unsupported format. Use 'parquet' or 'pickle'.")

    target = Path(output_file).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "parquet":
        command_table.to_parquet(target, index=False)
    else:
        command_table.to_pickle(target)
    return target


def build_and_save_command_map(
    mib_folder: Path,
    apid: int,
    output_file: Path,
    output_format: str,
) -> Path:
    from .mib_reader import MibDb_Essential

    logger = logging.getLogger(__name__)
    mib = MibDb_Essential(mib_folder=mib_folder, log=logger)
    table = build_command_map_table(mib=mib, apid=apid)
    return save_command_map_table(
        command_table=table,
        output_file=output_file,
        output_format=output_format,
    )


def build_telecommands_from_mib(
    mib_folder: Path,
    apid: int,
) -> list[Telecommand]:
    from .mib_reader import MibDb_Essential

    logger = logging.getLogger(__name__)
    mib = MibDb_Essential(mib_folder=mib_folder, log=logger)
    return build_telecommands(mib=mib, apid=apid)
