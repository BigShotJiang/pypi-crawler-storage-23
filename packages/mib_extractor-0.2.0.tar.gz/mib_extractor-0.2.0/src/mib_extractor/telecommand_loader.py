from __future__ import annotations

from typing import Any

import pandas as pd

from .telecommand_definition import Telecommand, TelecommandParameter


_COMMAND_COLUMN_ALIASES: dict[str, list[str]] = {
    "command_name": ["CNAME", "command_name"],
    "description": ["DESCR_CCF", "DESCR", "description"],
    "description2": ["DESCR2", "description2"],
    "command_type": ["CTYPE", "command_type"],
    "critical": ["CRITICAL", "critical"],
    "packet_id": ["PKTID", "packet_id"],
    "service_type": ["TYPE", "service_type"],
    "service_subtype": ["STYPE", "service_subtype"],
    "apid": ["APID", "apid"],
    "number_of_parameters": ["NPARS", "number_of_parameters"],
    "plan": ["PLAN", "plan"],
    "exec_mode": ["EXEC", "exec_mode"],
    "ilscope": ["ILSCOPE", "ilscope"],
    "ilstage": ["ILSTAGE", "ilstage"],
    "subsystem": ["SUBSYS", "subsystem"],
    "high_priority": ["HIPRI", "high_priority"],
    "map_id": ["MAPID", "map_id"],
    "default_set": ["DEFSET", "default_set"],
    "rapid": ["RAPID", "rapid"],
    "ack": ["ACK", "ack"],
    "subschedule_id": ["SUBSCHEDID", "subschedule_id"],
}

_PARAMETER_COLUMN_ALIASES: dict[str, list[str]] = {
    "command_name": ["CNAME", "command_name"],
    "element_type": ["ELTYPE", "element_type"],
    "description": ["DESCR_CDF", "DESCR", "description"],
    "bit_length": ["ELLEN", "bit_length"],
    "bit_offset": ["BIT", "bit_offset"],
    "group_size": ["GRPSIZE", "group_size"],
    "parameter_name": ["PNAME", "parameter_name"],
    "interpretation": ["INTER", "interpretation"],
    "default_value": ["VALUE", "default_value"],
    "tmid": ["TMID", "tmid"],
}


def _read_field(row: dict[str, Any], aliases: dict[str, list[str]], logical_name: str) -> Any:
    for candidate in aliases[logical_name]:
        if candidate in row:
            return row[candidate]
    raise ValueError(f"Missing required column for field '{logical_name}'.")


def _as_int(value: Any, field: str, *, default: int = 0) -> int:
    if pd.isna(value):
        return default
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Field '{field}' must be an integer. Got: {value!r}") from exc


def _as_text(value: Any, default: str = "") -> str:
    if pd.isna(value):
        return default
    text = str(value).strip()
    return text if text else default


def _row_to_parameter(row: dict[str, Any]) -> TelecommandParameter:
    return TelecommandParameter(
        command_name=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "command_name")),
        element_type=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "element_type")),
        description=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "description")),
        bit_length=_as_int(_read_field(row, _PARAMETER_COLUMN_ALIASES, "bit_length"), "bit_length", default=0),
        bit_offset=_as_int(_read_field(row, _PARAMETER_COLUMN_ALIASES, "bit_offset"), "bit_offset", default=0),
        group_size=_as_int(_read_field(row, _PARAMETER_COLUMN_ALIASES, "group_size"), "group_size", default=0),
        parameter_name=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "parameter_name")),
        interpretation=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "interpretation")),
        default_value=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "default_value")),
        tmid=_as_text(_read_field(row, _PARAMETER_COLUMN_ALIASES, "tmid")),
    )


def dataframe_to_telecommands(
    dataframe: pd.DataFrame,
    *,
    sort_parameters_by_bit: bool = True,
) -> list[Telecommand]:
    if dataframe.empty:
        return []

    grouped = dataframe.groupby("CNAME", sort=True, dropna=False)
    telecommands: list[Telecommand] = []

    for _, command_rows in grouped:
        base_row = command_rows.iloc[0].to_dict()
        row_dicts = [series.to_dict() for _, series in command_rows.iterrows()]

        if sort_parameters_by_bit:
            row_dicts = sorted(
                row_dicts,
                key=lambda row: _as_int(_read_field(row, _PARAMETER_COLUMN_ALIASES, "bit_offset"), "bit_offset", default=0),
            )

        parameters = [_row_to_parameter(row) for row in row_dicts]

        telecommands.append(
            Telecommand(
                command_name=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "command_name")),
                description=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "description")),
                description2=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "description2")),
                command_type=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "command_type")),
                critical=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "critical"), default="N"),
                packet_id=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "packet_id")),
                service_type=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "service_type"), "service_type"),
                service_subtype=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "service_subtype"), "service_subtype"),
                apid=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "apid"), "apid"),
                number_of_parameters=_as_int(
                    _read_field(base_row, _COMMAND_COLUMN_ALIASES, "number_of_parameters"),
                    "number_of_parameters",
                ),
                plan=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "plan"), default="N"),
                exec_mode=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "exec_mode"), default="Y"),
                ilscope=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "ilscope"), default="N"),
                ilstage=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "ilstage"), default="C"),
                subsystem=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "subsystem"), "subsystem", default=0),
                high_priority=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "high_priority"), default="N"),
                map_id=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "map_id"), "map_id", default=0),
                default_set=_as_text(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "default_set")),
                rapid=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "rapid"), "rapid", default=0),
                ack=_as_int(_read_field(base_row, _COMMAND_COLUMN_ALIASES, "ack"), "ack", default=0),
                subschedule_id=_as_int(
                    _read_field(base_row, _COMMAND_COLUMN_ALIASES, "subschedule_id"),
                    "subschedule_id",
                    default=0,
                ),
                parameters=parameters,
            )
        )

    return telecommands
