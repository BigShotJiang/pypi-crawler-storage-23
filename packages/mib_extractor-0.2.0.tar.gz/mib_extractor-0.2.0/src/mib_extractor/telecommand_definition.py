from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .calibration_strategy import CalibrationStrategy


@dataclass(slots=True)
class TelecommandParameter:
    command_name: str
    element_type: str
    description: str
    bit_length: int
    bit_offset: int
    group_size: int
    parameter_name: str
    interpretation: str
    default_value: str
    tmid: str

    calibrator: Optional[CalibrationStrategy] = None

    value: int | float | str | None = None
    calibrated: int | float | str | None = None

    def reset_runtime(self) -> None:
        self.value = None
        self.calibrated = None

    def calibrate(self) -> None:
        if self.calibrator is None:
            self.calibrated = self.value
        else:
            self.calibrated = self.calibrator(self.value)  # type: ignore[arg-type]


@dataclass(slots=True)
class Telecommand:
    command_name: str
    description: str
    description2: str
    command_type: str
    critical: str
    packet_id: str
    service_type: int
    service_subtype: int
    apid: int
    number_of_parameters: int
    plan: str
    exec_mode: str
    ilscope: str
    ilstage: str
    subsystem: int
    high_priority: str
    map_id: int
    default_set: str
    rapid: int
    ack: int
    subschedule_id: int
    parameters: list[TelecommandParameter] = field(default_factory=list)

    calibrator: Optional[CalibrationStrategy] = None

    value: int | float | str | None = None
    calibrated: int | float | str | None = None

    def reset_runtime(self) -> None:
        self.value = None
        self.calibrated = None

    def calibrate(self) -> None:
        if self.calibrator is None:
            self.calibrated = self.value
        else:
            self.calibrated = self.calibrator(self.value)  # type: ignore[arg-type]
