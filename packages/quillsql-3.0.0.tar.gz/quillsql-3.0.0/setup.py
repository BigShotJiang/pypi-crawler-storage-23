from setuptools import setup, find_packages

setup(
    name="quillsql",
    version="3.0.0",
    packages=find_packages(),
    install_requires=[
        "psycopg[binary]",
        "psycopg-pool",
        "requests",
        "redis",
        "python-dotenv",
        "pytest",
        "google-cloud-bigquery",
        "google-auth",
    ],
    author="Quill",
    author_email="shawn@quill.co",
    description="Quill SDK for Python.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/quill-sql/quill-python",
)
