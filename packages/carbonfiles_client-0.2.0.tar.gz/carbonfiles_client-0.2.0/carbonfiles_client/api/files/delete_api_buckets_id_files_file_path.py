from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    id: str,
    file_path: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/buckets/{id}/files/{file_path}".format(id=quote(str(id), safe=""),file_path=quote(str(file_path), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ErrorResponse | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | ErrorResponse]:
    """ Delete file

     Auth: Bucket owner or admin. Permanently deletes a file from the bucket.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,
file_path=file_path,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Any | ErrorResponse | None:
    """ Delete file

     Auth: Bucket owner or admin. Permanently deletes a file from the bucket.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorResponse
     """


    return sync_detailed(
        id=id,
file_path=file_path,
client=client,

    ).parsed

async def asyncio_detailed(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Response[Any | ErrorResponse]:
    """ Delete file

     Auth: Bucket owner or admin. Permanently deletes a file from the bucket.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,
file_path=file_path,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Any | ErrorResponse | None:
    """ Delete file

     Auth: Bucket owner or admin. Permanently deletes a file from the bucket.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorResponse
     """


    return (await asyncio_detailed(
        id=id,
file_path=file_path,
client=client,

    )).parsed
