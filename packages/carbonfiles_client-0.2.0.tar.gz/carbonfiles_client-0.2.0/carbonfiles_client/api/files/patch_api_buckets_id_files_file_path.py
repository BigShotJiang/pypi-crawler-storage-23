from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.bucket_file import BucketFile
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    id: str,
    file_path: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/buckets/{id}/files/{file_path}".format(id=quote(str(id), safe=""),file_path=quote(str(file_path), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BucketFile | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = BucketFile.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if response.status_code == 416:
        response_416 = ErrorResponse.from_dict(response.json())



        return response_416

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BucketFile | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Response[BucketFile | ErrorResponse]:
    """ Patch file content

     Auth: Bucket owner, admin, or upload token (?token=). Writes to a byte range of an existing file
    using Content-Range, or appends with X-Append: true.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BucketFile | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,
file_path=file_path,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> BucketFile | ErrorResponse | None:
    """ Patch file content

     Auth: Bucket owner, admin, or upload token (?token=). Writes to a byte range of an existing file
    using Content-Range, or appends with X-Append: true.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BucketFile | ErrorResponse
     """


    return sync_detailed(
        id=id,
file_path=file_path,
client=client,

    ).parsed

async def asyncio_detailed(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> Response[BucketFile | ErrorResponse]:
    """ Patch file content

     Auth: Bucket owner, admin, or upload token (?token=). Writes to a byte range of an existing file
    using Content-Range, or appends with X-Append: true.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BucketFile | ErrorResponse]
     """


    kwargs = _get_kwargs(
        id=id,
file_path=file_path,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    file_path: str,
    *,
    client: AuthenticatedClient,

) -> BucketFile | ErrorResponse | None:
    """ Patch file content

     Auth: Bucket owner, admin, or upload token (?token=). Writes to a byte range of an existing file
    using Content-Range, or appends with X-Append: true.

    Args:
        id (str):
        file_path (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BucketFile | ErrorResponse
     """


    return (await asyncio_detailed(
        id=id,
file_path=file_path,
client=client,

    )).parsed
