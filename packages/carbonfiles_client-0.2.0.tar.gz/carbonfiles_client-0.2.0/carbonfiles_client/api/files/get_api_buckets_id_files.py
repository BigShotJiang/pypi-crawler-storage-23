from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.paginated_response_of_bucket_file import PaginatedResponseOfBucketFile
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    id: str,
    *,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_limit: int | str | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_offset: int | str | Unset
    if isinstance(offset, Unset):
        json_offset = UNSET
    else:
        json_offset = offset
    params["offset"] = json_offset

    params["sort"] = sort

    params["order"] = order


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/buckets/{id}/files".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | PaginatedResponseOfBucketFile | None:
    if response.status_code == 200:
        response_200 = PaginatedResponseOfBucketFile.from_dict(response.json())



        return response_200

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | PaginatedResponseOfBucketFile]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> Response[ErrorResponse | PaginatedResponseOfBucketFile]:
    """ List files in bucket

     Public. Returns a paginated list of files in the specified bucket.

    Args:
        id (str):
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PaginatedResponseOfBucketFile]
     """


    kwargs = _get_kwargs(
        id=id,
limit=limit,
offset=offset,
sort=sort,
order=order,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> ErrorResponse | PaginatedResponseOfBucketFile | None:
    """ List files in bucket

     Public. Returns a paginated list of files in the specified bucket.

    Args:
        id (str):
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PaginatedResponseOfBucketFile
     """


    return sync_detailed(
        id=id,
client=client,
limit=limit,
offset=offset,
sort=sort,
order=order,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> Response[ErrorResponse | PaginatedResponseOfBucketFile]:
    """ List files in bucket

     Public. Returns a paginated list of files in the specified bucket.

    Args:
        id (str):
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PaginatedResponseOfBucketFile]
     """


    kwargs = _get_kwargs(
        id=id,
limit=limit,
offset=offset,
sort=sort,
order=order,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> ErrorResponse | PaginatedResponseOfBucketFile | None:
    """ List files in bucket

     Public. Returns a paginated list of files in the specified bucket.

    Args:
        id (str):
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PaginatedResponseOfBucketFile
     """


    return (await asyncio_detailed(
        id=id,
client=client,
limit=limit,
offset=offset,
sort=sort,
order=order,

    )).parsed
