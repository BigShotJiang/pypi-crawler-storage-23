from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.error_response import ErrorResponse
from ...models.paginated_response_of_api_key_list_item import PaginatedResponseOfApiKeyListItem
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_limit: int | str | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_offset: int | str | Unset
    if isinstance(offset, Unset):
        json_offset = UNSET
    else:
        json_offset = offset
    params["offset"] = json_offset

    params["sort"] = sort

    params["order"] = order


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/keys",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | PaginatedResponseOfApiKeyListItem | None:
    if response.status_code == 200:
        response_200 = PaginatedResponseOfApiKeyListItem.from_dict(response.json())



        return response_200

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | PaginatedResponseOfApiKeyListItem]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> Response[ErrorResponse | PaginatedResponseOfApiKeyListItem]:
    """ List API keys

     Auth: Admin only. Returns a paginated list of all API keys (secrets are masked).

    Args:
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PaginatedResponseOfApiKeyListItem]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,
sort=sort,
order=order,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> ErrorResponse | PaginatedResponseOfApiKeyListItem | None:
    """ List API keys

     Auth: Admin only. Returns a paginated list of all API keys (secrets are masked).

    Args:
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PaginatedResponseOfApiKeyListItem
     """


    return sync_detailed(
        client=client,
limit=limit,
offset=offset,
sort=sort,
order=order,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> Response[ErrorResponse | PaginatedResponseOfApiKeyListItem]:
    """ List API keys

     Auth: Admin only. Returns a paginated list of all API keys (secrets are masked).

    Args:
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | PaginatedResponseOfApiKeyListItem]
     """


    kwargs = _get_kwargs(
        limit=limit,
offset=offset,
sort=sort,
order=order,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    limit: int | str | Unset = 50,
    offset: int | str | Unset = 0,
    sort: str | Unset = 'created_at',
    order: str | Unset = 'desc',

) -> ErrorResponse | PaginatedResponseOfApiKeyListItem | None:
    """ List API keys

     Auth: Admin only. Returns a paginated list of all API keys (secrets are masked).

    Args:
        limit (int | str | Unset):  Default: 50.
        offset (int | str | Unset):  Default: 0.
        sort (str | Unset):  Default: 'created_at'.
        order (str | Unset):  Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | PaginatedResponseOfApiKeyListItem
     """


    return (await asyncio_detailed(
        client=client,
limit=limit,
offset=offset,
sort=sort,
order=order,

    )).parsed
