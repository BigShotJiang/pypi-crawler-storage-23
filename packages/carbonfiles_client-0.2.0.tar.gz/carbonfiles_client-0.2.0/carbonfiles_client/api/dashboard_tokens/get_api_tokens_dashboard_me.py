from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.dashboard_token_info import DashboardTokenInfo
from ...models.error_response import ErrorResponse
from typing import cast



def _get_kwargs(
    
) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/tokens/dashboard/me",
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DashboardTokenInfo | ErrorResponse | None:
    if response.status_code == 200:
        response_200 = DashboardTokenInfo.from_dict(response.json())



        return response_200

    if response.status_code == 401:
        response_401 = ErrorResponse.from_dict(response.json())



        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DashboardTokenInfo | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,

) -> Response[DashboardTokenInfo | ErrorResponse]:
    """ Validate dashboard token

     Auth: Dashboard token (Bearer). Validates the current dashboard token and returns its metadata
    (expiry, issued at).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardTokenInfo | ErrorResponse]
     """


    kwargs = _get_kwargs(
        
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,

) -> DashboardTokenInfo | ErrorResponse | None:
    """ Validate dashboard token

     Auth: Dashboard token (Bearer). Validates the current dashboard token and returns its metadata
    (expiry, issued at).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardTokenInfo | ErrorResponse
     """


    return sync_detailed(
        client=client,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,

) -> Response[DashboardTokenInfo | ErrorResponse]:
    """ Validate dashboard token

     Auth: Dashboard token (Bearer). Validates the current dashboard token and returns its metadata
    (expiry, issued at).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardTokenInfo | ErrorResponse]
     """


    kwargs = _get_kwargs(
        
    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,

) -> DashboardTokenInfo | ErrorResponse | None:
    """ Validate dashboard token

     Auth: Dashboard token (Bearer). Validates the current dashboard token and returns its metadata
    (expiry, issued at).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardTokenInfo | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,

    )).parsed
