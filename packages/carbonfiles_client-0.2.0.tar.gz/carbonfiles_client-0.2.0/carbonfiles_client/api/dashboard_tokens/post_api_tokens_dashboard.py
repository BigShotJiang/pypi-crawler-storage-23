from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_dashboard_token_request import CreateDashboardTokenRequest
from ...models.dashboard_token_response import DashboardTokenResponse
from ...models.error_response import ErrorResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateDashboardTokenRequest | None | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/tokens/dashboard",
    }

    
    if isinstance(body, CreateDashboardTokenRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> DashboardTokenResponse | ErrorResponse | None:
    if response.status_code == 201:
        response_201 = DashboardTokenResponse.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[DashboardTokenResponse | ErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateDashboardTokenRequest | None | Unset = UNSET,

) -> Response[DashboardTokenResponse | ErrorResponse]:
    """ Create dashboard token

     Auth: Admin only. Creates a short-lived JWT token for dashboard access with optional custom expiry.

    Args:
        body (CreateDashboardTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardTokenResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateDashboardTokenRequest | None | Unset = UNSET,

) -> DashboardTokenResponse | ErrorResponse | None:
    """ Create dashboard token

     Auth: Admin only. Creates a short-lived JWT token for dashboard access with optional custom expiry.

    Args:
        body (CreateDashboardTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardTokenResponse | ErrorResponse
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateDashboardTokenRequest | None | Unset = UNSET,

) -> Response[DashboardTokenResponse | ErrorResponse]:
    """ Create dashboard token

     Auth: Admin only. Creates a short-lived JWT token for dashboard access with optional custom expiry.

    Args:
        body (CreateDashboardTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardTokenResponse | ErrorResponse]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateDashboardTokenRequest | None | Unset = UNSET,

) -> DashboardTokenResponse | ErrorResponse | None:
    """ Create dashboard token

     Auth: Admin only. Creates a short-lived JWT token for dashboard access with optional custom expiry.

    Args:
        body (CreateDashboardTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardTokenResponse | ErrorResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
