from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_upload_token_request import CreateUploadTokenRequest
from ...models.error_response import ErrorResponse
from ...models.upload_token_response import UploadTokenResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    id: str,
    *,
    body: CreateUploadTokenRequest | None | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/buckets/{id}/tokens".format(id=quote(str(id), safe=""),),
    }

    
    if isinstance(body, CreateUploadTokenRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ErrorResponse | UploadTokenResponse | None:
    if response.status_code == 201:
        response_201 = UploadTokenResponse.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = ErrorResponse.from_dict(response.json())



        return response_400

    if response.status_code == 403:
        response_403 = ErrorResponse.from_dict(response.json())



        return response_403

    if response.status_code == 404:
        response_404 = ErrorResponse.from_dict(response.json())



        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ErrorResponse | UploadTokenResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: CreateUploadTokenRequest | None | Unset = UNSET,

) -> Response[ErrorResponse | UploadTokenResponse]:
    """ Create upload token

     Auth: Bucket owner or admin. Creates a scoped upload token for a specific bucket with optional
    expiry and upload limit.

    Args:
        id (str):
        body (CreateUploadTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | UploadTokenResponse]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient,
    body: CreateUploadTokenRequest | None | Unset = UNSET,

) -> ErrorResponse | UploadTokenResponse | None:
    """ Create upload token

     Auth: Bucket owner or admin. Creates a scoped upload token for a specific bucket with optional
    expiry and upload limit.

    Args:
        id (str):
        body (CreateUploadTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | UploadTokenResponse
     """


    return sync_detailed(
        id=id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: CreateUploadTokenRequest | None | Unset = UNSET,

) -> Response[ErrorResponse | UploadTokenResponse]:
    """ Create upload token

     Auth: Bucket owner or admin. Creates a scoped upload token for a specific bucket with optional
    expiry and upload limit.

    Args:
        id (str):
        body (CreateUploadTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorResponse | UploadTokenResponse]
     """


    kwargs = _get_kwargs(
        id=id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
    body: CreateUploadTokenRequest | None | Unset = UNSET,

) -> ErrorResponse | UploadTokenResponse | None:
    """ Create upload token

     Auth: Bucket owner or admin. Creates a scoped upload token for a specific bucket with optional
    expiry and upload limit.

    Args:
        id (str):
        body (CreateUploadTokenRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorResponse | UploadTokenResponse
     """


    return (await asyncio_detailed(
        id=id,
client=client,
body=body,

    )).parsed
