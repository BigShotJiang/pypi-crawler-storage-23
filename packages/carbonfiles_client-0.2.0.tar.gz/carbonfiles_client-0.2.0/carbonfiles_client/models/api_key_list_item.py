from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="ApiKeyListItem")



@_attrs_define
class ApiKeyListItem:
    """ 
        Attributes:
            prefix (str):
            name (str):
            created_at (datetime.datetime | Unset):
            last_used_at (datetime.datetime | None | Unset):
            bucket_count (int | str | Unset):
            file_count (int | str | Unset):
            total_size (int | str | Unset):
     """

    prefix: str
    name: str
    created_at: datetime.datetime | Unset = UNSET
    last_used_at: datetime.datetime | None | Unset = UNSET
    bucket_count: int | str | Unset = UNSET
    file_count: int | str | Unset = UNSET
    total_size: int | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        prefix = self.prefix

        name = self.name

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        last_used_at: None | str | Unset
        if isinstance(self.last_used_at, Unset):
            last_used_at = UNSET
        elif isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        bucket_count: int | str | Unset
        if isinstance(self.bucket_count, Unset):
            bucket_count = UNSET
        else:
            bucket_count = self.bucket_count

        file_count: int | str | Unset
        if isinstance(self.file_count, Unset):
            file_count = UNSET
        else:
            file_count = self.file_count

        total_size: int | str | Unset
        if isinstance(self.total_size, Unset):
            total_size = UNSET
        else:
            total_size = self.total_size


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "prefix": prefix,
            "name": name,
        })
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if last_used_at is not UNSET:
            field_dict["last_used_at"] = last_used_at
        if bucket_count is not UNSET:
            field_dict["bucket_count"] = bucket_count
        if file_count is not UNSET:
            field_dict["file_count"] = file_count
        if total_size is not UNSET:
            field_dict["total_size"] = total_size

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        prefix = d.pop("prefix")

        name = d.pop("name")

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        def _parse_last_used_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_1 = isoparse(data)



                return last_used_at_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at", UNSET))


        def _parse_bucket_count(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        bucket_count = _parse_bucket_count(d.pop("bucket_count", UNSET))


        def _parse_file_count(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        file_count = _parse_file_count(d.pop("file_count", UNSET))


        def _parse_total_size(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_size = _parse_total_size(d.pop("total_size", UNSET))


        api_key_list_item = cls(
            prefix=prefix,
            name=name,
            created_at=created_at,
            last_used_at=last_used_at,
            bucket_count=bucket_count,
            file_count=file_count,
            total_size=total_size,
        )


        api_key_list_item.additional_properties = d
        return api_key_list_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
