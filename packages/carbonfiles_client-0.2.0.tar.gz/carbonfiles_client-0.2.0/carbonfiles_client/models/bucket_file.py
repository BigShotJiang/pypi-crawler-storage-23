from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="BucketFile")



@_attrs_define
class BucketFile:
    """ 
        Attributes:
            path (str):
            name (str):
            mime_type (str):
            size (int | str | Unset):
            short_code (None | str | Unset):
            short_url (None | str | Unset):
            created_at (datetime.datetime | Unset):
            updated_at (datetime.datetime | Unset):
     """

    path: str
    name: str
    mime_type: str
    size: int | str | Unset = UNSET
    short_code: None | str | Unset = UNSET
    short_url: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        path = self.path

        name = self.name

        mime_type = self.mime_type

        size: int | str | Unset
        if isinstance(self.size, Unset):
            size = UNSET
        else:
            size = self.size

        short_code: None | str | Unset
        if isinstance(self.short_code, Unset):
            short_code = UNSET
        else:
            short_code = self.short_code

        short_url: None | str | Unset
        if isinstance(self.short_url, Unset):
            short_url = UNSET
        else:
            short_url = self.short_url

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "path": path,
            "name": name,
            "mime_type": mime_type,
        })
        if size is not UNSET:
            field_dict["size"] = size
        if short_code is not UNSET:
            field_dict["short_code"] = short_code
        if short_url is not UNSET:
            field_dict["short_url"] = short_url
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        path = d.pop("path")

        name = d.pop("name")

        mime_type = d.pop("mime_type")

        def _parse_size(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        size = _parse_size(d.pop("size", UNSET))


        def _parse_short_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        short_code = _parse_short_code(d.pop("short_code", UNSET))


        def _parse_short_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        short_url = _parse_short_url(d.pop("short_url", UNSET))


        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at,  Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)




        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at,  Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)




        bucket_file = cls(
            path=path,
            name=name,
            mime_type=mime_type,
            size=size,
            short_code=short_code,
            short_url=short_url,
            created_at=created_at,
            updated_at=updated_at,
        )


        bucket_file.additional_properties = d
        return bucket_file

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
