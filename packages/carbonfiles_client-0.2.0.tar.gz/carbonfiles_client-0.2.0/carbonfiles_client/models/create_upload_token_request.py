from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateUploadTokenRequest")



@_attrs_define
class CreateUploadTokenRequest:
    """ 
        Attributes:
            expires_in (None | str | Unset):
            max_uploads (int | None | str | Unset):
     """

    expires_in: None | str | Unset = UNSET
    max_uploads: int | None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        expires_in: None | str | Unset
        if isinstance(self.expires_in, Unset):
            expires_in = UNSET
        else:
            expires_in = self.expires_in

        max_uploads: int | None | str | Unset
        if isinstance(self.max_uploads, Unset):
            max_uploads = UNSET
        else:
            max_uploads = self.max_uploads


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if expires_in is not UNSET:
            field_dict["expires_in"] = expires_in
        if max_uploads is not UNSET:
            field_dict["max_uploads"] = max_uploads

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_expires_in(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expires_in = _parse_expires_in(d.pop("expires_in", UNSET))


        def _parse_max_uploads(data: object) -> int | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | str | Unset, data)

        max_uploads = _parse_max_uploads(d.pop("max_uploads", UNSET))


        create_upload_token_request = cls(
            expires_in=expires_in,
            max_uploads=max_uploads,
        )


        create_upload_token_request.additional_properties = d
        return create_upload_token_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
