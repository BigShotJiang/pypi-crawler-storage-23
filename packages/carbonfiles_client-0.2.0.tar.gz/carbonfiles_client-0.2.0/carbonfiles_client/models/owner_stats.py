from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="OwnerStats")



@_attrs_define
class OwnerStats:
    """ 
        Attributes:
            owner (str):
            bucket_count (int | str | Unset):
            file_count (int | str | Unset):
            total_size (int | str | Unset):
     """

    owner: str
    bucket_count: int | str | Unset = UNSET
    file_count: int | str | Unset = UNSET
    total_size: int | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        owner = self.owner

        bucket_count: int | str | Unset
        if isinstance(self.bucket_count, Unset):
            bucket_count = UNSET
        else:
            bucket_count = self.bucket_count

        file_count: int | str | Unset
        if isinstance(self.file_count, Unset):
            file_count = UNSET
        else:
            file_count = self.file_count

        total_size: int | str | Unset
        if isinstance(self.total_size, Unset):
            total_size = UNSET
        else:
            total_size = self.total_size


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "owner": owner,
        })
        if bucket_count is not UNSET:
            field_dict["bucket_count"] = bucket_count
        if file_count is not UNSET:
            field_dict["file_count"] = file_count
        if total_size is not UNSET:
            field_dict["total_size"] = total_size

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        owner = d.pop("owner")

        def _parse_bucket_count(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        bucket_count = _parse_bucket_count(d.pop("bucket_count", UNSET))


        def _parse_file_count(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        file_count = _parse_file_count(d.pop("file_count", UNSET))


        def _parse_total_size(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_size = _parse_total_size(d.pop("total_size", UNSET))


        owner_stats = cls(
            owner=owner,
            bucket_count=bucket_count,
            file_count=file_count,
            total_size=total_size,
        )


        owner_stats.additional_properties = d
        return owner_stats

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
