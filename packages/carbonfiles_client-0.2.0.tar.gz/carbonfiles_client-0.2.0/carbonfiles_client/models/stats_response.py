from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.owner_stats import OwnerStats





T = TypeVar("T", bound="StatsResponse")



@_attrs_define
class StatsResponse:
    """ 
        Attributes:
            storage_by_owner (list[OwnerStats]):
            total_buckets (int | str | Unset):
            total_files (int | str | Unset):
            total_size (int | str | Unset):
            total_keys (int | str | Unset):
            total_downloads (int | str | Unset):
     """

    storage_by_owner: list[OwnerStats]
    total_buckets: int | str | Unset = UNSET
    total_files: int | str | Unset = UNSET
    total_size: int | str | Unset = UNSET
    total_keys: int | str | Unset = UNSET
    total_downloads: int | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.owner_stats import OwnerStats
        storage_by_owner = []
        for storage_by_owner_item_data in self.storage_by_owner:
            storage_by_owner_item = storage_by_owner_item_data.to_dict()
            storage_by_owner.append(storage_by_owner_item)



        total_buckets: int | str | Unset
        if isinstance(self.total_buckets, Unset):
            total_buckets = UNSET
        else:
            total_buckets = self.total_buckets

        total_files: int | str | Unset
        if isinstance(self.total_files, Unset):
            total_files = UNSET
        else:
            total_files = self.total_files

        total_size: int | str | Unset
        if isinstance(self.total_size, Unset):
            total_size = UNSET
        else:
            total_size = self.total_size

        total_keys: int | str | Unset
        if isinstance(self.total_keys, Unset):
            total_keys = UNSET
        else:
            total_keys = self.total_keys

        total_downloads: int | str | Unset
        if isinstance(self.total_downloads, Unset):
            total_downloads = UNSET
        else:
            total_downloads = self.total_downloads


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "storage_by_owner": storage_by_owner,
        })
        if total_buckets is not UNSET:
            field_dict["total_buckets"] = total_buckets
        if total_files is not UNSET:
            field_dict["total_files"] = total_files
        if total_size is not UNSET:
            field_dict["total_size"] = total_size
        if total_keys is not UNSET:
            field_dict["total_keys"] = total_keys
        if total_downloads is not UNSET:
            field_dict["total_downloads"] = total_downloads

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.owner_stats import OwnerStats
        d = dict(src_dict)
        storage_by_owner = []
        _storage_by_owner = d.pop("storage_by_owner")
        for storage_by_owner_item_data in (_storage_by_owner):
            storage_by_owner_item = OwnerStats.from_dict(storage_by_owner_item_data)



            storage_by_owner.append(storage_by_owner_item)


        def _parse_total_buckets(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_buckets = _parse_total_buckets(d.pop("total_buckets", UNSET))


        def _parse_total_files(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_files = _parse_total_files(d.pop("total_files", UNSET))


        def _parse_total_size(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_size = _parse_total_size(d.pop("total_size", UNSET))


        def _parse_total_keys(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_keys = _parse_total_keys(d.pop("total_keys", UNSET))


        def _parse_total_downloads(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total_downloads = _parse_total_downloads(d.pop("total_downloads", UNSET))


        stats_response = cls(
            storage_by_owner=storage_by_owner,
            total_buckets=total_buckets,
            total_files=total_files,
            total_size=total_size,
            total_keys=total_keys,
            total_downloads=total_downloads,
        )


        stats_response.additional_properties = d
        return stats_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
