from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="UploadTokenResponse")



@_attrs_define
class UploadTokenResponse:
    """ 
        Attributes:
            token (str):
            bucket_id (str):
            expires_at (datetime.datetime | Unset):
            max_uploads (int | None | str | Unset):
            uploads_used (int | str | Unset):
     """

    token: str
    bucket_id: str
    expires_at: datetime.datetime | Unset = UNSET
    max_uploads: int | None | str | Unset = UNSET
    uploads_used: int | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        token = self.token

        bucket_id = self.bucket_id

        expires_at: str | Unset = UNSET
        if not isinstance(self.expires_at, Unset):
            expires_at = self.expires_at.isoformat()

        max_uploads: int | None | str | Unset
        if isinstance(self.max_uploads, Unset):
            max_uploads = UNSET
        else:
            max_uploads = self.max_uploads

        uploads_used: int | str | Unset
        if isinstance(self.uploads_used, Unset):
            uploads_used = UNSET
        else:
            uploads_used = self.uploads_used


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "token": token,
            "bucket_id": bucket_id,
        })
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if max_uploads is not UNSET:
            field_dict["max_uploads"] = max_uploads
        if uploads_used is not UNSET:
            field_dict["uploads_used"] = uploads_used

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        token = d.pop("token")

        bucket_id = d.pop("bucket_id")

        _expires_at = d.pop("expires_at", UNSET)
        expires_at: datetime.datetime | Unset
        if isinstance(_expires_at,  Unset):
            expires_at = UNSET
        else:
            expires_at = isoparse(_expires_at)




        def _parse_max_uploads(data: object) -> int | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | str | Unset, data)

        max_uploads = _parse_max_uploads(d.pop("max_uploads", UNSET))


        def _parse_uploads_used(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        uploads_used = _parse_uploads_used(d.pop("uploads_used", UNSET))


        upload_token_response = cls(
            token=token,
            bucket_id=bucket_id,
            expires_at=expires_at,
            max_uploads=max_uploads,
            uploads_used=uploads_used,
        )


        upload_token_response.additional_properties = d
        return upload_token_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
