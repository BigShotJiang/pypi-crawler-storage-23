from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.bucket_file import BucketFile





T = TypeVar("T", bound="UploadResponse")



@_attrs_define
class UploadResponse:
    """ 
        Attributes:
            uploaded (list[BucketFile]):
     """

    uploaded: list[BucketFile]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bucket_file import BucketFile
        uploaded = []
        for uploaded_item_data in self.uploaded:
            uploaded_item = uploaded_item_data.to_dict()
            uploaded.append(uploaded_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "uploaded": uploaded,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bucket_file import BucketFile
        d = dict(src_dict)
        uploaded = []
        _uploaded = d.pop("uploaded")
        for uploaded_item_data in (_uploaded):
            uploaded_item = BucketFile.from_dict(uploaded_item_data)



            uploaded.append(uploaded_item)


        upload_response = cls(
            uploaded=uploaded,
        )


        upload_response.additional_properties = d
        return upload_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
