from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.bucket_file import BucketFile





T = TypeVar("T", bound="PaginatedResponseOfBucketFile")



@_attrs_define
class PaginatedResponseOfBucketFile:
    """ 
        Attributes:
            items (list[BucketFile]):
            total (int | str | Unset):
            limit (int | str | Unset):
            offset (int | str | Unset):
     """

    items: list[BucketFile]
    total: int | str | Unset = UNSET
    limit: int | str | Unset = UNSET
    offset: int | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bucket_file import BucketFile
        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        total: int | str | Unset
        if isinstance(self.total, Unset):
            total = UNSET
        else:
            total = self.total

        limit: int | str | Unset
        if isinstance(self.limit, Unset):
            limit = UNSET
        else:
            limit = self.limit

        offset: int | str | Unset
        if isinstance(self.offset, Unset):
            offset = UNSET
        else:
            offset = self.offset


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "items": items,
        })
        if total is not UNSET:
            field_dict["total"] = total
        if limit is not UNSET:
            field_dict["limit"] = limit
        if offset is not UNSET:
            field_dict["offset"] = offset

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bucket_file import BucketFile
        d = dict(src_dict)
        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = BucketFile.from_dict(items_item_data)



            items.append(items_item)


        def _parse_total(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        total = _parse_total(d.pop("total", UNSET))


        def _parse_limit(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        limit = _parse_limit(d.pop("limit", UNSET))


        def _parse_offset(data: object) -> int | str | Unset:
            if isinstance(data, Unset):
                return data
            return cast(int | str | Unset, data)

        offset = _parse_offset(d.pop("offset", UNSET))


        paginated_response_of_bucket_file = cls(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
        )


        paginated_response_of_bucket_file.additional_properties = d
        return paginated_response_of_bucket_file

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
