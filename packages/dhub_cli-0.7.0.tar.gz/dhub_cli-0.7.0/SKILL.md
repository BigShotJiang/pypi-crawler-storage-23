---
name: my-skill
description: "A skill"
---

# my-skill

Describe what this skill does and how the agent should use it.
