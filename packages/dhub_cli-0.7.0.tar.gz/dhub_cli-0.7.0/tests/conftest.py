"""Shared test fixtures for dhub client."""
