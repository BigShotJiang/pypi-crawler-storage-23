"""CLI module for qqtools"""
