#!/usr/bin/env python3
"""Test script to verify screenshot format functionality."""

import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

# Add src to path
sys.path.insert(0, 'src')

from screenshooter.modules.settings.settings_helper import save_settings
from screenshooter.modules.settings.models import AppSettings, ScreenshotSettings


def test_png_format():
    """Test that PNG format works correctly."""
    print("Testing PNG format...")

    # Set format to PNG
    settings = AppSettings()
    settings.screenshot.default_format = "png"
    save_settings(settings)

    # Import after setting format
    from screenshooter.modules.screenshot.config import ScreenshooterConfig

    with tempfile.TemporaryDirectory() as temp_dir:
        config = ScreenshooterConfig(
            client_name="TestClient",
            project_name="TestProject",
            screenshots_dir=temp_dir
        )

        # Mock mss to avoid actual screenshot
        with patch('mss.mss') as mock_mss:
            mock_sct = MagicMock()
            mock_monitor = MagicMock()
            mock_monitor.width = 1920
            mock_monitor.height = 1080
            mock_sct.monitors = [None, mock_monitor]  # mss uses 1-based indexing

            mock_screenshot = MagicMock()
            mock_screenshot.rgb = b'fake_rgb_data'
            mock_screenshot.size = (1920, 1080)
            mock_sct.grab.return_value = mock_screenshot

            mock_mss.return_value.__enter__.return_value = mock_sct

            # Mock mss.tools.to_png to create a real minimal PNG file
            def mock_to_png(rgb, size, output):
                # Create a minimal valid PNG file (1x1 pixel)
                from PIL import Image
                img = Image.new('RGB', (1, 1), color='red')
                img.save(output, 'PNG')

            with patch('mss.tools.to_png', side_effect=mock_to_png):
                success = config.take_screenshot("1", "test_display1_screen", 1)

                assert success, "Screenshot should succeed"
                assert config.screenshot_count == 1, "Screenshot count should be 1"

                # Debug: list all files in the screenshots directory
                print(f"Screenshots dir: {config.screenshots_dir_path}")
                if config.screenshots_dir_path.exists():
                    print("Files in screenshots dir:", list(config.screenshots_dir_path.iterdir()))

                # Check that PNG file was created (file uses current timestamp, not session start time)
                import glob
                png_files = list(config.screenshots_dir_path.glob("*.png"))
                assert len(png_files) == 1, f"Expected 1 PNG file, found {len(png_files)}: {png_files}"
                expected_file = png_files[0]
                print(f"Expected file: {expected_file}")
                print(f"File exists: {expected_file.exists()}")
                assert expected_file.exists(), f"PNG file should exist: {expected_file}"

                print(f"✓ PNG format test passed - created {expected_file}")


def test_jpg_format():
    """Test that JPG format works correctly."""
    print("Testing JPG format...")

    # Set format to JPG
    settings = AppSettings()
    settings.screenshot.default_format = "jpg"
    settings.screenshot.default_quality = 85
    save_settings(settings)

    # Import after setting format
    from screenshooter.modules.screenshot.config import ScreenshooterConfig

    with tempfile.TemporaryDirectory() as temp_dir:
        config = ScreenshooterConfig(
            client_name="TestClient",
            project_name="TestProject",
            screenshots_dir=temp_dir
        )

        # Mock mss to avoid actual screenshot
        with patch('mss.mss') as mock_mss:
            mock_sct = MagicMock()
            mock_monitor = MagicMock()
            mock_monitor.width = 1920
            mock_monitor.height = 1080
            mock_sct.monitors = [None, mock_monitor]  # mss uses 1-based indexing

            mock_screenshot = MagicMock()
            mock_screenshot.rgb = b'fake_rgb_data'
            mock_screenshot.size = (1920, 1080)
            mock_sct.grab.return_value = mock_screenshot

            mock_mss.return_value.__enter__.return_value = mock_sct

            # Mock mss.tools.to_png to create a real minimal PNG file
            def mock_to_png(rgb, size, output):
                # Create a minimal valid PNG file (1x1 pixel)
                from PIL import Image
                img = Image.new('RGB', (1, 1), color='red')
                img.save(output, 'PNG')

            with patch('mss.tools.to_png', side_effect=mock_to_png):
                success = config.take_screenshot("1", "test_display1_screen", 1)

                assert success, "Screenshot should succeed"
                assert config.screenshot_count == 1, "Screenshot count should be 1"

                # Check that JPG file was created (not PNG)
                jpg_files = list(config.screenshots_dir_path.glob("*.jpg"))
                assert len(jpg_files) == 1, f"Expected 1 JPG file, found {len(jpg_files)}: {jpg_files}"
                expected_file = jpg_files[0]

                # Check that temporary PNG file was cleaned up
                png_files = list(config.screenshots_dir_path.glob("*.png"))
                assert len(png_files) == 0, f"Temporary PNG file should be cleaned up, but found: {png_files}"

                print(f"✓ JPG format test passed - created {expected_file}")


if __name__ == "__main__":
    try:
        test_png_format()
        test_jpg_format()
        print("\n✅ All format tests passed!")
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
