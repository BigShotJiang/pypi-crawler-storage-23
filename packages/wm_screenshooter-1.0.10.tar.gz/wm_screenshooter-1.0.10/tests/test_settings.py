from screenshooter_mac.modules.settings.models import EmailSettings, ScreenshotSettings


def test_email_settings_defaults():
    """Test EmailSettings has correct default values."""
    settings = EmailSettings()
    assert settings.enabled is False
    assert settings.smtp_port == 587
    assert settings.connection_security == "TLS"

def test_screenshot_settings_validation():
    """Test ScreenshotSettings validates input correctly."""
    settings = ScreenshotSettings(default_quality=95)
    assert settings.default_quality == 95
    assert settings.default_format == "jpg"  # default value


def test_screenshot_settings_countdown_default():
    """Test ScreenshotSettings countdown_before_capture default value."""
    settings = ScreenshotSettings()
    assert settings.countdown_before_capture == 10  # default should be 10 seconds