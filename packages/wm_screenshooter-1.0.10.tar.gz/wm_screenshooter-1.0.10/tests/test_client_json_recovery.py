#!/usr/bin/env python3
"""Test script to verify client.json recovery functionality."""

import os
import sys
import tempfile
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from screenshooter.modules.screenshot.config import ScreenshooterConfig
from screenshooter.modules.settings.settings_helper import should_use_database, reload_settings
from screenshooter.modules.settings.models import AppSettings
from screenshooter.modules.settings.settings_helper import save_settings


def test_database_mode_recovery():
    """Test that client.json is created from database when missing in DB mode."""
    print("Testing database mode client.json recovery...")

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        # Set up a mock client.json path that doesn't exist
        client_name = "test_client"
        project_name = "test_project"

        # Create config (this should trigger the recovery logic)
        try:
            config = ScreenshooterConfig(
                client_name=client_name,
                project_name=project_name,
                screenshots_dir=temp_dir
            )

            # Check if client.json was created
            if config.client_info_file.exists():
                print("✓ client.json was successfully created from database")
                return True
            else:
                print("✗ client.json was not created")
                return False

        except SystemExit as e:
            if "Cannot continue without client.json" in str(e):
                print("✗ Unexpected exit in database mode")
                return False
            else:
                print(f"✓ Expected exit in log_file mode: {e}")
                return True


def test_project_session_json_creation():
    """Test that project.json and session.json are created properly."""
    print("Testing project.json and session.json creation...")

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        client_name = "test_client"
        project_name = "test_project"

        try:
            config = ScreenshooterConfig(
                client_name=client_name,
                project_name=project_name,
                screenshots_dir=temp_dir
            )

            # Check if project.json was created
            if config.project_info_file.exists():
                print("✓ project.json was successfully created")
                # Read and validate content
                import json
                with open(config.project_info_file, 'r') as f:
                    data = json.load(f)
                if data.get("project_name") == project_name and data.get("client_name") == client_name:
                    print("✓ project.json contains correct data")
                else:
                    print("✗ project.json contains incorrect data")
                    return False
            else:
                print("✗ project.json was not created")
                return False

            # Check if session.json was created
            if config.session_info_file.exists():
                print("✓ session.json was successfully created")
                # Read and validate content
                with open(config.session_info_file, 'r') as f:
                    data = json.load(f)
                if (data.get("project_name") == project_name and
                    data.get("client_name") == client_name and
                    data.get("session_start_time")):
                    print("✓ session.json contains correct data")
                else:
                    print("✗ session.json contains incorrect data")
                    return False
            else:
                print("✗ session.json was not created")
                return False

            return True

        except Exception as e:
            print(f"✗ Unexpected error: {e}")
            return False
        except Exception as e:
            print(f"✗ Unexpected error: {e}")
            return False


def test_project_session_json_creation():
    """Test that project.json and session.json are created properly."""
    print("Testing project.json and session.json creation...")

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        client_name = "test_client"
        project_name = "test_project"

        try:
            config = ScreenshooterConfig(
                client_name=client_name,
                project_name=project_name,
                screenshots_dir=temp_dir
            )

            # Check if project.json was created
            if config.project_info_file.exists():
                print("✓ project.json was successfully created")
                # Read and validate content
                import json
                with open(config.project_info_file, 'r') as f:
                    data = json.load(f)
                if data.get("project_name") == project_name and data.get("client_name") == client_name:
                    print("✓ project.json contains correct data")
                else:
                    print("✗ project.json contains incorrect data")
                    return False
            else:
                print("✗ project.json was not created")
                return False

            # Check if session.json was created
            if config.session_info_file.exists():
                print("✓ session.json was successfully created")
                # Read and validate content
                with open(config.session_info_file, 'r') as f:
                    data = json.load(f)
                if (data.get("project_name") == project_name and
                    data.get("client_name") == client_name and
                    data.get("session_start_time") and
                    "notes" not in data and "captions" not in data):  # Ensure no complex fields
                    print("✓ session.json contains correct basic data (no notes/captions)")
                else:
                    print("✗ session.json contains incorrect data or complex fields")
                    return False
            else:
                print("✗ session.json was not created")
                return False

            return True

        except Exception as e:
            print(f"✗ Unexpected error: {e}")
            return False


def test_log_file_mode_error():
    """Test that system exits when client.json is missing in log_file mode."""
    print("Testing log_file mode error handling...")

    # Temporarily change to log_files mode
    settings = save_settings(AppSettings(data_source="log_files"))
    reload_settings()

    try:
        # Create a temporary directory for testing
        with tempfile.TemporaryDirectory() as temp_dir:
            client_name = "test_client"
            project_name = "test_project"

            # Create config (this should trigger the error)
            try:
                config = ScreenshooterConfig(
                    client_name=client_name,
                    project_name=project_name,
                    screenshots_dir=temp_dir
                )
                print("✗ Expected SystemExit but didn't get one")
                return False

            except SystemExit as e:
                if "Cannot continue without client.json in log_file mode" in str(e):
                    print("✓ Correctly exited with error message in log_file mode")
                    return True
                else:
                    print(f"✗ Unexpected exit message: {e}")
                    return False
            except Exception as e:
                print(f"✗ Unexpected error type: {e}")
                return False

    finally:
        # Restore database mode
        settings = save_settings(AppSettings(data_source="database"))
        reload_settings()


def main():
    """Run the test."""
    print("Testing client.json recovery functionality...")
    print(f"Initial data source mode: {'database' if should_use_database() else 'log_files'}")

    # Test database mode
    db_success = test_database_mode_recovery()

    # Test log_file mode
    log_success = test_log_file_mode_error()

    # Restore database mode for project/session test
    settings = save_settings(AppSettings(data_source="database"))
    reload_settings()

    # Test project and session json creation
    json_success = test_project_session_json_creation()

    if db_success and log_success and json_success:
        print("\n✓ All tests passed!")
    else:
        print("\n✗ Some tests failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()
