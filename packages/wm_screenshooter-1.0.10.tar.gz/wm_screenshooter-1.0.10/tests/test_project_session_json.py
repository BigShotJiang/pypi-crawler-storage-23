#!/usr/bin/env python3
"""Test script to verify project.json and session.json creation with database mocking."""

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import Mock, patch

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

def test_with_database_mock():
    """Test project.json and session.json creation with mocked database."""
    print("Testing project.json and session.json creation with database mock...")

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        # Mock the database operations
        from unittest.mock import Mock, patch

        # Mock database client data
        mock_client = Mock()
        mock_client.id = 1
        mock_client.name = "TestClient"
        mock_client.directory_name = "testclient"
        mock_client.company_name = "Test Company"
        mock_client.contact_name = "Test Contact"
        mock_client.contact_email = "test@example.com"
        mock_client.pdf_password = ""
        mock_client.preferences = {}
        mock_client.updated_at = None

        # Mock database project data
        mock_project = Mock()
        mock_project.id = 1
        mock_project.name = "TestProject"
        mock_project.directory_name = "testproject"
        mock_project.active = True
        mock_project.archived_at = None
        mock_project.created_at = None
        mock_project.updated_at = None

        # Mock database session data
        mock_session = Mock()
        mock_session.id = 1
        mock_session.name = "2024-12-01_12-00-00"
        mock_session.start_time = None
        mock_session.end_time = None
        mock_session.duration_seconds = None
        mock_session.timer_mode = "manual"

        # Mock the database operations
        with patch('screenshooter.modules.database.DatabaseOperations') as mock_db_class:
            mock_db_ops = Mock()
            mock_db_class.return_value = mock_db_ops

            # Mock client lookup
            mock_db_ops.get_client_by_directory.return_value = mock_client
            mock_db_ops.get_client_by_name.return_value = mock_client

            # Mock project lookup
            mock_db_ops.get_project_by_directory.return_value = mock_project
            mock_db_ops.get_project_by_name.return_value = mock_project

            # Mock session lookup
            mock_db_ops.get_session_by_name.return_value = mock_session

            # Force database mode
            with patch('screenshooter.modules.settings.settings_helper.should_use_database', return_value=True):
                from screenshooter.modules.screenshot.config import ScreenshooterConfig

                try:
                    config = ScreenshooterConfig(
                        client_name="TestClient",
                        project_name="TestProject",
                        screenshots_dir=temp_dir
                    )

                    print(f"Client dir: {config.client_dir}")
                    print(f"Project dir: {config.project_dir}")
                    print(f"Session dir: {config.session_dir}")

                    # Check if client.json was created from database
                    if config.client_info_file.exists():
                        print("✓ client.json was created from database mock")
                        import json
                        with open(config.client_info_file, 'r') as f:
                            client_data = json.load(f)
                        print(f"  Client data: {client_data}")
                        if client_data.get("client_name") == "TestClient":
                            print("✓ client.json contains correct TestClient data")
                        else:
                            print("✗ client.json contains incorrect data")
                            return False
                    else:
                        print("✗ client.json was not created")
                        return False

                    # Check if project.json was created from database
                    if config.project_info_file.exists():
                        print("✓ project.json was created from database mock")
                        with open(config.project_info_file, 'r') as f:
                            project_data = json.load(f)
                        print(f"  Project data: {project_data}")
                        if (project_data.get("project_name") == "TestProject" and
                            project_data.get("client_name") == "TestClient"):
                            print("✓ project.json contains correct TestProject data")
                        else:
                            print("✗ project.json contains incorrect data")
                            return False
                    else:
                        print("✗ project.json was not created")
                        return False

                    # Check if session.json was created from database
                    if config.session_info_file.exists():
                        print("✓ session.json was created from database mock")
                        with open(config.session_info_file, 'r') as f:
                            session_data = json.load(f)
                        print(f"  Session data: {session_data}")
                        if (session_data.get("project_name") == "TestProject" and
                            session_data.get("client_name") == "TestClient" and
                            "session_start_time" in session_data):
                            print("✓ session.json contains correct session data")
                        else:
                            print("✗ session.json contains incorrect data")
                            return False
                    else:
                        print("✗ session.json was not created")
                        return False

                    return True

                except Exception as e:
                    print(f"✗ Unexpected error: {e}")
                    import traceback
                    traceback.print_exc()
                    return False

def test_filesystem_fallback():
    """Test that basic JSON files are created when database lookup fails."""
    print("\nTesting filesystem fallback when database fails...")

    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as temp_dir:
        # Mock database to return None (simulating missing data)
        with patch('screenshooter.modules.database.DatabaseOperations') as mock_db_class:
            mock_db_ops = Mock()
            mock_db_class.return_value = mock_db_ops

            # Mock all lookups to return None
            mock_db_ops.get_client_by_directory.return_value = None
            mock_db_ops.get_client_by_name.return_value = None
            mock_db_ops.get_project_by_directory.return_value = None
            mock_db_ops.get_project_by_name.return_value = None
            mock_db_ops.get_session_by_name.return_value = None

            # Force database mode
            with patch('screenshooter.modules.settings.settings_helper.should_use_database', return_value=True):
                from screenshooter.modules.screenshot.config import ScreenshooterConfig

                try:
                    config = ScreenshooterConfig(
                        client_name="TestClient",
                        project_name="TestProject",
                        screenshots_dir=temp_dir
                    )

                    # Check if basic JSON files were still created
                    if config.project_info_file.exists():
                        print("✓ project.json created with basic data (database failed)")
                        import json
                        with open(config.project_info_file, 'r') as f:
                            project_data = json.load(f)
                        print(f"  Basic project data: {project_data}")
                    else:
                        print("✗ project.json was not created even with fallback")
                        return False

                    if config.session_info_file.exists():
                        print("✓ session.json created with basic data (database failed)")
                        with open(config.session_info_file, 'r') as f:
                            session_data = json.load(f)
                        print(f"  Basic session data: {session_data}")
                    else:
                        print("✗ session.json was not created even with fallback")
                        return False

                    return True

                except Exception as e:
                    print(f"✗ Unexpected error in fallback test: {e}")
                    return False

if __name__ == "__main__":
    print("Running project.json and session.json creation tests...\n")

    success1 = test_with_database_mock()
    success2 = test_filesystem_fallback()

    if success1 and success2:
        print("\n✓ All tests passed!")
        print("✓ Creating a new project creates project.json")
        print("✓ Creating a new session creates session.json")
        print("✓ Database mode creates JSON files from DB data")
        print("✓ Fallback creates basic JSON files when DB fails")
    else:
        print("\n✗ Some tests failed!")
        sys.exit(1)
