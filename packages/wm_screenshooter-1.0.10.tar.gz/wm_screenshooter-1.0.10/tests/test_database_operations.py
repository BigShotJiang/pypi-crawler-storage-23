import pytest
from unittest.mock import Mock, patch, MagicMock
from screenshooter_mac.modules.database.operations import DatabaseOperations
from screenshooter_mac.modules.database.models import DatabaseClient
def test_create_client_success():
    """Test successful client creation with mocked database."""
    # Mock the database manager and cursor
    mock_db = Mock()
    mock_cursor = Mock()
    mock_cursor.lastrowid = 123
    mock_db.execute_query.return_value = mock_cursor
    
    with patch('screenshooter_mac.modules.database.operations.DatabaseManager', return_value=mock_db):
        ops = DatabaseOperations(mock_db)
        client = DatabaseClient(name="Test Client", directory_name="test_client")
        
        result = ops.create_client(client)
        
        assert result == 123
        mock_db.execute_query.assert_called_once()
        mock_db.commit.assert_called_once()
def test_create_client_failure_no_id():
    """Test client creation when database returns no ID."""
    mock_db = Mock()
    mock_cursor = Mock()
    mock_cursor.lastrowid = None
    mock_db.execute_query.return_value = mock_cursor
    
    with patch('screenshooter_mac.modules.database.operations.DatabaseManager', return_value=mock_db):
        ops = DatabaseOperations(mock_db)
        client = DatabaseClient(name="Test Client", directory_name="test_client")
        
        with pytest.raises(RuntimeError, match="Failed to create client: no ID returned"):
            ops.create_client(client)

def test_get_client_by_name_not_found():
    """Test getting non-existent client returns None."""
    mock_db = Mock()
    mock_cursor = Mock()
    mock_cursor.fetchone.return_value = None
    mock_db.execute_query.return_value = mock_cursor
    
    ops = DatabaseOperations(mock_db)
    result = ops.get_client_by_name("Nonexistent")
    
    assert result is None
    mock_db.execute_query.assert_called_with("SELECT * FROM clients WHERE name = ?", ("Nonexistent",))