"""Settings package for ScreenShooter Mac.

Exposes models and helpers without importing the CLI module to avoid
side effects during package import.
"""

# Export models and manager (no CLI imports here)
from screenshooter.modules.settings.models import (
    AppSettings,
    SettingsManager,
)

# Import helper functions
from screenshooter.modules.settings.settings_helper import (
    are_notifications_enabled,
    get_default_countdown,
    get_default_screenshot_format,
    get_default_screenshot_mode,
    get_default_screenshot_quality,
    get_default_screenshot_timer,
    get_email_settings,
    get_max_screenshot_age,
    get_notification_display_time,
    get_notification_sound_enabled,
    get_pdf_optimization_settings,
    get_pdf_page_size,
    get_s3_cloudflare_config,
    get_s3_custom_link_base_url,
    get_screenshots_dir,
    get_settings,
    is_auto_cleanup_enabled,
    is_auto_organize_enabled,
    is_s3_custom_link_enabled,
    reload_settings,
    should_notify_before_scheduled,
    should_optimize_pdf,
)

__all__ = [
    "AppSettings",
    "SettingsManager",
    "are_notifications_enabled",
    "get_default_countdown",
    "get_default_screenshot_format",
    "get_default_screenshot_mode",
    "get_default_screenshot_quality",
    "get_default_screenshot_timer",
    "get_email_settings",
    "get_max_screenshot_age",
    "get_notification_display_time",
    "get_notification_sound_enabled",
    "get_pdf_optimization_settings",
    "get_pdf_page_size",
    "get_s3_cloudflare_config",
    "get_s3_custom_link_base_url",
    "get_screenshots_dir",
    "get_settings",
    "is_auto_cleanup_enabled",
    "is_auto_organize_enabled",
    "is_s3_custom_link_enabled",
    "reload_settings",
    "should_notify_before_scheduled",
    "should_optimize_pdf",
]
