#!/usr/bin/env python3
"""Settings models and manager for ScreenShooter"""

import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, PrivateAttr

from screenshooter.modules.settings.logging_utils import (
    get_settings_logger,
    log_settings_event,
)

logger = logging.getLogger(__name__)


class EmailSettings(BaseModel):
    """Email settings model."""

    enabled: bool = False
    sender_email: str = ""
    sender_name: str = ""  # Display name used in From:, subject suffix, and sign-off
    smtp_server: str = ""
    smtp_port: int = 587
    connection_security: str = "TLS"  # Options: "TLS", "SSL", "None"
    username: str = ""  # May differ from sender_email for some providers
    password: str = ""  # Note: In a production app, consider more secure storage
    default_recipients: list[str] = Field(default_factory=list)  # Default recipients list
    recipient_type: str = "TO"  # Options: "TO", "CC", "BCC"
    # Whether to always include default recipients
    always_include_defaults: bool = True


class NotificationSettings(BaseModel):
    """Notification settings model."""

    enabled: bool = True
    sound: bool = True
    display_time: int = 5  # seconds
    notify_before_scheduled: bool = True  # New setting for pre-capture warning


class StorageSettings(BaseModel):
    """Storage settings model."""

    base_directory: str = Field(default_factory=lambda: os.path.expanduser("~/Work_Screenshots"))
    auto_organize: bool = True
    max_screenshot_age: int = 90  # days to keep screenshots before auto-cleanup
    auto_cleanup: bool = False


class ScreenshotSettings(BaseModel):
    """Screenshot settings model."""

    default_mode: str = "all"  # all, main, second, window
    default_timer: int | str = 15  # minutes or "manual"
    default_format: str = "jpg"  # jpg, png
    default_quality: int = 90  # 1-100 for jpg
    countdown_before_capture: int = 10  # seconds
    # PDF optimization settings
    optimize_pdf: bool = True  # Whether to optimize PDF reports
    pdf_image_quality: int = 85  # Quality for images in PDF reports (1-100)
    # Format for images in PDF reports (JPEG, PNG, WebP)
    pdf_image_format: str = "JPEG"
    pdf_max_dimension: int = 1500  # Maximum image dimension in PDFs
    pdf_use_thumbnails: bool = False  # Use thumbnails instead of full images in PDFs
    pdf_thumbnail_size: int = 800  # Size for thumbnails when using thumbnails
    pdf_compression: bool = True  # Whether to apply compression to the PDF
    pdf_page_size: str = "A4"  # PDF page size (A4, letter)
    on_display_disconnect: str = "prompt"  # Options: "prompt", "main", "close"


class S3Settings(BaseModel):
    """S3/R2 settings model."""

    enabled: bool = False
    endpoint_url: str = ""
    access_key_id: str = ""
    secret_access_key: str = ""  # Consider more secure storage for secrets
    bucket_name: str = ""
    region: str = "auto"
    url_expiration: int = 3600  # Default to 1 hour in seconds
    send_attachment: bool = True  # Whether to also send PDF as attachment
    path_prefix: str = ""  # Optional path prefix for organizing files in the bucket

    # Custom Link (Vanity URL) Settings
    use_custom_link: bool = False
    custom_link_base_url: str = ""  # E.g., https://link.yourdomain.com
    cloudflare_account_id: str = ""
    cloudflare_kv_namespace_id: str = ""
    cloudflare_api_token: str = ""  # Consider more secure storage for secrets


class UpgradeCheckSettings(BaseModel):
    """Upgrade check settings model."""

    enabled: bool = True
    check_frequency_days: int = 7  # How often to check for updates
    last_check: datetime | None = None  # When we last checked
    channel: Literal["release", "dev"] = "release"
    dev_branch: str = "main"
    dev_channel_prompted: bool = False
    skip_version: str | None = None  # Version user wants to skip reminders for
    # Pin to specific version (no auto notifications for newer)
    pin_version: str | None = None


class BackupSettings(BaseModel):
    """Backup settings model."""

    backup_directory: str = ""  # Custom backup directory (optional)
    password_enabled: bool = False  # Whether to enable password protection for backups
    # Backup password (stored in settings.json, handle file securely)
    password: str = ""
    verbosity: str = "summary"  # Backup verbosity: "off", "summary", or "full"
    upload_to_s3_enabled: bool = False  # Whether to upload backup archives to S3/R2
    s3_bucket_name: str = ""  # Optional backup-specific bucket override
    s3_path_prefix: str = "backups"  # Backup-specific prefix when uploading to S3/R2


class AppSettings(BaseModel):
    """Application settings model."""

    _load_failed: bool = PrivateAttr(default=False)
    email: EmailSettings = Field(default_factory=EmailSettings)
    notifications: NotificationSettings = Field(default_factory=NotificationSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    screenshot: ScreenshotSettings = Field(default_factory=ScreenshotSettings)
    s3: S3Settings = Field(default_factory=S3Settings)  # Add S3 settings
    upgrade_check: UpgradeCheckSettings = Field(default_factory=UpgradeCheckSettings)
    backup: BackupSettings = Field(default_factory=BackupSettings)
    data_source: str = Field(
        default="database",
        description="Data source for client and report information: 'log_files' or 'database'",
    )


class SettingsManager:
    """Settings management functionality."""

    def __init__(self) -> None:
        """Initialize settings manager with default config path."""

        self.config_dir = Path(os.path.expanduser("~/.config/screenshooter"))
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.settings_file = self.config_dir / "settings.json"
        self.logger = get_settings_logger(__name__)

    def load_settings(self) -> AppSettings:
        """Load settings from file or create defaults."""

        if self.settings_file.exists():
            try:
                settings = AppSettings.model_validate_json(self.settings_file.read_text())
                settings._load_failed = False
                return settings
            except Exception as exc:
                log_settings_event(
                    f"Failed to load settings from {self.settings_file}: {exc}",
                    level=logging.WARNING,
                    terminal_message=(
                        "[yellow]Warning: Settings could not be read. "
                        "Defaults will be used. See settings.log for details.[/yellow]"
                    ),
                    logger=self.logger,
                )
                settings = AppSettings()
                settings._load_failed = True
                return settings

        settings = AppSettings()
        settings._load_failed = False
        return settings

    def save_settings(
        self, settings: AppSettings, *, allow_overwrite_on_failed_load: bool = False
    ) -> None:
        """Save settings to file.

        Args:
            settings: Settings to persist.
            allow_overwrite_on_failed_load: Set True when the caller is intentionally
                recovering from a failed load (e.g., user reconfigured settings interactively).
        """

        load_failed = getattr(settings, "_load_failed", False)
        if load_failed and self.settings_file.exists() and not allow_overwrite_on_failed_load:
            log_settings_event(
                f"Refusing to overwrite {self.settings_file} because the last load failed.",
                level=logging.ERROR,
                terminal_message=(
                    "[red]Settings were not saved because the existing file failed to load. "
                    "Open the interactive settings menu to repair and save again.[/red]"
                ),
                logger=self.logger,
            )
            return

        if load_failed and allow_overwrite_on_failed_load:
            log_settings_event(
                f"Overwriting {self.settings_file} after a failed load (caller approved).",
                level=logging.WARNING,
                terminal_message=(
                    "[yellow]Saving settings after recovery from load failure.[/yellow]"
                ),
                logger=self.logger,
            )

        content = settings.model_dump_json(indent=2)
        temp_path = self.config_dir / ".settings.json.tmp"

        try:
            with open(temp_path, "w", encoding="utf-8") as temp_file:
                temp_file.write(content)
                temp_file.flush()
                os.fsync(temp_file.fileno())
            temp_path.replace(self.settings_file)
            settings._load_failed = False
            log_settings_event(
                f"Wrote settings to {self.settings_file}",
                logger=self.logger,
            )
        finally:
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except OSError:
                    log_settings_event(
                        f"Could not remove temporary settings file {temp_path}",
                        level=logging.DEBUG,
                        logger=self.logger,
                    )
