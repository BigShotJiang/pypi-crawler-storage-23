#!/usr/bin/env python3
"""Settings CLI for ScreenShooter Mac."""

from collections.abc import Callable
from pathlib import Path

import click
from rich.console import Console
from rich.prompt import Confirm, Prompt

from screenshooter.modules.backup import (
    handle_paused_backup_upload_interactive,
    perform_backup,
)
from screenshooter.modules.database.cli import interactive_database_menu

from .models import AppSettings, SettingsManager
from .settings_helper import reload_settings
from .settings_helper import save_settings as save_settings_helper

# Initialize rich console
console = Console()

# Models and SettingsManager are imported from .models to avoid CLI import side effects


class InteractiveSettingsManager(SettingsManager):
    """Extends SettingsManager with interactive editing and display routines."""

    def _prompt_on_new_line(self, prompt_text: str, **kwargs) -> str:
        """Prompt with choices/default on one line, input on a clean `> ` line below."""
        choices = kwargs.get("choices")
        default = kwargs.get("default")
        password = kwargs.get("password", False)

        prompt_text = prompt_text.strip()

        if choices:
            choices_str = "/".join(str(c) for c in choices)
            # Escape opening bracket to prevent rich from interpreting it as a style tag
            extra = f" \\[{choices_str}]"
            if default is not None:
                extra += f" ({default})"
            console.print(f"{prompt_text}{extra}:")
        elif default is not None:
            console.print(f"{prompt_text} ({default}):")
        else:
            console.print(f"{prompt_text}:")

        while True:
            if password:
                # Use Prompt.ask for password to handle masking, accept annoying colon for now or
                # fix later
                # Note: Prompt.ask always adds a separator (default ': ') unless configured
                # otherwise on Console
                # We'll live with '>: ' for password for now to keep it simple
                raw = Prompt.ask(">", password=True, show_default=False)
            else:
                raw = input("> ").strip()

            if not raw and default is not None:
                raw = str(default)

            if choices:
                # Allow flexibility in matching (string vs int)
                if raw in [str(c) for c in choices]:
                    return raw
                console.print(
                    f"[red]Invalid choice: {raw}. Please enter one of: "
                    f"{', '.join(str(c) for c in choices)}[/red]"
                )
                continue
            return raw

    def _confirm_on_new_line(self, prompt_text: str, *, default: bool = False) -> bool:
        """Print confirm question and collect y/n input on a new line with '>'."""
        # Build indicator: [y/n] (default)
        default_char = "y" if default else "n"
        # Escape [y/n] to prevent rich from interpreting it as a style tag
        console.print(f"{prompt_text} \\[y/n] ({default_char}):")

        while True:
            # Use standard input to avoid rich adding ': '
            answer = input("> ").strip().lower()
            if not answer:
                return default
            if answer in ("y", "n"):
                return answer == "y"
            console.print("[red]Please enter 'y' or 'n'.[/red]")

    def edit_email_settings(self, settings: AppSettings) -> None:
        """Edit email settings interactively."""
        console.print("\n[bold]Email Settings[/bold]")
        console.print("==============")

        settings.email.enabled = self._confirm_on_new_line(
            "Enable email functionality", default=settings.email.enabled
        )

        settings.email.sender_email = self._prompt_on_new_line(
            "Sender email address", default=settings.email.sender_email
        )
        settings.email.sender_name = self._prompt_on_new_line(
            "Sender display name (optional)", default=settings.email.sender_name
        )
        settings.email.smtp_server = self._prompt_on_new_line(
            "SMTP server", default=settings.email.smtp_server
        )
        settings.email.smtp_port = int(
            self._prompt_on_new_line("SMTP port", default=str(settings.email.smtp_port))
        )

        security_options = ["TLS", "SSL", "None"]
        settings.email.connection_security = self._prompt_on_new_line(
            "Connection security",
            choices=security_options,
            default=settings.email.connection_security,
        )

        settings.email.username = self._prompt_on_new_line(
            "SMTP username (may differ from sender email)",
            default=settings.email.username or settings.email.sender_email,
        )

        update_password = self._confirm_on_new_line(
            "Update password", default=bool(not settings.email.password)
        )
        if update_password:
            settings.email.password = self._prompt_on_new_line("SMTP password", password=True)

        # Ask for default recipients
        recipients_str = ", ".join(settings.email.default_recipients)
        new_recipients = self._prompt_on_new_line(
            "Default additional recipients (comma-separated, optional)", default=recipients_str
        )
        if new_recipients:
            settings.email.default_recipients = [
                email.strip() for email in new_recipients.split(",") if email.strip()
            ]
        else:
            settings.email.default_recipients = []

        # Set recipient type (TO, CC, BCC)
        if settings.email.default_recipients:
            recipient_types = ["TO", "CC", "BCC"]
            settings.email.recipient_type = self._prompt_on_new_line(
                "Default recipient type for additional recipients",
                choices=recipient_types,
                default=settings.email.recipient_type,
            )

            # Ask if default recipients should always be included
            settings.email.always_include_defaults = self._confirm_on_new_line(
                "Always include default recipients in emails",
                default=settings.email.always_include_defaults,
            )

    def edit_notification_settings(self, settings: AppSettings) -> None:
        """Edit notification settings interactively."""
        console.print("\n[bold]Notification Settings[/bold]")
        console.print("=====================")

        settings.notifications.enabled = self._confirm_on_new_line(
            "Enable notifications", default=settings.notifications.enabled
        )

        settings.notifications.sound = self._confirm_on_new_line(
            "Enable notification sounds", default=settings.notifications.sound
        )
        settings.notifications.display_time = int(
            self._prompt_on_new_line(
                "Notification display time (seconds)",
                default=str(settings.notifications.display_time),
            )
        )
        settings.notifications.notify_before_scheduled = self._confirm_on_new_line(
            "Notify ~30s before scheduled screenshots",
            default=settings.notifications.notify_before_scheduled,
        )

    def edit_storage_settings(self, settings: AppSettings) -> None:
        """Edit storage settings interactively."""
        console.print("\n[bold]Storage Settings[/bold]")
        console.print("================")

        settings.storage.base_directory = self._prompt_on_new_line(
            "Base directory for screenshots", default=settings.storage.base_directory
        )
        settings.storage.auto_organize = self._confirm_on_new_line(
            "Automatically organize screenshots by client/project",
            default=settings.storage.auto_organize,
        )
        settings.storage.auto_cleanup = self._confirm_on_new_line(
            "Enable automatic cleanup of old screenshots", default=settings.storage.auto_cleanup
        )

        if settings.storage.auto_cleanup:
            settings.storage.max_screenshot_age = int(
                self._prompt_on_new_line(
                    "Days to keep screenshots before cleanup",
                    default=str(settings.storage.max_screenshot_age),
                )
            )

    def edit_data_source_settings(self, settings: AppSettings) -> None:
        """Edit data source settings interactively."""
        console.print("\n[bold]Data Source Settings[/bold]")
        console.print("====================")

        data_source_options = ["log_files", "database"]
        current = settings.data_source

        console.print(f"Current data source: {current}")
        console.print("Options:")
        console.print("  log_files - Use traditional log files for client/project/session data")
        console.print("  database  - Use SQLite database for client/project/session data")

        choice = self._prompt_on_new_line(
            "Select data source", choices=data_source_options, default=current
        )

        settings.data_source = choice

        if choice == "database":
            console.print(
                "[yellow]Note: Database mode requires the database to be properly set "
                "up and migrated.[/yellow]"
            )
            console.print(
                "[yellow]If database operations fail, the system will fall back to log "
                "files.[/yellow]"
            )

    def edit_database_settings(self, settings: AppSettings) -> None:
        """Open the interactive database management menu."""
        console.print("\n[bold]Database Settings & Tools[/bold]")
        console.print("=============================")
        console.print(
            f"Current data source: {settings.data_source} (set in 'Edit data source settings')"
        )
        console.print(
            "[dim]You are now entering the database management menu. "
            "When you exit, you will return to Settings Management.[/dim]"
        )

        interactive_database_menu()

    def edit_screenshot_settings(self, settings: AppSettings) -> None:
        """Edit screenshot settings interactively."""
        console.print("\n[bold]Screenshot Settings[/bold]")
        console.print("===================")

        mode_options = ["all", "main", "second", "window"]
        settings.screenshot.default_mode = self._prompt_on_new_line(
            "Default screenshot mode",
            choices=mode_options,
            default=settings.screenshot.default_mode,
        )

        timer_input = self._prompt_on_new_line(
            "Default timer interval (minutes, or 'manual' for manual mode)",
            default=str(settings.screenshot.default_timer),
        )
        if timer_input.lower() == "manual":
            settings.screenshot.default_timer = "manual"
        else:
            settings.screenshot.default_timer = int(timer_input)

        format_options = ["jpg", "png"]
        settings.screenshot.default_format = self._prompt_on_new_line(
            "Default screenshot format",
            choices=format_options,
            default=settings.screenshot.default_format,
        )

        if settings.screenshot.default_format == "jpg":
            settings.screenshot.default_quality = int(
                self._prompt_on_new_line(
                    "Default JPEG quality (1-100)", default=str(settings.screenshot.default_quality)
                )
            )

        settings.screenshot.countdown_before_capture = int(
            self._prompt_on_new_line(
                "Countdown before capture (seconds, 0 to disable)",
                default=str(settings.screenshot.countdown_before_capture),
            )
        )

        # Add on_display_disconnect option
        disconnect_options = ["prompt", "main", "close"]
        settings.screenshot.on_display_disconnect = self._prompt_on_new_line(
            "On display disconnect (prompt, main, close)",
            choices=disconnect_options,
            default=settings.screenshot.on_display_disconnect,
        )

    def edit_pdf_optimization_settings(self, settings: AppSettings) -> None:
        """Edit PDF report optimization settings interactively."""
        console.print("\n[bold]PDF Report Optimization Settings[/bold]")
        console.print("[dim](These settings help reduce the file size of PDF reports)[/dim]")

        settings.screenshot.optimize_pdf = self._confirm_on_new_line(
            "Optimize PDF reports by default", default=settings.screenshot.optimize_pdf
        )

        if settings.screenshot.optimize_pdf:
            # Image quality
            settings.screenshot.pdf_image_quality = int(
                self._prompt_on_new_line(
                    "Image quality (1-100, lower = smaller file)",
                    default=str(settings.screenshot.pdf_image_quality),
                )
            )

            # Image format
            format_options = ["JPEG", "PNG", "WebP"]
            settings.screenshot.pdf_image_format = self._prompt_on_new_line(
                "Image format in PDFs",
                choices=format_options,
                default=settings.screenshot.pdf_image_format,
            )

            # Max dimension
            settings.screenshot.pdf_max_dimension = int(
                self._prompt_on_new_line(
                    "Maximum image dimension in pixels",
                    default=str(settings.screenshot.pdf_max_dimension),
                )
            )

            # Use thumbnails
            settings.screenshot.pdf_use_thumbnails = self._confirm_on_new_line(
                "Use thumbnails instead of full-size images",
                default=settings.screenshot.pdf_use_thumbnails,
            )

            if settings.screenshot.pdf_use_thumbnails:
                settings.screenshot.pdf_thumbnail_size = int(
                    self._prompt_on_new_line(
                        "Thumbnail size in pixels",
                        default=str(settings.screenshot.pdf_thumbnail_size),
                    )
                )

            # PDF compression
            settings.screenshot.pdf_compression = self._confirm_on_new_line(
                "Apply PDF compression", default=settings.screenshot.pdf_compression
            )

            # PDF page size
            page_size_options = ["A4", "letter"]
            settings.screenshot.pdf_page_size = self._prompt_on_new_line(
                "Default PDF page size",
                choices=page_size_options,
                default=settings.screenshot.pdf_page_size,
            )

    def edit_s3_settings(self, settings: AppSettings) -> None:
        """Edit S3/R2 settings interactively."""
        console.print("\n[bold]S3/R2 Settings[/bold]")
        console.print("=============")

        settings.s3.enabled = self._confirm_on_new_line(
            "Enable S3/R2 functionality", default=settings.s3.enabled
        )

        settings.s3.endpoint_url = self._prompt_on_new_line(
            "S3/R2 endpoint URL", default=settings.s3.endpoint_url or ""
        )
        settings.s3.access_key_id = self._prompt_on_new_line(
            "Access Key ID", default=settings.s3.access_key_id or ""
        )
        # Prompt for Secret Key
        update_secret_key = self._confirm_on_new_line(
            "Update S3/R2 Secret Access Key?", default=bool(not settings.s3.secret_access_key)
        )
        if update_secret_key:
            settings.s3.secret_access_key = self._prompt_on_new_line(
                "Secret Access Key", password=True
            )
        elif not settings.s3.secret_access_key:
            console.print("[yellow]Warning: S3 Secret Access Key is not set.[/yellow]")

        settings.s3.bucket_name = self._prompt_on_new_line(
            "Bucket name", default=settings.s3.bucket_name or ""
        )
        settings.s3.region = self._prompt_on_new_line(
            "Region", default=settings.s3.region or "auto"
        )

        # Map for converting user input to seconds
        expiration_choices = {"1h": 3600, "1d": 86400, "3d": 259200}
        expiration_map_rev = {
            v: k for k, v in expiration_choices.items()
        }  # Reverse map for display

        # Determine current display value
        current_display = expiration_map_rev.get(
            settings.s3.url_expiration, str(settings.s3.url_expiration)
        )
        if current_display not in expiration_choices:
            current_display = "1h"  # Default if current value isn't a standard choice

        # Get user choice
        user_choice = self._prompt_on_new_line(
            "Presigned URL expiration time",
            choices=list(expiration_choices.keys()),
            default=current_display,
        )
        settings.s3.url_expiration = expiration_choices[user_choice]

        settings.s3.path_prefix = self._prompt_on_new_line(
            "Path prefix (e.g., 'reports/' or 'clients/', optional)",
            default=settings.s3.path_prefix or "",
        )
        settings.s3.send_attachment = self._confirm_on_new_line(
            "Also send PDF as email attachment when using S3/R2?",
            default=settings.s3.send_attachment,
        )

        # --- Custom Link Settings ---
        console.print("\n[bold cyan]Custom Link (Vanity URL via Cloudflare Worker)[/bold cyan]")
        settings.s3.use_custom_link = self._confirm_on_new_line(
            "Enable custom domain links (requires Cloudflare setup)",
            default=settings.s3.use_custom_link,
        )

        if settings.s3.use_custom_link:
            settings.s3.custom_link_base_url = self._prompt_on_new_line(
                "Custom link base URL (e.g., https://link.yourdomain.com)",
                default=settings.s3.custom_link_base_url or "",
            ).rstrip("/")  # Remove trailing slash if present

            settings.s3.cloudflare_account_id = self._prompt_on_new_line(
                "Cloudflare Account ID", default=settings.s3.cloudflare_account_id or ""
            )
            settings.s3.cloudflare_kv_namespace_id = self._prompt_on_new_line(
                "Cloudflare KV Namespace ID",
                default=settings.s3.cloudflare_kv_namespace_id or "",
            )

            # Prompt for Cloudflare API Token
            update_cf_token = self._confirm_on_new_line(
                (
                    "Update Cloudflare API Token? [yellow](Ensure token has KV Write "
                    "permissions)[/yellow]"
                ),
                default=bool(not settings.s3.cloudflare_api_token),
            )
            if update_cf_token:
                settings.s3.cloudflare_api_token = self._prompt_on_new_line(
                    "Cloudflare API Token", password=True
                )
            elif not settings.s3.cloudflare_api_token:
                console.print(
                    "[yellow]Warning: Cloudflare API Token is not set. Custom links "
                    "will fail.[/yellow]"
                )

            # Add a check for base URL format
            if settings.s3.custom_link_base_url and not settings.s3.custom_link_base_url.startswith(
                ("http://", "https://")
            ):
                console.print(
                    "[yellow]Warning: Custom link base URL should start with http:// or https://[/yellow]"
                )

    def edit_backup_settings(self, settings: AppSettings) -> None:
        """Backup helper from settings menu (mirror of CLI backup flow)."""
        console.print("\n[bold]Backup Settings[/bold]")
        console.print("=================")

        default_backup_dir, effective_dir, configured_dir = self._get_backup_paths(settings)
        self._print_backup_preview(settings, effective_dir)

        action = self._prompt_on_new_line(
            "\nRun backup now with these settings or edit them first?",
            choices=["y", "e", "n"],
            default="y",
        )
        console.print("")

        if action == "n":
            console.print("[dim]Backup cancelled.[/dim]")
            return
        if action == "y":
            self._run_backup_now(settings)
            return

        self._edit_backup_configuration(settings, configured_dir, effective_dir, default_backup_dir)
        self._print_backup_summary(settings, default_backup_dir)
        if self._confirm_on_new_line(
            "\nRun a backup now with these updated settings?", default=False
        ):
            self._run_backup_now(settings, include_settings=True)

    def display_settings(self, settings: AppSettings) -> None:
        """Display current settings."""
        console.print("\n[bold]Current Settings[/bold]")
        console.print("================")
        self._display_email_settings(settings)
        self._display_notification_settings(settings)
        self._display_storage_settings(settings)
        self._display_data_source_settings(settings)
        self._display_screenshot_settings(settings)
        self._display_pdf_optimization_settings(settings)
        self._display_s3_settings(settings)

    def _get_backup_paths(self, settings: AppSettings) -> tuple[Path, Path, str]:
        """Return default, effective, and configured backup directories."""
        default_backup_dir = Path(settings.storage.base_directory).expanduser() / "backups"
        configured_dir = settings.backup.backup_directory.strip()
        effective_dir = Path(configured_dir).expanduser() if configured_dir else default_backup_dir
        return default_backup_dir, effective_dir, configured_dir

    def _print_backup_preview(self, settings: AppSettings, effective_dir: Path) -> None:
        """Print backup configuration preview."""
        encryption_enabled = bool(settings.backup.password_enabled and settings.backup.password)
        upload_to_s3_enabled = bool(getattr(settings.backup, "upload_to_s3_enabled", False))
        console.print("\n[bold]Backup Configuration Preview[/bold]")
        console.print("===============================")
        console.print(f"Backup directory: {effective_dir}")
        console.print(f"Password protection: {'Enabled' if encryption_enabled else 'Disabled'}")
        console.print(f"Backup verbosity: {settings.backup.verbosity}")
        console.print(f"S3 backup upload: {'Enabled' if upload_to_s3_enabled else 'Disabled'}")
        if upload_to_s3_enabled:
            console.print(f"S3 backup location: {self._backup_s3_location_text(settings)}")

    def _run_backup_now(self, settings: AppSettings, *, include_settings: bool = False) -> None:
        """Prompt for backup type and run backup command."""
        if handle_paused_backup_upload_interactive(
            lambda question, choices, default: self._prompt_on_new_line(
                question,
                choices=choices,
                default=default,
            ),
            console_instance=console,
        ):
            return

        backup_type = self._prompt_on_new_line(
            "Select backup type",
            choices=["settings", "db", "all"],
            default="all",
        )
        try:
            if include_settings:
                zip_path = perform_backup(
                    backup_type,
                    verbosity=settings.backup.verbosity,
                    settings=settings,
                )
            else:
                zip_path = perform_backup(backup_type, verbosity=settings.backup.verbosity)
            console.print(f"[green]Backup created:[/green] {zip_path}")
        except Exception as e:
            console.print(f"[bold red]Backup failed:[/bold red] {e}")

    def _edit_backup_configuration(
        self,
        settings: AppSettings,
        configured_dir: str,
        effective_dir: Path,
        default_backup_dir: Path,
    ) -> None:
        """Edit backup settings interactively."""
        console.print("[bold]Edit Backup Settings[/bold]\n-----------------------")
        console.print(
            "\n[yellow]Note:[/yellow] Backup passwords are stored in settings.json. "
            "Ensure the file permissions on ~/.config/screenshooter are secure."
        )
        new_dir = self._prompt_on_new_line(
            "Backup directory (leave blank to use default)",
            default=configured_dir or str(effective_dir),
        ).strip()
        settings.backup.backup_directory = (
            "" if not new_dir or new_dir == str(default_backup_dir) else new_dir
        )
        self._update_backup_password(settings)
        self._update_backup_verbosity(settings)
        self._update_backup_s3_configuration(settings)

    def _update_backup_password(self, settings: AppSettings) -> None:
        """Update backup password and encryption toggle."""
        if self._confirm_on_new_line("Update backup password?", default=False):
            settings.backup.password = self._prompt_on_new_line(
                "Enter new backup password (leave blank for none)",
                password=True,
            )
        if settings.backup.password:
            settings.backup.password_enabled = self._confirm_on_new_line(
                "Enable password protection for backup ZIP files?",
                default=settings.backup.password_enabled,
            )
            return
        settings.backup.password_enabled = False
        console.print(
            "[dim]No backup password set; backups will be created without encryption.[/dim]"
        )

    def _update_backup_verbosity(self, settings: AppSettings) -> None:
        """Update backup verbosity setting."""
        verbosity_options = ["off", "summary", "full"]
        current_verbosity = settings.backup.verbosity or "full"
        default_verbosity = current_verbosity if current_verbosity in verbosity_options else "full"
        settings.backup.verbosity = self._prompt_on_new_line(
            "Backup verbosity (off = minimal, summary = per client/project, full = per file)",
            choices=verbosity_options,
            default=default_verbosity,
        )

    def _update_backup_s3_configuration(self, settings: AppSettings) -> None:
        """Update backup S3 upload settings."""
        upload_enabled = self._confirm_on_new_line(
            "Upload backup ZIP files to S3/R2 after local backup?",
            default=bool(getattr(settings.backup, "upload_to_s3_enabled", False)),
        )
        settings.backup.upload_to_s3_enabled = upload_enabled

        if not upload_enabled:
            return

        main_bucket = settings.s3.bucket_name.strip()
        if main_bucket:
            console.print(
                f"[dim]Main S3 bucket: {main_bucket} "
                "(used when backup override is blank).[/dim]"
            )
        else:
            console.print(
                "[yellow]Main S3 bucket is not set in S3/R2 settings. "
                "Set a backup bucket override or configure main S3 bucket.[/yellow]"
            )

        settings.backup.s3_bucket_name = self._prompt_on_new_line(
            "Backup S3 bucket override (leave blank to use main S3 bucket)",
            default=str(getattr(settings.backup, "s3_bucket_name", "") or ""),
        ).strip()
        settings.backup.s3_path_prefix = (
            self._prompt_on_new_line(
                "Backup S3 path prefix (used when uploading backup archives)",
                default=str(getattr(settings.backup, "s3_path_prefix", "backups") or "backups"),
            ).strip()
            or "backups"
        )

        if not settings.s3.enabled:
            console.print(
                "[yellow]Warning: S3/R2 is disabled in global S3 settings. "
                "Backup uploads will be skipped until enabled.[/yellow]"
            )

        if settings.backup.password_enabled and settings.backup.password:
            return

        console.print(
            "[yellow]S3 backup upload requires backup password protection. "
            "Please set and enable a backup password now.[/yellow]"
        )
        self._update_backup_password(settings)
        if not (settings.backup.password_enabled and settings.backup.password):
            console.print(
                "[yellow]Password protection is still disabled. S3 backup upload will fail "
                "until password protection is enabled.[/yellow]"
            )

    def _print_backup_summary(self, settings: AppSettings, default_backup_dir: Path) -> None:
        """Print backup summary after edits."""
        console.print("\n[bold cyan]Summary:[/bold cyan]")
        console.print(f"Backup directory: {settings.backup.backup_directory or default_backup_dir}")
        password_status = (
            "Enabled"
            if settings.backup.password_enabled and settings.backup.password
            else "Disabled"
        )
        console.print(f"Password protection: {password_status}")
        console.print(f"Backup verbosity: {settings.backup.verbosity}")
        upload_to_s3_enabled = bool(getattr(settings.backup, "upload_to_s3_enabled", False))
        console.print(f"S3 backup upload: {'Enabled' if upload_to_s3_enabled else 'Disabled'}")
        if upload_to_s3_enabled:
            console.print(f"S3 backup location: {self._backup_s3_location_text(settings)}")

    def _backup_s3_location_text(self, settings: AppSettings) -> str:
        """Render effective backup upload location for display."""
        backup_bucket = str(getattr(settings.backup, "s3_bucket_name", "") or "").strip()
        effective_bucket = backup_bucket or settings.s3.bucket_name or "(main bucket not set)"
        backup_prefix = str(
            getattr(settings.backup, "s3_path_prefix", "backups") or "backups"
        ).strip()
        effective_prefix = backup_prefix or "backups"
        return f"{effective_bucket}/{effective_prefix}"

    def _display_email_settings(self, settings: AppSettings) -> None:
        """Display email settings section."""
        console.print("\n[bold cyan]Email Settings:[/bold cyan]")
        console.print(f"Enabled: {'Yes' if settings.email.enabled else 'No'}")
        if not settings.email.enabled:
            return
        console.print(f"Sender: {settings.email.sender_email}")
        if settings.email.sender_name:
            console.print(f"Sender Name: {settings.email.sender_name}")
        console.print(f"SMTP Server: {settings.email.smtp_server}")
        console.print(f"SMTP Port: {settings.email.smtp_port}")
        console.print(f"Connection Security: {settings.email.connection_security}")
        console.print(f"Username: {settings.email.username}")
        console.print(f"Password: {'*' * 8 if settings.email.password else 'Not set'}")
        if settings.email.default_recipients:
            console.print(f"Default Recipients: {', '.join(settings.email.default_recipients)}")
            console.print(f"Recipient Type: {settings.email.recipient_type}")
            include_defaults = "Yes" if settings.email.always_include_defaults else "No"
            console.print(f"Always Include Defaults: {include_defaults}")

    def _display_notification_settings(self, settings: AppSettings) -> None:
        """Display notification settings section."""
        console.print("\n[bold cyan]Notification Settings:[/bold cyan]")
        console.print(f"Enabled: {'Yes' if settings.notifications.enabled else 'No'}")
        if not settings.notifications.enabled:
            return
        console.print(f"Sound: {'Yes' if settings.notifications.sound else 'No'}")
        console.print(f"Display Time: {settings.notifications.display_time} seconds")
        notify_flag = "Yes" if settings.notifications.notify_before_scheduled else "No"
        console.print(f"Notify Before Scheduled: {notify_flag}")

    def _display_storage_settings(self, settings: AppSettings) -> None:
        """Display storage settings section."""
        console.print("\n[bold cyan]Storage Settings:[/bold cyan]")
        console.print(f"Base Directory: {settings.storage.base_directory}")
        console.print(f"Auto-Organize: {'Yes' if settings.storage.auto_organize else 'No'}")
        console.print(f"Auto-Cleanup: {'Yes' if settings.storage.auto_cleanup else 'No'}")
        if settings.storage.auto_cleanup:
            console.print(f"Max Screenshot Age: {settings.storage.max_screenshot_age} days")

    def _display_data_source_settings(self, settings: AppSettings) -> None:
        """Display data source settings section."""
        console.print("\n[bold cyan]Data Source Settings:[/bold cyan]")
        console.print(f"Data Source: {settings.data_source}")
        description = (
            "Use database for client/project/session data"
            if settings.data_source == "database"
            else "Use log files for client/project/session data"
        )
        console.print(f"Description: {description}")

    def _display_screenshot_settings(self, settings: AppSettings) -> None:
        """Display screenshot settings section."""
        console.print("\n[bold cyan]Screenshot Settings:[/bold cyan]")
        console.print(f"Default Mode: {settings.screenshot.default_mode}")
        timer_display = (
            "manual mode"
            if settings.screenshot.default_timer == "manual"
            else f"{settings.screenshot.default_timer} minutes"
        )
        console.print(f"Default Timer: {timer_display}")
        console.print(f"Default Format: {settings.screenshot.default_format}")
        if settings.screenshot.default_format == "jpg":
            console.print(f"Default Quality: {settings.screenshot.default_quality}")
        console.print(f"Countdown: {settings.screenshot.countdown_before_capture} seconds")
        console.print(f"On Display Disconnect: {settings.screenshot.on_display_disconnect}")

    def _display_pdf_optimization_settings(self, settings: AppSettings) -> None:
        """Display PDF optimization settings section."""
        console.print("\n[bold cyan]PDF Report Optimization:[/bold cyan]")
        console.print(f"Optimize PDFs: {'Yes' if settings.screenshot.optimize_pdf else 'No'}")
        if not settings.screenshot.optimize_pdf:
            return
        console.print(f"Image Quality: {settings.screenshot.pdf_image_quality}")
        console.print(f"Image Format: {settings.screenshot.pdf_image_format}")
        console.print(f"Max Image Dimension: {settings.screenshot.pdf_max_dimension} pixels")
        console.print(
            f"Use Thumbnails: {'Yes' if settings.screenshot.pdf_use_thumbnails else 'No'}"
        )
        if settings.screenshot.pdf_use_thumbnails:
            console.print(f"Thumbnail Size: {settings.screenshot.pdf_thumbnail_size} pixels")
        console.print(f"PDF Compression: {'Yes' if settings.screenshot.pdf_compression else 'No'}")
        console.print(f"PDF Page Size: {settings.screenshot.pdf_page_size}")

    def _display_s3_settings(self, settings: AppSettings) -> None:
        """Display S3 and custom-link settings sections."""
        console.print("\n[bold cyan]S3/R2 Settings:[/bold cyan]")
        console.print(f"Enabled: {'Yes' if settings.s3.enabled else 'No'}")
        if not settings.s3.enabled:
            return
        console.print(f"Endpoint URL: {settings.s3.endpoint_url or 'Not set'}")
        console.print(f"Access Key ID: {settings.s3.access_key_id or 'Not set'}")
        console.print(
            f"Secret Access Key: {'*' * 8 if settings.s3.secret_access_key else 'Not set'}"
        )
        console.print(f"Bucket Name: {settings.s3.bucket_name or 'Not set'}")
        console.print(f"Region: {settings.s3.region}")
        expiration_map = {3600: "1 hour", 86400: "1 day", 259200: "3 days"}
        expiration_display = expiration_map.get(
            settings.s3.url_expiration,
            f"{settings.s3.url_expiration} seconds",
        )
        console.print(f"Presigned URL Expiration: {expiration_display}")
        console.print(f"Path Prefix: {settings.s3.path_prefix or 'None'}")
        console.print(f"Send Attachment: {'Yes' if settings.s3.send_attachment else 'No'}")

        console.print("\n[bold cyan]Custom Link (Vanity URL):[/bold cyan]")
        console.print(f"Enabled: {'Yes' if settings.s3.use_custom_link else 'No'}")
        if not settings.s3.use_custom_link:
            return
        console.print(f"Base URL: {settings.s3.custom_link_base_url or 'Not set'}")
        console.print(f"Cloudflare Account ID: {settings.s3.cloudflare_account_id or 'Not set'}")
        console.print(
            f"Cloudflare KV Namespace ID: {settings.s3.cloudflare_kv_namespace_id or 'Not set'}"
        )
        api_token_display = "*" * 8 if settings.s3.cloudflare_api_token else "Not set"
        console.print(f"Cloudflare API Token: {api_token_display}")
        if settings.s3.cloudflare_api_token or settings.s3.secret_access_key:
            console.print(
                "[dim yellow]Note: API keys/tokens are stored in settings.json. "
                "Ensure file permissions are secure.[/dim yellow]"
            )

    def edit_upgrade_settings(self, settings: AppSettings) -> None:
        """Edit upgrade check settings interactively."""
        console.print("\n[bold]Upgrade Notification Settings[/bold]")
        console.print("==============================")
        console.print("[dim]Current settings:[/dim]")

        # Show current status
        console.print(
            f"Upgrade checks enabled: {'Yes' if settings.upgrade_check.enabled else 'No'}"
        )
        console.print(
            f"Check frequency: every {settings.upgrade_check.check_frequency_days} day(s)"
        )
        if settings.upgrade_check.last_check:
            console.print(
                f"Last checked: {settings.upgrade_check.last_check.strftime('%Y-%m-%d %H:%M:%S')}"
            )
        else:
            console.print("Last checked: Never")

        if settings.upgrade_check.pin_version:
            console.print(f"Pinned to max version: {settings.upgrade_check.pin_version}")
        else:
            console.print("Pinned to max version: None")

        if settings.upgrade_check.skip_version:
            console.print(
                f"Skipping notifications for version: {settings.upgrade_check.skip_version}"
            )
        else:
            console.print("Skipping notifications for version: None")

        console.print(
            "\n[dim]Update settings below (press Enter at each prompt to keep the "
            "current value).[/dim]"
        )

        # Enable/disable automatic checks
        settings.upgrade_check.enabled = self._confirm_on_new_line(
            "Enable automatic upgrade checks",
            default=settings.upgrade_check.enabled,
        )

        # Check frequency
        settings.upgrade_check.check_frequency_days = int(
            Prompt.ask(
                "Days between automatic checks",
                default=str(settings.upgrade_check.check_frequency_days),
            )
        )

        # Configure skip version
        current_skip = settings.upgrade_check.skip_version or ""
        new_skip = Prompt.ask(
            "Skip notifications for version (leave blank to clear, e.g. v1.0.x)",
            default=current_skip,
        ).strip()

        if not new_skip:
            settings.upgrade_check.skip_version = None
        else:
            settings.upgrade_check.skip_version = new_skip

        # Configure pin version
        current_pin = settings.upgrade_check.pin_version or ""
        new_pin = Prompt.ask(
            "Pin to maximum version for automatic notifications (leave blank for none)",
            default=current_pin,
        ).strip()

        if not new_pin:
            settings.upgrade_check.pin_version = None
        else:
            settings.upgrade_check.pin_version = new_pin


def interactive_settings() -> None:
    """Interactive settings management interface."""
    manager = InteractiveSettingsManager()
    settings = manager.load_settings()
    option_pages = [
        [
            "Email Settings",
            "Notification Settings",
            "Storage Settings",
            "Data Source Settings",
            "Database Settings & Tools",
            "Screenshot Settings",
            "PDF Report Optimization Settings",
            "S3/R2 Settings",
        ],
        [
            "Upgrade Settings",
            "Backup Settings",
        ],
    ]
    total_pages = len(option_pages)
    current_page = 0

    while True:
        options = option_pages[current_page]
        _render_settings_menu(options, current_page=current_page, total_pages=total_pages)

        extra_choices: list[str] = []
        nav_hints: list[str] = []
        if current_page < total_pages - 1:
            extra_choices.append("n")
            nav_hints.append("'n' for next page")
        if current_page > 0:
            extra_choices.append("p")
            nav_hints.append("'p' for previous page")
        nav_hint_text = f", {', '.join(nav_hints)}" if nav_hints else ""

        choice = manager._prompt_on_new_line(
            (
                "\nSelect an option (or 'b' to go back, 's' to save, "
                f"'e' to exit without saving{nav_hint_text})"
            ),
            choices=[str(i) for i in range(1, len(options) + 1)] + ["b", "s", "e", *extra_choices],
            default="1",
        )
        if choice == "n":
            current_page += 1
            continue
        if choice == "p":
            current_page -= 1
            continue

        if _handle_menu_control(choice, manager, settings):
            break
        handlers = _settings_handlers_for_page(manager, current_page)
        handler = handlers.get(choice)
        if handler is None:
            continue
        handler(settings)
        input("\nPress Enter to continue...")


def _render_settings_menu(options: list[str], *, current_page: int, total_pages: int) -> None:
    """Render settings options menu."""
    console.print(
        f"\n[bold]Settings Management (Page {current_page + 1}/{total_pages})[/bold]"
    )
    console.print("=================================")
    console.print("(Enter 'b' at any prompt to go back to the previous menu)")
    console.print("\nOptions:")
    for index, option in enumerate(options, 1):
        console.print(f"{index}. {option}")
    if current_page < total_pages - 1:
        console.print("n. Next Page")
    if current_page > 0:
        console.print("p. Previous Page")


def _settings_handlers_for_page(
    manager: InteractiveSettingsManager,
    page: int,
) -> dict[str, Callable[[AppSettings], None]]:
    """Map page-local menu choices to settings editor handlers."""
    if page == 0:
        return {
            "1": manager.edit_email_settings,
            "2": manager.edit_notification_settings,
            "3": manager.edit_storage_settings,
            "4": manager.edit_data_source_settings,
            "5": manager.edit_database_settings,
            "6": manager.edit_screenshot_settings,
            "7": manager.edit_pdf_optimization_settings,
            "8": manager.edit_s3_settings,
        }
    if page == 1:
        return {
            "1": manager.edit_upgrade_settings,
            "2": manager.edit_backup_settings,
        }
    return {}


def _handle_menu_control(
    choice: str,
    manager: InteractiveSettingsManager,
    settings: AppSettings,
) -> bool:
    """Handle control actions. Returns True when menu should exit."""
    if choice == "b":
        if manager._confirm_on_new_line("[yellow]Exit settings without saving changes?[/yellow]"):
            console.print("[yellow]Returning to main menu without saving.[/yellow]")
            return True
        return False

    if choice == "s":
        save_settings_helper(settings, allow_overwrite_on_failed_load=True)
        reload_settings()
        console.print("[green]Settings saved. Exiting settings menu.[/green]")
        return True

    if choice != "e":
        return False

    if manager._confirm_on_new_line(
        "[yellow]Are you sure you want to exit without saving?[/yellow]"
    ):
        console.print("[yellow]Exiting without saving changes.[/yellow]")
        return True
    return False


@click.command()
@click.option("--reset", is_flag=True, help="Reset settings to defaults")
@click.option("--export", help="Export settings to a JSON file")
@click.option("--import-file", help="Import settings from a JSON file")
def main(reset: bool, export: str | None, import_file: str | None) -> None:
    """Settings management for ScreenShooter Mac."""
    manager = SettingsManager()

    if reset:
        if Confirm.ask("[yellow]Are you sure you want to reset all settings to defaults?[/yellow]"):
            save_settings_helper(AppSettings())
            reload_settings()
            console.print("[green]Settings reset to defaults.[/green]")
        return

    if export:
        settings = manager.load_settings()
        export_path = Path(export)
        try:
            export_path.write_text(settings.model_dump_json(indent=2))
            console.print(f"[green]Settings exported to {export_path}[/green]")
        except Exception as e:
            console.print(f"[bold red]Error exporting settings: {e}[/bold red]")
        return

    if import_file:
        import_path = Path(import_file)
        if not import_path.exists():
            console.print(f"[bold red]Import file not found: {import_path}[/bold red]")
            return

        try:
            settings = AppSettings.model_validate_json(import_path.read_text())
            save_settings_helper(settings)
            reload_settings()
            console.print(f"[green]Settings imported from {import_path}[/green]")
        except Exception as e:
            console.print(f"[bold red]Error importing settings: {e}[/bold red]")
        return

    # Interactive mode
    interactive_settings()


if __name__ == "__main__":
    main()
