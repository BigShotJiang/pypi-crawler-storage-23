#!/usr/bin/env python3
"""Client models for ScreenShooter Mac."""

from datetime import datetime

from pydantic import BaseModel, Field


class ClientInfo(BaseModel):
    """Client information model."""

    client_name: str
    directory_name: str  # Filesystem directory name
    archived_at: str = ""
    company_name: str = ""
    contact_name: str = ""
    contact_email: str = ""
    pdf_password: str = ""  # Password for PDF encryption
    preferences: dict[str, str] = Field(
        default_factory=lambda: {
            "screenshot_delivery": "local",
            "notification_preferences": "all",
            "reporting_frequency": "none",
            "pdf_security": "none",  # Options: none, password
            "page_size": "A4",  # Options: A4, letter
        }
    )
    last_updated: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
