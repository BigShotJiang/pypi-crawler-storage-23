#!/usr/bin/env python3
"""PDF generation methods for the ReportGenerator class."""

import logging
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from reportlab.lib.units import inch
from reportlab.platypus import KeepTogether, PageBreak, Paragraph, Spacer, Table, TableStyle

from screenshooter.modules.reports.pdf.components import (
    add_report_title,
    add_section_header,
    add_subsection_header,
)
from screenshooter.modules.reports.pdf.helper import (
    ImageOptimizationOptions,
    ScreenshotRenderContext,
    add_screenshot,
    create_pdf_document,
    get_pdf_styles,
)
from screenshooter.modules.reports.pdf.tables import (
    SessionSummaryData,
    add_client_info_table,
    add_session_summary_table,
)
from screenshooter.modules.reports.pdf.utils import handle_image_relocations

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_generation")


@dataclass
class EventRenderContext:
    """Context for rendering chronological session events."""

    story: list
    session_log: object
    screenshots_dir: Path
    report_generator: object
    styles: dict
    relocation_log: list
    page_break_between_sets: bool


def _resolve_pdf_password(report_generator) -> str | None:
    """Resolve optional PDF password from client preferences."""
    if (
        report_generator.client_info
        and report_generator.client_info.preferences.get("pdf_security") == "password"
        and report_generator.client_info.pdf_password
    ):
        report_generator.log_entry(
            "Applying password protection to PDF", level="info", suppress_logger=True
        )
        return report_generator.client_info.pdf_password
    return None


def _compute_note_count(session_log) -> int:
    """Compute total note count including captions and session note."""
    note_count = len(session_log.notes)
    note_count += len(getattr(session_log, "captions", {}))
    note_count += len(getattr(session_log, "set_captions", {}))
    if session_log.session_note:
        note_count += 1
    note_count += sum(
        1
        for event in getattr(session_log, "chronological_events", [])
        if event.get("type") == "caption"
    )
    return note_count


def _collect_screenshot_indices(session_log) -> list[int]:
    """Collect chronological-event indexes for screenshot events."""
    return [
        index
        for index, event in enumerate(session_log.chronological_events)
        if event["type"] == "screenshot"
    ]


def _is_last_screenshot_in_set(
    event_index: int,
    set_id,
    session_log,
    screenshot_indices: list[int],
) -> bool:
    """Return True when the screenshot event is the last in its set."""
    if event_index not in screenshot_indices:
        return False

    next_screenshot_idx = None
    for idx in screenshot_indices:
        if idx > event_index:
            next_screenshot_idx = idx
            break
    if next_screenshot_idx is None:
        return True
    return session_log.chronological_events[next_screenshot_idx]["set_id"] != set_id


def _append_set_caption_if_present(story, session_log, current_set, styles) -> None:
    """Append set caption directly under a completed set when available."""
    set_captions = getattr(session_log, "set_captions", {})
    if not set_captions or not current_set:
        return

    try:
        set_id_int = int(current_set)
    except Exception:
        return
    if set_id_int not in set_captions:
        return

    _, set_caption = set_captions[set_id_int]
    story.append(Paragraph(f"Caption: {set_caption}", styles["Caption"]))
    story.append(Spacer(1, 0.1 * inch))


def _build_image_options(report_generator) -> ImageOptimizationOptions:
    """Build image optimization options from report generator settings."""
    return ImageOptimizationOptions(
        image_quality=report_generator.image_quality,
        image_format=report_generator.image_format,
        max_dimension=report_generator.max_dimension,
        use_thumbnails=report_generator.use_thumbnails,
        thumbnail_size=report_generator.thumbnail_size,
        debug=report_generator.image_search_debug
        if hasattr(report_generator, "image_search_debug")
        else report_generator.debug,
    )


def _render_chronological_events(context: EventRenderContext) -> None:
    """Render chronological session events (screenshots, notes, captions)."""
    story = context.story
    session_log = context.session_log
    screenshots_dir = context.screenshots_dir
    report_generator = context.report_generator
    styles = context.styles
    relocation_log = context.relocation_log
    page_break_between_sets = context.page_break_between_sets

    current_set = None
    screenshot_count = 0
    screenshot_indices = _collect_screenshot_indices(session_log)
    image_options = _build_image_options(report_generator)

    for idx, event in enumerate(session_log.chronological_events):
        if event["type"] == "screenshot":
            screenshot_count += 1
            set_id = event["set_id"]
            screenshot_block = []

            if set_id != current_set:
                if current_set is not None:
                    if page_break_between_sets:
                        story.append(PageBreak())
                    else:
                        story.append(Spacer(1, 0.3 * inch))
                current_set = set_id
                if set_id:
                    screenshot_block.append(Paragraph(f"Set #{set_id}", styles["Heading3Bold"]))
                    screenshot_block.append(Spacer(1, 0.1 * inch))

            screenshot_data = session_log.screenshots[event["index"]]
            add_screenshot(
                target_story=screenshot_block,
                screenshot_data=screenshot_data,
                screenshot_num=screenshot_count,
                context=ScreenshotRenderContext(
                    screenshots_dir=screenshots_dir,
                    captions=session_log.captions,
                    options=image_options,
                    styles=styles,
                    temp_files=report_generator.temp_files,
                    client_base_dir=report_generator.client_dir,
                    report_relocations=True,
                    relocation_log=relocation_log,
                    project_dir=report_generator.project_dir,
                ),
            )
            story.append(KeepTogether(screenshot_block))

            if _is_last_screenshot_in_set(idx, set_id, session_log, screenshot_indices):
                _append_set_caption_if_present(story, session_log, current_set, styles)
            continue

        if event["type"] == "note":
            story.append(Paragraph(f"Note at {event['timestamp']}:", styles["Heading3Bold"]))
            story.append(Paragraph(event["content"], styles["Note"]))
            story.append(Spacer(1, 0.2 * inch))
            continue

        if event["type"] == "caption":
            story.append(Paragraph(f"Caption: {event['content']}", styles["Caption"]))
            story.append(Spacer(1, 0.2 * inch))


def _build_pdf_with_logging(report_generator, doc, story) -> Path:
    """Build PDF and log success or error details."""
    try:
        doc.build(story)
        report_generator.log_entry(
            f"PDF report generated successfully: {report_generator.pdf_file}",
            terminal_message="",
        )
        return report_generator.pdf_file
    except Exception as e:
        error_msg = f"Error building PDF: {e}"
        report_generator.log_entry(error_msg, level="error")
        if report_generator.debug:
            report_generator.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
        raise


def generate_single_session_pdf(report_generator) -> Path:
    """Generate PDF report for a single session.

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    if not report_generator.session_log:
        error_msg = "No session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    relocation_log = []
    project_name = (
        report_generator.project_name or report_generator.screenshots_dir.parent.parent.name
    )
    session_date = report_generator.session_date or report_generator.screenshots_dir.parent.name
    report_title = f"{project_name} - {session_date}"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_Session_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename
    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    pdf_password = _resolve_pdf_password(report_generator)
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
    )
    styles = get_pdf_styles()
    story = []

    add_report_title(story, "Screenshot Session Report", styles)
    add_section_header(story, report_title, styles)
    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    add_section_header(story, "Session Summary", styles)
    if report_generator.session_log.session_start and report_generator.session_log.session_end:
        note_count = _compute_note_count(report_generator.session_log)
        add_session_summary_table(
            story=story,
            summary=SessionSummaryData(
                session_start=report_generator.session_log.session_start,
                session_end=report_generator.session_log.session_end,
                session_duration=report_generator.session_log.session_duration,
                screenshot_count=len(report_generator.session_log.screenshots),
                note_count=note_count,
            ),
            styles=styles,
        )

    if report_generator.session_log.session_note:
        add_section_header(story, "Session Notes", styles)
        story.append(Paragraph(report_generator.session_log.session_note, styles["Note"]))
        story.append(Spacer(1, 0.3 * inch))

    _render_chronological_events(
        EventRenderContext(
            story=story,
            session_log=report_generator.session_log,
            screenshots_dir=report_generator.screenshots_dir,
            report_generator=report_generator,
            styles=styles,
            relocation_log=relocation_log,
            page_break_between_sets=True,
        )
    )

    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )
    return _build_pdf_with_logging(report_generator, doc, story)


def _resolve_multi_report_metadata(report_generator) -> tuple[str, str]:
    """Resolve multi-session report title and type string."""
    project_name = report_generator.project_name
    if report_generator.report_type == "day":
        date_str = report_generator.specific_date or datetime.now().strftime("%Y-%m-%d")
        return f"{project_name} - Day Report ({date_str})", "Day"
    return f"{project_name} - Project Report", "Project"


def _add_multi_summary_table(story, stats, styles, report_type: str) -> None:
    """Add report summary table for multi-session reports."""
    summary_data = [
        ["Total Sessions", str(stats["total_sessions"])],
        ["Total Screenshots", str(stats["total_screenshots"])],
        ["Total Notes", str(stats["total_notes"])],
        ["Total Duration", stats["formatted_total_duration"]],
    ]
    if report_type == "project":
        summary_data.insert(1, ["Days Covered", str(stats["days_covered"])])
    if stats["earliest_session_str"]:
        summary_data.append(["First Session", stats["earliest_session_str"]])
    if stats["latest_session_str"]:
        summary_data.append(["Last Session", stats["latest_session_str"]])

    summary_table = Table(summary_data, colWidths=[2 * inch, 3 * inch])
    summary_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, -1), styles["Heading3Bold"].backColor),
                ("TEXTCOLOR", (0, 0), (0, -1), styles["Heading3Bold"].textColor),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("GRID", (0, 0), (-1, -1), 0.5, styles["Heading3Bold"].textColor),
            ]
        )
    )
    story.append(summary_table)
    story.append(Spacer(1, 0.3 * inch))


def _resolve_session_screenshots_dir(report_generator, session_dir) -> Path:
    """Resolve screenshots directory for session source type."""
    if str(session_dir).startswith("/mock_sessions/"):
        return report_generator.screenshots_dir
    return session_dir / "screenshots"


def generate_multi_session_pdf(report_generator) -> Path:
    """Generate PDF report for multiple sessions (day or project).

    Args:
        report_generator: The ReportGenerator instance

    Returns:
        Path to the generated PDF
    """
    relocation_log = []
    if not report_generator.multi_sessions:
        error_msg = "No multi-session data loaded"
        report_generator.log_entry(error_msg, level="error")
        raise ValueError(error_msg)

    project_name = report_generator.project_name
    report_title, report_type_str = _resolve_multi_report_metadata(report_generator)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    pdf_filename = f"{project_name}_{report_type_str}_Report_{timestamp}.pdf"
    report_generator.pdf_file = report_generator.output_dir / pdf_filename
    report_generator.log_entry(f"Creating PDF at: {report_generator.pdf_file}", level="debug")

    pdf_password = _resolve_pdf_password(report_generator)
    doc = create_pdf_document(
        output_path=report_generator.pdf_file,
        page_size=report_generator.page_size,
        compress_pdf=report_generator.compress_pdf,
        pdf_password=pdf_password,
    )
    styles = get_pdf_styles()
    story = []

    if report_generator.report_type == "day":
        add_report_title(story, "Screenshot Day Report", styles)
    else:
        add_report_title(story, "Screenshot Project Report", styles)
    add_section_header(story, report_title, styles)

    if report_generator.client_info:
        add_client_info_table(
            story=story, client_info=report_generator.client_info.dict(), styles=styles
        )

    stats = report_generator.multi_sessions.get_combined_stats()
    add_section_header(story, "Report Summary", styles)
    _add_multi_summary_table(story, stats, styles, report_generator.report_type)

    for day, sessions in sorted(report_generator.multi_sessions.sessions_by_day.items()):
        story.append(Paragraph(f"Day: {day}", styles["DayHeader"]))
        story.append(Spacer(1, 0.1 * inch))

        for session_dir in sessions:
            session_name = session_dir.name
            session_time = session_name.split("_")[1].replace("-", ":")
            session_log = report_generator.multi_sessions.session_logs.get(session_name)
            if not session_log:
                report_generator.log_entry(
                    f"Session log for {session_name} not loaded", level="warning"
                )
                continue

            add_subsection_header(story, f"Session: {session_time}", styles)

            if session_log.session_start and session_log.session_end:
                note_count = _compute_note_count(session_log)
                add_session_summary_table(
                    story=story,
                    summary=SessionSummaryData(
                        session_start=session_log.session_start,
                        session_end=session_log.session_end,
                        session_duration=session_log.session_duration,
                        screenshot_count=len(session_log.screenshots),
                        note_count=note_count,
                    ),
                    styles=styles,
                )

            if session_log.session_note:
                story.append(Paragraph("Session Note:", styles["Heading3Bold"]))
                story.append(Paragraph(session_log.session_note, styles["Note"]))
                story.append(Spacer(1, 0.2 * inch))

            _render_chronological_events(
                EventRenderContext(
                    story=story,
                    session_log=session_log,
                    screenshots_dir=_resolve_session_screenshots_dir(
                        report_generator,
                        session_dir,
                    ),
                    report_generator=report_generator,
                    styles=styles,
                    relocation_log=relocation_log,
                    page_break_between_sets=False,
                )
            )

            # Add a page break after each session except the last one in the last day
            if not (
                day == list(sorted(report_generator.multi_sessions.sessions_by_day.keys()))[-1]
                and session_dir == sessions[-1]
            ):
                story.append(PageBreak())

    if relocation_log:
        changes_saved = handle_image_relocations(report_generator, relocation_log)
        report_generator.log_entry(
            f"Processed {len(relocation_log)} image relocations (changes: {changes_saved})",
            level="debug",
        )
    return _build_pdf_with_logging(report_generator, doc, story)
