#!/usr/bin/env python3
"""Report data models for ScreenShooter Mac."""

import logging
import re
from datetime import datetime
from pathlib import Path

from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("report_models")


class ClientInfo(BaseModel):
    """Client information model."""

    client_name: str
    company_name: str = ""
    contact_name: str = ""
    contact_email: str = ""
    pdf_password: str = ""  # Password for PDF encryption
    preferences: dict[str, str] = Field(
        default_factory=lambda: {
            "screenshot_delivery": "local",
            "notification_preferences": "all",
            "reporting_frequency": "none",
            "pdf_security": "none",  # Options: none, password
            "page_size": "A4",  # Options: A4, letter
        }
    )
    last_updated: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


class SessionLog:
    """Class to parse and represent a session log."""

    def __init__(self, log_file: Path | None = None):
        self.log_file = log_file
        self.entries = []
        self.notes = []
        self.captions = {}
        self.set_captions = {}  # Add this for per-set captions
        self.screenshots = []
        self.session_note = ""
        self.session_start = None
        self.session_end = None
        self.session_duration = ""
        # New attribute for chronological events
        self.chronological_events = []
        # Track screenshot sets
        self.screenshot_sets = {}

        # Only parse if we have a real log file
        if log_file and log_file.exists() and not str(log_file).startswith("/mock/"):
            self.parse_log()

    def parse_log(self) -> None:
        """Parse the session log file to extract entries."""
        try:
            with open(self.log_file) as f:
                for line in f:
                    self.entries.append(line.strip())
                    self._process_log_line(line)
            self._finalize_parsed_log()
        except Exception as e:
            logger.error(f"Error parsing log file {self.log_file}: {e}")
            raise

    def _process_log_line(self, line: str) -> None:
        """Process one session log line and update parsed structures."""
        if "SESSION START NOTE:" in line:
            self.session_note = line.split("SESSION START NOTE:", 1)[1].strip()
            return
        if "NOTE:" in line:
            self._record_note(line)
            return
        if "CAPTION for screenshot set #" in line:
            self._record_set_caption(line)
            return
        if "CAPTION for screenshot #" in line:
            self._record_screenshot_caption(line)
            return
        if "Screenshot saved:" in line:
            self._record_screenshot(line)
            return
        if "Session Duration:" in line:
            self.session_duration = line.split("Session Duration:", 1)[1].strip()
            self.session_end = self._extract_timestamp(line)

    def _finalize_parsed_log(self) -> None:
        """Finalize fields that depend on all lines being parsed."""
        if self.entries:
            self.session_start = self._extract_timestamp(self.entries[0])
        self.chronological_events.sort(key=lambda x: x["timestamp"])

    def _extract_timestamp(self, line: str) -> str:
        """Extract bracketed timestamp from a log line."""
        return line.split("]", 1)[0].strip("[")

    def _record_note(self, line: str) -> None:
        """Record NOTE entries in note and chronological collections."""
        timestamp = self._extract_timestamp(line)
        note_text = line.split("NOTE:", 1)[1].strip()
        self.notes.append((timestamp, note_text))
        self.chronological_events.append(
            {"type": "note", "timestamp": timestamp, "content": note_text}
        )

    def _record_set_caption(self, line: str) -> None:
        """Record set-level caption line."""
        try:
            parts = line.split("CAPTION for screenshot set #", 1)
            timestamp = self._extract_timestamp(parts[0])
            set_num, caption = parts[1].split(":", 1)
            self.set_captions[int(set_num)] = (timestamp, caption.strip())
        except Exception as e:
            logger.warning(f"Malformed set caption line: {line.strip()} ({e})")

    def _record_screenshot_caption(self, line: str) -> None:
        """Record screenshot-level caption line."""
        try:
            parts = line.split("CAPTION for screenshot #", 1)
            timestamp = self._extract_timestamp(parts[0])
            screenshot_num, caption = parts[1].split(":", 1)
            self.captions[int(screenshot_num)] = (timestamp, caption.strip())
        except Exception as e:
            logger.warning(f"Malformed caption line: {line.strip()} ({e})")

    def _record_screenshot(self, line: str) -> None:
        """Record screenshot metadata and chronological event."""
        timestamp = self._extract_timestamp(line)
        set_info, screenshot_path, suffix = self._parse_screenshot_payload(line)
        screenshot_data = (timestamp, screenshot_path, set_info, suffix)
        self.screenshots.append(screenshot_data)
        self.chronological_events.append(
            {
                "type": "screenshot",
                "timestamp": timestamp,
                "set_id": set_info,
                "suffix": suffix,
                "path": screenshot_path,
                "index": len(self.screenshots) - 1,
            }
        )
        if set_info:
            self.screenshot_sets.setdefault(set_info, []).append(screenshot_data)

    def _parse_screenshot_payload(self, line: str) -> tuple[str, str, str]:
        """Parse set id, path, and suffix from a screenshot log line."""
        match = re.search(r"Set #(\d+) - Screenshot saved: (.+?) \((.+?)\)", line)
        if match:
            set_num, screenshot_path, suffix = match.groups()
            return set_num, screenshot_path, suffix

        remainder = line.split("Screenshot saved:", 1)[1].strip()
        if " (" in remainder:
            path_part, suffix_part = remainder.rsplit(" (", 1)
            screenshot_path = path_part.strip()
            suffix = suffix_part.rstrip(")")
        else:
            screenshot_path = remainder
            suffix = ""
        set_info = line.split("Set #")[1].split(" -")[0] if "Set #" in line else ""
        return set_info, screenshot_path, suffix
