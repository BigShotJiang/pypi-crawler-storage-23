#!/usr/bin/env python3
"""Report generation for ScreenShooter Mac."""

import atexit
import json
import logging
import re
import traceback
from datetime import datetime, timedelta
from pathlib import Path, PurePath

from rich.console import Console

from screenshooter.modules.clients.manager import ClientManager
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.database import DatabaseOperations
from screenshooter.modules.reports.pdf.helper import cleanup_temp_files

# Import modules from the refactored code
from screenshooter.modules.reports.pdf.models import ClientInfo, SessionLog
from screenshooter.modules.reports.pdf.multi_session import MultiSessionReport
from screenshooter.modules.settings.settings_helper import (
    get_pdf_page_size,
    get_screenshots_dir,
    should_use_database,
)

# Initialize rich console
console = Console()

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("report_generator")

# Get base directory from settings
DEFAULT_SCREENSHOTS_DIR = get_screenshots_dir()


class ReportGenerator:
    """Class to generate PDF reports from screenshot sessions.

    This class handles the generation of PDF reports from screenshot sessions, with built-in
    optimization features to reduce file size through image compression and resizing.

    Optimization options:
        - image_quality: JPEG quality (1-100, lower = smaller file)
        - image_format: Format for images in the PDF (JPEG, PNG, WebP)
        - max_dimension: Maximum dimension for images in pixels
        - use_thumbnails: Use small thumbnails instead of full-size images
        - thumbnail_size: Size for thumbnails when enabled
        - compress_pdf: Apply PDF compression

    These options can be configured in the application settings or passed directly
    to the ReportGenerator. Settings from the app are used as defaults unless overridden.
    """

    def __init__(
        self,
        screenshots_dir: str | None = None,
        client_name: str | None = None,
        project_name: str | None = None,
        session_date: str | None = None,
        **options: object,
    ) -> None:
        normalized_options = self._normalize_init_options(options)

        # Set debug mode early
        self.debug = bool(normalized_options["debug"])
        self.image_search_debug = bool(normalized_options["image_search_debug"])

        if self.debug:
            logger.setLevel(logging.DEBUG)
            logger.debug("Debug mode enabled")

        if self.image_search_debug and not self.debug:
            logger.debug("Image search debugging enabled")

        # Use the hardcoded directory if none is provided
        self.screenshots_dir = (
            Path(screenshots_dir) if screenshots_dir else Path(DEFAULT_SCREENSHOTS_DIR)
        )
        logger.debug(f"Using screenshots directory: {self.screenshots_dir}")

        self.client_name = client_name
        self.project_name = project_name
        self.session_date = session_date
        output_dir = normalized_options["output_dir"]
        self.output_dir = Path(output_dir) if isinstance(output_dir, str) and output_dir else None

        # Report type and multi-session handling
        self.report_type = str(normalized_options["report_type"])
        specific_date = normalized_options["specific_date"]
        date_range = normalized_options["date_range"]
        multi_sessions = normalized_options["multi_sessions"]
        self.specific_date = specific_date if isinstance(specific_date, str) else None
        self.date_range = date_range if isinstance(date_range, tuple) else None
        self.multi_sessions = (
            multi_sessions if isinstance(multi_sessions, MultiSessionReport) else None
        )

        # Page size will be determined based on client preferences or settings
        # We'll store the provided page_size as a fallback if specified
        page_size = normalized_options["page_size"]
        page_size_str = page_size if isinstance(page_size, str) else None
        self._provided_page_size = page_size_str
        # Default to application settings if not specified
        self._page_size_str = page_size_str or get_pdf_page_size()
        # Convert string to actual pagesize object (will be used by PDF helper)
        self.page_size = self._page_size_str

        # Image optimization settings
        self.image_quality = int(normalized_options["image_quality"])
        self.image_dpi = int(normalized_options["image_dpi"])
        self.image_format = str(normalized_options["image_format"])
        self.max_dimension = int(normalized_options["max_dimension"])
        self.use_thumbnails = bool(normalized_options["use_thumbnails"])
        self.thumbnail_size = int(normalized_options["thumbnail_size"])
        self.compress_pdf = bool(normalized_options["compress_pdf"])

        # Track temporary files for cleanup
        self.temp_files = []

        self.client_info = None
        self.session_log = None
        self.pdf_file = None

        # Ensure cleanup on exit
        atexit.register(self.cleanup_temp_files)

        # Initialize log file paths
        if self.client_name and self.project_name:
            self.client_dir, self.project_dir = self._resolve_client_and_project_dirs()
            self.master_log_file = self.project_dir / f"{self.project_name}_log.txt"
            self.report_log_file = (
                self.project_dir / f"{self.project_name}_report_generation_log.txt"
            )

            # Create necessary directories including project-level reports directory
            self.project_dir.mkdir(parents=True, exist_ok=True)
            self.reports_dir = self.project_dir / "reports"
            self.reports_dir.mkdir(parents=True, exist_ok=True)

            # Initialize log files
            self.master_log_file.touch(exist_ok=True)
            self.report_log_file.touch(exist_ok=True)

    @staticmethod
    def _normalize_init_options(options: dict[str, object]) -> dict[str, object]:
        """Normalize constructor options for report generation."""
        return {
            "output_dir": options.get("output_dir"),
            "page_size": options.get("page_size"),
            "image_quality": int(options.get("image_quality", 85)),
            "image_dpi": int(options.get("image_dpi", 150)),
            "image_format": str(options.get("image_format", "JPEG")),
            "max_dimension": int(options.get("max_dimension", 1500)),
            "use_thumbnails": bool(options.get("use_thumbnails", False)),
            "thumbnail_size": int(options.get("thumbnail_size", 800)),
            "compress_pdf": bool(options.get("compress_pdf", True)),
            "debug": bool(options.get("debug", False)),
            "report_type": str(options.get("report_type", "session")),
            "specific_date": options.get("specific_date"),
            "date_range": options.get("date_range"),
            "multi_sessions": options.get("multi_sessions"),
            "image_search_debug": bool(options.get("image_search_debug", True)),
        }

    def _resolve_client_and_project_dirs(self) -> tuple[Path, Path]:
        """Resolve client and project directories using safe slugs when available."""
        client_dir = Path(self.screenshots_dir)

        # Try database first for authoritative mapping
        if should_use_database():
            try:
                db_ops = DatabaseOperations()
                client = db_ops.get_client_by_name(
                    self.client_name
                ) or db_ops.get_client_by_directory(self.client_name)
                if client and getattr(client, "directory_name", None):
                    client_dir = client_dir / client.directory_name
                else:
                    client_dir = client_dir / self.client_name

                project_dir = client_dir
                if client and getattr(client, "id", None) and self.project_name:
                    project = db_ops.get_project_by_name(client.id, self.project_name)
                    if project and getattr(project, "directory_name", None):
                        project_dir = client_dir / project.directory_name
                    else:
                        project_dir = client_dir / self.project_name
                else:
                    project_dir = client_dir / self.project_name

                return client_dir, project_dir
            except Exception:
                # Fall through to filesystem/slug-based resolution
                pass

        # Filesystem / slug-based resolution
        try:
            manager = ClientManager(str(self.screenshots_dir))
            client_info = manager.load_client_info(self.client_name)
            client_dir = Path(self.screenshots_dir) / client_info.directory_name
        except Exception:
            # Fallback to slug or raw name
            client_slug = slugify_name(self.client_name)
            client_dir = Path(self.screenshots_dir) / (client_slug or self.client_name)

        project_slug = slugify_name(self.project_name)
        project_dir = client_dir / project_slug
        if not project_dir.exists():
            # Legacy fallback: project directory using display name
            project_dir = client_dir / self.project_name

        return client_dir, project_dir

    def _parse_caption_note(self, content: str) -> tuple[int | None, str]:
        """Extract set metadata and caption text from a caption note.

        Args:
            content: Caption content stored in the database.

        Returns:
            Tuple containing the set ID (if present) and the cleaned caption text.
        """
        set_id: int | None = None
        caption_text = content.strip()
        set_str: str | None = None

        bracket_match = re.match(r"\[set #(?P<set>\d+)\]\s*(?P<caption>.+)", content, re.IGNORECASE)
        if bracket_match:
            set_str = bracket_match.group("set")
            caption_text = bracket_match.group("caption").strip()
        else:
            suffix_match = re.match(
                r"(?P<caption>.+?)\s*\(Set #(?P<set>\d+)\)\s*$", content, re.IGNORECASE
            )
            if suffix_match:
                set_str = suffix_match.group("set")
                caption_text = suffix_match.group("caption").strip()

        if set_str:
            try:
                set_id = int(set_str)
            except ValueError:
                set_id = None

        return set_id, caption_text

    def cleanup_temp_files(self):
        """Clean up any temporary files created during report generation."""
        cleanup_temp_files(self.temp_files, self.debug)
        self.temp_files = []

    def write_to_logs(self, message: str) -> None:
        """Write a message to both the master log and report log files."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"

        # Write to master log
        if hasattr(self, "master_log_file"):
            with open(self.master_log_file, "a") as f:
                f.write(f"{entry}\n")

        # Write to report log
        if hasattr(self, "report_log_file"):
            with open(self.report_log_file, "a") as f:
                f.write(f"{entry}\n")

        # Also write to session log if available
        if self.session_log and hasattr(self, "session_dir"):
            session_log_file = self.session_dir / "session.log"
            with open(session_log_file, "a") as f:
                f.write(f"{entry}\n")

    def log_entry(
        self,
        message: str,
        terminal_message: str | None = None,
        level: str = "info",
        suppress_logger: bool = False,
    ) -> None:
        """Add a log entry and optionally display a custom message to the terminal.

        Args:
            message: The message to write to the log files
            terminal_message: Optional custom message to display in the terminal
            level: Log level (info, warning, error, debug)
            suppress_logger: If True, skips logger output even if terminal_message is None
        """
        # Write to log files
        self.write_to_logs(message)

        # Log to the Python logger but only if no terminal message is provided
        # and suppress_logger is False
        if terminal_message is None and not suppress_logger:
            if level == "error":
                logger.error(message)
            elif level == "warning":
                logger.warning(message)
            elif level == "debug":
                logger.debug(message)
            else:
                logger.info(message)

        # Display in terminal if a custom message is provided
        if terminal_message:
            if level == "error":
                console.print(f"[bold red]{terminal_message}[/bold red]")
            elif level == "warning":
                console.print(f"[bold yellow]{terminal_message}[/bold yellow]")
            else:
                console.print(terminal_message)

    def load_client_info(self) -> None:
        """Load client information from client_info.json."""
        if not self.client_name:
            self.log_entry(
                "Client name is required to load client information",
                "Client name is required",
                level="error",
            )
            raise ValueError("Client name is required to load client information")

        if self._try_load_client_info_from_database():
            return

        client_info_file, legacy_client_info_file = self._resolve_client_info_paths()

        self.log_entry(
            f"Looking for client info at: {client_info_file}",
            "[yellow]Looking for client info[/yellow]",
            level="debug",
        )

        self._migrate_legacy_client_info(client_info_file, legacy_client_info_file)

        if client_info_file.exists():
            try:
                with open(client_info_file) as f:
                    data = json.load(f)
                self.client_info = ClientInfo(**data)
                self.log_entry(
                    f"Loaded client info for {self.client_info.client_name}",
                    (
                        f"[green]Successfully loaded client info for "
                        f"{self.client_info.client_name}[/green]"
                    ),
                )
                if self.debug:
                    self.log_entry(f"Client info content: {data}", level="debug")
                self._apply_client_page_size_preference()
            except Exception as e:
                error_msg = f"Error loading client info: {e}"
                self.log_entry(error_msg, level="error")
                if self.debug:
                    self.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
                raise
        else:
            self.log_entry(
                f"Client info file not found at {client_info_file}",
                "[yellow]Client info file not found[/yellow]",
                level="warning",
            )

    def _try_load_client_info_from_database(self) -> bool:
        """Try loading client info from database first."""
        if not should_use_database():
            return False
        try:
            db_ops = DatabaseOperations()
            db_client = db_ops.get_client_by_name(self.client_name)
            if not db_client:
                db_client = db_ops.get_client_by_directory(self.client_name)
            if not db_client:
                return False

            self.client_info = ClientInfo(
                client_name=db_client.name,
                company_name=db_client.company_name or "",
                contact_name=db_client.contact_name or "",
                contact_email=db_client.contact_email or "",
                pdf_password=db_client.pdf_password or "",
                preferences=db_client.preferences or {},
                last_updated=db_client.updated_at.strftime("%Y-%m-%d %H:%M:%S")
                if db_client.updated_at
                else "",
            )
            self.log_entry(
                f"Loaded client info for {self.client_info.client_name} from database",
                (
                    f"[green]Successfully loaded client info for "
                    f"{self.client_info.client_name} from database[/green]"
                ),
            )
            if self.debug:
                self.log_entry(f"Client info content: {self.client_info}", level="debug")
            self._apply_client_page_size_preference()
            return True
        except Exception as e:
            self.log_entry(f"Failed to load client info from database: {e}", level="warning")
            return False

    def _resolve_client_info_paths(self) -> tuple[Path, Path]:
        """Resolve primary and legacy client info file paths."""
        client_dir = self.screenshots_dir / self.client_name
        return client_dir / "client.json", client_dir / "client_info.json"

    def _migrate_legacy_client_info(self, client_info_file: Path, legacy_file: Path) -> None:
        """Migrate legacy client_info.json to client.json format when needed."""
        if client_info_file.exists() or not legacy_file.exists():
            return
        try:
            data = json.load(legacy_file.open())
            archived_val = data.pop("archived", False)
            archived_at = data.get("archived_at", "")
            if not archived_at and archived_val:
                archived_at = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            data["archived_at"] = archived_at
            client_info_file.write_text(json.dumps(data, indent=2))
            legacy_file.unlink(missing_ok=True)
        except Exception:
            pass

    def _apply_client_page_size_preference(self) -> None:
        """Apply client page size preference unless explicitly overridden."""
        if not self.client_info:
            return
        if "page_size" not in self.client_info.preferences:
            self.log_entry(
                f"No page size preference found in client info, using {self._page_size_str}",
                level="debug",
            )
            return

        client_page_size = self.client_info.preferences.get("page_size")
        if not self._provided_page_size:
            self.log_entry(f"Using client page size preference: {client_page_size}", level="debug")
            self._page_size_str = client_page_size
            self.page_size = client_page_size
            return
        self.log_entry(
            (
                f"Explicit page size provided ({self._provided_page_size}), "
                f"ignoring client preference ({client_page_size})"
            ),
            level="debug",
        )

    def find_session(self) -> tuple[Path, Path]:
        """Find the session directory based on the provided information."""
        if not self.client_name:
            self.log_entry(
                "Client name is required to find session directory",
                "Client name is required",
                level="error",
            )
            raise ValueError("Client name is required to find session directory")

        if not self.project_name:
            self.log_entry(
                "Project name is required to find session directory",
                "Project name is required",
                level="error",
            )
            raise ValueError("Project name is required to find session directory")

        client_dir, project_dir = self._resolve_client_and_project_dirs()

        if not client_dir.exists():
            error_msg = f"Client directory not found: {client_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        if not project_dir.exists():
            error_msg = f"Project directory not found: {project_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        sessions_dir = project_dir / "sessions"
        if not sessions_dir.exists():
            error_msg = f"Sessions directory not found: {sessions_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        # Look for exact match if session_date is provided
        if self.session_date:
            session_dir = sessions_dir / self.session_date
            if session_dir.exists():
                self.log_entry(
                    f"Found session directory: {session_dir}",
                    f"[green]Using session from {self.session_date}[/green]",
                )
                self.session_dir = session_dir  # Store for later use
                return session_dir, session_dir / "session.log"

        # If exact match not found or no session_date provided, find the most recent session
        sessions = sorted(
            [d for d in sessions_dir.iterdir() if d.is_dir()], key=lambda x: x.name, reverse=True
        )

        if self.debug:
            self.log_entry(f"Available sessions: {[s.name for s in sessions]}", level="debug")

        if sessions:
            session_dir = sessions[0]
            self.session_dir = session_dir  # Store for later use
            self.log_entry(
                f"Using most recent session: {session_dir}",
                f"[green]Using most recent session from {session_dir.name}[/green]",
            )
            return session_dir, session_dir / "session.log"

        error_msg = f"No session directories found in {sessions_dir}"
        self.log_entry(error_msg, level="error")
        raise FileNotFoundError(error_msg)

    def _load_session_from_log_files(self) -> None:
        """Load session data from log files (original logic)."""
        session_dir, log_file = self.find_session()

        if not log_file.exists():
            error_msg = f"Session log file not found: {log_file}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        try:
            self.session_log = SessionLog(log_file)
            self.log_entry(
                f"Loaded session log with {len(self.session_log.screenshots)} screenshots",
                (
                    f"[green]Successfully loaded session with "
                    f"{len(self.session_log.screenshots)} screenshots[/green]"
                ),
            )

            if self.debug and self.session_log.screenshots:
                self.log_entry(
                    f"First screenshot path: {self.session_log.screenshots[0][1]}", level="debug"
                )

            # Set the screenshots directory to the session's screenshots directory
            self.screenshots_dir = session_dir / "screenshots"
            self.log_entry(f"Set screenshots directory to: {self.screenshots_dir}", level="debug")

            # Set the output directory to the project's reports directory if not already set
            if not self.output_dir:
                self.output_dir = self.reports_dir
                self.log_entry(f"Using project reports directory: {self.output_dir}", level="debug")

        except Exception as e:
            error_msg = f"Error loading session log: {e}"
            self.log_entry(error_msg, level="error")
            if self.debug:
                self.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
            raise

    def load_session(self) -> None:
        """Load session data."""
        # Skip if we're doing a multi-session report as we'll handle it differently
        if self.report_type in ("day", "project"):
            self.log_entry(
                f"Skipping single session loading for {self.report_type} report", level="debug"
            )
            return

        # Check if we should use database
        if should_use_database():
            try:
                self._load_session_from_database()
                return
            except Exception as e:
                self.log_entry(
                    f"Failed to load session from database, falling back to log files: {e}",
                    level="warning",
                )
                # Fall back to log files on database error

        # Default: use log files (existing logic)
        self._load_session_from_log_files()

    def setup_multi_session_report(self) -> None:
        """Set up multi-session report data."""
        # Check if we should use database
        if should_use_database():
            try:
                self._setup_multi_session_report_from_database()
                return
            except Exception as e:
                self.log_entry(
                    (
                        f"Failed to set up multi-session report from database, falling back "
                        f"to log files: {e}"
                    ),
                    level="warning",
                )
                # Fall back to log files on database error

        # Default: use log files (existing logic)
        self._setup_multi_session_report_from_log_files()

    def _load_session_from_database(self) -> None:
        """Load a single session's data from the database.

        This is used for *session* reports only. Multi-session (day/project)
        reports are handled by ``_setup_multi_session_report_from_database``.
        """
        db_ops = DatabaseOperations()

        # Validate inputs
        if not self.client_name:
            raise ValueError("Client name is required")
        if not self.project_name:
            raise ValueError("Project name is required")

        # Get client and project from database
        client = db_ops.get_client_by_name(self.client_name)
        if not client:
            client = db_ops.get_client_by_directory(self.client_name)

        if not client or not client.id:
            raise ValueError(f"Client '{self.client_name}' not found in database")

        project = db_ops.get_project_by_name(client.id, self.project_name)
        if not project or not project.id:
            raise ValueError(f"Project '{self.project_name}' not found in database")

        # Decide which session to load:
        # - Prefer an exact name match (session_date comes from CLI selection)
        # - Fallback to the most recent session in the project
        db_session = None
        if self.session_date:
            db_session = db_ops.get_session_by_name(project.id, self.session_date)

        if not db_session:
            sessions = db_ops.list_sessions(project.id)
            if sessions:
                db_session = sessions[0]

        if not db_session:
            raise ValueError(f"No session found in database for project '{self.project_name}'")

        # Build an in-memory SessionLog from database rows
        session_log = self._create_session_log_from_database(db_ops, db_session)
        self.session_log = session_log

        screenshot_count = len(session_log.screenshots)
        self.log_entry(
            f"Loaded session '{db_session.name}' with {screenshot_count} screenshots from database",
            (
                f"[green]Successfully loaded session '{db_session.name}' with "
                f"{screenshot_count} screenshots from database[/green]"
            ),
        )

        # Use project/session directories for resolving image paths when possible
        self.client_dir, self.project_dir = self._resolve_client_and_project_dirs()
        self.reports_dir = self.project_dir / "reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)

        # Default output directory to project reports directory if not already set
        if not self.output_dir:
            self.output_dir = self.reports_dir
            self.log_entry(f"Using project reports directory: {self.output_dir}", level="debug")

    def _create_session_log_from_database(self, db_ops, session) -> "SessionLog":
        """Create a SessionLog object from database data."""
        # Create SessionLog instance without a file (database data)
        session_log = SessionLog()

        # Clear default empty data
        session_log.entries = []
        session_log.notes = []
        session_log.captions = {}
        session_log.set_captions = {}
        session_log.screenshots = []
        session_log.chronological_events = []
        session_log.screenshot_sets = {}

        # Load screenshots from database
        db_screenshots = db_ops.list_screenshots(session.id)
        for idx, screenshot in enumerate(db_screenshots):
            timestamp = (
                screenshot.timestamp.strftime("%Y-%m-%d %H:%M:%S") if screenshot.timestamp else ""
            )
            screenshot_path = screenshot.file_path
            set_info = screenshot.set_id or ""
            suffix = screenshot.suffix or ""

            screenshot_data = (timestamp, screenshot_path, set_info, suffix)
            session_log.screenshots.append(screenshot_data)
            session_log.chronological_events.append(
                {
                    "type": "screenshot",
                    "timestamp": timestamp,
                    "set_id": set_info,
                    "suffix": suffix,
                    "path": screenshot_path,
                    "index": idx,
                }
            )

            if set_info:
                if set_info not in session_log.screenshot_sets:
                    session_log.screenshot_sets[set_info] = []
                session_log.screenshot_sets[set_info].append(screenshot_data)

        # Load notes from database
        db_notes = db_ops.list_notes(session.id)
        for note in db_notes:
            timestamp = note.timestamp.strftime("%Y-%m-%d %H:%M:%S") if note.timestamp else ""
            content = note.content or ""
            note_type = (note.note_type or "").lower()

            if note_type == "note":
                # Standard note
                session_log.notes.append((timestamp, content))
                session_log.chronological_events.append(
                    {"type": "note", "timestamp": timestamp, "content": content}
                )
            elif note_type == "caption":
                set_id, caption_text = self._parse_caption_note(content)
                if set_id is not None:
                    session_log.set_captions[set_id] = (timestamp, caption_text)
                else:
                    # Caption without set metadata falls back to chronological rendering
                    session_log.chronological_events.append(
                        {"type": "caption", "timestamp": timestamp, "content": content}
                    )
            elif note_type == "session_start":
                # Initial session note (displayed in the dedicated Session Note area)
                session_log.session_note = content

        # Set session timing information
        session_log.session_start = (
            session.start_time.strftime("%Y-%m-%d %H:%M:%S") if session.start_time else ""
        )
        session_log.session_end = (
            session.end_time.strftime("%Y-%m-%d %H:%M:%S") if session.end_time else ""
        )
        session_log.session_duration = self._format_duration(session.duration_seconds)

        # Sort chronological events
        session_log.chronological_events.sort(key=lambda x: x["timestamp"])

        return session_log

    def _format_duration(self, duration_seconds: int | None) -> str:
        """Format duration seconds into a human-readable verbose string.

        Example outputs:
            - 1 hour 5 minutes 20 seconds
            - 2 hours 3 minutes
            - 45 seconds

        Args:
            duration_seconds: Duration in seconds

        Returns:
            Formatted duration string
        """
        if not duration_seconds:
            return "0 seconds"

        hours, remainder = divmod(duration_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        parts: list[str] = []
        if hours > 0:
            parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
        if minutes > 0:
            parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
        if seconds > 0 or not parts:
            parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")

        return " ".join(parts)

    def _setup_multi_session_report_from_database(self) -> None:
        """Set up multi-session report from database."""
        db_ops = DatabaseOperations()
        project = self._get_database_project(db_ops)
        sessions = self._get_filtered_report_sessions(db_ops, project.id)

        if not sessions:
            raise ValueError(f"No sessions found for {self.report_type} report")

        self.multi_sessions = self._create_database_multi_session_report()

        total_duration = timedelta()
        for session in sessions:
            total_duration += self._add_database_session_to_multi_report(db_ops, session)

        self._sort_multi_session_days()

        self.multi_sessions.total_duration = total_duration
        self._log_multi_session_database_summary()
        self._ensure_output_dir_set()

    def _get_database_project(self, db_ops):
        """Resolve project record from database for current client/project names."""
        if not self.client_name:
            raise ValueError("Client name is required")
        if not self.project_name:
            raise ValueError("Project name is required")

        client = db_ops.get_client_by_name(self.client_name)
        if not client:
            client = db_ops.get_client_by_directory(self.client_name)
        if not client or not client.id:
            raise ValueError(f"Client '{self.client_name}' not found in database")

        project = db_ops.get_project_by_name(client.id, self.project_name)
        if not project or not project.id:
            raise ValueError(f"Project '{self.project_name}' not found in database")
        return project

    def _get_filtered_report_sessions(self, db_ops, project_id: int):
        """Get project sessions filtered for day/project report mode."""
        sessions = db_ops.list_sessions(project_id)
        if self.report_type == "day":
            target_date = self.specific_date or datetime.now().strftime("%Y-%m-%d")
            return [
                session
                for session in sessions
                if session.start_time and session.start_time.strftime("%Y-%m-%d") == target_date
            ]

        if not self.date_range:
            return sessions
        start_date, end_date = self.date_range
        return [
            session
            for session in sessions
            if session.start_time
            and start_date <= session.start_time.strftime("%Y-%m-%d") <= end_date
        ]

    def _create_database_multi_session_report(self) -> MultiSessionReport:
        """Create a MultiSessionReport container for DB-backed sessions."""
        return MultiSessionReport(
            client_name=self.client_name,
            project_name=self.project_name,
            sessions_dir=Path("/tmp/dummy_sessions"),
            report_type=self.report_type,
            specific_date=self.specific_date,
            date_range=self.date_range,
            debug=self.debug,
        )

    def _add_database_session_to_multi_report(self, db_ops, session):
        """Add a single DB session into the multi-session report aggregates."""
        session_log = self._create_session_log_from_database(db_ops, session)
        session_date, session_dir_name = self._resolve_db_session_identity(session)
        mock_session_path = PurePath(f"/mock_sessions/{session_dir_name}")
        self.multi_sessions.sessions_by_day[session_date].append(mock_session_path)
        self.multi_sessions.session_logs[session_dir_name] = session_log

        self.multi_sessions.total_screenshots += len(session_log.screenshots)
        self.multi_sessions.total_notes += self._count_session_notes(session_log)
        self._update_multi_session_time_bounds(session.start_time)

        return (
            timedelta(seconds=session.duration_seconds) if session.duration_seconds else timedelta()
        )

    @staticmethod
    def _resolve_db_session_identity(session) -> tuple[str, str]:
        """Resolve stable day key and directory-like session key for a DB session."""
        if session.start_time:
            session_date = session.start_time.strftime("%Y-%m-%d")
            session_time = session.start_time.strftime("%H-%M-%S")
            return session_date, f"{session_date}_{session_time}"
        session_date = "unknown_date"
        return session_date, f"{session_date}_session_{session.id}"

    @staticmethod
    def _count_session_notes(session_log) -> int:
        """Count notes including captions and session-note metadata."""
        note_count = len(session_log.notes)
        note_count += len(getattr(session_log, "captions", {}))
        note_count += len(getattr(session_log, "set_captions", {}))
        if session_log.session_note:
            note_count += 1
        note_count += sum(
            1
            for event in getattr(session_log, "chronological_events", [])
            if event.get("type") == "caption"
        )
        return note_count

    def _update_multi_session_time_bounds(self, session_start_time) -> None:
        """Track earliest/latest session timestamps for summary output."""
        if not session_start_time:
            return
        if (
            self.multi_sessions.earliest_session is None
            or session_start_time < self.multi_sessions.earliest_session
        ):
            self.multi_sessions.earliest_session = session_start_time
        if (
            self.multi_sessions.latest_session is None
            or session_start_time > self.multi_sessions.latest_session
        ):
            self.multi_sessions.latest_session = session_start_time

    def _sort_multi_session_days(self) -> None:
        """Sort session entries within each day for deterministic rendering."""
        for day, day_sessions in self.multi_sessions.sessions_by_day.items():
            self.multi_sessions.sessions_by_day[day] = sorted(day_sessions, key=lambda p: p.name)

    def _log_multi_session_database_summary(self) -> None:
        """Log database-backed multi-session summary to report logs/terminal."""
        stats = self.multi_sessions.get_combined_stats()
        if self.report_type == "day":
            date_str = self.specific_date or datetime.now().strftime("%Y-%m-%d")
            self.log_entry(
                (
                    f"Loaded {stats['total_sessions']} sessions for day {date_str} with "
                    f"{stats['total_screenshots']} screenshots from database"
                ),
                (
                    f"[green]Loaded {stats['total_sessions']} sessions with "
                    f"{stats['total_screenshots']} screenshots for {date_str} from database[/green]"
                ),
            )
            return
        self.log_entry(
            (
                f"Loaded {stats['total_sessions']} sessions across "
                f"{stats['days_covered']} days with {stats['total_screenshots']} "
                f"screenshots from database"
            ),
            (
                f"[green]Loaded {stats['total_sessions']} sessions with "
                f"{stats['total_screenshots']} screenshots for project from database[/green]"
            ),
        )

    def _ensure_output_dir_set(self) -> None:
        """Ensure output directory defaults to project reports directory."""
        if self.output_dir:
            return
        self.output_dir = self.reports_dir
        self.log_entry(f"Using project reports directory: {self.output_dir}", level="debug")

    def _setup_multi_session_report_from_log_files(self) -> None:
        """Set up multi-session report from log files (original logic)."""
        # Get project directory
        if not self.client_name or not self.project_name:
            raise ValueError("Client name and project name are required")

        client_dir, project_dir = self._resolve_client_and_project_dirs()
        if not client_dir.exists():
            error_msg = f"Client directory not found: {client_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        if not project_dir.exists():
            error_msg = f"Project directory not found: {project_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        sessions_dir = project_dir / "sessions"
        if not sessions_dir.exists():
            error_msg = f"Sessions directory not found: {sessions_dir}"
            self.log_entry(error_msg, level="error")
            raise FileNotFoundError(error_msg)

        # Create MultiSessionReport
        try:
            self.multi_sessions = MultiSessionReport(
                client_name=self.client_name or "",
                project_name=self.project_name or "",
                sessions_dir=sessions_dir,
                report_type=self.report_type,
                specific_date=self.specific_date,
                date_range=self.date_range,
                debug=self.debug,
            )

            # Load the session logs
            self.multi_sessions.load_session_logs()

            # Log summary
            stats = self.multi_sessions.get_combined_stats()

            if self.report_type == "day":
                date_str = self.specific_date or datetime.now().strftime("%Y-%m-%d")
                self.log_entry(
                    (
                        f"Loaded {stats['total_sessions']} sessions for day {date_str} with "
                        f"{stats['total_screenshots']} screenshots"
                    ),
                    (
                        f"[green]Loaded {stats['total_sessions']} sessions with "
                        f"{stats['total_screenshots']} screenshots for {date_str}[/green]"
                    ),
                )
            else:  # project
                self.log_entry(
                    (
                        f"Loaded {stats['total_sessions']} sessions across "
                        f"{stats['days_covered']} days with {stats['total_screenshots']} "
                        f"screenshots"
                    ),
                    (
                        f"[green]Loaded {stats['total_sessions']} sessions with "
                        f"{stats['total_screenshots']} screenshots for project[/green]"
                    ),
                )

            # Set the output directory to the project's reports directory if not already set
            if not self.output_dir:
                self.output_dir = self.reports_dir
                self.log_entry(f"Using project reports directory: {self.output_dir}", level="debug")

        except Exception as e:
            error_msg = f"Error setting up multi-session report: {e}"
            self.log_entry(error_msg, level="error")
            if self.debug:
                self.log_entry(f"Stack trace: {traceback.format_exc()}", level="debug")
            raise
