"""PDF report subpackage for design components, document generation, and utilities."""

# Re-export utility functions
# Re-export components
from .components import add_report_title, add_section_header, add_subsection_header

# Re-export primary generation functions
from .generation import generate_multi_session_pdf, generate_single_session_pdf

# Re-export generator class
from .generator import ReportGenerator

# Re-export helper functions
from .helper import (
    add_screenshot,
    cleanup_temp_files,
    create_pdf_document,
    find_image_path,
    get_pdf_styles,
    optimize_image,
)

# Re-export models
from .models import ClientInfo, SessionLog

# Re-export multi-session handling
from .multi_session import MultiSessionReport

# Re-export tables
from .tables import add_client_info_table, add_session_summary_table
from .utils import handle_image_relocations

__all__ = [
    "ClientInfo",
    "MultiSessionReport",
    "ReportGenerator",
    "SessionLog",
    "add_client_info_table",
    "add_report_title",
    "add_screenshot",
    "add_section_header",
    "add_session_summary_table",
    "add_subsection_header",
    "cleanup_temp_files",
    "create_pdf_document",
    "find_image_path",
    "generate_multi_session_pdf",
    "generate_single_session_pdf",
    "get_pdf_styles",
    "handle_image_relocations",
    "optimize_image",
]
