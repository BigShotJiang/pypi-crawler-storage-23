#!/usr/bin/env python3
"""PDF generation helper functions for ScreenShooter Mac."""

import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

# Import reportlab for PDF generation
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.pdfencrypt import StandardEncryption
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
)

# Try importing PIL with error handling
try:
    from PIL import Image as PILImage

    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    logging.warning("Pillow (PIL) not available. PDF optimization features will be limited.")

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("pdf_helper")


@dataclass(slots=True)
class ImageOptimizationOptions:
    """Options for optimizing screenshot images before PDF embedding."""

    image_quality: int = 85
    image_format: str = "JPEG"
    max_dimension: int = 1500
    use_thumbnails: bool = False
    thumbnail_size: int = 800
    debug: bool = False


@dataclass(slots=True)
class ImageLookupContext:
    """Context for locating image paths in project/client hierarchies."""

    client_base_dir: Path | None = None
    debug: bool = False
    report_relocation: bool = True
    project_dir: Path | None = None


@dataclass(slots=True)
class ScreenshotRenderContext:
    """Rendering and lookup context for adding screenshots to a PDF story."""

    screenshots_dir: Path
    captions: dict[int, tuple[str, str]]
    options: ImageOptimizationOptions = field(default_factory=ImageOptimizationOptions)
    styles: dict | None = None
    temp_files: list[str] | None = None
    client_base_dir: Path | None = None
    report_relocations: bool = True
    relocation_log: list | None = None
    project_dir: Path | None = None


def get_pdf_styles():
    """Get the standard styles dictionary for PDF generation with custom styles added."""
    styles = getSampleStyleSheet()

    # Define custom styles
    custom_styles = {
        "Heading1Bold": ParagraphStyle(
            name="Heading1Bold",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            spaceAfter=12,
        ),
        "Heading2Bold": ParagraphStyle(
            name="Heading2Bold",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=16,
            spaceAfter=10,
        ),
        "Heading3Bold": ParagraphStyle(
            name="Heading3Bold",
            parent=styles["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=14,
            spaceAfter=8,
        ),
        "Caption": ParagraphStyle(
            name="Caption", fontName="Helvetica-Oblique", fontSize=10, leading=12, spaceAfter=12
        ),
        "Note": ParagraphStyle(
            name="Note",
            fontName="Helvetica",
            fontSize=12,
            backColor=colors.lightgrey,
            borderPadding=5,
            spaceAfter=12,
        ),
        "Timestamp": ParagraphStyle(
            name="Timestamp",
            fontName="Helvetica-Bold",
            fontSize=10,
            textColor=colors.darkblue,
            spaceAfter=4,
        ),
        "DayHeader": ParagraphStyle(
            name="DayHeader",
            fontName="Helvetica-Bold",
            fontSize=14,
            textColor=colors.darkblue,
            backColor=colors.lightgrey,
            borderPadding=5,
            spaceAfter=8,
        ),
    }

    # Add custom styles if they don't already exist
    for style_name, style in custom_styles.items():
        if style_name not in styles:
            styles.add(style)

    return styles


def optimize_image(
    img_path: Path,
    *,
    options: ImageOptimizationOptions | None = None,
    **legacy_options: int | str | bool,
) -> str | None:
    """Optimize an image for PDF inclusion.

    Args:
        img_path: Path to the image file
        image_quality: JPEG quality (1-100)
        image_format: Format for optimized image (JPEG, PNG, WebP)
        max_dimension: Maximum dimension for resizing
        use_thumbnails: Whether to use small thumbnails
        thumbnail_size: Size for thumbnails
        debug: Enable debug logging

    Returns:
        Path to the temporary optimized image, or None if optimization failed
    """
    options = options or ImageOptimizationOptions(
        image_quality=int(legacy_options.get("image_quality", 85)),
        image_format=str(legacy_options.get("image_format", "JPEG")),
        max_dimension=int(legacy_options.get("max_dimension", 1500)),
        use_thumbnails=bool(legacy_options.get("use_thumbnails", False)),
        thumbnail_size=int(legacy_options.get("thumbnail_size", 800)),
        debug=bool(legacy_options.get("debug", False)),
    )

    if not PIL_AVAILABLE:
        return None

    if not img_path.exists():
        return None

    try:
        # Process image with PIL to optimize it
        pil_img = PILImage.open(str(img_path))

        # Step 1: Resize if needed (keep aspect ratio)
        original_width, original_height = pil_img.size
        if options.use_thumbnails:
            # Use thumbnail size if thumbnails are enabled
            target_size = options.thumbnail_size
        else:
            # Otherwise use the max dimension setting
            target_size = options.max_dimension

        # Only resize if image is larger than target size
        if original_width > target_size or original_height > target_size:
            if original_width > original_height:
                new_width = target_size
                new_height = int(original_height * (target_size / original_width))
            else:
                new_height = target_size
                new_width = int(original_width * (target_size / original_height))

            pil_img = pil_img.resize((new_width, new_height), PILImage.LANCZOS)
            if options.debug:
                logger.debug(
                    f"Resized image from {original_width}x{original_height} to "
                    f"{new_width}x{new_height}"
                )

        # Step 2: Convert to preferred format and compress
        # Use chosen format or fallback to JPEG for best compression
        save_format = options.image_format
        save_params = {"quality": options.image_quality}

        # Handle special formats
        if save_format.upper() == "JPEG" and pil_img.mode == "RGBA":
            # Convert RGBA to RGB for JPEG format which doesn't support alpha
            pil_img = pil_img.convert("RGB")

        # Create a temporary file for the optimized image
        with tempfile.NamedTemporaryFile(
            delete=False, suffix=f".{save_format.lower()}"
        ) as temp_file:
            temp_path = temp_file.name

        # Save the optimized image to the temporary file
        pil_img.save(temp_path, format=save_format, **save_params)

        # Log compression stats if debug is enabled
        if options.debug:
            original_size = os.path.getsize(img_path)
            compressed_size = os.path.getsize(temp_path)
            compression_ratio = (1 - (compressed_size / original_size)) * 100
            logger.debug(
                f"Compressed image: {original_size} bytes -> {compressed_size} bytes "
                f"({compression_ratio:.1f}% reduction)"
            )

        return temp_path
    except Exception as e:
        logger.error(f"Error optimizing image {img_path}: {e}")
        return None


def create_pdf_document(
    output_path: Path,
    page_size: str = "A4",
    compress_pdf: bool = True,
    pdf_password: str | None = None,
) -> SimpleDocTemplate:
    """Create a PDF document with the specified settings.

    Args:
        output_path: Path where the PDF will be saved
        page_size: Page size (A4, letter)
        compress_pdf: Whether to compress the PDF
        pdf_password: Optional password for PDF encryption

    Returns:
        SimpleDocTemplate with the configured settings
    """
    # Determine page size
    pdf_page_size = A4
    if page_size == "letter":
        pdf_page_size = letter

    # Create document with encryption if needed
    if pdf_password:
        encryption = StandardEncryption(pdf_password, canPrint=1, canModify=0, canCopy=0)
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=pdf_page_size,
            rightMargin=0.5 * inch,
            leftMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
            compress=compress_pdf,
            encrypt=encryption,
        )
    else:
        doc = SimpleDocTemplate(
            str(output_path),
            pagesize=pdf_page_size,
            rightMargin=0.5 * inch,
            leftMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
            compress=compress_pdf,
        )

    return doc


def find_image_path(
    screenshot_path: str,
    screenshots_dir: Path,
    *,
    context: ImageLookupContext | None = None,
    **legacy_context: Path | bool | None,
) -> tuple[Path | None, dict | None]:
    """Find the actual image path from the screenshot path in the log.

    This handles relocations and different path formats.

    Args:
        screenshot_path: Path from log entry
        screenshots_dir: Base directory for screenshots
        client_base_dir: Optional base client directory
        debug: Enable debug logging
        report_relocation: Whether to track relocations
        project_dir: Optional project directory for caching lookups

    Returns:
        Tuple of (found path or None, relocation info or None)
    """
    context = context or ImageLookupContext(
        client_base_dir=legacy_context.get("client_base_dir"),
        debug=bool(legacy_context.get("debug", False)),
        report_relocation=bool(legacy_context.get("report_relocation", True)),
        project_dir=legacy_context.get("project_dir"),
    )

    return _find_image_path_with_context(
        screenshot_path=screenshot_path,
        screenshots_dir=screenshots_dir,
        context=context,
    )


def _find_image_path_with_context(
    *,
    screenshot_path: str,
    screenshots_dir: Path,
    context: ImageLookupContext,
) -> tuple[Path | None, dict | None]:
    """Resolve screenshot path using direct, local, and client-tree lookups."""
    if context.debug:
        logger.debug(f"Looking for image: {screenshot_path}")
        logger.debug(f"Base screenshots dir: {screenshots_dir}")

    path_obj = Path(screenshot_path)
    exact_match = _try_exact_path(path_obj=path_obj, debug=context.debug)
    if exact_match:
        return exact_match, None

    screenshots_dir_match = _try_screenshots_dir_path(
        screenshot_path=screenshot_path,
        path_obj=path_obj,
        screenshots_dir=screenshots_dir,
        context=context,
    )
    if screenshots_dir_match:
        return screenshots_dir_match

    client_tree_match = _try_client_tree_path(
        screenshot_path=screenshot_path,
        path_obj=path_obj,
        context=context,
    )
    if client_tree_match:
        return client_tree_match

    if context.debug:
        logger.debug(f"Image not found: {screenshot_path}")
    return None, None


def _try_exact_path(*, path_obj: Path, debug: bool) -> Path | None:
    """Return exact path when it exists."""
    if not path_obj.exists():
        return None
    if debug:
        logger.debug(f"Found image at exact path: {path_obj}")
    return path_obj


def _try_screenshots_dir_path(
    *,
    screenshot_path: str,
    path_obj: Path,
    screenshots_dir: Path,
    context: ImageLookupContext,
) -> tuple[Path, dict | None] | None:
    """Try resolving image by filename inside screenshots root."""
    rel_path = screenshots_dir / path_obj.name
    if not rel_path.exists():
        return None

    if context.debug:
        logger.debug(f"Found image in screenshots dir: {rel_path}")
    relocation_info = _build_relocation_info(
        screenshot_path=screenshot_path,
        found_path=rel_path,
        method="screenshots_dir",
        report_relocation=context.report_relocation,
    )
    return rel_path, relocation_info


def _try_client_tree_path(
    *,
    screenshot_path: str,
    path_obj: Path,
    context: ImageLookupContext,
) -> tuple[Path, dict | None] | None:
    """Try relocation cache and client directory tree scan."""
    if not context.client_base_dir:
        return None

    if context.debug:
        logger.debug(f"Searching in client base dir: {context.client_base_dir}")

    cache_match = _try_relocation_cache(
        screenshot_path=screenshot_path,
        context=context,
    )
    if cache_match:
        return cache_match

    return _search_client_tree(
        screenshot_path=screenshot_path,
        file_name=path_obj.name,
        context=context,
    )


def _try_relocation_cache(
    *,
    screenshot_path: str,
    context: ImageLookupContext,
) -> tuple[Path, dict] | None:
    """Try cached relocation map in project directory."""
    if not context.project_dir or not context.report_relocation:
        return None

    relocation_log_path = context.project_dir / "image_relocation_log.json"
    if not relocation_log_path.exists():
        return None

    try:
        with open(relocation_log_path) as f:
            relocations = json.load(f)
    except Exception as e:
        if context.debug:
            logger.debug(f"Error checking relocation cache: {e}")
        return None

    for entry in relocations:
        if entry.get("original_path") != str(screenshot_path):
            continue
        found_path = Path(entry.get("found_path"))
        if not found_path.exists():
            continue
        if context.debug:
            logger.debug(f"Found image using relocation cache: {found_path}")
        entry_with_cache_marker = entry.copy()
        entry_with_cache_marker["from_cache"] = True
        return found_path, entry_with_cache_marker

    return None


def _search_client_tree(
    *,
    screenshot_path: str,
    file_name: str,
    context: ImageLookupContext,
) -> tuple[Path, dict | None] | None:
    """Walk client tree and return first matching filename."""
    if not context.client_base_dir:
        return None

    for root, _, files in os.walk(context.client_base_dir):
        if file_name not in files:
            continue

        found_path = Path(root) / file_name
        if context.debug:
            logger.debug(f"Found image in client tree: {found_path}")
        relocation_info = _build_relocation_info(
            screenshot_path=screenshot_path,
            found_path=found_path,
            method="client_tree_search",
            report_relocation=context.report_relocation,
        )
        return found_path, relocation_info

    return None


def _build_relocation_info(
    *,
    screenshot_path: str,
    found_path: Path,
    method: str,
    report_relocation: bool,
) -> dict | None:
    """Build relocation payload when relocation tracking is enabled."""
    if not report_relocation:
        return None
    return {
        "original_path": str(screenshot_path),
        "found_path": str(found_path),
        "method": method,
    }


def add_screenshot(
    target_story: list,
    screenshot_data: tuple,
    screenshot_num: int,
    *,
    context: ScreenshotRenderContext,
) -> None:
    """Add a screenshot to the PDF story.

    Args:
        target_story: The story list to append to
        screenshot_data: Tuple containing (timestamp, path, set_id, suffix)
        screenshot_num: Screenshot number
        screenshots_dir: Directory where screenshots are stored
        captions: Dictionary of screenshot captions
        image_quality: JPEG quality for compression
        image_dpi: DPI for images
        image_format: Format for image conversion
        max_dimension: Maximum dimension for images
        use_thumbnails: Whether to use small thumbnails
        thumbnail_size: Size for thumbnails
        debug: Enable debug logging
        styles: Dictionary of paragraph styles
        temp_files: List to track temporary files
        client_base_dir: Base directory for client files
        report_relocations: Whether to track image relocations
        relocation_log: List to log image relocations
        project_dir: Project directory for caching relocations
    """
    styles = context.styles or get_pdf_styles()

    temp_files = context.temp_files if context.temp_files is not None else []

    if context.options.debug:
        logger.debug(f"Adding screenshot #{screenshot_num}: {screenshot_data}")

    # Extract data from the tuple
    timestamp, screenshot_path, set_id, _suffix = screenshot_data

    # Find the image (handles relocations)
    img_path, relocation_info = find_image_path(
        screenshot_path=screenshot_path,
        screenshots_dir=context.screenshots_dir,
        context=ImageLookupContext(
            client_base_dir=context.client_base_dir,
            debug=context.options.debug,
            report_relocation=context.report_relocations,
            project_dir=context.project_dir,
        ),
    )

    # Track relocation if needed
    if relocation_info and context.relocation_log is not None:
        context.relocation_log.append(relocation_info)

    # Add timestamp
    target_story.append(
        Paragraph(f"Screenshot #{screenshot_num} at {timestamp}", styles["Timestamp"])
    )

    # Add set ID if available
    if set_id:
        target_story.append(Paragraph(f"Set: {set_id}", styles["Caption"]))

    # Add image if found
    if img_path and img_path.exists():
        # Optimize the image
        optimized_path = optimize_image(img_path=img_path, options=context.options)

        if optimized_path:
            # Track temporary file for cleanup
            temp_files.append(optimized_path)

            # Add the image to the document
            img = Image(optimized_path, width=540, height=720, kind="proportional")
            img.hAlign = "CENTER"
            target_story.append(img)
        else:
            # If optimization failed, use original
            try:
                img = Image(str(img_path), width=540, height=720, kind="proportional")
                img.hAlign = "CENTER"
                target_story.append(img)
            except Exception as e:
                logger.error(f"Error adding image {img_path}: {e}")
                target_story.append(
                    Paragraph(f"[Image not available: {img_path.name}]", styles["Note"])
                )
    else:
        # Image not found
        target_story.append(Paragraph(f"[Image not found: {screenshot_path}]", styles["Note"]))

    # Add caption if available
    if screenshot_num in context.captions:
        _, caption_text = context.captions[screenshot_num]
        target_story.append(Paragraph(f"Caption: {caption_text}", styles["Caption"]))

    # Add spacer
    target_story.append(Spacer(1, 0.2 * inch))


def cleanup_temp_files(temp_files: list[str], debug: bool = False) -> None:
    """Clean up temporary files created during PDF generation.

    Args:
        temp_files: List of paths to temporary files
        debug: Enable debug logging
    """
    if debug:
        logger.debug(f"Cleaning up {len(temp_files)} temporary files")

    for file_path in temp_files:
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                if debug:
                    logger.debug(f"Removed temporary file: {file_path}")
        except Exception as e:
            logger.error(f"Error removing temporary file {file_path}: {e}")
