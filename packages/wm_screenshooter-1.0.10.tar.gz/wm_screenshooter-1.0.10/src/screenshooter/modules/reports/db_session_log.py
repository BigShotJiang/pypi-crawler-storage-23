#!/usr/bin/env python3
"""Database-enabled session log for reports.

Provides database-backed session data to complement file-based parsing.
"""

from datetime import datetime
from pathlib import Path
from typing import Any

from screenshooter.modules.database import DatabaseOperations


class DatabaseSessionLog:
    """Database-backed session log implementation."""

    def __init__(self, client_name: str, project_name: str, session_name: str):
        """Initialize database session log.

        Args:
            client_name: Client name
            project_name: Project name
            session_name: Session name
        """
        self.client_name = client_name
        self.project_name = project_name
        self.session_name = session_name

        # Database operations
        self.db_operations = None
        self.session_data = None

        # Try to initialize database
        self._load_from_database()

    def _load_from_database(self) -> None:
        """Load session data from database."""
        try:
            self.db_operations = DatabaseOperations()

            # Find client
            client = self.db_operations.get_client_by_directory(self.client_name)
            if not client:
                return

            # Find project
            project = self.db_operations.get_project_by_name(client.id, self.project_name)
            if not project:
                return

            # Find session
            session = self.db_operations.get_session_by_name(project.id, self.session_name)
            if not session:
                return

            self.session_data = session

        except Exception:
            # Database not available or error occurred
            self.db_operations = None

    @property
    def session_start(self) -> datetime | None:
        """Get session start time."""
        return self.session_data.start_time if self.session_data else None

    @property
    def session_end(self) -> datetime | None:
        """Get session end time."""
        return self.session_data.end_time if self.session_data else None

    @property
    def session_duration(self) -> str | None:
        """Get formatted session duration."""
        if not self.session_data or not self.session_data.duration_seconds:
            return None

        hours = self.session_data.duration_seconds // 3600
        minutes = (self.session_data.duration_seconds % 3600) // 60
        seconds = self.session_data.duration_seconds % 60

        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        else:
            return f"{seconds}s"

    @property
    def session_note(self) -> str | None:
        """Get session note."""
        return self.session_data.session_note if self.session_data else None

    @property
    def screenshots(self) -> list[dict[str, Any]]:
        """Get screenshots for this session."""
        if not self.db_operations or not self.session_data:
            return []

        try:
            db_screenshots = self.db_operations.list_screenshots(self.session_data.id)
            return [
                {
                    "file_path": screenshot.file_path,
                    "timestamp": screenshot.timestamp,
                    "suffix": screenshot.suffix or "",
                    "display_mode": screenshot.display_mode or "",
                    "set_id": screenshot.set_id,
                }
                for screenshot in db_screenshots
            ]
        except Exception:
            return []

    @property
    def notes(self) -> list[dict[str, Any]]:
        """Get notes for this session."""
        if not self.db_operations or not self.session_data:
            return []

        try:
            db_notes = self.db_operations.list_notes(self.session_data.id)
            return [{"content": note.content, "timestamp": note.timestamp} for note in db_notes]
        except Exception:
            return []

    @property
    def captions(self) -> dict[int, str]:
        """Get captions for this session."""
        if not self.db_operations or not self.session_data:
            return {}

        try:
            db_captions = self.db_operations.list_captions(self.session_data.id)
            return {caption.set_id: caption.content for caption in db_captions}
        except Exception:
            return {}

    @property
    def chronological_events(self) -> list[dict[str, Any]]:
        """Get all events in chronological order."""
        events = []

        # Add screenshots
        for screenshot in self.screenshots:
            events.append(
                {
                    "type": "screenshot",
                    "timestamp": screenshot["timestamp"],
                    "set_id": screenshot["set_id"],
                    "data": screenshot,
                }
            )

        # Add notes
        for note in self.notes:
            events.append({"type": "note", "timestamp": note["timestamp"], "data": note})

        # Sort by timestamp
        events.sort(key=lambda x: x["timestamp"])
        return events

    def is_available(self) -> bool:
        """Check if database data is available.

        Returns:
            True if database data is available
        """
        return self.session_data is not None


def create_database_session_log(
    client_name: str, project_name: str, session_name: str, session_dir: Path
) -> "DatabaseSessionLog":
    """Create a database-backed session log.

    Args:
        client_name: Client name
        project_name: Project name
        session_name: Session name
        session_dir: Session directory path

    Returns:
        DatabaseSessionLog instance
    """
    return DatabaseSessionLog(client_name, project_name, session_name)
