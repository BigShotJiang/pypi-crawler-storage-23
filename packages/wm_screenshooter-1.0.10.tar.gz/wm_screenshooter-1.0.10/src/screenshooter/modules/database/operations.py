#!/usr/bin/env python3
"""Database operations for ScreenShooter Mac.

Provides CRUD operations for all database entities, mirroring
the existing file-based logging functionality.
"""

import json

from .database import DatabaseManager
from .models import (
    DatabaseClient,
    DatabaseNote,
    DatabaseProject,
    DatabaseScreenshot,
    DatabaseSession,
)


class DatabaseOperations:
    """Handles all database CRUD operations."""

    def __init__(self, db_manager: DatabaseManager | None = None):
        """Initialize database operations.

        Args:
            db_manager: Optional database manager instance
        """
        self.db = db_manager or DatabaseManager()

    # Client operations
    def create_client(self, client: DatabaseClient) -> int | None:
        """Create a new client record.

        Args:
            client: Client data

        Returns:
            Client ID
        """
        cursor = self.db.execute_query(
            """
            INSERT INTO clients (name, directory_name, company_name, contact_name,
                               contact_email, pdf_password, preferences)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                client.name,
                client.directory_name,
                client.company_name,
                client.contact_name,
                client.contact_email,
                client.pdf_password,
                json.dumps(client.preferences),
            ),
        )
        self.db.commit()
        client_id = cursor.lastrowid
        if client_id is None:
            raise RuntimeError("Failed to create client: no ID returned")
        return client_id

    def get_client_by_name(self, name: str) -> DatabaseClient | None:
        """Get client by name.

        Args:
            name: Client name

        Returns:
            Client data or None if not found
        """
        cursor = self.db.execute_query("SELECT * FROM clients WHERE name = ?", (name,))
        row = cursor.fetchone()
        if row:
            return self._row_to_client(row)
        return None

    def get_client_by_directory(self, directory_name: str) -> DatabaseClient | None:
        """Get client by directory name.

        Args:
            directory_name: Client directory name

        Returns:
            Client data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM clients WHERE directory_name = ?", (directory_name,)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_client(row)
        return None

    def list_clients(self, active_only: bool = False) -> list[DatabaseClient]:
        """List clients.

        Args:
            active_only: If True, only return active clients (not archived)

        Returns:
            List of clients
        """
        if active_only:
            cursor = self.db.execute_query(
                "SELECT * FROM clients WHERE archived_at IS NULL ORDER BY name"
            )
        else:
            cursor = self.db.execute_query("SELECT * FROM clients ORDER BY name")
        return [self._row_to_client(row) for row in cursor.fetchall()]

    def update_client(self, client: DatabaseClient) -> bool:
        """Update client record.

        Args:
            client: Updated client data

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE clients SET name = ?, directory_name = ?, company_name = ?,
                              contact_name = ?, contact_email = ?, pdf_password = ?,
                              preferences = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """,
            (
                client.name,
                client.directory_name,
                client.company_name,
                client.contact_name,
                client.contact_email,
                client.pdf_password,
                json.dumps(client.preferences),
                client.id,
            ),
        )
        self.db.commit()
        return cursor.rowcount > 0

    # Project operations
    def create_project(self, project: DatabaseProject) -> int | None:
        """Create a new project record.

        Args:
            project: Project data

        Returns:
            Project ID
        """
        cursor = self.db.execute_query(
            """
            INSERT INTO projects (client_id, name, directory_name)
            VALUES (?, ?, ?)
            """,
            (project.client_id, project.name, project.directory_name),
        )
        self.db.commit()
        project_id = cursor.lastrowid
        if project_id is None:
            raise RuntimeError("Failed to create project: no ID returned")
        return project_id

    def get_project_by_name(self, client_id: int, name: str) -> DatabaseProject | None:
        """Get project by client ID and name.

        Args:
            client_id: Client ID
            name: Project name

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM projects WHERE client_id = ? AND name = ?", (client_id, name)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def get_project_by_directory(
        self, client_id: int, directory_name: str
    ) -> DatabaseProject | None:
        """Get project by client ID and directory name.

        Args:
            client_id: Client ID
            directory_name: Project directory name

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM projects WHERE client_id = ? AND directory_name = ?",
            (client_id, directory_name),
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def get_project_by_id(self, project_id: int) -> DatabaseProject | None:
        """Get project by ID.

        Args:
            project_id: Project ID

        Returns:
            Project data or None if not found
        """
        cursor = self.db.execute_query("SELECT * FROM projects WHERE id = ?", (project_id,))
        row = cursor.fetchone()
        if row:
            return self._row_to_project(row)
        return None

    def list_projects(self, client_id: int, active_only: bool = True) -> list[DatabaseProject]:
        """List projects for a client.

        Args:
            client_id: Client ID
            active_only: If True, only return active projects

        Returns:
            List of projects
        """
        if active_only:
            cursor = self.db.execute_query(
                """
                SELECT * FROM projects
                WHERE client_id = ? AND archived_at IS NULL
                ORDER BY name
                """,
                (client_id,),
            )
        else:
            cursor = self.db.execute_query(
                "SELECT * FROM projects WHERE client_id = ? ORDER BY name", (client_id,)
            )
        return [self._row_to_project(row) for row in cursor.fetchall()]

    def list_archived_projects(self, client_id: int) -> list[DatabaseProject]:
        """List archived projects for a client, ordered by most recently archived.

        Args:
            client_id: Client ID

        Returns:
            List of archived projects ordered by updated_at DESC
        """
        cursor = self.db.execute_query(
            """
            SELECT * FROM projects
            WHERE client_id = ? AND archived_at IS NOT NULL
            ORDER BY archived_at DESC
            """,
            (client_id,),
        )
        return [self._row_to_project(row) for row in cursor.fetchall()]

    def update_project_name(self, project_id: int, new_name: str) -> bool:
        """Update a project's display name.

        Args:
            project_id: Project ID to update
            new_name: New display name for the project

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET name = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (new_name, project_id),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def list_archived_clients(self) -> list[DatabaseClient]:
        """List archived clients, ordered by most recently archived.

        Returns:
            List of archived clients ordered by archived_at DESC
        """
        cursor = self.db.execute_query(
            """
            SELECT * FROM clients
            WHERE archived_at IS NOT NULL
            ORDER BY archived_at DESC
            """
        )
        return [self._row_to_client(row) for row in cursor.fetchall()]

    # Session operations

    def create_session(self, session: DatabaseSession) -> int | None:
        """Create a new session record.

        Args:
            session: Session data

        Returns:
            Session ID
        """
        cursor = self.db.execute_query(
            """
            INSERT INTO sessions (project_id, name, start_time, end_time,
                                duration_seconds, timer_mode)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                session.project_id,
                session.name,
                session.start_time,
                session.end_time,
                session.duration_seconds,
                session.timer_mode,
            ),
        )
        self.db.commit()
        session_id = cursor.lastrowid
        if session_id is None:
            raise RuntimeError("Failed to create session: no ID returned")
        return session_id

    def update_session(self, session: DatabaseSession) -> bool:
        """Update session record.

        Args:
            session: Updated session data

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE sessions SET end_time = ?, duration_seconds = ?, 
                              timer_mode = ?
            WHERE id = ?
        """,
            (
                session.end_time,
                session.duration_seconds,
                session.timer_mode,
                session.id,
            ),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_session(self, session_id: int) -> bool:
        """Archive a session (soft delete).

        Args:
            session_id: Session ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE sessions
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP)
            WHERE id = ?
            """,
            (session_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_client(self, client_id: int) -> bool:
        """Archive a client and all related data (soft delete).

        Args:
            client_id: Client ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE clients
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP)
            WHERE id = ?
            """,
            (client_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_client(self, client_id: int) -> bool:
        """Unarchive a client.

        Args:
            client_id: Client ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            "UPDATE clients SET archived_at = NULL WHERE id = ?",
            (client_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_project(self, project_id: int) -> bool:
        """Archive a project and all related data (soft delete).

        Args:
            project_id: Project ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (project_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_project(self, project_id: int) -> bool:
        """Unarchive a project (restore from soft delete).

        Args:
            project_id: Project ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE projects
            SET archived_at = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (project_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_screenshot(self, screenshot_id: int) -> bool:
        """Archive a screenshot (soft delete).

        Args:
            screenshot_id: Screenshot ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE screenshots
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP)
            WHERE id = ?
            """,
            (screenshot_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def archive_note(self, note_id: int) -> bool:
        """Archive a note (soft delete).

        Args:
            note_id: Note ID to archive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE notes
            SET archived_at = COALESCE(archived_at, CURRENT_TIMESTAMP)
            WHERE id = ?
            """,
            (note_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_screenshot(self, screenshot_id: int) -> bool:
        """Unarchive a screenshot (restore from soft delete).

        Args:
            screenshot_id: Screenshot ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE screenshots
            SET archived_at = NULL
            WHERE id = ?
            """,
            (screenshot_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def unarchive_note(self, note_id: int) -> bool:
        """Unarchive a note (restore from soft delete).

        Args:
            note_id: Note ID to unarchive

        Returns:
            True if successful, False otherwise
        """
        cursor = self.db.execute_query(
            """
            UPDATE notes
            SET archived_at = NULL
            WHERE id = ?
            """,
            (note_id,),
        )
        self.db.commit()
        return cursor.rowcount > 0

    def get_session_by_name(self, project_id: int, name: str) -> DatabaseSession | None:
        """Get session by project ID and name.

        Args:
            project_id: Project ID
            name: Session name

        Returns:
            Session data or None if not found
        """
        cursor = self.db.execute_query(
            "SELECT * FROM sessions WHERE project_id = ? AND name = ?", (project_id, name)
        )
        row = cursor.fetchone()
        if row:
            return self._row_to_session(row)
        return None

    def list_sessions(self, project_id: int) -> list[DatabaseSession]:
        """List sessions for a project.

        Args:
            project_id: Project ID

        Returns:
            List of sessions
        """
        cursor = self.db.execute_query(
            "SELECT * FROM sessions WHERE project_id = ? ORDER BY start_time DESC", (project_id,)
        )
        return [self._row_to_session(row) for row in cursor.fetchall()]

    # Screenshot operations

    def create_screenshot(self, screenshot: DatabaseScreenshot) -> int | None:
        """Create a new screenshot record.

        Args:
            screenshot: Screenshot data

        Returns:
            Screenshot ID
        """
        cursor = self.db.execute_query(
            """
            INSERT INTO screenshots (session_id, set_id, file_path, timestamp,
                                   display_mode, suffix)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                screenshot.session_id,
                screenshot.set_id,
                screenshot.file_path,
                screenshot.timestamp,
                screenshot.display_mode,
                screenshot.suffix,
            ),
        )
        self.db.commit()
        screenshot_id = cursor.lastrowid
        if screenshot_id is None:
            raise RuntimeError("Failed to create screenshot: no ID returned")
        return screenshot_id

    def list_screenshots(
        self, session_id: int, include_archived: bool = False
    ) -> list[DatabaseScreenshot]:
        """List screenshots for a session.

        Args:
            session_id: Session ID
            include_archived: If True, include archived screenshots

        Returns:
            List of screenshots
        """
        if include_archived:
            cursor = self.db.execute_query(
                "SELECT * FROM screenshots WHERE session_id = ? ORDER BY timestamp", (session_id,)
            )
        else:
            cursor = self.db.execute_query(
                (
                    "SELECT * FROM screenshots WHERE session_id = ? AND archived_at IS NULL "
                    "ORDER BY timestamp"
                ),
                (session_id,),
            )
        return [self._row_to_screenshot(row) for row in cursor.fetchall()]

    def list_all_screenshots(self) -> list[DatabaseScreenshot]:
        """List all screenshots across all sessions.

        Returns:
            List of all screenshots
        """
        cursor = self.db.execute_query("SELECT * FROM screenshots ORDER BY timestamp")
        return [self._row_to_screenshot(row) for row in cursor.fetchall()]

    # Note operations

    def create_note(self, note: DatabaseNote) -> int | None:
        """Create a new note record.

        Args:
            note: Note data

        Returns:
            Note ID
        """
        cursor = self.db.execute_query(
            """
            INSERT INTO notes (session_id, content, note_type, timestamp)
            VALUES (?, ?, ?, ?)
            """,
            (note.session_id, note.content, note.note_type, note.timestamp),
        )
        self.db.commit()
        note_id = cursor.lastrowid
        if note_id is None:
            raise RuntimeError("Failed to create note: no ID returned")
        return note_id

    def list_notes(self, session_id: int, include_archived: bool = False) -> list[DatabaseNote]:
        """List notes for a session.

        Args:
            session_id: Session ID
            include_archived: If True, include archived notes

        Returns:
            List of notes
        """
        if include_archived:
            cursor = self.db.execute_query(
                "SELECT * FROM notes WHERE session_id = ? ORDER BY timestamp", (session_id,)
            )
        else:
            cursor = self.db.execute_query(
                (
                    "SELECT * FROM notes WHERE session_id = ? AND archived_at IS NULL ORDER "
                    "BY timestamp"
                ),
                (session_id,),
            )
        return [self._row_to_note(row) for row in cursor.fetchall()]

    # Helper methods for converting database rows to models

    def _row_to_client(self, row) -> DatabaseClient:
        """Convert database row to DatabaseClient."""
        return DatabaseClient(
            id=row["id"],
            name=row["name"],
            directory_name=row["directory_name"],
            company_name=row["company_name"],
            contact_name=row["contact_name"],
            contact_email=row["contact_email"],
            pdf_password=row["pdf_password"],
            preferences=json.loads(row["preferences"]) if row["preferences"] else {},
            archived_at=row["archived_at"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def _row_to_project(self, row) -> DatabaseProject:
        """Convert database row to DatabaseProject."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        # Derive active flag from archived_at: NULL means active
        active_value = archived_at is None

        return DatabaseProject(
            id=row["id"],
            client_id=row["client_id"],
            name=row["name"],
            directory_name=row["directory_name"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def _row_to_session(self, row) -> DatabaseSession:
        """Convert database row to DatabaseSession."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseSession(
            id=row["id"],
            project_id=row["project_id"],
            name=row["name"],
            start_time=row["start_time"],
            end_time=row["end_time"],
            duration_seconds=row["duration_seconds"],
            timer_mode=row["timer_mode"],
            created_at=row["created_at"],
            active=active_value,
            archived_at=archived_at,
        )

    def _row_to_screenshot(self, row) -> DatabaseScreenshot:
        """Convert database row to DatabaseScreenshot."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseScreenshot(
            id=row["id"],
            session_id=row["session_id"],
            set_id=row["set_id"],
            file_path=row["file_path"],
            timestamp=row["timestamp"],
            display_mode=row["display_mode"],
            suffix=row["suffix"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
        )

    def _row_to_note(self, row) -> DatabaseNote:
        """Convert database row to DatabaseNote."""
        row_keys = row.keys()
        archived_at = row["archived_at"] if "archived_at" in row_keys else None
        active_value = archived_at is None

        return DatabaseNote(
            id=row["id"],
            session_id=row["session_id"],
            content=row["content"],
            note_type=row["note_type"] if row["note_type"] else "note",
            timestamp=row["timestamp"],
            active=active_value,
            archived_at=archived_at,
            created_at=row["created_at"],
        )

    # No separate caption table anymore; captions are stored in ``notes``
    # with ``note_type = DatabaseNoteType.CAPTION``.
