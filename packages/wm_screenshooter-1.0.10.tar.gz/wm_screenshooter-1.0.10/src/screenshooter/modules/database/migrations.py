#!/usr/bin/env python3
"""Database migration utilities for ScreenShooter Mac.

Provides functionality to migrate existing log file data to the SQLite database.
"""

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from screenshooter.modules.settings.settings_helper import get_screenshots_dir

from .models import (
    DatabaseClient,
    DatabaseNote,
    DatabaseNoteType,
    DatabaseProject,
    DatabaseScreenshot,
    DatabaseSession,
)
from .operations import DatabaseOperations


class LogFileParser:
    """Parses existing log files to extract session data."""

    def __init__(self, log_file_path: Path):
        """Initialize parser with log file path.

        Args:
            log_file_path: Path to log file
        """
        self.log_file_path = log_file_path

    def parse_session_log(self) -> dict[str, Any]:
        """Parse session log file and extract structured data.

        Returns:
            Dictionary containing parsed session data
        """
        if not self.log_file_path.exists():
            return {}

        content = self.log_file_path.read_text()
        lines = content.strip().split("\n")

        session_data = {"screenshots": [], "notes": [], "captions": {}, "session_info": {}}

        session_data["session_info"] = self._load_session_info_json()

        # Parse log entries
        for line in lines:
            parsed_entry = self._parse_log_line(line)
            if not parsed_entry:
                continue
            message, timestamp = parsed_entry
            self._collect_session_entry(session_data, message, timestamp)

        return session_data

    def _load_session_info_json(self) -> dict[str, Any]:
        """Load session.json metadata for this log directory when available."""
        session_json_path = self.log_file_path.parent / "session.json"
        if not session_json_path.exists():
            return {}
        try:
            return json.loads(session_json_path.read_text())
        except json.JSONDecodeError:
            return {}

    @staticmethod
    def _parse_log_line(line: str) -> tuple[str, datetime] | None:
        """Parse a raw session log line into message and timestamp."""
        if not line.strip():
            return None
        timestamp_match = re.match(r"^\[([^\]]+)\] (.+)$", line)
        if not timestamp_match:
            return None
        timestamp_str, message = timestamp_match.groups()
        try:
            timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return None
        return message, timestamp

    def _collect_session_entry(
        self,
        session_data: dict[str, Any],
        message: str,
        timestamp: datetime,
    ) -> None:
        """Collect one parsed log entry into screenshots, notes, or captions."""
        if "Screenshot saved:" in message:
            screenshot_data = self._parse_screenshot_entry(message, timestamp)
            if screenshot_data:
                session_data["screenshots"].append(screenshot_data)
            return

        if message.startswith("NOTE: "):
            note_data = self._parse_note_entry(message, timestamp)
            if note_data:
                session_data["notes"].append(note_data)
            return

        if message.startswith("SESSION START NOTE: "):
            self._append_typed_note(
                session_data,
                message[len("SESSION START NOTE: ") :].strip(),
                timestamp,
                DatabaseNoteType.SESSION_START,
            )
            return

        if message.startswith("SESSION PAUSED: "):
            self._append_typed_note(
                session_data,
                message[len("SESSION PAUSED: ") :].strip(),
                timestamp,
                DatabaseNoteType.PAUSE,
            )
            return

        if message.startswith("Paused for ") or message.startswith("SESSION RESUMED"):
            session_data["notes"].append(
                {
                    "content": message.strip(),
                    "timestamp": timestamp,
                    "note_type": DatabaseNoteType.RESUME,
                }
            )
            return

        if "CAPTION for screenshot set #" in message:
            caption_data = self._parse_caption_entry(message, timestamp)
            if caption_data:
                set_id, content = caption_data
                session_data["captions"][str(set_id)] = {
                    "content": content,
                    "timestamp": timestamp,
                }

    @staticmethod
    def _append_typed_note(
        session_data: dict[str, Any],
        content: str,
        timestamp: datetime,
        note_type: DatabaseNoteType,
    ) -> None:
        """Append a typed note only when content is non-empty."""
        if not content:
            return
        session_data["notes"].append(
            {
                "content": content,
                "timestamp": timestamp,
                "note_type": note_type,
            }
        )

    def _parse_screenshot_entry(self, message: str, timestamp: datetime) -> dict[str, Any] | None:
        """Parse screenshot log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Screenshot data dictionary or None
        """
        # Example: "Set #1 - Screenshot saved: /path/to/file.jpg (all)"
        match = re.search(r"Set #(\d+) - Screenshot saved: (.+?) \((.+?)\)", message)
        if match:
            set_id, file_path, suffix = match.groups()
            return {
                "set_id": int(set_id),
                "file_path": file_path.strip(),
                "suffix": suffix.strip(),
                "timestamp": timestamp,
            }
        return None

    def _parse_note_entry(self, message: str, timestamp: datetime) -> dict[str, Any] | None:
        """Parse note log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Note data dictionary or None
        """
        # Example: "NOTE: This is a note"
        content = message[6:].strip()  # Remove "NOTE: " prefix
        if content:
            return {"content": content, "timestamp": timestamp}
        return None

    def _parse_caption_entry(self, message: str, timestamp: datetime) -> tuple[int, str] | None:
        """Parse caption log entry.

        Args:
            message: Log message
            timestamp: Entry timestamp

        Returns:
            Tuple of (set_id, content) or None
        """
        # Example: "CAPTION for screenshot set #1: This is a caption"
        match = re.search(r"CAPTION for screenshot set #(\d+): (.+)", message)
        if match:
            set_id, content = match.groups()
            return int(set_id), content.strip()
        return None


@dataclass
class SessionTimingContext:
    """Data needed to update migrated session timing."""

    project_id: int
    session_id: int
    session_name: str
    session_start: datetime
    session_timer_mode: str | None


class DatabaseMigrator:
    """Migrates existing log file data to database."""

    def __init__(self, db_operations: DatabaseOperations):
        """Initialize migrator with database operations.

        Args:
            db_operations: Database operations instance
        """
        self.db_ops = db_operations

    def _load_image_relocations(self, project_dir: Path) -> dict[str, str]:
        """Load image relocation mappings from project directory.

        Args:
            project_dir: Project directory path

        Returns:
            Dictionary mapping original paths to relocated paths
        """
        relocation_lookup = {}
        relocation_log_path = project_dir / "image_relocation_log.json"

        if relocation_log_path.exists():
            try:
                with open(relocation_log_path) as f:
                    relocations = json.load(f)

                for entry in relocations:
                    original_path = entry.get("original_path")
                    found_path = entry.get("found_path")
                    if original_path and found_path:
                        relocation_lookup[original_path] = found_path

                print(
                    f"Loaded {len(relocation_lookup)} image relocations from {relocation_log_path}"
                )

            except Exception as e:
                print(f"Error loading image relocations: {e}")

        return relocation_lookup

    def migrate_client_data(self, base_dir: Path) -> dict[str, int]:
        """Migrate all client data from file structure to database.

        Args:
            base_dir: Base screenshots directory

        Returns:
            Dictionary mapping client directory names to database IDs
        """
        client_mappings = {}

        for client_dir in base_dir.iterdir():
            if not client_dir.is_dir():
                continue

            client_info_file = client_dir / "client.json"
            if not client_info_file.exists():
                continue

            try:
                client_info = json.loads(client_info_file.read_text())

                # Check if client already exists
                existing_client = self.db_ops.get_client_by_directory(client_dir.name)
                if existing_client:
                    client_mappings[client_dir.name] = existing_client.id
                    continue

                # Create new client record
                db_client = DatabaseClient(
                    name=client_info.get("client_name", client_dir.name),
                    directory_name=client_dir.name,
                    company_name=client_info.get("company_name", ""),
                    contact_name=client_info.get("contact_name", ""),
                    contact_email=client_info.get("contact_email", ""),
                    pdf_password=client_info.get("pdf_password", ""),
                    preferences=client_info.get("preferences", {}),
                )

                client_id = self.db_ops.create_client(db_client)
                client_mappings[client_dir.name] = client_id

            except (json.JSONDecodeError, Exception):
                # Skip problematic client directories
                continue

        return client_mappings

    def migrate_project_data(
        self, base_dir: Path, client_mappings: dict[str, int]
    ) -> dict[str, int]:
        """Migrate project data for all clients.

        Args:
            base_dir: Base screenshots directory
            client_mappings: Client directory name to ID mapping

        Returns:
            Dictionary mapping project paths to database IDs
        """
        project_mappings = {}

        for client_dir_name, client_id in client_mappings.items():
            client_dir = base_dir / client_dir_name
            regular_projects, archived_projects = self._collect_project_dirs(client_dir)

            self._migrate_project_batch(
                client_id=client_id,
                project_dirs=regular_projects,
                project_mappings=project_mappings,
                active=True,
            )
            self._migrate_project_batch(
                client_id=client_id,
                project_dirs=archived_projects,
                project_mappings=project_mappings,
                active=False,
            )

        return project_mappings

    def _collect_project_dirs(self, client_dir: Path) -> tuple[list[Path], list[Path]]:
        """Collect regular and archived project directories with sessions."""
        regular_projects = self._list_project_dirs(client_dir, exclude_archive_dir=True)
        archive_dir = client_dir / "archive"
        archived_projects = self._list_project_dirs(archive_dir, exclude_archive_dir=False)
        return regular_projects, archived_projects

    @staticmethod
    def _list_project_dirs(projects_root: Path, *, exclude_archive_dir: bool) -> list[Path]:
        """List valid project directories under a root folder."""
        if not projects_root.exists() or not projects_root.is_dir():
            return []

        project_dirs: list[Path] = []
        for project_dir in projects_root.iterdir():
            if not project_dir.is_dir():
                continue
            if exclude_archive_dir and project_dir.name == "archive":
                continue
            if not (project_dir / "sessions").exists():
                continue
            project_dirs.append(project_dir)
        return project_dirs

    def _migrate_project_batch(
        self,
        *,
        client_id: int,
        project_dirs: list[Path],
        project_mappings: dict[str, int],
        active: bool,
    ) -> None:
        """Migrate a batch of project directories."""
        for project_dir in project_dirs:
            existing_project = self.db_ops.get_project_by_name(client_id, project_dir.name)
            if existing_project:
                project_mappings[str(project_dir)] = existing_project.id
                continue

            db_project = DatabaseProject(
                client_id=client_id,
                name=project_dir.name,
                directory_name=project_dir.name,
                active=active,
            )
            project_id = self.db_ops.create_project(db_project)
            project_mappings[str(project_dir)] = project_id

    def migrate_session_data(self, base_dir: Path, project_mappings: dict[str, int]) -> None:
        """Migrate session data for all projects.

        Args:
            base_dir: Base screenshots directory
            project_mappings: Project path to ID mapping
        """
        for project_path, project_id in project_mappings.items():
            project_dir = Path(project_path)
            sessions_dir = project_dir / "sessions"

            if not sessions_dir.exists():
                continue

            for session_dir in sessions_dir.iterdir():
                if not session_dir.is_dir():
                    continue

                self._migrate_single_session(session_dir, project_id)

    def _migrate_single_session(self, session_dir: Path, project_id: int) -> None:
        """Migrate a single session directory.

        Args:
            session_dir: Session directory path
            project_id: Project database ID
        """
        # Parse session log
        log_file = session_dir / "session.log"
        parser = LogFileParser(log_file)
        session_data = parser.parse_session_log()

        if not session_data:
            return

        # Load image relocation data if available
        project_dir = session_dir.parent.parent
        relocation_lookup = self._load_image_relocations(project_dir)
        self._apply_relocations_to_session_data(session_data, relocation_lookup)

        session_info = session_data.get("session_info", {})
        session_name, start_time, timer_mode = self._resolve_session_metadata(
            session_dir, session_info
        )
        (
            session_id,
            session_start_for_duration,
            session_timer_mode_for_update,
        ) = self._get_or_create_session_record(
            project_id,
            session_name,
            start_time,
            timer_mode,
            session_info,
        )

        event_timestamps = self._migrate_session_events(session_id, session_data)
        timing_context = SessionTimingContext(
            project_id=project_id,
            session_id=session_id,
            session_name=session_name,
            session_start=session_start_for_duration,
            session_timer_mode=session_timer_mode_for_update,
        )
        self._update_session_timing(
            timing_context,
            event_timestamps,
        )

    @staticmethod
    def _apply_relocations_to_session_data(
        session_data: dict[str, Any],
        relocation_lookup: dict[str, str],
    ) -> None:
        """Apply relocated image paths to parsed screenshot entries."""
        for screenshot in session_data.get("screenshots", []):
            original_path = screenshot["file_path"]
            if original_path not in relocation_lookup:
                continue
            screenshot["file_path"] = relocation_lookup[original_path]
            print(f"Applied relocation: {original_path} -> {screenshot['file_path']}")

    @staticmethod
    def _resolve_session_metadata(
        session_dir: Path,
        session_info: dict[str, Any],
    ) -> tuple[str, datetime, str | None]:
        """Resolve session name/start/timer metadata from legacy files."""
        session_name = session_dir.name

        start_time_raw = session_info.get("session_start_time")
        if isinstance(start_time_raw, str):
            try:
                start_time = datetime.strptime(start_time_raw, "%Y-%m-%d_%H-%M-%S")
            except ValueError:
                start_time = datetime.now()
        else:
            start_time = datetime.now()

        raw_timer = session_info.get("timer")
        timer_mode = None if raw_timer is None else str(raw_timer)
        return session_name, start_time, timer_mode

    def _get_or_create_session_record(
        self,
        project_id: int,
        session_name: str,
        start_time: datetime,
        timer_mode: str | None,
        session_info: dict[str, Any],
    ) -> tuple[int, datetime, str | None]:
        """Get an existing session row or create a new one."""
        existing_session = self.db_ops.get_session_by_name(project_id, session_name)
        if existing_session and existing_session.id is not None:
            return existing_session.id, existing_session.start_time, existing_session.timer_mode

        db_session = DatabaseSession(
            project_id=project_id,
            name=session_name,
            start_time=start_time,
            timer_mode=timer_mode,
        )
        session_id = self.db_ops.create_session(db_session)

        session_note_text = session_info.get("session_note")
        if session_note_text:
            db_session_note = DatabaseNote(
                session_id=session_id,
                content=session_note_text,
                note_type=DatabaseNoteType.SESSION_START,
                timestamp=start_time,
            )
            self.db_ops.create_note(db_session_note)

        return session_id, start_time, timer_mode

    def _migrate_session_events(
        self, session_id: int, session_data: dict[str, Any]
    ) -> list[datetime]:
        """Migrate screenshots/notes/captions and return event timestamps."""
        event_timestamps: list[datetime] = []

        for screenshot_data in session_data.get("screenshots", []):
            event_timestamps.append(screenshot_data["timestamp"])
            db_screenshot = DatabaseScreenshot(
                session_id=session_id,
                set_id=screenshot_data["set_id"],
                file_path=screenshot_data["file_path"],
                timestamp=screenshot_data["timestamp"],
                suffix=screenshot_data.get("suffix", ""),
                display_mode=screenshot_data.get("suffix", ""),
            )
            self.db_ops.create_screenshot(db_screenshot)

        for note_data in session_data.get("notes", []):
            event_timestamps.append(note_data["timestamp"])
            db_note = DatabaseNote(
                session_id=session_id,
                content=note_data["content"],
                note_type=note_data.get("note_type", DatabaseNoteType.NOTE),
                timestamp=note_data["timestamp"],
            )
            self.db_ops.create_note(db_note)

        for set_id_str, caption_data in session_data.get("captions", {}).items():
            content = caption_data["content"]
            timestamp = caption_data["timestamp"]
            event_timestamps.append(timestamp)
            db_caption_note = DatabaseNote(
                session_id=session_id,
                content=f"[set #{set_id_str}] {content}",
                note_type=DatabaseNoteType.CAPTION,
                timestamp=timestamp,
            )
            self.db_ops.create_note(db_caption_note)

        return event_timestamps

    def _update_session_timing(
        self,
        timing_context: SessionTimingContext,
        event_timestamps: list[datetime],
    ) -> None:
        """Update end_time and duration inferred from migrated events."""
        if not event_timestamps:
            return

        end_time = max(event_timestamps)
        duration_seconds = int((end_time - timing_context.session_start).total_seconds())
        try:
            updated_session = DatabaseSession(
                id=timing_context.session_id,
                project_id=timing_context.project_id,
                name=timing_context.session_name,
                start_time=timing_context.session_start,
                end_time=end_time,
                duration_seconds=duration_seconds,
                timer_mode=timing_context.session_timer_mode,
            )
            self.db_ops.update_session(updated_session)
        except Exception:
            pass

    def migrate_all_data(self, base_dir: Path | None = None) -> None:
        """Migrate all existing data from file structure to database.

        Args:
            base_dir: Base screenshots directory. If None, uses settings.
        """
        if base_dir is None:
            base_dir = Path(get_screenshots_dir())

        print(f"Migrating data from {base_dir} to database...")

        # Migrate clients
        print("Migrating clients...")
        client_mappings = self.migrate_client_data(base_dir)
        print(f"Migrated {len(client_mappings)} clients")

        # Migrate projects
        print("Migrating projects...")
        project_mappings = self.migrate_project_data(base_dir, client_mappings)
        print(f"Migrated {len(project_mappings)} projects")

        # Migrate sessions
        print("Migrating sessions...")
        self.migrate_session_data(base_dir, project_mappings)
        print("Session migration completed")

        print("Data migration completed successfully!")
