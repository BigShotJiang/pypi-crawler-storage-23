#!/usr/bin/env python3
"""Upgrade check module for ScreenShooter.

This module provides functionality to check for new versions of ScreenShooter
using the GitLab releases API.
"""

import json
import logging
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests
from packaging import version

from screenshooter import __version__
from screenshooter.modules.settings.settings_helper import get_settings, save_settings

logger = logging.getLogger(__name__)
VERSION_HASH_PATTERN = re.compile(r"g([0-9a-fA-F]{7,40})")
ISSUE_REF_PATTERN = re.compile(r"(?<![\w/])#(\d+)")


def _commits_match(first: str | None, second: str | None) -> bool:
    """Return True when two commit identifiers refer to the same commit."""
    if not first or not second:
        return False
    left = first.lower()
    right = second.lower()
    return left.startswith(right) or right.startswith(left)


def _normalize_channel(raw_channel: str | None) -> str:
    """Normalize persisted update channel value."""
    if raw_channel == "dev":
        return "dev"
    return "release"


def _normalize_dev_branch(raw_branch: str | None) -> str:
    """Normalize persisted dev branch value."""
    branch = (raw_branch or "").strip()
    return branch if branch else "main"


def _extract_installed_commit_sha(version_string: str) -> str | None:
    """Extract git short/long SHA from a PEP 440 local version segment."""
    try:
        parsed = version.parse(version_string)
        local_part = parsed.local if isinstance(parsed, version.Version) else None
        local_text = str(local_part or "")
    except version.InvalidVersion:
        local_text = version_string

    match = VERSION_HASH_PATTERN.search(local_text)
    if match:
        return match.group(1).lower()

    return None


def _extract_issue_ids(text: str | None) -> list[str]:
    """Extract unique GitLab issue numbers from a text block."""
    if not text:
        return []

    issue_ids: list[str] = []
    seen: set[str] = set()
    for match in ISSUE_REF_PATTERN.findall(text):
        if match in seen:
            continue
        seen.add(match)
        issue_ids.append(match)
    return issue_ids


def _build_issue_links(issue_ids: list[str]) -> list[str]:
    """Build GitLab issue links for the project."""
    return [
        f"https://gitlab.com/workmaster/screenshooter/-/issues/{issue_id}"
        for issue_id in issue_ids
    ]


def _render_related_issue_lines(release_info: dict[str, Any]) -> list[str]:
    """Render issue-reference lines for console output."""
    issue_ids = release_info.get("issue_ids") or []
    issue_links = release_info.get("issue_links") or []
    if not issue_ids or not issue_links:
        return []

    return [
        f"Related to issue #{issue_id}: {issue_link}"
        for issue_id, issue_link in zip(issue_ids, issue_links, strict=False)
    ]


def _print_dev_update_details(
    *,
    console: Any,
    latest_version: str,
    release_info: dict[str, Any],
) -> None:
    """Print detailed dev update information for manual checks."""
    console.print(f"[green]✓ New dev commit available: {latest_version}[/green]")
    console.print(f"Current version: {__version__}")
    current_commit = release_info.get("current_commit_id") or "unknown"
    relationship = str(release_info.get("relationship", "unknown"))
    target_commit = release_info.get("short_id") or release_info.get("commit_id", "")
    console.print(f"Current commit: {current_commit}")
    console.print("")
    console.print(f"Target commit: {target_commit}")

    commit_url = str(release_info.get("web_url", "")).strip()
    if commit_url:
        console.print(f"Commit: {commit_url}")
    console.print("")

    commit_title = str(release_info.get("commit_title", "")).strip()
    if commit_title:
        console.print(f"Commit message: {commit_title}")

    for issue_line in _render_related_issue_lines(release_info):
        console.print(issue_line)

    if relationship == "unknown":
        console.print("[dim]Relationship: unknown (treating as update for safety)[/dim]")


def _print_dev_no_update_context(
    *,
    console: Any,
    dev_branch: str,
    release_info: dict[str, Any] | None,
) -> None:
    """Print dev-channel context when no updates are available."""
    console.print(f"[dim]Dev branch: {dev_branch}[/dim]")
    if release_info is None:
        current_commit = _extract_installed_commit_sha(__version__) or "unknown"
        console.print(f"[dim]Current commit: {current_commit}[/dim]")
        return

    current_commit = release_info.get("current_commit_id") or "unknown"
    target_commit = release_info.get("short_id") or release_info.get("commit_id", "")
    relationship = str(release_info.get("relationship", "unknown"))
    console.print(f"[dim]Current commit: {current_commit}[/dim]")
    console.print(f"[dim]Target commit: {target_commit}[/dim]")
    console.print(f"[dim]Relationship: {relationship}[/dim]")

    commit_title = str(release_info.get("commit_title", "")).strip()
    if commit_title:
        console.print(f"[dim]Latest commit message: {commit_title}[/dim]")

    for issue_line in _render_related_issue_lines(release_info):
        console.print(f"[dim]{issue_line}[/dim]")


def _get_local_git_head_sha() -> str | None:
    """Get current local git HEAD SHA when running from a checkout."""
    git_root: Path | None = None
    for parent in Path(__file__).resolve().parents:
        if (parent / ".git").exists():
            git_root = parent
            break

    if git_root is None:
        return None

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=git_root,
            check=False,
            capture_output=True,
            text=True,
        )
    except OSError:
        return None

    if result.returncode != 0:
        return None

    sha = result.stdout.strip().lower()
    if re.fullmatch(r"[0-9a-f]{40}", sha):
        return sha
    return None


def _is_release_notification_suppressed(
    latest_version: str, settings: Any, channel: str
) -> bool:
    """Check whether notification should be suppressed by user settings."""
    if settings.upgrade_check.skip_version == latest_version:
        return True

    if channel == "release" and settings.upgrade_check.pin_version:
        try:
            current_pin = version.parse(settings.upgrade_check.pin_version)
            latest_ver = version.parse(latest_version)
            if latest_ver > current_pin:
                return True
        except version.InvalidVersion:
            return False

    return False


def format_release_description_preview(description: str) -> str:
    """Format a release description into a preview with first few lines.

    Args:
        description: The full release description text

    Returns:
        Formatted preview string with dimmed styling, or empty string if no description
    """
    if not description:
        return ""

    desc = description.strip()
    if not desc:
        return ""

    # Clean up markdown and limit length
    desc = desc.replace("\r\n", "\n").replace("\r", "\n")
    lines = desc.split("\n")

    # Take first few lines, limit total length
    max_preview_length = 200
    max_preview_lines = 5
    preview_lines = []
    total_length = 0
    truncated = False

    for line in lines[:max_preview_lines]:  # First 5 lines max
        if total_length + len(line) > max_preview_length:
            truncated_line = line[: max_preview_length - total_length] + "..."
            preview_lines.append(truncated_line)
            truncated = True
            break
        preview_lines.append(line)
        total_length += len(line) + 1  # +1 for newline

    # Check if there are more lines or content was truncated
    has_more = len(lines) > max_preview_lines or truncated

    if preview_lines:
        desc_preview = "\n".join(preview_lines)
        if has_more:
            desc_preview += "\n[dim]...and more[/dim]"
        return f"\n[dim]{desc_preview}[/dim]"

    return ""


class GitLabUpgradeChecker:
    """Handles checking for application updates via GitLab releases API."""

    # GitLab project details
    PROJECT_ID = "workmaster%2Fscreenshooter"
    GITLAB_RELEASES_API_URL = f"https://gitlab.com/api/v4/projects/{PROJECT_ID}/releases"
    GITLAB_BRANCHES_API_URL = f"https://gitlab.com/api/v4/projects/{PROJECT_ID}/repository/branches"
    GITLAB_COMMITS_API_URL = f"https://gitlab.com/api/v4/projects/{PROJECT_ID}/repository/commits"
    GITLAB_MERGE_BASE_API_URL = (
        f"https://gitlab.com/api/v4/projects/{PROJECT_ID}/repository/merge_base"
    )

    @staticmethod
    def get_latest_release() -> dict[str, Any] | None:
        """Fetch the latest release from GitLab.

        Returns:
            Dictionary containing release information or None if failed
        """
        try:
            response = requests.get(GitLabUpgradeChecker.GITLAB_RELEASES_API_URL, timeout=10)
            response.raise_for_status()

            releases = response.json()
            if not releases:
                logger.debug("No releases found")
                return None

            # Get the first (latest) release
            latest = releases[0]

            # Extract version from tag_name (remove 'v' prefix if present)
            tag_name = latest.get("tag_name", "").lstrip("v")

            return {
                "version": tag_name,
                "name": latest.get("name", ""),
                "description": latest.get("description", ""),
                "released_at": latest.get("released_at", ""),
                "assets": latest.get("assets", {}).get("links", []),
                "tag_name": latest.get("tag_name", ""),
            }

        except (requests.RequestException, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Failed to fetch GitLab releases: {e}")
            return None

    @staticmethod
    def get_branch_head(branch_name: str) -> dict[str, Any] | None:
        """Fetch branch head commit information from GitLab."""
        encoded_branch = quote(branch_name, safe="")
        branch_url = f"{GitLabUpgradeChecker.GITLAB_BRANCHES_API_URL}/{encoded_branch}"
        try:
            response = requests.get(branch_url, timeout=10)
            response.raise_for_status()
            branch_data = response.json()
            commit = branch_data.get("commit", {})
            return {
                "branch": branch_data.get("name", branch_name),
                "commit_id": commit.get("id", ""),
                "short_id": commit.get("short_id", ""),
                "committed_date": commit.get("committed_date", ""),
                "web_url": commit.get("web_url", ""),
            }
        except (requests.RequestException, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Failed to fetch GitLab branch info for {branch_name}: {e}")
            return None

    @staticmethod
    def get_commit(commit_sha: str) -> dict[str, Any] | None:
        """Fetch commit details from GitLab."""
        encoded_sha = quote(commit_sha, safe="")
        commit_url = f"{GitLabUpgradeChecker.GITLAB_COMMITS_API_URL}/{encoded_sha}"
        try:
            response = requests.get(commit_url, timeout=10)
            response.raise_for_status()
            commit_data = response.json()
            return {
                "id": commit_data.get("id", ""),
                "short_id": commit_data.get("short_id", ""),
                "web_url": commit_data.get("web_url", ""),
                "title": commit_data.get("title", ""),
                "message": commit_data.get("message", ""),
            }
        except (requests.RequestException, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Failed to fetch commit info for {commit_sha}: {e}")
            return None

    @staticmethod
    def get_merge_base_sha(left_ref: str, right_ref: str) -> str | None:
        """Fetch merge-base SHA between two refs from GitLab."""
        try:
            response = requests.get(
                GitLabUpgradeChecker.GITLAB_MERGE_BASE_API_URL,
                params={"refs[]": [left_ref, right_ref]},
                timeout=10,
            )
            response.raise_for_status()
            merge_base_data = response.json()
            commit = merge_base_data.get("id")
            return str(commit).lower() if commit else None
        except (requests.RequestException, json.JSONDecodeError, KeyError) as e:
            logger.debug(f"Failed to fetch merge-base for {left_ref}..{right_ref}: {e}")
            return None

    @staticmethod
    def _resolve_current_commit_sha(current_commit: str | None) -> str | None:
        """Resolve current commit to full SHA when possible."""
        if not current_commit:
            return None
        commit_info = GitLabUpgradeChecker.get_commit(current_commit)
        if commit_info and commit_info.get("id"):
            return str(commit_info["id"]).lower()
        return current_commit.lower()

    @staticmethod
    def _get_dev_relationship(current_commit: str | None, branch_commit: str) -> str:
        """Return one of: identical, behind, ahead, diverged, unknown."""
        if not current_commit:
            return "unknown"
        if _commits_match(current_commit, branch_commit):
            return "identical"

        merge_base_sha = GitLabUpgradeChecker.get_merge_base_sha(current_commit, branch_commit)
        if not merge_base_sha:
            return "unknown"
        if _commits_match(merge_base_sha, current_commit):
            return "behind"
        if _commits_match(merge_base_sha, branch_commit):
            return "ahead"
        return "diverged"

    @staticmethod
    def _is_release_upgrade_available() -> tuple[bool, str | None, dict[str, Any] | None]:
        """Check if an upgrade is available in the release channel."""
        release = GitLabUpgradeChecker.get_latest_release()
        if not release:
            return False, None, None

        latest_version = release["version"]
        if not latest_version:
            return False, None, None

        try:
            current_ver = version.parse(__version__)
            latest_ver = version.parse(latest_version)
            is_available = latest_ver > current_ver
            return is_available, latest_version, release if is_available else None
        except version.InvalidVersion:
            logger.warning(
                f"Invalid version format: current={__version__}, latest={latest_version}"
            )
            return False, None, None

    @staticmethod
    def _is_dev_upgrade_available(
        branch_name: str,
    ) -> tuple[bool, str | None, dict[str, Any] | None]:
        """Check if local commit is behind configured branch head."""
        branch_info = GitLabUpgradeChecker.get_branch_head(branch_name)
        if not branch_info:
            return False, None, None

        branch_commit = str(branch_info.get("commit_id", "")).lower()
        short_id = str(branch_info.get("short_id", "")).lower()
        if not branch_commit:
            return False, None, None

        current_commit = _get_local_git_head_sha() or _extract_installed_commit_sha(__version__)
        resolved_current_commit = GitLabUpgradeChecker._resolve_current_commit_sha(current_commit)
        identifier = f"{branch_name}@{short_id or branch_commit[:8]}"
        relationship = GitLabUpgradeChecker._get_dev_relationship(
            resolved_current_commit,
            branch_commit,
        )
        is_available = current_commit is None or relationship in {"behind", "unknown"}

        current_commit_display = current_commit or "unknown"
        target_commit_info = GitLabUpgradeChecker.get_commit(branch_commit) or {}
        commit_title = str(target_commit_info.get("title", "")).strip()
        commit_message = str(target_commit_info.get("message", "")).strip()
        issue_ids = _extract_issue_ids(commit_message or commit_title)
        issue_links = _build_issue_links(issue_ids)

        return (
            is_available,
            identifier,
            {
                "channel": "dev",
                "branch": branch_name,
                "commit_id": branch_commit,
                "short_id": short_id,
                "current_commit_id": current_commit_display,
                "current_commit_resolved": resolved_current_commit,
                "relationship": relationship,
                "web_url": branch_info.get("web_url", ""),
                "commit_title": commit_title,
                "commit_message": commit_message,
                "issue_ids": issue_ids,
                "issue_links": issue_links,
            },
        )

    @staticmethod
    def get_latest_version() -> str | None:
        """Get the latest identifier for the configured channel.

        Returns:
            Latest version/identifier string or None if failed
        """
        _is_available, latest_version, _release_info = GitLabUpgradeChecker.is_upgrade_available()
        return latest_version

    @staticmethod
    def is_upgrade_available() -> tuple[bool, str | None, dict[str, Any] | None]:
        """Check if an upgrade is available.

        Returns:
            Tuple of (is_available, latest_version, release_info)
        """
        settings = get_settings()
        channel = _normalize_channel(getattr(settings.upgrade_check, "channel", "release"))
        if channel == "dev":
            dev_branch = _normalize_dev_branch(
                getattr(settings.upgrade_check, "dev_branch", "main")
            )
            return GitLabUpgradeChecker._is_dev_upgrade_available(dev_branch)
        return GitLabUpgradeChecker._is_release_upgrade_available()

    @staticmethod
    def check_and_notify(console=None) -> bool:
        """Check for updates and display notification if needed.

        Args:
            console: Rich console instance for output (optional)

        Returns:
            True if upgrade is available and notification shown, False otherwise
        """
        settings = get_settings()
        channel = _normalize_channel(getattr(settings.upgrade_check, "channel", "release"))
        dev_branch = _normalize_dev_branch(getattr(settings.upgrade_check, "dev_branch", "main"))
        is_available, latest_version, release_info = GitLabUpgradeChecker.is_upgrade_available()

        if is_available and latest_version and release_info:
            if _is_release_notification_suppressed(latest_version, settings, channel):
                return False  # Skip notification for this version

            if channel == "dev":
                message = "\n[bold yellow]A new dev update is available![/bold yellow]\n"
                message += f"Channel: dev ({dev_branch})\n"
                message += f"Current version: {__version__}\n"
                message += f"Latest commit: {latest_version}\n"
                current_commit = release_info.get("current_commit_id") or "unknown"
                target_commit = release_info.get("short_id") or release_info.get("commit_id", "")
                message += f"Current commit: {current_commit}\n"
                message += "\n"
                message += f"Target commit: {target_commit}\n"
                commit_url = str(release_info.get("web_url", "")).strip()
                if commit_url:
                    message += f"Commit: {commit_url}\n"
                message += "\n"
                commit_title = str(release_info.get("commit_title", "")).strip()
                if commit_title:
                    message += f"Commit message: {commit_title}\n"
                for issue_line in _render_related_issue_lines(release_info):
                    message += f"{issue_line}\n"
            else:
                message = (
                    "\n[bold yellow]A new version of ScreenShooter is available!"
                    "[/bold yellow]\n"
                )
                message += f"Current version: {__version__}\n"
                message += f"Latest version: {latest_version}\n"

                if release_info.get("name"):
                    message += f"Release: {release_info['name']}\n"

                message += (
                    "[dim]Download: "
                    f"https://gitlab.com/workmaster/screenshooter/-/releases/{release_info['tag_name']}[/dim]"
                )

                # Show release notes preview if available
                desc_preview = format_release_description_preview(
                    release_info.get("description", "")
                )
                if desc_preview:
                    message += desc_preview

            if console:
                console.print(message)
            else:
                print(message)

            return True

        return False

    @staticmethod
    def manual_check_and_display(console) -> None:
        """Perform a manual upgrade check and display results.

        Args:
            console: Rich console instance for output
        """
        settings = get_settings()
        channel = _normalize_channel(getattr(settings.upgrade_check, "channel", "release"))
        dev_branch = _normalize_dev_branch(getattr(settings.upgrade_check, "dev_branch", "main"))
        channel_label = f"{channel} ({dev_branch})" if channel == "dev" else "release"
        console.print(f"\n[bold]Checking for updates ({channel_label})...[/bold]")
        is_available, latest_version, release_info = GitLabUpgradeChecker.is_upgrade_available()

        if is_available and latest_version and release_info:
            if channel == "dev":
                _print_dev_update_details(
                    console=console,
                    latest_version=latest_version,
                    release_info=release_info,
                )
            else:
                console.print(f"[green]✓ New version available: {latest_version}[/green]")
                console.print(f"Current version: {__version__}")

                if release_info.get("name"):
                    console.print(f"Release: {release_info['name']}")

                console.print(
                    f"Download: https://gitlab.com/workmaster/screenshooter/-/releases/{release_info['tag_name']}"
                )

                # Show release notes preview if available
                desc_preview = format_release_description_preview(
                    release_info.get("description", "")
                )
                if desc_preview:
                    console.print(desc_preview)

            # Update last check time
            settings.upgrade_check.last_check = datetime.now()
            save_settings(settings)
        else:
            console.print("[dim]No updates available[/dim]")
            if channel == "dev":
                _print_dev_no_update_context(
                    console=console,
                    dev_branch=dev_branch,
                    release_info=release_info,
                )

            # Check if user has pinned or skipped any versions and inform them
            if channel == "release" and settings.upgrade_check.pin_version:
                console.print(
                    f"[dim]Note: You are pinned to max version "
                    f"{settings.upgrade_check.pin_version}[/dim]"
                )
                console.print(
                    "[dim]Automatic notifications are suppressed for versions newer "
                    "than this pin[/dim]"
                )
                console.print("[dim]To unpin: screenshooter upgrade unpin[/dim]")

            if settings.upgrade_check.skip_version:
                console.print(
                    f"[dim]Note: You are currently skipping upgrade notifications for "
                    f"version {settings.upgrade_check.skip_version}[/dim]"
                )
                console.print(
                    "[dim]To stop skipping: screenshooter upgrade skip stop[/dim]"
                )
                console.print(
                    "[dim]To skip a different version: screenshooter upgrade "
                    "skip <version>[/dim]"
                )


def check_for_updates(console=None) -> bool:
    """Convenience function to check for updates.

    Args:
        console: Rich console instance for output (optional)

    Returns:
        True if upgrade is available, False otherwise
    """
    return GitLabUpgradeChecker.check_and_notify(console)


class CachedUpgradeChecker:
    """Cached upgrade checker with channel-aware cache durations."""

    CACHE_FILE = Path.home() / ".config" / "screenshooter" / "upgrade_cache.json"
    RELEASE_CACHE_DURATION_DAYS = 7
    DEV_CACHE_DURATION_DAYS = 1

    @staticmethod
    def _resolve_release_cache_days(configured_days: Any) -> int:
        """Resolve release cache duration from settings with sane fallback."""
        try:
            parsed_days = int(configured_days)
        except (TypeError, ValueError):
            return CachedUpgradeChecker.RELEASE_CACHE_DURATION_DAYS

        # 0 or negative disables release cache reads and forces an upstream check.
        if parsed_days <= 0:
            return 0
        return parsed_days

    @staticmethod
    def _load_cache(
        channel: str, dev_branch: str, release_cache_days: int
    ) -> dict[str, Any] | None:
        """Load upgrade check cache from disk."""
        if not CachedUpgradeChecker.CACHE_FILE.exists():
            return None

        try:
            with open(CachedUpgradeChecker.CACHE_FILE) as f:
                cache_data = json.load(f)

            cached_at = datetime.fromisoformat(cache_data.get("cached_at", ""))
            cache_days = (
                CachedUpgradeChecker.DEV_CACHE_DURATION_DAYS
                if channel == "dev"
                else release_cache_days
            )
            if cache_days <= 0:
                return None

            # Cache entries are channel and branch specific.
            channel_matches = cache_data.get("channel", "release") == channel
            branch_matches = channel != "dev" or cache_data.get("dev_branch", "main") == dev_branch
            cache_is_fresh = (datetime.now() - cached_at).total_seconds() < (cache_days * 86400)
            version_matches = cache_data.get("current_version") == __version__

            if channel_matches and branch_matches and cache_is_fresh and version_matches:
                return cache_data
        except (json.JSONDecodeError, KeyError, ValueError):
            pass

        return None

    @staticmethod
    def _save_cache(
        is_available: bool,
        latest_version: str | None = None,
        channel: str = "release",
        dev_branch: str = "main",
    ) -> None:
        """Save upgrade check result to cache."""
        CachedUpgradeChecker.CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)

        cache_data = {
            "cached_at": datetime.now().isoformat(),
            "is_available": is_available,
            "latest_version": latest_version,
            "current_version": __version__,
            "channel": channel,
            "dev_branch": dev_branch,
        }

        try:
            with open(CachedUpgradeChecker.CACHE_FILE, "w") as f:
                json.dump(cache_data, f, indent=2)
        except (OSError, TypeError, ValueError):
            # Silently fail if we can't write cache
            pass

    @staticmethod
    def check_for_update_simple() -> bool:
        """Check for updates with caching. Returns True if update available and not skipped."""
        settings = get_settings()
        channel = _normalize_channel(getattr(settings.upgrade_check, "channel", "release"))
        dev_branch = _normalize_dev_branch(getattr(settings.upgrade_check, "dev_branch", "main"))
        release_cache_days = CachedUpgradeChecker._resolve_release_cache_days(
            getattr(settings.upgrade_check, "check_frequency_days", None)
        )

        # Dev channel intentionally checks upstream every time (no cache reads).
        if channel == "dev":
            is_available, latest_version, _ = GitLabUpgradeChecker.is_upgrade_available()
            if is_available and latest_version:
                is_available = not _is_release_notification_suppressed(
                    latest_version, settings, channel
                )
            CachedUpgradeChecker._save_cache(
                is_available,
                latest_version,
                channel=channel,
                dev_branch=dev_branch,
            )
            return is_available

        # First check cache
        cache = CachedUpgradeChecker._load_cache(channel, dev_branch, release_cache_days)
        if cache is not None:
            is_available = cache.get("is_available", False)
            if not is_available:
                return False

            latest_version = cache.get("latest_version")
            if not latest_version:
                return False
            if _is_release_notification_suppressed(latest_version, settings, channel):
                return False  # Don't notify about skipped versions

            return True

        # Cache miss or expired - fetch from API
        is_available, latest_version, _ = GitLabUpgradeChecker.is_upgrade_available()

        # Check if user wants to skip this version
        if is_available and latest_version:
            is_available = not _is_release_notification_suppressed(
                latest_version, settings, channel
            )

        # Cache the result
        CachedUpgradeChecker._save_cache(
            is_available,
            latest_version,
            channel=channel,
            dev_branch=dev_branch,
        )

        return is_available


def show_simple_upgrade_notification(console) -> None:
    """Show a simple one-line upgrade notification."""
    is_available = CachedUpgradeChecker.check_for_update_simple()
    if is_available:
        # Check if user wants to skip this version
        settings = get_settings()
        channel = _normalize_channel(getattr(settings.upgrade_check, "channel", "release"))
        dev_branch = _normalize_dev_branch(getattr(settings.upgrade_check, "dev_branch", "main"))
        release_cache_days = CachedUpgradeChecker._resolve_release_cache_days(
            getattr(settings.upgrade_check, "check_frequency_days", None)
        )
        cache = CachedUpgradeChecker._load_cache(channel, dev_branch, release_cache_days)
        latest_version = cache.get("latest_version") if cache else None

        if latest_version and not _is_release_notification_suppressed(
            latest_version, settings, channel
        ):
            console.print(
                "[yellow]Update available! "
                "Run 'screenshooter upgrade check' for details.[/yellow]"
            )
