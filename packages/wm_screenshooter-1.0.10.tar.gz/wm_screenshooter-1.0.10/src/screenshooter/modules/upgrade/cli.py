#!/usr/bin/env python3
"""Upgrade CLI commands for ScreenShooter."""

import click
from rich.console import Console

from screenshooter.modules.settings.settings_helper import get_settings, save_settings
from screenshooter.modules.upgrade.checker import GitLabUpgradeChecker

console = Console()


@click.group(invoke_without_command=True)
@click.pass_context
def upgrade(ctx: click.Context) -> None:
    """Manage upgrade checks and notifications."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@upgrade.command()
def help() -> None:
    """Show help for upgrade commands."""
    ctx = click.get_current_context()
    click.echo(ctx.parent.get_help())


@upgrade.command()
def check() -> None:
    """Check for application updates manually."""
    GitLabUpgradeChecker.manual_check_and_display(console)


@upgrade.command()
@click.option("--enable/--disable", default=None, help="Enable or disable upgrade checks")
@click.option("--frequency", type=int, help="Check frequency in days")
def settings(enable: bool | None, frequency: int | None) -> None:
    """Configure upgrade check settings."""
    current_settings = get_settings()

    if enable is not None:
        current_settings.upgrade_check.enabled = enable

    if frequency is not None:
        current_settings.upgrade_check.check_frequency_days = frequency

    save_settings(current_settings)
    console.print("[green]Upgrade check settings updated[/green]")


@upgrade.command()
@click.argument("channel", type=click.Choice(["release", "dev"]))
def channel(channel: str) -> None:
    """Set upgrade check channel (release or dev)."""
    current_settings = get_settings()
    current_settings.upgrade_check.channel = channel
    save_settings(current_settings)
    console.print(f"[green]Upgrade channel set to {channel}[/green]")
    if channel == "dev":
        console.print(
            f"[dim]Current dev branch target: {current_settings.upgrade_check.dev_branch}[/dim]"
        )


@upgrade.command()
@click.argument("branch_name")
def branch(branch_name: str) -> None:
    """Set the target branch used by dev-channel upgrade checks."""
    normalized_branch = branch_name.strip()
    if not normalized_branch:
        console.print("[red]Branch name cannot be empty[/red]")
        return

    current_settings = get_settings()
    current_settings.upgrade_check.dev_branch = normalized_branch
    save_settings(current_settings)
    console.print(f"[green]Dev upgrade branch set to {normalized_branch}[/green]")
    if current_settings.upgrade_check.channel != "dev":
        console.print("[dim]Note: upgrade channel is currently 'release'[/dim]")
        console.print("[dim]Enable dev channel: screenshooter upgrade channel dev[/dim]")


@upgrade.command()
def status() -> None:
    """Show current upgrade channel and branch targets."""
    current_settings = get_settings()
    configured_channel = current_settings.upgrade_check.channel
    console.print("\n[bold]Upgrade Channel Status[/bold]")
    console.print(f"Checks enabled: {'Yes' if current_settings.upgrade_check.enabled else 'No'}")
    console.print(f"Channel: {configured_channel}")
    if configured_channel == "dev":
        console.print(f"Dev branch: {current_settings.upgrade_check.dev_branch}")
        console.print("[dim]Check frequency: ignored (dev checks every run)[/dim]")
    else:
        console.print(
            f"[dim]Dev branch target (used when channel=dev): "
            f"{current_settings.upgrade_check.dev_branch}[/dim]"
        )
        console.print(
            "[dim]Check frequency: every "
            f"{current_settings.upgrade_check.check_frequency_days} day(s)[/dim]"
        )


@upgrade.command()
@click.argument("version")
def skip(version: str) -> None:
    """Skip upgrade notifications for a specific version, or clear skip setting."""
    current_settings = get_settings()

    if version.lower() in ["stop", "clear", "none", "reset"]:
        current_settings.upgrade_check.skip_version = None
        save_settings(current_settings)
        console.print("[green]Upgrade notification skipping has been cleared[/green]")
        console.print("[dim]You will now receive notifications for all available updates[/dim]")
        return

    current_settings.upgrade_check.skip_version = version
    save_settings(current_settings)
    console.print(f"[green]Will skip upgrade notifications for version {version}[/green]")
    console.print("[dim]To stop skipping this version: screenshooter upgrade skip stop[/dim]")


@upgrade.command()
@click.argument("version")
def pin(version: str) -> None:
    """Pin to a maximum allowed version for automatic notifications."""
    current_settings = get_settings()
    current_settings.upgrade_check.pin_version = version
    save_settings(current_settings)
    console.print(f"[green]Pinned to max version {version}[/green]")
    console.print(
        "[dim]You will not receive automatic notifications for versions newer than this "
        "version[/dim]"
    )
    console.print("[dim]Manual upgrade checks will still work: screenshooter upgrade check[/dim]")
    console.print("[dim]To unpin: screenshooter upgrade unpin[/dim]")


@upgrade.command()
def unpin() -> None:
    """Remove version pinning to receive all upgrade notifications."""
    current_settings = get_settings()
    old_pin = current_settings.upgrade_check.pin_version
    current_settings.upgrade_check.pin_version = None
    save_settings(current_settings)
    if old_pin:
        console.print(f"[green]Unpinned from version {old_pin}[/green]")
        console.print("[dim]You will now receive notifications for all available updates[/dim]")
    else:
        console.print("[dim]No version was pinned[/dim]")
