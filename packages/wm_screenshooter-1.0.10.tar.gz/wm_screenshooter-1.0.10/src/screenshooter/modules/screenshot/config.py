#!/usr/bin/env python3
"""Configuration class for the screenshot module."""

import importlib
import json
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import mss
import mss.tools
from dateutil import parser
from PIL import Image
from rich.console import Console
from rich.prompt import Prompt

from screenshooter.modules.clients.models import ClientInfo
from screenshooter.modules.clients.utils import slugify_name
from screenshooter.modules.screenshot.models import SessionInfo
from screenshooter.modules.screenshot.project import ProjectMetadata
from screenshooter.modules.settings.settings_helper import (
    get_default_countdown,
    get_default_screenshot_format,
    get_default_screenshot_mode,
    get_default_screenshot_quality,
    get_default_screenshot_timer,
    get_screenshots_dir,
    get_settings,
    should_use_database,
)

from .db_integration import DatabaseLogger
from .utils import get_connected_displays, get_key

# Initialize rich console
console = Console()

MIN_MONITOR_ENTRIES_FOR_SECONDARY_DISPLAY = 2
SNIPPET_REGION_PARTS = 4


def _build_client_manager(screenshots_dir: str | None = None):
    """Create ClientManager via dynamic import to avoid module cycles."""
    manager_module = importlib.import_module("screenshooter.modules.clients.manager")
    manager_cls = manager_module.ClientManager
    return manager_cls(screenshots_dir)


def _build_db_operations():
    """Create DatabaseOperations via dynamic import to avoid module cycles."""
    database_module = importlib.import_module("screenshooter.modules.database")
    return database_module.DatabaseOperations()


class ScreenshooterConfig:
    """Configuration class for the screenshooter."""

    def __init__(
        self,
        client_name: str,
        project_name: str,
        mode: str = "all",
        timer: int | str = 0,
        **options: str | None,
    ) -> None:
        """Initialize ScreenshooterConfig with client, project, and mode information."""
        screenshots_dir = options.get("screenshots_dir")
        session_name = options.get("session_name")
        self.client_name = client_name
        self.project_name = project_name
        self.mode = mode or get_default_screenshot_mode()
        self.timer = timer or get_default_screenshot_timer()
        self.countdown_seconds = get_default_countdown()
        self.screenshots_dir = screenshots_dir or get_screenshots_dir()
        self.session_start_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.session_name = session_name
        self.last_screenshot: str | None = None
        self.screenshot_count = 0
        self.set_id = 0
        self.snapshot_delay = 10
        self.is_paused = False
        # Flag to track if exit sequence is already in progress
        self.exit_in_progress = False
        # Track pause timing
        self.pause_start_time: datetime | None = None
        self.total_paused_seconds: float = 0.0
        self.last_snippet_region: tuple[int, int, int, int] | None = None
        self.snippet_gui_unavailable_warned = False
        self.snippet_gui_error_warned = False
        self.snippet_linux_experimental_warned = False

        # Initialize paths using safe directory names where available
        self.client_dir = self._resolve_client_dir()
        self.client_info_file = self.client_dir / "client.json"
        self.project_dir = self._resolve_project_dir()
        self.project_metadata_file = self.project_dir / "project.json"
        self.session_dir = self.project_dir / "sessions" / self.session_start_time
        self.screenshots_dir_path = self.session_dir / "screenshots"
        self.master_log_file = self.project_dir / f"{self.project_name}_log.txt"
        self.session_log_file = self.session_dir / "session.log"
        self.session_info_file = self.session_dir / "session.json"

        # Create necessary directories
        self.client_dir.mkdir(parents=True, exist_ok=True)
        self.project_dir.mkdir(parents=True, exist_ok=True)
        self.session_dir.mkdir(parents=True, exist_ok=True)
        self.screenshots_dir_path.mkdir(parents=True, exist_ok=True)

        # Initialize log files
        self.master_log_file.touch(exist_ok=True)
        self.session_log_file.touch(exist_ok=True)

        # Initialize client info, project info, and session info
        self.initialize_client_info()
        self.initialize_project_info()
        self.initialize_session_info()

        # Initialize database logger for dual logging
        self.db_logger = DatabaseLogger(
            self.client_name, self.project_name, self.session_start_time
        )

    def _resolve_client_dir(self) -> Path:
        """Resolve the filesystem directory for this client.

        Preference order:
        1. Database client.directory_name if available
        2. ClientInfo.directory_name from filesystem
        3. Slugified client name (for new clients)
        4. Raw client name (legacy fallback)
        """
        base_dir = Path(self.screenshots_dir)

        # Try database first
        if should_use_database():
            try:
                db_ops = _build_db_operations()
                client = db_ops.get_client_by_directory(
                    self.client_name
                ) or db_ops.get_client_by_name(self.client_name)
                if client and getattr(client, "directory_name", None):
                    return base_dir / client.directory_name
            except Exception:
                # Fall back to filesystem resolution
                pass

        # Try filesystem client_info.json via ClientManager
        try:
            manager = _build_client_manager(self.screenshots_dir)
            client_info = manager.load_client_info(self.client_name)
            if getattr(client_info, "directory_name", None):
                return base_dir / client_info.directory_name
        except Exception:
            # Fall back to slugged/legacy
            pass

        # For brand new clients, use a safe slug of the display name
        slug = slugify_name(self.client_name)
        return base_dir / (slug or self.client_name)

    def _resolve_project_dir(self) -> Path:
        """Resolve the filesystem directory for this project within the client."""
        base_client_dir = self.client_dir

        # Try database first
        if should_use_database():
            try:
                db_ops = _build_db_operations()
                client = db_ops.get_client_by_directory(
                    self.client_name
                ) or db_ops.get_client_by_name(self.client_name)
                if client and getattr(client, "id", None):
                    project = db_ops.get_project_by_directory(client.id, self.project_name)
                    if project and getattr(project, "directory_name", None):
                        return base_client_dir / project.directory_name
            except Exception:
                # Fall back to filesystem resolution
                pass

        # Filesystem:
        # 1. If a legacy directory using the raw project name exists, use it.
        legacy_dir = base_client_dir / self.project_name
        if legacy_dir.exists():
            return legacy_dir

        # 2. Otherwise, use a slugified directory name (spaces -> underscores, safe chars only)
        slug = slugify_name(self.project_name)
        return base_client_dir / (slug or self.project_name)

    def update_db_session(self) -> None:
        """Update the current session record in the database, if available."""
        if hasattr(self, "db_logger") and self.db_logger.is_available():
            try:
                duration_seconds = self._calculate_duration_seconds()
                self.db_logger.update_session(
                    end_time=datetime.now(),
                    duration_seconds=duration_seconds,
                    timer_mode=str(self.timer),
                )
            except Exception as e:
                console.print(f"[yellow]Failed to update session in database: {e}[/yellow]")

    def initialize_client_info(self) -> None:
        """Initialize or load client information."""
        legacy_file = self.client_dir / "client_info.json"
        if legacy_file.exists():
            try:
                data = json.loads(legacy_file.read_text())
            except Exception:
                data = {}
            archived_val = data.pop("archived", False)
            archived_at = data.get("archived_at", "")
            if not archived_at and archived_val:
                archived_at = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            data["archived_at"] = archived_at
            data.setdefault("client_name", self.client_name)
            data.setdefault("directory_name", self.client_dir.name)
            legacy_file.unlink(missing_ok=True)
            self.client_info_file.write_text(json.dumps(data, indent=2))
            self.log_entry(
                f"Legacy client_info.json migrated and removed for '{self.client_name}'",
                terminal_message="",
            )

        if not self.client_info_file.exists():
            if should_use_database():
                if self._create_client_info_from_database():
                    self.log_entry(
                        f"client.json created from database for {self.client_name}",
                        terminal_message="",
                    )
                else:
                    console.print(
                        f"[bold red]Warning: client.json not found for "
                        f"{self.client_name} and could not be created from database[/bold red]"
                    )
                    console.print(
                        f"[bold red]Expected location: {self.client_info_file}[/bold red]"
                    )
                    console.print(
                        "[bold red]Please create the client through the client "
                        "management module first.[/bold red]"
                    )
            else:
                console.print(
                    f"[bold red]Error: client.json not found for {self.client_name}[/bold red]"
                )
                console.print(f"[bold red]Expected location: {self.client_info_file}[/bold red]")
                console.print(
                    "[bold red]The system is configured to use log files only, but "
                    "client.json is missing.[/bold red]"
                )
                console.print(
                    "[bold red]Please check your configuration or create the client "
                    "through the client management module first.[/bold red]"
                )
                raise SystemExit("Cannot continue without client.json in log_file mode")

    def initialize_project_info(self) -> None:
        """Ensure project.json exists and legacy project_info.json is removed."""
        legacy_file = self.project_dir / "project_info.json"

        # If project.json already exists, still delete any legacy file and return
        if self.project_metadata_file.exists():
            if legacy_file.exists():
                try:
                    legacy_file.unlink(missing_ok=True)
                    self.log_entry(
                        (
                            f"Legacy project_info.json removed (project.json already "
                            f"present) for '{self.project_name}'"
                        ),
                        terminal_message="",
                    )
                except Exception as e:
                    self.log_entry(
                        f"Failed to remove legacy project_info.json: {e}",
                        terminal_message="",
                    )
            return

        # Try database first
        if self._create_project_info_from_database():
            self.log_entry(
                f"project.json created from database for project '{self.project_name}'",
                terminal_message="",
            )
            # Remove any lingering legacy file
            if legacy_file.exists():
                legacy_file.unlink(missing_ok=True)
            return

        # Migrate legacy project_info.json if it exists (and project.json absent)
        if legacy_file.exists():
            try:
                data = json.loads(legacy_file.read_text())
                metadata = ProjectMetadata(
                    project_name=data.get("project_name", self.project_name),
                    directory_name=data.get("directory_name", self.project_dir.name),
                    client_name=data.get("client_name", self.client_name),
                    started_at=data.get("created_at", datetime.now().strftime("%Y-%m-%d_%H-%M-%S")),
                    last_updated=data.get(
                        "updated_at", datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                    ),
                    finished_at=data.get("finished_at", ""),
                    archived_at=data.get("archived_at", ""),
                )
                self.project_metadata_file.write_text(metadata.model_dump_json(indent=2))
                legacy_file.unlink(missing_ok=True)
                self.log_entry(
                    f"Legacy project_info.json migrated and removed for '{self.project_name}'",
                    terminal_message="",
                )
                return
            except Exception as e:
                legacy_file.unlink(missing_ok=True)
                self.log_entry(
                    f"Legacy project_info.json removed (could not parse): {e}",
                    terminal_message="",
                )

        # Create a basic project.json if no other source
        metadata = ProjectMetadata(
            project_name=self.project_name,
            directory_name=self.project_dir.name,
            client_name=self.client_name,
        )
        self.project_metadata_file.write_text(metadata.model_dump_json(indent=2))
        self.log_entry(
            f"project.json created for project '{self.project_name}' (filesystem init)",
            terminal_message="",
        )

    def load_client_info(self) -> ClientInfo:
        """Load client information from file."""
        if self.client_info_file.exists():
            try:
                return ClientInfo.model_validate_json(self.client_info_file.read_text())
            except Exception as e:
                console.print(f"[bold red]Error loading client info: {e}[/bold red]")
                # Fall back to default if file is corrupted
                return ClientInfo(client_name=self.client_name, directory_name=self.client_name)

        # If file doesn't exist, the client should have been created properly
        console.print(f"[bold red]Client info file not found: {self.client_info_file}[/bold red]")
        console.print("[bold red]This client may not have been created properly.[/bold red]")
        # Return a minimal default to prevent crashes, but log the issue
        return ClientInfo(client_name=self.client_name, directory_name=self.client_name)

    def display_client_info(self) -> None:
        """Display client information."""
        client_info = self.load_client_info()
        console.print("\n[bold]Client Information:[/bold]")
        console.print("------------------")
        console.print(f"Client: [bold]{client_info.client_name}[/bold]")
        console.print(f"Company: {client_info.company_name}")
        console.print(f"Contact: {client_info.contact_name}")
        console.print(f"Email: {client_info.contact_email}")

        console.print("\n[bold]Preferences:[/bold]")
        console.print(
            f"Screenshot Delivery: {client_info.preferences.get('screenshot_delivery', 'local')}"
        )
        console.print(
            f"Notifications: {client_info.preferences.get('notification_preferences', 'all')}"
        )
        console.print(f"Reporting: {client_info.preferences.get('reporting_frequency', 'none')}")
        console.print(f"Last Updated: {client_info.last_updated}\n")

    def _create_client_info_from_database(self) -> bool:
        """Try to create client_info.json from database data.

        Returns:
            bool: True if successfully created, False otherwise
        """
        try:
            db_ops = _build_db_operations()

            # Try to find the client by directory name or client name
            client = db_ops.get_client_by_directory(self.client_name)
            if not client:
                client = db_ops.get_client_by_name(self.client_name)

            if client:
                # Create ClientInfo from database data
                client_info = ClientInfo(
                    client_name=client.name,
                    directory_name=client.directory_name or self.client_name,
                    company_name=client.company_name or "",
                    contact_name=client.contact_name or "",
                    contact_email=client.contact_email or "",
                    pdf_password=client.pdf_password or "",
                    preferences=client.preferences or {},
                    last_updated=client.updated_at.strftime("%Y-%m-%d %H:%M:%S")
                    if client.updated_at
                    else "",
                )

                # Save to filesystem
                self.client_info_file.parent.mkdir(parents=True, exist_ok=True)
                self.client_info_file.write_text(client_info.model_dump_json(indent=2))
                return True
            else:
                console.print(f"[yellow]Client '{self.client_name}' not found in database[/yellow]")
                return False

        except Exception as e:
            console.print(f"[bold red]Error creating client info from database: {e}[/bold red]")
            return False

    def _create_project_info_from_database(self) -> bool:
        """Try to create project.json from database data.

        Returns:
            bool: True if successfully created, False otherwise
        """
        try:
            db_ops = _build_db_operations()

            # Get the client first
            client = db_ops.get_client_by_directory(self.client_name)
            if not client:
                client = db_ops.get_client_by_name(self.client_name)

            if not client or not client.id:
                console.print(f"[yellow]Client '{self.client_name}' not found in database[/yellow]")
                return False

            # Try to find the project by directory name or name
            project = db_ops.get_project_by_directory(client.id, self.project_name)
            if not project:
                project = db_ops.get_project_by_name(client.id, self.project_name)

            if project:

                def _fmt(dt_obj: datetime | None) -> str:
                    if not dt_obj:
                        return ""
                    try:
                        return dt_obj.strftime("%Y-%m-%d_%H-%M-%S")
                    except Exception:
                        return str(dt_obj)

                metadata = ProjectMetadata(
                    project_name=project.name,
                    directory_name=project.directory_name or self.project_dir.name,
                    client_name=self.client_name,
                    started_at=_fmt(getattr(project, "created_at", None))
                    or datetime.now().strftime("%Y-%m-%d_%H-%M-%S"),
                    last_updated=_fmt(getattr(project, "updated_at", None))
                    or datetime.now().strftime("%Y-%m-%d_%H-%M-%S"),
                    finished_at=_fmt(getattr(project, "finished_at", None)),
                    archived_at=_fmt(getattr(project, "archived_at", None)),
                )

                # Save to filesystem
                self.project_metadata_file.parent.mkdir(parents=True, exist_ok=True)
                self.project_metadata_file.write_text(metadata.model_dump_json(indent=2))
                self.log_entry(
                    f"project.json created from database for project '{self.project_name}'",
                    terminal_message="",
                )
                return True
            else:
                console.print(f"New project '{self.project_name}' created")
                return False

        except Exception as e:
            console.print(f"[bold red]Error creating project info from database: {e}[/bold red]")
            return False

    def _create_session_info_from_database(self) -> bool:
        """Try to create session.json from database data.

        Returns:
            bool: True if successfully created, False otherwise
        """
        try:
            db_ops = _build_db_operations()

            # Get the client first
            client = db_ops.get_client_by_directory(self.client_name)
            if not client:
                client = db_ops.get_client_by_name(self.client_name)

            if not client or not client.id:
                console.print(f"[yellow]Client '{self.client_name}' not found in database[/yellow]")
                return False

            # Get the project
            project = db_ops.get_project_by_directory(client.id, self.project_name)
            if not project:
                project = db_ops.get_project_by_name(client.id, self.project_name)

            if not project or not project.id:
                console.print(
                    f"[yellow]Project '{self.project_name}' not found in database[/yellow]"
                )
                return False

            # Try to find existing session by name, or create basic session info
            session = db_ops.get_session_by_name(project.id, self.session_start_time)

            # Create SessionInfo with basic data from database or defaults
            session_info = SessionInfo(
                session_name=self.session_name or self.session_start_time,
                session_start_time=self.session_start_time,
                session_finish_time="",
                client_name=self.client_name,
                project_name=self.project_name,
                timer=str(self.timer),
                archived_at="",
            )

            # If we found a session in the database, populate additional data
            if session:
                # Note: We skip notes and captions as per user request
                # Could potentially add basic session metadata here if needed
                pass

            # Save to filesystem
            self.session_info_file.parent.mkdir(parents=True, exist_ok=True)
            self.session_info_file.write_text(session_info.model_dump_json(indent=2))
            return True

        except Exception as e:
            console.print(f"[bold red]Error creating session info from database: {e}[/bold red]")
            return False

    def write_to_logs(self, message: str) -> None:
        """Write a message to both log files."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"

        with open(self.master_log_file, "a") as f:
            f.write(f"{entry}\n")

        with open(self.session_log_file, "a") as f:
            f.write(f"{entry}\n")

    def log_entry(self, message: str, terminal_message: str | None = None) -> None:
        """Add a log entry and optionally display it to the terminal.

        Args:
            message: The message to write to the log file (and database)
            terminal_message: Optional custom message for the terminal.
                            If provided (even empty string), it overrides the default behavior
                            of printing 'message'. If None, 'message' is printed.
        """
        self.write_to_logs(message)

        # Also log to database if available
        self._log_to_database(message)

        if terminal_message is not None:
            if terminal_message:
                console.print(terminal_message)
        else:
            console.print(message)

    def _log_to_database(self, message: str) -> None:
        """Log specific message types to database."""
        if not hasattr(self, "db_logger") or not self.db_logger.is_available():
            return

        # Parse different log message types and log accordingly
        if "Screenshot saved:" in message:
            self._parse_screenshot_log(message)
        elif message.startswith("NOTE: "):
            self.db_logger.log_note(message[6:])  # Remove "NOTE: " prefix
        elif message.startswith("SESSION PAUSED: "):
            pause_reason = message[len("SESSION PAUSED: ") :]
            self.db_logger.log_pause(pause_reason)
        elif message.startswith("Paused for "):
            self.db_logger.log_resume(message)
        elif message.startswith("SESSION START NOTE: "):
            # Store the initial session note with SESSION_START type
            self.db_logger.log_session_start_note(message[len("SESSION START NOTE: ") :])
        elif "CAPTION for screenshot set #" in message:
            self._parse_caption_log(message)

    def _parse_screenshot_log(self, message: str) -> None:
        """Parse screenshot log message and log to database."""
        try:
            # Example: "Set #1 - Screenshot saved: /path/to/file.jpg (all)"
            match = re.search(r"Set #(\d+) - Screenshot saved: (.+?) \((.+?)\)", message)
            if match:
                set_id, file_path, suffix = match.groups()
                self.db_logger.log_screenshot(
                    int(set_id), file_path.strip(), suffix.strip(), self.mode
                )
        except Exception:
            pass  # Silently fail to avoid disrupting main functionality

    def _parse_caption_log(self, message: str) -> None:
        """Parse caption log message and log to database."""
        try:
            # Example: "CAPTION for screenshot set #1: This is a caption"
            match = re.search(r"CAPTION for screenshot set #(\d+): (.+)", message)
            if match:
                set_id, content = match.groups()
                self.db_logger.log_caption(int(set_id), content.strip())
        except Exception:
            pass  # Silently fail to avoid disrupting main functionality

    def _calculate_duration_seconds(self) -> int:
        """Calculate session duration in seconds."""
        try:
            # Convert the session start time to datetime
            start_time_str = self.session_start_time.replace("_", " ").replace("-", ":")
            start_time = parser.parse(start_time_str)
            end_time = datetime.now()
            duration = end_time - start_time
            return int(duration.total_seconds())
        except Exception:
            return 0

    def has_secondary_display(self) -> bool:
        """Check if a secondary display is connected.

        Uses mss for cross-platform monitor detection.
        """
        try:
            with mss.mss() as sct:
                # mss.monitors[0] is the "all monitors" virtual screen
                # mss.monitors[1:] are individual monitors
                return (
                    len(sct.monitors) > MIN_MONITOR_ENTRIES_FOR_SECONDARY_DISPLAY
                )  # More than one actual monitor
        except Exception:
            return False

    def _parse_region_mode(self, mode: str) -> dict[str, int] | None:
        """Parse a region mode string into an mss region dictionary."""
        if not mode.startswith("-R "):
            return None

        try:
            left, top, width, height = [
                int(part.strip()) for part in mode[3:].split(",", maxsplit=SNIPPET_REGION_PARTS - 1)
            ]
        except ValueError:
            self.log_entry(f"Invalid snippet region format: {mode}")
            return None

        if width <= 0 or height <= 0:
            self.log_entry(f"Invalid snippet region size (width={width}, height={height})")
            return None

        return {
            "left": left,
            "top": top,
            "width": width,
            "height": height,
        }

    def _resolve_monitor_number(self, mode: str) -> int:
        """Resolve monitor number from mode string."""
        if mode.startswith("-D "):
            try:
                return int(mode.split()[1])
            except (IndexError, ValueError):
                return 1

        if mode == "-w":
            console.print(
                "[yellow]Window capture mode not available cross-platform. "
                "Capturing primary monitor instead.[/yellow]"
            )
            return 1

        if mode.isdigit():
            return int(mode)
        return 1

    def _resolve_capture_target(self, mode: str, sct: Any) -> tuple[dict[str, int] | None, bool]:
        """Resolve mss capture target from mode and monitor availability."""
        region = self._parse_region_mode(mode)
        if mode.startswith("-R ") and region is None:
            return None, False

        if region is not None:
            return region, True

        monitor_num = self._resolve_monitor_number(mode)
        if monitor_num < 1 or monitor_num >= len(sct.monitors):
            console.print(
                f"[yellow]Monitor {monitor_num} not available. Using primary monitor.[/yellow]"
            )
            monitor_num = 1
        return dict(sct.monitors[monitor_num]), True

    @staticmethod
    def _capture_to_temp_png(sct: Any, target: dict[str, int], temp_png_file: Path) -> None:
        """Capture target via mss and write PNG output."""
        screenshot = sct.grab(target)
        mss.tools.to_png(screenshot.rgb, screenshot.size, output=str(temp_png_file))

    @staticmethod
    def _finalize_output_image(
        temp_png_file: Path,
        final_output_file: Path,
        screenshot_format: str,
        screenshot_quality: int,
    ) -> None:
        """Convert PNG output to requested format, or keep PNG output."""
        if screenshot_format.lower() == "jpg":
            with Image.open(temp_png_file) as img:
                if img.mode == "RGBA":
                    converted_img = img.convert("RGB")
                    converted_img.save(final_output_file, "JPEG", quality=screenshot_quality)
                else:
                    img.save(final_output_file, "JPEG", quality=screenshot_quality)
            temp_png_file.unlink()
            return

        temp_png_file.rename(final_output_file)

    @staticmethod
    def _cleanup_temp_png(temp_png_file: Path) -> None:
        """Remove temporary PNG file if present."""
        if not temp_png_file.exists():
            return
        try:
            temp_png_file.unlink()
        except Exception:
            pass

    def _log_screenshot_success(
        self, set_number: int, final_output_file: Path, suffix: str
    ) -> None:
        """Store screenshot success state and write success log entries."""
        self.last_screenshot = str(final_output_file)
        self.screenshot_count += 1
        self.log_entry(
            f"Set #{set_number} - Screenshot saved: {final_output_file} ({suffix})",
            terminal_message=f"Set #{set_number} - Screenshot saved.",
        )

    def _log_screenshot_failure(self, error: Exception) -> None:
        """Write screenshot failure log entry."""
        self.log_entry(f"Error taking screenshot: {error}")

    def take_screenshot(self, mode: str, suffix: str, set_number: int) -> bool:
        """Take a screenshot with the specified mode and suffix.

        Uses mss for cross-platform screenshot capture.

        Args:
            mode: Display mode - either a monitor number (e.g., "1", "2") or "window"
            suffix: Suffix for the filename
            set_number: The screenshot set number for logging
        """
        date_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        screenshot_format = get_default_screenshot_format()
        screenshot_quality = get_default_screenshot_quality()
        file_extension = screenshot_format.lower()
        final_output_file = (
            self.screenshots_dir_path / f"{self.project_name}_{date_time}_{suffix}.{file_extension}"
        )
        temp_png_file = self.screenshots_dir_path / f"{self.project_name}_{date_time}_{suffix}.png"

        try:
            with mss.mss() as sct:
                target, is_valid = self._resolve_capture_target(mode, sct)
                if not is_valid or target is None:
                    return False
                self._capture_to_temp_png(sct, target, temp_png_file)

            self._finalize_output_image(
                temp_png_file,
                final_output_file,
                screenshot_format,
                screenshot_quality,
            )
            self._log_screenshot_success(set_number, final_output_file, suffix)
            return True
        except Exception as e:
            self._log_screenshot_failure(e)
            self._cleanup_temp_png(temp_png_file)
            return False

    @staticmethod
    def is_interactive() -> bool:
        """Return True if running in an interactive terminal."""
        return sys.stdin.isatty()

    @staticmethod
    def _build_capture_suffix(suffix_extra: str | None, base_suffix: str) -> str:
        """Build capture filename suffix with optional prefix."""
        prefix = f"{suffix_extra}_" if suffix_extra else ""
        return f"{prefix}{base_suffix}"

    def _prompt_replacement_mode(self, displays_now: list[int]) -> str:
        """Prompt user for a replacement display mode."""
        mode_options = ["all", "window"] + [f"display{d}" for d in displays_now] + ["custom"]
        option_labels = ["all (all displays)", "window (selected window)"]
        option_labels += [f"display{d} (Display {d})" for d in displays_now]
        option_labels.append("custom (choose displays)")

        console.print("\n[bold]Available display modes:[/bold]")
        for i, label in enumerate(option_labels, 1):
            console.print(f"{i}. {label}")

        mode_choice = Prompt.ask(
            "Choose display mode",
            choices=[str(i) for i in range(1, len(mode_options) + 1)],
            default="1",
        )
        new_mode = mode_options[int(mode_choice) - 1]
        if new_mode != "custom":
            return new_mode

        while True:
            custom_input = Prompt.ask(
                f"Enter display numbers separated by space or comma "
                f"(available: {' '.join(str(d) for d in displays_now)})"
            )
            parts = [p for p in custom_input.replace(",", " ").split() if p.isdigit()]
            chosen = [int(p) for p in parts]
            if all(d in displays_now for d in chosen) and chosen:
                return f"custom:{','.join(str(d) for d in chosen)}"
            console.print(
                f"[red]Invalid selection. Please choose from: "
                f"{' '.join(str(d) for d in displays_now)}[/red]"
            )

    def _handle_disconnect_behavior(
        self,
        display_num: int,
        suffix_extra: str | None,
        on_disconnect: str,
        displays: list[int],
    ) -> bool:
        """Handle disconnected-display behavior based on settings."""
        if on_disconnect == "prompt" and self.is_interactive():
            console.print(f"[red]Display {display_num} is not connected.[/red]")
            new_mode = self._prompt_replacement_mode(get_connected_displays())
            self.mode = new_mode
            self.log_entry(f"Display mode changed to: {new_mode}")
            console.print(f"Display mode updated to: {new_mode}")
            return self.capture_screenshots(suffix_extra)

        if on_disconnect == "main":
            if 1 in displays:
                self.log_entry(f"Display {display_num} not connected. Switching to Display 1.")
                self.mode = "display1"
                return self.capture_screenshots(suffix_extra)
            self.log_entry("No displays available to switch to.")
            return False

        if on_disconnect == "close":
            self.log_entry(f"Display {display_num} not connected. Closing session as per settings.")
            console.print(f"[red]Display {display_num} not connected. Closing session.[/red]")
            return False

        self.log_entry(
            f"Display {display_num} not connected. Unknown "
            f"on_display_disconnect setting: {on_disconnect}"
        )
        return False

    @staticmethod
    def _parse_custom_displays(mode: str) -> list[int]:
        """Parse display IDs from custom mode string."""
        if not mode.startswith("custom:"):
            return []
        return [int(x) for x in mode.split(":", 1)[1].replace(",", " ").split() if x.isdigit()]

    def _capture_display_set(
        self,
        mode: str,
        displays: list[int],
        current_set: int,
        suffix_extra: str | None,
        on_disconnect: str,
    ) -> bool:
        """Capture screenshots for the selected display mode."""
        success = True
        result: bool | None = None

        if mode == "all":
            for display_id in displays:
                suffix = self._build_capture_suffix(suffix_extra, f"display{display_id}_screen")
                success &= self.take_screenshot(f"-D {display_id}", suffix, current_set)
            result = success
        elif mode.startswith("display") and mode[7:].isdigit():
            display_id = int(mode[7:])
            if display_id not in displays:
                result = self._handle_disconnect_behavior(
                    display_id,
                    suffix_extra,
                    on_disconnect,
                    displays,
                )
            else:
                suffix = self._build_capture_suffix(suffix_extra, f"display{display_id}_screen")
                result = self.take_screenshot(f"-D {display_id}", suffix, current_set)
        elif mode == "window":
            suffix = self._build_capture_suffix(suffix_extra, "window")
            result = self.take_screenshot("-w", suffix, current_set)
        elif mode.startswith("custom:"):
            for display_id in self._parse_custom_displays(mode):
                if display_id not in displays:
                    result = self._handle_disconnect_behavior(
                        display_id,
                        suffix_extra,
                        on_disconnect,
                        displays,
                    )
                    break
                suffix = self._build_capture_suffix(suffix_extra, f"display{display_id}_screen")
                success &= self.take_screenshot(f"-D {display_id}", suffix, current_set)
            if result is None:
                result = success
        else:
            self.log_entry(f"Unknown mode: {mode}")
            result = False

        return bool(result)

    def capture_screenshots(self, suffix_extra: str | None = None) -> bool:
        """Capture screenshots based on the current mode."""
        self.set_id += 1
        current_set = self.set_id
        displays = get_connected_displays()
        mode = self.mode
        settings = get_settings()
        on_disconnect = getattr(settings.screenshot, "on_display_disconnect", "prompt")

        # Log set start
        if suffix_extra:
            self.log_entry(f"Starting screenshot set #{current_set} ({suffix_extra})")
        else:
            self.log_entry(f"Starting screenshot set #{current_set} (scheduled)")

        success = self._capture_display_set(
            mode=mode,
            displays=displays,
            current_set=current_set,
            suffix_extra=suffix_extra,
            on_disconnect=on_disconnect,
        )

        # Notification - cross-platform desktop notification
        if success:
            self._send_notification("Screenshot(s) Taken", f"Saved to {self.screenshots_dir_path}")
        return success

    def capture_snippet(self, left: int, top: int, width: int, height: int) -> bool:
        """Capture a one-off snippet region screenshot."""
        self.set_id += 1
        current_set = self.set_id
        self.last_snippet_region = (left, top, width, height)

        self.log_entry(f"Starting screenshot set #{current_set} (snippet)")
        suffix = self._build_capture_suffix("snippet", "region")
        success = self.take_screenshot(f"-R {left},{top},{width},{height}", suffix, current_set)
        if success:
            self._send_notification("Snippet Captured", f"Saved to {self.screenshots_dir_path}")
        return success

    def _send_notification(self, title: str, message: str) -> None:
        """Send a cross-platform desktop notification.

        Supports macOS, Linux, and Windows.
        """
        try:
            system = platform.system()

            if system == "Darwin":
                # macOS - use terminal-notifier if available
                notifier_path = shutil.which("terminal-notifier")
                if notifier_path:
                    subprocess.run(
                        [notifier_path, "-title", title, "-message", message],
                        check=False,
                        capture_output=True,
                    )
            elif system == "Linux":
                # Linux - use notify-send if available
                notifier_path = shutil.which("notify-send")
                if notifier_path:
                    subprocess.run(
                        [notifier_path, title, message],
                        check=False,
                        capture_output=True,
                    )
            elif system == "Windows":
                # Windows - use PowerShell toast notification
                ps_script = f'''
                [Windows.UI.Notifications.ToastNotificationManager,
                 Windows.UI.Notifications,
                 ContentType = WindowsRuntime] | Out-Null
                $template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent(
                    [Windows.UI.Notifications.ToastTemplateType]::ToastText02
                )
                $textNodes = $template.GetElementsByTagName("text")
                $textNodes.Item(0).AppendChild($template.CreateTextNode("{title}")) | Out-Null
                $textNodes.Item(1).AppendChild($template.CreateTextNode("{message}")) | Out-Null
                $toast = [Windows.UI.Notifications.ToastNotification]::new($template)
                [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("ScreenShooter").Show($toast)
                '''
                subprocess.run(
                    ["powershell", "-Command", ps_script],
                    check=False,
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                    if hasattr(subprocess, "CREATE_NO_WINDOW")
                    else 0,
                )
        except Exception:
            # Silently fail if notifications don't work
            pass

    def handle_exit(self) -> bool:
        """Handle script exit gracefully.
        Returns True if exit should proceed, False if canceled."""
        # Finalize any paused time
        self._finalize_pause()
        # Prevent re-entry
        if self.exit_in_progress:
            return self._quick_exit(
                "Project session terminated by user (quick exit - no final screenshot)",
                "\nScript terminated by user. No final screenshot taken.",
            )
        self.exit_in_progress = True

        # Check if we're in manual mode - we should show a different message
        is_manual_mode = getattr(self, "timer", None) == "manual"
        countdown_seconds = self.countdown_seconds

        if is_manual_mode:
            console.print(
                f"\nExiting in {countdown_seconds} seconds. Please minimize this terminal window..."
            )
        else:
            console.print(
                f"\nTaking final screenshot in {countdown_seconds} seconds. Please "
                f"minimize this terminal window..."
            )

        console.print("Press 'z' to cancel this operation.")
        console.print("Press 'q' or Ctrl+C again to exit without final screenshot.")
        try:
            countdown_result = self._run_exit_countdown(countdown_seconds, is_manual_mode)
            if countdown_result == "cancel":
                self.log_entry("Final screenshot canceled by user")
                console.print("Final screenshot canceled. Script will continue running.")
                self.exit_in_progress = False
                return False
            if countdown_result == "quick_exit":
                return self._quick_exit(
                    "Project session ended by user (quick exit - no final screenshot)",
                    "Script terminated by user.",
                )
        except KeyboardInterrupt:
            return self._quick_exit(
                "Project session terminated by user (quick exit - Ctrl+C)",
                "\nScript terminated by user (Ctrl+C pressed during countdown).",
            )

        # Only take final screenshot if NOT in manual mode
        if is_manual_mode:
            console.print("\nExiting manual mode...")
        else:
            console.print("\nTaking final screenshot...")
            self.capture_screenshots("finish")

        active = self.calculate_session_duration()
        paused = self.format_seconds(self.total_paused_seconds)
        total = self.calculate_total_duration()
        self.log_entry("Project session ended by user")
        self.log_entry(f"Session Duration: {active}")
        self.log_entry(f"Paused Duration: {paused}")
        self.log_entry(f"Total Time (incl. pauses): {total}")

        # Update session in database with end time and duration
        self.update_db_session()

        console.print("Script terminated by user.")
        return True

    def _log_session_time_summary(self, end_message: str) -> None:
        """Log end-of-session summary with active/paused/total durations."""
        active = self.calculate_session_duration()
        paused = self.format_seconds(self.total_paused_seconds)
        total = self.calculate_total_duration()
        self.log_entry(end_message)
        self.log_entry(f"Session Duration: {active}")
        self.log_entry(f"Paused Duration: {paused}")
        self.log_entry(f"Total Time (incl. pauses): {total}")

    def _quick_exit(self, end_message: str, terminal_message: str) -> bool:
        """Perform quick-exit logging/DB updates and return True."""
        self._log_session_time_summary(end_message)
        self.update_db_session()
        console.print(terminal_message)
        return True

    def _run_exit_countdown(self, countdown_seconds: int, is_manual_mode: bool) -> str:
        """Run exit countdown and return action: complete, cancel, or quick_exit."""
        for i in range(countdown_seconds):
            remaining = countdown_seconds - i
            if is_manual_mode:
                sys.stdout.write(f"\rExiting in {remaining} seconds... ")
            else:
                sys.stdout.write(f"\rTaking final screenshot in {remaining} seconds... ")
            sys.stdout.flush()

            start_time = datetime.now().timestamp()
            while datetime.now().timestamp() < start_time + 1:
                try:
                    key = get_key()
                    if not key:
                        continue
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    if key == "z":
                        return "cancel"
                    if key in {"q", "ctrl+c"}:
                        return "quick_exit"
                except KeyboardInterrupt:
                    return "quick_exit"
        return "complete"

    def calculate_session_duration(self) -> str:
        """Calculate and format session duration."""
        # Convert the session start time string to a datetime object
        # Format is: YYYY-MM-DD_HH-MM-SS
        try:
            start_time_str = self.session_start_time.replace("_", " ").replace("-", ":")
            start_time = parser.parse(start_time_str)
        except Exception:
            # Fallback method if parsing fails
            parts = self.session_start_time.split("_")
            date_part = parts[0]
            time_part = parts[1].replace("-", ":")
            start_time = parser.parse(f"{date_part} {time_part}")

        end_time = datetime.now()
        # Subtract total paused time to get active duration
        duration = end_time - start_time - timedelta(seconds=self.total_paused_seconds)

        hours = duration.total_seconds() // 3600
        minutes = (duration.total_seconds() % 3600) // 60
        seconds = duration.total_seconds() % 60

        if hours > 0:
            return f"{int(hours)} hour(s) {int(minutes)} minute(s)"
        elif minutes > 0:
            return f"{int(minutes)} minute(s) {int(seconds)} second(s)"
        else:
            return f"{int(seconds)} second(s)"

    def format_seconds(self, total_seconds: float) -> str:
        """Format a duration in seconds to a human-readable string."""
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60
        if hours > 0:
            return f"{int(hours)} hour(s) {int(minutes)} minute(s)"
        elif minutes > 0:
            return f"{int(minutes)} minute(s) {int(seconds)} second(s)"
        else:
            return f"{int(seconds)} second(s)"

    def calculate_total_duration(self) -> str:
        """Calculate total session duration including pauses."""
        try:
            start_time_str = self.session_start_time.replace("_", " ").replace("-", ":")
            start_time = parser.parse(start_time_str)
        except Exception:
            parts = self.session_start_time.split("_")
            date_part = parts[0]
            time_part = parts[1].replace("-", ":")
            start_time = parser.parse(f"{date_part} {time_part}")
        total_delta = datetime.now() - start_time
        return self.format_seconds(total_delta.total_seconds())

    def _calculate_session_duration_seconds(self) -> int:
        """Return the active duration of the current session in seconds.

        Active duration excludes paused time and increases in real-time while
        the session is running.
        """
        try:
            start_time_str = self.session_start_time.replace("_", " ").replace("-", ":")
            start_time = parser.parse(start_time_str)
        except Exception:
            parts = self.session_start_time.split("_")
            date_part = parts[0]
            time_part = parts[1].replace("-", ":")
            start_time = parser.parse(f"{date_part} {time_part}")

        end_time = datetime.now()
        duration = end_time - start_time - timedelta(seconds=self.total_paused_seconds)
        return int(duration.total_seconds())

    @staticmethod
    def _parse_duration_string_to_seconds(duration_str: str) -> int:
        """Parse a human-readable duration string into seconds.

        Supports formats like:
        - "X hour(s) Y minute(s)"
        - "Y minute(s) Z second(s)"
        - "Z second(s)"
        """
        text = duration_str.lower()
        hours = minutes = seconds = 0
        try:
            if "hour" in text:
                try:
                    hours = int(text.split("hour")[0].strip().split()[-1])
                except Exception:
                    hours = 0
            if "minute" in text:
                try:
                    # take the token before "minute"
                    minutes = int(text.split("minute")[0].strip().split()[-1])
                except Exception:
                    minutes = 0
            if "second" in text:
                try:
                    seconds = int(text.split("second")[0].strip().split()[-1])
                except Exception:
                    seconds = 0
        except Exception:
            return 0
        return hours * 3600 + minutes * 60 + seconds

    def get_time_info(self) -> tuple[str, str, str]:
        """Compute time summaries for display when pressing 'i'.

        Returns:
            tuple[str, str, str]: (current_session_str, today_total_str, project_total_str)
                - current_session_str: active time in the current session (excludes pauses)
                - today_total_str: total time for today's sessions (includes current session)
                - project_total_str: total time across all sessions for this project
                  (includes current session)
        """
        sessions_root = self.project_dir / "sessions"
        today_key = datetime.now().strftime("%Y-%m-%d")
        total_project_seconds, total_today_seconds = self._read_logged_time_totals(
            sessions_root,
            today_key,
        )

        current_has_final = self._session_log_has_final_duration(self.session_log_file)

        if not current_has_final:
            live_seconds = self._calculate_session_duration_seconds()
            total_project_seconds += live_seconds
            if today_key == self.session_start_time.split("_")[0]:
                total_today_seconds += live_seconds

        current_session_str = self.calculate_session_duration()
        return (
            current_session_str,
            self.format_seconds(total_today_seconds),
            self.format_seconds(total_project_seconds),
        )

    def _read_logged_time_totals(self, sessions_root: Path, today_key: str) -> tuple[int, int]:
        """Read completed-session time totals from session logs."""
        total_project_seconds = 0
        total_today_seconds = 0
        if not sessions_root.exists():
            return total_project_seconds, total_today_seconds

        for session_dir in sessions_root.iterdir():
            if not session_dir.is_dir():
                continue
            log_file = session_dir / "session.log"
            if not log_file.exists():
                continue

            duration_seconds = self._read_last_session_duration_seconds(log_file)
            total_project_seconds += duration_seconds
            if session_dir.name.split("_")[0] == today_key:
                total_today_seconds += duration_seconds

        return total_project_seconds, total_today_seconds

    def _read_last_session_duration_seconds(self, log_file: Path) -> int:
        """Read the last Session Duration value from a session log."""
        duration_seconds = 0
        try:
            with open(log_file) as f:
                for line in f:
                    if "Session Duration:" not in line:
                        continue
                    duration_text = line.split("Session Duration:")[1].strip()
                    duration_seconds = self._parse_duration_string_to_seconds(duration_text)
        except Exception:
            return 0
        return duration_seconds

    def _session_log_has_final_duration(self, log_file: Path) -> bool:
        """Return True when a session log already has a final Session Duration line."""
        try:
            if not log_file.exists():
                return False
            with open(log_file) as f:
                for line in f:
                    if "Session Duration:" in line:
                        return True
        except Exception:
            return False
        return False

    def _finalize_pause(self) -> None:
        """Finalize any ongoing pause before exit summary."""
        if self.pause_start_time is not None:
            pause_end = datetime.now()
            pause_delta = pause_end - self.pause_start_time
            self.total_paused_seconds += pause_delta.total_seconds()
            self.pause_start_time = None
            self.is_paused = False

    def countdown_for_screenshot(
        self,
        seconds: int,
        action_name: str,
        start_message: str | None = None,
        show_minimize_hint: bool = True,
        cancel_message: str | None = None,
    ) -> bool:
        """Show a countdown to allow user to minimize terminal window.
        Returns True if the countdown completed, False if canceled."""
        minimize_hint = ""
        if show_minimize_hint:
            minimize_hint = " Please minimize this terminal window..."
        console.print(f"\n{action_name} in {seconds} seconds.{minimize_hint}")
        console.print("Press 'z' to cancel this operation.")

        for i in range(seconds):
            remaining = seconds - i
            # Use sys.stdout for cleaner output
            sys.stdout.write(f"\r{action_name} in {remaining} seconds... ")
            sys.stdout.flush()

            # Wait for 1 second, checking for key presses
            start_time = datetime.now().timestamp()
            while datetime.now().timestamp() < start_time + 1:
                key = get_key()
                if key:
                    if key == "z":
                        sys.stdout.write("\n")
                        sys.stdout.flush()
                        console.print(cancel_message or f"{action_name} canceled.")
                        return False
                    elif key == "ctrl+c":
                        # Handle Ctrl+C during countdown
                        sys.stdout.write("\n")
                        sys.stdout.flush()
                        should_exit = self.handle_exit()
                        if should_exit:
                            sys.exit(0)

        sys.stdout.write("\n")
        sys.stdout.flush()
        console.print(start_message or f"Taking {action_name.lower()}...")
        return True

    def initialize_session_info(self) -> None:
        """Initialize or load session information."""
        if not self.session_info_file.exists():
            # Always try to create session.json from database data if available
            # This ensures parity even in database mode
            if self._create_session_info_from_database():
                console.print(
                    f"[green]Session info file created from database for "
                    f"{self.session_start_time}[/green]"
                )
            else:
                # Create a basic session info file if database lookup fails
                session_info = SessionInfo(
                    session_name=self.session_name or "Untitled Session",
                    session_start_time=self.session_start_time,
                    session_finish_time="",
                    client_name=self.client_name,
                    project_name=self.project_name,
                    timer=str(self.timer),
                    archived_at="",
                )
                self.session_info_file.write_text(session_info.model_dump_json(indent=2))
                console.print(f"Created new session information file at: {self.session_info_file}")

    def update_session_info(self) -> None:
        """Update session information last_updated timestamp."""
        try:
            session_info = SessionInfo.model_validate_json(self.session_info_file.read_text())
            session_info.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.session_info_file.write_text(session_info.model_dump_json(indent=2))
        except Exception as e:
            console.print(f"[bold red]Error updating session info: {e}[/bold red]")

    def set_session_finish_time(self) -> None:
        """Record the session finish time in session.json."""
        try:
            if not self.session_info_file.exists():
                return

            session_info = SessionInfo.model_validate_json(self.session_info_file.read_text())
            session_info.session_finish_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            session_info.last_updated = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.session_info_file.write_text(session_info.model_dump_json(indent=2))
        except Exception as e:
            console.print(f"[bold red]Error setting session finish time: {e}[/bold red]")

    def update_project_metadata_last_updated(self) -> None:
        """Update project.json last_updated timestamp."""
        try:
            raw: dict = {}
            if self.project_metadata_file.exists():
                try:
                    raw = json.loads(self.project_metadata_file.read_text())
                except json.JSONDecodeError:
                    raw = {}

            def _get(key: str, default: str) -> str:
                value = raw.get(key, default)
                return str(value) if value is not None else default

            now_started = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            metadata = ProjectMetadata(
                project_name=_get("project_name", self.project_name),
                directory_name=_get("directory_name", self.project_dir.name),
                client_name=_get("client_name", self.client_name),
                started_at=_get("started_at", raw.get("created_at", now_started)),
                last_updated=datetime.now().strftime("%Y-%m-%d_%H-%M-%S"),
                finished_at=_get("finished_at", ""),
                archived_at=_get("archived_at", ""),
            )

            self.project_metadata_file.parent.mkdir(parents=True, exist_ok=True)
            self.project_metadata_file.write_text(metadata.model_dump_json(indent=2))
            # Log creation when we had to rebuild from missing/corrupt metadata
            if not raw:
                self.log_entry(
                    f"project.json created for project '{self.project_name}' (auto-rebuilt)",
                    terminal_message="",
                )
        except Exception as e:
            console.print(f"[bold red]Error updating project metadata: {e}[/bold red]")
