#!/usr/bin/env python3
"""Screenshot module for ScreenShooter Mac.

This package contains functionality for capturing and organizing screenshots.
"""

# Re-export main components for backwards compatibility
from .config import ScreenshooterConfig
from .project import ProjectMetadata
from .session import SessionInfo

# Don't import the main function here to avoid circular imports
# from .main import main

__all__ = ["ProjectMetadata", "ScreenshooterConfig", "SessionInfo"]
