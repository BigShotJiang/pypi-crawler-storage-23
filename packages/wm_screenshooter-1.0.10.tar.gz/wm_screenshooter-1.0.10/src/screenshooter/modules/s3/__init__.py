"""S3/R2 storage module for ScreenShooter Mac."""

# Re-export main functionality for backward compatibility
from screenshooter.modules.s3.helper import (
    S3Helper,
    get_s3_settings,
    is_s3_enabled,
    log_entry,
    setup_report_logging,
    suppress_console_errors,
)

# Make the module directly executable
from screenshooter.modules.s3.main import main
from screenshooter.modules.s3.vanity_helper import generate_custom_link

__all__ = [
    "S3Helper",
    "generate_custom_link",
    "get_s3_settings",
    "is_s3_enabled",
    "log_entry",
    "main",
    "setup_report_logging",
    "suppress_console_errors",
]
