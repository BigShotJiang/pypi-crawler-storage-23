#!/usr/bin/env python3
"""Abort in-progress multipart uploads for S3/R2 buckets.

By default, this script reads ScreenShooter settings from:
~/.config/screenshooter/settings.json

It uses `s3` settings for endpoint/credentials and resolves bucket as:
1) --bucket CLI argument
2) backup.s3_bucket_name (if set)
3) s3.bucket_name
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError

DEFAULT_SETTINGS_PATH = Path.home() / ".config" / "screenshooter" / "settings.json"


def _load_settings(path: Path) -> dict[str, Any]:
    """Load settings JSON from disk."""
    if not path.exists():
        raise FileNotFoundError(f"Settings file not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _resolve_credentials_and_target(
    args: argparse.Namespace, settings: dict[str, Any]
) -> tuple[str, str, str, str, str]:
    """Resolve endpoint, access key, secret key, bucket and region."""
    s3_settings = settings.get("s3", {}) if isinstance(settings, dict) else {}
    backup_settings = settings.get("backup", {}) if isinstance(settings, dict) else {}

    endpoint_url = args.endpoint_url or str(s3_settings.get("endpoint_url", "")).strip()
    access_key_id = args.access_key_id or str(s3_settings.get("access_key_id", "")).strip()
    secret_access_key = args.secret_access_key or str(
        s3_settings.get("secret_access_key", "")
    ).strip()
    backup_bucket = str(backup_settings.get("s3_bucket_name", "")).strip()
    default_bucket = str(s3_settings.get("bucket_name", "")).strip()
    bucket_name = args.bucket or backup_bucket or default_bucket
    region = args.region or str(s3_settings.get("region", "auto")).strip() or "auto"

    missing = []
    if not endpoint_url:
        missing.append("endpoint_url")
    if not access_key_id:
        missing.append("access_key_id")
    if not secret_access_key:
        missing.append("secret_access_key")
    if not bucket_name:
        missing.append("bucket_name")
    if missing:
        raise ValueError(
            "Missing required values: "
            + ", ".join(missing)
            + ". Set them in settings.json or pass CLI overrides."
        )

    return endpoint_url, access_key_id, secret_access_key, bucket_name, region


def _list_uploads(
    client: Any, bucket_name: str, prefix: str | None
) -> list[tuple[str, str, str]]:
    """List in-progress multipart uploads as (key, upload_id, initiated)."""
    kwargs: dict[str, Any] = {"Bucket": bucket_name}
    if prefix:
        kwargs["Prefix"] = prefix

    uploads: list[tuple[str, str, str]] = []
    paginator = client.get_paginator("list_multipart_uploads")
    for page in paginator.paginate(**kwargs):
        for upload in page.get("Uploads", []):
            key = str(upload.get("Key", ""))
            upload_id = str(upload.get("UploadId", ""))
            initiated = str(upload.get("Initiated", ""))
            if key and upload_id:
                uploads.append((key, upload_id, initiated))
    return uploads


def _build_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser."""
    parser = argparse.ArgumentParser(description="Abort in-progress multipart uploads in S3/R2.")
    parser.add_argument(
        "--settings-file",
        type=Path,
        default=DEFAULT_SETTINGS_PATH,
        help=f"Path to settings.json (default: {DEFAULT_SETTINGS_PATH})",
    )
    parser.add_argument("--bucket", help="Bucket name override")
    parser.add_argument("--prefix", default="", help="Only abort uploads under this key prefix")
    parser.add_argument("--endpoint-url", help="S3 endpoint URL override")
    parser.add_argument("--access-key-id", help="Access key override")
    parser.add_argument("--secret-access-key", help="Secret key override")
    parser.add_argument("--region", help="Region override")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List uploads that would be aborted without aborting them",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show per-upload details",
    )
    return parser


def main() -> int:
    """Run multipart upload cleanup script."""
    parser = _build_parser()
    args = parser.parse_args()

    try:
        settings = _load_settings(args.settings_file)
        endpoint_url, access_key_id, secret_access_key, bucket_name, region = (
            _resolve_credentials_and_target(args, settings)
        )

        client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            region_name=region,
        )

        prefix = args.prefix.strip() or None
        uploads = _list_uploads(client, bucket_name, prefix)

        if args.verbose:
            print(f"Bucket: {bucket_name}")
            if prefix:
                print(f"Prefix: {prefix}")
            print(f"Found multipart uploads: {len(uploads)}")

        if not uploads:
            if not args.verbose:
                print("No in-progress multipart uploads found.")
            return 0

        if args.dry_run:
            if args.verbose:
                for key, upload_id, initiated in uploads:
                    print(f"DRY RUN | key={key} upload_id={upload_id} initiated={initiated}")
            print(f"Dry run complete. Multipart uploads matched: {len(uploads)}")
            return 0

        aborted_count = 0
        for key, upload_id, initiated in uploads:
            if args.verbose:
                print(f"Aborting | key={key} upload_id={upload_id} initiated={initiated}")
            client.abort_multipart_upload(
                Bucket=bucket_name,
                Key=key,
                UploadId=upload_id,
            )
            aborted_count += 1

        print(f"Aborted multipart uploads: {aborted_count}")
        return 0
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code", "Unknown")
        message = exc.response.get("Error", {}).get("Message", str(exc))
        print(f"AWS/S3 error [{code}]: {message}", file=sys.stderr)
        return 3
    except BotoCoreError as exc:
        print(f"Boto core error: {exc}", file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
