# DEVELOPMENT

Developer guidance for working on ScreenShooter during active feature development.

## Branch and Release Flow

- `main` is the stable branch.
- Stable versions are tagged releases (for example, `v1.0.9`, `v1.0.10`).
- You can keep separate dev branches per version (for example, `v1.0.10` or `dev/v1.0.10`).
- Do not tag every commit. Tag only stable release points.

## Versioning with `setuptools-scm`

ScreenShooter uses SCM-derived package versions so dev builds are uniquely identifiable by commit.

- Stable tagged commit example: `1.0.10`
- Dev commit example: `1.0.11.devN+g<sha>`

This prevents ambiguity when a local/dev install is ahead of the latest public release tag.

## Upgrade Check Channels

Upgrade checks support two channels:

- `release`: checks GitLab releases (stable/public release path).
- `dev`: checks branch head commit for the configured dev branch.
  - Dev channel intentionally checks upstream on every run (no cache reads).
  - For local checkout workflows (`uv run screenshooter`), the current commit comes from local git
    `HEAD` first, then falls back to package version metadata if git is unavailable.

On first startup of a detected development build, ScreenShooter prompts once to switch upgrade checks
to the `dev` channel and suggests a version branch (for example `v1.0.10`).

### Commands

```bash
screenshooter upgrade check
screenshooter upgrade status
screenshooter upgrade channel <release|dev>
screenshooter upgrade branch <branch-name>
screenshooter upgrade settings --enable --frequency 7
screenshooter upgrade skip <version>
screenshooter upgrade pin <version>
screenshooter upgrade unpin
```

## Recommended Daily Workflow

1. Create or switch to your target dev branch (for example, `v1.0.10`).
2. Keep channel on `dev` while actively developing:
   - `screenshooter upgrade channel dev`
   - `screenshooter upgrade branch v1.0.10`
3. Use `release` channel when validating stable/public updates:
   - `screenshooter upgrade channel release`

## Validation Checklist

- Confirm version metadata is SCM-derived:
  - `uv run screenshooter --version`
- Confirm release channel behavior:
  - `uv run screenshooter upgrade channel release`
  - `uv run screenshooter upgrade check`
- Confirm dev branch behavior:
  - `uv run screenshooter upgrade channel dev`
  - `uv run screenshooter upgrade branch <branch-name>`
  - `uv run screenshooter upgrade check`
