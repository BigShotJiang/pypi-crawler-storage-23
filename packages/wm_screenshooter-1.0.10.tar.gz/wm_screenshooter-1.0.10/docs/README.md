# WorkMaster ScreenShooter Documentation

This documentation is for the WorkMaster ScreenShooter application.

## Table of Contents

- Core documentation:

- [CHANGELOG](CHANGELOG.md)
- [ROADMAP](ROADMAP.md)
- [DEVELOPMENT](DEVELOPMENT.md)

- Temporary documentation for ROADMAP and Scoped Issues:

- [Remediation Pass](remediation-pass/remediation_ruff_rule_expansion_staged_plan.md) - Staged plan for expanding Ruff linting rules in future releases.
