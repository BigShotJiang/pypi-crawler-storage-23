# Quick Start: Publishing with uv

## Local Testing

### 1. Build the package
```bash
uv build
```

This creates:
- `dist/sqlmodel_graphql-0.1.0.tar.gz` (source distribution)
- `dist/sqlmodel_graphql-0.1.0-py3-none-any.whl` (wheel)

### 2. Test the build locally
```bash
# Create a test environment
python -m venv test-env
source test-env/bin/activate  # On Windows: test-env\Scripts\activate

# Install from local wheel
pip install dist/sqlmodel_graphql-0.1.0-py3-none-any.whl

# Test import
python -c "from sqlmodel_graphql import GraphQLHandler; print('Success!')"
```

### 3. Publish to TestPyPI (optional)
```bash
# Get your TestPyPI token from https://test.pypi.org/manage/account/token/
uv publish --repository-url https://test.pypi.org/simple/ --token <your-testpypi-token>

# Test installation
pip install --index-url https://test.pypi.org/simple/ sqlmodel-graphql
```

## Publishing to PyPI

### Option 1: Manual Publish

```bash
# Set your PyPI token
export UV_PUBLISH_TOKEN=<your-pypi-token>

# Build and publish
uv build
uv publish
```

### Option 2: Automated via GitHub Actions (Recommended)

1. **Add PyPI token to GitHub**
   - Go to: Repository → Settings → Secrets → Actions
   - Name: `PYPI_PUBLISHER`
   - Value: Your PyPI API token

2. **Publish a new version**
   ```bash
   # Update version
   vim src/sqlmodel_graphql/__init__.py  # Update __version__
   vim pyproject.toml                    # Update version

   # Commit and tag
   git add .
   git commit -m "chore: release v0.1.0"
   git tag v0.1.0
   git push origin master --tags
   ```

3. **GitHub Actions will automatically:**
   - Build with `uv build`
   - Publish to PyPI with `uv publish`
   - Create GitHub Release

## Getting PyPI Token

1. Go to https://pypi.org/manage/account/token/
2. Click "Add API token"
3. Scope: "Entire account" (for first project) or "Project: sqlmodel-graphql"
4. Copy the token (starts with `pypi-`)
5. Save it securely - you won't see it again!

## Troubleshooting

### "File already exists"
You're trying to upload the same version. Bump the version number.

### "Invalid or missing authentication"
Check your PyPI token is correct and not expired.

### "HTTP Error 400"
- Ensure `pyproject.toml` has all required fields
- Check version number format (should be semver: X.Y.Z)

## Useful Commands

```bash
# View package contents
tar -tzf dist/sqlmodel_graphql-0.1.0.tar.gz
unzip -l dist/sqlmodel_graphql-0.1.0-py3-none-any.whl

# Check package metadata
uv run python -c "import tomllib; print(tomllib.load(open('pyproject.toml', 'rb')))"

# Clean build artifacts
rm -rf dist/ build/ *.egg-info src/*.egg-info
```
