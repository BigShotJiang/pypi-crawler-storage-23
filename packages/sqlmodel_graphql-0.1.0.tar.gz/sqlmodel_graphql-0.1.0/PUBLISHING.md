# Publishing Checklist for sqlmodel-graphql v0.1.0

## ✅ Completed Tasks

### Documentation
- [x] Updated README.md with auto-discovery feature documentation
- [x] Created comprehensive API reference
- [x] Added examples for nested relationship queries
- [x] Created CHANGELOG.md
- [x] Created RELEASE.md with publishing guide

### Legal
- [x] Added MIT License file

### Code Quality
- [x] Fixed all ruff linter issues
- [x] Formatted code with ruff format
- [x] Fixed line length issues
- [x] Removed unused variables
- [x] All checks passed: `ruff check src/`

### Project Configuration
- [x] Updated .gitignore with comprehensive ignore patterns
- [x] pyproject.toml configured correctly
- [x] Version set to 0.1.0

## 📋 Pre-Publish Checklist

Before publishing to PyPI, verify:

### 1. Code Quality
```bash
# Run linter
python -m ruff check src/

# Format code
python -m ruff format src/

# Type check (optional)
python -m mypy src/
```

### 2. Build Package
```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Build distributions
python -m build
```

### 3. Check Package
```bash
# Check package metadata
twine check dist/*

# View package contents
unzip -l dist/sqlmodel_graphql-0.1.0-py3-none-any.whl
```

### 4. Test Installation (Optional)
```bash
# Create test environment
python -m venv test-env
source test-env/bin/activate

# Install from local wheel
pip install dist/sqlmodel_graphql-0.1.0-py3-none-any.whl

# Test import
python -c "from sqlmodel_graphql import GraphQLHandler; print('Success!')"
```

### 5. Upload to TestPyPI (Recommended)
```bash
# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Test install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ sqlmodel-graphql
```

### 6. Publish to PyPI
```bash
# Upload to PyPI
python -m twine upload dist/*
```

## 📦 Package Contents

### Core Files
- `src/sqlmodel_graphql/` - Main package
  - `__init__.py` - Package exports
  - `decorator.py` - @query/@mutation decorators
  - `handler.py` - GraphQLHandler with auto-discovery
  - `query_parser.py` - Query parser and QueryMeta
  - `sdl_generator.py` - SDL generation
  - `types.py` - Type definitions
  - `type_converter.py` - Type conversion utilities
  - `introspection.py` - GraphQL introspection

### Documentation
- `README.md` - Main documentation
- `CHANGELOG.md` - Version history
- `RELEASE.md` - Publishing guide
- `how_it_works.md` - Implementation details
- `demo/` - Example application
- `examples/` - Usage examples

### Configuration
- `pyproject.toml` - Package configuration
- `LICENSE` - MIT License
- `.gitignore` - Git ignore patterns

## 🚀 Quick Publish Commands

### Using uv (Recommended)

```bash
# 1. Build
uv build

# 2. Publish to PyPI
uv publish --token <your-pypi-token>

# Or set token via environment variable
export UV_PUBLISH_TOKEN=<your-pypi-token>
uv publish
```

### Using twine (Traditional)

```bash
# 1. Clean and build
rm -rf dist/ build/ && python -m build

# 2. Check
twine check dist/*

# 3. Upload to PyPI
twine upload dist/*
```

## 🤖 Automated Publishing via GitHub Actions

This project uses GitHub Actions for automated publishing when you push a tag.

### Setup GitHub Secrets

1. Get your PyPI API token:
   - Go to https://pypi.org/manage/account/token/
   - Create a new token with "Upload" scope
   - Copy the token (starts with `pypi-`)

2. Add secret to GitHub repository:
   - Go to your repo → Settings → Secrets and variables → Actions
   - Click "New repository secret"
   - Name: `PYPI_PUBLISHER`
   - Value: Paste your PyPI token
   - Click "Add secret"

### Publish a New Version

```bash
# 1. Update version in src/sqlmodel_graphql/__init__.py
__version__ = "0.2.0"  # New version

# 2. Update version in pyproject.toml
version = "0.2.0"

# 3. Update CHANGELOG.md

# 4. Commit and tag
git add .
git commit -m "chore: bump version to 0.2.0"
git tag v0.2.0
git push origin master --tags

# 5. GitHub Actions will automatically:
#    - Build the package with uv
#    - Publish to PyPI
#    - Create GitHub Release
```

### Manual Trigger

You can also manually trigger the publish workflow:
1. Go to Actions tab in GitHub
2. Select "Publish to PyPI via uv"
3. Click "Run workflow"

## 📝 Post-Publish Tasks

After successful publication:

1. **Create Git Tag**
   ```bash
   git tag -a v0.1.0 -m "Release version 0.1.0"
   git push origin v0.1.0
   ```

2. **Create GitHub Release**
   - Go to https://github.com/allmonday/sqlmodel-graphql/releases/new
   - Select tag v0.1.0
   - Add release notes from CHANGELOG.md

3. **Verify PyPI**
   - Check https://pypi.org/project/sqlmodel-graphql/
   - Test installation: `pip install sqlmodel-graphql`

4. **Announce**
   - Update GitHub repository description
   - Share on social media
   - Post on Python/Discord communities

## 🔗 Important Links

- PyPI: https://pypi.org/project/sqlmodel-graphql/
- TestPyPI: https://test.pypi.org/project/sqlmodel-graphql/
- GitHub: https://github.com/allmonday/sqlmodel-graphql
- Documentation: See README.md and demo/

## ⚠️ Common Issues

### "File already exists"
Bump version in `__init__.py` and `pyproject.toml`

### "Invalid distribution"
Ensure all dependencies are listed in `pyproject.toml`

### Import errors
Check that all required packages are in `dependencies` list

## 📊 Current Status

**Version:** 0.1.0
**Status:** ✅ Ready to publish
**Last Updated:** 2025-03-06

All quality checks passed:
- ✅ Code formatted
- ✅ Linter checks passed
- ✅ Documentation complete
- ✅ License added
- ✅ CHANGELOG created
