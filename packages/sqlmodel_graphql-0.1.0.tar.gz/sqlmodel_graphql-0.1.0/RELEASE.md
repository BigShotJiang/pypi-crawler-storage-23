# Release Guide

This guide explains how to publish `sqlmodel-graphql` to PyPI.

## Prerequisites

1. Create accounts on:
   - [PyPI](https://pypi.org/account/register/)
   - [TestPyPI](https://test.pypi.org/account/register/) (for testing)

2. Install publishing tools:
```bash
pip install build twine
```

## Version Management

Update the version in:
- `src/sqlmodel_graphql/__init__.py` - `__version__`
- `pyproject.toml` - `version`

Follow [Semantic Versioning](https://semver.org/):
- MAJOR version for incompatible API changes
- MINOR version for new features (backward compatible)
- PATCH version for bug fixes

## Pre-release Checklist

1. **Update Documentation**
   - [ ] Update README.md with new features
   - [ ] Update API reference
   - [ ] Add examples for new features

2. **Run Tests**
   ```bash
   # Run all tests
   pytest

   # Run with coverage
   pytest --cov=sqlmodel_graphql

   # Type checking
   mypy src
   ```

3. **Code Quality**
   ```bash
   # Format code
   ruff format .

   # Check for issues
   ruff check .
   ```

4. **Update Changelog**
   Create or update `CHANGELOG.md` with:
   - New features
   - Bug fixes
   - Breaking changes
   - Deprecations

## Building the Package

```bash
# Clean previous builds
rm -rf dist/ build/ *.egg-info

# Build source distribution and wheel
python -m build
```

This creates:
- `dist/sqlmodel_graphql-0.1.0.tar.gz` (source distribution)
- `dist/sqlmodel_graphql-0.1.0-py3-none-any.whl` (wheel)

## Testing the Distribution

### Test on TestPyPI (Recommended)

1. Upload to TestPyPI:
```bash
python -m twine upload --repository testpypi dist/*
```

2. Test installation:
```bash
# Create a test environment
python -m venv test-env
source test-env/bin/activate  # On Windows: test-env\Scripts\activate

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ sqlmodel-graphql

# Test the package
python -c "from sqlmodel_graphql import GraphQLHandler; print('Success!')"
```

### Local Testing

```bash
# Install locally
pip install dist/sqlmodel_graphql-0.1.0-py3-none-any.whl

# Test
python -c "from sqlmodel_graphql import GraphQLHandler; print('Success!')"
```

## Publishing to PyPI

### First-time Setup

1. Create API token on PyPI:
   - Go to https://pypi.org/manage/account/token/
   - Create a new API token
   - Save the token securely

2. Configure credentials:
```bash
# Option 1: Using ~/.pypirc
cat > ~/.pypirc << EOF
[pypi]
  username = __token__
  password = pypi-...your-token...

[testpypi]
  username = __token__
  password = pypi-...your-token...
EOF

# Option 2: Environment variables
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-...your-token...
```

### Publishing

```bash
# Upload to PyPI
python -m twine upload dist/*
```

Your package will be available at:
https://pypi.org/project/sqlmodel-graphql/

## Post-release

1. **Create Git Tag**
```bash
git tag -a v0.1.0 -m "Release version 0.1.0"
git push origin v0.1.0
```

2. **Create GitHub Release**
   - Go to https://github.com/allmonday/sqlmodel-graphql/releases/new
   - Select the tag
   - Add release notes from CHANGELOG.md
   - Attach distribution files (optional)

3. **Announce**
   - Update GitHub repository description
   - Share on social media (Twitter, Reddit, etc.)
   - Post on Python forums

## Automated Publishing (Optional)

### GitHub Actions

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          pip install build twine

      - name: Build
        run: python -m build

      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

Add `PYPI_API_TOKEN` to GitHub repository secrets.

## Troubleshooting

### File already exists
If you try to upload the same version again:
```
HTTPError: 400 Bad Request
File already exists.
```
**Solution**: Bump the version number and rebuild.

### Invalid distribution
If the wheel is invalid:
```
HTTPError: 400 Bad Request
Invalid distribution.
```
**Solution**: Ensure `pyproject.toml` is correct and rebuild.

### Missing dependencies
If dependencies aren't installed:
```
ModuleNotFoundError: No module named 'xxx'
```
**Solution**: Add to `dependencies` in `pyproject.toml`.

## Useful Commands

```bash
# Check package metadata
twine check dist/*

# View package contents
tar -tzf dist/sqlmodel_graphql-0.1.0.tar.gz
unzip -l dist/sqlmodel_graphql-0.1.0-py3-none-any.whl

# Download from PyPI
pip download sqlmodel-graphql

# Inspect package
pip show sqlmodel-graphql
```

## Resources

- [Python Packaging Guide](https://packaging.python.org/)
- [Twine Documentation](https://twine.readthedocs.io/)
- [PyPI Help](https://pypi.org/help/)
