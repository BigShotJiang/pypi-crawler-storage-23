# Templates

Templates let you combine multiple secret values into structured configuration files
using Jinja2.

## When to Use Templates

- Application config files that require multiple secrets
- Connection strings composed from several fields
- Bundling credentials into structured formats

## Related

- [Template Target](targets/template.md)
- [Secret Generation](generators/index.md)
