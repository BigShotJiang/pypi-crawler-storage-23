# Data Models

SecretZero uses Pydantic models to validate configuration and runtime data.

## Key Models

- Secretfile schema and validation
- Lockfile entries for rotation tracking
- Provider and target configurations

## Related

- [Schema Documentation](../schema.md)
- [Secretfile Reference](../user-guide/configuration/secretfile.md)
