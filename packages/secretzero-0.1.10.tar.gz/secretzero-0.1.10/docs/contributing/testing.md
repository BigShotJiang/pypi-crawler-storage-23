# Testing

## Run Tests

```bash
pytest
```

## Tips

- Use `pytest -k` to focus on a subset
- Keep one assertion per test when possible
- Use fixtures for shared setup
