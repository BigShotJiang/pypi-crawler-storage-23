# Security Best Practices

- Use least-privilege credentials
- Separate dev and prod secret stores
- Avoid secrets in logs or debug output
- Review drift and rotation reports regularly
