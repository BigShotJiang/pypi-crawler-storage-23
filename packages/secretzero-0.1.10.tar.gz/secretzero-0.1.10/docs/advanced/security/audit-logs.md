# Audit Logs

Audit logs record secret operations for compliance and investigation.

## Best Practices

- Centralize logs in a SIEM system
- Retain logs based on compliance requirements
- Alert on unexpected rotation or drift events
