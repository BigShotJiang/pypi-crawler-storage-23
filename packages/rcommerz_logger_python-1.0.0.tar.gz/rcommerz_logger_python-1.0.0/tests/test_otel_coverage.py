"""Tests for OpenTelemetry integration to achieve 100% coverage"""

import pytest
from unittest.mock import Mock, patch

from rcommerz_logger import Logger, LoggerConfig


class TestOpenTelemetryIntegration:
    """Test OpenTelemetry trace context extraction"""

    @patch('rcommerz_logger.logger.trace')
    def test_trace_context_with_active_span(self, mock_trace, capsys):
        """Should extract trace context from active OpenTelemetry span"""
        # Setup mock span with trace and span IDs
        mock_span_context = Mock()
        mock_span_context.trace_id = 0x5e3d2c1b0a09080706050403a2010100
        mock_span_context.span_id = 0x1234567890abcdef

        mock_span = Mock()
        mock_span.is_recording.return_value = True
        mock_span.get_span_context.return_value = mock_span_context

        mock_trace.get_current_span.return_value = mock_span

        # Initialize logger
        Logger.initialize(LoggerConfig(
            service_name="test-otel-active",
            service_version="1.0.0",
            env="test"
        ))

        logger = Logger.get_instance()
        logger.info("Test with active span", {"test": "data"})

        captured = capsys.readouterr()
        output = captured.out

        # Should include trace context
        assert "trace_id" in output
        assert "span_id" in output

    @patch('rcommerz_logger.logger.trace')
    def test_trace_context_with_non_recording_span(self, mock_trace, capsys):
        """Should handle non-recording span gracefully"""
        # Setup mock span that is not recording
        mock_span = Mock()
        mock_span.is_recording.return_value = False

        mock_trace.get_current_span.return_value = mock_span

        Logger.initialize(LoggerConfig(
            service_name="test-otel-not-recording",
            service_version="1.0.0",
            env="test"
        ))

        logger = Logger.get_instance()
        logger.info("Test with non-recording span")

        captured = capsys.readouterr()
        output = captured.out

        # Should still log, just without trace context
        assert "Test with non-recording span" in output

    @patch('rcommerz_logger.logger.trace')
    def test_trace_context_with_none_span(self, mock_trace, capsys):
        """Should handle None span gracefully"""
        mock_trace.get_current_span.return_value = None

        Logger.initialize(LoggerConfig(
            service_name="test-otel-none-span",
            service_version="1.0.0",
            env="test"
        ))

        logger = Logger.get_instance()
        logger.info("Test with None span")

        captured = capsys.readouterr()
        output = captured.out

        # Should still log without crash
        assert "Test with None span" in output

    @patch('rcommerz_logger.logger.trace')
    def test_trace_context_exception_handling(self, mock_trace, capsys):
        """Should handle exceptions in trace extraction"""
        # Make get_current_span raise an exception
        mock_trace.get_current_span.side_effect = Exception(
            "OpenTelemetry error")

        Logger.initialize(LoggerConfig(
            service_name="test-otel-exception",
            service_version="1.0.0",
            env="test"
        ))

        logger = Logger.get_instance()
        logger.info("Test with exception in trace extraction")

        captured = capsys.readouterr()
        output = captured.out

        # Should handle exception and continue logging
        assert "Test with exception in trace extraction" in output

    @patch('rcommerz_logger.logger.trace')
    def test_all_log_methods_with_trace_context(self, mock_trace, capsys):
        """Should extract trace context for all log methods"""
        # Setup mock span
        mock_span_context = Mock()
        mock_span_context.trace_id = 0x1234567890abcdef1234567890abcdef
        mock_span_context.span_id = 0xabcdef1234567890

        mock_span = Mock()
        mock_span.is_recording.return_value = True
        mock_span.get_span_context.return_value = mock_span_context

        mock_trace.get_current_span.return_value = mock_span

        Logger.initialize(LoggerConfig(
            service_name="test-all-methods-trace",
            service_version="1.0.0",
            env="test",
            level="debug"
        ))

        logger = Logger.get_instance()

        # Test all log methods with trace context
        logger.info("Info log")
        logger.error("Error log", {"error_details": "something"})
        logger.warn("Warning log")
        logger.debug("Debug log")
        logger.security("Security log", {"security_event": "login"})
        logger.audit("Audit log", {"action": "create"})
        logger.http("HTTP log", {"method": "GET"})

        captured = capsys.readouterr()
        output = captured.out

        # All logs should have trace_id
        assert output.count("trace_id") >= 7
