"""Pytest configuration and shared fixtures"""

import pytest
from io import StringIO
from typing import Generator

from rcommerz_logger import Logger
from rcommerz_logger.types import LoggerConfig


@pytest.fixture(autouse=True)
def reset_logger():
    """Reset logger singleton before each test"""
    Logger._instance = None
    Logger._initialized = False
    yield
    Logger._instance = None
    Logger._initialized = False


@pytest.fixture
def logger_config() -> LoggerConfig:
    """Provide default logger configuration for tests"""
    return LoggerConfig(
        service_name="test-service",
        service_version="1.0.0",
        env="test",
        level="INFO"
    )


@pytest.fixture
def initialized_logger(logger_config: LoggerConfig) -> Logger:
    """Provide an initialized logger instance"""
    return Logger.initialize(logger_config)


@pytest.fixture
def capture_stdout() -> Generator[StringIO, None, None]:
    """Capture stdout output for log verification"""
    old_stdout = sys.stdout
    sys.stdout = captured_output = StringIO()
    yield captured_output
    sys.stdout = old_stdout
