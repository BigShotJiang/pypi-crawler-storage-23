"""Unit tests for Logger class"""

import json
import pytest
from datetime import datetime
from io import StringIO

from rcommerz_logger import Logger
from rcommerz_logger.types import LoggerConfig, LogType


@pytest.mark.unit
class TestLoggerInitialization:
    """Test logger initialization and singleton pattern"""

    def test_initialize_creates_singleton(self, logger_config):
        """Should create singleton instance"""
        logger1 = Logger.initialize(logger_config)
        logger2 = Logger.get_instance()

        assert logger1 is logger2
        assert Logger._initialized is True

    def test_initialize_only_once(self, logger_config):
        """Should not reinitialize if already initialized"""
        logger1 = Logger.initialize(logger_config)

        new_config = LoggerConfig(
            service_name="different-service",
            service_version="2.0.0",
            env="production",
            level="DEBUG"
        )
        logger2 = Logger.initialize(new_config)

        assert logger1 is logger2
        assert logger1.config.service_name == "test-service"

    def test_get_instance_before_initialization(self):
        """Should raise error if logger not initialized"""
        with pytest.raises(RuntimeError, match="Logger not initialized"):
            Logger.get_instance()

    def test_logger_config_stored(self, initialized_logger, logger_config):
        """Should store configuration"""
        assert initialized_logger.config.service_name == logger_config.service_name
        assert initialized_logger.config.service_version == logger_config.service_version
        assert initialized_logger.config.env == logger_config.env
        assert initialized_logger.config.level == logger_config.level


@pytest.mark.unit
class TestLoggingMethods:
    """Test logging methods"""

    def test_info_logging(self, initialized_logger, capsys):
        """Should log info messages"""
        initialized_logger.info("Test info message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Test info message"
        assert log_data["log.level"] == "INFO"
        assert log_data["log_type"] == "normal"

    def test_error_logging(self, initialized_logger, capsys):
        """Should log error messages"""
        initialized_logger.error("Test error message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Test error message"
        assert log_data["log.level"] == "ERROR"

    def test_warn_logging(self, initialized_logger, capsys):
        """Should log warning messages"""
        initialized_logger.warn("Test warning message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Test warning message"
        assert log_data["log.level"] == "WARNING"

    def test_debug_logging(self, logger_config, capsys):
        """Should log debug messages when level is DEBUG"""
        logger_config.level = "DEBUG"
        logger = Logger.initialize(logger_config)

        logger.debug("Test debug message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Test debug message"
        assert log_data["log.level"] == "DEBUG"

    def test_security_logging(self, initialized_logger, capsys):
        """Should log security events"""
        initialized_logger.security(
            "Security event occurred", {"ip": "192.168.1.1"})

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Security event occurred"
        assert log_data["log_type"] == "security"
        assert log_data["ip"] == "192.168.1.1"

    def test_audit_logging(self, initialized_logger, capsys):
        """Should log audit events"""
        initialized_logger.audit("User action logged", {
                                 "action": "delete", "resource": "user-123"})

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "User action logged"
        assert log_data["log_type"] == "audit"
        assert log_data["action"] == "delete"

    def test_http_logging(self, initialized_logger, capsys):
        """Should log HTTP requests"""
        initialized_logger.http(
            "GET /api/users", {"status": 200, "duration_ms": 45})

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "GET /api/users"
        assert log_data["log_type"] == "http"
        assert log_data["status"] == 200


@pytest.mark.unit
class TestContextHandling:
    """Test context management"""

    def test_logging_with_context(self, initialized_logger, capsys):
        """Should include context in logs"""
        context = {
            "user_id": "usr-123",
            "request_id": "req-456",
            "ip": "192.168.1.1"
        }

        initialized_logger.info("Test with context", context)

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["user_id"] == "usr-123"
        assert log_data["request_id"] == "req-456"
        assert log_data["ip"] == "192.168.1.1"

    def test_logging_with_empty_context(self, initialized_logger, capsys):
        """Should handle empty context"""
        initialized_logger.info("Test without context")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["message"] == "Test without context"

    def test_logging_with_nested_context(self, initialized_logger, capsys):
        """Should handle nested context objects"""
        context = {
            "user": {
                "id": "usr-123",
                "email": "test@example.com"
            },
            "metadata": {
                "tags": ["important", "urgent"]
            }
        }

        initialized_logger.info("Test nested context", context)

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["user"]["id"] == "usr-123"
        assert log_data["metadata"]["tags"] == ["important", "urgent"]

    def test_logging_with_exception(self, initialized_logger, capsys):
        """Should extract error details from exceptions"""
        try:
            raise ValueError("Test error message")
        except ValueError as e:
            initialized_logger.error("Error occurred", {"error": e})

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert "error_message" in log_data
        assert "error_type" in log_data
        assert log_data["error_message"] == "Test error message"
        assert log_data["error_type"] == "ValueError"


@pytest.mark.unit
class TestStandardFields:
    """Test standard log fields"""

    def test_includes_timestamp(self, initialized_logger, capsys):
        """Should include @timestamp field"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert "@timestamp" in log_data
        # Verify it's a valid ISO timestamp
        datetime.fromisoformat(log_data["@timestamp"].replace('Z', '+00:00'))

    def test_includes_service_fields(self, initialized_logger, capsys):
        """Should include service name and version"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["service.name"] == "test-service"
        assert log_data["service.version"] == "1.0.0"

    def test_includes_environment(self, initialized_logger, capsys):
        """Should include environment"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert log_data["env"] == "test"

    def test_includes_hostname(self, initialized_logger, capsys):
        """Should include hostname"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert "host.name" in log_data
        assert log_data["host.name"] == initialized_logger.hostname

    def test_includes_log_level(self, initialized_logger, capsys):
        """Should include log.level field"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()
        log_data = json.loads(captured.out.strip())

        assert "log.level" in log_data
        assert log_data["log.level"] == "INFO"

    def test_output_is_json(self, initialized_logger, capsys):
        """Should output valid JSON"""
        initialized_logger.info("Test message")

        captured = capsys.readouterr()

        # Should not raise exception
        log_data = json.loads(captured.out.strip())
        assert isinstance(log_data, dict)


@pytest.mark.unit
class TestLogLevels:
    """Test log level filtering"""

    def test_info_level_filters_debug(self, logger_config, capsys):
        """Should not log debug when level is INFO"""
        logger_config.level = "INFO"
        logger = Logger.initialize(logger_config)

        logger.debug("This should not appear")
        logger.info("This should appear")

        captured = capsys.readouterr()
        output = captured.out

        assert "This should not appear" not in output
        assert "This should appear" in output

    def test_error_level_filters_info(self, logger_config, capsys):
        """Should not log info when level is ERROR"""
        logger_config.level = "ERROR"
        logger = Logger.initialize(logger_config)

        logger.info("This should not appear")
        logger.error("This should appear")

        captured = capsys.readouterr()
        output = captured.out

        assert "This should not appear" not in output
        assert "This should appear" in output

    def test_debug_level_logs_all(self, logger_config, capsys):
        """Should log all levels when level is DEBUG"""
        logger_config.level = "DEBUG"
        logger = Logger.initialize(logger_config)

        logger.debug("Debug message")
        logger.info("Info message")
        logger.warn("Warn message")
        logger.error("Error message")

        captured = capsys.readouterr()
        output = captured.out

        assert "Debug message" in output
        assert "Info message" in output
        assert "Warn message" in output
        assert "Error message" in output


@pytest.mark.performance
class TestPerformance:
    """Test logging performance"""

    def test_can_log_many_messages_quickly(self, initialized_logger, capsys):
        """Should handle high-volume logging"""
        import time

        start = time.time()
        for i in range(1000):
            initialized_logger.info(f"Log message {i}")
        duration = time.time() - start

        # Should complete 1000 logs in under 1 second
        assert duration < 1.0

    def test_context_does_not_slow_logging(self, initialized_logger, capsys):
        """Should handle context efficiently"""
        import time

        context = {"key1": "value1", "key2": "value2", "key3": "value3"}

        start = time.time()
        for i in range(500):
            initialized_logger.info(f"Log with context {i}", context)
        duration = time.time() - start

        # Should complete 500 logs with context in under 1 second
        assert duration < 1.0
