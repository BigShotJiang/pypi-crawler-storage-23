"""Integration tests for complete logging flows"""

import json
import pytest
from fastapi import FastAPI, HTTPException, Request
from httpx import AsyncClient, ASGITransport
import asyncio

from rcommerz_logger import Logger, LoggerConfig
from rcommerz_logger.middleware import LoggerMiddleware
from rcommerz_logger.types import LogType


@pytest.fixture
def full_app():
    """Create a complete FastAPI app with all features"""
    Logger.initialize(LoggerConfig(
        service_name="integration-test-api",
        service_version="2.0.0",
        env="test",
        level="info"
    ))

    app = FastAPI()
    logger = Logger.get_instance()

    app.add_middleware(
        LoggerMiddleware,
        exclude_paths=["/health"]
    )

    @app.get("/api/users/{user_id}")
    async def get_user(user_id: str, request: Request):
        request.state.user_id = user_id
        logger.info(f"Fetching user {user_id}")
        return {"user_id": user_id, "name": "Test User"}

    @app.post("/api/orders")
    async def create_order(request: Request):
        request.state.user_id = "usr-456"
        logger.audit("Order created", {"order_id": "ORD-789", "total": 199.99})
        return {"order_id": "ORD-789", "status": "created"}

    @app.get("/api/secure")
    async def secure_endpoint():
        logger.security("Accessing secure endpoint", {"ip": "192.168.1.1"})
        return {"data": "sensitive"}

    @app.get("/api/error-test")
    async def error_test():
        try:
            raise ValueError("Something went wrong")
        except ValueError as e:
            logger.error("Error in endpoint", {"error": str(e)})
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/health")
    async def health():
        return {"status": "healthy"}

    return app


@pytest.mark.integration
@pytest.mark.asyncio
class TestCompleteFlows:
    """Test complete request/response flows with logging"""

    async def test_user_fetch_flow(self, full_app, capsys):
        """Should log complete user fetch flow"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            response = await client.get("/api/users/usr-123")

        assert response.status_code == 200
        assert response.json()["user_id"] == "usr-123"

        captured = capsys.readouterr()
        output = captured.out

        # Should have both application log and HTTP log
        assert "Fetching user usr-123" in output
        assert "GET /api/users/usr-123" in output
        assert '"user_id": "usr-123"' in output

    async def test_order_creation_audit_flow(self, full_app, capsys):
        """Should log audit trail for order creation"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            response = await client.post("/api/orders", json={"item_id": "item-123"})

        assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Should have audit log
        assert "Order created" in output
        assert '"log_type": "audit"' in output
        assert "ORD-789" in output

    async def test_security_event_flow(self, full_app, capsys):
        """Should log security events properly"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            response = await client.get("/api/secure")

        assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Should have security log
        assert "Accessing secure endpoint" in output
        assert '"log_type": "security"' in output
        assert "192.168.1.1" in output

    async def test_error_handling_flow(self, full_app, capsys):
        """Should log errors with full context"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            response = await client.get("/api/error-test")

        assert response.status_code == 500

        captured = capsys.readouterr()
        output = captured.out

        # Should have error logs
        assert "Error in endpoint" in output
        assert "Something went wrong" in output

    async def test_excluded_endpoints_not_logged(self, full_app, capsys):
        """Should not log excluded health check endpoints"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            response = await client.get("/health")

        assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Health endpoint should not be in logs
        assert output == "" or "/health" not in output


@pytest.mark.integration
@pytest.mark.asyncio
class TestConcurrentScenarios:
    """Test concurrent request scenarios"""

    async def test_concurrent_mixed_requests(self, full_app, capsys):
        """Should handle concurrent requests of different types"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            tasks = [
                client.get("/api/users/usr-1"),
                client.get("/api/users/usr-2"),
                client.post("/api/orders", json={"item": "test"}),
                client.get("/api/secure"),
                client.get("/health"),
            ]

            responses = await asyncio.gather(*tasks, return_exceptions=True)

        # Check responses
        assert responses[0].status_code == 200  # user 1
        assert responses[1].status_code == 200  # user 2
        assert responses[2].status_code == 200  # order
        assert responses[3].status_code == 200  # secure
        assert responses[4].status_code == 200  # health

        captured = capsys.readouterr()
        output = captured.out

        # Verify all endpoints are logged (except health)
        assert "/api/users/usr-1" in output
        assert "/api/users/usr-2" in output
        assert "/api/orders" in output
        assert "/api/secure" in output

    async def test_high_load_stability(self, full_app, capsys):
        """Should remain stable under high load"""
        import time

        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            start = time.time()

            # 50 concurrent requests
            tasks = [client.get("/api/users/usr-test") for _ in range(50)]
            responses = await asyncio.gather(*tasks)

            duration = time.time() - start

        # All should succeed
        assert all(r.status_code == 200 for r in responses)

        # Should complete in reasonable time
        assert duration < 10.0

        captured = capsys.readouterr()
        output = captured.out

        # Should have logs for all requests (count JSON lines, not string occurrences)
        log_lines = [line for line in output.strip().split("\n") if line and "/api/users/usr-test" in line]
        assert len(log_lines) == 50


@pytest.mark.integration
class TestLogStructure:
    """Test log structure and format consistency"""

    @pytest.mark.asyncio
    async def test_all_logs_are_valid_json(self, full_app, capsys):
        """Should produce valid JSON for all log entries"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            await client.get("/api/users/usr-123")
            await client.post("/api/orders", json={})
            await client.get("/api/secure")

        captured = capsys.readouterr()

        # Verify each line is valid JSON
        for line in captured.out.split('\n'):
            if line.strip():
                # Should not raise exception
                log_data = json.loads(line)
                assert isinstance(log_data, dict)

    @pytest.mark.asyncio
    async def test_mandatory_fields_present(self, full_app, capsys):
        """Should include all mandatory fields in every log"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            await client.get("/api/users/usr-123")

        captured = capsys.readouterr()

        mandatory_fields = [
            "@timestamp",
            "log.level",
            "log_type",
            "service.name",
            "service.version",
            "env",
            "host.name",
            "message"
        ]

        for line in captured.out.split('\n'):
            if line.strip():
                log_data = json.loads(line)
                for field in mandatory_fields:
                    assert field in log_data, f"Missing mandatory field: {field}"

    @pytest.mark.asyncio
    async def test_service_metadata_consistent(self, full_app, capsys):
        """Should maintain consistent service metadata across all logs"""
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            await client.get("/api/users/usr-1")
            await client.get("/api/users/usr-2")
            await client.post("/api/orders", json={})

        captured = capsys.readouterr()

        service_names = []
        service_versions = []
        environments = []

        for line in captured.out.split('\n'):
            if line.strip():
                log_data = json.loads(line)
                service_names.append(log_data.get("service.name"))
                service_versions.append(log_data.get("service.version"))
                environments.append(log_data.get("env"))

        # All should be consistent
        assert len(set(service_names)) == 1
        assert service_names[0] == "integration-test-api"
        assert len(set(service_versions)) == 1
        assert service_versions[0] == "2.0.0"
        assert len(set(environments)) == 1
        assert environments[0] == "test"


@pytest.mark.integration
@pytest.mark.performance
class TestPerformanceIntegration:
    """Test performance under realistic conditions"""

    @pytest.mark.asyncio
    async def test_logging_overhead_minimal(self, full_app):
        """Should have minimal performance overhead"""
        import time

        # Test without logging to get baseline
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            start = time.time()
            for _ in range(100):
                await client.get("/health")  # Excluded from logging
            baseline_duration = time.time() - start

        # Test with logging
        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            start = time.time()
            for _ in range(100):
                await client.get("/api/users/usr-test")  # Logged
            logged_duration = time.time() - start

        # Logging overhead should be < 50% of baseline
        overhead = logged_duration - baseline_duration
        assert overhead < (baseline_duration * 0.5)

    @pytest.mark.asyncio
    async def test_memory_efficient_logging(self, full_app, capsys):
        """Should not cause memory issues with high volume"""
        import sys

        async with AsyncClient(transport=ASGITransport(app=full_app), base_url="http://test") as client:
            # Generate lots of logs
            for i in range(500):
                await client.get(f"/api/users/usr-{i}")

        # Should complete without memory errors
        captured = capsys.readouterr()
        assert len(captured.out) > 0
