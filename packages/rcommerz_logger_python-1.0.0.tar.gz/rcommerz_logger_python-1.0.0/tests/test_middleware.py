"""Tests for FastAPI middleware"""

import json
import pytest
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from httpx import AsyncClient, ASGITransport

from rcommerz_logger import Logger, LoggerConfig
from rcommerz_logger.middleware import LoggerMiddleware


@pytest.fixture
def app():
    """Create FastAPI app with logger middleware"""
    Logger.initialize(LoggerConfig(
        service_name="test-api",
        service_version="1.0.0",
        env="test",
        level="info"
    ))

    app = FastAPI()
    app.add_middleware(
        LoggerMiddleware,
        exclude_paths=["/health", "/metrics"]
    )

    @app.get("/api/test")
    async def test_endpoint():
        return {"status": "ok"}

    @app.get("/api/error")
    async def error_endpoint():
        raise HTTPException(status_code=500, detail="Internal error")

    @app.get("/api/notfound")
    async def notfound_endpoint():
        raise HTTPException(status_code=404, detail="Not found")

    @app.get("/health")
    async def health_endpoint():
        return {"status": "healthy"}

    @app.get("/api/user")
    async def user_endpoint(request: Request):
        request.state.user_id = "usr-123"
        return {"user": "data"}

    @app.post("/api/orders")
    async def create_order():
        return {"order_id": "ORD-123"}

    return app


@pytest.mark.asyncio
class TestMiddlewareLogging:
    """Test middleware logging functionality"""

    async def test_logs_successful_requests(self, app, capsys):
        """Should log successful HTTP requests"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/test")

        assert response.status_code == 200

        captured = capsys.readouterr()
        assert "GET /api/test" in captured.out
        assert '"status_code": 200' in captured.out

    async def test_logs_error_responses(self, app, capsys):
        """Should log error responses"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/error")

        assert response.status_code == 500

        captured = capsys.readouterr()
        assert "GET /api/error" in captured.out
        assert '"status_code": 500' in captured.out

    async def test_logs_client_errors(self, app, capsys):
        """Should log client error responses"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/notfound")

        assert response.status_code == 404

        captured = capsys.readouterr()
        assert "GET /api/notfound" in captured.out
        assert '"status_code": 404' in captured.out

    async def test_excludes_health_endpoints(self, app, capsys):
        """Should exclude specified paths from logging"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/health")

        assert response.status_code == 200

        captured = capsys.readouterr()
        # Health endpoint should not be logged
        assert captured.out == "" or "/health" not in captured.out

    async def test_includes_user_context(self, app, capsys):
        """Should include user_id from request state"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/user")

        assert response.status_code == 200

        captured = capsys.readouterr()
        assert '"user_id": "usr-123"' in captured.out

    async def test_measures_request_duration(self, app, capsys):
        """Should measure and log request duration"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/test")

        assert response.status_code == 200

        captured = capsys.readouterr()
        assert '"duration_ms"' in captured.out

        # Verify duration is a number > 0
        for line in captured.out.split('\n'):
            if line.strip():
                log_data = json.loads(line)
                if "duration_ms" in log_data:
                    assert log_data["duration_ms"] > 0

    async def test_includes_query_parameters(self, app, capsys):
        """Should log query parameters"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/test?page=1&limit=10")

        assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        # Verify query params are logged
        assert "page" in output or "query" in output


@pytest.mark.asyncio
class TestMiddlewareConfiguration:
    """Test middleware configuration options"""

    async def test_exclude_multiple_paths(self, capsys):
        """Should exclude multiple paths from logging"""
        Logger.initialize(LoggerConfig(
            service_name="test-api",
            service_version="1.0.0",
            env="test",
            level="info"
        ))

        app = FastAPI()
        app.add_middleware(
            LoggerMiddleware,
            exclude_paths=["/health", "/metrics", "/readiness"]
        )

        @app.get("/health")
        async def health():
            return {"status": "ok"}

        @app.get("/metrics")
        async def metrics():
            return {"metrics": {}}

        @app.get("/api/data")
        async def data():
            return {"data": "test"}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            await client.get("/health")
            await client.get("/metrics")
            await client.get("/api/data")

        captured = capsys.readouterr()
        output = captured.out

        # Excluded paths should not appear
        assert "/health" not in output or output.count("/health") == 0
        assert "/metrics" not in output or output.count("/metrics") == 0
        # Normal API should be logged
        assert "/api/data" in output

    async def test_handles_different_http_methods(self, app, capsys):
        """Should log various HTTP methods"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # GET
            response = await client.get("/api/test")
            assert response.status_code == 200

            # POST
            response = await client.post("/api/orders", json={"item": "test"})
            assert response.status_code == 200

        captured = capsys.readouterr()
        output = captured.out

        assert "GET /api/test" in output
        assert "POST /api/orders" in output


@pytest.mark.asyncio
class TestMiddlewareIntegration:
    """Test middleware integration scenarios"""

    async def test_concurrent_requests(self, app, capsys):
        """Should handle concurrent requests correctly"""
        import asyncio

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # Send 10 concurrent requests
            tasks = [client.get("/api/test") for _ in range(10)]
            responses = await asyncio.gather(*tasks)

        # All should succeed
        assert all(r.status_code == 200 for r in responses)

        captured = capsys.readouterr()
        output = captured.out

        # Should have 10 log entries (count JSON lines, not string occurrences)
        log_lines = [line for line in output.strip().split("\n") if line and "/api/test" in line]
        assert len(log_lines) == 10

    async def test_logs_contain_standard_fields(self, app, capsys):
        """Should include all standard fields in logs"""
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.get("/api/test")

        assert response.status_code == 200

        captured = capsys.readouterr()

        # Parse log output
        for line in captured.out.split('\n'):
            if line.strip() and "/api/test" in line:
                log_data = json.loads(line)

                # Verify standard fields
                assert "@timestamp" in log_data
                assert "log.level" in log_data
                assert "service.name" in log_data
                assert log_data["service.name"] == "test-api"
                assert "service.version" in log_data
                assert "env" in log_data
                assert "host.name" in log_data
                assert "method" in log_data
                assert "path" in log_data
                assert "status_code" in log_data
                assert "duration_ms" in log_data

    async def test_performance_with_high_volume(self, app, capsys):
        """Should handle high-volume requests efficiently"""
        import time

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            start = time.time()

            # Send 100 requests
            for _ in range(100):
                await client.get("/api/test")

            duration = time.time() - start

        # Should complete in reasonable time (< 5 seconds)
        assert duration < 5.0
