"""Tests for edge cases and 100% coverage"""

import pytest
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport

from rcommerz_logger import Logger, LoggerConfig, create_fastapi_middleware


class TestEdgeCases:
    """Test edge cases for complete code coverage"""

    def test_logger_init_early_return(self):
        """Should handle __init__ when already initialized"""
        config = LoggerConfig(
            service_name="test-edge",
            service_version="1.0.0",
            env="test"
        )

        # Initialize once
        Logger.initialize(config)

        # Try to initialize again (should trigger early return in __init__)
        config2 = LoggerConfig(
            service_name="different",
            service_version="2.0.0",
            env="prod"
        )
        Logger.initialize(config2)

        # Should keep original config (early return was triggered)
        instance = Logger.get_instance()
        assert instance.config.service_name == "test-edge"

    @pytest.mark.asyncio
    async def test_middleware_unhandled_exception(self, capsys):
        """Should log unhandled exceptions in middleware"""
        app = FastAPI()

        Logger.initialize(LoggerConfig(
            service_name="test-exception",
            service_version="1.0.0",
            env="test"
        ))

        create_fastapi_middleware(app)

        @app.get("/crash")
        async def crash_endpoint():
            # Simulate unhandled exception
            raise ValueError("Unexpected error")

        # Test that middleware catches and logs the exception
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with pytest.raises(ValueError):
                await client.get("/crash")

        captured = capsys.readouterr()
        output = captured.out

        # Should log the unhandled exception
        assert "Unhandled exception" in output
        assert "Unexpected error" in output
        assert "/crash" in output

    @pytest.mark.asyncio
    async def test_middleware_handles_zero_division(self, capsys):
        """Should catch and log ZeroDivisionError"""
        app = FastAPI()

        Logger.initialize(LoggerConfig(
            service_name="test-zero-div",
            service_version="1.0.0",
            env="test"
        ))

        create_fastapi_middleware(app)

        @app.get("/divide")
        async def divide_endpoint():
            return {"result": 10 / 0}

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            with pytest.raises(ZeroDivisionError):
                await client.get("/divide")

        captured = capsys.readouterr()
        output = captured.out

        # Should log the exception
        assert "Unhandled exception" in output
        assert "division by zero" in output


class TestOpenTelemetryPaths:
    """Test OpenTelemetry integration paths"""

    def test_trace_extraction_without_active_span(self, capsys):
        """Should handle case where no span is recording"""
        Logger.initialize(LoggerConfig(
            service_name="test-otel",
            service_version="1.0.0",
            env="test",
            level="info"
        ))

        logger = Logger.get_instance()

        # Log without active OpenTelemetry span
        # This exercises the _extract_trace_context method
        logger.info("Test without span", {"test": "data"})

        captured = capsys.readouterr()
        output = captured.out

        # Should still log successfully
        assert "Test without span" in output
        assert "test" in output

    def test_multiple_logs_without_trace_context(self, capsys):
        """Should handle multiple logs without trace context"""
        Logger.initialize(LoggerConfig(
            service_name="test-no-trace",
            service_version="1.0.0",
            env="test"
        ))

        logger = Logger.get_instance()

        # Multiple logs without trace context
        for i in range(5):
            logger.info(f"Log {i}", {"index": i})

        captured = capsys.readouterr()
        output = captured.out

        # All logs should be present
        for i in range(5):
            assert f"Log {i}" in output


class TestLoggerReinitializationProtection:
    """Test logger reinitialization protection"""

    def test_cannot_reinitialize_after_first_init(self):
        """Should not allow reinitialization after first initialize()"""
        config1 = LoggerConfig(
            service_name="first-service",
            service_version="1.0.0",
            env="test"
        )

        config2 = LoggerConfig(
            service_name="second-service",
            service_version="2.0.0",
            env="production"
        )

        # Initialize with first config
        Logger.initialize(config1)
        instance1 = Logger.get_instance()

        # Try to initialize again with different config
        Logger.initialize(config2)
        instance2 = Logger.get_instance()

        # Should be same instance with original config
        assert instance1 is instance2
        assert instance1.config.service_name == "first-service"
        assert instance1.config.service_version == "1.0.0"

    def test_direct_constructor_after_initialize(self):
        """Should handle direct constructor call after initialize()"""
        config = LoggerConfig(
            service_name="test-direct",
            service_version="1.0.0",
            env="test"
        )

        # Initialize first
        Logger.initialize(config)
        original = Logger.get_instance()

        # Try direct constructor (tests __init__ early return)
        new_config = LoggerConfig(
            service_name="different",
            service_version="2.0.0",
            env="prod"
        )
        attempted = Logger(new_config)

        # Should return early and maintain original instance
        assert original.config.service_name == "test-direct"
