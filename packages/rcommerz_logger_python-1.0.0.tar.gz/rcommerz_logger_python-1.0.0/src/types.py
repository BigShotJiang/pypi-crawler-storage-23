"""Type definitions for the logger"""

from typing import Any, Dict, Literal
from dataclasses import dataclass

LogLevel = Literal["DEBUG", "INFO", "WARN", "ERROR"]
LogType = Literal["normal", "http", "error", "security", "audit", "debug"]


@dataclass
class LoggerConfig:
    """Configuration for logger initialization"""
    service_name: str
    service_version: str
    env: str
    level: str = "INFO"


LogContext = Dict[str, Any]
