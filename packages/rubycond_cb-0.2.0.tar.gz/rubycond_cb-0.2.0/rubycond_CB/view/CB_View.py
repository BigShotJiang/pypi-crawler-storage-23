# -*- coding: utf-8 -*-
"""

Title: Rubycond_CB: tool for calibrating the wavelength of the spectrometer

This file is part of Rubycond: Pressure by Ruby Luminescence (PRL) software to determine pressure in diamond anvil cell experiments.

Version 0.2.0
Release 260301

Author:

Yiuri Garino
    yiuri.garino@cnrs.fr

Copyright (c) 2023-2026 Yiuri Garino

Download: 
    https://github.com/CelluleProjet/Rubycond_calc

License: GPLv3

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

"""

def reset():
    import sys
    
    if hasattr(sys, 'ps1'):
        
        #clean Console and Memory
        from IPython import get_ipython
        get_ipython().run_line_magic('clear','/')
        get_ipython().run_line_magic('reset','-sf')
        print("Running interactively")
        print()
        terminal = False
    else:
        print("Running in terminal")
        print()
        terminal = True

if __name__ == '__main__':
    reset()
    

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.backend_bases import MouseEvent
from pathlib import Path
import time
from datetime import datetime

#import OpenFile_00 as of
import sys

from lmfit.models import LinearModel, GaussianModel



# x, y = np.linspace(-10,10,400), np.linspace(-10,10,400)
# X, Y = np.meshgrid(x, y)

# data = np.sinc(np.hypot(X, Y))
        
from PyQt5 import QtWidgets, QtCore, QtGui
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavigationToolbar

version = 'RC_View_11.py'

class Data_Table(QtWidgets.QTableWidget):
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.debug = self.model.debug
        self.setColumnCount(3)
        self.setRowCount(1)
        self.setColumnWidth(0, 50)
        self.setColumnWidth(1, 50)
        self.setColumnWidth(2, 50)
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self)
        # Neon = np.loadtxt("Neon_Astrosurf.csv", delimiter=',')
        # self.setHorizontalHeaderLabels(['Wavelength', 'Intensity'])
        # self.set_numpy_2D(Neon)
        
    def print_time(self, event = None, Message = 'Now = '):
        print('Data_Table')

    
     
    def set_numpy_2D(self, data):
        row, col = data.shape
        self.setColumnCount(col+1)
        self.setRowCount(row)
        for i_r in range(row):
            for i_c in range(col):
                self.setItem(i_r, i_c, QtWidgets.QTableWidgetItem(f'{data[i_r,i_c]:.2f}'))
            #self.setItem(i_r, 2, QtWidgets.ItemIsUserCheckable()) #QCheckBox
            
   
            cell_widget = QtWidgets.QWidget()
            chk_bx = QtWidgets.QCheckBox()
            chk_bx.setCheckState(QtCore.Qt.Checked)
            lay_out = QtWidgets.QHBoxLayout(cell_widget)
            lay_out.addWidget(chk_bx)
            lay_out.setAlignment(QtCore.Qt.AlignCenter)
            lay_out.setContentsMargins(0,0,0,0)
            cell_widget.setLayout(lay_out)
            if self.debug: print(f'line {i_r}')
            self.setCellWidget(i_r, 2, cell_widget)
            
class Data_Table_Fine_Calib(Data_Table):
    
    
    def __init__(self, model):
        
        super().__init__(model)
        self.setHorizontalHeaderLabels(['Wavelength', 'Intensity', 'used'])
        self.set_numpy_2D(self.model.Neon_lines)
            
class Data_Table_Points(Data_Table):
    
    signal_table_simple_fit_checkbox_toggled = QtCore.pyqtSignal(int, bool)
    
    def __init__(self, model):
        
        super().__init__(model)
         
        self.setHorizontalHeaderLabels(['nm', 'pixel', 'used'])
        #header = self.horizontalHeader()  
        #header.setResizeMode(QtGui.QHeaderView.ResizeToContents)
        self.setColumnCount(3)
        self.setRowCount(1)
        
        self.used_Row = 0
        self.table_checkbox_ref = []
        self.table_checkbox_ref_checked = []
        self.table_checkbox_nm = []
        self.table_checkbox_pixel = []
        
    def add_col_nm(self, value):
        self.setItem(0, 0, QtWidgets.QTableWidgetItem(value)) #f'{value:.2f}'
    
    def add_col_pixel(self, value):
        self.setItem(0, 1, QtWidgets.QTableWidgetItem(f'{value}'))
    
    def add_table_line(self):
        
        A = self.item(0,0).text()
        B = self.item(0,1).text()

        try:
            A = float(A)
            B = float(B)
        except:
            self.model.error_box("\nPlease Select on Both Graph\n")
            A = 0 
            B = 0
        if (A > 0) and (B > 0):
            cell_widget = QtWidgets.QWidget()
            self.chk_bx = QtWidgets.QCheckBox()
            self.chk_bx.setCheckState(QtCore.Qt.Checked)
            self.chk_bx.toggled.connect(self.table_checkbox_toggled)
            
            #Ref 
            self.table_checkbox_ref.append(self.chk_bx)
            self.table_checkbox_ref_checked.append(True)
            self.table_checkbox_nm.append(A)
            self.table_checkbox_pixel.append(B)
            
            lay_out = QtWidgets.QHBoxLayout(cell_widget)
            lay_out.addWidget(self.chk_bx)
            lay_out.setAlignment(QtCore.Qt.AlignCenter)
            lay_out.setContentsMargins(0,0,0,0)
            cell_widget.setLayout(lay_out)
            if self.debug : print(self.used_Row)
            self.setCellWidget(0, 2, cell_widget)
            self.insertRow(0)
            self.used_Row += 1
        
    
    def table_RESET(self):
        for i in range(self.used_Row):
            self.removeRow(1)
        self.used_Row = 0
        self.table_checkbox_ref = []
        self.table_checkbox_ref_checked = []
        self.table_checkbox_nm = []
        self.table_checkbox_pixel = []
        self.setItem(0, 0, QtWidgets.QTableWidgetItem(''))
        self.setItem(0, 1, QtWidgets.QTableWidgetItem(''))
    
    def table_checkbox_toggled(self):
        print('togg')
        #Check changed and value
        status = []
        for i in self.table_checkbox_ref:
            status.append(i.isChecked())
        a = self.table_checkbox_ref_checked
        #b = status[::-1]
        b = status
        arg = np.argwhere(np.array(a) != np.array(b))
        self.table_checkbox_ref_checked = status
        i = arg[0][0]
        print(a)
        print(b)
        print(i)
        print(b[i])
        self.signal_table_simple_fit_checkbox_toggled.emit(i, b[i])

class CustomToolbar(NavigationToolbar):
    def __init__(self, canvas, parent, ax, debug):
        super(CustomToolbar, self).__init__(canvas, parent, coordinates=True)
        self.ax = ax
        self.debug = debug
        
    def _update_view(self):
        if self.debug: print('my_home')
        self.ax.relim()
        self.ax.autoscale()
        self.canvas.draw()
        
class Frame_1_graph(QtWidgets.QFrame):
    
    signal_fig_on_click = QtCore.pyqtSignal(MouseEvent)
    signal_fig_click_no_drag = QtCore.pyqtSignal(MouseEvent)
    signal_fig_click_drag = QtCore.pyqtSignal(MouseEvent)
    
    def __init__(self, model):
        
        super().__init__()
        self.model = model
        self.debug = self.model.debug
        if self.debug: print("\nDebug mode\n")
        if self.debug: self.setStyleSheet("border: 20px solid red")
        
        layout = QtWidgets.QVBoxLayout()
        self.fig = plt.figure(figsize=(5, 5))
        self.canvas = FigureCanvas(self.fig)
        self.canvas.mpl_connect('button_press_event', self.on_click)
        self.canvas.mpl_connect('button_release_event', self.off_click)
        
        #self.navigationToolbar = NavigationToolbar(self.canvas, self, coordinates=True) #CustomToolbar
        
        self.ax = self.fig.add_subplot(111)
        self.navigationToolbar = CustomToolbar(self.canvas, self, self.ax, self.debug)
        self.ax.grid()
        self.x_moving_ref_left = 0 #Ref to detect drag
        self.y_moving_ref_left = 0 #Ref to detect drag
        #self.navigationToolbar.setSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        
        # show canvas
        self.canvas.show()
        
        # create main layout

        layout.addWidget(self.canvas)
        layout.addWidget(self.navigationToolbar)

        self.setLayout(layout)
        
        self.plot_ref = None
        self.data_x = None
        self.data_y = None
        self.plot_simple_calib_ref = None
    
    def on_click(self, event):
        if self.debug: print('on_click')
        self.x_moving_ref_left = event.xdata
        self.y_moving_ref_left = event.ydata
        self.signal_fig_on_click.emit(event)
    
    def off_click(self, event):
        if self.debug: print('off_click')
        _x = event.xdata
        _y = event.ydata
        not_moved = ((self.x_moving_ref_left == _x) and (self.y_moving_ref_left == _y))
        if not_moved:
            self.signal_fig_click_no_drag.emit(event)
        else:
            self.signal_fig_click_drag.emit(event)
        
    def plot_data(self, data_x, data_y):
        self.data_x = data_x
        self.data_y = data_y
        self.ax.cla()
        self.ax.grid()
        self.ax.plot(self.data_x, self.data_y, '-o')
        self.canvas.draw()
        
    def update_data_y(self, data_y):
        self.data_y = data_y
        self.plot_ref.set_ydata(self.data_y)
        self.rescale_y()
        self.canvas.draw()
        
    def rescale_y(self):
        y_min = self.data_y.min()
        y_max = self.data_y.max()
        y_range = (y_max -y_min)*0.05*np.array((-1,1))+np.array((y_min,y_max))
        self.ax.set_ylim(y_range)
        self.canvas.draw()

class Frame_1_graph_Neon(Frame_1_graph):
    

    
    def __init__(self, model):
        super().__init__(model)


        self.neon_line_ADD_ref_list = []
    

            
    def neon_lines_plot(self, data):
        
        wavelenghts = data[:,0]
        intensities = data[:,1]
        
        self.Neon_plot_ref = []
        self.Neon_text_ref = []
        
        y_pos = (intensities.max()+intensities.min())/2


        
        for i in range(0,len(wavelenghts)):

            self.Neon_plot_ref.append(self.ax.axvline(wavelenghts[i], color = 'orange', ls = '--'))
            if (i%2) == 0: 
                self.Neon_text_ref.append(self.ax.text(wavelenghts[i], intensities.max()-y_pos*2/3, f'{wavelenghts[i]:.2f}', fontdict=None, rotation = 'vertical'))
            else:
                self.Neon_text_ref.append(self.ax.text(wavelenghts[i], y_pos, f'{wavelenghts[i]:.2f}', fontdict=None, rotation = 'vertical'))
        # access legend objects automatically created from data
        handles, labels = self.ax.get_legend_handles_labels()
        line = Line2D([0], [0], label='Neon Lines', color='orange')
        handles.extend([line])

        leg = self.ax.legend(handles=handles)
        leg.set_draggable(True)
    
    def Rescale_x(self, value):
        
        if value:
            x_min = min(self.model.peaks_data_x.min(), 0.99*self.model.Neon_lines[:,0].min())
            x_max = max(self.model.peaks_data_x.max(), 1.01*self.model.Neon_lines[:,0].max())
        else:
            x_min = 0.99*self.model.Neon_lines[:,0].min()
            x_max = 1.01*self.model.Neon_lines[:,0].max()
        x_range = (x_max -x_min)*0.05*np.array((-1,1))+np.array((x_min,x_max))
        self.ax.set_xlim(x_range)
        if self.debug: print('Rescale x')
        
    def plot_simple_calib(self, value):
        if self.debug : 
            print(f'Plot simple: {value}')
            print(self.plot_simple_calib_ref)
        if value:
            try:
                self.plot_simple_calib_ref.remove()
            except:
                pass
            x = self.model.peaks_data_x_simple_calib
            if self.debug : print(x.min(), x.max())
            y_min = self.model.peaks_data_y.min()
            y_max = self.model.peaks_data_y.max()
            y = (self.model.peaks_data_y - y_min) / (y_max - y_min) *self.model.Neon_lines[:,1].max() 
            self.plot_simple_calib_ref, = self.ax.plot(x, y, color = 'blue')
        else:
            try:
                self.plot_simple_calib_ref.remove()
            except:
                pass
            #self.Rescale_x(value)
        # access legend objects automatically created from data
        handles, labels = self.ax.get_legend_handles_labels()
        line = Line2D([0], [0], label='Simple Calib', color='blue')
        handles.extend([line])

        leg = self.ax.legend(handles=handles)
        leg.set_draggable(True)
        # self.autoScaleY()
        # self.navigationToolbar.update()
        self.canvas.draw()
     
    def autoScaleXY(self):
      self.ax.relim()
      self.ax.autoscale()
          
    def autoScaleY(self):
      self.ax.relim()
      self.ax.autoscale(axis='y')
      #self.canvas.draw()
      
    def neon_lines_plot_int(self, data):
        
        wavelenghts = data[:,0]
        intensities = data[:,1]
        
        self.Neon_plot_ref = []
        self.Neon_text_ref = []
        
        #y_pos = (intensities.max()+intensities.min())/2


        
        for i in range(0,len(wavelenghts)):
            line_x = (wavelenghts[i],wavelenghts[i])
            line_y = (0, intensities[i])
            self.Neon_plot_ref.append(self.ax.plot(line_x, line_y, color = 'orange', linewidth=3))
            y_pos = intensities[i]
            if (i%2) == 0: 
                self.Neon_text_ref.append(self.ax.text(wavelenghts[i]+1, y_pos*2/3, f'{wavelenghts[i]:.2f}', fontdict=None, rotation = 'vertical'))
            else:
                self.Neon_text_ref.append(self.ax.text(wavelenghts[i]+1, y_pos, f'{wavelenghts[i]:.2f}', fontdict=None, rotation = 'vertical'))
        
        # access legend objects automatically created from data
        handles, labels = self.ax.get_legend_handles_labels()
        line = Line2D([0], [0], label='Neon Lines', color='orange')
        handles.extend([line])

        leg = self.ax.legend(handles=handles)
        leg.set_draggable(True)
    
    def plot_neon_X(self, x):
        if self.debug: print('\nplot_neon_X\n')
        x, y = self.model.nearest_neon(x)
        
        if self.debug: print(x,y)
        try:
            self.neon_line_X_ref.remove()
        except:
            pass
        self.neon_line_X_ref = self.ax.scatter(x, y, s = 300, marker = 'x', color = 'black', linewidths = 4, zorder=3)
        #self.ax.scatter(x, y, s = 300, marker = 'o', color = 'red', facecolors='none')
        self.canvas.draw()
    
    def plot_neon_ADD(self, x):
        if self.debug: print('\nplot_neon_O\n')
        x, y = self.model.nearest_neon(x)
        self.neon_line_ADD_ref_list.append(self.ax.plot(x, y, markersize = 12, marker = 'o', color = 'red', zorder=3))
        self.canvas.draw()
    
    def plot_neon_ADD_toggle(self, indice, visible):
        if self.debug: print('\plot_neon_O_allO\ntoggle data checkbox\n')
        point = self.neon_line_ADD_ref_list[indice]
        if visible:
            self.ax.add_line(point[0])
        else:
            point[0].remove()
        self.canvas.draw()
    
    def plot_neon_RESET(self):
        for point in self.neon_line_ADD_ref_list:
            try:
                point[0].remove()
            except:
                pass
            try:
                del point[0]
            except:
                pass
        self.canvas.draw() 
        self.neon_line_ADD_ref_list = []
        
    def plot_left_neon_line(self):
        x = self.model.Neon_Left_reference
        x, y = self.model.nearest_neon(x)
        if self.debug: print(x,y)
        try:
            self.left_neon_line_ref.remove()
        except:
            pass
        self.left_neon_line_ref = self.ax.scatter(x, y, s = 300, marker = 'x', color = 'black', linewidths = 4)
        #self.ax.scatter(x, y, s = 300, marker = 'o', color = 'red', facecolors='none')
        self.canvas.draw()
    
    def plot_right_neon_line(self):
        x = self.model.Neon_Right_reference
        x, y = self.model.nearest_neon(x)
        if self.debug: print(x,y)
        try:
            self.right_neon_line_ref.remove()
        except:
            pass
        self.right_neon_line_ref = self.ax.scatter(x, y, s = 300, marker = 'x', color = 'black', linewidths = 4)
        #self.ax.scatter(x, y, s = 300, marker = 'o', color = 'red', facecolors='none')
        self.canvas.draw()
        
    def neon_lines_remove(self, data):
        
        [i.remove() for i in self.Neon_plot_ref]
        [i.remove() for i in self.Neon_text_ref]
        leg = self.ax.legend()
        leg.set_draggable(True)

class Frame_1_graph_Peaks(Frame_1_graph):
    
    
    
    def __init__(self, model):
        super().__init__(model)

        
        self.peak_line_ADD_ref_list = []
        
    
        


    def plot_left_peak_line(self):
        i_x = self.model.Peaks_Left_reference
        x = self.model.peaks_data_x[i_x]
        try:
            self.left_peak_line_ref.remove()
        except:
            pass
        self.left_peak_line_ref = self.ax.axvline(x, ls = '--', color = 'red', linewidth = 4)
        self.canvas.draw()
    
    def plot_right_peak_line(self):
        i_x = self.model.Peaks_Right_reference
        x = self.model.peaks_data_x[i_x]
        try:
            self.right_neon_line_ref.remove()
        except:
            pass
        self.right_neon_line_ref = self.ax.axvline(x, ls = '--', color = 'red', linewidth = 4)
        self.canvas.draw()
    
    def plot_click(self, value):
                
        try:
            self.plot_click_ref.remove()
        except:
            pass
        self.plot_click_ref = self.ax.axvline(value, color = 'black', ls = '--')
        
        # access legend objects automatically created from data
        handles, labels = self.ax.get_legend_handles_labels()
        line = Line2D([0], [0], label='Left Click', color='black', ls = '--')
        handles.extend([line])

        leg = self.ax.legend(handles=handles)
        leg.set_draggable(True)
        self.canvas.draw()
    
    def plot_click_fit(self, fit_x, fit_y):
                
        self.plot_click_fit_cls()
        self.plot_click_fit_ref_1 = self.ax.axvline(fit_x[0], color = 'blue', ls = '--', lw = 1)
        self.plot_click_fit_ref_2 = self.ax.axvline(fit_x[-1], color = 'blue', ls = '--', lw = 1)
        self.plot_click_fit_ref_3, = self.ax.plot(fit_x, fit_y, color = 'red', ls = '--', lw = 3)
        
        self.canvas.draw()
        
    def plot_click_fit_cls(self):
        try:
            self.plot_click_fit_ref_1.remove()
            self.plot_click_fit_ref_2.remove()
            self.plot_click_fit_ref_3.remove()
            self.canvas.draw()
        except:
            pass
    
    def plot_peak_ADD(self, value):
        self.peak_line_ADD_ref_list.append(self.ax.axvline(value, color = 'red', ls = '--', lw = '4'))
        self.canvas.draw()
    
    def plot_peak_ADD_toggle(self, indice, visible):
        if self.debug: print('\plot_peak_O_allO\ntoggle data checkbox\n')
        point = self.peak_line_ADD_ref_list[indice]
        if visible:
            self.ax.add_line(point)
        else:
            point.remove()
        self.canvas.draw()
        
    
    def plot_peak_RESET(self):
        for point in self.peak_line_ADD_ref_list:
            try:
                point.remove()
            except:
                pass
            try:
                del point
            except:
                pass
        self.canvas.draw() 
        self.peak_line_ADD_ref_list = []
        
    def Rescale_x(self):
        x_min = self.model.peaks_data_x.min()
        x_max = self.model.peaks_data_x.max()
        x_range = (x_max -x_min)*0.05*np.array((-1,1))+np.array((x_min,x_max))
        self.ax.set_xlim(x_range)
        if self.debug: print('Rescale x')
        
    
class Frame_2_graph_h(QtWidgets.QFrame):
    def __init__(self, model):
        super().__init__()
        self.model = model
        #self.setStyleSheet("border: 20px solid red")
        
        layout = QtWidgets.QHBoxLayout()
        self.Fig_A = Frame_1_graph_Neon(model)
        self.Fig_B = Frame_1_graph_Peaks(model)
        
        layout.addWidget(self.Fig_A)
        layout.addWidget(self.Fig_B)
        self.setLayout(layout)
        
class Data_Fine_Calib(QtWidgets.QFrame):
    def __init__(self, model):
        super().__init__()
        self.model = model

        button_1 = QtWidgets.QPushButton("Button 1")
        button_2 = QtWidgets.QPushButton("Button 2")
        button_3 = QtWidgets.QPushButton("Fill Table")
        
        button_1.clicked.connect(self.print_time)
        
        button_2_clicked = QtCore.pyqtSignal(str)

        
        button_2.clicked.connect(self.onclick_2)
        button_3.clicked.connect(self.onclick_3)
        
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(button_1)
        layout.addWidget(button_2)
        layout.addWidget(button_3)
        
        self.setLayout(layout)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Fixed,
            QtWidgets.QSizePolicy.Fixed)
        
    def onclick_2(self):
        print('onclick_2')

        
    def onclick_3(self):
        print('onclick_3')
        
    def print_time(self, event = None, Message = 'Now = '):
        now = datetime.now()
        current_time = now.strftime("%A %d %B %Y %H:%M:%S")
        print(Message + current_time)

class Fig_Commands(QtWidgets.QFrame):
    def __init__(self, model):
        super().__init__()
        self.model = model

        button_1 = QtWidgets.QPushButton("Button 1")
        button_2 = QtWidgets.QPushButton("Button 2")
        button_3 = QtWidgets.QPushButton("Fill Table")
        
        button_1.clicked.connect(self.print_time)
        
        button_2_clicked = QtCore.pyqtSignal(str)

        
        button_2.clicked.connect(self.onclick_2)
        button_3.clicked.connect(self.onclick_3)
        
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(button_1)
        layout.addWidget(button_2)
        layout.addWidget(button_3)
        
        
        self.setLayout(layout)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Fixed,
            QtWidgets.QSizePolicy.Fixed)
        
    def onclick_2(self):
        print('onclick_2')

        
    def onclick_3(self):
        print('onclick_3')
        
    def print_time(self, event = None, Message = 'Now = '):
        now = datetime.now()
        current_time = now.strftime("%A %d %B %Y %H:%M:%S")
        print(Message + current_time)   
        
        


class Fine_calib_Commands(QtWidgets.QFrame):
    
    #signal_checkbox_show_simple_calib = QtCore.pyqtSignal(bool)
    
    def __init__(self, model):
        super().__init__()
        
        self.model = model
        self.max_width = 250
        self.table = Data_Table_Fine_Calib(model)
        
        
        #Commanda
        self.button_calc_fine_calib = QtWidgets.QPushButton("Fine Calib")
        self.label_delta = QtWidgets.QLabel(self)
        self.label_delta.setText('Non so ancora')
        
        self.entry_delta = QtWidgets.QLineEdit(self, placeholderText=f'{str(self.model.delta)}',
        clearButtonEnabled=True)
        #self.entry_1.setText('NaN')
        self.entry_delta.returnPressed.connect(self.change_delta) 
        #returnPressed() https://doc.qt.io/qt-6/qlineedit.html
        #editingFinished
        
        #Layout Commands
        Widget_Commands = QtWidgets.QWidget()
        Widget_Commands.setMaximumWidth(self.max_width)
        Widget_Commands.setObjectName('3_1_1')
        Widget_Commands.setStyleSheet("#3_1_1 {border: 2px solid green; border-radius: 10px;}")
        
        layout_Commands = QtWidgets.QGridLayout(Widget_Commands)
        
        layout_Commands.addWidget(self.label_delta, 1, 1)
        layout_Commands.addWidget(self.entry_delta, 1, 2)
        layout_Commands.addWidget(self.button_calc_fine_calib, 2, 1)

        
        #Layout Table
        Widget_Table = QtWidgets.QWidget()
        Widget_Table.setMaximumWidth(self.max_width)
        Widget_Table.setObjectName('Table')
        Widget_Table.setStyleSheet("#Table {border: 2px solid blue; border-radius: 10px;}")
        
        layout_Table = QtWidgets.QVBoxLayout(Widget_Table)
        
        layout_Table.addWidget(self.table)
        
        
        
        #Final layout
        
        layout_left = QtWidgets.QVBoxLayout()

        layout_left.addWidget(Widget_Commands)
        layout_left.addWidget(Widget_Table)

        #self
        self.setLayout(layout_left)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Fixed,
            QtWidgets.QSizePolicy.Fixed)
    
    def change_delta(self):
        self.print_time()
        
        try :
            text = self.entry_delta.text()
            self.model.delta = float(text)
            self.model.statusbar_message('delta = ' + text)
        
        except Exception as e:
            self.model.error_box(e)
            self.model.statusbar_message('invalid value, delta =' + str(self.model.delta))
    
    def print_time(self, event = None, Message = 'Now = '):
        now = datetime.now()
        current_time = now.strftime("%A %d %B %Y %H:%M:%S")
        print(Message + current_time) 
    
    
class Fig_2_Commands(QtWidgets.QFrame):
    
    #signal_checkbox_show_simple_calib = QtCore.pyqtSignal(bool)
    
    def __init__(self, model):
        super().__init__()
        
        self.model = model
        self.max_width = 200
        #Top left
        
        
        
        self.checkbox_fit_on_click = QtWidgets.QCheckBox("Fit on click") 
        self.checkbox_fit_on_click.setChecked(True)
        
        
        self.label_delta = QtWidgets.QLabel(self)
        self.label_delta.setText('Delta (pixel)')
        
        self.entry_delta = QtWidgets.QLineEdit(self, placeholderText=f'{str(self.model.delta)}',
        clearButtonEnabled=True)
        self.entry_delta.returnPressed.connect(self.change_delta) 
        
        self.button_ADD = QtWidgets.QPushButton("ADD")
        #self.button_left_neon_line.clicked.connect(self.onclick_button_left_neon)
        #self.button_DELETE = QtWidgets.QPushButton("DELETE")
        #self.entry_DELETE = QtWidgets.QLineEdit("NaN")
        self.button_RESET = QtWidgets.QPushButton("RESET")
        

        
        #Table
        self.table_simple_fit = Data_Table_Points(model)
        
        
        #Calcul
        self.button_calc_simple_calib = QtWidgets.QPushButton("Simple Calib")
        #self.button_calc_simple_calib.clicked.connect(self.model.button_calc_simple_calib)
        self.checkbox_show_simple_calib = QtWidgets.QCheckBox("Show") 
        self.checkbox_show_simple_calib.setChecked(False)
        
        #Fit Output
        self.label_fit_output = QtWidgets.QLabel()
        self.label_fit_output.setText('Fit results')
        self.label_fit_output.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.label_fit_output.setMaximumWidth(self.max_width)
        
        #Selection
        
        self.sel_button_accept = QtWidgets.QPushButton("Accept")
        self.sel_button_cancel = QtWidgets.QPushButton("Cancel")
        
        entry_1 = QtWidgets.QLineEdit()
        entry_1.setText('NaN')
        
        Widget_Neon_lines = QtWidgets.QWidget()
        Widget_Neon_lines.setMaximumWidth(self.max_width)
        Widget_Neon_lines.setObjectName('3_1_1')
        Widget_Neon_lines.setStyleSheet("#3_1_1 {border: 2px solid green; border-radius: 10px;}")
        
        layout_Neon_lines = QtWidgets.QGridLayout(Widget_Neon_lines)
        
        layout_Neon_lines.addWidget(self.checkbox_fit_on_click, 1, 1)
        layout_Neon_lines.addWidget(self.label_delta, 2, 1)
        layout_Neon_lines.addWidget(self.entry_delta, 2, 2)
        layout_Neon_lines.addWidget(self.button_ADD, 3, 1)
        #layout_Neon_lines.addWidget(self.button_DELETE, 2, 1)
        #layout_Neon_lines.addWidget(self.entry_DELETE, 2, 2)
        layout_Neon_lines.addWidget(self.button_RESET, 4, 1)
        #layout.addWidget(self.button_1, 3, 1)
        
    
        
        
        
        
        Widget_Calc = QtWidgets.QWidget()
        Widget_Calc.setMaximumWidth(self.max_width)
        Widget_Calc.setObjectName('3_1_3')
        Widget_Calc.setStyleSheet("#3_1_3 {border: 2px solid green; border-radius: 10px;}")
        
        layout_Calc = QtWidgets.QGridLayout(Widget_Calc)
        
        layout_Calc.addWidget(self.button_calc_simple_calib, 4, 1)
        layout_Calc.addWidget(self.checkbox_show_simple_calib, 4, 2)
        
        Widget_Table = QtWidgets.QWidget()
        Widget_Table.setMaximumWidth(self.max_width)
        Widget_Table.setObjectName('Table')
        Widget_Table.setStyleSheet("#Table {border: 2px solid blue; border-radius: 10px;}")
        
        layout_Table = QtWidgets.QVBoxLayout(Widget_Table)
        
        layout_Table.addWidget(self.table_simple_fit)

        Widget_Output = QtWidgets.QWidget()
        Widget_Output.setMaximumWidth(self.max_width)
        Widget_Output.setObjectName('Out')
        Widget_Output.setStyleSheet("#Out {border: 2px solid green; border-radius: 10px;}")
        
        layout_Output = QtWidgets.QVBoxLayout(Widget_Output)
        
        layout_Output.addWidget(self.label_fit_output)
        
        #Sel layout
        
        Widget_sel = QtWidgets.QWidget()
        Widget_sel.setMaximumWidth(self.max_width)
        Widget_sel.setObjectName('3_1_5')
        Widget_sel.setStyleSheet("#3_1_5 {border: 2px solid red; border-radius: 10px;}")
        
        layout_sel_lines = QtWidgets.QGridLayout(Widget_sel)
        
        layout_sel_lines.addWidget(self.sel_button_accept, 1, 1)
        layout_sel_lines.addWidget(self.sel_button_cancel, 2, 1)

        #Final layout
        
        layout_left = QtWidgets.QVBoxLayout()

        layout_left.addWidget(Widget_Neon_lines)
        layout_left.addWidget(Widget_Table)
        layout_left.addWidget(Widget_Calc)
        layout_left.addWidget(Widget_Output)
        layout_left.addWidget(Widget_sel)
        
        #self
        
        
        self.setLayout(layout_left)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Fixed,
            QtWidgets.QSizePolicy.Fixed)
    
    # def show_simple_calib_toggle(self):
    #     self.signal_checkbox_show_simple_calib.emit(self.checkbox_show_simple_calib.isChecked())
    
    # def onclick_button_left_neon(self):
    #     text = f'{self.model.Last_Neon_clicked:.2f}'
    #     self.label_left_neon_line.setText(text)
    #     self.model.Neon_Left_reference = self.model.Last_Neon_clicked
    
    # def onclick_button_right_neon(self):
    #     text = f'{self.model.Last_Neon_clicked:.2f}'
    #     self.label_right_neon_line.setText(text)
    #     self.model.Neon_Right_reference = self.model.Last_Neon_clicked
    
    # def onclick_button_left_peaks(self):
    #     text = f'{self.model.Last_peaks_pixel_clicked}'
    #     self.label_left_neon_peak.setText(text)
    #     self.model.Peaks_Left_reference = self.model.Last_peaks_pixel_clicked
    
    # def onclick_button_right_peaks(self):
    #     text = f'{self.model.Last_peaks_pixel_clicked}'
    #     self.label_right_neon_peak.setText(text)
    #     self.model.Peaks_Right_reference = self.model.Last_peaks_pixel_clicked
    
    def change_delta(self):
        self.print_time()
        
        try :
            text = self.entry_delta.text()
            self.model.delta = int(text)
            self.model.statusbar_message('delta = ' + str(self.model.delta))
            self.entry_delta.setPlaceholderText(text)
            print(text)

        
        except Exception as e:
            self.model.error_box(e)
            self.model.statusbar_message('invalid value, delta =' + str(self.model.delta))
            
    def toggle_selection(self):
        cbutton = self.sender()
        side = cbutton.side
        status = cbutton.isChecked()
        if status:
            if side == "Left":
                self.selct_2.setChecked(False)
            else:
                self.selct_1.setChecked(False)

        
    def onclick_3(self):
        print('onclick_3')
        
    def print_time(self, event = None, Message = 'Now = '):
        now = datetime.now()
        current_time = now.strftime("%A %d %B %Y %H:%M:%S")
        print(Message + current_time) 

    
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet("""
                      * {
                          font-size: 15px;
                    }
                      """)
    from RC_Model_11 import my_model
    model = my_model()
    #window = Frame_1_graph(model)
    window = Fig_2_Commands(model)
    #window = Fine_calib_Commands(model)
    #window= Data_Table_Points(model)
    #window = Frame_2_graph_h(model)
    window.show()
    sys.exit(app.exec())