# -*- coding: utf-8 -*-
"""

Title: Rubycond_CB: tool for calibrating the wavelength of the spectrometer

This file is part of Rubycond: Pressure by Ruby Luminescence (PRL) software to determine pressure in diamond anvil cell experiments.

Version 0.2.0
Release 260301

Author:

Yiuri Garino
    yiuri.garino@cnrs.fr

Copyright (c) 2023-2026 Yiuri Garino

Download: 
    https://github.com/CelluleProjet/Rubycond_calc

License: GPLv3

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

"""

def reset():
    import sys
    
    if hasattr(sys, 'ps1'):
        
        #clean Console and Memory
        from IPython import get_ipython
        get_ipython().run_line_magic('clear','/')
        get_ipython().run_line_magic('reset','-sf')
        print("Running interactively")
        print()
        terminal = False
    else:
        print("Running in terminal")
        print()
        terminal = True

if __name__ == '__main__':
    reset()

import configparser as cp
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import os
from datetime import datetime
from lmfit.models import LinearModel, GaussianModel, PolynomialModel
from PyQt5 import QtWidgets, QtCore, QtGui
from scipy.special import wofz
from scipy.interpolate import Akima1DInterpolator
from pathlib import Path

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

class my_model():
    def __init__(self, debug = False):
        self.debug = debug
        self.version = 'RC_Model_11.py'
        if self.debug: print('\nModel\n')
        try:
            #file_NEON = Path("Neon_Astrosurf.csv")
            file_NEON = Path("Neon_PI.csv")
            path_NEON = Path(__file__).parent.resolve() / file_NEON
        except:
            path_NEON = file_NEON

            
        self.Neon_lines = np.loadtxt(path_NEON, delimiter=',')
        self.peaks_data_x = np.zeros((2,2)) #Data from open file
        self.peaks_data_y = np.zeros((2,2)) #Data from open file
        self.peaks_data_x_simple_calib = np.zeros((2,2))
        
        self.fit_delta_pixel = .6
        
        self.Last_peaks_pixel_clicked = 0
    
        
        self.delta = 20
        self.calib_cn = [0,0,0,0] #max poly degree = 3
        
        #
        self.statusbar_message_ref = [print] #List of messages method (print, label, statusbar, etc)
    
    def statusbar_message_add(self, method):
        #print(method)
        self.statusbar_message_ref.append(method)
        
    def nearest_neon(self, value):
        if value is not None:
            i = abs(self.Neon_lines[:,0]-value).argmin()
            data = self.Neon_lines[i]
            #print(self.Neon_lines)
            #print(abs(self.Neon_lines-value))
            if self.debug :
                print(f'input {i}: {value}')
                print(f'output : {data}')
        else:
            data = 0
        return data
    
    def peaks_data_pixel(self, value):
        if value is not None:
            data = abs(self.peaks_data_x-value).argmin()
            
            
            #print(abs(self.Neon_lines-value))
            if self.debug :
                print(self.peaks_data_x)
                print(f'input : {value}')
                print(f'output : {data}')
        else:
            data = 0
        return data

    def button_calc_simple_calib(self):
        y1 = self.Neon_Left_reference
        y2 = self.Neon_Right_reference
        x1 = self.Peaks_Left_reference
        x2 = self.Peaks_Right_reference
        s = (y2 - y1)/(x2 - x1)
        i = y1 - s*x1
        size = len(self.peaks_data_x)
        pixels = np.arange(0,size,1)
        if self.debug :
            print(f'slope : {s}')
            print(f'intercept : {i}')
        self.peaks_data_x_simple_calib = i + s*pixels
    
    def format_fit_results(self, degree, res):
        message = 'Fit Output\n'
        message+= '\n'
        # message+= 'Wavelengths (nm) = c0 + c1 * pixels + c2 * pixels\u00B2 + c3 * pixels\u00B3\n'
        # message+= '\n\n'
        for i in range(degree+1):
            
            message+= f'c{i} = ' 
            message+= f"{res.params[f'line_c{i}'].value:.5e}"
            message+= '\n'
            self.calib_cn[i] = res.params[f'line_c{i}'].value
        for j in range(3 - degree):
            message+= f'c{j + degree +1} = 0'
            message+= '\n'
            self.calib_cn[j + degree +1] = 0
        print(message)
        print(self.calib_cn)
        self.print_message_output = message
        
    def calib_poly_3(self, data_x, data_y):
        degree = min(len(data_x)-1, 3)
        model = PolynomialModel(degree=degree, prefix='line_')
        pars = model.guess(data_y, data_x)
        res = model.fit(data_y, pars, x = data_x)
        if self.debug: pars.pretty_print()
        #if self.debug: res.fit_report()#TODO restore in next version
        print(res.fit_report()) #TODO cut in next version
        size = len(self.peaks_data_x)
        pixels = np.arange(0,size,1)
        
        self.peaks_data_x_simple_calib = model.eval(res.params, x = pixels)
        
        #prepare message to be used in layout_Output
        self.format_fit_results(degree, res)
    
    def fit_peak_range(self):
        try:
            center = self.Last_peaks_pixel_clicked
            delta = self.delta
            data_x_graph = self.peaks_data_x[center - delta: center + delta + 1]
            data_x_pixel = np.linspace(center - delta, center + delta, delta*2+1)
            data_y = self.peaks_data_y[center - delta: center + delta + 1]
            data_x, data_y, init, fit_x, fit_y, res = self.fit_peak(data_x_pixel, data_y)
            
            spl = Akima1DInterpolator(data_x_pixel, data_x_graph)
    
            data_x = spl(data_x)
            fit_x = spl(fit_x)
            center_pixel = res.params['center'].value
            center_graph = spl(center_pixel)
            return data_x, data_y, init, fit_x, fit_y, center_graph, center_pixel
        except:
            return None
        
    def fit_peak(self, data_x, data_y):
        model = LinearModel() + GaussianModel()
        pars = model.make_params()
        
        y1 = data_y[0]
        y2 = data_y[-1]
        x1 = data_x[0]
        x2 = data_x[-1]
        slope = (y2 - y1)/(x2 - x1)
        intercept = y1 - slope*x1
        pars['slope'].value = slope
        pars['intercept'].value = intercept
        center = data_x[data_y.argmax()]
        pars['center'].value = center
        sigma = 5 * abs(data_x[1] - data_x[0])
        pars['sigma'].value = sigma
        height = data_y.max() - (intercept + slope * center)
        pars['amplitude'].value = self.Gauss_amplitude(height, sigma)
        
        init = model.eval(pars, x = data_x)
        if self.debug: pars.pretty_print()
        res = model.fit(data_y, pars, x = data_x)
        
        if self.debug: print(res.fit_report())
        size = len(self.peaks_data_x)
        fit_x = np.linspace(data_x.min(),data_x.max(),500)
        fit_y = model.eval(res.params, x = fit_x)
        
        return data_x, data_y, init, fit_x, fit_y, res
    
    def x_2_nm(self, x, i, c1, c2, c3):
        return i +c1*x + c2*x**2 +c3*x**3 

    def Voigt(self, x, c0, c1, c2, c3, amplitude, center, sigma, gamma):
        """
        Return the Voigt line shape at x with Lorentzian component HWHM gamma
        and Gaussian component sigma.
        sigma = HWHM / sqrt(2 * log(2))

        """
        nm = c0 +c1*x + c2*x**2 +c3*x**3
        return amplitude*np.real(wofz((nm - center + 1j*gamma)/sigma/np.sqrt(2))) / sigma /np.sqrt(2*np.pi)

    def Voigt_amplitude(self, height, gamma, sigma):
        
        return height*(sigma*np.sqrt(2*np.pi))/wofz((1j*gamma)/(sigma*np.sqrt(2))).real

    def Gauss(self, x, c0, c1, c2, c3, amplitude, center, sigma):
        #x pixel
        nm = c0 +c1*x + c2*x**2 +c3*x**3
        cm = 1e7/nm
        center_cm = 1e7/center
        return amplitude / sigma / np.sqrt(2*np.pi) * np.exp( - (cm -center_cm) **2 / 2 / sigma**2 )

    def Gauss_amplitude(self, height, sigma):
        return sigma * np.sqrt(2*np.pi) * height
    
    #
    def statusbar_message(self, message):
        now = datetime.now()
        text = now.strftime("%H:%M:%S : ") + message
        for method in self.statusbar_message_ref:
            method(text)

    def error_box(self, error):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Critical)
        msgBox.setWindowTitle("Script Error")
        msgBox.setText(str(error))
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec()
'''
#%%
data_x = np.array((300,400,500,600))
data_y = np.array((300,400,500,600))
model = PolynomialModel(degree=2, prefix='line_')
pars = model.guess(data_y, data_x)
res = model.fit(data_y, pars, x = data_x)
pars.pretty_print()
res.params.pretty_print()
res.fit_report()

Fit = self.model.eval(self.out.params, x = x_fit_lmfit)
self.center_pk = self.out.params['pk_center'].value
self.out = self.model.fit(y_fit, self.pars, x = x, max_nfev = self.Fit_iter_lim.get()) 
comps = self.out.eval_components(x = x_fit_lmfit)
'''