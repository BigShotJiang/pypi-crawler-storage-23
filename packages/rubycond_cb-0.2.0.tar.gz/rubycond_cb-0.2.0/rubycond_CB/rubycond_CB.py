# -*- coding: utf-8 -*-
"""

Title: Rubycond_CB: tool for calibrating the wavelength of the spectrometer

This file is part of Rubycond: Pressure by Ruby Luminescence (PRL) software to determine pressure in diamond anvil cell experiments.

Version 0.2.0
Release 260301

Author:

Yiuri Garino

Copyright (c) 2023-2026 Yiuri Garino

Download: 
    https://github.com/CelluleProjet/Rubycond_OF

Contacts:

Yiuri Garino
    yiuri.garino@cnrs.fr

Silvia Boccato
    silvia.boccato@cnrs.fr
    
License: GPLv3

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

"""

def reset():
    import sys
    
    if hasattr(sys, 'ps1'):
        
        #clean Console and Memory
        from IPython import get_ipython
        get_ipython().run_line_magic('clear','/')
        get_ipython().run_line_magic('reset','-sf')
        print("Running interactively")
        print()
    else:
        print("Running in terminal")
        print()

if __name__ == '__main__':
    reset()
    

import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

#https://stackoverflow.com/questions/16981921/relative-imports-in-python-3
import os, sys, platform
script = os.path.abspath(__file__)
script_dir = os.path.dirname(script)
sys.path.append(script_dir)



from rubycond_OF.rubycond_OF import open_file

from model.CB_Model import my_model
from view.CB_View import Data_Table, Fig_Commands, Frame_1_graph, Fig_2_Commands, Frame_2_graph_h, Fine_calib_Commands
from view.CB_about import about
        
from PyQt5 import QtWidgets, QtCore, QtGui

import traceback

class Tab_2(QtWidgets.QFrame):
    """
    Init Left = commands, Alignment on Top
    """
    def __init__(self, Left, Right, model):
        super().__init__()
        self.model = model
        self.debug = self.model.debug
        
        self.Left = Left(model)
        layout_Left = QtWidgets.QVBoxLayout()
        layout_Left.addWidget(self.Left)
        layout_Left.setAlignment(QtCore.Qt.AlignTop)
        
        self.Right = Right(model)
        layout_Right = QtWidgets.QVBoxLayout()
        layout_Right.addWidget(self.Right)
        
        
        layout_main = QtWidgets.QHBoxLayout()
        layout_main.addLayout(layout_Left)
        layout_main.addLayout(layout_Right)
        self.setLayout(layout_main)
        
class Tab_Fine_Calib(Tab_2):
    """
    Init Left = commands, Alignment on Top
    """
    def __init__(self, model):
        self.model = model
        self.Left = Fine_calib_Commands
        self.Right = Frame_1_graph
        super().__init__(self.Left, self.Right, model)
        

class Tab_Single(Tab_2):
    """
    Init Left = commands, Alignment on Top
    """
    def __init__(self, model):
        self.model = model
        super().__init__(Fig_Commands, Data_Table, model)
        
        

class Tab_Double(Tab_2):
    """
    Init Left = commands, Alignment on Top
    """
    def __init__(self, model):
        self.model = model
        
        self.Left = Fig_2_Commands
        self.Right = Frame_2_graph_h #Inside Fig_A on the left and Fig_B on the right
        super().__init__(self.Left, self.Right, model)
        
        
        #Click on Neon line figure
        self.Right.Fig_A.signal_fig_click_no_drag.connect(self.click_left_figure_no_drag)


        #Click on Peaks figure
        self.Right.Fig_B.signal_fig_click_no_drag.connect(self.click_right_figure_no_drag)
        
        #self.Left.signal_checkbox_show_simple_calib.connect(self.Right.Fig_B.plot_simple_calib)
        
        #self.Left.button_left_neon_line.connect(self.Right.Fig_A.plot_left_neon_line)
        #self.Left.button_right_neon_line.connect(self.Right.Fig_A.plot_right_neon_line)
        
        self.Left.button_ADD.clicked.connect(self.onclick_button_ADD)

        self.Left.checkbox_show_simple_calib.toggled.connect(self.show_simple_calib_toggle)
        self.Left.button_calc_simple_calib.clicked.connect(self.onclick_button_calc_simple_calib)
        self.Left.button_RESET.clicked.connect(self.onclick_button_RESET)
        
        
        self.Left.table_simple_fit.signal_table_simple_fit_checkbox_toggled.connect(self.Right.Fig_A.plot_neon_ADD_toggle)
        self.Left.table_simple_fit.signal_table_simple_fit_checkbox_toggled.connect(self.Right.Fig_B.plot_peak_ADD_toggle)
        
        self.Left.checkbox_fit_on_click.toggled.connect(self.Left_checkbox_fit_on_click_toggled)
    
    def Left_checkbox_fit_on_click_toggled(self):
        self.Right.Fig_B.plot_click_fit_cls()
        #self.onclick_button_RESET()
        
        
    def onclick_button_RESET(self):
        self.Right.Fig_A.plot_neon_RESET()
        self.Right.Fig_B.plot_peak_RESET()
        self.Left.table_simple_fit.table_RESET()
        state = self.Left.checkbox_show_simple_calib.isChecked()
        if state:
            #Force refresh
            self.Left.checkbox_show_simple_calib.setChecked(False)
        
    def onclick_button_ADD(self):
        try:
            self.Left.table_simple_fit.add_table_line()
            self.Right.Fig_A.plot_neon_ADD(self.model.Last_Neon_clicked)
            self.Right.Fig_B.plot_peak_ADD(self.model.ADD_line_ref)
            if self.debug:
                print('\nself.model.Last_peaks_pixel_clicked')
                print(self.model.Last_peaks_pixel_clicked)
                print('\n')
        except Exception as e:
            self.model.error_box(e)
    
    def error_box(self, title : str):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Critical)
        msgBox.setWindowTitle(str(title))
        msgBox.setText(traceback.format_exc())
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec()
    
    def error_message(self, title : str, error : str):
        msgBox = QtWidgets.QMessageBox()
        msgBox.setIcon(QtWidgets.QMessageBox.Critical)
        msgBox.setWindowTitle(title)
        msgBox.setText(error)
        msgBox.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msgBox.exec()
        
    def onclick_button_calc_simple_calib(self):
        if self.debug: print('\nonclick_button_calc_simple_calib\n')
        #mask = selected points
        mask = np.array(self.Left.table_simple_fit.table_checkbox_ref_checked)
        data_y = np.array(self.Left.table_simple_fit.table_checkbox_nm)
        data_x = np.array(self.Left.table_simple_fit.table_checkbox_pixel)
        
        if len(data_x)<2:
            self.error_message('Data Error','Minimum 2 selected points')
        else:
            #fit the selected points
            self.model.calib_poly_3(data_x[mask], data_y[mask])
            
            self.Left.checkbox_show_simple_calib.setEnabled(True)
            
            #Force refresh
            state = self.Left.checkbox_show_simple_calib.isChecked()
            if state:
                #Force refresh
                self.Left.checkbox_show_simple_calib.setChecked(False)
                self.Left.checkbox_show_simple_calib.setChecked(True)
            else:
                #Show Result
                self.Left.checkbox_show_simple_calib.setChecked(True)
            #self.show_simple_calib_toggle()
            
            #put results in Fit results
            self.Left.label_fit_output.setText(self.model.print_message_output)
        
    def show_simple_calib_toggle(self):
        if self.debug: print('\nshow_simple_calib_toggle\n')
        state = self.Left.checkbox_show_simple_calib.isChecked()
        #print(state)
        self.Right.Fig_A.plot_simple_calib(state)

    
    def click_right_figure_no_drag(self, event):
        if self.debug: print('click no drag right')
        
        button = event.button
        if self.debug:
            print('click')
            print(type(event))
            print(event)
            print(event.xdata)


        if (event.xdata != None):
            x = event.x
            y = event.y
            xdata = event.xdata
            ydata = event.ydata
            self.click = [button, x, y, xdata, ydata]
            self.model.Last_peaks_value_clicked = xdata
            self.model.Last_peaks_pixel_clicked = self.model.peaks_data_pixel(xdata)
            error = 0
            if self.Left.checkbox_fit_on_click.isChecked():
                autofit = self.model.fit_peak_range()
                if autofit is not None:
                    data_x, data_y, init, fit_x, fit_y, center_graph, center_pixel = autofit
                    self.Right.Fig_B.plot_click_fit(fit_x, fit_y)
                    self.model.ADD_line_ref = center_graph
                    text = f"{center_pixel:.2f}"
                else:
                    error = 1
                    self.model.error_box('Point selected too close to edge, not enough data to fit')
            else:
                text = f'{self.model.Last_peaks_pixel_clicked}'
                self.model.ADD_line_ref = event.xdata
            
            if not error:
                self.Right.Fig_B.plot_click(self.model.ADD_line_ref)
                self.Left.table_simple_fit.add_col_pixel(text)
            
            if self.debug: 
                print(f'button = {button}, x = {x}, y = {y}, xdata = {xdata}, ydata = {ydata}')
        else:
            if self.debug: print('Click out of graph')
    

        
    def click_left_figure_no_drag(self, event):
        if self.debug: print('click no drag left')
        button = event.button
        if self.debug:
            print('click')
            print(type(event))
            print(event)
            print(event.xdata)
            print(self.model.nearest_neon(event.xdata))

        if (event.xdata != None):
            x = event.x
            y = event.y
            xdata = event.xdata
            ydata = event.ydata
            self.click = [button, x, y, xdata, ydata]
            self.model.Last_Neon_clicked = self.model.nearest_neon(event.xdata)[0]
            text = f'{self.model.Last_Neon_clicked:.2f}'
            self.Left.table_simple_fit.add_col_nm(text)
            self.Right.Fig_A.plot_neon_X(self.model.Last_Neon_clicked)
            if self.debug: 
                print(f'button = {button}, x = {x}, y = {y}, xdata = {xdata}, ydata = {ydata}')
        else:
            if self.debug: print('Click out of graph')
   
class pop_up_simple(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        layout = QtWidgets.QVBoxLayout()
        self.label = QtWidgets.QLabel()
        self.label.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        layout.addWidget(self.label)
        self.setLayout(layout)

class calibrator(QtWidgets.QMainWindow):
    signal_update_calibration_pars = QtCore.pyqtSignal(list)
    
    def __init__(self, debug = False, data = None):
        super().__init__()
        self.setWindowTitle("QTabWidget Example")
        #self.resize(500, 500)
        self.debug = debug
        self.model = my_model(self.debug)
        
        self.version = 'RC_Controller_13.py'
        
        self.__name__ = 'Rubycond Calibrator'
        self.__version__ = '0.2.0' 
        self.__release__ = '260301'
        
        self.about = about(self.__name__, self.__version__, self.__release__)
        self.pop_up_info = pop_up_simple()
        
        SMALL_SIZE = 15
        MEDIUM_SIZE = 17
        BIGGER_SIZE = 19
        
        plt.rcParams["font.size"] = BIGGER_SIZE
        
        plt.rc('font', size=SMALL_SIZE)          # controls default text sizes
        plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
        plt.rc('xtick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
        plt.rc('ytick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
        plt.rc('legend', fontsize=SMALL_SIZE)    # legend fontsize
        plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title

        
        # self.Tab_Neon_Data =  Tab_2(Data_Commands, Data_Table)
        # self.Tab_Single =  Tab_2(Fig_Commands, Frame_1_graph)
        # self.Tab_Double =  Tab_2(Fig_2_Commands, Frame_2_graph_h)
        
        #self.Tab_Neon_Data =  Tab_Neon_Data(self.model)
        self.Tab_Fine =  Tab_Fine_Calib(self.model)
        self.Tab_Double =  Tab_Double(self.model)
        
        
        #self.fig = Frame_1_graph()
        
        tabs = QtWidgets.QTabWidget()
        #tabs.setTabPosition(QtWidgets.QTabWidget.West)
        #tabs.addTab(self.Tab_Neon_Data, "Neon Lines")
        tabs.addTab(self.Tab_Double, "Simple Calib")
        #tabs.addTab(self.Tab_Fine, "Fine Calib")
        
        #
        #self.Tab_Neon_Data.Right.setHorizontalHeaderLabels(['Wavelength', 'Intensity'])
        #self.Tab_Neon_Data.Right.set_numpy_2D(self.model.Neon_lines)
        self.Tab_Double.Right.Fig_A.neon_lines_plot_int(self.model.Neon_lines)
        
        
        #Signal Slot Connection
        
        self.open_file = open_file(model = self.model)
        self.open_file.commands.signal_selected_data_xy.connect(self.open_file_command_xy)
        self.Tab_Double.Left.sel_button_accept.clicked.connect(self.update_calibration_pars)
        self.Tab_Double.Left.sel_button_cancel.clicked.connect(self.quit_main)
        
        # self.open_file.commands.signal_selected_data.connect(self.Tab_Single.Right.plot_data)
        # self.open_file.commands.signal_selected_data.connect(self.Tab_Double.Right.Fig_B.plot_data)
        # self.open_file.commands.signal_selected_data.connect(self.data_to_model) #Data from Open File to Model
        # self.open_file.commands.signal_selected_data.connect(self.onclick_button_RESET)
        
        self.setCentralWidget(tabs)
        self.init_Actions()
        self.init_Menu()
        self.init_Statusbar()
        if data is not None:
            self.open_file_command(data[0], data[1]) #data sent from parent
        self.model.statusbar_message(f'Done init RC {__file__}')
        
        self.Tab_Double.Left.checkbox_show_simple_calib.setEnabled(False)
        
        #Shortcuts
        
        shortcut = QtGui.QKeySequence(QtCore.Qt.CTRL + QtCore.Qt.Key_I)
        shortcut = QtWidgets.QShortcut(shortcut, self)
        shortcut.activated.connect(self.script_info) 
    
    def open_about(self):
        self.about.show()
    
    def script_info(self):
        script = os.path.abspath(__file__)
        script_dir = os.path.dirname(script)
        script_name = os.path.basename(script)
        now = datetime.now()
        date = now.isoformat(sep = ' ', timespec = 'seconds') #example = '2024-03-27 18:04:46'
        
        print()
        print('_/‾\\'*20)
        print()
        print(date)
        print()
        print("File folder = " + script_dir)
        print("File name = " + script_name)
        print("Current working directory (AKA Called from ...) = " + os.getcwd())
        print("Python version = " + sys.version)
        print("Python folder = " + sys.executable)
        print()
        print('_/‾\\'*20)
        print()
        
        time = datetime.now().strftime("%d %B %Y %H:%M:%S")
        message = '\n'
        message+= f'Program name = {self.__name__}\n'
        message+= f'Version {self.__version__} | Release {self.__release__}\n'
        message+= '\n'
        message+= "Sys Info:\n"
        message+= '\n'
        message+= f"OS: {platform.system()} {platform.release()}\n"
        message+= f"Architecture: {platform.machine()}\n"
        message+= '\n'
        message+= 'Script Info:\n'
        message+= '\n'
        message+= f"File folder = {script_dir}\n"
        message+= f"File name = {script_name}\n"
        message+= f"Current working directory = {os.getcwd()}\n"
        message+= f"Python version = {sys.version}\n"
        message+= f"Python folder = {sys.executable}\n"
        message+= '\n'
        self.pop_up_info.setWindowTitle('Info ' + time)
        self.pop_up_info.label.setText(message)
        self.pop_up_info.show()
        
    def update_calibration_pars(self):
        self.signal_update_calibration_pars.emit(self.model.calib_cn)
        self.quit_main()
        
    def open_file_command_xy(self, data_x, data_y, filename):
        self.Tab_Double.onclick_button_RESET()
        self.Tab_Fine.Right.plot_data(data_x, data_y)
        self.Tab_Double.Right.Fig_B.plot_data(data_x, data_y)
        
        #Data from Open File to Model
        self.model.peaks_data_x = data_x
        self.model.peaks_data_y = data_y
        
        
    # def data_to_model(self, data):
    #     #Data from Open File to Model
    #     self.model.peaks_data_x = data[:,0]
    #     self.model.peaks_data_y = data[:,1]
        
    def init_Actions(self):
        #Menu Files Action Open

        self.action_Open_file = QtWidgets.QAction()
        self.action_Open_file.setText('Open File')
        self.action_Open_file.setShortcut('Ctrl+O')
        self.action_Open_file.triggered.connect(self.show_open_file)
        
        self.action_Quit = QtWidgets.QAction()
        self.action_Quit.setText('Quit')
        #self.action_Open_image.setShortcut('Ctrl+O')
        self.action_Quit.triggered.connect(self.quit_main)
        
        self.action_About = QtWidgets.QAction()
        self.action_About.setText('About')
        self.action_About.setShortcut('Ctrl+H')
        self.action_About.triggered.connect(self.open_about)
        
        
    def init_Menu(self):
        menu_Bar = QtWidgets.QMenuBar()
        menu_File = QtWidgets.QMenu("&File", menu_Bar)
        menu_File.addAction(self.action_Open_file)
        menu_File.addAction(self.action_Quit)
        
        menu_Edit = QtWidgets.QMenu('&Edit', menu_Bar)
        menu_Help = QtWidgets.QMenu('&Help', menu_Bar)
        menu_Help.addAction(self.action_About)
        
        menu_Bar.addMenu(menu_File)
        #menu_Bar.addMenu(menu_Edit)
        menu_Bar.addMenu(menu_Help)
        self.setMenuBar(menu_Bar)
    
    def init_Statusbar(self):
        self.statusbar = QtWidgets.QStatusBar()
        #self.statusbar.addPermanentWidget(QtWidgets.QLabel("Welcome !"))
        #self.statusbar.addWidget(QtWidgets.QLineEdit())
        self.setStatusBar(self.statusbar)
        #self.statusbar.showMessage('Init 2')
        self.model.statusbar_message_add(self.statusbar.showMessage)
    
    def show_open_file(self):
        
        self.open_file.show()
        
    def print_time(self, event = None, Message = 'Now = '):
        now = datetime.now()
        current_time = now.strftime("%A %d %B %Y %H:%M:%S")
        print(Message + current_time)
    
    def quit_main(self):
        print('Quitting...')
        self.close()

'''
def closeEvent(self, event):
        print "User has clicked the red x on the main window"
        event.accept()
'''      
def main():
    #Entry point in poetry pyproject.toml
    app = QtWidgets.QApplication(sys.argv)
    app.setStyleSheet("""
                      * {
                          font-size: 15px;
                    }
                      """)
    window = calibrator() 
    #window = Data_Commands()
    #window = Data_Table()
    #window = Data_Tab() 
    #window = Tab_2(Data_Commands,Data_Table)
    #window = Tab_2(Data_Commands,Frame_1_graph)
    #window = Tab_2(Data_Commands,Frame_2_graph_h)
    #window = Tab_Neon_Data()
    #window = Tab_Single()
    #window = Tab_Double(my_model())
    #window = Frame_1_graph()
    #window = Plot_tab()
    #window = Fine_calib_Commands(model = my_model())
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()