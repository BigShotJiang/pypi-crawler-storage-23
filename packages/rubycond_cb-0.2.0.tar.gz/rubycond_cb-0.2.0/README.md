# Rubycond_CB
Tool for calibrating the spectrometer wavelengths 
  
<img width="1282" height="702" alt="1_open_file" src="https://github.com/user-attachments/assets/3d744deb-cf81-4d27-aae1-8c685986c98d" />

# Manual
  
1) Select the Neon line on the left graph and the corresponding peak on the right graph.  
The program automatically performs a peak fit within the pixel window defined in Delta (pixels), default 20 pixels.

2) Add the pair of points using the **ADD** button.  The points used for calibration are indicated on both the graphs and the table on the left.  
<img width="1920" height="1032" alt="2_1_point" src="https://github.com/user-attachments/assets/7078a113-a26a-4ff4-9c1e-c06ab30deee6" />  
  
3) Repeat the operation, adding as many peaks as possible.  
<img width="1920" height="1032" alt="3_n_point" src="https://github.com/user-attachments/assets/d46ac124-a0f3-407e-87d8-41a6133e65b5" />  
  
4) Use the **Simple Calib** button to perform the calibration.  
The calibration result is displayed in the left graph, and the fit result is shown in the Fit Output window.
<img width="1920" height="1032" alt="4_output" src="https://github.com/user-attachments/assets/689a1baa-e4ec-4fb9-97c4-5956a9384e15" />  
  
5) Use the **Accept** button to send the calibration parameters to the main program  
# Install
Use pip to install the program **within a virtual environment (strongly recommended).**  
[Here's a short tutorial on installing a virtual environment.](https://github.com/CelluleProjet/Install/tree/main?tab=readme-ov-file#install-virtual-environment)
```bash
pip install rubycond_CB
```
# About
## Author

**Yiuri Garino**  

## Contacts

**Yiuri Garino**  
- yiuri.garino@cnrs.fr
   
**Silvia Boccato**
- silvia.boccato@cnrs.fr
  
<img src="https://github.com/CelluleProjet/Rubycond/assets/83216683/b728fe64-2752-4ecd-843b-09d335cf4f93" width="100" height="100">
<img src="https://github.com/CelluleProjet/Rubycond/assets/83216683/0a81ce1f-089f-49d8-ae65-d19af8078492" width="100" height="100">


[Cellule Projet](http://impmc.sorbonne-universite.fr/fr/plateformes-et-equipements/cellule-projet.html) @ [IMPMC](http://impmc.sorbonne-universite.fr/en/index.html)


## License
**Rubycond_CB**: Tool for calibrating the spectrometer wavelengths 


Copyright (c) 2022-2026 Yiuri Garino

**Rubycond_CB** is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program. If not, see <https://www.gnu.org/licenses/>.

## Release notes

Version 0.2.0 Release 260301: First release  
