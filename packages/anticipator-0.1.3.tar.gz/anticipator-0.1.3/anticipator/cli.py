import click
from anticipator.detection.scanner import scan as run_scan
from anticipator.integrations.monitor import print_summary


@click.group()
@click.version_option(version="0.1.0")
def main():
    """Anticipator — Runtime threat detection for multi-agent AI systems."""
    pass


@main.command()
@click.argument("message")
@click.option("--agent", default="agent_a", help="Agent ID")
@click.option("--source", default=None, help="Source agent ID")
def scan(message, agent, source):
    """Scan a message for threats."""
    result = run_scan(text=message, agent_id=agent, source_agent_id=source)
    if result["detected"]:
        sev = result["severity"].upper()
        click.echo(f"[ANTICIPATOR] ⚠ {sev} detected")
        click.echo(f"  Message : {message[:80]}")
        click.echo(f"  Severity: {result['severity']}")
    else:
        click.echo("✅ Clean — no threats detected")


@main.command()
@click.option("--graph", default=None, help="Filter by graph/pipeline name")
@click.option("--last", default=None, help="Time window e.g. 24h, 7d, 30d")
def monitor(graph, last):
    """Show persistent threat monitor from SQLite."""
    print_summary(graph=graph, last=last)


if __name__ == "__main__":
    main()