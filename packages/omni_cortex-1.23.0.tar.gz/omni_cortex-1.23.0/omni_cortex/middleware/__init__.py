"""Omni-Cortex v2 Middleware Layer.

Provides configuration management and middleware infrastructure
for Claude Code hooks (PreToolUse/PostToolUse).
"""

from .config import CacheConfig, MiddlewareConfig, load_middleware_config

__all__ = ["CacheConfig", "MiddlewareConfig", "load_middleware_config"]
