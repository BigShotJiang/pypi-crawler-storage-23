from .rtsp import *

__doc__ = rtsp.__doc__
if hasattr(rtsp, "__all__"):
    __all__ = rtsp.__all__