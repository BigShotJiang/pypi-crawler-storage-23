VERSION = "0.3.0"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
