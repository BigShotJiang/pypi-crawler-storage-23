"""允许通过 python -m hotel_search_mcp 运行"""
from hotel_search_mcp.server import main

main()
