# 酒店搜索 MCP Server

基于 MCP (Model Context Protocol) 的酒店搜索服务，整合高德地图和百度地图数据，提供酒店价格、评分、类型等信息。

## 功能特性

- ✅ 搜索周边酒店（基于高德地图 API）
- ✅ 获取酒店价格信息（来自百度地图）
- ✅ 显示酒店评分（高德+百度双评分）
- ✅ 展示酒店类型（星级、快捷、民宿等）
- ✅ 支持价格范围筛选
- ✅ 自动按距离排序
- ✅ 支持 stdio 和 SSE 两种运行模式

## 安装

### 使用 uv（推荐）

```bash
# 安装并运行（stdio 模式）
uvx hotel-search-mcp

# 或使用 uv tool
uv tool run hotel-search-mcp

```

### 使用 pip
# 安装基础版本
pip install hotel-search-mcp

# 安装完整版本（包含 SSE 支持）
pip install hotel-search-mcp[sse]


### 使用方法
1. Stdio 模式（用于 Cursor、Claude Desktop）
在 Cursor 中配置
编辑 .cursor/mcp.json 或全局配置：

```json
{
  "mcpServers": {
    "hotel-search": {
      "command": "uvx",
      "args": ["hotel-search-mcp"],
      "env": {
        "AMAP_API_KEY": "your_amap_api_key_here"
      }
    }
  }
}
```

在 Claude Desktop 中配置
编辑 ~/Library/Application Support/Claude/claude_desktop_config.json：

```json
{
  "mcpServers": {
    "hotel-search": {
      "command": "uvx",
      "args": ["hotel-search-mcp"],
      "env": {
        "AMAP_API_KEY": "your_amap_api_key_here"
      }
    }
  }
}
```

2. SSE 模式（用于百炼平台、Web 应用）
启动 SSE 服务器
```bash
# 设置环境变量
export AMAP_API_KEY="your_amap_api_key_here"
```

# 启动服务
hotel-search-mcp --mode sse --host 0.0.0.0 --port 8000
在阿里云百炼平台配置
部署服务到云服务器或函数计算
在百炼平台"MCP 广场"中创建自定义 MCP 服务
配置为 HTTP 模式，填写服务 URL：http://your-server:8000/sse
工具说明
search_hotels
搜索指定地点周边的酒店信息。

# 参数：
city (必填): 城市名称，如"杭州"、"上海"
address (必填): 具体地址或地标，如"西湖"、"外滩"
min_price (可选): 最低价格（元/晚）
max_price (可选): 最高价格（元/晚）
radius (可选): 搜索半径（米），默认 10000
max_results (可选): 返回结果数量，默认 20

# 示例：
```json
{
  "city": "杭州",
  "address": "西湖",
  "min_price": 300,
  "max_price": 500,
  "max_results": 10
}
```

返回结果：
```json
{
  "success": true,
  "搜索时间": "2024-01-20 10:30:00",
  "城市": "杭州",
  "地址": "西湖",
  "总数量": 45,
  "返回数量": 10,
  "酒店列表": [
    {
      "名称": "西湖国宾馆",
      "地址": "杭州市西湖区...",
      "距离": "500米",
      "电话": "0571-12345678",
      "高德评分": "4.8",
      "百度评分": "4.7",
      "参考价格": "¥450",
      "评论数": "1200条",
      "高德类型": "星级酒店",
      "百度类型": "五星级酒店",
      "坐标": "120.123,30.456"
    }
  ]
}
```

# 环境变量
AMAP_API_KEY: 高德地图 API Key（必需）

# 开发
bash
# 克隆仓库
git clone https://github.com/yourusername/hotel-search-mcp.git
cd hotel-search-mcp

# 安装开发依赖
pip install -e ".[sse,dev]"

# 运行测试
pytest

# 代码格式化
black src/
ruff check src/
许可证
MIT License

作者
Your Name - your.email@example.com


### 5. `LICENSE`

```text
MIT License

Copyright (c) 2024 Your Name

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

