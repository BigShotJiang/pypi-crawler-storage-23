#! /usr/bin/env bash

function bluer_ugv_ROS_gazebo_log() {
    bluer_ai_log "GZ_IP: $GZ_IP"
    bluer_ai_log "GZ_RELAY: $GZ_RELAY"
}
