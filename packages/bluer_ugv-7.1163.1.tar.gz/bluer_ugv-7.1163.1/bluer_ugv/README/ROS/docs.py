from bluer_ugv.README.ROS.validations import docs as validations

docs = [
    {
        "path": "../docs/ROS",
    }
] + validations.docs
