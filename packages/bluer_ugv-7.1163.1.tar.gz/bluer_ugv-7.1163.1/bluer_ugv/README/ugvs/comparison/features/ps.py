from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class PSFeature(Feature):
    nickname = "ps"
    long_name = "سامانه‌ی مکان‌یابی و ارتباطی محلی"

    comparison_as_str = {}
