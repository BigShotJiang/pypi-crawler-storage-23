from bluer_objects.README.consts import assets_url, designs_url

arzhang_assets = assets_url(
    suffix="arzhang",
)

arzhang_assets2 = assets_url(
    suffix="arzhang",
    volume=2,
)

arzhang2_assets2 = assets_url(
    suffix="arzhang2",
    volume=2,
)
arzhang2_assets3 = assets_url(
    suffix="arzhang2",
    volume=3,
)

arzhang_mechanical_design = designs_url("arzhang")
