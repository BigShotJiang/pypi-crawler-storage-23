'''
KitPyLib
========

A Python Library of basic tools.

How to use
----------
We recommend you to import `kitpy` as ``kp``:\n
  >>> import kitpylib as kpl
  >>> kpl.fplot2d(lambda x: x**3, 0, 2)
  
Use the built-in ``help`` function to view a function's docstring:\n
  >>> help(kpl.fplot2d)
  ... # doctest: +SKIP
  
Available subpackages
---------------------
PyFile
    KitPyLib's subpackage to solve txt file problems
PyWidget
    KitPyLib's subpackage about qt widgets
   
Utilities
---------
__version__
    KitPyLib version string
__copr__
    KitPyLib copyright string
__lic__
    KitPyLib license string
'''
from . import PyFile
from .PyMath import *
from .PyModule import *
from .PyPlot import *
__version__ = '1.0.1'
__copr__ = myinfo['copyright']
__lic__ = __copr__ + mit_license