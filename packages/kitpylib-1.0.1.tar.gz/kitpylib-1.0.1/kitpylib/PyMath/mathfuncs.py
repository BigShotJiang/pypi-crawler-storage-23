from numpy import (linspace, sin, cos, tan, sinh, cosh, tanh, arcsin, arccos, 
                   arctan, arcsinh, arccosh, arctanh, degrees, radians, sqrt,
                   log10, round, floor, ceil, sign, exp, log)
from scipy.special import gamma, erf
from .spf3d import (tri2d, ramp2d, rect2d, sign2d, step2d, sinc2d, gaus2d,
                    tri3d, ramp3d, rect3d, sign3d, step3d, sinc3d, gaus3d)