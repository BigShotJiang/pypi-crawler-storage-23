# Definitions & Types

Core type definitions, enums, and constants used throughout DerivaML.
This includes vocabulary types, status enums, column definitions, and other
foundational types.

::: deriva_ml.core.definitions
    handler: python
