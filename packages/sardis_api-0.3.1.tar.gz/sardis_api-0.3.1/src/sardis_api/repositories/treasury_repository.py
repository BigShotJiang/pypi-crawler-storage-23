"""Treasury repository for Lithic financial accounts and ACH records."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional
import os
import uuid
import hashlib


class TreasuryRepository:
    def __init__(self, pool=None, dsn: str | None = None):
        self._pool = pool
        self._dsn = dsn or os.getenv("DATABASE_URL", "")
        self._financial_accounts: dict[tuple[str, str], dict[str, Any]] = {}
        self._external_bank_accounts: dict[tuple[str, str], dict[str, Any]] = {}
        self._payments: dict[tuple[str, str], dict[str, Any]] = {}
        self._payment_events: list[dict[str, Any]] = []
        self._balance_snapshots: list[dict[str, Any]] = []
        self._reservations: dict[str, dict[str, Any]] = {}
        self._webhook_events: dict[tuple[str, str], dict[str, Any]] = {}
        self._issuing_funding_events: dict[tuple[str, str, str], dict[str, Any]] = {}
        self._issuer_funding_table_ready: bool = False
        self._funding_attempts: dict[tuple[str, str, int], dict[str, Any]] = {}
        self._funding_attempt_table_ready: bool = False

    def _use_postgres(self) -> bool:
        if self._pool is not None:
            return True
        return self._dsn.startswith(("postgresql://", "postgres://"))

    async def _get_pool(self):
        if self._pool is None:
            if not self._use_postgres():
                return None
            import asyncpg

            dsn = self._dsn
            if dsn.startswith("postgres://"):
                dsn = dsn.replace("postgres://", "postgresql://", 1)
            self._pool = await asyncpg.create_pool(dsn, min_size=1, max_size=8)
        return self._pool

    async def upsert_financial_account(self, organization_id: str, account: dict[str, Any]) -> dict[str, Any]:
        token = str(account.get("token", ""))
        if not token:
            raise ValueError("financial account token is required")

        row = {
            "organization_id": organization_id,
            "financial_account_token": token,
            "account_token": account.get("account_token"),
            "account_role": account.get("type", "OPERATING"),
            "currency": account.get("currency", "USD"),
            "status": account.get("status", "OPEN"),
            "is_program_level": bool(account.get("is_program_level", account.get("account_token") in (None, ""))),
            "nickname": account.get("nickname"),
            "routing_number": account.get("routing_number"),
            "account_number_last4": (account.get("account_number") or "")[-4:] if account.get("account_number") else None,
            "metadata": account,
            "updated_at": datetime.now(timezone.utc),
        }

        if not self._use_postgres():
            now = datetime.now(timezone.utc).isoformat()
            row["created_at"] = self._financial_accounts.get((organization_id, token), {}).get("created_at", now)
            self._financial_accounts[(organization_id, token)] = row
            return row

        pool = await self._get_pool()
        if pool is None:
            raise RuntimeError("PostgreSQL pool unavailable")
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO lithic_financial_accounts (
                    id, organization_id, account_token, financial_account_token, account_role,
                    currency, status, is_program_level, nickname, routing_number,
                    account_number_last4, metadata, created_at, updated_at
                ) VALUES (
                    $1::uuid, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb, NOW(), NOW()
                )
                ON CONFLICT (financial_account_token) DO UPDATE SET
                    organization_id = EXCLUDED.organization_id,
                    account_token = EXCLUDED.account_token,
                    account_role = EXCLUDED.account_role,
                    currency = EXCLUDED.currency,
                    status = EXCLUDED.status,
                    is_program_level = EXCLUDED.is_program_level,
                    nickname = EXCLUDED.nickname,
                    routing_number = EXCLUDED.routing_number,
                    account_number_last4 = EXCLUDED.account_number_last4,
                    metadata = EXCLUDED.metadata,
                    updated_at = NOW()
                """,
                str(uuid.uuid4()),
                organization_id,
                row["account_token"],
                token,
                row["account_role"],
                row["currency"],
                row["status"],
                row["is_program_level"],
                row["nickname"],
                row["routing_number"],
                row["account_number_last4"],
                row["metadata"],
            )
            db_row = await conn.fetchrow(
                """
                SELECT organization_id, account_token, financial_account_token, account_role,
                       currency, status, is_program_level, nickname, routing_number,
                       account_number_last4, metadata, created_at, updated_at
                FROM lithic_financial_accounts
                WHERE organization_id = $1 AND financial_account_token = $2
                """,
                organization_id,
                token,
            )
            return dict(db_row) if db_row else row

    async def get_financial_account(self, organization_id: str, financial_account_token: str) -> Optional[dict[str, Any]]:
        if not self._use_postgres():
            return self._financial_accounts.get((organization_id, financial_account_token))
        pool = await self._get_pool()
        if pool is None:
            return None
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT organization_id, account_token, financial_account_token, account_role,
                       currency, status, is_program_level, nickname, routing_number,
                       account_number_last4, metadata, created_at, updated_at
                FROM lithic_financial_accounts
                WHERE organization_id = $1 AND financial_account_token = $2
                """,
                organization_id,
                financial_account_token,
            )
            return dict(row) if row else None

    async def list_financial_accounts(
        self,
        organization_id: str,
        account_token: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        if not self._use_postgres():
            rows = [
                value for (org, _), value in self._financial_accounts.items() if org == organization_id
            ]
            if account_token:
                rows = [r for r in rows if r.get("account_token") == account_token]
            return rows
        pool = await self._get_pool()
        if pool is None:
            return []
        query = """
            SELECT organization_id, account_token, financial_account_token, account_role,
                   currency, status, is_program_level, nickname, routing_number,
                   account_number_last4, metadata, created_at, updated_at
            FROM lithic_financial_accounts
            WHERE organization_id = $1
        """
        args: list[Any] = [organization_id]
        if account_token:
            query += " AND account_token = $2"
            args.append(account_token)
        query += " ORDER BY account_role, created_at DESC"
        async with pool.acquire() as conn:
            rows = await conn.fetch(query, *args)
        return [dict(r) for r in rows]

    async def get_funding_account_for_org(
        self,
        organization_id: str,
        preferred_role: str = "ISSUING",
    ) -> Optional[str]:
        accounts = await self.list_financial_accounts(organization_id)
        if not accounts:
            return None
        by_role = [a for a in accounts if str(a.get("account_role", "")).upper() == preferred_role.upper()]
        if by_role:
            return str(by_role[0].get("financial_account_token", ""))
        return str(accounts[0].get("financial_account_token", ""))

    async def upsert_external_bank_account(self, organization_id: str, external: dict[str, Any]) -> dict[str, Any]:
        token = str(external.get("token", ""))
        if not token:
            raise ValueError("external bank account token is required")
        row = {
            "organization_id": organization_id,
            "external_bank_account_token": token,
            "financial_account_token": external.get("financial_account_token"),
            "owner_type": external.get("owner_type", ""),
            "owner": external.get("owner", ""),
            "account_type": external.get("type", ""),
            "verification_method": external.get("verification_method", ""),
            "verification_state": external.get("verification_state", "PENDING"),
            "state": external.get("state", "ENABLED"),
            "currency": external.get("currency", "USD"),
            "country": external.get("country", "USA"),
            "name": external.get("name"),
            "routing_number": external.get("routing_number"),
            "last_four": external.get("last_four"),
            "user_defined_id": external.get("user_defined_id"),
            "company_id": external.get("company_id"),
            "is_paused": False,
            "pause_reason": None,
            "last_return_reason_code": external.get("verification_failed_reason"),
            "metadata": external,
        }
        if not self._use_postgres():
            self._external_bank_accounts[(organization_id, token)] = row
            return row

        pool = await self._get_pool()
        if pool is None:
            raise RuntimeError("PostgreSQL pool unavailable")
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO external_bank_accounts (
                    id, organization_id, external_bank_account_token, financial_account_token,
                    owner_type, owner, account_type, verification_method, verification_state,
                    state, currency, country, name, routing_number, last_four, user_defined_id,
                    company_id, is_paused, pause_reason, last_return_reason_code, metadata, created_at, updated_at
                ) VALUES (
                    $1::uuid, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17,
                    $18, $19, $20, $21::jsonb, NOW(), NOW()
                )
                ON CONFLICT (external_bank_account_token) DO UPDATE SET
                    organization_id = EXCLUDED.organization_id,
                    financial_account_token = EXCLUDED.financial_account_token,
                    owner_type = EXCLUDED.owner_type,
                    owner = EXCLUDED.owner,
                    account_type = EXCLUDED.account_type,
                    verification_method = EXCLUDED.verification_method,
                    verification_state = EXCLUDED.verification_state,
                    state = EXCLUDED.state,
                    currency = EXCLUDED.currency,
                    country = EXCLUDED.country,
                    name = EXCLUDED.name,
                    routing_number = EXCLUDED.routing_number,
                    last_four = EXCLUDED.last_four,
                    user_defined_id = EXCLUDED.user_defined_id,
                    company_id = EXCLUDED.company_id,
                    last_return_reason_code = EXCLUDED.last_return_reason_code,
                    metadata = EXCLUDED.metadata,
                    updated_at = NOW()
                """,
                str(uuid.uuid4()),
                organization_id,
                token,
                row["financial_account_token"],
                row["owner_type"],
                row["owner"],
                row["account_type"],
                row["verification_method"],
                row["verification_state"],
                row["state"],
                row["currency"],
                row["country"],
                row["name"],
                row["routing_number"],
                row["last_four"],
                row["user_defined_id"],
                row["company_id"],
                row["is_paused"],
                row["pause_reason"],
                row["last_return_reason_code"],
                row["metadata"],
            )
            db_row = await conn.fetchrow(
                """
                SELECT * FROM external_bank_accounts
                WHERE organization_id = $1 AND external_bank_account_token = $2
                """,
                organization_id,
                token,
            )
            return dict(db_row) if db_row else row

    async def get_external_bank_account(self, organization_id: str, token: str) -> Optional[dict[str, Any]]:
        if not self._use_postgres():
            return self._external_bank_accounts.get((organization_id, token))
        pool = await self._get_pool()
        if pool is None:
            return None
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT * FROM external_bank_accounts
                WHERE organization_id = $1 AND external_bank_account_token = $2
                """,
                organization_id,
                token,
            )
            return dict(row) if row else None

    async def upsert_ach_payment(
        self,
        organization_id: str,
        payment: dict[str, Any],
        *,
        idempotency_key: Optional[str] = None,
    ) -> dict[str, Any]:
        payment_token = str(payment.get("token", ""))
        if not payment_token:
            raise ValueError("payment token is required")
        row = {
            "organization_id": organization_id,
            "payment_token": payment_token,
            "financial_account_token": payment.get("financial_account_token", ""),
            "external_bank_account_token": payment.get("external_bank_account_token", ""),
            "direction": payment.get("direction", ""),
            "method": payment.get("method", ""),
            "sec_code": (payment.get("method_attributes", {}) or {}).get("sec_code", "CCD"),
            "currency": payment.get("currency", "USD"),
            "amount_minor": int(payment.get("pending_amount", 0) or 0),
            "status": payment.get("status", "PENDING"),
            "result": payment.get("result"),
            "source": payment.get("source"),
            "provider_reference": payment.get("provider_reference"),
            "user_defined_id": payment.get("user_defined_id"),
            "idempotency_key": idempotency_key,
            "retry_count": 0,
            "last_return_reason_code": None,
            "metadata": payment,
        }

        if not self._use_postgres():
            self._payments[(organization_id, payment_token)] = row
            return row

        pool = await self._get_pool()
        if pool is None:
            raise RuntimeError("PostgreSQL pool unavailable")
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO ach_payments (
                    id, payment_token, organization_id, financial_account_token, external_bank_account_token,
                    direction, method, sec_code, currency, amount_minor, status, result, source,
                    provider_reference, user_defined_id, idempotency_key, retry_count,
                    metadata, created_at, updated_at
                ) VALUES (
                    $1::uuid, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
                    $14, $15, $16, $17, $18::jsonb, NOW(), NOW()
                )
                ON CONFLICT (payment_token) DO UPDATE SET
                    organization_id = EXCLUDED.organization_id,
                    financial_account_token = EXCLUDED.financial_account_token,
                    external_bank_account_token = EXCLUDED.external_bank_account_token,
                    direction = EXCLUDED.direction,
                    method = EXCLUDED.method,
                    sec_code = EXCLUDED.sec_code,
                    currency = EXCLUDED.currency,
                    amount_minor = EXCLUDED.amount_minor,
                    status = EXCLUDED.status,
                    result = EXCLUDED.result,
                    source = EXCLUDED.source,
                    provider_reference = EXCLUDED.provider_reference,
                    user_defined_id = EXCLUDED.user_defined_id,
                    metadata = EXCLUDED.metadata,
                    updated_at = NOW()
                """,
                str(uuid.uuid4()),
                payment_token,
                organization_id,
                row["financial_account_token"],
                row["external_bank_account_token"],
                row["direction"],
                row["method"],
                row["sec_code"],
                row["currency"],
                row["amount_minor"],
                row["status"],
                row["result"],
                row["source"],
                row["provider_reference"],
                row["user_defined_id"],
                row["idempotency_key"],
                row["retry_count"],
                row["metadata"],
            )
            db_row = await conn.fetchrow(
                "SELECT * FROM ach_payments WHERE organization_id = $1 AND payment_token = $2",
                organization_id,
                payment_token,
            )
            return dict(db_row) if db_row else row

    async def get_ach_payment(self, organization_id: str, payment_token: str) -> Optional[dict[str, Any]]:
        if not self._use_postgres():
            return self._payments.get((organization_id, payment_token))
        pool = await self._get_pool()
        if pool is None:
            return None
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM ach_payments WHERE organization_id = $1 AND payment_token = $2",
                organization_id,
                payment_token,
            )
            return dict(row) if row else None

    async def update_ach_payment_status(
        self,
        organization_id: str,
        payment_token: str,
        status_value: str,
        *,
        result: Optional[str] = None,
        return_reason_code: Optional[str] = None,
        provider_reference: Optional[str] = None,
    ) -> Optional[dict[str, Any]]:
        if not self._use_postgres():
            row = self._payments.get((organization_id, payment_token))
            if row is None:
                return None
            row["status"] = status_value
            if result is not None:
                row["result"] = result
            if return_reason_code is not None:
                row["last_return_reason_code"] = return_reason_code
            if provider_reference is not None:
                row["provider_reference"] = provider_reference
            row["updated_at"] = datetime.now(timezone.utc)
            return row
        pool = await self._get_pool()
        if pool is None:
            return None
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                UPDATE ach_payments
                SET status = $3,
                    result = COALESCE($4, result),
                    last_return_reason_code = COALESCE($5, last_return_reason_code),
                    provider_reference = COALESCE($6, provider_reference),
                    updated_at = NOW()
                WHERE organization_id = $1 AND payment_token = $2
                RETURNING *
                """,
                organization_id,
                payment_token,
                status_value,
                result,
                return_reason_code,
                provider_reference,
            )
            return dict(row) if row else None

    async def increment_retry_count(self, organization_id: str, payment_token: str) -> None:
        if not self._use_postgres():
            row = self._payments.get((organization_id, payment_token))
            if row:
                row["retry_count"] = int(row.get("retry_count", 0) or 0) + 1
            return
        pool = await self._get_pool()
        if pool is None:
            return
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE ach_payments
                SET retry_count = retry_count + 1, updated_at = NOW()
                WHERE organization_id = $1 AND payment_token = $2
                """,
                organization_id,
                payment_token,
            )

    async def append_ach_events(self, organization_id: str, payment_token: str, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        if not self._use_postgres():
            for e in events:
                self._payment_events.append(
                    {
                        "organization_id": organization_id,
                        "payment_token": payment_token,
                        "event_token": e.get("token"),
                        "event_type": e.get("type"),
                        "amount_minor": int(e.get("amount", 0) or 0),
                        "result": e.get("result"),
                        "detailed_results": e.get("detailed_results", []),
                        "return_reason_code": e.get("return_reason_code"),
                        "raw_payload": e,
                    }
                )
            return
        pool = await self._get_pool()
        if pool is None:
            return
        async with pool.acquire() as conn:
            for e in events:
                await conn.execute(
                    """
                    INSERT INTO ach_payment_events (
                        id, payment_token, organization_id, event_token, event_type, amount_minor, result,
                        detailed_results, return_reason_code, raw_payload, created_at
                    ) VALUES (
                        $1::uuid, $2, $3, $4, $5, $6, $7, $8::jsonb, $9, $10::jsonb, NOW()
                    )
                    ON CONFLICT (organization_id, event_token) WHERE event_token IS NOT NULL DO NOTHING
                    """,
                    str(uuid.uuid4()),
                    payment_token,
                    organization_id,
                    e.get("token"),
                    e.get("type"),
                    int(e.get("amount", 0) or 0),
                    e.get("result"),
                    e.get("detailed_results", []),
                    e.get("return_reason_code"),
                    e,
                )

    async def add_balance_snapshot(
        self,
        organization_id: str,
        financial_account_token: str,
        currency: str,
        available_amount_minor: int,
        pending_amount_minor: int,
        total_amount_minor: int,
        as_of_event_token: Optional[str] = None,
    ) -> dict[str, Any]:
        row = {
            "organization_id": organization_id,
            "financial_account_token": financial_account_token,
            "currency": currency,
            "available_amount_minor": int(available_amount_minor),
            "pending_amount_minor": int(pending_amount_minor),
            "total_amount_minor": int(total_amount_minor),
            "as_of_event_token": as_of_event_token,
            "created_at": datetime.now(timezone.utc),
        }
        if not self._use_postgres():
            self._balance_snapshots.append(row)
            return row
        pool = await self._get_pool()
        if pool is None:
            return row
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO treasury_balance_snapshots (
                    id, organization_id, financial_account_token, currency, available_amount_minor,
                    pending_amount_minor, total_amount_minor, as_of_event_token, created_at
                ) VALUES ($1::uuid, $2, $3, $4, $5, $6, $7, $8, NOW())
                """,
                str(uuid.uuid4()),
                organization_id,
                financial_account_token,
                currency,
                int(available_amount_minor),
                int(pending_amount_minor),
                int(total_amount_minor),
                as_of_event_token,
            )
        return row

    async def list_latest_balance_snapshots(self, organization_id: str) -> list[dict[str, Any]]:
        if not self._use_postgres():
            latest: dict[tuple[str, str], dict[str, Any]] = {}
            for s in self._balance_snapshots:
                if s.get("organization_id") != organization_id:
                    continue
                key = (s.get("financial_account_token", ""), s.get("currency", "USD"))
                prev = latest.get(key)
                if prev is None or s["created_at"] > prev["created_at"]:
                    latest[key] = s
            return list(latest.values())
        pool = await self._get_pool()
        if pool is None:
            return []
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT DISTINCT ON (financial_account_token, currency)
                    organization_id, financial_account_token, currency,
                    available_amount_minor, pending_amount_minor, total_amount_minor,
                    as_of_event_token, provider_updated_at, created_at
                FROM treasury_balance_snapshots
                WHERE organization_id = $1
                ORDER BY financial_account_token, currency, created_at DESC
                """,
                organization_id,
            )
            return [dict(r) for r in rows]

    async def create_reservation(
        self,
        *,
        reservation_id: str,
        organization_id: str,
        wallet_id: Optional[str],
        card_id: Optional[str],
        currency: str,
        amount_minor: int,
        status: str,
        reason: Optional[str] = None,
        reference_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        row = {
            "reservation_id": reservation_id,
            "organization_id": organization_id,
            "wallet_id": wallet_id,
            "card_id": card_id,
            "currency": currency,
            "amount_minor": amount_minor,
            "status": status,
            "reason": reason,
            "reference_id": reference_id,
            "metadata": metadata or {},
            "updated_at": datetime.now(timezone.utc),
        }
        if not self._use_postgres():
            row["created_at"] = row["updated_at"]
            self._reservations[reservation_id] = row
            return row
        pool = await self._get_pool()
        if pool is None:
            return row
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO treasury_reservations (
                    reservation_id, organization_id, wallet_id, card_id, currency, amount_minor,
                    status, reason, reference_id, metadata, created_at, updated_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb, NOW(), NOW()
                )
                ON CONFLICT (reservation_id) DO UPDATE SET
                    status = EXCLUDED.status,
                    reason = EXCLUDED.reason,
                    reference_id = EXCLUDED.reference_id,
                    metadata = EXCLUDED.metadata,
                    updated_at = NOW()
                """,
                reservation_id,
                organization_id,
                wallet_id,
                card_id,
                currency,
                amount_minor,
                status,
                reason,
                reference_id,
                metadata or {},
            )
            db_row = await conn.fetchrow(
                "SELECT * FROM treasury_reservations WHERE reservation_id = $1",
                reservation_id,
            )
            return dict(db_row) if db_row else row

    async def pause_external_bank_account(
        self,
        organization_id: str,
        external_bank_account_token: str,
        reason: str,
        return_code: Optional[str] = None,
    ) -> None:
        if not self._use_postgres():
            row = self._external_bank_accounts.get((organization_id, external_bank_account_token))
            if row:
                row["is_paused"] = True
                row["state"] = "PAUSED"
                row["pause_reason"] = reason
                row["last_return_reason_code"] = return_code
            return
        pool = await self._get_pool()
        if pool is None:
            return
        async with pool.acquire() as conn:
            await conn.execute(
                """
                UPDATE external_bank_accounts
                SET is_paused = TRUE,
                    state = 'PAUSED',
                    pause_reason = $3,
                    last_return_reason_code = $4,
                    updated_at = NOW()
                WHERE organization_id = $1 AND external_bank_account_token = $2
                """,
                organization_id,
                external_bank_account_token,
                reason,
                return_code,
            )

    async def list_payments_for_reconciliation(
        self,
        organization_id: str,
        *,
        status_filter: Optional[list[str]] = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        if not self._use_postgres():
            rows = [row for (org, _), row in self._payments.items() if org == organization_id]
            if status_filter:
                allowed = {s.upper() for s in status_filter}
                rows = [r for r in rows if str(r.get("status", "")).upper() in allowed]
            return rows[:limit]
        pool = await self._get_pool()
        if pool is None:
            return []
        async with pool.acquire() as conn:
            if status_filter:
                rows = await conn.fetch(
                    """
                    SELECT * FROM ach_payments
                    WHERE organization_id = $1 AND status = ANY($2::text[])
                    ORDER BY updated_at DESC
                    LIMIT $3
                    """,
                    organization_id,
                    status_filter,
                    limit,
                )
            else:
                rows = await conn.fetch(
                    """
                    SELECT * FROM ach_payments
                    WHERE organization_id = $1
                    ORDER BY updated_at DESC
                    LIMIT $2
                    """,
                    organization_id,
                    limit,
            )
            return [dict(r) for r in rows]

    async def list_retryable_payments(
        self,
        organization_id: str,
        *,
        max_retry_count: int = 2,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        retry_codes = {"R01", "R09"}
        if not self._use_postgres():
            rows = []
            for (org, _), row in self._payments.items():
                if org != organization_id:
                    continue
                if str(row.get("last_return_reason_code", "")) not in retry_codes:
                    continue
                if int(row.get("retry_count", 0) or 0) >= max_retry_count:
                    continue
                if str(row.get("status", "")).upper() not in {"RETURNED", "RETURN_INITIATED"}:
                    continue
                rows.append(row)
            return rows[:limit]
        pool = await self._get_pool()
        if pool is None:
            return []
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM ach_payments
                WHERE organization_id = $1
                  AND status = ANY($2::text[])
                  AND last_return_reason_code = ANY($3::text[])
                  AND retry_count < $4
                ORDER BY updated_at DESC
                LIMIT $5
                """,
                organization_id,
                ["RETURNED", "RETURN_INITIATED"],
                ["R01", "R09"],
                max_retry_count,
                limit,
            )
            return [dict(r) for r in rows]

    async def get_org_payment_stats(self, organization_id: str, *, hours: int = 24) -> dict[str, int]:
        if not self._use_postgres():
            now = datetime.now(timezone.utc)
            total_minor = 0
            count = 0
            for (org, _), row in self._payments.items():
                if org != organization_id:
                    continue
                created_at = row.get("created_at")
                if isinstance(created_at, str):
                    try:
                        created_dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    except Exception:
                        created_dt = now
                elif isinstance(created_at, datetime):
                    created_dt = created_at
                else:
                    created_dt = now
                if (now - created_dt).total_seconds() <= hours * 3600:
                    count += 1
                    total_minor += int(row.get("amount_minor", 0) or 0)
            return {"count": count, "total_minor": total_minor}
        pool = await self._get_pool()
        if pool is None:
            return {"count": 0, "total_minor": 0}
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """
                SELECT
                    COUNT(*)::int AS count,
                    COALESCE(SUM(amount_minor), 0)::bigint AS total_minor
                FROM ach_payments
                WHERE organization_id = $1
                  AND created_at >= NOW() - ($2 || ' hours')::interval
                """,
                organization_id,
                hours,
            )
            return {"count": int(row["count"]), "total_minor": int(row["total_minor"])}

    async def _ensure_issuer_funding_table(self) -> None:
        if self._issuer_funding_table_ready:
            return
        if not self._use_postgres():
            self._issuer_funding_table_ready = True
            return
        pool = await self._get_pool()
        if pool is None:
            return
        async with pool.acquire() as conn:
            await conn.execute(
                """
                CREATE TABLE IF NOT EXISTS issuer_funding_audit (
                    id UUID PRIMARY KEY,
                    organization_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    transfer_id TEXT NOT NULL,
                    amount_minor BIGINT NOT NULL,
                    currency TEXT NOT NULL DEFAULT 'USD',
                    status TEXT NOT NULL,
                    connected_account_id TEXT,
                    idempotency_key TEXT,
                    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    UNIQUE(provider, transfer_id)
                );
                CREATE INDEX IF NOT EXISTS idx_issuer_funding_org_created
                  ON issuer_funding_audit(organization_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_issuer_funding_org_status
                  ON issuer_funding_audit(organization_id, status);
                CREATE INDEX IF NOT EXISTS idx_issuer_funding_org_connected
                  ON issuer_funding_audit(organization_id, connected_account_id);
                """
            )
        self._issuer_funding_table_ready = True

    async def _ensure_funding_attempt_table(self) -> None:
        if self._funding_attempt_table_ready:
            return
        if not self._use_postgres():
            self._funding_attempt_table_ready = True
            return
        pool = await self._get_pool()
        if pool is None:
            return
        environment = (os.getenv("SARDIS_ENVIRONMENT", "dev") or "dev").strip().lower()
        async with pool.acquire() as conn:
            if environment in {"prod", "production"}:
                exists = await conn.fetchval(
                    """
                    SELECT EXISTS(
                        SELECT 1
                        FROM information_schema.tables
                        WHERE table_name = 'issuer_funding_attempts'
                    )
                    """
                )
                if not exists:
                    raise RuntimeError(
                        "issuer_funding_attempts table not found in production; "
                        "run database migrations before starting the API"
                    )
            else:
                await conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS issuer_funding_attempts (
                        id UUID PRIMARY KEY,
                        organization_id TEXT NOT NULL,
                        operation_id TEXT NOT NULL,
                        attempt_index INT NOT NULL,
                        provider TEXT NOT NULL,
                        rail TEXT NOT NULL,
                        status TEXT NOT NULL,
                        error TEXT,
                        amount_minor BIGINT NOT NULL,
                        currency TEXT NOT NULL DEFAULT 'USD',
                        connected_account_id TEXT,
                        metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        UNIQUE(organization_id, operation_id, attempt_index)
                    );
                    CREATE INDEX IF NOT EXISTS idx_funding_attempts_org_created
                      ON issuer_funding_attempts(organization_id, created_at DESC);
                    CREATE INDEX IF NOT EXISTS idx_funding_attempts_org_operation
                      ON issuer_funding_attempts(organization_id, operation_id, attempt_index);
                    """
                )
        self._funding_attempt_table_ready = True

    async def record_issuing_funding_event(
        self,
        *,
        organization_id: str,
        provider: str,
        transfer_id: str,
        amount_minor: int,
        currency: str,
        status_value: str,
        connected_account_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        if not transfer_id:
            raise ValueError("transfer_id is required")
        provider_value = str(provider or "unknown").strip().lower()
        status_normalized = str(status_value or "processing").strip().lower()
        row = {
            "id": str(uuid.uuid4()),
            "organization_id": organization_id,
            "provider": provider_value,
            "transfer_id": transfer_id,
            "amount_minor": int(amount_minor),
            "currency": str(currency or "USD").upper(),
            "status": status_normalized,
            "connected_account_id": connected_account_id,
            "idempotency_key": idempotency_key,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }

        if not self._use_postgres():
            key = (organization_id, provider_value, transfer_id)
            existing = self._issuing_funding_events.get(key)
            if existing:
                existing.update(
                    {
                        "amount_minor": row["amount_minor"],
                        "currency": row["currency"],
                        "status": row["status"],
                        "connected_account_id": row["connected_account_id"],
                        "idempotency_key": row["idempotency_key"],
                        "metadata": row["metadata"],
                        "updated_at": row["updated_at"],
                    }
                )
                return existing
            self._issuing_funding_events[key] = row
            return row

        await self._ensure_issuer_funding_table()
        pool = await self._get_pool()
        if pool is None:
            raise RuntimeError("PostgreSQL pool unavailable")
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO issuer_funding_audit (
                    id, organization_id, provider, transfer_id, amount_minor, currency,
                    status, connected_account_id, idempotency_key, metadata, created_at, updated_at
                ) VALUES (
                    $1::uuid, $2, $3, $4, $5, $6,
                    $7, $8, $9, $10::jsonb, NOW(), NOW()
                )
                ON CONFLICT (provider, transfer_id) DO UPDATE SET
                    amount_minor = EXCLUDED.amount_minor,
                    currency = EXCLUDED.currency,
                    status = EXCLUDED.status,
                    connected_account_id = EXCLUDED.connected_account_id,
                    idempotency_key = EXCLUDED.idempotency_key,
                    metadata = EXCLUDED.metadata,
                    updated_at = NOW()
                """,
                row["id"],
                organization_id,
                provider_value,
                transfer_id,
                row["amount_minor"],
                row["currency"],
                row["status"],
                connected_account_id,
                idempotency_key,
                row["metadata"],
            )
            db_row = await conn.fetchrow(
                """
                SELECT *
                FROM issuer_funding_audit
                WHERE provider = $1 AND transfer_id = $2
                """,
                provider_value,
                transfer_id,
            )
            return dict(db_row) if db_row else row

    async def list_issuing_funding_events(
        self,
        organization_id: str,
        *,
        limit: int = 100,
        provider: Optional[str] = None,
        connected_account_id: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        if not self._use_postgres():
            rows = [
                value
                for (org, _, _), value in self._issuing_funding_events.items()
                if org == organization_id
            ]
            if provider:
                p = str(provider).strip().lower()
                rows = [r for r in rows if str(r.get("provider", "")).strip().lower() == p]
            if connected_account_id:
                rows = [r for r in rows if str(r.get("connected_account_id") or "") == connected_account_id]
            rows.sort(key=lambda r: str(r.get("created_at", "")), reverse=True)
            return rows[:limit]

        await self._ensure_issuer_funding_table()
        pool = await self._get_pool()
        if pool is None:
            return []
        query = """
            SELECT *
            FROM issuer_funding_audit
            WHERE organization_id = $1
        """
        args: list[Any] = [organization_id]
        idx = 2
        if provider:
            query += f" AND provider = ${idx}"
            args.append(str(provider).strip().lower())
            idx += 1
        if connected_account_id:
            query += f" AND connected_account_id = ${idx}"
            args.append(connected_account_id)
            idx += 1
        query += f" ORDER BY created_at DESC LIMIT ${idx}"
        args.append(limit)
        async with pool.acquire() as conn:
            rows = await conn.fetch(query, *args)
            return [dict(r) for r in rows]

    async def summarize_issuing_funding_events(
        self,
        organization_id: str,
        *,
        hours: int = 24,
    ) -> dict[str, Any]:
        if not self._use_postgres():
            now = datetime.now(timezone.utc)
            total_minor = 0
            count = 0
            by_status: dict[str, int] = {}
            for (org, _, _), row in self._issuing_funding_events.items():
                if org != organization_id:
                    continue
                created_at = row.get("created_at")
                if isinstance(created_at, str):
                    try:
                        created_dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                    except Exception:
                        created_dt = now
                elif isinstance(created_at, datetime):
                    created_dt = created_at
                else:
                    created_dt = now
                if (now - created_dt).total_seconds() > hours * 3600:
                    continue
                count += 1
                total_minor += int(row.get("amount_minor", 0) or 0)
                key = str(row.get("status", "unknown")).strip().lower() or "unknown"
                by_status[key] = by_status.get(key, 0) + 1
            return {
                "organization_id": organization_id,
                "window_hours": hours,
                "count": count,
                "total_minor": total_minor,
                "by_status": by_status,
            }

    async def record_funding_attempt(
        self,
        *,
        organization_id: str,
        operation_id: str,
        attempt_index: int,
        provider: str,
        rail: str,
        status_value: str,
        error_message: Optional[str] = None,
        amount_minor: int,
        currency: str,
        connected_account_id: Optional[str] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        if not operation_id:
            raise ValueError("operation_id is required")
        if attempt_index <= 0:
            raise ValueError("attempt_index must be greater than zero")

        row = {
            "id": str(uuid.uuid4()),
            "organization_id": organization_id,
            "operation_id": operation_id,
            "attempt_index": int(attempt_index),
            "provider": str(provider or "unknown").strip().lower(),
            "rail": str(rail or "fiat").strip().lower(),
            "status": str(status_value or "failed").strip().lower(),
            "error": error_message,
            "amount_minor": int(amount_minor),
            "currency": str(currency or "USD").upper(),
            "connected_account_id": connected_account_id,
            "metadata": metadata or {},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        if not self._use_postgres():
            key = (organization_id, operation_id, int(attempt_index))
            self._funding_attempts[key] = row
            return row

        await self._ensure_funding_attempt_table()
        pool = await self._get_pool()
        if pool is None:
            raise RuntimeError("PostgreSQL pool unavailable")
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO issuer_funding_attempts (
                    id, organization_id, operation_id, attempt_index, provider, rail, status, error,
                    amount_minor, currency, connected_account_id, metadata, created_at
                ) VALUES (
                    $1::uuid, $2, $3, $4, $5, $6, $7, $8,
                    $9, $10, $11, $12::jsonb, NOW()
                )
                ON CONFLICT (organization_id, operation_id, attempt_index) DO UPDATE SET
                    provider = EXCLUDED.provider,
                    rail = EXCLUDED.rail,
                    status = EXCLUDED.status,
                    error = EXCLUDED.error,
                    amount_minor = EXCLUDED.amount_minor,
                    currency = EXCLUDED.currency,
                    connected_account_id = EXCLUDED.connected_account_id,
                    metadata = EXCLUDED.metadata
                """,
                row["id"],
                organization_id,
                operation_id,
                int(attempt_index),
                row["provider"],
                row["rail"],
                row["status"],
                row["error"],
                row["amount_minor"],
                row["currency"],
                connected_account_id,
                row["metadata"],
            )
            db_row = await conn.fetchrow(
                """
                SELECT *
                FROM issuer_funding_attempts
                WHERE organization_id = $1 AND operation_id = $2 AND attempt_index = $3
                """,
                organization_id,
                operation_id,
                int(attempt_index),
            )
            return dict(db_row) if db_row else row

    async def list_funding_attempts(
        self,
        organization_id: str,
        *,
        operation_id: Optional[str] = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        if not self._use_postgres():
            rows = [
                value
                for (org, op_id, _), value in self._funding_attempts.items()
                if org == organization_id and (operation_id is None or op_id == operation_id)
            ]
            rows.sort(
                key=lambda r: (str(r.get("operation_id", "")), int(r.get("attempt_index", 0) or 0)),
                reverse=False,
            )
            rows = rows[-limit:]
            return rows

        await self._ensure_funding_attempt_table()
        pool = await self._get_pool()
        if pool is None:
            return []
        query = """
            SELECT *
            FROM issuer_funding_attempts
            WHERE organization_id = $1
        """
        args: list[Any] = [organization_id]
        idx = 2
        if operation_id is not None:
            query += f" AND operation_id = ${idx}"
            args.append(operation_id)
            idx += 1
        query += f" ORDER BY created_at DESC, attempt_index ASC LIMIT ${idx}"
        args.append(limit)
        async with pool.acquire() as conn:
            rows = await conn.fetch(query, *args)
            return [dict(r) for r in rows]

        await self._ensure_issuer_funding_table()
        pool = await self._get_pool()
        if pool is None:
            return {
                "organization_id": organization_id,
                "window_hours": hours,
                "count": 0,
                "total_minor": 0,
                "by_status": {},
            }
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT status, COUNT(*)::int AS count, COALESCE(SUM(amount_minor), 0)::bigint AS total_minor
                FROM issuer_funding_audit
                WHERE organization_id = $1
                  AND created_at >= NOW() - ($2 || ' hours')::interval
                GROUP BY status
                ORDER BY status
                """,
                organization_id,
                hours,
            )
            by_status: dict[str, int] = {}
            total_minor = 0
            count = 0
            for row in rows:
                key = str(row["status"])
                c = int(row["count"])
                by_status[key] = c
                count += c
                total_minor += int(row["total_minor"])
            return {
                "organization_id": organization_id,
                "window_hours": hours,
                "count": count,
                "total_minor": total_minor,
                "by_status": by_status,
            }

    async def list_organization_ids(self) -> list[str]:
        if not self._use_postgres():
            orgs = set()
            for org, _ in self._payments.keys():
                orgs.add(org)
            for org, _ in self._financial_accounts.keys():
                orgs.add(org)
            for org, _ in self._external_bank_accounts.keys():
                orgs.add(org)
            for org, _, _ in self._issuing_funding_events.keys():
                orgs.add(org)
            for org, _, _ in self._funding_attempts.keys():
                orgs.add(org)
            return sorted(orgs)
        pool = await self._get_pool()
        if pool is None:
            return []
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT DISTINCT organization_id
                FROM (
                    SELECT organization_id FROM ach_payments
                    UNION
                    SELECT organization_id FROM lithic_financial_accounts
                    UNION
                    SELECT organization_id FROM external_bank_accounts
                ) t
                WHERE organization_id IS NOT NULL
                """
            )
            return [str(r["organization_id"]) for r in rows]

    async def record_treasury_webhook_event(
        self,
        *,
        provider: str,
        event_id: str,
        body: bytes,
        status_value: str = "processed",
        metadata: Optional[dict[str, Any]] = None,
    ) -> None:
        body_hash = hashlib.sha256(body).hexdigest() if body else ""
        if not self._use_postgres():
            self._webhook_events[(provider, event_id)] = {
                "provider": provider,
                "event_id": event_id,
                "body_hash": body_hash,
                "status": status_value,
                "metadata": metadata or {},
                "processed_at": datetime.now(timezone.utc).isoformat(),
            }
            return
        pool = await self._get_pool()
        if pool is None:
            return
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO treasury_webhook_events (provider, event_id, body_hash, status, metadata, processed_at)
                VALUES ($1, $2, $3, $4, $5::jsonb, NOW())
                ON CONFLICT (provider, event_id) DO UPDATE SET
                    body_hash = EXCLUDED.body_hash,
                    status = EXCLUDED.status,
                    metadata = EXCLUDED.metadata,
                    processed_at = NOW()
                """,
                provider,
                event_id,
                body_hash,
                status_value,
                metadata or {},
            )
