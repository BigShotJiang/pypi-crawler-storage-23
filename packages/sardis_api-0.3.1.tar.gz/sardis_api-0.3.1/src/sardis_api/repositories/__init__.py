"""Repositories for database persistence."""
