"""Compliance API endpoints for KYC and Sanctions screening."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import hmac
from inspect import isawaitable
import json
import logging
import os
import time
from decimal import Decimal
from typing import Any, Optional, List

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from sardis_api.authz import Principal, require_admin_principal, require_principal
from sardis_api.webhook_replay import run_with_replay_protection

logger = logging.getLogger(__name__)

router = APIRouter(dependencies=[Depends(require_principal)])
public_router = APIRouter()


# ============================================================================
# Webhook Security Configuration
# ============================================================================

class WebhookSecurityConfig:
    """
    Configuration for webhook signature verification.

    CRITICAL SECURITY: Webhook signature verification is mandatory.
    Unverified webhooks MUST be rejected to prevent spoofing attacks.
    """

    # Persona webhook settings
    PERSONA_SIGNATURE_HEADER = "Persona-Signature"
    PERSONA_TIMESTAMP_HEADER = "Persona-Signature-Timestamp"

    # Maximum age for webhook timestamps (5 minutes)
    MAX_TIMESTAMP_AGE_SECONDS = 300

    # Minimum webhook secret length
    MIN_SECRET_LENGTH = 32


def get_persona_webhook_secret() -> Optional[str]:
    """
    Get Persona webhook secret from environment.

    Returns None if not configured, which will cause webhooks to be rejected.
    """
    secret = os.getenv("PERSONA_WEBHOOK_SECRET")
    if secret and len(secret) < WebhookSecurityConfig.MIN_SECRET_LENGTH:
        logger.error(
            f"SECURITY: Persona webhook secret is too short "
            f"(minimum {WebhookSecurityConfig.MIN_SECRET_LENGTH} characters)"
        )
        return None
    return secret


def verify_persona_webhook_signature(
    payload: bytes,
    signature: str,
    timestamp: str,
    secret: str,
) -> tuple[bool, Optional[str]]:
    """
    Verify Persona webhook signature using HMAC-SHA256.

    Persona signs webhooks using the format:
    HMAC-SHA256(timestamp + "." + payload, secret)

    The signature header contains: t=timestamp,v1=signature

    Args:
        payload: Raw request body
        signature: Value of Persona-Signature header
        timestamp: Value of Persona-Signature-Timestamp header (or from signature)
        secret: Webhook secret

    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        # Parse signature header (format: t=timestamp,v1=signature)
        sig_parts = {}
        for part in signature.split(","):
            if "=" in part:
                key, value = part.split("=", 1)
                sig_parts[key.strip()] = value.strip()

        # Extract timestamp and signature value
        sig_timestamp = sig_parts.get("t") or timestamp
        sig_value = sig_parts.get("v1", "")

        if not sig_timestamp:
            return False, "Missing timestamp in signature"

        if not sig_value:
            return False, "Missing signature value"

        # Validate timestamp freshness to prevent replay attacks
        try:
            ts = int(sig_timestamp)
            current_time = int(time.time())
            age = current_time - ts

            if age > WebhookSecurityConfig.MAX_TIMESTAMP_AGE_SECONDS:
                logger.warning(
                    f"Persona webhook rejected: timestamp too old ({age} seconds)"
                )
                return False, f"Webhook timestamp too old ({age} seconds)"

            if age < -60:  # Allow 1 minute clock skew
                logger.warning(
                    f"Persona webhook rejected: timestamp in future ({-age} seconds)"
                )
                return False, "Webhook timestamp is in the future"

        except ValueError:
            return False, "Invalid timestamp format"

        # Compute expected signature
        # Persona format: timestamp.payload
        signed_payload = f"{sig_timestamp}.".encode() + payload
        expected_signature = hmac.new(
            secret.encode(),
            signed_payload,
            hashlib.sha256,
        ).hexdigest()

        # Constant-time comparison to prevent timing attacks
        if not hmac.compare_digest(sig_value, expected_signature):
            logger.warning("Persona webhook signature verification failed")
            return False, "Invalid signature"

        return True, None

    except Exception as e:
        logger.error(f"Error verifying Persona webhook signature: {e}")
        return False, f"Signature verification error: {str(e)}"


async def verify_persona_webhook(
    request: Request,
    persona_signature: Optional[str] = Header(None, alias="Persona-Signature"),
    persona_timestamp: Optional[str] = Header(None, alias="Persona-Signature-Timestamp"),
) -> bytes:
    """
    FastAPI dependency to verify Persona webhook signature.

    SECURITY: This dependency MUST be used for all Persona webhook endpoints.
    It will reject any request without a valid HMAC signature.

    Raises:
        HTTPException 401: If signature is missing or invalid
        HTTPException 500: If webhook secret is not configured
    """
    # Get webhook secret
    secret = get_persona_webhook_secret()
    if not secret:
        logger.error(
            "SECURITY: Persona webhook received but PERSONA_WEBHOOK_SECRET not configured"
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Webhook verification not configured",
        )

    # Check for signature header
    if not persona_signature:
        logger.warning("Persona webhook rejected: missing signature header")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing webhook signature",
        )

    # Read raw body for signature verification
    body = await request.body()

    # Verify signature
    is_valid, error_msg = verify_persona_webhook_signature(
        payload=body,
        signature=persona_signature,
        timestamp=persona_timestamp or "",
        secret=secret,
    )

    if not is_valid:
        logger.warning(f"Persona webhook signature invalid: {error_msg}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=error_msg or "Invalid webhook signature",
        )

    logger.info("Persona webhook signature verified successfully")
    return body


# ============================================================================
# Request/Response Models
# ============================================================================

class KYCVerificationRequest(BaseModel):
    """Request to create a KYC verification."""

    agent_id: str = Field(..., description="Agent ID to verify")
    name_first: Optional[str] = Field(None, description="First name")
    name_last: Optional[str] = Field(None, description="Last name")
    email: Optional[str] = Field(None, description="Email address")


class KYCStatusResponse(BaseModel):
    """KYC verification status response."""

    agent_id: str
    status: str
    verification_id: Optional[str] = None
    is_verified: bool
    verified_at: Optional[str] = None
    expires_at: Optional[str] = None
    provider: str
    warning: Optional[str] = None


class KYCInquiryResponse(BaseModel):
    """Response when creating a KYC inquiry."""

    inquiry_id: str
    session_token: str
    redirect_url: Optional[str] = None
    status: str


class SanctionsScreenRequest(BaseModel):
    """Request to screen an address for sanctions."""

    address: str = Field(..., description="Wallet address to screen")
    chain: str = Field(default="ethereum", description="Blockchain network")


class SanctionsScreenResponse(BaseModel):
    """Sanctions screening response."""

    address: str
    chain: str
    risk_level: str
    is_sanctioned: bool
    should_block: bool
    provider: str
    matches: List[dict] = []
    reason: Optional[str] = None


class TransactionScreenRequest(BaseModel):
    """Request to screen a transaction for sanctions."""

    tx_hash: str
    chain: str
    from_address: str
    to_address: str
    amount: str
    token: str = "USDC"


class KYARegisterRequest(BaseModel):
    """Request to register an agent in KYA."""

    agent_id: str
    owner_id: str
    capabilities: List[str] = Field(default_factory=list)
    max_budget_per_tx: str = "50.00"
    daily_budget: str = "500.00"
    allowed_domains: List[str] = Field(default_factory=list)
    blocked_domains: List[str] = Field(default_factory=list)
    framework: Optional[str] = None
    framework_version: Optional[str] = None
    description: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class KYACheckRequestModel(BaseModel):
    """Request payload for KYA evaluation."""

    amount: str = "0"
    merchant_id: Optional[str] = None
    merchant_domain: Optional[str] = None


class KYAUpgradeRequest(BaseModel):
    """Request payload for KYA level upgrade."""

    target_level: str = Field(..., description="Target KYA level: basic/verified/attested")
    anchor_verification_id: Optional[str] = None
    code_hash: Optional[str] = None
    framework: Optional[str] = None
    version: Optional[str] = None
    attester: str = "self"


class KYASuspendRequest(BaseModel):
    """Request payload to suspend/revoke an agent."""

    reason: str = "manual_review"


class EvidenceSignatureVerifyRequest(BaseModel):
    """Request payload for evidence JWS verification."""

    token: str
    expected_bundle_digest: Optional[str] = None


# ============================================================================
# Dependency Injection
# ============================================================================

class ComplianceDependencies:
    """Dependencies for compliance endpoints."""

    def __init__(
        self,
        kyc_service,
        sanctions_service,
        audit_store=None,
        kya_service=None,
        policy_store=None,
        approval_service=None,
    ):
        self.kyc_service = kyc_service
        self.sanctions_service = sanctions_service
        self.audit_store = audit_store
        self.kya_service = kya_service
        self.policy_store = policy_store
        self.approval_service = approval_service


def get_deps() -> ComplianceDependencies:
    """Get compliance dependencies (override in main.py)."""
    raise NotImplementedError("Dependency override required")


async def _resolve_maybe_awaitable(value: Any) -> Any:
    if isawaitable(value):
        return await value
    return value


def _serialize_audit_entry(entry: Any) -> dict[str, Any]:
    if hasattr(entry, "to_dict") and callable(entry.to_dict):
        payload = entry.to_dict()
        if isinstance(payload, dict):
            return payload
    if isinstance(entry, dict):
        return dict(entry)
    return {"raw": str(entry)}


def _serialize_approval(approval: Any) -> dict[str, Any]:
    if approval is None:
        return {}
    if hasattr(approval, "model_dump") and callable(approval.model_dump):
        payload = approval.model_dump()
        if isinstance(payload, dict):
            return payload
    if hasattr(approval, "__dict__"):
        out: dict[str, Any] = {}
        for key, value in vars(approval).items():
            if hasattr(value, "isoformat"):
                out[key] = value.isoformat()
            else:
                out[key] = value
        return out
    if isinstance(approval, dict):
        return dict(approval)
    return {"raw": str(approval)}


def _compute_audit_entries_digest(entries: list[dict[str, Any]]) -> str:
    canonical = json.dumps(entries, sort_keys=True, separators=(",", ":"), default=str)
    return f"sha256:{hashlib.sha256(canonical.encode()).hexdigest()}"


def _hash_json(payload: Any) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode()).hexdigest()


def _build_merkle_root(leaves: list[str]) -> str:
    if not leaves:
        return ""
    level = list(leaves)
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        next_level: list[str] = []
        for idx in range(0, len(level), 2):
            next_level.append(hashlib.sha256((level[idx] + level[idx + 1]).encode()).hexdigest())
        level = next_level
    return level[0]


def _build_merkle_proof(leaves: list[str], leaf_index: int) -> list[dict[str, str]]:
    proof: list[dict[str, str]] = []
    if not leaves:
        return proof

    level = list(leaves)
    index = leaf_index
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        is_right = index % 2 == 1
        sibling_index = index - 1 if is_right else index + 1
        proof.append(
            {
                "position": "left" if is_right else "right",
                "hash": level[sibling_index],
            }
        )
        next_level: list[str] = []
        for idx in range(0, len(level), 2):
            next_level.append(hashlib.sha256((level[idx] + level[idx + 1]).encode()).hexdigest())
        level = next_level
        index //= 2
    return proof


def _verify_merkle_proof(leaf_hash: str, proof: list[dict[str, str]], root_hash: str) -> bool:
    current = leaf_hash
    for step in proof:
        sibling = step["hash"]
        if step["position"] == "left":
            current = hashlib.sha256((sibling + current).encode()).hexdigest()
        else:
            current = hashlib.sha256((current + sibling).encode()).hexdigest()
    return current == root_hash


def _build_hash_chain_summary(entries: list[dict[str, Any]]) -> dict[str, Any]:
    prev_hash = "0" * 64
    head = prev_hash
    tail = prev_hash
    for idx, entry in enumerate(entries):
        material = {
            "index": idx,
            "prev_hash": prev_hash,
            "entry": entry,
        }
        canonical = json.dumps(material, sort_keys=True, separators=(",", ":"), default=str)
        current = hashlib.sha256(canonical.encode()).hexdigest()
        if idx == 0:
            tail = current
        head = current
        prev_hash = current
    return {
        "algorithm": "sha256",
        "genesis": "0" * 64,
        "tail": tail if entries else None,
        "head": head if entries else None,
        "length": len(entries),
    }


def _attestation_candidates(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for entry in entries:
        metadata = entry.get("metadata") or {}
        if not isinstance(metadata, dict):
            continue
        keys = set(metadata.keys())
        if {
            "policy_hash",
            "audit_anchor",
            "decision_id",
        } & keys or "attestation" in str(entry.get("reason") or "").lower():
            out.append(entry)
    return out


def _compute_bundle_digest(payload: dict[str, Any]) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return f"sha256:{hashlib.sha256(canonical.encode()).hexdigest()}"


def _parse_iso_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    text = value.strip()
    if not text:
        return None
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed
    except Exception:
        return None


def _is_production_env() -> bool:
    return (os.getenv("SARDIS_ENVIRONMENT", "dev") or "dev").strip().lower() in {"prod", "production"}


def _evidence_signing_secret() -> str:
    return (os.getenv("SARDIS_EVIDENCE_SIGNING_SECRET", "") or "").strip()


def _evidence_signing_key_id() -> str:
    return (os.getenv("SARDIS_EVIDENCE_SIGNING_KEY_ID", "v1") or "v1").strip()


def _evidence_cursor_secret() -> str:
    configured = (os.getenv("SARDIS_EVIDENCE_CURSOR_SECRET", "") or "").strip()
    if configured:
        return configured
    signing_secret = _evidence_signing_secret()
    if signing_secret:
        return signing_secret
    if _is_production_env():
        raise RuntimeError("evidence_cursor_secret_not_configured")
    return "dev-insecure-evidence-cursor-secret"


def _encode_evidence_cursor(payload: dict[str, Any]) -> str:
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    signature = hmac.new(
        _evidence_cursor_secret().encode(),
        canonical.encode(),
        hashlib.sha256,
    ).hexdigest()
    envelope = {
        "v": 1,
        "payload": payload,
        "sig": signature,
    }
    encoded = base64.urlsafe_b64encode(
        json.dumps(envelope, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).decode()
    return encoded.rstrip("=")


def _decode_evidence_cursor(token: str) -> dict[str, Any]:
    raw = (token or "").strip()
    if not raw:
        raise ValueError("invalid_cursor")
    padded = raw + "=" * (-len(raw) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode()).decode()
        envelope = json.loads(decoded)
    except Exception as exc:
        raise ValueError("invalid_cursor") from exc
    if not isinstance(envelope, dict) or envelope.get("v") != 1:
        raise ValueError("invalid_cursor")
    payload = envelope.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("invalid_cursor_payload")
    signature = str(envelope.get("sig", ""))
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    expected = hmac.new(
        _evidence_cursor_secret().encode(),
        canonical.encode(),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(signature, expected):
        raise ValueError("invalid_cursor_signature")
    return payload


def _entry_sort_key(entry: dict[str, Any]) -> tuple[datetime, str]:
    evaluated = _parse_iso_datetime(str(entry.get("evaluated_at", "")))
    if evaluated is None:
        evaluated = datetime.fromtimestamp(0, tz=timezone.utc)
    return evaluated, str(entry.get("audit_id", ""))


def _build_evidence_signature(payload: dict[str, Any]) -> dict[str, Any]:
    secret = _evidence_signing_secret()
    if not secret:
        raise RuntimeError("evidence_signing_secret_not_configured")
    from jwt import encode as jwt_encode

    issued_at = int(time.time())
    envelope = {
        "iss": "sardis-api",
        "iat": issued_at,
        "evidence": payload,
    }
    kid = _evidence_signing_key_id()
    token = jwt_encode(envelope, secret, algorithm="HS256", headers={"kid": kid, "typ": "JWT"})
    return {
        "alg": "HS256",
        "kid": kid,
        "issued_at": issued_at,
        "token": token,
    }


def _require_kya_service(deps: ComplianceDependencies):
    if deps.kya_service is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="kya_service_not_configured",
        )
    return deps.kya_service


# ============================================================================
# KYC Endpoints
# ============================================================================

@router.post("/kyc/verify", response_model=KYCInquiryResponse)
async def create_kyc_verification(
    request: KYCVerificationRequest,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Create a new KYC verification inquiry for an agent.

    This initiates the KYC flow. The returned session_token and redirect_url
    can be used to embed the verification in your frontend.
    """
    try:
        session = await deps.kyc_service.create_verification(
            agent_id=request.agent_id,
            name_first=request.name_first,
            name_last=request.name_last,
            email=request.email,
        )

        return KYCInquiryResponse(
            inquiry_id=session.inquiry_id,
            session_token=session.session_token,
            redirect_url=session.redirect_url,
            status=session.status.value,
        )

    except Exception as e:
        logger.error(f"Failed to create KYC verification: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create KYC verification: {str(e)}",
        )


@router.get("/kyc/{agent_id}", response_model=KYCStatusResponse)
async def get_kyc_status(
    agent_id: str,
    force_refresh: bool = False,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Get the KYC verification status for an agent.

    Returns the current verification status, including any warnings
    about upcoming expiration.
    """
    try:
        result = await deps.kyc_service.check_verification(
            agent_id=agent_id,
            force_refresh=force_refresh,
        )

        # Check for expiration warning
        warning = await deps.kyc_service.get_expiration_warning(agent_id)

        return KYCStatusResponse(
            agent_id=agent_id,
            status=result.effective_status.value,
            verification_id=result.verification_id,
            is_verified=result.is_verified,
            verified_at=result.verified_at.isoformat() if result.verified_at else None,
            expires_at=result.expires_at.isoformat() if result.expires_at else None,
            provider=result.provider,
            warning=warning,
        )

    except Exception as e:
        logger.error(f"Failed to get KYC status: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get KYC status: {str(e)}",
        )


@router.get("/kyc/{agent_id}/required")
async def check_kyc_required(
    agent_id: str,
    amount_minor: int,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Check if KYC is required for a transaction.

    Returns whether the agent needs to complete KYC verification
    before proceeding with the transaction.
    """
    required = await deps.kyc_service.is_kyc_required(agent_id, amount_minor)

    return {
        "agent_id": agent_id,
        "amount_minor": amount_minor,
        "kyc_required": required,
        "message": "KYC verification required before transaction" if required else "KYC not required",
    }


# ============================================================================
# KYA Endpoints
# ============================================================================

@router.post("/kya/register")
async def register_kya_agent(
    request: KYARegisterRequest,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Register an agent manifest for KYA enforcement."""
    kya_service = _require_kya_service(deps)
    try:
        from sardis_compliance.kya import AgentManifest

        manifest = AgentManifest(
            agent_id=request.agent_id,
            owner_id=request.owner_id,
            capabilities=request.capabilities,
            max_budget_per_tx=Decimal(request.max_budget_per_tx),
            daily_budget=Decimal(request.daily_budget),
            allowed_domains=request.allowed_domains,
            blocked_domains=request.blocked_domains,
            framework=request.framework,
            framework_version=request.framework_version,
            description=request.description,
            metadata=request.metadata,
        )
        result = await kya_service.register_agent(manifest)
        return result.to_dict()
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Failed to register KYA agent %s: %s", request.agent_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to register KYA agent: {exc}",
        ) from exc


@router.get("/kya/{agent_id}")
async def get_kya_status(
    agent_id: str,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """Get current KYA status for an agent."""
    kya_service = _require_kya_service(deps)
    manifest = await kya_service.get_manifest_async(agent_id)
    if manifest is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="agent_not_registered")
    trust_score = await kya_service.get_trust_score(agent_id)
    level = await kya_service.get_level_async(agent_id)
    kya_status = await kya_service.get_status_async(agent_id)
    is_alive = await kya_service.is_alive_async(agent_id)
    return {
        "agent_id": agent_id,
        "owner_id": manifest.owner_id,
        "level": level.value,
        "status": kya_status.value,
        "manifest_hash": manifest.manifest_hash,
        "capabilities": manifest.capabilities,
        "max_budget_per_tx": str(manifest.max_budget_per_tx),
        "daily_budget": str(manifest.daily_budget),
        "allowed_domains": manifest.allowed_domains,
        "blocked_domains": manifest.blocked_domains,
        "trust_score": trust_score.score if trust_score else None,
        "is_alive": is_alive,
    }


@router.post("/kya/{agent_id}/check")
async def check_kya_for_payment(
    agent_id: str,
    request: KYACheckRequestModel,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """Evaluate KYA policy for a potential payment."""
    kya_service = _require_kya_service(deps)
    try:
        from sardis_compliance.kya import KYACheckRequest

        result = await kya_service.check_agent(
            KYACheckRequest(
                agent_id=agent_id,
                amount=Decimal(request.amount),
                merchant_id=request.merchant_id,
                merchant_domain=request.merchant_domain,
            )
        )
        return result.to_dict()
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("/kya/{agent_id}/upgrade")
async def upgrade_kya_level(
    agent_id: str,
    request: KYAUpgradeRequest,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Upgrade KYA level for an agent (verified/attested workflows)."""
    kya_service = _require_kya_service(deps)
    try:
        from sardis_compliance.kya import CodeAttestation, KYALevel

        target_level = KYALevel(request.target_level.strip().lower())
        code_attestation = None
        if target_level == KYALevel.ATTESTED:
            if not request.code_hash:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="code_hash_required_for_attested_upgrade",
                )
            code_attestation = CodeAttestation(
                code_hash=request.code_hash,
                framework=request.framework,
                version=request.version,
                attester=request.attester,
            )
        result = await kya_service.upgrade_level(
            agent_id=agent_id,
            target_level=target_level,
            anchor_verification_id=request.anchor_verification_id,
            code_attestation=code_attestation,
        )
        return result.to_dict()
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("/kya/{agent_id}/suspend")
async def suspend_kya_agent(
    agent_id: str,
    request: KYASuspendRequest,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Suspend an agent's KYA status."""
    kya_service = _require_kya_service(deps)
    result = await kya_service.suspend_agent(agent_id=agent_id, reason=request.reason)
    return result.to_dict()


@router.post("/kya/{agent_id}/reactivate")
async def reactivate_kya_agent(
    agent_id: str,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Reactivate a suspended agent."""
    kya_service = _require_kya_service(deps)
    result = await kya_service.reactivate_agent(agent_id=agent_id)
    return result.to_dict()


@router.post("/kya/{agent_id}/heartbeat")
async def heartbeat_kya_agent(
    agent_id: str,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """Record an agent heartbeat for KYA liveness tracking."""
    kya_service = _require_kya_service(deps)
    await kya_service.ping_async(agent_id)
    is_alive = await kya_service.is_alive_async(agent_id)
    kya_status = await kya_service.get_status_async(agent_id)
    return {
        "agent_id": agent_id,
        "is_alive": is_alive,
        "status": kya_status.value,
    }


@router.post("/kya/stale/sweep")
async def sweep_stale_kya_agents(
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Suspend stale agents that missed heartbeat deadlines."""
    kya_service = _require_kya_service(deps)
    suspended = await kya_service.check_stale_agents()
    return {
        "suspended_agents": suspended,
        "count": len(suspended),
    }


# ============================================================================
# Sanctions Screening Endpoints
# ============================================================================

@router.post("/sanctions/screen", response_model=SanctionsScreenResponse)
async def screen_address(
    request: SanctionsScreenRequest,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Screen a wallet address for sanctions.

    Checks the address against OFAC, EU, UN, and other sanctions lists.
    """
    try:
        result = await deps.sanctions_service.screen_address(
            address=request.address,
            chain=request.chain,
        )

        return SanctionsScreenResponse(
            address=request.address,
            chain=request.chain,
            risk_level=result.risk_level.value,
            is_sanctioned=result.is_sanctioned,
            should_block=result.should_block,
            provider=result.provider,
            matches=result.matches,
            reason=result.reason,
        )

    except Exception as e:
        logger.error(f"Failed to screen address: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to screen address: {str(e)}",
        )


@router.post("/sanctions/screen-transaction", response_model=SanctionsScreenResponse)
async def screen_transaction(
    request: TransactionScreenRequest,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Screen a transaction for sanctions compliance.

    Checks both the sender and recipient addresses.
    """
    try:
        from decimal import Decimal

        result = await deps.sanctions_service.screen_transaction(
            tx_hash=request.tx_hash,
            chain=request.chain,
            from_address=request.from_address,
            to_address=request.to_address,
            amount=Decimal(request.amount),
            token=request.token,
        )

        return SanctionsScreenResponse(
            address=f"{request.from_address} -> {request.to_address}",
            chain=request.chain,
            risk_level=result.risk_level.value,
            is_sanctioned=result.is_sanctioned,
            should_block=result.should_block,
            provider=result.provider,
            matches=result.matches,
            reason=result.reason,
        )

    except Exception as e:
        logger.error(f"Failed to screen transaction: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to screen transaction: {str(e)}",
        )


@router.get("/sanctions/check/{address}")
async def check_address_blocked(
    address: str,
    chain: str = "ethereum",
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Quick check if an address is blocked.

    Faster than full screening for simple allow/block decisions.
    """
    is_blocked = await deps.sanctions_service.is_blocked(address, chain)

    return {
        "address": address,
        "chain": chain,
        "is_blocked": is_blocked,
        "message": "Address is blocked by sanctions" if is_blocked else "Address is not blocked",
    }


@router.post("/sanctions/block")
async def block_address(
    address: str,
    reason: str,
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Add an address to the internal blocklist.

    This is for manual blocking based on internal risk assessment.
    """
    success = await deps.sanctions_service.block_address(address, reason)

    if success:
        return {
            "success": True,
            "address": address,
            "message": f"Address blocked: {reason}",
        }
    else:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to block address",
        )


# ============================================================================
# Compliance Status Endpoint
# ============================================================================

@router.get("/status")
async def get_compliance_status(
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Get overall compliance system status.

    Shows which providers are configured and their status.
    """
    return {
        "kyc": {
            "provider": deps.kyc_service._provider.__class__.__name__,
            "is_mock": "Mock" in deps.kyc_service._provider.__class__.__name__,
            "threshold": deps.kyc_service._require_kyc_above,
        },
        "sanctions": {
            "provider": deps.sanctions_service._provider.__class__.__name__,
            "is_mock": "Mock" in deps.sanctions_service._provider.__class__.__name__,
            "cache_ttl": deps.sanctions_service._cache_ttl,
        },
        "kya": {
            "enabled": deps.kya_service is not None,
            "provider": deps.kya_service.__class__.__name__ if deps.kya_service is not None else None,
        },
        "audit": {
            "store": deps.audit_store.__class__.__name__ if deps.audit_store is not None else None,
            "supports_chain_verification": bool(
                deps.audit_store is not None
                and callable(getattr(deps.audit_store, "verify_chain_integrity", None))
            ),
        },
        "environment": os.getenv("SARDIS_ENVIRONMENT", "development"),
        "message": (
            "Using production providers"
            if not ("Mock" in deps.kyc_service._provider.__class__.__name__)
            else "Using mock providers for development"
        ),
    }


@router.get("/audit/mandate/{mandate_id}")
async def get_mandate_audit_trail(
    mandate_id: str,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Return immutable compliance audit entries for a mandate with deterministic digest."""
    if deps.audit_store is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="audit_store_not_configured",
        )

    entries = await _resolve_maybe_awaitable(deps.audit_store.get_by_mandate(mandate_id))
    serialized = [_serialize_audit_entry(entry) for entry in entries]
    return {
        "mandate_id": mandate_id,
        "count": len(serialized),
        "entries_digest": _compute_audit_entries_digest(serialized),
        "entries": serialized,
    }


@router.get("/audit/recent")
async def get_recent_audit_entries(
    limit: int = Query(default=100, ge=1, le=1000),
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Return recent compliance audit entries for operational monitoring."""
    if deps.audit_store is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="audit_store_not_configured",
        )
    entries = await _resolve_maybe_awaitable(deps.audit_store.get_recent(limit))
    serialized = [_serialize_audit_entry(entry) for entry in entries]
    return {
        "limit": limit,
        "count": len(serialized),
        "entries_digest": _compute_audit_entries_digest(serialized),
        "entries": serialized,
    }


@router.get("/audit/evidence/export")
async def export_audit_evidence_bundle(
    mandate_id: Optional[str] = Query(default=None),
    approval_id: Optional[str] = Query(default=None),
    limit: int = Query(default=500, ge=1, le=5000),
    page_size: int = Query(default=250, ge=1, le=1000),
    cursor: Optional[str] = Query(default=None, description="Opaque replay-safe pagination cursor"),
    start_at: Optional[str] = Query(default=None, description="Inclusive ISO8601 lower bound for evaluated_at"),
    end_at: Optional[str] = Query(default=None, description="Inclusive ISO8601 upper bound for evaluated_at"),
    include_signature: bool = Query(default=False),
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """
    Export a unified evidence bundle for policy/approval/audit verification.

    This endpoint is intentionally append-only friendly:
    - Pulls immutable audit entries from the compliance audit store.
    - Adds optional approval artifact (if configured and requested).
    - Returns deterministic integrity summaries for third-party verification.
    """
    if deps.audit_store is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="audit_store_not_configured",
        )
    if not mandate_id and not approval_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="mandate_id_or_approval_id_required",
        )

    if mandate_id:
        entries = await _resolve_maybe_awaitable(deps.audit_store.get_by_mandate(mandate_id))
    else:
        entries = await _resolve_maybe_awaitable(deps.audit_store.get_recent(limit))
    serialized = [_serialize_audit_entry(entry) for entry in entries]
    start_dt = _parse_iso_datetime(start_at)
    end_dt = _parse_iso_datetime(end_at)
    if (start_at and start_dt is None) or (end_at and end_dt is None):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="invalid_time_window",
        )
    if start_dt is not None or end_dt is not None:
        windowed: list[dict[str, Any]] = []
        for entry in serialized:
            evaluated = _parse_iso_datetime(str(entry.get("evaluated_at", "")))
            if evaluated is None:
                continue
            if start_dt is not None and evaluated < start_dt:
                continue
            if end_dt is not None and evaluated > end_dt:
                continue
            windowed.append(entry)
        serialized = windowed
    serialized.sort(key=_entry_sort_key, reverse=True)

    scope_payload = {
        "mandate_id": mandate_id,
        "approval_id": approval_id,
        "limit": limit,
        "start_at": start_at,
        "end_at": end_at,
        "page_size": page_size,
    }
    scope_hash = _hash_json(scope_payload)
    cursor_snapshot_at: datetime = datetime.now(timezone.utc)
    cursor_last_key: Optional[tuple[datetime, str]] = None

    if cursor:
        try:
            cursor_payload = _decode_evidence_cursor(cursor)
        except RuntimeError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=str(exc),
            ) from exc
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(exc),
            ) from exc

        if str(cursor_payload.get("scope_hash", "")) != scope_hash:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="cursor_scope_mismatch",
            )
        cursor_snapshot_at = _parse_iso_datetime(str(cursor_payload.get("snapshot_at", "")))  # type: ignore[assignment]
        if cursor_snapshot_at is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="invalid_cursor_snapshot",
            )
        last_key = cursor_payload.get("last_key")
        if not isinstance(last_key, dict):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="invalid_cursor_last_key",
            )
        last_key_dt = _parse_iso_datetime(str(last_key.get("evaluated_at", "")))
        last_key_audit_id = str(last_key.get("audit_id", ""))
        if last_key_dt is None or not last_key_audit_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="invalid_cursor_last_key",
            )
        cursor_last_key = (last_key_dt, last_key_audit_id)

    stable_entries = [
        entry
        for entry in serialized
        if _entry_sort_key(entry)[0] <= cursor_snapshot_at
    ]
    if cursor_last_key is not None:
        stable_entries = [
            entry
            for entry in stable_entries
            if _entry_sort_key(entry) < cursor_last_key
        ]

    has_more = len(stable_entries) > page_size
    serialized = stable_entries[:page_size]

    next_cursor: Optional[str] = None
    if has_more and serialized:
        last_dt, last_audit_id = _entry_sort_key(serialized[-1])
        cursor_payload = {
            "scope_hash": scope_hash,
            "snapshot_at": cursor_snapshot_at.isoformat(),
            "last_key": {
                "evaluated_at": last_dt.isoformat(),
                "audit_id": last_audit_id,
            },
        }
        try:
            next_cursor = _encode_evidence_cursor(cursor_payload)
        except RuntimeError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=str(exc),
            ) from exc

    policy_entries = [
        entry for entry in serialized if str(entry.get("provider", "")).strip().lower() == "policy_engine"
    ]
    attestation_entries = _attestation_candidates(serialized)

    approval_record: Optional[dict[str, Any]] = None
    if approval_id and deps.approval_service is not None:
        getter = getattr(deps.approval_service, "get_approval", None)
        if callable(getter):
            approval = await _resolve_maybe_awaitable(getter(approval_id))
            if approval is not None:
                approval_record = _serialize_approval(approval)

    approval_related_entries = []
    for entry in serialized:
        metadata = entry.get("metadata") or {}
        if not isinstance(metadata, dict):
            continue
        if approval_id and str(metadata.get("approval_id", "")) == approval_id:
            approval_related_entries.append(entry)

    leaves = [_hash_json(entry) for entry in serialized]
    merkle_root = _build_merkle_root(leaves)
    entries_digest = _compute_audit_entries_digest(serialized)
    hash_chain = _build_hash_chain_summary(serialized)

    generated_at = datetime.now(timezone.utc).isoformat()
    counts = {
        "total_entries": len(serialized),
        "policy_entries": len(policy_entries),
        "approval_related_entries": len(approval_related_entries),
        "attestation_entries": len(attestation_entries),
        "has_approval_artifact": approval_record is not None,
    }
    verifier_hints = [
        "Verify entries_digest against canonical JSON of entries",
        "Verify merkle root from leaf hashes to prove inclusion",
        "Verify hash_chain head by replaying prev_hash chain from genesis",
    ]
    if mandate_id:
        verifier_hints.append("Cross-check mandate_id scope against payment/control plane event logs")
    if approval_id:
        verifier_hints.append("Cross-check approval_id against approval service export/logs")

    chain_verification: dict[str, Any] = {
        "supported_by_store": False,
        "verified": None,
        "error": None,
    }
    verifier = getattr(deps.audit_store, "verify_chain_integrity", None)
    if callable(verifier):
        verification_result = await _resolve_maybe_awaitable(verifier())
        chain_verification["supported_by_store"] = True
        if isinstance(verification_result, tuple) and len(verification_result) >= 2:
            chain_verification["verified"] = bool(verification_result[0])
            chain_verification["error"] = verification_result[1]
        elif isinstance(verification_result, bool):
            chain_verification["verified"] = verification_result
        else:
            chain_verification["verified"] = None
            chain_verification["error"] = "unexpected_verifier_result"

    bundle_digest = _compute_bundle_digest(
        {
            "generated_at": generated_at,
            "scope": {
                "mandate_id": mandate_id,
                "approval_id": approval_id,
                "limit": limit,
                "page_size": page_size,
                "cursor": cursor,
                "start_at": start_at,
                "end_at": end_at,
            },
            "pagination": {
                "snapshot_at": cursor_snapshot_at.isoformat(),
                "has_more": has_more,
                "next_cursor": next_cursor,
            },
            "counts": counts,
            "entries_digest": entries_digest,
            "merkle_root": merkle_root,
            "hash_chain_head": hash_chain.get("head"),
            "chain_verification": chain_verification,
        }
    )

    response_payload = {
        "metadata": {
            "generated_at": generated_at,
            "scope": {
                "mandate_id": mandate_id,
                "approval_id": approval_id,
                "limit": limit,
                "page_size": page_size,
                "cursor": cursor,
                "start_at": start_at,
                "end_at": end_at,
            },
            "pagination": {
                "returned": len(serialized),
                "has_more": has_more,
                "next_cursor": next_cursor,
                "snapshot_at": cursor_snapshot_at.isoformat(),
                "replay_safe": True,
            },
            "counts": counts,
            "hints_version": "evidence-v1",
            "verifier_hints": verifier_hints,
        },
        "integrity": {
            "bundle_digest": bundle_digest,
            "entries_digest": entries_digest,
            "merkle_root": f"merkle::{merkle_root}" if merkle_root else None,
            "leaf_count": len(leaves),
            "hash_chain": hash_chain,
            "chain_verification": chain_verification,
        },
        "artifacts": {
            "approval": approval_record,
            "policy_decisions": policy_entries,
            "attestations": attestation_entries,
            "approval_related_entries": approval_related_entries,
            "audit_entries": serialized,
        },
    }
    if include_signature:
        sign_payload = {
            "metadata": response_payload["metadata"],
            "integrity": response_payload["integrity"],
        }
        try:
            response_payload["signature"] = _build_evidence_signature(sign_payload)
        except RuntimeError as exc:
            if _is_production_env():
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail=str(exc),
                ) from exc
            response_payload["signature"] = {
                "error": str(exc),
            }
    return response_payload


@router.get("/audit/verify-chain")
async def verify_audit_chain_integrity(
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Verify append-only hash-chain integrity for compliance audit storage."""
    if deps.audit_store is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="audit_store_not_configured",
        )

    verifier = getattr(deps.audit_store, "verify_chain_integrity", None)
    entry_count = None
    if callable(getattr(deps.audit_store, "count", None)):
        entry_count = await _resolve_maybe_awaitable(deps.audit_store.count())

    if not callable(verifier):
        return {
            "supported": False,
            "verified": None,
            "error": "chain_verification_not_supported_by_store",
            "entry_count": entry_count,
        }

    verification_result = await _resolve_maybe_awaitable(verifier())
    verified: Optional[bool]
    error: Optional[str]
    if isinstance(verification_result, tuple) and len(verification_result) >= 2:
        verified = bool(verification_result[0])
        error = verification_result[1]
    elif isinstance(verification_result, bool):
        verified = verification_result
        error = None
    else:
        verified = None
        error = "unexpected_verifier_result"

    return {
        "supported": True,
        "verified": verified,
        "error": error,
        "entry_count": entry_count,
    }


@router.post("/audit/evidence/verify-signature")
async def verify_evidence_signature(
    payload: EvidenceSignatureVerifyRequest,
    _: Principal = Depends(require_admin_principal),
):
    """Verify a signed evidence bundle JWS produced by export endpoint."""
    secret = _evidence_signing_secret()
    if not secret:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="evidence_signing_secret_not_configured",
        )

    from jwt import decode as jwt_decode, get_unverified_header
    from jwt.exceptions import InvalidTokenError

    try:
        header = get_unverified_header(payload.token)
        decoded = jwt_decode(
            payload.token,
            secret,
            algorithms=["HS256"],
            options={"require": ["iss", "iat", "evidence"]},
        )
    except InvalidTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid_signature:{exc}",
        ) from exc

    evidence_payload = decoded.get("evidence")
    if not isinstance(evidence_payload, dict):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="invalid_signature_payload",
        )

    integrity = evidence_payload.get("integrity") or {}
    if not isinstance(integrity, dict):
        integrity = {}
    bundle_digest = integrity.get("bundle_digest")

    if payload.expected_bundle_digest and bundle_digest != payload.expected_bundle_digest:
        return {
            "valid": False,
            "reason": "bundle_digest_mismatch",
            "expected_bundle_digest": payload.expected_bundle_digest,
            "actual_bundle_digest": bundle_digest,
            "kid": header.get("kid"),
            "alg": header.get("alg"),
        }

    return {
        "valid": True,
        "kid": header.get("kid"),
        "alg": header.get("alg"),
        "bundle_digest": bundle_digest,
        "issued_at": decoded.get("iat"),
        "issuer": decoded.get("iss"),
    }


@router.get("/audit/mandate/{mandate_id}/proof/{audit_id}")
async def get_mandate_audit_proof(
    mandate_id: str,
    audit_id: str,
    deps: ComplianceDependencies = Depends(get_deps),
    _: Principal = Depends(require_admin_principal),
):
    """Return Merkle inclusion proof for one audit entry within a mandate audit set."""
    if deps.audit_store is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="audit_store_not_configured",
        )

    entries = await _resolve_maybe_awaitable(deps.audit_store.get_by_mandate(mandate_id))
    serialized = [_serialize_audit_entry(entry) for entry in entries]
    if not serialized:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="mandate_audit_not_found",
        )

    target_index = next(
        (idx for idx, entry in enumerate(serialized) if str(entry.get("audit_id", "")) == audit_id),
        None,
    )
    if target_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="audit_id_not_found_for_mandate",
        )

    leaves = [_hash_json(entry) for entry in serialized]
    leaf_hash = leaves[target_index]
    merkle_root = _build_merkle_root(leaves)
    proof = _build_merkle_proof(leaves, target_index)
    verified = _verify_merkle_proof(leaf_hash, proof, merkle_root)

    return {
        "mandate_id": mandate_id,
        "audit_id": audit_id,
        "entry": serialized[target_index],
        "leaf_hash": leaf_hash,
        "merkle_root": f"merkle::{merkle_root}",
        "proof": proof,
        "proof_verified": verified,
        "entry_count": len(serialized),
    }


# ============================================================================
# Persona Webhook Endpoints (with HMAC verification)
# ============================================================================

class PersonaWebhookPayload(BaseModel):
    """Persona webhook event payload."""
    data: dict
    included: Optional[List[dict]] = None


@public_router.post("/webhooks/persona")
async def handle_persona_webhook(
    request: Request,
    verified_body: bytes = Depends(verify_persona_webhook),
    deps: ComplianceDependencies = Depends(get_deps),
):
    """
    Handle Persona KYC webhook events.

    SECURITY: This endpoint verifies the HMAC signature before processing.
    Unsigned or invalid webhooks are rejected with 401.

    Supported events:
    - inquiry.completed: KYC verification completed
    - inquiry.expired: KYC verification expired
    - inquiry.failed: KYC verification failed
    - inquiry.approved: KYC verification approved
    - inquiry.declined: KYC verification declined

    Persona Webhook Docs: https://docs.withpersona.com/docs/webhooks
    """
    try:
        # Parse the verified payload
        payload = json.loads(verified_body)
        event_type = payload.get("data", {}).get("attributes", {}).get("name", "")
        inquiry_data = payload.get("data", {})
        inquiry_id = inquiry_data.get("id", "")

        async def _process() -> dict:
            logger.info(
                f"Persona webhook received: event={event_type}, inquiry={inquiry_id}"
            )

            # Process based on event type
            if event_type in ("inquiry.completed", "inquiry.approved"):
                # KYC completed successfully
                await deps.kyc_service.handle_webhook(
                    event_type="inquiry.completed",
                    payload=payload,
                )
                logger.info(f"KYC inquiry {inquiry_id} completed successfully")

            elif event_type == "inquiry.expired":
                # KYC verification expired
                await deps.kyc_service.handle_webhook(
                    event_type="inquiry.expired",
                    payload=payload,
                )
                logger.info(f"KYC inquiry {inquiry_id} expired")

            elif event_type in ("inquiry.failed", "inquiry.declined"):
                # KYC verification failed
                await deps.kyc_service.handle_webhook(
                    event_type="inquiry.completed",
                    payload=payload,
                )
                logger.warning(f"KYC inquiry {inquiry_id} failed/declined")

            elif event_type == "inquiry.created":
                # New inquiry created - just log
                logger.info(f"KYC inquiry {inquiry_id} created")

            else:
                # Unknown event type - log but don't fail
                logger.warning(f"Unknown Persona webhook event: {event_type}")

            return {
                "success": True,
                "event": event_type,
                "inquiry_id": inquiry_id,
            }

        return await run_with_replay_protection(
            request=request,
            provider="persona",
            event_id=f"{event_type}:{inquiry_id}",
            body=verified_body,
            ttl_seconds=7 * 24 * 60 * 60,
            response_on_duplicate={
                "success": True,
                "event": event_type,
                "inquiry_id": inquiry_id,
            },
            fn=_process,
        )

    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse Persona webhook payload: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid JSON payload",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing Persona webhook: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Webhook processing error: {str(e)}",
        )


@router.get("/webhooks/persona/verify")
async def verify_persona_webhook_config(
    _: Principal = Depends(require_admin_principal),
):
    """
    Check if Persona webhook verification is properly configured.

    Returns the configuration status without exposing the secret.
    """
    secret = get_persona_webhook_secret()
    is_configured = secret is not None

    return {
        "configured": is_configured,
        "signature_header": WebhookSecurityConfig.PERSONA_SIGNATURE_HEADER,
        "max_timestamp_age_seconds": WebhookSecurityConfig.MAX_TIMESTAMP_AGE_SECONDS,
        "message": (
            "Persona webhook verification is configured"
            if is_configured
            else "WARNING: PERSONA_WEBHOOK_SECRET not set - webhooks will be rejected"
        ),
    }
