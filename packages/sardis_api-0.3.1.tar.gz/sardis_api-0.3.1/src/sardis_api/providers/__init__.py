"""External provider adapters for sardis-api."""

