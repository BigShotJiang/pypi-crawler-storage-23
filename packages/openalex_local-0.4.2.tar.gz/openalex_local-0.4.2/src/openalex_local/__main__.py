"""Allow running as python -m openalex_local."""

from .cli import main

if __name__ == "__main__":
    main()
