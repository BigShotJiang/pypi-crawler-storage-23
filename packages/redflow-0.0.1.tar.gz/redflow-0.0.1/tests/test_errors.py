"""Test error serialization for cross-language wire compat."""

from redflow.errors import (
    CanceledError,
    InputValidationError,
    NonRetriableError,
    OutputSerializationError,
    RedflowError,
    TimeoutError,
    UnknownWorkflowError,
    serialize_error,
)


def test_serialize_redflow_error() -> None:
    err = RedflowError("something went wrong")
    result = serialize_error(err)
    assert result["name"] == "RedflowError"
    assert result["message"] == "something went wrong"
    assert result["kind"] == "error"


def test_serialize_canceled_error() -> None:
    err = CanceledError("user asked to stop")
    result = serialize_error(err)
    assert result["kind"] == "canceled"


def test_serialize_timeout_error() -> None:
    err = TimeoutError("took too long")
    result = serialize_error(err)
    assert result["kind"] == "timeout"


def test_serialize_validation_error() -> None:
    err = InputValidationError("bad input", issues=[{"field": "name"}])
    result = serialize_error(err)
    assert result["kind"] == "validation"


def test_serialize_unknown_workflow() -> None:
    err = UnknownWorkflowError("missing-wf")
    result = serialize_error(err)
    assert result["kind"] == "unknown_workflow"
    assert "missing-wf" in result["message"]


def test_serialize_output_error() -> None:
    err = OutputSerializationError("not serializable")
    result = serialize_error(err)
    assert result["kind"] == "serialization"


def test_serialize_non_retriable() -> None:
    err = NonRetriableError("permanent failure")
    result = serialize_error(err)
    assert result["kind"] == "non_retriable"


def test_serialize_standard_exception() -> None:
    err = ValueError("oops")
    result = serialize_error(err)
    assert result["kind"] == "error"
    assert result["name"] == "ValueError"


def test_serialize_non_exception() -> None:
    result = serialize_error("just a string")
    assert result["kind"] == "error"
    assert result["message"] == "just a string"
