"""Worker — polls Redis queues, executes workflows, and manages the run lifecycle.

This module implements the same loops as the TypeScript worker:
  * **worker loop** — BLMOVE claim → process_run with step engine
  * **scheduled promoter** — promotes ``scheduled`` → ``queued`` when due
  * **reaper** — reclaims orphaned runs whose lease expired
  * **cron scheduler** — leader-elected cron trigger loop
  * **watchdog** — detects stuck pollers and restarts them

All loops respect an ``asyncio.Event`` for graceful shutdown.
"""

from __future__ import annotations

import asyncio
import builtins
import contextlib
import logging
import os
import uuid
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from redis.asyncio import Redis

from . import _keys as K
from ._json import safe_json_dumps, safe_json_loads, safe_json_try_loads
from ._lua_scripts import (
    ALL_SCRIPTS,
    CLAIM_QUEUED_RUN_FOR_INLINE,
    RENEW_LEASE,
    REQUEUE_DUE_TO_CONCURRENCY,
    UNLOCK,
)
from ._time import now_ms
from .client import (
    RedflowClient,
    _decode,
    _normalize_max_concurrency,
    compute_retry_delay_ms,
    create_client,
    default_prefix,
    is_retryable_error,
    make_error_json,
)
from .errors import (
    CanceledError,
    OutputSerializationError,
    RedflowError,
    TimeoutError,
    UnknownWorkflowError,
)
from .registry import WorkflowHandlerContext, WorkflowRegistry, _RunInfo, get_default_registry
from .types import DEFAULT_MAX_ATTEMPTS, RunStatus

logger = logging.getLogger("redflow")

_debug_enabled = os.environ.get("REDFLOW_LOG") == "1"


def _dbg(msg: str) -> None:
    if _debug_enabled:
        logger.debug(msg)


_POLL_MS = 250


# ---------- types ----------


@dataclass(slots=True)
class StartWorkerOptions:
    app: str
    redis: Redis[Any] | None = None
    url: str | None = None
    prefix: str | None = None
    registry: WorkflowRegistry | None = None
    queues: list[str] | None = None
    concurrency: int = 1
    lease_ms: int = 5000
    blmove_timeout_sec: int = 1
    reaper_interval_ms: int = 500
    watchdog_enabled: bool = True
    watchdog_interval_ms: int = 1000
    watchdog_stalled_for_ms: int = 15_000


class WorkerHandle:
    """Handle returned by ``start_worker`` for graceful shutdown."""

    def __init__(
        self,
        stop_event: asyncio.Event,
        tasks: list[asyncio.Task[None]],
        owned_redis: list[Redis[Any]],
        slots: list[Any] | None = None,
    ) -> None:
        self._stop_event = stop_event
        self._tasks = tasks
        self._owned_redis = owned_redis
        self._slots = slots or []

    async def stop(self) -> None:
        self._stop_event.set()
        all_tasks: list[asyncio.Task[None]] = list(self._tasks)
        for slot in self._slots:
            if slot.task and slot.task not in all_tasks:
                all_tasks.append(slot.task)
        await asyncio.gather(*all_tasks, return_exceptions=True)
        for r in self._owned_redis:
            with contextlib.suppress(Exception):
                await r.aclose()


# ---------- worker slot health tracking ----------


@dataclass(slots=True)
class _WorkerHealth:
    index: int
    last_progress_at: int = field(default_factory=now_ms)
    in_flight_since: int | None = None
    in_flight_command: str | None = None
    in_flight_queue: str | None = None
    restart_count: int = 0


def _mark_progress(h: _WorkerHealth) -> None:
    h.last_progress_at = now_ms()


def _track_in_flight(h: _WorkerHealth, command: str, queue: str) -> None:
    h.in_flight_command = command
    h.in_flight_queue = queue
    h.in_flight_since = now_ms()


def _clear_in_flight(h: _WorkerHealth) -> None:
    h.in_flight_command = None
    h.in_flight_queue = None
    h.in_flight_since = None
    _mark_progress(h)


@dataclass(slots=True)
class _WorkerSlot:
    index: int
    redis: Redis[Any]
    client: RedflowClient
    health: _WorkerHealth
    cancel_scope: asyncio.Event
    task: asyncio.Task[None] | None = None
    restarting: bool = False


# ---------- start_worker ----------


async def start_worker(options: StartWorkerOptions) -> WorkerHandle:
    """Launch the redflow worker — returns a handle with a ``stop()`` method."""
    app = options.app.strip()
    if not app:
        raise ValueError("start_worker requires a non-empty options.app")

    registry = options.registry or get_default_registry()
    prefix = options.prefix or default_prefix()
    concurrency = max(1, options.concurrency)
    lease_ms = max(100, options.lease_ms)
    blmove_timeout_sec = options.blmove_timeout_sec
    reaper_interval_ms = options.reaper_interval_ms
    watchdog_enabled = options.watchdog_enabled
    watchdog_interval_ms = max(250, options.watchdog_interval_ms)
    watchdog_stalled_for_ms = max(watchdog_interval_ms * 2, options.watchdog_stalled_for_ms)

    base_redis: Redis[Any]
    owns_base = False
    if options.redis:
        base_redis = options.redis
    elif options.url:
        base_redis = Redis.from_url(options.url)
        owns_base = True
    else:
        base_redis = Redis.from_url(os.environ.get("REDIS_URL", "redis://localhost:6379"))
        owns_base = True

    stop_event = asyncio.Event()
    tasks: list[asyncio.Task[None]] = []
    owned_redis: list[Redis[Any]] = []
    worker_slots: list[_WorkerSlot] = []

    # Preload Lua scripts into Redis cache
    for script in ALL_SCRIPTS:
        await script.preload(base_redis)

    sync_client = create_client(redis=base_redis, prefix=prefix)
    queues = options.queues or _derive_queues(registry)

    try:
        await sync_client.sync_registry(registry, app=app)

        _dbg(f"start_worker app={app} queues={queues} concurrency={concurrency} lease_ms={lease_ms}")

        if not queues:
            logger.warning("redflow: worker started with zero queues; polling is disabled")

        # Worker loops — one Redis connection per slot
        for i in range(concurrency):
            slot = await _create_worker_slot(i + 1, base_redis, prefix, owned_redis)
            worker_slots.append(slot)
            task = asyncio.create_task(
                _worker_loop(
                    slot=slot,
                    registry=registry,
                    prefix=prefix,
                    queues=queues,
                    blmove_timeout_sec=blmove_timeout_sec,
                    lease_ms=lease_ms,
                    stop_event=stop_event,
                ),
                name=f"redflow-worker-{i + 1}",
            )
            slot.task = task
            tasks.append(task)

        # Watchdog
        if watchdog_enabled and queues and worker_slots:
            wd_redis = base_redis.client()
            owned_redis.append(wd_redis)
            tasks.append(
                asyncio.create_task(
                    _poller_watchdog_loop(
                        redis=wd_redis,
                        prefix=prefix,
                        queues=queues,
                        slots=worker_slots,
                        check_interval_ms=watchdog_interval_ms,
                        stalled_for_ms=watchdog_stalled_for_ms,
                        stop_event=stop_event,
                        base_redis=base_redis,
                        owned_redis=owned_redis,
                        registry=registry,
                        lease_ms=lease_ms,
                        blmove_timeout_sec=blmove_timeout_sec,
                    ),
                    name="redflow-watchdog",
                )
            )

        # Promoter
        promoter_redis = base_redis.client()
        owned_redis.append(promoter_redis)
        promoter_client = create_client(redis=promoter_redis, prefix=prefix)
        tasks.append(
            asyncio.create_task(
                _scheduled_promoter_loop(
                    redis=promoter_redis,
                    client=promoter_client,
                    prefix=prefix,
                    queues=queues,
                    stop_event=stop_event,
                ),
                name="redflow-promoter",
            )
        )

        # Reaper
        reaper_redis = base_redis.client()
        owned_redis.append(reaper_redis)
        tasks.append(
            asyncio.create_task(
                _reaper_loop(
                    redis=reaper_redis,
                    prefix=prefix,
                    queues=queues,
                    interval_ms=reaper_interval_ms,
                    stop_event=stop_event,
                ),
                name="redflow-reaper",
            )
        )

        # Cron scheduler
        cron_redis = base_redis.client()
        owned_redis.append(cron_redis)
        cron_client = create_client(redis=cron_redis, prefix=prefix)
        tasks.append(
            asyncio.create_task(
                _cron_scheduler_loop(
                    redis=cron_redis,
                    client=cron_client,
                    prefix=prefix,
                    stop_event=stop_event,
                ),
                name="redflow-cron",
            )
        )

        if owns_base:
            owned_redis.append(base_redis)

        return WorkerHandle(stop_event, tasks, owned_redis, slots=worker_slots)

    except Exception:
        stop_event.set()
        await asyncio.gather(*tasks, return_exceptions=True)
        for r in owned_redis:
            with contextlib.suppress(Exception):
                await r.aclose()
        if owns_base:
            with contextlib.suppress(Exception):
                await base_redis.aclose()
        raise


def _derive_queues(registry: WorkflowRegistry) -> list[str]:
    queues: set[str] = set()
    for defn in registry.list():
        queues.add(defn.options.queue)
    return sorted(queues)


async def _create_worker_slot(
    index: int,
    base_redis: Redis[Any],
    prefix: str,
    owned_redis: list[Redis[Any]],
) -> _WorkerSlot:
    redis = base_redis.client()
    owned_redis.append(redis)
    client = create_client(redis=redis, prefix=prefix)
    return _WorkerSlot(
        index=index,
        redis=redis,
        client=client,
        health=_WorkerHealth(index=index),
        cancel_scope=asyncio.Event(),
    )


# ---------- worker loop ----------


async def _worker_loop(
    *,
    slot: _WorkerSlot,
    registry: WorkflowRegistry,
    prefix: str,
    queues: list[str],
    blmove_timeout_sec: int,
    lease_ms: int,
    stop_event: asyncio.Event,
) -> None:
    redis = slot.redis
    client = slot.client
    health = slot.health
    queue_cursor = 0

    _mark_progress(health)

    while not stop_event.is_set() and not slot.cancel_scope.is_set():
        try:
            if not queues:
                _mark_progress(health)
                await asyncio.sleep(0.025)
                continue

            claim: dict[str, str] | None = None

            # Non-blocking probe across all queues
            for i in range(len(queues)):
                if stop_event.is_set() or slot.cancel_scope.is_set():
                    break
                idx = (queue_cursor + i) % len(queues)
                queue = queues[idx]
                ready_key = K.queue_ready(prefix, queue)
                processing_key = K.queue_processing(prefix, queue)

                _track_in_flight(health, "lmove", queue)
                try:
                    run_id_raw = await redis.lmove(ready_key, processing_key, "RIGHT", "LEFT")
                finally:
                    _clear_in_flight(health)

                if not run_id_raw:
                    continue

                run_id = _decode(run_id_raw)
                _dbg(f"slot#{health.index} lmove claimed run={run_id} queue={queue}")
                claim = {"queue": queue, "processing_key": processing_key, "run_id": run_id}
                queue_cursor = (idx + 1) % len(queues)
                _mark_progress(health)
                break

            # Nothing ready — block on one queue
            if claim is None and not stop_event.is_set() and not slot.cancel_scope.is_set():
                idx = queue_cursor % len(queues)
                queue = queues[idx]
                queue_cursor = (idx + 1) % len(queues)

                ready_key = K.queue_ready(prefix, queue)
                processing_key = K.queue_processing(prefix, queue)

                _track_in_flight(health, "blmove", queue)
                try:
                    run_id_raw = await redis.blmove(ready_key, processing_key, blmove_timeout_sec, "RIGHT", "LEFT")
                finally:
                    _clear_in_flight(health)

                if run_id_raw:
                    run_id = _decode(run_id_raw)
                    _dbg(f"slot#{health.index} blmove claimed run={run_id} queue={queue}")
                    claim = {"queue": queue, "processing_key": processing_key, "run_id": run_id}
                    _mark_progress(health)

            if claim is None:
                _mark_progress(health)
                await asyncio.sleep(0.01)
                continue

            try:
                await _process_run(
                    redis=redis,
                    client=client,
                    registry=registry,
                    prefix=prefix,
                    queues=queues,
                    queue=claim["queue"],
                    run_id=claim["run_id"],
                    processing_key=claim["processing_key"],
                    lease_ms=lease_ms,
                    stop_event=stop_event,
                )
            except Exception:
                pass
            finally:
                _mark_progress(health)

        except Exception:
            if stop_event.is_set() or slot.cancel_scope.is_set():
                break
            await asyncio.sleep(0.05)


# ---------- process_run (core step engine) ----------


async def _process_run(
    *,
    redis: Redis[Any],
    client: RedflowClient,
    registry: WorkflowRegistry,
    prefix: str,
    queues: list[str],
    queue: str,
    run_id: str,
    processing_key: str,
    lease_ms: int,
    stop_event: asyncio.Event,
) -> None:
    run_key = K.run(prefix, run_id)
    steps_key = K.run_steps(prefix, run_id)
    lease_key = K.run_lease(prefix, run_id)
    lease_token = f"lease_{uuid.uuid4()}"

    # Acquire lease
    lease_ok = await redis.set(lease_key, lease_token, nx=True, px=lease_ms)
    if not lease_ok:
        _dbg(f"process_run run={run_id} lease already held, skipping")
        removed = await redis.lrem(processing_key, 1, run_id)

        latest_status = _decode(await redis.hget(run_key, "status"))
        if removed > 0 and latest_status == "queued":
            await redis.rpush(K.queue_ready(prefix, queue), run_id)
            _dbg(f"process_run run={run_id} restored to ready after lease collision")
        return

    _dbg(f"process_run run={run_id} queue={queue} lease acquired")

    cancel_event = asyncio.Event()
    lease_lost = False

    def mark_lease_lost() -> None:
        nonlocal lease_lost
        if not lease_lost:
            lease_lost = True
            cancel_event.set()

    # Lease renewal task
    async def renew_lease_loop() -> None:
        nonlocal lease_lost
        failures = 0
        interval = lease_ms / 2 / 1000

        while not cancel_event.is_set() and not stop_event.is_set():
            await asyncio.sleep(interval)
            if cancel_event.is_set():
                break
            try:
                renewed = await RENEW_LEASE.execute(redis, keys=[lease_key], args=[lease_token, str(lease_ms)])
                if renewed is None:
                    _dbg(f"process_run run={run_id} lease lost (token mismatch)")
                    mark_lease_lost()
                    return
                failures = 0
            except Exception:
                failures += 1
                _dbg(f"process_run run={run_id} lease renewal error (failures={failures})")
                if failures >= 2:
                    mark_lease_lost()
                    return

    lease_task = asyncio.create_task(renew_lease_loop())

    try:
        raw = await redis.hgetall(run_key)
        if not raw:
            await redis.lrem(processing_key, 0, run_id)
            return

        run_data: dict[str, str] = {_decode(k): _decode(v) for k, v in raw.items()}
        current_status: RunStatus = run_data.get("status", "queued")  # type: ignore[assignment]

        _dbg(
            f"process_run run={run_id} status={current_status} workflow={run_data.get('workflow')} attempt={run_data.get('attempt')}/{run_data.get('maxAttempts')}"
        )

        if current_status in ("succeeded", "failed", "canceled"):
            await redis.lrem(processing_key, 0, run_id)
            return

        if current_status == "scheduled":
            await redis.lrem(processing_key, 0, run_id)
            return

        if current_status not in ("queued", "running"):
            await redis.lrem(processing_key, 0, run_id)
            return

        workflow_name = run_data.get("workflow", "")
        defn = registry.get(workflow_name) if workflow_name else None
        max_concurrency = _normalize_max_concurrency(defn.options.max_concurrency if defn else 1)
        max_attempts = int(run_data.get("maxAttempts", str(DEFAULT_MAX_ATTEMPTS)))
        cancel_requested_at = run_data.get("cancelRequestedAt", "")

        if cancel_requested_at:
            await client.finalize_run(run_id, status="canceled", finished_at=now_ms(), workflow_name=workflow_name)
            await redis.lrem(processing_key, 0, run_id)
            return

        started_at = int(run_data["startedAt"]) if run_data.get("startedAt") else now_ms()

        if current_status == "queued":
            transition_result = await client.transition_queued_to_running(
                run_id,
                workflow_name=workflow_name,
                max_concurrency=max_concurrency,
                updated_at=started_at,
            )

            if transition_result == 1:
                _dbg(f"process_run run={run_id} requeued: concurrency limit reached (max={max_concurrency})")
                await REQUEUE_DUE_TO_CONCURRENCY.execute(
                    redis,
                    keys=[processing_key, K.queue_ready(prefix, queue)],
                    args=[run_id],
                )
                await asyncio.sleep(0.025)
                return

            if transition_result == 0:
                _dbg(f"process_run run={run_id} transition queued->running failed (not queued or missing)")
                await redis.lrem(processing_key, 0, run_id)
                return

        # Re-read run data after Lua script may have set startedAt and incremented attempt
        refreshed_raw = await redis.hgetall(run_key)
        if refreshed_raw:
            run_data = {_decode(k): _decode(v) for k, v in refreshed_raw.items()}

        attempt = max(1, int(run_data.get("attempt", "0")))

        if not workflow_name:
            err_json = make_error_json(UnknownWorkflowError(""))
            await client.finalize_run(
                run_id, status="failed", error_json=err_json, finished_at=now_ms(), workflow_name=workflow_name
            )
            await redis.lrem(processing_key, 0, run_id)
            return

        if not defn:
            err_json = make_error_json(UnknownWorkflowError(workflow_name))
            await client.finalize_run(
                run_id, status="failed", error_json=err_json, finished_at=now_ms(), workflow_name=workflow_name
            )
            await redis.lrem(processing_key, 0, run_id)
            return

        # Parse and validate input
        input_val: Any
        try:
            input_raw = safe_json_loads(run_data.get("inputJson") or "null")
            input_val = input_raw
            # TODO: pydantic schema validation if schema is attached to defn
        except Exception as err:
            await _invoke_on_failure(
                defn.options.on_failure, err, None, run_id, workflow_name, queue, attempt, max_attempts
            )
            await client.finalize_run(
                run_id,
                status="failed",
                error_json=make_error_json(err),
                finished_at=now_ms(),
                workflow_name=workflow_name,
            )
            await redis.lrem(processing_key, 0, run_id)
            return

        # Cancel poll task
        async def cancel_poll_loop() -> None:
            while not cancel_event.is_set() and not stop_event.is_set():
                await asyncio.sleep(0.1)
                if cancel_event.is_set():
                    break
                try:
                    cancel_raw = await redis.hget(run_key, "cancelRequestedAt")
                    if cancel_raw and _decode(cancel_raw):
                        cancel_event.set()
                except Exception:
                    pass

        cancel_poll_task = asyncio.create_task(cancel_poll_loop())

        try:
            # Build step API
            existing_steps_raw = await redis.hgetall(steps_key)
            step_seq = 0
            for raw_val in existing_steps_raw.values():
                try:
                    parsed = safe_json_loads(_decode(raw_val))
                    seq = parsed.get("seq") if isinstance(parsed, dict) else None
                    if isinstance(seq, (int, float)) and seq > step_seq:
                        step_seq = int(seq)
                except Exception:
                    pass

            used_step_names: set[str] = set()

            async def run_step(
                name: str, fn: Callable[..., Coroutine[Any, Any, Any]], *, timeout_ms: int | None = None
            ) -> Any:
                nonlocal step_seq

                if cancel_event.is_set():
                    raise CanceledError()

                if name in used_step_names:
                    raise RedflowError(
                        f"Duplicate step name '{name}' in workflow '{workflow_name}'. Step names must be unique within a run."
                    )
                used_step_names.add(name)

                # Check cached step result
                existing_raw = await redis.hget(steps_key, name)
                seq = 0
                if existing_raw:
                    existing = safe_json_loads(_decode(existing_raw))
                    existing_seq = existing.get("seq") if isinstance(existing, dict) else None
                    if isinstance(existing_seq, (int, float)) and existing_seq > step_seq:
                        step_seq = int(existing_seq)

                    if isinstance(existing, dict) and existing.get("status") == "succeeded":
                        return safe_json_try_loads(existing.get("outputJson"))

                    if existing_seq is not None:
                        seq = int(existing_seq)
                    else:
                        step_seq += 1
                        seq = step_seq
                else:
                    step_seq += 1
                    seq = step_seq

                step_started_at = now_ms()
                await redis.hset(
                    steps_key,
                    name,
                    safe_json_dumps(
                        {
                            "status": "running",
                            "seq": seq,
                            "startedAt": step_started_at,
                        }
                    ),
                )

                try:
                    fn_task = asyncio.create_task(fn())
                    cancel_wait = asyncio.create_task(_wait_for_event(cancel_event))
                    waitables: set[asyncio.Task[Any]] = {fn_task, cancel_wait}

                    timeout_task: asyncio.Task[Any] | None = None
                    if timeout_ms and timeout_ms > 0:
                        timeout_task = asyncio.create_task(asyncio.sleep(timeout_ms / 1000))
                        waitables.add(timeout_task)

                    done, pending = await asyncio.wait(
                        waitables,
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    for p in pending:
                        p.cancel()
                        with contextlib.suppress(asyncio.CancelledError, Exception):
                            await p

                    if fn_task in done:
                        value = fn_task.result()
                    elif cancel_wait in done:
                        raise CanceledError()
                    else:
                        raise TimeoutError(f"Step timed out: {name}")

                    step_finished_at = now_ms()
                    try:
                        output_json = safe_json_dumps(value)
                    except Exception as ser_err:
                        raise OutputSerializationError(
                            f"Step output is not JSON-serializable: {name}", ser_err
                        ) from ser_err

                    await redis.hset(
                        steps_key,
                        name,
                        safe_json_dumps(
                            {
                                "status": "succeeded",
                                "seq": seq,
                                "startedAt": step_started_at,
                                "finishedAt": step_finished_at,
                                "outputJson": output_json,
                            }
                        ),
                    )
                    return value

                except (CanceledError, TimeoutError):
                    raise
                except builtins.TimeoutError as te:
                    raise TimeoutError(f"Step timed out: {name}") from te
                except Exception as err:
                    step_finished_at = now_ms()
                    await redis.hset(
                        steps_key,
                        name,
                        safe_json_dumps(
                            {
                                "status": "failed",
                                "seq": seq,
                                "startedAt": step_started_at,
                                "finishedAt": step_finished_at,
                                "errorJson": make_error_json(err),
                            }
                        ),
                    )
                    raise

            async def emit_workflow_step(
                name: str,
                target_workflow: str,
                workflow_input: Any,
                *,
                run_at: datetime | None = None,
                queue_override: str | None = None,
                idempotency_key: str | None = None,
                idempotency_ttl: int | None = None,
            ) -> str:
                idem_key = idempotency_key or _default_step_workflow_idempotency_key(run_id, name, target_workflow)

                async def _do() -> str:
                    handle = await client.run_by_name(
                        target_workflow,
                        workflow_input,
                        run_at=run_at,
                        queue_override=queue_override,
                        idempotency_key=idem_key,
                        idempotency_ttl=idempotency_ttl,
                    )
                    return handle.id

                return await run_step(name, _do)

            async def run_workflow_step(
                name: str,
                target_workflow: str,
                workflow_input: Any,
                *,
                timeout_ms: int | None = None,
                run_at: datetime | None = None,
                queue_override: str | None = None,
                idempotency_key: str | None = None,
                idempotency_ttl: int | None = None,
            ) -> Any:
                idem_key = idempotency_key or _default_step_workflow_idempotency_key(run_id, name, target_workflow)

                async def _do() -> Any:
                    handle = await client.run_by_name(
                        target_workflow,
                        workflow_input,
                        run_at=run_at,
                        queue_override=queue_override,
                        idempotency_key=idem_key,
                        idempotency_ttl=idempotency_ttl,
                    )
                    return await _wait_for_run_with_inline_assist(
                        redis=redis,
                        client=client,
                        registry=registry,
                        prefix=prefix,
                        queues=queues,
                        lease_ms=lease_ms,
                        stop_event=stop_event,
                        child_run_id=handle.id,
                        cancel_event=cancel_event,
                    )

                return await run_step(name, _do, timeout_ms=timeout_ms)

            # Build step context
            step_api = _StepApi(
                run=run_step,
                emit_workflow=emit_workflow_step,
                run_workflow=run_workflow_step,
            )

            run_info = _RunInfo(
                id=run_id,
                workflow=workflow_name,
                queue=queue,
                attempt=attempt,
                max_attempts=max_attempts,
            )
            ctx = WorkflowHandlerContext(
                input=input_val,
                run=run_info,
                step=step_api,
                signal=cancel_event,
            )

            # Execute handler
            try:
                if cancel_event.is_set():
                    raise CanceledError()

                handler_task = asyncio.create_task(defn.handler(ctx))
                cancel_wait = asyncio.create_task(_wait_for_event(cancel_event))
                done, pending = await asyncio.wait(
                    {handler_task, cancel_wait},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for p in pending:
                    p.cancel()
                    with contextlib.suppress(asyncio.CancelledError, Exception):
                        await p

                if handler_task in done:
                    output = handler_task.result()
                else:
                    raise CanceledError()

                if cancel_event.is_set():
                    raise CanceledError()

                try:
                    output_json = safe_json_dumps(output)
                except Exception as ser_err:
                    raise OutputSerializationError("Workflow output is not JSON-serializable", ser_err) from ser_err

            except CanceledError:
                if lease_lost:
                    _dbg(f"process_run run={run_id} lease lost, leaving for reaper")
                    return
                _dbg(f"process_run run={run_id} canceled")
                await client.finalize_run(run_id, status="canceled", finished_at=now_ms(), workflow_name=workflow_name)
                await redis.lrem(processing_key, 0, run_id)
                return

            except Exception as err:
                retryable = is_retryable_error(err)
                has_attempts_left = attempt < max_attempts
                finished_at = now_ms()

                if retryable and has_attempts_left:
                    delay = compute_retry_delay_ms(attempt)
                    next_at = finished_at + delay
                    _dbg(
                        f"process_run run={run_id} scheduling retry attempt={attempt + 1}/{max_attempts} delay={delay}ms"
                    )
                    await client.schedule_retry(
                        run_id,
                        queue=queue,
                        next_at=next_at,
                        error_json=make_error_json(err),
                        updated_at=finished_at,
                        workflow_name=workflow_name,
                    )
                    await redis.lrem(processing_key, 0, run_id)
                    return

                _dbg(f"process_run run={run_id} failed permanently attempt={attempt}/{max_attempts}")
                await _invoke_on_failure(
                    defn.options.on_failure, err, input_val, run_id, workflow_name, queue, attempt, max_attempts
                )
                await client.finalize_run(
                    run_id,
                    status="failed",
                    error_json=make_error_json(err),
                    finished_at=finished_at,
                    workflow_name=workflow_name,
                )
                await redis.lrem(processing_key, 0, run_id)
                return

            _dbg(f"process_run run={run_id} succeeded")
            await client.finalize_run(
                run_id,
                status="succeeded",
                output_json=output_json,
                finished_at=now_ms(),
                workflow_name=workflow_name,
            )
            await redis.lrem(processing_key, 0, run_id)

        finally:
            cancel_event.set()
            cancel_poll_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await cancel_poll_task

    finally:
        cancel_event.set()
        lease_task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await lease_task
        with contextlib.suppress(Exception):
            await UNLOCK.execute(redis, keys=[lease_key], args=[lease_token])


# ---------- inline assist for child runs ----------


async def _wait_for_run_with_inline_assist(
    *,
    redis: Redis[Any],
    client: RedflowClient,
    registry: WorkflowRegistry,
    prefix: str,
    queues: list[str],
    lease_ms: int,
    stop_event: asyncio.Event,
    child_run_id: str,
    cancel_event: asyncio.Event,
) -> Any:
    missing_grace_ms = max(250, min(2000, _POLL_MS * 4))
    missing_since: int | None = None
    seen_state = False

    while True:
        if cancel_event.is_set():
            raise CanceledError()

        state = await client.get_run(child_run_id)
        if not state:
            t = now_ms()
            if missing_since is None:
                missing_since = t
            if t - missing_since >= missing_grace_ms:
                if seen_state:
                    raise RedflowError(f"Run state unavailable: {child_run_id}")
                raise RedflowError(f"Run not found: {child_run_id}")
            await asyncio.sleep(_POLL_MS / 1000)
            continue

        seen_state = True
        missing_since = None

        status = state.get("status")
        if status == "succeeded":
            return state.get("output")
        if status == "failed":
            raise RedflowError(f"Run failed: {safe_json_dumps(state.get('error'))}")
        if status == "canceled":
            cancel_reason = state.get("cancel_reason")
            raise CanceledError(f"Run canceled: {cancel_reason}" if cancel_reason else "Run canceled")

        child_queue = state.get("queue", "default")
        if status in ("queued", "running") and child_queue in queues:
            _dbg(f"inline_assist child={child_run_id} status={status} attempting inline claim")
            claimed = await _claim_queued_run_for_inline(redis, prefix, child_queue, child_run_id)
            if claimed:
                _dbg(f"inline_assist child={child_run_id} claimed, executing inline")
                await _process_run(
                    redis=redis,
                    client=client,
                    registry=registry,
                    prefix=prefix,
                    queues=queues,
                    queue=child_queue,
                    run_id=child_run_id,
                    processing_key=K.queue_processing(prefix, child_queue),
                    lease_ms=lease_ms,
                    stop_event=stop_event,
                )
                continue

        await asyncio.sleep(_POLL_MS / 1000)


async def _claim_queued_run_for_inline(redis: Redis[Any], prefix: str, queue: str, run_id: str) -> bool:
    result = await CLAIM_QUEUED_RUN_FOR_INLINE.execute(
        redis,
        keys=[K.queue_ready(prefix, queue), K.queue_processing(prefix, queue), K.run(prefix, run_id)],
        args=[run_id],
    )
    return result == 1 or result == b"1"


# ---------- scheduled promoter loop ----------


async def _scheduled_promoter_loop(
    *,
    redis: Redis[Any],
    client: RedflowClient,
    prefix: str,
    queues: list[str],
    stop_event: asyncio.Event,
) -> None:
    promote_batch_size = 100

    while not stop_event.is_set():
        try:
            now = now_ms()
            next_wake: int | None = None

            for queue in queues:
                if stop_event.is_set():
                    break
                sched_key = K.queue_scheduled(prefix, queue)

                due_ids_raw = await redis.zrangebyscore(sched_key, "-inf", str(now), start=0, num=promote_batch_size)
                for rid_raw in due_ids_raw:
                    if stop_event.is_set():
                        break
                    run_id = _decode(rid_raw)
                    promoted = await client.promote_scheduled_run_if_due(
                        run_id, queue=queue, due_at=now, updated_at=now
                    )
                    if promoted == "promoted":
                        _dbg(f"promoter run={run_id} promoted scheduled->queued queue={queue}")

                earliest = await redis.zrange(sched_key, 0, 0, withscores=True)
                if earliest:
                    _, earliest_score = earliest[0]
                    next_wake = int(earliest_score) if next_wake is None else min(next_wake, int(earliest_score))

            if next_wake is not None:
                await asyncio.sleep(min(1.0, max(0.01, (next_wake - now_ms()) / 1000)))
            else:
                await asyncio.sleep(0.05)

        except Exception:
            if stop_event.is_set():
                break
            await asyncio.sleep(0.1)


# ---------- reaper loop ----------


async def _reaper_loop(
    *,
    redis: Redis[Any],
    prefix: str,
    queues: list[str],
    interval_ms: int,
    stop_event: asyncio.Event,
) -> None:
    while not stop_event.is_set():
        try:
            for queue in queues:
                if stop_event.is_set():
                    break
                processing_key = K.queue_processing(prefix, queue)
                ready_key = K.queue_ready(prefix, queue)
                run_ids_raw = await redis.lrange(processing_key, 0, -1)

                for rid_raw in run_ids_raw:
                    rid = _decode(rid_raw)
                    lease_key = K.run_lease(prefix, rid)
                    lease = await redis.get(lease_key)
                    if lease:
                        continue
                    _dbg(f"reaper run={rid} unleased in processing, moving to ready queue={queue}")
                    removed = await redis.lrem(processing_key, 1, rid)
                    if removed > 0:
                        await redis.lpush(ready_key, rid)

            await asyncio.sleep(interval_ms / 1000)

        except Exception:
            if stop_event.is_set():
                break
            await asyncio.sleep(max(0.1, interval_ms / 1000))


# ---------- watchdog loop ----------


async def _poller_watchdog_loop(
    *,
    redis: Redis[Any],
    prefix: str,
    queues: list[str],
    slots: list[_WorkerSlot],
    check_interval_ms: int,
    stalled_for_ms: int,
    stop_event: asyncio.Event,
    base_redis: Redis[Any],
    owned_redis: list[Redis[Any]],
    registry: WorkflowRegistry,
    lease_ms: int,
    blmove_timeout_sec: int,
) -> None:
    last_recovery_at = 0

    while not stop_event.is_set():
        try:
            ready = 0
            processing = 0
            for q in queues:
                try:
                    ready += await redis.llen(K.queue_ready(prefix, q))
                    processing += await redis.llen(K.queue_processing(prefix, q))
                except Exception:
                    pass

            if (ready <= 0 and processing <= 0) or not slots:
                await asyncio.sleep(check_interval_ms / 1000)
                continue

            now = now_ms()
            if now - last_recovery_at < stalled_for_ms:
                await asyncio.sleep(check_interval_ms / 1000)
                continue

            stale_slots = [
                s
                for s in slots
                if not s.restarting
                and (
                    (s.health.in_flight_since is not None and now - s.health.in_flight_since >= stalled_for_ms)
                    or (now - s.health.last_progress_at >= stalled_for_ms)
                )
            ]

            if not stale_slots:
                await asyncio.sleep(check_interval_ms / 1000)
                continue

            logger.warning(f"redflow: watchdog detected {len(stale_slots)} stalled pollers, restarting")

            for slot in stale_slots:
                await _restart_worker_slot(
                    slot=slot,
                    base_redis=base_redis,
                    prefix=prefix,
                    owned_redis=owned_redis,
                    registry=registry,
                    queues=queues,
                    lease_ms=lease_ms,
                    blmove_timeout_sec=blmove_timeout_sec,
                    stop_event=stop_event,
                )

            last_recovery_at = now_ms()
            await asyncio.sleep(check_interval_ms / 1000)

        except Exception:
            if stop_event.is_set():
                break
            await asyncio.sleep(max(0.25, check_interval_ms / 1000))


async def _restart_worker_slot(
    *,
    slot: _WorkerSlot,
    base_redis: Redis[Any],
    prefix: str,
    owned_redis: list[Redis[Any]],
    registry: WorkflowRegistry,
    queues: list[str],
    lease_ms: int,
    blmove_timeout_sec: int,
    stop_event: asyncio.Event,
) -> None:
    if slot.restarting or stop_event.is_set():
        return
    slot.restarting = True

    try:
        slot.health.restart_count += 1
        slot.cancel_scope.set()

        if slot.task:
            slot.task.cancel()
            with contextlib.suppress(asyncio.CancelledError, asyncio.TimeoutError, Exception):
                await asyncio.wait_for(slot.task, timeout=0.5)

        old_redis = slot.redis
        with contextlib.suppress(Exception):
            await old_redis.aclose()
        with contextlib.suppress(ValueError):
            owned_redis.remove(old_redis)

        if stop_event.is_set():
            return

        new_redis = base_redis.client()
        owned_redis.append(new_redis)
        new_client = create_client(redis=new_redis, prefix=prefix)

        slot.redis = new_redis
        slot.client = new_client
        slot.cancel_scope = asyncio.Event()
        slot.health.in_flight_since = None
        slot.health.in_flight_command = None
        slot.health.in_flight_queue = None
        _mark_progress(slot.health)

        logger.warning(f"redflow: restarted worker slot #{slot.index}")

        task = asyncio.create_task(
            _worker_loop(
                slot=slot,
                registry=registry,
                prefix=prefix,
                queues=queues,
                blmove_timeout_sec=blmove_timeout_sec,
                lease_ms=lease_ms,
                stop_event=stop_event,
            ),
            name=f"redflow-worker-{slot.index}",
        )
        slot.task = task

    finally:
        slot.restarting = False


# ---------- cron scheduler loop ----------


async def _cron_scheduler_loop(
    *,
    redis: Redis[Any],
    client: RedflowClient,
    prefix: str,
    stop_event: asyncio.Event,
) -> None:
    lock_key = K.lock_cron(prefix)
    token = f"cronlock_{uuid.uuid4()}"
    lock_ms = 2000

    while not stop_event.is_set():
        try:
            acquired = await redis.set(lock_key, token, nx=True, px=lock_ms)
            if not acquired:
                await asyncio.sleep(0.25)
                continue

            while not stop_event.is_set():
                try:
                    renewed = await RENEW_LEASE.execute(redis, keys=[lock_key], args=[token, str(lock_ms)])
                    if renewed is None:
                        break

                    now = now_ms()
                    raw_next = await redis.zpopmin(K.cron_next(prefix))
                    if not raw_next:
                        await asyncio.sleep(0.25)
                        continue

                    cron_id_raw, score = raw_next[0]
                    cron_id = _decode(cron_id_raw)
                    score = float(score)

                    if score > now:
                        await redis.zadd(K.cron_next(prefix), {cron_id: score})
                        await asyncio.sleep(min(1.0, max(0.01, (score - now) / 1000)))
                        continue

                    requeue_current = True
                    try:
                        def_raw = await redis.hget(K.cron_def(prefix), cron_id)
                        if not def_raw:
                            requeue_current = False
                            continue

                        try:
                            cron_def = safe_json_loads(_decode(def_raw))
                        except Exception:
                            requeue_current = False
                            continue

                        wf_name = cron_def.get("workflow", "")
                        wf_queue = cron_def.get("queue", "default")

                        try:
                            input_val = safe_json_loads(cron_def.get("inputJson", "null"))
                        except Exception:
                            requeue_current = False
                            continue

                        cron_max_concurrency = _normalize_max_concurrency(cron_def.get("maxConcurrency"))
                        running_count = await _count_running_runs_for_workflow(
                            redis=redis, prefix=prefix, workflow_name=wf_name, stop_at=cron_max_concurrency
                        )

                        if running_count < cron_max_concurrency:
                            await client.run_by_name(wf_name, input_val, queue_override=wf_queue)

                        # Schedule next from current time to avoid catch-up bursts
                        next_at: int | None = None
                        try:
                            from croniter import croniter

                            tz_name = cron_def.get("timezone")
                            if tz_name:
                                from zoneinfo import ZoneInfo

                                base_dt = datetime.now(ZoneInfo(tz_name))
                            else:
                                base_dt = datetime.now()
                            cron_iter = croniter(cron_def.get("expression", ""), base_dt)
                            next_dt = cron_iter.get_next(datetime)
                            next_at = int(next_dt.timestamp() * 1000)
                        except Exception:
                            requeue_current = False
                            continue

                        if next_at is not None:
                            await redis.zadd(K.cron_next(prefix), {cron_id: next_at})
                        requeue_current = False

                    except Exception:
                        pass
                    finally:
                        if requeue_current:
                            retry_at = max(score, now_ms() + 250)
                            with contextlib.suppress(Exception):
                                await redis.zadd(K.cron_next(prefix), {cron_id: retry_at})

                except Exception:
                    if stop_event.is_set():
                        break
                    await asyncio.sleep(0.25)
                    break

        except Exception:
            if stop_event.is_set():
                break
            await asyncio.sleep(0.25)


# ---------- helpers ----------


async def _count_running_runs_for_workflow(
    *,
    redis: Redis[Any],
    prefix: str,
    workflow_name: str,
    stop_at: int | None = None,
) -> int:
    running_count_key = K.workflow_running(prefix, workflow_name)
    cached = await redis.get(running_count_key)
    if cached is not None:
        try:
            count = max(0, int(cached))
        except (TypeError, ValueError):
            count = 0
        return min(count, stop_at) if stop_at is not None else count

    running_ids = await redis.zrevrange(K.runs_status(prefix, "running"), 0, -1)
    count = 0
    for rid_raw in running_ids:
        rid = _decode(rid_raw)
        wf = _decode(await redis.hget(K.run(prefix, rid), "workflow"))
        if wf != workflow_name:
            continue
        count += 1

    await redis.set(running_count_key, str(count))
    return min(count, stop_at) if stop_at is not None else count


def _default_step_workflow_idempotency_key(parent_run_id: str, step_name: str, child_workflow: str) -> str:
    def _enc(v: str) -> str:
        return f"{len(v)}:{v}"

    return f"stepwf:{_enc(parent_run_id)}:{_enc(step_name)}:{_enc(child_workflow)}"


async def _wait_for_event(event: asyncio.Event) -> None:
    """Wait until an asyncio.Event is set."""
    await event.wait()


async def _invoke_on_failure(
    handler: Any,
    error: Any,
    input_val: Any,
    run_id: str,
    workflow_name: str,
    queue: str,
    attempt: int,
    max_attempts: int,
) -> None:
    if handler is None:
        return
    try:
        from .types import OnFailureContext, RunContext

        ctx = OnFailureContext(
            error=error,
            input=input_val,
            run=RunContext(id=run_id, workflow=workflow_name, queue=queue, attempt=attempt, max_attempts=max_attempts),
        )
        result = handler(ctx)
        if asyncio.iscoroutine(result):
            await result
    except Exception:
        pass


@dataclass(slots=True)
class _StepApi:
    """Step API passed to workflow handlers."""

    run: Callable[..., Coroutine[Any, Any, Any]]
    emit_workflow: Callable[..., Coroutine[Any, Any, str]]
    run_workflow: Callable[..., Coroutine[Any, Any, Any]]
