"""Wall-clock millisecond timestamp — matches ``Date.now()`` in the TS client."""

from __future__ import annotations

import time


def now_ms() -> int:
    """Current UTC time in milliseconds since epoch."""
    return int(time.time() * 1000)
