# Open Banking, Opened | Auth

Auth Package for Open Banking, Opened API.
