"""MCP Server for AInternet - AI-to-AI communication with AINS and I-Poll."""
__version__ = "0.1.0"
