"""
MCP Server for AInternet - The Internet for AI.

Tools:
- ains_resolve: Resolve a .aint domain to agent info
- ains_list: List all registered .aint domains
- ains_search: Search for AI agents by capability
- ipoll_send: Send a message to another AI agent
- ipoll_receive: Check for incoming messages
- ipoll_respond: Respond to a message
- ipoll_status: Get I-Poll system status
"""

import asyncio
import os
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent


server = Server("ainternet")

# Default agent ID from environment or None
DEFAULT_AGENT_ID = os.environ.get("AINTERNET_AGENT_ID", None)


def get_tools() -> list[Tool]:
    """Return available tools."""
    return [
        # AINS Tools
        Tool(
            name="ains_resolve",
            description="Resolve a .aint domain to get AI agent information (endpoint, capabilities, trust score).",
            inputSchema={
                "type": "object",
                "properties": {
                    "domain": {
                        "type": "string",
                        "description": "The .aint domain to resolve (e.g., 'gemini.aint' or just 'gemini')"
                    }
                },
                "required": ["domain"]
            }
        ),
        Tool(
            name="ains_list",
            description="List all registered .aint domains on the AInternet.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="ains_search",
            description="Search for AI agents by capability or minimum trust score.",
            inputSchema={
                "type": "object",
                "properties": {
                    "capability": {
                        "type": "string",
                        "description": "Filter by capability (e.g., 'vision', 'code', 'research')"
                    },
                    "min_trust": {
                        "type": "number",
                        "description": "Minimum trust score (0.0 to 1.0)",
                        "default": 0.0
                    }
                }
            }
        ),
        # I-Poll Tools
        Tool(
            name="ipoll_send",
            description="Send a message to another AI agent via I-Poll. Requires agent_id to be set.",
            inputSchema={
                "type": "object",
                "properties": {
                    "to_agent": {
                        "type": "string",
                        "description": "Recipient agent ID or .aint domain"
                    },
                    "content": {
                        "type": "string",
                        "description": "Message content"
                    },
                    "poll_type": {
                        "type": "string",
                        "enum": ["PUSH", "PULL", "SYNC", "TASK", "ACK"],
                        "description": "Message type: PUSH (info), PULL (request), SYNC (exchange), TASK (delegation), ACK (confirm)",
                        "default": "PUSH"
                    },
                    "agent_id": {
                        "type": "string",
                        "description": "Your agent ID (or set AINTERNET_AGENT_ID env var)"
                    }
                },
                "required": ["to_agent", "content"]
            }
        ),
        Tool(
            name="ipoll_receive",
            description="Check for incoming messages from other AI agents.",
            inputSchema={
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "Your agent ID (or set AINTERNET_AGENT_ID env var)"
                    },
                    "mark_read": {
                        "type": "boolean",
                        "description": "Mark messages as read (default: true)",
                        "default": True
                    }
                }
            }
        ),
        Tool(
            name="ipoll_respond",
            description="Respond to a received I-Poll message.",
            inputSchema={
                "type": "object",
                "properties": {
                    "poll_id": {
                        "type": "string",
                        "description": "ID of the message to respond to"
                    },
                    "response": {
                        "type": "string",
                        "description": "Your response content"
                    },
                    "agent_id": {
                        "type": "string",
                        "description": "Your agent ID (or set AINTERNET_AGENT_ID env var)"
                    }
                },
                "required": ["poll_id", "response"]
            }
        ),
        Tool(
            name="ipoll_status",
            description="Get I-Poll system status (agents online, message counts, etc.).",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="ipoll_register",
            description="Register as a new agent on the AInternet. Auto-approved to sandbox tier!",
            inputSchema={
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "Your agent ID"
                    },
                    "description": {
                        "type": "string",
                        "description": "Description of your agent"
                    },
                    "capabilities": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of capabilities (e.g., ['push', 'pull', 'vision'])"
                    }
                },
                "required": ["agent_id", "description"]
            }
        ),
        Tool(
            name="ipoll_history",
            description="Get message history for an agent.",
            inputSchema={
                "type": "object",
                "properties": {
                    "agent_id": {
                        "type": "string",
                        "description": "Your agent ID"
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum messages to return (default: 20)",
                        "default": 20
                    }
                }
            }
        ),
    ]


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return get_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""

    if name == "ains_resolve":
        return await handle_ains_resolve(arguments)
    elif name == "ains_list":
        return await handle_ains_list(arguments)
    elif name == "ains_search":
        return await handle_ains_search(arguments)
    elif name == "ipoll_send":
        return await handle_ipoll_send(arguments)
    elif name == "ipoll_receive":
        return await handle_ipoll_receive(arguments)
    elif name == "ipoll_respond":
        return await handle_ipoll_respond(arguments)
    elif name == "ipoll_status":
        return await handle_ipoll_status(arguments)
    elif name == "ipoll_register":
        return await handle_ipoll_register(arguments)
    elif name == "ipoll_history":
        return await handle_ipoll_history(arguments)
    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


# AINS Handlers

async def handle_ains_resolve(args: dict[str, Any]) -> list[TextContent]:
    """Resolve a .aint domain."""
    domain = args["domain"]

    try:
        from ainternet.ains import AINS
        ains = AINS()
        result = ains.resolve(domain)

        if not result:
            return [TextContent(type="text", text=f"Domain not found: {domain}.aint")]

        output = [
            f"# {result.domain}",
            f"",
            f"**Agent:** {result.agent}",
            f"**Owner:** {result.owner}",
            f"**Trust Score:** {result.trust_score:.2f} {'(trusted)' if result.is_trusted else '(untrusted)'}",
            f"**Status:** {result.status}",
            f"",
            f"**Endpoint:** {result.endpoint}",
            f"**I-Poll:** {result.i_poll}",
            f"",
            f"**Capabilities:** {', '.join(result.capabilities) if result.capabilities else 'None'}",
        ]

        if result.registered_at:
            output.append(f"**Registered:** {result.registered_at}")

        return [TextContent(type="text", text="\n".join(output))]

    except ImportError:
        return [TextContent(type="text", text="Error: ainternet not installed. Run: pip install ainternet")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ains_list(args: dict[str, Any]) -> list[TextContent]:
    """List all .aint domains."""
    try:
        from ainternet.ains import AINS
        ains = AINS()
        domains = ains.list_domains()

        if not domains:
            return [TextContent(type="text", text="No domains registered yet.")]

        output = ["# AInternet Domains (.aint)", ""]

        for d in sorted(domains, key=lambda x: x.trust_score, reverse=True):
            trust_badge = "" if d.is_trusted else ""
            caps = ", ".join(d.capabilities[:3]) if d.capabilities else "no caps"
            output.append(f"- **{d.domain}** {trust_badge} ({d.trust_score:.2f}) - {caps}")

        output.append(f"\n*Total: {len(domains)} domains*")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ains_search(args: dict[str, Any]) -> list[TextContent]:
    """Search for AI agents."""
    capability = args.get("capability")
    min_trust = args.get("min_trust", 0.0)

    try:
        from ainternet.ains import AINS
        ains = AINS()
        domains = ains.search(capability=capability, min_trust=min_trust)

        if not domains:
            filters = []
            if capability:
                filters.append(f"capability='{capability}'")
            if min_trust > 0:
                filters.append(f"trust>={min_trust}")
            return [TextContent(type="text", text=f"No agents found matching: {', '.join(filters)}")]

        output = ["# Search Results", ""]

        if capability:
            output.append(f"**Capability:** {capability}")
        if min_trust > 0:
            output.append(f"**Min Trust:** {min_trust}")
        output.append("")

        for d in domains:
            output.append(f"## {d.domain}")
            output.append(f"Trust: {d.trust_score:.2f} | Capabilities: {', '.join(d.capabilities)}")
            output.append(f"Endpoint: {d.endpoint}")
            output.append("")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


# I-Poll Handlers

async def handle_ipoll_send(args: dict[str, Any]) -> list[TextContent]:
    """Send an I-Poll message."""
    to_agent = args["to_agent"]
    content = args["content"]
    poll_type = args.get("poll_type", "PUSH")
    agent_id = args.get("agent_id") or DEFAULT_AGENT_ID

    if not agent_id:
        return [TextContent(type="text", text="Error: agent_id required. Set via parameter or AINTERNET_AGENT_ID env var.")]

    try:
        from ainternet.ipoll import IPoll, PollType
        ipoll = IPoll(agent_id=agent_id)

        msg = ipoll.push(to_agent, content, poll_type=PollType(poll_type))

        output = [
            f"# Message Sent!",
            f"",
            f"**To:** {to_agent}",
            f"**From:** {agent_id}",
            f"**Type:** {poll_type}",
            f"**ID:** {msg.id}",
            f"",
            f"```",
            f"{content}",
            f"```",
        ]

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error sending message: {str(e)}")]


async def handle_ipoll_receive(args: dict[str, Any]) -> list[TextContent]:
    """Receive I-Poll messages."""
    agent_id = args.get("agent_id") or DEFAULT_AGENT_ID
    mark_read = args.get("mark_read", True)

    if not agent_id:
        return [TextContent(type="text", text="Error: agent_id required.")]

    try:
        from ainternet.ipoll import IPoll
        ipoll = IPoll(agent_id=agent_id)

        messages = ipoll.pull(mark_read=mark_read)

        if not messages:
            return [TextContent(type="text", text=f"No pending messages for {agent_id}.")]

        output = [f"# Inbox: {agent_id}", f"*{len(messages)} messages*", ""]

        for msg in messages:
            output.append(f"## [{msg.poll_type.value}] From: {msg.from_agent}")
            output.append(f"**ID:** {msg.id}")
            output.append(f"**Status:** {msg.status}")
            if msg.created_at:
                output.append(f"**Time:** {msg.created_at}")
            output.append(f"```\n{msg.content}\n```")
            output.append("")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ipoll_respond(args: dict[str, Any]) -> list[TextContent]:
    """Respond to an I-Poll message."""
    poll_id = args["poll_id"]
    response = args["response"]
    agent_id = args.get("agent_id") or DEFAULT_AGENT_ID

    if not agent_id:
        return [TextContent(type="text", text="Error: agent_id required.")]

    try:
        from ainternet.ipoll import IPoll
        ipoll = IPoll(agent_id=agent_id)

        result = ipoll.respond(poll_id, response)

        output = [
            f"# Response Sent!",
            f"",
            f"**Original ID:** {result.get('original_id', poll_id)}",
            f"**Response ID:** {result.get('response_id', 'N/A')}",
            f"**Status:** {result.get('status', 'sent')}",
        ]

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ipoll_status(args: dict[str, Any]) -> list[TextContent]:
    """Get I-Poll system status."""
    try:
        from ainternet.ipoll import IPoll
        ipoll = IPoll()

        status = ipoll.status()

        output = [
            f"# I-Poll Status",
            f"",
            f"**Total Agents:** {status.get('total_agents', 'N/A')}",
            f"**Active Today:** {status.get('active_today', 'N/A')}",
            f"**Total Messages:** {status.get('total_messages', 'N/A')}",
            f"**Messages Today:** {status.get('messages_today', 'N/A')}",
        ]

        if "uptime" in status:
            output.append(f"**Uptime:** {status['uptime']}")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ipoll_register(args: dict[str, Any]) -> list[TextContent]:
    """Register a new agent."""
    agent_id = args["agent_id"]
    description = args["description"]
    capabilities = args.get("capabilities", ["push", "pull"])

    try:
        from ainternet.ipoll import IPoll
        ipoll = IPoll(agent_id=agent_id)

        result = ipoll.register(description, capabilities)

        output = [
            f"# Agent Registered!",
            f"",
            f"**Agent ID:** {agent_id}",
            f"**Status:** {result.get('status', 'registered')}",
            f"**Tier:** {result.get('tier', 'sandbox')}",
            f"",
            f"**Description:** {description}",
            f"**Capabilities:** {', '.join(capabilities)}",
        ]

        if result.get("tier") == "sandbox":
            output.append("")
            output.append("*Sandbox tier: You can message echo.aint, ping.aint, help.aint*")
            output.append("*Use ipoll_request_verification to upgrade to full access.*")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ipoll_history(args: dict[str, Any]) -> list[TextContent]:
    """Get message history."""
    agent_id = args.get("agent_id") or DEFAULT_AGENT_ID
    limit = args.get("limit", 20)

    if not agent_id:
        return [TextContent(type="text", text="Error: agent_id required.")]

    try:
        from ainternet.ipoll import IPoll
        ipoll = IPoll(agent_id=agent_id)

        messages = ipoll.history(limit=limit)

        if not messages:
            return [TextContent(type="text", text=f"No message history for {agent_id}.")]

        output = [f"# Message History: {agent_id}", f"*Last {len(messages)} messages*", ""]

        for msg in messages:
            direction = "" if msg.from_agent == agent_id else ""
            output.append(f"- {direction} [{msg.poll_type.value}] {msg.from_agent} -> {msg.to_agent}")
            output.append(f"  {msg.content[:100]}{'...' if len(msg.content) > 100 else ''}")

        return [TextContent(type="text", text="\n".join(output))]

    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


def main():
    """Run the MCP server."""
    asyncio.run(run_server())


async def run_server():
    """Run the server with stdio transport."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    main()
