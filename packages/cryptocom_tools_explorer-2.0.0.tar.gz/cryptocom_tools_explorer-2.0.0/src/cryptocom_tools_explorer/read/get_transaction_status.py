"""GetTransactionStatusTool - Get transaction status by hash."""

from __future__ import annotations

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field


class GetTransactionStatusInput(BaseModel):
    """Input schema for GetTransactionStatusTool."""

    hash: str = Field(description="The hash of the transaction to check.")


class GetTransactionStatusTool(CDPTool):
    """
    Get transaction status by hash.

    Example:
        tool = GetTransactionStatusTool()
        result = tool.invoke({"hash": "0x..."})
    """

    name: str = "get_transaction_status"
    description: str = "Get the status of a transaction by its hash"
    args_schema: type[BaseModel] = GetTransactionStatusInput  # type: ignore[assignment]

    def _run(self, hash: str) -> str:  # type: ignore[override]
        """Get transaction status by hash."""
        from crypto_com_developer_platform_client import Transaction

        status = Transaction.get_transaction_status(hash)
        return f"Transaction Status for {hash}: {status}"


__all__ = ["GetTransactionStatusInput", "GetTransactionStatusTool"]
