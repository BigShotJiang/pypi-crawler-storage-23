"""GetBlockByTagTool - Get block information by tag or number."""

from __future__ import annotations

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field


class GetBlockByTagInput(BaseModel):
    """Input schema for GetBlockByTagTool."""

    tag: str = Field(
        default="latest",
        description="Block tag ('latest', 'earliest', 'pending') or block number as string",
    )
    tx_detail: str = Field(
        default="false",
        description="If 'true', returns full transaction objects; if 'false', only hashes.",
    )


class GetBlockByTagTool(CDPTool):
    """
    Get block information by tag or number.

    Example:
        tool = GetBlockByTagTool()
        result = tool.invoke({"tag": "latest"})
    """

    name: str = "get_block_by_tag"
    description: str = "Get block information by tag (latest, earliest, pending) or block number"
    args_schema: type[BaseModel] = GetBlockByTagInput  # type: ignore[assignment]

    def _run(self, tag: str = "latest", tx_detail: str = "false") -> str:  # type: ignore[override]
        """Get block information by tag or number."""
        from crypto_com_developer_platform_client import Block

        response = Block.get_by_tag(tag, tx_detail)
        return f"Block data for tag {tag}: {response}"


__all__ = ["GetBlockByTagInput", "GetBlockByTagTool"]
