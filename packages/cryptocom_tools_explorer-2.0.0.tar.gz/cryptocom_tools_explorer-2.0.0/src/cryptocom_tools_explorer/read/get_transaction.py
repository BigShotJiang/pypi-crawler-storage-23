"""GetTransactionByHashTool - Get transaction details by hash."""

from __future__ import annotations

from cryptocom_tools_core import CDPTool
from pydantic import BaseModel, Field


class GetTransactionByHashInput(BaseModel):
    """Input schema for GetTransactionByHashTool."""

    hash: str = Field(description="The hash of the transaction to retrieve.")


class GetTransactionByHashTool(CDPTool):
    """
    Get transaction details by hash.

    Example:
        tool = GetTransactionByHashTool()
        result = tool.invoke({"hash": "0x..."})
    """

    name: str = "get_transaction_by_hash"
    description: str = "Get transaction details by transaction hash"
    args_schema: type[BaseModel] = GetTransactionByHashInput  # type: ignore[assignment]

    def _run(self, hash: str) -> str:  # type: ignore[override]
        """Get transaction details by hash."""
        from crypto_com_developer_platform_client import Transaction

        transaction = Transaction.get_transaction_by_hash(hash)
        return f"Transaction Details: {transaction}"


__all__ = ["GetTransactionByHashInput", "GetTransactionByHashTool"]
