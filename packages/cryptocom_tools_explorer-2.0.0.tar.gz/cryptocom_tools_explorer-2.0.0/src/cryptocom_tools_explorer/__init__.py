"""
Crypto.com Tools Explorer - Blockchain explorer tools.

This package provides read-only blockchain explorer tools for the Crypto.com Developer Platform.

Tools inherit from CDPTool (which extends LangChain BaseTool) for:
- Native LangChain/LangGraph compatibility
- Export to OpenAI/Anthropic SDKs via adapters
- Automatic CDP client initialization via api_key

Example:
    from cryptocom_tools_explorer import (
        GetBlockByTagTool,
        GetTransactionByHashTool,
        GetTransactionStatusTool,
    )

    # Tools auto-read API key from CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY env var
    tool = GetBlockByTagTool()
    result = tool.invoke({"tag": "latest"})
"""

from __future__ import annotations

from typing import Any

__version__ = "0.1.0"

# Result types
# Tools
from .read import (
    GetBlockByTagInput,
    GetBlockByTagTool,
    GetTransactionByHashInput,
    GetTransactionByHashTool,
    GetTransactionStatusInput,
    GetTransactionStatusTool,
)

__all__ = [
    # Version
    "__version__",
    # Tools
    "GetBlockByTagInput",
    "GetBlockByTagTool",
    "GetTransactionByHashInput",
    "GetTransactionByHashTool",
    "GetTransactionStatusInput",
    "GetTransactionStatusTool",
    # Helper function
    "get_all_tools",
]


def get_all_tools(api_key: str | None = None) -> list[Any]:
    """
    Get all available explorer tools initialized with the CDP API key.

    Args:
        api_key: Crypto.com Developer Platform API key

    Returns:
        List of all initialized tool instances

    Example:
        tools = get_all_tools(api_key=os.getenv("CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"))
        agent = create_agent("openai:gpt-4o", tools=tools)
    """
    return [
        GetBlockByTagTool(api_key=api_key),
        GetTransactionByHashTool(api_key=api_key),
        GetTransactionStatusTool(api_key=api_key),
    ]
