# cryptocom-tools-explorer

Blockchain explorer tools for the Crypto.com Developer Platform.

## Installation

```bash
pip install cryptocom-tools-explorer
```

## Features

Read-only blockchain explorer tools:
- `GetBlockByTagTool` - Get block by tag (latest, earliest, pending) or block number
- `GetTransactionByHashTool` - Get transaction details by hash
- `GetTransactionStatusTool` - Get transaction confirmation status

## Usage

```python
import os
from cryptocom_tools_explorer import (
    GetBlockByTagTool,
    GetTransactionByHashTool,
    GetTransactionStatusTool,
)

# Tools auto-read API key from CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY env var
tool = GetBlockByTagTool()
result = tool.invoke({"tag": "latest"})
print(result)

# Or pass API key explicitly
tool = GetTransactionByHashTool(api_key=os.getenv("CRYPTOCOM_DEVELOPER_PLATFORM_API_KEY"))
result = tool.invoke({"hash": "0x..."})
print(result)
```

## License

MIT
