Custom Views
============

In these documentation pages you will find detailed information on creating custom views for your Splunk SOAR app actions.

Dive into the custom views documentation:

.. toctree::
   :maxdepth: 2

   view_handlers
   templates
   reusable_components
