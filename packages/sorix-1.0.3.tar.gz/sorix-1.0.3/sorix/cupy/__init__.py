from .cupy import _cupy_available
