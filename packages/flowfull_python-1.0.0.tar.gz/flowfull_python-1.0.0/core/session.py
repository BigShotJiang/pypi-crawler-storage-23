"""
Flowfull-Python Client - Session Manager

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

from typing import Optional, Callable
import os
from .storage import Storage, MemoryStorage
from .types import SessionConfig


class SessionManager:
    """Manages session ID detection and injection"""

    def __init__(
        self,
        storage: Optional[Storage] = None,
        session_id: Optional[str] = None,
        get_session_id: Optional[Callable[[], Optional[str]]] = None,
        config: Optional[SessionConfig] = None,
    ) -> None:
        """
        Initialize session manager

        Args:
            storage: Storage adapter for session persistence
            session_id: Static session ID (highest priority)
            get_session_id: Function to get session ID dynamically
            config: Session configuration
        """
        self.storage = storage or MemoryStorage()
        self.static_session_id = session_id
        self.get_session_id_func = get_session_id
        self.config = config or SessionConfig()

    def get_session_id(self) -> Optional[str]:
        """
        Get session ID with priority:
        1. Static session_id
        2. get_session_id() function
        3. Storage adapter
        4. Environment variable (FLOWFULL_SESSION_ID)
        """
        # Priority 1: Static session ID
        if self.static_session_id:
            return self.static_session_id

        # Priority 2: Dynamic function
        if self.get_session_id_func:
            session_id = self.get_session_id_func()
            if session_id:
                return session_id

        # Priority 3: Storage adapter
        session_id = self.storage.get_item(self.config.storage_key)
        if session_id:
            return session_id

        # Priority 4: Environment variable
        return os.getenv("FLOWFULL_SESSION_ID")

    def set_session_id(self, session_id: str) -> None:
        """Store session ID in storage"""
        self.storage.set_item(self.config.storage_key, session_id)

    def clear_session(self) -> None:
        """Clear session from storage"""
        self.storage.remove_item(self.config.storage_key)
        self.storage.remove_item(self.config.user_data_key)

    def get_user_data(self) -> Optional[str]:
        """Get user data from storage"""
        return self.storage.get_item(self.config.user_data_key)

    def set_user_data(self, user_data: str) -> None:
        """Store user data in storage"""
        self.storage.set_item(self.config.user_data_key, user_data)

    def inject_session_header(self, headers: dict) -> dict:
        """
        Inject session ID into headers if available

        Args:
            headers: Existing headers dict

        Returns:
            Headers dict with session ID injected (if available)
        """
        session_id = self.get_session_id()
        if session_id and self.config.include_session:
            headers[self.config.session_header] = session_id
        return headers

