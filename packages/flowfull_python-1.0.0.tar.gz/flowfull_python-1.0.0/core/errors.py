"""
Flowfull-Python Client - Error Types

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""


class FlowfullError(Exception):
    """Base exception for all Flowfull errors"""

    pass


class AuthenticationError(FlowfullError):
    """Raised when authentication fails"""

    pass


class ValidationError(FlowfullError):
    """Raised when validation fails"""

    pass


class NetworkError(FlowfullError):
    """Raised when network request fails"""

    pass


class SessionError(FlowfullError):
    """Raised when session management fails"""

    pass


class QueryBuilderError(FlowfullError):
    """Raised when query building fails"""

    pass

