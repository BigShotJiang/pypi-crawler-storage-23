"""
Flowfull-Python Client - Async Query Builder

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

from typing import Any, Dict, Optional, Tuple, TYPE_CHECKING
from .types import ApiResponse

if TYPE_CHECKING:
    from .async_client import AsyncFlowfullClient


class AsyncQueryBuilder:
    """Chainable async query builder for complex queries"""

    def __init__(self, client: "AsyncFlowfullClient", path: str) -> None:
        """
        Initialize async query builder

        Args:
            client: AsyncFlowfullClient instance
            path: Request path
        """
        self._client = client
        self._path = path
        self._params: Dict[str, Any] = {}
        self._filters: Dict[str, Tuple[str, Any]] = {}
        self._search_query: Optional[str] = None
        self._sort_field: Optional[str] = None
        self._sort_order: Optional[str] = None
        self._page_num: Optional[int] = None
        self._limit_num: Optional[int] = None

    def where(self, field: str, operator_or_value: Any, value: Any = None) -> "AsyncQueryBuilder":
        """
        Add filter condition

        Args:
            field: Field name
            operator_or_value: Operator tuple (from operators.py) or direct value
            value: Value (if operator_or_value is a string operator)

        Returns:
            Self for chaining

        Examples:
            .where("status", eq("active"))
            .where("price", gte(50))
            .where("status", "active")  # shorthand for eq
        """
        if isinstance(operator_or_value, tuple) and len(operator_or_value) == 2:
            # Operator tuple from operators.py
            operator, val = operator_or_value
            self._filters[field] = (operator, val)
        elif value is not None:
            # String operator with separate value
            self._filters[field] = (operator_or_value, value)
        else:
            # Direct value (shorthand for eq)
            self._filters[field] = ("eq", operator_or_value)

        return self

    def search(self, query: str) -> "AsyncQueryBuilder":
        """
        Add search query

        Args:
            query: Search query string

        Returns:
            Self for chaining
        """
        self._search_query = query
        return self

    def sort(self, field: str, order: str = "asc") -> "AsyncQueryBuilder":
        """
        Add sorting

        Args:
            field: Field to sort by
            order: Sort order ("asc" or "desc")

        Returns:
            Self for chaining
        """
        self._sort_field = field
        self._sort_order = order
        return self

    def page(self, page_num: int) -> "AsyncQueryBuilder":
        """
        Set page number

        Args:
            page_num: Page number (1-based)

        Returns:
            Self for chaining
        """
        self._page_num = page_num
        return self

    def limit(self, limit_num: int) -> "AsyncQueryBuilder":
        """
        Set limit (items per page)

        Args:
            limit_num: Number of items per page

        Returns:
            Self for chaining
        """
        self._limit_num = limit_num
        return self

    def _build_params(self) -> Dict[str, Any]:
        """Build query parameters from builder state"""
        params = self._params.copy()

        # Add filters using bracket syntax: field[operator]=value
        for field, (operator, value) in self._filters.items():
            if isinstance(value, list):
                # Array values: join with comma
                params[f"{field}[{operator}]"] = ",".join(str(v) for v in value)
            else:
                params[f"{field}[{operator}]"] = str(value)

        # Add search
        if self._search_query:
            params["search"] = self._search_query

        # Add sorting
        if self._sort_field:
            params["sort"] = self._sort_field
            if self._sort_order:
                params["order"] = self._sort_order

        # Add pagination
        if self._page_num is not None:
            params["page"] = self._page_num
        if self._limit_num is not None:
            params["limit"] = self._limit_num

        return params

    async def get(self) -> ApiResponse:
        """
        Execute async GET request with built query

        Returns:
            ApiResponse object
        """
        params = self._build_params()
        return await self._client.get(self._path, params=params)

