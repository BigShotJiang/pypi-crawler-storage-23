"""
Flowfull-Python Client - Async Authentication Helper

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import json
from typing import TYPE_CHECKING, Optional
from .types import (
    LoginCredentials,
    RegisterData,
    LoginResult,
    User,
    PasswordResetRequest,
    TokenValidation,
    ValidationResult,
    PasswordResetComplete,
    PasswordChange,
    ResendVerification,
    TokenCreate,
    TokenCreateResult,
    SocialProvidersResult,
    SocialLoginData,
    SocialAccountsResult,
    SessionValidationResult,
    ProfileUpdate,
    PictureUploadResult,
)
from .errors import AuthenticationError

if TYPE_CHECKING:
    from .async_client import AsyncFlowfullClient


class AsyncAuthHelper:
    """Async authentication helper for Flowfull client"""

    def __init__(self, client: "AsyncFlowfullClient") -> None:
        """
        Initialize async auth helper

        Args:
            client: AsyncFlowfullClient instance
        """
        self.client = client
        self.base_path = "/auth"

    # ========================================================================
    # Core Authentication
    # ========================================================================

    async def login(
        self,
        email: Optional[str] = None,
        user_name: Optional[str] = None,
        password: str = "",
    ) -> LoginResult:
        """
        Login with email/username and password

        Args:
            email: User email
            user_name: Username
            password: Password

        Returns:
            LoginResult with user and session data

        Raises:
            AuthenticationError: If login fails
        """
        credentials = LoginCredentials(
            email=email,
            user_name=user_name,
            password=password,
        )

        response = await self.client.post(
            f"{self.base_path}/login",
            json=credentials.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    async def register(self, data: RegisterData) -> LoginResult:
        """
        Register new user (public registration)

        Args:
            data: Registration data

        Returns:
            LoginResult with user and session data

        Raises:
            AuthenticationError: If registration fails
        """
        response = await self.client.post(
            f"{self.base_path}/register",
            json=data.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Registration failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    async def logout(self) -> bool:
        """
        Logout current user

        Returns:
            True if logout successful

        Raises:
            AuthenticationError: If logout fails
        """
        response = await self.client.post(f"{self.base_path}/logout")

        if not response.success:
            raise AuthenticationError(response.error or "Logout failed")

        # Clear session and user data
        self.client.session_manager.clear_session()

        return True

    async def validate_session(self) -> SessionValidationResult:
        """
        Validate current session

        Returns:
            SessionValidationResult with validation status

        Raises:
            AuthenticationError: If validation fails
        """
        response = await self.client.get(f"{self.base_path}/validate")

        if not response.success:
            raise AuthenticationError(response.error or "Session validation failed")

        return SessionValidationResult(**response.data)

    async def refresh_user(self) -> User:
        """
        Refresh user data from server

        Returns:
            Updated User object

        Raises:
            AuthenticationError: If refresh fails
        """
        response = await self.client.get(f"{self.base_path}/refresh")

        if not response.success:
            raise AuthenticationError(response.error or "User refresh failed")

        user = User(**response.data)

        # Update stored user data
        self.client.session_manager.set_user_data(user.model_dump_json())

        return user

    # ========================================================================
    # Password Management
    # ========================================================================

    async def request_password_reset(self, email: str) -> bool:
        """Request password reset email"""
        data = PasswordResetRequest(email=email)
        response = await self.client.post(
            f"{self.base_path}/password/reset/request",
            json=data.model_dump(),
        )
        return response.success

    async def validate_reset_token(self, token: str) -> ValidationResult:
        """Validate password reset token"""
        data = TokenValidation(token=token)
        response = await self.client.post(
            f"{self.base_path}/password/reset/validate",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token validation failed")

        return ValidationResult(**response.data)

    async def complete_password_reset(self, token: str, new_password: str) -> bool:
        """Complete password reset with token"""
        data = PasswordResetComplete(token=token, new_password=new_password)
        response = await self.client.post(
            f"{self.base_path}/password/reset/complete",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Password reset failed")

        return True

    async def change_password(self, current_password: str, new_password: str) -> bool:
        """Change password (authenticated)"""
        data = PasswordChange(current_password=current_password, new_password=new_password)
        response = await self.client.post(
            f"{self.base_path}/password/change",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Password change failed")

        return True

    # ========================================================================
    # Email Verification
    # ========================================================================

    async def verify_email(self, token: str) -> bool:
        """Verify email with token"""
        data = TokenValidation(token=token)
        response = await self.client.post(
            f"{self.base_path}/email/verify",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Email verification failed")

        return True

    async def resend_verification(self, email: str) -> bool:
        """Resend verification email"""
        data = ResendVerification(email=email)
        response = await self.client.post(
            f"{self.base_path}/email/resend",
            json=data.model_dump(),
        )
        return response.success

    # ========================================================================
    # Token Authentication
    # ========================================================================

    async def create_login_token(self, email: str, expires_in: int = 3600) -> TokenCreateResult:
        """Create login token"""
        data = TokenCreate(email=email, expires_in=expires_in)
        response = await self.client.post(
            f"{self.base_path}/token/create",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token creation failed")

        return TokenCreateResult(**response.data)

    async def login_with_token(self, token: str) -> LoginResult:
        """Login with token"""
        data = TokenValidation(token=token)
        response = await self.client.post(
            f"{self.base_path}/token/login",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    # ========================================================================
    # Social Authentication
    # ========================================================================

    async def get_social_providers(self) -> SocialProvidersResult:
        """Get available social providers"""
        response = await self.client.get(f"{self.base_path}/social/providers")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get social providers")

        return SocialProvidersResult(**response.data)

    async def login_with_social(self, data: SocialLoginData) -> LoginResult:
        """Login with social provider"""
        response = await self.client.post(
            f"{self.base_path}/social/login",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Social login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    async def get_social_accounts(self) -> SocialAccountsResult:
        """Get user's linked social accounts"""
        response = await self.client.get(f"{self.base_path}/social/accounts")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get social accounts")

        return SocialAccountsResult(**response.data)

    async def link_social_account(self, data: SocialLoginData) -> bool:
        """Link social account to current user"""
        response = await self.client.post(
            f"{self.base_path}/social/link",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to link social account")

        return True

    async def unlink_social_account(self, provider: str) -> bool:
        """Unlink social account"""
        response = await self.client.delete(f"{self.base_path}/social/unlink/{provider}")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to unlink social account")

        return True

    # ========================================================================
    # Profile Management
    # ========================================================================

    async def get_profile(self) -> User:
        """Get current user profile"""
        response = await self.client.get(f"{self.base_path}/profile")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get profile")

        return User(**response.data)

    async def update_profile(self, data: ProfileUpdate) -> User:
        """Update user profile"""
        response = await self.client.patch(
            f"{self.base_path}/profile",
            json=data.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to update profile")

        user = User(**response.data)

        # Update stored user data
        self.client.session_manager.set_user_data(user.model_dump_json())

        return user

    async def upload_picture(self, file_path: str) -> PictureUploadResult:
        """Upload profile picture"""
        with open(file_path, "rb") as f:
            files = {"file": f}
            response = await self.client.post(
                f"{self.base_path}/profile/picture",
                files=files,
            )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to upload picture")

        return PictureUploadResult(**response.data)

