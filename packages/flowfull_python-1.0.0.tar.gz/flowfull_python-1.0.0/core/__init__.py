"""
Flowfull-Python Client

Production-ready HTTP client for Python applications to interact with Flowfull backends.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published
by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Copyright (C) 2024 Pubflow Team
License: AGPL-3.0-or-later
"""

__version__ = "1.0.0"
__license__ = "AGPL-3.0-or-later"

from .client import FlowfullClient
from .async_client import AsyncFlowfullClient
from .operators import (
    # Comparison operators
    eq,
    ne,
    gt,
    gte,
    lt,
    lte,
    # String operators
    like,
    ilike,
    starts_with,
    ends_with,
    # Array operators
    in_,
    not_in,
    # Null operators
    is_null,
    is_not_null,
    # Range operators
    between,
    not_between,
)
from .types import (
    ApiResponse,
    PaginationMeta,
    FlowfullConfig,
    # Auth types
    User,
    Session,
    LoginCredentials,
    RegisterData,
    LoginResult,
    PasswordResetRequest,
    TokenValidation,
    ValidationResult,
    PasswordResetComplete,
    PasswordChange,
    ResendVerification,
    TokenCreate,
    TokenCreateResult,
    SocialProvider,
    SocialProviderInfo,
    SocialProvidersResult,
    SocialLoginData,
    SocialAccount,
    SocialAccountsResult,
    SessionValidationResult,
    ProfileUpdate,
    PictureUploadResult,
)
from .storage import Storage, FileStorage, MemoryStorage
from .errors import FlowfullError, AuthenticationError, ValidationError, NetworkError

__all__ = [
    # Version and license
    "__version__",
    "__license__",
    # Core clients
    "FlowfullClient",
    "AsyncFlowfullClient",
    # Comparison operators
    "eq",
    "ne",
    "gt",
    "gte",
    "lt",
    "lte",
    # String operators
    "like",
    "ilike",
    "starts_with",
    "ends_with",
    # Array operators
    "in_",
    "not_in",
    # Null operators
    "is_null",
    "is_not_null",
    # Range operators
    "between",
    "not_between",
    # Types
    "ApiResponse",
    "PaginationMeta",
    "FlowfullConfig",
    # Auth types
    "User",
    "Session",
    "LoginCredentials",
    "RegisterData",
    "LoginResult",
    "PasswordResetRequest",
    "TokenValidation",
    "ValidationResult",
    "PasswordResetComplete",
    "PasswordChange",
    "ResendVerification",
    "TokenCreate",
    "TokenCreateResult",
    "SocialProvider",
    "SocialProviderInfo",
    "SocialProvidersResult",
    "SocialLoginData",
    "SocialAccount",
    "SocialAccountsResult",
    "SessionValidationResult",
    "ProfileUpdate",
    "PictureUploadResult",
    # Storage
    "Storage",
    "FileStorage",
    "MemoryStorage",
    # Errors
    "FlowfullError",
    "AuthenticationError",
    "ValidationError",
    "NetworkError",
]

