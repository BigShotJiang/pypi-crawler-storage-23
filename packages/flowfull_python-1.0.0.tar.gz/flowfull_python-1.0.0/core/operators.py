"""
Flowfull-Python Client - Filter Operators

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

from typing import Any, List, Tuple, Union


# ============================================================================
# Comparison Operators
# ============================================================================


def eq(value: Any) -> Tuple[str, Any]:
    """Equal to (=)"""
    return ("eq", value)


def ne(value: Any) -> Tuple[str, Any]:
    """Not equal to (!=)"""
    return ("ne", value)


def gt(value: Any) -> Tuple[str, Any]:
    """Greater than (>)"""
    return ("gt", value)


def gte(value: Any) -> Tuple[str, Any]:
    """Greater than or equal to (>=)"""
    return ("gte", value)


def lt(value: Any) -> Tuple[str, Any]:
    """Less than (<)"""
    return ("lt", value)


def lte(value: Any) -> Tuple[str, Any]:
    """Less than or equal to (<=)"""
    return ("lte", value)


# ============================================================================
# String Operators
# ============================================================================


def like(value: str) -> Tuple[str, str]:
    """SQL LIKE (case-sensitive)"""
    return ("like", value)


def ilike(value: str) -> Tuple[str, str]:
    """SQL ILIKE (case-insensitive)"""
    return ("ilike", value)


def starts_with(value: str) -> Tuple[str, str]:
    """Starts with (case-sensitive)"""
    return ("starts_with", value)


def ends_with(value: str) -> Tuple[str, str]:
    """Ends with (case-sensitive)"""
    return ("ends_with", value)


# ============================================================================
# Array Operators
# ============================================================================


def in_(values: List[Any]) -> Tuple[str, List[Any]]:
    """IN operator (value in list)"""
    return ("in", values)


def not_in(values: List[Any]) -> Tuple[str, List[Any]]:
    """NOT IN operator (value not in list)"""
    return ("nin", values)


# ============================================================================
# Null Operators
# ============================================================================


def is_null() -> Tuple[str, bool]:
    """IS NULL"""
    return ("null", True)


def is_not_null() -> Tuple[str, bool]:
    """IS NOT NULL"""
    return ("notNull", True)


# ============================================================================
# Range Operators
# ============================================================================


def between(min_value: Any, max_value: Any) -> Tuple[str, str]:
    """BETWEEN operator (inclusive range)"""
    return ("between", f"{min_value},{max_value}")


def not_between(min_value: Any, max_value: Any) -> Tuple[str, str]:
    """NOT BETWEEN operator (exclusive range)"""
    return ("notBetween", f"{min_value},{max_value}")

