"""
Flowfull-Python Client - Async Request Handler

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import httpx
import asyncio
from typing import Optional, Dict, Any, List, Callable
from .types import ApiResponse, RetryConfig
from .errors import NetworkError


class AsyncRequestHandler:
    """Handles async HTTP requests with retry logic"""

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        retry_config: Optional[RetryConfig] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Initialize async request handler

        Args:
            base_url: Base URL for all requests
            timeout: Request timeout in seconds
            retry_config: Retry configuration
            headers: Default headers for all requests
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.retry_config = retry_config or RetryConfig()
        self.default_headers = headers or {}
        self.request_interceptors: List[Callable] = []
        self.response_interceptors: List[Callable] = []
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client"""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close async HTTP client"""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    def add_request_interceptor(self, interceptor: Callable) -> None:
        """Add request interceptor"""
        self.request_interceptors.append(interceptor)

    def add_response_interceptor(self, interceptor: Callable) -> None:
        """Add response interceptor"""
        self.response_interceptors.append(interceptor)

    def _build_url(self, path: str) -> str:
        """Build full URL from path"""
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}/{path.lstrip('/')}"

    def _merge_headers(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Merge default headers with request headers"""
        merged = self.default_headers.copy()
        if headers:
            merged.update(headers)
        return merged

    def _apply_request_interceptors(self, request_data: Dict[str, Any]) -> Dict[str, Any]:
        """Apply request interceptors"""
        for interceptor in self.request_interceptors:
            request_data = interceptor(request_data)
        return request_data

    async def _apply_response_interceptors(self, response: httpx.Response) -> httpx.Response:
        """Apply response interceptors"""
        for interceptor in self.response_interceptors:
            if asyncio.iscoroutinefunction(interceptor):
                response = await interceptor(response)
            else:
                response = interceptor(response)
        return response

    async def _execute_with_retry(
        self, method: str, url: str, **kwargs: Any
    ) -> httpx.Response:
        """Execute async request with retry logic"""
        last_error: Optional[Exception] = None
        delay = self.retry_config.delay

        for attempt in range(self.retry_config.attempts):
            try:
                response = await self.client.request(method, url, **kwargs)
                response.raise_for_status()
                return await self._apply_response_interceptors(response)
            except (httpx.HTTPError, httpx.RequestError) as e:
                last_error = e
                if attempt < self.retry_config.attempts - 1:
                    await asyncio.sleep(delay)
                    if self.retry_config.exponential:
                        delay = min(delay * 2, self.retry_config.max_delay)

        raise NetworkError(f"Request failed after {self.retry_config.attempts} attempts: {last_error}")

    async def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> ApiResponse:
        """
        Execute async HTTP request

        Args:
            method: HTTP method (GET, POST, PUT, PATCH, DELETE)
            path: Request path
            params: Query parameters
            data: Form data
            json: JSON data
            headers: Request headers
            files: Files to upload

        Returns:
            ApiResponse object
        """
        url = self._build_url(path)
        merged_headers = self._merge_headers(headers)

        # Apply request interceptors
        request_data = self._apply_request_interceptors({
            "method": method,
            "url": url,
            "params": params,
            "data": data,
            "json": json,
            "headers": merged_headers,
            "files": files,
        })

        # Execute request
        response = await self._execute_with_retry(
            request_data["method"],
            request_data["url"],
            params=request_data.get("params"),
            data=request_data.get("data"),
            json=request_data.get("json"),
            headers=request_data["headers"],
            files=request_data.get("files"),
        )

        # Parse response
        try:
            response_data = response.json()
            return ApiResponse(**response_data)
        except Exception:
            # Fallback for non-JSON responses
            return ApiResponse(
                success=response.is_success,
                data=response.text,
                status=response.status_code,
            )

