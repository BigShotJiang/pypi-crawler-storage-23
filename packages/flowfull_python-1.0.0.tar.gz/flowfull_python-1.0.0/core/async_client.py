"""
Flowfull-Python Client - Async Client

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import httpx
from typing import Optional, Dict, Any, Callable
from .types import FlowfullConfig, ApiResponse, SessionConfig, RetryConfig
from .storage import Storage, FileStorage
from .session import SessionManager
from .async_request import AsyncRequestHandler
from .async_query import AsyncQueryBuilder
from .async_auth import AsyncAuthHelper


class AsyncFlowfullClient:
    """Asynchronous Flowfull HTTP client"""

    def __init__(
        self,
        base_url: str,
        session_id: Optional[str] = None,
        get_session_id: Optional[Callable[[], Optional[str]]] = None,
        storage: Optional[Storage] = None,
        timeout: float = 30.0,
        headers: Optional[Dict[str, str]] = None,
        retry_attempts: int = 3,
        retry_delay: float = 1.0,
        retry_exponential: bool = True,
        include_session: bool = False,
    ) -> None:
        """
        Initialize async Flowfull client

        Args:
            base_url: Base URL of the Flowfull instance
            session_id: Static session ID (optional)
            get_session_id: Function to get session ID dynamically (optional)
            storage: Storage adapter for session persistence (default: FileStorage)
            timeout: Request timeout in seconds
            headers: Default headers for all requests
            retry_attempts: Number of retry attempts on failure
            retry_delay: Initial delay between retries (seconds)
            retry_exponential: Use exponential backoff for retries
            include_session: Automatically include session in requests
        """
        # Initialize storage
        if storage is None:
            storage = FileStorage()

        # Initialize session config
        session_config = SessionConfig(include_session=include_session)

        # Initialize session manager
        self.session_manager = SessionManager(
            storage=storage,
            session_id=session_id,
            get_session_id=get_session_id,
            config=session_config,
        )

        # Initialize retry config
        retry_config = RetryConfig(
            attempts=retry_attempts,
            delay=retry_delay,
            exponential=retry_exponential,
        )

        # Initialize request handler
        self.request_handler = AsyncRequestHandler(
            base_url=base_url,
            timeout=timeout,
            retry_config=retry_config,
            headers=headers,
        )

        # Store config
        self.config = FlowfullConfig(
            base_url=base_url,
            session_id=session_id,
            get_session_id=get_session_id,
            timeout=timeout,
            headers=headers,
            retry_attempts=retry_attempts,
            retry_delay=retry_delay,
            retry_exponential=retry_exponential,
            session_config=session_config,
        )

        # Initialize auth helper (lazy)
        self._auth_helper: Optional[AsyncAuthHelper] = None

    def _inject_session(self, headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Inject session ID into headers"""
        headers = headers or {}
        return self.session_manager.inject_session_header(headers)

    async def get(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ApiResponse:
        """Execute async GET request"""
        headers = self._inject_session(headers)
        return await self.request_handler.request("GET", path, params=params, headers=headers)

    async def post(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        files: Optional[Dict[str, Any]] = None,
    ) -> ApiResponse:
        """Execute async POST request"""
        headers = self._inject_session(headers)
        return await self.request_handler.request(
            "POST", path, data=data, json=json, headers=headers, files=files
        )

    async def put(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ApiResponse:
        """Execute async PUT request"""
        headers = self._inject_session(headers)
        return await self.request_handler.request("PUT", path, data=data, json=json, headers=headers)

    async def patch(
        self,
        path: str,
        data: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ApiResponse:
        """Execute async PATCH request"""
        headers = self._inject_session(headers)
        return await self.request_handler.request("PATCH", path, data=data, json=json, headers=headers)

    async def delete(
        self,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> ApiResponse:
        """Execute async DELETE request"""
        headers = self._inject_session(headers)
        return await self.request_handler.request("DELETE", path, params=params, headers=headers)

    def query(self, path: str) -> AsyncQueryBuilder:
        """Create async query builder for complex queries"""
        return AsyncQueryBuilder(self, path)

    def auth(self) -> AsyncAuthHelper:
        """Get async authentication helper"""
        if self._auth_helper is None:
            self._auth_helper = AsyncAuthHelper(self)
        return self._auth_helper

    async def __aenter__(self) -> "AsyncFlowfullClient":
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit"""
        await self.request_handler.close()

