"""
Flowfull-Python Client - Storage Interface

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

from typing import Protocol, Optional, Dict
import json
import os
from pathlib import Path


class Storage(Protocol):
    """Storage interface for session persistence"""

    def get_item(self, key: str) -> Optional[str]:
        """Get item from storage"""
        ...

    def set_item(self, key: str, value: str) -> None:
        """Set item in storage"""
        ...

    def remove_item(self, key: str) -> None:
        """Remove item from storage"""
        ...

    def clear(self) -> None:
        """Clear all items from storage"""
        ...


class MemoryStorage:
    """In-memory storage implementation"""

    def __init__(self) -> None:
        self._storage: Dict[str, str] = {}

    def get_item(self, key: str) -> Optional[str]:
        """Get item from memory storage"""
        return self._storage.get(key)

    def set_item(self, key: str, value: str) -> None:
        """Set item in memory storage"""
        self._storage[key] = value

    def remove_item(self, key: str) -> None:
        """Remove item from memory storage"""
        self._storage.pop(key, None)

    def clear(self) -> None:
        """Clear all items from memory storage"""
        self._storage.clear()


class FileStorage:
    """File-based storage implementation"""

    def __init__(self, storage_path: Optional[str] = None) -> None:
        """
        Initialize file storage

        Args:
            storage_path: Path to storage directory (default: ~/.flowfull)
        """
        if storage_path is None:
            home = Path.home()
            storage_path = str(home / ".flowfull")

        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.storage_file = self.storage_path / "storage.json"

        # Initialize storage file if it doesn't exist
        if not self.storage_file.exists():
            self._save({})

    def _load(self) -> Dict[str, str]:
        """Load storage from file"""
        try:
            with open(self.storage_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save(self, data: Dict[str, str]) -> None:
        """Save storage to file"""
        with open(self.storage_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def get_item(self, key: str) -> Optional[str]:
        """Get item from file storage"""
        data = self._load()
        return data.get(key)

    def set_item(self, key: str, value: str) -> None:
        """Set item in file storage"""
        data = self._load()
        data[key] = value
        self._save(data)

    def remove_item(self, key: str) -> None:
        """Remove item from file storage"""
        data = self._load()
        data.pop(key, None)
        self._save(data)

    def clear(self) -> None:
        """Clear all items from file storage"""
        self._save({})

