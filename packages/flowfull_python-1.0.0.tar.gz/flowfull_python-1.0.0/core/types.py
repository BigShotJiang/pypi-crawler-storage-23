"""
Flowfull-Python Client - Type Definitions

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

from pydantic import BaseModel, EmailStr, Field, ConfigDict
from typing import Optional, Any, Dict, List, Callable, Literal
from datetime import datetime
from enum import Enum


# ============================================================================
# Core Response Types
# ============================================================================


class PaginationMeta(BaseModel):
    """Pagination metadata"""

    page: Optional[int] = None
    limit: Optional[int] = None
    total: Optional[int] = None
    total_pages: Optional[int] = Field(None, alias="totalPages")

    model_config = ConfigDict(populate_by_name=True)


class ApiResponse(BaseModel):
    """Standard API response"""

    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    message: Optional[str] = None
    status: int = 200
    meta: Optional[PaginationMeta] = None

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Configuration Types
# ============================================================================


class SessionConfig(BaseModel):
    """Session configuration"""

    include_session: bool = False
    session_header: str = "X-Session-ID"
    storage_key: str = "pubflow_session_id"
    user_data_key: str = "pubflow_user_data"


class RetryConfig(BaseModel):
    """Retry configuration"""

    attempts: int = 3
    delay: float = 1.0
    exponential: bool = True
    max_delay: float = 30.0


class FlowfullConfig(BaseModel):
    """Flowfull client configuration"""

    base_url: str
    session_id: Optional[str] = None
    get_session_id: Optional[Callable[[], Optional[str]]] = None
    timeout: float = 30.0
    headers: Optional[Dict[str, str]] = None
    retry_attempts: int = 3
    retry_delay: float = 1.0
    retry_exponential: bool = True
    session_config: SessionConfig = Field(default_factory=SessionConfig)

    model_config = ConfigDict(arbitrary_types_allowed=True)


# ============================================================================
# Authentication Types
# ============================================================================


class User(BaseModel):
    """User profile model"""

    id: str
    email: EmailStr
    name: str
    last_name: Optional[str] = None
    user_name: Optional[str] = None
    user_type: Optional[str] = None
    picture: Optional[str] = None
    phone: Optional[str] = None
    is_verified: bool = False
    two_factor: bool = False
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(populate_by_name=True)


class Session(BaseModel):
    """Session model"""

    id: str
    user_id: str
    expires_at: datetime
    ip_address: str
    user_agent: str
    last_used_at: datetime

    model_config = ConfigDict(populate_by_name=True)


class LoginCredentials(BaseModel):
    """Login credentials (email or username)"""

    email: Optional[EmailStr] = None
    user_name: Optional[str] = None
    password: str = Field(..., min_length=8)

    model_config = ConfigDict(validate_assignment=True)


class RegisterData(BaseModel):
    """Public registration data"""

    email: EmailStr
    password: str = Field(..., min_length=8)
    name: str
    last_name: Optional[str] = None
    user_name: Optional[str] = None
    phone: Optional[str] = None
    user_type: Optional[str] = None


class LoginResult(BaseModel):
    """Login/register result"""

    success: bool
    user: User
    session_id: str = Field(..., alias="sessionId")
    expires_at: datetime = Field(..., alias="expiresAt")
    message: Optional[str] = None
    is_new_user: Optional[bool] = Field(None, alias="isNewUser")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Password Management Types
# ============================================================================


class PasswordResetRequest(BaseModel):
    """Password reset request"""

    email: EmailStr


class TokenValidation(BaseModel):
    """Token validation request"""

    token: str


class ValidationResult(BaseModel):
    """Token validation result"""

    success: bool
    valid: bool
    message: Optional[str] = None


class PasswordResetComplete(BaseModel):
    """Complete password reset"""

    token: str
    new_password: str = Field(..., min_length=8)


class PasswordChange(BaseModel):
    """Change password (authenticated)"""

    current_password: str
    new_password: str = Field(..., min_length=8)


class ResendVerification(BaseModel):
    """Resend verification email"""

    email: EmailStr


# ============================================================================
# Token Authentication Types
# ============================================================================


class TokenCreate(BaseModel):
    """Create login token"""

    email: EmailStr
    expires_in: Optional[int] = 3600  # seconds


class TokenCreateResult(BaseModel):
    """Token creation result"""

    success: bool
    token: str
    expires_at: datetime = Field(..., alias="expiresAt")

    model_config = ConfigDict(populate_by_name=True)


# ============================================================================
# Social Authentication Types
# ============================================================================


class SocialProvider(str, Enum):
    """Supported social providers"""

    GOOGLE = "google"
    FACEBOOK = "facebook"
    GITHUB = "github"
    APPLE = "apple"


class SocialProviderInfo(BaseModel):
    """Social provider information"""

    provider: str
    enabled: bool
    client_id: Optional[str] = None
    redirect_uri: Optional[str] = None


class SocialProvidersResult(BaseModel):
    """List of available social providers"""

    success: bool
    providers: List[SocialProviderInfo]


class SocialLoginData(BaseModel):
    """Social login data"""

    provider: SocialProvider
    access_token: str
    id_token: Optional[str] = None


class SocialAccount(BaseModel):
    """Linked social account"""

    id: str
    user_id: str
    provider: str
    provider_user_id: str
    email: Optional[str] = None
    created_at: datetime

    model_config = ConfigDict(populate_by_name=True)


class SocialAccountsResult(BaseModel):
    """User's linked social accounts"""

    success: bool
    accounts: List[SocialAccount]


# ============================================================================
# Session Management Types
# ============================================================================


class SessionValidationResult(BaseModel):
    """Session validation result"""

    success: bool
    valid: bool
    user: Optional[User] = None
    session: Optional[Session] = None


# ============================================================================
# Profile Management Types
# ============================================================================


class ProfileUpdate(BaseModel):
    """Profile update data"""

    name: Optional[str] = None
    last_name: Optional[str] = None
    user_name: Optional[str] = None
    phone: Optional[str] = None
    picture: Optional[str] = None


class PictureUploadResult(BaseModel):
    """Picture upload result"""

    success: bool
    url: str
    message: Optional[str] = None

