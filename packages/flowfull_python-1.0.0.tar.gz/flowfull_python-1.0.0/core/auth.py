"""
Flowfull-Python Client - Authentication Helper

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import json
from typing import TYPE_CHECKING, Optional, List
from .types import (
    LoginCredentials,
    RegisterData,
    LoginResult,
    User,
    PasswordResetRequest,
    TokenValidation,
    ValidationResult,
    PasswordResetComplete,
    PasswordChange,
    ResendVerification,
    TokenCreate,
    TokenCreateResult,
    SocialProvidersResult,
    SocialLoginData,
    SocialAccountsResult,
    SessionValidationResult,
    ProfileUpdate,
    PictureUploadResult,
)
from .errors import AuthenticationError

if TYPE_CHECKING:
    from .client import FlowfullClient


class AuthHelper:
    """Authentication helper for Flowfull client"""

    def __init__(self, client: "FlowfullClient") -> None:
        """
        Initialize auth helper

        Args:
            client: FlowfullClient instance
        """
        self.client = client
        self.base_path = "/auth"

    # ========================================================================
    # Core Authentication
    # ========================================================================

    def login(
        self,
        email: Optional[str] = None,
        user_name: Optional[str] = None,
        password: str = "",
    ) -> LoginResult:
        """
        Login with email/username and password

        Args:
            email: User email
            user_name: Username
            password: Password

        Returns:
            LoginResult with user and session data

        Raises:
            AuthenticationError: If login fails
        """
        credentials = LoginCredentials(
            email=email,
            user_name=user_name,
            password=password,
        )

        response = self.client.post(
            f"{self.base_path}/login",
            json=credentials.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    def register(self, data: RegisterData) -> LoginResult:
        """
        Register new user (public registration)

        Args:
            data: Registration data

        Returns:
            LoginResult with user and session data

        Raises:
            AuthenticationError: If registration fails
        """
        response = self.client.post(
            f"{self.base_path}/register",
            json=data.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Registration failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    def logout(self) -> bool:
        """
        Logout current user

        Returns:
            True if logout successful

        Raises:
            AuthenticationError: If logout fails
        """
        response = self.client.post(f"{self.base_path}/logout")

        if not response.success:
            raise AuthenticationError(response.error or "Logout failed")

        # Clear session and user data
        self.client.session_manager.clear_session()

        return True

    def validate_session(self) -> SessionValidationResult:
        """
        Validate current session

        Returns:
            SessionValidationResult with validation status

        Raises:
            AuthenticationError: If validation fails
        """
        response = self.client.get(f"{self.base_path}/validate")

        if not response.success:
            raise AuthenticationError(response.error or "Session validation failed")

        return SessionValidationResult(**response.data)

    def refresh_user(self) -> User:
        """
        Refresh user data from server

        Returns:
            Updated User object

        Raises:
            AuthenticationError: If refresh fails
        """
        response = self.client.get(f"{self.base_path}/refresh")

        if not response.success:
            raise AuthenticationError(response.error or "User refresh failed")

        user = User(**response.data)

        # Update stored user data
        self.client.session_manager.set_user_data(user.model_dump_json())

        return user

    # ========================================================================
    # Password Management
    # ========================================================================

    def request_password_reset(self, email: str) -> bool:
        """
        Request password reset email

        Args:
            email: User email

        Returns:
            True if request successful
        """
        data = PasswordResetRequest(email=email)
        response = self.client.post(
            f"{self.base_path}/password/reset/request",
            json=data.model_dump(),
        )
        return response.success

    def validate_reset_token(self, token: str) -> ValidationResult:
        """
        Validate password reset token

        Args:
            token: Reset token

        Returns:
            ValidationResult
        """
        data = TokenValidation(token=token)
        response = self.client.post(
            f"{self.base_path}/password/reset/validate",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token validation failed")

        return ValidationResult(**response.data)

    def complete_password_reset(self, token: str, new_password: str) -> bool:
        """
        Complete password reset with token

        Args:
            token: Reset token
            new_password: New password

        Returns:
            True if reset successful
        """
        data = PasswordResetComplete(token=token, new_password=new_password)
        response = self.client.post(
            f"{self.base_path}/password/reset/complete",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Password reset failed")

        return True

    def change_password(self, current_password: str, new_password: str) -> bool:
        """
        Change password (authenticated)

        Args:
            current_password: Current password
            new_password: New password

        Returns:
            True if change successful
        """
        data = PasswordChange(current_password=current_password, new_password=new_password)
        response = self.client.post(
            f"{self.base_path}/password/change",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Password change failed")

        return True

    # ========================================================================
    # Email Verification
    # ========================================================================

    def verify_email(self, token: str) -> bool:
        """
        Verify email with token

        Args:
            token: Verification token

        Returns:
            True if verification successful
        """
        data = TokenValidation(token=token)
        response = self.client.post(
            f"{self.base_path}/email/verify",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Email verification failed")

        return True

    def resend_verification(self, email: str) -> bool:
        """
        Resend verification email

        Args:
            email: User email

        Returns:
            True if resend successful
        """
        data = ResendVerification(email=email)
        response = self.client.post(
            f"{self.base_path}/email/resend",
            json=data.model_dump(),
        )
        return response.success

    # ========================================================================
    # Token Authentication
    # ========================================================================

    def create_login_token(self, email: str, expires_in: int = 3600) -> TokenCreateResult:
        """
        Create login token

        Args:
            email: User email
            expires_in: Token expiration in seconds

        Returns:
            TokenCreateResult with token
        """
        data = TokenCreate(email=email, expires_in=expires_in)
        response = self.client.post(
            f"{self.base_path}/token/create",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token creation failed")

        return TokenCreateResult(**response.data)

    def login_with_token(self, token: str) -> LoginResult:
        """
        Login with token

        Args:
            token: Login token

        Returns:
            LoginResult with user and session data
        """
        data = TokenValidation(token=token)
        response = self.client.post(
            f"{self.base_path}/token/login",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Token login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    # ========================================================================
    # Social Authentication
    # ========================================================================

    def get_social_providers(self) -> SocialProvidersResult:
        """
        Get available social providers

        Returns:
            SocialProvidersResult with provider list
        """
        response = self.client.get(f"{self.base_path}/social/providers")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get social providers")

        return SocialProvidersResult(**response.data)

    def login_with_social(self, data: SocialLoginData) -> LoginResult:
        """
        Login with social provider

        Args:
            data: Social login data

        Returns:
            LoginResult with user and session data
        """
        response = self.client.post(
            f"{self.base_path}/social/login",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Social login failed")

        result = LoginResult(**response.data)

        # Store session and user data
        self.client.session_manager.set_session_id(result.session_id)
        self.client.session_manager.set_user_data(result.user.model_dump_json())

        return result

    def get_social_accounts(self) -> SocialAccountsResult:
        """
        Get user's linked social accounts

        Returns:
            SocialAccountsResult with account list
        """
        response = self.client.get(f"{self.base_path}/social/accounts")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get social accounts")

        return SocialAccountsResult(**response.data)

    def link_social_account(self, data: SocialLoginData) -> bool:
        """
        Link social account to current user

        Args:
            data: Social login data

        Returns:
            True if linking successful
        """
        response = self.client.post(
            f"{self.base_path}/social/link",
            json=data.model_dump(),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to link social account")

        return True

    def unlink_social_account(self, provider: str) -> bool:
        """
        Unlink social account

        Args:
            provider: Provider name (google, facebook, etc.)

        Returns:
            True if unlinking successful
        """
        response = self.client.delete(f"{self.base_path}/social/unlink/{provider}")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to unlink social account")

        return True

    # ========================================================================
    # Profile Management
    # ========================================================================

    def get_profile(self) -> User:
        """
        Get current user profile

        Returns:
            User object
        """
        response = self.client.get(f"{self.base_path}/profile")

        if not response.success:
            raise AuthenticationError(response.error or "Failed to get profile")

        return User(**response.data)

    def update_profile(self, data: ProfileUpdate) -> User:
        """
        Update user profile

        Args:
            data: Profile update data

        Returns:
            Updated User object
        """
        response = self.client.patch(
            f"{self.base_path}/profile",
            json=data.model_dump(exclude_none=True),
        )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to update profile")

        user = User(**response.data)

        # Update stored user data
        self.client.session_manager.set_user_data(user.model_dump_json())

        return user

    def upload_picture(self, file_path: str) -> PictureUploadResult:
        """
        Upload profile picture

        Args:
            file_path: Path to image file

        Returns:
            PictureUploadResult with image URL
        """
        with open(file_path, "rb") as f:
            files = {"file": f}
            response = self.client.post(
                f"{self.base_path}/profile/picture",
                files=files,
            )

        if not response.success:
            raise AuthenticationError(response.error or "Failed to upload picture")

        return PictureUploadResult(**response.data)

