"""
Tests for Storage

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
import tempfile
import os
from pathlib import Path
from core.storage import MemoryStorage, FileStorage


class TestMemoryStorage:
    """Test memory storage implementation"""

    def test_set_and_get(self):
        storage = MemoryStorage()
        storage.set_item("key1", "value1")
        assert storage.get_item("key1") == "value1"

    def test_get_nonexistent(self):
        storage = MemoryStorage()
        assert storage.get_item("nonexistent") is None

    def test_remove_item(self):
        storage = MemoryStorage()
        storage.set_item("key1", "value1")
        storage.remove_item("key1")
        assert storage.get_item("key1") is None

    def test_clear(self):
        storage = MemoryStorage()
        storage.set_item("key1", "value1")
        storage.set_item("key2", "value2")
        storage.clear()
        assert storage.get_item("key1") is None
        assert storage.get_item("key2") is None


class TestFileStorage:
    """Test file storage implementation"""

    def test_set_and_get(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = FileStorage(tmpdir)
            storage.set_item("key1", "value1")
            assert storage.get_item("key1") == "value1"

    def test_persistence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create storage and set item
            storage1 = FileStorage(tmpdir)
            storage1.set_item("key1", "value1")

            # Create new storage instance with same path
            storage2 = FileStorage(tmpdir)
            assert storage2.get_item("key1") == "value1"

    def test_remove_item(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = FileStorage(tmpdir)
            storage.set_item("key1", "value1")
            storage.remove_item("key1")
            assert storage.get_item("key1") is None

    def test_clear(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            storage = FileStorage(tmpdir)
            storage.set_item("key1", "value1")
            storage.set_item("key2", "value2")
            storage.clear()
            assert storage.get_item("key1") is None
            assert storage.get_item("key2") is None

    def test_default_path(self):
        storage = FileStorage()
        assert storage.storage_path.exists()
        # Cleanup
        storage.clear()

