"""
Tests for Session Manager

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
import os
from core.session import SessionManager
from core.storage import MemoryStorage


class TestSessionManager:
    """Test session manager functionality"""

    def test_static_session_id(self):
        """Test static session_id has highest priority"""
        storage = MemoryStorage()
        storage.set_item("session_id", "storage_session")
        
        manager = SessionManager(
            session_id="static_session",
            storage=storage
        )
        
        assert manager.get_session_id() == "static_session"

    def test_get_session_id_function(self):
        """Test get_session_id function has second priority"""
        storage = MemoryStorage()
        storage.set_item("session_id", "storage_session")
        
        def get_session():
            return "function_session"
        
        manager = SessionManager(
            get_session_id=get_session,
            storage=storage
        )
        
        assert manager.get_session_id() == "function_session"

    def test_storage_session_id(self):
        """Test storage has third priority"""
        storage = MemoryStorage()
        storage.set_item("pubflow_session_id", "storage_session")

        manager = SessionManager(storage=storage)

        assert manager.get_session_id() == "storage_session"

    def test_env_session_id(self):
        """Test environment variable has lowest priority"""
        os.environ["FLOWFULL_SESSION_ID"] = "env_session"
        
        manager = SessionManager()
        
        assert manager.get_session_id() == "env_session"
        
        # Cleanup
        del os.environ["FLOWFULL_SESSION_ID"]

    def test_no_session_id(self):
        """Test when no session_id is available"""
        manager = SessionManager()
        assert manager.get_session_id() is None

    def test_set_session_id(self):
        """Test setting session_id"""
        storage = MemoryStorage()
        manager = SessionManager(storage=storage)

        manager.set_session_id("new_session")

        assert manager.get_session_id() == "new_session"
        assert storage.get_item("pubflow_session_id") == "new_session"

    def test_clear_session(self):
        """Test clearing session"""
        storage = MemoryStorage()
        storage.set_item("pubflow_session_id", "test_session")
        storage.set_item("pubflow_user_data", '{"id": 1}')

        manager = SessionManager(storage=storage)
        manager.clear_session()

        assert storage.get_item("pubflow_session_id") is None
        assert storage.get_item("pubflow_user_data") is None

    def test_user_data(self):
        """Test user data storage"""
        storage = MemoryStorage()
        manager = SessionManager(storage=storage)
        
        user_json = '{"id": 1, "email": "test@example.com"}'
        manager.set_user_data(user_json)
        
        assert manager.get_user_data() == user_json

    def test_inject_session_header(self):
        """Test session header injection"""
        from core.types import SessionConfig
        config = SessionConfig(include_session=True)
        manager = SessionManager(session_id="test_session", config=config)

        headers = {}
        manager.inject_session_header(headers)

        assert headers["X-Session-ID"] == "test_session"

    def test_inject_session_header_no_session(self):
        """Test header injection when no session"""
        manager = SessionManager()
        
        headers = {}
        manager.inject_session_header(headers)
        
        assert "X-Session-Id" not in headers

