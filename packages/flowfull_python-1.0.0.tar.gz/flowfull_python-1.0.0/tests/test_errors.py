"""
Tests for Error Classes

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from core.errors import (
    FlowfullError,
    AuthenticationError,
    ValidationError,
    NetworkError,
    SessionError,
    QueryBuilderError
)


class TestFlowfullError:
    """Test base FlowfullError"""

    def test_base_error(self):
        """Test base error creation"""
        error = FlowfullError("Test error")
        assert str(error) == "Test error"

    def test_base_error_inheritance(self):
        """Test base error is Exception"""
        error = FlowfullError("Test")
        assert isinstance(error, Exception)


class TestAuthenticationError:
    """Test AuthenticationError"""

    def test_authentication_error(self):
        """Test authentication error"""
        error = AuthenticationError("Invalid credentials")
        assert str(error) == "Invalid credentials"
        assert isinstance(error, FlowfullError)


class TestValidationError:
    """Test ValidationError"""

    def test_validation_error(self):
        """Test validation error"""
        error = ValidationError("Invalid email format")
        assert str(error) == "Invalid email format"
        assert isinstance(error, FlowfullError)


class TestNetworkError:
    """Test NetworkError"""

    def test_network_error(self):
        """Test network error"""
        error = NetworkError("Connection timeout")
        assert str(error) == "Connection timeout"
        assert isinstance(error, FlowfullError)


class TestSessionError:
    """Test SessionError"""

    def test_session_error(self):
        """Test session error"""
        error = SessionError("Session expired")
        assert str(error) == "Session expired"
        assert isinstance(error, FlowfullError)


class TestQueryBuilderError:
    """Test QueryBuilderError"""

    def test_query_builder_error(self):
        """Test query builder error"""
        error = QueryBuilderError("Invalid operator")
        assert str(error) == "Invalid operator"
        assert isinstance(error, FlowfullError)


class TestErrorRaising:
    """Test error raising"""

    def test_raise_authentication_error(self):
        """Test raising authentication error"""
        with pytest.raises(AuthenticationError) as exc_info:
            raise AuthenticationError("Login failed")
        
        assert str(exc_info.value) == "Login failed"

    def test_raise_validation_error(self):
        """Test raising validation error"""
        with pytest.raises(ValidationError) as exc_info:
            raise ValidationError("Invalid data")
        
        assert str(exc_info.value) == "Invalid data"

    def test_catch_flowfull_error(self):
        """Test catching FlowfullError catches all"""
        with pytest.raises(FlowfullError):
            raise AuthenticationError("Test")
        
        with pytest.raises(FlowfullError):
            raise ValidationError("Test")
        
        with pytest.raises(FlowfullError):
            raise NetworkError("Test")

