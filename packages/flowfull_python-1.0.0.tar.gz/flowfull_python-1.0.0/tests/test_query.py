"""
Tests for Query Builder

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from unittest.mock import Mock, MagicMock
from core.query import QueryBuilder
from core.operators import eq, gte, in_, is_null
from core.types import ApiResponse


class TestQueryBuilder:
    """Test query builder functionality"""

    def test_where_single_filter(self):
        """Test single where filter"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.where("status", eq("active"))
        params = qb._build_params()
        
        assert params["status[eq]"] == "active"

    def test_where_multiple_filters(self):
        """Test multiple where filters"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.where("status", eq("active"))
        qb.where("age", gte(18))

        params = qb._build_params()

        assert params["status[eq]"] == "active"
        assert params["age[gte]"] == "18"

    def test_where_array_filter(self):
        """Test array filter"""
        client = Mock()
        qb = QueryBuilder(client, "/users")

        qb.where("role", in_(["admin", "user"]))
        params = qb._build_params()

        assert params["role[in]"] == "admin,user"

    def test_where_null_filter(self):
        """Test null filter"""
        client = Mock()
        qb = QueryBuilder(client, "/users")

        qb.where("deleted_at", is_null())
        params = qb._build_params()

        assert params["deleted_at[null]"] == "True"

    def test_search(self):
        """Test search parameter"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.search("john")
        params = qb._build_params()
        
        assert params["search"] == "john"

    def test_sort_ascending(self):
        """Test sort ascending"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.sort("name", "asc")
        params = qb._build_params()
        
        assert params["sort"] == "name"
        assert params["order"] == "asc"

    def test_sort_descending(self):
        """Test sort descending"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.sort("created_at", "desc")
        params = qb._build_params()
        
        assert params["sort"] == "created_at"
        assert params["order"] == "desc"

    def test_pagination(self):
        """Test pagination"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        qb.page(2).limit(50)
        params = qb._build_params()
        
        assert params["page"] == 2
        assert params["limit"] == 50

    def test_chaining(self):
        """Test method chaining"""
        client = Mock()
        qb = QueryBuilder(client, "/users")
        
        result = (
            qb.where("status", eq("active"))
            .where("age", gte(18))
            .search("john")
            .sort("name", "asc")
            .page(1)
            .limit(20)
        )
        
        assert result is qb
        params = qb._build_params()

        assert params["status[eq]"] == "active"
        assert params["age[gte]"] == "18"
        assert params["search"] == "john"
        assert params["sort"] == "name"
        assert params["order"] == "asc"
        assert params["page"] == 1
        assert params["limit"] == 20

    def test_get(self):
        """Test get method"""
        client = Mock()
        client.get = Mock(return_value=ApiResponse(
            success=True,
            data=[{"id": 1, "name": "John"}],
            error=None,
            meta=None
        ))
        
        qb = QueryBuilder(client, "/users")
        qb.where("status", eq("active"))
        
        response = qb.get()
        
        assert response.success is True
        assert len(response.data) == 1
        client.get.assert_called_once()

