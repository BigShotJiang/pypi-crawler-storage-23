"""
Tests for Filter Operators

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from core.operators import (
    eq, ne, gt, gte, lt, lte,
    like, ilike, starts_with, ends_with,
    in_, not_in,
    is_null, is_not_null,
    between, not_between
)


class TestComparisonOperators:
    """Test comparison operators"""

    def test_eq(self):
        assert eq("active") == ("eq", "active")
        assert eq(42) == ("eq", 42)

    def test_ne(self):
        assert ne("inactive") == ("ne", "inactive")

    def test_gt(self):
        assert gt(50) == ("gt", 50)

    def test_gte(self):
        assert gte(50) == ("gte", 50)

    def test_lt(self):
        assert lt(100) == ("lt", 100)

    def test_lte(self):
        assert lte(100) == ("lte", 100)


class TestStringOperators:
    """Test string operators"""

    def test_like(self):
        assert like("%test%") == ("like", "%test%")

    def test_ilike(self):
        assert ilike("%test%") == ("ilike", "%test%")

    def test_starts_with(self):
        assert starts_with("prefix") == ("starts_with", "prefix")

    def test_ends_with(self):
        assert ends_with("suffix") == ("ends_with", "suffix")


class TestArrayOperators:
    """Test array operators"""

    def test_in(self):
        assert in_(["a", "b", "c"]) == ("in", ["a", "b", "c"])

    def test_not_in(self):
        assert not_in([1, 2, 3]) == ("nin", [1, 2, 3])


class TestNullOperators:
    """Test null operators"""

    def test_is_null(self):
        assert is_null() == ("null", True)

    def test_is_not_null(self):
        assert is_not_null() == ("notNull", True)


class TestRangeOperators:
    """Test range operators"""

    def test_between(self):
        assert between(10, 100) == ("between", "10,100")

    def test_not_between(self):
        assert not_between(10, 100) == ("notBetween", "10,100")

