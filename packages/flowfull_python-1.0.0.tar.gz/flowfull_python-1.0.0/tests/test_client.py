"""
Tests for FlowfullClient

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from core.client import FlowfullClient
from core.query import QueryBuilder
from core.auth import AuthHelper
from core.storage import MemoryStorage
from core.types import ApiResponse


class TestFlowfullClient:
    """Test FlowfullClient functionality"""

    def test_client_initialization(self):
        """Test client initialization"""
        client = FlowfullClient("https://api.example.com")

        assert client.config.base_url == "https://api.example.com"
        assert client.session_manager is not None
        assert client.request_handler is not None

    def test_client_with_custom_config(self):
        """Test client with custom configuration"""
        storage = MemoryStorage()
        client = FlowfullClient(
            base_url="https://api.example.com",
            storage=storage,
            timeout=60.0,
            retry_attempts=5,
            retry_delay=2.0,
            retry_exponential=True,
            include_session=True
        )

        assert client.config.timeout == 60.0
        assert client.config.retry_attempts == 5
        assert client.config.session_config.include_session is True

    def test_client_with_session_id(self):
        """Test client with static session ID"""
        client = FlowfullClient(
            base_url="https://api.example.com",
            session_id="test-session-123"
        )
        
        assert client.session_manager.get_session_id() == "test-session-123"

    @patch('core.request.RequestHandler.request')
    def test_get_request(self, mock_request):
        """Test GET request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=[{"id": 1}],
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        response = client.get("/users")
        
        assert response.success is True
        assert len(response.data) == 1
        mock_request.assert_called_once()

    @patch('core.request.RequestHandler.request')
    def test_post_request(self, mock_request):
        """Test POST request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "New User"},
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        response = client.post("/users", json={"name": "New User"})
        
        assert response.success is True
        assert response.data["name"] == "New User"

    @patch('core.request.RequestHandler.request')
    def test_put_request(self, mock_request):
        """Test PUT request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "Updated User"},
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        response = client.put("/users/1", json={"name": "Updated User"})
        
        assert response.success is True
        assert response.data["name"] == "Updated User"

    @patch('core.request.RequestHandler.request')
    def test_patch_request(self, mock_request):
        """Test PATCH request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "Patched User"},
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        response = client.patch("/users/1", json={"name": "Patched User"})
        
        assert response.success is True

    @patch('core.request.RequestHandler.request')
    def test_delete_request(self, mock_request):
        """Test DELETE request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=None,
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        response = client.delete("/users/1")
        
        assert response.success is True

    def test_query_builder(self):
        """Test query builder creation"""
        client = FlowfullClient("https://api.example.com")
        qb = client.query("/products")

        assert isinstance(qb, QueryBuilder)
        assert qb._path == "/products"

    def test_auth_helper(self):
        """Test auth helper creation"""
        client = FlowfullClient("https://api.example.com")
        auth = client.auth()

        assert isinstance(auth, AuthHelper)

    @patch('core.request.RequestHandler.request')
    def test_session_injection(self, mock_request):
        """Test session ID injection in requests"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=[],
            error=None,
            meta=None
        )
        
        client = FlowfullClient(
            base_url="https://api.example.com",
            session_id="test-session",
            include_session=True
        )
        
        client.get("/users")
        
        # Verify session was injected
        call_args = mock_request.call_args
        headers = call_args[1].get('headers', {})
        assert 'X-Session-Id' in headers or client.session_manager.get_session_id() == "test-session"

    @patch('core.request.RequestHandler.request')
    def test_custom_headers(self, mock_request):
        """Test custom headers in request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=[],
            error=None,
            meta=None
        )
        
        client = FlowfullClient("https://api.example.com")
        client.get("/users", headers={"X-Custom-Header": "value"})
        
        call_args = mock_request.call_args
        headers = call_args[1].get('headers', {})
        assert headers.get("X-Custom-Header") == "value"

