"""
Tests for AsyncFlowfullClient

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from unittest.mock import Mock, patch, AsyncMock
from core.async_client import AsyncFlowfullClient
from core.async_query import AsyncQueryBuilder
from core.async_auth import AsyncAuthHelper
from core.storage import MemoryStorage
from core.types import ApiResponse


class TestAsyncFlowfullClient:
    """Test AsyncFlowfullClient functionality"""

    @pytest.mark.asyncio
    async def test_client_initialization(self):
        """Test async client initialization"""
        async with AsyncFlowfullClient("https://api.example.com") as client:
            assert client.config.base_url == "https://api.example.com"
            assert client.session_manager is not None
            assert client.request_handler is not None

    @pytest.mark.asyncio
    async def test_client_with_custom_config(self):
        """Test async client with custom configuration"""
        storage = MemoryStorage()
        async with AsyncFlowfullClient(
            base_url="https://api.example.com",
            storage=storage,
            timeout=60.0,
            retry_attempts=5,
            retry_delay=2.0,
            retry_exponential=True,
            include_session=True
        ) as client:
            assert client.config.timeout == 60.0
            assert client.config.retry_attempts == 5
            assert client.config.session_config.include_session is True

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test async context manager"""
        async with AsyncFlowfullClient("https://api.example.com") as client:
            assert client is not None
        
        # Client should be closed after context

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_get_request(self, mock_request):
        """Test async GET request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=[{"id": 1}],
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            response = await client.get("/users")
            
            assert response.success is True
            assert len(response.data) == 1

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_post_request(self, mock_request):
        """Test async POST request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "New User"},
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            response = await client.post("/users", json={"name": "New User"})
            
            assert response.success is True
            assert response.data["name"] == "New User"

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_put_request(self, mock_request):
        """Test async PUT request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "Updated User"},
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            response = await client.put("/users/1", json={"name": "Updated User"})
            
            assert response.success is True

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_patch_request(self, mock_request):
        """Test async PATCH request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data={"id": 1, "name": "Patched User"},
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            response = await client.patch("/users/1", json={"name": "Patched User"})
            
            assert response.success is True

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_delete_request(self, mock_request):
        """Test async DELETE request"""
        mock_request.return_value = ApiResponse(
            success=True,
            data=None,
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            response = await client.delete("/users/1")
            
            assert response.success is True

    @pytest.mark.asyncio
    async def test_query_builder(self):
        """Test async query builder creation"""
        async with AsyncFlowfullClient("https://api.example.com") as client:
            qb = client.query("/products")

            assert isinstance(qb, AsyncQueryBuilder)
            assert qb._path == "/products"

    @pytest.mark.asyncio
    async def test_auth_helper(self):
        """Test async auth helper creation"""
        async with AsyncFlowfullClient("https://api.example.com") as client:
            auth = client.auth()
            
            assert isinstance(auth, AsyncAuthHelper)

    @pytest.mark.asyncio
    @patch('core.async_request.AsyncRequestHandler.request', new_callable=AsyncMock)
    async def test_concurrent_requests(self, mock_request):
        """Test concurrent async requests"""
        import asyncio
        
        mock_request.return_value = ApiResponse(
            success=True,
            data=[],
            error=None,
            meta=None
        )
        
        async with AsyncFlowfullClient("https://api.example.com") as client:
            # Execute multiple requests concurrently
            results = await asyncio.gather(
                client.get("/users"),
                client.get("/products"),
                client.get("/orders")
            )
            
            assert len(results) == 3
            assert all(r.success for r in results)

