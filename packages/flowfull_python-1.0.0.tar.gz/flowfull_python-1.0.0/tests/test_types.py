"""
Tests for Type Definitions

This file is part of Flowfull-Python Client.
License: AGPL-3.0-or-later
"""

import pytest
from pydantic import ValidationError
from core.types import (
    ApiResponse,
    PaginationMeta,
    User,
    LoginCredentials,
    RegisterData,
    LoginResult,
    PasswordResetRequest,
    SocialProvider,
    ProfileUpdate
)


class TestApiResponse:
    """Test ApiResponse model"""

    def test_success_response(self):
        """Test successful response"""
        response = ApiResponse(
            success=True,
            data={"id": 1, "name": "Test"},
            error=None,
            meta=None
        )
        
        assert response.success is True
        assert response.data == {"id": 1, "name": "Test"}
        assert response.error is None

    def test_error_response(self):
        """Test error response"""
        response = ApiResponse(
            success=False,
            data=None,
            error="Something went wrong",
            meta=None
        )
        
        assert response.success is False
        assert response.error == "Something went wrong"


class TestPaginationMeta:
    """Test PaginationMeta model"""

    def test_pagination_meta(self):
        """Test pagination metadata"""
        meta = PaginationMeta(
            page=1,
            limit=20,
            total=100,
            total_pages=5
        )
        
        assert meta.page == 1
        assert meta.limit == 20
        assert meta.total == 100
        assert meta.total_pages == 5


class TestUser:
    """Test User model"""

    def test_user_creation(self):
        """Test user creation"""
        user = User(
            id="1",
            email="test@example.com",
            name="Test User",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z"
        )

        assert user.id == "1"
        assert user.email == "test@example.com"
        assert user.name == "Test User"

    def test_user_optional_fields(self):
        """Test user with optional fields"""
        user = User(
            id="1",
            email="test@example.com",
            name="Test User",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z"
        )

        assert user.last_name is None
        assert user.picture is None


class TestLoginCredentials:
    """Test LoginCredentials model"""

    def test_login_credentials(self):
        """Test login credentials"""
        creds = LoginCredentials(
            email="test@example.com",
            password="password123"
        )
        
        assert creds.email == "test@example.com"
        assert creds.password == "password123"


class TestRegisterData:
    """Test RegisterData model"""

    def test_register_data(self):
        """Test register data"""
        data = RegisterData(
            email="test@example.com",
            password="password123",
            name="Test User"
        )
        
        assert data.email == "test@example.com"
        assert data.password == "password123"
        assert data.name == "Test User"


class TestLoginResult:
    """Test LoginResult model"""

    def test_login_result(self):
        """Test login result"""
        user = User(
            id="1",
            email="test@example.com",
            name="Test User",
            created_at="2024-01-01T00:00:00Z",
            updated_at="2024-01-01T00:00:00Z"
        )

        result = LoginResult(
            success=True,
            session_id="session123",
            user=user,
            expires_at="2024-01-02T00:00:00Z"
        )

        assert result.success is True
        assert result.session_id == "session123"
        assert result.user.id == "1"


class TestPasswordResetRequest:
    """Test PasswordResetRequest model"""

    def test_password_reset_request(self):
        """Test password reset request"""
        request = PasswordResetRequest(email="test@example.com")
        
        assert request.email == "test@example.com"


class TestSocialProvider:
    """Test SocialProvider enum"""

    def test_social_providers(self):
        """Test social provider values"""
        assert SocialProvider.GOOGLE == "google"
        assert SocialProvider.FACEBOOK == "facebook"
        assert SocialProvider.GITHUB == "github"
        assert SocialProvider.APPLE == "apple"


class TestProfileUpdate:
    """Test ProfileUpdate model"""

    def test_profile_update(self):
        """Test profile update"""
        update = ProfileUpdate(
            name="New Name",
            phone="+1234567890"
        )

        assert update.name == "New Name"
        assert update.phone == "+1234567890"

    def test_profile_update_exclude_none(self):
        """Test profile update excludes None values"""
        update = ProfileUpdate(name="New Name")
        data = update.model_dump(exclude_none=True)

        assert "name" in data
        assert "phone" not in data

