"""Cost limit guard for the Synth SDK.

Tracks cumulative cost during a run and raises a violation when the
configured dollar limit is exceeded.
"""

from __future__ import annotations

from synth.guards.base import BaseGuard
from synth.types import GuardContext, GuardResult


class CostGuard(BaseGuard):
    """Guard that enforces a cumulative cost limit.

    Checks ``context.cumulative_cost`` against the configured dollar limit
    and returns a failing result when the cost exceeds the threshold.

    Parameters
    ----------
    limit:
        Maximum allowed cost in USD.
    """

    def __init__(self, limit: float) -> None:
        super().__init__(name="CostGuard")
        self.limit = limit

    async def check(self, content: str, context: GuardContext) -> GuardResult:
        """Check whether cumulative cost exceeds the limit.

        Parameters
        ----------
        content:
            The text to inspect (unused by this guard).
        context:
            Run context containing ``cumulative_cost``.

        Returns
        -------
        GuardResult
            Pass/fail result with violation details if cost exceeded.
        """
        if context.cumulative_cost > self.limit:
            return GuardResult(
                passed=False,
                violation_message=(
                    f"Cost limit exceeded: ${context.cumulative_cost:.4f} "
                    f"exceeds limit of ${self.limit:.4f}"
                ),
            )
        return GuardResult(passed=True)
