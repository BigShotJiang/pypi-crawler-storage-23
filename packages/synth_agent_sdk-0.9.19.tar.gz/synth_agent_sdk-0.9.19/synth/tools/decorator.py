"""``@tool`` decorator and JSON schema generation.

Inspects a function's signature, type hints, and docstring at decoration
time to produce a JSON schema compatible with the OpenAI function-calling
format.  The schema is stored on the function as ``fn._tool_schema``.
"""

from __future__ import annotations

import inspect
import typing
from typing import Any, Callable, Optional, get_args, get_origin

from synth.errors import ToolDefinitionError

# Type alias for a decorated tool function (just a regular callable with
# an extra ``_tool_schema`` attribute).
ToolFunction = Callable[..., Any]

# Mapping from Python built-in types to JSON Schema type strings.
_PYTHON_TO_JSON_SCHEMA: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def _is_optional(annotation: Any) -> tuple[bool, Any]:
    """Return ``(True, inner_type)`` if *annotation* is ``Optional[X]``, else ``(False, annotation)``."""
    origin = get_origin(annotation)
    if origin is typing.Union:
        args = get_args(annotation)
        # Optional[X] is Union[X, None]
        non_none = [a for a in args if a is not type(None)]
        if len(non_none) == 1 and type(None) in args:
            return True, non_none[0]
    return False, annotation


def _python_type_to_json_schema(annotation: Any) -> dict[str, str]:
    """Convert a Python type annotation to a JSON Schema type dict.

    Supports the basic types (str, int, float, bool, list, dict) and
    ``Optional[X]`` (which unwraps to the inner type).
    """
    # Unwrap Optional first
    is_opt, inner = _is_optional(annotation)
    if is_opt:
        annotation = inner

    # Handle bare generic aliases like list[str] → just "array"
    origin = get_origin(annotation)
    if origin is not None and origin in _PYTHON_TO_JSON_SCHEMA:
        return {"type": _PYTHON_TO_JSON_SCHEMA[origin]}

    if annotation in _PYTHON_TO_JSON_SCHEMA:
        return {"type": _PYTHON_TO_JSON_SCHEMA[annotation]}

    # Fallback for unknown types
    return {"type": "string"}


def _build_schema(fn: Callable[..., Any]) -> dict[str, Any]:
    """Build a JSON schema dict from *fn*'s signature and docstring."""
    sig = inspect.signature(fn)
    # Resolve string annotations (from __future__ annotations) to real types
    hints = typing.get_type_hints(fn)
    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        annotation = hints.get(name, param.annotation)
        is_opt, _ = _is_optional(annotation)
        has_default = param.default is not inspect.Parameter.empty

        prop = _python_type_to_json_schema(annotation)
        prop["description"] = ""
        properties[name] = prop

        # A parameter is required unless it's Optional[X] or has a default value
        if not is_opt and not has_default:
            required.append(name)

    schema: dict[str, Any] = {
        "name": fn.__name__,
        "description": (fn.__doc__ or "").strip(),
        "parameters": {
            "type": "object",
            "properties": properties,
            "required": required,
        },
    }
    return schema


def tool(fn: Callable[..., Any]) -> ToolFunction:
    """Decorator that validates annotations/docstring and generates JSON schema.

    Raises :class:`~synth.errors.ToolDefinitionError` at decoration time if:
    - Any parameter is missing a type annotation.
    - The function has no docstring.

    On success the generated schema is stored as ``fn._tool_schema``.
    """
    # --- Validate docstring ---------------------------------------------------
    if not fn.__doc__ or not fn.__doc__.strip():
        raise ToolDefinitionError(
            message=f"Function '{fn.__name__}' is missing a docstring.",
            component="@tool",
            suggestion="Add a docstring describing what the tool does.",
        )

    # --- Validate type annotations --------------------------------------------
    sig = inspect.signature(fn)
    for name, param in sig.parameters.items():
        if param.annotation is inspect.Parameter.empty:
            raise ToolDefinitionError(
                message=f"Parameter '{name}' of function '{fn.__name__}' is missing a type annotation.",
                component="@tool",
                suggestion=f"Add a type annotation to parameter '{name}', e.g. '{name}: str'.",
            )

    # --- Generate and attach schema -------------------------------------------
    fn._tool_schema = _build_schema(fn)  # type: ignore[attr-defined]
    return fn  # type: ignore[return-value]
