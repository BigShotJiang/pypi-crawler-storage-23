"""Graph class, ``@node`` decorator, and edge routing engine.

Provides a directed-graph orchestration construct where nodes represent
processing steps and edges (optionally conditional) define control flow.
Supports loops, branching, concurrent independent nodes, checkpointing,
human-in-the-loop pausing, and Mermaid visualisation.

Example::

    from synth import Graph

    graph = Graph()

    @node(graph)
    def classify(state):
        state["category"] = "urgent"
        return state

    @node(graph)
    def handle(state):
        state["handled"] = True
        return state

    graph.add_edge("classify", "handle")
    graph.add_edge("handle", Graph.END)
    graph.set_entry("classify")

    result = graph.run({"text": "help!"})
"""

from __future__ import annotations

import copy
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel

from synth._compat import run_sync
from synth.checkpointing.base import BaseCheckpointStore
from synth.errors import GraphLoopError, GraphRoutingError, RunNotFoundError
from synth.types import Checkpoint, RunResult, TokenUsage


# ---------------------------------------------------------------------------
# Sentinel for graph termination
# ---------------------------------------------------------------------------


class _EndSentinel:
    """Sentinel value representing graph termination."""

    def __repr__(self) -> str:
        return "Graph.END"


# ---------------------------------------------------------------------------
# Edge definition
# ---------------------------------------------------------------------------


@dataclass
class _Edge:
    """An edge from *source* to *target* with an optional condition."""

    source: str
    target: str | _EndSentinel
    when: Callable[[Any], bool] | None = None


# ---------------------------------------------------------------------------
# Graph
# ---------------------------------------------------------------------------


class Graph:
    """Directed-graph orchestration with conditional edges and loops.

    Parameters
    ----------
    state_schema:
        Optional Pydantic model to validate state after each node.
    """

    END: _EndSentinel = _EndSentinel()

    def __init__(
        self,
        state_schema: type[BaseModel] | None = None,
    ) -> None:
        self._nodes: dict[str, Callable[..., Any]] = {}
        self._edges: list[_Edge] = []
        self._entry: str | None = None
        self._state_schema = state_schema
        self._checkpoint_store: BaseCheckpointStore | None = None
        self._pause_at: list[str] = []
        self._pause_timeout: float | None = None
        self._pause_fallback: str | None = None

    # ------------------------------------------------------------------
    # Graph construction
    # ------------------------------------------------------------------

    def add_node(self, name: str, fn: Callable[..., Any]) -> None:
        """Register a processing node.

        Parameters
        ----------
        name:
            Unique node identifier.
        fn:
            Callable that receives state and returns updated state.
        """
        self._nodes[name] = fn

    def add_edge(
        self,
        source: str,
        target: str | _EndSentinel,
        when: Callable[[Any], bool] | None = None,
    ) -> None:
        """Add a directed edge between nodes.

        Parameters
        ----------
        source:
            Source node name.
        target:
            Target node name or ``Graph.END`` sentinel.
        when:
            Optional condition evaluated against the source node's
            returned state.  If ``None`` the edge is unconditional.
        """
        self._edges.append(_Edge(source=source, target=target, when=when))

    def set_entry(self, name: str) -> None:
        """Set the entry node for graph execution.

        Parameters
        ----------
        name:
            The node to start execution from.
        """
        self._entry = name

    def with_checkpointing(
        self,
        store: BaseCheckpointStore | None = None,
    ) -> Graph:
        """Enable checkpoint persistence after each node.

        Parameters
        ----------
        store:
            Checkpoint backend.  Defaults to ``LocalCheckpointStore``.

        Returns
        -------
        Graph
            Self, for method chaining.
        """
        if store is None:
            from synth.checkpointing.local import LocalCheckpointStore
            store = LocalCheckpointStore()
        self._checkpoint_store = store
        return self

    def with_human_in_the_loop(
        self,
        pause_at: list[str],
        timeout: float | None = None,
        fallback: str | None = None,
    ) -> Graph:
        """Configure human-in-the-loop pausing.

        Parameters
        ----------
        pause_at:
            Node names where execution should pause.
        timeout:
            Seconds to wait for ``resume()`` before aborting or
            routing to *fallback*.
        fallback:
            Node to route to on timeout.  If ``None``, the run aborts.

        Returns
        -------
        Graph
            Self, for method chaining.
        """
        self._pause_at = pause_at
        self._pause_timeout = timeout
        self._pause_fallback = fallback
        return self

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def run(
        self,
        input: Any,
        *,
        run_id: str | None = None,
        max_iterations: int = 100,
    ) -> RunResult:
        """Execute the graph synchronously.

        Parameters
        ----------
        input:
            Initial state passed to the entry node.
        run_id:
            Optional run identifier for checkpointing.
        max_iterations:
            Maximum node executions before raising ``GraphLoopError``.

        Returns
        -------
        RunResult
            The final state wrapped in a ``RunResult``.
        """
        return run_sync(
            self.arun(input, run_id=run_id, max_iterations=max_iterations),
        )

    async def arun(
        self,
        input: Any,
        *,
        run_id: str | None = None,
        max_iterations: int = 100,
    ) -> RunResult | Any:
        """Execute the graph asynchronously.

        Parameters
        ----------
        input:
            Initial state passed to the entry node.
        run_id:
            Optional run identifier for checkpointing.
        max_iterations:
            Maximum node executions before raising ``GraphLoopError``.

        Returns
        -------
        RunResult | PausedRun
            The final state as ``RunResult``, or a ``PausedRun`` if
            execution pauses for human-in-the-loop.
        """
        import time

        start_time = time.perf_counter()

        if self._entry is None:
            raise GraphRoutingError(
                message="No entry node set. Call graph.set_entry() first.",
                component="Graph",
                suggestion="Call graph.set_entry('node_name') before run().",
                node_name="<none>",
                current_state=input,
            )

        state = input
        current_node = self._entry
        node_history: list[str] = []
        step = 0

        for iteration in range(max_iterations):
            if current_node not in self._nodes:
                raise GraphRoutingError(
                    message=f"Node '{current_node}' not found in graph.",
                    component="Graph",
                    suggestion=f"Add node '{current_node}' with graph.add_node().",
                    node_name=current_node,
                    current_state=state,
                )

            node_history.append(current_node)

            # Execute the node
            fn = self._nodes[current_node]
            import asyncio
            if asyncio.iscoroutinefunction(fn):
                state = await fn(state)
            else:
                state = fn(state)

            # Validate state against schema if configured
            if self._state_schema is not None:
                self._state_schema.model_validate(state)

            step += 1

            # Checkpoint after each node
            if self._checkpoint_store and run_id:
                checkpoint = Checkpoint(
                    run_id=run_id,
                    state=state,
                    step=step,
                    node_name=current_node,
                    timestamp=datetime.now(timezone.utc),
                )
                await self._checkpoint_store.save(checkpoint)

            # Check for human-in-the-loop pause
            if current_node in self._pause_at:
                from synth.types import PausedRun
                checkpoint = Checkpoint(
                    run_id=run_id or "",
                    state=state,
                    step=step,
                    node_name=current_node,
                    timestamp=datetime.now(timezone.utc),
                )
                if self._checkpoint_store and run_id:
                    await self._checkpoint_store.save(checkpoint)
                return PausedRun(
                    run_id=run_id or "",
                    paused_at_node=current_node,
                    state=state,
                    checkpoint=checkpoint,
                )

            # Evaluate outbound edges
            next_node = self._resolve_next(current_node, state)

            # Check for termination
            if isinstance(next_node, _EndSentinel):
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                return RunResult(
                    text=str(state),
                    output=state,
                    tokens=TokenUsage(
                        input_tokens=0, output_tokens=0, total_tokens=0,
                    ),
                    cost=0.0,
                    latency_ms=elapsed_ms,
                    trace=None,
                    tool_calls=[],
                )

            current_node = next_node

        # Exceeded max_iterations
        raise GraphLoopError(
            message=(
                f"Graph exceeded {max_iterations} iterations. "
                f"Possible infinite loop detected."
            ),
            component="Graph",
            suggestion=(
                "Increase max_iterations or review edge conditions "
                "for cycles."
            ),
            node_history=node_history,
            max_iterations=max_iterations,
        )

    def resume(
        self,
        run_id: str,
        human_input: Any = None,
    ) -> RunResult | Any:
        """Resume a paused graph run synchronously.

        Parameters
        ----------
        run_id:
            The run identifier of the paused run.
        human_input:
            Input from the human to inject into the state.

        Returns
        -------
        RunResult | PausedRun
            The final result or another ``PausedRun``.
        """
        return run_sync(self.aresume(run_id, human_input=human_input))

    async def aresume(
        self,
        run_id: str,
        human_input: Any = None,
    ) -> RunResult | Any:
        """Resume a paused graph run asynchronously.

        Parameters
        ----------
        run_id:
            The run identifier of the paused run.
        human_input:
            Input from the human to inject into the state.

        Returns
        -------
        RunResult | PausedRun
            The final result or another ``PausedRun``.

        Raises
        ------
        RunNotFoundError
            If no checkpoint exists for *run_id*.
        """
        if self._checkpoint_store is None:
            raise RunNotFoundError(
                message=f"No checkpoint store configured for run '{run_id}'.",
                component="Graph",
                suggestion="Enable checkpointing with graph.with_checkpointing().",
                run_id=run_id,
            )

        checkpoint = await self._checkpoint_store.load(run_id)
        if checkpoint is None:
            raise RunNotFoundError(
                message=f"No checkpoint found for run_id '{run_id}'.",
                component="Graph",
                suggestion="Check that the run_id is correct.",
                run_id=run_id,
            )

        # Restore state and inject human input
        state = checkpoint.state
        if human_input is not None:
            if isinstance(state, dict):
                state["human_input"] = human_input
            else:
                state = human_input

        # Find the next node after the paused node
        next_node = self._resolve_next(checkpoint.node_name, state)

        if isinstance(next_node, _EndSentinel):
            return RunResult(
                text=str(state),
                output=state,
                tokens=TokenUsage(
                    input_tokens=0, output_tokens=0, total_tokens=0,
                ),
                cost=0.0,
                latency_ms=0.0,
                trace=None,
                tool_calls=[],
            )

        # Continue execution from the next node
        # Temporarily remove the pause_at for the resumed node
        # to avoid re-pausing immediately
        original_pause_at = self._pause_at[:]
        if checkpoint.node_name in self._pause_at:
            self._pause_at = [
                n for n in self._pause_at
                if n != checkpoint.node_name
            ]

        try:
            return await self.arun(
                state, run_id=run_id, max_iterations=100,
            )
        finally:
            self._pause_at = original_pause_at

    # ------------------------------------------------------------------
    # Visualisation
    # ------------------------------------------------------------------

    def visualise(self) -> str:
        """Render a Mermaid diagram string of the graph structure.

        Returns
        -------
        str
            A Mermaid diagram string.
        """
        lines = ["graph TD"]

        for name in self._nodes:
            lines.append(f"    {name}[\"{name}\"]")

        for edge in self._edges:
            target_name = (
                "END" if isinstance(edge.target, _EndSentinel)
                else edge.target
            )
            if isinstance(edge.target, _EndSentinel):
                lines.append(f"    END([\"END\"])")

            if edge.when is not None:
                label = getattr(edge.when, "__name__", "condition")
                lines.append(
                    f"    {edge.source} -->|{label}| {target_name}"
                )
            else:
                lines.append(f"    {edge.source} --> {target_name}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_next(
        self, current_node: str, state: Any,
    ) -> str | _EndSentinel:
        """Evaluate outbound edges and return the next node.

        Raises ``GraphRoutingError`` if no edge condition matches.
        """
        outbound = [e for e in self._edges if e.source == current_node]

        if not outbound:
            raise GraphRoutingError(
                message=(
                    f"Node '{current_node}' has no outbound edges."
                ),
                component="Graph",
                suggestion=(
                    f"Add an edge from '{current_node}' to another "
                    f"node or Graph.END."
                ),
                node_name=current_node,
                current_state=state,
            )

        # Evaluate conditional edges first, then unconditional
        for edge in outbound:
            if edge.when is not None and edge.when(state):
                return edge.target
            elif edge.when is None:
                return edge.target

        # No condition matched
        raise GraphRoutingError(
            message=(
                f"No outbound edge condition matched at node "
                f"'{current_node}'."
            ),
            component="Graph",
            suggestion=(
                "Add a default (unconditional) edge or review "
                "edge conditions."
            ),
            node_name=current_node,
            current_state=state,
        )


# ---------------------------------------------------------------------------
# @node decorator
# ---------------------------------------------------------------------------


def node(
    graph: Graph,
    name: str | None = None,
) -> Callable[..., Any]:
    """Decorator that registers a function as a graph node.

    Parameters
    ----------
    graph:
        The ``Graph`` instance to register the node on.
    name:
        Optional node name.  Defaults to ``fn.__name__``.

    Returns
    -------
    Callable
        The original function, unmodified.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        node_name = name or fn.__name__
        graph.add_node(node_name, fn)
        return fn

    return decorator
