# Requirements Document

## Introduction

This document specifies requirements for adding live AgentCore observability capabilities to the Synth SDK's browser-based testing dashboard. The feature connects the dashboard to a deployed AgentCore instance to pull real-time invocation logs, health status, memory state, cost/usage metrics, and enables remote invocation of the deployed agent. It also completes the stub-level `AgentCoreMemory` implementation to actually call AgentCore's managed memory API. This spec is scoped exclusively to live deployed-agent observability; static `agentcore.yaml` detection and local config panel features are covered by the separate `testing-ui-enhancements` spec.

## Glossary

- **Dashboard**: The browser-based testing UI served at `http://localhost:8420`, consisting of HTML, CSS, and vanilla JavaScript files in `synth/cli/_ui_assets/`.
- **Server**: The FastAPI backend (`server.py`) that loads the agent module, exposes API endpoints, and serves the Dashboard.
- **AgentCore_Client**: A new backend service class that wraps boto3 calls to AgentCore observability, invocation, and memory APIs, using credentials from the existing `CredentialResolver`.
- **CredentialResolver**: The existing `synth.deploy.agentcore.credentials.CredentialResolver` class that detects AWS credentials from environment variables, AWS profiles, and IDE toolkit extensions.
- **AgentCore_Config**: The parsed contents of the `agentcore.yaml` file, containing `agent_name`, `aws_region`, `model_id`, `aws_profile`, and `cris_enabled`.
- **Invocation_Log**: A record of a single AgentCore agent invocation, containing timestamp, prompt preview, response preview, latency, token counts, estimated cost, user ID, and success/error status.
- **Health_Status**: The current operational state of a deployed AgentCore agent, including agent status (active, deploying, failed), last deployment timestamp, runtime version, and deployed model ID.
- **Memory_Inspector**: A Dashboard UI section that displays memory thread data for both local Synth memory backends and AgentCore managed memory.
- **AgentCoreMemory**: The `synth.deploy.agentcore.memory.AgentCoreMemory` class that delegates memory operations to AgentCore's managed memory service.
- **BaseMemory**: The abstract base class `synth.memory.base.BaseMemory` defining `get_messages()` and `add_messages()` methods.
- **Cost_Dashboard**: A Dashboard UI section that displays aggregated cost, usage, and performance metrics from the deployed agent over time.
- **Remote_Invoke**: The capability to send a prompt to the deployed AgentCore agent via the AgentCore invocation API and display the response in the Dashboard.
- **Credential_Scrubbing**: The process of redacting AWS access keys, secret keys, and session tokens from all log output, API responses, and UI display, using `CredentialResolver.redact_credentials()`.
- **AgentCore_Evaluations**: The AgentCore Evaluations service that provides automated assessment of agent performance using built-in and custom LLM-as-a-Judge evaluators, with results published to CloudWatch.
- **Evaluation_Config**: A JSON configuration file (`eval_config.json`) specifying evaluator IDs, sampling rate, and default settings for AgentCore online evaluation.
- **On_Demand_Evaluation**: A one-time evaluation run against specific agent sessions or traces using selected evaluators.
- **Online_Evaluation**: Continuous automated evaluation of live agent traffic at a configurable sampling rate using AgentCore Evaluations.
- **Built_In_Evaluator**: A pre-defined AgentCore evaluator identified by ARN (e.g., `arn:aws:bedrock-agentcore:::evaluator/Builtin.Helpfulness`), operating at session, trace, or tool-call level.

## Requirements

### Requirement 1: AgentCore Client Service

**User Story:** As a developer, I want the Server to have a dedicated client for communicating with AgentCore APIs, so that all live observability features use a consistent, credential-safe interface.

#### Acceptance Criteria

1. WHEN the Server starts and an AgentCore_Config is detected, THE AgentCore_Client SHALL initialize a boto3 session using the `aws_profile` and `aws_region` from AgentCore_Config, resolved through the existing CredentialResolver.
2. WHEN the AgentCore_Client makes any API call, THE AgentCore_Client SHALL apply Credential_Scrubbing to all request and response data before logging or returning results to the Dashboard.
3. IF boto3 or the `synth[agentcore]` optional dependencies are not installed, THEN THE AgentCore_Client SHALL raise a `SynthConfigError` with the message referencing `pip install synth-agent-sdk[agentcore]` and the Server SHALL return a structured error response indicating the missing dependency.
4. IF AWS credentials cannot be resolved, THEN THE AgentCore_Client SHALL return a structured error response indicating the credential failure without exposing credential details, and the Dashboard SHALL display a connection status banner explaining the issue.
5. THE AgentCore_Client SHALL enforce a configurable per-request timeout (default 30 seconds) on all boto3 API calls to prevent blocking the Server event loop.

### Requirement 2: Live Invocation Log

**User Story:** As a developer, I want to view recent invocations of my deployed AgentCore agent in the Dashboard, so that I can monitor production behavior alongside local testing.

#### Acceptance Criteria

1. WHEN the Dashboard requests invocation logs, THE Server SHALL return a list of Invocation_Log records from the deployed agent, each containing timestamp, prompt preview (first 200 characters), response preview (first 200 characters), latency in milliseconds, input token count, output token count, estimated cost, user ID, and status (success or error).
2. WHEN displaying invocation logs, THE Dashboard SHALL render them in a sortable table with columns for timestamp, prompt preview, status, latency, tokens, and cost.
3. WHEN a user clicks on an invocation row, THE Dashboard SHALL expand the row to show the full prompt text, full response text, and complete metadata.
4. WHEN the Dashboard is in auto-refresh mode, THE Server SHALL poll for new invocation logs at a configurable interval (default 30 seconds) and the Dashboard SHALL append new entries without losing scroll position.
5. WHEN a user applies filters (time range, user ID, or status), THE Server SHALL return only Invocation_Log records matching all active filter criteria.
6. WHEN displaying any Invocation_Log data, THE Dashboard SHALL apply Credential_Scrubbing to all text fields before rendering.

### Requirement 3: Deployed Agent Health Status

**User Story:** As a developer, I want to see the current health and deployment status of my AgentCore agent, so that I can verify the deployed agent is operational.

#### Acceptance Criteria

1. WHEN the Dashboard requests health status, THE Server SHALL return the Health_Status of the deployed agent, containing agent status, last deployment timestamp, runtime version, and deployed model ID.
2. WHEN the deployed agent status is not "active", THE Dashboard SHALL display a warning banner with the current status and last known deployment timestamp.
3. WHEN the deployed model ID differs from the local Agent's model attribute, THE Dashboard SHALL display a configuration drift indicator showing both the local and deployed model values.
4. WHEN health status data is unavailable due to API errors, THE Dashboard SHALL display a "connection unavailable" state with the last successful check timestamp.

### Requirement 4: AgentCoreMemory Implementation

**User Story:** As a developer, I want the `AgentCoreMemory` class to actually call AgentCore's managed memory API instead of returning stubs, so that memory operations work in AgentCore deployments.

#### Acceptance Criteria

1. WHEN `AGENTCORE_MEMORY_ENDPOINT` is set, THE AgentCoreMemory SHALL call the AgentCore memory API to retrieve messages for a given thread ID, returning them as a list of `Message` objects.
2. WHEN `AGENTCORE_MEMORY_ENDPOINT` is set, THE AgentCoreMemory SHALL call the AgentCore memory API to store messages for a given thread ID.
3. WHEN the AgentCore memory API returns an error, THE AgentCoreMemory SHALL raise a `SynthConfigError` with the error details and the component set to "AgentCoreMemory".
4. WHEN `AGENTCORE_MEMORY_ENDPOINT` is not set and a fallback backend is provided, THE AgentCoreMemory SHALL delegate to the fallback backend.
5. WHEN `AGENTCORE_MEMORY_ENDPOINT` is not set and no fallback is provided, THE AgentCoreMemory SHALL raise a `SynthConfigError` with a suggestion to configure the endpoint or provide a fallback.
6. THE AgentCoreMemory SHALL use `httpx.AsyncClient` for HTTP calls to the memory endpoint, with a configurable timeout (default 10 seconds).
7. WHEN the AgentCoreMemory lists available threads, THE AgentCoreMemory SHALL return a list of thread ID strings from the AgentCore memory API.

### Requirement 5: Memory Inspector

**User Story:** As a developer, I want to browse memory threads and their messages in the Dashboard, so that I can debug conversation state for both local and deployed agents.

#### Acceptance Criteria

1. WHEN the Dashboard requests the memory thread list, THE Server SHALL return a list of active thread IDs with message counts for the currently configured memory backend (local or AgentCore).
2. WHEN a user selects a thread ID, THE Dashboard SHALL display all messages in that thread in chronological order, showing role, content, and timestamp for each message.
3. WHEN the memory backend is AgentCoreMemory with a live endpoint, THE Memory_Inspector SHALL indicate that data is from the deployed agent's managed memory.
4. WHEN the memory backend is a local Synth backend (thread, persistent, or semantic), THE Memory_Inspector SHALL indicate that data is from the local memory store.
5. IF the memory backend does not support thread listing (e.g., semantic memory), THEN THE Server SHALL return an empty list with a message indicating the backend does not support thread enumeration.

### Requirement 6: Cost and Usage Dashboard

**User Story:** As a developer, I want to see aggregated cost, usage, and performance metrics from my deployed agent, so that I can track operational costs and identify performance trends.

#### Acceptance Criteria

1. WHEN the Dashboard requests usage metrics, THE Server SHALL return aggregated data containing total invocation count, total input tokens, total output tokens, total estimated cost, average latency in milliseconds, and error count, for a specified time range.
2. WHEN the Dashboard displays usage metrics, THE Cost_Dashboard SHALL render a time-series chart showing invocation count over time with configurable granularity (hourly, daily).
3. WHEN the Dashboard displays usage metrics, THE Cost_Dashboard SHALL render a time-series chart showing token usage and estimated cost over time.
4. WHEN the Dashboard displays usage metrics, THE Cost_Dashboard SHALL render a time-series chart showing average latency and error rate over time.
5. WHEN no usage data is available for the selected time range, THE Cost_Dashboard SHALL display an empty state message indicating no invocations were recorded.

### Requirement 7: Remote Invoke

**User Story:** As a developer, I want to send a prompt to my deployed AgentCore agent from the Dashboard and see the response, so that I can compare deployed behavior with local behavior.

#### Acceptance Criteria

1. WHEN a user submits a prompt via the remote invoke interface, THE Server SHALL send the prompt to the deployed AgentCore agent using the AgentCore invocation API and return the response text, token counts, latency, and cost.
2. WHEN a remote invocation completes, THE Dashboard SHALL display the response alongside the telemetry metadata (tokens, latency, cost).
3. WHEN a user triggers a side-by-side comparison, THE Dashboard SHALL send the same prompt to both the local agent and the deployed agent, and display both responses with their respective telemetry for comparison.
4. IF the remote invocation fails, THEN THE Server SHALL return a structured error response with the failure reason, and the Dashboard SHALL display the error message without exposing credential or infrastructure details.
5. WHEN displaying remote invocation results, THE Dashboard SHALL clearly label the response as originating from the deployed agent, distinct from local agent responses.

### Requirement 8: Observability Tab UI

**User Story:** As a developer, I want the live observability features organized in a dedicated Dashboard tab, so that I can access all deployed-agent data from one location.

#### Acceptance Criteria

1. THE Dashboard SHALL display an "AgentCore" tab in the tab bar, visible only when AgentCore_Config is detected.
2. WHEN the "AgentCore" tab is active, THE Dashboard SHALL display sub-sections for Health Status, Invocation Log, Memory Inspector, Cost Dashboard, Remote Invoke, and Evaluations (when AgentCore_Evaluations is configured).
3. THE Dashboard SHALL use the same green-on-dark CRT terminal theme as the existing Dashboard tabs for all observability UI elements.
4. WHEN the AgentCore_Client is not connected (missing credentials or dependencies), THE Dashboard SHALL display a single connection-required message with setup instructions instead of the sub-sections.

### Requirement 9: Init Flow AgentCore Feature Wiring

**User Story:** As a developer running `synth init` with the AgentCore provider, I want the generated agent code to use `AgentCoreMemory` when I select the memory feature, and I want an observability feature option, so that my project is correctly configured for AgentCore deployment from the start.

#### Acceptance Criteria

1. WHEN a user selects the "agentcore" provider and enables the "memory" feature during `synth init`, THE init wizard SHALL generate agent code that imports `AgentCoreMemory` from `synth.deploy.agentcore.memory` and passes it as the memory backend with `Memory.thread()` as the fallback, instead of using `Memory.thread()` alone.
2. WHEN a user selects the "agentcore" provider, THE init wizard SHALL offer an "observability" feature option in the feature selection list, described as "Live AgentCore observability dashboard".
3. WHEN a user enables the "observability" feature during `synth init`, THE init wizard SHALL add a comment in the generated agent code indicating that `synth dev agent.py` will show the AgentCore observability tab in the Dashboard.
4. WHEN a user selects the "agentcore" provider but does not enable the "memory" feature, THE init wizard SHALL not import or configure AgentCoreMemory.

### Requirement 10: Graceful Degradation

**User Story:** As a developer without AgentCore dependencies installed, I want the Dashboard to function normally without errors, so that the observability feature does not break the existing experience.

#### Acceptance Criteria

1. WHEN the `synth[agentcore]` optional dependencies are not installed, THE Server SHALL omit AgentCore-specific API endpoints from the route table and the Dashboard SHALL hide the "AgentCore" tab.
2. WHEN AWS credentials expire during a Dashboard session, THE AgentCore_Client SHALL return a credential-expired error and the Dashboard SHALL display a re-authentication prompt without crashing.
3. WHEN the AgentCore API is unreachable (network error, service outage), THE AgentCore_Client SHALL return a timeout or connection error after the configured timeout, and the Dashboard SHALL display a retry option.
4. THE Server SHALL isolate all AgentCore observability logic so that failures in AgentCore API calls do not affect local agent chat, eval, or other existing Dashboard functionality.

### Requirement 11: Remote Evaluation

**User Story:** As a developer, I want to run my evaluation suite against the deployed AgentCore agent and compare results with local evaluations, so that I can verify deployed behavior matches local testing.

#### Acceptance Criteria

1. WHEN a user triggers a remote eval run from the Dashboard, THE Server SHALL execute the evaluation dataset against the deployed AgentCore agent using the Remote_Invoke capability, and return an EvalReport with per-case results.
2. WHEN a remote eval run completes, THE Dashboard SHALL display the results in the same format as local eval results, with each case showing input, expected output, actual output, score, latency, and cost.
3. WHEN both a local eval run and a remote eval run exist for the same dataset, THE Dashboard SHALL display a comparison view showing per-case score differences, latency differences, and cost differences between local and deployed results.
4. IF a remote eval case fails due to an invocation error, THEN THE Server SHALL record the case as failed with the error message and continue executing remaining cases.
5. WHEN displaying remote eval results, THE Dashboard SHALL clearly label them as originating from the deployed agent.

### Requirement 12: Credential Security

**User Story:** As a developer, I want all AgentCore observability features to follow the SDK's credential security patterns, so that AWS credentials are never exposed in the Dashboard or logs.

#### Acceptance Criteria

1. THE AgentCore_Client SHALL apply `CredentialResolver.redact_credentials()` to all API response data before returning it to the Server.
2. THE Server SHALL apply Credential_Scrubbing to all JSON responses from AgentCore observability endpoints before sending them to the Dashboard.
3. THE AgentCore_Client SHALL resolve credentials at call time from the CredentialResolver, and SHALL NOT store AWS access keys, secret keys, or session tokens as instance attributes.
4. WHEN logging AgentCore API calls at DEBUG level, THE AgentCore_Client SHALL redact all credential patterns from log messages.


### Requirement 13: Init Flow AgentCore Evaluations Wiring

**User Story:** As a developer running `synth init` with the AgentCore provider, I want the init wizard to generate AgentCore Evaluations configuration when I select the eval feature, so that my project is ready for continuous agent quality monitoring from the start.

#### Acceptance Criteria

1. WHEN a user selects the "agentcore" provider AND enables the "eval" feature during `synth init`, THE init wizard SHALL generate an `eval_config.json` file containing a default Online_Evaluation configuration with a sampling rate of 1.0 and three Built_In_Evaluator references: `Builtin.Helpfulness`, `Builtin.Correctness`, and `Builtin.GoalSuccessRate`.
2. WHEN a user selects the "agentcore" provider AND enables the "eval" feature, THE init wizard SHALL add an `evaluations` section to the generated `agentcore.yaml` containing the evaluator IDs, sampling rate, and a placeholder online evaluation config name.
3. WHEN a user selects the "agentcore" provider AND enables the "eval" feature, THE init wizard SHALL add AgentCore Evaluations IAM permissions (`bedrock-agentcore:CreateEvaluationConfig`, `bedrock-agentcore:RunEvaluation`, `bedrock-agentcore:GetEvaluationResults`, `logs:CreateLogGroup`, `logs:PutLogEvents`) to the `permissions` list in `agentcore.yaml`.
4. WHEN a user selects the "agentcore" provider AND enables the "eval" feature, THE init wizard SHALL add a comment block in the generated agent code explaining that AgentCore Evaluations is configured and referencing the `eval_config.json` file.
5. WHEN a user selects the "agentcore" provider AND enables the "eval" feature, THE init wizard SHALL also generate the local `eval_dataset.json` file so that both local Synth eval and AgentCore Evaluations are available.
6. WHEN a user does NOT select the "agentcore" provider AND enables the "eval" feature, THE init wizard SHALL generate only the local `eval_dataset.json` file without any AgentCore Evaluations configuration.
7. IF the `eval_config.json` contains evaluator ARNs that do not match the pattern `arn:aws:bedrock-agentcore:::evaluator/Builtin.*`, THEN THE init wizard SHALL emit a warning indicating the evaluator reference may be invalid.

### Requirement 14: Dashboard Evaluations Integration

**User Story:** As a developer, I want to view AgentCore Evaluation results and manage evaluation configurations in the Dashboard, so that I can monitor agent quality alongside other observability data.

#### Acceptance Criteria

1. WHEN the "AgentCore" tab is active and AgentCore_Evaluations is configured, THE Dashboard SHALL display an "Evaluations" sub-section within the observability tab.
2. WHEN the Dashboard requests evaluation results, THE Server SHALL return evaluation scores from the AgentCore Evaluations API, each containing evaluator name, score, evaluation level (session, trace, or tool_call), and timestamp.
3. WHEN displaying evaluation results, THE Dashboard SHALL render a summary table showing the most recent score for each configured Built_In_Evaluator, with visual indicators for scores below a configurable threshold (default 0.5).
4. WHEN a user triggers an on-demand evaluation from the Dashboard, THE Server SHALL call the AgentCore Evaluations API to run the selected evaluators against the most recent agent session and return the results.
5. WHEN the Dashboard displays the Evaluations sub-section, THE Dashboard SHALL show the current Online_Evaluation configuration status including active or disabled state, sampling rate, and configured evaluator list.
6. IF AgentCore_Evaluations is not configured (no `eval_config.json` or no evaluations section in `agentcore.yaml`), THEN THE Dashboard SHALL hide the Evaluations sub-section and display no error.
7. WHEN displaying evaluation data, THE Dashboard SHALL apply Credential_Scrubbing to all response fields before rendering.
