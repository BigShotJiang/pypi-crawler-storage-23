# Implementation Plan: Testing UI Enhancements

## Overview

Incremental implementation of four dashboard capabilities: Config Panel (backend + frontend), Guard Visibility, Streaming Metrics, and Enhanced Export. Each task builds on previous work, with backend endpoints implemented before their corresponding frontend consumers. Tests are co-located with implementation tasks.

## Tasks

- [x] 1. Add runtime configuration state management and config API endpoints to server.py
  - [x] 1.1 Add runtime state tracking to server.py
    - Add `_original_config` dict, `_disabled_tools` set, and `_all_tools` dict as module-level state
    - Modify `_load_agent()` to snapshot original config (model, instructions, tool names) and populate `_all_tools`
    - Add `_has_drift()` helper that compares current agent state against `_original_config`
    - _Requirements: 4.3, 7.1, 7.3_

  - [x] 1.2 Implement GET /api/config endpoint
    - Return current model, full instructions, tools list (with name, description, enabled status from `_disabled_tools`), guards list (name, type via `type(g).__name__`), `has_drift` flag
    - Detect `agentcore.yaml` in agent file directory and include deployment metadata if present
    - Return 503 if no agent loaded
    - _Requirements: 1.1, 1.3, 14.1_

  - [x] 1.3 Implement GET /api/models endpoint
    - Import `_PROVIDER_SPECS` from `synth.providers.router` and `_PROVIDERS` from `synth.cli.init_cmd`
    - Return models grouped by provider display name
    - _Requirements: 1.2_

  - [x] 1.4 Implement PATCH /api/config endpoint
    - Accept optional `model`, `instructions`, and `tools` (dict of name->bool) fields
    - For model changes: validate against `ProviderRouter`, update `_agent.model` and re-resolve `_agent.provider`
    - For instructions changes: update `_agent.instructions`
    - For tool toggles: update `_disabled_tools` set and rebuild `_agent._registered_tools` / `_agent.tool_executor` from `_all_tools` minus disabled
    - Return 400 for invalid model, 503 if no agent loaded
    - _Requirements: 2.1, 2.2, 2.3, 3.1, 3.2, 4.1, 4.2_

  - [x] 1.5 Implement POST /api/config/save endpoint
    - Import `_atomic_write`, `_patch_model`, `_patch_instructions`, `_patch_tools_list` from `synth.cli.edit_cmd`
    - Read agent file source, attempt regex patches for model, instructions, tools
    - Collect warnings for fields that don't match expected patterns (regex returns unchanged source)
    - Validate non-empty model and instructions before writing
    - Write via `_atomic_write`, then update `_original_config` snapshot
    - _Requirements: 5.1, 5.2, 5.3, 5.4_

  - [x] 1.6 Write property tests for config endpoints
    - **Property 1: Config response completeness** — For any agent config, GET /api/config returns all required fields
    - **Validates: Requirements 1.1, 1.3**
    - **Property 2: Config update correctness** — For any valid model/instructions, PATCH updates agent attributes
    - **Validates: Requirements 2.1, 3.1**
    - **Property 3: Invalid model rejection** — For any unrecognized model string, PATCH returns error and model unchanged
    - **Validates: Requirements 2.3**

  - [x] 1.7 Write property tests for tool toggling and drift detection
    - **Property 4: Tool toggle round-trip** — Disable then re-enable restores tool to active set
    - **Validates: Requirements 4.1, 4.2**
    - **Property 5: Tool registry invariant** — _all_tools unchanged after any enable/disable sequence
    - **Validates: Requirements 4.3**
    - **Property 8: Drift detection correctness** — has_drift is True iff config differs from original
    - **Validates: Requirements 7.1**

  - [x] 1.8 Write property tests for file patching and AgentCore detection
    - **Property 6: Agent file patching round-trip** — Patch then re-parse yields new values
    - **Validates: Requirements 5.2**
    - **Property 7: Non-patchable field warning** — Non-literal model args produce warnings
    - **Validates: Requirements 5.3**
    - **Property 15: AgentCore metadata detection** — Valid agentcore.yaml produces correct metadata
    - **Validates: Requirements 14.1**
    - **Property 16: AgentCore model mismatch detection** — Mismatch flag correct for any model pair
    - **Validates: Requirements 14.3**

- [x] 2. Checkpoint — Ensure all backend config tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 3. Add guard evaluation visibility to the streaming endpoint
  - [x] 3.1 Extend SSE streaming to capture and emit guard results
    - Wrap the guard evaluation in `_agent._evaluate_guards()` calls with timing (before and after)
    - Capture each guard's name, type, passed status, duration_ms, and violation_message
    - Emit a `guard_result` SSE event with the guard results array before the `done` event
    - For non-streaming `/api/chat`, include guard results in the response JSON under a `guards` key
    - _Requirements: 8.1, 8.4_

  - [x] 3.2 Write unit tests for guard result emission
    - **Property 9: Guard results completeness** — For N guards, response contains N results with all fields
    - **Validates: Requirements 8.1**
    - **Property 10: Guard event ordering** — guard_result event appears before done in SSE stream
    - **Validates: Requirements 8.4**

- [x] 4. Add Config tab to the frontend (index.html + app.js + style.css)
  - [x] 4.1 Add Config tab HTML structure to index.html
    - Add `<button class="tab" data-tab="config">&#x2699; Config</button>` to tab bar
    - Add `tab-content` div with `feature-layout` pattern: model selector, instructions textarea, tool toggles, save/reset buttons, drift indicator, agentcore info section
    - _Requirements: 15.1, 15.2, 15.3_

  - [x] 4.2 Add Config tab styles to style.css
    - Style model selector as grouped dropdown matching CRT theme
    - Style tool toggle switches (green on, dim off)
    - Style drift indicator dot/badge on tab button
    - Style save/reset buttons, warning box for save warnings
    - Style agentcore deployment info section
    - _Requirements: 15.1_

  - [x] 4.3 Implement Config tab JavaScript in app.js
    - Add `loadConfig()` function: fetch GET /api/config, populate model selector, instructions textarea, tool toggles, guard list, agentcore section
    - Add `loadModels()` function: fetch GET /api/models, populate model selector with optgroups
    - Add `updateConfig(field, value)` function: send PATCH /api/config for model/instructions/tool changes
    - Add `saveConfigToFile()` function: send POST /api/config/save, display warnings if any
    - Add `resetConfig()` function: call POST /api/reload then loadConfig()
    - Add drift indicator logic: compare current values against loaded snapshot, toggle badge visibility
    - Wire up event listeners for model change, instructions blur, tool toggles, save/reset buttons
    - Call `loadConfig()` and `loadModels()` on tab switch to "config"
    - _Requirements: 2.1, 3.1, 4.1, 4.2, 5.1, 6.1, 6.2, 7.1, 7.2, 14.2, 14.3, 15.4_

- [x] 5. Add streaming metrics to the telemetry panel
  - [x] 5.1 Add streaming metrics HTML to telemetry panel in index.html
    - Add a new `telem-section` with title "STREAMING" containing TTFT, Tokens/sec, and Duration cards
    - Place it between the existing "TOKENS & COST" and "SESSION" sections
    - _Requirements: 9.4_

  - [x] 5.2 Implement streaming metrics computation in app.js
    - In `sendPrompt()`, record `requestStartTime = performance.now()` before fetch
    - On first `token` event, record `firstTokenTime = performance.now()` and compute `ttft = firstTokenTime - requestStartTime`
    - Count output tokens during streaming
    - On `done` event, compute `streamDuration = performance.now() - firstTokenTime` and `tokensPerSec = tokenCount / (streamDuration / 1000)`
    - Handle edge case: if no tokens received, set all metrics to 0
    - Pass metrics object to `updateTelemetry()`
    - _Requirements: 9.1, 9.2, 9.3_

  - [x] 5.3 Extend updateTelemetry() to display streaming metrics and guard results
    - Add TTFT, tokens/sec, and duration values to the new telemetry cards
    - Add guard results section: render each guard with name, pass/fail badge, duration, and violation message if failed
    - Handle `guard_result` SSE event in `sendPrompt()` to capture guard data
    - _Requirements: 8.2, 8.3, 9.4_

  - [x] 5.4 Write property tests for streaming metrics computation
    - **Property 11: Streaming metrics computation** — For any event timestamps and token count, TTFT/duration/tokens-per-sec are correctly computed
    - **Validates: Requirements 9.1, 9.2, 9.3**

- [x] 6. Checkpoint — Ensure all tests pass, verify Config tab and streaming metrics work end-to-end
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Add enhanced export functionality
  - [x] 7.1 Add export buttons to index.html
    - Add JSON and Markdown export buttons to the conversation header area (topbar-left or topbar-right)
    - Add JSON export button to the eval results toolbar (next to RUN ALL button)
    - _Requirements: 13.1, 13.2_

  - [x] 7.2 Implement conversation JSON export in app.js
    - Add `exportConversationJSON()` function: fetch current conversation from `/api/conversations/{id}`, build JSON with all messages and metadata, trigger download as `conversation-{id}-{timestamp}.json`
    - Use `URL.createObjectURL()` + temporary `<a>` element for download
    - _Requirements: 10.1, 10.2_

  - [x] 7.3 Implement conversation Markdown export in app.js
    - Add `exportConversationMarkdown()` function: fetch current conversation, format as Markdown with `## User` / `## Agent` headers, inline tool calls as code blocks, trigger download as `conversation-{id}-{timestamp}.md`
    - _Requirements: 11.1, 11.2_

  - [x] 7.4 Implement eval results JSON export in app.js
    - Add `exportEvalResults()` function: serialize the last eval run results array as JSON, trigger download as `eval-results-{timestamp}.json`
    - Wire to the export button, only enabled after evals have been run
    - _Requirements: 12.1, 12.2_

  - [x] 7.5 Write property tests for export functions
    - **Property 12: Conversation JSON export completeness** — For any conversation, JSON export contains all messages with required fields
    - **Validates: Requirements 10.1**
    - **Property 13: Conversation Markdown export completeness** — For any conversation, Markdown contains all messages with role headers
    - **Validates: Requirements 11.1**
    - **Property 14: Eval JSON export completeness** — For any eval results, JSON export contains all results with required fields
    - **Validates: Requirements 12.1**

- [x] 8. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests use `hypothesis` with `@settings(max_examples=100)`
- Backend endpoints follow existing server.py patterns (JSON request/response, error handling)
- Frontend follows existing vanilla JS patterns (no framework)
- File patching reuses `synth/cli/edit_cmd.py` functions directly — no duplication
