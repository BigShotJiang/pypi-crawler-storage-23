---
inclusion: manual
---

# Release and Versioning

Rules for versioning, releasing, and maintaining backwards compatibility in the Synth SDK.
This guide is manually included — reference it with `#Release and Versioning` in chat
when doing release work.

## Semantic Versioning

- Follow semver strictly: `MAJOR.MINOR.PATCH`.
  - MAJOR — breaking changes to the public API.
  - MINOR — new features, new public API symbols, new optional extras. Backwards compatible.
  - PATCH — bug fixes, documentation, internal refactors. No API changes.
- The version lives in two places and MUST be kept in sync:
  - `synth/__init__.py` → `__version__ = "X.Y.Z"`
  - `pyproject.toml` → `[project] version = "X.Y.Z"`
- Pre-1.0 (`0.x.y`): MINOR bumps may include breaking changes. Document them clearly.

## Public API Surface

- The public API is defined by `synth/__init__.py` → `__all__`. Only symbols listed
  there are considered public.
- Any symbol in `__all__` is covered by the semver contract. Removing or changing its
  signature is a breaking change.
- Internal symbols (prefixed with `_`, or not in `__all__`) can change freely in any
  release.
- Provider-specific types (`ProviderResponse`, `ProviderEvent`, etc.) exported from
  `synth/providers/__init__.py` are semi-public — they're stable but not part of the
  top-level `__all__`. Changes require a MINOR bump.

## Adding a New Optional Extra

1. Add the dependency to `pyproject.toml` under `[project.optional-dependencies]`.
2. Add it to the `all` extra as well.
3. Ensure the extra only installs its own SDK — no cross-contamination between extras.
4. Verify with the isolation test in `tests/test_scaffold.py` → `test_extras_isolation`.
5. Update the provider router if it's a new provider (`_PROVIDER_SPECS` in `router.py`).
6. This is a MINOR version bump.

## Adding a New Public API Symbol

1. Add the symbol to `synth/__init__.py` → `__all__`.
2. Ensure the symbol has a docstring with at least one usage example.
3. Add unit tests covering the new symbol.
4. This is a MINOR version bump.

## Deprecation Process

- Deprecate before removing. Use `warnings.warn("...", DeprecationWarning, stacklevel=2)`.
- Include the deprecation version and the replacement in the warning message:
  `"Agent.execute() is deprecated since 0.3.0, use Agent.run() instead."`
- Keep deprecated symbols for at least one MINOR release cycle before removal.
- Removal of a deprecated symbol is a MAJOR bump (or MINOR if pre-1.0).

## Changelog

- Maintain a `CHANGELOG.md` at the repo root.
- Use the Keep a Changelog format: `Added`, `Changed`, `Deprecated`, `Removed`, `Fixed`,
  `Security`.
- Every PR that changes the public API or fixes a bug MUST include a changelog entry.
- Link each version header to the git diff between tags.

## Dependency Version Policy

- Core dependencies in `pyproject.toml` use `>=` minimum pins, not exact pins.
  This gives users flexibility while ensuring compatibility.
- Security-sensitive dependencies (`httpx`, `boto3`, `pydantic`) should have their
  minimum versions reviewed and bumped periodically.
- Optional extras follow the same `>=` convention.
- The `requires-python = ">=3.10"` constraint MUST be maintained. Test against
  Python 3.10, 3.11, 3.12, and 3.13.

## Release Checklist

1. Update version in `synth/__init__.py` and `pyproject.toml`.
2. Update `CHANGELOG.md` with the new version section.
3. Run the full test suite: `pytest --cov=synth`.
4. Verify coverage meets the 90% threshold.
5. Run `tests/test_scaffold.py` to verify package structure and extras isolation.
6. Build the package: `python -m build`.
7. Tag the release: `git tag vX.Y.Z`.
8. Publish to PyPI.

## Backwards Compatibility Rules

- Never change the constructor signature of `Agent`, `Graph`, `Pipeline`, or
  `AgentTeam` in a PATCH release.
- New parameters MUST have defaults so existing code continues to work.
- Error class hierarchies are part of the public API — don't change inheritance
  relationships in PATCH releases. Users may be catching specific exception types.
- The `SynthError` base class contract (`component` and `suggestion` kwargs) is
  permanent and MUST NOT change.
- `RunResult`, `StreamEvent`, and other dataclass shapes are public API. Adding
  fields with defaults is MINOR. Removing or renaming fields is MAJOR.
