"""Unit tests for synth.deploy.agentcore.adapter.

Covers ``AgentCoreAdapter`` — construction, async/sync invocation,
payload extraction for all supported shapes, and error paths.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock

import pytest

from synth.deploy.agentcore.adapter import AgentCoreAdapter
from synth.errors import SynthConfigError
from synth.types import RunResult, TokenUsage


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_result(text: str = "hello") -> RunResult:
    return RunResult(
        text=text,
        output=None,
        tokens=TokenUsage(input_tokens=10, output_tokens=20, total_tokens=30),
        cost=0.005,
        latency_ms=123.4,
        trace=None,
        tool_calls=[],
    )


def _make_mock_target(result: RunResult | None = None) -> AsyncMock:
    """Return a mock agent/graph with an ``arun`` async method."""
    target = AsyncMock()
    target.arun.return_value = result or _make_run_result()
    return target


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestAgentCoreAdapterInit:
    def test_stores_target(self):
        target = object()
        adapter = AgentCoreAdapter(target)
        assert adapter._target is target


# ---------------------------------------------------------------------------
# _extract_prompt — all payload shapes
# ---------------------------------------------------------------------------


class TestExtractPrompt:
    """Tests for ``AgentCoreAdapter._extract_prompt``."""

    def test_input_string(self):
        assert AgentCoreAdapter._extract_prompt({"input": "hello"}) == "hello"

    def test_input_dict_with_text(self):
        payload = {"input": {"text": "world"}}
        assert AgentCoreAdapter._extract_prompt(payload) == "world"

    def test_prompt_field(self):
        assert AgentCoreAdapter._extract_prompt({"prompt": "hi"}) == "hi"

    def test_prompt_field_non_string_coerced(self):
        """Non-string prompt values are coerced via str()."""
        assert AgentCoreAdapter._extract_prompt({"prompt": 42}) == "42"

    def test_input_takes_precedence_over_prompt(self):
        """When both 'input' and 'prompt' are present, 'input' wins."""
        payload = {"input": "from_input", "prompt": "from_prompt"}
        assert AgentCoreAdapter._extract_prompt(payload) == "from_input"

    def test_missing_both_fields_raises(self):
        with pytest.raises(SynthConfigError, match="missing 'input' or 'prompt'"):
            AgentCoreAdapter._extract_prompt({"other": "value"})

    def test_empty_dict_raises(self):
        with pytest.raises(SynthConfigError, match="missing 'input' or 'prompt'"):
            AgentCoreAdapter._extract_prompt({})

    def test_non_dict_payload_raises(self):
        with pytest.raises(SynthConfigError, match="must be a dict"):
            AgentCoreAdapter._extract_prompt("not a dict")  # type: ignore[arg-type]

    def test_non_dict_payload_list_raises(self):
        with pytest.raises(SynthConfigError, match="must be a dict"):
            AgentCoreAdapter._extract_prompt([1, 2])  # type: ignore[arg-type]

    def test_input_dict_without_text_key_falls_through(self):
        """input is a dict but has no 'text' key — should fall through to prompt."""
        payload = {"input": {"content": "no text key"}, "prompt": "fallback"}
        assert AgentCoreAdapter._extract_prompt(payload) == "fallback"

    def test_input_dict_without_text_key_no_prompt_raises(self):
        """input is a dict without 'text' and no 'prompt' — error."""
        with pytest.raises(SynthConfigError, match="missing 'input' or 'prompt'"):
            AgentCoreAdapter._extract_prompt({"input": {"content": "nope"}})

    def test_error_component_is_agentcore_adapter(self):
        with pytest.raises(SynthConfigError) as exc_info:
            AgentCoreAdapter._extract_prompt({})
        assert exc_info.value.component == "AgentCoreAdapter"

    def test_error_suggestion_present(self):
        with pytest.raises(SynthConfigError) as exc_info:
            AgentCoreAdapter._extract_prompt({})
        assert exc_info.value.suggestion


# ---------------------------------------------------------------------------
# ahandle_invocation — async path
# ---------------------------------------------------------------------------


class TestAhandleInvocation:
    """Tests for the async invocation handler."""

    @pytest.mark.asyncio
    async def test_returns_correct_response_structure(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        response = await adapter.ahandle_invocation({"input": "test"})

        assert response["output"]["text"] == "hello"
        assert response["metadata"]["tokens"]["input"] == 10
        assert response["metadata"]["tokens"]["output"] == 20
        assert response["metadata"]["tokens"]["total"] == 30
        assert response["metadata"]["cost"] == 0.005
        assert response["metadata"]["latency_ms"] == 123.4

    @pytest.mark.asyncio
    async def test_passes_extracted_prompt_to_arun(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        await adapter.ahandle_invocation({"prompt": "my question"})

        target.arun.assert_awaited_once_with("my question")

    @pytest.mark.asyncio
    async def test_input_string_payload(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        await adapter.ahandle_invocation({"input": "direct string"})

        target.arun.assert_awaited_once_with("direct string")

    @pytest.mark.asyncio
    async def test_input_dict_payload(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        await adapter.ahandle_invocation({"input": {"text": "nested"}})

        target.arun.assert_awaited_once_with("nested")

    @pytest.mark.asyncio
    async def test_propagates_arun_exception(self):
        target = _make_mock_target()
        target.arun.side_effect = RuntimeError("boom")
        adapter = AgentCoreAdapter(target)

        with pytest.raises(RuntimeError, match="boom"):
            await adapter.ahandle_invocation({"input": "test"})

    @pytest.mark.asyncio
    async def test_invalid_payload_raises_before_arun(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        with pytest.raises(SynthConfigError):
            await adapter.ahandle_invocation({})

        target.arun.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_response_text_matches_run_result(self):
        result = _make_run_result(text="custom response")
        target = _make_mock_target(result)
        adapter = AgentCoreAdapter(target)

        response = await adapter.ahandle_invocation({"input": "q"})

        assert response["output"]["text"] == "custom response"


# ---------------------------------------------------------------------------
# handle_invocation — sync path
# ---------------------------------------------------------------------------


class TestHandleInvocation:
    """Tests for the synchronous invocation handler."""

    def test_returns_same_result_as_async(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        response = adapter.handle_invocation({"input": "sync test"})

        assert response["output"]["text"] == "hello"
        assert response["metadata"]["tokens"]["total"] == 30
        target.arun.assert_awaited_once_with("sync test")

    def test_invalid_payload_raises(self):
        target = _make_mock_target()
        adapter = AgentCoreAdapter(target)

        with pytest.raises(SynthConfigError):
            adapter.handle_invocation({})
