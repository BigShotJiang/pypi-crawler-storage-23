"""Tests for synth.cli.discover — agent discovery and selection."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from synth.cli.discover import DiscoveredAgent, discover_agents


# ---------------------------------------------------------------------------
# DiscoveredAgent dataclass
# ---------------------------------------------------------------------------


class TestDiscoveredAgent:
    """Tests for the DiscoveredAgent dataclass defaults and fields."""

    def test_minimal_construction(self) -> None:
        agent = DiscoveredAgent(file="agent.py", name="my-agent")
        assert agent.file == "agent.py"
        assert agent.name == "my-agent"
        assert agent.model == ""
        assert agent.has_agentcore_yaml is False
        assert agent.is_deployed is False
        assert agent.aws_region == ""
        assert agent.cloud_status == ""
        assert agent.agent_id == ""

    def test_full_construction(self) -> None:
        agent = DiscoveredAgent(
            file="proj/agent.py",
            name="proj",
            model="claude-sonnet-4-5",
            has_agentcore_yaml=True,
            is_deployed=True,
            aws_region="us-west-2",
            cloud_status="ACTIVE",
            agent_id="agt-12345",
        )
        assert agent.cloud_status == "ACTIVE"
        assert agent.agent_id == "agt-12345"
        assert agent.is_deployed is True
        assert agent.aws_region == "us-west-2"

    def test_cloud_status_default_empty(self) -> None:
        agent = DiscoveredAgent(file="a.py", name="a")
        assert agent.cloud_status == ""

    def test_agent_id_default_empty(self) -> None:
        agent = DiscoveredAgent(file="a.py", name="a")
        assert agent.agent_id == ""


# ---------------------------------------------------------------------------
# discover_agents
# ---------------------------------------------------------------------------


class TestDiscoverAgents:
    """Tests for the discover_agents() directory scanner."""

    def test_finds_agent_py(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "agent"
        assert agents[0].model == "claude-sonnet-4-5"

    def test_finds_agent_prefixed_files(self, tmp_path: Path) -> None:
        (tmp_path / "agent_writer.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "agent_writer"

    def test_ignores_non_agent_files(self, tmp_path: Path) -> None:
        (tmp_path / "tools.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_ignores_files_without_agent_pattern(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            "# just a comment, no Agent usage\nx = 1\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_reads_agentcore_yaml(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="bedrock/claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: us-east-1\ndeployed: true\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].has_agentcore_yaml is True
        assert agents[0].is_deployed is True
        assert agents[0].aws_region == "us-east-1"

    def test_agentcore_yaml_not_deployed(self, tmp_path: Path) -> None:
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="bedrock/claude-sonnet-4-5")\n',
            encoding="utf-8",
        )
        (tmp_path / "agentcore.yaml").write_text(
            "aws_region: eu-west-1\ndeployed: false\n",
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert agents[0].is_deployed is False
        assert agents[0].aws_region == "eu-west-1"

    def test_skips_hidden_directories(self, tmp_path: Path) -> None:
        hidden = tmp_path / ".hidden"
        hidden.mkdir()
        (hidden / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_skips_pycache(self, tmp_path: Path) -> None:
        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 0

    def test_subdirectory_agent_uses_dir_name(self, tmp_path: Path) -> None:
        sub = tmp_path / "my_project"
        sub.mkdir()
        (sub / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].name == "my_project"

    def test_multiple_agents_sorted_by_file(self, tmp_path: Path) -> None:
        content = 'from synth import Agent\nagent = Agent(model="gpt-4o")\n'
        (tmp_path / "agent.py").write_text(content, encoding="utf-8")
        sub = tmp_path / "beta"
        sub.mkdir()
        (sub / "agent.py").write_text(content, encoding="utf-8")
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 2
        assert agents[0].file < agents[1].file

    def test_empty_directory(self, tmp_path: Path) -> None:
        agents = discover_agents(str(tmp_path))
        assert agents == []

    def test_new_fields_default_in_discovered_agents(self, tmp_path: Path) -> None:
        """Discovered agents have empty cloud_status and agent_id by default."""
        (tmp_path / "agent.py").write_text(
            'from synth import Agent\nagent = Agent(model="gpt-4o")\n',
            encoding="utf-8",
        )
        agents = discover_agents(str(tmp_path))
        assert len(agents) == 1
        assert agents[0].cloud_status == ""
        assert agents[0].agent_id == ""
