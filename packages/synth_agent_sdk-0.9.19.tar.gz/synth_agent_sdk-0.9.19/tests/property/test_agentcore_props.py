"""Property-based tests for AgentCore deployment.

**Property 45: AgentCore manifest generation**
**Validates: Requirements 20.3**

**Property 46: AgentCore payload translation round-trip**
**Validates: Requirements 20.4**
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.agent import Agent
from synth.deploy.agentcore.adapter import AgentCoreAdapter
from synth.deploy.agentcore.manifest import generate_manifest
from synth.providers.base import ProviderResponse
from synth.types import TokenUsage
from tests.conftest import MockProvider


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_USAGE = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)


def _make_agent(text: str) -> Agent:
    """Create an Agent backed by a MockProvider."""
    provider = MockProvider(
        responses=[ProviderResponse(text=text, usage=_USAGE)],
    )
    with patch("synth.agent.ProviderRouter.resolve", return_value=provider):
        return Agent(instructions="test agent")


# ---------------------------------------------------------------------------
# Property 45: AgentCore manifest generation
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    name=st.text(
        alphabet=st.characters(whitelist_categories=("L", "N")),
        min_size=1, max_size=20,
    ),
    description=st.text(min_size=1, max_size=50),
)
def test_agentcore_manifest_generation(name: str, description: str):
    """Property 45: AgentCore manifest generation.

    For any Agent with a name and description, the generated manifest
    should contain the agent's name, description, and actions.

    **Validates: Requirements 20.3**
    """
    agent = _make_agent("hello")
    manifest = generate_manifest(
        agent, name=name, description=description,
    )

    assert manifest["name"] == name
    assert manifest["description"] == description
    assert isinstance(manifest["actions"], list)
    assert len(manifest["actions"]) >= 1  # at least "invoke"
    assert manifest["actions"][0]["name"] == "invoke"


# ---------------------------------------------------------------------------
# Property 46: AgentCore payload translation round-trip
# ---------------------------------------------------------------------------


@settings(max_examples=50)
@given(
    prompt=st.text(min_size=1, max_size=50),
)
def test_agentcore_payload_translation_round_trip(prompt: str):
    """Property 46: AgentCore payload translation round-trip.

    For any valid AgentCore invocation payload, translating it to Synth's
    run() input and then translating the RunResult back should preserve
    the essential content.

    **Validates: Requirements 20.4**
    """
    agent = _make_agent("response text")
    adapter = AgentCoreAdapter(agent)

    payload = {"input": {"text": prompt}}
    response = _run_async(adapter.ahandle_invocation(payload))

    assert "output" in response
    assert "text" in response["output"]
    assert response["output"]["text"] == "response text"
    assert "metadata" in response
    assert "tokens" in response["metadata"]
