# -*- coding: utf-8 -*-
from enum import Enum


class Tags(Enum):
    CLASSIFICATION = "classification"
    DYNAMIC = "dynamic"
    INFERENCE = "inference"
    FORECASTING = "forecasting"
    MODELS = "models"
    PREDICTION = "prediction"
    SKTIME = "sktime"
