### TODO
* semantic models on top of models in packages?
  * could avoid removing them + log a warning
* merging semantic models with versioned models
* create new model entry / file for semantic model that refs a model without .yml