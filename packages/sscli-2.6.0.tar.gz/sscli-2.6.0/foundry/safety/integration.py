"""
Integration utilities for GitGuard with CLI commands.
Provides decorators and helpers for enforcing git safety in codemod commands.
"""

from functools import wraps
from typing import Callable, Optional
import typer

from foundry.safety import GitGuard, GitStatusError, GitGuardConfig
from foundry.constants import console


def require_git_status_check(allow_untracked: bool = False) -> Callable:
    """
    Decorator to enforce git status check on CLI commands.
    
    Args:
        allow_untracked: Whether to allow untracked files
    
    Usage:
        @app.command()
        @require_git_status_check()
        def my_codemod(force: bool = typer.Option(False, "--force")):
            # Command implementation
            pass
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, force: bool = False, **kwargs):
            # Skip check if force is specified
            if force:
                console.print("[yellow]⚠️  Bypassing git status check (--force)[/yellow]")
                return func(*args, force=force, **kwargs)
            
            # Perform git check
            config = GitGuardConfig(allow_untracked=allow_untracked)
            guard = GitGuard(config=config)
            
            try:
                guard.require_clean_status()
                console.print("[green]✓[/green] Git status verified - proceeding with codemod")
            except GitStatusError as e:
                console.print(f"[red]❌ {e}[/red]")
                _print_git_suggestions()
                raise typer.Exit(code=1)
            
            return func(*args, force=force, **kwargs)
        
        return wrapper
    return decorator


def verify_git_status(force: bool = False, allow_untracked: bool = False) -> None:
    """
    Verify git status before executing a codemod.
    Use this in command implementations.
    
    Args:
        force: Whether to skip the check
        allow_untracked: Whether to allow untracked files
    
    Raises:
        typer.Exit: If git status is not clean and force is False
    
    Usage:
        def my_command(force: bool = ...):
            verify_git_status(force=force)
            # Safe to proceed with codemod
    """
    if force:
        console.print("[yellow]⚠️  Bypassing git status check (--force)[/yellow]")
        return
    
    config = GitGuardConfig(allow_untracked=allow_untracked)
    guard = GitGuard(config=config)
    
    try:
        guard.require_clean_status()
        console.print("[green]✓[/green] Git status verified")
    except GitStatusError as e:
        console.print(f"[red]❌ {e}[/red]")
        _print_git_suggestions()
        raise typer.Exit(code=1)


def _print_git_suggestions() -> None:
    """Print helpful suggestions for resolving git status issues."""
    console.print("""
[bold cyan]💡 Suggestions to fix git status:[/bold cyan]

[dim]1. Commit changes (recommended):[/dim]
   git add .
   git commit -m "Before running codemod"

[dim]2. Stash changes temporarily:[/dim]
   git stash
   # Run codemod here
   git stash pop

[dim]3. View changes:[/dim]
   git status          # See what changed
   git diff            # See unstaged changes
   git diff --staged   # See staged changes

[dim]4. Clean up untracked files:[/dim]
   git clean -fn       # Dry run: show what would be deleted
   git clean -fd       # Actually delete untracked files

[dim]5. Continue anyway (last resort):[/dim]
   # Add --force flag when running the command
   # WARNING: This is not recommended and may cause data loss
""")


class CodemodSafetyContext:
    """
    Context manager for safe codemod execution with git checks.
    
    Usage:
        with CodemodSafetyContext(force=False) as safety:
            if safety.is_safe:
                # Execute codemod
                pass
    """
    
    def __init__(self, force: bool = False, allow_untracked: bool = False):
        self.force = force
        self.allow_untracked = allow_untracked
        self.is_safe = False
        self.guard = None
    
    def __enter__(self):
        if self.force:
            self.is_safe = True
            return self
        
        config = GitGuardConfig(allow_untracked=self.allow_untracked)
        self.guard = GitGuard(config=config)
        
        try:
            self.guard.require_clean_status()
            self.is_safe = True
            console.print("[green]✓[/green] Git status verified")
        except GitStatusError as e:
            self.is_safe = False
            console.print(f"[red]❌ {e}[/red]")
            _print_git_suggestions()
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            console.print("[red]✗ Codemod failed[/red]")
            console.print(f"[dim]Error: {exc_val}[/dim]")
            # Could implement auto-rollback here
        return False


def get_git_status_display() -> str:
    """
    Get a displayable git status summary for logging/telemetry.
    
    Returns:
        Formatted string with git status information
    """
    guard = GitGuard()
    status = guard.get_status_summary()
    
    if not status["is_git_repo"]:
        return "NOT_IN_GIT_REPO"
    
    parts = []
    if status["staged_files"]:
        parts.append(f"staged:{len(status['staged_files'])}")
    if status["unstaged_files"]:
        parts.append(f"unstaged:{len(status['unstaged_files'])}")
    if status["untracked_files"]:
        parts.append(f"untracked:{len(status['untracked_files'])}")
    if status["merge_conflicts"]:
        parts.append(f"conflicts:{len(status['merge_conflicts'])}")
    
    return ",".join(parts) if parts else "CLEAN"
