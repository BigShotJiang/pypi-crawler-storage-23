"""
Safety mechanisms for code modifications.
Ensures transformations don't cause data loss or corruption.
Includes dry-run preview engine for previewing changes before applying.
"""

from .git_guard import GitGuard, GitStatusError, GitGuardConfig
from .verification_hook import (
    VerificationHook,
    ValidationReport,
    ValidatorCommand,
)
from .dry_run_engine import (
    DryRunEngine,
    DryRunResult,
    FileModification,
    DryRunCodemodWrapper,
)

# Optional imports with graceful fallback
try:
    from .integration import (
        verify_git_status,
        require_git_status_check,
        CodemodSafetyContext,
        get_git_status_display,
    )
    _has_integration = True
except ImportError:
    _has_integration = False

__all__ = [
    "GitGuard",
    "GitStatusError",
    "GitGuardConfig",
    "VerificationHook",
    "ValidationReport",
    "ValidatorCommand",
    "DryRunEngine",
    "DryRunResult",
    "FileModification",
    "DryRunCodemodWrapper",
]

if _has_integration:
    __all__.extend([
        "verify_git_status",
        "require_git_status_check",
        "CodemodSafetyContext",
        "get_git_status_display",
    ])