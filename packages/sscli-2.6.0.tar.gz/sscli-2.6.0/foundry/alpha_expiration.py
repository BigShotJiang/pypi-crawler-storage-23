#!/usr/bin/env python3
"""
Alpha Package Expiration Check (Refactored)
"""

import sys
from .alpha import AlphaInfo, ExpirationStatus, AlphaExpirationManager


def get_expiration_manager() -> AlphaExpirationManager:
    """Factory function to get the global expiration manager."""
    return AlphaExpirationManager()


def main():
    """Debug/test CLI for expiration checks."""
    import argparse

    parser = argparse.ArgumentParser(description="Alpha Package Expiration Check")
    parser.add_argument(
        "--status", action="store_true", help="Show alpha status (if available)"
    )
    parser.add_argument(
        "--check", type=str, help="Check if action is permitted (e.g., 'generate')"
    )

    args = parser.parse_args()
    manager = AlphaExpirationManager()

    if args.status:
        manager.show_status()
    elif args.check:
        allowed = manager.check_before_action(args.check)
        sys.exit(0 if allowed else 1)
    else:
        if manager.is_alpha():
            manager.show_status()
        else:
            from rich.console import Console

            Console().print("[dim]Not running in alpha mode[/dim]")


if __name__ == "__main__":
    main()

