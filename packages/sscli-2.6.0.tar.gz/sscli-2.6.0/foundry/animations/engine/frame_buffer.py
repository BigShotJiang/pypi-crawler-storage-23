"""
Layered frame buffer for efficient, organized rendering in the terminal.
Supports z-ordering and character-level transparency.
"""

from collections import OrderedDict
from typing import Dict, List, Optional

from rich.console import Console
from rich.text import Text


class FrameBuffer:
    """
    Multi-layer rendering with z-ordering.

    Each layer is a list of Rich Text objects representing rows.
    Layers are merged from back to front.
    """

    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        self.layers: Dict[str, List[Text]] = OrderedDict()
        self._console = Console()

    def add_layer(self, name: str, lines: List[Text]):
        """Add or update a layer in the buffer."""
        if len(lines) != self.height:
            # Pad if necessary or raise error
            if len(lines) < self.height:
                lines = lines + [
                    Text(" " * self.width) for _ in range(self.height - len(lines))
                ]
            else:
                lines = lines[: self.height]

        self.layers[name] = lines

    def get_layer(self, name: str) -> Optional[List[Text]]:
        """Get lines for a specific layer."""
        return self.layers.get(name)

    def clear(self):
        """Clear all layers."""
        self.layers.clear()

    def render(self) -> List[Text]:
        """
        Composite all layers into a single list of Text objects.
        Space characters are treated as transparent.
        """
        if not self.layers:
            return [Text(" " * self.width) for _ in range(self.height)]

        result = [Text(" " * self.width) for _ in range(self.height)]

        # Merge layers in order (back to front)
        for layer_name, layer_lines in self.layers.items():
            for y in range(self.height):
                result[y] = self._merge_lines(result[y], layer_lines[y])

        return result

    def _merge_lines(self, base: Text, overlay: Text) -> Text:
        """
        Merge two Rich Text lines character by character.
        Overlay characters that are not spaces replace base characters.
        """
        # This is a simplified merge. A more efficient one would use spans.
        # But for terminal animations, character-level transparency is often needed.
        base_plain = base.plain
        overlay_plain = overlay.plain

        # Ensure exact width
        base_plain = base_plain.ljust(self.width)[: self.width]
        overlay_plain = overlay_plain.ljust(self.width)[: self.width]

        # Create a new Text object for the merged result
        new_text = Text("")

        # Optimization: if overlay is all spaces, return base
        if overlay_plain.strip() == "":
            return base

        # Character by character merge (to support transparency)
        for i in range(self.width):
            if i < len(overlay_plain) and overlay_plain[i] != " ":
                # Find style at this position in overlay
                style = overlay.get_style_at_offset(self._console, i)
                new_text.append(overlay_plain[i], style=style)
            else:
                # Use base character and style
                style = base.get_style_at_offset(self._console, i)
                new_text.append(base_plain[i], style=style)

        return new_text
