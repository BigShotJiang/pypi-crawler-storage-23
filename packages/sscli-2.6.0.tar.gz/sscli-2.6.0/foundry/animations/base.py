from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional
from .engine.frame_buffer import FrameBuffer
from .engine.state import AnimationState


@dataclass
class AnimationConfig:
    """Configuration for animation instances."""
    duration: float = 1.0
    loop: bool = False
    auto_advance: bool = True


class Animation(ABC):
    """Base class for all animations."""

    def __init__(self, config: Optional[AnimationConfig] = None):
        self.config = config or AnimationConfig()
        self.elapsed_time = 0.0
        self.is_complete = False
        self.final_action: Optional[str] = None

    def update(self, dt: float, state: AnimationState) -> AnimationState:
        """Main update loop."""
        if self.is_complete and not self.config.loop: return state
        self.elapsed_time += dt
        if self.elapsed_time >= self.config.duration:
            if self.config.loop:
                self.elapsed_time %= self.config.duration
            else:
                self.is_complete = True
                self.elapsed_time = self.config.duration
        return self._update_impl(dt, state)

    @abstractmethod
    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        """Subclass-specific update logic."""
        pass

    @abstractmethod
    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        """Render the animation state."""
        pass

    def handle_input(self, key: str) -> Optional[str]:
        """Handle user input."""
        return None

    def get_progress(self) -> float:
        """Get normalized progress (0.0-1.0)."""
        return min(1.0, self.elapsed_time / self.config.duration) if self.config.duration > 0 else 1.0
