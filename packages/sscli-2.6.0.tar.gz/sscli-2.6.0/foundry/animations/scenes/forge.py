"""
Forge scene for internal development ops menu.
Features industrial/tech theme with different colors and background.
"""

from typing import Optional

from rich.text import Text

from ..animation import Animation, AnimationConfig
from ..assets import SMALL_LOGO
from ..components import render_base_background, render_stars, render_sun
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class ForgeAnimation(Animation):
    """
    Forge animation: Industrial/tech themed scene for internal development.
    """

    def __init__(self):
        # Infinite duration unless interrupted
        super().__init__(AnimationConfig(duration=float("inf")))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        # More dynamic wind oscillation for industrial feel
        import math

        wind = 0.8 + 0.3 * math.sin(state.elapsed_time * 3)  # More aggressive wind

        # Faster tree growth in this scene - industrial progress
        growth = min(1.0, self.elapsed_time / 8.0)  # Faster growth

        # Sun position: More central and brighter for industrial theme
        sun_prog = min(1.0, self.elapsed_time / 10.0)
        rise_factor = sun_prog**0.7
        sun_y = 8.0 - (6.0 * rise_factor)  # More central
        sun_x = 45.0 + (10.0 * rise_factor)  # More central

        return state.with_updates(
            grass_wind=wind,
            tree_growth=growth,
            sun_x=sun_x,
            sun_y=sun_y,
            sun_progress=sun_prog,
            scene_phase=ScenePhase.TRANQUILITY,  # Reuse tranquility phase
        )

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer - Industrial theme (darker, more metallic)
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        # More stars for "digital/tech" feel
        render_stars(bg_canvas, count=30)

        # Brighter, more central sun
        render_sun(bg_canvas, pos=(int(state.sun_y), int(state.sun_x)))
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Nature layer (Growing tree with industrial tint)
        nature_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_base_background(
            nature_canvas,
            tree_growth=state.tree_growth,
            grass_wind=state.grass_wind
        )
        frame_buffer.add_layer("nature", nature_canvas.buffer)

        # 3. Logo layer - Industrial colors
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        for i, line in enumerate(SMALL_LOGO):
            logo_canvas.draw_text(line, 4, 1 + i, style="bold magenta")  # Magenta logo
        frame_buffer.add_layer("logo", logo_canvas.buffer)

        # 4. Interactive menu layer (Industrial theme)
        ui_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)

        # Menu progress: FASTER (0.4 seconds for industrial speed)
        menu_duration = 0.4
        menu_progress = min(1.0, self.elapsed_time / menu_duration)

        # Slide effect: Bottom to Top (industrial lift)
        target_x, target_y = 4, 6
        start_y = FRAME_HEIGHT + 10  # Start below screen
        current_x = target_x  # Fixed X
        current_y = int(start_y - (start_y - target_y) * (menu_progress**0.5))

        # Draw menu box with industrial theme
        from rich.panel import Panel

        INTERNAL_MENU_ITEMS = [
            "Verify Builds",
            "Hygiene Check", 
            "Full Suite",
            "Clean Reports",
            "View Docs",  # Keep this for consistency
            "Back to Main",
        ]

        menu_content = Text("")
        for i, item in enumerate(INTERNAL_MENU_ITEMS):
            prefix = "⚙️ " if state.menu_selected_index == i else "  "

            # Industrial color scheme
            if state.menu_selected_index == i:
                style = "bold magenta"  # Magenta highlight
            else:
                style = "cyan"  # Cyan for unselected

            menu_content.append(f"{prefix}{item}\n", style=style)

        panel = Panel(
            menu_content,
            title="[bold magenta]FORGE OPS MENU[/bold magenta]",
            border_style="magenta",
            width=32,
            height=10,
        )

        # Render panel to lines
        from rich.console import Console

        temp_console = Console(width=32, force_terminal=True, color_system="standard")
        with temp_console.capture() as capture:
            temp_console.print(panel)

        captured_text = capture.get()
        panel_lines = [
            Text.from_ansi(line) for line in captured_text.splitlines() if line
        ]

        # Draw the panel lifting up
        ui_canvas.draw_sprite(panel_lines, current_x, current_y)

        frame_buffer.add_layer("ui", ui_canvas.buffer)

    def handle_input(self, key: str) -> Optional[str]:
        """Handle menu navigation."""
        if key == "enter":
            return "SELECT"
        return None