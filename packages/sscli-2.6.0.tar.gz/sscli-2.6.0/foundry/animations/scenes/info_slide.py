"""
Info slide animation: Displaying features with a menu overlay.
"""

from ..animation import Animation, AnimationConfig
from ..assets import SMALL_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class InfoSlideAnimation(Animation):
    """
    Info slide animation: Shows key features of the platform.
    """

    def __init__(self, duration: float = 3.0):
        super().__init__(AnimationConfig(duration=duration))
        self.features = [
            "  ⬢ SOURCE CONTROL FOR AI",
            "  ⬢ DISTRIBUTED FOUNDRY",
            "  ⬢ NEURAL WEIGHTS REPO",
        ]

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        return state.with_updates(scene_phase=ScenePhase.MENU)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)
        render_base_background(bg_canvas, tree_growth=0.8, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        for i, line in enumerate(SMALL_LOGO):
            logo_canvas.draw_text(line, 4, 1 + i, style="bold blue")
        frame_buffer.add_layer("logo", logo_canvas.buffer)

        # 3. Features layer
        feat_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        progress = self.get_progress()

        y_start = 8
        for i, feat in enumerate(self.features):
            # Staggered reveal
            feat_prog = min(1.0, max(0.0, (progress * 1.5) - (i * 0.2)))
            if feat_prog > 0:
                style = "bold green" if feat_prog >= 1.0 else "dim green"
                feat_canvas.draw_text(feat, 6, y_start + (i * 2), style=style)

        frame_buffer.add_layer("features", feat_canvas.buffer)
