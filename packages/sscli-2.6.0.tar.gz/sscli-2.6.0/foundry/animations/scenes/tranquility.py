"""
Tranquility scene for the main menu.
Features the sun, fixed stars, and the full tree.
"""

from typing import Optional

from rich.text import Text

from ..animation import Animation, AnimationConfig
from ..assets import SMALL_LOGO
from ..components import render_base_background, render_stars, render_sun
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class TranquilityAnimation(Animation):
    """
    Tranquility animation: Final atmospheric scene with interactive menu possibility.
    """

    def __init__(self):
        # Infinite duration unless interrupted
        super().__init__(AnimationConfig(duration=float("inf")))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        # Subtle wind oscillation
        import math

        wind = 0.6 + 0.2 * math.sin(state.elapsed_time * 2)

        # Slow tree growth in this scene
        # Start from 0.0 (sprout) and grow to 1.0 (full tree) over ~15 seconds
        growth = min(1.0, self.elapsed_time / 15.0)

        # Sun Rise: Rise up to the right
        # Start far right and high enough to avoid menu overlap
        sun_prog = min(1.0, self.elapsed_time / 15.0)
        rise_factor = sun_prog**0.5
        sun_y = 10.0 - (8.0 * rise_factor)  # Starts high-ish, goes higher
        sun_x = 55.0 + (15.0 * rise_factor)  # Starts far-right, goes further right

        return state.with_updates(
            grass_wind=wind,
            tree_growth=growth,
            sun_x=sun_x,
            sun_y=sun_y,
            sun_progress=sun_prog,
            scene_phase=ScenePhase.TRANQUILITY,
        )

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=20)

        # Use state-driven sun position, ensure it's on right side
        render_sun(bg_canvas, pos=(int(state.sun_y), int(state.sun_x)))
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Nature layer (Slowly growing tree/sprout)
        nature_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        # Offset tree slightly more to the right if needed, but 60 is usually good
        render_base_background(
            nature_canvas, tree_growth=state.tree_growth, grass_wind=state.grass_wind
        )
        frame_buffer.add_layer("nature", nature_canvas.buffer)

        # 3. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        for i, line in enumerate(SMALL_LOGO):
            logo_canvas.draw_text(line, 4, 1 + i, style="bold cyan")
        frame_buffer.add_layer("logo", logo_canvas.buffer)

        # 4. Interactive menu layer (With slide-in effect)
        ui_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)

        # Menu progress: FASTER (0.6 seconds)
        menu_duration = 0.6
        menu_progress = min(1.0, self.elapsed_time / menu_duration)

        # Slide effect: Left to Right
        target_x, target_y = 4, 6
        start_x = -30  # Start fully off-screen left
        current_x = int(start_x + (target_x - start_x) * (menu_progress**0.5))
        current_y = target_y  # Fixed Y for cleaner horizontal slide

        # Draw menu box
        from rich.panel import Panel

        from ...constants import ANIMATED_MENU_ITEMS

        menu_content = Text("")
        for i, item in enumerate(ANIMATED_MENU_ITEMS):
            prefix = "> " if state.menu_selected_index == i else "  "

            # Highlight selected
            if state.menu_selected_index == i:
                style = "bold cyan"
            else:
                style = "white"

            menu_content.append(f"{prefix}{item}\n", style=style)

        panel = Panel(
            menu_content,
            title="[bold blue]STACK-FOUNDRY MENU[/bold blue]",
            border_style="blue",
            width=30,
            height=9,
        )

        # Render panel to lines using a console with specific settings to avoid extra artifacts
        from rich.console import Console

        temp_console = Console(width=30, force_terminal=True, color_system="standard")
        with temp_console.capture() as capture:
            temp_console.print(panel)

        # Strip ANSI if needed, or use from_ansi to preserve it during canvas drawing
        captured_text = capture.get()
        panel_lines = [
            Text.from_ansi(line) for line in captured_text.splitlines() if line
        ]

        # Draw the panel sliding in
        ui_canvas.draw_sprite(panel_lines, current_x, current_y)

        frame_buffer.add_layer("ui", ui_canvas.buffer)

    def handle_input(self, key: str) -> Optional[str]:
        """Handle menu navigation."""
        if key == "enter":
            return "SELECT"
        return None
