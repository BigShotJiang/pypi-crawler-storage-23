"""
Foundry Animation Core: Utilities for the layered rendering system.
"""

# Constants - kept here for easy access by other modules
FRAME_WIDTH = 80
FRAME_HEIGHT = 22
FRAME_COLOR = "bold blue"
ANIMATION_SPEED = 0.01

# Re-export classes and functions from sub-modules
from .canvas import Canvas
from .rendering import draw_frame, pad_content
from .utils import align_content, center_content, right_align_content

__all__ = [
    "Canvas",
    "draw_frame",
    "pad_content",
    "align_content",
    "center_content",
    "right_align_content",
    "FRAME_WIDTH",
    "FRAME_HEIGHT",
    "FRAME_COLOR",
    "ANIMATION_SPEED",
]
