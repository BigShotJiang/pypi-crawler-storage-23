from typing import List, Optional
from .base import Animation, AnimationConfig
from .engine.frame_buffer import FrameBuffer
from .engine.state import AnimationState


class AnimationSequence(Animation):
    """Play a sequence of animations in order."""

    def __init__(self, animations: List[Animation]):
        super().__init__(AnimationConfig(duration=sum(a.config.duration for a in animations)))
        self.animations, self.current_index = animations, 0

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        if self.current_index >= len(self.animations):
            self.is_complete = True
            return state
        current = self.animations[self.current_index]
        state = current.update(dt, state)
        if current.is_complete and self.current_index < len(self.animations) - 1:
            self.current_index += 1
        if self.current_index >= len(self.animations) - 1 and current.is_complete:
            self.is_complete = True
        return state

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        if self.current_index < len(self.animations):
            self.animations[self.current_index].render(frame_buffer, state)

    def handle_input(self, key: str) -> Optional[str]:
        if self.current_index < len(self.animations):
            return self.animations[self.current_index].handle_input(key)
        return None


class AnimationGroup(Animation):
    """Play multiple animations simultaneously (layered)."""

    def __init__(self, animations: List[Animation], config: Optional[AnimationConfig] = None):
        duration = max((a.config.duration for a in animations), default=0.0)
        super().__init__(config or AnimationConfig(duration=duration))
        self.animations = animations

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        all_complete = True
        for anim in self.animations:
            state = anim.update(dt, state)
            if not anim.is_complete: all_complete = False
        if all_complete: self.is_complete = True
        return state

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        for anim in self.animations: anim.render(frame_buffer, state)

    def handle_input(self, key: str) -> Optional[str]:
        for anim in self.animations:
            action = anim.handle_input(key)
            if action: return action
        return None
