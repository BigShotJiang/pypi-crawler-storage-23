"""
Per-Template Access Control for Alpha Users

This module manages which alpha users have access to which templates.
It enables granular, per-template access grants for alpha testers.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Set
from datetime import date, datetime

from foundry.constants import console


class AlphaTemplateAccessManager:
    """Manages per-template access grants for alpha users."""

    # Location of the access control manifest
    # In a distributed alpha package, this would be included and updated
    ACCESS_MANIFEST_PATH = Path.home() / ".config" / "sscli" / "alpha_template_access.json"

    def __init__(self):
        """Initialize the access manager."""
        self.access_grants: Dict[str, List[str]] = {}  # user_id -> list of available templates
        self._load_manifest()

    def _load_manifest(self) -> None:
        """Load the access manifest from disk."""
        if not self.ACCESS_MANIFEST_PATH.exists():
            self.access_grants = {}
            return

        try:
            with open(self.ACCESS_MANIFEST_PATH, "r") as f:
                data = json.load(f)
                self.access_grants = data.get("template_access", {})
        except Exception as e:
            console.print(f"[yellow]⚠️  Warning: Could not load access manifest: {e}[/yellow]")
            self.access_grants = {}

    def _save_manifest(self) -> None:
        """Persist the access manifest to disk."""
        self.ACCESS_MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
        try:
            with open(self.ACCESS_MANIFEST_PATH, "w") as f:
                json.dump(
                    {
                        "template_access": self.access_grants,
                        "last_updated": date.today().isoformat(),
                    },
                    f,
                    indent=2,
                )
        except Exception as e:
            console.print(f"[red]✗ Error saving access manifest: {e}[/red]")

    def grant_template_access(
        self, user_id: str, templates: List[str], persist: bool = True
    ) -> None:
        """
        Grant a user access to specific templates.

        Args:
            user_id: The alpha user's unique identifier
            templates: List of template names to grant access to
            persist: Whether to save changes to disk
        """
        if user_id not in self.access_grants:
            self.access_grants[user_id] = []

        # Add new templates, avoiding duplicates
        for template in templates:
            if template not in self.access_grants[user_id]:
                self.access_grants[user_id].append(template)

        if persist:
            self._save_manifest()

    def revoke_template_access(
        self, user_id: str, templates: Optional[List[str]] = None, persist: bool = True
    ) -> None:
        """
        Revoke a user's access to specific templates (or all if not specified).

        Args:
            user_id: The alpha user's unique identifier
            templates: List of template names to revoke. If None, revokes all.
            persist: Whether to save changes to disk
        """
        if user_id not in self.access_grants:
            return

        if templates is None:
            # Revoke all access
            del self.access_grants[user_id]
        else:
            # Revoke specific templates
            for template in templates:
                if template in self.access_grants[user_id]:
                    self.access_grants[user_id].remove(template)

            # Remove user entry if no templates remain
            if not self.access_grants[user_id]:
                del self.access_grants[user_id]

        if persist:
            self._save_manifest()

    def can_access_template(self, user_id: str, template: str) -> bool:
        """
        Check if a user has access to a specific template.

        Args:
            user_id: The alpha user's unique identifier
            template: The template name to check

        Returns:
            True if the user has access, False otherwise
        """
        return template in self.access_grants.get(user_id, [])

    def get_accessible_templates(self, user_id: str) -> List[str]:
        """
        Get all templates a user has access to.

        Args:
            user_id: The alpha user's unique identifier

        Returns:
            List of template names the user can access
        """
        return self.access_grants.get(user_id, [])

    def get_all_grants(self) -> Dict[str, List[str]]:
        """Get all access grants (for admin/audit purposes)."""
        return self.access_grants.copy()


# Convenience functions
_manager: Optional[AlphaTemplateAccessManager] = None


def get_access_manager() -> AlphaTemplateAccessManager:
    """Get the singleton access manager instance."""
    global _manager
    if _manager is None:
        _manager = AlphaTemplateAccessManager()
    return _manager


def user_can_access_template(user_id: str, template: str) -> bool:
    """Check if an alpha user can access a specific template."""
    return get_access_manager().can_access_template(user_id, template)


def grant_access(user_id: str, templates: List[str]) -> None:
    """Grant an alpha user access to templates."""
    get_access_manager().grant_template_access(user_id, templates)
    console.print(f"[green]✓ Granted {user_id} access to: {', '.join(templates)}[/green]")


def revoke_access(user_id: str, templates: Optional[List[str]] = None) -> None:
    """Revoke an alpha user's template access."""
    action_str = f"{', '.join(templates)}" if templates else "all templates"
    get_access_manager().revoke_template_access(user_id, templates)
    console.print(f"[green]✓ Revoked {user_id} access to: {action_str}[/green]")
