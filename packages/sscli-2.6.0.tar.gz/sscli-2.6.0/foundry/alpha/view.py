from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from foundry.constants import ALPHA_FEEDBACK_FORM, SALES_EMAIL, ALPHA_SUPPORT_EMAIL
from .models import AlphaInfo, ExpirationStatus

console = Console()

console = Console()


def show_expiration_message(info: AlphaInfo) -> None:
    """Display expiration message and prevent further action."""
    console.print(
        Panel(
            f"""[bold red]≡ ALPHA PACKAGE EXPIRED ≡[/bold red]

Your alpha evaluation period has ended.

[bold]User ID:[/bold] {info.user_id[:8]}...
[bold]Issued to:[/bold] {info.email}
[bold]Expired on:[/bold] {info.expires.isoformat()}

[yellow]📖 Read-only access available:[/yellow]
  • Documentation & examples
  • Template exploration
  • Configuration review

[red]❌ Disabled:[/red]
  • Project generation
  • Setup and installation
  • Template deployment

[bold cyan]🚀 Next Steps:[/bold cyan]
1. Review your experience: [link]{ALPHA_FEEDBACK_FORM}[/link]
2. Upgrade to [bold]PRO[/bold]: Email {SALES_EMAIL}
3. Request [bold]extension[/bold]: Contact {ALPHA_SUPPORT_EMAIL}

[dim]Thank you for participating in Seed & Source Alpha![/dim]""",
            style="red",
        )
    )


def show_warning_message(info: AlphaInfo) -> None:
    """Display expiration warning message."""
    console.print(
        Panel(
            f"""[bold yellow]⏰ ALPHA EXPIRATION WARNING[/bold yellow]

Your alpha evaluation period expires soon.

[bold]Expires in:[/bold] {info.days_remaining} days ({info.expires.isoformat()})
[bold]User ID:[/bold] {info.user_id[:8]}...

[cyan]💡 Next Steps:[/cyan]
  [bold]Option 1 - Extend:[/bold] Email {ALPHA_SUPPORT_EMAIL}
  [bold]Option 2 - Upgrade:[/bold] Explore PRO tier at {SALES_EMAIL}
  [bold]Option 3 - Feedback:[/bold] Complete [link]{ALPHA_FEEDBACK_FORM}[/link]

[dim]Your feedback is valuable - please share your experience![/dim]""",
            style="yellow",
        )
    )


def show_status(info: AlphaInfo) -> None:
    """Display full alpha status information."""
    console.print("\n")
    table = Table(title="Alpha Package Status", show_header=False)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="white")

    table.add_row("User ID", info.user_id)
    table.add_row("Issued to", info.email)
    table.add_row("Issue Date", info.issue_date.isoformat())
    table.add_row("Expires", info.expires.isoformat())

    status_style = {
        ExpirationStatus.ACTIVE: "[green]Active[/green]",
        ExpirationStatus.WARNING: "[yellow]Warning (7 days left)[/yellow]",
        ExpirationStatus.EXPIRED: "[red]Expired[/red]",
    }
    table.add_row("Status", status_style.get(info.status, "Unknown"))

    if info.days_remaining >= 0:
        table.add_row(
            "Days Remaining",
            f"[{('green' if info.days_remaining > 7 else 'yellow')}]{info.days_remaining}[/]",
        )
    else:
        table.add_row(
            "Days Remaining",
            f"[red]{info.days_remaining}[/red] (Expired)",
        )

    console.print(table)
    console.print()
