import questionary
from questionary import Choice
import sys
from pathlib import Path
from foundry.constants import console, QUESTIONARY_STYLE

def manage_licenses_menu():
    """Sub-menu for managing user and organization licenses."""
    # Add license-server to path to import upgrade functions
    repo_root = Path(__file__).resolve().parent.parent.parent
    license_server_path = repo_root / "services" / "license-server"
    
    if str(license_server_path) not in sys.path:
        sys.path.insert(0, str(license_server_path))

    while True:
        action = questionary.select(
            "What would you like to manage?",
            choices=[
                Choice("⬆️  Upgrade User", value="user", description="Promote a user to ALPHA or PRO tier"),
                Choice("🏢 Upgrade Organization", value="org", description="Upgrade an entire organization"),
                Choice("👥 Create Org Membership", value="member", description="Add a user to an organization"),
                "Back",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values
        if action == "user":
            action = "Upgrade User"
        elif action == "org":
            action = "Upgrade Organization"
        elif action == "member":
            action = "Create Org Membership"

        if action == "Back" or not action:
            break

        if action == "Upgrade User":
            tier = questionary.select(
                "Select Tier:",
                choices=[
                    Choice("free", value="free", description="No access to ALPHA/PRO templates"),
                    Choice("alpha", value="alpha", description="Access to ALPHA templates (expires)"),
                    Choice("pro", value="pro", description="Full access to PRO features and extensions"),
                    Choice("enterprise", value="enterprise", description="Custom agreement and support"),
                ],
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()
            
            identifier_type = questionary.select(
                "Identify user by:",
                choices=[
                    Choice("github", value="github", description="GitHub username"),
                    Choice("email", value="email", description="Email address"),
                ],
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()

            identifier = questionary.text(
                f"Enter {identifier_type.capitalize()} for the user:"
            ).ask()

            if tier and identifier:
                try:
                    from upgrade_user import upgrade_user_by_identifier
                    upgrade_user_by_identifier(tier, identifier, identifier_type)
                except Exception as e:
                    console.print(f"[red]Error upgrading user: {e}[/red]")

        elif action == "Upgrade Organization":
            tier = questionary.select(
                "Select Tier:",
                choices=[
                    Choice("free", value="free", description="No access to ALPHA/PRO templates"),
                    Choice("alpha", value="alpha", description="ALPHA tier membership for all users"),
                    Choice("pro", value="pro", description="PRO tier for entire organization"),
                    Choice("enterprise", value="enterprise", description="Enterprise agreement"),
                ],
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()

            org_name = questionary.text("Enter Organization Name:").ask()

            if tier and org_name:
                try:
                    from upgrade_org import upgrade_org_by_name
                    upgrade_org_by_name(tier, org_name)
                except Exception as e:
                    console.print(f"[red]Error upgrading organization: {e}[/red]")
        
        elif action == "Create Org Membership":
            org_name = questionary.text("Enter Organization Name:").ask()
            username = questionary.text("Enter GitHub Username:").ask()
            role = questionary.select(
                "Select Role:",
                choices=[
                    Choice("member", value="member", description="Regular member with read access"),
                    Choice("admin", value="admin", description="Administrator with full permissions"),
                ],
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()

            if org_name and username and role:
                try:
                    from manage_members import add_user_to_org
                    add_user_to_org(org_name, username, role)
                except Exception as e:
                    console.print(f"[red]Error adding member: {e}[/red]")
