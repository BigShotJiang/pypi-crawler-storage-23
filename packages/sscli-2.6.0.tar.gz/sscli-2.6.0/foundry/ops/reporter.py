import csv
from datetime import datetime
from pathlib import Path
from foundry.constants import console


def create_result(name: str, status: str, details: str):
    """Create a standardized result dictionary."""
    return {
        "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "Template": name,
        "TestCategory": "Build Verification (Internal)",
        "Status": status,
        "Details": details,
    }


def write_report(root_dir: Path, results: list):
    """Write results to a CSV report."""
    report_path = root_dir / "verification_results.csv"
    file_exists = report_path.exists()

    try:
        with open(report_path, "a", newline="") as csvfile:
            fieldnames = ["Timestamp", "Template", "TestCategory", "Status", "Details"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            if not file_exists:
                writer.writeheader()
            for r in results:
                writer.writerow(r)
        console.print(f"[dim]Results logged to {report_path.name}[/dim]")
    except Exception as e:
        console.print(f"[red]Failed to write report: {e}[/red]")


def clean_reports(root_dir: Path):
    """Remove the verification CSV report."""
    report_path = root_dir / "verification_results.csv"
    if report_path.exists():
        report_path.unlink()
        console.print(f"[green]Deleted {report_path.name}[/green]")
    else:
        console.print("[dim]No report found to clean.[/dim]")
