import questionary
import sys
from pathlib import Path
from foundry.constants import console

from .licenses import manage_licenses_menu


def generate_pdf_menu():
    """Sub-menu for generating branded onboarding PDFs."""
    # Add onboarding to path to import GuideGenerator
    repo_root = Path(__file__).resolve().parent.parent.parent
    onboarding_path = repo_root / "docs" / "onboarding"
    
    if str(onboarding_path) not in sys.path:
        sys.path.insert(0, str(onboarding_path))

    console.print("\n[bold cyan]Seed & Source — PDF Guide Generator[/bold cyan]")
    console.print("Generate branded onboarding materials for your customers.\n")

    # Gather inputs
    org_name = questionary.text(
        "Organization Name (e.g., 'Acme Corp'):",
        default="Seed & Source"
    ).ask()

    support_email = questionary.text(
        "Support Email Address:",
        default="support@seedsource.dev"
    ).ask()

    docs_url = questionary.text(
        "Documentation URL:",
        default="https://docs.seedsource.dev"
    ).ask()

    engine = questionary.select(
        "PDF Generation Engine:",
        choices=["pandoc", "weasyprint"],
        default="pandoc"
    ).ask()

    # Optional: custom output path
    custom_output = questionary.confirm(
        "Customize output file path?",
        default=False
    ).ask()

    output_path = "invite-developers-guide.pdf"
    if custom_output:
        output_path = questionary.text(
            "Output file path (relative to current directory):",
            default="invite-developers-guide.pdf"
        ).ask()

    try:
        from generate_guides import GuideGenerator

        # Initialize generator
        source_md = onboarding_path / "invite-developers-guide.md"
        source_css = onboarding_path / "invite-developers-guide.css"
        
        if not source_md.exists():
            console.print(f"[red]❌ Source markdown not found: {source_md}[/red]")
            return
        
        if not source_css.exists():
            console.print(f"[red]❌ Source CSS not found: {source_css}[/red]")
            return

        console.print("\n📝 Substituting placeholders...")
        generator = GuideGenerator(str(source_md), str(source_css))
        content = generator.substitute_placeholders(org_name, support_email, docs_url)
        temp_md = generator.write_temp_markdown(content)
        console.print("   ✓ Placeholders substituted")

        # Generate PDF
        console.print(f"\n🎨 Generating PDF with {engine}...")
        
        if engine == "pandoc":
            success = generator.generate_pdf_pandoc(output_path)
        else:
            success = generator.render_pdf_weasy(output_path)

        # Cleanup
        generator.cleanup()

        if success:
            console.print(f"\n[green]✅ Success![/green]")
            console.print(f"   PDF saved to: [bold]{output_path}[/bold]")
        else:
            console.print(f"\n[red]❌ Failed to generate PDF[/red]")

    except ImportError as e:
        console.print(f"[red]❌ Import error: {e}[/red]")
    except Exception as e:
        console.print(f"[red]❌ Error generating PDF: {e}[/red]")
