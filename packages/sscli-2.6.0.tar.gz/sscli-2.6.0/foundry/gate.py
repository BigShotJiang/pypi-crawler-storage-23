import questionary
from questionary import Choice
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.auth import get_current_license_info, login_flow
from foundry.utils import is_internal_dev
from foundry.interactive_utils import internal_ops_menu

def check_auth_gate():
    """Handles the login or continue flow. Returns current auth_info.
    
    First loads cached credentials. Only prompts for login if credentials file doesn't exist.
    """
    from pathlib import Path
    
    CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"
    
    # Load cached credentials first (without verification, to avoid unnecessary server calls)
    auth_info = get_current_license_info(verify=False)
    
    # SECURITY: Always verify non-free tiers with server to prevent local file tampering
    if auth_info.get("tier") != "free" and auth_info.get("access_token"):
        auth_info = get_current_license_info(verify=True)
    
    # Only prompt for login if:
    # 1. No credentials file exists AND
    # 2. User is "free" tier (not verified)
    if not CREDENTIALS_FILE.exists() and auth_info.get("tier") == "free":
        console.print("\n[bold yellow]🔐 Authentication Available[/bold yellow]")
        console.print("Authenticate to access PRO and ALPHA features.\n")
        auth_choice = questionary.select(
            "Would you like to authenticate now?",
            choices=[
                Choice("Login with GitHub (Recommended)", value="login", description="Unlock ALPHA and PRO features"),
                Choice("Continue as Free User", value="free", description="Use free tier templates only"),
                "Exit",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values
        if auth_choice == "login":
            auth_choice = "Login with GitHub (Recommended)"
        elif auth_choice == "free":
            auth_choice = "Continue as Free User"
        if auth_choice == "Exit" or auth_choice is None:
            return None
        elif auth_choice == "Login with GitHub (Recommended)":
            try:
                if login_flow():
                    auth_info = get_current_license_info(verify=True)  # Verify immediately after login
                else:
                    console.print("\n[yellow]Login was not completed. Continuing as free user...\n")
            except Exception as e:
                console.print(f"\n[red]✗ Authentication failed:[/red] {e}\nContinuing as free user...\n")
    
    return auth_info

def check_internal_gate(auth_info):
    """Checks if the user can and wants to enter internal ops. Returns True if handled internal flow."""
    is_admin = auth_info.get("tier") == "admin"
    is_local_dev = is_internal_dev()
    
    # Determine available modes
    choices = ["Seed & Source (Client Side)"]
    
    # Show Foundry Ops if admin or internal dev
    if is_admin or is_local_dev:
        choices.append("Foundry Ops (Internal Side)")
    
    # Show Development mode if admin AND in local dev environment
    if is_admin and is_local_dev:
        choices.append("🔧 Development Tools")
    
    choices.append("Exit")
    
    # Only show menu if there are multiple options
    if len(choices) > 2:  # More than just Client and Exit
        # Build mode choices with hints
        mode_choices = []
        for choice_obj in choices:
            if choice_obj == "Seed & Source (Client Side)":
                mode_choices.append(Choice(choice_obj, value="client", description="Deploy templates and generate projects"))
            elif choice_obj == "Foundry Ops (Internal Side)":
                mode_choices.append(Choice(choice_obj, value="ops", description="Verify builds, manage licenses, generate materials"))
            elif choice_obj == "🔧 Development Tools":
                mode_choices.append(Choice(choice_obj, value="dev", description="Internal development and debugging tools"))
            else:
                mode_choices.append(choice_obj)
        
        mode = questionary.select(
            "Select Your Experience:",
            choices=mode_choices,
            style=questionary.Style(QUESTIONARY_STYLE),
        ).ask()
        
        # Map choice values
        if mode == "client":
            mode = "Seed & Source (Client Side)"
        elif mode == "ops":
            mode = "Foundry Ops (Internal Side)"
        elif mode == "dev":
            mode = "🔧 Development Tools"
        if mode == "Exit" or mode is None:
            return "EXIT"
        if mode == "Foundry Ops (Internal Side)":
            return "INTERNAL"
        if mode == "🔧 Development Tools":
            return "DEVELOPMENT"
    
    return "CLIENT"
