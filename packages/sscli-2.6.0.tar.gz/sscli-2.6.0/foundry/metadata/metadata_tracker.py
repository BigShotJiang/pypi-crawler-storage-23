"""
Metadata Tracker for Seed & Source CLI - Phase 3 Implementation.

Tracks project metadata including template version, sscli version, features,
and user modifications to enable intelligent version-aware upgrades.
"""

from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any
import json
import sys

from foundry.constants import console


@dataclass
class ModificationRecord:
    """Record of a user modification tracked in metadata."""
    file: str
    reason: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ModificationRecord":
        """Create from dictionary."""
        return cls(**data)


@dataclass
class UpgradeRecord:
    """Record of a template upgrade action."""
    from_version: str
    to_version: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    applied_codemods: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    notes: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "UpgradeRecord":
        """Create from dictionary."""
        return cls(**data)


@dataclass
class ProjectMetadata:
    """Core metadata for a Seed & Source project."""

    # Template information
    installed_template_name: str
    installed_template_version: str

    # Creation information
    created_at: str  # ISO 8601 timestamp
    sscli_version: str

    # Feature tracking
    features_enabled: List[str] = field(default_factory=list)

    # User modifications
    custom_modifications: List[ModificationRecord] = field(default_factory=list)

    # Upgrade tracking
    last_upgraded: Optional[str] = None
    upgrade_history: List[UpgradeRecord] = field(default_factory=list)

    # Additional metadata
    project_name: Optional[str] = None
    notes: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert metadata to dictionary for JSON serialization."""
        return {
            "template": self.installed_template_name,
            "version": self.installed_template_version,
            "created_at": self.created_at,
            "sscli_version": self.sscli_version,
            "features": self.features_enabled,
            "custom_modifications": [mod.to_dict() for mod in self.custom_modifications],
            "last_upgraded": self.last_upgraded,
            "upgrade_history": [rec.to_dict() for rec in self.upgrade_history],
            "project_name": self.project_name,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectMetadata":
        """Create metadata from dictionary (JSON)."""
        # Handle nested structures
        modifications = [
            ModificationRecord.from_dict(mod)
            for mod in data.get("custom_modifications", [])
        ]
        upgrades = [
            UpgradeRecord.from_dict(rec)
            for rec in data.get("upgrade_history", [])
        ]

        return cls(
            installed_template_name=data.get("template", ""),
            installed_template_version=data.get("version", ""),
            created_at=data.get("created_at", ""),
            sscli_version=data.get("sscli_version", ""),
            features_enabled=data.get("features", []),
            custom_modifications=modifications,
            last_upgraded=data.get("last_upgraded"),
            upgrade_history=upgrades,
            project_name=data.get("project_name"),
            notes=data.get("notes"),
        )


class MetadataTracker:
    """
    Manages metadata lifecycle for Seed & Source projects.

    Responsibilities:
    - Initialize metadata for new projects
    - Read/write metadata from .sscli/metadata.json
    - Track template versions and features
    - Record user modifications
    - Validate metadata integrity
    - Support upgrade workflows
    """

    METADATA_DIR = ".sscli"
    METADATA_FILE = "metadata.json"

    def __init__(self, project_path: Optional[Path] = None):
        """Initialize tracker for a project."""
        self.project_path = Path(project_path) if project_path else Path.cwd()
        self.metadata_dir = self.project_path / self.METADATA_DIR
        self.metadata_file = self.metadata_dir / self.METADATA_FILE

    def get_metadata_path(self) -> Path:
        """Get the full path to the metadata file."""
        return self.metadata_file

    def init_project(
        self,
        template_name: str,
        version: str,
        features: Optional[List[str]] = None,
        sscli_version: Optional[str] = None,
        project_name: Optional[str] = None,
    ) -> ProjectMetadata:
        """
        Initialize metadata for a new project.

        Args:
            template_name: Name of the template (e.g., "python-saas")
            version: Template version (e.g., "2.3.0")
            features: List of enabled features
            sscli_version: Version of sscli used (optional, will be detected if not provided)
            project_name: Name of the project (optional)

        Returns:
            ProjectMetadata instance
        """
        if features is None:
            features = []

        if sscli_version is None:
            sscli_version = self._get_sscli_version()

        metadata = ProjectMetadata(
            installed_template_name=template_name,
            installed_template_version=version,
            created_at=datetime.now(timezone.utc).isoformat(),
            sscli_version=sscli_version,
            features_enabled=features,
            project_name=project_name,
        )

        self.write_project(metadata)
        return metadata

    def read_project(self, project_path: Optional[Path] = None) -> Optional[ProjectMetadata]:
        """
        Load metadata from an existing project.

        Args:
            project_path: Path to the project (uses self.project_path if not provided)

        Returns:
            ProjectMetadata or None if metadata not found
        """
        if project_path:
            self.project_path = Path(project_path)
            self.metadata_dir = self.project_path / self.METADATA_DIR
            self.metadata_file = self.metadata_dir / self.METADATA_FILE

        if not self.metadata_file.exists():
            return None

        try:
            content = self.metadata_file.read_text(encoding="utf-8")
            data = json.loads(content)
            return ProjectMetadata.from_dict(data)
        except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
            console.print(f"[yellow]⚠️  Failed to read metadata: {e}[/yellow]")
            return None

    def write_project(self, metadata: ProjectMetadata) -> bool:
        """
        Save metadata to the project's metadata file.

        Args:
            metadata: ProjectMetadata instance to save

        Returns:
            True if successful, False otherwise
        """
        try:
            # Create metadata directory if needed
            self.metadata_dir.mkdir(parents=True, exist_ok=True)

            # Write metadata file with pretty formatting
            content = json.dumps(metadata.to_dict(), indent=2)
            self.metadata_file.write_text(content, encoding="utf-8")
            return True
        except Exception as e:
            console.print(f"[yellow]⚠️  Failed to write metadata: {e}[/yellow]")
            return False

    def update_version(self, new_version: str) -> bool:
        """
        Update the installed template version (for upgrades).

        Args:
            new_version: New template version

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        old_version = metadata.installed_template_version
        metadata.installed_template_version = new_version
        metadata.last_upgraded = datetime.now(timezone.utc).isoformat()

        # Add upgrade record
        upgrade_record = UpgradeRecord(
            from_version=old_version,
            to_version=new_version,
        )
        metadata.upgrade_history.append(upgrade_record)

        return self.write_project(metadata)

    def update_version_with_codemods(
        self,
        new_version: str,
        applied_codemods: Optional[List[str]] = None,
        conflicts: Optional[List[str]] = None,
        notes: Optional[str] = None,
    ) -> bool:
        """
        Update version with codemod tracking (used during upgrades).

        Args:
            new_version: New template version
            applied_codemods: List of codemod identifiers applied
            conflicts: List of any conflicts encountered
            notes: Optional notes about the upgrade

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        old_version = metadata.installed_template_version
        metadata.installed_template_version = new_version
        metadata.last_upgraded = datetime.now(timezone.utc).isoformat()

        # Add upgrade record with codemods
        upgrade_record = UpgradeRecord(
            from_version=old_version,
            to_version=new_version,
            applied_codemods=applied_codemods or [],
            conflicts=conflicts or [],
            notes=notes,
        )
        metadata.upgrade_history.append(upgrade_record)

        return self.write_project(metadata)

    def mark_modified(self, file_path: str, reason: str) -> bool:
        """
        Track a file as modified by the user (conflict zone marker).

        Args:
            file_path: Path to the modified file (relative to project root)
            reason: Reason for the modification

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        # Check if already tracked
        existing = next(
            (mod for mod in metadata.custom_modifications if mod.file == file_path),
            None,
        )
        if existing:
            # Update existing modification with new reason
            existing.reason = reason
            existing.timestamp = datetime.now(timezone.utc).isoformat()
        else:
            # Add new modification record
            modification = ModificationRecord(file=file_path, reason=reason)
            metadata.custom_modifications.append(modification)

        return self.write_project(metadata)

    def clear_modifications(self, file_path: Optional[str] = None) -> bool:
        """
        Clear modification tracking for a file or all files.

        Args:
            file_path: Specific file to clear (clears all if None)

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        if file_path:
            metadata.custom_modifications = [
                mod for mod in metadata.custom_modifications
                if mod.file != file_path
            ]
        else:
            metadata.custom_modifications = []

        return self.write_project(metadata)

    def add_feature(self, feature_name: str) -> bool:
        """
        Add a feature to the features_enabled list.

        Args:
            feature_name: Name of the feature to add

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        if feature_name not in metadata.features_enabled:
            metadata.features_enabled.append(feature_name)
            return self.write_project(metadata)
        return True

    def remove_feature(self, feature_name: str) -> bool:
        """
        Remove a feature from the features_enabled list.

        Args:
            feature_name: Name of the feature to remove

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        if feature_name in metadata.features_enabled:
            metadata.features_enabled.remove(feature_name)
            return self.write_project(metadata)
        return True

    def add_features(self, features: List[str]) -> bool:
        """
        Add multiple features at once.

        Args:
            features: List of features to add

        Returns:
            True if successful, False otherwise
        """
        metadata = self.read_project()
        if not metadata:
            return False

        for feature in features:
            if feature not in metadata.features_enabled:
                metadata.features_enabled.append(feature)

        return self.write_project(metadata)

    def validate(self) -> tuple[bool, List[str]]:
        """
        Validate metadata integrity.

        Returns:
            Tuple of (is_valid, list of errors/warnings)
        """
        errors = []

        # Check if metadata file exists
        if not self.metadata_file.exists():
            errors.append("Metadata file does not exist")
            return False, errors

        # Try to read and parse
        metadata = self.read_project()
        if metadata is None:
            errors.append("Failed to parse metadata JSON")
            return False, errors

        # Validate required fields
        if not metadata.installed_template_name:
            errors.append("Missing installed_template_name")
        if not metadata.installed_template_version:
            errors.append("Missing installed_template_version")
        if not metadata.created_at:
            errors.append("Missing created_at timestamp")
        if not metadata.sscli_version:
            errors.append("Missing sscli_version")

        # Validate format of timestamps
        try:
            datetime.fromisoformat(metadata.created_at.replace("Z", "+00:00"))
        except ValueError:
            errors.append(f"Invalid created_at timestamp format: {metadata.created_at}")

        if metadata.last_upgraded:
            try:
                datetime.fromisoformat(metadata.last_upgraded.replace("Z", "+00:00"))
            except ValueError:
                errors.append(f"Invalid last_upgraded timestamp format: {metadata.last_upgraded}")

        # Validate features list
        if not isinstance(metadata.features_enabled, list):
            errors.append("features_enabled must be a list")

        # Validate custom modifications
        if not isinstance(metadata.custom_modifications, list):
            errors.append("custom_modifications must be a list")

        # Validate upgrade history
        if not isinstance(metadata.upgrade_history, list):
            errors.append("upgrade_history must be a list")

        return len(errors) == 0, errors

    def get_status(self) -> Dict[str, Any]:
        """
        Get a summary of the project's metadata status.

        Returns:
            Dictionary with status information
        """
        metadata = self.read_project()
        if not metadata:
            return {"status": "no_metadata"}

        return {
            "status": "valid",
            "template": metadata.installed_template_name,
            "version": metadata.installed_template_version,
            "created_at": metadata.created_at,
            "sscli_version": metadata.sscli_version,
            "features": metadata.features_enabled,
            "modifications_count": len(metadata.custom_modifications),
            "upgrade_count": len(metadata.upgrade_history),
            "last_upgraded": metadata.last_upgraded,
        }

    @staticmethod
    def _get_sscli_version() -> str:
        """Get the current sscli version from pyproject.toml."""
        try:
            # Try to get version from installed package
            import importlib.metadata
            return importlib.metadata.version("sscli")
        except Exception:
            # Fallback to reading pyproject.toml
            try:
                pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"
                content = pyproject_path.read_text(encoding="utf-8")
                for line in content.splitlines():
                    if line.startswith('version = "'):
                        return line.split('"')[1]
            except Exception:
                pass
            return "unknown"
