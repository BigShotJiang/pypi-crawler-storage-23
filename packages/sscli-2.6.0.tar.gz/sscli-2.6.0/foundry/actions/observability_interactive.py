"""
Interactive observability tools for Seed & Source.
Exposes Plan 025 features (diff, workspace) in interactive menu.
"""

import questionary
from questionary import Choice
from pathlib import Path
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.actions.diff import compute_diff
from foundry.workspaces import create_feature_workspace, list_workspaces
from foundry.interactive_utils import pause
from rich.panel import Panel
from rich.syntax import Syntax
import json


def observability_menu():
    """Interactive observability tools: diff, workspace isolation, metadata."""
    while True:
        choices = [
            Choice("🔍 3-Way Diff (Compare changes)", value="diff"),
            Choice("🎯 Create Feature Workspace (Isolated dev environment)", value="workspace"),
            Choice("📋 List Workspaces (Find all isolated workspaces)", value="list"),
            Choice("📊 View Project Metadata (Feature tracking)", value="metadata"),
            Choice("← Back to Main Menu", value="back"),
        ]
        
        selection = questionary.select(
            "🔬 Observability Tools:",
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        if selection == "back" or not selection:
            break
        elif selection == "diff":
            interactive_diff()
            pause()
        elif selection == "workspace":
            interactive_workspace_create()
            pause()
        elif selection == "list":
            interactive_workspace_list()
            pause()
        elif selection == "metadata":
            interactive_view_metadata()
            pause()


def interactive_diff():
    """Interactive 3-way diff with project path selection."""
    console.print(Panel("[bold]3-Way Diff: Base ↔ Current ↔ Injected Feature[/bold]", style="blue"))
    
    project_path = questionary.text(
        "📂 Project path to analyze:",
        default=".",
        validate=lambda x: Path(x).exists() or "Project path does not exist"
    ).ask()
    
    if not project_path:
        console.print("[yellow]Cancelled.[/yellow]")
        return
    
    output_format = questionary.select(
        "📊 Output format:",
        choices=[
            Choice("Colored (terminal)", value="colored"),
            Choice("Unified diff (patch-style)", value="unified"),
            Choice("JSON (machine-readable)", value="json"),
        ],
        default="colored",
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    console.print("\n⏳ Computing diff...\n")
    
    try:
        diff_result = compute_diff(
            project_path=project_path,
            format=output_format or "colored"
        )
        
        if isinstance(diff_result, dict) and output_format == "json":
            console.print_json(data=diff_result)
        else:
            console.print(diff_result)
        
        console.print("\n[green]✓ Diff complete[/green]")
    except Exception as e:
        console.print(f"\n[red]✗ Error:[/red] {e}")


def interactive_workspace_create():
    """Interactive feature workspace creation."""
    console.print(Panel("[bold]Create Feature Workspace[/bold]", style="blue"))
    
    from foundry.utils import get_templates, get_template_info
    available_templates = [t.name for t in get_templates()]
    
    template_name = questionary.select(
        "📦 Select template:",
        choices=available_templates,
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    if not template_name:
        console.print("[yellow]Cancelled.[/yellow]")
        return
    
    # List available features
    from foundry.features import AVAILABLE_EXTENSIONS
    compatible_features = [
        f for f, info in AVAILABLE_EXTENSIONS.items()
        if template_name in info.get("templates", [])
    ]
    
    if not compatible_features:
        console.print(f"[yellow]No features available for {template_name}[/yellow]")
        return
    
    feature_name = questionary.select(
        "🎁 Select feature to isolate:",
        choices=compatible_features,
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    if not feature_name:
        console.print("[yellow]Cancelled.[/yellow]")
        return
    
    output_path = questionary.text(
        "📁 Output directory:",
        default=f"./{feature_name}-workspace",
        validate=lambda x: True  # Allow paths that don't exist yet
    ).ask()
    
    if not output_path:
        console.print("[yellow]Cancelled.[/yellow]")
        return
    
    console.print(f"\n⏳ Creating workspace for [bold]{feature_name}[/bold]...\n")
    
    try:
        workspace_path = create_feature_workspace(
            feature_name=feature_name,
            template_name=template_name,
            output_path=output_path
        )
        
        console.print(f"[green]✓ Workspace created:[/green] {workspace_path}")
        console.print(f"\n[bold]Next steps:[/bold]")
        console.print(f"  1. cd {workspace_path}")
        console.print(f"  2. Edit files in isolation while mapped to full project structure")
        console.print(f"  3. Use [cyan]sscli obs diff[/cyan] to see your changes")
        
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")


def interactive_workspace_list():
    """Interactive workspace listing and navigation."""
    console.print(Panel("[bold]Feature Workspaces[/bold]", style="blue"))
    
    search_path = questionary.text(
        "🔍 Search path (blank for current directory):",
        default="."
    ).ask()
    
    if search_path is None:
        return
    
    try:
        workspaces = list_workspaces(search_path or ".")
        
        if not workspaces:
            console.print("[yellow]No workspaces found[/yellow]")
            return
        
        console.print(f"\n[bold]Found {len(workspaces)} workspace(s):[/bold]\n")
        
        for i, ws in enumerate(workspaces, 1):
            console.print(f"  {i}. {ws.get('workspace_id', 'Unknown')}")
            console.print(f"     Feature: {ws.get('feature_name')} | Template: {ws.get('template_name')}")
            console.print(f"     Files: {ws.get('files_included', 0)} | Created: {ws.get('created_at', 'N/A')}")
            console.print()
        
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")


def interactive_view_metadata():
    """Interactive view of project metadata."""
    console.print(Panel("[bold]Project Metadata[/bold]", style="blue"))
    
    project_path = questionary.text(
        "📂 Project path:",
        default=".",
        validate=lambda x: Path(x).exists() or "Path does not exist"
    ).ask()
    
    if not project_path:
        return
    
    metadata_file = Path(project_path) / ".sscli-metadata.json"
    
    if not metadata_file.exists():
        console.print(f"[yellow]No metadata found in {project_path}[/yellow]")
        return
    
    try:
        with open(metadata_file) as f:
            metadata = json.load(f)
        
        console.print("\n[bold cyan]📊 .sscli-metadata.json[/bold cyan]\n")
        console.print(Syntax(
            json.dumps(metadata, indent=2),
            "json",
            theme="monokai",
            line_numbers=False
        ))
        
        console.print("\n[bold]Features Injected:[/bold]")
        for feature in metadata.get("features_injected", []):
            console.print(f"  • {feature.get('name')} (v{feature.get('version', '?')}) @ {feature.get('injected_at', 'N/A')}")
        
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
