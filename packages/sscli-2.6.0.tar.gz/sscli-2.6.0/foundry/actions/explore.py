from foundry.constants import console, TIER_HIERARCHY, QUESTIONARY_STYLE, TEMPLATE_REGISTRY
from foundry.utils import get_templates, get_template_info
from foundry.auth import get_current_license_info
from rich.panel import Panel
from rich.tree import Tree
import questionary
from questionary import Choice
from prompt_toolkit.formatted_text import ANSI
import re


def _get_template_tech(name):
    """Get technology stack for a template by name."""
    # Map template names to tech descriptions
    tech_map = {
        "python-saas": "Python (FastAPI/SQLAlchemy)",
        "rails-api": "Ruby on Rails",
        "react-client": "React/Vite",
        "rails-ui-kit": "Rails + ViewComponent",
        "static-landing": "Astro (Static Site)",
        "mobile-android": "Android (Kotlin/Compose)",
        "mobile-ios": "iOS (Swift/SwiftUI)",
        "data-pipeline": "Data Stack (dbt + Python)",
        "terraform-infra": "Terraform (Multi-cloud)",
        "wiring": "Docker Orchestration",
    }
    return tech_map.get(name, "Multi-tech Stack")


def _strip_markup(text):
    """Remove Rich markup tags from text."""
    return re.sub(r'\[/?[^\]]+\]', '', text)


def _render_templates_tree(buckets):
    """Render a tree view with all categories expanded showing available templates."""
    tree = Tree("[bold green]Seed & Source Inventory[/bold green]")

    for category, items in buckets.items():
        if not items:
            continue

        count = len(items)
        cat_node = tree.add(f"[bold yellow]▼ {category} ({count})[/bold yellow]")
        
        for item in items:
            node = cat_node.add(f"[bold cyan]{item['name']}[/bold cyan]")
            # Show tier badge in tree
            if item['tier'] != "free":
                tier_display = f"(🔐 {item['tier'].upper()})" if item['locked'] else f"(✅ {item['tier'].upper()})"
                node.add(f"[yellow]{tier_display}[/yellow]")
            # Show tech
            tech = _get_template_tech(item['name'])
            node.add(f"[dim]{tech}[/dim]")

    console.print(Panel(tree, title="Available Templates", border_style="green"))


def _show_template_info(name):
    """Show detailed information about a template."""
    info = get_template_info(name)
    tech = _get_template_tech(name)
    
    content = f"[bold cyan]Name:[/bold cyan] {name}\n"
    content += f"[bold cyan]Tech:[/bold cyan] {tech}\n"
    content += f"[bold cyan]Tier:[/bold cyan] {info.get('tier', 'free').upper()}\n"
    content += f"[bold cyan]Repo:[/bold cyan] {info.get('repo', 'N/A')}\n\n"
    content += f"[italic]{info.get('description', 'No detailed description available.')}[/italic]"
    
    console.print(Panel(content, title=f"Template Details: {name}", border_style="cyan", expand=False))
    questionary.press_any_key_to_continue().ask()


def run_explore():
    """Interactive template explorer with collapsible tree and selectable templates."""
    # Get user info for tier checking
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    # Group templates by category
    buckets = {
        "Backend Services": [],
        "Frontend & UI": [],
        "Mobile App": [],
        "Data Engineering": [],
        "Infrastructure": [],
        "Other": [],
    }

    templates = get_templates()

    for tmpl in templates:
        name = tmpl.name
        # Fetch metadata to get the tier
        info = get_template_info(name)
        tmpl_tier = info.get("tier", "free").lower()
        tmpl_rank = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Check if locked
        locked = tmpl_rank > user_rank
        
        # Store template data for processing
        tmpl_data = {
            "name": name,
            "tier": tmpl_tier,
            "locked": locked,
        }

        if name in ["python-saas", "rails-api"]:
            buckets["Backend Services"].append(tmpl_data)
        elif name in ["react-client", "rails-ui-kit", "static-landing"]:
            buckets["Frontend & UI"].append(tmpl_data)
        elif name.startswith("mobile-"):
            buckets["Mobile App"].append(tmpl_data)
        elif name == "data-pipeline":
            buckets["Data Engineering"].append(tmpl_data)
        elif name == "terraform-infra":
            buckets["Infrastructure"].append(tmpl_data)
        else:
            buckets["Other"].append(tmpl_data)

    # Remove empty categories
    buckets = {k: v for k, v in buckets.items() if v}
    
    # State for collapsible sections - start collapsed as requested
    expanded_categories = set()
    last_selected_value = f"toggle:{list(buckets.keys())[0]}" if buckets else None
    
    # ANSI Colors for visual richness
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    RED = "\033[31m"
    MAGENTA = "\033[35m"
    BOLD = "\033[1m"
    RESET = "\033[0m"
    
    while True:
        choices = []
        for category, items in buckets.items():
            is_expanded = category in expanded_categories
            symbol = "▼" if is_expanded else "▶"
            count = len(items)
            
            # Category choice - Base Yellow
            choices.append(Choice(
                title=ANSI(f"{YELLOW}{symbol} {category} ({count}){RESET}"),
                value=f"toggle:{category}"
            ))
            
            if is_expanded:
                for i, item in enumerate(items):
                    is_last = (i == len(items) - 1)
                    connector = "  └─ " if is_last else "  ├─ "
                    
                    # Blue template names
                    label = f"{connector}{BLUE}{item['name']}{RESET}"
                    
                    # Colored badges
                    if item['locked']:
                        label += f" {RED}🔐 LOCKED{RESET}"
                    else:
                        tier = item['tier']
                        if tier == "alpha":
                            label += f" {YELLOW}✅ ALPHA{RESET}"
                        elif tier == "pro":
                            label += f" {MAGENTA}✅ PRO{RESET}"
                        elif tier == "free":
                            label += f" {GREEN}✅ FREE{RESET}"
                    
                    # Tech description for the gray 3rd row (via patch)
                    tech = _get_template_tech(item['name'])
                    description = f"  Description: {tech}"
                    
                    choices.append(Choice(
                        title=ANSI(label),
                        value=f"tmpl:{item['name']}",
                        description=description
                    ))
        
        choices.append(Choice("← Back to Main Menu", value="back"))

        console.clear()
        # Green frame that encompasses the header and instructions
        console.print(Panel(
            f"[bold green]Seed & Source Inventory[/bold green]\n"
            f"[dim]Navigate with arrows. Use {BOLD}Enter/Right{RESET} [dim]to expand/select, {BOLD}Left{RESET} [dim]to collapse.[/dim]",
            border_style="green",
            padding=(1, 2)
        ))
        
        selected = questionary.select(
            "Select a template to view details:",
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE),
            use_indicator=True,
            default=last_selected_value
        ).ask()

        if selected is None or selected == "back":
            break
            
        last_selected_value = selected
            
        if selected.startswith("toggle:"):
            cat = selected.split(":", 1)[1]
            if cat in expanded_categories:
                expanded_categories.remove(cat)
            else:
                expanded_categories.add(cat)
            continue
            
        if selected.startswith("tmpl:"):
            tmpl_name = selected.split(":", 1)[1]
            _show_template_info(tmpl_name)

