import subprocess
import sys
from typing import Optional

from foundry.constants import TEMPLATES_DIR, TEMPLATE_REGISTRY, TIER_HIERARCHY, console
from foundry.auth import get_current_license_info


def run_setup(
    verbose: bool = False,
    force: bool = False,
    skip_deps: bool = False,
    env: str = "dev",
    strategy: Optional[str] = None,
):
    """
    Orchestrates the setup process for all available templates.
    Hands off execution to each template's local bin/setup.py.
    
    Auth gating: Only allows users to set up templates matching their tier.
    """
    templates = [
        "python-saas",
        "rails-api",
        "rails-ui-kit",
        "data-pipeline",
        "react-client",
        "mobile-android",
        "mobile-ios",
        "terraform-infra",
    ]

    # Get current user tier for access control
    auth_info = get_current_license_info()
    user_tier = auth_info.get("tier", "free")
    user_tier_level = TIER_HIERARCHY.get(user_tier, 0)

    console.print("[bold yellow]Foundry: Running Template Setup Suite[/bold yellow]")
    console.print(f"[dim]User tier: {user_tier.upper()}[/dim]\n")

    blocked_templates = []
    
    for tmpl in templates:
        tmpl_path = TEMPLATES_DIR / tmpl
        if not tmpl_path.exists():
            continue

        # Get template tier requirement from registry
        tmpl_tier = TEMPLATE_REGISTRY.get(tmpl, {}).get("tier", "free")
        tmpl_tier_level = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Check if user has access to this template
        if user_tier_level < tmpl_tier_level:
            blocked_templates.append((tmpl, tmpl_tier))
            console.print(
                f"[yellow]⊝ Skipping {tmpl}[/] - "
                f"requires {tmpl_tier.upper()} tier (you have {user_tier.upper()})"
            )
            continue

        console.print(f"\n[bold cyan]▶ Setting up {tmpl}[/bold cyan]")

        setup_script = tmpl_path / "bin" / "setup.py"
        if not setup_script.exists():
            console.print(f"  [dim]No setup.py found for {tmpl}, skipping.[/dim]")
            continue

        cmd = [sys.executable, str(setup_script), "--env", env]
        if force:
            cmd.append("--force")
        if skip_deps:
            cmd.append("--skip-deps")
        # Strategy is currently handled per-template if they support it
        if strategy:
            cmd.extend(["--strategy", strategy])

        try:
            # We use check_call to ensure we stop on first failure
            subprocess.check_call(cmd, cwd=tmpl_path)
            console.print(f"  [green]✔ {tmpl} setup complete.[/green]")
        except subprocess.CalledProcessError:
            console.print(f"  [red]✘ {tmpl} setup failed.[/red]")
            # We don't exit here to allow other templates if needed,
            # but bin/setup usually wants total success.
            # However, for the orchestrator, we might want to continue or exit.
            # Given bin/setup's use case, exit 1 is safer.
            sys.exit(1)
        except Exception as e:
            console.print(f"  [red]Unexpected error:[/red] {e}")
            sys.exit(1)

    if blocked_templates:
        console.print(f"\n[yellow]⚠️  {len(blocked_templates)} template(s) were skipped due to tier restrictions.[/yellow]")
        console.print("[dim]Upgrade to PRO or ALPHA to access all templates:[/dim]")
        for tmpl, tier in blocked_templates:
            console.print(f"  [dim]• {tmpl} ({tier.upper()})[/dim]")
        console.print()

    console.print(
        "\n[bold green]Template setup suite completed successfully.[/bold green]"
    )
