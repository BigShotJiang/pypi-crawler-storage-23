"""
3-way diff engine for comparing base template, current code, and injected features.
"""

import json
import difflib
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict
from foundry.constants import console, FOUNDRY_ROOT


@dataclass
class DiffSection:
    """Represents a section of a file with its diff type."""
    file_path: str
    diff_type: str  # 'added_by_base', 'added_by_feature', 'modified_by_user', 'unchanged'
    lines: List[str]
    start_line: int
    end_line: int
    context: str = ""


@dataclass
class FileDiff:
    """Complete diff information for a single file."""
    file_path: str
    exists_in_base: bool
    exists_in_current: bool
    exists_in_feature: bool
    sections: List[DiffSection]
    change_type: str  # 'added', 'deleted', 'modified', 'unchanged'
    additions: int = 0
    deletions: int = 0
    modifications: int = 0


def compute_diff(
    project_path: str,
    base_template_path: Optional[str] = None,
    feature_name: Optional[str] = None,
    template_name: Optional[str] = None,
    output_format: str = "colored",
) -> Dict:
    """
    Compute a 3-way diff between:
    1. Base Template (original project scaffold)
    2. Current Code (user's project, potentially with modifications)
    3. Injected Feature (feature being added/compared)
    
    Args:
        project_path: Path to the current project
        base_template_path: Path to base template (if None, infers from metadata)
        feature_name: Feature to compare against (if None, all injected features)
        template_name: Template type (python-saas, rails-api, react-client, static-landing)
        output_format: 'colored', 'unified', 'json'
    
    Returns:
        Dict with diff results, statistics, and human-readable output
    """
    project_path = Path(project_path).resolve()
    
    # Load project metadata to understand what features are injected
    metadata = _read_project_metadata(project_path)
    
    if not metadata:
        return {
            "success": False,
            "error": "No .sscli-metadata.json found. Project may not be generated with sscli.",
            "project_path": str(project_path),
        }
    
    template_name = template_name or metadata.get("base_template_version", "").split("/")[0]
    
    # Get paths for comparison
    base_template_path = base_template_path or _infer_template_path(
        template_name, metadata.get("base_template_version")
    )
    
    if not base_template_path or not Path(base_template_path).exists():
        return {
            "success": False,
            "error": f"Base template path not found: {base_template_path}",
            "project_path": str(project_path),
        }
    
    base_template_path = Path(base_template_path).resolve()
    
    # Get feature injection paths
    injected_features = metadata.get("features_injected", [])
    feature_paths = {}
    
    for feature in injected_features:
        feature_name_id = (
            feature.get("name") if isinstance(feature, dict) else feature.split("/")[0]
        )
        feature_path = _infer_feature_path(template_name, feature_name_id)
        if feature_path and Path(feature_path).exists():
            feature_paths[feature_name_id] = Path(feature_path).resolve()
    
    # Compute diffs
    file_diffs = {}
    stats = {
        "total_files": 0,
        "added": 0,
        "deleted": 0,
        "modified": 0,
        "unchanged": 0,
        "total_additions": 0,
        "total_deletions": 0,
        "total_modifications": 0,
    }
    
    # Compare current project with base template
    for current_file in _get_all_files(project_path):
        rel_path = current_file.relative_to(project_path)
        
        # Skip metadata and special files
        if _should_skip_file(rel_path):
            continue
        
        base_file = base_template_path / rel_path
        feature_file = None
        
        # Find which feature contains this file (if any)
        for fname, fpath in feature_paths.items():
            potential_file = fpath / rel_path
            if potential_file.exists():
                feature_file = potential_file
                break
        
        diff = _compute_file_diff(
            str(rel_path),
            current_file,
            base_file if base_file.exists() else None,
            feature_file,
        )
        
        if diff:
            file_diffs[str(rel_path)] = diff
            stats["total_files"] += 1
            stats[diff.change_type] += 1
            stats["total_additions"] += diff.additions
            stats["total_deletions"] += diff.deletions
            stats["total_modifications"] += diff.modifications
    
    # Generate output based on format
    output = {
        "success": True,
        "project_path": str(project_path),
        "base_template": str(base_template_path),
        "template_type": template_name,
        "features_compared": list(feature_paths.keys()),
        "statistics": stats,
        "file_diffs": {k: _serialize_diff(v) for k, v in file_diffs.items()},
        "metadata": metadata,
    }
    
    # Add human-readable output
    if output_format == "colored":
        output["formatted_output"] = _format_diff_colored(file_diffs, stats)
    elif output_format == "unified":
        output["formatted_output"] = _format_diff_unified(file_diffs, stats)
    
    return output


def _read_project_metadata(project_path: Path) -> Optional[Dict]:
    """Read .sscli-metadata.json from project."""
    metadata_file = project_path / ".sscli-metadata.json"
    if not metadata_file.exists():
        return None
    
    try:
        return json.loads(metadata_file.read_text(encoding="utf-8"))
    except Exception as e:
        console.print(f"[yellow]Warning: Could not read metadata: {e}[/yellow]")
        return None


def _infer_template_path(template_name: str, version: Optional[str]) -> Optional[str]:
    """Infer path to base template from template name."""
    if not template_name:
        return None
    
    foundry_root = Path(FOUNDRY_ROOT)
    
    # Try different possible locations
    possible_paths = [
        foundry_root / "templates" / template_name,
        foundry_root.parent / template_name,
        Path("/") / "tmp" / template_name,  # Cached templates
    ]
    
    for path in possible_paths:
        if path.exists():
            return str(path)
    
    return None


def _infer_feature_path(template_name: str, feature_name: str) -> Optional[str]:
    """Infer path to feature directory."""
    foundry_root = Path(FOUNDRY_ROOT)
    
    # Features can be at root/features/<feature_name>
    # or root/features/<feature_name>/<template_name>
    possible_paths = [
        foundry_root / "features" / feature_name / template_name,
        foundry_root / "features" / feature_name,
        foundry_root.parent / "features" / feature_name,
    ]
    
    for path in possible_paths:
        if path.exists():
            return str(path)
    
    return None


def _get_all_files(path: Path) -> List[Path]:
    """Recursively get all files in a directory."""
    files = []
    for item in path.rglob("*"):
        if item.is_file() and not _should_skip_directory(item):
            files.append(item)
    return files


def _should_skip_directory(file_path: Path) -> bool:
    """Check if file is in a directory that should be skipped."""
    skip_dirs = {
        ".git",
        ".env",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        "venv",
        "build",
        "dist",
        ".egg-info",
        ".coverage",
        ".next",
        "tmp",
        "log",
    }
    return any(part in skip_dirs for part in file_path.parts)


def _should_skip_file(rel_path: Path) -> bool:
    """Check if file should be skipped in diff."""
    skip_files = {
        ".sscli-metadata.json",
        ".feature-workspace.json",
        ".gitignore",
        ".env",
        ".env.local",
        ".env.example",  # Often varies by user
    }
    
    return (
        rel_path.name in skip_files
        or _should_skip_directory(rel_path)
        or rel_path.suffix in {".pyc", ".class"}
    )


def _compute_file_diff(
    file_path: str,
    current_file: Optional[Path],
    base_file: Optional[Path],
    feature_file: Optional[Path],
) -> Optional[FileDiff]:
    """Compute detailed diff for a single file."""
    
    try:
        current_lines = (
            current_file.read_text(encoding="utf-8").splitlines(keepends=True)
            if current_file and current_file.exists()
            else []
        )
        base_lines = (
            base_file.read_text(encoding="utf-8").splitlines(keepends=True)
            if base_file and base_file.exists()
            else []
        )
        feature_lines = (
            feature_file.read_text(encoding="utf-8").splitlines(keepends=True)
            if feature_file and feature_file.exists()
            else []
        )
    except (UnicodeDecodeError, IOError):
        # Skip binary files
        return None
    
    # Determine what changed
    sections = []
    additions = deletions = modifications = 0
    
    # 3-way comparison using difflib
    if current_lines == base_lines and base_lines == feature_lines:
        change_type = "unchanged"
    elif not current_lines and base_lines:
        change_type = "deleted"
        deletions = len(base_lines)
    elif not base_lines and current_lines:
        change_type = "added"
        additions = len(current_lines)
    else:
        change_type = "modified"
        
        # Use difflib to compute modifications
        diff = difflib.unified_diff(base_lines, current_lines, lineterm="")
        diff_lines = list(diff)
        
        additions = sum(1 for line in diff_lines if line.startswith("+"))
        deletions = sum(1 for line in diff_lines if line.startswith("-"))
        modifications = max(additions, deletions)
    
    return FileDiff(
        file_path=file_path,
        exists_in_base=bool(base_file and base_file.exists()),
        exists_in_current=bool(current_file and current_file.exists()),
        exists_in_feature=bool(feature_file and feature_file.exists()),
        sections=sections,
        change_type=change_type,
        additions=additions,
        deletions=deletions,
        modifications=modifications,
    )


def _serialize_diff(diff: FileDiff) -> Dict:
    """Convert FileDiff to serializable dict."""
    return {
        "file_path": diff.file_path,
        "exists_in_base": diff.exists_in_base,
        "exists_in_current": diff.exists_in_current,
        "exists_in_feature": diff.exists_in_feature,
        "change_type": diff.change_type,
        "additions": diff.additions,
        "deletions": diff.deletions,
        "modifications": diff.modifications,
        "sections": [asdict(s) for s in diff.sections],
    }


def _format_diff_colored(file_diffs: Dict[str, FileDiff], stats: Dict) -> str:
    """Format diff output with color codes (Rich)."""
    output_lines = [
        "[bold cyan]╔════════════════════════════════════════════════════════════╗[/bold cyan]",
        "[bold cyan]║          3-Way Diff: Base ↔ Current ↔ Feature               ║[/bold cyan]",
        "[bold cyan]╚════════════════════════════════════════════════════════════╝[/bold cyan]",
        "",
        f"[bold]Summary:[/bold]",
        f"  [green]✓ Unchanged: {stats['unchanged']}[/green]",
        f"  [yellow]± Modified: {stats['modified']}[/yellow]",
        f"  [blue]+ Added: {stats['added']}[/blue]",
        f"  [red]- Deleted: {stats['deleted']}[/red]",
        "",
        f"[bold]Statistics:[/bold]",
        f"  Total additions: [green]+{stats['total_additions']}[/green]",
        f"  Total deletions: [red]-{stats['total_deletions']}[/red]",
        f"  Total modifications: [yellow]±{stats['total_modifications']}[/yellow]",
        "",
        "[bold]Changed Files:[/bold]",
    ]
    
    for file_path, diff in sorted(file_diffs.items()):
        if diff.change_type != "unchanged":
            icon = {
                "added": "[blue]+[/blue]",
                "deleted": "[red]-[/red]",
                "modified": "[yellow]±[/yellow]",
            }.get(diff.change_type, " ")
            
            output_lines.append(
                f"  {icon} {file_path} "
                f"([green]+{diff.additions}[/green] "
                f"[red]-{diff.deletions}[/red] "
                f"[yellow]±{diff.modifications}[/yellow])"
            )
    
    return "\n".join(output_lines)


def _format_diff_unified(file_diffs: Dict[str, FileDiff], stats: Dict) -> str:
    """Format diff output in unified diff style."""
    output_lines = [
        "=" * 60,
        "3-Way Diff: Base ↔ Current ↔ Feature",
        "=" * 60,
        "",
        f"Summary:",
        f"  Unchanged:    {stats['unchanged']} files",
        f"  Modified:     {stats['modified']} files",
        f"  Added:        {stats['added']} files",
        f"  Deleted:      {stats['deleted']} files",
        "",
        f"Statistics:",
        f"  Total additions:     +{stats['total_additions']} lines",
        f"  Total deletions:     -{stats['total_deletions']} lines",
        f"  Total modifications: ±{stats['total_modifications']} lines",
        "",
        "Changed Files:",
    ]
    
    for file_path, diff in sorted(file_diffs.items()):
        if diff.change_type != "unchanged":
            output_lines.append(
                f"  {diff.change_type:10} {file_path} "
                f"(+{diff.additions} -{diff.deletions} ±{diff.modifications})"
            )
    
    return "\n".join(output_lines)


# Example: compute_diff("/tmp/my-project", output_format="colored")
