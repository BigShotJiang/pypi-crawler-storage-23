"""
Transformation command integration with dry-run support.

Provides unified interface for applying transformations (refactor, upgrade, new)
with optional dry-run preview mode.
"""

import sys
from pathlib import Path
from typing import Optional, List, Callable
from foundry.constants import console
from foundry.safety import DryRunEngine
from foundry.telemetry import log_event


class TransformationCommand:
    """Base class for transformation commands with dry-run support."""
    
    def __init__(
        self,
        name: str,
        description: str
    ):
        """
        Initialize transformation command.
        
        Args:
            name: Command name (e.g., 'new', 'refactor', 'upgrade')
            description: Command description
        """
        self.name = name
        self.description = description
        self.dry_run_engine: Optional[DryRunEngine] = None
    
    def execute(
        self,
        dry_run: bool = False,
        json_output: bool = False,
        stats_only: bool = False,
        output_file: Optional[str] = None,
        verbose: bool = False,
        **kwargs
    ) -> bool:
        """
        Execute transformation with optional dry-run.
        
        Args:
            dry_run: If True, preview without applying changes
            json_output: If True, output JSON format
            stats_only: If True, only show statistics
            output_file: If provided, write output to file
            verbose: If True, show detailed information
            **kwargs: Additional arguments for the transformation
        
        Returns:
            True if successful, False otherwise
        """
        if dry_run:
            console.print(f"[yellow]🔍 DRY-RUN:[/yellow] Previewing {self.name} transformation...")
            self.dry_run_engine = DryRunEngine()
        
        try:
            # Run the actual transformation logic
            success = self._run_transformation(**kwargs)
            
            if not success:
                return False
            
            # If dry-run, show preview instead of applying
            if dry_run:
                self._show_dry_run_output(
                    json_output=json_output,
                    stats_only=stats_only,
                    output_file=output_file,
                    verbose=verbose
                )
                console.print("[yellow]✓ Dry-run complete (no changes applied)[/yellow]")
                return True
            else:
                console.print(f"[green]✓ {self.name.capitalize()} completed successfully[/green]")
                return True
        
        except Exception as e:
            console.print(f"[red]✗ {self.name} failed: {str(e)}[/red]")
            if verbose:
                import traceback
                traceback.print_exc()
            return False
    
    def _run_transformation(self, **kwargs) -> bool:
        """
        Run the actual transformation logic.
        Must be overridden by subclasses.
        
        Returns:
            True if successful, False otherwise
        """
        raise NotImplementedError("Subclasses must implement _run_transformation")
    
    def _show_dry_run_output(
        self,
        json_output: bool = False,
        stats_only: bool = False,
        output_file: Optional[str] = None,
        verbose: bool = False
    ) -> None:
        """
        Display dry-run preview output.
        
        Args:
            json_output: If True, output JSON format
            stats_only: If True, only show statistics
            output_file: If provided, write to file instead of stdout
        """
        if not self.dry_run_engine:
            return
        
        # Determine output content
        if json_output:
            output = self.dry_run_engine.as_json(include_content=False)
        elif stats_only:
            output = self.dry_run_engine.as_stats(verbose=verbose)
        else:
            output = self.dry_run_engine.as_unified_diff()
        
        # Output to file or stdout
        if output_file:
            Path(output_file).write_text(output)
            console.print(f"[cyan]📄 Output written to:[/cyan] {output_file}")
        else:
            console.print(output)
        
        # Show summary
        if not stats_only:
            summary = self.dry_run_engine.get_summary_line()
            console.print(f"[cyan]Summary:[/cyan] {summary}")


class TransformationCommandRegistry:
    """Registry for managing transformation commands."""
    
    def __init__(self):
        """Initialize the registry."""
        self._commands: dict[str, TransformationCommand] = {}
    
    def register(self, command: TransformationCommand) -> None:
        """Register a transformation command."""
        self._commands[command.name] = command
    
    def get(self, name: str) -> Optional[TransformationCommand]:
        """Get a registered command."""
        return self._commands.get(name)
    
    def list_commands(self) -> List[str]:
        """List all registered commands."""
        return list(self._commands.keys())


# Global registry
_registry = TransformationCommandRegistry()


def register_command(command: TransformationCommand) -> None:
    """Register a transformation command."""
    _registry.register(command)


def get_command(name: str) -> Optional[TransformationCommand]:
    """Get a registered command."""
    return _registry.get(name)


def handle_dry_run_output(
    engine: DryRunEngine,
    json_format: bool = False,
    stats_only: bool = False,
    output_file: Optional[str] = None,
    verbose: bool = False
) -> None:
    """
    Handle output from a dry-run operation.
    
    This is a utility function for commands that want to use dry-run
    but aren't using the TransformationCommand base class.
    
    Args:
        engine: The DryRunEngine instance
        json_format: If True, output JSON
        stats_only: If True, only show stats
        output_file: If provided, write to file
        verbose: If True, show verbose stats
    """
    if json_format:
        output = engine.as_json(include_content=False)
    elif stats_only:
        output = engine.as_stats(verbose=verbose)
    else:
        output = engine.as_unified_diff()
    
    if output_file:
        Path(output_file).write_text(output)
        console.print(f"[cyan]📄[/cyan] Output written to: {output_file}")
    else:
        console.print(output)
    
    if not stats_only:
        console.print(f"[cyan]Summary:[/cyan] {engine.get_summary_line()}")
