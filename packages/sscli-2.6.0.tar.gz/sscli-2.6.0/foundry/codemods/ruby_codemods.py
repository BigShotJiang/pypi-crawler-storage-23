"""
Ruby codemods for Rails applications using ast-grep and Synvert.

Provides code modifications for Rails apps:
- Route definition injection (config/routes.rb)
- Middleware registration
- Model association injection
- Configuration constant injection

Uses Synvert for AST-aware Ruby transformations when available,
with ast-grep and string-based fallbacks.
"""

from pathlib import Path
from typing import Optional, Dict, Tuple, List
import subprocess
import tempfile

from foundry.codemods.base import BaseCodemod, ModificationResult
from foundry.constants import console


class RubyCodemod(BaseCodemod):
    """
    Base class for Ruby code transformations using Synvert or ast-grep.
    Prioritizes safe AST transformations over string manipulation.
    """

    def apply(self, path: Path) -> ModificationResult:
        """Apply Ruby code transformation."""
        if not path.exists():
            return ModificationResult(
                success=False,
                error=f"File not found: {path}"
            )

        try:
            # Try Synvert first (most robust for Ruby)
            try:
                from foundry.tools.synvert_adapter import SynvertAdapter
                result = self._apply_synvert(path)
                if result.success or result.error != "Synvert not available":
                    return result
            except (ImportError, RuntimeError):
                pass

            # Try ast-grep
            result = self._apply_ast_grep(path)
            if result.success or result.error != "ast-grep not available":
                return result

            # Fallback to string-based
            return self._apply_string_based(path)

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"{self.__class__.__name__}: {str(e)}"
            )

    def _apply_synvert(self, path: Path) -> ModificationResult:
        """Apply transformation using Synvert (Ruby AST)."""
        try:
            from foundry.tools.synvert_adapter import SynvertAdapter
            adapter = SynvertAdapter(path.parent)
            rule = self.get_synvert_rule()
            if rule:
                result = adapter.execute_rule(rule)
                if result["success"]:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=1
                    )
                else:
                    return ModificationResult(
                        success=False,
                        error=result.get("error", "Synvert rule failed")
                    )
        except (ImportError, RuntimeError):
            pass

        return ModificationResult(
            success=False,
            error="Synvert not available"
        )

    def _apply_ast_grep(self, path: Path) -> ModificationResult:
        """Apply transformation using ast-grep."""
        try:
            rule = self.get_ast_grep_rule()
            if not rule:
                return ModificationResult(success=False, error="No rule defined")

            original_content = path.read_text(encoding="utf-8")

            try:
                cmd = [
                    'ast-grep', 'scan',
                    '--pattern', rule.get('pattern', ''),
                    '--replace', rule.get('replace', ''),
                    str(path)
                ]

                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=10
                )

                modified_content = path.read_text(encoding="utf-8")

                if modified_content != original_content:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=1
                    )
                else:
                    return ModificationResult(
                        success=True,
                        modified_path=path,
                        changes_made=0
                    )

            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

        except Exception:
            pass

        return ModificationResult(
            success=False,
            error="ast-grep not available"
        )

    def get_synvert_rule(self) -> Optional[str]:
        """
        Return Synvert rule definition.
        Override in subclasses.
        """
        return None

    def get_ast_grep_rule(self) -> Optional[Dict]:
        """
        Return ast-grep rule definition for Ruby.
        Override in subclasses.
        """
        return None

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """
        Fallback string-based transformation.
        Override in subclasses for safety-aware string injection.
        """
        return ModificationResult(
            success=False,
            error="No transformation approach available"
        )


class InjectRouteCodemod(RubyCodemod):
    """
    Add a route definition to Rails config/routes.rb.
    Handles both simple routes and namespaced routes.
    
    Examples:
        get '/users', to: 'users#index'
        namespace :admin do
          resources :users
        end
        post 'webhooks/shopify', to: 'webhooks/shopify#handle'
    """

    def __init__(
        self,
        http_method: str,
        path: str,
        controller_action: str,
        namespace: Optional[str] = None
    ):
        """
        Args:
            http_method: HTTP method (get, post, patch, delete, etc.)
            path: Route path (e.g., 'users' or 'webhooks/shopify')
            controller_action: Controller#action (e.g., 'users#index')
            namespace: Rails namespace if applicable
        """
        self.http_method = http_method.lower()
        self.path = path
        self.controller_action = controller_action
        self.namespace = namespace

    def get_synvert_rule(self) -> Optional[str]:
        """Return Synvert rule for route injection."""
        if self.namespace:
            return (
                f"Synvert::Mutation.new('rails/add_namespaced_route') {{\n"
                f"  description 'Add {self.http_method} route to {self.namespace}'\n"
                f"  within_files 'config/routes.rb' {{\n"
                f"    find_node {{\n"
                f"      type 'send'\n"
                f"      message 'namespace'\n"
                f"      receiver nil\n"
                f"    }} {{\n"
                f"      goto_node 'arguments.first.block' {{\n"
                f"        insert 'after_end', '{self.http_method} \"{self.path}\", to: \"{self.controller_action}\"'\n"
                f"      }}\n"
                f"    }}\n"
                f"  }}\n"
                f"}}\n"
            )
        else:
            return (
                f"Synvert::Mutation.new('rails/add_route') {{\n"
                f"  description 'Add {self.http_method} route'\n"
                f"  within_files 'config/routes.rb' {{\n"
                f"    find_node {{\n"
                f"      type 'send'\n"
                f"      message 'draw'\n"
                f"    }} {{\n"
                f"      insert 'before_end', '{self.http_method} \"{self.path}\", to: \"{self.controller_action}\"'\n"
                f"    }}\n"
                f"  }}\n"
                f"}}\n"
            )

    def get_ast_grep_rule(self) -> Optional[Dict]:
        """Return ast-grep rule for route injection."""
        return {
            "pattern": f"{self.http_method} '{self.path}'",
            "replace": f"{self.http_method} '{self.path}', to: '{self.controller_action}'"
        }

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based route injection."""
        try:
            content = path.read_text(encoding="utf-8")

            # Build route line
            if self.namespace:
                route_line = (
                    f"    {self.http_method} '{self.path}', "
                    f"to: '{self.controller_action}'"
                )
            else:
                route_line = (
                    f"  {self.http_method} '{self.path}', "
                    f"to: '{self.controller_action}'"
                )

            # Check for duplicate
            if f"{self.http_method} '{self.path}'" in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # Find insertion point
            lines = content.split('\n')
            insert_idx = -1

            if self.namespace:
                # Find namespace block
                for i, line in enumerate(lines):
                    if f"namespace :{self.namespace}" in line:
                        # Find next matching end
                        depth = 0
                        for j in range(i, len(lines)):
                            if 'end' in lines[j]:
                                insert_idx = j
                                break
                        break
            else:
                # Find last route definition or end of routes block
                for i in range(len(lines) - 1, -1, -1):
                    if lines[i].strip().startswith(('get ', 'post ', 'patch ', 'delete ', 'put ')):
                        insert_idx = i + 1
                        break
                    elif lines[i].strip() == 'end':
                        insert_idx = i
                        break

            if insert_idx != -1:
                lines.insert(insert_idx, route_line)
                path.write_text('\n'.join(lines) + '\n', encoding="utf-8")
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=1
                )

            return ModificationResult(
                success=False,
                error="Could not find route insertion point"
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based route injection failed: {str(e)}"
            )


class InjectCallCodemod(RubyCodemod):
    """
    Add a method call or middleware registration to Rails initialization code.
    
    Examples:
        app.use Rack::Cors
        config.middleware.use Rack::Cors
        app.include_router routes
    """

    def __init__(
        self,
        call_statement: str,
        target_file: str = "config/application.rb"
    ):
        """
        Args:
            call_statement: Full call statement to inject
            target_file: File to inject into (relative to Rails root)
        """
        self.call_statement = call_statement
        self.target_file = target_file

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based call injection."""
        try:
            content = path.read_text(encoding="utf-8")

            # Check for duplicate
            if self.call_statement in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # Insert before final 'end'
            lines = content.split('\n')
            insert_idx = -1

            for i in range(len(lines) - 1, -1, -1):
                if lines[i].strip() == 'end':
                    insert_idx = i
                    break

            if insert_idx != -1:
                lines.insert(insert_idx, f"    {self.call_statement}")
                path.write_text('\n'.join(lines) + '\n', encoding="utf-8")
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=1
                )

            return ModificationResult(
                success=False,
                error="Could not find insertion point"
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based call injection failed: {str(e)}"
            )


class InjectConstantCodemod(RubyCodemod):
    """
    Add a configuration constant to Rails config/application.rb or initializer.
    
    Examples:
        API_KEY = ENV['API_KEY']
        MAX_UPLOAD_SIZE = 100.megabytes
    """

    def __init__(
        self,
        name: str,
        value: str
    ):
        """
        Args:
            name: Constant name (e.g., 'API_KEY')
            value: Value expression (e.g., "ENV['API_KEY']")
        """
        self.name = name
        self.value = value

    def _apply_string_based(self, path: Path) -> ModificationResult:
        """Fallback string-based constant injection."""
        try:
            content = path.read_text(encoding="utf-8")
            const_stmt = f"{self.name} = {self.value}"

            # Check for duplicate
            if f"{self.name} =" in content:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

            # Insert after require statements
            lines = content.split('\n')
            insert_idx = 0

            for i, line in enumerate(lines):
                if line.strip().startswith(('require ', 'Rails.')) or 'class' in line:
                    insert_idx = i + 1

            lines.insert(insert_idx, const_stmt)
            path.write_text('\n'.join(lines) + '\n', encoding="utf-8")

            return ModificationResult(
                success=True,
                modified_path=path,
                changes_made=1
            )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"String-based constant injection failed: {str(e)}"
            )
