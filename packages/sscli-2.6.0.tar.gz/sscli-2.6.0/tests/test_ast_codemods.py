"""
Unit tests for AST-based codemods.

Tests cover:
- Python codemods using libcst
- JavaScript codemods using ast-grep
- Ruby codemods using Synvert/ast-grep
- Idempotency (no duplicates)
- Formatting preservation
- Fallback mechanisms
"""

import unittest
from pathlib import Path
import tempfile
import shutil


class TestPythonCodemods(unittest.TestCase):
    """Test Python code transformations using libcst."""

    def setUp(self):
        """Create temporary directory for test files."""
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.test_dir)

    def test_inject_import_basic(self):
        """Test basic import injection."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "test.py"
        test_file.write_text("def hello():\n    pass\n")

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        self.assertEqual(result.changes_made, 1)

        content = test_file.read_text()
        self.assertIn("Flask", content)

    def test_inject_import_idempotent(self):
        """Test that duplicate imports are not added."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "test.py"
        test_file.write_text("from flask import Flask\n\ndef hello():\n    pass\n")

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        # Should succeed but with 0 changes
        self.assertTrue(result.success)
        self.assertEqual(result.changes_made, 0)

    def test_inject_constant_basic(self):
        """Test basic constant injection."""
        from foundry.codemods import PythonInjectConstantCodemod

        test_file = self.test_dir / "test.py"
        test_file.write_text("import os\n\ndef main():\n    pass\n")

        codemod = PythonInjectConstantCodemod(
            "API_KEY",
            'os.environ.get("API_KEY")'
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        self.assertIn("API_KEY", content)

    def test_inject_constant_idempotent(self):
        """Test that duplicate constants are not added."""
        from foundry.codemods import PythonInjectConstantCodemod

        test_file = self.test_dir / "test.py"
        test_file.write_text('API_KEY = os.environ.get("API_KEY")\n')

        codemod = PythonInjectConstantCodemod(
            "API_KEY",
            'os.environ.get("API_KEY")'
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        # Count occurrences - should still be 1
        content = test_file.read_text()
        self.assertEqual(content.count("API_KEY"), 2)  # name + value

    def test_invalid_python_file(self):
        """Test handling of invalid Python syntax."""
        from foundry.codemods import PythonInjectImportCodemod

        test_file = self.test_dir / "test.py"
        test_file.write_text("def broken(\n    pass\n")  # Invalid syntax

        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(test_file)

        self.assertFalse(result.success)
        self.assertIn("Failed to parse", result.error)


class TestJavaScriptCodemods(unittest.TestCase):
    """Test JavaScript code transformations using ast-grep."""

    def setUp(self):
        """Create temporary directory for test files."""
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.test_dir)

    def test_inject_import_esm(self):
        """Test ESM import injection."""
        from foundry.codemods import JsInjectImportCodemod

        test_file = self.test_dir / "app.js"
        test_file.write_text("console.log('hello');\n")

        codemod = JsInjectImportCodemod(
            "react",
            ["useState"],
            import_type="esm"
        )
        result = codemod.apply(test_file)

        # Should succeed (fallback or ast-grep)
        self.assertTrue(result.success)
        content = test_file.read_text()
        # Check that fallback was used if ast-grep unavailable
        self.assertIn("react", content)

    def test_inject_route_basic(self):
        """Test route injection in React app."""
        from foundry.codemods import JsInjectRouteCodemod

        test_file = self.test_dir / "App.jsx"
        test_file.write_text("<Routes>\n</Routes>\n")

        codemod = JsInjectRouteCodemod(
            "/dashboard",
            "Dashboard",
            framework="react"
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        # Fallback should work
        self.assertIn("/dashboard", content)

    def test_inject_constant_basic(self):
        """Test constant injection in JavaScript."""
        from foundry.codemods import JsInjectConstantCodemod

        test_file = self.test_dir / "config.js"
        test_file.write_text("const PORT = 3000;\n")

        codemod = JsInjectConstantCodemod(
            "API_URL",
            'process.env.API_URL'
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        self.assertIn("API_URL", content)


class TestRubyCodemods(unittest.TestCase):
    """Test Ruby code transformations for Rails."""

    def setUp(self):
        """Create temporary directory for test files."""
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        """Clean up temporary directory."""
        shutil.rmtree(self.test_dir)

    def test_inject_route_basic(self):
        """Test route injection in Rails routes.rb."""
        from foundry.codemods import RubyInjectRouteCodemod

        test_file = self.test_dir / "routes.rb"
        test_file.write_text("Rails.application.routes.draw do\nend\n")

        codemod = RubyInjectRouteCodemod(
            "post",
            "webhooks/shopify",
            "webhooks/shopify#handle"
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)

    def test_inject_route_namespaced(self):
        """Test namespaced route injection."""
        from foundry.codemods import RubyInjectRouteCodemod

        test_file = self.test_dir / "routes.rb"
        test_file.write_text(
            "Rails.application.routes.draw do\n"
            "  namespace :api do\n"
            "  end\n"
            "end\n"
        )

        codemod = RubyInjectRouteCodemod(
            "get",
            "users",
            "users#index",
            namespace="api"
        )
        result = codemod.apply(test_file)

        # Should succeed (string fallback if others fail)
        self.assertTrue(result.success)

    def test_inject_constant_basic(self):
        """Test constant injection in Rails."""
        from foundry.codemods import RubyInjectConstantCodemod

        test_file = self.test_dir / "config.rb"
        test_file.write_text("require 'rails'\n")

        codemod = RubyInjectConstantCodemod(
            "MAX_FILE_SIZE",
            "100.megabytes"
        )
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()
        self.assertIn("MAX_FILE_SIZE", content)


class TestCodemodIntegration(unittest.TestCase):
    """Integration tests for feature injection pipeline."""

    def setUp(self):
        """Create mock project structure."""
        self.project_dir = Path(tempfile.mkdtemp())
        self.src_dir = self.project_dir / "src"
        self.src_dir.mkdir()

    def tearDown(self):
        """Clean up."""
        shutil.rmtree(self.project_dir)

    def test_python_saas_injection(self):
        """Test injecting codemods for Python SaaS project."""
        from foundry.actions.features import inject_features_ast

        # Create minimal project
        (self.src_dir / "app.py").write_text("def main():\n    pass\n")
        (self.src_dir.parent / "pyproject.toml").write_text(
            "[project]\nname = \"test\"\ndependencies = []\n"
        )

        result = inject_features_ast(
            self.project_dir,
            "python-saas",
            {
                "imports": [
                    {"module": "flask", "names": ["Flask"]}
                ],
                "dependencies": ["flask"]
            }
        )

        # Should have attempted injection
        self.assertIsInstance(result, dict)
        self.assertIn('success', result)
        self.assertIn('changes', result)

    def test_react_injection(self):
        """Test injecting codemods for React project."""
        from foundry.actions.features import inject_features_ast

        # Create minimal project
        (self.project_dir / "src").mkdir()
        (self.project_dir / "src" / "App.jsx").write_text(
            "export default function App() {}\n"
        )

        result = inject_features_ast(
            self.project_dir,
            "react-client",
            {
                "imports": [
                    {"module": "react", "names": ["useState"]}
                ],
                "routes": [
                    {"path": "/dashboard", "component": "Dashboard"}
                ]
            }
        )

        self.assertIsInstance(result, dict)
        self.assertIn('success', result)


class TestCodemodValidation(unittest.TestCase):
    """Test validation and error handling."""

    def setUp(self):
        """Create temporary directory."""
        self.test_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        """Clean up."""
        shutil.rmtree(self.test_dir)

    def test_missing_file_handling(self):
        """Test handling of missing files."""
        from foundry.codemods import PythonInjectImportCodemod

        nonexistent = self.test_dir / "nonexistent.py"
        codemod = PythonInjectImportCodemod("flask", ["Flask"])
        result = codemod.apply(nonexistent)

        self.assertFalse(result.success)
        self.assertIn("not found", result.error)

    def test_formatting_preservation(self):
        """Test that formatting is preserved after transformation."""
        from foundry.codemods import PythonInjectConstantCodemod

        test_file = self.test_dir / "test.py"
        original = """# Configuration file
import os


def main():
    \"\"\"Main function.\"\"\"
    pass
"""
        test_file.write_text(original)

        codemod = PythonInjectConstantCodemod("DEBUG", "True")
        result = codemod.apply(test_file)

        self.assertTrue(result.success)
        content = test_file.read_text()

        # Verify formatting is preserved
        self.assertIn("# Configuration file", content)
        self.assertIn('"""Main function."""', content)


if __name__ == "__main__":
    unittest.main()
