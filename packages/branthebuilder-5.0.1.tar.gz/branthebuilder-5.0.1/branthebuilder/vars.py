import importlib
import re
import sys
import tomllib
from enum import Enum
from functools import cached_property
from pathlib import Path
from warnings import warn

README_PATH = Path("README.md")
CFF_PATH = Path("CITATION.cff")
DOC_DIR = Path("docs")

ORCID_DIC_ENV = "ORCID_MAP"

cc_repo = "https://github.com/endremborza/python-boilerplate-v2"

_D = {"project": {"name": ".", "author": []}}


class Bump(Enum):
    major = "major"
    minor = "minor"
    bug = "bug"


class PackageConf:
    @cached_property
    def pytom(self):
        try:
            with open("pyproject.toml", "rb") as f:
                return tomllib.load(f)
        except FileNotFoundError:
            warn(f"not in project directory, using defaults {_D}")
            return _D

    @property
    def project_conf(self):
        return self.pytom["project"]

    @property
    def name(self):
        return self.project_conf["name"]

    @property
    def module_path(self):
        if Path(self.name).exists():
            return self.name
        return f"{self.name}.py"

    @property
    def module(self):
        cwd = str(Path.cwd())
        if cwd not in sys.path:
            sys.path.insert(0, cwd)
        for site_packages in Path(".venv").glob("lib/python*/site-packages"):
            s = str(site_packages)
            if s not in sys.path:
                sys.path.insert(0, s)
        module = importlib.import_module(self.name)
        return importlib.reload(module)

    @property
    def version(self):
        return re.findall('__version__ = "(.*)"', self.version_file.read_text())[0]

    @property
    def version_file(self):
        if Path(self.name).exists():
            return Path(self.name, "__init__.py")
        else:
            return Path(f"{self.name}.py")

    def get_bumped_version(self, bump: Bump):
        old_v = self.version
        major, minor, bug = map(int, old_v.split("."))
        match bump:
            case Bump.major:
                major += 1
                minor = 0
                bug = 0
            case Bump.minor:
                minor += 1
                bug = 0
            case Bump.bug:
                bug += 1
            case _:
                raise ValueError(f"wrong kind of bump {bump}")
        new_v = ".".join(map(str, (major, minor, bug)))
        self.version_file.write_text(
            self.version_file.read_text().replace(
                f'__version__ = "{old_v}"', f'__version__ = "{new_v}"'
            )
        )
        return new_v


conf = PackageConf()
