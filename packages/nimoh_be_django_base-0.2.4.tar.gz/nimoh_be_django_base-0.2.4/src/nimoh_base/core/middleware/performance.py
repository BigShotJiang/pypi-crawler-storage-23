"""
Performance Monitoring Middleware
==================================

Consolidated performance monitoring middleware that tracks request/response
metrics for all API endpoints. Combines logging, Sentry integration, and
optional database persistence via the monitoring app.

Replaces the separate implementations formerly in:
- nimoh_base.core.middleware.performance (logging + Sentry)
- nimoh_base.monitoring.middleware.performance (DB + cache)
"""

import logging
import time
from decimal import Decimal

from django.conf import settings
from django.core.cache import cache
from django.db import connection
from django.db.utils import DatabaseError
from django.utils.deprecation import MiddlewareMixin

from nimoh_base.conf import nimoh_setting
from nimoh_base.core.utils import get_client_ip

# Import sentry_sdk at module level to avoid import overhead on each request
try:
    import sentry_sdk

    SENTRY_AVAILABLE = True
except ImportError:
    SENTRY_AVAILABLE = False

# Use the app registry to check if monitoring is installed, then attempt import.
# This avoids silently swallowing real import errors in monitoring/models.py.
from django.apps import apps as _django_apps

try:
    if _django_apps.is_installed("nimoh_base.monitoring"):
        from nimoh_base.monitoring.models import MetricType, PerformanceMetric

        MONITORING_MODELS_AVAILABLE = True
    else:
        MONITORING_MODELS_AVAILABLE = False
except Exception:
    MONITORING_MODELS_AVAILABLE = False

logger = logging.getLogger("performance")


class PerformanceMonitoringMiddleware(MiddlewareMixin):
    """
    Unified middleware to track request performance metrics.

    Features:
    - Logs request duration with structured data
    - Identifies slow requests (configurable thresholds)
    - Tracks database query count per request
    - Sends metrics to Sentry as breadcrumbs (if configured)
    - Persists metrics to DB via monitoring app (if available)
    - Updates real-time cache metrics for dashboards
    """

    SLOW_REQUEST_WARNING_MS = 200
    SLOW_REQUEST_ERROR_MS = 500

    def process_request(self, request):
        """Store request start time and query baseline."""
        request._start_time = time.time()
        request._queries_before = len(self._get_queries())
        return None

    def process_response(self, request, response):
        """Calculate and log request metrics."""
        if not hasattr(request, "_start_time"):
            return response

        # Skip monitoring for static/media files and health checks
        path = request.path
        if path.startswith("/static/") or path.startswith("/media/"):
            return response
        if path in ("/health/", "/healthz/", "/ready/", "/api/v1/health/"):
            return response

        # Calculate duration
        duration_ms = (time.time() - request._start_time) * 1000

        # Get query count
        queries_after = len(self._get_queries())
        query_count = queries_after - getattr(request, "_queries_before", 0)

        # Prepare log data
        log_data = {
            "method": request.method,
            "path": path,
            "status_code": response.status_code,
            "duration_ms": round(duration_ms, 2),
            "query_count": query_count,
            "user": getattr(request.user, "username", "Anonymous") if hasattr(request, "user") else "Anonymous",
            "remote_addr": get_client_ip(request),
        }

        # Add debug headers
        if settings.DEBUG:
            response["X-Request-Duration-Ms"] = str(round(duration_ms, 2))
            response["X-Query-Count"] = str(query_count)

        # Log based on performance
        if duration_ms > self.SLOW_REQUEST_ERROR_MS:
            logger.error(
                f"SLOW REQUEST: {request.method} {path} took {duration_ms:.2f}ms with {query_count} queries",
                extra=log_data,
            )
        elif duration_ms > self.SLOW_REQUEST_WARNING_MS:
            logger.warning(
                f"Slow request: {request.method} {path} took {duration_ms:.2f}ms with {query_count} queries",
                extra=log_data,
            )
        else:
            logger.info(f"{request.method} {path} - {duration_ms:.2f}ms ({query_count} queries)", extra=log_data)

        # Send to Sentry as breadcrumb
        self._add_sentry_breadcrumb(request, duration_ms, query_count)

        # Persist to monitoring DB (if available and enabled)
        if nimoh_setting("ENABLE_MONITORING_PERSISTENCE", False):
            self._persist_metrics(request, response, duration_ms, query_count)

        # Update real-time cache metrics
        self._update_realtime_metrics(path, request.method, duration_ms, response.status_code)

        return response

    def _get_queries(self):
        """Get current database queries."""
        try:
            return connection.queries
        except AttributeError:
            return []

    def _add_sentry_breadcrumb(self, request, duration_ms, query_count):
        """Add performance data to Sentry breadcrumb."""
        if not SENTRY_AVAILABLE:
            return
        try:
            sentry_sdk.add_breadcrumb(
                category="performance",
                message=f"{request.method} {request.path}",
                level="info" if duration_ms < self.SLOW_REQUEST_WARNING_MS else "warning",
                data={
                    "duration_ms": duration_ms,
                    "query_count": query_count,
                    "status_code": getattr(request, "status_code", None),
                },
            )
        except (TypeError, ValueError) as e:
            logger.debug(f"Failed to add Sentry breadcrumb: {e}")

    def _persist_metrics(self, request, response, duration_ms, query_count):
        """Persist metrics to DB via monitoring app when available."""
        if not MONITORING_MODELS_AVAILABLE:
            return
        try:
            user_id = getattr(request.user, "id", None) if hasattr(request, "user") else None
            context = {
                "endpoint_path": request.path,
                "method": request.method,
                "status_code": response.status_code,
                "query_count": query_count,
                "user_id": str(user_id) if user_id else None,
                "user_agent": request.META.get("HTTP_USER_AGENT", ""),
                "remote_addr": get_client_ip(request),
            }
            PerformanceMetric.objects.create(
                metric_type=MetricType.REQUEST_RESPONSE,
                name=f"{request.method} {request.path}",
                value=Decimal(str(round(duration_ms, 2))),
                unit="ms",
                context=context,
            )
        except DatabaseError as e:
            logger.error(f"Error persisting performance metrics: {e}")

    def _update_realtime_metrics(self, path, method, response_time_ms, status_code):
        """Update real-time metrics in cache for monitoring dashboards."""
        try:
            cache_key_prefix = f"metrics:realtime:{method}:{path}"
            cache_timeout = 3600

            cache.get_or_set(f"{cache_key_prefix}:count", 0, cache_timeout)
            cache.incr(f"{cache_key_prefix}:count")

            if status_code >= 400:
                cache.get_or_set(f"{cache_key_prefix}:errors", 0, cache_timeout)
                cache.incr(f"{cache_key_prefix}:errors")

            current_avg = cache.get(f"{cache_key_prefix}:avg_time", 0)
            current_count = cache.get(f"{cache_key_prefix}:count", 1)
            new_avg = ((current_avg * (current_count - 1)) + response_time_ms) / current_count
            cache.set(f"{cache_key_prefix}:avg_time", new_avg, cache_timeout)
        except (ConnectionError, OSError, ValueError) as e:
            logger.error(f"Error updating real-time metrics: {e}")


class QueryCountWarningMiddleware(MiddlewareMixin):
    """
    Middleware to detect N+1 query problems.
    Raises warning if query count exceeds threshold.
    """

    MAX_QUERIES_WARNING = 20
    MAX_QUERIES_ERROR = 50

    def process_request(self, request):
        """Reset query tracking."""
        request._queries_start = len(self._get_queries())
        return None

    def process_response(self, request, response):
        """Check query count and warn if excessive."""
        if not hasattr(request, "_queries_start"):
            return response

        queries_end = len(self._get_queries())
        query_count = queries_end - request._queries_start

        if query_count > self.MAX_QUERIES_ERROR:
            logger.error(
                f"EXCESSIVE QUERIES: {request.method} {request.path} "
                f"executed {query_count} database queries! Possible N+1 problem.",
                extra={
                    "method": request.method,
                    "path": request.path,
                    "query_count": query_count,
                    "status_code": response.status_code,
                },
            )
        elif query_count > self.MAX_QUERIES_WARNING:
            logger.warning(
                f"High query count: {request.method} {request.path} "
                f"executed {query_count} queries. Consider optimization.",
                extra={
                    "method": request.method,
                    "path": request.path,
                    "query_count": query_count,
                },
            )

        return response

    def _get_queries(self):
        """Get current database queries."""
        try:
            return connection.queries
        except AttributeError:
            return []
