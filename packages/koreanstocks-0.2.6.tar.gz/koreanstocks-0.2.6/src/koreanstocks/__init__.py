VERSION = "0.2.6"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
