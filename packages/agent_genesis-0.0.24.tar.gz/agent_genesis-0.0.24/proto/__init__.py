"""Generated protobuf modules for sandbox bridge transport."""

