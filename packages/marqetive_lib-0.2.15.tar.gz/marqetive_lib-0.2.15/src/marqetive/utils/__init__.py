"""Utility functions for MarqetiveLib."""

from marqetive.utils.crdt import (
    SUPPORTED_PLATFORMS as CRDT_SUPPORTED_PLATFORMS,
)
from marqetive.utils.crdt import (
    AutoNumberConfig,
    BaseCRDTParser,
    ContentType,
    CRDTEmptyDocumentError,
    CRDTError,
    CRDTParseError,
    CRDTParserFactory,
    CRDTSchemaError,
    CRDTUnsupportedPlatformError,
    CRDTValidationError,
    InstagramCRDTParser,
    InstagramPostContent,
    LinkedInCommentContent,
    LinkedInCRDTParser,
    LinkedInPostContent,
    ParsedDocument,
    ParsedInstagramDocument,
    ParsedLinkedInDocument,
    ParsedTikTokDocument,
    ParsedTwitterDocument,
    Platform,
    PostVisibility,
    TikTokCRDTParser,
    TikTokPostContent,
    TwitterCardContent,
    TwitterCRDTParser,
    detect_platform,
    parse_crdt_binary,
    parse_crdt_document,
    parse_instagram_document,
    parse_linkedin_document,
    parse_tiktok_document,
    parse_twitter_document,
    validate_crdt_document,
)
from marqetive.utils.file_handlers import (
    TempFileManager,
    download_file,
    download_to_memory,
    get_file_info,
    read_file_bytes,
    stream_file_upload,
    write_file_bytes,
)
from marqetive.utils.helpers import format_response, parse_query_params
from marqetive.utils.media import (
    MediaValidator,
    chunk_file,
    detect_mime_type,
    format_file_size,
    get_chunk_count,
    get_file_hash,
    validate_file_size,
    validate_media_type,
)

__all__ = [
    # helpers
    "format_response",
    "parse_query_params",
    # media
    "MediaValidator",
    "chunk_file",
    "detect_mime_type",
    "format_file_size",
    "get_chunk_count",
    "get_file_hash",
    "validate_file_size",
    "validate_media_type",
    # file_handlers
    "TempFileManager",
    "download_file",
    "download_to_memory",
    "get_file_info",
    "read_file_bytes",
    "stream_file_upload",
    "write_file_bytes",
    # CRDT exceptions
    "CRDTError",
    "CRDTParseError",
    "CRDTValidationError",
    "CRDTSchemaError",
    "CRDTUnsupportedPlatformError",
    "CRDTEmptyDocumentError",
    # CRDT enums
    "Platform",
    "ContentType",
    "PostVisibility",
    # CRDT models
    "AutoNumberConfig",
    # CRDT platform content models
    "TwitterCardContent",
    "LinkedInPostContent",
    "LinkedInCommentContent",
    "InstagramPostContent",
    "TikTokPostContent",
    # CRDT document result models
    "ParsedTwitterDocument",
    "ParsedLinkedInDocument",
    "ParsedInstagramDocument",
    "ParsedTikTokDocument",
    "ParsedDocument",
    # CRDT factory
    "CRDTParserFactory",
    "CRDT_SUPPORTED_PLATFORMS",
    # CRDT main API functions
    "parse_crdt_document",
    "parse_crdt_binary",
    "validate_crdt_document",
    "detect_platform",
    # CRDT platform-specific functions
    "parse_twitter_document",
    "parse_linkedin_document",
    "parse_instagram_document",
    "parse_tiktok_document",
    # CRDT parsers
    "BaseCRDTParser",
    "TwitterCRDTParser",
    "LinkedInCRDTParser",
    "InstagramCRDTParser",
    "TikTokCRDTParser",
]
