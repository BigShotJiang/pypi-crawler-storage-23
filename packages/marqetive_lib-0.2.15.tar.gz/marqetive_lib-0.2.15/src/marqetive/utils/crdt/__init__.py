"""CRDT Document Parser for Social Media Platforms.

This module provides utilities for parsing Y.js CRDT documents containing
ProseMirror schema structures for Twitter, LinkedIn, Instagram, and TikTok.

Main API:
    - parse_crdt_document: Parse a CRDT document for a specific platform
    - parse_crdt_binary: Parse from binary Y.js update data
    - validate_crdt_document: Validate document against platform rules
    - detect_platform: Auto-detect platform from document structure

Platform-specific functions (with better type inference):
    - parse_twitter_document: Parse Twitter document
    - parse_linkedin_document: Parse LinkedIn document
    - parse_instagram_document: Parse Instagram document
    - parse_tiktok_document: Parse TikTok document

Factory:
    - CRDTParserFactory: Create platform-specific parsers

Models:
    - ParsedTwitterDocument, ParsedLinkedInDocument, etc.
    - TwitterCardContent, LinkedInPostContent, etc.
    - AutoNumberConfig

Exceptions:
    - CRDTError, CRDTParseError, CRDTValidationError, etc.

Example:
    >>> from marqetive.utils.crdt import parse_crdt_binary
    >>>
    >>> # Parse Twitter thread from binary data
    >>> with open("thread.yjs", "rb") as f:
    ...     result = parse_crdt_binary("twitter", f.read())
    >>>
    >>> for card in result.cards:
    ...     print(f"Tweet: {card.text[:50]}...")
    ...     print(f"  Media: {len(card.media)} items")
"""

# Exceptions
from marqetive.utils.crdt.exceptions import (
    CRDTEmptyDocumentError,
    CRDTError,
    CRDTParseError,
    CRDTSchemaError,
    CRDTUnsupportedPlatformError,
    CRDTValidationError,
)

# Models - Enums
# Models - Platform content
# Models - Document results
from marqetive.utils.crdt.models import (
    AutoNumberConfig,
    ContentType,
    InstagramPostContent,
    LinkedInCommentContent,
    LinkedInPostContent,
    ParsedDocument,
    ParsedInstagramDocument,
    ParsedLinkedInDocument,
    ParsedTikTokDocument,
    ParsedTwitterDocument,
    Platform,
    PostVisibility,
    TikTokPostContent,
    TwitterCardContent,
)

# Factory
# Main API functions
# Platform-specific functions
from marqetive.utils.crdt.parser import (
    SUPPORTED_PLATFORMS,
    CRDTParserFactory,
    detect_platform,
    parse_crdt_binary,
    parse_crdt_document,
    parse_instagram_document,
    parse_linkedin_document,
    parse_tiktok_document,
    parse_twitter_document,
    validate_crdt_document,
)

# Platform parsers
from marqetive.utils.crdt.platforms import (
    InstagramCRDTParser,
    LinkedInCRDTParser,
    TikTokCRDTParser,
    TwitterCRDTParser,
)

# Base parser (for custom implementations)
from marqetive.utils.crdt.platforms.base import BaseCRDTParser

__all__ = [
    # Exceptions
    "CRDTError",
    "CRDTParseError",
    "CRDTValidationError",
    "CRDTSchemaError",
    "CRDTUnsupportedPlatformError",
    "CRDTEmptyDocumentError",
    # Enums
    "Platform",
    "ContentType",
    "PostVisibility",
    # Models
    "AutoNumberConfig",
    # Platform content models
    "TwitterCardContent",
    "LinkedInPostContent",
    "LinkedInCommentContent",
    "InstagramPostContent",
    "TikTokPostContent",
    # Document result models
    "ParsedTwitterDocument",
    "ParsedLinkedInDocument",
    "ParsedInstagramDocument",
    "ParsedTikTokDocument",
    "ParsedDocument",
    # Factory
    "CRDTParserFactory",
    "SUPPORTED_PLATFORMS",
    # Main API functions
    "parse_crdt_document",
    "parse_crdt_binary",
    "validate_crdt_document",
    "detect_platform",
    # Platform-specific functions
    "parse_twitter_document",
    "parse_linkedin_document",
    "parse_instagram_document",
    "parse_tiktok_document",
    # Base and platform parsers
    "BaseCRDTParser",
    "TwitterCRDTParser",
    "LinkedInCRDTParser",
    "InstagramCRDTParser",
    "TikTokCRDTParser",
]
