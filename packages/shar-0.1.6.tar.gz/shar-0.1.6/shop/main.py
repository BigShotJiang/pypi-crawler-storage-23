# Онлайн-магазин — PyQt6 + pymysql
import os, sys
import pymysql
from pymysql.cursors import DictCursor

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QPushButton, QMessageBox,
    QLabel, QComboBox, QFrame, QAbstractItemView, QDialog, QFormLayout, QLineEdit,
    QDoubleSpinBox, QDialogButtonBox)

DB = {"host": "localhost", "user": "root", "password": "0210", "database": "shop", "charset": "utf8mb4"}
SZ, IMG = 80, os.path.join(os.path.dirname(os.path.abspath(__file__)), "image1.png")


def q(sql, params=None, fetch=True):
    c = pymysql.connect(**DB, cursorclass=DictCursor)
    try:
        cur = c.cursor()
        cur.execute(sql, params or ())
        return cur.fetchall() if fetch else (c.commit() or None)
    finally: cur.close(); c.close()


def ph():
    p = QPixmap(SZ, SZ); p.fill(QColor(230, 230, 235))
    pa = QPainter(p); pa.setPen(QColor(120, 120, 120)); pa.setFont(QFont("Arial", 24))
    pa.drawText(p.rect(), Qt.AlignmentFlag.AlignCenter, "?"); pa.end()
    return p


def pix(path):
    p = path or IMG
    if not os.path.isabs(p): p = os.path.join(os.path.dirname(os.path.abspath(__file__)), p)
    if not os.path.isfile(p): return ph()
    px = QPixmap(p)
    return px.scaled(SZ, SZ, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation) if not px.isNull() else ph()


def fill(tbl, rows):
    tbl.setRowCount(len(rows))
    for i, r in enumerate(rows):
        l = QLabel(); l.setPixmap(pix(r.get("image_path"))); l.setAlignment(Qt.AlignmentFlag.AlignCenter); l.setFixedSize(SZ + 4, SZ + 4)
        tbl.setCellWidget(i, 0, l)
        it = QTableWidgetItem(str(r.get("name", ""))); it.setData(Qt.ItemDataRole.UserRole, r.get("id"))
        tbl.setItem(i, 1, it); tbl.setItem(i, 2, QTableWidgetItem(str(r.get("price", "")))); tbl.setItem(i, 3, QTableWidgetItem(str(r.get("category", ""))))
        for j in range(1, 4): tbl.item(i, j).setFlags(tbl.item(i, j).flags() & ~Qt.ItemFlag.ItemIsEditable)


class ProductsView(QWidget):
    def __init__(self, deleted=False, parent=None):
        super().__init__(parent)
        self.deleted, self.sort_asc = deleted, True
        self.ftr = q("SELECT label, field FROM ui_footer ORDER BY sort_order")
        self.sort_col = self.ftr[0]["field"] if self.ftr else "name"
        lay = QVBoxLayout(self)
        self.tbl = QTableWidget(); self.tbl.setColumnCount(4)
        self.tbl.setHorizontalHeaderLabels([r["label"] for r in q("SELECT label FROM ui_header ORDER BY col_order")])
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents); self.tbl.setColumnWidth(0, SZ + 10)
        self.tbl.horizontalHeader().sectionClicked.connect(self._hdr); self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        lay.addWidget(self.tbl)
        f = QFrame(); fl = QHBoxLayout(f); fl.addWidget(QLabel("Сортировка:"))
        self.combo = QComboBox(); self.combo.addItems([r["label"] for r in self.ftr]); self.combo.currentIndexChanged.connect(self._combo)
        fl.addWidget(self.combo)
        self.dir_btn = QPushButton("▲ По возрастанию"); self.dir_btn.setCheckable(True); self.dir_btn.toggled.connect(lambda c: self._dir(not c))
        fl.addWidget(self.dir_btn); fl.addStretch(); lay.addWidget(f)
        self._load()

    def _hdr(self, idx):
        hr = q("SELECT field FROM ui_header ORDER BY col_order")
        if idx < len(hr) and hr[idx]["field"] != "image":
            self.sort_col, self.sort_asc = hr[idx]["field"], not self.sort_asc
            self._load(); self._sync()

    def _combo(self, idx):
        if idx < len(self.ftr): self.sort_col = self.ftr[idx]["field"]
        self._load(); self._sync()

    def _dir(self, asc):
        self.sort_asc = asc; self.dir_btn.setText("▲ По возрастанию" if asc else "▼ По убыванию"); self._load()

    def _sync(self):
        fs = [r["field"] for r in self.ftr]
        if self.sort_col in fs: self.combo.blockSignals(True); self.combo.setCurrentIndex(fs.index(self.sort_col)); self.combo.blockSignals(False)
        self.dir_btn.setChecked(not self.sort_asc)

    def _load(self):
        try:
            v = "v_products_deleted" if self.deleted else "v_products"
            fill(self.tbl, q(f"SELECT * FROM {v} ORDER BY {self.sort_col} {'ASC' if self.sort_asc else 'DESC'}"))
        except pymysql.Error as e: QMessageBox.critical(self, "Ошибка БД", str(e))


class DeletedView(QWidget):
    def __init__(self, on_restore=None, parent=None):
        super().__init__(parent)
        self.on_restore = on_restore
        lay = QVBoxLayout(self); lay.addWidget(QLabel("Корзина удалённых"))
        self.tbl = QTableWidget(); self.tbl.setColumnCount(4)
        self.tbl.setHorizontalHeaderLabels([r["label"] for r in q("SELECT label FROM ui_header ORDER BY col_order")])
        self.tbl.setColumnWidth(0, SZ + 10); self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        lay.addWidget(self.tbl)
        bl = QHBoxLayout()
        for txt, cb in [("Восстановить", self._restore), ("Обновить", self._load)]:
            b = QPushButton(txt); b.clicked.connect(cb); bl.addWidget(b)
        lay.addLayout(bl)
        self._load()

    def _load(self):
        try: fill(self.tbl, q("SELECT id,name,price,category,image_path FROM v_products_deleted ORDER BY deleted_at DESC"))
        except pymysql.Error as e: QMessageBox.critical(self, "Ошибка БД", str(e))

    def _restore(self):
        r = self.tbl.currentRow()
        if r < 0: QMessageBox.warning(self, "Внимание", "Выберите товар"); return
        pid = self.tbl.item(r, 1).data(Qt.ItemDataRole.UserRole)
        if pid:
            try:
                q("UPDATE products SET is_deleted=0, deleted_at=NULL WHERE id=%s", (pid,), fetch=False)
                self._load(); self.on_restore and self.on_restore()
                QMessageBox.information(self, "Готово", "Товар восстановлен")
            except pymysql.Error as e: QMessageBox.critical(self, "Ошибка", str(e))


class AddDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить товар")
        lay = QFormLayout(self)
        self.name_edit = QLineEdit(); lay.addRow("Название:", self.name_edit)
        self.price_edit = QDoubleSpinBox(); self.price_edit.setRange(0, 1e9); self.price_edit.setValue(1000); lay.addRow("Цена:", self.price_edit)
        self.cat = QComboBox(); self.cat.setEditable(True)
        for r in q("SELECT DISTINCT category FROM products WHERE is_deleted=0"): self.cat.addItem(r["category"])
        self.cat.count() == 0 and self.cat.addItems(["Электроника", "Книги", "Одежда"])
        lay.addRow("Категория:", self.cat)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addRow(bb)

    def vals(self):
        return (self.name_edit.text().strip(), self.price_edit.value(), self.cat.currentText().strip() or "Прочее", "image1.png")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Онлайн-магазин"); self.setMinimumSize(900, 600); self.resize(1000, 700)
        self.pv = ProductsView(); self.dv = DeletedView(self.pv._load)
        t = QTabWidget(); t.addTab(self.pv, "Товары"); t.addTab(self.dv, "Корзина удалённых")
        bl = QHBoxLayout()
        for txt, cb in [("Удалить в корзину", self._del), ("Добавить", self._add), ("Обновить", self._refresh)]:
            b = QPushButton(txt); b.clicked.connect(cb); bl.addWidget(b)
        c = QWidget(); lay = QVBoxLayout(c); lay.addLayout(bl); lay.addWidget(t); self.setCentralWidget(c)

    def _refresh(self): self.pv._load(); self.dv._load()

    def _del(self):
        r = self.pv.tbl.currentRow()
        if r < 0: QMessageBox.warning(self, "Внимание", "Выберите товар"); return
        pid = self.pv.tbl.item(r, 1).data(Qt.ItemDataRole.UserRole)
        if pid:
            try:
                q("UPDATE products SET is_deleted=1, deleted_at=NOW() WHERE id=%s", (pid,), fetch=False)
                self.pv._load(); self.dv._load(); QMessageBox.information(self, "Готово", "В корзину")
            except pymysql.Error as e: QMessageBox.critical(self, "Ошибка", str(e))

    def _add(self):
        d = AddDialog(self)
        if d.exec():
            try:
                q("INSERT INTO products (name,price,category,image_path) VALUES (%s,%s,%s,%s)", d.vals(), fetch=False)
                self.pv._load(); QMessageBox.information(self, "Готово", "Добавлено")
            except pymysql.Error as e: QMessageBox.critical(self, "Ошибка", str(e))


def run():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    try:
        run()
    except Exception as e:
        QMessageBox.critical(None, "Ошибка запуска", str(e))
        sys.exit(1)
