-- бд «онлайн-магазин» (mysql)
set names utf8mb4;
create database if not exists shop character set utf8mb4;
use shop;
set foreign_key_checks = 0;

-- таблица товаров (с мягким удалением для корзины удалённых)
drop table if exists products;

create table products (
  id int auto_increment primary key,
  name varchar(100) not null,
  price decimal(12, 2) not null,
  category varchar(50) not null,
  image_path varchar(255) default null,
  is_deleted tinyint(1) default 0,
  deleted_at datetime default null,
  created_at timestamp default current_timestamp
);

-- индексы для сортировки и запросов
create index idx_products_deleted on products(is_deleted);
create index idx_products_category on products(category);
create index idx_products_price on products(price);
create index idx_products_name on products(name);

-- вью для вывода товаров (активные)
create or replace view v_products as
select id, name, price, category, image_path
from products where is_deleted = 0;

-- вью для вывода удалённых товаров
create or replace view v_products_deleted as
select id, name, price, category, image_path, deleted_at
from products where is_deleted = 1;

-- заголовки таблицы (ХП)
drop table if exists ui_header;
create table ui_header (
  id int auto_increment primary key,
  col_order int not null,
  label varchar(50) not null,
  field varchar(50) not null
);
insert into ui_header (col_order, label, field) values
(0, 'Изображение', 'image'),
(1, 'Название', 'name'),
(2, 'Цена', 'price'),
(3, 'Категория', 'category');

-- опции сортировки для футера (ХФ)
drop table if exists ui_footer;
create table ui_footer (
  id int auto_increment primary key,
  sort_order int not null,
  label varchar(50) not null,
  field varchar(50) not null
);
insert into ui_footer (sort_order, label, field) values
(0, 'По названию', 'name'),
(1, 'По цене', 'price'),
(2, 'По категории', 'category');

set foreign_key_checks = 1;

-- тестовые данные
insert into products (name, price, category, image_path) values
('смартфон x1', 29990.00, 'электроника', null),
('наушники pro', 4990.00, 'электроника', null),
('клавиатура механическая', 7990.00, 'электроника', null),
('книга python', 1490.00, 'книги', null),
('книга mysql', 1890.00, 'книги', null),
('футболка', 990.00, 'одежда', null),
('джинсы', 2990.00, 'одежда', null),
('ноутбук', 59990.00, 'электроника', null),
('мышь беспроводная', 1990.00, 'электроника', null);
