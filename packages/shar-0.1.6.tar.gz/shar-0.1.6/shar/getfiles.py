"""Скопировать папку shar (app.py, database.sql, database.txt) и shop в текущую папку."""
import shutil
import os


def main():
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    dest = os.getcwd()
    shar_dest = os.path.join(dest, "shar")
    os.makedirs(shar_dest, exist_ok=True)
    for name in ("app.py", "database.sql", "database.txt"):
        src = os.path.join(pkg_dir, name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(shar_dest, name))
            print(f"Скопировано: shar/{name}")
    for folder in ("shop", "petshop"):
        src = os.path.join(os.path.dirname(pkg_dir), folder)
        dst = os.path.join(dest, folder)
        if os.path.isdir(src):
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
            print(f"Скопировано: {folder}/")
