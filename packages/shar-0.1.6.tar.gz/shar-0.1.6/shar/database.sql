CREATE DATABASE IF NOT EXISTS users_db;
USE users_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS cart (
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    PRIMARY KEY (user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE OR REPLACE VIEW v_cart_detail AS
SELECT c.user_id, c.product_id, p.name, p.price, c.quantity
FROM cart c
JOIN products p ON p.id = c.product_id;

DELIMITER //
DROP PROCEDURE IF EXISTS sp_add_to_cart //
DROP PROCEDURE IF EXISTS sp_remove_from_cart //
DROP PROCEDURE IF EXISTS sp_search_products //
DROP PROCEDURE IF EXISTS sp_products_sorted //
DROP FUNCTION IF EXISTS fn_cart_total //
CREATE PROCEDURE sp_add_to_cart(IN p_user_id INT, IN p_product_id INT)
BEGIN
    INSERT INTO cart (user_id, product_id, quantity)
    VALUES (p_user_id, p_product_id, 1)
    ON DUPLICATE KEY UPDATE quantity = quantity + 1;
END //

CREATE PROCEDURE sp_remove_from_cart(IN p_user_id INT, IN p_product_id INT)
BEGIN
    DELETE FROM cart WHERE user_id = p_user_id AND product_id = p_product_id;
END //

CREATE PROCEDURE sp_search_products(IN p_search VARCHAR(100))
BEGIN
    SELECT id, name, price FROM products
    WHERE name LIKE CONCAT('%', p_search, '%');
END //

CREATE PROCEDURE sp_products_sorted(IN p_order VARCHAR(10))
BEGIN
    IF p_order = 'price' THEN
        SELECT id, name, price FROM products ORDER BY price;
    ELSE
        SELECT id, name, price FROM products ORDER BY name;
    END IF;
END //

CREATE FUNCTION fn_cart_total(p_user_id INT) RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE total DECIMAL(10,2) DEFAULT 0;
    SELECT COALESCE(SUM(p.price * c.quantity), 0) INTO total
    FROM cart c JOIN products p ON p.id = c.product_id
    WHERE c.user_id = p_user_id;
    RETURN total;
END //
DELIMITER ;

INSERT IGNORE INTO users (login, password, is_admin) VALUES ('user', '123', 0);
INSERT INTO products (name, price) VALUES
('Хлеб', 50), ('Молоко', 80), ('Сыр', 200), ('Яблоки', 120), ('Колбаса', 350),
('Масло', 180), ('Яйца', 95), ('Сахар', 70), ('Соль', 30), ('Чай', 150),
('Кофе', 450), ('Рис', 90), ('Макароны', 60), ('Картофель', 45), ('Лук', 40),
('Помидоры', 110), ('Огурцы', 85), ('Кефир', 75), ('Творог', 120), ('Сметана', 95);
