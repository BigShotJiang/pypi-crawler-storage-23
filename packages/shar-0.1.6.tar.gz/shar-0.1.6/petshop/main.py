import sqlite3
import sys
import os

from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTableView,
    QPushButton,
    QLabel,
    QMessageBox,
    QGroupBox,
    QHeaderView,
)
from PyQt6.QtCore import Qt

НАЗВАНИЕ = "Зоомагазин Лапки"
ФАЙЛ_БД = os.path.join(os.path.dirname(__file__), "petshop.db")

СТОЛБЦЫ = [
    "Категория", "Порода", "Кличка", "Окрас", "Возраст_мес", "Стоимость",
    "Дата_продажи", "Стат_доставки", "Клиент"
]

ДАННЫЕ = [
    ["Собака", "Лабрадор", "Тузик", "Черный", 2, 7000.0, "", "", ""],
    ["Кошка", "Персидская", "Мурка", "Серый", 3, 2000.0, "", "", ""],
    ["Птица", "Попугай", "Кеша", "Зеленый", 2, 1000.0, "", "", ""],
    ["Собака", "Овчарка", "Рекс", "Рыжий", 6, 2000.0, "", "", ""],
    ["Собака", "Такса", "Шарик", "Коричневая", 4, 8000.0, "", "", ""],
    ["Кошка", "Персидская", "Барсик", "Серый", 6, 1800.0, "20.05.24 12:00", "в пути", "Cli1@ya.ru"],
    ["Кошка", "Британская", "Борис", "Черепаховый", 2, 6000.0, "", "", ""],
    ["Кошка", "Британская", "Томас", "Серебристый", 2, 6500.0, "20.05.24 12:00", "получен", "Cli1@ya.ru"],
    ["Птица", "Канарейка", "Кешуля", "Желтый", 4, 2200.0, "15.05.24 12:00", "в пути", "Cli2@ya.ru"],
]

def _c(i): return СТОЛБЦЫ[i]

НАСТРОЙКИ = {
    "view": {"name": "v_pets_in_shop", "описание": "питомцы в магазине"},
    "hf": {"подпись": "SUM(Стоимость)", "sql": f"SELECT COALESCE(SUM({_c(5)}),0) FROM pets", "сообщение": lambda r: f"Результат: {r}"},
    "hp": {"подпись": "оформление продажи", "run": lambda conn: _хп_оформить_продажу(conn), "view_после": "v_pets_in_shop", "сообщение": lambda n, msg: f"{msg}\nТаблица обновилась."},
    "trigger": {"подпись": "«в пути»→«получен»", "run": lambda conn: _trigger_получен(conn), "view_после": "v_pets_all", "сообщение": lambda n: f"Обновлено: {n}. Триггер записал в delivery_log."},
}

def _хп_оформить_продажу(conn):
    cur = conn.cursor()
    cur.execute(f"SELECT id FROM pets WHERE ({_c(6)} IS NULL OR {_c(6)}='') LIMIT 1")
    row = cur.fetchone()
    if not row:
        return 0, "Нет в магазине"
    pid = row[0]
    sid = cur.execute("SELECT id FROM delivery_statuses WHERE name='в пути'").fetchone()
    cid = cur.execute("SELECT id FROM clients LIMIT 1").fetchone()
    cur.execute(f"UPDATE pets SET {_c(6)}=datetime('now'), delivery_status_id=?, client_id=? WHERE id=?", (sid[0] if sid else None, cid[0] if cid else None, pid))
    conn.commit()
    return 1, f"Продажа id={pid}"

def _trigger_получен(conn):
    cur = conn.cursor()
    cur.execute("""
        UPDATE pets SET delivery_status_id=(SELECT id FROM delivery_statuses WHERE name='получен')
        WHERE id=(SELECT id FROM pets WHERE delivery_status_id=(SELECT id FROM delivery_statuses WHERE name='в пути') LIMIT 1)
    """)
    n = cur.rowcount
    conn.commit()
    return n

def get_conn():
    c = sqlite3.connect(ФАЙЛ_БД)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)")
    cur.execute("CREATE TABLE IF NOT EXISTS breeds (id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER REFERENCES categories(id), name TEXT NOT NULL)")
    cur.execute("CREATE TABLE IF NOT EXISTS delivery_statuses (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL)")
    cur.execute("CREATE TABLE IF NOT EXISTS clients (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE)")
    cur.execute(f"""CREATE TABLE IF NOT EXISTS pets (id INTEGER PRIMARY KEY AUTOINCREMENT, breed_id INTEGER REFERENCES breeds(id),
        {_c(2)} TEXT NOT NULL, {_c(3)} TEXT, {_c(4)} INTEGER, {_c(5)} REAL, {_c(6)} TEXT, delivery_status_id INTEGER REFERENCES delivery_statuses(id), client_id INTEGER REFERENCES clients(id))""")
    cur.execute("CREATE TABLE IF NOT EXISTS delivery_log (id INTEGER PRIMARY KEY AUTOINCREMENT, pet_id INTEGER, ts TEXT)")
    cats = {}
    for r in ДАННЫЕ:
        v = (r[0] or "").strip()
        if v and v not in cats:
            cur.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (v,))
            cats[v] = cur.execute("SELECT id FROM categories WHERE name = ?", (v,)).fetchone()[0]
    breeds = {}
    for r in ДАННЫЕ:
        c, b = (r[0] or "").strip(), (r[1] or "").strip()
        if not b or (c, b) in breeds:
            continue
        cid = cats.get(c)
        if cid:
            cur.execute("INSERT INTO breeds (category_id, name) VALUES (?, ?)", (cid, b))
            breeds[(c, b)] = cur.execute("SELECT id FROM breeds WHERE category_id = ? AND name = ?", (cid, b)).fetchone()[0]
    statuses = {}
    for r in ДАННЫЕ:
        v = (r[7] or "").strip()
        if v and v not in statuses:
            cur.execute("INSERT OR IGNORE INTO delivery_statuses (name) VALUES (?)", (v,))
            statuses[v] = cur.execute("SELECT id FROM delivery_statuses WHERE name = ?", (v,)).fetchone()[0]
    clients = {}
    for r in ДАННЫЕ:
        v = (r[8] or "").strip()
        if v and v not in clients:
            cur.execute("INSERT OR IGNORE INTO clients (email) VALUES (?)", (v,))
            clients[v] = cur.execute("SELECT id FROM clients WHERE email = ?", (v,)).fetchone()[0]
    cur.execute("DELETE FROM pets")
    for r in ДАННЫЕ:
        c, b = (r[0] or "").strip(), (r[1] or "").strip()
        bid = breeds.get((c, b))
        if not bid:
            continue
        sd = (r[6] or "").strip() or None
        sid = statuses.get((r[7] or "").strip()) if (r[7] or "").strip() else None
        cid = clients.get((r[8] or "").strip()) if (r[8] or "").strip() else None
        cur.execute(f"INSERT INTO pets (breed_id, {_c(2)}, {_c(3)}, {_c(4)}, {_c(5)}, {_c(6)}, delivery_status_id, client_id) VALUES (?,?,?,?,?,?,?,?)",
                    (bid, r[2] or "", r[3] or "", r[4] or 0, r[5] or 0, sd, sid, cid))
    cur.execute("DROP VIEW IF EXISTS v_pets_in_shop")
    cur.execute(f"""CREATE VIEW v_pets_in_shop AS SELECT c.name AS {_c(0)}, b.name AS {_c(1)}, p.{_c(2)}, p.{_c(3)}, p.{_c(4)}, p.{_c(5)}
        FROM pets p JOIN breeds b ON p.breed_id=b.id JOIN categories c ON b.category_id=c.id WHERE (p.{_c(6)} IS NULL OR p.{_c(6)}='') ORDER BY c.name, b.name""")
    cur.execute("DROP VIEW IF EXISTS v_pets_all")
    cur.execute(f"""CREATE VIEW v_pets_all AS SELECT c.name AS {_c(0)}, b.name AS {_c(1)}, p.{_c(2)}, p.{_c(3)}, p.{_c(4)}, p.{_c(5)},
        p.{_c(6)}, COALESCE(d.name,'') AS {_c(7)}, COALESCE(cl.email,'') AS {_c(8)} FROM pets p JOIN breeds b ON p.breed_id=b.id JOIN categories c ON b.category_id=c.id
        LEFT JOIN delivery_statuses d ON p.delivery_status_id=d.id LEFT JOIN clients cl ON p.client_id=cl.id ORDER BY p.id""")
    cur.execute("DROP TRIGGER IF EXISTS trg_delivery_received")
    cur.execute("""CREATE TRIGGER trg_delivery_received AFTER UPDATE ON pets WHEN NEW.delivery_status_id=(SELECT id FROM delivery_statuses WHERE name='получен' LIMIT 1)
        BEGIN INSERT INTO delivery_log (pet_id, ts) VALUES (NEW.id, datetime('now')); END""")
    conn.commit()
    conn.close()

def select_view(conn, name):
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {name}")
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description] if cur.description else []
    return rows, cols

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.conn = get_conn()
        self.setWindowTitle(НАЗВАНИЕ)
        self.setMinimumSize(900, 580)
        self._build()

    def _build(self):
        c = QWidget()
        self.setCentralWidget(c)
        v = QVBoxLayout(c)
        v.setSpacing(4)
        v.addWidget(QLabel(НАЗВАНИЕ, alignment=Qt.AlignmentFlag.AlignCenter))
        btns = QHBoxLayout()
        btns.setSpacing(8)
        cfg = НАСТРОЙКИ
        for lbl, key, h in [("1. View", "view", self._view), ("2. ХФ", "hf", self._hf), ("3. ХП", "hp", self._hp), ("4. Триггер", "trigger", self._trg)]:
            b = QPushButton(lbl)
            b.setToolTip(cfg[key].get("подпись", cfg[key].get("описание", "")))
            b.clicked.connect(h)
            btns.addWidget(b)
        v.addLayout(btns)
        g = QGroupBox("Таблица")
        gl = QVBoxLayout(g)
        self.tbl = QTableView()
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        gl.addWidget(self.tbl)
        v.addWidget(g)
        self._view()

    def _fill(self, rows, cols):
        from PyQt6.QtGui import QStandardItemModel, QStandardItem
        m = QStandardItemModel()
        m.setHorizontalHeaderLabels(cols)
        for r in rows:
            m.appendRow([QStandardItem(str(x) if x is not None else "") for x in r])
        self.tbl.setModel(m)

    def _view(self):
        r, cols = select_view(self.conn, НАСТРОЙКИ["view"]["name"])
        self._fill(r, cols)

    def _hf(self):
        cfg = НАСТРОЙКИ["hf"]
        res = self.conn.cursor().execute(cfg["sql"]).fetchone()[0]
        QMessageBox.information(self, "2. Хранимая функция", f"SQL: {cfg['sql']}\n\n{cfg['сообщение'](res)}")

    def _hp(self):
        cfg = НАСТРОЙКИ["hp"]
        n, msg = cfg["run"](self.conn)
        r, cols = select_view(self.conn, cfg["view_после"])
        self._fill(r, cols)
        QMessageBox.information(self, "3. Хранимая процедура", cfg["сообщение"](n, msg))

    def _trg(self):
        cfg = НАСТРОЙКИ["trigger"]
        n = cfg["run"](self.conn)
        r, cols = select_view(self.conn, cfg["view_после"])
        self._fill(r, cols)
        QMessageBox.information(self, "4. Триггер", cfg["сообщение"](n))

    def closeEvent(self, e):
        self.conn.close()
        e.accept()

def main():
    init_db()
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
