"""agent-bom REST API — FastAPI backend for the cloud and desktop UI."""
