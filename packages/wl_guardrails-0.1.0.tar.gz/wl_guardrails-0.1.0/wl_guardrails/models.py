"""Pydantic models for wl-guardrails SDK."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class GuardrailAction(str, Enum):
    """Action taken by the guardrails engine."""

    PASS = "pass"
    BLOCK = "block"
    SANITIZE = "sanitize"


class Violation(BaseModel):
    """A guardrail policy violation.

    Attributes:
        rule_id: The ID of the violated rule.
        error_code: Machine-readable error code.
        message: Human-readable violation description.
        severity: Severity level (e.g., "high", "critical").
    """

    rule_id: str = ""
    error_code: str = ""
    message: str = ""
    severity: str = ""


class CheckResult(BaseModel):
    """Result of a guardrail content check.

    Attributes:
        action: The action taken (pass, block, or sanitize).
        violations: List of policy violations found.
        sanitized: Sanitized content (only if action is "sanitize").
        checks_run: List of check names that were executed.
        request_id: Correlation ID for tracing.
    """

    action: GuardrailAction = GuardrailAction.PASS
    violations: list[Violation] = Field(default_factory=list)
    sanitized: str | None = None
    checks_run: list[str] = Field(default_factory=list)
    request_id: str = ""

    @property
    def is_blocked(self) -> bool:
        """Check if the content was blocked."""
        return self.action == GuardrailAction.BLOCK

    @property
    def is_sanitized(self) -> bool:
        """Check if the content was sanitized."""
        return self.action == GuardrailAction.SANITIZE

    @property
    def is_passed(self) -> bool:
        """Check if the content passed all checks."""
        return self.action == GuardrailAction.PASS


class HealthResponse(BaseModel):
    """Health check response from the guardrails service.

    Attributes:
        status: Service status (e.g., "healthy").
        service: Service name.
        version: Service version.
        policies_loaded: Number of policies currently loaded.
    """

    status: str
    service: str | None = None
    version: str | None = None
    policies_loaded: int | None = None
