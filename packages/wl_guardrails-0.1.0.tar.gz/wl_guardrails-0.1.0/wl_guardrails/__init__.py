"""WL-Guardrails Python SDK.

A Python SDK for integrating Watchlight Guardrails content safety checks
into AI agent workflows.

Basic Usage:
    >>> from wl_guardrails import WlGuardrailsClient
    >>>
    >>> async with WlGuardrailsClient() as client:
    ...     result = await client.check_input("user message")
    ...     if result.is_passed:
    ...         # Content is safe, proceed
    ...         pass

Sync Usage:
    >>> from wl_guardrails import WlGuardrailsSyncClient
    >>>
    >>> with WlGuardrailsSyncClient() as client:
    ...     result = client.check_output("LLM response")
    ...     if result.is_sanitized:
    ...         safe_content = result.sanitized
"""

from .client import WlGuardrailsClient, WlGuardrailsSyncClient
from .exceptions import (
    ConfigurationError,
    GuardrailBlockError,
    ServiceUnavailable,
    ValidationError,
    WlGuardrailsError,
)
from .models import CheckResult, GuardrailAction, HealthResponse, Violation

__version__ = "0.1.0"

__all__ = [
    # Version
    "__version__",
    # Clients
    "WlGuardrailsClient",
    "WlGuardrailsSyncClient",
    # Models
    "CheckResult",
    "GuardrailAction",
    "HealthResponse",
    "Violation",
    # Exceptions
    "WlGuardrailsError",
    "GuardrailBlockError",
    "ServiceUnavailable",
    "ConfigurationError",
    "ValidationError",
]
