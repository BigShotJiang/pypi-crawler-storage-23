"""Exception classes for wl-guardrails SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import CheckResult


class WlGuardrailsError(Exception):
    """Base exception for wl-guardrails SDK."""


class GuardrailBlockError(WlGuardrailsError):
    """Raised when a guardrail blocks content.

    Attributes:
        result: The full check result from the server.
        error_code: The primary violation error code.
        rule_id: The primary violation rule ID.
        guardrail_message: The primary violation message.
        request_id: The request correlation ID.
    """

    def __init__(self, result: CheckResult) -> None:
        self.result = result
        self.error_code = result.violations[0].error_code if result.violations else "UNKNOWN"
        self.rule_id = result.violations[0].rule_id if result.violations else "unknown"
        self.guardrail_message = (
            result.violations[0].message if result.violations else "Blocked by guardrails"
        )
        self.request_id = result.request_id
        super().__init__(
            f"Guardrail {result.action.value}: {self.error_code} "
            f"(rule={self.rule_id}, request_id={self.request_id})"
        )


class ServiceUnavailable(WlGuardrailsError):
    """Raised when the guardrails service is unavailable."""

    def __init__(
        self,
        message: str = "WL-Guardrails service is unavailable",
        url: str | None = None,
    ) -> None:
        super().__init__(message)
        self.url = url


class ConfigurationError(WlGuardrailsError):
    """Raised when there's a configuration error."""


class ValidationError(WlGuardrailsError):
    """Raised when request validation fails."""

    def __init__(self, message: str, error_code: str | None = None) -> None:
        super().__init__(message)
        self.error_code = error_code
