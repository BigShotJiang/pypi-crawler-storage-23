def setup_mlflow(api, train_split_id):
    """
    Setup MLFlow experiment and run.
    
    Args:
        api: KWS API client
        train_split_id: Train split ID for experiment run
    
    Returns:
        Tuple of (use_mlflow, mlflow_run_id, experiment_id)
    """
    try:
        # Get or create experiment
        print("\n=== Setting up MLFlow experiment ===")
        experiments = api.experiments.list(page=1, page_size=100)
        experiment_name = "CNN Training"
        
        # Find existing experiment or create new one
        experiment = None
        for exp in experiments.get('items', []):
            if exp.get('name') == experiment_name:
                experiment = exp
                break
        
        if not experiment:
            print(f"Creating new experiment: {experiment_name}")
            experiment = api.experiments.create(
                name=experiment_name,
                description="CNN model training for keyword spotting"
            )
        
        experiment_id = experiment.get('experiments_id') or experiment.get('id')
        print(f"Using experiment ID: {experiment_id}")
        
        # Note: To create an experiment run, you need model_id and dataset_split_id
        # For now, we'll skip creating the run and use MLFlow directly
        # If you have model_id, you can uncomment below to create experiment run:
        """
        # Create experiment run (this will create MLFlow run via Celery task)
        print("Creating experiment run...")
        # You need to provide model_id
        run_response = api.experiments.create_run(
            experiment_id=experiment_id,
            model_id=1,  # Replace with actual model ID
            dataset_split_id=train_split_id,  # Use train split ID
            config={
                "learning_rate": 0.001,
                "batch_size": 32,
                "epochs": 100
            },
            git_commit="manual-training"
        )
        
        # Wait for job to complete
        job_id = run_response.get('job_id')
        if job_id:
            print(f"Waiting for experiment run job {job_id} to complete...")
            job_status = api.jobs.wait_for_completion(job_id, timeout=60)
            
            # Get experiment runs to find the created run
            runs = api.experiments.list_runs(experiment_id)
            if runs:
                latest_run = runs[0]
                kws_run_id = latest_run.get('experiment_runs_id') or latest_run.get('id')
                mlflow_run_id = latest_run.get('mlflow_run_id')
                if mlflow_run_id:
                    print(f"Got MLFlow run ID: {mlflow_run_id}")
        """
        
        return True, None, experiment_id
        
    except Exception as e:
        print(f"Warning: MLFlow setup failed: {e}")
        print("Continuing without MLFlow logging...")
        return False, None, None
