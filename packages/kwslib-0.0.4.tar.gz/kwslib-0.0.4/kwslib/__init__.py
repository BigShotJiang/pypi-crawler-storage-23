"""
KWS Library - Python client for KWS Platform API

Design note:
- Keep package import lightweight. Some optional modules (e.g. TensorFlow models)
  are heavy; we lazy-load them via __getattr__ so that "smoke" / client usage
  doesn't pull ML stacks unnecessarily.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

__version__ = "0.0.4"

if TYPE_CHECKING:
    # For type checkers / IDEs only (these imports may be heavy at runtime).
    from .client import KWSClient
    from .high_level import KWSSession, DatasetPipeline, ModelManager
    from .minio_client import DatasetSplitFilesClient
    from .telegram_notifier import TelegramNotifier
    from .standards.metrics import STANDARD_METRIC_KEYS, build_metrics_payload, metrics_from_sklearn


_LAZY_ATTRS = {
    # Core lightweight pieces
    "KWSClient": ("kwslib.client", "KWSClient"),
    "DatasetSplitFilesClient": ("kwslib.minio_client", "DatasetSplitFilesClient"),
    "TelegramNotifier": ("kwslib.telegram_notifier", "TelegramNotifier"),
    # Standards (lightweight)
    "STANDARD_METRIC_KEYS": ("kwslib.standards.metrics", "STANDARD_METRIC_KEYS"),
    "build_metrics_payload": ("kwslib.standards.metrics", "build_metrics_payload"),
    "metrics_from_sklearn": ("kwslib.standards.metrics", "metrics_from_sklearn"),
    # High-level API (may pull training / TF deps)
    "KWSSession": ("kwslib.high_level", "KWSSession"),
    "DatasetPipeline": ("kwslib.high_level", "DatasetPipeline"),
    "ModelManager": ("kwslib.high_level", "ModelManager"),
}

__all__ = ["__version__", *_LAZY_ATTRS.keys()]


def __getattr__(name: str):
    if name not in _LAZY_ATTRS:
        raise AttributeError(name)
    module_name, attr_name = _LAZY_ATTRS[name]
    import importlib

    mod = importlib.import_module(module_name)
    return getattr(mod, attr_name)
