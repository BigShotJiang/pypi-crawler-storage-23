from setuptools import setup, find_packages
setup(
    name='pi-plates',
    version='11.0',
    license='BSD',
    author='Jerry Wasinger, WallyWare, inc.',
    author_email='support@pi-plates.com',
    keywords = "pi-plates,data acquisition, Windows, Mac, Linux, raspberry pi, relays, motors, temperature sensing, HATs, 4-20mA, and so much more",
    url='https://www.pi-plates.com',
    long_description="README.txt",
    packages=['piplates'],
    include_package_data=True,
    package_data={'' : ['*.txt']},
    description="Pi-Plates library setup",
)