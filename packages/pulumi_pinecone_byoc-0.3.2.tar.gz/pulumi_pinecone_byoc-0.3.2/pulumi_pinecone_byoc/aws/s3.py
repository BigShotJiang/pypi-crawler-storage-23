"""
S3 component for Pinecone BYOC infrastructure.

Creates S3 buckets for vector data storage, WAL, and operational data.
"""

import pulumi
import pulumi_aws as aws

from config.aws import AWSConfig

# https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html
AWS_S3_BUCKET_NAME_LIMIT = 63


class S3Buckets(pulumi.ComponentResource):
    """
    Creates S3 buckets with:
    - Data bucket for vector storage
    - WAL bucket for write-ahead logs
    - Internal bucket for operational data
    - Server-side encryption (AES256)
    - Lifecycle rules for multipart upload cleanup
    - Optional versioning for production
    """

    def __init__(
        self,
        name: str,
        config: AWSConfig,
        cell_name: pulumi.Input[str],
        kms_key_arn: pulumi.Output[str] | None = None,
        force_destroy: bool = False,
        opts: pulumi.ResourceOptions | None = None,
    ):
        super().__init__("pinecone:byoc:S3Buckets", name, None, opts)

        self.config = config
        self._cell_name = pulumi.Output.from_input(cell_name)
        self._force_destroy = force_destroy
        child_opts = pulumi.ResourceOptions(parent=self)

        # bucket naming follows reference pattern: pc-{type}-{cell_name}
        self.data_bucket = self._create_bucket(
            name=f"{name}-data",
            bucket_type="data",
            kms_key_arn=kms_key_arn,
            opts=child_opts,
        )

        self.index_backups_bucket = self._create_bucket(
            name=f"{name}-index-backups",
            bucket_type="index-backups",
            kms_key_arn=kms_key_arn,
            opts=child_opts,
        )

        self.wal_bucket = self._create_bucket(
            name=f"{name}-wal",
            bucket_type="wal",
            kms_key_arn=kms_key_arn,
            opts=child_opts,
        )

        self.janitor_bucket = self._create_bucket(
            name=f"{name}-janitor",
            bucket_type="janitor",
            kms_key_arn=kms_key_arn,
            opts=child_opts,
        )

        self.internal_bucket = self._create_bucket(
            name=f"{name}-internal",
            bucket_type="internal",
            kms_key_arn=kms_key_arn,
            opts=child_opts,
        )

        self.register_outputs(
            {
                "data_bucket_name": self.data_bucket.id,
                "data_bucket_arn": self.data_bucket.arn,
                "index_backups_bucket_name": self.index_backups_bucket.id,
                "wal_bucket_name": self.wal_bucket.id,
                "janitor_bucket_name": self.janitor_bucket.id,
                "internal_bucket_name": self.internal_bucket.id,
            }
        )

    def _create_bucket(
        self,
        name: str,
        bucket_type: str,
        kms_key_arn: pulumi.Output[str] | None = None,
        opts: pulumi.ResourceOptions | None = None,
    ) -> aws.s3.Bucket:
        """Create an S3 bucket with standard configuration."""
        full_bucket_name = self._cell_name.apply(
            lambda cn: f"pc-{bucket_type}-{cn}"[:AWS_S3_BUCKET_NAME_LIMIT].strip("-")
        )
        bucket = aws.s3.Bucket(
            name,
            bucket=full_bucket_name,
            force_destroy=self._force_destroy,
            tags=full_bucket_name.apply(lambda bn: self.config.tags(Name=bn)),
            opts=opts,
        )

        aws.s3.BucketVersioning(
            f"{name}-versioning",
            bucket=bucket.id,
            versioning_configuration=aws.s3.BucketVersioningVersioningConfigurationArgs(
                status="Enabled",
            ),
            opts=opts,
        )

        aws.s3.BucketPublicAccessBlock(
            f"{name}-public-access-block",
            bucket=bucket.id,
            block_public_acls=True,
            block_public_policy=True,
            ignore_public_acls=True,
            restrict_public_buckets=True,
            opts=opts,
        )

        if kms_key_arn:
            aws.s3.BucketServerSideEncryptionConfiguration(
                f"{name}-encryption",
                bucket=bucket.id,
                rules=[
                    aws.s3.BucketServerSideEncryptionConfigurationRuleArgs(
                        apply_server_side_encryption_by_default=aws.s3.BucketServerSideEncryptionConfigurationRuleApplyServerSideEncryptionByDefaultArgs(
                            sse_algorithm="aws:kms",
                            kms_master_key_id=kms_key_arn,
                        ),
                        bucket_key_enabled=True,
                    ),
                ],
                opts=opts,
            )
        else:
            aws.s3.BucketServerSideEncryptionConfiguration(
                f"{name}-encryption",
                bucket=bucket.id,
                rules=[
                    aws.s3.BucketServerSideEncryptionConfigurationRuleArgs(
                        apply_server_side_encryption_by_default=aws.s3.BucketServerSideEncryptionConfigurationRuleApplyServerSideEncryptionByDefaultArgs(
                            sse_algorithm="AES256",
                        ),
                    ),
                ],
                opts=opts,
            )

        aws.s3.BucketLifecycleConfiguration(
            f"{name}-lifecycle",
            bucket=bucket.id,
            rules=[
                aws.s3.BucketLifecycleConfigurationRuleArgs(
                    id="abort-incomplete-multipart",
                    status="Enabled",
                    abort_incomplete_multipart_upload=aws.s3.BucketLifecycleConfigurationRuleAbortIncompleteMultipartUploadArgs(
                        days_after_initiation=2,
                    ),
                    expiration=aws.s3.BucketLifecycleConfigurationRuleExpirationArgs(
                        expired_object_delete_marker=True,
                    ),
                    noncurrent_version_expiration=aws.s3.BucketLifecycleConfigurationRuleNoncurrentVersionExpirationArgs(
                        noncurrent_days=3,
                    ),
                ),
                aws.s3.BucketLifecycleConfigurationRuleArgs(
                    id="delete-activity-scrapes",
                    status="Enabled",
                    expiration=aws.s3.BucketLifecycleConfigurationRuleExpirationArgs(days=30),
                    filter=aws.s3.BucketLifecycleConfigurationRuleFilterArgs(
                        prefix="activity-scrapes/"
                    ),
                ),
                aws.s3.BucketLifecycleConfigurationRuleArgs(
                    id="delete-janitor",
                    status="Enabled",
                    expiration=aws.s3.BucketLifecycleConfigurationRuleExpirationArgs(days=7),
                    filter=aws.s3.BucketLifecycleConfigurationRuleFilterArgs(prefix="janitor/"),
                ),
                aws.s3.BucketLifecycleConfigurationRuleArgs(
                    id="delete-lag-reporter",
                    status="Enabled",
                    expiration=aws.s3.BucketLifecycleConfigurationRuleExpirationArgs(days=14),
                    filter=aws.s3.BucketLifecycleConfigurationRuleFilterArgs(
                        prefix="lag-reporter/"
                    ),
                ),
            ],
            opts=opts,
        )

        return bucket

    @property
    def data_bucket_name(self) -> pulumi.Output[str]:
        return self.data_bucket.id

    @property
    def data_bucket_arn(self) -> pulumi.Output[str]:
        return self.data_bucket.arn

    @property
    def index_backups_bucket_name(self) -> pulumi.Output[str]:
        return self.index_backups_bucket.id

    @property
    def wal_bucket_name(self) -> pulumi.Output[str]:
        return self.wal_bucket.id

    @property
    def janitor_bucket_name(self) -> pulumi.Output[str]:
        return self.janitor_bucket.id

    @property
    def internal_bucket_name(self) -> pulumi.Output[str]:
        return self.internal_bucket.id
