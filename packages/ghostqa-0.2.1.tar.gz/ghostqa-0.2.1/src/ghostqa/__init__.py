"""GhostQA — AI persona-based behavioral testing for web apps."""

__version__ = "0.1.0"
