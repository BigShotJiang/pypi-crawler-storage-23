"""Allow running as python -m ghostqa."""

from ghostqa.cli.app import app

app()
