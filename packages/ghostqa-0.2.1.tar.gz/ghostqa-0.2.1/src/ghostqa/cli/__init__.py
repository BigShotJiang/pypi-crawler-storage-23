"""GhostQA CLI — Typer + Rich command-line interface."""
