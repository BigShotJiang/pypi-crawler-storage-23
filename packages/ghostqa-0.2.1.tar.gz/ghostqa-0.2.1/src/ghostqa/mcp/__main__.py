"""Allow running the MCP server as ``python -m ghostqa.mcp``."""

from ghostqa.mcp.server import main

main()
