# README Installation Instructions Update

## Issue
The README contained incorrect installation instructions that suggested installing from PyPI:
```bash
pip install trendsleuth
uv tool install trendsleuth
```

However, TrendSleuth is not yet published on PyPI, so these commands would fail.

## Changes Made

### 1. Added Notice About PyPI
Added a clear note at the top of the Installation section:
```markdown
> **Note:** TrendSleuth is not yet published on PyPI. Install from source using the instructions below.
```

### 2. Updated Installation Instructions
Changed from PyPI-based installation to source-based installation with two methods:

#### Method 1: Using uv (Recommended)
```bash
# Clone the repository
git clone https://github.com/lukemaxwell/trendsleuth.git
cd trendsleuth

# Install with uv (recommended)
uv sync

# Activate the virtual environment
source .venv/bin/activate  # Linux/macOS
# or
.venv\Scripts\activate     # Windows

# Install in development mode
uv pip install -e .
```

#### Method 2: Using pip
```bash
# Clone the repository
git clone https://github.com/lukemaxwell/trendsleuth.git
cd trendsleuth

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# or
.venv\Scripts\activate     # Windows

# Install dependencies
pip install -e .
```

### 3. Updated Development Section
Clarified that the Development section is for contributors and noted that `uv sync` already installs the package in editable mode, so no additional steps are needed.

## Result
Users can now successfully install TrendSleuth by:
1. Cloning the repository from GitHub
2. Installing dependencies with either `uv` or `pip`
3. The package is installed in editable/development mode so the `trendsleuth` command is available

The instructions are clear, accurate, and include both Linux/macOS and Windows variants.

## Future Consideration
Once TrendSleuth is published to PyPI, the installation instructions can be simplified to:
```bash
pip install trendsleuth
# or
uv tool install trendsleuth
```

And the source installation can be moved to the Development/Contributing section only.
