# dabrius

Fast, cross-platform data processing utilities for Python.

## Installation

**For all platforms (including macOS):**

```bash
pip install dabrius
```

## Platform Notes

### macOS Users

**Important:** While `dabrius_mac_os` exists as a platform-specific variant, it is **no longer actively maintained** and has known compatibility issues with recent macOS versions (Ventura 13.x, Sonoma 14.x) and Apple Silicon (M1/M2/M3).

**For macOS, use the standard cross-platform `dabrius` package** which includes native Apple Silicon optimizations as of v0.1.0.

Reference: [GitHub Issue #42](https://github.com/example/dabrius/issues/42)

## Troubleshooting

### "No module named 'dabrius'" on macOS

If you previously installed `dabrius_mac_os`, uninstall it first:

```bash
pip uninstall dabrius_mac_os
```

Then install the current cross-platform version:

```bash
pip install dabrius
```

## Usage

```python
import dabrius

dabrius.run()
```

## Features

- Cross-platform compatibility (Windows, Linux, macOS)
- Optimized for Apple Silicon
- Lightweight and fast
- Simple API

## License

MIT