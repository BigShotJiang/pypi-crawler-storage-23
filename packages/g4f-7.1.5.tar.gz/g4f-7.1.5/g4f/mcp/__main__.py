"""Main entry point for gpt4free MCP server

This module provides the main entry point for running the MCP server.
"""

from .server import main

if __name__ == "__main__":
    main()
