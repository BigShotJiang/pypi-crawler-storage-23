import os

from pydantic import ValidationError

from osa_tool.config.settings import ConfigManager
from osa_tool.core.git.metadata import RepositoryMetadata
from osa_tool.core.llm.llm import ModelHandler, ModelHandlerFactory
from osa_tool.operations.analysis.repository_report.response_validation import (
    RepositoryReport,
    RepositoryStructure,
    ReadmeEvaluation,
    CodeDocumentation,
    OverallAssessment,
    AfterReportBlock,
    AfterReport,
)
from osa_tool.tools.repository_analysis.sourcerank import SourceRank
from osa_tool.utils.logger import logger
from osa_tool.utils.prompts_builder import PromptBuilder
from osa_tool.utils.response_cleaner import JsonProcessor, JsonParseError
from osa_tool.utils.utils import extract_readme_content, parse_folder_name


class TextGenerator:
    def __init__(self, config_manager: ConfigManager, metadata: RepositoryMetadata):
        self.config_manager = config_manager
        self.model_settings = self.config_manager.get_model_settings("general")
        self.sourcerank = SourceRank(self.config_manager)
        self.prompts = self.config_manager.get_prompts()
        self.metadata = metadata
        self.model_handler: ModelHandler = ModelHandlerFactory.build(self.model_settings)
        self.repo_url = self.config_manager.get_git_settings().repository
        self.base_path = os.path.join(os.getcwd(), parse_folder_name(self.repo_url))

    def make_request(self) -> RepositoryReport:
        """
        Sends a request to the model handler to generate the repository analysis.

        Returns:
            str: The generated repository analysis response from the model.
        """
        prompt = PromptBuilder.render(
            self.prompts.get("analysis.main_prompt"),
            project_name=self.metadata.name,
            metadata=self.metadata,
            repository_tree=self.sourcerank.tree,
            presence_files=self._extract_presence_files(),
            readme_content=extract_readme_content(self.base_path),
        )

        try:
            data = self.model_handler.send_and_parse(
                prompt=prompt,
                parser=lambda raw: RepositoryReport.model_validate(JsonProcessor.parse(raw, expected_type=dict)),
            )
            return data

        except (ValidationError, JsonParseError) as e:
            logger.warning(f"Parsing failed, fallback applied: {e}")

            return RepositoryReport(
                structure=RepositoryStructure(),
                readme=ReadmeEvaluation(),
                documentation=CodeDocumentation(),
                assessment=OverallAssessment(),
            )

        except Exception as e:
            logger.error(f"Unexpected error while parsing RepositoryReport: {e}")
            raise ValueError(f"Failed to process model response: {e}")

    def _extract_presence_files(self) -> list[str]:
        """
        Extracts information about the presence of key files in the repository.

        This method generates a list of strings indicating whether key files like
        README, LICENSE, documentation, examples, requirements and tests are present in the repository.

        Returns:
            list[str]: A list of strings summarizing the presence of key files in the repository.
        """
        contents = [
            f"README presence is {self.sourcerank.readme_presence()}",
            f"LICENSE presence is {self.sourcerank.license_presence()}",
            f"Examples presence is {self.sourcerank.examples_presence()}",
            f"Documentation presence is {self.sourcerank.docs_presence()}",
            f"Requirements presence is {self.sourcerank.requirements_presence()}",
        ]
        return contents


class AfterReportTextGenerator:
    def __init__(self, config_manger: ConfigManager, what_has_been_done: list[tuple[str, bool]]) -> None:
        self.config_manager = config_manger
        self.model_settings = self.config_manager.get_model_settings("general")
        self.prompts = self.config_manager.config.prompts
        self.what_has_been_done = what_has_been_done
        self.model_handler: ModelHandler = ModelHandlerFactory.build(self.model_settings)

    def make_request(self) -> AfterReport:
        """
        Sends a request to the model handler to generate the OSA work summary.

        Returns:
            The generated OSA work summary response from the model.
        """
        formatted_tasks = "\n".join(
            f"Task {i}. {n}: {'Yes' if d else 'No'}" for i, (n, d) in enumerate(self.what_has_been_done)
        )
        json_prompt = PromptBuilder.render(
            self.prompts.get("analysis.after_report_blocks_prompt"),
            tasks_list=formatted_tasks,
        )
        summary_prompt = PromptBuilder.render(
            self.prompts.get("analysis.after_report_text_prompt"),
            tasks_list=formatted_tasks,
        )

        try:
            summary = self.model_handler.send_request(prompt=summary_prompt)
            json_result = self.model_handler.send_and_parse(
                prompt=json_prompt,
                parser=lambda raw: [
                    AfterReportBlock(
                        name=d["name"],
                        description=d["description"],
                        tasks=[self.what_has_been_done[i] for i in d["tasks"]],
                    )
                    for d in JsonProcessor.parse(raw, expected_type=list)
                ],
            )
            return AfterReport(summary=summary, blocks=json_result)
        except Exception as e:
            logger.error(f"Unexpected error while parsing RepositoryReport: {e}")
            raise ValueError(f"Failed to process model response: {e}")
