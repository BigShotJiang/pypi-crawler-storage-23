#ifndef CS_RISCV_DISASSEMBLER_EXTENSION_H
#define CS_RISCV_DISASSEMBLER_EXTENSION_H

#include "../../cs_priv.h"

bool RISCV_getFeatureBits(unsigned int mode, unsigned int feature);

#endif // CS_RISCV_DISASSEMBLER_EXTENSION_H
