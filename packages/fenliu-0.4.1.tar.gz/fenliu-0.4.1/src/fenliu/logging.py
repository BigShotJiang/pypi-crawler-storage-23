"""Logging configuration for FenLiu application.

This module provides centralized logging setup with:
- DEBUG level logs written to file with daily rotation (3 versions kept)
- Console output showing INFO and ERROR levels only
- Formatted logs including module, class/method, and line number information
"""

import logging
import logging.handlers
import sys
from pathlib import Path


class ContextualLogFormatter(logging.Formatter):
    """Custom formatter that includes module, class/method, and line number."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with contextual information."""
        # Remove 'fenliu.' prefix from module name for cleaner output
        module_name = record.name.replace("fenliu.", "") if record.name else "root"
        func_name = record.funcName if record.funcName != "<module>" else None

        # Build context string
        if func_name:
            context = f"{module_name}.{func_name}"
        else:
            context = module_name

        # Create formatted message
        timestamp = self.formatTime(record, self.datefmt)
        return f"{timestamp} - {context}:{record.lineno} - {record.levelname} - {record.getMessage()}"


def setup_logging(debug: bool = False, log_dir: str | Path = "logs") -> logging.Logger:
    """Configure logging with file and console handlers.

    Args:
        debug: If True, enables debug mode with file logging at DEBUG level
        log_dir: Directory to store debug log files

    Returns:
        Configured logger instance for the fenliu module

    """
    # Ensure log directory exists
    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)

    # Get the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # Capture all levels, handlers will filter

    # Remove any existing handlers to prevent duplicates
    root_logger.handlers.clear()

    # Create formatter
    formatter = ContextualLogFormatter(datefmt="%Y-%m-%d %H:%M:%S")

    # Console handler - INFO and ERROR only
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    # File handler - DEBUG level with daily rotation (debug mode only)
    if debug:
        debug_log_file = log_path / "fenliu_debug.log"
        file_handler = logging.handlers.TimedRotatingFileHandler(
            filename=str(debug_log_file),
            when="midnight",  # Rotate at midnight daily
            interval=1,
            backupCount=3,  # Keep 3 old versions (current + 2 backups)
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    return root_logger


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance for a specific module.

    Args:
        name: The module name (__name__ typically)

    Returns:
        Logger instance for the module

    """
    return logging.getLogger(name)
