from evolib.config.schema import FullConfig
from evolib.initializers.registry import _resolve_evonet_initializer
from evolib.representation.evonet import EvoNet


def test_default_initializer_evonet_builds_expected_structure() -> None:
    config = FullConfig(
        parent_pool_size=1,
        offspring_pool_size=1,
        max_generations=1,
        num_elites=0,
        max_indiv_age=0,
        modules={
            "brain": {
                "type": "evonet",
                "dim": [2, 3, 1],
                "activation": "linear",
                "connectivity": {
                    "scope": "adjacent",
                    "density": 1.0,
                },
                "weights": {
                    "initializer": "normal",
                    "std": 0.5,
                    "bounds": [-1.0, 1.0],
                },
                "bias": {
                    "initializer": "normal",
                    "std": 0.1,
                    "bounds": [-0.5, 0.5],
                },
                "mutation": {
                    "strategy": "constant",
                    "strength": 0.1,
                    "probability": 1.0,
                },
            }
        },
    )

    init_fn = _resolve_evonet_initializer("default")
    para = init_fn(config, "brain")
    assert isinstance(para, EvoNet)
    net = para.net

    # Check structure: number of layers
    assert len(net.layers) == 3

    # Count total neurons across layers
    total_neurons = sum(len(layer.neurons) for layer in net.layers)
    assert total_neurons == 6

    # Count output neurons
    output_neurons = net.layers[-1].neurons
    assert len(output_neurons) == 1

    # Check connections
    connection_count = len(net.get_all_connections())
    assert connection_count == (2 * 3) + (3 * 1)  # fully connected
