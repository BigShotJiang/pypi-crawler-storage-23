"""
Beispiel: Stanze (Disassembly) + Zugmaschine + zwei Medienlagerungen, zwei Laboranten.

Ablauf:
  - Quelle erzeugt "fell" -> Stanze (Disassembly mit Laborant_1).
  - Stanze liefert: fell, dogbone, medium_luft, medium_flussigkeit.
  - fell -> Sink (Transport Laborant_1).
  - dogbone -> Zugmaschine (Laborant_1) -> Sink.
  - medium_luft -> Medienlagerung_Luft (Laborant_1: Setup/Lagerung/Setdown) -> Sink.
  - medium_flussigkeit -> Medienlagerung_Flüssigkeit (Laborant_2: Transport + Setup/Lagerung/Setdown) -> Sink.

Erwartete aktive Ressourcen: Stanze, Zugmaschine, Medienlagerung_Luft, Medienlagerung_Flüssigkeit, Laborant_1, Laborant_2.
"""

import prodsys.express as psx
import prodsys
from prodsys.models.production_system_data import add_default_queues_to_production_system
from prodsys.models import port_data

prodsys.set_logging("CRITICAL")


# ---------------------------------------------------------------------------
# Zeitmodelle und Prozesse
# ---------------------------------------------------------------------------

# --- Arrival ---
tm_arrival = psx.FunctionTimeModel(distribution_function="exponential", location=6.0, scale=0.3, ID="tm_arrival")
p_arrival = psx.ProductionProcess(time_model=tm_arrival, ID="p_arrival")

# --- Transport ---
tm_transport_1 = psx.DistanceTimeModel(speed=80, reaction_time=0.1, ID="m_transport_1")
p_transport_1 = psx.TransportProcess(time_model=tm_transport_1, ID="p_transport_1")

# --- Stanzen ---
tm_stanzen = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_stanzen")
p_stanzen = psx.ProductionProcess(time_model=tm_stanzen, ID="p_stanzen")

# --- Zugversuch ---
tm_zugversuch = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_zugversuch")
p_zugversuch = psx.ProductionProcess(time_model=tm_zugversuch, ID="p_zugversuch")

# --- Dichte/Haerte
tm_dichte_haerte = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_dichte_haerte")
p_dichte_haerte = psx.ProductionProcess(time_model=tm_dichte_haerte, ID="p_dichte_haerte")

# --- Medienlagerung Luft ---
tm_setup_lagerung_luft = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_setup_lagerung_luft")
tm_lagerung_luft = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_medienlagerung_luft")
tm_setdown_lagerung_luft = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_setdown_lagerung_luft")
p_setup_lagerung_luft = psx.ProductionProcess(time_model=tm_setup_lagerung_luft, ID="p_setup_lagerung_luft")
p_lagerung_luft = psx.ProductionProcess(time_model=tm_lagerung_luft, ID="p_lagerung_luft")
p_setdown_lagerung_luft = psx.ProductionProcess(time_model=tm_setdown_lagerung_luft, ID="p_setdown_lagerung_luft")


# --- Medienlagerung Flüssigkeit ---
tm_setup_lagerung_flussigkeit = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_setup_lagerung_flussigkeit")
tm_lagerung_flussigkeit = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_medienlagerung_flussigkeit")
tm_setdown_lagerung_flussigkeit = t_setup = psx.FunctionTimeModel(distribution_function="normal", location=1.0, scale=0.3, ID="tm_setdown_lagerung_flussigkeit")
p_setup_lagerung_flussigkeit = psx.ProductionProcess(time_model=tm_setup_lagerung_flussigkeit, ID="p_setup_lagerung_flussigkeit")
p_lagerung_flussigkeit = psx.ProductionProcess(time_model=tm_lagerung_flussigkeit, ID="p_lagerung_flussigkeit")
p_setdown_lagerung_flussigkeit = psx.ProductionProcess(time_model=tm_setdown_lagerung_flussigkeit, ID="p_setdown_lagerung_flussigkeit")


# ---------------------------------------------------------------------------
# Resourcen
# ---------------------------------------------------------------------------

# --- Worker ---
laborant_1 = psx.Resource(
    processes=[p_transport_1],
    location=[0, 1],
    capacity=1,
    ID="Laborant_1"
)

laborant_2 = psx.Resource(
    processes=[p_transport_1],
    location=[0, 2],
    capacity=1,
    ID="Laborant_2"
)

stanze = psx.Resource(
    processes=[p_stanzen],
    location=[10, 0],
    capacity=1,
    ID="Stanze"
)

# stanze.ports = [
#     psx.Queue(
#         ID="In_Out",
#         capacity = 4,
#         location = stanze.location,
#         interface_type=port_data.PortInterfaceType.INPUT_OUTPUT,
#     ),
# ]

zugmaschine = psx.Resource(
    processes=[p_zugversuch],
    location=[12, 0],
    capacity=1,
    ID="Zugmaschine"
)

medienlagerung_luft = psx.Resource(
    processes=[p_setup_lagerung_luft, p_lagerung_luft, p_setdown_lagerung_luft],
    location=[11, 0],
    capacity=1,
    ID="Medienlagerung_Luft"
)

medienlagerung_flussigkeit = psx.Resource(
    processes=[p_setup_lagerung_flussigkeit, p_lagerung_flussigkeit, p_setdown_lagerung_flussigkeit],   
    location=[13, 0],
    capacity=1,
    ID="Medienlagerung_Flussigkeit"
)

dichte_haerte = psx.Resource(
    processes=[p_dichte_haerte],   
    location=[14, 0],
    capacity=1,
    ID="Dichte_Haerte"
)

# ---------------------------------------------------------------------------
# Produkte
# ---------------------------------------------------------------------------
fell= psx.Product(process=[p_stanzen], transport_process=p_transport_1, ID="fell")
dogbone = psx.Product(process=[p_zugversuch], transport_process=p_transport_1, ID="dogbone")
medium_luft = psx.Product(process=[p_setup_lagerung_luft, p_lagerung_luft, p_setdown_lagerung_luft, p_zugversuch], transport_process=p_transport_1, ID="medium_luft")
medium_flussigkeit = psx.Product(process=[p_setup_lagerung_flussigkeit, p_lagerung_flussigkeit, p_setdown_lagerung_flussigkeit, p_dichte_haerte, p_zugversuch], transport_process=p_transport_1, ID="medium_flussigkeit")

# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------
node_stanze = psx.Node(location=[10, 0], ID="node_stanze")
node_zugmaschine = psx.Node(location=[10, 0], ID="node_zugmaschine")
node_medienlagerung_luft = psx.Node(location=[10, 0], ID="node_medienlagerung_luft")
node_medienlagerung_flussigkeit = psx.Node(location=[10, 0], ID="node_medienlagerung_flussigkeit")
node_dichte_haerte = psx.Node(location=[10, 0], ID="node_dichte_haerte")

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------
dep_stanze = psx.ResourceDependency(
    required_resource=laborant_1,
    interaction_node=node_stanze,
    ID="dep_stanze",
)
dep_zugmaschine = psx.ResourceDependency(
    required_resource=laborant_1,
    interaction_node=node_zugmaschine,
    ID="dep_zugmaschine",
)

dep_medienlagerung_luft = psx.ResourceDependency(
    required_resource=laborant_1,
    interaction_node=node_medienlagerung_luft,
    ID="dep_medienlagerung_luft",
)
dep_medienlagerung_flussigkeit = psx.ResourceDependency(
    required_resource=laborant_2,
    interaction_node=node_medienlagerung_flussigkeit,
    ID="dep_medienlagerung_flussigkeit",
)

dep_dichte_haerte = psx.ResourceDependency(
    required_resource=laborant_2,
    interaction_node=node_dichte_haerte,
    ID="dep_dichte_haerte",
)

dep_vereinzeln_fell = psx.DisassemblyDependency(ID="dep_vereinzeln_fell", required_entity=fell)
dep_vereinzeln_dogbone = psx.DisassemblyDependency(ID="dep_vereinzeln_dogbone", required_entity=dogbone)
dep_vereinzeln_medium_luft = psx.DisassemblyDependency(ID="dep_vereinzeln_luft", required_entity=medium_luft)
dep_vereinzeln_medium_flussigkeit = psx.DisassemblyDependency(ID="dep_vereizeln_flussigkeit", required_entity=medium_flussigkeit)

p_stanzen.dependencies = [dep_vereinzeln_fell, dep_vereinzeln_dogbone, dep_vereinzeln_medium_luft, dep_vereinzeln_medium_flussigkeit]
p_setup_lagerung_luft.dependencies = [dep_medienlagerung_luft]
p_setdown_lagerung_luft.dependencies = [dep_medienlagerung_luft]
p_setup_lagerung_flussigkeit.dependencies = [dep_medienlagerung_flussigkeit]
p_setdown_lagerung_flussigkeit.dependencies = [dep_medienlagerung_flussigkeit]

#p_dichte_haerte.dependencies = [dep_dichte_haerte] # Das ist der Prozess, der auf Ressource dichte_haerte läuft
dichte_haerte.dependencies = [dep_dichte_haerte] # Das ist die Ressource
stanze.dependencies = [dep_stanze]
zugmaschine.dependencies = [dep_zugmaschine]


# ---------------------------------------------------------------------------
# Sources & Sinks
# ---------------------------------------------------------------------------

source = psx.Source(
    product=fell,
    time_model=tm_arrival,
    location=[0, 0],
    ID="source",
)

sink_fell = psx.Sink(
    product=fell,
    location=[20, 0],
    ID="sink_fell",
)
sink_medium_luft = psx.Sink(
    product=medium_luft,
    location=[20, 0],
    ID="sink_medium_luft",
)
sink_medium_flussigkeit = psx.Sink(
    product=medium_flussigkeit,
    location=[20, 0],
    ID="sink_medium_flussigkeit",
)
sink_dogbone = psx.Sink(
    product=dogbone,
    location=[20, 0],
    ID="sink_dogbone",
)

# ---------------------------------------------------------------------------
# Production system and run
# ---------------------------------------------------------------------------
system = psx.ProductionSystem(
    resources=[dichte_haerte, stanze, zugmaschine, medienlagerung_luft, medienlagerung_flussigkeit, laborant_1, laborant_2],
    sources=[source],
    sinks=[sink_fell, sink_medium_luft, sink_medium_flussigkeit, sink_dogbone],
)

if __name__ == "__main__":
    model = system.to_model()
    add_default_queues_to_production_system(model, reset=False)

    model.seed = 1

    runner_instance = prodsys.runner.Runner(
        production_system_data=model,
    )
    runner_instance.initialize_simulation()

    runner_instance.run(500)
    runner_instance.print_results()
    runner_instance.plot_results()
    runner_instance.save_results_as_csv()

    # Übersicht: welche Ressourcen erscheinen in den Ergebnissen?
    pp = runner_instance.get_post_processor()
    df_states = pp.df_aggregated_resource_states
    resources_in_output = df_states["Resource"].unique().tolist()
    expected_resources = [
        "Stanze",
        "Zugmaschine",
        "Medienlagerung_Luft",
        "Medienlagerung_Flussigkeit",
        "Laborant_1",
        "Laborant_2",
    ]
    print("\n------------- Ressourcen-Check -------------")
    print("Erwartet (alle sollten aktiv vorkommen):", expected_resources)
    print("In Ergebnissen vorhanden:", resources_in_output)
    missing = [r for r in expected_resources if r not in resources_in_output]
    if missing:
        print("Fehlend in Ausgabe (evtl. nie genutzt oder nicht geloggt):", missing)
    else:
        print("Alle erwarteten Ressourcen sind in der Ausgabe.")