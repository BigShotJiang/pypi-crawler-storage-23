"""
Contains utility functions for the prodsys package.
"""
