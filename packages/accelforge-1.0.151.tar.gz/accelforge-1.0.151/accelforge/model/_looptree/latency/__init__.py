from .latency import get_latency

__all__ = [
    "get_latency",
]
