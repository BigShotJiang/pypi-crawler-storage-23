# Nexus Documentation

## Getting Started

- [Getting Started](getting-started.md) — Install, configure, first index and search

## User Guide

- [CLI Reference](cli-reference.md) — Every command, every flag
- [Storage Tiers](storage-tiers.md) — T1/T2/T3 architecture and data flow
- [Project Management](project-management.md) — Progress tracking, blockers, archive, session integration
- [Repo Indexing](repo-indexing.md) — Smart file classification, chunking, frecency
- [Configuration](configuration.md) — Config hierarchy, .nexus.yml, settings

## RDR (Research-Design-Review)

- [RDR Documentation](rdr/README.md) — Overview, workflow, Nexus integration, template reference

## Development

- [Architecture](architecture.md) — Module map, design decisions
- [Contributing](contributing.md) — Dev setup, testing, code style

## Plugin

- [nx Plugin](../nx/README.md) — Claude Code plugin: agents, skills, hooks, commands

## Historical

- [Historical Documents](historical/README.md) — Original spec, architecture, and implementation plans
