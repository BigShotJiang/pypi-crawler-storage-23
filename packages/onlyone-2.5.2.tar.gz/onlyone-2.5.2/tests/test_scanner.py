"""
Unit tests for FileScannerImpl.
Verifies file discovery with size/extension filters, error handling, and edge cases.
"""
from pathlib import Path
import sys
import pytest
from onlyone.core.scanner import FileScannerImpl
from onlyone.core.grouper import FileGrouperImpl
from onlyone.core.models import DeduplicationParams, File


# =============================================================================
# 1. EXTENSION NORMALIZATION TESTS
# =============================================================================
class TestExtensionNormalization:
    """Tests for DeduplicationParams._normalize_extensions static method."""

    def test_whitelist_basic_normalization(self):
        """Whitelist: raw extensions should be normalized with dots."""
        exts, mode = DeduplicationParams._normalize_extensions(["txt", "md"])
        assert mode == "whitelist"
        assert exts == [".txt", ".md"]

    def test_whitelist_with_dots(self):
        """Whitelist: extensions with dots should remain unchanged."""
        exts, mode = DeduplicationParams._normalize_extensions([".txt", ".pdf"])
        assert mode == "whitelist"
        assert exts == [".txt", ".pdf"]

    def test_whitelist_mixed_case(self):
        """Whitelist: extensions should be lowercased."""
        exts, mode = DeduplicationParams._normalize_extensions(["TXT", "PdF"])
        assert mode == "whitelist"
        assert exts == [".txt", ".pdf"]

    def test_blacklist_mode_separate_marker(self):
        """Blacklist: '^' marker should set mode and be excluded from list."""
        exts, mode = DeduplicationParams._normalize_extensions(["^", "tmp", "log"])
        assert mode == "blacklist"
        assert exts == [".tmp", ".log"]

    def test_blacklist_attached_marker(self):
        """Blacklist: '^' attached to extension (e.g., '^tmp')."""
        exts, mode = DeduplicationParams._normalize_extensions(["^tmp", "^log"])
        assert mode == "blacklist"
        assert exts == [".tmp", ".log"]

    def test_blacklist_with_dots(self):
        """Blacklist: extensions with dots should be normalized."""
        exts, mode = DeduplicationParams._normalize_extensions(["^", ".tmp", ".log"])
        assert mode == "blacklist"
        assert exts == [".tmp", ".log"]

    def test_empty_list(self):
        """Empty list: should default to whitelist with empty extensions."""
        exts, mode = DeduplicationParams._normalize_extensions([])
        assert mode == "whitelist"
        assert exts == []

    def test_whitespace_handling(self):
        """Whitespace: should be stripped from extensions."""
        exts, mode = DeduplicationParams._normalize_extensions(["  txt  ", "  md  "])
        assert exts == [".txt", ".md"]

    def test_mixed_blacklist_markers(self):
        """Mixed '^' positions should all result in blacklist mode."""
        exts, mode = DeduplicationParams._normalize_extensions(["txt", "^", "tmp"])
        assert mode == "blacklist"
        assert exts == [".txt", ".tmp"]

    def test_empty_strings_filtered(self):
        """Empty strings should be filtered out."""
        exts, mode = DeduplicationParams._normalize_extensions(["txt", "", "  ", "md"])
        assert exts == [".txt", ".md"]


# =============================================================================
# 2. ROOT DIRECTORY NORMALIZATION TESTS
# =============================================================================
class TestRootDirNormalization:
    """Tests for DeduplicationParams._normalize_root_dirs static method."""

    def test_single_valid_directory(self, temp_dir):
        """Single valid directory should be normalized to absolute path."""
        result = DeduplicationParams._normalize_root_dirs([str(temp_dir)])
        assert len(result) == 1
        assert Path(result[0]).is_absolute()

    def test_multiple_directories(self, temp_dir):
        """Multiple directories should all be normalized."""
        subdir = temp_dir / "subdir"
        subdir.mkdir()
        result = DeduplicationParams._normalize_root_dirs([str(temp_dir), str(subdir)])
        assert len(result) == 2

    def test_duplicate_directories_removed(self, temp_dir):
        """Duplicate directories should be removed while preserving order."""
        result = DeduplicationParams._normalize_root_dirs([str(temp_dir), str(temp_dir)])
        assert len(result) == 1

    def test_nonexistent_directory_returns_empty(self, temp_dir):
        """Non-existent directory should raise ValueError."""
        nonexistent = temp_dir / "does_not_exist"
        with pytest.raises(ValueError, match="does not exist"):
            DeduplicationParams._normalize_root_dirs([str(nonexistent)])

    def test_file_as_directory_raises_error(self, temp_dir):
        """File path should raise ValueError."""
        file_path = temp_dir / "file.txt"
        file_path.write_bytes(b"content")
        with pytest.raises(ValueError, match="not a directory"):
            DeduplicationParams._normalize_root_dirs([str(file_path)])

    def test_empty_list_returns_empty(self):
        """Empty list should return empty list."""
        result = DeduplicationParams._normalize_root_dirs([])
        assert result == []

    def test_relative_paths_resolved(self, temp_dir, monkeypatch):
        """Relative paths should be resolved to absolute."""
        monkeypatch.chdir(temp_dir)
        subdir = temp_dir / "subdir"
        subdir.mkdir()
        result = DeduplicationParams._normalize_root_dirs(["subdir"])
        assert len(result) == 1
        assert Path(result[0]).is_absolute()


# =============================================================================
# 3. FILE SCANNER TESTS
# =============================================================================
class TestFileScannerImpl:
    """Test file scanning with filters and error handling."""

    def test_scans_all_files_without_filters(self, temp_dir):
        """Scanner should find all files when no filters applied."""
        (temp_dir / "file1.txt").write_bytes(b"content1")
        (temp_dir / "file2.txt").write_bytes(b"content2")
        (temp_dir / "file3.pdf").write_bytes(b"content3")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=100_000_000,
            extensions=[],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 3

    def test_filters_by_extension_whitelist(self, temp_dir):
        """Whitelist: only files with specified extensions should be included."""
        (temp_dir / "file1.txt").write_bytes(b"content1")
        (temp_dir / "file2.txt").write_bytes(b"content2")
        (temp_dir / "file3.pdf").write_bytes(b"content3")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=100_000_000,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 2
        assert all(f.extension == ".txt" for f in files)

    def test_filters_by_extension_blacklist(self, temp_dir):
        """Blacklist: files with specified extensions should be excluded."""
        (temp_dir / "file1.txt").write_bytes(b"content1")
        (temp_dir / "file2.tmp").write_bytes(b"content2")
        (temp_dir / "file3.log").write_bytes(b"content3")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=100_000_000,
            extensions=["^", ".tmp", ".log"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert files[0].extension == ".txt"

    def test_filters_by_min_size(self, temp_dir):
        """Files smaller than min_size should be excluded."""
        (temp_dir / "small.txt").write_bytes(b"A" * 100)
        (temp_dir / "large.txt").write_bytes(b"B" * 2000)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=500,
            max_size_bytes=100_000_000,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert files[0].size >= 500

    def test_filters_by_max_size(self, temp_dir):
        """Files larger than max_size should be excluded."""
        (temp_dir / "small.txt").write_bytes(b"A" * 100)
        (temp_dir / "large.txt").write_bytes(b"B" * 2000)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=500,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert files[0].size <= 500

    def test_scans_subdirectories_recursively(self, temp_dir):
        """Scanner should traverse into subdirectories by default."""
        subdir = temp_dir / "subdir"
        subdir.mkdir()
        (temp_dir / "root.txt").write_bytes(b"root")
        (subdir / "nested.txt").write_bytes(b"nested")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=100_000_000,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 2
        paths = [f.path for f in files]
        assert any("subdir" in p for p in paths)

    def test_skips_empty_files(self, temp_dir):
        """Scanner should skip zero-byte files."""
        (temp_dir / "empty.txt").write_bytes(b"")
        (temp_dir / "nonempty.txt").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=100_000_000,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        # Check by size, not by filename (more reliable)
        assert len(files) == 1
        assert all(f.size > 0 for f in files)
        assert not any(f.size == 0 for f in files)

    def test_scanner_skips_symlinks(self, temp_dir):
        """Symbolic links must be skipped to prevent duplicate processing."""
        # Create real file with known content
        real_file = temp_dir / "real.txt"
        real_file.write_bytes(b"real content here for testing")

        # Verify file was created successfully
        assert real_file.exists()
        assert real_file.is_file()
        assert real_file.stat().st_size > 0

        # Create symlink to the real file
        symlink_created = False
        try:
            symlink = temp_dir / "link.txt"
            symlink.symlink_to(real_file.resolve())
            symlink_created = symlink.is_symlink()
        except (OSError, NotImplementedError):
            pass  # Symlinks not supported on this platform

        # Scan with empty extensions to allow all files
        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)

        # Should find exactly the real file (symlink skipped)
        assert len(files) == 1
        assert "real.txt" in files[0].path
        assert files[0].size > 0

        # If symlink was created, verify it was skipped
        if symlink_created:
            assert not any("link.txt" in f.path for f in files)

    def test_scanner_skips_directory_symlinks(self, temp_dir):
        """Scanner should skip symbolic link directories."""
        real_dir = temp_dir / "real"
        real_dir.mkdir()
        (real_dir / "file.txt").write_bytes(b"content")

        link_dir = temp_dir / "link"
        link_dir.symlink_to(real_dir)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)

        # File should appear only once (not twice via symlink)
        assert len(files) == 1
        assert "real" in files[0].path

    def test_scanner_handles_permission_error(self, temp_dir, monkeypatch):
        """Scanner must gracefully skip files with PermissionError without crashing."""
        (temp_dir / "accessible.txt").write_bytes(b"ok")
        denied_file = temp_dir / "denied.txt"
        denied_file.write_bytes(b"secret")
        original_stat = Path.stat

        def mocked_stat(path_obj, *args, **kwargs):
            if str(path_obj) == str(denied_file):
                raise PermissionError(f"Permission denied: {path_obj}")
            return original_stat(path_obj, *args, **kwargs)

        monkeypatch.setattr(Path, 'stat', mocked_stat)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)

        assert len(files) == 1
        assert "accessible.txt" in files[0].path

    def test_scanner_inclusive_size_boundaries(self, temp_dir):
        """Size filters must be inclusive: min_size <= file.size <= max_size."""
        (temp_dir / "min_boundary.txt").write_bytes(b"A" * 1024)
        (temp_dir / "max_boundary.txt").write_bytes(b"B" * 2048)
        (temp_dir / "below_min.txt").write_bytes(b"C" * 1023)
        (temp_dir / "above_max.txt").write_bytes(b"D" * 2049)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=1024,
            max_size_bytes=2048,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        sizes = sorted([f.size for f in files])
        assert 1024 in sizes
        assert 2048 in sizes
        assert 1023 not in sizes
        assert 2049 not in sizes

    def test_case_insensitive_extension_filter(self, temp_dir):
        """Extension filter should be case-insensitive."""
        (temp_dir / "upper.TXT").write_bytes(b"content")
        (temp_dir / "lower.txt").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 2
        assert all(f.extension == ".txt" for f in files)

    def test_empty_directory_returns_empty_list(self, temp_dir):
        """Scanner should return empty list for empty directory."""
        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 0

    def test_multiple_root_directories(self, temp_dir):
        """Scanner should scan all provided root directories."""
        dir1 = temp_dir / "dir1"
        dir1.mkdir()
        dir2 = temp_dir / "dir2"
        dir2.mkdir()
        (dir1 / "file1.txt").write_bytes(b"content1")
        (dir2 / "file2.txt").write_bytes(b"content2")

        params = DeduplicationParams(
            root_dirs=[str(dir1), str(dir2)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 2


# =============================================================================
# 4. SYSTEM TRASH DIRECTORY TESTS
# =============================================================================
class TestSystemTrashDirectories:
    """Tests for system trash/recycle bin detection and skipping."""

    def test_skips_system_trash_directories_windows(self, temp_dir, monkeypatch):
        """Scanner must skip Windows $Recycle.Bin directories."""
        monkeypatch.setattr(sys, 'platform', 'win32')
        recycle_bin = temp_dir / "$Recycle.Bin" / "S-1-5-18"
        recycle_bin.mkdir(parents=True)
        (recycle_bin / "deleted.txt").write_bytes(b"trashed")
        (temp_dir / "normal.txt").write_bytes(b"keep me")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert "normal.txt" in files[0].path
        assert "$Recycle.Bin" not in files[0].path

    def test_skips_system_trash_directories_macos(self, temp_dir, monkeypatch):
        """Scanner must skip macOS .Trash directories."""
        monkeypatch.setattr(sys, 'platform', 'darwin')
        trash_dir = temp_dir / ".Trash"
        trash_dir.mkdir()
        (trash_dir / "deleted.jpg").write_bytes(b"trashed")
        (temp_dir / "normal.jpg").write_bytes(b"keep me")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".jpg"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert "normal.jpg" in files[0].path
        assert ".Trash" not in files[0].path

    def test_skips_system_trash_directories_linux(self, temp_dir, monkeypatch):
        """Scanner must skip Linux .local/share/Trash directories."""
        monkeypatch.setattr(sys, 'platform', 'linux')
        trash_dir = temp_dir / ".local" / "share" / "Trash"
        trash_dir.mkdir(parents=True)
        (trash_dir / "deleted.pdf").write_bytes(b"trashed")
        (temp_dir / "normal.pdf").write_bytes(b"keep me")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".pdf"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert "normal.pdf" in files[0].path
        assert "Trash" not in files[0].path


# =============================================================================
# 5. FAVOURITE DIRECTORIES TESTS
# =============================================================================
class TestFavouriteDirectories:
    """Tests for favourite directory detection and marking."""

    def test_favourite_dirs_status_set_during_scan(self, temp_dir):
        """Files in favourite directories must have is_from_fav_dir=True after scan."""
        fav_dir = temp_dir / "favourites"
        fav_dir.mkdir()
        normal_dir = temp_dir / "normal"
        normal_dir.mkdir()
        (fav_dir / "fav.txt").write_bytes(b"content")
        (normal_dir / "normal.txt").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[str(fav_dir)],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        files_by_name = {Path(f.path).name: f for f in files}
        assert files_by_name["fav.txt"].is_from_fav_dir is True
        assert files_by_name["normal.txt"].is_from_fav_dir is False


# =============================================================================
# 6. EXCLUDED DIRECTORIES TESTS
# =============================================================================
class TestExcludedDirectories:
    """Tests for excluded directory functionality."""

    def test_excluded_dirs_are_skipped(self, temp_dir):
        """Files in excluded directories should be skipped."""
        excluded_subdir = temp_dir / "excluded"
        excluded_subdir.mkdir()
        (excluded_subdir / "file.txt").write_bytes(b"content")
        (temp_dir / "included.txt").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[],
            favourite_dirs=[],
            excluded_dirs=[str(excluded_subdir)]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert "included.txt" in files[0].path
        assert "excluded" not in files[0].path

    def test_excluded_dirs_takes_precedence_over_favourite_dirs(self, temp_dir):
        """If a directory is both excluded and favourite, excluded must win."""
        special_dir = temp_dir / "special"
        special_dir.mkdir()
        (special_dir / "file.txt").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[str(special_dir)],
            excluded_dirs=[str(special_dir)]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 0


# =============================================================================
# 7. PATH DEPTH AND METADATA TESTS
# =============================================================================
class TestPathDepthAndMetadata:
    """Tests for file metadata like path_depth, extension, name."""

    def test_path_depth_field_set_correctly(self, temp_dir):
        """File.path_depth must reflect actual directory nesting level."""
        root_file = temp_dir / "root.txt"
        root_file.write_bytes(b"content")
        subdir = temp_dir / "level1"
        subdir.mkdir()
        level1_file = subdir / "level1.txt"
        level1_file.write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        files_by_name = {Path(f.path).name: f for f in files}

        root_depth = files_by_name["root.txt"].path_depth
        assert files_by_name["level1.txt"].path_depth > root_depth

    def test_extension_extracted_automatically(self, temp_dir):
        """File extension should be extracted from path automatically."""
        (temp_dir / "file.TXT").write_bytes(b"content")

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=lambda: False)
        assert len(files) == 1
        assert files[0].extension == ".txt"  # Lowercase
        assert files[0].name == "file.TXT"  # Original case preserved


# =============================================================================
# 8. CANCELLATION AND PROGRESS TESTS
# =============================================================================
class TestCancellationAndProgress:
    """Tests for stopped_flag and progress_callback functionality."""

    def test_stopped_flag_during_scan(self, temp_dir):
        """Scanner must respect stopped_flag during scanning."""
        for i in range(10):
            subdir = temp_dir / f"dir{i}"
            subdir.mkdir()
            (subdir / f"file{i}.txt").write_bytes(b"content")

        call_count = 0
        def stopped_flag():
            nonlocal call_count
            call_count += 1
            return call_count > 3

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        files = scanner.scan(stopped_flag=stopped_flag)

        assert call_count <= 5
        assert len(files) < 10

    def test_progress_callback_called(self, temp_dir):
        """Progress callback should be called during scanning."""
        for i in range(100):
            (temp_dir / f"file{i}.txt").write_bytes(b"content")

        progress_calls = []

        def progress_callback(stage, current, total):
            progress_calls.append((stage, current, total))

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1024 * 1024,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        scanner = FileScannerImpl(params=params)
        scanner.scan(progress_callback=progress_callback)  # ← FIXED: removed unused 'files ='

        assert len(progress_calls) > 0
        assert any(call[0] == 'scanning' for call in progress_calls)


# =============================================================================
# 9. DEDUPLICATION PARAMS VALIDATION TESTS
# =============================================================================
class TestDeduplicationParamsValidation:
    """Tests for DeduplicationParams validation logic."""

    def test_params_validation_empty_root(self):
        """Should raise ValueError for empty root directory list."""
        with pytest.raises(ValueError, match="No valid root directories"):
            DeduplicationParams(
                root_dirs=[],
                min_size_bytes=0,
                max_size_bytes=1000000
            )

    def test_params_validation_negative_min_size(self, temp_dir):
        """
        Should raise ValueError for negative min_size.
        FIX: Use valid temp_dir for root_dirs so validation reaches min_size check.
        """
        # root_dirs must exist, otherwise validation fails at root_dirs check first
        with pytest.raises(ValueError, match="Minimum size cannot be negative"):
            DeduplicationParams(
                root_dirs=[str(temp_dir)],  # Use valid directory
                min_size_bytes=-1,
                max_size_bytes=1000000
            )

    def test_params_validation_max_less_than_min(self, temp_dir):
        """
        Should raise ValueError when max_size < min_size.
        FIX: Use valid temp_dir for root_dirs so validation reaches max_size check.
        """
        # root_dirs must exist, otherwise validation fails at root_dirs check first
        with pytest.raises(ValueError, match="Maximum size cannot be less than minimum size"):
            DeduplicationParams(
                root_dirs=[str(temp_dir)],  # Use valid directory
                min_size_bytes=1000,
                max_size_bytes=500
            )

    def test_params_normalized_properties(self, temp_dir):
        """Normalized properties should return processed values."""
        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1000000,
            extensions=["TXT", "md"]
        )
        assert params.normalized_extensions == [".txt", ".md"]
        assert params.extension_filter_mode == "whitelist"
        assert len(params.normalized_root_dirs) == 1
        assert Path(params.normalized_root_dirs[0]).is_absolute()


# =============================================================================
# 10. BOOST MODE TESTS (Grouper)
# =============================================================================
class TestBoostModes:
    """
    Tests for different boost modes in initial grouping.
    NOTE: FileGrouperImpl._group_by() filters out groups with < 2 files!
    Tests must create actual duplicates to form valid groups.
    """

    def test_boost_mode_same_size(self, temp_dir):
        """BoostMode.SAME_SIZE should group only by size (requires 2+ files per group)."""

        file1 = File(path=str(temp_dir / "a.txt"), size=100)
        file2 = File(path=str(temp_dir / "b.txt"), size=100)  # Same size = duplicate
        file3 = File(path=str(temp_dir / "c.txt"), size=100)  # Same size = duplicate
        file4 = File(path=str(temp_dir / "d.txt"), size=200)  # Different size
        file5 = File(path=str(temp_dir / "e.txt"), size=200)  # Same size = duplicate

        grouper = FileGrouperImpl()
        size_groups = grouper.group_by_size([file1, file2, file3, file4, file5])

        # Only groups with 2+ files are returned
        assert len(size_groups) == 2  # One group for 100 bytes (3 files), one for 200 bytes (2 files)
        assert len(size_groups[100]) == 3
        assert len(size_groups[200]) == 2

    def test_boost_mode_same_size_plus_ext(self, temp_dir):
        """BoostMode.SAME_SIZE_PLUS_EXT should group by size and extension."""

        # Create duplicates with same size but different extensions
        file1 = File(path=str(temp_dir / "a.txt"), size=100)
        file2 = File(path=str(temp_dir / "b.txt"), size=100)  # Same size + ext
        file3 = File(path=str(temp_dir / "c.pdf"), size=100)  # Same size, diff ext
        file4 = File(path=str(temp_dir / "d.pdf"), size=100)  # Same size + ext

        grouper = FileGrouperImpl()
        groups = grouper.group_by_size_and_extension([file1, file2, file3, file4])

        # .txt and .pdf should be in separate groups (both have 2+ files)
        assert len(groups) == 2

    def test_boost_mode_same_size_plus_filename(self, temp_dir):
        """BoostMode.SAME_SIZE_PLUS_FILENAME should group by size and exact name."""
        file1 = File(path=str(temp_dir / "doc.txt"), size=100)
        file2 = File(path=str(temp_dir / "sub/doc.txt"), size=100)  # Same name + size
        file3 = File(path=str(temp_dir / "other.txt"), size=100)  # Different name
        file4 = File(path=str(temp_dir / "sub/other.txt"), size=100)  # Same name + size

        grouper = FileGrouperImpl()
        groups = grouper.group_by_size_and_name([file1, file2, file3, file4])

        # doc.txt and other.txt should be in separate groups
        assert len(groups) == 2

    def test_boost_mode_fuzzy_filename(self, temp_dir):
        """BoostMode.SAME_SIZE_PLUS_FUZZY_FILENAME should normalize names."""
        from onlyone.core.normalizer import normalize_filename

        # These should normalize to the same name
        name1 = normalize_filename("DSC_0001.JPG")
        name2 = normalize_filename("DSC_0001Copy2.JPG")
        name3 = normalize_filename("DSC_0001 (1).JPG")

        assert name1 == name2
        assert name1 == name3

        # Test with actual files
        file1 = File(path=str(temp_dir / "DSC_0001.JPG"), size=100)
        file2 = File(path=str(temp_dir / "DSC_0001Copy2.JPG"), size=100)
        file3 = File(path=str(temp_dir / "DSC_0002.JPG"), size=100)  # Different base name

        grouper = FileGrouperImpl()
        groups = grouper.group_by_size_and_normalized_name([file1, file2, file3])

        # DSC_0001 variants should be in one group, DSC_0002 in another (but only 1 file)
        # Since DSC_0002 has only 1 file, it won't be in the result
        assert len(groups) == 1
        assert len(groups[(100, name1)]) == 2


# =============================================================================
# 11. INTEGRATION TESTS (DeduplicationCommand)
# =============================================================================
class TestDeduplicationCommandIntegration:
    """End-to-end tests through DeduplicationCommand."""

    def test_command_whitelist_mode(self, temp_dir):
        """Command: whitelist should only scan allowed extensions."""
        from onlyone.commands import DeduplicationCommand
        content = b"duplicate content"
        (temp_dir / "file1.txt").write_bytes(content)
        (temp_dir / "file2.txt").write_bytes(content)
        (temp_dir / "file3.pdf").write_bytes(content)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1000000,
            extensions=[".txt"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        command = DeduplicationCommand()
        groups, stats = command.execute(params)

        all_files = []
        for group in groups:
            for f in group.files:
                all_files.append(f.path)

        if all_files:
            assert any(".txt" in f for f in all_files)
            assert not any(".pdf" in f for f in all_files)

    def test_command_blacklist_mode(self, temp_dir):
        """Command: blacklist should exclude specified extensions."""
        from onlyone.commands import DeduplicationCommand
        content = b"duplicate content"
        (temp_dir / "file1.txt").write_bytes(content)
        (temp_dir / "file2.txt").write_bytes(content)
        (temp_dir / "cache.tmp").write_bytes(content)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1000000,
            extensions=["^", ".tmp"],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        command = DeduplicationCommand()
        groups, stats = command.execute(params)

        all_files = []
        for group in groups:
            for f in group.files:
                all_files.append(f.path)

        if all_files:
            assert not any(".tmp" in f for f in all_files)

    def test_command_empty_extensions_allows_all(self, temp_dir):
        """Command: empty extensions should allow all file types."""
        from onlyone.commands import DeduplicationCommand
        content = b"duplicate content"
        (temp_dir / "file1.txt").write_bytes(content)
        (temp_dir / "file2.txt").write_bytes(content)

        params = DeduplicationParams(
            root_dirs=[str(temp_dir)],
            min_size_bytes=0,
            max_size_bytes=1000000,
            extensions=[],
            favourite_dirs=[],
            excluded_dirs=[]
        )
        command = DeduplicationCommand()
        groups, stats = command.execute(params)

        assert isinstance(groups, list)
        assert hasattr(stats, 'total_time')