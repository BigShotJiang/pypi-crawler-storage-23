from amstools.resources.prototypes import (
    get_structures_dictionary,
    get_color_for_prototype,
    get_color_for_strukturbericht,
)
from amstools.resources.data import get_resources_filenames_by_glob, get_data_path
