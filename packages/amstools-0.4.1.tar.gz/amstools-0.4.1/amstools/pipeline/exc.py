class PausedException(Exception):
    pass
