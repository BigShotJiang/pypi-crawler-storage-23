# Legacy module - wrapper classes have been removed.
# Old class names are resolved via CLASS_ALIASES in pipelinestep.py
# for backward compatibility with serialized pipeline.json files.
