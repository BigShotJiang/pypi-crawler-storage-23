# autoML uses databricks.feature_store.entities.feature_spec alias
from databricks.ml_features_common.entities.feature_spec import FeatureSpec

__all__ = ["FeatureSpec"]
