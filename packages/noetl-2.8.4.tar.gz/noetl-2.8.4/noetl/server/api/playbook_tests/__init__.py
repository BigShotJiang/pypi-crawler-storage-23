"""Playbook test suite API package."""

from .endpoint import router

__all__ = ["router"]

