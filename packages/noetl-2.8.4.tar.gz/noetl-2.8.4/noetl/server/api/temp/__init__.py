"""
TempRef REST API module.

Provides endpoints for temp storage operations.
"""

from noetl.server.api.temp.endpoint import router

__all__ = ["router"]
