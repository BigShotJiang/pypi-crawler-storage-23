from .endpoint import router

__all__ = [
    'router',
]
