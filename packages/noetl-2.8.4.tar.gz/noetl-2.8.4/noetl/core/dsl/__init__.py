"""
Core DSL utilities (rendering, schema, and models).
"""

