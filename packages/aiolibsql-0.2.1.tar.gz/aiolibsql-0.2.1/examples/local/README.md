# Local

This example demonstrates how to use aiolibsql with a local SQLite file.

## Install

```bash
pip install "aiolibsql @ git+https://github.com/fuhnut/aiolibsql"
```

## Running

```bash
python3 main.py
```
