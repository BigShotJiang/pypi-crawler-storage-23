# Batch (executescript)

This example demonstrates how to execute multiple SQL statements in a single batch.

## Install

```bash
pip install "aiolibsql @ git+https://github.com/fuhnut/aiolibsql"
```

## Running

```bash
python3 main.py
```
