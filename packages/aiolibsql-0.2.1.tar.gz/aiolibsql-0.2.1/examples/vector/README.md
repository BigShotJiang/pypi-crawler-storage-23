# Vector Search

This example demonstrates vector similarity search using libSQL's built-in vector extensions.

## Install

```bash
pip install "aiolibsql @ git+https://github.com/fuhnut/aiolibsql"
```

## Running

```bash
python3 main.py
```
