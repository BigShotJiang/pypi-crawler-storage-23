"""
aiolibsql — Comprehensive CLI Test
Tests every exposed function and property of the aiolibsql library.
"""

import asyncio
import aiolibsql

PASS = "✅"
FAIL = "❌"
results = []

def report(name: str, passed: bool, detail: str = ""):
    status = PASS if passed else FAIL
    results.append((name, passed))
    msg = f"  {status} {name}"
    if detail:
        msg += f"  →  {detail}"
    print(msg)

async def main():
    print("=" * 60)
    print("  aiolibsql — Full API Test Suite (v0.2.0)")
    print("=" * 60)

    print("\n── Module Functions ──")

    try:
        conn = await aiolibsql.connect(":memory:")
        report("connect()", True, "in-memory database opened")
    except Exception as e:
        report("connect()", False, str(e))
        return

    print("\n── Connection Properties ──")

    try:
        il = conn.isolation_level
        report("isolation_level (getter)", True, f"value={il!r}")
    except Exception as e:
        report("isolation_level (getter)", False, str(e))

    try:
        ac = conn.autocommit
        report("autocommit (getter)", True, f"value={ac}")
    except Exception as e:
        report("autocommit (getter)", False, str(e))

    try:
        conn.autocommit = 1
        assert conn.autocommit == 1
        conn.autocommit = 0
        assert conn.autocommit == 0
        conn.autocommit = aiolibsql.LEGACY_TRANSACTION_CONTROL
        report("autocommit (setter)", True, "set to 1, 0, and LEGACY")
    except Exception as e:
        report("autocommit (setter)", False, str(e))

    try:
        it = conn.in_transaction
        report("in_transaction (getter)", True, f"value={it}")
    except Exception as e:
        report("in_transaction (getter)", False, str(e))

    print("\n── Cursor Creation ──")

    try:
        cur = conn.cursor()
        report("cursor()", True, f"type={type(cur).__name__}")
    except Exception as e:
        report("cursor()", False, str(e))

    print("\n── Connection.execute() ──")

    try:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS test_table (
                id    INTEGER PRIMARY KEY AUTOINCREMENT,
                name  TEXT NOT NULL,
                age   INTEGER,
                score REAL,
                data  BLOB
            )
        """)
        report("execute() — CREATE TABLE", True)
    except Exception as e:
        report("execute() — CREATE TABLE", False, str(e))

    try:
        cursor = await conn.execute(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            ("Alice", 28, 95.5),
        )
        report("execute() — INSERT (tuple params)", True)
    except Exception as e:
        report("execute() — INSERT (tuple params)", False, str(e))

    try:
        cursor = await conn.execute(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            ["Bob", 34, 88.0],
        )
        report("execute() — INSERT (list params)", True)
    except Exception as e:
        report("execute() — INSERT (list params)", False, str(e))

    try:
        await conn.execute(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            ("Charlie", None, None),
        )
        report("execute() — INSERT (NULL values)", True)
    except Exception as e:
        report("execute() — INSERT (NULL values)", False, str(e))

    try:
        await conn.execute(
            "INSERT INTO test_table (name, age, score, data) VALUES (?, ?, ?, ?)",
            ("Diana", 22, 91.0, b"\x00\x01\x02\x03"),
        )
        report("execute() — INSERT (BLOB data)", True)
    except Exception as e:
        report("execute() — INSERT (BLOB data)", False, str(e))

    try:
        cursor = await conn.execute("SELECT * FROM test_table")
        report("execute() — SELECT", True)
    except Exception as e:
        report("execute() — SELECT", False, str(e))

    try:
        await conn.execute(
            "UPDATE test_table SET age = ? WHERE name = ?", (29, "Alice")
        )
        report("execute() — UPDATE", True)
    except Exception as e:
        report("execute() — UPDATE", False, str(e))

    try:
        await conn.execute("DELETE FROM test_table WHERE name = ?", ("Charlie",))
        report("execute() — DELETE", True)
    except Exception as e:
        report("execute() — DELETE", False, str(e))

    print("\n── Connection.executemany() ──")

    try:
        await conn.executemany(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            [
                ("Eve", 30, 77.0),
                ("Frank", 41, 62.5),
                ("Grace", 25, 99.9),
            ],
        )
        report("executemany()", True, "inserted 3 rows")
    except Exception as e:
        report("executemany()", False, str(e))

    print("\n── Connection.executescript() ──")

    try:
        await conn.executescript("""
            CREATE TABLE IF NOT EXISTS script_table (x INTEGER);
            INSERT INTO script_table VALUES (1);
            INSERT INTO script_table VALUES (2);
            INSERT INTO script_table VALUES (3);
        """)
        report("executescript()", True, "ran multi-statement script")
    except Exception as e:
        report("executescript()", False, str(e))

    print("\n── Cursor.execute() ──")

    try:
        cur = conn.cursor()
        cur = await cur.execute("SELECT * FROM test_table ORDER BY id")
        report("Cursor.execute()", True)
    except Exception as e:
        report("Cursor.execute()", False, str(e))

    print("\n── Cursor.fetchall() ──")

    try:
        rows = await cur.fetchall()
        report("Cursor.fetchall()", True, f"got {len(rows)} rows")
        print("    Data:")
        for row in rows:
            print(f"      {row}")
    except Exception as e:
        report("Cursor.fetchall()", False, str(e))

    print("\n── Cursor.fetchone() ──")

    try:
        cur = conn.cursor()
        cur = await cur.execute("SELECT * FROM test_table ORDER BY id LIMIT 3")
        row = await cur.fetchone()
        report("Cursor.fetchone()", True, f"first row = {row}")

        await cur.fetchone()
        await cur.fetchone()
        none_row = await cur.fetchone()
        report("Cursor.fetchone() — exhausted", none_row is None, f"value={none_row!r}")
    except Exception as e:
        report("Cursor.fetchone()", False, str(e))

    print("\n── Cursor.fetchmany() ──")

    try:
        cur = conn.cursor()
        cur = await cur.execute("SELECT * FROM test_table ORDER BY id")
        batch = await cur.fetchmany(2)
        report("Cursor.fetchmany(size=2)", True, f"got {len(batch)} rows")

        batch2 = await cur.fetchmany()
        report("Cursor.fetchmany() — default size", True, f"got {len(batch2)} rows")
    except Exception as e:
        report("Cursor.fetchmany()", False, str(e))

    print("\n── Cursor.arraysize ──")

    try:
        cur = conn.cursor()
        default = cur.arraysize
        cur.arraysize = 5
        report("Cursor.arraysize (get/set)", True, f"default={default}, set to {cur.arraysize}")
    except Exception as e:
        report("Cursor.arraysize", False, str(e))

    print("\n── Cursor.description ──")

    try:
        cur = conn.cursor()
        cur = await cur.execute("SELECT id, name, age, score FROM test_table LIMIT 1")
        desc = cur.description
        report("Cursor.description", desc is not None, f"columns={[d[0] for d in desc] if desc else None}")
    except Exception as e:
        report("Cursor.description", False, str(e))

    print("\n── Cursor.lastrowid ──")

    try:
        cur = conn.cursor()
        cur = await cur.execute(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            ("Heidi", 27, 85.0),
        )
        rid = cur.lastrowid
        report("Cursor.lastrowid", rid is not None, f"value={rid}")
    except Exception as e:
        report("Cursor.lastrowid", False, str(e))

    print("\n── Cursor.rowcount ──")

    try:
        rc = cur.rowcount
        report("Cursor.rowcount", True, f"value={rc}")
    except Exception as e:
        report("Cursor.rowcount", False, str(e))

    print("\n── Cursor.executemany() ──")

    try:
        cur = conn.cursor()
        cur = await cur.executemany(
            "INSERT INTO test_table (name, age, score) VALUES (?, ?, ?)",
            [("Ivan", 33, 70.0), ("Judy", 29, 80.0)],
        )
        report("Cursor.executemany()", True, "inserted 2 rows via cursor")
    except Exception as e:
        report("Cursor.executemany()", False, str(e))

    print("\n── Cursor.executescript() ──")

    try:
        cur = conn.cursor()
        cur = await cur.executescript("""
            CREATE TABLE IF NOT EXISTS cur_script (val TEXT);
            INSERT INTO cur_script VALUES ('hello');
            INSERT INTO cur_script VALUES ('world');
        """)
        report("Cursor.executescript()", True)
    except Exception as e:
        report("Cursor.executescript()", False, str(e))

    print("\n── Connection.commit() ──")

    try:
        await conn.commit()
        report("commit()", True)
    except Exception as e:
        report("commit()", False, str(e))

    print("\n── Connection.rollback() ──")

    try:
        await conn.rollback()
        report("rollback()", True)
    except Exception as e:
        report("rollback()", False, str(e))

    print("\n── Cursor.close() ──")

    try:
        cur = conn.cursor()
        await cur.close()
        report("Cursor.close()", True)
    except Exception as e:
        report("Cursor.close()", False, str(e))

    print("\n── Connection.close() ──")

    try:
        await conn.close()
        report("Connection.close()", True)
    except Exception as e:
        report("Connection.close()", False, str(e))

    print("\n── Async Context Manager ──")

    try:
        async with await aiolibsql.connect(":memory:") as ctx_conn:
            await ctx_conn.execute("CREATE TABLE ctx_test (id INTEGER)")
            await ctx_conn.execute("INSERT INTO ctx_test VALUES (?)", (42,))
            cursor = await ctx_conn.execute("SELECT * FROM ctx_test")
            rows = await cursor.fetchall()
            assert rows[0][0] == 42
        report("async with (__aenter__/__aexit__)", True, "context manager works")
    except Exception as e:
        report("async with (__aenter__/__aexit__)", False, str(e))

    print("\n── ConnectionPool API ──")

    try:
        pool = await aiolibsql.create_pool(":memory:", size=5)
        report("create_pool()", True, "pool initialized with size=5")
    except Exception as e:
        report("create_pool()", False, str(e))
        pool = None

    if pool:
        try:
            await pool.execute("CREATE TABLE pool_test (id INTEGER PRIMARY KEY, val TEXT)")
            report("pool.execute() — DDL", True)
        except Exception as e:
            report("pool.execute() — DDL", False, str(e))

        try:
            await pool.execute("INSERT INTO pool_test (val) VALUES (?)", ("hello",))
            report("pool.execute() — INSERT", True)
        except Exception as e:
            report("pool.execute() — INSERT", False, str(e))

        try:
            cursor = await pool.execute("SELECT * FROM pool_test")
            row = cursor.fetchone()
            report("pool.execute() — SELECT / fetchone (sync)", row is not None and row[1] == "hello", f"row={row}")
        except Exception as e:
            report("pool.execute() — SELECT", False, str(e))

        try:
            await pool.executemany(
                "INSERT INTO pool_test (val) VALUES (?)",
                [("a",), ("b",), ("c",)]
            )
            report("pool.executemany()", True, "inserted 3 rows")
        except Exception as e:
            report("pool.executemany()", False, str(e))

        try:
            await pool.executebatch([
                ("INSERT INTO pool_test (val) VALUES (?)", ("batch1",)),
                ("INSERT INTO pool_test (val) VALUES (?)", ("batch2",)),
                ("UPDATE pool_test SET val = ? WHERE val = ?", ("updated", "batch1")),
            ])
            report("pool.executebatch()", True, "ran atomic batch of 3 statements")
        except Exception as e:
            report("pool.executebatch()", False, str(e))

        try:
            async with pool:
                report("pool async with", True)
        except Exception as e:
            report("pool async with", False, str(e))

        try:
            await pool.close()
            report("pool.close()", True)
        except Exception as e:
            report("pool.close()", False, str(e))

    print("\n── Module Constants ──")

    try:
        ltc = aiolibsql.LEGACY_TRANSACTION_CONTROL
        report("LEGACY_TRANSACTION_CONTROL", ltc == -1, f"value={ltc}")
    except Exception as e:
        report("LEGACY_TRANSACTION_CONTROL", False, str(e))

    try:
        ps = aiolibsql.paramstyle
        report("paramstyle", ps == "qmark", f"value={ps!r}")
    except Exception as e:
        report("paramstyle", False, str(e))

    try:
        svi = aiolibsql.sqlite_version_info
        report("sqlite_version_info", True, f"value={svi}")
    except Exception as e:
        report("sqlite_version_info", False, str(e))

    try:
        err = aiolibsql.Error
        report("Error exception class", err is not None, f"type={err}")
    except Exception as e:
        report("Error exception class", False, str(e))

    try:
        ver = aiolibsql.VERSION
        report("VERSION", isinstance(ver, str) and len(ver) > 0, f"value={ver!r}")
    except Exception as e:
        report("VERSION", False, str(e))

    print("\n" + "=" * 60)
    passed = sum(1 for _, p in results if p)
    total = len(results)
    print(f"  Results: {passed}/{total} passed")
    if passed == total:
        print("  🎉 ALL TESTS PASSED!")
    else:
        print("  ⚠️  Some tests failed:")
        for name, p in results:
            if not p:
                print(f"    {FAIL} {name}")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(main())
