def test_ok() -> None:
    assert 1 == 1  # noqa: PLR0133
