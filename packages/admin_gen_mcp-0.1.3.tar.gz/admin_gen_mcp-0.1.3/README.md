# Admin Gen MCP

Vue 3 + Element Plus 前端 & Spring Boot + MyBatis-Plus 后端 全栈代码生成器，基于 MCP 协议。

## 功能

- **前端生成**：api.ts, options.ts, index.vue, form.vue
- **后端生成**：Entity, Controller, Service, ServiceImpl, Mapper, Mapper.xml
- **全栈生成**：一份 JSON 配置同时生成前端 + 后端（自动类型映射）
- 支持主表 + 多子表
- 支持字典配置
- 代码直接保存到磁盘，返回文件路径列表
- 调用阿里云 qwen3-max 模型生成代码

## 快速开始

### 前提条件

- 阿里云 DashScope API Key（[获取地址](https://dashscope.console.aliyun.com/)）
- 安装方式二选一：
  - **uvx（推荐）**：需安装 [uv](https://docs.astral.sh/uv/)，无需手动安装包
  - **pip**：需 Python >= 3.10

### 安装 uv（如果选择 uvx 方式）

```bash
# Windows (PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# 或通过 pip
pip install uv
```

### 安装包（如果选择 pip 方式）

```bash
pip install admin-gen-mcp
```

## IDE 配置

所有 IDE 的 MCP 配置中都需要设置 `DASHSCOPE_API_KEY` 环境变量。将 `your-api-key` 替换为你的阿里云 DashScope API Key。

### Trae IDE

Trae 主界面 → AI 面板 → 右上角设置 → MCP → 添加 → 手动配置：

**uvx 方式（推荐）：**

```json
{
  "mcpServers": {
    "admin-gen": {
      "command": "uvx",
      "args": ["admin-gen-mcp"],
      "env": {
        "DASHSCOPE_API_KEY": "your-api-key"
      }
    }
  }
}
```

**pip 方式：**

```json
{
  "mcpServers": {
    "admin-gen": {
      "command": "cmd",
      "args": ["/c", "admin-gen-mcp"],
      "env": {
        "DASHSCOPE_API_KEY": "your-api-key"
      }
    }
  }
}
```

> 配置保存后选择智能体 **Builder with MCP**。
>
> 详细使用文档见 [TRAE_GUIDE.md](./TRAE_GUIDE.md)

### Claude Code

```bash
# uvx 方式（推荐）
claude mcp add admin-gen -- uvx admin-gen-mcp
# 然后设置环境变量 DASHSCOPE_API_KEY

# pip 方式
claude mcp add-json admin-gen '{"type":"stdio","command":"admin-gen-mcp","env":{"DASHSCOPE_API_KEY":"your-api-key"}}'
```

### Cursor

设置 → MCP → 添加，粘贴与 Trae 相同的 JSON 配置。

### VS Code (Copilot)

在项目根目录创建 `.vscode/mcp.json`，内容与上方 JSON 配置相同。

### Windsurf

设置 → MCP → 添加配置，内容与上方 JSON 配置相同。

## 命令行工具

```bash
# 从 JSON 配置文件生成前端代码
admin-gen --config fields/example.json

# 交互模式
admin-gen -i
```

## Python API

```python
from admin_gen_mcp.generator import CodeGenerator

gen = CodeGenerator(api_key="your-api-key")
config = gen.load_config("fields/example.json")

# 全栈生成
results = gen.generate_fullstack(config)
print(results["frontend"])  # 前端 4 个文件
print(results["backend"])   # 后端 6~9 个文件
```

## MCP 工具列表

| 工具 | 说明 |
|------|------|
| `generate_admin_page` | 前端代码生成（直接传字段参数） |
| `generate_from_config` | 前端代码生成（JSON 配置文件路径） |
| `generate_backend_code` | 后端代码生成（直接传字段参数） |
| `generate_fullstack` | 前后端一体生成（JSON 配置文件路径） |

## 配置文件格式

```json
{
  "功能名称": "员工培训申请",
  "模块路径": "hr/trainApplication",
  "权限前缀": "hr_trainapplication",
  "输出目录": "src/views",

  "主表字段": [
    {
      "label": "培训主题",
      "key": "trainTitle",
      "type": "input",
      "required": true,
      "show": true,
      "alwaysHide": false,
      "smart": true,
      "width": "200"
    }
  ],

  "子表配置": [
    {
      "名称": "参训人员明细",
      "标识": "detail",
      "实体名称": "TrainApplicationDetail",
      "字段列表": [...]
    }
  ],

  "字典配置": [
    { "key": "trainType", "dict": "hr_train_type", "import": "/@/enums/dict" }
  ]
}
```

## 字段类型映射

| 前端 type | 前端组件 | Java 类型 |
|-----------|---------|-----------|
| input | el-input | String |
| textarea | el-input[textarea] | String |
| select | el-select | String |
| date | el-date-picker | LocalDate |
| datetime | el-date-picker | LocalDateTime |
| number | microme-operator | BigDecimal |
| upload | upload-file | String |

## License

MIT
