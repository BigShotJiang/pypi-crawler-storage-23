"""
Admin Page Generator MCP Server
Vue 3 + Element Plus 后台管理页面代码生成器
"""

__version__ = "0.1.3"
