package com.worsoft.worsoft.hr.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.worsoft.worsoft.common.data.base.BaseService;
import com.worsoft.worsoft.common.core.constant.ErrorConstants;
import com.worsoft.worsoft.common.core.util.R;
import com.worsoft.worsoft.common.data.base.BaseProcessController;
import com.worsoft.worsoft.common.data.dto.PageDto;
import com.worsoft.worsoft.common.data.util.BaseQueryWrapper;
import com.worsoft.worsoft.common.data.util.WrapperBuilder;
import com.worsoft.worsoft.common.excel.annotation.ResponseExcel;
import com.worsoft.worsoft.common.excel.dto.ExportExcelVO;
import com.worsoft.worsoft.common.log.annotation.SysLog;
import com.worsoft.worsoft.hr.entity.ContractSignBatchEntity;
import com.worsoft.worsoft.hr.service.ContractSignBatchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/contractSignBatch")
@Tag(description = "contractSignBatch", name = "合同批量签订管理")
public class ContractSignBatchController extends BaseProcessController {

	private final ContractSignBatchService contractSignBatchService;

	@Override
	protected BaseService getCurrentService() {
		return contractSignBatchService;
	}

	@Operation(summary = "通过ids删除", description = "通过ids删除")
	@SysLog("通过ids删除合同批量签订")
	@PostMapping("/removeByIds")
	public R removeByIds(@RequestBody List<Long> ids) {
		return R.ok(contractSignBatchService.deleteEditDataByIds(ids));
	}

	@Operation(summary = "分页查询", description = "分页查询")
	@GetMapping("/page")
	public R getPage(PageDto page, ContractSignBatchEntity entity) {
		BaseQueryWrapper<ContractSignBatchEntity> query = WrapperBuilder.generateQuery(entity, page);
		query.appendCreateOgnFilter();
		return R.ok(contractSignBatchService.page((Page) page, query));
	}

	@ResponseExcel
	@Operation(summary = "导出功能", description = "导出功能")
	@PostMapping("/export")
	public ExportExcelVO export(@RequestBody Map params) {
		BaseQueryWrapper<ContractSignBatchEntity> query = WrapperBuilder.generateQuery(params, ContractSignBatchEntity.class);
		query.appendCreateOgnFilter();
		List<ContractSignBatchEntity> data = contractSignBatchService.list(query);
		return new ExportExcelVO(data, params);
	}

	@Operation(summary = "通过id查询", description = "通过id查询")
	@GetMapping("/{id}")
	public R getById(@PathVariable("id") Long id) {
		return R.ok(contractSignBatchService.getById(id));
	}

	@Operation(summary = "新增", description = "新增")
	@SysLog("新增合同批量签订")
	@PostMapping
	@Transactional
	public R save(@RequestBody ContractSignBatchEntity entity) {
		contractSignBatchService.save(entity);
		return R.ok(entity);
	}

	@Operation(summary = "修改", description = "修改")
	@SysLog("修改合同批量签订")
	@PostMapping("/updateById")
	@Transactional
	public R updateById(@RequestBody ContractSignBatchEntity entity) {
		if (contractSignBatchService.updateAllColumnById(entity)) {
			return R.ok(entity);
		}
		return R.failed(ErrorConstants.DB_UPDATE_ERROR_MSG);
	}
}
