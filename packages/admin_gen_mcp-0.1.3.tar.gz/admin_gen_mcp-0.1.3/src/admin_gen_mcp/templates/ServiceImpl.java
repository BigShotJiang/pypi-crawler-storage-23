package com.worsoft.worsoft.hr.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.worsoft.worsoft.admin.feign.RemoteBillNumberService;
import com.worsoft.worsoft.common.data.base.BaseServiceImpl;
import com.worsoft.worsoft.common.core.constant.enums.BillState;
import com.worsoft.worsoft.common.security.util.SecurityUtils;
import com.worsoft.worsoft.hr.entity.ContractSignBatchDetailEntity;
import com.worsoft.worsoft.hr.entity.ContractSignBatchEntity;
import com.worsoft.worsoft.hr.mapper.ContractSignBatchDetailMapper;
import com.worsoft.worsoft.hr.mapper.ContractSignBatchMapper;
import com.worsoft.worsoft.hr.service.ContractSignBatchService;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@Service
@AllArgsConstructor
public class ContractSignBatchServiceImpl extends BaseServiceImpl<ContractSignBatchMapper, ContractSignBatchEntity> implements ContractSignBatchService {

	private final ContractSignBatchDetailMapper detailMapper;
	private final RemoteBillNumberService remoteBillNumberService;

	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean save(ContractSignBatchEntity entity) {
		super.save(entity);
		this.createDetail(entity);
		if (StrUtil.equals(BillState.FINISHED.getStatus(), entity.getBillStateId())) {
			this.processCompleted(entity.getId());
		}
		return true;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean updateAllColumnById(ContractSignBatchEntity entity) {
		super.updateAllColumnById(entity);
		this.createDetail(entity);
		if (StrUtil.equals(BillState.FINISHED.getStatus(), entity.getBillStateId())) {
			this.processCompleted(entity.getId());
		}
		return true;
	}

	// 子表保存：先删后插
	private void createDetail(ContractSignBatchEntity entity) {
		List<ContractSignBatchDetailEntity> detailList = entity.getDetailList();
		LambdaQueryWrapper<ContractSignBatchDetailEntity> query = new LambdaQueryWrapper<>();
		query.eq(ContractSignBatchDetailEntity::getMainId, entity.getId());
		detailMapper.delete(query);

		if (ObjectUtil.isNotEmpty(detailList)) {
			detailList.forEach(data -> {
				data.setMainId(entity.getId());
				data.setTenantId(SecurityUtils.getTenantId());
				data.setId(null);
			});
			detailMapper.insertBatchSomeColumn(detailList);
		}
	}

	@Override
	public ContractSignBatchEntity getById(Serializable id) {
		ContractSignBatchEntity result = super.getById(id);
		List<ContractSignBatchDetailEntity> details = detailMapper.selectList(
			new LambdaQueryWrapper<ContractSignBatchDetailEntity>()
				.eq(ContractSignBatchDetailEntity::getMainId, id)
		);
		result.setDetailList(details);
		return result;
	}

	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean removeByIds(Collection idList) {
		detailMapper.delete(
			new LambdaQueryWrapper<ContractSignBatchDetailEntity>()
				.in(ContractSignBatchDetailEntity::getMainId, idList)
		);
		return super.removeByIds(idList);
	}

	@Override
	@GlobalTransactional
	public void processCompleted(Long id) {
		ContractSignBatchEntity entity = new ContractSignBatchEntity();
		entity.setId(id);
		entity.setBillCode(SecurityUtils.getTenantCode() + remoteBillNumberService.getBillCode());
		entity.setFinishedTime(LocalDateTime.now());
		entity.updateById();
	}
}
