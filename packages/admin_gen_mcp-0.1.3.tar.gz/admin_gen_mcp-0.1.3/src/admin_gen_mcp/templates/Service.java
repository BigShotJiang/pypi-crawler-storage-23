package com.worsoft.worsoft.hr.service;

import com.worsoft.worsoft.common.data.base.BaseService;
import com.worsoft.worsoft.hr.entity.ContractSignBatchEntity;

public interface ContractSignBatchService extends BaseService<ContractSignBatchEntity> {

}
