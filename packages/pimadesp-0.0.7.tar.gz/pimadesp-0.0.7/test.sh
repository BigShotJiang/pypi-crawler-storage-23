#!/usr/bin/env fish

source nvm.sh
nvm install --lts
nvm use --lts

source uv.sh
uv run --extra tests playwright install chromium
uv run --extra tests pytest