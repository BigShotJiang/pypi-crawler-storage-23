#!/bin/bash

has_nvm() {
    if command -v nvm >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

install_nvm() {
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
    load_nvm
    if ! has_nvm; then
        echo "Failed to install nvm"
        exit 1
    fi
}

load_nvm() {
    if [ -z "$NVM_DIR" ]; then
        export NVM_DIR="$HOME/.nvm"
    fi
    [ -s "$NVM_DIR/nvm.sh" ] && source "$NVM_DIR/nvm.sh"
}

load_nvm
if ! has_nvm; then
    install_nvm
fi