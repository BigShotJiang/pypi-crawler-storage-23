import pathlib
import textwrap

from sphinx.application import Sphinx


def test_table_transformation(tmp_path):
    """Test that HTML tables are transformed to Angular Material format."""
    conf = textwrap.dedent("""
        project = "test_table"
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """)
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(conf)

    index = textwrap.dedent("""
        ==========
        Test Table
        ==========

        .. list-table:: Test Table
           :header-rows: 1
           :widths: 30 70

           * - Column A
             - Column B
           * - Value 1
             - Description 1
           * - Value 2
             - Description 2
    """)
    (srcdir / "index.rst").write_text(index)

    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    builder = "html"
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), builder)
    app.build()

    content_file = outdir / "index.html"
    content = content_file.read_text()

    # Verify Material Design table classes
    assert 'class="mat-mdc-table mdc-data-table__table mat-elevation-z2"' in content, \
        "Table should have Material Design table classes"
    assert 'data-material-table' in content, \
        "Table should have data-material-table attribute"

    # Verify header row has Material classes
    assert 'class="mat-mdc-header-row mdc-data-table__header-row"' in content, \
        "Header row should have Material Design classes"
    assert 'class="mat-mdc-header-cell mdc-data-table__header-cell"' in content, \
        "Header cells should have Material Design classes"

    # Verify data rows have Material classes
    assert 'class="mat-mdc-row mdc-data-table__row"' in content, \
        "Data rows should have Material Design classes"
    assert 'class="mat-mdc-cell mdc-data-table__cell"' in content, \
        "Data cells should have Material Design classes"

    # Verify header content
    assert 'Column A' in content, "Header should contain Column A"
    assert 'Column B' in content, "Header should contain Column B"

    # Verify data content
    assert 'Value 1' in content, "Table should contain Value 1"
    assert 'Description 1' in content, "Table should contain Description 1"
    assert 'Value 2' in content, "Table should contain Value 2"
    assert 'Description 2' in content, "Table should contain Description 2"


def test_multiple_tables(tmp_path):
    """Test that multiple tables on a page are all transformed."""
    conf = textwrap.dedent("""
        project = "test_multiple_tables"
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """)
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(conf)

    index = textwrap.dedent("""
        ==============
        Multiple Tables
        ==============

        First Table
        -----------

        .. list-table::
           :header-rows: 1

           * - A
             - B
           * - 1
             - 2

        Second Table
        ------------

        .. list-table::
           :header-rows: 1

           * - X
             - Y
           * - 3
             - 4
    """)
    (srcdir / "index.rst").write_text(index)

    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    builder = "html"
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), builder)
    app.build()

    content_file = outdir / "index.html"
    content = content_file.read_text()

    # Count the number of transformed tables. The body appears twice in the HTML
    # (once in <app-root> as a no-JS fallback, once in #static-body for Angular),
    # so 2 tables × 2 occurrences = 4.
    table_count = content.count('class="mat-mdc-table mdc-data-table__table mat-elevation-z2"')
    assert table_count == 4, f"Should have 2 transformed tables (4 occurrences), found {table_count}"


def test_table_with_code(tmp_path):
    """Test that tables with code/formatting in cells are preserved."""
    conf = textwrap.dedent("""
        project = "test_table_code"
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """)
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(conf)

    index = textwrap.dedent("""
        ================
        Table with Code
        ================

        .. list-table::
           :header-rows: 1

           * - File
             - Description
           * - ``config.py``
             - Configuration file
           * - ``index.rst``
             - Main document
    """)
    (srcdir / "index.rst").write_text(index)

    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    builder = "html"
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), builder)
    app.build()

    content_file = outdir / "index.html"
    content = content_file.read_text()

    # Verify table is transformed
    assert 'class="mat-mdc-table mdc-data-table__table mat-elevation-z2"' in content

    # Verify code formatting is preserved
    assert '<code' in content, "Code formatting should be preserved"
    assert 'config.py' in content
    assert 'index.rst' in content
