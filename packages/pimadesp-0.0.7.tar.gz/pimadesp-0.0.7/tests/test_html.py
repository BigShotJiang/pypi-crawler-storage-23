import pathlib
import textwrap

from sphinx.application import Sphinx


def test_title(tmp_path):
    conf = textwrap.dedent("""
        project = "test_html"
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """)
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(conf)
    index = textwrap.dedent("""
        ==========
        test_title
        ==========
    """)
    (srcdir / "index.rst").write_text(index)
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    builder = "html"
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), builder)
    app.build()
    html = (outdir / "index.html").read_text()
    assert "<title>test_title | test_html</title>" in html
