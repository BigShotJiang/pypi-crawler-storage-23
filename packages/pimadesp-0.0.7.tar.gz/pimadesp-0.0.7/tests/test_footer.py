import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_footer_shows_only_root_toctree(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        .. toctree::

           branch/index
    """))
    (srcdir / "branch").mkdir()
    (srcdir / "branch/index.rst").write_text(textwrap.dedent("""
        ======
        branch
        ======

        .. toctree::

           leaf
    """))
    (srcdir / "branch/leaf.rst").write_text(textwrap.dedent("""
        ====
        leaf
        ====
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)
    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    footer = page.locator("app-footer")
    # The root toctree has one entry: branch
    expect(footer.get_by_role("link", name="branch")).to_be_visible()
    # leaf is a child of branch, not in the root toctree — must not appear
    expect(footer.get_by_role("link", name="leaf")).not_to_be_visible()
