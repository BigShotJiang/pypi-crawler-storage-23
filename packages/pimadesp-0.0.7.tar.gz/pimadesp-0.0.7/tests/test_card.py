import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_card_renders(page: Page, tmp_path, live_server):
    """Test that a basic card with no title renders a mat-card element."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ==========
        Card Test
        ==========

        .. card::

           This is a basic card with no title.
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("mat-card", timeout=10000)

    card = page.locator("mat-card")
    expect(card).to_be_visible()


def test_card_with_title(page: Page, tmp_path, live_server):
    """Test that a card with a title argument renders mat-card-title containing the title text."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ==========
        Card Test
        ==========

        .. card:: My Card Title

           Card body content.
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("mat-card", timeout=10000)

    card_title = page.locator("mat-card-title")
    expect(card_title).to_be_visible()
    expect(card_title).to_have_text("My Card Title")


def test_card_with_subtitle(page: Page, tmp_path, live_server):
    """Test that a card with a :subtitle: option renders mat-card-subtitle."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ==========
        Card Test
        ==========

        .. card:: My Card Title
           :subtitle: My Card Subtitle

           Card body content.
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("mat-card", timeout=10000)

    card_subtitle = page.locator("mat-card-subtitle")
    expect(card_subtitle).to_be_visible()
    expect(card_subtitle).to_have_text("My Card Subtitle")


def test_card_body_content(page: Page, tmp_path, live_server):
    """Test that card body text appears inside mat-card-content."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ==========
        Card Test
        ==========

        .. card::

           Hello from the card body.
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("mat-card", timeout=10000)

    card_content = page.locator("mat-card-content")
    expect(card_content).to_be_visible()
    expect(card_content).to_have_text("Hello from the card body.")
