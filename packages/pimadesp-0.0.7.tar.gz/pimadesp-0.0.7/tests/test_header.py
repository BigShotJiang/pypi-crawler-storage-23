import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_navigation(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        .. toctree::

           branch/index
    """))
    (srcdir / "branch").mkdir()
    (srcdir / "branch/index.rst").write_text(textwrap.dedent("""
        ======
        branch
        ======

        .. toctree::

           leaf
    """))
    (srcdir / "branch/leaf.rst").write_text(textwrap.dedent("""
        ====
        leaf
        ====
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)
    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.locator("button[aria-label='Open branch menu']").click()
    page.get_by_role("menuitem", name="Overview").click()
    expect(page.locator("h1")).to_contain_text("branch")
    page.locator("button[aria-label='Open branch menu']").click()
    page.get_by_role("menuitem", name="leaf").click()
    expect(page.locator("h1")).to_contain_text("leaf")

def test_navigation_overflow(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        .. toctree::

           item1
           item2
           item3
           item4
           item5/index
           item6
           item7/index
    """))
    for i in [1, 2, 3, 4, 6]:
        (srcdir / f"item{i}.rst").write_text(textwrap.dedent(f"""
            =====
            item{i}
            =====
        """))
    for i in [5, 7]:
        (srcdir / f"item{i}").mkdir()
        (srcdir / f"item{i}/index.rst").write_text(textwrap.dedent(f"""
            =====
            item{i}
            =====
            
            .. toctree::
               
               sub
        """))
        (srcdir / f"item{i}/sub.rst").write_text(textwrap.dedent(f"""
            ===
            sub
            ===
        """))

    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)
    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)

    # First 5 items should be visible directly
    expect(page.locator("a.nav-link", has_text="item1")).to_be_visible()
    expect(page.locator("a.nav-link", has_text="item4")).to_be_visible()
    expect(page.locator("button.nav-link.menu-trigger", has_text="item5")).to_be_visible()

    # The 6th and 7th item should not be visible as top-level links
    expect(page.locator("a.nav-link", has_text="item6")).not_to_be_visible()
    expect(page.locator("button.nav-link.menu-trigger", has_text="item7")).not_to_be_visible()

    # The More menu should be visible
    more_btn = page.locator("button.nav-link.menu-trigger", has_text="More")
    expect(more_btn).to_be_visible()
    more_btn.click()

    # Inside More menu, item6 should be a simple link, item7 should be a sub-menu
    expect(page.locator("a.menu-item", has_text="item6")).to_be_visible()
    
    item7_btn = page.locator("button.mat-mdc-menu-item", has_text="item7")
    expect(item7_btn).to_be_visible()
    item7_btn.click()
    
    # Inside item7 sub-menu, we should see Overview and sub
    expect(page.locator("a.menu-item", has_text="Overview")).to_be_visible()
    expect(page.locator("a.menu-item", has_text="sub")).to_be_visible()

