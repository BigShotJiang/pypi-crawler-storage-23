import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_table_sorting_basic(page: Page, tmp_path, live_server):
    """Test that tables can be sorted by clicking column headers."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ===========
        Table Test
        ===========

        .. list-table:: Browsers
           :header-rows: 1

           * - Browser
             - Version
             - Year
           * - Chrome
             - 90
             - 2021
           * - Firefox
             - 88
             - 2021
           * - Safari
             - 14
             - 2020
           * - Edge
             - 90
             - 2021
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)

    # Wait for content to load and tables to be transformed
    page.wait_for_selector("table[mat-table]", timeout=10000)

    # Verify table exists
    table = page.locator("table[mat-table]")
    expect(table).to_be_visible()

    # Verify table has Material Design classes
    class_attr = table.get_attribute("class")
    assert "mat-mdc-table" in class_attr, f"Table should have mat-mdc-table class, got: {class_attr}"

    # Check initial order - get all browser names
    cells = page.locator("td.mat-mdc-cell").nth(0)
    initial_first = cells.text_content()

    # Get all rows to verify initial order
    rows = page.locator("tr.mat-mdc-row")
    row_count = rows.count()
    assert row_count == 4, f"Should have 4 data rows, found {row_count}"

    # Get the first cell (Browser column) of each row
    initial_order = []
    for i in range(row_count):
        cell = rows.nth(i).locator("td").nth(0)
        # Extract text from the paragraph inside
        text = cell.text_content()
        initial_order.append(text.strip())

    # Verify initial order matches insertion order
    assert "Chrome" in initial_order[0], f"First row should contain Chrome, got: {initial_order[0]}"
    assert "Firefox" in initial_order[1], f"Second row should contain Firefox, got: {initial_order[1]}"

    # Click the "Browser" column header to sort
    browser_header = page.locator("th.mat-mdc-header-cell").filter(has_text="Browser")
    expect(browser_header).to_be_visible()
    browser_header.click()

    # Wait a bit for the sort animation
    page.wait_for_timeout(500)

    # Get the new order after sorting
    sorted_order = []
    for i in range(row_count):
        cell = rows.nth(i).locator("td").nth(0)
        text = cell.text_content()
        sorted_order.append(text.strip())

    # Verify the order changed (alphabetically)
    # Should be: Chrome, Edge, Firefox, Safari
    assert "Chrome" in sorted_order[0], f"After sort, first should be Chrome, got: {sorted_order[0]}"
    assert "Edge" in sorted_order[1], f"After sort, second should be Edge, got: {sorted_order[1]}"
    assert "Firefox" in sorted_order[2], f"After sort, third should be Firefox, got: {sorted_order[2]}"
    assert "Safari" in sorted_order[3], f"After sort, fourth should be Safari, got: {sorted_order[3]}"


def test_table_sorting_reverse(page: Page, tmp_path, live_server):
    """Test that clicking a column header twice reverses the sort order."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ============
        Sort Test
        ============

        .. list-table:: Numbers
           :header-rows: 1

           * - Name
             - Value
           * - Alpha
             - 100
           * - Beta
             - 200
           * - Gamma
             - 300
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("table[mat-table]", timeout=10000)

    # Get initial order
    rows = page.locator("tr.mat-mdc-row")
    initial_first = rows.nth(0).locator("td").nth(0).text_content()

    # Click "Name" header once for ascending sort
    name_header = page.locator("th.mat-mdc-header-cell").filter(has_text="Name")
    name_header.click()
    page.wait_for_timeout(500)

    first_after_asc = rows.nth(0).locator("td").nth(0).text_content()
    assert "Alpha" in first_after_asc, f"After ascending sort, first should be Alpha, got: {first_after_asc}"

    # Click again for descending sort
    name_header.click()
    page.wait_for_timeout(500)

    first_after_desc = rows.nth(0).locator("td").nth(0).text_content()
    assert "Gamma" in first_after_desc, f"After descending sort, first should be Gamma, got: {first_after_desc}"


def test_table_multiple_columns_sort(page: Page, tmp_path, live_server):
    """Test that different columns can be sorted independently."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ================
        Multi-Sort Test
        ================

        .. list-table:: Data
           :header-rows: 1

           * - Letter
             - Number
           * - C
             - 3
           * - A
             - 1
           * - B
             - 2
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("table[mat-table]", timeout=10000)

    rows = page.locator("tr.mat-mdc-row")

    # Sort by Letter column
    letter_header = page.locator("th.mat-mdc-header-cell").filter(has_text="Letter")
    letter_header.click()
    page.wait_for_timeout(500)

    first_cell = rows.nth(0).locator("td").nth(0).text_content()
    assert "A" in first_cell, f"After sorting by Letter, first should be A, got: {first_cell}"

    # Now sort by Number column
    number_header = page.locator("th.mat-mdc-header-cell").filter(has_text="Number")
    number_header.click()
    page.wait_for_timeout(500)

    # Second column (Number) of first row should be 1
    first_row_number = rows.nth(0).locator("td").nth(1).text_content()
    assert "1" in first_row_number, f"After sorting by Number, first row's number should be 1, got: {first_row_number}"


def test_table_sort_indicator(page: Page, tmp_path, live_server):
    """Test that the sort indicator (arrow) appears on sorted columns."""
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ==================
        Sort Indicator Test
        ==================

        .. list-table:: Items
           :header-rows: 1

           * - Item
             - Price
           * - Apple
             - 1.00
           * - Banana
             - 0.50
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)
    page.wait_for_selector("table[mat-table]", timeout=10000)

    # Click the Item header
    item_header = page.locator("th.mat-mdc-header-cell").filter(has_text="Item")
    item_header.click()
    page.wait_for_timeout(500)

    # Check that the header has the sort-header class active
    # Angular Material adds aria-sort attribute when sorted
    # The Item header should have aria-sort attribute
    expect(item_header).to_have_attribute("aria-sort", "ascending")
