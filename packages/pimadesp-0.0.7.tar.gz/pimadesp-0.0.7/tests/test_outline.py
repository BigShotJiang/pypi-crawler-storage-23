import textwrap

from playwright.sync_api import Page, expect
from sphinx.application import Sphinx


def test_outline_scrolls_viewport(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        section one
        ===========

        .. raw:: html

            <div style="height: 2000px;">spacer</div>

        section two
        ===========
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)

    # Initial scroll position should be 0
    assert page.evaluate("window.scrollY") == 0

    outline = page.locator("app-outline")
    expect(outline).to_be_visible()

    # Click the second section link in the outline
    link = outline.get_by_role("link", name="section two")
    expect(link).to_be_visible()
    link.click()

    # Wait for the scroll to happen
    page.wait_for_function("window.scrollY > 100")

    # Verify that the viewport has scrolled
    assert page.evaluate("window.scrollY") > 0


def test_outline_complex_headings(page: Page, tmp_path, live_server):
    srcdir = tmp_path
    (srcdir / "conf.py").write_text(textwrap.dedent("""
        extensions = ["pimadesp"]
        html_theme = "pimadesp"
    """))
    (srcdir / "index.rst").write_text(textwrap.dedent("""
        ====
        root
        ====

        h2 one
        ======

        h3 one
        ------

        h4 one
        ^^^^^^

        h3 two
        ------

        h2 two
        ======
    """))
    outdir = tmp_path / "out"
    outdir.mkdir()
    doctreedir = tmp_path / "doctrees"
    doctreedir.mkdir()
    app = Sphinx(str(srcdir), str(srcdir), str(outdir), str(doctreedir), "html")
    app.build()
    url = live_server(outdir)

    page.goto(f"{url}/")
    page.wait_for_selector("app-root", timeout=5000)

    outline = page.locator("app-outline")
    expect(outline).to_be_visible()

    links = outline.locator("a")
    # Providing a list instructs Playwright to ensure that the
    # DOM nodes occur in the expected order.
    expect(links).to_have_text([
        "h2 one",
        "h3 one",
        "h4 one",
        "h3 two",
        "h2 two"
    ])
