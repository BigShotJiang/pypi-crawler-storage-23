#!/bin/bash

has_uv() {
    if command -v uv >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

install_uv() {
    curl -LsSf https://astral.sh/uv/install.sh | sh
    if ! has_uv; then
        echo "Failed to install uv"
        exit 1
    fi
}

if ! has_nvm; then
    install_nvm
fi