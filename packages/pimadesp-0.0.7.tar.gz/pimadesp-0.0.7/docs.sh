#!/usr/bin/env bash

source nvm.sh
source uv.sh

cd docs
if [ -d "out" ]; then
    rm -rf out
fi

ANGULAR_CACHE=".pimadesp-cache"
if [ -d "$ANGULAR_CACHE" ]; then
    rm -rf "$ANGULAR_CACHE"
fi

uv run --python 3.12.12 --with-requirements deps.txt sphinx-build -b html . out