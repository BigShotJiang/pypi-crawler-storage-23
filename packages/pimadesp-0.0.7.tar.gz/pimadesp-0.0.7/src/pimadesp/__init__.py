import json
import logging
import re
from pathlib import Path
from xml.etree import ElementTree as ET

from docutils import nodes
from docutils.parsers.rst import Directive, directives
from pimadesp import angular, search

logger = logging.getLogger(__name__)


class card_node(nodes.General, nodes.Element):
    pass


class CardDirective(Directive):
    """RST directive that maps to an Angular Material card component.

    Usage::

        .. card:: Optional title
           :subtitle: Optional subtitle

           Card body content. Any RST is valid here.
    """
    optional_arguments = 1
    final_argument_whitespace = True
    option_spec = {
        'subtitle': directives.unchanged,
    }
    has_content = True

    def run(self):
        node = card_node()
        node['card_title'] = self.arguments[0] if self.arguments else ''
        node['card_subtitle'] = self.options.get('subtitle', '')
        self.state.nested_parse(self.content, self.content_offset, node)
        return [node]


def visit_card_html(self, node):
    title = node.get('card_title', '').replace('"', '&quot;')
    subtitle = node.get('card_subtitle', '').replace('"', '&quot;')
    attrs = 'data-material-card'
    if title:
        attrs += f' data-card-title="{title}"'
    if subtitle:
        attrs += f' data-card-subtitle="{subtitle}"'
    self.body.append(f'<div {attrs}><div class="card-body">')


def depart_card_html(self, node):
    self.body.append('</div></div>')

def compute_sitemap(app):
    """Build sitemap tree from toctree structure."""
    from sphinx import addnodes
    env = app.builder.env
    master = env.config.master_doc

    def get_children(pagename):
        toc = env.tocs.get(pagename)
        if toc is None:
            return []
        children = []
        for toctree_node in toc.findall(addnodes.toctree):
            for title, ref in toctree_node['entries']:
                is_self = ref == 'self'
                if is_self:
                    ref = pagename
                if title is None:
                    title = env.titles[ref].astext() if ref in env.titles else ref
                path = app.builder.get_target_uri(ref)
                entry = {
                    'title': title,
                    'path': path,
                    'children': [] if is_self else get_children(ref),
                }
                children.append(entry)
        return children

    return get_children(master)

def normalize_path(path):
    import re
    path = re.sub(r'\.html$', '', path)
    path = re.sub(r'/index$', '', path)
    path = re.sub(r'/$', '', path)
    return path


def extract_sections(doctree):
    """Extract section hierarchy from doctree, excluding the H1 (page title)."""
    from docutils import nodes
    sections = []

    for section in doctree.findall(nodes.section):
        ids = section.get('ids', [])
        if not ids:
            continue

        title_node = section[0] if section.children else None
        if not isinstance(title_node, nodes.title):
            continue

        # Determine heading level by counting parent sections
        level = 2
        parent = section.parent
        while parent:
            if isinstance(parent, nodes.section):
                level += 1
            parent = parent.parent

        # Skip level 2 (H1) sections - these are page titles
        if level == 2:
            continue

        sections.append({
            'id': ids[0],
            'title': title_node.astext(),
            'level': level
        })

    return sections

def write_page_sitemap_data(app, doctree, docname):
    """Write per-page sitemap data after doctree resolution."""
    sections = extract_sections(doctree)

    env = app.builder.env

    page_data = {
        'docname': docname,
        'path': app.builder.get_target_uri(docname),
        'title': env.titles[docname].astext() if docname in env.titles else docname,
        'sections': sections
    }

    # Write immediately (parallel-safe - each page writes its own file)
    sitemap_dir = Path(app.outdir) / '_sitemap' / 'pages'
    sitemap_dir.mkdir(exist_ok=True, parents=True)

    page_file = sitemap_dir / f'{docname}.json'
    page_file.parent.mkdir(exist_ok=True, parents=True)
    page_file.write_text(json.dumps(page_data), encoding='utf-8')

def strip_toc_title(toc_html):
    """Remove the H1 (document title) from the ToC, keeping only H2+ entries."""
    if not toc_html or not toc_html.strip():
        return toc_html
    try:
        root = ET.fromstring(toc_html)
        first_li = root.find('li')
        if first_li is not None:
            nested_ul = first_li.find('ul')
            if nested_ul is not None:
                return ET.tostring(nested_ul, encoding='unicode', method='html')
        return toc_html
    except ET.ParseError:
        return toc_html

def transform_tables_to_material(html_content):
    """Transform HTML tables into Angular Material table components.

    Since the content is inserted via innerHTML, we generate static HTML
    with Material Design classes and a data attribute that an Angular
    directive can use to enhance the table if needed.
    """
    if not html_content or '<table' not in html_content:
        return html_content

    def parse_table(match):
        table_html = match.group(0)
        try:
            # Parse the table HTML
            # Wrap in a div to ensure valid XML parsing
            wrapped = f'<div>{table_html}</div>'
            root = ET.fromstring(wrapped)
            table = root.find('.//table')

            if table is None:
                return table_html

            # Extract headers
            headers = []
            column_ids = []
            thead = table.find('.//thead')
            if thead is not None:
                header_row = thead.find('.//tr')
                if header_row is not None:
                    for idx, th in enumerate(header_row.findall('.//th')):
                        header_text = ''.join(th.itertext()).strip()
                        headers.append(header_text)
                        # Create column ID from header text (lowercase, replace spaces with underscores)
                        col_id = re.sub(r'[^a-z0-9_]', '', header_text.lower().replace(' ', '_'))
                        if not col_id:
                            col_id = f'col_{idx}'
                        column_ids.append(col_id)

            # Extract data rows
            data_rows = []
            tbody = table.find('.//tbody')
            if tbody is not None:
                for tr in tbody.findall('.//tr'):
                    row_data = []
                    for td in tr.findall('.//td'):
                        # Get HTML content of cell, preserving formatting
                        cell_content = ET.tostring(td, encoding='unicode', method='html')
                        # Extract just the inner content
                        cell_content = re.sub(r'^<td[^>]*>', '', cell_content)
                        cell_content = re.sub(r'</td>$', '', cell_content)
                        row_data.append(cell_content.strip())
                    if row_data:
                        data_rows.append(row_data)

            if not headers or not data_rows:
                return table_html

            # Build static HTML table with Material Design classes
            # Add data-material-table attribute for potential Angular directive enhancement
            result = ['<table class="mat-mdc-table mdc-data-table__table mat-elevation-z2" data-material-table>']

            # Header row with Material classes
            result.append('  <thead>')
            result.append('    <tr class="mat-mdc-header-row mdc-data-table__header-row">')
            for header in headers:
                result.append(f'      <th class="mat-mdc-header-cell mdc-data-table__header-cell">{header}</th>')
            result.append('    </tr>')
            result.append('  </thead>')

            # Data rows with Material classes
            result.append('  <tbody class="mdc-data-table__content">')
            for row_data in data_rows:
                result.append('    <tr class="mat-mdc-row mdc-data-table__row">')
                for cell_content in row_data:
                    result.append(f'      <td class="mat-mdc-cell mdc-data-table__cell">{cell_content}</td>')
                result.append('    </tr>')
            result.append('  </tbody>')

            result.append('</table>')

            return '\n'.join(result)

        except ET.ParseError as e:
            logger.warning(f'Failed to parse table HTML: {e}')
            return table_html
        except Exception as e:
            logger.warning(f'Error transforming table to Material Design: {e}')
            return table_html

    # Find and replace all tables
    pattern = r'<table[^>]*>.*?</table>'
    transformed = re.sub(pattern, parse_table, html_content, flags=re.DOTALL)

    return transformed

def prepare_page_context(app, pagename, templatename, context, doctree):
    """Prepare page context: transform tables and inject template data."""
    # Transform tables to Angular Material format in static HTML
    body_content = context.get('body', '')
    body_content = transform_tables_to_material(body_content)
    context['body'] = body_content

    # Strip toc title for the template
    context['toc'] = strip_toc_title(context.get('toc', ''))

    # For SSR template: compute sitemap from toctree
    sitemap = compute_sitemap(app)
    context['sitemap_json'] = json.dumps(sitemap)

    # Set root page for Angular app
    env = app.builder.env
    master = env.config.master_doc
    master_title = env.titles[master].astext() if master in env.titles else 'Home'
    master_path = app.builder.get_target_uri(master)
    root_page = {'title': master_title, 'path': master_path}
    context['root_page_json'] = json.dumps(root_page)

def build_comprehensive_sitemap(app, exception):
    """Collect all per-page data and build comprehensive sitemap."""
    if exception:
        return

    sitemap_dir = Path(app.outdir) / '_sitemap'
    pages_dir = sitemap_dir / 'pages'

    # Read all per-page JSON files
    pages = {}
    if pages_dir.exists():
        for page_file in pages_dir.glob('**/*.json'):
            docname = str(page_file.relative_to(pages_dir)).replace('.json', '')
            page_data = json.loads(page_file.read_text(encoding='utf-8'))
            pages[docname] = page_data

    # Build tree from toctree
    tree = compute_sitemap(app)

    # Get root page
    env = app.builder.env
    master = env.config.master_doc
    root_page = {
        'title': pages.get(master, {}).get('title', 'Home'),
        'path': pages.get(master, {}).get('path', 'index.html')
    }

    # Write comprehensive sitemap
    comprehensive = {
        'version': '1.0',
        'rootPage': root_page,
        'pages': pages,
        'tree': tree
    }

    (sitemap_dir / 'index.json').write_text(json.dumps(comprehensive), encoding='utf-8')

def setup(app):
    app.add_html_theme('pimadesp', Path(__file__).resolve().parent)

    app.add_node(card_node, html=(visit_card_html, depart_card_html))
    app.add_directive('card', CardDirective)

    # Connect event handlers
    app.connect('builder-inited', angular.build)
    app.connect('doctree-resolved', write_page_sitemap_data)
    app.connect('html-page-context', prepare_page_context)
    app.connect('html-page-context', search.inject_search_config)
    app.connect('build-finished', build_comprehensive_sitemap)
    app.connect('build-finished', angular.copy_to_static)
    app.connect('build-finished', search.run_pagefind_indexing)
    return {"parallel_read_safe": True, "parallel_write_safe": True}
