import { Component, inject } from '@angular/core';
import { MatDividerModule } from '@angular/material/divider';
import { ContentService } from './content.service';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [MatDividerModule],
  template: `
    <footer class="site-footer">
      <mat-divider></mat-divider>
      <div class="footer-content">
        @for (section of contentService.sitemap(); track section.path) {
          <div class="footer-column">
            <a [href]="contentService.basePath + section.path" (click)="navigate($event, section.path)">{{ section.title }}</a>
          </div>
        }
      </div>
    </footer>
  `,
  styleUrl: './footer.component.scss'
})
export class FooterComponent {
  contentService = inject(ContentService);

  navigate(event: Event, path: string) {
    event.preventDefault();
    this.contentService.loadPage(path);
    history.pushState(null, '', this.contentService.basePath + path);
  }
}
