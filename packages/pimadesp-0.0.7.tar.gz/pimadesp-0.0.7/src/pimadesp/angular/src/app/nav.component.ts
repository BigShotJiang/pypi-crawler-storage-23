import { Component, inject } from '@angular/core';
import { ContentService, SecnavItem } from './content.service';
import { LayoutService } from './layout.service';

@Component({
  selector: 'app-nav',
  standalone: true,
  template: `
    <nav class="section-nav">
      @if (contentService.secnav().parent; as parent) {
        <div class="nav-parent">
          <a [href]="contentService.basePath + parent.path" (click)="navigateParent($event, parent)">&lsaquo; {{ parent.title }}</a>
        </div>
      }
      <ul class="nav-list">
        @for (item of contentService.secnav().items; track item.path) {
          <li>
            @if (item.type === 'label') {
              <span class="nav-label">{{ item.title }}</span>
            } @else {
              <a
                [href]="contentService.basePath + item.path"
                [class.active]="isActive(item.path)"
                (click)="navigate($event, item)"
              >{{ item.title }}</a>
            }
          </li>
        }
      </ul>
    </nav>
  `,
  styleUrl: './nav.component.scss'
})
export class NavComponent {
  contentService = inject(ContentService);
  private layoutService = inject(LayoutService);

  isActive(path: string): boolean {
    const current = this.contentService.currentPath();
    const normalizedCurrent = current.replace(/\.html$/, '').replace(/\/index$/, '/').replace(/\/$/, '');
    const normalizedPath = path.replace(/\.html$/, '').replace(/\/index$/, '/').replace(/\/$/, '');
    return normalizedCurrent === normalizedPath;
  }

  navigateParent(event: Event, parent: {title: string, path: string}) {
    event.preventDefault();
    this.contentService.secnavContext.set(parent.path);
  }

  navigate(event: Event, item: SecnavItem) {
    event.preventDefault();
    if (item.type === 'expandable') {
      // Update only secnav context, don't load page
      this.contentService.secnavContext.set(item.path);
    } else {
      // Load page and reset secnav context
      this.contentService.loadPage(item.path);
      history.pushState(null, '', this.contentService.basePath + item.path);
      this.layoutService.closeSidenav();
    }
  }
}
