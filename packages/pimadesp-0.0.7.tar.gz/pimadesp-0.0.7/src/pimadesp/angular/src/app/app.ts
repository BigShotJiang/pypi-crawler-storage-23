import { Component, inject, OnInit } from '@angular/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';
import { ContentService } from './content.service';
import { SpaNavigationService } from './spa-navigation.service';
import { ThemeService } from './theme.service';
import { LayoutService } from './layout.service';
import { SpaLinkDirective } from './spa-link.directive';
import { HeaderComponent } from './header.component';
import { NavComponent } from './nav.component';
import { OutlineComponent } from './outline.component';
import { FooterComponent } from './footer.component';
import { SearchComponent } from './search.component';
import { OutlineViewComponent } from './outline-view.component';
import { NavViewComponent } from './nav-view.component';
import { BreadcrumbsComponent } from './breadcrumbs.component';
import { ContentComponent } from './content.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    SpaLinkDirective,
    MatProgressBarModule,
    MatTableModule,
    MatSortModule,
    MatCardModule,
    HeaderComponent,
    NavComponent,
    OutlineComponent,
    FooterComponent,
    SearchComponent,
    OutlineViewComponent,
    NavViewComponent,
    BreadcrumbsComponent,
    ContentComponent,
  ],
  template: `
    @if (contentService.loading()) {
      <mat-progress-bar mode="indeterminate"></mat-progress-bar>
    }
    <app-header></app-header>
    @if (layoutService.searchActive()) {
      <app-search></app-search>
    } @else if (layoutService.tocActive()) {
      <app-outline-view></app-outline-view>
    } @else if (layoutService.isMobile() && layoutService.sidenavOpen()) {
      <app-nav-view></app-nav-view>
    } @else {
      @if (layoutService.isMobile()) {
        <div class="layout mobile">
          <main class="main-content" appSpaContent>
            <app-breadcrumbs></app-breadcrumbs>
            <div class="content">
              <app-content></app-content>
            </div>
          </main>
        </div>
        <app-outline></app-outline>
      } @else {
        <div class="layout" [class.with-sidenav]="contentService.currentSections().length" [class.with-sidenav-only]="!contentService.currentSections().length">
          <aside class="left-column">
            <app-nav></app-nav>
          </aside>
          <main class="main-content" appSpaContent>
            <app-breadcrumbs></app-breadcrumbs>
            <div class="content">
              <app-content></app-content>
            </div>
          </main>
          @if (contentService.currentSections().length) {
            <aside class="right-column">
              <app-outline></app-outline>
            </aside>
          }
        </div>
      }
      <app-footer></app-footer>
    }
  `,
  styleUrl: './app.component.scss'
})
export class App implements OnInit {
  contentService = inject(ContentService);
  layoutService = inject(LayoutService);
  private navService = inject(SpaNavigationService);
  private themeService = inject(ThemeService);

  ngOnInit(): void {
    this.navService.initialize();
  }
}
