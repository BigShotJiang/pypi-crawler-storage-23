import {
  Component,
  ElementRef,
  ViewChild,
  AfterViewInit,
  ViewContainerRef,
  ComponentRef,
  effect,
  inject,
  ChangeDetectorRef,
  Input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatCardModule } from '@angular/material/card';
import { ContentService } from './content.service';

interface TableData {
  [key: string]: string;
}

@Component({
  selector: 'app-dynamic-material-table',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatSortModule],
  template: `
    <table mat-table [dataSource]="dataSource" matSort class="mat-elevation-z2">
      @for (column of displayedColumns; track column) {
        <ng-container [matColumnDef]="column">
          <th mat-header-cell *matHeaderCellDef mat-sort-header>
            {{ headers[column] }}
          </th>
          <td mat-cell *matCellDef="let row" [innerHTML]="row[column]"></td>
        </ng-container>
      }
      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
    </table>
  `,
  styles: [`
    table {
      width: 100%;
      margin: 1em 0;
    }
  `]
})
export class DynamicMaterialTableComponent implements AfterViewInit {
  tableData: TableData[] = [];
  headers: { [key: string]: string } = {};
  displayedColumns: string[] = [];

  @ViewChild(MatSort) sort!: MatSort;

  dataSource = new MatTableDataSource<TableData>([]);

  ngAfterViewInit() {
    this.dataSource.data = this.tableData;
    this.dataSource.sort = this.sort;
  }
}

@Component({
  selector: 'app-dynamic-material-card',
  standalone: true,
  imports: [CommonModule, MatCardModule],
  template: `
    <mat-card>
      @if (title || subtitle) {
        <mat-card-header>
          @if (title) { <mat-card-title>{{ title }}</mat-card-title> }
          @if (subtitle) { <mat-card-subtitle>{{ subtitle }}</mat-card-subtitle> }
        </mat-card-header>
      }
      <mat-card-content [innerHTML]="bodyHtml"></mat-card-content>
    </mat-card>
  `,
  styles: [`
    mat-card {
      margin: 1em 0;
    }
    mat-card-content {
      padding-top: 8px;
    }
  `]
})
export class DynamicMaterialCardComponent {
  @Input() title = '';
  @Input() subtitle = '';
  @Input() bodyHtml = '';
}

@Component({
  selector: 'app-content',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div #contentContainer></div>
  `,
})
export class ContentComponent implements AfterViewInit {
  @ViewChild('contentContainer', { read: ElementRef }) contentContainer!: ElementRef;
  @ViewChild('contentContainer', { read: ViewContainerRef }) viewContainer!: ViewContainerRef;

  private contentService = inject(ContentService);
  private cdr = inject(ChangeDetectorRef);
  private componentRefs: ComponentRef<DynamicMaterialTableComponent | DynamicMaterialCardComponent>[] = [];

  constructor() {
    effect(() => {
      // React to content changes
      const content = this.contentService.content();
      if (this.contentContainer) {
        this.updateContent();
      }
    });
  }

  ngAfterViewInit() {
    this.updateContent();
  }

  private updateContent() {
    // Clear previous dynamic components
    this.componentRefs.forEach(ref => ref.destroy());
    this.componentRefs = [];

    // Set the HTML content
    const container = this.contentContainer.nativeElement as HTMLElement;
    container.innerHTML = this.contentService.content();

    // Find and replace Material components
    setTimeout(() => {
      this.convertTablesToMaterial();
      this.convertCardsToMaterial();
      this.cdr.detectChanges();
    }, 0);
  }

  private convertTablesToMaterial() {
    const container = this.contentContainer.nativeElement as HTMLElement;
    const tables = container.querySelectorAll('table[data-material-table]');

    tables.forEach((table) => {
      const tableElement = table as HTMLTableElement;
      const data = this.extractTableData(tableElement);

      if (data) {
        const componentRef = this.viewContainer.createComponent(DynamicMaterialTableComponent);

        componentRef.instance.tableData = data.rows;
        componentRef.instance.headers = data.headers;
        componentRef.instance.displayedColumns = data.columns;

        this.componentRefs.push(componentRef);

        const parent = tableElement.parentNode;
        if (parent) {
          parent.replaceChild(
            componentRef.location.nativeElement,
            tableElement
          );
        }
      }
    });
  }

  private convertCardsToMaterial() {
    const container = this.contentContainer.nativeElement as HTMLElement;
    const cards = container.querySelectorAll('div[data-material-card]');

    cards.forEach((el) => {
      const div = el as HTMLDivElement;
      const title = div.dataset['cardTitle'] ?? '';
      const subtitle = div.dataset['cardSubtitle'] ?? '';
      const bodyEl = div.querySelector('.card-body');
      const bodyHtml = bodyEl ? bodyEl.innerHTML.trim() : div.innerHTML.trim();

      const componentRef = this.viewContainer.createComponent(DynamicMaterialCardComponent);
      componentRef.instance.title = title;
      componentRef.instance.subtitle = subtitle;
      componentRef.instance.bodyHtml = bodyHtml;

      this.componentRefs.push(componentRef);

      div.parentNode?.replaceChild(componentRef.location.nativeElement, div);
    });
  }

  private extractTableData(table: HTMLTableElement): {
    headers: { [key: string]: string };
    columns: string[];
    rows: TableData[];
  } | null {
    const thead = table.querySelector('thead');
    const tbody = table.querySelector('tbody');

    if (!thead || !tbody) {
      return null;
    }

    const headerRow = thead.querySelector('tr');
    if (!headerRow) {
      return null;
    }

    const headers: { [key: string]: string } = {};
    const columns: string[] = [];
    const headerCells = headerRow.querySelectorAll('th');

    headerCells.forEach((th, index) => {
      const headerText = th.textContent?.trim() || `col_${index}`;
      const columnId = `col_${index}`;
      headers[columnId] = headerText;
      columns.push(columnId);
    });

    const rows: TableData[] = [];
    const dataRows = tbody.querySelectorAll('tr');

    dataRows.forEach((tr) => {
      const row: TableData = {};
      const cells = tr.querySelectorAll('td');

      cells.forEach((td, index) => {
        const columnId = `col_${index}`;
        row[columnId] = td.innerHTML.trim();
      });

      rows.push(row);
    });

    return { headers, columns, rows };
  }
}
