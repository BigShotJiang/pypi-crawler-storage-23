import {
  Component,
  inject,
  signal,
  OnInit,
  OnDestroy,
  ViewChild,
  ElementRef,
  AfterViewInit,
  HostListener,
} from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatListModule } from '@angular/material/list';
import { MatRippleModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { SearchService, SearchResultItem } from './search.service';
import { ContentService } from './content.service';
import { LayoutService } from './layout.service';
import { Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatListModule,
    MatRippleModule,
    MatCardModule,
    MatDividerModule
  ],
  template: `
    <div class="search-view">
      <div class="search-header">
        <mat-form-field appearance="outline" class="search-input">
          <mat-icon matPrefix>search</mat-icon>
          <input
            matInput
            placeholder="Search docs..."
            (input)="onInput($event)"
            #searchInput
          />
        </mat-form-field>
      </div>

      @if (loading()) {
        <div class="search-loading">
          <mat-spinner diameter="40"></mat-spinner>
        </div>
      } @else if (results().length) {
        <div class="results-container">
          @for (result of results(); track result.url; let last = $last) {
            @if (result.subResults.length > 0) {
              <!-- Page with sub-results -->
              <div class="result-group">
                <div class="page-header"
                     (click)="selectPage(result)"
                     (keydown.enter)="selectPage(result)"
                     tabindex="0"
                     role="button">
                  <mat-icon class="page-icon">description</mat-icon>
                  <span class="page-title">{{ result.title }}</span>
                </div>
                <mat-list class="sub-results-list">
                  @for (subResult of result.subResults; track subResult.url) {
                    <mat-list-item
                      class="sub-result-item"
                      (click)="selectResult(subResult)"
                      (keydown.enter)="selectResult(subResult)"
                      tabindex="0">
                      <mat-icon matListItemIcon>tag</mat-icon>
                      <div matListItemTitle class="result-title">{{ subResult.title }}</div>
                      <div matListItemLine class="result-excerpt" [innerHTML]="sanitizeHtml(subResult.excerpt)"></div>
                    </mat-list-item>
                  }
                </mat-list>
              </div>
            } @else {
              <!-- Single page result without sub-results -->
              <mat-list class="result-list">
                <mat-list-item
                  class="result-item"
                  (click)="selectResult(result)"
                  (keydown.enter)="selectResult(result)"
                  tabindex="0">
                  <mat-icon matListItemIcon>article</mat-icon>
                  <div matListItemTitle class="result-title">{{ result.title }}</div>
                  <div matListItemLine class="result-excerpt" [innerHTML]="sanitizeHtml(result.excerpt)"></div>
                </mat-list-item>
              </mat-list>
            }
            @if (!last) {
              <mat-divider></mat-divider>
            }
          }
        </div>
      } @else if (query()) {
        <p class="no-results">No results found.</p>
      }
    </div>
  `,
  styleUrl: './search.component.scss'
})
export class SearchComponent implements OnInit, OnDestroy, AfterViewInit {
  private searchService = inject(SearchService);
  private contentService = inject(ContentService);
  private layoutService = inject(LayoutService);
  private sanitizer = inject(DomSanitizer);

  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

  results = signal<SearchResultItem[]>([]);
  query = signal<string>('');
  loading = signal<boolean>(false);

  private searchSubject = new Subject<string>();
  private subscription!: Subscription;

  ngOnInit() {
    this.subscription = this.searchSubject
      .pipe(
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(async (query) => {
        this.query.set(query);
        this.loading.set(true);

        const response = await this.searchService.search(query);
        console.log('[Search Component] Query:', query);
        console.log('[Search Component] Response:', response);
        console.log('[Search Component] Results:', response.results);
        this.results.set(response.results);

        this.loading.set(false);
      });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.searchInput.nativeElement.focus();
    }, 100);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  onInput(event: Event) {
    const input = event.target as HTMLInputElement;
    this.searchSubject.next(input.value);
  }

  async selectPage(result: { url: string; title: string; excerpt: string }) {
    this.close();
    const url = new URL(result.url, window.location.origin);
    window.history.pushState({}, '', url.pathname);
    await this.contentService.loadPage(url.pathname);
    // Scroll to top of page
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async selectResult(result: { url: string; title: string; excerpt: string }) {
    this.close();
    const url = new URL(result.url, window.location.origin);
    window.history.pushState({}, '', url.pathname + url.hash);
    await this.contentService.loadPage(url.pathname);

    if (url.hash) {
      setTimeout(() => {
        const element = document.querySelector(url.hash);
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }

  close() {
    this.layoutService.closeSearch();
    this.searchSubject.next('');
    this.results.set([]);
    this.query.set('');
  }

  sanitizeHtml(html: string): SafeHtml {
    return this.sanitizer.sanitize(1, html) || html;
  }

  @HostListener('document:keydown.escape')
  onEscape() {
    this.close();
  }
}
