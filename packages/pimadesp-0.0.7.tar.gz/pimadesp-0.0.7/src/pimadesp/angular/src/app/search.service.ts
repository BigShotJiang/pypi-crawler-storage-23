import { Injectable, signal } from '@angular/core';

export interface SubResult {
  title: string;
  url: string;
  excerpt: string;
}

export interface SearchResultItem {
  url: string;
  title: string;
  excerpt: string;
  subResults: SubResult[];
}

export interface SearchResponse {
  results: SearchResultItem[];
  totalResults: number;
}

// Pagefind types
interface PagefindAPI {
  init: () => Promise<void>;
  options: (opts: any) => Promise<void>;
  search: (query: string) => Promise<PagefindSearchResponse>;
  debouncedSearch: (query: string, opts?: any) => Promise<PagefindSearchResponse>;
}

interface PagefindSearchResponse {
  results: PagefindResult[];
}

interface PagefindResult {
  id: string;
  data: () => Promise<PagefindResultData>;
}

interface PagefindSubResult {
  title: string;
  url: string;
  excerpt: string;
  anchor?: {
    element: string;
    id: string;
    text: string;
    location: number;
  };
}

interface PagefindResultData {
  url: string;
  content: string;
  excerpt: string;
  meta?: Record<string, string>;
  sub_results?: PagefindSubResult[];
}

declare global {
  interface Window {
    pagefind?: PagefindAPI;
  }
}

@Injectable({ providedIn: 'root' })
export class SearchService {
  private pagefind: PagefindAPI | null = null;
  private basePath: string;
  private initPromise: Promise<void>;

  readonly ready = signal<boolean>(false);

  constructor() {
    const contentRoot = document.documentElement.dataset['content_root'] || './';
    this.basePath = new URL(contentRoot, window.location.href).pathname;
    this.initPromise = this.initialize();
  }

  private async initialize(): Promise<void> {
    // Wait for pagefind to be available on window
    let attempts = 0;
    while (!window.pagefind && attempts < 50) {
      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }

    if (!window.pagefind) {
      console.warn('Pagefind not available - search disabled');
      return;
    }

    try {
      this.pagefind = window.pagefind;
      await this.pagefind.options({
        bundlePath: `${this.basePath}pagefind/`
      });
      await this.pagefind.init();
      this.ready.set(true);
    } catch (error) {
      console.error('Failed to initialize pagefind:', error);
    }
  }

  async search(query: string): Promise<SearchResponse> {
    await this.initPromise;

    if (!query.trim() || !this.pagefind || !this.ready()) {
      return { results: [], totalResults: 0 };
    }

    try {
      const response = await this.pagefind.debouncedSearch(query, {
        debounce: 300
      });

      console.log('[Search Service] Raw pagefind response:', response);
      console.log('[Search Service] Number of results:', response.results.length);

      // Load result data in parallel
      const resultDataPromises = response.results.map(r => r.data());
      const resultData = await Promise.all(resultDataPromises);

      console.log('[Search Service] Result data (all):', resultData);

      const results: SearchResultItem[] = resultData.map((data, index) => {
        console.log(`[Search Service] Result ${index}:`, {
          url: data.url,
          title: this.extractTitle(data),
          excerpt: data.excerpt,
          sub_results: data.sub_results,
          raw_data: data
        });

        return {
          url: this.basePath + data.url,
          title: this.extractTitle(data),
          excerpt: data.excerpt,
          subResults: (data.sub_results || []).map(sub => {
            // Workaround for Pagefind limitation: remove duplicate title from excerpt
            let cleanedExcerpt = sub.excerpt;
            const titlePrefix = `${sub.title}. `;
            if (cleanedExcerpt.startsWith(titlePrefix)) {
              cleanedExcerpt = cleanedExcerpt.replace(titlePrefix, '');
            }
            return {
              title: sub.title,
              url: this.basePath + sub.url,
              excerpt: cleanedExcerpt
            };
          })
        };
      });

      console.log('[Search Service] Transformed results:', results);

      return { results, totalResults: results.length };
    } catch (error) {
      console.error('Search error:', error);
      return { results: [], totalResults: 0 };
    }
  }

  private extractTitle(data: PagefindResultData): string {
    if (data.meta?.['title']) {
      return data.meta['title'];
    }

    const div = document.createElement('div');
    div.innerHTML = data.content;
    const heading = div.querySelector('h1, h2, h3');
    return heading?.textContent || 'Untitled';
  }
}
