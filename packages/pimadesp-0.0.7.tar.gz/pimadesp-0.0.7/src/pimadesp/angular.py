import hashlib
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)

ANGULAR_SRC = Path(__file__).parent / 'angular'
_DEFAULT_USER_THEME = ANGULAR_SRC / 'src' / '_user-theme.scss'
_USER_THEME_DEST = ANGULAR_SRC / 'src' / '_user-theme.scss'

# Maps user-facing partial name to the stub path inside angular.
# Users create _<name>.scss in their confdir; angular.py writes the
# content (or an empty string) to the corresponding _user-<name>.scss stub
# before every Angular build.
_COMPONENT_PARTIALS: dict[str, Path] = {
    'app':          ANGULAR_SRC / 'src' / 'app' / '_user-app.scss',
    'breadcrumbs':  ANGULAR_SRC / 'src' / 'app' / '_user-breadcrumbs.scss',
    'footer':       ANGULAR_SRC / 'src' / 'app' / '_user-footer.scss',
    'header':       ANGULAR_SRC / 'src' / 'app' / '_user-header.scss',
    'nav':          ANGULAR_SRC / 'src' / 'app' / '_user-nav.scss',
    'nav-menu-item': ANGULAR_SRC / 'src' / 'app' / '_user-nav-menu-item.scss',
    'nav-view':     ANGULAR_SRC / 'src' / 'app' / '_user-nav-view.scss',
    'outline':      ANGULAR_SRC / 'src' / 'app' / '_user-outline.scss',
    'outline-view': ANGULAR_SRC / 'src' / 'app' / '_user-outline-view.scss',
    'search':       ANGULAR_SRC / 'src' / 'app' / '_user-search.scss',
}


def _resolve_user_theme(confdir: str) -> tuple[str, str]:
    """Return (content, source_label) for the global theme partial to use.

    Looks for _theme.scss in the Sphinx project root (same directory as conf.py).
    Falls back to the pimadesp default if not found.
    """
    candidate = Path(confdir) / '_theme.scss'
    if candidate.exists():
        return candidate.read_text(), str(candidate)
    return _DEFAULT_USER_THEME.read_text(), '(pimadesp default)'


def _resolve_component_partials(confdir: str) -> dict[str, str]:
    """Return {name: content} for each component partial.

    Reads _<name>.scss from confdir if present, otherwise returns empty string.
    """
    contents: dict[str, str] = {}
    for name in _COMPONENT_PARTIALS:
        candidate = Path(confdir) / f'_{name}.scss'
        contents[name] = candidate.read_text() if candidate.exists() else ''
    return contents


def _theme_hash(theme_content: str, component_contents: dict[str, str]) -> str:
    h = hashlib.md5(theme_content.encode())
    for name in sorted(component_contents):
        h.update(name.encode())
        h.update(component_contents[name].encode())
    return h.hexdigest()[:12]


def _ensure_node_modules() -> None:
    node_modules = ANGULAR_SRC / 'node_modules'
    if not node_modules.exists():
        logger.info('pimadesp: running npm install...')
        try:
            subprocess.run(
                ['npm', 'install', '--ci'],
                cwd=ANGULAR_SRC,
                check=True,
            )
        except FileNotFoundError:
            raise RuntimeError(
                'pimadesp requires Node.js and npm to build the Angular theme. '
                'Please install Node.js from https://nodejs.org and re-run sphinx-build.'
            )


def _run_ng_build() -> None:
    logger.info('pimadesp: running ng build...')
    subprocess.run(
        ['npx', 'ng', 'build'],
        cwd=ANGULAR_SRC,
        check=True,
        env={**os.environ, 'CI': 'true'},
    )


def _run_ng_build_bazel(build_dir: Path, node_modules_dir: Path) -> None:
    logger.info('pimadesp: running ng build (Bazel)...')
    ng_js = node_modules_dir / '@angular' / 'cli' / 'bin' / 'ng.js'
    subprocess.run(
        ['node', str(ng_js), 'build'],
        cwd=build_dir,
        check=True,
        env={**os.environ, 'CI': 'true'},
    )


def build(app) -> None:
    """Compile the Angular app with the user's theme partials. Called from builder-inited."""
    theme_content, theme_source = _resolve_user_theme(app.confdir)
    component_contents = _resolve_component_partials(app.confdir)
    theme_hash = _theme_hash(theme_content, component_contents)

    cache_dir = Path(app.confdir) / '.pimadesp-cache' / theme_hash
    cached_css = cache_dir / 'angular.css'
    cached_js = cache_dir / 'main.js'

    if cached_css.exists() and cached_js.exists():
        logger.info(f'pimadesp: using cached Angular build (hash: {theme_hash})')
    else:
        logger.info(f'pimadesp: building Angular with theme from {theme_source}')
        node_modules_dir_str = app.config.html_theme_options.get('node_modules_dir', '')

        if node_modules_dir_str:
            node_modules_dir = Path(node_modules_dir_str)
            with tempfile.TemporaryDirectory() as tmp:
                build_dir = Path(tmp) / 'angular'
                shutil.copytree(
                    ANGULAR_SRC,
                    build_dir,
                    ignore=shutil.ignore_patterns('node_modules', 'dist', '.angular'),
                )
                (build_dir / 'node_modules').symlink_to(node_modules_dir)
                (build_dir / 'src' / '_user-theme.scss').write_text(theme_content)
                for name, stub_path in _COMPONENT_PARTIALS.items():
                    dest = build_dir / stub_path.relative_to(ANGULAR_SRC)
                    dest.write_text(component_contents[name])
                _run_ng_build_bazel(build_dir, node_modules_dir)
                cache_dir.mkdir(parents=True, exist_ok=True)
                dist = build_dir / 'dist' / 'browser'
                shutil.copy(dist / 'styles.css', cached_css)
                shutil.copy(dist / 'main.js', cached_js)
        else:
            _USER_THEME_DEST.write_text(theme_content)
            for name, stub_path in _COMPONENT_PARTIALS.items():
                stub_path.write_text(component_contents[name])
            _ensure_node_modules()
            _run_ng_build()
            cache_dir.mkdir(parents=True, exist_ok=True)
            dist = ANGULAR_SRC / 'dist' / 'browser'
            shutil.copy(dist / 'styles.css', cached_css)
            shutil.copy(dist / 'main.js', cached_js)

        logger.info(f'pimadesp: Angular build cached (hash: {theme_hash})')

    app.pimadesp_cached_css = cached_css
    app.pimadesp_cached_js = cached_js


def copy_to_static(app, exception) -> None:
    """Copy built Angular files to _static/. Called from build-finished."""
    if exception:
        return
    if not hasattr(app, 'pimadesp_cached_css'):
        return

    static_dir = Path(app.outdir) / '_static'
    static_dir.mkdir(exist_ok=True)
    shutil.copy(app.pimadesp_cached_css, static_dir / 'angular.css')
    shutil.copy(app.pimadesp_cached_js, static_dir / 'main.js')
    logger.info('pimadesp: copied angular.css and main.js to _static/')
