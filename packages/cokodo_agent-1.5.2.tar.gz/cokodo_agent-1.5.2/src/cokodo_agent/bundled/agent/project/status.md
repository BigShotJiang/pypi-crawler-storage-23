# Project Status

> Last updated: {{DATE}} | Updated by: {{UPDATER}}

---

## Current Phase

[Describe the current development phase in one or two sentences.]

## Active Goals

| # | Goal | Priority | Status |
|---|------|----------|--------|
| 1 | [Goal description] | High | Pending |

## Task Board

### In Progress
- [ ] [Task description]

### Pending
- [ ] Fill in project/context.md with project information
- [ ] Fill in project/tech-stack.md with technology decisions
- [ ] Define initial development goals in this file

### Recently Completed
- (none yet)

## Blockers

None.

## Session Context

- [Key information from recent sessions that the next AI session needs to know.]
- [Uncommitted changes, in-flight decisions, important caveats, etc.]

## Roadmap Overview

| Phase | Focus | Status |
|-------|-------|--------|
| [Phase name] | [Description] | Current |

## Quick Reference

| Item | Value |
|------|-------|
| Protocol | {{PROTOCOL_VERSION}} |
| Status | Initialized |

---

*This file is the primary entry point for AI session continuity.*
*Update after each significant session: refresh tasks, goals, blockers, and session context.*
