# Security Development Standards

> Activation Mode: Manual

For detailed rules, please refer to:

@.agent/core/security.md
