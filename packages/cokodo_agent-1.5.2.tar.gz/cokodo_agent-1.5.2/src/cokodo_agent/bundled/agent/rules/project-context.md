# Project Context

> Activation Mode: Always On

Project business context and tech stack information:

@.agent/project/context.md
@.agent/project/tech-stack.md
@.agent/project/known-issues.md
