# Naming and Git Conventions

> Activation Mode: Model Decision

For detailed rules, please refer to:

@.agent/core/conventions.md
