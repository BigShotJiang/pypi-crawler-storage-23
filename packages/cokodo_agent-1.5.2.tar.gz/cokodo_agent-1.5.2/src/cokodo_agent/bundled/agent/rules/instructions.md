# AI Collaboration Guidelines

> Activation Mode: Always On

For detailed rules, please refer to:

@.agent/core/instructions.md
