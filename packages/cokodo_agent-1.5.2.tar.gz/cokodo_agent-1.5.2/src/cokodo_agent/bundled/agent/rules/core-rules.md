# Core Rules

> Activation Mode: Always On

For detailed rules, please refer to:

@.agent/core/core-rules.md
