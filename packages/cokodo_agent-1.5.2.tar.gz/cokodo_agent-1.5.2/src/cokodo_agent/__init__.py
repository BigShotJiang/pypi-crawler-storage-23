"""Cokodo Agent - AI collaboration protocol generator."""

__version__ = "1.5.2"
