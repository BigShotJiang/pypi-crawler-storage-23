"""Tests for inline-env-var rule."""

from ansiblelint.app import App
from ansiblelint.rules import RulesCollection
from ansiblelint.rules.inline_env_var import EnvVarsInCommandRule
from ansiblelint.testing import RunFromText

SUCCESS_PLAY_TASKS = """
- hosts: localhost

  tasks:
  - name: Actual use of environment
    shell: echo $HELLO
    environment:
      HELLO: hello

  - name: Use some key-value pairs
    command: chdir=/tmp creates=/tmp/bobbins touch bobbins

  - name: Commands can have flags
    command: abc --xyz=def blah

  - name: Commands can have equals in them
    command: echo "==========="

  - name: Commands with cmd
    command:
      cmd:
        echo "-------"

  - name: Command with stdin (ansible > 2.4)
    command: /bin/cat
    args:
      stdin: "Hello, world!"

  - name: Use argv to send the command as a list
    command:
      argv:
        - /bin/echo
        - Hello
        - World

  - name: Another use of argv
    command:
    args:
      argv:
        - echo
        - testing

  - name: Environment variable with shell
    shell: HELLO=hello echo $HELLO

  - name: Command with stdin_add_newline (ansible > 2.8)
    command: /bin/cat
    args:
      stdin: "Hello, world!"
      stdin_add_newline: false

  - name: Command with strip_empty_ends (ansible > 2.8)
    command: echo
    args:
      strip_empty_ends: false

  - name: Command with expand_argument_vars option
    command:
      cmd: /bin/echo $LITERAL
      expand_argument_vars: false

  - name: Mutually exclusive cmd and argv should not trigger a false-positive
    ansible.builtin.command:
      cmd: /bin/echo
      argv:
         - Hello
"""

FAIL_PLAY_TASKS = """
- hosts: localhost

  tasks:
  - name: Environment variable with command
    command: HELLO=hello echo $HELLO

  - name: Typo some stuff
    command: crates=/tmp/blah touch /tmp/blah
"""


def test_success(app: App, empty_rule_collection: RulesCollection) -> None:
    """Positive test for inline-env-var."""
    empty_rule_collection.register(EnvVarsInCommandRule())
    runner = RunFromText(empty_rule_collection, app)
    results = runner.run_playbook(SUCCESS_PLAY_TASKS)
    assert len(results) == 0


def test_fail(app: App, empty_rule_collection: RulesCollection) -> None:
    """Negative test for inline-env-var."""
    empty_rule_collection.register(EnvVarsInCommandRule())
    runner = RunFromText(empty_rule_collection, app)
    results = runner.run_playbook(FAIL_PLAY_TASKS)
    assert len(results) == 2
