"""Skills package for Zeer CLI."""
