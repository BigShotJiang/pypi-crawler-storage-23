"""Text processing skill."""
