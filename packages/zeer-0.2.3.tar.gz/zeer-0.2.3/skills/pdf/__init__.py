"""PDF builder skill."""
