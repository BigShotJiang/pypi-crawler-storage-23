"""Frontend design skill."""
