"""File operations skill."""
