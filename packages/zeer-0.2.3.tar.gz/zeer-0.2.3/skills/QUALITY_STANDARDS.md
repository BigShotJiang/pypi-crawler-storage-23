# Quality Standards for All Skills

This document defines the universal quality standards that apply to ALL skills and outputs.

## Core Principles

1. **Professional Quality**: Every output should be production-ready, not a prototype or demo
2. **Modern Design**: Use current best practices, modern patterns, and contemporary aesthetics
3. **Attention to Detail**: Pay attention to spacing, typography, colors, and visual hierarchy
4. **User Experience**: Consider usability, accessibility, and user delight
5. **Completeness**: Deliver fully functional, polished results

## Universal Quality Checklist

### Visual Design
- [ ] Professional, modern aesthetic
- [ ] Consistent visual theme throughout
- [ ] Proper use of whitespace and spacing
- [ ] Clear visual hierarchy
- [ ] Appropriate color palette (not just black/white)
- [ ] Professional typography with proper font choices

### Technical Quality
- [ ] Clean, maintainable code
- [ ] Follows best practices for the technology
- [ ] Responsive and adaptive where applicable
- [ ] Performance-optimized
- [ ] Accessible (WCAG guidelines where applicable)

### Content Quality
- [ ] Well-written, clear content
- [ ] Proper grammar and spelling
- [ ] Appropriate tone for the context
- [ ] Complete information (no placeholders like "Lorem ipsum" unless explicitly requested)

## What to AVOID

- ❌ Basic, minimal designs that look like beginner work
- ❌ Generic templates with no personality
- ❌ Inconsistent styling across components
- ❌ Poor spacing and cluttered layouts
- ❌ Placeholder content in final deliverables
- ❌ Outdated design patterns or deprecated code
- ❌ Inaccessible color contrasts or font sizes

## Skill-Specific Standards

Each skill (pdf, pptx, frontend-design, etc.) has its own SKILL.md file with detailed, domain-specific quality standards. Always refer to the activated skill's guidelines for specific requirements.

## Remember

Quality is not optional. Users expect professional, polished results. When in doubt, aim higher.
