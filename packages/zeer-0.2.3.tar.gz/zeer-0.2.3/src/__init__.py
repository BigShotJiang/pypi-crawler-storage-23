"""Zeer - Agentic AI CLI with tool calling and extensible skills system."""

__version__ = "0.2.3"
