"""
Ollama LLM provider – local inference with no API key required.

Requires a running Ollama instance (https://ollama.ai).

Environment variables:
    OPENRAG_OLLAMA_BASE_URL    Ollama server URL   (default: http://localhost:11434)
    OPENRAG_OLLAMA_MODEL       Model name          (default: llama3.2)
    OPENRAG_OLLAMA_TEMPERATURE float               (default: 0.1)
"""

import logging
import os
import time
from typing import Any, Optional, Type

from pydantic import BaseModel
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from ..base import LLMProvider, LLMResponse

logger = logging.getLogger(__name__)

_DEFAULT_MODEL = "llama3.2"
_DEFAULT_BASE_URL = "http://localhost:11434"


class OllamaProvider(LLMProvider):
    """
    Ollama local LLM provider.

    Uses ``langchain-ollama`` (``ChatOllama``).  No API key is needed —
    just start an Ollama server and set ``OPENRAG_OLLAMA_MODEL``.
    """

    def __init__(self, model: str, **kwargs):
        self.base_url = kwargs.get(
            "base_url",
            os.getenv("OPENRAG_OLLAMA_BASE_URL", _DEFAULT_BASE_URL),
        )
        # Set before super().__init__ so _validate_config can read them
        super().__init__(model, **kwargs)
        self._client = None
        self._initialize_client()

    # ------------------------------------------------------------------
    # LLMProvider interface
    # ------------------------------------------------------------------

    def _validate_config(self) -> None:
        pass  # No API key required for Ollama

    def _initialize_client(self) -> None:
        try:
            from langchain_ollama import ChatOllama

            temperature = float(self.config.get("default_temperature", 0.1))
            self._client = ChatOllama(
                model=self.model,
                base_url=self.base_url,
                temperature=temperature,
            )
            logger.info(
                "Ollama provider configured: model=%s base_url=%s",
                self.model, self.base_url,
            )
        except ImportError as e:
            raise RuntimeError(
                "langchain-ollama is required. "
                "Install with: pip install langchain-ollama"
            ) from e

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> LLMResponse:
        start_time = time.time()
        try:
            message = HumanMessage(content=prompt)
            result = self._client.invoke([message])
            return LLMResponse(
                content=result.content,
                model=self.model,
                provider="ollama",
                response_time=time.time() - start_time,
            )
        except Exception as e:
            logger.error("Ollama generate failed: %s", e)
            raise RuntimeError(f"Ollama call failed: {e}") from e

    def generate_structured(
        self,
        prompt: str,
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> Any:
        start_time = time.time()
        try:
            parser = JsonOutputParser()
            chain = self._client | parser
            message = HumanMessage(content=prompt)
            result = chain.invoke([message])
            logger.debug("Ollama structured output in %.2fs", time.time() - start_time)
            return result
        except Exception as e:
            logger.error("Ollama structured generation failed: %s", e)
            raise RuntimeError(f"Ollama structured call failed: {e}") from e
