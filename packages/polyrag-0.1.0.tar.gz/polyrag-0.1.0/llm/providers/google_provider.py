"""Google AI LLM provider implementation."""

from typing import Dict, Any, Optional, Type, Union
from pydantic import BaseModel
import time
import logging
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from ..base import LLMProvider, LLMResponse

logger = logging.getLogger(__name__)


class GoogleProvider(LLMProvider):
    """Google AI LLM provider using langchain-google-genai."""
    
    def __init__(self, model: str, api_key: str, **kwargs):
        self.api_key = api_key  # Set API key before parent init
        super().__init__(model, **kwargs)
        self.client = None
        self._initialize_client()
    
    def _validate_config(self) -> None:
        """Validate Google AI configuration."""
        if not hasattr(self, 'api_key') or not self.api_key:
            raise ValueError("Google API key is required")
    
    def _initialize_client(self):
        """Initialize the Google AI client."""
        try:
            # Extract Google-specific parameters
            google_params = {
                "model": self.model,
                "google_api_key": self.api_key,  # Note: different parameter name
                "temperature": self.config.get("default_temperature", 0.0),
                "max_output_tokens": self.config.get("max_output_tokens"),
            }
            
            # Add Google-specific parameters if present
            if "top_p" in self.config:
                google_params["top_p"] = self.config["top_p"]
            if "top_k" in self.config:
                google_params["top_k"] = self.config["top_k"]
            
            # Remove None values
            google_params = {k: v for k, v in google_params.items() if v is not None}
            
            self.client = ChatGoogleGenerativeAI(**google_params)
            logger.debug(f"Initialized Google AI client with model: {self.model}")
            
        except Exception as e:
            logger.error(f"Failed to initialize Google AI client: {e}")
            raise RuntimeError(f"Google AI initialization failed: {e}")
    
    def generate(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text from prompt."""
        start_time = time.time()
        
        try:
            # Create a new client instance with specific parameters for this request
            request_params = {
                "model": self.model,
                "google_api_key": self.api_key,
                "temperature": temperature or self.config.get("default_temperature", 0.0),
            }
            
            if max_tokens:
                request_params["max_output_tokens"] = max_tokens
            
            # Add Google-specific parameters
            if "top_p" in kwargs:
                request_params["top_p"] = kwargs["top_p"]
            elif "top_p" in self.config:
                request_params["top_p"] = self.config["top_p"]
                
            if "top_k" in kwargs:
                request_params["top_k"] = kwargs["top_k"]
            elif "top_k" in self.config:
                request_params["top_k"] = self.config["top_k"]
            
            # Remove None values
            request_params = {k: v for k, v in request_params.items() if v is not None}
            
            client = ChatGoogleGenerativeAI(**request_params)
            
            # Generate response
            message = HumanMessage(content=prompt)
            response = client.invoke([message])
            
            response_time = time.time() - start_time
            
            # Extract usage information if available
            usage = None
            if hasattr(response, 'response_metadata') and response.response_metadata:
                usage_metadata = response.response_metadata.get('usage_metadata', {})
                usage = {
                    "prompt_token_count": usage_metadata.get('prompt_token_count', 0),
                    "candidates_token_count": usage_metadata.get('candidates_token_count', 0),
                    "total_token_count": usage_metadata.get('total_token_count', 0),
                }
            
            return LLMResponse(
                content=response.content,
                model=self.model,
                provider="google",
                usage=usage,
                response_time=response_time,
                finish_reason=getattr(response, 'finish_reason', None),
                metadata={
                    "temperature": temperature or self.config.get("default_temperature", 0.0),
                    "max_output_tokens": max_tokens,
                    "top_p": request_params.get("top_p"),
                    "top_k": request_params.get("top_k"),
                }
            )
            
        except Exception as e:
            logger.error(f"Google AI generation failed: {e}")
            raise RuntimeError(f"Google AI API call failed: {e}")
    
    def generate_structured(
        self, 
        prompt: str, 
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Any:
        """Generate structured output matching the provided schema."""
        start_time = time.time()
        
        try:
            # Create client with structured output configuration
            request_params = {
                "model": self.model,
                "google_api_key": self.api_key,
                "temperature": temperature or 0.0,  # Lower temp for structured output
            }
            
            if max_tokens:
                request_params["max_output_tokens"] = max_tokens
            
            # Add Google-specific parameters for better structured output
            request_params["top_p"] = kwargs.get("top_p", 0.95)
            request_params["top_k"] = kwargs.get("top_k", 40)
            
            # Remove None values
            request_params = {k: v for k, v in request_params.items() if v is not None}
            
            client = ChatGoogleGenerativeAI(**request_params)
            
            # Check if format is specified as "json" to use JsonOutputParser
            format_type = kwargs.get("format", "").lower()
            
            if format_type == "json":
                # Use JsonOutputParser instead of structured output
                parser = JsonOutputParser()
                chain = client | parser
                
                # Generate response using JsonOutputParser
                message = HumanMessage(content=prompt)
                response = chain.invoke([message])
            else:
                # Use langchain's structured output capability
                structured_client = client.with_structured_output(response_schema)
                
                # Generate structured response
                message = HumanMessage(content=prompt)
                response = structured_client.invoke([message])
            
            response_time = time.time() - start_time
            
            logger.debug(f"Generated structured output in {response_time:.2f}s")
            
            return response
            
        except Exception as e:
            logger.error(f"Google AI structured generation failed: {e}")
            raise RuntimeError(f"Google AI structured API call failed: {e}")
    
    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for Google AI models."""
        # Google AI token estimation (rough approximation)
        return len(text.split()) * 1.2  # Average ~1.2 tokens per word for Gemini
    
    def get_available_models(self) -> list[str]:
        """Get list of available Google AI models."""
        return [
            "gemini-2.0-flash",
            "gemini-2.5-flash",
            "gemini-1.5-flash",
            "gemini-1.5-pro",
            "gemini-pro",
        ]
    
    def supports_structured_output(self) -> bool:
        """Check if the current model supports structured output."""
        # Most Gemini models support structured output
        structured_models = ["gemini-2.0", "gemini-2.5", "gemini-1.5", "gemini-pro"]
        return any(model in self.model for model in structured_models)
    
    def get_model_context_length(self) -> int:
        """Get context length for the current model."""
        context_lengths = {
            "gemini-2.0-flash": 1000000,  # 1M tokens
            "gemini-2.5-flash": 1000000,
            "gemini-1.5-flash": 1000000,
            "gemini-1.5-pro": 2000000,    # 2M tokens
            "gemini-pro": 32768,
        }
        
        for model_name, length in context_lengths.items():
            if model_name in self.model:
                return length
        
        return 32768  # Default fallback
    
    def supports_multimodal(self) -> bool:
        """Check if the current model supports multimodal inputs."""
        multimodal_models = ["gemini-2.0", "gemini-2.5", "gemini-1.5", "gemini-pro"]
        return any(model in self.model for model in multimodal_models)
