"""OpenAI LLM provider implementation."""

from typing import Dict, Any, Optional, Type, Union
from pydantic import BaseModel
import time
import logging
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from ..base import LLMProvider, LLMResponse

logger = logging.getLogger(__name__)


class OpenAIProvider(LLMProvider):
    """OpenAI LLM provider using langchain-openai."""
    
    def __init__(self, model: str, api_key: str, **kwargs):
        self.api_key = api_key  # Set API key before parent init
        super().__init__(model, **kwargs)
        self.client = None
        self._initialize_client()
    
    def _validate_config(self) -> None:
        """Validate OpenAI configuration."""
        if not hasattr(self, 'api_key') or not self.api_key:
            raise ValueError("OpenAI API key is required")
    
    def _initialize_client(self):
        """Initialize the OpenAI client."""
        try:
            # Extract OpenAI-specific parameters
            openai_params = {
                "model": self.model,
                "api_key": self.api_key,
                "temperature": self.config.get("default_temperature", 0.0),
                "max_tokens": self.config.get("max_tokens"),
                "timeout": self.config.get("timeout", 120),  # Use timeout from config
            }
            
            # O1 and O3 models don't support temperature and max_tokens parameters
            if "o1" in self.model or "o3" in self.model:
                openai_params.pop("temperature", None)
                openai_params.pop("max_tokens", None)
            
            # Remove None values
            openai_params = {k: v for k, v in openai_params.items() if v is not None}
            
            self.client = ChatOpenAI(**openai_params)
            logger.debug(f"Initialized OpenAI client with model: {self.model}, timeout: {openai_params.get('timeout')}s")
            
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            raise RuntimeError(f"OpenAI initialization failed: {e}")
    
    def generate(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text from prompt."""
        start_time = time.time()
        
        try:
            # Create a new client instance with specific parameters for this request
            request_params = {
                "model": self.model,
                "api_key": self.api_key,
                "timeout": self.config.get("timeout", 120),  # Use timeout from config
            }
            
            # For o1 and o3 models, never include temperature or max_tokens
            if "o1" not in self.model and "o3" not in self.model:
                request_params["temperature"] = temperature or self.config.get("default_temperature", 0.0)
                if max_tokens:
                    request_params["max_tokens"] = max_tokens
            
            # Remove None values
            request_params = {k: v for k, v in request_params.items() if v is not None}
            
            client = ChatOpenAI(**request_params)
            
            # Generate response
            message = HumanMessage(content=prompt)
            response = client.invoke([message])
            
            response_time = time.time() - start_time
            
            # Extract usage information if available
            usage = None
            if hasattr(response, 'response_metadata') and response.response_metadata:
                token_usage = response.response_metadata.get('token_usage', {})
                usage = {
                    "prompt_tokens": token_usage.get('prompt_tokens', 0),
                    "completion_tokens": token_usage.get('completion_tokens', 0),
                    "total_tokens": token_usage.get('total_tokens', 0),
                }
            
            return LLMResponse(
                content=response.content,
                model=self.model,
                provider="openai",
                usage=usage,
                response_time=response_time,
                finish_reason=getattr(response, 'finish_reason', None),
                metadata={
                    "temperature": request_params.get("temperature"),
                    "max_tokens": max_tokens,
                }
            )
            
        except Exception as e:
            logger.error(f"OpenAI generation failed: {e}")
            raise RuntimeError(f"OpenAI API call failed: {e}")
    
    def generate_structured(
        self, 
        prompt: str, 
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Any:
        """Generate structured output matching the provided schema."""
        start_time = time.time()
        
        try:
            # Create client with structured output configuration
            request_params = {
                "model": self.model,
                "api_key": self.api_key,
                "timeout": self.config.get("timeout", 120),  # Use timeout from config
            }
            
            # For o1 and o3 models, never include temperature or max_tokens
            if "o1" not in self.model and "o3" not in self.model:
                request_params["temperature"] = temperature or 0.0  # Lower temp for structured output
                if max_tokens:
                    request_params["max_tokens"] = max_tokens
            
            # Remove None values
            request_params = {k: v for k, v in request_params.items() if v is not None}
            
            client = ChatOpenAI(**request_params)
            
            # Check if format is specified as "json" to use JsonOutputParser
            format_type = kwargs.get("format", "").lower()
            
            if format_type == "json":
                # Use JsonOutputParser instead of structured output
                parser = JsonOutputParser()
                chain = client | parser
                
                # Generate response using JsonOutputParser
                message = HumanMessage(content=prompt)
                response = chain.invoke([message])
            else:
                # Use langchain's structured output capability
                structured_client = client.with_structured_output(response_schema)
                
                # Generate structured response
                message = HumanMessage(content=prompt)
                response = structured_client.invoke([message])
            
            response_time = time.time() - start_time
            
            logger.debug(f"Generated structured output in {response_time:.2f}s")
            
            return response
            
        except Exception as e:
            logger.error(f"OpenAI structured generation failed: {e}")
            raise RuntimeError(f"OpenAI structured API call failed: {e}")
    
    def estimate_tokens(self, text: str) -> int:
        """Estimate token count for OpenAI models."""
        # More accurate estimation for OpenAI models
        # This is a rough approximation - for production use tiktoken
        return len(text.split()) * 1.3  # Average ~1.3 tokens per word
    
    def get_available_models(self) -> list[str]:
        """Get list of available OpenAI models."""
        return [
            "gpt-5.2",
            "o3",
            "o3-mini",
            "o1",
            "o1-mini",
            "gpt-4o",
            "gpt-4o-mini", 
            "gpt-4",
            "gpt-4-turbo",
            "gpt-3.5-turbo",
        ]
    
    def supports_structured_output(self) -> bool:
        """Check if the current model supports structured output."""
        structured_models = ["gpt-5.2", "o3", "o1", "gpt-4o", "gpt-4o-mini", "gpt-4", "gpt-4-turbo"]
        return any(model in self.model for model in structured_models)
    
    def get_model_context_length(self) -> int:
        """Get context length for the current model."""
        context_lengths = {
            "gpt-5.2": 128000,
            "o3": 200000,  # O3 context length
            "o3-mini": 200000,  # O3 mini context length
            "o1": 200000,  # O1 context length
            "o1-mini": 128000,
            "gpt-4o": 128000,
            "gpt-4o-mini": 128000,
            "gpt-4": 8192,
            "gpt-4-turbo": 128000,
            "gpt-3.5-turbo": 4096,
        }
        
        for model_name, length in context_lengths.items():
            if model_name in self.model:
                return length
        
        return 4096  # Default fallback
