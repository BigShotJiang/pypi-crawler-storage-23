"""
HuggingFace LLM provider – supports both cloud API and local pipeline modes.

Mode is selected via ``OPENRAG_HF_MODE``:

    api   (default) – calls the HuggingFace Inference API (requires HUGGINGFACE_API_TOKEN)
    local            – downloads and runs the model locally via ``transformers``
                       (requires GPU/CPU RAM, no API token needed)

Environment variables:
    OPENRAG_HF_MODE              api | local            (default: api)
    HUGGINGFACE_API_TOKEN        HF Hub token           (required for api mode)
    OPENRAG_HF_MODEL             model repo-id          (default: mistralai/Mistral-7B-Instruct-v0.2)
    OPENRAG_HF_TASK              text-generation | text2text-generation  (default: text-generation)
    OPENRAG_HF_MAX_NEW_TOKENS    int                    (default: 1024)
    OPENRAG_HF_TEMPERATURE       float                  (default: 0.1)
"""

import logging
import os
import time
from typing import Any, Optional, Type

from pydantic import BaseModel
from langchain_core.messages import HumanMessage
from langchain_core.output_parsers import JsonOutputParser

from ..base import LLMProvider, LLMResponse

logger = logging.getLogger(__name__)

_DEFAULT_MODEL = "mistralai/Mistral-7B-Instruct-v0.2"


class HuggingFaceProvider(LLMProvider):
    """
    HuggingFace LLM provider.

    Wraps ``langchain-huggingface`` (``ChatHuggingFace`` backed by either
    ``HuggingFaceEndpoint`` for API mode or ``HuggingFacePipeline`` for
    local mode).
    """

    def __init__(self, model: str, **kwargs):
        self.hf_mode = kwargs.get("hf_mode", os.getenv("OPENRAG_HF_MODE", "api")).lower()
        self.api_token = kwargs.get(
            "api_token",
            os.getenv("HUGGINGFACE_API_TOKEN", ""),
        )
        self.max_new_tokens = int(
            kwargs.get("max_new_tokens", os.getenv("OPENRAG_HF_MAX_NEW_TOKENS", "1024"))
        )
        self.hf_task = kwargs.get(
            "task",
            os.getenv("OPENRAG_HF_TASK", "text-generation"),
        )
        # Set before super().__init__ so _validate_config can read them
        super().__init__(model, **kwargs)
        self._client = None
        self._initialize_client()

    # ------------------------------------------------------------------
    # LLMProvider interface
    # ------------------------------------------------------------------

    def _validate_config(self) -> None:
        if self.hf_mode == "api" and not self.api_token:
            raise ValueError(
                "HUGGINGFACE_API_TOKEN is required when OPENRAG_HF_MODE=api. "
                "Set the environment variable or pass api_token= to the constructor."
            )

    def _initialize_client(self) -> None:
        """Build the LangChain chat client for the selected mode."""
        temperature = float(self.config.get("default_temperature", 0.1))

        if self.hf_mode == "local":
            try:
                from langchain_huggingface import ChatHuggingFace, HuggingFacePipeline

                pipeline = HuggingFacePipeline.from_model_id(
                    model_id=self.model,
                    task=self.hf_task,
                    pipeline_kwargs={
                        "max_new_tokens": self.max_new_tokens,
                        "temperature": temperature,
                        "do_sample": True,
                    },
                )
                self._client = ChatHuggingFace(llm=pipeline)
                logger.info(
                    "HuggingFace local pipeline loaded: model=%s task=%s",
                    self.model, self.hf_task,
                )
            except ImportError as e:
                raise RuntimeError(
                    "langchain-huggingface and transformers are required for local mode. "
                    "Install with: pip install langchain-huggingface transformers accelerate"
                ) from e
        else:
            try:
                from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint

                endpoint = HuggingFaceEndpoint(
                    repo_id=self.model,
                    task=self.hf_task,
                    huggingfacehub_api_token=self.api_token,
                    max_new_tokens=self.max_new_tokens,
                    temperature=temperature,
                )
                self._client = ChatHuggingFace(llm=endpoint)
                logger.info(
                    "HuggingFace API endpoint configured: model=%s task=%s",
                    self.model, self.hf_task,
                )
            except ImportError as e:
                raise RuntimeError(
                    "langchain-huggingface is required. "
                    "Install with: pip install langchain-huggingface"
                ) from e

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> LLMResponse:
        start_time = time.time()
        try:
            message = HumanMessage(content=prompt)
            result = self._client.invoke([message])
            content = result.content if hasattr(result, "content") else str(result)
            return LLMResponse(
                content=content,
                model=self.model,
                provider="huggingface",
                response_time=time.time() - start_time,
            )
        except Exception as e:
            logger.error("HuggingFace generate failed: %s", e)
            raise RuntimeError(f"HuggingFace API call failed: {e}") from e

    def generate_structured(
        self,
        prompt: str,
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> Any:
        start_time = time.time()
        try:
            parser = JsonOutputParser()
            chain = self._client | parser
            message = HumanMessage(content=prompt)
            result = chain.invoke([message])
            logger.debug(
                "HuggingFace structured output in %.2fs", time.time() - start_time
            )
            return result
        except Exception as e:
            logger.error("HuggingFace structured generation failed: %s", e)
            raise RuntimeError(f"HuggingFace structured call failed: {e}") from e
