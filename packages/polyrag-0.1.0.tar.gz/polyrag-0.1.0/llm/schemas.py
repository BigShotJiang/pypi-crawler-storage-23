"""Pydantic schemas for LLM requests, responses, and structured outputs."""

from typing import Dict, Any, List, Optional, Union, Literal
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


# === Request/Response Schemas ===

class GenerationConfig(BaseModel):
    """Configuration for LLM generation."""
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    stop_sequences: Optional[List[str]] = None
    use_cache: bool = True


class LLMRequest(BaseModel):
    """Standard LLM request format."""
    prompt: str
    model: Optional[str] = None
    config: Optional[GenerationConfig] = None
    metadata: Optional[Dict[str, Any]] = None


class LLMStructuredRequest(LLMRequest):
    """Request for structured output generation."""
    response_schema: str = Field(..., description="Name of the response schema class")
    validation_prompt: Optional[str] = None


# === Structured Output Schemas ===
# Based on patterns found in your current codebase

class FollowUpLegacy(BaseModel):
    """Legacy schema - kept for backward compatibility if needed."""
    followup_questions: List[str] = Field(description="Two follow-up questions in the direction of the knowing a company's info given the previous conversation.")


class UserRequirementsOld(BaseModel):
    """Schema for extracting user requirements from conversations (legacy)."""
    requirements: List[str] = Field(..., description="List of user requirements extracted from conversation")
    context: Optional[str] = Field(None, description="Additional context about the requirements")
    priority: Optional[str] = Field(None, description="Priority level: high, medium, low")

class Step(BaseModel):
    step_name: str
    actors: List[str]
    action: str
    input_entities: List[str]
    output_entities: List[str]
    # relationships: List[Relationship]

class Process(BaseModel):
    name: str
    description: Optional[str] = None
    intent: Optional[str] = None
    steps: List[Step]

class Entity(BaseModel):
    name: str
    type: Literal["Actor", "Artifact", "Concept", "Resource"]
    attributes: List[str]

class OntologyExtraction(BaseModel):
    processes: List[Process]
    entities: List[Entity]

##Onotlogies Schema
class Concept(BaseModel):
    name: str
    attributes: List[str]

class Relationship(BaseModel):
    from_: str = Field(..., alias="from")
    to: str
    type: str

class OntologySchema(BaseModel):
    concepts: List[Concept]
    relationships: List[Relationship]

class BusinessSummary(BaseModel):
    """Schema for business analysis and workflow extraction."""
    business_overview: str = Field(..., description="What the organization does, its business goals and mission")
    users_and_stakeholders: str = Field(..., description="Types of users, customers, stakeholders, or roles")
    workflows_and_processes: str = Field(..., description="Detailed steps, sequences, and processes")
    success_metrics: str = Field(..., description="KPIs, outcomes, performance indicators, targets")
    key_systems: str = Field(..., description="Important tools, platforms, or systems the business uses")


class RequestUnderstandingOld(BaseModel):
    """Schema for understanding user requests in different contexts (legacy)."""
    requests: List[Dict[str, Any]] = Field(..., description="Parsed and structured user requests")
    intent: str = Field(..., description="Overall intent of the user")
    entities: List[str] = Field(default_factory=list, description="Key entities mentioned")
    confidence: Optional[float] = Field(None, description="Confidence score 0-1")


class ViewDefinitionOld(BaseModel):
    """Schema for Neo4j view/query definition (legacy)."""
    nodes: List[Dict[str, Any]] = Field(..., description="Node definitions with labels and properties")
    relationships: List[Dict[str, Any]] = Field(..., description="Relationship definitions")
    filters: Optional[List[Dict[str, Any]]] = Field(None, description="Filter conditions")
    view_name: str = Field(..., description="Name of the view")
    description: Optional[str] = Field(None, description="Description of what the view represents")


class CypherOld(BaseModel):
    """Schema for Cypher query generation (legacy)."""
    query: str = Field(..., description="The generated Cypher query")


class ValidCypherOld(BaseModel):
    """Schema for validated Cypher queries (legacy)."""
    query: str = Field(..., description="The validated Cypher query")
    is_valid: bool = Field(..., description="Whether the query is syntactically valid")
    errors: List[str] = Field(default_factory=list, description="Validation errors if any")
    suggestions: List[str] = Field(default_factory=list, description="Improvement suggestions")


class ViewQueryOld(BaseModel):
    """Schema for view creation queries (legacy)."""
    query: str = Field(..., description="The SQL or Cypher query for the view")
    view_type: str = Field(..., description="Type of view: materialized, standard, etc.")
    dependencies: List[str] = Field(default_factory=list, description="Tables or views this depends on")
    refresh_schedule: Optional[str] = Field(None, description="How often to refresh if materialized")


# === Analytics Section ===
# Schemas for fetching relevant dataframes from graph without rigorous filters or metrics calculations

class UserRequirements(BaseModel):
    """Clear and concise list of user requirements."""
    requirements: List[str] = Field(..., description="Clear and Concise list of user requirements.")


class ViewDefinition(BaseModel):
    """Schema for Neo4j view definition - fetches relevant dataframe from graph."""
    view_name: str = Field(..., description="A short machine-friendly and can be easily understandable for the view (snake_case).")
    node_labels: List[str] = Field(..., description='Which node labels to include, e.g. ["Office","LoanDistribution"].')
    rel_types: List[str] = Field(..., description='Which relationship types to traverse.')
    properties: Optional[Dict[str, List[str]]] = Field(..., description='Map of label to list of properties to select.')


class Cypher(BaseModel):
    """Schema for Cypher query."""
    cypher: str = Field(..., description="A valid cypher query")


class ValidCypher(BaseModel):
    """Schema for validating Cypher queries."""
    valid: str = Field(..., description="yes or no, depending on if the cypher query is valid or not. If valid then yes, else no")


class RequestUnderstanding(BaseModel):
    """Schema for understanding and contextualizing user requests."""
    requests: List[str] = Field(..., description="A list of contextualized separate requests that are relevant to and from the user's requirement.")


class ViewQuery(BaseModel):
    """Schema for SQL query."""
    query: str = Field(..., description="A valid SQL query.")


class Query(BaseModel):
    """Schema for general SQL queries."""
    query: str = Field(..., description="The SQL query")
    query_type: str = Field(..., description="SELECT, INSERT, UPDATE, DELETE")
    tables_involved: List[str] = Field(default_factory=list, description="Tables used in the query")
    estimated_rows: Optional[int] = Field(None, description="Estimated number of rows returned")


class QueryResponse(BaseModel):
    """Schema for query response analysis."""
    response: str = Field(..., description="Natural language response to the query results")
    summary: Optional[str] = Field(None, description="Brief summary of findings")
    key_insights: List[str] = Field(default_factory=list, description="Key insights from the data")
    follow_up_questions: List[str] = Field(default_factory=list, description="Suggested follow-up questions")


class QuerySchema(BaseModel):
    """Schema for database schema understanding."""
    response: str = Field(..., description="Description of the schema structure")
    tables: List[Dict[str, Any]] = Field(default_factory=list, description="Table information")
    relationships: List[Dict[str, Any]] = Field(default_factory=list, description="Table relationships")
    indexes: List[str] = Field(default_factory=list, description="Important indexes")


class FollowUp(BaseModel):
    """Schema for follow-up questions and conversation continuation."""
    followup_questions: List[str] = Field(..., description="List of follow-up questions (typically 2 questions)")
    if_end: bool = Field(..., description="Whether the conversation should end")
    potential_responses: List[str] = Field(..., description="List of potential responses with exactly 4 options per question. For 2 questions, provide 8 responses total. The responses are allocated sequentially: first 4 responses correspond to question 1, next 4 responses correspond to question 2, and so on.")
    next_step: Optional[str] = Field(None, description="Suggested next step")
    context_summary: Optional[str] = Field(None, description="Summary of current conversation context")


class ConversationDecision(BaseModel):
    """Schema for routing conversation flow based on user intent."""
    next_step: Literal["workflow", "analytics", "normal_qa", "platform"] = Field(
        ..., 
        description="The next step in the conversation: workflow (automation/workflow creation), analytics (charts/plots), normal_qa (data queries/insights), or platform (platform-related queries)"
    )


class PropertyDescription(BaseModel):
    """Description of a single property"""
    property_name: str = Field(description="Name of the property")
    description: str = Field(description="Why this property is important")

class AggregationOperation(BaseModel):
    """Aggregation operation for a single column"""
    column_name: str = Field(description="Name of the column")
    operations: List[str] = Field(description="List of aggregation operations (SUM, COUNT, AVG, etc.)")

class CriticalPropertiesAnalysis(BaseModel):
    """Schema for critical property analysis from user request"""
    explicit_properties: List[str] = Field(
        default_factory=list,
        description="Properties explicitly mentioned in user request"
    )
    priority_properties: List[str] = Field(
        default_factory=list,
        description="Properties inferred as important for the analysis based on domain understanding"
    )
    property_descriptions: List[PropertyDescription] = Field(
        default_factory=list,
        description="Domain context/description for each critical property explaining why it's important"
    )
    reasoning: str = Field(
        default="",
        description="Explanation of why these properties were selected and their relevance to the user's request"
    )


class AggregationIntent(BaseModel):
    """Schema for aggregation intent analysis from user request"""
    group_by_columns: List[str] = Field(
        default_factory=list,
        description="Columns to use for GROUP BY operations in the final view"
    )
    aggregate_operations: List[AggregationOperation] = Field(
        default_factory=list,
        description="Aggregation operations per column (e.g., [{'column_name': 'amount', 'operations': ['SUM', 'AVG']}])"
    )
    filter_conditions: List[str] = Field(
        default_factory=list,
        description="Optional filter conditions (e.g., ['status = active', 'amount > 0'])"
    )
    reasoning: str = Field(
        default="",
        description="Explanation of the aggregation strategy and why these operations are appropriate"
    )


# === Orchestration Schemas ===

class TaskType(str, Enum):
    """Types of tasks in workflow orchestration."""
    API_CALL = "api_call"
    HUMAN_TASK = "human_task"
    DATA_PROCESSING = "data_processing"
    VALIDATION = "validation"


class WorkflowTask(BaseModel):
    """Schema for individual workflow tasks."""
    task_name: str = Field(..., description="Name of the task")
    task_type: TaskType = Field(..., description="Type of task")
    inputparams: List[str] = Field(..., description="List of input parameters required")
    table_used: Optional[str] = Field(None, description="Database table involved")
    api_call: Optional[str] = Field(None, description="API endpoint to call")
    api_method: Optional[str] = Field("GET", description="HTTP method")
    api_body: Optional[Dict[str, Any]] = Field(None, description="Request body")
    api_headers: Optional[Dict[str, Any]] = Field(None, description="Request headers")
    assigned_to: str = Field(..., description="system or human")
    previous_task: Optional[str] = Field(None, description="Previous task name")
    next_task: Optional[str] = Field(None, description="Next task name")
    timeout: Optional[int] = Field(None, description="Task timeout in seconds")
    retry_count: Optional[int] = Field(0, description="Number of retries allowed")


class OrchestrationPlan(BaseModel):
    """Schema for complete workflow orchestration plans."""
    plan_name: str = Field(..., description="Name of the orchestration plan")
    description: str = Field(..., description="Description of what the plan accomplishes")
    tasks: List[WorkflowTask] = Field(..., description="List of tasks in execution order")
    estimated_duration: Optional[int] = Field(None, description="Estimated execution time in minutes")
    dependencies: List[str] = Field(default_factory=list, description="External dependencies required")
    success_criteria: List[str] = Field(default_factory=list, description="Criteria for successful completion")


# === Entity and Association Schemas ===

class EntityType(str, Enum):
    """Types of entities in the system."""
    PERSON = "person"
    ORGANIZATION = "organization"
    PROCESS = "process"
    SYSTEM = "system"
    DOCUMENT = "document"
    DATA = "data"


class Entity(BaseModel):
    """Schema for extracted entities."""
    name: str = Field(..., description="Entity name")
    type: EntityType = Field(..., description="Entity type")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Entity properties")
    confidence: Optional[float] = Field(None, description="Extraction confidence")
    source: Optional[str] = Field(None, description="Source of the entity")


class Relationship(BaseModel):
    """Schema for entity relationships."""
    source_entity: str = Field(..., description="Source entity name")
    target_entity: str = Field(..., description="Target entity name")
    relationship_type: str = Field(..., description="Type of relationship")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Relationship properties")
    confidence: Optional[float] = Field(None, description="Relationship confidence")
    bidirectional: bool = Field(False, description="Whether relationship is bidirectional")


class AssociationAnalysis(BaseModel):
    """Schema for association analysis results."""
    entities: List[Entity] = Field(..., description="Identified entities")
    relationships: List[Relationship] = Field(..., description="Identified relationships")
    summary: str = Field(..., description="Summary of associations found")
    recommendations: List[str] = Field(default_factory=list, description="Recommendations for data modeling")


# === Validation Schemas ===

class ValidationResult(BaseModel):
    """Schema for validation results."""
    is_valid: bool = Field(..., description="Whether the input is valid")
    errors: List[str] = Field(default_factory=list, description="List of validation errors")
    warnings: List[str] = Field(default_factory=list, description="List of warnings")
    suggestions: List[str] = Field(default_factory=list, description="Improvement suggestions")
    confidence: Optional[float] = Field(None, description="Validation confidence")


# === Email Processing Schemas ===

class EmailEntityType(str, Enum):
    """Types of entities that can be extracted from emails."""
    PERSON = "person"
    ORGANIZATION = "organization"
    LOCATION = "location"
    DATE_TIME = "date_time"
    PRODUCT = "product"
    SERVICE = "service"
    PROCESS = "process"
    CONCEPT = "concept"
    DOCUMENT = "document"
    MONEY = "money"
    EVENT = "event"


class EmailEntity(BaseModel):
    """Entity extracted from an email."""
    model_config = {"extra": "forbid"}
    
    id: str = Field(..., description="Unique identifier for this entity")
    name: str = Field(..., description="Entity name or value")
    type: EmailEntityType = Field(..., description="Type of entity")
    properties: Optional[str] = Field(default=None, description="Additional properties as JSON string (role, title, department, etc.)")
    email_id: str = Field(..., description="ID of the email this entity was extracted from")
    confidence: float = Field(default=1.0, ge=0, le=1, description="Confidence score for extraction")
    mentions: List[str] = Field(default_factory=list, description="Text snippets where entity was mentioned")


class EmailIntent(BaseModel):
    """Intent or action identified in an email."""
    model_config = {"extra": "forbid"}
    
    action: str = Field(..., description="The main action or verb (e.g., 'request', 'inform', 'approve')")
    description: str = Field(..., description="Brief description of the intent")
    actors: List[str] = Field(default_factory=list, description="Entity IDs of who is performing the action")
    targets: List[str] = Field(default_factory=list, description="Entity IDs of what/who is affected")
    email_id: str = Field(..., description="ID of the email")


class EmailProcess(BaseModel):
    """Process or workflow identified in emails."""
    model_config = {"extra": "forbid"}
    
    id: str = Field(..., description="Unique identifier for the process")
    name: str = Field(..., description="Process name")
    description: str = Field(..., description="Description of the process")
    steps: List[str] = Field(default_factory=list, description="Steps in the process")
    involved_entities: List[str] = Field(default_factory=list, description="Entity IDs involved in this process")
    email_ids: List[str] = Field(default_factory=list, description="Email IDs where this process was mentioned")


class EmailRelationship(BaseModel):
    """Relationship between entities extracted from emails."""
    model_config = {"extra": "forbid"}
    
    source_entity_id: str = Field(..., description="ID of source entity")
    target_entity_id: str = Field(..., description="ID of target entity")
    relationship_type: str = Field(..., description="Type of relationship (e.g., 'REPORTS_TO', 'WORKS_WITH', 'MANAGES')")
    properties: Optional[str] = Field(default=None, description="Additional relationship properties as JSON string")
    email_id: str = Field(..., description="Email ID where this relationship was identified")
    confidence: float = Field(default=1.0, ge=0, le=1, description="Confidence score")
    context: Optional[str] = Field(None, description="Context or evidence for this relationship")


class EmailBatchExtraction(BaseModel):
    """Complete extraction results from a batch of emails - Stage 1."""
    model_config = {"extra": "forbid"}
    
    entities: List[EmailEntity] = Field(..., description="All entities extracted from the email batch")
    intents: List[EmailIntent] = Field(..., description="All intents/actions identified")
    processes: List[EmailProcess] = Field(default_factory=list, description="Processes identified")
    summary: str = Field(..., description="High-level summary of what was extracted")


class EmailRelationshipExtraction(BaseModel):
    """Relationship extraction results - Stage 2."""
    model_config = {"extra": "forbid"}
    
    relationships: List[EmailRelationship] = Field(..., description="All relationships between entities")
    summary: str = Field(..., description="Summary of relationship patterns found")


class CrossEmailConnection(BaseModel):
    """Connection between different emails in a batch."""
    model_config = {"extra": "forbid"}
    
    email_ids: List[str] = Field(..., description="IDs of connected emails")
    connection_type: str = Field(..., description="Type of connection (e.g., 'thread', 'related_topic', 'same_process')")
    description: str = Field(..., description="Description of how these emails are connected")
    shared_entities: List[str] = Field(default_factory=list, description="Entity IDs that appear in multiple emails")
    temporal_order: Optional[List[str]] = Field(None, description="Chronological order of email_ids if applicable")


class CrossEmailAnalysis(BaseModel):
    """Cross-email analysis results - Stage 3."""
    model_config = {"extra": "forbid"}
    
    connections: List[CrossEmailConnection] = Field(..., description="Connections between emails")
    conversation_threads: List[str] = Field(default_factory=list, description="Identified conversation threads as JSON strings")
    temporal_relationships: List[str] = Field(default_factory=list, description="Time-based relationships as JSON strings")
    summary: str = Field(..., description="Summary of cross-email patterns")


class EntityResolution(BaseModel):
    """Entity deduplication and resolution - Stage 4 (Optional)."""
    model_config = {"extra": "forbid"}
    
    entity_groups: List[List[str]] = Field(..., description="Groups of entity IDs that refer to the same real-world entity")
    canonical_entities: List[str] = Field(..., description="List of mappings from duplicate to canonical as 'duplicate_id:canonical_id'")
    resolution_notes: List[str] = Field(default_factory=list, description="Notes on resolution decisions")


# === Relationship Modification Schemas ===

class RDSRelationshipItem(BaseModel):
    """A single RDS/SQL relationship."""
    model_config = {"extra": "forbid"}
    
    from_: str = Field(..., alias="from", description="Source table.column")
    to: str = Field(..., description="Target table.column")
    type: str = Field(..., description="Relationship type (e.g., LOCATED_IN, HAS_MANY)")
    business_logic: Optional[str] = Field(None, description="Business logic explanation")


class RDSRelationships(BaseModel):
    """RDS/SQL relationships structure."""
    model_config = {"extra": "forbid"}
    
    relationships: List[RDSRelationshipItem] = Field(..., description="List of relationships")


class MongoDBRelationshipItem(BaseModel):
    """A single MongoDB relationship within a collection."""
    model_config = {"extra": "forbid"}
    
    from_: str = Field(..., alias="from", description="Source field")
    to: str = Field(..., description="Target field")
    relationship_type: str = Field(..., description="Type of relationship")


class MongoDBCollectionRelationships(BaseModel):
    """Relationships for a MongoDB collection."""
    model_config = {"extra": "forbid"}
    
    relationships: List[MongoDBRelationshipItem] = Field(..., description="List of relationships in this collection")


class MongoDBRelationships(BaseModel):
    """MongoDB relationships structure."""
    model_config = {"extra": "allow"}  # Allow dynamic collection names as keys
    
    relationships: Dict[str, Any] = Field(..., description="Relationships organized by collection name")


class SheetsWithinSheetRelationship(BaseModel):
    """A relationship within a single sheet."""
    model_config = {"extra": "forbid"}
    
    from_column: str = Field(..., description="Source column")
    to_column: str = Field(..., description="Target column")
    relationship: str = Field(..., description="Relationship type")


class SheetsCrossSheetRelationship(BaseModel):
    """A relationship across different sheets."""
    model_config = {"extra": "forbid"}
    
    from_column: str = Field(..., description="Source column")
    to_column: str = Field(..., description="Target column")
    from_sheet: str = Field(..., description="Source sheet name")
    to_sheet: str = Field(..., description="Target sheet name")
    relationship_type: str = Field(..., description="Type of relationship")
    confidence: str = Field(..., description="Confidence level: high, medium, low")


class SheetsRelationships(BaseModel):
    """Sheets relationships structure."""
    model_config = {"extra": "allow"}  # Allow dynamic sheet names as keys
    
    within_sheet_relationships: Dict[str, Any] = Field(..., description="Within-sheet relationships by sheet name")
    cross_sheet_relationships: List[SheetsCrossSheetRelationship] = Field(..., description="Cross-sheet relationships")


class SemanticRelationship(BaseModel):
    """Semantic relationship between sheets (like foreign keys)."""
    from_sheet: str = Field(..., description="Source sheet/table name")
    from_column: str = Field(..., description="Source column name")
    to_sheet: str = Field(..., description="Target sheet/table name")
    to_column: str = Field(..., description="Target column name")
    relationship_type: str = Field(default="FOREIGN_KEY", description="Type of relationship (e.g., FOREIGN_KEY, REFERENCES)")
    confidence: str = Field(default="medium", description="Confidence level: high, medium, low")
    reason: Optional[str] = Field(None, description="Reasoning behind the relationship identification")


class SemanticRelationships(BaseModel):
    """Collection of semantic relationships extracted from sheets using LLM."""
    relationships: List[SemanticRelationship] = Field(..., description="List of identified semantic relationships between sheets")


class MongoDBCrossCollectionRelationship(BaseModel):
    """Semantic relationship between MongoDB collections (like foreign keys)."""
    from_collection: str = Field(..., description="Source collection name")
    from_field: str = Field(..., description="Source field name (can be nested path like 'user.id')")
    to_collection: str = Field(..., description="Target collection name")
    to_field: str = Field(..., description="Target field name (can be nested path like 'user_id')")
    relationship_type: str = Field(default="REFERENCES", description="Type of relationship (e.g., REFERENCES, HAS_MANY, BELONGS_TO)")
    confidence: str = Field(default="medium", description="Confidence level: high, medium, low")
    reason: Optional[str] = Field(None, description="Reasoning behind the relationship identification")


class MongoDBCrossCollectionRelationships(BaseModel):
    """Collection of cross-collection relationships for MongoDB."""
    relationships: List[MongoDBCrossCollectionRelationship] = Field(..., description="List of identified cross-collection relationships")


##For mongodb Relationships
class NodeMappingSchema(BaseModel):
    label: str = Field(description="Node label (e.g., Order, User, Item)")
    path: str = Field(description="Path in document (e.g., _root, user, items[])")
    id_field: str = Field(description="Field to use as node ID")
    properties: List[str] = Field(description="List of property fields to extract", default_factory=list)

class RelationMappingSchema(BaseModel):
    type: str = Field(description="Relationship type (e.g., PLACED_BY, CONTAINS)")
    from_path: str = Field(description="Source node path", default="_root")
    to_path: Optional[str] = Field(None, description="Target node path")
    fk_field: Optional[str] = Field(None, description="Foreign key field name")

class TextExtractionSchema(BaseModel):
    fields: List[str] = Field(description="Text fields to analyze", default_factory=list)
    entity_labels: List[str] = Field(description="Entity types to extract", default_factory=list)
    relation_types: List[str] = Field(description="Relationship types to extract", default_factory=list)

class MappingResponseSchema(BaseModel):
    nodes: List[NodeMappingSchema]
    relations: List[RelationMappingSchema]
    text_extraction: TextExtractionSchema

class ExtractedNodeSchema(BaseModel):
    label: str = Field(description="Entity type")
    id: str = Field(description="Unique identifier")
    props: Optional[Dict[str, str]] = Field(default=None, description="Entity properties (string values only)")
    
    class Config:
        extra = "forbid"

class ExtractedEdgeSchema(BaseModel):
    type: str = Field(description="Relationship type")
    from_id: str = Field(alias="from", description="Source node ID")
    to_id: str = Field(alias="to", description="Target node ID")
    
    class Config:
        extra = "forbid"

class TextExtractionResponseSchema(BaseModel):
    nodes: List[ExtractedNodeSchema] = Field(default_factory=list)
    edges: List[ExtractedEdgeSchema] = Field(default_factory=list)
    
    class Config:
        extra = "forbid"

class FKGuessSchema(BaseModel):
    to_label: str = Field(description="Target label for foreign key")
    rel: str = Field(description="Relationship type")


# === Document Metadata Extraction Schemas ===

class ExtractedEntity(BaseModel):
    """Entity extracted from document text."""
    model_config = {"extra": "forbid"}
    
    name: str = Field(..., description="Name of the entity")
    type: Literal["PERSON", "ORGANIZATION", "PRODUCT", "SERVICE", "SYSTEM", "CONCEPT", "OTHER"] = Field(
        ..., 
        description="Type of entity"
    )
    context: str = Field(..., description="Brief context or description of the entity")
    mentions: List[str] = Field(default_factory=list, description="Text snippets where entity appears (max 3)")


class ExtractedDateTime(BaseModel):
    """Date/time information extracted from document."""
    model_config = {"extra": "forbid"}
    
    datetime_string: str = Field(..., description="The date/time string as it appears in text (e.g., 'Q2 2025', 'January 15, 2024')")
    normalized_format: str = Field(
        ..., 
        description="Normalized date in OpenSearch-compatible format. REQUIRED. Use ISO 8601 format: YYYY-MM-DD for dates, YYYY-MM-DDTHH:MM:SS for datetimes. For periods (e.g., 'Q2 2025'), use the start date (e.g., '2025-04-01'). For quarters: Q1=01-01, Q2=04-01, Q3=07-01, Q4=10-01. For years only, use YYYY-01-01. Always provide a valid date format that OpenSearch can parse."
    )
    type: Literal["DATE", "TIME", "DATETIME", "PERIOD", "DEADLINE", "EVENT_TIME"] = Field(
        ..., 
        description="Type of datetime reference"
    )
    context: str = Field(..., description="What this datetime refers to")


class ExtractedLocation(BaseModel):
    """Geographic location extracted from document."""
    model_config = {"extra": "forbid"}
    
    location_name: str = Field(..., description="Name of the location")
    type: Literal["COUNTRY", "CITY", "STATE", "REGION", "ADDRESS", "LANDMARK", "COORDINATE"] = Field(
        ..., 
        description="Type of location"
    )
    context: str = Field(..., description="How this location is relevant to the document")
    coordinates: Optional[str] = Field(None, description="Lat/long if available")


class ExtractedMetric(BaseModel):
    """Quantitative metric or measurement extracted from document."""
    model_config = {"extra": "forbid"}
    
    name: str = Field(..., description="Name or description of the metric")
    value: str = Field(..., description="The numeric value and unit (e.g., '100 USD', '50%', '10 days')")
    context: str = Field(..., description="What this metric represents")


class ImportantMetadataItem(BaseModel):
    """Domain-specific metadata extracted from the document."""
    model_config = {"extra": "forbid"}

    key: str = Field(
        ...,
        description="Normalized metadata key (snake_case, e.g., 'tenant_count', 'contract_term')",
    )
    value: str = Field(
        ...,
        description="String value as it appears or is derived from the text (e.g., '3', '12 months', 'Acme Corp')",
    )
    value_type: Literal[
        "COUNT",
        "AMOUNT",
        "DATE",
        "DURATION",
        "PERCENT",
        "BOOLEAN",
        "IDENTIFIER",
        "CATEGORY",
        "TEXT",
        "LIST",
        "RANGE",
        "OTHER",
    ] = Field(..., description="Type of metadata value")
    context: str = Field(..., description="What this metadata represents")
    evidence: Optional[str] = Field(
        None, description="Short quote from the document supporting this value"
    )
    confidence: Optional[Literal["HIGH", "MEDIUM", "LOW"]] = Field(
        None, description="Confidence in this metadata item"
    )


class DocumentMetadataExtraction(BaseModel):
    """Complete metadata extraction from a document."""
    model_config = {"extra": "forbid"}
    
    title: str = Field(
        ...,
        description="Document title - MANDATORY: must be extracted (either explicitly mentioned or inferred from the content)"
    )
    entities: List[ExtractedEntity] = Field(
        default_factory=list, 
        description="All entities identified (people, organizations, products, systems, concepts)"
    )
    datetime_references: List[ExtractedDateTime] = Field(
        default_factory=list, 
        description="All date/time references found"
    )
    locations: List[ExtractedLocation] = Field(
        default_factory=list, 
        description="All geographic locations mentioned"
    )
    metrics: List[ExtractedMetric] = Field(
        default_factory=list, 
        description="Key metrics, numbers, and measurements"
    )
    important_metadata: List[ImportantMetadataItem] = Field(
        default_factory=list,
        description=(
            "Domain-specific key-value metadata inferred directly from the text. "
            "Include counts when multiple items are mentioned (e.g., tenant_count)."
        ),
    )
    summary: str = Field(..., description="Brief summary of the document's main content")
    key_topics: List[str] = Field(default_factory=list, description="Main topics or themes (3-7 topics)")
    sentiment: Literal["POSITIVE", "NEGATIVE", "NEUTRAL", "MIXED"] = Field(
        ..., 
        description="Overall sentiment of the document"
    )
    confidence: Literal["HIGH", "MEDIUM", "LOW"] = Field(
        default="MEDIUM", 
        description="Overall confidence in the extraction quality"
    )


# === OCR and Text Extraction Schemas ===

class TabularDataRow(BaseModel):
    """Represents a single row of tabular data with column-value pairs."""
    values: List[Any] = Field(..., description="List of values in the same order as columns")


class TabularDataExtraction(BaseModel):
    """Schema for extracting tabular data from text (OCR, documents, etc.)."""
    model_config = {"extra": "forbid"}
    
    title: str = Field(..., description="Descriptive title for the extracted data")
    reasoning: str = Field(..., description="Explanation of what tabular structure was identified and why")
    columns: List[str] = Field(..., description="List of column names identified in the data")
    # NOTE: Use strings here to keep the schema compatible with OpenAI strict structured output.
    # Values can still be numeric-like but will be coerced to strings by the model/provider.
    rows: List[List[str]] = Field(..., description="List of rows, where each row is a list of values (as strings) matching the columns order")
    row_count: int = Field(..., description="Total number of data rows extracted")
    confidence: str = Field(default="medium", description="Confidence level in the extraction: high, medium, low")
    notes: Optional[str] = Field(None, description="Additional notes about the extraction (e.g., data quality issues, missing values)")
    
    @property
    def data(self) -> List[Dict[str, Any]]:
        """Convert rows to list of dictionaries for easier access."""
        return [
            {col: val for col, val in zip(self.columns, row)}
            for row in self.rows
        ]


class RelationshipModificationType(str, Enum):
    """Types of modifications that can be made."""
    ADD = "add"
    DELETE = "delete"
    UPDATE = "update"
    MODIFY = "modify"


class ModificationExplanation(BaseModel):
    """Explanation of what modifications were made."""
    model_config = {"extra": "forbid"}
    
    modification_type: RelationshipModificationType = Field(..., description="Type of modification")
    description: str = Field(..., description="What was modified")
    affected_relationships: List[str] = Field(..., description="Which relationships were affected")


class ModifiedRelationshipsResponse(BaseModel):
    """Response containing modified relationships."""
    model_config = {"extra": "forbid"}
    
    modified_relationships: Union[RDSRelationships, MongoDBRelationships, SheetsRelationships] = Field(..., description="The modified relationships in the original structure")
    modifications_made: List[ModificationExplanation] = Field(..., description="Summary of modifications")
    notes: Optional[str] = Field(None, description="Additional notes or warnings")


# === Export all schemas ===
__all__ = [
    # Request/Response
    "GenerationConfig",
    "LLMRequest", 
    "LLMStructuredRequest",
    
    # Core business schemas
    "UserRequirements",
    "BusinessSummary",
    "RequestUnderstanding",
    
    # Data and query schemas
    "ViewDefinition",
    "Cypher",
    "ValidCypher", 
    "ViewQuery",
    "Query",
    "QueryResponse",
    "QuerySchema",
    
    # Conversation schemas
    "FollowUp",
    "ConversationDecision",
    "PropertyDescription",
    "AggregationOperation",
    "CriticalPropertiesAnalysis",
    "AggregationIntent",
    
    # Orchestration schemas
    "TaskType",
    "WorkflowTask", 
    "OrchestrationPlan",
    
    # Entity schemas
    "EntityType",
    "Entity",
    "Relationship", 
    "AssociationAnalysis",
    "Process",
    "Concept",
    "Ontology",
    "EntitiesAndProcesses",
    "DatabaseRelationship",
    "SchemaRelationships",
    
    # Validation schemas
    "ValidationResult",
    
    # Email processing schemas
    "EmailEntityType",
    "EmailEntity",
    "EmailIntent",
    "EmailProcess",
    "EmailRelationship",
    "EmailBatchExtraction",
    "EmailRelationshipExtraction",
    "CrossEmailConnection",
    "CrossEmailAnalysis",
    "EntityResolution",
    
    # Document metadata extraction schemas
    "ExtractedEntity",
    "ExtractedDateTime",
    "ExtractedLocation",
    "ExtractedMetric",
    "ImportantMetadataItem",
    "DocumentMetadataExtraction",
    
    # Text extraction schemas
    "TabularDataRow",
    "TabularDataExtraction",
    
    # Relationship modification schemas
    "RDSRelationshipItem",
    "RDSRelationships",
    "MongoDBRelationshipItem",
    "MongoDBCollectionRelationships",
    "MongoDBRelationships",
    "SheetsWithinSheetRelationship",
    "SheetsCrossSheetRelationship",
    "SheetsRelationships",
    "SemanticRelationship",
    "SemanticRelationships",
    "MongoDBCrossCollectionRelationship",
    "MongoDBCrossCollectionRelationships",
    "RelationshipModificationType",
    "ModificationExplanation",
    "ModifiedRelationshipsResponse",
]
