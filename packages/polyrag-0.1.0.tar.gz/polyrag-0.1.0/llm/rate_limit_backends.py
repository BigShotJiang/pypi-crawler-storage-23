"""Rate limiter backend implementations."""

from __future__ import annotations

import logging
import math
import threading
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from .rate_limit_schemas import (
    LLMRateLimitTimeoutError,
    RateLimitDecision,
    RateLimitKey,
    RateLimitPolicy,
)

logger = logging.getLogger(__name__)


class RateLimiterBackend(ABC):
    """Backend contract used by the high-level limiter wrapper."""

    @abstractmethod
    def acquire(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        estimated_tokens: int,
        request_id: str,
        timeout_s: Optional[float] = None,
    ) -> RateLimitDecision:
        pass

    @abstractmethod
    def heartbeat(self, key: RateLimitKey, request_id: str) -> None:
        pass

    @abstractmethod
    def complete(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        request_id: str,
        actual_tokens: Optional[int] = None,
    ) -> None:
        pass


@dataclass
class _InMemoryBucketState:
    ticket_counter: int = 0
    serving_ticket: int = 0
    tokens: Optional[float] = None
    req_tokens: Optional[float] = None
    last_refill_ts: Optional[float] = None
    waiter_heartbeats: Dict[int, float] = field(default_factory=dict)
    request_ticket: Dict[str, int] = field(default_factory=dict)
    granted_estimate: Dict[str, int] = field(default_factory=dict)


class InMemoryRateLimiter(RateLimiterBackend):
    """
    Simple in-process fallback backend.

    Not suitable for multi-instance production, but useful for local/dev.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._states: Dict[str, _InMemoryBucketState] = {}

    def acquire(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        estimated_tokens: int,
        request_id: str,
        timeout_s: Optional[float] = None,
    ) -> RateLimitDecision:
        timeout_s = float(timeout_s if timeout_s is not None else policy.max_wait_seconds)
        timeout_s = max(0.0, timeout_s)
        bucket_id = key.bucket_id
        start = time.time()
        deadline = start + timeout_s
        last_heartbeat = 0.0

        with self._lock:
            state = self._states.setdefault(bucket_id, _InMemoryBucketState())
            state.ticket_counter += 1
            ticket = state.ticket_counter
            if state.serving_ticket <= 0:
                state.serving_ticket = ticket
            state.waiter_heartbeats[ticket] = start
            state.request_ticket[request_id] = ticket

        while True:
            now = time.time()
            if now > deadline:
                self._cleanup_timeout(bucket_id, request_id, now)
                raise LLMRateLimitTimeoutError(
                    message=(
                        "LLM request exceeded local queue wait timeout while "
                        "enforcing TPM/RPM guard"
                    ),
                    provider=key.provider,
                    model=key.model,
                    retry_after_seconds=max(1.0, policy.poll_interval_seconds),
                    queue_wait_elapsed=now - start,
                )

            with self._lock:
                state = self._states[bucket_id]
                ticket = state.request_ticket.get(request_id, ticket)

                if now - last_heartbeat >= policy.heartbeat_interval_seconds:
                    state.waiter_heartbeats[ticket] = now
                    last_heartbeat = now

                self._advance_stale_head(state, policy, now)

                queue_position = max(1, ticket - state.serving_ticket + 1)

                if state.serving_ticket > ticket:
                    raise LLMRateLimitTimeoutError(
                        message=(
                            "LLM request was skipped from queue due to stale-head recovery"
                        ),
                        provider=key.provider,
                        model=key.model,
                        retry_after_seconds=max(1.0, policy.poll_interval_seconds),
                        queue_wait_elapsed=now - start,
                    )

                if state.serving_ticket == ticket:
                    granted, wait_seconds = self._consume_if_possible(
                        state=state,
                        policy=policy,
                        estimated_tokens=estimated_tokens,
                        now=now,
                    )
                    if granted:
                        state.serving_ticket += 1
                        state.waiter_heartbeats.pop(ticket, None)
                        state.granted_estimate[request_id] = int(estimated_tokens)
                        return RateLimitDecision(
                            granted=True,
                            wait_seconds=now - start,
                            retry_after_seconds=0.0,
                            queue_position=1,
                        )

                    retry_after = max(policy.poll_interval_seconds, wait_seconds)
                else:
                    retry_after = policy.poll_interval_seconds

            sleep_for = min(retry_after, max(0.05, deadline - now))
            time.sleep(sleep_for)

    def heartbeat(self, key: RateLimitKey, request_id: str) -> None:
        bucket_id = key.bucket_id
        now = time.time()
        with self._lock:
            state = self._states.get(bucket_id)
            if not state:
                return
            ticket = state.request_ticket.get(request_id)
            if not ticket:
                return
            state.waiter_heartbeats[ticket] = now

    def complete(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        request_id: str,
        actual_tokens: Optional[int] = None,
    ) -> None:
        bucket_id = key.bucket_id
        with self._lock:
            state = self._states.get(bucket_id)
            if not state:
                return

            estimate = state.granted_estimate.pop(request_id, None)
            ticket = state.request_ticket.pop(request_id, None)
            if ticket:
                state.waiter_heartbeats.pop(ticket, None)

            if estimate is None or actual_tokens is None:
                return

            if actual_tokens < 0:
                return

            credit = max(0.0, float(estimate) - float(actual_tokens))
            if credit <= 0:
                return

            now = time.time()
            self._refill(state, policy, now)
            if state.tokens is None:
                state.tokens = float(policy.tpm)
            state.tokens = min(float(policy.tpm), state.tokens + credit)

    def _cleanup_timeout(self, bucket_id: str, request_id: str, now: float) -> None:
        with self._lock:
            state = self._states.get(bucket_id)
            if not state:
                return

            ticket = state.request_ticket.pop(request_id, None)
            state.granted_estimate.pop(request_id, None)
            if not ticket:
                return

            state.waiter_heartbeats.pop(ticket, None)
            if state.serving_ticket == ticket:
                state.serving_ticket += 1
            self._advance_stale_head(state, RateLimitPolicy(tpm=1, rpm=1), now)

    @staticmethod
    def _advance_stale_head(
        state: _InMemoryBucketState,
        policy: RateLimitPolicy,
        now: float,
    ) -> None:
        while 0 < state.serving_ticket <= state.ticket_counter:
            hb = state.waiter_heartbeats.get(state.serving_ticket)
            if hb is None:
                state.serving_ticket += 1
                continue
            if now - hb > policy.stale_head_seconds:
                state.waiter_heartbeats.pop(state.serving_ticket, None)
                state.serving_ticket += 1
                continue
            break

    @staticmethod
    def _refill(
        state: _InMemoryBucketState,
        policy: RateLimitPolicy,
        now: float,
    ) -> None:
        if state.tokens is None:
            state.tokens = float(policy.tpm)
        if state.req_tokens is None:
            state.req_tokens = float(policy.rpm)
        if state.last_refill_ts is None:
            state.last_refill_ts = now
            return

        elapsed = max(0.0, now - state.last_refill_ts)
        if elapsed <= 0:
            return

        state.tokens = min(float(policy.tpm), state.tokens + (float(policy.tpm) / 60.0) * elapsed)
        state.req_tokens = min(float(policy.rpm), state.req_tokens + (float(policy.rpm) / 60.0) * elapsed)
        state.last_refill_ts = now

    @classmethod
    def _consume_if_possible(
        cls,
        *,
        state: _InMemoryBucketState,
        policy: RateLimitPolicy,
        estimated_tokens: int,
        now: float,
    ) -> Tuple[bool, float]:
        cls._refill(state, policy, now)
        if state.tokens is None:
            state.tokens = float(policy.tpm)
        if state.req_tokens is None:
            state.req_tokens = float(policy.rpm)

        est = max(1.0, float(estimated_tokens))

        if state.tokens >= est and state.req_tokens >= 1.0:
            state.tokens -= est
            state.req_tokens -= 1.0
            return True, 0.0

        token_deficit = max(0.0, est - state.tokens)
        req_deficit = max(0.0, 1.0 - state.req_tokens)

        token_wait = token_deficit / (float(policy.tpm) / 60.0) if policy.tpm > 0 else math.inf
        req_wait = req_deficit / (float(policy.rpm) / 60.0) if policy.rpm > 0 else math.inf

        wait_s = max(token_wait, req_wait)
        if not math.isfinite(wait_s):
            wait_s = max(policy.poll_interval_seconds, 1.0)
        return False, max(policy.poll_interval_seconds, wait_s)


class RedisRateLimiter(RateLimiterBackend):
    """Distributed Redis-backed limiter for multi-worker deployments."""

    def __init__(self, redis_url: str, key_prefix: str = "llm:rl") -> None:
        try:
            import redis
        except Exception as exc:  # pragma: no cover - import path guard
            raise RuntimeError("redis package is required for RedisRateLimiter") from exc

        self._redis = redis.Redis.from_url(redis_url, decode_responses=True)
        self._prefix = key_prefix
        self._lock_release_script = """
if redis.call('get', KEYS[1]) == ARGV[1] then
  return redis.call('del', KEYS[1])
end
return 0
"""

    def acquire(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        estimated_tokens: int,
        request_id: str,
        timeout_s: Optional[float] = None,
    ) -> RateLimitDecision:
        timeout_s = float(timeout_s if timeout_s is not None else policy.max_wait_seconds)
        timeout_s = max(0.0, timeout_s)
        start = time.time()
        deadline = start + timeout_s
        last_heartbeat = 0.0
        ticket = self._enqueue_waiter(key, request_id, start)

        while True:
            now = time.time()
            if now > deadline:
                self._cleanup_timeout(key, request_id, ticket)
                raise LLMRateLimitTimeoutError(
                    message=(
                        "LLM request exceeded local queue wait timeout while "
                        "enforcing TPM/RPM guard"
                    ),
                    provider=key.provider,
                    model=key.model,
                    retry_after_seconds=max(1.0, policy.poll_interval_seconds),
                    queue_wait_elapsed=now - start,
                )

            if now - last_heartbeat >= policy.heartbeat_interval_seconds:
                self._touch_heartbeat(key, ticket, now)
                last_heartbeat = now

            serving = self._get_serving_ticket(key)
            if serving < ticket:
                self._try_advance_stale_head(key, policy, now)
                retry_after = policy.poll_interval_seconds
                queue_position = max(1, ticket - serving + 1)
            elif serving > ticket:
                self._cleanup_timeout(key, request_id, ticket)
                raise LLMRateLimitTimeoutError(
                    message=(
                        "LLM request was skipped from queue due to stale-head recovery"
                    ),
                    provider=key.provider,
                    model=key.model,
                    retry_after_seconds=max(1.0, policy.poll_interval_seconds),
                    queue_wait_elapsed=now - start,
                )
            else:
                granted, wait_seconds = self._consume_if_turn(
                    key=key,
                    policy=policy,
                    ticket=ticket,
                    request_id=request_id,
                    estimated_tokens=max(1, int(estimated_tokens)),
                    now=now,
                )
                if granted:
                    return RateLimitDecision(
                        granted=True,
                        wait_seconds=now - start,
                        retry_after_seconds=0.0,
                        queue_position=1,
                    )
                retry_after = max(policy.poll_interval_seconds, wait_seconds)
                queue_position = 1

            sleep_for = min(retry_after, max(0.05, deadline - now))
            time.sleep(sleep_for)

    def heartbeat(self, key: RateLimitKey, request_id: str) -> None:
        ticket = self._hget(self._k(key, "request_ticket"), request_id)
        if ticket is None:
            return
        try:
            ticket_int = int(ticket)
        except Exception:
            return
        self._touch_heartbeat(key, ticket_int, time.time())

    def complete(
        self,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        request_id: str,
        actual_tokens: Optional[int] = None,
    ) -> None:
        estimate_raw = self._hget(self._k(key, "request_estimate"), request_id)
        ticket_raw = self._hget(self._k(key, "request_ticket"), request_id)

        if estimate_raw is not None and actual_tokens is not None:
            try:
                estimate = float(estimate_raw)
                actual = float(actual_tokens)
            except Exception:
                estimate = 0.0
                actual = 0.0

            credit = max(0.0, estimate - actual)
            if credit > 0:
                self._credit_tokens(key, policy, credit)

        if ticket_raw is not None:
            try:
                ticket = int(ticket_raw)
            except Exception:
                ticket = None
            if ticket is not None:
                self._hdel(self._k(key, "heartbeat"), str(ticket))

        self._hdel(self._k(key, "request_ticket"), request_id)
        self._hdel(self._k(key, "request_estimate"), request_id)

    def _enqueue_waiter(self, key: RateLimitKey, request_id: str, now: float) -> int:
        ticket = int(self._incr(self._k(key, "ticket_counter")))
        pipe = self._redis.pipeline()
        pipe.hset(self._k(key, "heartbeat"), str(ticket), now)
        pipe.hset(self._k(key, "request_ticket"), request_id, ticket)
        pipe.setnx(self._k(key, "serving_ticket"), ticket)
        pipe.execute()
        return ticket

    def _cleanup_timeout(self, key: RateLimitKey, request_id: str, ticket: int) -> None:
        serving = self._get_serving_ticket(key)
        pipe = self._redis.pipeline()
        pipe.hdel(self._k(key, "heartbeat"), str(ticket))
        pipe.hdel(self._k(key, "request_ticket"), request_id)
        pipe.hdel(self._k(key, "request_estimate"), request_id)
        if serving == ticket:
            pipe.set(self._k(key, "serving_ticket"), ticket + 1)
        pipe.execute()

    def _consume_if_turn(
        self,
        *,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        ticket: int,
        request_id: str,
        estimated_tokens: int,
        now: float,
    ) -> Tuple[bool, float]:
        lock_key = self._k(key, "lock")
        lock_val = str(uuid.uuid4())
        got_lock = self._redis.set(lock_key, lock_val, nx=True, ex=5)
        if not got_lock:
            return False, policy.poll_interval_seconds

        try:
            serving = self._get_serving_ticket(key)
            if serving != ticket:
                return False, policy.poll_interval_seconds

            tokens, req_tokens, last_refill = self._read_bucket_state(key)
            tokens, req_tokens = self._refill_bucket(
                policy=policy,
                now=now,
                tokens=tokens,
                req_tokens=req_tokens,
                last_refill=last_refill,
            )

            est = max(1.0, float(estimated_tokens))
            if tokens >= est and req_tokens >= 1.0:
                tokens -= est
                req_tokens -= 1.0
                pipe = self._redis.pipeline()
                pipe.set(self._k(key, "tokens"), tokens)
                pipe.set(self._k(key, "req_tokens"), req_tokens)
                pipe.set(self._k(key, "last_refill_ts"), now)
                pipe.set(self._k(key, "serving_ticket"), ticket + 1)
                pipe.hdel(self._k(key, "heartbeat"), str(ticket))
                pipe.hset(self._k(key, "request_estimate"), request_id, int(est))
                pipe.execute()
                return True, 0.0

            token_deficit = max(0.0, est - tokens)
            req_deficit = max(0.0, 1.0 - req_tokens)
            token_wait = token_deficit / (float(policy.tpm) / 60.0) if policy.tpm > 0 else math.inf
            req_wait = req_deficit / (float(policy.rpm) / 60.0) if policy.rpm > 0 else math.inf
            wait_s = max(token_wait, req_wait)
            if not math.isfinite(wait_s):
                wait_s = max(policy.poll_interval_seconds, 1.0)

            pipe = self._redis.pipeline()
            pipe.set(self._k(key, "tokens"), tokens)
            pipe.set(self._k(key, "req_tokens"), req_tokens)
            pipe.set(self._k(key, "last_refill_ts"), now)
            pipe.execute()
            return False, max(policy.poll_interval_seconds, wait_s)
        finally:
            self._redis.eval(self._lock_release_script, 1, lock_key, lock_val)

    def _try_advance_stale_head(self, key: RateLimitKey, policy: RateLimitPolicy, now: float) -> None:
        lock_key = self._k(key, "lock")
        lock_val = str(uuid.uuid4())
        got_lock = self._redis.set(lock_key, lock_val, nx=True, ex=5)
        if not got_lock:
            return
        try:
            serving = self._get_serving_ticket(key)
            hb = self._hget(self._k(key, "heartbeat"), str(serving))
            if hb is None:
                self._redis.set(self._k(key, "serving_ticket"), serving + 1)
                return
            try:
                hb_ts = float(hb)
            except Exception:
                hb_ts = 0.0
            if now - hb_ts > policy.stale_head_seconds:
                pipe = self._redis.pipeline()
                pipe.hdel(self._k(key, "heartbeat"), str(serving))
                pipe.set(self._k(key, "serving_ticket"), serving + 1)
                pipe.execute()
        finally:
            self._redis.eval(self._lock_release_script, 1, lock_key, lock_val)

    def _touch_heartbeat(self, key: RateLimitKey, ticket: int, now: float) -> None:
        self._hset(self._k(key, "heartbeat"), str(ticket), now)

    def _credit_tokens(self, key: RateLimitKey, policy: RateLimitPolicy, credit: float) -> None:
        lock_key = self._k(key, "lock")
        lock_val = str(uuid.uuid4())
        got_lock = self._redis.set(lock_key, lock_val, nx=True, ex=5)
        if not got_lock:
            return
        try:
            now = time.time()
            tokens, req_tokens, last_refill = self._read_bucket_state(key)
            tokens, req_tokens = self._refill_bucket(
                policy=policy,
                now=now,
                tokens=tokens,
                req_tokens=req_tokens,
                last_refill=last_refill,
            )
            tokens = min(float(policy.tpm), tokens + float(credit))
            pipe = self._redis.pipeline()
            pipe.set(self._k(key, "tokens"), tokens)
            pipe.set(self._k(key, "req_tokens"), req_tokens)
            pipe.set(self._k(key, "last_refill_ts"), now)
            pipe.execute()
        finally:
            self._redis.eval(self._lock_release_script, 1, lock_key, lock_val)

    def _read_bucket_state(self, key: RateLimitKey) -> Tuple[float, float, float]:
        raw = self._redis.mget(
            [
                self._k(key, "tokens"),
                self._k(key, "req_tokens"),
                self._k(key, "last_refill_ts"),
            ]
        )
        tokens = float(raw[0]) if raw[0] is not None else math.nan
        req_tokens = float(raw[1]) if raw[1] is not None else math.nan
        last_refill = float(raw[2]) if raw[2] is not None else math.nan
        return tokens, req_tokens, last_refill

    @staticmethod
    def _refill_bucket(
        *,
        policy: RateLimitPolicy,
        now: float,
        tokens: float,
        req_tokens: float,
        last_refill: float,
    ) -> Tuple[float, float]:
        if not math.isfinite(tokens):
            tokens = float(policy.tpm)
        if not math.isfinite(req_tokens):
            req_tokens = float(policy.rpm)
        if not math.isfinite(last_refill):
            return tokens, req_tokens

        elapsed = max(0.0, now - last_refill)
        if elapsed <= 0:
            return tokens, req_tokens

        tokens = min(float(policy.tpm), tokens + (float(policy.tpm) / 60.0) * elapsed)
        req_tokens = min(float(policy.rpm), req_tokens + (float(policy.rpm) / 60.0) * elapsed)
        return tokens, req_tokens

    def _get_serving_ticket(self, key: RateLimitKey) -> int:
        raw = self._redis.get(self._k(key, "serving_ticket"))
        if raw is None:
            self._redis.setnx(self._k(key, "serving_ticket"), 1)
            raw = self._redis.get(self._k(key, "serving_ticket")) or "1"
        try:
            return int(raw)
        except Exception:
            return 1

    def _k(self, key: RateLimitKey, suffix: str) -> str:
        provider = key.provider.lower().replace(":", "_")
        model = key.model.lower().replace(":", "_").replace("/", "_")
        return f"{self._prefix}:{provider}:{model}:{suffix}"

    def _incr(self, key: str) -> int:
        return int(self._redis.incr(key))

    def _hset(self, key: str, field: str, value: object) -> None:
        self._redis.hset(key, field, value)

    def _hget(self, key: str, field: str) -> Optional[str]:
        return self._redis.hget(key, field)

    def _hdel(self, key: str, field: str) -> None:
        self._redis.hdel(key, field)
