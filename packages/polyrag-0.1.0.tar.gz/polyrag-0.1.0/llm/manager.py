"""Centralized LLM management and factory."""

from typing import Dict, Type, Optional, Any, List
from enum import Enum
import logging
from .base import LLMProvider, LLMResponse
from .providers.openai_provider import OpenAIProvider
from .providers.google_provider import GoogleProvider
from .providers.huggingface_provider import HuggingFaceProvider
from .providers.ollama_provider import OllamaProvider
from .rate_limit import RateLimitedLLMProvider, get_global_rate_limiter
from app.config.settings import get_settings
from app.config.llm import get_llm_config, LLMModelCategory


logger = logging.getLogger(__name__)


class LLMType(str, Enum):
    """Available LLM providers."""
    OPENAI = "openai"
    GOOGLE = "google"
    HUGGINGFACE = "huggingface"
    OLLAMA = "ollama"


class LLMManager:
    """Centralized LLM management with provider registry and caching."""
    
    def __init__(self):
        self.settings = get_settings()
        self.llm_config = get_llm_config()
        
        # Provider registry
        self.providers: Dict[LLMType, Type[LLMProvider]] = {
            LLMType.OPENAI: OpenAIProvider,
            LLMType.GOOGLE: GoogleProvider,
            LLMType.HUGGINGFACE: HuggingFaceProvider,
            LLMType.OLLAMA: OllamaProvider,
        }
        
        # Instance cache for reusing LLM instances
        self._instances: Dict[str, LLMProvider] = {}
        
        # Usage statistics
        self._usage_stats: Dict[str, Dict[str, Any]] = {}
    
    def register_provider(self, provider_type: LLMType, provider_class: Type[LLMProvider]):
        """Register a new LLM provider."""
        self.providers[provider_type] = provider_class
        logger.info(f"Registered LLM provider: {provider_type}")
    
    def get_available_providers(self) -> List[LLMType]:
        """Get list of available and properly configured providers."""
        return self.llm_config.get_available_providers()
    
    def get_llm(
        self, 
        provider: Optional[LLMType] = None, 
        model: Optional[str] = None,
        category: Optional[LLMModelCategory] = None,
        use_cache: bool = True,
        **kwargs
    ) -> LLMProvider:
        """
        Get LLM instance with intelligent caching and model selection.
        
        Args:
            provider: LLM provider to use (defaults to configured default)
            model: Specific model to use (defaults to provider default)
            category: Use case category for automatic model selection
            use_cache: Whether to use cached instances
            **kwargs: Additional provider-specific configuration
        
        Returns:
            LLMProvider instance
        """
        # Determine provider
        if provider is None:
            provider = self.settings.DEFAULT_LLM_PROVIDER
        
        # Validate provider is available
        if provider not in self.providers:
            raise ValueError(f"Provider {provider} not registered")
        
        if not self.llm_config.validate_provider_config(provider):
            available = self.get_available_providers()
            if not available:
                raise RuntimeError("No LLM providers are properly configured")
            
            logger.warning(f"Provider {provider} not configured, using {available[0]}")
            provider = available[0]
        
        # Determine model
        if model is None:
            if category:
                model = self.llm_config.get_model_for_category(category, provider)
            else:
                provider_config = self.llm_config.get_provider_config(provider)
                model = provider_config["default_model"]
        
        # Create cache key
        cache_key = self._create_cache_key(provider, model, kwargs)
        
        # Return cached instance if available
        if use_cache and cache_key in self._instances:
            logger.debug(f"Using cached LLM instance: {cache_key}")
            return self._instances[cache_key]
        
        # Create new instance
        provider_class = self.providers[provider]
        provider_config = self.llm_config.get_provider_config(provider)
        
        # Merge configurations
        instance_config = {**provider_config, **kwargs}
        instance_config.pop("models", None)  # Remove models dict from instance config
        
        try:
            instance = provider_class(model=model, **instance_config)

            # Wrap all providers with global TPM/RPM limiter when enabled.
            runtime_cfg = self.llm_config.get_rate_limit_runtime()
            if runtime_cfg.get("enabled", False) and not isinstance(instance, RateLimitedLLMProvider):
                try:
                    limiter = get_global_rate_limiter(self.llm_config)
                    instance = RateLimitedLLMProvider(
                        wrapped=instance,
                        limiter=limiter,
                        provider=provider.value if hasattr(provider, "value") else str(provider),
                        model=model,
                        usage_callback=self.record_usage,
                    )
                except Exception as exc:
                    if runtime_cfg.get("fail_open", False):
                        logger.warning(
                            "Failed to initialize LLM limiter; continuing due to fail-open: %s",
                            exc,
                        )
                    else:
                        raise RuntimeError(
                            f"Failed to initialize LLM limiter while fail-open is disabled: {exc}"
                        ) from exc
            
            if use_cache:
                self._instances[cache_key] = instance
                logger.info(f"Created and cached new LLM instance: {provider}:{model}")
            else:
                logger.info(f"Created new LLM instance (no cache): {provider}:{model}")
            
            return instance
            
        except Exception as e:
            logger.error(f"Failed to create LLM instance {provider}:{model}: {e}")
            raise RuntimeError(f"Failed to initialize {provider} provider: {e}")
    
    def _create_cache_key(self, provider: LLMType, model: str, config: Dict[str, Any]) -> str:
        """Create a cache key for LLM instances."""
        # Only include configuration that affects the instance creation
        cache_config = {
            k: v for k, v in config.items() 
            if k in ["temperature", "max_tokens", "top_p", "api_key"]
        }
        
        import hashlib
        import json
        content = f"{provider}:{model}:{json.dumps(cache_config, sort_keys=True)}"
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def get_for_orchestration(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for orchestration tasks."""
        return self.get_llm(
            category=LLMModelCategory.ORCHESTRATION,
            **kwargs
        )
    
    def get_for_structured_output(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for structured output generation."""
        provider = kwargs.pop("provider", LLMType.OPENAI)
        return self.get_llm(
            provider=provider,
            category=LLMModelCategory.STRUCTURED,
            **kwargs
        )
    
    def get_for_chat(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for chat/conversation."""
        return self.get_llm(
            category=LLMModelCategory.CHAT,
            **kwargs
        )
    
    def get_for_analysis(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for data analysis tasks.""" 
        return self.get_llm(
            category=LLMModelCategory.ANALYSIS,
            **kwargs
        )
    
    def get_for_associations(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for association analysis."""
        return self.get_llm(
            category=LLMModelCategory.ASSOCIATIONS, 
            **kwargs
        )
    
    def get_for_views(self, **kwargs) -> LLMProvider:
        """Get LLM optimized for view creation."""
        return self.get_llm(
            category=LLMModelCategory.VIEWS,
            **kwargs
        )
    
    def clear_cache(self):
        """Clear all cached LLM instances."""
        count = len(self._instances)
        self._instances.clear()
        logger.info(f"Cleared {count} cached LLM instances")
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get caching statistics."""
        return {
            "cached_instances": len(self._instances),
            "cache_keys": list(self._instances.keys()),
            "available_providers": [p.value for p in self.get_available_providers()],
            "default_provider": self.settings.DEFAULT_LLM_PROVIDER,
        }
    
    def record_usage(self, provider: str, model: str, tokens_used: int, response_time: float):
        """Record usage statistics for monitoring."""
        key = f"{provider}:{model}"
        if key not in self._usage_stats:
            self._usage_stats[key] = {
                "total_requests": 0,
                "total_tokens": 0,
                "total_time": 0.0,
                "avg_response_time": 0.0
            }
        
        stats = self._usage_stats[key]
        stats["total_requests"] += 1
        stats["total_tokens"] += tokens_used
        stats["total_time"] += response_time
        stats["avg_response_time"] = stats["total_time"] / stats["total_requests"]
    
    def get_usage_stats(self) -> Dict[str, Dict[str, Any]]:
        """Get usage statistics."""
        return self._usage_stats.copy()


# Global instance
llm_manager = LLMManager()


# Convenience functions for easy access
def get_llm(
    provider: Optional[LLMType] = None, 
    model: Optional[str] = None,
    category: Optional[LLMModelCategory] = None,
    **kwargs
) -> LLMProvider:
    """Get LLM instance using the global manager."""
    return llm_manager.get_llm(provider, model, category, **kwargs)


def get_llm_for_orchestration(**kwargs) -> LLMProvider:
    """Get LLM optimized for orchestration tasks."""
    return llm_manager.get_for_orchestration(**kwargs)


def get_llm_for_structured_output(**kwargs) -> LLMProvider:
    """Get LLM optimized for structured output."""
    return llm_manager.get_for_structured_output(**kwargs)


def get_llm_for_chat(**kwargs) -> LLMProvider:
    """Get LLM optimized for chat."""
    return llm_manager.get_for_chat(**kwargs)


def get_llm_for_analysis(**kwargs) -> LLMProvider:
    """Get LLM optimized for analysis."""
    return llm_manager.get_for_analysis(**kwargs)


def get_llm_for_associations(**kwargs) -> LLMProvider:
    """Get LLM optimized for associations."""
    return llm_manager.get_for_associations(**kwargs)


def get_llm_for_views(**kwargs) -> LLMProvider:
    """Get LLM optimized for views."""
    return llm_manager.get_for_views(**kwargs)


# Migration helpers for your existing code
def get_openai_llm(model: str = "gpt-4o", **kwargs) -> LLMProvider:
    """Direct access to OpenAI LLM (migration helper)."""
    return get_llm(provider=LLMType.OPENAI, model=model, **kwargs)


def get_google_llm(model: str = "gemini-2.0-flash", **kwargs) -> LLMProvider:
    """Direct access to Google LLM (migration helper)."""
    return get_llm(provider=LLMType.GOOGLE, model=model, **kwargs)


def get_huggingface_llm(model: str = "mistralai/Mistral-7B-Instruct-v0.2", **kwargs) -> LLMProvider:
    """Direct access to HuggingFace LLM."""
    return get_llm(provider=LLMType.HUGGINGFACE, model=model, **kwargs)


def get_ollama_llm(model: str = "llama3.2", **kwargs) -> LLMProvider:
    """Direct access to Ollama LLM."""
    return get_llm(provider=LLMType.OLLAMA, model=model, **kwargs)
