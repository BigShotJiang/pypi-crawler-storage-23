"""Global LLM TPM/RPM guard and provider wrapper."""

from __future__ import annotations

import logging
import math
import re
import threading
import time
import uuid
from typing import Any, Callable, Optional, Type

from pydantic import BaseModel

from .base import LLMProvider, LLMResponse
from .rate_limit_backends import InMemoryRateLimiter, RateLimiterBackend, RedisRateLimiter
from .rate_limit_schemas import LLMRateLimitTimeoutError, RateLimitKey, RateLimitPolicy

logger = logging.getLogger(__name__)


class GlobalLLMRateLimiter:
    """Singleton-style coordinator around backend + policy lookup."""

    def __init__(self, llm_config) -> None:
        self._llm_config = llm_config
        self._runtime = llm_config.get_rate_limit_runtime()
        self._backend = self._build_backend()

    def _build_backend(self) -> RateLimiterBackend:
        backend = self._runtime["backend"]
        if backend == "redis":
            return RedisRateLimiter(
                redis_url=self._runtime["redis_url"],
                key_prefix=self._runtime["redis_key_prefix"],
            )
        return InMemoryRateLimiter()

    @property
    def enabled(self) -> bool:
        return bool(self._runtime["enabled"])

    @property
    def fail_open(self) -> bool:
        return bool(self._runtime["fail_open"])

    def get_policy(self, provider: str, model: str) -> RateLimitPolicy:
        policy_dict = self._llm_config.get_rate_limit_policy(provider, model)
        return RateLimitPolicy(**policy_dict)

    def acquire(
        self,
        *,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        estimated_tokens: int,
        request_id: str,
        timeout_s: Optional[float] = None,
    ):
        return self._backend.acquire(
            key=key,
            policy=policy,
            estimated_tokens=max(1, int(estimated_tokens)),
            request_id=request_id,
            timeout_s=timeout_s,
        )

    def heartbeat(self, *, key: RateLimitKey, request_id: str) -> None:
        self._backend.heartbeat(key=key, request_id=request_id)

    def complete(
        self,
        *,
        key: RateLimitKey,
        policy: RateLimitPolicy,
        request_id: str,
        actual_tokens: Optional[int] = None,
    ) -> None:
        self._backend.complete(
            key=key,
            policy=policy,
            request_id=request_id,
            actual_tokens=actual_tokens,
        )


_limiter_lock = threading.Lock()
_limiter_instance: Optional[GlobalLLMRateLimiter] = None


def get_global_rate_limiter(llm_config) -> GlobalLLMRateLimiter:
    """Get global limiter singleton."""
    global _limiter_instance
    if _limiter_instance is None:
        with _limiter_lock:
            if _limiter_instance is None:
                _limiter_instance = GlobalLLMRateLimiter(llm_config=llm_config)
    return _limiter_instance


class RateLimitedLLMProvider(LLMProvider):
    """LLMProvider wrapper that enforces global TPM/RPM limits."""

    def __init__(
        self,
        wrapped: LLMProvider,
        limiter: GlobalLLMRateLimiter,
        provider: str,
        model: str,
        usage_callback: Optional[Callable[[str, str, int, float], None]] = None,
    ):
        self._wrapped = wrapped
        self._limiter = limiter
        self._provider = provider
        self._usage_callback = usage_callback
        super().__init__(model=model)
        self.provider_name = wrapped.provider_name

    def _validate_config(self) -> None:
        return

    def __getattr__(self, name: str) -> Any:
        return getattr(self._wrapped, name)

    def generate(
        self,
        prompt: str,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> LLMResponse:
        return self._guarded_call(
            method_name="generate",
            prompt=prompt,
            max_tokens=max_tokens,
            fn=lambda: self._wrapped.generate(
                prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs,
            ),
        )

    def generate_structured(
        self,
        prompt: str,
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs,
    ) -> Any:
        return self._guarded_call(
            method_name="generate_structured",
            prompt=prompt,
            max_tokens=max_tokens,
            fn=lambda: self._wrapped.generate_structured(
                prompt,
                response_schema,
                temperature=temperature,
                max_tokens=max_tokens,
                **kwargs,
            ),
        )

    def estimate_tokens(self, text: str) -> int:
        return self._wrapped.estimate_tokens(text)

    def _guarded_call(
        self,
        *,
        method_name: str,
        prompt: str,
        max_tokens: Optional[int],
        fn: Callable[[], Any],
    ) -> Any:
        key = RateLimitKey(provider=self._provider, model=self.model)
        policy = self._limiter.get_policy(provider=self._provider, model=self.model)

        input_estimate = max(1, int(self._wrapped.estimate_tokens(prompt)))
        output_reserve = (
            int(max_tokens)
            if max_tokens is not None
            else int(policy.output_token_reserve)
        )
        estimated_total = int(math.ceil((input_estimate + max(0, output_reserve)) * policy.safety_factor))
        request_id = str(uuid.uuid4())
        queue_start = time.time()

        try:
            self._limiter.acquire(
                key=key,
                policy=policy,
                estimated_tokens=estimated_total,
                request_id=request_id,
                timeout_s=policy.max_wait_seconds,
            )
        except LLMRateLimitTimeoutError:
            logger.warning(
                "llm_limiter_timeout_count provider=%s model=%s method=%s",
                self._provider, self.model, method_name,
            )
            raise
        except Exception as exc:
            if policy.fail_open:
                logger.warning(
                    "llm_limiter_backend_error_fail_open provider=%s model=%s method=%s err=%s",
                    self._provider, self.model, method_name, exc,
                )
            else:
                raise RuntimeError(
                    "LLM limiter backend error while fail-open is disabled"
                ) from exc

        wait_elapsed = time.time() - queue_start
        if wait_elapsed > 0:
            logger.info(
                "llm_limiter_acquire_wait_seconds provider=%s model=%s method=%s wait=%.3f reserved_tokens=%d",
                self._provider, self.model, method_name, wait_elapsed, estimated_total,
            )

        actual_tokens: Optional[int] = None
        response_time = 0.0
        call_start = time.time()
        try:
            result = fn()
            response_time = time.time() - call_start

            if isinstance(result, LLMResponse):
                actual_tokens = _extract_total_tokens(result.usage)
                if self._usage_callback and actual_tokens is not None:
                    self._usage_callback(self._provider, self.model, actual_tokens, response_time)
                logger.info(
                    "llm_actual_tokens_reported provider=%s model=%s tokens=%s",
                    self._provider, self.model, actual_tokens,
                )

            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception as exc:
            if _is_provider_rate_limit_error(exc):
                retry_after = _extract_retry_after_seconds(exc) or max(
                    1.0, policy.poll_interval_seconds
                )
                logger.warning(
                    "llm_rate_limit_provider_errors provider=%s model=%s method=%s retry_after=%.2f err=%s",
                    self._provider, self.model, method_name, retry_after, exc,
                )
                raise LLMRateLimitTimeoutError(
                    message=(
                        "Upstream provider returned a rate-limit error; retry later"
                    ),
                    provider=self._provider,
                    model=self.model,
                    retry_after_seconds=retry_after,
                    queue_wait_elapsed=wait_elapsed,
                ) from exc
            raise
        finally:
            try:
                self._limiter.complete(
                    key=key,
                    policy=policy,
                    request_id=request_id,
                    actual_tokens=actual_tokens,
                )
            except Exception:
                logger.warning(
                    "Failed to finalize limiter request state provider=%s model=%s",
                    self._provider, self.model,
                    exc_info=True,
                )


def _extract_total_tokens(usage: Optional[dict]) -> Optional[int]:
    return LLMProvider.extract_total_tokens_from_usage(usage)


def _is_provider_rate_limit_error(exc: Exception) -> bool:
    msg = str(exc).lower()
    candidates = [
        "rate limit",
        "429",
        "tokens per minute",
        "requests per minute",
        "too many requests",
        "quota exceeded",
    ]
    return any(c in msg for c in candidates)


def _extract_retry_after_seconds(exc: Exception) -> Optional[float]:
    msg = str(exc).lower()
    patterns = [
        r"retry after[:\s]+(\d+(?:\.\d+)?)",
        r"try again in[:\s]+(\d+(?:\.\d+)?)",
        r"after\s+(\d+(?:\.\d+)?)\s*s",
    ]
    for pattern in patterns:
        m = re.search(pattern, msg)
        if m:
            try:
                return float(m.group(1))
            except Exception:
                continue
    return None
