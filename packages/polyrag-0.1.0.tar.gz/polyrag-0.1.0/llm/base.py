"""Abstract base classes for LLM providers."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Union, Type, List
from pydantic import BaseModel
import time
import hashlib
import json


class LLMResponse(BaseModel):
    """Standard response format from LLM providers."""
    content: str
    model: str
    provider: str
    usage: Optional[Dict[str, Any]] = None
    metadata: Optional[Dict[str, Any]] = None
    response_time: Optional[float] = None
    finish_reason: Optional[str] = None


class LLMProvider(ABC):
    """Abstract base class for LLM providers."""
    
    def __init__(self, model: str, **kwargs):
        self.model = model
        self.provider_name = self.__class__.__name__.replace("Provider", "").lower()
        self.config = kwargs
        self._validate_config()
    
    @abstractmethod
    def _validate_config(self) -> None:
        """Validate provider-specific configuration."""
        pass
    
    @abstractmethod
    def generate(
        self, 
        prompt: str, 
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> LLMResponse:
        """Generate text from prompt."""
        pass
    
    @abstractmethod
    def generate_structured(
        self, 
        prompt: str, 
        response_schema: Type[BaseModel],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        **kwargs
    ) -> Any:
        """Generate structured output matching the provided schema."""
        pass
    
    def generate_with_retry(
        self,
        prompt: str,
        max_retries: int = 3,
        **kwargs
    ) -> LLMResponse:
        """Generate with automatic retry on failures."""
        last_error = None
        
        for attempt in range(max_retries + 1):
            try:
                return self.generate(prompt, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    # Exponential backoff
                    wait_time = 2 ** attempt
                    time.sleep(wait_time)
                    continue
                else:
                    break
        
        raise RuntimeError(f"Failed after {max_retries + 1} attempts: {last_error}")
    
    def generate_structured_with_retry(
        self,
        prompt: str,
        response_schema: Type[BaseModel],
        max_retries: int = 3,
        **kwargs
    ) -> Any:
        """Generate structured output with automatic retry on failures."""
        last_error = None
        
        for attempt in range(max_retries + 1):
            try:
                return self.generate_structured(prompt, response_schema, **kwargs)
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    # Exponential backoff
                    wait_time = 2 ** attempt
                    time.sleep(wait_time)
                    continue
                else:
                    break
        
        raise RuntimeError(f"Failed after {max_retries + 1} attempts: {last_error}")
    
    def estimate_tokens(self, text: str) -> int:
        """Rough estimation of token count (override in specific providers for accuracy)."""
        # Simple approximation: ~4 characters per token
        return len(text) // 4
    
    def create_cache_key(self, prompt: str, **kwargs) -> str:
        """Create cache key for request."""
        # Create deterministic hash of prompt and parameters
        content = {
            "prompt": prompt,
            "model": self.model,
            "params": kwargs
        }
        content_str = json.dumps(content, sort_keys=True)
        return hashlib.md5(content_str.encode()).hexdigest()

    @staticmethod
    def extract_total_tokens_from_usage(usage: Optional[Dict[str, Any]]) -> Optional[int]:
        """Normalize provider usage payload into a single token count."""
        if not usage:
            return None
        for key in ("total_tokens", "total_token_count"):
            if key in usage and usage[key] is not None:
                try:
                    return int(usage[key])
                except Exception:
                    pass
        prompt = usage.get("prompt_tokens") or usage.get("prompt_token_count")
        completion = usage.get("completion_tokens") or usage.get("candidates_token_count")
        if prompt is None and completion is None:
            return None
        try:
            return int(prompt or 0) + int(completion or 0)
        except Exception:
            return None
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model})"


class CachedLLMProvider(LLMProvider):
    """LLM provider with caching capabilities."""
    
    def __init__(self, model: str, cache_size: int = 100, **kwargs):
        super().__init__(model, **kwargs)
        self.cache_size = cache_size
        self._cache: Dict[str, LLMResponse] = {}
        self._cache_order: List[str] = []
    
    def _get_from_cache(self, cache_key: str) -> Optional[LLMResponse]:
        """Get response from cache if available."""
        if cache_key in self._cache:
            # Move to end (most recently used)
            self._cache_order.remove(cache_key)
            self._cache_order.append(cache_key)
            return self._cache[cache_key]
        return None
    
    def _store_in_cache(self, cache_key: str, response: LLMResponse) -> None:
        """Store response in cache with LRU eviction."""
        if len(self._cache) >= self.cache_size:
            # Remove least recently used
            oldest_key = self._cache_order.pop(0)
            del self._cache[oldest_key]
        
        self._cache[cache_key] = response
        self._cache_order.append(cache_key)
    
    def generate(self, prompt: str, use_cache: bool = True, **kwargs) -> LLMResponse:
        """Generate with optional caching."""
        if use_cache:
            cache_key = self.create_cache_key(prompt, **kwargs)
            cached_response = self._get_from_cache(cache_key)
            if cached_response:
                return cached_response
        
        response = super().generate(prompt, **kwargs)
        
        if use_cache:
            self._store_in_cache(cache_key, response)
        
        return response
    
    def clear_cache(self) -> None:
        """Clear the cache."""
        self._cache.clear()
        self._cache_order.clear()
    
    def cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return {
            "size": len(self._cache),
            "max_size": self.cache_size,
            "keys": list(self._cache_order)
        }
