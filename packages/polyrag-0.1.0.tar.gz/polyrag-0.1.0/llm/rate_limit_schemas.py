"""Schemas and exceptions for LLM rate limiting."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class RateLimitKey:
    """Provider/model identity for independent rate buckets."""

    provider: str
    model: str

    @property
    def bucket_id(self) -> str:
        return f"{self.provider}:{self.model}"


@dataclass(frozen=True)
class RateLimitPolicy:
    """Runtime policy for one provider/model bucket."""

    tpm: int
    rpm: int
    safety_factor: float = 1.15
    max_wait_seconds: float = 90.0
    stale_head_seconds: float = 30.0
    poll_interval_seconds: float = 0.5
    heartbeat_interval_seconds: float = 2.0
    output_token_reserve: int = 1_024
    fail_open: bool = False


@dataclass(frozen=True)
class RateLimitDecision:
    """Decision payload returned from acquire()."""

    granted: bool
    wait_seconds: float = 0.0
    retry_after_seconds: float = 0.0
    queue_position: int = 1


class LLMRateLimitTimeoutError(RuntimeError):
    """Retryable local throttling timeout."""

    def __init__(
        self,
        *,
        message: str,
        provider: str,
        model: str,
        retry_after_seconds: float,
        queue_wait_elapsed: float,
    ) -> None:
        super().__init__(message)
        self.error_code = "llm_rate_limited_local_guard"
        self.provider = provider
        self.model = model
        self.retry_after_seconds = max(0.0, float(retry_after_seconds))
        self.queue_wait_elapsed = max(0.0, float(queue_wait_elapsed))

