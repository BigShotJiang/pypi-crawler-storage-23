"""
Application settings loaded from environment variables.

Provides the ``get_settings()`` function used by ``llm.manager``.
"""

import os
from dotenv import load_dotenv

load_dotenv(override=True)


class Settings:
    """Application-wide settings read from environment variables."""

    def __init__(self):
        from llm.manager import LLMType

        # Default LLM provider – set DEFAULT_LLM_PROVIDER env var to choose:
        #   openai (default) | google | huggingface | ollama
        _provider_map = {
            "openai": LLMType.OPENAI,
            "google": LLMType.GOOGLE,
            "huggingface": LLMType.HUGGINGFACE,
            "ollama": LLMType.OLLAMA,
        }
        default = os.getenv("DEFAULT_LLM_PROVIDER", "openai").lower().strip()
        self.DEFAULT_LLM_PROVIDER = _provider_map.get(default, LLMType.OPENAI)


_settings = None


def get_settings() -> Settings:
    """Return a cached Settings instance."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
