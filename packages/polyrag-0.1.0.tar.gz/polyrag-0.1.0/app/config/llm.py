"""
LLM provider configuration loaded from environment variables.

Provides ``get_llm_config()`` and ``LLMModelCategory`` used by
``llm.manager``.
"""

import os
import re
from enum import Enum
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

load_dotenv(override=True)


class LLMModelCategory(str, Enum):
    """Use-case categories for automatic model selection."""
    ORCHESTRATION = "orchestration"
    STRUCTURED = "structured"
    CHAT = "chat"
    ANALYSIS = "analysis"
    ASSOCIATIONS = "associations"
    VIEWS = "views"


# Model mappings per category per provider
_CATEGORY_MODELS = {
    "openai": {
        LLMModelCategory.ORCHESTRATION: "gpt-4o",
        LLMModelCategory.STRUCTURED: "gpt-4o",
        LLMModelCategory.CHAT: "gpt-4o-mini",
        LLMModelCategory.ANALYSIS: "gpt-4o",
        LLMModelCategory.ASSOCIATIONS: "gpt-4o",
        LLMModelCategory.VIEWS: "gpt-4o-mini",
    },
    "google": {
        LLMModelCategory.ORCHESTRATION: "gemini-2.0-flash",
        LLMModelCategory.STRUCTURED: "gemini-2.0-flash",
        LLMModelCategory.CHAT: "gemini-2.0-flash",
        LLMModelCategory.ANALYSIS: "gemini-2.0-flash",
        LLMModelCategory.ASSOCIATIONS: "gemini-2.0-flash",
        LLMModelCategory.VIEWS: "gemini-2.0-flash",
    },
    "huggingface": {
        LLMModelCategory.ORCHESTRATION: "mistralai/Mistral-7B-Instruct-v0.2",
        LLMModelCategory.STRUCTURED: "mistralai/Mistral-7B-Instruct-v0.2",
        LLMModelCategory.CHAT: "mistralai/Mistral-7B-Instruct-v0.2",
        LLMModelCategory.ANALYSIS: "mistralai/Mistral-7B-Instruct-v0.2",
        LLMModelCategory.ASSOCIATIONS: "mistralai/Mistral-7B-Instruct-v0.2",
        LLMModelCategory.VIEWS: "mistralai/Mistral-7B-Instruct-v0.2",
    },
    "ollama": {
        LLMModelCategory.ORCHESTRATION: "llama3.2",
        LLMModelCategory.STRUCTURED: "llama3.2",
        LLMModelCategory.CHAT: "llama3.2",
        LLMModelCategory.ANALYSIS: "llama3.2",
        LLMModelCategory.ASSOCIATIONS: "llama3.2",
        LLMModelCategory.VIEWS: "llama3.2",
    },
}


class LLMConfig:
    """Configuration for LLM providers, read from environment variables."""

    def __init__(self):
        self._openai_key = os.getenv("OPENAI_API_KEY", "")
        self._google_key = os.getenv("GOOGLE_API_KEY", "")
        self._hf_token = os.getenv("HUGGINGFACE_API_TOKEN", "")

    def get_available_providers(self) -> list:
        """Return list of providers that have API keys configured."""
        from llm.manager import LLMType

        available = []
        if self._openai_key:
            available.append(LLMType.OPENAI)
        if self._google_key:
            available.append(LLMType.GOOGLE)
        # HuggingFace: api mode needs a token; local mode does not
        hf_mode = os.getenv("OPENRAG_HF_MODE", "api").lower()
        if hf_mode == "local" or self._hf_token:
            available.append(LLMType.HUGGINGFACE)
        # Ollama: always considered available (connection checked at call time)
        available.append(LLMType.OLLAMA)
        return available

    def validate_provider_config(self, provider) -> bool:
        """Check if a provider has the required credentials."""
        from llm.manager import LLMType

        if provider == LLMType.OPENAI:
            return bool(self._openai_key)
        if provider == LLMType.GOOGLE:
            return bool(self._google_key)
        if provider == LLMType.HUGGINGFACE:
            hf_mode = os.getenv("OPENRAG_HF_MODE", "api").lower()
            return hf_mode == "local" or bool(self._hf_token)
        if provider == LLMType.OLLAMA:
            return True  # Connection is validated at call time
        return False

    def get_model_for_category(
        self, category: LLMModelCategory, provider
    ) -> str:
        """Get the recommended model for a use-case category + provider."""
        from llm.manager import LLMType

        provider_key = provider.value if isinstance(provider, LLMType) else str(provider)
        models = _CATEGORY_MODELS.get(provider_key, {})
        return models.get(category, "gpt-4o")

    def get_provider_config(self, provider) -> Dict[str, Any]:
        """
        Return the full configuration dict for a provider.

        The dict includes ``api_key``, ``default_model``, and any
        provider-specific settings.  The ``api_key`` is read from
        environment variables.
        """
        from llm.manager import LLMType

        if provider == LLMType.OPENAI:
            return {
                "api_key": self._openai_key,
                "default_model": os.getenv("OPENAI_DEFAULT_MODEL", "gpt-4o"),
                "default_temperature": 0.0,
                "max_tokens": int(os.getenv("OPENAI_MAX_TOKENS", "4096")),
                "timeout": int(os.getenv("OPENAI_TIMEOUT", "120")),
            }

        if provider == LLMType.GOOGLE:
            return {
                "api_key": self._google_key,
                "default_model": os.getenv(
                    "GOOGLE_DEFAULT_MODEL", "gemini-2.0-flash"
                ),
                "default_temperature": 0.0,
                "max_output_tokens": int(
                    os.getenv("GOOGLE_MAX_TOKENS", "4096")
                ),
            }

        if provider == LLMType.HUGGINGFACE:
            return {
                "api_token": self._hf_token,
                "default_model": os.getenv(
                    "OPENRAG_HF_MODEL", "mistralai/Mistral-7B-Instruct-v0.2"
                ),
                "default_temperature": float(os.getenv("OPENRAG_HF_TEMPERATURE", "0.1")),
                "hf_mode": os.getenv("OPENRAG_HF_MODE", "api"),
                "task": os.getenv("OPENRAG_HF_TASK", "text-generation"),
                "max_new_tokens": int(os.getenv("OPENRAG_HF_MAX_NEW_TOKENS", "1024")),
            }

        if provider == LLMType.OLLAMA:
            return {
                "default_model": os.getenv("OPENRAG_OLLAMA_MODEL", "llama3.2"),
                "default_temperature": float(os.getenv("OPENRAG_OLLAMA_TEMPERATURE", "0.1")),
                "base_url": os.getenv("OPENRAG_OLLAMA_BASE_URL", "http://localhost:11434"),
            }

        raise ValueError(f"Unknown provider: {provider}")

    # ------------------------------------------------------------------
    # Rate limit configuration
    # ------------------------------------------------------------------

    @staticmethod
    def _model_env_key(model: str) -> str:
        key = re.sub(r"[^a-zA-Z0-9]+", "_", model or "")
        key = re.sub(r"_+", "_", key).strip("_")
        return key.upper() or "DEFAULT"

    def get_rate_limit_runtime(self) -> Dict[str, Any]:
        """Runtime configuration for global LLM rate limiting."""
        return {
            "enabled": os.getenv("LLM_RATE_LIMIT_ENABLED", "false").lower() == "true",
            "backend": os.getenv("LLM_RATE_LIMIT_BACKEND", "redis").lower(),
            "redis_url": os.getenv("LLM_RATE_LIMIT_REDIS_URL", "redis://localhost:6379/0"),
            "redis_key_prefix": os.getenv("LLM_RATE_LIMIT_REDIS_KEY_PREFIX", "llm:rl"),
            "timeout_seconds": float(os.getenv("LLM_RATE_LIMIT_TIMEOUT_SECONDS", "90")),
            "safety_factor": float(os.getenv("LLM_RATE_LIMIT_SAFETY_FACTOR", "1.15")),
            "stale_head_seconds": float(os.getenv("LLM_RATE_LIMIT_STALE_HEAD_SECONDS", "30")),
            "poll_interval_seconds": float(os.getenv("LLM_RATE_LIMIT_POLL_INTERVAL_SECONDS", "0.5")),
            "heartbeat_interval_seconds": float(os.getenv("LLM_RATE_LIMIT_HEARTBEAT_SECONDS", "2")),
            "output_token_reserve": int(os.getenv("LLM_RATE_LIMIT_OUTPUT_RESERVE_TOKENS", "1024")),
            "fail_open": os.getenv("LLM_RATE_LIMIT_FAIL_OPEN", "false").lower() == "true",
        }

    def get_rate_limit_policy(self, provider, model: str) -> Dict[str, Any]:
        """
        Resolve policy (TPM/RPM) for provider + model from env.

        Precedence:
        1. Per-model: ``LLM_LIMIT_{PROVIDER}_{MODEL}_TPM/RPM``
        2. Provider defaults: ``LLM_LIMIT_{PROVIDER}_DEFAULT_TPM/RPM``
        3. Built-in conservative fallback
        """
        from llm.manager import LLMType

        runtime = self.get_rate_limit_runtime()
        provider_key = provider.value if isinstance(provider, LLMType) else str(provider)
        provider_key = provider_key.lower()
        provider_env = provider_key.upper()
        model_env = self._model_env_key(model)

        model_tpm = os.getenv(f"LLM_LIMIT_{provider_env}_{model_env}_TPM")
        model_rpm = os.getenv(f"LLM_LIMIT_{provider_env}_{model_env}_RPM")
        default_tpm = os.getenv(f"LLM_LIMIT_{provider_env}_DEFAULT_TPM")
        default_rpm = os.getenv(f"LLM_LIMIT_{provider_env}_DEFAULT_RPM")

        # Conservative defaults if no envs are provided.
        built_in_tpm = 60_000 if provider_key == "openai" else 80_000
        built_in_rpm = 300 if provider_key == "openai" else 300

        tpm = int(model_tpm or default_tpm or built_in_tpm)
        rpm = int(model_rpm or default_rpm or built_in_rpm)

        return {
            "tpm": max(1, tpm),
            "rpm": max(1, rpm),
            "safety_factor": runtime["safety_factor"],
            "max_wait_seconds": runtime["timeout_seconds"],
            "stale_head_seconds": runtime["stale_head_seconds"],
            "poll_interval_seconds": runtime["poll_interval_seconds"],
            "heartbeat_interval_seconds": runtime["heartbeat_interval_seconds"],
            "output_token_reserve": runtime["output_token_reserve"],
            "fail_open": runtime["fail_open"],
        }


_config = None


def get_llm_config() -> LLMConfig:
    """Return a cached LLMConfig instance."""
    global _config
    if _config is None:
        _config = LLMConfig()
    return _config
