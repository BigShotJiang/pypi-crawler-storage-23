"""Shim: re-exports from parsers.unified_parser, avoiding circular imports."""
import importlib.util
import sys
from pathlib import Path


def _import_unified_parser():
    """Load parsers/unified_parser.py directly without triggering parsers/__init__.py."""
    mod_name = "parsers.unified_parser"
    if mod_name in sys.modules:
        return sys.modules[mod_name]

    file_path = Path(__file__).resolve().parents[3] / "parsers" / "unified_parser.py"
    spec = importlib.util.spec_from_file_location(mod_name, file_path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)
    return mod


_mod = _import_unified_parser()

# Re-export the names that other parsers import
normalize_extension = _mod.normalize_extension
parse_document = getattr(_mod, "parse_document", None)
