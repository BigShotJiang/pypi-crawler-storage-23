"""Shim: re-exports from structured_data.run."""
from structured_data.run import *  # noqa: F401,F403
from structured_data.run import run_pipeline  # noqa: F811
