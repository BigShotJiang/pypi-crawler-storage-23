"""Shim: re-exports from structured_data.run_query."""
from structured_data.run_query import *  # noqa: F401,F403
