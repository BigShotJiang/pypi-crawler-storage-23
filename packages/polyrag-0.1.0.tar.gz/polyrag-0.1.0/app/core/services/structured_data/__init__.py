"""Shim: re-exports from structured_data."""
from structured_data import *  # noqa: F401,F403
from structured_data.pipeline import StructuredDataPipeline  # noqa: F811
