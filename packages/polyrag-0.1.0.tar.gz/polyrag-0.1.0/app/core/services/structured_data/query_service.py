"""Shim: re-exports from structured_data.query_service."""
from structured_data.query_service import *  # noqa: F401,F403
from structured_data.query_service import StructuredDataQueryService  # noqa: F811
