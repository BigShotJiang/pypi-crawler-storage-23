"""Shim: re-exports from structured_data.evaluation_assertions."""
from structured_data.evaluation_assertions import *  # noqa: F401,F403
from structured_data.evaluation_assertions import evaluate_query_result  # noqa: F811
