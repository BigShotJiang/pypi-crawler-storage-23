"""Stub: OCR utilities. Actual implementation not available in standalone mode."""

def extract_text_from_pdf(*args, **kwargs):
    raise NotImplementedError("OCR not available in standalone mode")

def extract_text_from_image(*args, **kwargs):
    raise NotImplementedError("OCR not available in standalone mode")
