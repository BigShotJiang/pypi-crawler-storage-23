#!/usr/bin/env python3
"""
Unified Document Parser

This module provides a single interface for document parsing that automatically
routes to the best parser based on file type:
- LlamaParse: ALWAYS for Excel/CSV files (.xlsx, .xls, .xlsm, .csv) - better sheet handling
- LlamaParse: ALWAYS for image files (.jpg, .jpeg, .png) - OCR and text extraction
- Docling: for PDF, DOCX, PPTX, TXT, MD (local, fast, free)
- LlamaParse: for other formats and as fallback (cloud-based, accurate, paid)

Returns consistent structure:
- LangChain Documents (page-wise)
- Pandas DataFrames (tables)
- Merged tables (optional)
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import os
import re

import pandas as pd

try:
    from langchain_core.documents import Document as LCDocument
except ImportError:
    try:
        from langchain.schema import Document as LCDocument
    except ImportError:
        LCDocument = None  # type: ignore


# File extensions supported by each parser
DOCLING_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt", ".md", ".xlsx", ".xlsm", ".csv"}
LLAMAPARSE_EXTENSIONS = {".pdf", ".docx", ".pptx", ".xlsx", ".xls", ".xlsm", ".csv", ".jpg", ".jpeg", ".png"}


def normalize_extension(extension: str) -> str:
    """
    Normalize file extension by extracting the base extension from variant extensions.
    
    Handles variant extensions like:
    - .xlsx_v2, .xlsx_v7, .xlsx_v10 → .xlsx
    - .pdf_v7, .pdf_v2 → .pdf
    - .csv_v3 → .csv
    
    Args:
        extension: File extension (with or without leading dot, e.g., ".xlsx_v2" or "xlsx_v2")
        
    Returns:
        Normalized base extension with leading dot (e.g., ".xlsx")
        
    Examples:
        >>> normalize_extension(".xlsx_v2")
        '.xlsx'
        >>> normalize_extension("pdf_v7")
        '.pdf'
        >>> normalize_extension(".csv")
        '.csv'
    """
    # Ensure extension starts with dot for consistency
    if not extension.startswith("."):
        extension = "." + extension
    
    extension = extension.lower()
    
    # Pattern to match version suffixes: _v followed by digits
    # Matches: _v2, _v7, _v10, _v123, etc.
    version_pattern = r"_v\d+$"
    
    # Remove version suffix if present
    normalized = re.sub(version_pattern, "", extension)
    
    return normalized

# Environment variables for LLM cleanup configuration
# For Excel/CSV files (sheets): Default True, always enabled unless explicitly disabled
USE_LLM_CLEANUP_FOR_SHEETS = os.getenv("USE_LLM_CLEANUP_FOR_SHEETS", "True").lower() in ("true", "1", "yes")
# For PDFs, DOCX, PPTX, etc. (documents): Default False
USE_LLM_CLEANUP_FOR_DOCS = os.getenv("USE_LLM_CLEANUP_FOR_DOCS", "False").lower() in ("true", "1", "yes")
# Keep table parts separate instead of combining them (for saving as separate tables in S3/Athena)
# Default False (combines parts into _combined_clean_llm tables)
KEEP_TABLE_PARTS_SEPARATE = os.getenv("KEEP_TABLE_PARTS_SEPARATE", "False").lower() in ("true", "1", "yes")


@dataclass
class UnifiedParseResult:
    """
    Unified result structure returned by any parser.
    
    Attributes:
        file_path: Path to the source file
        file_name: Name of the source file
        document_type: File extension (e.g., 'pdf', 'docx')
        parser_used: Which parser was used ('docling' or 'llamaparse')
        
        documents: List of LangChain Document objects (page-wise)
        tables: Dict mapping table identifiers to pandas DataFrames
        merged_tables: Optional dict of merged tables (by matching headers)
        
        full_markdown: Complete document as markdown (if available)
        metadata: Additional parser-specific metadata
    """
    file_path: str
    file_name: str
    document_type: str
    parser_used: str
    
    documents: List[Any]  # LangChain Documents
    tables: Dict[str, pd.DataFrame]
    merged_tables: Optional[Dict[str, pd.DataFrame]] = None
    
    full_markdown: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


def _normalize_docling_result(
    docling_result: Any,
    file_path: Path,
) -> UnifiedParseResult:
    """
    Normalize Docling ParsedDocResult to UnifiedParseResult.
    """
    # Convert page_docs to list of LangChain Documents
    documents = docling_result.page_docs
    
    # Convert tables to dict format
    tables = {}
    for i, table_result in enumerate(docling_result.tables, 1):
        key = f"page{table_result.page_no}_table{i}" if table_result.page_no else f"table{i}"
        tables[key] = table_result.dataframe
    
    # Get merged tables
    merged_tables = docling_result.merged_tables
    
    return UnifiedParseResult(
        file_path=str(file_path),
        file_name=file_path.name,
        document_type=normalize_extension(file_path.suffix).lstrip("."),
        parser_used="docling",
        documents=documents,
        tables=tables,
        merged_tables=merged_tables,
        full_markdown=docling_result.full_markdown,
        metadata={
            "total_pages": len(docling_result.page_docs),
            "total_tables": len(docling_result.tables),
            "total_merged_tables": len(merged_tables) if merged_tables else 0,
        },
    )


def _normalize_llamaparse_result(
    llamaparse_result: Dict[str, Any],
    file_path: Path,
) -> UnifiedParseResult:
    """
    Normalize LlamaParse result dict to UnifiedParseResult.
    """
    # Get LangChain Documents
    documents = llamaparse_result.get("documents", [])
    
    # Collect all tables from pages (prefer LLM-cleaned versions)
    tables = {}
    for page in llamaparse_result.get("pages", []):
        page_tables = page.get("tables_llm") or page.get("tables", {})
        tables.update(page_tables)
    
    # Get merged tables
    merged_tables = llamaparse_result.get("merged_tables")
    
    # Try to construct full markdown
    full_markdown = None
    if llamaparse_result.get("pages"):
        markdown_parts = [page.get("markdown", "") for page in llamaparse_result["pages"]]
        full_markdown = "\n\n---\n\n".join(markdown_parts)
    
    return UnifiedParseResult(
        file_path=str(file_path),
        file_name=llamaparse_result.get("file_name", file_path.name),
        document_type=llamaparse_result.get("document_type", normalize_extension(file_path.suffix).lstrip(".")),
        parser_used="llamaparse",
        documents=documents,
        tables=tables,
        merged_tables=merged_tables,
        full_markdown=full_markdown,
        metadata={
            "total_pages": len(llamaparse_result.get("pages", [])),
            "total_tables": llamaparse_result.get("table_count", 0),
            "total_merged_tables": llamaparse_result.get("merged_table_count", 0),
            "llm_cleanup": llamaparse_result.get("llm_cleanup") is not None,
        },
    )


def parse_document(
    file_path: Union[str, Path],
    *,
    prefer_llamaparse: bool = False,
    merge_tables: bool = True,
    ocr: bool = True,
    use_llm_cleanup: Optional[bool] = None,
) -> UnifiedParseResult:
    """
    Parse a document using the most appropriate parser.
    
    Routing logic:
    - LlamaParse: ALWAYS for Excel/CSV files (.xlsx, .xls, .xlsm, .csv) - better sheet name handling
    - LlamaParse: ALWAYS for image files (.jpg, .jpeg, .png) - OCR and text extraction
    - Docling: for PDF, DOCX, PPTX, TXT, MD (local, fast, free)
    - LlamaParse: for other formats or when prefer_llamaparse=True
    
    Args:
        file_path: Path to document to parse
        prefer_llamaparse: Force use of LlamaParse even for Docling-supported formats
        merge_tables: Merge tables with matching headers across pages
        ocr: Enable OCR for scanned documents (Docling only)
        use_llm_cleanup: Use LLM to clean table headers (LlamaParse only).
                        If None, uses environment variables:
                        - USE_LLM_CLEANUP_FOR_SHEETS (default: True) for Excel/CSV
                        - USE_LLM_CLEANUP_FOR_DOCS (default: False) for PDFs/DOCX/PPTX
        
    Returns:
        UnifiedParseResult with consistent structure regardless of parser used
        
    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file format is not supported by any parser
        
    Example:
        >>> result = parse_document("invoice.pdf", merge_tables=True)
        >>> print(f"Parsed with {result.parser_used}")
        >>> print(f"Pages: {len(result.documents)}")
        >>> print(f"Tables: {len(result.tables)}")
        >>> if result.merged_tables:
        ...     for name, df in result.merged_tables.items():
        ...         print(f"{name}: {df.shape}")
    """
    path = Path(file_path).resolve()
    
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    
    # Normalize extension to handle variant extensions like .xlsx_v2, .pdf_v7
    extension = normalize_extension(path.suffix)
    
    # Determine LLM cleanup setting based on file type and environment variables
    excel_csv_extensions = {".xlsx", ".xls", ".xlsm", ".csv", ".tsv"}
    if use_llm_cleanup is None:
        if extension in excel_csv_extensions:
            # For Excel/CSV files: Use USE_LLM_CLEANUP_FOR_SHEETS (default: True)
            use_llm_cleanup = USE_LLM_CLEANUP_FOR_SHEETS
        else:
            # For PDFs, DOCX, PPTX, etc.: Use USE_LLM_CLEANUP_FOR_DOCS (default: False)
            use_llm_cleanup = USE_LLM_CLEANUP_FOR_DOCS
    
    # ALWAYS use LlamaParse for Excel/CSV files (better sheet name handling)
    if extension in excel_csv_extensions:
        return _parse_with_llamaparse(
            path,
            merge_tables=merge_tables,
            use_llm_cleanup=use_llm_cleanup,
        )
    
    # ALWAYS use LlamaParse for image files (JPEG, PNG) - OCR and text extraction
    image_extensions = {".jpg", ".jpeg", ".png"}
    if extension in image_extensions:
        return _parse_with_llamaparse(
            path,
            merge_tables=merge_tables,
            use_llm_cleanup=use_llm_cleanup,
        )
    
    # Determine which parser to use for other formats
    use_docling = (
        extension in DOCLING_EXTENSIONS
        and not prefer_llamaparse
    )
    
    if use_docling:
        return _parse_with_docling(
            path,
            merge_tables=merge_tables,
            ocr=ocr,
        )
    elif extension in LLAMAPARSE_EXTENSIONS:
        return _parse_with_llamaparse(
            path,
            merge_tables=merge_tables,
            use_llm_cleanup=use_llm_cleanup,
        )
    else:
        raise ValueError(
            f"Unsupported file format: {extension}\n"
            f"Docling supports: {', '.join(sorted(DOCLING_EXTENSIONS))}\n"
            f"LlamaParse supports: {', '.join(sorted(LLAMAPARSE_EXTENSIONS))}"
        )


def _parse_with_docling(
    file_path: Path,
    *,
    merge_tables: bool,
    ocr: bool,
) -> UnifiedParseResult:
    """Parse document using Docling."""
    from .docling_utils import parse_documents_in_memory
    
    results = parse_documents_in_memory(
        [file_path],
        ocr=ocr,
        do_table_structure=True,
        fast_tables=False,  # Use accurate mode for better results
        merge_tables_with_same_headers=merge_tables,
    )
    
    if not results:
        raise RuntimeError(f"Docling failed to parse: {file_path}")
    
    return _normalize_docling_result(results[0], file_path)


def _parse_with_llamaparse(
    file_path: Path,
    *,
    merge_tables: bool,
    use_llm_cleanup: bool,
) -> UnifiedParseResult:
    """Parse document using LlamaParse."""
    from .llama_parse_extraction import extract_tables_and_markdown
    
    result = extract_tables_and_markdown(
        str(file_path),
        use_llm_cleanup=use_llm_cleanup,
        concatenate_matching_headers=merge_tables,
    )
    
    return _normalize_llamaparse_result(result, file_path)


def parse_documents(
    file_paths: List[Union[str, Path]],
    *,
    prefer_llamaparse: bool = False,
    merge_tables: bool = True,
    ocr: bool = True,
    use_llm_cleanup: bool = True,
) -> List[UnifiedParseResult]:
    """
    Parse multiple documents.
    
    Args:
        file_paths: List of paths to documents
        prefer_llamaparse: Force use of LlamaParse for all files
        merge_tables: Merge tables with matching headers across pages
        ocr: Enable OCR for scanned documents
        use_llm_cleanup: Use LLM to clean table headers (LlamaParse)
        
    Returns:
        List of UnifiedParseResult objects
        
    Example:
        >>> results = parse_documents(["doc1.pdf", "doc2.docx"])
        >>> for result in results:
        ...     print(f"{result.file_name}: {len(result.documents)} pages")
    """
    results = []
    
    for file_path in file_paths:
        try:
            result = parse_document(
                file_path,
                prefer_llamaparse=prefer_llamaparse,
                merge_tables=merge_tables,
                ocr=ocr,
                use_llm_cleanup=use_llm_cleanup,
            )
            results.append(result)
        except Exception as e:
            print(f"Warning: Failed to parse {file_path}: {e}")
            continue
    
    return results


# Convenience functions for specific use cases

def parse_document_for_rag(
    file_path: Union[str, Path],
    *,
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List[Any]:
    """
    Parse document and return chunked LangChain Documents ready for RAG.
    
    Args:
        file_path: Path to document
        chunk_size: Maximum chunk size in characters
        chunk_overlap: Overlap between chunks
        
    Returns:
        List of chunked LangChain Documents with metadata
    """
    result = parse_document(file_path, merge_tables=True)
    
    # For RAG, we typically want to chunk the documents
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        
        chunked_docs = splitter.split_documents(result.documents)
        
        # Also include table documents (as separate chunks)
        for table_key, df in result.tables.items():
            df = df.reset_index(drop=True)
            table_md = df.to_markdown(index=False)
            table_doc = LCDocument(
                page_content=table_md,
                metadata={
                    "source": result.file_path,
                    "file_name": result.file_name,
                    "doc_type": "table",
                    "table_key": table_key,
                    "table_shape": list(df.shape),
                }
            )
            chunked_docs.append(table_doc)
        
        return chunked_docs
        
    except ImportError:
        # If text splitter not available, return original documents
        return result.documents


def get_clean_tables_by_sheet(
    result: UnifiedParseResult,
    use_actual_sheet_names: bool = True,
    skip_empty_sheets: bool = True
) -> Dict[str, pd.DataFrame]:
    """
    Extract main tables from Excel/multi-sheet documents with readable names.
    
    For Excel files, returns tables named by their actual sheet name instead of
    cryptic names like "page1_itemtable1_combined_clean_llm". Automatically
    skips empty sheets and matches data to the correct sheet.
    
    Behavior depends on KEEP_TABLE_PARTS_SEPARATE environment variable:
    - If False (default): Returns combined tables (e.g., "Sales Orders")
    - If True: Returns separate parts (e.g., "Sales Orders_Part1", "Sales Orders_Part2")
    
    Args:
        result: UnifiedParseResult from parse_document()
        use_actual_sheet_names: If True and file is Excel, read actual sheet names
        skip_empty_sheets: If True, skip empty sheets when mapping names
        
    Returns:
        Dictionary mapping sheet names to their cleaned tables.
        When KEEP_TABLE_PARTS_SEPARATE=True, includes separate parts with _PartN suffix.
        
    Example:
        >>> result = parse_document("sales.xlsx", prefer_llamaparse=True)
        >>> clean_tables = get_clean_tables_by_sheet(result)
        >>> # With KEEP_TABLE_PARTS_SEPARATE=False (default):
        >>> print(clean_tables.keys())
        dict_keys(['Sales Orders', 'Old Sales Orders'])  # Combined tables
        >>> 
        >>> # With KEEP_TABLE_PARTS_SEPARATE=True:
        >>> print(clean_tables.keys())
        dict_keys(['Sales Orders_Part1', 'Sales Orders_Part2', 'Old Sales Orders_Part1'])
    """
    clean_tables = {}
    
    # Get actual Excel sheet names and check which have data
    page_to_actual_sheet = {}
    non_empty_sheets = []
    
    if use_actual_sheet_names and result.document_type in ['xlsx', 'xls', 'xlsm']:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(result.file_path, read_only=True, data_only=True)
            
            for idx, sheet_name in enumerate(wb.sheetnames, start=1):
                sheet = wb[sheet_name]
                
                # Check if sheet has actual data (not just formatting)
                has_data = False
                if skip_empty_sheets:
                    # Check first 100 rows for any non-None values
                    for row in sheet.iter_rows(max_row=100, values_only=True):
                        if any(cell is not None and str(cell).strip() for cell in row):
                            has_data = True
                            break
                else:
                    has_data = True  # Consider all sheets as having data
                
                if has_data:
                    non_empty_sheets.append(sheet_name)
                    # Map to the index in non-empty sheets (1-based)
                    page_to_actual_sheet[len(non_empty_sheets)] = sheet_name
            
            wb.close()
        except Exception as e:
            # Fall back to using metadata sheet names
            import warnings
            warnings.warn(f"Could not read Excel sheet names: {e}")
    
    # For LlamaParse results, map page numbers to sheet names
    if result.parser_used == "llamaparse":
        # Build mapping of page number -> sheet name from documents
        page_to_sheet = {}
        for doc in result.documents:
            metadata = doc.metadata if hasattr(doc, 'metadata') else doc.get('metadata', {})
            page_num = metadata.get('page_number')
            sheet_name = metadata.get('sheet_name')
            if page_num and sheet_name:
                page_to_sheet[page_num] = sheet_name
        
        # Check if we should keep parts separate
        keep_parts_separate = KEEP_TABLE_PARTS_SEPARATE
        
        if keep_parts_separate:
            # When keeping parts separate, look for individual _part*_clean_llm tables
            import re
            # Group parts by their base (e.g., page1_itemtable1)
            parts_by_base = {}
            
            for table_key, df in result.tables.items():
                if '_clean_llm' in table_key and '_combined_clean_llm' not in table_key:
                    # Match patterns like: page1_itemtable1_part1_clean_llm or page1_itemtable1_clean_llm
                    match = re.match(r'(page\d+_(?:item)?table\d+)(?:_part(\d+))?_clean_llm', table_key)
                    if match:
                        base = match.group(1)
                        part_num = match.group(2) if match.group(2) else None
                        
                        if base not in parts_by_base:
                            parts_by_base[base] = []
                        
                        parts_by_base[base].append({
                            'key': table_key,
                            'df': df,
                            'part_num': int(part_num) if part_num else 0
                        })
            
            # Process each base and create separate table names for each part
            for base, parts in parts_by_base.items():
                # Sort parts by part number
                parts.sort(key=lambda x: x['part_num'])
                
                # Extract page number from base
                page_match = re.match(r'page(\d+)_', base)
                if page_match:
                    page_num = int(page_match.group(1))
                    
                    # Get sheet name
                    if page_num in page_to_actual_sheet:
                        base_sheet_name = page_to_actual_sheet[page_num]
                    else:
                        base_sheet_name = page_to_sheet.get(page_num, f"Sheet {page_num}")
                        if base_sheet_name.startswith('page') and base_sheet_name[4:].isdigit():
                            base_sheet_name = f"Sheet {page_num}"
                    
                    # Create separate table names for each part
                    if len(parts) == 1:
                        # Only one part, use base sheet name
                        clean_tables[base_sheet_name] = parts[0]['df']
                    else:
                        # Multiple parts, append part number
                        for part in parts:
                            if part['part_num'] > 0:
                                sheet_name = f"{base_sheet_name}_Part{part['part_num']}"
                            else:
                                sheet_name = f"{base_sheet_name}_Part1"
                            clean_tables[sheet_name] = part['df']
                else:
                    # Fallback: use original keys with part numbers
                    for part in parts:
                        if part['part_num'] > 0:
                            clean_tables[f"{base}_Part{part['part_num']}"] = part['df']
                        else:
                            clean_tables[base] = part['df']
        else:
            # When combine_parts=True (default), _combined_clean_llm always exists for every sheet
            # (even for single-part tables, ensuring consistency: 5 sheets = 5 _combined_clean_llm tables)
            for table_key, df in result.tables.items():
                if '_combined_clean_llm' in table_key:
                    # Extract page number from key (e.g., "page1_itemtable1_combined_clean_llm")
                    import re
                    match = re.match(r'page(\d+)_', table_key)
                    if match:
                        page_num = int(match.group(1))
                        
                        # Use actual Excel sheet name if available
                        if page_num in page_to_actual_sheet:
                            sheet_name = page_to_actual_sheet[page_num]
                        else:
                            # Otherwise use metadata sheet name
                            sheet_name = page_to_sheet.get(page_num, f"Sheet {page_num}")
                            
                            # Clean up if it's still "pageX"
                            if sheet_name.startswith('page') and sheet_name[4:].isdigit():
                                sheet_name = f"Sheet {page_num}"
                        
                        clean_tables[sheet_name] = df
                    else:
                        # Fallback to original key if parsing fails
                        clean_tables[table_key] = df
    
    # For Docling results, use page metadata
    elif result.parser_used == "docling":
        # Docling tables are already well-named, just use them
        clean_tables = result.tables.copy()
    
    else:
        # Unknown parser, return as-is
        clean_tables = result.tables.copy()
    
    return clean_tables


def get_parser_recommendation(file_path: Union[str, Path]) -> str:
    """
    Get recommendation for which parser to use.
    
    Returns:
        String describing the recommended parser and reasoning
    """
    path = Path(file_path)
    extension = normalize_extension(path.suffix)
    
    if extension in {".pdf", ".docx", ".pptx"}:
        return (
            f"Recommended: Docling (local, fast, free)\n"
            f"  - Good for: Standard PDFs, Office documents\n"
            f"  - Fallback to LlamaParse if: Tables classified as images, complex layouts\n"
            f"Alternative: LlamaParse (cloud, accurate, paid)\n"
            f"  - Better for: Complex tables, scanned documents, forms"
        )
    elif extension in {".xlsx", ".xls", ".xlsm", ".csv"}:
        return (
            f"Recommended: Docling (for Excel/CSV - if supported in your version)\n"
            f"Alternative: LlamaParse\n"
            f"  - Better for: Complex Excel workbooks with multiple sheets"
        )
    elif extension == ".txt":
        return "Recommended: Docling (local, simple text parsing)"
    elif extension == ".md":
        return "Recommended: Docling (native markdown support)"
    else:
        return f"Unsupported format: {extension}"


# Example usage
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python unified_parser.py <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    
    print(f"Parsing: {file_path}")
    print("=" * 80)
    
    # Get recommendation
    recommendation = get_parser_recommendation(file_path)
    print(f"\n{recommendation}\n")
    print("=" * 80)
    
    # Parse the document
    result = parse_document(file_path, merge_tables=True)
    
    print(f"\nParser used: {result.parser_used}")
    print(f"File: {result.file_name}")
    print(f"Type: {result.document_type}")
    print(f"\nDocuments (pages): {len(result.documents)}")
    print(f"Tables: {len(result.tables)}")
    print(f"Merged tables: {len(result.merged_tables) if result.merged_tables else 0}")
    
    # Show document details
    print("\n--- Documents ---")
    for i, doc in enumerate(result.documents, 1):
        metadata = doc.metadata if hasattr(doc, 'metadata') else doc.get('metadata', {})
        content_len = len(doc.page_content if hasattr(doc, 'page_content') else doc.get('page_content', ''))
        page_no = metadata.get('page_no') or metadata.get('page_number') or i
        print(f"  Page {page_no}: {content_len} chars")
    
    # Show table details
    if result.tables:
        print("\n--- Tables ---")
        for key, df in result.tables.items():
            print(f"  {key}: {df.shape[0]} rows x {df.shape[1]} cols")
            print(f"    Columns: {df.columns.tolist()}")
    
    # Show merged tables
    if result.merged_tables:
        print("\n--- Merged Tables ---")
        for key, df in result.merged_tables.items():
            print(f"  {key}: {df.shape[0]} rows x {df.shape[1]} cols")
            print(f"    Columns: {df.columns.tolist()}")
    
    # Show clean tables with readable names (for Excel)
    if result.document_type in ['xlsx', 'xls', 'xlsm']:
        print("\n--- Clean Tables by Sheet Name ---")
        clean_tables = get_clean_tables_by_sheet(result)
        for sheet_name, df in clean_tables.items():
            print(f"  {sheet_name}: {df.shape[0]} rows x {df.shape[1]} cols")
            print(f"    Columns: {df.columns.tolist()}")

