"""
DOCX Parser - Extract text from Microsoft Word documents.

Supports:
- Text extraction from paragraphs
- Tables
- Headers and footers
- Bulleted and numbered lists
- OCR fallback for documents with insufficient text
"""

import logging
import zipfile
from typing import Dict, Any, Optional
from pathlib import Path
import sys
import os
from app.core.parsers.unified_parser import normalize_extension

# Add parent directory to path to import from utils
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

try:
    from langchain_community.document_loaders import Docx2txtLoader
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    TEXT_SPLITTER_AVAILABLE = True
except ImportError:
    TEXT_SPLITTER_AVAILABLE = False

try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

try:
    from app.utils.ocr import extract_text_from_image
    OCR_UTILS_AVAILABLE = True
except ImportError:
    OCR_UTILS_AVAILABLE = False

try:
    from pdf2image import convert_from_path
    PDF2IMAGE_AVAILABLE = True
except ImportError:
    PDF2IMAGE_AVAILABLE = False

try:
    from docx2pdf import convert
    DOCX2PDF_AVAILABLE = True
except ImportError:
    DOCX2PDF_AVAILABLE = False

OCR_AVAILABLE = OCR_UTILS_AVAILABLE and PDF2IMAGE_AVAILABLE and DOCX2PDF_AVAILABLE

logger = logging.getLogger(__name__)

# Text length threshold to trigger OCR
MIN_TEXT_LENGTH_THRESHOLD = 100


class DOCXParser:
    """
    DOCX text extraction from Microsoft Word documents using LangChain loaders.
    
    Uses LangChain Docx2txtLoader for primary extraction, with OCR fallback
    for documents with insufficient text (< 100 characters).
    """
    
    def __init__(
        self, 
        use_ocr: bool = True, 
        min_text_threshold: int = MIN_TEXT_LENGTH_THRESHOLD,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        enable_chunking: bool = True
    ):
        """
        Initialize DOCX parser.
        
        Args:
            use_ocr: Whether to use OCR fallback for documents with < 100 chars (default: True)
            min_text_threshold: Minimum text length to consider extraction successful (default: 100)
            chunk_size: Maximum size of each chunk in characters (default: 1000)
            chunk_overlap: Number of characters to overlap between chunks (default: 200)
            enable_chunking: Whether to chunk the extracted text (default: True)
        """
        self.use_ocr = use_ocr
        self.min_text_threshold = min_text_threshold
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.enable_chunking = enable_chunking
        
        if not LANGCHAIN_AVAILABLE and not DOCX_AVAILABLE:
            raise RuntimeError(
                "No DOCX parsing library available. Install: pip install langchain langchain-community python-docx"
            )
        
        if not LANGCHAIN_AVAILABLE:
            logger.warning(
                "LangChain not available. Falling back to python-docx. Install: pip install langchain langchain-community"
            )
        
        if use_ocr and not OCR_AVAILABLE:
            missing_deps = []
            if not OCR_UTILS_AVAILABLE:
                missing_deps.append("app.utils.ocr")
            if not PDF2IMAGE_AVAILABLE:
                missing_deps.append("pdf2image")
            if not DOCX2PDF_AVAILABLE:
                missing_deps.append("docx2pdf")
            logger.warning(
                f"OCR requested but not available. Missing dependencies: {', '.join(missing_deps)}. "
                f"Install: pip install pdf2image docx2pdf"
            )
        
        if enable_chunking and not TEXT_SPLITTER_AVAILABLE:
            logger.warning(
                "Chunking requested but langchain-text-splitters not available. Install: pip install langchain-text-splitters"
            )
    
    def parse(self, file_path: str) -> Dict[str, Any]:
        """
        Extract text from DOCX file using LangChain loaders with OCR fallback.
        
        Args:
            file_path: Path to DOCX file
        
        Returns:
            dict: {
                "text": str,
                "chunks": list,        # List of chunked Document objects (if chunking enabled)
                "metadata": dict,
                "paragraph_count": int,
                "table_count": int,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"DOCX file not found: {file_path}")
            
            # Normalize extension to handle variant extensions like .docx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.docx', '.doc']:
                raise ValueError(f"Not a DOCX file: {file_path}")
            
            # Check file size
            file_size = file_path.stat().st_size
            if file_size == 0:
                raise ValueError(f"DOCX file is empty: {file_path}")
            
            logger.info(f"Parsing DOCX file: {file_path} ({file_size} bytes)")
            
            # Validate that the file is a valid ZIP archive (DOCX files are ZIP archives)
            try:
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    # Check if required DOCX structure exists
                    if 'word/document.xml' not in zip_ref.namelist():
                        raise ValueError(
                            f"File appears to be a ZIP but not a valid DOCX structure: {file_path}"
                        )
            except zipfile.BadZipFile as e:
                raise ValueError(
                    f"File is not a valid DOCX/ZIP archive (may be corrupted or not a real DOCX file): {file_path}. "
                    f"Error: {str(e)}"
                )
            
            # Try LangChain loader first
            result = None
            if LANGCHAIN_AVAILABLE:
                try:
                    result = self._extract_with_langchain(file_path)
                except Exception as e:
                    logger.warning(f"LangChain extraction failed: {e}")
            
            # Fallback to python-docx if LangChain failed or unavailable
            if result is None:
                result = self._extract_with_python_docx(file_path)
            
            # Check if text is too short and apply OCR if needed
            if len(result["text"].strip()) < self.min_text_threshold and self.use_ocr:
                logger.info(f"Extracted text ({len(result['text'].strip())} chars) below threshold. Attempting OCR...")
                try:
                    ocr_text = self._extract_with_ocr(file_path)
                    if ocr_text and len(ocr_text.strip()) > len(result["text"].strip()):
                        result["text"] = ocr_text
                        result["method_used"] = result.get("method_used", "unknown") + "_with_ocr"
                        logger.info(f"OCR successfully extracted {len(ocr_text.strip())} chars")
                        
                        # Re-chunk if chunking was enabled and we have chunks
                        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE and "chunks" in result:
                            try:
                                from langchain_core.documents import Document
                                updated_document = Document(page_content=ocr_text, metadata=result.get("metadata", {}))
                                result["chunks"] = self._chunk_documents([updated_document])
                                logger.info(f"Re-chunked document after OCR: {len(result['chunks'])} chunks")
                            except Exception as e:
                                logger.warning(f"Failed to re-chunk after OCR: {e}")
                except Exception as e:
                    logger.warning(f"OCR extraction failed: {e}")
            
            return result
        
        except Exception as e:
            logger.exception(f"Failed to parse DOCX: {file_path}")
            return {
                "text": "",
                "metadata": {"error": str(e)},
                "paragraph_count": 0,
                "table_count": 0,
                "method_used": "failed"
            }
    
    def _extract_with_langchain(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using LangChain Docx2txtLoader."""
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("LangChain is not installed. Install with: pip install langchain langchain-community python-docx")
        
        loader = Docx2txtLoader(str(file_path))
        documents = loader.load()
        
        # Combine all documents into a single text
        text_parts = []
        metadata = {}
        
        for doc in documents:
            text = doc.page_content if hasattr(doc, 'page_content') else str(doc)
            if text.strip():
                text_parts.append(text.strip())
            
            # Collect metadata from first document
            if not metadata and hasattr(doc, 'metadata'):
                metadata = doc.metadata.copy()
        
        combined_text = "\n\n".join(text_parts)
        
        # Count paragraphs and tables (approximate)
        paragraph_count = len([p for p in combined_text.split('\n\n') if p.strip()])
        table_count = combined_text.count('|') // 3  # Rough estimate
        
        # Chunk the documents if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                chunks = self._chunk_documents(documents)
                logger.info(f"Created {len(chunks)} chunks from {len(documents)} document(s)")
            except Exception as e:
                logger.warning(f"Failed to chunk documents: {e}")
        
        result = {
            "text": combined_text,
            "metadata": metadata,
            "paragraph_count": paragraph_count,
            "table_count": table_count,
            "method_used": "langchain"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _extract_with_python_docx(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using python-docx library (fallback method)."""
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx not available. Install: pip install python-docx")
        
        # Load document
        doc = Document(file_path)
        
        # Extract text from paragraphs
        text_parts = []
        paragraph_count = 0
        
        for paragraph in doc.paragraphs:
            text = paragraph.text.strip()
            if text:
                text_parts.append(text)
                paragraph_count += 1
        
        # Extract text from tables
        table_count = 0
        for table in doc.tables:
            table_count += 1
            table_text = self._extract_table_text(table)
            if table_text:
                text_parts.append(table_text)
        
        # Extract core properties (metadata)
        metadata = self._extract_metadata(doc)
        metadata["paragraph_count"] = paragraph_count
        metadata["table_count"] = table_count
        
        combined_text = "\n\n".join(text_parts)
        
        # Create document for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                langchain_doc = Document(page_content=combined_text, metadata=metadata)
                chunks = self._chunk_documents([langchain_doc])
                logger.info(f"Created {len(chunks)} chunks from document")
            except Exception as e:
                logger.warning(f"Failed to chunk document: {e}")
        
        result = {
            "text": combined_text,
            "metadata": metadata,
            "paragraph_count": paragraph_count,
            "table_count": table_count,
            "method_used": "python-docx"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _chunk_documents(self, documents: list) -> list:
        """
        Split documents into chunks using LangChain text splitter.
        
        Args:
            documents: List of Document objects from LangChain
            
        Returns:
            List of chunked Document objects
        """
        if not TEXT_SPLITTER_AVAILABLE:
            raise ImportError("LangChain text splitter is not installed. Install: pip install langchain-text-splitters")
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
        
        chunks = text_splitter.split_documents(documents)
        return chunks
    
    def _extract_with_ocr(self, file_path: Path) -> str:
        """
        Extract text from DOCX using OCR by converting to images.
        
        This method converts the DOCX to PDF first, then to images, then uses OCR.
        """
        if not OCR_AVAILABLE:
            raise ImportError(
                "OCR dependencies not available. Install: pip install pdf2image docx2pdf. "
                f"Status: OCR_UTILS={OCR_UTILS_AVAILABLE}, PDF2IMAGE={PDF2IMAGE_AVAILABLE}, "
                f"DOCX2PDF={DOCX2PDF_AVAILABLE}"
            )
        
        import tempfile
        
        try:
            # Convert DOCX to PDF temporarily
            with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp_pdf:
                tmp_pdf_path = tmp_pdf.name
            
            try:
                # Convert DOCX to PDF
                convert(str(file_path), tmp_pdf_path)
                
                # Convert PDF pages to images
                images = convert_from_path(tmp_pdf_path)
                
                # Extract text from each image using OCR
                text_parts = []
                for page_num, image in enumerate(images, start=1):
                    # Save image temporarily
                    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_img:
                        tmp_img_path = tmp_img.name
                        image.save(tmp_img_path, 'PNG')
                    
                    try:
                        # Extract text using OCR
                        page_text = extract_text_from_image(tmp_img_path)
                        if page_text and page_text.strip():
                            text_parts.append(page_text.strip())
                            logger.info(f"OCR extracted {len(page_text.strip())} chars from page {page_num}")
                    except Exception as e:
                        logger.warning(f"OCR failed for page {page_num}: {e}")
                    finally:
                        # Clean up temporary image
                        if os.path.exists(tmp_img_path):
                            os.unlink(tmp_img_path)
                
                return "\n\n".join(text_parts)
                
            finally:
                # Clean up temporary PDF
                if os.path.exists(tmp_pdf_path):
                    os.unlink(tmp_pdf_path)
                    
        except Exception as e:
            logger.error(f"OCR extraction failed: {e}")
            raise
    
    def _extract_table_text(self, table) -> str:
        """
        Extract text from a table.
        
        Args:
            table: docx Table object
        
        Returns:
            str: Formatted table text
        """
        try:
            rows = []
            for row in table.rows:
                cells = []
                for cell in row.cells:
                    cell_text = cell.text.strip()
                    cells.append(cell_text)
                if any(cells):  # Only add non-empty rows
                    rows.append(" | ".join(cells))
            
            return "\n".join(rows)
        
        except Exception as e:
            logger.warning(f"Failed to extract table text: {e}")
            return ""
    
    def _extract_metadata(self, doc) -> Dict[str, Any]:
        """
        Extract document metadata/properties.
        
        Args:
            doc: Document object
        
        Returns:
            dict: Metadata dictionary
        """
        try:
            core_props = doc.core_properties
            
            return {
                "author": core_props.author or "",
                "title": core_props.title or "",
                "subject": core_props.subject or "",
                "created": str(core_props.created) if core_props.created else "",
                "modified": str(core_props.modified) if core_props.modified else "",
                "last_modified_by": core_props.last_modified_by or "",
                "revision": core_props.revision or 0,
                "category": core_props.category or "",
                "comments": core_props.comments or ""
            }
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return {}
    
    @staticmethod
    def is_valid_docx(file_path: str) -> bool:
        """
        Check if file is a valid DOCX file.
        
        Args:
            file_path: Path to file
        
        Returns:
            bool: True if valid DOCX
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Normalize extension to handle variant extensions like .docx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.docx', '.doc']:
                return False
            
            # Check file size
            if file_path.stat().st_size == 0:
                return False
            
            # Validate ZIP structure
            try:
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    if 'word/document.xml' not in zip_ref.namelist():
                        return False
            except zipfile.BadZipFile:
                return False
            
            # Try to open as DOCX
            if DOCX_AVAILABLE:
                from docx import Document
                Document(file_path)
                return True
            
            return False
        
        except Exception:
            return False

