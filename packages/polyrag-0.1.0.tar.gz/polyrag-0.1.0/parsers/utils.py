from llama_cloud_services import (
    LlamaParse,
    LlamaExtract,
    LlamaCloudIndex,
)
from typing import Dict, Tuple
import inspect
import os
import re
from dotenv import load_dotenv
import json
import pandas as pd
import numpy as np
import asyncio

# Handle nested event loops for LlamaParse async operations
try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    # nest_asyncio not available, will handle with fallback
    pass

load_dotenv()

parser = LlamaParse(
    parse_mode="parse_page_with_agent",
    model="openai-gpt-4o-mini",
    high_res_ocr=True,
    adaptive_long_table=True,
    outlined_table_extraction=True,
    output_tables_as_HTML=True,
    result_type="json",
)

def extract_pages(docs):
    """Return a list of page-like objects from docs."""
    if hasattr(docs, "pages") and docs.pages is not None:
        return docs.pages
    if isinstance(docs, dict) and "pages" in docs:
        return docs.get("pages") or []
    return docs or []


def get_table_rows(table_like):
    """Return the row content from any table-like object (tables, items, subtables)."""
    if table_like is None:
        return []
    if isinstance(table_like, dict):
        rows = table_like.get("rows") or table_like.get("json") or []
        # If rows is a method, call it; otherwise return as-is
        if callable(rows) and not isinstance(rows, (list, tuple, dict)):
            try:
                rows = rows()
            except Exception:
                rows = []
        return rows if isinstance(rows, (list, tuple)) else (list(rows) if rows else [])
    
    # Try to get rows attribute
    rows_attr = getattr(table_like, "rows", None)
    if rows_attr is not None:
        # If it's a method, call it; otherwise use as-is
        if callable(rows_attr) and not isinstance(rows_attr, (list, tuple, dict)):
            try:
                rows_attr = rows_attr()
            except Exception:
                rows_attr = []
        # Ensure it's iterable
        if rows_attr and isinstance(rows_attr, (list, tuple)):
            return rows_attr
        elif rows_attr:
            try:
                return list(rows_attr)
            except (TypeError, ValueError):
                pass
    
    # Try json attribute
    json_attr = getattr(table_like, "json", None)
    if json_attr is not None:
        if callable(json_attr) and not isinstance(json_attr, (list, tuple, dict)):
            try:
                json_attr = json_attr()
            except Exception:
                json_attr = []
        if json_attr and isinstance(json_attr, (list, tuple)):
            return json_attr
        elif json_attr:
            try:
                return list(json_attr)
            except (TypeError, ValueError):
                pass
    
    return []


def is_blank(val):
    if val is None:
        return True
    if isinstance(val, str):
        return val.strip() == ""
    return False


def detect_column_alignment_issue(rows):
    """
    Detect if there's a column alignment issue where values are shifted.
    Returns the number of leading columns that should be removed (if any).
    
    This handles cases where:
    1. Multiple leading columns are consistently empty across all rows
    2. Header row has fewer cells than data rows
    3. Values appear shifted to the right
    """
    import logging
    logger = logging.getLogger(__name__)
    
    if not rows or len(rows) < 2:
        return 0
    
    # Convert to lists for easier processing
    list_rows = []
    for row in rows:
        if isinstance(row, (list, tuple)):
            list_rows.append(list(row))
        else:
            try:
                list_rows.append(list(row))
            except (TypeError, ValueError):
                list_rows.append([row])
    
    if not list_rows or len(list_rows) < 2:
        return 0
    
    rows_to_check = min(20, len(list_rows))
    
    # Check for multiple leading empty columns (up to 5 columns)
    # Count how many leading columns are consistently empty
    max_cols_to_check = min(5, len(list_rows[0]) if list_rows else 0)
    leading_empty_cols = []
    
    for col_idx in range(max_cols_to_check):
        empty_count = 0
        for row in list_rows[:rows_to_check]:
            if row and len(row) > col_idx and is_blank(row[col_idx]):
                empty_count += 1
        
        # If most rows have this column empty, it's a leading empty column
        if empty_count > rows_to_check * 0.8:
            leading_empty_cols.append(col_idx)
        else:
            # Once we find a non-empty column, stop checking
            break
    
    if leading_empty_cols:
        logger.debug(f"Found {len(leading_empty_cols)} leading empty columns: {leading_empty_cols}")
        return len(leading_empty_cols)
    
    # Check if first row (header) is significantly shorter than data rows
    first_row = list_rows[0] if list_rows else []
    data_rows = list_rows[1:min(10, len(list_rows))]
    
    if not first_row or not data_rows:
        return 0
    
    first_row_len = len([c for c in first_row if not is_blank(c)])
    data_row_lens = [len([c for c in r if not is_blank(c)]) for r in data_rows]
    avg_data_len = sum(data_row_lens) / len(data_row_lens) if data_row_lens else 0
    
    logger.debug(f"Header row: {first_row_len} non-empty cells, Data rows avg: {avg_data_len:.1f} non-empty cells")
    
    # NEW: Check for pattern where header has values but data rows have empty cells in those positions
    # This detects cases like: header=["#", "metric", "fy20", "fy21", "fy22"]
    # but data=["1", "Sales", empty, empty, "1325545"] (data shifted right)
    consecutive_empty_cols = []
    max_cols_to_check = min(15, len(first_row), len(data_rows[0]) if data_rows else 0)
    
    # Start checking from column 2 (skip # and metric columns which are usually fine)
    for col_idx in range(2, max_cols_to_check):
        # Check if header has a non-empty value at this position
        header_has_value = col_idx < len(first_row) and not is_blank(first_row[col_idx])
        
        if header_has_value:
            # Check how many data rows have this column empty
            empty_in_data = sum(1 for r in data_rows if r and len(r) > col_idx and is_blank(r[col_idx]))
            
            # If header has value but most data rows are empty, this is an empty column
            if empty_in_data > len(data_rows) * 0.7:
                consecutive_empty_cols.append(col_idx)
            else:
                # If we find a non-empty column after finding empty ones, stop
                if consecutive_empty_cols:
                    break
    
    if consecutive_empty_cols:
        logger.debug(f"Found {len(consecutive_empty_cols)} consecutive empty data columns: {consecutive_empty_cols}")
        # Return a special marker that we need to remove specific columns, not leading ones
        # We'll handle this differently in rows_to_df
        return -len(consecutive_empty_cols)  # Negative value indicates non-leading columns to remove
    
    # If header is much shorter, check how many leading columns are empty in data rows
    if first_row_len < avg_data_len - 1:
        # Check consecutive leading empty columns in data rows
        max_leading_empty = 0
        for col_idx in range(min(5, len(data_rows[0]) if data_rows else 0)):
            leading_empty_count = sum(1 for r in data_rows if r and len(r) > col_idx and is_blank(r[col_idx]))
            if leading_empty_count > len(data_rows) * 0.7:
                max_leading_empty = col_idx + 1
            else:
                break
        
        if max_leading_empty > 0:
            logger.debug(f"Header shorter than data, found {max_leading_empty} leading empty columns")
            return max_leading_empty
    
    return 0


def rows_to_df(rows):
    # Trim trailing blanks per row to avoid wide None-padded tables
    # Ensure rows is iterable (handle case where it might be a method)
    if rows is None:
        rows = []
    elif callable(rows) and not isinstance(rows, (list, tuple, dict)):
        # If rows is a method, call it
        try:
            rows = rows()
        except Exception:
            rows = []
    elif not isinstance(rows, (list, tuple)):
        # Try to convert to list if it's iterable but not a list/tuple
        try:
            rows = list(rows) if rows else []
        except (TypeError, ValueError):
            rows = []
    
    if not rows:
        return pd.DataFrame()
    
    # Convert all rows to lists and analyze structure
    list_rows = []
    for row in rows:
        if isinstance(row, (list, tuple)):
            list_rows.append(list(row))
        else:
            try:
                list_rows.append(list(row))
            except (TypeError, ValueError):
                list_rows.append([row])
    
    if not list_rows:
        return pd.DataFrame()
    
    # DEBUG: Log row structure to detect alignment issues (only warnings for issues)
    import logging
    logger = logging.getLogger(__name__)
    if len(list_rows) > 0:
        row_lengths = [len(r) for r in list_rows]
        if len(set(row_lengths)) > 1:
            logger.warning(f"⚠️  rows_to_df - Inconsistent row lengths detected! Min: {min(row_lengths)}, Max: {max(row_lengths)}")
    
    # Detect and fix column alignment issues
    alignment_shift = detect_column_alignment_issue(list_rows)
    
    if alignment_shift > 0:
        # Positive value: remove leading columns
        logger.warning(f"⚠️  Removing {alignment_shift} leading column(s) to fix alignment")
        # Apply the fix - remove leading columns
        list_rows = [r[alignment_shift:] if len(r) > alignment_shift else r for r in list_rows]
    elif alignment_shift < 0:
        # Negative value: remove specific empty columns (not leading ones)
        num_empty_cols = -alignment_shift
        # Find which columns are empty (starting from column 2)
        empty_col_indices = []
        if len(list_rows) > 1:
            data_rows = list_rows[1:min(10, len(list_rows))]
            for col_idx in range(2, min(15, len(list_rows[0]) if list_rows else 0)):
                empty_count = sum(1 for r in data_rows if r and len(r) > col_idx and is_blank(r[col_idx]))
                if empty_count > len(data_rows) * 0.7:
                    empty_col_indices.append(col_idx)
                elif empty_col_indices:
                    break  # Stop if we found consecutive empty columns
        
        if empty_col_indices:
            logger.warning(f"⚠️  Removing {len(empty_col_indices)} empty data columns (columns {empty_col_indices})")
            # Apply the fix - remove specific columns (in reverse order to maintain indices)
            for col_idx in reversed(empty_col_indices):
                list_rows = [r[:col_idx] + r[col_idx+1:] if len(r) > col_idx else r for r in list_rows]
    
    # Also check for leading empty cells that might cause misalignment
    # If most rows start with empty cells, we might need to trim them
    leading_empty_count = 0
    total_rows_checked = min(10, len(list_rows))
    for row in list_rows[:total_rows_checked]:
        if row and is_blank(row[0]):
            leading_empty_count += 1
    
    # If most rows start with empty cells, trim them (likely a formatting issue)
    # But only if we haven't already trimmed for alignment
    if alignment_shift == 0:
        trim_leading = leading_empty_count > total_rows_checked * 0.7 and total_rows_checked > 0
        if trim_leading:
            logger.warning(f"⚠️  rows_to_df - Detected leading empty cells in {leading_empty_count}/{total_rows_checked} rows, trimming them")
            list_rows = [r[1:] if r and is_blank(r[0]) else r for r in list_rows]
    
    # Trim trailing blanks per row
    trimmed_rows = []
    max_len = 0
    for row in list_rows:
        r = list(row)
        # Trim trailing blanks
        while r and is_blank(r[-1]):
            r.pop()
        max_len = max(max_len, len(r))
        trimmed_rows.append(r)
    
    if not trimmed_rows:
        return pd.DataFrame()
    
    # Pad rows back to the max length (rectangular for DataFrame)
    # CRITICAL: Ensure all rows are aligned to the same length
    normalized_rows = []
    for r in trimmed_rows:
        # Pad with None to match max_len
        padded = r + [None] * (max_len - len(r))
        normalized_rows.append(padded)
    
    # Additional check: if first row is significantly shorter, it might be a header issue
    if len(normalized_rows) > 1:
        first_row_len = len([c for c in normalized_rows[0] if not is_blank(c)])
        avg_data_row_len = sum(len([c for c in r if not is_blank(c)]) for r in normalized_rows[1:5]) / min(4, len(normalized_rows) - 1)
        if first_row_len < avg_data_row_len * 0.7:
            logger.warning(f"⚠️  rows_to_df - First row ({first_row_len} cells) is much shorter than data rows ({avg_data_row_len:.1f} avg), possible header misalignment")
    
    df = pd.DataFrame(normalized_rows).reset_index(drop=True)
    
    # Drop empty rows
    df = df.loc[~df.apply(lambda r: all(is_blank(v) for v in r), axis=1)]
    
    # Drop empty columns (but be careful - this might cause misalignment if done incorrectly)
    # Only drop columns that are completely empty (all None/empty strings)
    non_empty_cols = []
    for col_idx in range(df.shape[1]):
        col = df.iloc[:, col_idx]
        if not all(is_blank(v) for v in col):
            non_empty_cols.append(col_idx)
    
    if len(non_empty_cols) < df.shape[1]:
        logger.debug(f"🔍 rows_to_df - Dropping {df.shape[1] - len(non_empty_cols)} empty columns")
        df = df.iloc[:, non_empty_cols]
    
    # Trim strings
    df = df.map(lambda v: v.strip() if isinstance(v, str) else v)
    df.reset_index(drop=True, inplace=True)
    
    return df


def split_rows_into_blocks(rows):
    """
    Split a flattened table into logical blocks so merged tables (like a whole sheet)
    are separated when a new block starts with an empty leading cell (common for
    Excel regions where the top-left is blank) or on fully blank rows.
    """
    blocks = []
    current = []
    for row in rows or []:
        if row is None:
            continue
        r = list(row)
        if all(is_blank(v) for v in r):
            if current:
                blocks.append(current)
                current = []
            continue
        starts_new_block = is_blank(r[0]) and any(not is_blank(v) for v in r[1:])
        if starts_new_block and current:
            blocks.append(current)
            current = []
        current.append(r)
    if current:
        blocks.append(current)
    return blocks


def merge_header_body_blocks(blocks, min_header_width=5, max_header_rows=2, min_body_rows=3):
    """
    Merge runs of short header-like blocks into the following body block when
    they likely belong to the same wide table (e.g., multi-row headers such as
    Gantt week labels).
    """
    merged = []
    i = 0

    def block_width(block):
        width = 0
        for r in block or []:
            if r is None:
                continue
            width = max(width, len(r))
        return width

    while i < len(blocks):
        header_blocks = []
        header_width = 0
        start_i = i

        # Gather consecutive short blocks as potential headers
        while i < len(blocks) and len(blocks[i]) <= max_header_rows:
            header_blocks.append(blocks[i])
            header_width = max(header_width, block_width(blocks[i]))
            i += 1

        has_body = i < len(blocks) and len(blocks[i]) >= min_body_rows
        should_merge = (
            header_blocks
            and has_body
            and header_width >= min_header_width  # avoid merging narrow mini-tables (e.g., small assumptions)
        )

        if should_merge:
            combined = []
            for hb in header_blocks:
                combined.extend(hb)
            combined.extend(blocks[i])  # body
            merged.append(combined)
            i += 1  # move past body
        else:
            if header_blocks:
                merged.extend(header_blocks)
            else:
                merged.append(blocks[i])
                i += 1

    return merged


def docs_to_dataframes(docs) -> Tuple[Dict[str, pd.DataFrame], int]:
    """
    Convert parsed LlamaParse docs into a dict of pandas DataFrames.

    Returns:
        dataframes (dict): key -> DataFrame for each table/sub-table
        table_count (int): total number of tables found
    """
    dataframes = {}
    table_count = 0
    pages = extract_pages(docs)

    for p_idx, page in enumerate(pages, start=1):
        tables = getattr(page, "tables", None) or (page.get("tables") if isinstance(page, dict) else [])
        item_tables = [
            it
            for it in (getattr(page, "items", None) or (page.get("items") if isinstance(page, dict) else []) or [])
            if (getattr(it, "type", None) or (isinstance(it, dict) and it.get("type"))) == "table"
        ]

        # Prefer the richest source: explicit tables and table-items.
        table_idx = 1
        for tbl in tables:
            rows = get_table_rows(tbl)
            # Keep a full view without block splitting (preserves context if needed)
            dataframes[f"page{p_idx}_table{table_idx}_full"] = rows_to_df(rows)
            table_count += 1

            blocks = split_rows_into_blocks(rows)
            blocks = merge_header_body_blocks(blocks)
            for block_idx, block in enumerate(blocks, start=1):
                df = rows_to_df(block)
                key = (
                    f"page{p_idx}_table{table_idx}"
                    if len(blocks) == 1
                    else f"page{p_idx}_table{table_idx}_part{block_idx}"
                )
                dataframes[key] = df
                table_count += 1
            table_idx += 1

        for tbl in item_tables:
            rows = get_table_rows(tbl)
            # Keep a full view without block splitting (preserves context if needed)
            dataframes[f"page{p_idx}_itemtable{table_idx}_full"] = rows_to_df(rows)
            table_count += 1

            blocks = split_rows_into_blocks(rows)
            blocks = merge_header_body_blocks(blocks)
            for block_idx, block in enumerate(blocks, start=1):
                df = rows_to_df(block)
                key = (
                    f"page{p_idx}_itemtable{table_idx}"
                    if len(blocks) == 1
                    else f"page{p_idx}_itemtable{table_idx}_part{block_idx}"
                )
                dataframes[key] = df
                table_count += 1
            table_idx += 1

        # Sub-tables are usually cropped regions; keep them as well, but note they may lose edge columns.
        sub_tables = getattr(page, "subTables", None) or (page.get("subTables") if isinstance(page, dict) else [])
        for st_idx, st in enumerate(sub_tables, start=1):
            df = rows_to_df(get_table_rows(st))
            key = f"page{p_idx}_subtable{st_idx}"
            dataframes[key] = df
            table_count += 1

    return dataframes, table_count


def get_obj_attr(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def docs_to_markdown(docs) -> Dict[str, str]:
    """
    Collect Markdown per page/sheet. Prefer page-level markdown, but fall back to
    item/table markdown if the page doesn't provide any.
    """
    markdown_by_page = {}
    pages = extract_pages(docs)

    for p_idx, page in enumerate(pages, start=1):
        chunks = []
        page_md = get_obj_attr(page, "md")
        if page_md:
            chunks.append(page_md)
        else:
            items = get_obj_attr(page, "items") or []
            for item in items:
                item_md = get_obj_attr(item, "md")
                if item_md:
                    chunks.append(item_md)
            tables = get_obj_attr(page, "tables") or []
            for table in tables:
                table_md = get_obj_attr(table, "md")
                if table_md:
                    chunks.append(table_md)

        markdown_by_page[f"page{p_idx}_markdown"] = "\n\n".join(chunks)

    return markdown_by_page


def docs_to_outputs(docs):
    dataframes, table_count = docs_to_dataframes(docs)
    markdown_by_page = docs_to_markdown(docs)
    return dataframes, table_count, markdown_by_page


def get_page_name(page, fallback=None):
    name_fields = [
        "sheetName",
        "sheet_name",
        "worksheetName",
        "worksheet",
        "pageName",
        "page_name",
        "name",
        "title",
        "label",
        "pageLabel",
    ]
    for field in name_fields:
        value = get_obj_attr(page, field)
        if isinstance(value, str) and value.strip():
            return value.strip()
    structured = get_obj_attr(page, "structuredData")
    if isinstance(structured, dict):
        for field in name_fields:
            value = structured.get(field)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return fallback


def docs_to_page_names(docs) -> Dict[str, str]:
    page_names = {}
    pages = extract_pages(docs)
    for p_idx, page in enumerate(pages, start=1):
        page_key = f"page{p_idx}"
        page_names[page_key] = get_page_name(page, fallback=page_key)
    return page_names


def docs_to_outputs_with_page_names(docs):
    dataframes, table_count = docs_to_dataframes(docs)
    markdown_by_page = docs_to_markdown(docs)
    page_names = docs_to_page_names(docs)
    return dataframes, table_count, markdown_by_page, page_names


def format_key_with_sheet_name(key, page_names):
    match = re.match(r"^(page\d+)_", key)
    if not match:
        return key
    page_key = match.group(1)
    sheet_name = page_names.get(page_key)
    if not sheet_name:
        return key
    suffix = key[len(page_key) + 1 :]
    return f"{sheet_name}_{suffix}"


def rename_keys_with_sheet_name(table_map, page_names):
    renamed = {}
    for key, value in table_map.items():
        renamed_key = format_key_with_sheet_name(key, page_names)
        renamed[renamed_key] = value
    return renamed


MONTH_NAMES = {
    "january",
    "february",
    "march",
    "april",
    "may",
    "june",
    "july",
    "august",
    "september",
    "october",
    "november",
    "december",
}


def is_numeric_string(text: str) -> bool:
    if text is None:
        return False
    s = text.strip()
    if not s:
        return False
    s = s.replace(",", "")
    if s.endswith("%"):
        s = s[:-1]
    try:
        float(s)
        return True
    except ValueError:
        return False


def is_text_cell(val) -> bool:
    if not isinstance(val, str):
        return False
    s = val.strip()
    if not s:
        return False
    return not is_numeric_string(s)


def contains_month(val) -> bool:
    if not isinstance(val, str):
        return False
    s = val.strip().lower()
    return s in MONTH_NAMES


def is_metadata_row(row) -> bool:
    non_blank = [v for v in row if not is_blank(v)]
    return len(non_blank) == 1


def is_header_candidate(row) -> bool:
    non_blank = [v for v in row if not is_blank(v)]
    if len(non_blank) < 2:
        return False
    text_count = sum(is_text_cell(v) for v in non_blank)
    if text_count / len(non_blank) >= 0.6:
        return True
    if any(contains_month(v) for v in non_blank):
        return True
    header_keywords = {"account", "number", "name", "currency", "area"}
    if any(isinstance(v, str) and v.strip().lower() in header_keywords for v in non_blank):
        return True
    return False


def detect_header_rows(df, max_scan=8, max_header_rows=3):
    metadata_rows = []
    header_rows = []
    for i in range(min(max_scan, len(df))):
        row = df.iloc[i].tolist()
        if not header_rows and is_metadata_row(row):
            metadata_rows.append(i)
            continue
        if is_header_candidate(row):
            header_rows.append(i)
            if len(header_rows) >= max_header_rows:
                break
        elif header_rows:
            break
    return metadata_rows, header_rows


def combine_header_rows(df, header_rows, sep=" "):
    if not header_rows:
        return None
    width = df.shape[1]
    headers = []
    for col in range(width):
        parts = []
        for r in header_rows:
            val = df.iloc[r, col]
            if not is_blank(val):
                parts.append(str(val).strip())
        header = sep.join(parts).strip()
        headers.append(header if header else None)
    return headers


def normalize_headers(headers):
    if headers is None:
        return None
    cleaned = []
    seen = {}
    for idx, h in enumerate(headers):
        if h is None:
            h = f"col_{idx}"
        else:
            h = re.sub(r"\s+", " ", str(h)).strip()
            if not h:
                h = f"col_{idx}"
        if h in seen:
            seen[h] += 1
            h = f"{h}_{seen[h]}"
        else:
            seen[h] = 0
        cleaned.append(h)
    return cleaned


def normalize_text(val) -> str:
    if val is None:
        return ""
    s = str(val).strip().lower()
    return re.sub(r"\s+", " ", s)


def header_token_set(headers):
    tokens = set()
    for h in headers or []:
        s = normalize_text(h)
        if not s:
            continue
        tokens.add(s)
        for token in s.split(" "):
            tokens.add(token)
    return tokens


def looks_like_header_row(row, headers) -> bool:
    tokens = [normalize_text(v) for v in row if isinstance(v, str) and v.strip()]
    if not tokens:
        return False
    header_tokens = header_token_set(headers)
    matches = sum(1 for t in tokens if t in header_tokens)
    return matches / len(tokens) >= 0.6


def pad_integer_columns(df, target_width=None):
    import logging
    logger = logging.getLogger(__name__)
    
    df = df.copy().reset_index(drop=True)
    
    cols = list(df.columns)
    if cols and all(isinstance(c, int) for c in cols):
        max_col = max(cols)
        width = max(max_col + 1, target_width or 0)
        
        try:
            result = df.reindex(columns=list(range(width)))
            return result
        except Exception as e:
            logger.error(f"❌ ERROR in pad_integer_columns df.reindex(columns=...): {e}")
            logger.error(f"❌ df shape: {df.shape}, df index: {df.index.tolist()}")
            import traceback
            logger.error(traceback.format_exc())
            raise
            
    if target_width is not None and df.shape[1] < target_width:
        for i in range(df.shape[1], target_width):
            df[i] = None
    return df


def align_df_to_headers(df, headers):
    df = df.copy().reset_index(drop=True)
    if headers is None:
        return df
    df = pad_integer_columns(df, target_width=len(headers))
    if df.shape[1] > len(headers):
        extra = [f"extra_{i}" for i in range(df.shape[1] - len(headers))]
        headers = headers + extra
    
    # Make headers unique to avoid "Length mismatch" error
    # This happens when headers list has duplicate names
    import logging
    import pandas as pd
    logger = logging.getLogger(__name__)
    
    
    # ALWAYS make headers unique to prevent concat errors
    unique_headers = []
    seen = {}
    for h in headers:
        if h in seen:
            seen[h] += 1
            unique_name = f"{h}_{seen[h]}"
            unique_headers.append(unique_name)
        else:
            seen[h] = 0
            unique_headers.append(h)
    
    # Check if we had to make any unique and log it
    if unique_headers != headers:
        headers_series = pd.Series(headers)
        duplicates = headers_series[headers_series.duplicated()].unique()
        logger.warning(f"⚠️  align_df_to_headers - Found duplicate headers: {duplicates.tolist()}, made unique")
        logger.debug(f"align_df_to_headers - made headers unique: {unique_headers[:20] if len(unique_headers) > 20 else unique_headers}")
    
    # ALWAYS use unique_headers (moved assignment outside if block)
    df.columns = unique_headers
    return df


def strip_leading_metadata_rows(df, max_rows=5):
    df = df.copy().reset_index(drop=True)
    drop_count = 0
    for i in range(min(max_rows, len(df))):
        row = df.iloc[i].tolist()
        if is_metadata_row(row):
            drop_count += 1
        else:
            break
    if drop_count:
        df = df.iloc[drop_count:].reset_index(drop=True)
    return df


def apply_headers_to_df(df, headers, drop_metadata=True, drop_header_row=True):
    df = df.copy().reset_index(drop=True)
    if drop_metadata:
        df = strip_leading_metadata_rows(df)
    if headers is None:
        return df
    df = pad_integer_columns(df, target_width=len(headers))
    if drop_header_row and len(df) > 0:
        first_row = df.iloc[0].tolist()
        if looks_like_header_row(first_row, headers):
            df = df.iloc[1:].reset_index(drop=True)
    df = align_df_to_headers(df, headers)
    df.reset_index(drop=True, inplace=True)
    return df


def stringify_nans(df):
    return df.where(pd.notna(df), "nan")


def extract_metadata_rows(df, metadata_rows):
    metadata = []
    for idx in metadata_rows or []:
        row = df.iloc[idx].tolist()
        text = " ".join(str(v).strip() for v in row if not is_blank(v))
        if text:
            metadata.append(text)
    return metadata


def sort_itemtable_keys(keys):
    def part_num(k):
        m = re.search(r"_part(\d+)$", k)
        return int(m.group(1)) if m else 0
    return sorted(keys, key=part_num)


def group_itemtable_keys(dataframes):
    groups = {}
    for key in dataframes.keys():
        if "_itemtable" not in key:
            continue
        if key.endswith("_full"):
            base = key[:-5]
        elif "_part" in key:
            base = key.split("_part")[0]
        else:
            base = key
        groups.setdefault(base, []).append(key)
    return groups


def clean_itemtables(dataframes, max_header_rows=3, add_sections=False):
    cleaned = {}
    header_map = {}
    metadata_map = {}

    groups = group_itemtable_keys(dataframes)
    for base, keys in groups.items():
        full_df = dataframes.get(f"{base}_full")
        headers = None
        metadata = []

        if full_df is not None:
            metadata_rows, header_rows = detect_header_rows(full_df, max_header_rows=max_header_rows)
            headers = normalize_headers(combine_header_rows(full_df, header_rows))
            metadata = extract_metadata_rows(full_df, metadata_rows)

        if headers is None:
            for key in sort_itemtable_keys(keys):
                if key.endswith("_full"):
                    continue
                df = dataframes[key]
                _, header_rows = detect_header_rows(df, max_header_rows=max_header_rows)
                if header_rows:
                    headers = normalize_headers(combine_header_rows(df, header_rows))
                    break

        header_map[base] = headers
        if metadata:
            metadata_map[base] = metadata

        cleaned_parts = []
        for key in sort_itemtable_keys(keys):
            if key.endswith("_full"):
                continue
            df = dataframes[key]
            df = apply_headers_to_df(df, headers, drop_metadata=True, drop_header_row=True)
            if add_sections:
                df = add_section_column(df)
            df = stringify_nans(df)
            # Ensure clean indices before adding to list
            df = df.reset_index(drop=True)
            cleaned_key = f"{key}_clean"
            cleaned[cleaned_key] = df
            cleaned_parts.append(df)

        if cleaned_parts:
            import logging
            logger = logging.getLogger(__name__)
            # Double-check all DataFrames have clean indices before concat
            for i, df_part in enumerate(cleaned_parts):
                # Force reset to be absolutely sure - create a completely new DataFrame if needed
                if df_part.index.duplicated().any() or not isinstance(df_part.index, pd.RangeIndex):
                    logger.warning(f"⚠️  cleaned_parts[{i}] has non-standard or duplicate index, creating fresh DataFrame")
                    cleaned_parts[i] = pd.DataFrame(df_part.values, columns=df_part.columns)
                else:
                    cleaned_parts[i] = df_part.reset_index(drop=True)
            
            try:
                combined = pd.concat(cleaned_parts, ignore_index=True)
                combined = stringify_nans(combined)
                cleaned[f"{base}_combined_clean"] = combined
            except Exception as e:
                logger.error(f"❌ ERROR during pd.concat in _clean_tables: {e}")
                for i, df_part in enumerate(cleaned_parts):
                    logger.error(f"❌ cleaned_parts[{i}] - shape: {df_part.shape}, index: {df_part.index.tolist()}, columns: {df_part.columns.tolist()}")
                raise

    return cleaned, header_map, metadata_map


def is_section_row(row, label_col=1) -> bool:
    if label_col >= len(row):
        return False
    non_blank = [i for i, v in enumerate(row) if not is_blank(v)]
    if len(non_blank) != 1 or non_blank[0] != label_col:
        return False
    val = row[label_col]
    if not isinstance(val, str):
        return False
    text = val.strip()
    if not text:
        return False
    return text.upper() == text


def add_section_column(df, section_col="section", label_col=1):
    df = df.copy().reset_index(drop=True)
    current_section = None
    sections = []
    for _, row in df.iterrows():
        row_vals = row.tolist()
        if is_section_row(row_vals, label_col=label_col):
            current_section = str(row_vals[label_col]).strip()
        sections.append(current_section)
    df.insert(0, section_col, sections)
    return df


DEFAULT_LLM_MODEL = os.getenv("LLM_TABLE_MODEL", "gpt-4o")
DEFAULT_LLM_PROVIDER = os.getenv("LLM_PROVIDER", "").strip().lower()


def cell_to_primitive(val):
    if pd.isna(val):
        return None
    if isinstance(val, (np.generic,)):
        return val.item()
    return val


def df_to_llm_payload(df, max_rows=50, max_cols=50):
    """
    Convert DataFrame to LLM payload format.
    
    Args:
        df: Input DataFrame
        max_rows: Maximum number of rows to include in preview (default: 50)
        max_cols: Maximum number of columns to include in preview (default: 50)
    
    Returns:
        dict with:
            - shape: Full DataFrame shape [rows, cols]
            - preview_shape: Preview shape [rows, cols] 
            - rows: Preview data (limited to max_rows x max_cols)
    """
    import logging
    logger = logging.getLogger(__name__)
    
    full_shape = [int(df.shape[0]), int(df.shape[1])]
    
    if full_shape[1] > max_cols:
        logger.warning(f"⚠️  DataFrame has {full_shape[1]} columns but only {max_cols} will be sent to LLM!")
    
    preview = df.iloc[:max_rows, :max_cols].copy().reset_index(drop=True)
    preview = preview.map(cell_to_primitive)
    rows = preview.values.tolist()
    
    preview_shape = [len(rows), len(rows[0]) if rows else 0]
    
    return {
        "shape": full_shape,
        "preview_shape": preview_shape,
        "rows": rows,
    }


def build_table_prompt(table_name, payload, master_header=None):
    prompt = {
        "task": "table_cleanup",
        "table_name": table_name,
        "instructions": [
            "Identify and remove metadata/title rows and header rows.",
            "If headers are split across multiple rows, combine into one header string per column.",
            "If no explicit header exists, decide whether to use master_header.",
            "Return JSON only. No extra text.",
        ],
        "expected_json": {
            "drop_rows": "list[int] rows to drop from the provided rows",
            "header": "list[str] final header list if table has its own header, else null",
            "use_master_header": "bool (true if table should use master_header)",
            "column_mapping": "optional mapping of column index -> master header name",
            "metadata": "optional list of metadata strings extracted from dropped rows",
            "notes": "optional string",
        },
        "master_header": master_header,
        "table_preview": payload,
    }
    return json.dumps(prompt, ensure_ascii=True)


def extract_json_from_text(text):
    if not isinstance(text, str):
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    match = re.search(r"(\{.*\}|\[.*\])", text, re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(1))
    except json.JSONDecodeError:
        return None


def coerce_llm_json(result):
    if result is None:
        return None
    if isinstance(result, dict):
        return result
    if isinstance(result, list):
        for item in result:
            payload = coerce_llm_json(item)
            if payload is not None:
                return payload
        return None
    if isinstance(result, str):
        return extract_json_from_text(result)
    if hasattr(result, "model_dump"):
        return coerce_llm_json(result.model_dump())
    if hasattr(result, "dict"):
        return coerce_llm_json(result.dict())
    if hasattr(result, "json"):
        try:
            return extract_json_from_text(result.json())
        except Exception:
            return None
    return None


def build_llm_kwargs(method, prompt):
    try:
        sig = inspect.signature(method)
    except (TypeError, ValueError):
        return None
    params = sig.parameters
    kwargs = {}
    if "prompt" in params:
        kwargs["prompt"] = prompt
    elif "text" in params:
        kwargs["text"] = prompt
    elif "input" in params:
        kwargs["input"] = prompt
    elif "messages" in params:
        kwargs["messages"] = [{"role": "user", "content": prompt}]
    else:
        return None
    if "response_format" in params:
        kwargs["response_format"] = "json"
    if "output_format" in params:
        kwargs["output_format"] = "json"
    if "format" in params:
        kwargs["format"] = "json"
    if "response_mime_type" in params:
        kwargs["response_mime_type"] = "application/json"
    if "temperature" in params:
        kwargs["temperature"] = 0
    return kwargs


def call_llamaextract_json(prompt, model=DEFAULT_LLM_MODEL):
    try:
        from llama_cloud_services import LlamaExtract
    except Exception as exc:
        return None, f"LlamaExtract unavailable: {exc}"

    try:
        extractor = LlamaExtract(model=model)
    except TypeError:
        extractor = LlamaExtract()

    for method_name in ("extract", "predict", "run", "complete", "__call__"):
        if not hasattr(extractor, method_name):
            continue
        method = getattr(extractor, method_name)
        kwargs = build_llm_kwargs(method, prompt)
        try:
            if kwargs is None:
                result = method(prompt)
            else:
                result = method(**kwargs)
        except TypeError:
            continue
        payload = coerce_llm_json(result)
        if payload is not None:
            return payload, None
    return None, "No compatible LlamaExtract method found"


def call_openai_json(prompt, model=DEFAULT_LLM_MODEL):
    try:
        from openai import OpenAI
    except Exception as exc:
        return None, f"OpenAI unavailable: {exc}"

    try:
        client = OpenAI()
    except Exception as exc:
        return None, f"OpenAI client init failed: {exc}"

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            response_format={"type": "json_object"},
        )
    except Exception as exc:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
            )
        except Exception as exc2:
            return None, f"OpenAI request failed: {exc}; fallback failed: {exc2}"

    try:
        content = response.choices[0].message.content
    except Exception:
        content = None
    payload = coerce_llm_json(content)
    if payload is not None:
        return payload, None
    return None, "OpenAI returned non-JSON response"


def call_llm_json(prompt, model=DEFAULT_LLM_MODEL, provider=None):
    provider_name = (provider or DEFAULT_LLM_PROVIDER).strip().lower()
    if provider_name in ("openai", "oai"):
        return call_openai_json(prompt, model=model)
    if provider_name in ("llama", "llamaextract", "llama_cloud"):
        return call_llamaextract_json(prompt, model=model)

    payload, error = call_llamaextract_json(prompt, model=model)
    if payload is not None:
        return payload, None
    payload2, error2 = call_openai_json(prompt, model=model)
    if payload2 is not None:
        return payload2, None
    if error and error2:
        return None, f"LlamaExtract failed: {error}; OpenAI failed: {error2}"
    return None, error or error2 or "No LLM provider available"


def coerce_int_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        out = []
        for v in value:
            try:
                out.append(int(v))
            except (TypeError, ValueError):
                continue
        return out
    return []


def normalize_llm_spec(spec):
    if not isinstance(spec, dict):
        return None
    cleaned = dict(spec)
    cleaned["drop_rows"] = coerce_int_list(spec.get("drop_rows"))
    if "use_master_header" in cleaned:
        cleaned["use_master_header"] = bool(cleaned["use_master_header"])
    header = spec.get("header")
    if header is not None and not isinstance(header, list):
        header = None
    cleaned["header"] = header
    mapping = spec.get("column_mapping")
    if mapping is not None and not isinstance(mapping, dict):
        mapping = None
    cleaned["column_mapping"] = mapping
    metadata = spec.get("metadata")
    if metadata is not None and not isinstance(metadata, list):
        metadata = None
    cleaned["metadata"] = metadata
    return cleaned


def make_columns_unique(columns):
    """
    Make a list of column names unique by appending _1, _2, etc. to duplicates.
    
    Args:
        columns: List of column names (may contain duplicates)
    
    Returns:
        List of unique column names
    """
    unique_headers = []
    seen = {}
    for h in columns:
        if h in seen:
            seen[h] += 1
            unique_name = f"{h}_{seen[h]}"
            unique_headers.append(unique_name)
        else:
            seen[h] = 0
            unique_headers.append(h)
    return unique_headers


def apply_column_mapping(df, master_headers, column_mapping=None):
    df = df.copy().reset_index(drop=True)
    df = pad_integer_columns(df, target_width=len(master_headers))
    if column_mapping:
        rename_map = {}
        for key, header in column_mapping.items():
            try:
                idx = int(key)
            except (TypeError, ValueError):
                continue
            if 0 <= idx < df.shape[1] and header in master_headers:
                rename_map[idx] = header
        if rename_map:
            df = df.rename(columns=rename_map)
    # Add debug logging
    import logging
    import pandas as pd
    logger = logging.getLogger(__name__)
    
    cols = list(df.columns)
    if all(isinstance(c, int) for c in cols):
        headers_to_assign = master_headers[: df.shape[1]]
        
        # If DataFrame has more columns than headers, pad with extra_N
        if df.shape[1] > len(headers_to_assign):
            extra = [f"extra_{i}" for i in range(len(headers_to_assign), df.shape[1])]
            headers_to_assign = headers_to_assign + extra
        
        # ALWAYS make headers unique to prevent concat errors
        unique_headers = make_columns_unique(headers_to_assign)
        
        # Check if we had to make any unique and log it
        if unique_headers != headers_to_assign:
            headers_series = pd.Series(headers_to_assign)
            duplicates = headers_series[headers_series.duplicated()].unique()
            logger.warning(f"⚠️  apply_column_mapping - Found duplicate headers: {duplicates.tolist()}, made unique")
            logger.debug(f"apply_column_mapping - made headers unique: {unique_headers[:20] if len(unique_headers) > 20 else unique_headers}")
        
        # ALWAYS use unique_headers (moved assignment outside if block)
        df.columns = unique_headers
        
        # Build reindex order using unique_headers instead of master_headers to avoid duplicates
        # Separate the columns that came from master_headers vs extras
        master_cols = unique_headers[:len(master_headers)]  # The unique versions of master_headers
        extra_cols = unique_headers[len(master_headers):]    # Any extra columns beyond master_headers
        
        try:
            # Reindex using the unique column names we just assigned
            df = df.reindex(columns=master_cols + extra_cols)
        except Exception as e:
            logger.error(f"❌ ERROR in apply_column_mapping df.reindex(columns=...): {e}")
            logger.error(f"❌ df shape: {df.shape}, columns: {df.columns.tolist()[:20]}")
            logger.error(f"❌ df index: {df.index.tolist()}")
            import traceback
            logger.error(traceback.format_exc())
            raise
    else:
        # Columns already have names, just reorder to put master_headers first
        # CRITICAL FIX: Ensure master_headers are unique first, then handle remaining columns
        unique_master_headers = make_columns_unique(master_headers) if master_headers else []
        remaining = [c for c in df.columns if c not in unique_master_headers]
        
        # Combine and ensure the final column list is unique
        all_columns = unique_master_headers + remaining
        final_columns = make_columns_unique(all_columns)
        
        # Check for duplicates in current columns and fix them
        if df.columns.duplicated().any():
            logger.warning(f"⚠️  apply_column_mapping - DataFrame already has duplicate columns, fixing them")
            df.columns = make_columns_unique(df.columns.tolist())
        
        try:
            # Reindex to the final unique column order
            df = df.reindex(columns=final_columns)
        except Exception as e:
            logger.error(f"❌ ERROR in apply_column_mapping df.reindex(columns=...): {e}")
            logger.error(f"❌ df shape: {df.shape}, columns: {df.columns.tolist()[:20]}")
            import traceback
            logger.error(traceback.format_exc())
            raise
    
    # Final safety check: ensure columns are unique before returning
    if df.columns.duplicated().any():
        logger.warning(f"⚠️  apply_column_mapping - Final safety check: found duplicates, fixing")
        df.columns = make_columns_unique(df.columns.tolist())
    
    return df


def apply_llm_spec(df, spec, master_headers=None):
    if spec is None:
        return df
    df = df.copy().reset_index(drop=True)
    drop_rows = spec.get("drop_rows") or []
    drop_rows = [r for r in drop_rows if 0 <= r < len(df)]
    if drop_rows:
        df = df.drop(index=drop_rows).reset_index(drop=True)
    if spec.get("use_master_header") and master_headers:
        df = apply_column_mapping(df, master_headers, spec.get("column_mapping"))
        return df
    header = spec.get("header")
    if header:
        header = normalize_headers(header)
        df = align_df_to_headers(df, header)
    return df


def infer_table_spec_llm(
    df,
    table_name,
    master_headers=None,
    max_rows=50,
    max_cols=50,
    model=DEFAULT_LLM_MODEL,
):
    payload = df_to_llm_payload(df, max_rows=max_rows, max_cols=max_cols)
    prompt = build_table_prompt(table_name, payload, master_header=master_headers)
    spec, error = call_llm_json(prompt, model=model)
    if spec is None:
        return None, error
    return normalize_llm_spec(spec), None


def normalize_header_for_comparison(header_list):
    """
    Normalize headers for comparison by converting to lowercase and removing extra whitespace.
    Returns a tuple of normalized headers for use as a dictionary key.
    """
    if not header_list:
        return None
    normalized = []
    for h in header_list:
        if h is None:
            normalized.append("")
        else:
            # Convert to lowercase, collapse whitespace, strip
            norm = re.sub(r"\s+", " ", str(h).strip().lower())
            normalized.append(norm)
    return tuple(normalized)


def headers_match(headers1, headers2, min_overlap=0.8):
    """
    Check if two header lists match sufficiently.
    
    Args:
        headers1: First header list
        headers2: Second header list
        min_overlap: Minimum ratio of matching headers (default 0.8 = 80%)
    
    Returns:
        bool: True if headers match sufficiently
    """
    if not headers1 or not headers2:
        return False
    
    norm1 = normalize_header_for_comparison(headers1)
    norm2 = normalize_header_for_comparison(headers2)
    
    if norm1 == norm2:
        return True
    
    # Check for partial overlap (handles cases where tables have slightly different column counts)
    min_len = min(len(norm1), len(norm2))
    if min_len == 0:
        return False
    
    matches = sum(1 for i in range(min_len) if norm1[i] == norm2[i])
    return (matches / min_len) >= min_overlap


def concatenate_tables_by_headers(cleaned_tables, header_map, exclude_pattern=None):
    """
    Concatenate tables across different bases that have matching headers.
    
    Args:
        cleaned_tables: Dict of cleaned table DataFrames
        header_map: Dict mapping base names to their headers
        exclude_pattern: Optional regex pattern to exclude certain keys from cross-table concatenation
    
    Returns:
        Dict with additional concatenated tables under synthetic keys like "merged_group_1"
    """
    # Group tables by their normalized headers
    header_groups = {}
    
    for base, headers in header_map.items():
        if not headers:
            continue
            
        # Skip if matches exclude pattern
        if exclude_pattern and re.search(exclude_pattern, base):
            continue
        
        norm_headers = normalize_header_for_comparison(headers)
        if norm_headers:
            header_groups.setdefault(norm_headers, []).append(base)
    
    # Only concatenate groups that have multiple tables
    result = {}
    group_id = 1
    
    for norm_headers, bases in header_groups.items():
        if len(bases) < 2:
            continue
        
        # Collect all cleaned tables for these bases
        tables_to_merge = []
        
        for base in sorted(bases):
            # Look for the combined_clean_llm version first
            combined_key = f"{base}_combined_clean_llm"
            if combined_key in cleaned_tables:
                tables_to_merge.append(cleaned_tables[combined_key])
            else:
                # Look for individual cleaned parts
                for key, df in cleaned_tables.items():
                    if key.startswith(f"{base}_") and key.endswith("_clean_llm"):
                        tables_to_merge.append(df)
        
        if len(tables_to_merge) >= 2:
            # Get the master headers from the first base
            master_headers = header_map[bases[0]]
            
            # Ensure all tables have the same columns before concatenating
            aligned_tables = []
            for df in tables_to_merge:
                if df.empty:
                    continue
                # Reindex to match master headers
                df_aligned = df.copy().reset_index(drop=True)
                current_cols = list(df_aligned.columns)
                
                # If columns match, use as is; otherwise try to align
                if current_cols != master_headers:
                    import logging
                    logger = logging.getLogger(__name__)
                    try:
                        df_aligned = df_aligned.reindex(columns=master_headers)
                    except Exception as e:
                        logger.error(f"❌ ERROR in table merging df_aligned.reindex(columns=...): {e}")
                        logger.error(f"❌ df_aligned shape: {df_aligned.shape if hasattr(df_aligned, 'shape') else 'N/A'}")
                        import traceback
                        logger.error(traceback.format_exc())
                        # If reindex fails, skip this table
                        continue
                
                # Ensure clean indices before adding to list
                df_aligned = df_aligned.reset_index(drop=True)
                aligned_tables.append(df_aligned)
            
            if len(aligned_tables) >= 2:
                import logging
                logger = logging.getLogger(__name__)
                # Double-check all DataFrames have clean indices before concat
                for i, df_part in enumerate(aligned_tables):
                    # Force reset to be absolutely sure - create a completely new DataFrame if needed
                    if df_part.index.duplicated().any() or not isinstance(df_part.index, pd.RangeIndex):
                        logger.warning(f"⚠️  aligned_tables[{i}] has non-standard or duplicate index, creating fresh DataFrame")
                        aligned_tables[i] = pd.DataFrame(df_part.values, columns=df_part.columns)
                    else:
                        aligned_tables[i] = df_part.reset_index(drop=True)
                
                try:
                    merged = pd.concat(aligned_tables, ignore_index=True)
                    merged = stringify_nans(merged)
                except Exception as e:
                    logger.error(f"❌ ERROR during pd.concat in _merge_tables: {e}")
                    for i, df_part in enumerate(aligned_tables):
                        logger.error(f"❌ aligned_tables[{i}] - shape: {df_part.shape}, index: {df_part.index.tolist()}, columns: {df_part.columns.tolist()}")
                    raise
                
                # Create a descriptive key
                base_names = "_".join([b.replace("page", "p") for b in bases[:3]])
                if len(bases) > 3:
                    base_names += f"_and_{len(bases)-3}_more"
                
                result[f"merged_{base_names}"] = merged
                group_id += 1
    
    return result


def clean_itemtables_llm(
    dataframes,
    model=DEFAULT_LLM_MODEL,
    max_rows=50,
    max_cols=50,
    allow_fallback=False,
    combine_parts=True,
):
    cleaned = {}
    header_map = {}
    metadata_map = {}
    llm_specs = {}

    groups = group_itemtable_keys(dataframes)
    for base, keys in groups.items():
        full_df = dataframes.get(f"{base}_full")
        master_headers = None
        metadata = []

        if full_df is not None:
            spec, error = infer_table_spec_llm(
                full_df,
                f"{base}_full",
                master_headers=None,
                max_rows=max_rows,
                max_cols=max_cols,
                model=model,
            )
            if spec:
                llm_specs[f"{base}_full"] = spec
                master_headers = spec.get("header")
                metadata = spec.get("metadata") or []
            elif error:
                llm_specs[f"{base}_full"] = {"error": error}
            elif allow_fallback:
                metadata_rows, header_rows = detect_header_rows(full_df)
                master_headers = normalize_headers(combine_header_rows(full_df, header_rows))
                metadata = extract_metadata_rows(full_df, metadata_rows)

        header_map[base] = master_headers
        if metadata:
            metadata_map[base] = metadata

        cleaned_parts = []
        for key in sort_itemtable_keys(keys):
            if key.endswith("_full"):
                continue
            df = dataframes[key]
            spec, error = infer_table_spec_llm(
                df,
                key,
                master_headers=master_headers,
                max_rows=max_rows,
                max_cols=max_cols,
                model=model,
            )
            import logging
            logger = logging.getLogger(__name__)
            
            if spec:
                llm_specs[key] = spec
                df = apply_llm_spec(df, spec, master_headers=master_headers)
            elif error:
                llm_specs[key] = {"error": error}
            elif allow_fallback:
                df = apply_headers_to_df(df, master_headers, drop_metadata=True, drop_header_row=True)
            
            df = stringify_nans(df)
            # Ensure clean indices before adding to list
            df = df.reset_index(drop=True)
            
            # Check for duplicate column names before adding and fix them
            if df.columns.duplicated().any():
                logger.warning(f"⚠️  DataFrame for {key} has duplicate column names, fixing them")
                df.columns = make_columns_unique(df.columns.tolist())
            
            cleaned_key = f"{key}_clean_llm"
            cleaned[cleaned_key] = df
            cleaned_parts.append(df)

        if cleaned_parts:
            import logging
            logger = logging.getLogger(__name__)
            
            # Always create _combined_clean_llm when combine_parts=True (even for single parts)
            # This ensures consistency: every sheet/table has exactly one _combined_clean_llm table
            if combine_parts:
                if len(cleaned_parts) > 1:
                    # Multiple parts: combine them
                    # CRITICAL FIX: Ensure all DataFrames have unique column names and clean indices before concat
                    for i, df_part in enumerate(cleaned_parts):
                        # Fix duplicate column names FIRST (before any other operations)
                        if df_part.columns.duplicated().any():
                            logger.warning(f"⚠️  cleaned_parts_llm[{i}] has duplicate column names, fixing them")
                            new_columns = make_columns_unique(df_part.columns.tolist())
                            df_part = df_part.copy()
                            df_part.columns = new_columns
                        
                        # Force reset to be absolutely sure - create a completely new DataFrame if needed
                        if df_part.index.duplicated().any() or not isinstance(df_part.index, pd.RangeIndex):
                            logger.warning(f"⚠️  cleaned_parts_llm[{i}] has non-standard or duplicate index, creating fresh DataFrame")
                            cleaned_parts[i] = pd.DataFrame(df_part.values, columns=df_part.columns)
                        else:
                            cleaned_parts[i] = df_part.reset_index(drop=True)
                        
                        # Final verification: ensure no duplicate columns
                        if cleaned_parts[i].columns.duplicated().any():
                            logger.error(f"❌ ERROR: cleaned_parts_llm[{i}] STILL has duplicate columns after fix!")
                            cleaned_parts[i].columns = make_columns_unique(cleaned_parts[i].columns.tolist())
                    
                    try:
                        # Verify all DataFrames have unique column names before concat
                        for i, df_part in enumerate(cleaned_parts):
                            if df_part.columns.duplicated().any():
                                logger.error(f"❌ ERROR: cleaned_parts[{i}] has duplicate columns right before concat!")
                                raise ValueError(f"DataFrame {i} has duplicate columns: {df_part.columns[df_part.columns.duplicated()].tolist()}")
                        
                        combined = pd.concat(cleaned_parts, ignore_index=True)
                        combined = stringify_nans(combined)
                        cleaned[f"{base}_combined_clean_llm"] = combined
                    except Exception as e:
                        logger.error(f"❌ ERROR during pd.concat in _clean_tables_llm: {e}")
                        for i, df_part in enumerate(cleaned_parts):
                            logger.error(f"❌ cleaned_parts[{i}] - shape: {df_part.shape}, has duplicate columns: {df_part.columns.duplicated().any()}")
                        raise
                else:
                    # Single part: create _combined_clean_llm with that single part (for consistency)
                    # This ensures every sheet has exactly one _combined_clean_llm table
                    single_part = cleaned_parts[0]
                    # Ensure clean index and no duplicate columns
                    if single_part.index.duplicated().any() or not isinstance(single_part.index, pd.RangeIndex):
                        single_part = pd.DataFrame(single_part.values, columns=single_part.columns)
                    else:
                        single_part = single_part.reset_index(drop=True)
                    
                    if single_part.columns.duplicated().any():
                        single_part.columns = make_columns_unique(single_part.columns.tolist())
                    
                    combined = stringify_nans(single_part)
                    cleaned[f"{base}_combined_clean_llm"] = combined

    return cleaned, header_map, metadata_map, llm_specs


if __name__ == "__main__":
    import time
    start_time = time.time()
    docs = parser.parse("2019 Barque Smokehouse CONSENT ASSIGN (Pipers Arms Pub) & LEA 04-05.pdf")
    end_time = time.time()
    print(end_time - start_time)
    
    # print(docs.pages[0].tables)
    # print(docs.pages[0].text)
    # print(docs)
    page_names = docs_to_page_names(docs)
    print(f"\nPage to sheet names: {json.dumps(page_names, indent=2)}")
    markdown_by_page = docs_to_markdown(docs)
    for name, md in markdown_by_page.items():
        page_key = name.replace("_markdown", "")
        sheet_name = page_names.get(page_key)
        label = f"{name}" if not sheet_name else f"{name} (sheet={sheet_name})"
        print(f"\n{label}:\n{md}")
    # Write the text of each page in docs to a single txt file with separation between pages
    # with open("all_pages.txt", "w", encoding="utf-8") as f:
    #     for page_num, page in enumerate(docs.pages, start=1):
    #         f.write(f"--- Page {page_num} ---\n")

    #         # Write the raw text
    #         if getattr(page, "text", None):
    #             f.write(page.text)
    #             f.write("\n")

    #         # Write the Markdown version, if any
    #         if getattr(page, "md", None):
    #             f.write(page.md)
    #             f.write("\n")
            
    #         # Write image metadata
    #         images = getattr(page, "images", None)
    #         if images:
    #             for img in images:
    #                 # Write summary line per image
    #                 f.write(f"[Image] name={getattr(img, 'name', '')}, size=({getattr(img, 'width', '')}x{getattr(img, 'height', '')}), x={getattr(img, 'x', '')}, y={getattr(img, 'y', '')}\n")
    #                 # If there's OCR text found in the image's 'ocr' attribute, write it in
    #                 ocr_list = getattr(img, 'ocr', None)
    #                 if ocr_list:
    #                     for ocr in ocr_list:
    #                         text = ocr.get("text", "")
    #                         confidence = ocr.get("confidence", "")
    #                         f.write(f"    [Image OCR] conf={confidence}: {text}\n")
    #             f.write("\n")
            
    #         # Write tables, if present
    #         tables = getattr(page, "tables", None)
    #         if tables:
    #             for t_idx, table in enumerate(tables, start=1):
    #                 f.write(f"[Table {t_idx}]\n")
    #                 if hasattr(table, "md") and table.md:
    #                     f.write(table.md)
    #                     f.write("\n")
    #                 elif hasattr(table, "text") and table.text:
    #                     f.write(table.text)
    #                     f.write("\n")
    #                 elif hasattr(table, "rows"):
    #                     for row in table.rows:
    #                         row_str = "\t".join(str(col) for col in row)
    #                         f.write(row_str + "\n")
    #                 f.write("\n")

    #         # Write layout elements, if desired (optional; not shown in your extract you pasted)
    #         layout = getattr(page, "layout", None)
    #         if layout:
    #             f.write("[Layout]\n")
    #             f.write(str(layout) + "\n")

    #         # Write items if present (structured blocks, e.g. headings, page items)
    #         items = getattr(page, "items", None)
    #         if items:
    #             for item in items:
    #                 # Write the type and value
    #                 f.write(f"[Item type={getattr(item, 'type', '')}] {getattr(item, 'value', '')}\n")
    #                 if getattr(item, "md", None):
    #                     f.write(item.md + "\n")
    #             f.write("\n")

    #         # Write charts, if present
    #         charts = getattr(page, "charts", None)
    #         if charts:
    #             for c_idx, chart in enumerate(charts, start=1):
    #                 f.write(f"[Chart {c_idx}]\n")
    #                 f.write(str(chart) + "\n")
    #             f.write("\n")

    #         # Write any additional structuredData or other metadata as raw JSON for inspection
    #         if hasattr(page, "structuredData") and page.structuredData:
    #             try:
    #                 import json
    #                 f.write("[StructuredData]\n")
    #                 f.write(json.dumps(page.structuredData, indent=2))
    #                 f.write("\n")
    #             except Exception:
    #                 pass

    #         # Two newlines between pages for clear separation
    #         f.write("\n\n")

    # print("All extracted components written to 'all_pages.txt'")
    dataframes, table_count = docs_to_dataframes(docs)
    # print(f"Total tables: {table_count}")
    # print(f"Keys: {list(dataframes.keys())}")
    # if dataframes:
    #     first_key = next(iter(dataframes))
    #     print(f"\nSample ({first_key}):\n{dataframes[first_key].head()}")

    # # Iterate over all dataframes if needed
    # for name, df in dataframes.items():
    #     print(f"\n{name}:\n{df}")

    # cleaned_itemtables, header_map, metadata_map = clean_itemtables(dataframes)
    # print(f"\nCleaned itemtables: {list(cleaned_itemtables.keys())}")
    # if metadata_map:
    #     print(f"\nExtracted metadata: {json.dumps(metadata_map, indent=2)}")
    # print(cleaned_itemtables)

    cleaned_itemtables_llm, llm_header_map, llm_metadata_map, llm_specs = clean_itemtables_llm(
        dataframes
    )
    print(f"\nCleaned itemtables (LLM): {list(cleaned_itemtables_llm.keys())}")
    if llm_metadata_map:
        print(f"\nExtracted metadata (LLM): {json.dumps(llm_metadata_map, indent=2)}")
    if llm_specs:
        print(f"\nLLM specs (sample): {list(llm_specs.items())[:1]}")

    for cleanted_item_llm in cleaned_itemtables_llm:
        print(f"\n{cleanted_item_llm}:")
        print(cleaned_itemtables_llm[cleanted_item_llm])
