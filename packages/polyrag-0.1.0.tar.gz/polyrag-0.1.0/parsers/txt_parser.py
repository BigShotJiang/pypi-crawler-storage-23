"""
TXT Parser - Extract text from plain text files using LangChain loaders.

Supports:
- Plain text files (.txt)
- Multiple encodings (UTF-8, latin-1, etc.)
- Automatic encoding detection
- Line count and character statistics
- Text chunking with LangChain text splitters
"""

import logging
from typing import Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

try:
    from langchain_community.document_loaders import TextLoader
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    TEXT_SPLITTER_AVAILABLE = True
except ImportError:
    TEXT_SPLITTER_AVAILABLE = False


class TXTParser:
    """
    Plain text file extraction using LangChain loaders with encoding detection.
    
    Handles various text encodings and provides basic text statistics.
    Supports text chunking using LangChain text splitters.
    """
    
    def __init__(
        self, 
        encoding: Optional[str] = None,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        enable_chunking: bool = True
    ):
        """
        Initialize TXT parser.
        
        Args:
            encoding: File encoding (default: auto-detect)
            chunk_size: Maximum size of each chunk in characters (default: 1000)
            chunk_overlap: Number of characters to overlap between chunks (default: 200)
            enable_chunking: Whether to chunk the extracted text (default: True)
        """
        self.encoding = encoding
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.enable_chunking = enable_chunking
        
        if not LANGCHAIN_AVAILABLE:
            logger.warning(
                "LangChain not available. Falling back to legacy text reader. Install: pip install langchain langchain-community"
            )
        
        if enable_chunking and not TEXT_SPLITTER_AVAILABLE:
            logger.warning(
                "Chunking requested but langchain-text-splitters not available. Install: pip install langchain-text-splitters"
            )
    
    def parse(self, file_path: str) -> Dict[str, Any]:
        """
        Extract text from plain text file using LangChain loaders with chunking.
        
        Args:
            file_path: Path to text file
        
        Returns:
            dict: {
                "text": str,
                "chunks": list,        # List of chunked Document objects (if chunking enabled)
                "metadata": dict,
                "line_count": int,
                "char_count": int,
                "word_count": int,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"Text file not found: {file_path}")
            
            # Check file size
            file_size = file_path.stat().st_size
            if file_size == 0:
                logger.warning(f"Text file is empty: {file_path}")
                return {
                    "text": "",
                    "metadata": {"encoding": "utf-8", "file_size": 0},
                    "line_count": 0,
                    "char_count": 0,
                    "word_count": 0,
                    "method_used": "text_reader"
                }
            
            logger.info(f"Parsing text file: {file_path} ({file_size} bytes)")
            
            # Try LangChain loader first
            result = None
            if LANGCHAIN_AVAILABLE:
                try:
                    result = self._extract_with_langchain(file_path)
                except Exception as e:
                    logger.warning(f"LangChain extraction failed: {e}")
            
            # Fallback to legacy text reader if LangChain failed or unavailable
            if result is None:
                result = self._extract_with_legacy_reader(file_path)
            
            return result
        
        except Exception as e:
            logger.exception(f"Failed to parse text file: {file_path}")
            return {
                "text": "",
                "metadata": {"error": str(e)},
                "line_count": 0,
                "char_count": 0,
                "word_count": 0,
                "method_used": "failed"
            }
    
    def _extract_with_langchain(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using LangChain TextLoader."""
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("LangChain is not installed. Install with: pip install langchain langchain-community")
        
        # Determine encoding for TextLoader
        encoding = self.encoding or 'utf-8'
        
        # Try to load with specified/default encoding first
        try:
            loader = TextLoader(str(file_path), encoding=encoding)
            documents = loader.load()
        except UnicodeDecodeError:
            # If encoding fails, try auto-detection
            logger.warning(f"Failed with encoding {encoding}, trying auto-detection")
            text, encoding_used = self._read_with_encoding(file_path)
            # Create a document manually from the text
            from langchain_core.documents import Document
            documents = [Document(page_content=text, metadata={"source": str(file_path), "encoding": encoding_used})]
            encoding = encoding_used
        
        # Combine all documents into a single text
        text_parts = []
        metadata = {}
        
        for doc in documents:
            text = doc.page_content if hasattr(doc, 'page_content') else str(doc)
            if text.strip():
                text_parts.append(text.strip())
            
            # Collect metadata from first document
            if not metadata and hasattr(doc, 'metadata'):
                metadata = doc.metadata.copy()
        
        combined_text = "\n".join(text_parts)
        
        # Calculate statistics
        lines = combined_text.split('\n')
        line_count = len(lines)
        char_count = len(combined_text)
        word_count = len(combined_text.split())
        
        # Remove excessive whitespace but preserve structure
        cleaned_lines = [line.rstrip() for line in lines]
        cleaned_text = '\n'.join(cleaned_lines)
        
        # Chunk the documents if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                chunks = self._chunk_documents(documents)
                logger.info(f"Created {len(chunks)} chunks from {len(documents)} document(s)")
            except Exception as e:
                logger.warning(f"Failed to chunk documents: {e}")
        
        # Update metadata with statistics
        metadata.update({
            "encoding": encoding,
            "file_size": file_path.stat().st_size,
            "line_count": line_count,
            "char_count": char_count,
            "word_count": word_count
        })
        
        result = {
            "text": cleaned_text,
            "metadata": metadata,
            "line_count": line_count,
            "char_count": char_count,
            "word_count": word_count,
            "method_used": "langchain"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _extract_with_legacy_reader(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using legacy text reader (fallback method)."""
        # Read file with encoding detection
        text, encoding_used = self._read_with_encoding(file_path)
        
        # Calculate statistics
        lines = text.split('\n')
        line_count = len(lines)
        char_count = len(text)
        word_count = len(text.split())
        
        # Remove excessive whitespace but preserve structure
        cleaned_lines = [line.rstrip() for line in lines]
        cleaned_text = '\n'.join(cleaned_lines)
        
        # Create document for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                langchain_doc = Document(
                    page_content=cleaned_text, 
                    metadata={"source": str(file_path), "encoding": encoding_used}
                )
                chunks = self._chunk_documents([langchain_doc])
                logger.info(f"Created {len(chunks)} chunks from document")
            except Exception as e:
                logger.warning(f"Failed to chunk document: {e}")
        
        metadata = {
            "encoding": encoding_used,
            "file_size": file_path.stat().st_size,
            "line_count": line_count,
            "char_count": char_count,
            "word_count": word_count
        }
        
        result = {
            "text": cleaned_text,
            "metadata": metadata,
            "line_count": line_count,
            "char_count": char_count,
            "word_count": word_count,
            "method_used": "text_reader"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _chunk_documents(self, documents: list) -> list:
        """
        Split documents into chunks using LangChain text splitter.
        
        Args:
            documents: List of Document objects from LangChain
            
        Returns:
            List of chunked Document objects
        """
        if not TEXT_SPLITTER_AVAILABLE:
            raise ImportError("LangChain text splitter is not installed. Install: pip install langchain-text-splitters")
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
        
        chunks = text_splitter.split_documents(documents)
        return chunks
    
    def _read_with_encoding(self, file_path: Path) -> tuple[str, str]:
        """
        Read file with automatic encoding detection.
        
        Args:
            file_path: Path to text file
        
        Returns:
            tuple: (text_content, encoding_used)
        """
        # If encoding is specified, use it
        if self.encoding:
            try:
                with open(file_path, 'r', encoding=self.encoding) as f:
                    text = f.read()
                logger.info(f"Read file with specified encoding: {self.encoding}")
                return text, self.encoding
            except UnicodeDecodeError:
                logger.warning(f"Failed with specified encoding {self.encoding}, trying alternatives")
        
        # Try common encodings
        encodings_to_try = [
            'utf-8',
            'utf-8-sig',  # UTF-8 with BOM
            'latin-1',
            'iso-8859-1',
            'cp1252',  # Windows-1252
            'ascii'
        ]
        
        for encoding in encodings_to_try:
            try:
                with open(file_path, 'r', encoding=encoding) as f:
                    text = f.read()
                logger.info(f"Successfully read file with encoding: {encoding}")
                return text, encoding
            except (UnicodeDecodeError, LookupError):
                continue
        
        # Last resort: read as binary and decode with errors='replace'
        logger.warning(f"All encoding attempts failed, using binary read with error replacement")
        with open(file_path, 'rb') as f:
            binary_content = f.read()
        text = binary_content.decode('utf-8', errors='replace')
        return text, 'utf-8 (with errors replaced)'
    
    @staticmethod
    def is_valid_txt(file_path: str) -> bool:
        """
        Check if file is a valid text file.
        
        Args:
            file_path: Path to file
        
        Returns:
            bool: True if valid text file
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Check file size
            if file_path.stat().st_size == 0:
                return True  # Empty files are technically valid
            
            # Try to read first few bytes to verify it's text
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    f.read(1024)  # Read first 1KB
                return True
            except UnicodeDecodeError:
                # Try with latin-1 (accepts all byte values)
                with open(file_path, 'r', encoding='latin-1') as f:
                    f.read(1024)
                return True
        
        except Exception:
            return False

