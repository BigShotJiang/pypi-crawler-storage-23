"""
XML Parser - Extract text and structure from XML files

This parser handles XML documents and extracts all text content while preserving structure.
"""

import logging
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Any, Optional
import re

logger = logging.getLogger(__name__)


class XMLParser:
    """
    Parser for extracting text from XML files.
    
    Extracts all text content from XML elements, preserving structure and metadata.
    """
    
    def __init__(self, preserve_tags: bool = False, include_attributes: bool = True):
        """
        Initialize XML parser.
        
        Args:
            preserve_tags: If True, include tag names in output
            include_attributes: If True, include attribute values in text extraction
        """
        self.preserve_tags = preserve_tags
        self.include_attributes = include_attributes
        logger.info(
            f"XMLParser initialized (preserve_tags={preserve_tags}, "
            f"include_attributes={include_attributes})"
        )
    
    def parse(self, file_path: str) -> Dict[str, Any]:
        """
        Extract text from XML file.
        
        Args:
            file_path: Path to XML file
        
        Returns:
            dict: {
                "text": str,              # Extracted text
                "metadata": dict,         # File metadata
                "element_count": int,     # Number of elements
                "root_tag": str,          # Root element tag name
                "method_used": str        # "xml.etree.ElementTree"
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"XML file not found: {file_path}")
            
            # Parse XML file
            try:
                tree = ET.parse(file_path)
                root = tree.getroot()
            except ET.ParseError as e:
                logger.error(f"XML parsing error in {file_path}: {e}")
                # Try to clean and reparse
                return self._parse_with_cleanup(file_path)
            
            # Extract text from all elements
            text_parts = []
            element_count = 0
            
            def extract_text_recursive(element, level=0):
                nonlocal element_count
                element_count += 1
                
                # Add tag name if preserving structure
                if self.preserve_tags and element.tag:
                    indent = "  " * level
                    text_parts.append(f"{indent}<{element.tag}>")
                
                # Add attributes if enabled
                if self.include_attributes and element.attrib:
                    attr_text = " ".join(f"{k}={v}" for k, v in element.attrib.items())
                    text_parts.append(attr_text)
                
                # Add element text
                if element.text and element.text.strip():
                    text_parts.append(element.text.strip())
                
                # Recursively process children
                for child in element:
                    extract_text_recursive(child, level + 1)
                    # Add tail text (text after child element)
                    if child.tail and child.tail.strip():
                        text_parts.append(child.tail.strip())
                
                if self.preserve_tags and element.tag:
                    indent = "  " * level
                    text_parts.append(f"{indent}</{element.tag}>")
            
            extract_text_recursive(root)
            
            # Combine text with proper spacing
            full_text = "\n".join(text_parts)
            
            # Clean up excessive whitespace
            full_text = re.sub(r'\n\s*\n\s*\n', '\n\n', full_text)
            
            # Extract metadata
            metadata = {
                "file_name": file_path.name,
                "file_size": file_path.stat().st_size,
                "root_tag": root.tag,
                "xml_encoding": tree.docinfo.encoding if hasattr(tree, 'docinfo') else "UTF-8",
                "namespace": self._extract_namespace(root.tag) if '{' in root.tag else None
            }
            
            return {
                "text": full_text,
                "metadata": metadata,
                "element_count": element_count,
                "root_tag": root.tag,
                "method_used": "xml.etree.ElementTree"
            }
        
        except Exception as e:
            logger.exception(f"Failed to parse XML: {file_path}")
            return {
                "text": "",
                "metadata": {"error": str(e)},
                "element_count": 0,
                "root_tag": "",
                "method_used": "failed"
            }
    
    def _parse_with_cleanup(self, file_path: Path) -> Dict[str, Any]:
        """
        Attempt to parse XML with cleanup for malformed files.
        
        Args:
            file_path: Path to XML file
            
        Returns:
            dict: Parsing results
        """
        try:
            # Read file and try to clean it
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Remove BOM if present
            content = content.lstrip('\ufeff')
            
            # Try to extract text even from malformed XML
            # Remove XML tags and extract text
            text = re.sub(r'<[^>]+>', ' ', content)
            text = re.sub(r'\s+', ' ', text).strip()
            
            logger.warning(f"Parsed malformed XML using regex extraction: {file_path}")
            
            return {
                "text": text,
                "metadata": {
                    "file_name": file_path.name,
                    "file_size": file_path.stat().st_size,
                    "warning": "Parsed with cleanup due to malformed XML"
                },
                "element_count": 0,
                "root_tag": "unknown",
                "method_used": "regex_cleanup"
            }
            
        except Exception as e:
            logger.exception(f"Failed to parse even with cleanup: {file_path}")
            return {
                "text": "",
                "metadata": {"error": str(e)},
                "element_count": 0,
                "root_tag": "",
                "method_used": "failed"
            }
    
    def _extract_namespace(self, tag: str) -> Optional[str]:
        """
        Extract namespace from tag name.
        
        Args:
            tag: Tag name (e.g., '{http://example.com}element')
            
        Returns:
            str: Namespace URI or None
        """
        if '{' in tag:
            return tag.split('}')[0][1:]
        return None

