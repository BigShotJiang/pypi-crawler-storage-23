"""
CSV Parser - Extract data from CSV files.

Supports:
- Standard CSV files
- Various delimiters (comma, tab, semicolon, pipe)
- Different encodings (UTF-8, latin-1, etc.)
- Headers and headerless files
"""

import logging
import csv
from typing import Dict, Any, Optional, List
from pathlib import Path
from app.core.parsers.unified_parser import normalize_extension

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False


logger = logging.getLogger(__name__)


class CSVParser:
    """
    CSV data extraction with multiple encoding support.
    
    Uses pandas if available for robust parsing, falls back to csv module.
    """
    
    def __init__(
        self,
        delimiter: Optional[str] = None,
        encoding: str = "utf-8",
        has_header: bool = True
    ):
        """
        Initialize CSV parser.
        
        Args:
            delimiter: Column delimiter (auto-detected if None)
            encoding: File encoding (default: utf-8)
            has_header: Whether first row is header
        """
        self.delimiter = delimiter
        self.encoding = encoding
        self.has_header = has_header
    
    def parse(
        self,
        file_path: str,
        max_rows: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Extract data from CSV file.
        
        Args:
            file_path: Path to CSV file
            max_rows: Maximum number of rows to read (None for all)
        
        Returns:
            dict: {
                "text": str (formatted table text),
                "data": list (list of row dicts),
                "metadata": dict,
                "row_count": int,
                "column_count": int,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"CSV file not found: {file_path}")
            
            # Normalize extension to handle variant extensions like .csv_v3
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.csv', '.tsv', '.txt']:
                raise ValueError(f"Not a CSV file: {file_path}")
            
            # Try pandas first if available (more robust)
            if PANDAS_AVAILABLE:
                return self._parse_with_pandas(file_path, max_rows)
            else:
                return self._parse_with_csv_module(file_path, max_rows)
        
        except Exception as e:
            logger.exception(f"Failed to parse CSV: {file_path}")
            return {
                "text": "",
                "data": [],
                "metadata": {"error": str(e)},
                "row_count": 0,
                "column_count": 0,
                "method_used": "failed"
            }
    
    def _parse_with_pandas(
        self,
        file_path: Path,
        max_rows: Optional[int]
    ) -> Dict[str, Any]:
        """Parse CSV using pandas (preferred method)."""
        try:
            # Detect delimiter if not specified
            delimiter = self.delimiter
            if delimiter is None:
                delimiter = self._detect_delimiter(file_path)
            
            # Read CSV with pandas
            df = pd.read_csv(
                file_path,
                delimiter=delimiter,
                encoding=self.encoding,
                nrows=max_rows,
                header=0 if self.has_header else None,
                on_bad_lines='skip'  # Skip bad lines instead of failing
            ).reset_index(drop=True)
            
            # Convert to text representation
            text = df.to_string(index=False)
            
            # Convert to list of dicts
            data = df.to_dict('records')
            
            # Get column names
            columns = df.columns.tolist()
            
            metadata = {
                "delimiter": delimiter,
                "encoding": self.encoding,
                "columns": columns,
                "has_header": self.has_header
            }
            
            return {
                "text": text,
                "data": data,
                "metadata": metadata,
                "row_count": len(df),
                "column_count": len(columns),
                "method_used": "pandas"
            }
        
        except UnicodeDecodeError:
            # Try alternative encoding
            logger.warning(f"Failed with {self.encoding}, trying latin-1")
            return self._parse_with_pandas_alternative_encoding(file_path, max_rows)
        
        except Exception as e:
            logger.error(f"Pandas parsing failed: {e}")
            # Fallback to csv module
            return self._parse_with_csv_module(file_path, max_rows)
    
    def _parse_with_pandas_alternative_encoding(
        self,
        file_path: Path,
        max_rows: Optional[int]
    ) -> Dict[str, Any]:
        """Try parsing with alternative encoding."""
        for encoding in ['latin-1', 'iso-8859-1', 'cp1252']:
            try:
                delimiter = self.delimiter or self._detect_delimiter(file_path)
                
                df = pd.read_csv(
                    file_path,
                    delimiter=delimiter,
                    encoding=encoding,
                    nrows=max_rows,
                    header=0 if self.has_header else None,
                    on_bad_lines='skip'
                ).reset_index(drop=True)
                
                text = df.to_string(index=False)
                data = df.to_dict('records')
                columns = df.columns.tolist()
                
                return {
                    "text": text,
                    "data": data,
                    "metadata": {
                        "delimiter": delimiter,
                        "encoding": encoding,
                        "columns": columns,
                        "has_header": self.has_header
                    },
                    "row_count": len(df),
                    "column_count": len(columns),
                    "method_used": "pandas"
                }
            
            except Exception:
                continue
        
        raise UnicodeDecodeError(
            'utf-8', b'', 0, 1, 'All encoding attempts failed'
        )
    
    def _parse_with_csv_module(
        self,
        file_path: Path,
        max_rows: Optional[int]
    ) -> Dict[str, Any]:
        """Parse CSV using standard csv module (fallback)."""
        try:
            delimiter = self.delimiter
            if delimiter is None:
                delimiter = self._detect_delimiter(file_path)
            
            rows = []
            with open(file_path, 'r', encoding=self.encoding) as f:
                reader = csv.reader(f, delimiter=delimiter)
                
                headers = None
                if self.has_header:
                    headers = next(reader)
                
                for i, row in enumerate(reader):
                    if max_rows and i >= max_rows:
                        break
                    rows.append(row)
            
            # Convert to text
            text_lines = []
            if headers:
                text_lines.append(" | ".join(headers))
                text_lines.append("-" * 50)
            
            for row in rows:
                text_lines.append(" | ".join(str(cell) for cell in row))
            
            # Convert to list of dicts
            data = []
            if headers:
                for row in rows:
                    data.append(dict(zip(headers, row)))
            else:
                for row in rows:
                    data.append({f"col_{i}": val for i, val in enumerate(row)})
            
            column_count = len(headers) if headers else (len(rows[0]) if rows else 0)
            
            return {
                "text": "\n".join(text_lines),
                "data": data,
                "metadata": {
                    "delimiter": delimiter,
                    "encoding": self.encoding,
                    "columns": headers or [],
                    "has_header": self.has_header
                },
                "row_count": len(rows),
                "column_count": column_count,
                "method_used": "csv_module"
            }
        
        except Exception as e:
            logger.exception(f"CSV module parsing failed: {file_path}")
            raise
    
    def _detect_delimiter(self, file_path: Path) -> str:
        """
        Auto-detect delimiter from file.
        
        Args:
            file_path: Path to CSV file
        
        Returns:
            str: Detected delimiter
        """
        try:
            with open(file_path, 'r', encoding=self.encoding) as f:
                # Read first few lines
                sample = f.read(8192)
                
                # Use csv.Sniffer to detect delimiter
                sniffer = csv.Sniffer()
                delimiter = sniffer.sniff(sample).delimiter
                
                logger.info(f"Detected delimiter: '{delimiter}'")
                return delimiter
        
        except Exception as e:
            logger.warning(f"Failed to detect delimiter: {e}, using comma")
            return ','
    
    @staticmethod
    def is_valid_csv(file_path: str) -> bool:
        """
        Check if file is a valid CSV file.
        
        Args:
            file_path: Path to file
        
        Returns:
            bool: True if valid CSV
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Normalize extension to handle variant extensions like .csv_v3
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.csv', '.tsv', '.txt']:
                return False
            
            # Try to read first line
            with open(file_path, 'r') as f:
                csv.reader(f).__next__()
                return True
        
        except Exception:
            return False

