"""
Shared file-to-text parsing helper for ingestion pipelines.

Strategy:
- PDFs: try pdfplumber text extraction first.
- OCR-like PDFs: fallback to existing unified parser routing.
- Non-PDFs: use unified parser directly.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
import os
from pathlib import Path
import re
from typing import Optional

from parsers.pdf_parser import PDFParser
from parsers.unified_parser import normalize_extension, parse_document

logger = logging.getLogger(__name__)


_DEFAULT_USE_PDFPLUMBER_FIRST = True
_DEFAULT_TOTAL_MIN_CHARS = 200
_DEFAULT_PAGE_MIN_CHARS = 40
_DEFAULT_LOW_TEXT_PAGE_RATIO = 0.8
_PAGE_MARKER_RE = re.compile(r"^---\s*Page\s+\d+\s*---$")


@dataclass
class PipelineTextParseResult:
    text: str
    title_hint: Optional[str]
    route: str
    ocr_like: bool
    fallback_reason: Optional[str] = None


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        logger.warning("Invalid int for %s=%r. Using default=%d", name, value, default)
        return default


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        logger.warning("Invalid float for %s=%r. Using default=%s", name, value, default)
        return default


def _derive_title_hint(text: str) -> Optional[str]:
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if line and len(line) < 200 and not _PAGE_MARKER_RE.match(line):
            return line
    return None


def _coerce_page_number(value: object) -> Optional[int]:
    try:
        if value is None:
            return None
        if isinstance(value, bool):
            return None
        page = int(value)
        return page if page > 0 else None
    except (TypeError, ValueError):
        return None


def _render_page_separated_text(page_entries: list[tuple[Optional[int], str]]) -> str:
    rendered = []
    for idx, (page_num, page_text) in enumerate(page_entries, start=1):
        if not page_text:
            continue
        page_label = page_num or idx
        rendered.append(f"--- Page {page_label} ---\n{page_text.strip()}")
    return "\n\n".join(rendered).strip()


def _build_page_text_from_pdf_pages(pages: object) -> str:
    if not isinstance(pages, dict) or not pages:
        return ""
    page_entries: list[tuple[Optional[int], str]] = []
    for raw_page, raw_text in pages.items():
        page_num = _coerce_page_number(raw_page)
        page_text = str(raw_text or "").strip()
        if page_text:
            page_entries.append((page_num, page_text))
    return _render_page_separated_text(page_entries)


def _build_page_text_from_unified_documents(documents: object) -> str:
    if not isinstance(documents, list) or not documents:
        return ""

    page_entries: list[tuple[Optional[int], str]] = []
    for idx, doc in enumerate(documents, start=1):
        page_content = getattr(doc, "page_content", "")
        if not page_content and isinstance(doc, dict):
            page_content = doc.get("page_content", "")
        page_text = str(page_content or "").strip()
        if not page_text:
            continue

        metadata = getattr(doc, "metadata", None)
        if metadata is None and isinstance(doc, dict):
            metadata = doc.get("metadata", {})
        metadata = metadata or {}

        if isinstance(metadata, dict):
            page_num = _coerce_page_number(metadata.get("page"))
            if page_num is None:
                page_num = _coerce_page_number(metadata.get("page_number"))
        else:
            page_num = _coerce_page_number(getattr(metadata, "page", None))
            if page_num is None:
                page_num = _coerce_page_number(getattr(metadata, "page_number", None))
        if page_num is None:
            page_num = idx
        page_entries.append((page_num, page_text))

    return _render_page_separated_text(page_entries)


def _extract_text_from_unified_result(result: object) -> str:
    if hasattr(result, "documents") and result.documents:
        paged_text = _build_page_text_from_unified_documents(result.documents)
        if paged_text:
            return paged_text

    if hasattr(result, "full_markdown") and result.full_markdown:
        return str(result.full_markdown).strip()

    return ""


def _parse_with_unified(file_path: str, *, route: str, ocr_like: bool, reason: Optional[str]) -> PipelineTextParseResult:
    result = parse_document(file_path)
    text = _extract_text_from_unified_result(result)
    return PipelineTextParseResult(
        text=text,
        title_hint=_derive_title_hint(text),
        route=route,
        ocr_like=ocr_like,
        fallback_reason=reason,
    )


def _get_pdf_heuristic_config() -> tuple[bool, int, int, float]:
    use_pdfplumber_first = _env_bool(
        "PDF_PIPELINE_USE_PDFPLUMBER_FIRST",
        _DEFAULT_USE_PDFPLUMBER_FIRST,
    )
    total_min_chars = _env_int("PDF_PIPELINE_TOTAL_MIN_CHARS", _DEFAULT_TOTAL_MIN_CHARS)
    page_min_chars = _env_int("PDF_PIPELINE_PAGE_MIN_CHARS", _DEFAULT_PAGE_MIN_CHARS)
    low_text_page_ratio = _env_float(
        "PDF_PIPELINE_LOW_TEXT_PAGE_RATIO",
        _DEFAULT_LOW_TEXT_PAGE_RATIO,
    )
    return use_pdfplumber_first, total_min_chars, page_min_chars, low_text_page_ratio


def _get_pdf_fallback_reason(
    *,
    method_used: str,
    total_chars: int,
    total_min_chars: int,
    page_count: int,
    low_text_pages: int,
    low_text_page_ratio: float,
) -> Optional[str]:
    if method_used == "failed":
        return "pdfplumber_failed"
    if total_chars == 0:
        return "empty_text"
    if total_chars < total_min_chars:
        return f"low_total_chars:{total_chars}<{total_min_chars}"
    if page_count >= 3 and page_count > 0:
        ratio = low_text_pages / page_count
        if ratio >= low_text_page_ratio:
            return f"low_text_page_ratio:{ratio:.3f}>={low_text_page_ratio:.3f}"
    return None


def parse_file_to_text(file_path: str) -> PipelineTextParseResult:
    """
    Parse a file to text using ingestion-safe routing.

    Returns:
        PipelineTextParseResult with text, title_hint, route, and fallback details.
    """
    path = Path(file_path)
    extension = normalize_extension(path.suffix)

    if extension != ".pdf":
        return _parse_with_unified(
            file_path,
            route="unified_direct",
            ocr_like=False,
            reason=None,
        )

    (
        use_pdfplumber_first,
        total_min_chars,
        page_min_chars,
        low_text_page_ratio,
    ) = _get_pdf_heuristic_config()

    if not use_pdfplumber_first:
        return _parse_with_unified(
            file_path,
            route="unified_direct",
            ocr_like=False,
            reason="pdfplumber_first_disabled",
        )

    fallback_reason: Optional[str] = None
    try:
        parser = PDFParser(
            use_ocr=False,
            use_openai_ocr=False,
            enable_chunking=False,
        )
        pdf_result = parser.parse(file_path, method="pdfplumber")

        pages = pdf_result.get("pages") or {}
        page_count = int(pdf_result.get("page_count") or len(pages))
        method_used = str(pdf_result.get("method_used") or "")
        raw_text = str(pdf_result.get("text") or "").strip()
        if not raw_text and isinstance(pages, dict):
            raw_text = "\n\n".join(
                str(page_text or "").strip()
                for page_text in pages.values()
                if str(page_text or "").strip()
            )
        text = _build_page_text_from_pdf_pages(pages) or raw_text
        total_chars = len(raw_text)
        low_text_pages = sum(
            1
            for page_text in pages.values()
            if len(str(page_text or "").strip()) < page_min_chars
        )

        fallback_reason = _get_pdf_fallback_reason(
            method_used=method_used,
            total_chars=total_chars,
            total_min_chars=total_min_chars,
            page_count=page_count,
            low_text_pages=low_text_pages,
            low_text_page_ratio=low_text_page_ratio,
        )

        if fallback_reason is None:
            return PipelineTextParseResult(
                text=text,
                title_hint=_derive_title_hint(text),
                route="pdfplumber_direct",
                ocr_like=False,
                fallback_reason=None,
            )
    except Exception as exc:
        fallback_reason = f"pdfplumber_exception:{type(exc).__name__}"
        logger.warning("pdfplumber-first parse failed for %s: %s", file_path, exc)

    return _parse_with_unified(
        file_path,
        route="unified_fallback",
        ocr_like=True,
        reason=fallback_reason,
    )
