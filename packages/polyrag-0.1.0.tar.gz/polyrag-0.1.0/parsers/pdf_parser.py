"""
PDF Parser - Extract text from PDF documents.

Supports various PDF types and handles common issues like:
- Scanned PDFs (with OCR)
- Multi-column layouts
- Tables and figures
- Encrypted PDFs
"""

import logging
from typing import Dict, Any, Optional
from pathlib import Path
import io
import sys
import os
from app.core.parsers.unified_parser import normalize_extension

# Add parent directory to path to import from utils
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../..'))

# Initialize logger first
logger = logging.getLogger(__name__)

try:
    from langchain_community.document_loaders import PyPDFLoader
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    TEXT_SPLITTER_AVAILABLE = True
except ImportError:
    TEXT_SPLITTER_AVAILABLE = False

try:
    import PyPDF2
    PYPDF2_AVAILABLE = True
except ImportError:
    PYPDF2_AVAILABLE = False

try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False

try:
    from PIL import Image
    import pytesseract  # type: ignore
    PYTESSERACT_AVAILABLE = True
except ImportError:
    PYTESSERACT_AVAILABLE = False

try:
    from app.utils.ocr import extract_text_from_pdf as openai_ocr_extract
    OPENAI_OCR_AVAILABLE = True
except ImportError:
    OPENAI_OCR_AVAILABLE = False
    logger.warning("OpenAI OCR not available. Install required dependencies.")


# Text length threshold to detect scanned PDFs
MIN_TEXT_LENGTH_THRESHOLD = 600


class PDFParser:
    """
    PDF text extraction using LangChain loaders with OCR fallback.
    
    Extraction methods (in order of preference):
    1. LangChain PyPDFLoader - Primary extraction method
    2. OpenAI Vision OCR - For pages with < 100 chars (auto-triggered)
    3. Fallback to pdfplumber/PyPDF2 if LangChain unavailable
    """
    
    def __init__(
        self, 
        use_ocr: bool = False, 
        use_openai_ocr: bool = True, 
        min_text_threshold: int = MIN_TEXT_LENGTH_THRESHOLD,
        chunk_size: int = 1000,
        chunk_overlap: int = 200,
        enable_chunking: bool = True
    ):
        """
        Initialize PDF parser.
        
        Args:
            use_ocr: Whether to use pytesseract OCR for scanned PDFs (legacy option)
            use_openai_ocr: Whether to use OpenAI Vision OCR as fallback for scanned PDFs (default: True)
            min_text_threshold: Minimum text length to consider extraction successful (default: 100)
            chunk_size: Maximum size of each chunk in characters (default: 1000)
            chunk_overlap: Number of characters to overlap between chunks (default: 200)
            enable_chunking: Whether to chunk the extracted text (default: True)
        """
        self.use_pytesseract_ocr = use_ocr and PYTESSERACT_AVAILABLE
        self.use_openai_ocr = use_openai_ocr and OPENAI_OCR_AVAILABLE
        self.min_text_threshold = min_text_threshold
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.enable_chunking = enable_chunking
        
        if not LANGCHAIN_AVAILABLE and not PYPDF2_AVAILABLE and not PDFPLUMBER_AVAILABLE:
            raise RuntimeError(
                "No PDF parsing library available. Install: pip install langchain langchain-community pypdf pdfplumber"
            )
        
        if not LANGCHAIN_AVAILABLE:
            logger.warning(
                "LangChain not available. Falling back to legacy parsers. Install: pip install langchain langchain-community pypdf"
            )
        
        if use_ocr and not PYTESSERACT_AVAILABLE:
            logger.warning(
                "Pytesseract OCR requested but not available. Install: pip install pytesseract pillow"
            )
        
        if use_openai_ocr and not OPENAI_OCR_AVAILABLE:
            logger.warning(
                "OpenAI OCR requested but not available. Check OpenAI API configuration."
            )
        
        if enable_chunking and not TEXT_SPLITTER_AVAILABLE:
            logger.warning(
                "Chunking requested but langchain-text-splitters not available. Install: pip install langchain-text-splitters"
            )
    
    def parse(
        self,
        file_path: str,
        method: str = "auto"
    ) -> Dict[str, Any]:
        """
        Extract text from PDF file using LangChain loaders with OCR fallback.
        
        Args:
            file_path: Path to PDF file
            method: Extraction method - "auto", "langchain", "pdfplumber", "pypdf2", "openai_ocr", "ocr"/"pytesseract"
                    "auto" uses LangChain first, then falls back to legacy methods if needed
                    Automatically uses OpenAI OCR for pages with < 100 chars
        
        Returns:
            dict: {
                "text": str,           # Combined text from all pages
                "pages": {             # Dictionary with per-page text
                    1: "page 1 text",
                    2: "page 2 text",
                    ...
                },
                "chunks": list,        # List of chunked Document objects (if chunking enabled)
                "metadata": dict,
                "page_count": int,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"PDF file not found: {file_path}")
            
            # Normalize extension to handle variant extensions like .pdf_v7
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext != '.pdf':
                raise ValueError(f"Not a PDF file: {file_path}")
            
            # Try LangChain loader first (primary method)
            if method == "auto" or method == "langchain":
                if LANGCHAIN_AVAILABLE:
                    try:
                        result = self._extract_with_langchain(file_path)
                        # Check each page and use OCR for pages with < 100 chars
                        result = self._apply_ocr_for_short_pages(file_path, result)
                        return result
                    except Exception as e:
                        logger.warning(f"LangChain extraction failed: {e}")
                        if method == "langchain":
                            raise
                        # Fall through to legacy methods if auto mode
            
            # Legacy extraction methods (fallback)
            if method == "auto":
                extracted_text = ""
                result = None
                
                # Try pdfplumber first (best quality)
                if PDFPLUMBER_AVAILABLE:
                    try:
                        result = self._extract_with_pdfplumber(file_path)
                        extracted_text = result["text"].strip()
                        if len(extracted_text) >= self.min_text_threshold:
                            logger.info(f"Successfully extracted {len(extracted_text)} chars using pdfplumber")
                            # Check each page and use OCR for pages with < 100 chars
                            result = self._apply_ocr_for_short_pages(file_path, result)
                            return result
                        elif extracted_text:
                            logger.info(f"pdfplumber extracted only {len(extracted_text)} chars (below threshold of {self.min_text_threshold})")
                    except Exception as e:
                        logger.warning(f"pdfplumber extraction failed: {e}")
                
                # Fallback to PyPDF2
                if PYPDF2_AVAILABLE:
                    try:
                        result = self._extract_with_pypdf2(file_path)
                        extracted_text = result["text"].strip()
                        if len(extracted_text) >= self.min_text_threshold:
                            logger.info(f"Successfully extracted {len(extracted_text)} chars using PyPDF2")
                            # Check each page and use OCR for pages with < 100 chars
                            result = self._apply_ocr_for_short_pages(file_path, result)
                            return result
                        elif extracted_text:
                            logger.info(f"PyPDF2 extracted only {len(extracted_text)} chars (below threshold of {self.min_text_threshold})")
                    except Exception as e:
                        logger.warning(f"PyPDF2 extraction failed: {e}")
                
                # If extracted text is below threshold, try OpenAI Vision OCR for all pages
                if len(extracted_text) < self.min_text_threshold and self.use_openai_ocr:
                    logger.info(f"Extracted text ({len(extracted_text)} chars) below threshold. Attempting OpenAI Vision OCR...")
                    try:
                        result = self._extract_with_openai_ocr(file_path)
                        if result["text"].strip():
                            logger.info(f"OpenAI Vision OCR successfully extracted {len(result['text'].strip())} chars")
                            return result
                    except Exception as e:
                        logger.warning(f"OpenAI Vision OCR extraction failed: {e}")
                
                # Fallback to pytesseract OCR if enabled
                if self.use_pytesseract_ocr:
                    try:
                        result = self._extract_with_pytesseract_ocr(file_path)
                        if result["text"].strip():
                            logger.info(f"Pytesseract OCR successfully extracted {len(result['text'].strip())} chars")
                            return result
                    except Exception as e:
                        logger.warning(f"Pytesseract OCR extraction failed: {e}")
                
                # If we have any text at all, return it even if below threshold
                if result and extracted_text:
                    logger.warning(f"Returning extracted text despite being below threshold ({len(extracted_text)} chars)")
                    return result
                
                raise RuntimeError("All PDF extraction methods failed")
            
            elif method == "pdfplumber":
                result = self._extract_with_pdfplumber(file_path)
                result = self._apply_ocr_for_short_pages(file_path, result)
                return result
            
            elif method == "pypdf2":
                result = self._extract_with_pypdf2(file_path)
                result = self._apply_ocr_for_short_pages(file_path, result)
                return result
            
            elif method == "openai_ocr":
                if not self.use_openai_ocr:
                    raise ValueError("OpenAI OCR not enabled. Initialize with use_openai_ocr=True")
                return self._extract_with_openai_ocr(file_path)
            
            elif method == "ocr" or method == "pytesseract":
                if not self.use_pytesseract_ocr:
                    raise ValueError("Pytesseract OCR not enabled. Initialize with use_ocr=True")
                return self._extract_with_pytesseract_ocr(file_path)
            
            else:
                raise ValueError(f"Unknown extraction method: {method}")
        
        except Exception as e:
            logger.exception(f"Failed to parse PDF: {file_path}")
            return {
                "text": "",
                "pages": {},
                "metadata": {"error": str(e)},
                "page_count": 0,
                "method_used": "failed"
            }
    
    def _extract_with_langchain(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using LangChain PyPDFLoader."""
        if not LANGCHAIN_AVAILABLE:
            raise ImportError("LangChain is not installed. Install with: pip install langchain langchain-community pypdf")
        
        loader = PyPDFLoader(str(file_path))
        documents = loader.load()
        
        pages_dict = {}
        metadata = {}
        
        for page_num, doc in enumerate(documents, start=1):
            # Extract page number from metadata if available
            page_metadata = doc.metadata if hasattr(doc, 'metadata') else {}
            page_text = doc.page_content if hasattr(doc, 'page_content') else str(doc)
            pages_dict[page_num] = page_text
            
            # Collect metadata from first document
            if page_num == 1:
                metadata = page_metadata.copy()
        
        # Combine all pages for backward compatibility
        combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
        
        # Chunk the documents if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                chunks = self._chunk_documents(documents)
                logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
            except Exception as e:
                logger.warning(f"Failed to chunk documents: {e}")
        
        result = {
            "text": combined_text,
            "pages": pages_dict,
            "metadata": metadata,
            "page_count": len(pages_dict),
            "method_used": "langchain"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _chunk_documents(self, documents: list) -> list:
        """
        Split documents into chunks using LangChain text splitter.
        
        Args:
            documents: List of Document objects from LangChain
            
        Returns:
            List of chunked Document objects
        """
        if not TEXT_SPLITTER_AVAILABLE:
            raise ImportError("LangChain text splitter is not installed. Install: pip install langchain-text-splitters")
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
        
        chunks = text_splitter.split_documents(documents)
        return chunks
    
    def _apply_ocr_for_short_pages(self, file_path: Path, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check each page and apply OCR for pages with < 100 characters.
        
        Args:
            file_path: Path to PDF file
            result: Result dictionary from initial extraction
            
        Returns:
            Updated result dictionary with OCR text for short pages
        """
        if not self.use_openai_ocr or not OPENAI_OCR_AVAILABLE:
            return result
        
        pages_dict = result.get("pages", {})
        updated_pages = pages_dict.copy()
        needs_ocr = False
        
        # Check which pages need OCR
        pages_needing_ocr = []
        for page_num, page_text in pages_dict.items():
            if len(page_text.strip()) < self.min_text_threshold:
                pages_needing_ocr.append(page_num)
                needs_ocr = True
        
        if not needs_ocr:
            return result
        
        logger.info(f"Found {len(pages_needing_ocr)} page(s) with < {self.min_text_threshold} chars. Applying OCR...")
        
        try:
            # Extract text from PDF using OCR (only for pages that need it)
            ocr_results = openai_ocr_extract(str(file_path), page_numbers=pages_needing_ocr)
            
            # Update only the pages that needed OCR
            for page_num in pages_needing_ocr:
                if page_num in ocr_results:
                    ocr_text = ocr_results[page_num]
                    if ocr_text and not ocr_text.startswith("ERROR:"):
                        updated_pages[page_num] = ocr_text
                        logger.info(f"Applied OCR to page {page_num} (extracted {len(ocr_text)} chars)")
                    else:
                        logger.warning(f"OCR failed for page {page_num}: {ocr_text}")
            
            # Rebuild combined text
            combined_text = "\n\n".join([text for text in updated_pages.values() if text.strip()])
            
            result["text"] = combined_text
            result["pages"] = updated_pages
            result["method_used"] = result.get("method_used", "unknown") + "_with_ocr"
            
            # Re-chunk if chunking was enabled and we have chunks
            if self.enable_chunking and TEXT_SPLITTER_AVAILABLE and "chunks" in result:
                try:
                    # Recreate documents from updated pages for re-chunking
                    from langchain_core.documents import Document
                    updated_documents = []
                    for page_num in sorted(updated_pages.keys()):
                        page_text = updated_pages[page_num]
                        doc_metadata = result.get("metadata", {}).copy()
                        doc_metadata["page"] = page_num
                        updated_documents.append(Document(page_content=page_text, metadata=doc_metadata))
                    
                    result["chunks"] = self._chunk_documents(updated_documents)
                    logger.info(f"Re-chunked documents after OCR: {len(result['chunks'])} chunks")
                except Exception as e:
                    logger.warning(f"Failed to re-chunk after OCR: {e}")
            
            return result
            
        except Exception as e:
            logger.warning(f"Failed to apply OCR for short pages: {e}")
            return result
    
    def _extract_with_pdfplumber(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using pdfplumber (best for complex layouts)."""
        import pdfplumber
        
        pages_dict = {}
        metadata = {}
        
        with pdfplumber.open(file_path) as pdf:
            metadata = {
                "page_count": len(pdf.pages),
                "metadata": pdf.metadata or {}
            }
            
            for page_num, page in enumerate(pdf.pages, start=1):
                page_text = page.extract_text() or ""
                pages_dict[page_num] = page_text
        
        # Combine all pages for backward compatibility
        combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
        
        # Create documents for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                documents = []
                for page_num in sorted(pages_dict.keys()):
                    page_text = pages_dict[page_num]
                    doc_metadata = metadata.copy()
                    doc_metadata["page"] = page_num
                    documents.append(Document(page_content=page_text, metadata=doc_metadata))
                
                chunks = self._chunk_documents(documents)
                logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
            except Exception as e:
                logger.warning(f"Failed to chunk documents: {e}")
        
        result = {
            "text": combined_text,
            "pages": pages_dict,
            "metadata": metadata,
            "page_count": metadata["page_count"],
            "method_used": "pdfplumber"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _extract_with_pypdf2(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using PyPDF2 (fast, simple PDFs)."""
        import PyPDF2
        
        pages_dict = {}
        metadata = {}
        
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            metadata = {
                "page_count": len(pdf_reader.pages),
                "metadata": pdf_reader.metadata or {}
            }
            
            for page_num, page in enumerate(pdf_reader.pages, start=1):
                page_text = page.extract_text() or ""
                pages_dict[page_num] = page_text
        
        # Combine all pages for backward compatibility
        combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
        
        # Create documents for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                documents = []
                for page_num in sorted(pages_dict.keys()):
                    page_text = pages_dict[page_num]
                    doc_metadata = metadata.copy()
                    doc_metadata["page"] = page_num
                    documents.append(Document(page_content=page_text, metadata=doc_metadata))
                
                chunks = self._chunk_documents(documents)
                logger.info(f"Created {len(chunks)} chunks from {len(documents)} pages")
            except Exception as e:
                logger.warning(f"Failed to chunk documents: {e}")
        
        result = {
            "text": combined_text,
            "pages": pages_dict,
            "metadata": metadata,
            "page_count": metadata["page_count"],
            "method_used": "pypdf2"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _extract_with_pytesseract_ocr(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using Pytesseract OCR (for scanned PDFs)."""
        try:
            from pdf2image import convert_from_path
        except ImportError:
            raise ImportError("pdf2image required for OCR. Install: pip install pdf2image")
        
        import pytesseract  # type: ignore
        
        # Convert PDF to images
        images = convert_from_path(file_path)
        
        pages_dict = {}
        for page_num, image in enumerate(images, start=1):
            # Extract text from image using OCR
            page_text = pytesseract.image_to_string(image)
            pages_dict[page_num] = page_text
        
        # Combine all pages for backward compatibility
        combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
        
        # Create documents for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                documents = []
                metadata = {"page_count": len(images)}
                for page_num in sorted(pages_dict.keys()):
                    page_text = pages_dict[page_num]
                    if page_text.strip():
                        doc_metadata = metadata.copy()
                        doc_metadata["page"] = page_num
                        documents.append(Document(page_content=page_text, metadata=doc_metadata))
                
                if documents:
                    chunks = self._chunk_documents(documents)
                    logger.info(f"Created {len(chunks)} chunks from {len(documents)} OCR pages")
            except Exception as e:
                logger.warning(f"Failed to chunk OCR documents: {e}")
        
        result = {
            "text": combined_text,
            "pages": pages_dict,
            "metadata": {"page_count": len(images)},
            "page_count": len(images),
            "method_used": "pytesseract_ocr"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def _extract_with_openai_ocr(self, file_path: Path) -> Dict[str, Any]:
        """Extract text using OpenAI Vision OCR (for scanned PDFs)."""
        if not OPENAI_OCR_AVAILABLE:
            raise ImportError("OpenAI OCR not available. Check app/utils/ocr.py and OpenAI API configuration.")
        
        logger.info(f"Starting OpenAI Vision OCR extraction for: {file_path}")
        
        # Use the OpenAI Vision-based OCR extraction (returns dict with page numbers as keys)
        pages_dict = openai_ocr_extract(str(file_path))
        page_count = len(pages_dict)
        
        # Log any errors
        for page_num, page_text in pages_dict.items():
            if page_text and page_text.startswith("ERROR:"):
                logger.warning(f"OpenAI OCR failed for page {page_num}: {page_text}")
        
        # Combine all pages for backward compatibility (exclude errors)
        combined_text = "\n\n".join([
            text for text in pages_dict.values() 
            if text and not text.startswith("ERROR:") and text.strip()
        ])
        
        # Create documents for chunking if enabled
        chunks = []
        if self.enable_chunking and TEXT_SPLITTER_AVAILABLE:
            try:
                from langchain_core.documents import Document
                documents = []
                metadata = {"page_count": page_count, "extraction_method": "openai_vision_ocr"}
                for page_num in sorted(pages_dict.keys()):
                    page_text = pages_dict[page_num]
                    # Skip error pages
                    if page_text and not page_text.startswith("ERROR:") and page_text.strip():
                        doc_metadata = metadata.copy()
                        doc_metadata["page"] = page_num
                        documents.append(Document(page_content=page_text, metadata=doc_metadata))
                
                if documents:
                    chunks = self._chunk_documents(documents)
                    logger.info(f"Created {len(chunks)} chunks from {len(documents)} OCR pages")
            except Exception as e:
                logger.warning(f"Failed to chunk OCR documents: {e}")
        
        result = {
            "text": combined_text,
            "pages": pages_dict,
            "metadata": {"page_count": page_count, "extraction_method": "openai_vision_ocr"},
            "page_count": page_count,
            "method_used": "openai_vision_ocr"
        }
        
        if chunks:
            result["chunks"] = chunks
        
        return result
    
    def parse_from_bytes(
        self,
        pdf_bytes: bytes,
        method: str = "auto"
    ) -> Dict[str, Any]:
        """
        Extract text from PDF bytes (for in-memory processing).
        
        Args:
            pdf_bytes: PDF file content as bytes
            method: Extraction method
        
        Returns:
            dict: Same as parse()
        """
        try:
            # Create temporary file-like object
            pdf_buffer = io.BytesIO(pdf_bytes)
            
            if method == "auto" or method == "pdfplumber":
                if PDFPLUMBER_AVAILABLE:
                    try:
                        import pdfplumber
                        pages_dict = {}
                        metadata = {}
                        
                        with pdfplumber.open(pdf_buffer) as pdf:
                            metadata = {
                                "page_count": len(pdf.pages),
                                "metadata": pdf.metadata or {}
                            }
                            
                            for page_num, page in enumerate(pdf.pages, start=1):
                                page_text = page.extract_text() or ""
                                pages_dict[page_num] = page_text
                        
                        # Combine all pages for backward compatibility
                        combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
                        
                        return {
                            "text": combined_text,
                            "pages": pages_dict,
                            "metadata": metadata,
                            "page_count": metadata["page_count"],
                            "method_used": "pdfplumber"
                        }
                    except Exception as e:
                        logger.warning(f"pdfplumber extraction from bytes failed: {e}")
            
            # Fallback to PyPDF2
            if method == "auto" or method == "pypdf2":
                if PYPDF2_AVAILABLE:
                    import PyPDF2
                    
                    pdf_buffer.seek(0)
                    pdf_reader = PyPDF2.PdfReader(pdf_buffer)
                    
                    pages_dict = {}
                    metadata = {
                        "page_count": len(pdf_reader.pages),
                        "metadata": pdf_reader.metadata or {}
                    }
                    
                    for page_num, page in enumerate(pdf_reader.pages, start=1):
                        page_text = page.extract_text() or ""
                        pages_dict[page_num] = page_text
                    
                    # Combine all pages for backward compatibility
                    combined_text = "\n\n".join([text for text in pages_dict.values() if text.strip()])
                    
                    return {
                        "text": combined_text,
                        "pages": pages_dict,
                        "metadata": metadata,
                        "page_count": metadata["page_count"],
                        "method_used": "pypdf2"
                    }
            
            raise RuntimeError("All PDF extraction methods failed for bytes input")
        
        except Exception as e:
            logger.exception("Failed to parse PDF from bytes")
            return {
                "text": "",
                "pages": {},
                "metadata": {"error": str(e)},
                "page_count": 0,
                "method_used": "failed"
            }
    
    @staticmethod
    def is_valid_pdf(file_path: str) -> bool:
        """Check if file is a valid PDF."""
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Normalize extension to handle variant extensions like .pdf_v7
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext != '.pdf':
                return False
            
            # Check PDF header
            with open(file_path, 'rb') as f:
                header = f.read(5)
                return header == b'%PDF-'
        
        except Exception:
            return False

