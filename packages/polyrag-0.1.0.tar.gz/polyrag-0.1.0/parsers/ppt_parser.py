"""
PPT Parser - Extract text from Microsoft PowerPoint presentations.

Supports:
- Text extraction from slides (.pptx format)
- Slide titles and content
- Notes and comments
- Tables within slides
- Slide count and statistics

Note: Only .pptx format (Office 2007+) is supported.
Legacy .ppt format requires additional dependencies.
"""

import logging
import zipfile
from typing import Dict, Any, Optional, List
from pathlib import Path
from app.core.parsers.unified_parser import normalize_extension

try:
    from pptx import Presentation
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False


logger = logging.getLogger(__name__)


class PPTParser:
    """
    PowerPoint text extraction from .pptx files.
    
    Uses python-pptx library to extract text from PowerPoint presentations.
    """
    
    def __init__(self):
        """Initialize PPT parser."""
        if not PPTX_AVAILABLE:
            raise RuntimeError(
                "python-pptx not available. Install: pip install python-pptx"
            )
    
    def parse(self, file_path: str) -> Dict[str, Any]:
        """
        Extract text from PowerPoint file.
        
        Args:
            file_path: Path to PPTX file
        
        Returns:
            dict: {
                "text": str,
                "metadata": dict,
                "slide_count": int,
                "slides": list,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"PowerPoint file not found: {file_path}")
            
            # Normalize extension to handle variant extensions like .pptx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.pptx', '.ppt']:
                raise ValueError(f"Not a PowerPoint file: {file_path}")
            
            # Legacy .ppt format not supported
            if normalized_ext == '.ppt':
                raise ValueError(
                    f"Legacy .ppt format not supported. Please convert to .pptx format: {file_path}"
                )
            
            # Check file size
            file_size = file_path.stat().st_size
            if file_size == 0:
                raise ValueError(f"PowerPoint file is empty: {file_path}")
            
            logger.info(f"Parsing PowerPoint file: {file_path} ({file_size} bytes)")
            
            # Validate that the file is a valid ZIP archive (PPTX files are ZIP archives)
            try:
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    # Check if required PPTX structure exists
                    if 'ppt/presentation.xml' not in zip_ref.namelist():
                        raise ValueError(
                            f"File appears to be a ZIP but not a valid PPTX structure: {file_path}"
                        )
            except zipfile.BadZipFile as e:
                raise ValueError(
                    f"File is not a valid PPTX/ZIP archive (may be corrupted or not a real PPTX file): {file_path}. "
                    f"Error: {str(e)}"
                )
            
            # Load presentation
            prs = Presentation(file_path)
            
            # Extract text from all slides
            text_parts = []
            slides_data = []
            slide_count = 0
            
            for slide_num, slide in enumerate(prs.slides, start=1):
                slide_text_parts = []
                slide_title = ""
                
                # Extract text from shapes
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text.strip():
                        text = shape.text.strip()
                        slide_text_parts.append(text)
                        
                        # Try to identify title
                        if not slide_title and hasattr(shape, "name") and "title" in shape.name.lower():
                            slide_title = text
                
                # Extract notes
                notes_text = ""
                if slide.has_notes_slide:
                    notes_slide = slide.notes_slide
                    if notes_slide.notes_text_frame:
                        notes_text = notes_slide.notes_text_frame.text.strip()
                
                # Combine slide content
                slide_content = "\n".join(slide_text_parts)
                
                if slide_content or notes_text:
                    slide_count += 1
                    
                    # Format slide text
                    slide_header = f"=== Slide {slide_num} ==="
                    if slide_title:
                        slide_header += f" {slide_title}"
                    
                    slide_full_text = [slide_header]
                    if slide_content:
                        slide_full_text.append(slide_content)
                    if notes_text:
                        slide_full_text.append(f"\nNotes: {notes_text}")
                    
                    formatted_slide = "\n".join(slide_full_text)
                    text_parts.append(formatted_slide)
                    
                    # Store slide data
                    slides_data.append({
                        "slide_number": slide_num,
                        "title": slide_title or f"Slide {slide_num}",
                        "content": slide_content,
                        "notes": notes_text
                    })
            
            # Extract core properties (metadata)
            metadata = self._extract_metadata(prs)
            metadata["slide_count"] = slide_count
            metadata["total_slides"] = len(prs.slides)
            
            combined_text = "\n\n".join(text_parts)
            
            return {
                "text": combined_text,
                "metadata": metadata,
                "slide_count": slide_count,
                "slides": slides_data,
                "method_used": "python-pptx"
            }
        
        except Exception as e:
            logger.exception(f"Failed to parse PowerPoint: {file_path}")
            return {
                "text": "",
                "metadata": {"error": str(e)},
                "slide_count": 0,
                "slides": [],
                "method_used": "failed"
            }
    
    def _extract_metadata(self, prs: 'Presentation') -> Dict[str, Any]:
        """
        Extract presentation metadata/properties.
        
        Args:
            prs: Presentation object
        
        Returns:
            dict: Metadata dictionary
        """
        try:
            core_props = prs.core_properties
            
            return {
                "author": core_props.author or "",
                "title": core_props.title or "",
                "subject": core_props.subject or "",
                "created": str(core_props.created) if core_props.created else "",
                "modified": str(core_props.modified) if core_props.modified else "",
                "last_modified_by": core_props.last_modified_by or "",
                "revision": core_props.revision or 0,
                "category": core_props.category or "",
                "comments": core_props.comments or ""
            }
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return {}
    
    @staticmethod
    def is_valid_pptx(file_path: str) -> bool:
        """
        Check if file is a valid PPTX file.
        
        Args:
            file_path: Path to file
        
        Returns:
            bool: True if valid PPTX
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Normalize extension to handle variant extensions like .pptx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext != '.pptx':
                return False
            
            # Check file size
            if file_path.stat().st_size == 0:
                return False
            
            # Validate ZIP structure
            try:
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    if 'ppt/presentation.xml' not in zip_ref.namelist():
                        return False
            except zipfile.BadZipFile:
                return False
            
            # Try to open as Presentation
            if PPTX_AVAILABLE:
                from pptx import Presentation
                Presentation(file_path)
                return True
            
            return False
        
        except Exception:
            return False

