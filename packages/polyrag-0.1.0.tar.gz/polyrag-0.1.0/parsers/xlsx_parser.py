"""
XLSX Parser - Extract data from Microsoft Excel spreadsheets.

Supports:
- Multiple sheets
- Formulas and values
- Cell formatting
- Tables and named ranges
"""

import logging
from typing import Dict, Any, Optional, List
from pathlib import Path
from app.core.parsers.unified_parser import normalize_extension

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

try:
    import openpyxl
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False


logger = logging.getLogger(__name__)


class XLSXParser:
    """
    XLSX data extraction from Excel spreadsheets.
    
    Uses pandas for efficient reading, with openpyxl as engine.
    Can extract data from multiple sheets.
    """
    
    def __init__(
        self,
        sheet_name: Optional[str] = None,
        read_all_sheets: bool = True
    ):
        """
        Initialize XLSX parser.
        
        Args:
            sheet_name: Specific sheet to read (None for first sheet)
            read_all_sheets: If True, read all sheets; if False, read only first/specified sheet
        """
        if not PANDAS_AVAILABLE and not OPENPYXL_AVAILABLE:
            raise RuntimeError(
                "pandas or openpyxl not available. Install: pip install pandas openpyxl"
            )
        
        self.sheet_name = sheet_name
        self.read_all_sheets = read_all_sheets
    
    def parse(
        self,
        file_path: str,
        max_rows: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Extract data from XLSX file.
        
        Args:
            file_path: Path to XLSX file
            max_rows: Maximum number of rows to read per sheet (None for all)
        
        Returns:
            dict: {
                "text": str (formatted text from all sheets),
                "sheets": dict (sheet_name -> data dict),
                "metadata": dict,
                "sheet_count": int,
                "total_row_count": int,
                "method_used": str
            }
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"XLSX file not found: {file_path}")
            
            # Normalize extension to handle variant extensions like .xlsx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.xlsx', '.xlsm', '.xls']:
                raise ValueError(f"Not an Excel file: {file_path}")
            
            # Use pandas for parsing
            if PANDAS_AVAILABLE:
                return self._parse_with_pandas(file_path, max_rows)
            elif OPENPYXL_AVAILABLE:
                return self._parse_with_openpyxl(file_path, max_rows)
            else:
                raise RuntimeError("No Excel parsing library available")
        
        except Exception as e:
            logger.exception(f"Failed to parse XLSX: {file_path}")
            return {
                "text": "",
                "sheets": {},
                "metadata": {"error": str(e)},
                "sheet_count": 0,
                "total_row_count": 0,
                "method_used": "failed"
            }
    
    def _parse_with_pandas(
        self,
        file_path: Path,
        max_rows: Optional[int]
    ) -> Dict[str, Any]:
        """Parse XLSX using pandas (preferred method)."""
        try:
            # Read Excel file
            if self.read_all_sheets:
                # Read all sheets into a dict of DataFrames
                excel_data = pd.read_excel(
                    file_path,
                    sheet_name=None,  # Read all sheets
                    nrows=max_rows,
                    engine='openpyxl'
                )
            else:
                # Read single sheet
                sheet_to_read = self.sheet_name or 0  # First sheet by default
                df = pd.read_excel(
                    file_path,
                    sheet_name=sheet_to_read,
                    nrows=max_rows,
                    engine='openpyxl'
                )
                excel_data = {sheet_to_read if isinstance(sheet_to_read, str) else 'Sheet1': df}
            
            # Process each sheet
            sheets = {}
            text_parts = []
            total_rows = 0
            
            for sheet_name, df in excel_data.items():
                # Reset index to avoid duplicate index errors
                df = df.reset_index(drop=True)
                # Convert to text
                sheet_text = df.to_string(index=False)
                text_parts.append(f"=== Sheet: {sheet_name} ===\n{sheet_text}")
                
                # Convert to list of dicts
                data = df.to_dict('records')
                
                # Get column names
                columns = df.columns.tolist()
                
                sheets[sheet_name] = {
                    "text": sheet_text,
                    "data": data,
                    "columns": columns,
                    "row_count": len(df),
                    "column_count": len(columns)
                }
                
                total_rows += len(df)
            
            # Extract workbook metadata
            metadata = self._extract_metadata_pandas(file_path)
            metadata["sheet_names"] = list(excel_data.keys())
            
            return {
                "text": "\n\n".join(text_parts),
                "sheets": sheets,
                "metadata": metadata,
                "sheet_count": len(sheets),
                "total_row_count": total_rows,
                "method_used": "pandas"
            }
        
        except Exception as e:
            logger.exception(f"Pandas XLSX parsing failed: {file_path}")
            # Try openpyxl fallback
            if OPENPYXL_AVAILABLE:
                return self._parse_with_openpyxl(file_path, max_rows)
            raise
    
    def _parse_with_openpyxl(
        self,
        file_path: Path,
        max_rows: Optional[int]
    ) -> Dict[str, Any]:
        """Parse XLSX using openpyxl (fallback method)."""
        try:
            from openpyxl import load_workbook
            
            # Load workbook
            wb = load_workbook(filename=file_path, read_only=True, data_only=True)
            
            sheets = {}
            text_parts = []
            total_rows = 0
            
            # Determine which sheets to read
            if self.read_all_sheets:
                sheet_names = wb.sheetnames
            else:
                sheet_names = [self.sheet_name] if self.sheet_name else [wb.sheetnames[0]]
            
            for sheet_name in sheet_names:
                ws = wb[sheet_name]
                
                # Extract data
                rows = []
                headers = []
                
                for i, row in enumerate(ws.iter_rows(values_only=True)):
                    if max_rows and i >= max_rows + 1:  # +1 for header
                        break
                    
                    if i == 0:
                        # Assume first row is headers
                        headers = [str(cell) if cell is not None else f"Column_{j}" 
                                  for j, cell in enumerate(row)]
                    else:
                        rows.append(row)
                
                # Convert to text
                text_lines = [" | ".join(headers)]
                text_lines.append("-" * 50)
                
                for row in rows:
                    text_lines.append(" | ".join(str(cell) if cell is not None else "" 
                                                 for cell in row))
                
                sheet_text = "\n".join(text_lines)
                text_parts.append(f"=== Sheet: {sheet_name} ===\n{sheet_text}")
                
                # Convert to list of dicts
                data = []
                for row in rows:
                    row_dict = {}
                    for j, cell in enumerate(row):
                        header = headers[j] if j < len(headers) else f"Column_{j}"
                        row_dict[header] = cell
                    data.append(row_dict)
                
                sheets[sheet_name] = {
                    "text": sheet_text,
                    "data": data,
                    "columns": headers,
                    "row_count": len(rows),
                    "column_count": len(headers)
                }
                
                total_rows += len(rows)
            
            # Extract metadata
            metadata = self._extract_metadata_openpyxl(wb)
            metadata["sheet_names"] = list(sheets.keys())
            
            wb.close()
            
            return {
                "text": "\n\n".join(text_parts),
                "sheets": sheets,
                "metadata": metadata,
                "sheet_count": len(sheets),
                "total_row_count": total_rows,
                "method_used": "openpyxl"
            }
        
        except Exception as e:
            logger.exception(f"Openpyxl XLSX parsing failed: {file_path}")
            raise
    
    def _extract_metadata_pandas(self, file_path: Path) -> Dict[str, Any]:
        """
        Extract workbook metadata using openpyxl.
        
        Args:
            file_path: Path to Excel file
        
        Returns:
            dict: Metadata dictionary
        """
        try:
            if not OPENPYXL_AVAILABLE:
                return {}
            
            from openpyxl import load_workbook
            
            wb = load_workbook(filename=file_path, read_only=True)
            props = wb.properties
            
            metadata = {
                "title": props.title or "",
                "creator": props.creator or "",
                "created": str(props.created) if props.created else "",
                "modified": str(props.modified) if props.modified else "",
                "last_modified_by": props.lastModifiedBy or "",
                "subject": props.subject or "",
                "description": props.description or "",
                "category": props.category or ""
            }
            
            wb.close()
            return metadata
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return {}
    
    def _extract_metadata_openpyxl(self, workbook) -> Dict[str, Any]:
        """
        Extract metadata from openpyxl workbook object.
        
        Args:
            workbook: Openpyxl workbook
        
        Returns:
            dict: Metadata dictionary
        """
        try:
            props = workbook.properties
            
            return {
                "title": props.title or "",
                "creator": props.creator or "",
                "created": str(props.created) if props.created else "",
                "modified": str(props.modified) if props.modified else "",
                "last_modified_by": props.lastModifiedBy or "",
                "subject": props.subject or "",
                "description": props.description or "",
                "category": props.category or ""
            }
        
        except Exception as e:
            logger.warning(f"Failed to extract metadata: {e}")
            return {}
    
    @staticmethod
    def is_valid_xlsx(file_path: str) -> bool:
        """
        Check if file is a valid XLSX file.
        
        Args:
            file_path: Path to file
        
        Returns:
            bool: True if valid XLSX
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                return False
            
            # Normalize extension to handle variant extensions like .xlsx_v2
            normalized_ext = normalize_extension(file_path.suffix)
            if normalized_ext not in ['.xlsx', '.xlsm', '.xls']:
                return False
            
            # Try to open with openpyxl or pandas
            if OPENPYXL_AVAILABLE:
                from openpyxl import load_workbook
                wb = load_workbook(filename=file_path, read_only=True)
                wb.close()
                return True
            elif PANDAS_AVAILABLE:
                pd.read_excel(file_path, nrows=1)
                return True
            
            return False
        
        except Exception:
            return False

