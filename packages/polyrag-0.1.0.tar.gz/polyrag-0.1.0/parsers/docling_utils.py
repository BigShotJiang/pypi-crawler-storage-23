#!/usr/bin/env python3
from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

import pandas as pd

from docling.datamodel.base_models import InputFormat
from docling.datamodel.pipeline_options import ConvertPipelineOptions, PdfPipelineOptions
from docling.document_converter import (
    DocumentConverter,
    MarkdownFormatOption,
    PdfFormatOption,
    PowerpointFormatOption,
    WordFormatOption,
)

# Optional: CSV/XLSX support (present in newer Docling builds)
try:
    from docling.document_converter import CsvFormatOption, ExcelFormatOption  # type: ignore
except Exception:
    CsvFormatOption = None  # type: ignore
    ExcelFormatOption = None  # type: ignore

# TableFormerMode exists in newer Docling versions; keep optional for compatibility.
try:
    from docling.datamodel.pipeline_options import TableFormerMode  # type: ignore
except Exception:
    TableFormerMode = None  # type: ignore

# Optional: LangChain Document
try:
    from langchain_core.documents import Document as LCDocument  # type: ignore
except Exception:
    try:
        from langchain.schema import Document as LCDocument  # type: ignore
    except Exception:
        LCDocument = None  # type: ignore

logger = logging.getLogger(__name__)


SUPPORTED_EXTS = {
    ".pdf",
    ".docx",
    ".pptx",
    ".ppt",
    ".md",
    ".txt",
    ".xlsx",
    ".xlsm",
    ".csv",
}

# PDF table extraction tuning:
DO_CELL_MATCHING = True
FAST_TABLES = False


@dataclass
class TableResult:
    table_index: int
    page_no: Optional[int]
    markdown: str
    html: str
    dataframe: pd.DataFrame


@dataclass
class ParsedDocResult:
    source_path: Path
    full_markdown: str
    page_docs: List[Any]  # LangChain Document if installed, else dict
    table_docs: List[Any]  # LangChain Document if installed, else dict
    tables: List[TableResult]
    docling_document: Any  # keep if you want to do more downstream
    merged_tables: Optional[Dict[str, pd.DataFrame]] = None  # Tables merged by matching headers


def _which_soffice() -> Optional[str]:
    return shutil.which("soffice") or shutil.which("libreoffice")


def _convert_ppt_to_pptx(ppt_path: Path) -> Path:
    """Convert legacy .ppt to .pptx using LibreOffice headless mode (local)."""
    soffice = _which_soffice()
    if not soffice:
        raise RuntimeError(
            f"Cannot process {ppt_path.name}: .ppt is legacy; Docling supports .pptx. "
            f"Install LibreOffice and ensure 'soffice' is on PATH, or convert to .pptx."
        )

    out_dir = ppt_path.parent
    cmd = [
        soffice,
        "--headless",
        "--convert-to",
        "pptx",
        "--outdir",
        str(out_dir),
        str(ppt_path),
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    converted = out_dir / f"{ppt_path.stem}.pptx"
    if not converted.exists():
        raise RuntimeError(f"LibreOffice conversion ran, but did not produce: {converted}")
    return converted


def _gather_inputs(paths: List[Union[str, Path]]) -> List[Path]:
    out: List[Path] = []
    for raw in paths:
        p = Path(raw).expanduser().resolve()
        from app.core.parsers.unified_parser import normalize_extension
        if p.is_dir():
            for f in p.rglob("*"):
                normalized_ext = normalize_extension(f.suffix)
                if f.is_file() and normalized_ext in SUPPORTED_EXTS:
                    out.append(f)
        else:
            normalized_ext = normalize_extension(p.suffix)
            if p.is_file() and normalized_ext in SUPPORTED_EXTS:
                out.append(p)
    return out


def _safe_set_tableformer_mode(pdf_opts: PdfPipelineOptions, fast: bool) -> None:
    if TableFormerMode is None:
        return
    tso = getattr(pdf_opts, "table_structure_options", None)
    if tso is None or not hasattr(tso, "mode"):
        return
    tso.mode = TableFormerMode.FAST if fast else TableFormerMode.ACCURATE  # type: ignore


def _safe_set_cell_matching(pdf_opts: PdfPipelineOptions, do_cell_matching: bool) -> None:
    tso = getattr(pdf_opts, "table_structure_options", None)
    if tso is None or not hasattr(tso, "do_cell_matching"):
        return
    tso.do_cell_matching = do_cell_matching


def _safe_set_local_only(opts_obj: Any) -> None:
    """
    Best-effort "local only" across Docling versions.
    (Docling may still download model weights to local cache on first run.)
    """
    if hasattr(opts_obj, "enable_remote_services"):
        setattr(opts_obj, "enable_remote_services", False)
    if hasattr(opts_obj, "allow_external_plugins"):
        setattr(opts_obj, "allow_external_plugins", False)
    if hasattr(opts_obj, "do_picture_classification"):
        setattr(opts_obj, "do_picture_classification", False)
    if hasattr(opts_obj, "do_picture_description"):
        setattr(opts_obj, "do_picture_description", False)


def build_converter(*, ocr: bool, table_structure: bool, fast_tables: bool) -> DocumentConverter:
    simple_opts = ConvertPipelineOptions()
    _safe_set_local_only(simple_opts)

    pdf_opts = PdfPipelineOptions(do_ocr=ocr, do_table_structure=table_structure)
    _safe_set_local_only(pdf_opts)

    _safe_set_tableformer_mode(pdf_opts, fast=fast_tables)
    _safe_set_cell_matching(pdf_opts, do_cell_matching=DO_CELL_MATCHING)

    allowed_formats = [InputFormat.PDF, InputFormat.DOCX, InputFormat.PPTX, InputFormat.MD]
    format_options: Dict[InputFormat, Any] = {
        InputFormat.PDF: PdfFormatOption(pipeline_options=pdf_opts),
        InputFormat.DOCX: WordFormatOption(pipeline_options=simple_opts),
        InputFormat.PPTX: PowerpointFormatOption(pipeline_options=simple_opts),
        InputFormat.MD: MarkdownFormatOption(pipeline_options=simple_opts),
    }

    # Optional CSV/XLSX
    if CsvFormatOption is not None and hasattr(InputFormat, "CSV"):
        allowed_formats.append(InputFormat.CSV)
        format_options[InputFormat.CSV] = CsvFormatOption(pipeline_options=simple_opts)  # type: ignore
    if ExcelFormatOption is not None and hasattr(InputFormat, "XLSX"):
        allowed_formats.append(InputFormat.XLSX)
        format_options[InputFormat.XLSX] = ExcelFormatOption(pipeline_options=simple_opts)  # type: ignore

    return DocumentConverter(allowed_formats=allowed_formats, format_options=format_options)


def _make_lc_doc(page_content: str, metadata: Dict[str, Any]) -> Any:
    if LCDocument is None:
        return {"page_content": page_content, "metadata": metadata}
    return LCDocument(page_content=page_content, metadata=metadata)


def _get_page_nos(doc: Any) -> List[int]:
    """
    Prefer doc.pages keys when present; otherwise try doc.num_pages(); otherwise single-page fallback.
    """
    pages_obj = getattr(doc, "pages", None)
    if isinstance(pages_obj, dict) and pages_obj:
        # Usually keyed by real page numbers for PDFs; for other formats may be empty.
        return sorted(int(k) for k in pages_obj.keys())
    if hasattr(doc, "num_pages"):
        try:
            n = int(doc.num_pages())
            if n > 0:
                return list(range(1, n + 1))
        except Exception:
            pass
    return []


def _text_labels() -> Optional[set]:
    """
    Try to include only text-ish labels in per-page exports (skip TABLE/PICTURE).
    If API path differs across versions, return None (Docling defaults apply).
    """
    try:
        from docling.datamodel.docling_document import DocItemLabel  # type: ignore
    except Exception:
        try:
            from docling.datamodel.document import DocItemLabel  # type: ignore
        except Exception:
            return None

    return {
        DocItemLabel.TITLE,
        DocItemLabel.SECTION_HEADER,
        DocItemLabel.PARAGRAPH,
        DocItemLabel.TEXT,
        DocItemLabel.LIST_ITEM,
        DocItemLabel.CODE,
        DocItemLabel.FOOTNOTE,
        DocItemLabel.REFERENCE,
        DocItemLabel.CAPTION,
        DocItemLabel.PAGE_HEADER,
        DocItemLabel.PAGE_FOOTER,
    }


def _strip_trailing_pagebreak_noise(md: str) -> str:
    # Some Docling versions may append many page-break markers when using page_no.
    # Make it safe by trimming repeated tail markers.
    tail = "\n\n---\n\n"
    while md.endswith(tail):
        md = md[: -len(tail)]
    return md


def _normalize_column_names(columns: List[str]) -> Tuple[str, ...]:
    """
    Normalize column names for comparison by lowercasing and stripping whitespace.
    Returns tuple for hashable comparison.
    """
    return tuple(str(col).lower().strip() for col in columns)


def merge_tables_by_headers(tables: List[TableResult]) -> Dict[str, pd.DataFrame]:
    """
    Merge tables that have matching column headers across different pages.
    
    Args:
        tables: List of TableResult objects extracted from document
        
    Returns:
        Dictionary mapping header signature to merged DataFrame
        
    Example:
        If page 1 has table with headers ["Item", "Price", "Qty"]
        and page 3 has table with headers ["Item", "Price", "Qty"],
        they will be merged into one DataFrame with all rows.
    """
    if not tables:
        return {}
    
    # Group tables by normalized header signature
    header_groups: Dict[Tuple[str, ...], List[TableResult]] = {}
    
    for table in tables:
        # Skip empty tables
        if table.dataframe.empty:
            continue
            
        columns = table.dataframe.columns.tolist()
        
        # Need at least one column to merge
        if not columns:
            continue
            
        header_sig = _normalize_column_names(columns)
        header_groups.setdefault(header_sig, []).append(table)
    
    # Merge tables in each group
    merged_tables: Dict[str, pd.DataFrame] = {}
    
    for header_sig, table_group in header_groups.items():
        # Only merge if we have multiple tables with same headers
        if len(table_group) < 2:
            continue
            
        # Sort by page number (None goes last)
        table_group.sort(key=lambda t: (t.page_no is None, t.page_no or 0))
        
        # Use original column names from first table (preserves casing)
        original_columns = table_group[0].dataframe.columns.tolist()
        
        # Concatenate all dataframes
        import logging
        logger = logging.getLogger(__name__)
        
        dfs_to_merge = [t.dataframe.reset_index(drop=True) for t in table_group]
        
        # Double-check all DataFrames have clean indices
        for i, df in enumerate(dfs_to_merge):
            if df.index.duplicated().any():
                logger.warning(f"⚠️  dfs_to_merge[{i}] has duplicate indices, resetting...")
                dfs_to_merge[i] = df.reset_index(drop=True)
        
        merged_df = pd.concat(dfs_to_merge, ignore_index=True)
        
        # Create descriptive key
        page_list = [str(t.page_no) for t in table_group if t.page_no is not None]
        if page_list:
            key = f"merged_table_pages_{'_'.join(page_list)}_{original_columns[0]}"
        else:
            key = f"merged_table_{original_columns[0]}"
        
        # Sanitize key (remove special chars)
        key = key.replace(" ", "_").replace("/", "_").replace("\\", "_")
        
        merged_tables[key] = merged_df
    
    return merged_tables


def _convert_path(converter: DocumentConverter, src: Path) -> Tuple[str, Any, Path]:
    from app.core.parsers.unified_parser import normalize_extension
    ext = normalize_extension(src.suffix)

    # Handle .ppt -> .pptx (local)
    if ext == ".ppt":
        src = _convert_ppt_to_pptx(src)
        ext = ".pptx"

    if ext == ".txt":
        content = src.read_text(encoding="utf-8", errors="replace")
        name_for_logs = src.with_suffix(".md").name
        res = converter.convert_string(content=content, format=InputFormat.MD, name=name_for_logs)
    else:
        res = converter.convert(src, raises_on_error=False)

    if getattr(res, "document", None) is None:
        status = str(getattr(res, "status", "UNKNOWN"))
        errs = getattr(res, "errors", None)
        raise RuntimeError(f"{src.name}: conversion failed (status={status}) errors={errs}")

    doc = res.document
    full_md = doc.export_to_markdown()
    return full_md, doc, src


def parse_documents_in_memory(
    paths: List[Union[str, Path]],
    *,
    ocr: bool = True,
    do_table_structure: bool = True,
    fast_tables: bool = FAST_TABLES,
    merge_tables_with_same_headers: bool = False,
) -> List[ParsedDocResult]:
    """
    Pass file/dir paths in; returns per-file results:
      - page_docs: LangChain Document per page (or single doc if no pagination)
      - table_docs: LangChain Document per table (markdown)
      - tables: TableResult list (df/html/md) kept in memory
      - merged_tables: Optional dict of merged tables by matching headers
    No files are written.
    
    Args:
        paths: List of file/directory paths to process
        ocr: Enable OCR for scanned PDFs
        do_table_structure: Extract table structure
        fast_tables: Use fast mode for table extraction (less accurate)
        merge_tables_with_same_headers: Merge tables across pages if they have matching column headers
    """
    converter = build_converter(ocr=ocr, table_structure=do_table_structure, fast_tables=fast_tables)

    files = _gather_inputs(paths)
    if not files:
        return []

    labels = _text_labels()
    results: List[ParsedDocResult] = []

    for src in files:
        full_md, doc, effective_src = _convert_path(converter, src)

        # Per-page docs
        page_nos = _get_page_nos(doc)
        page_docs: List[Any] = []
        if not page_nos:
            # Formats like DOCX/MD/TXT often don't have stable pagination -> treat as one page.
            md = doc.export_to_markdown(labels=labels)
            meta = {
                "doc_type": "page",
                "file_name": effective_src.name,
                "source_path": str(effective_src),
                "page_no": 1,
                "page_index": 1,
            }
            page_docs.append(_make_lc_doc(md, meta))
        else:
            for idx, page_no in enumerate(page_nos, start=1):
                md = doc.export_to_markdown(labels=labels, page_no=int(page_no))
                md = _strip_trailing_pagebreak_noise(md)
                meta = {
                    "doc_type": "page",
                    "file_name": effective_src.name,
                    "source_path": str(effective_src),
                    "page_no": int(page_no),
                    "page_index": idx,
                }
                page_docs.append(_make_lc_doc(md, meta))

        # Tables (separate)
        tables: List[TableResult] = []
        table_docs: List[Any] = []
        tables_attr = getattr(doc, "tables", [])
        if callable(tables_attr):
            logger.warning(
                "Docling doc.tables is callable (type=%s) for %s",
                type(tables_attr),
                effective_src.name,
            )
        for t_idx, table in enumerate(tables_attr or [], start=1):
            # Table exporters want the full document context.
            df: pd.DataFrame = table.export_to_dataframe(doc=doc)
            md_t = table.export_to_markdown(doc=doc)
            html_t = table.export_to_html(doc=doc)

            # Best-effort page number from provenance
            page_no: Optional[int] = None
            prov = getattr(table, "prov", None)
            if prov:
                try:
                    page_no = int(prov[0].page_no)
                except Exception:
                    page_no = None

            tables.append(
                TableResult(
                    table_index=t_idx,
                    page_no=page_no,
                    markdown=md_t,
                    html=html_t,
                    dataframe=df,
                )
            )
            table_docs.append(
                _make_lc_doc(
                    md_t,
                    {
                        "doc_type": "table",
                        "file_name": effective_src.name,
                        "source_path": str(effective_src),
                        "table_index": t_idx,
                        "page_no": page_no,
                        "shape": [int(df.shape[0]), int(df.shape[1])],
                        "columns": [str(c) for c in df.columns.tolist()],
                    },
                )
            )

        # Merge tables with matching headers if requested
        merged_tables_dict: Optional[Dict[str, pd.DataFrame]] = None
        if merge_tables_with_same_headers and tables:
            merged_tables_dict = merge_tables_by_headers(tables)

        results.append(
            ParsedDocResult(
                source_path=effective_src,
                full_markdown=full_md,
                page_docs=page_docs,
                table_docs=table_docs,
                tables=tables,
                docling_document=doc,
                merged_tables=merged_tables_dict,
            )
        )

    return results


# Example usage (no disk writes):
if __name__ == "__main__":
    # Replace with your own list of files/dirs.
    # demo_inputs = [Path(__file__).resolve().parent / "documents"]
    demo_inputs = ["documents/large_multipage_table.pdf"]
    parsed = parse_documents_in_memory(demo_inputs, merge_tables_with_same_headers=True)

    for r in parsed:
        merged_info = f"merged={len(r.merged_tables)}" if r.merged_tables else "merged=0"
        print(
            f"{r.source_path.name}: pages={len(r.page_docs)} tables={len(r.tables)} {merged_info} "
            f"(full_md_chars={len(r.full_markdown)})"
        )
        
        # Show merged table info
        if r.merged_tables:
            for key, df in r.merged_tables.items():
                print(f"  Merged: {key} -> {df.shape[0]} rows x {df.shape[1]} cols")
