"""
LlamaParse extraction helpers.

Provides a single entry point that returns per-page tables and markdown, along
with sheet/page metadata.
"""

from pathlib import Path
from typing import Any, Dict, List, Optional, Set, TYPE_CHECKING
import re
import asyncio
import json
import pandas as pd

# Handle nested event loops for LlamaParse async operations
try:
    import nest_asyncio
    nest_asyncio.apply()
except ImportError:
    # nest_asyncio not available, will handle with fallback
    pass

EXCEL_EXTENSIONS = {".xlsx", ".xls", ".xlsm"}

_PAGE_KEY_RE = re.compile(r"^(page\d+)")
_PAGE_NUMBER_RE = re.compile(r"^page(\d+)$")

if TYPE_CHECKING:
    from langchain_core.documents import Document


def _table_key_to_page_key(table_key: str) -> str:
    match = _PAGE_KEY_RE.match(table_key)
    return match.group(1) if match else "page1"


def _page_number_from_key(page_key: str) -> Optional[int]:
    match = _PAGE_NUMBER_RE.match(page_key)
    return int(match.group(1)) if match else None


def _sorted_page_keys(page_keys: Set[str]) -> List[str]:
    def sort_key(key: str):
        number = _page_number_from_key(key)
        return (number is None, number or 0, key)

    return sorted(page_keys, key=sort_key)


def _group_tables_by_page(table_map: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    page_tables: Dict[str, Dict[str, Any]] = {}
    for key, df in table_map.items():
        page_key = _table_key_to_page_key(key)
        page_tables.setdefault(page_key, {})[key] = df
    return page_tables


def build_page_documents(
    pages: List[Dict[str, Any]],
    file_name: Optional[str],
    file_path: Optional[str] = None,
    document_type: Optional[str] = None,
) -> List["Document"]:
    """
    Convert page markdown into LangChain Document objects with metadata.
    """
    try:
        from langchain_core.documents import Document
    except ImportError as exc:
        raise ImportError(
            "LangChain core is not installed. Install: pip install langchain-core"
        ) from exc

    documents: List["Document"] = []
    for page in pages:
        markdown = (page.get("markdown") or "").strip()
        if not markdown:
            continue
        metadata = {
            "page_number": page.get("page_number"),
            "file_name": file_name,
            "tables": page.get("tables"),
            "tables_llm": page.get("tables_llm"),
            "page_key": page.get("page_key"),
            "sheet_name": page.get("sheet_name"),
            "file_path": file_path,
            "document_type": document_type,
        }
        documents.append(Document(page_content=markdown, metadata=metadata))
    return documents


def chunk_documents(
    documents: List["Document"],
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
) -> List["Document"]:
    """
    Split LangChain Document objects into smaller chunks.
    """
    try:
        from langchain_text_splitters import RecursiveCharacterTextSplitter
    except ImportError as exc:
        raise ImportError(
            "LangChain text splitter is not installed. Install: pip install langchain-text-splitters"
        ) from exc

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        length_function=len,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    return splitter.split_documents(documents)


def extract_tables_and_markdown(
    file_path: str,
    parser_instance=None,
    use_llm_cleanup: bool = False,
    llm_model: Optional[str] = None,
    llm_max_rows: int = 50,
    llm_max_cols: int = 50,
    llm_allow_fallback: bool = False,
    concatenate_matching_headers: bool = True,
) -> Dict[str, Any]:
    """
    Parse a document with LlamaParse and return page/sheet-aware outputs.

    Set use_llm_cleanup=True to run LLM-based cleanup for item tables; cleaned
    tables are returned in pages[*].tables_llm along with llm_cleanup metadata.
    
    Set concatenate_matching_headers=True to merge tables with matching headers
    across different pages (only for non-Excel documents).
    
    Returns:
        {
            "file_name": str,
            "file_path": str,
            "document_type": str,
            "table_count": int,
            "pages": [
                {
                    "page_key": str,
                    "page_number": int | None,
                    "sheet_name": str | None,
                    "markdown": str,
                    "tables": Dict[str, pd.DataFrame],
                    "tables_llm": Dict[str, pd.DataFrame],
                },
                ...
            ],
            "documents": list[Document],
            "merged_tables": Dict[str, pd.DataFrame],  # Tables merged across pages
        }
    """
    from . import utils as llama_utils

    path = Path(file_path)
    docs_parser = parser_instance or llama_utils.parser
    
    # Handle nested event loop issues with LlamaParse
    try:
        docs = docs_parser.parse(str(path))
    except RuntimeError as e:
        error_msg = str(e)
        if "nested async" in error_msg.lower() or "event loop is closed" in error_msg.lower():
            # Try to handle nested event loop by creating a new one
            try:
                # Check if there's an existing event loop
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_closed():
                        # Create new loop if closed
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                except RuntimeError:
                    # No event loop exists, create one
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                
                # Try parsing again
                docs = docs_parser.parse(str(path))
            except Exception as retry_error:
                # If nest_asyncio wasn't applied, try to apply it now
                try:
                    import nest_asyncio
                    nest_asyncio.apply()
                    docs = docs_parser.parse(str(path))
                except Exception as final_error:
                    raise RuntimeError(
                        f"Failed to parse with LlamaParse due to event loop issues. "
                        f"Original error: {error_msg}. Retry error: {retry_error}. "
                        f"Final error: {final_error}. "
                        f"Consider installing nest_asyncio: pip install nest-asyncio"
                    ) from final_error
        else:
            # Re-raise if it's not an event loop error
            raise

    dataframes, table_count, markdown_by_page, page_names = (
        llama_utils.docs_to_outputs_with_page_names(docs)
    )

    # PRINT: Raw LlamaParse parsed table results as DataFrames
    print("\n" + "="*80)
    print("📊 RAW LLAMAPARSE OUTPUT (DataFrames)")
    print("="*80)
    for key, df in dataframes.items():
        print(f"\n--- {key} ---")
        print(f"Shape: {df.shape[0]} rows × {df.shape[1]} columns")
        if len(df) > 0:
            # Show first 20 rows, first 15 columns for readability
            max_rows_to_show = min(20, len(df))
            max_cols_to_show = min(15, len(df.columns))
            preview_df = df.iloc[:max_rows_to_show, :max_cols_to_show]
            print(f"\nFirst {max_rows_to_show} rows, first {max_cols_to_show} columns:")
            # Use pandas display with better formatting
            with pd.option_context('display.max_rows', None, 'display.max_columns', None, 
                                  'display.width', None, 'display.max_colwidth', 50):
                print(preview_df)
            if len(df) > max_rows_to_show:
                print(f"\n... ({len(df) - max_rows_to_show} more rows not shown)")
            if len(df.columns) > max_cols_to_show:
                print(f"... ({len(df.columns) - max_cols_to_show} more columns not shown)")
            print(f"\nAll columns: {list(df.columns)}")
        else:
            print("Empty DataFrame")
    print("="*80)

    page_tables = _group_tables_by_page(dataframes)

    cleaned_tables: Dict[str, Any] = {}
    llm_specs: Dict[str, Any] = {}
    header_map: Dict[str, Any] = {}
    metadata_map: Dict[str, Any] = {}
    merged_tables: Dict[str, Any] = {}
    
    if use_llm_cleanup:
        # Check environment variable for whether to combine table parts
        from .unified_parser import KEEP_TABLE_PARTS_SEPARATE
        combine_parts = not KEEP_TABLE_PARTS_SEPARATE
        
        cleaned_tables, header_map, metadata_map, llm_specs = llama_utils.clean_itemtables_llm(
            dataframes,
            model=llm_model or llama_utils.DEFAULT_LLM_MODEL,
            max_rows=llm_max_rows,
            max_cols=llm_max_cols,
            allow_fallback=llm_allow_fallback,
            combine_parts=combine_parts,
        )
        
        # PRINT: LLM refined tables as DataFrames
        print("\n" + "="*80)
        print("✨ LLM REFINED OUTPUT (DataFrames)")
        print("="*80)
        for key, df in cleaned_tables.items():
            print(f"\n--- {key} ---")
            print(f"Shape: {df.shape[0]} rows × {df.shape[1]} columns")
            if len(df) > 0:
                # Show first 20 rows, first 15 columns for readability
                max_rows_to_show = min(20, len(df))
                max_cols_to_show = min(15, len(df.columns))
                preview_df = df.iloc[:max_rows_to_show, :max_cols_to_show]
                print(f"\nFirst {max_rows_to_show} rows, first {max_cols_to_show} columns:")
                # Use pandas display with better formatting
                with pd.option_context('display.max_rows', None, 'display.max_columns', None, 
                                      'display.width', None, 'display.max_colwidth', 50):
                    print(preview_df)
                if len(df) > max_rows_to_show:
                    print(f"\n... ({len(df) - max_rows_to_show} more rows not shown)")
                if len(df.columns) > max_cols_to_show:
                    print(f"... ({len(df.columns) - max_cols_to_show} more columns not shown)")
                print(f"\nAll columns: {list(df.columns)}")
            else:
                print("Empty DataFrame")
        print("="*80 + "\n")
        
        # Concatenate tables with matching headers (only for non-Excel documents)
        from app.core.parsers.unified_parser import normalize_extension
        normalized_ext = normalize_extension(path.suffix)
        is_excel = normalized_ext in EXCEL_EXTENSIONS
        if concatenate_matching_headers and not is_excel and cleaned_tables:
            merged_tables = llama_utils.concatenate_tables_by_headers(
                cleaned_tables, 
                header_map
            )

    page_tables_llm = _group_tables_by_page(cleaned_tables) if cleaned_tables else {}

    markdown_page_keys = {key.replace("_markdown", "") for key in markdown_by_page.keys()}
    page_keys = set(page_names.keys()) | set(page_tables.keys()) | markdown_page_keys

    from app.core.parsers.unified_parser import normalize_extension
    normalized_ext = normalize_extension(path.suffix)
    is_excel = normalized_ext in EXCEL_EXTENSIONS

    pages = []
    for page_key in _sorted_page_keys(page_keys):
        page_number = _page_number_from_key(page_key)
        page_label = page_names.get(page_key, page_key)
        markdown = markdown_by_page.get(f"{page_key}_markdown", "")

        tables = page_tables.get(page_key, {})
        tables_llm = page_tables_llm.get(page_key, {})
        pages.append(
            {
                "page_key": page_key,
                "page_number": page_number,
                "sheet_name": page_label if is_excel else None,
                "markdown": markdown,
                "tables": tables,
                "tables_llm": tables_llm,
            }
        )

    from app.core.parsers.unified_parser import normalize_extension
    normalized_ext = normalize_extension(path.suffix)
    document_type = normalized_ext.lstrip(".")
    
    documents = build_page_documents(
        pages,
        file_name=path.name,
        file_path=str(path),
        document_type=document_type,
    )

    result = {
        "file_name": path.name,
        "file_path": str(path),
        "document_type": document_type,
        "table_count": table_count,
        "pages": pages,
        "documents": documents,
    }

    if use_llm_cleanup:
        result["llm_cleanup"] = {
            "table_count": len(cleaned_tables),
            "header_map": header_map,
            "metadata_map": metadata_map,
            "specs": llm_specs,
        }
    
    # Add merged tables if any were created
    if merged_tables:
        result["merged_tables"] = merged_tables
        result["merged_table_count"] = len(merged_tables)

    return result


##Tables go in pages and also in Langchain Documents
