# doc_pros — Document Intelligence Platform

## Goal

Transform unstructured documents (PDFs, Word files, spreadsheets, etc.) into a **queryable structured database** — then let users ask natural language questions and get precise, SQL-computed answers instead of LLM-hallucinated guesses.

Optionally pair structured extraction with **OpenRAG** — a fully open-source BM25 + FAISS retrieval layer — for semantic and keyword-based document search without any paid APIs.

## Why This Exists (vs. Basic RAG)

Traditional RAG (e.g., OpenSearch + embeddings) retrieves text chunks and asks an LLM to synthesize answers. This fails for:

- **Numerical questions** — "What's the total salary expenditure?" (LLM can't reliably add numbers from chunks)
- **Aggregations** — SUM, AVG, COUNT, MAX, ranking across documents
- **Cross-document comparison** — same entity appearing in 8 yearly reports
- **Consistency** — same question returns different answers depending on which chunks are retrieved

This platform **extracts structured data first**, stores it in typed SQL tables, then uses the LLM only to generate the SQL query — the actual computation is done by the database engine, eliminating hallucination for factual/numerical answers.

For free-text semantic search, **OpenRAG** adds BM25 keyword search (inverted index) and FAISS vector search (HNSW embeddings) as a parallel retrieval layer — both fully open-source.

## Architecture

```
Raw Documents
    |
    v
[parsers/] ─────────────> Unified Parser (Docling / LlamaParse / pdfplumber)
    |
    |─────────────────────────────────────────────────────────────────┐
    v                                                                 v
[structured_data/]                                              [openrag/]
    |── extractor.py ────> LLM-based 3-tier extraction          |── stores/
    |── entity_resolver.py > 5-stage entity resolution          |     |── text_sqlite.py    BM25 (SQLite)
    |── entity_consolidator> Merge into master records          |     |── text_postgres.py  BM25 (Postgres)
    |── storage/         ──> Pluggable SQL backend              |     |── text_mysql.py     BM25 (MySQL)
    |     |── athena      (AWS Athena / Iceberg)                |     |── text_mongodb.py   BM25 (MongoDB)
    |     |── postgres    (PostgreSQL)                          |     └── vector_store.py   FAISS HNSW
    |     |── mysql       (MySQL)                              |── embedding/
    |     └── sqlite      (local)                              |     └── sentence_transformers
    |── query_service.py ──> NL → SQL → results               |── indexer.py   index_file / index_text
    |                                                          |── retriever.py retrieve (hybrid/text/vector)
    v                                                          |── run_index.py CLI
[connectors/] ─────────> MongoDB, Neo4j, AWS SQS             └── run_query.py CLI
    |
    v
[llm/] ─────────────────> OpenAI, Google Gemini providers
    |
    v
[unified_pipeline/] ────> Orchestrate both pipelines (parse once, share text)
```

## Modules

| Module | Purpose |
|--------|---------|
| [parsers/](parsers/) | Multi-format document parsing (PDF, DOCX, XLSX, CSV, PPTX, TXT, XML) |
| [llm/](llm/) | LLM provider abstraction, model management, Pydantic schemas |
| [connectors/](connectors/) | Database connectors (MongoDB, Neo4j, AWS SQS) |
| [structured_data/](structured_data/) | Core pipeline: LLM extraction, entity resolution, pluggable SQL storage, NL querying |
| [openrag/](openrag/) | Open-source BM25 + FAISS retrieval: index and search document chunks |
| [unified_pipeline/](unified_pipeline/) | Flexible orchestration: run structured, RAG, or both with one call |
| [search_algorithms/](search_algorithms/) | Reference BM25, HNSW, TF-IDF implementations |

## Data Flow

**Structured extraction (ingestion):**
```
Document file  ->  Parse to text (pdfplumber / Docling)
               ->  LLM extracts structured rows (entity, metric, date, attribute...)
               ->  Entity resolver links mentions across documents
               ->  Consolidator merges into master records (MongoDB)
               ->  Store typed rows in pluggable SQL backend (Athena / Postgres / MySQL / SQLite)
```

**RAG indexing (OpenRAG):**
```
Document file  ->  Parse to text
               ->  Chunk into overlapping windows (~10k chars, 500 overlap)
               ->  Embed with sentence-transformers (any HuggingFace model)
               ->  Store BM25 inverted index in chosen text backend
               ->  Store embeddings in FAISS IndexHNSWFlat + JSON sidecar
```

**Unified (both together):**
```
Document file  ->  Parse ONCE (shared text)
               ->  Structured extraction  →  entity metadata (names, types, doc_type)
               ->  RAG indexing with entity metadata attached to every chunk
               ->  Query via SQL (precise aggregations) OR vector/BM25 (semantic search)
```

**Querying:**
```
NL question  ->  Extract entity candidates from question
             ->  Resolve against MongoDB entities_master
             ->  LLM generates SQL with entity context
             ->  Execute SQL on chosen backend
             ->  Return precise, computed results

                   OR

NL question  ->  BM25 keyword search + FAISS vector search
             ->  Reciprocal Rank Fusion (RRF) for hybrid results
             ->  Return ranked chunks with full text + metadata
```

## Tech Stack

- **Python 3.13+** with **uv** package manager
- **LLM Providers**: OpenAI (GPT-4o), Google Gemini
- **Document Parsing**: Docling (local), LlamaParse (cloud), pdfplumber
- **Structured Storage**: AWS Athena/Iceberg, PostgreSQL, MySQL, SQLite (pluggable)
- **Entity Master**: MongoDB
- **Graph**: Neo4j (optional)
- **Queue**: AWS SQS for async processing
- **Embeddings**: sentence-transformers (any HuggingFace model, fully open-source)
- **Vector Index**: FAISS IndexHNSWFlat
- **Text Search**: BM25 inverted index (SQLite / PostgreSQL / MySQL / MongoDB)
- **Frameworks**: FastAPI, LangChain, LangGraph, Pydantic

## Setup

```bash
# Install dependencies
uv sync

# Configure environment
cp .env.example .env
# Fill in: OPENAI_API_KEY, mongo_connection_string, AWS credentials, etc.
```

## Quick Start

### Structured Extraction

```python
from structured_data import StructuredDataPipeline

pipeline = StructuredDataPipeline()
result = pipeline.process_file(
    file_path="document.pdf",
    tenant_id="org_123",
    user_id="user_456",
    resource_id="res_789",
)
print(result["extraction_count"])   # number of entities extracted
print(result["document_id"])        # stable doc identifier

# Query extracted data with natural language
from structured_data import StructuredDataQueryService

svc = StructuredDataQueryService()
answer = svc.query("What is the average salary in Engineering?", tenant_id="org_123")
print(answer["rows"])   # precise SQL-computed result
```

Choose your storage backend via `OPENRAG_STORAGE_BACKEND` env var:

```bash
OPENRAG_STORAGE_BACKEND=sqlite   # local SQLite (default for dev)
OPENRAG_STORAGE_BACKEND=postgres # PostgreSQL
OPENRAG_STORAGE_BACKEND=mysql    # MySQL
OPENRAG_STORAGE_BACKEND=athena   # AWS Athena / Iceberg (production)
```

### OpenRAG — Semantic + Keyword Search

```bash
# Index a document (BM25 + FAISS)
python -m openrag.run_index document.pdf \
    --text-backend sqlite \
    --embedding-model all-MiniLM-L6-v2 \
    --verbose

# Hybrid search (BM25 + vector, fused with RRF)
python -m openrag.run_query "engineering salary 2024" \
    --mode hybrid --top-k 5 --show-text

# Text-only (BM25)
python -m openrag.run_query "invoice total amount" --mode text --top-k 5

# Vector-only (FAISS HNSW)
python -m openrag.run_query "compensation benefits" --mode vector --top-k 5
```

Text backends for BM25: `sqlite` (default), `postgres`, `mysql`, `mongodb`.
Embedding models: any model on HuggingFace via sentence-transformers (e.g. `all-MiniLM-L6-v2`, `BAAI/bge-small-en-v1.5`).

```python
from openrag import OpenRAGConfig, OpenRAGIndexer, OpenRAGRetriever

cfg = OpenRAGConfig(
    text_backend="sqlite",
    embedding_model="all-MiniLM-L6-v2",
    retrieval_mode="hybrid",
)
OpenRAGIndexer(cfg).index_file("document.pdf")

retriever = OpenRAGRetriever(cfg)
results = retriever.retrieve("engineering salary", top_k=5)
for r in results:
    print(r["retrieval_score"], r["text"][:120])
    print(r.get("metadata", {}))   # entity_names, entity_types, doc_type (if indexed via unified pipeline)
```

### Unified Pipeline — Structured + RAG Together

Parse once, run both pipelines, share entity metadata as chunk enrichment:

```bash
# Both pipelines (parse once, entity metadata enriches RAG chunks)
python -m unified_pipeline.run_process document.pdf \
    --mode both \
    --tenant-id org_123 --user-id user_456 --resource-id res_789 \
    --text-backend sqlite \
    --embedding-model all-MiniLM-L6-v2 \
    --verbose

# Structured extraction only
python -m unified_pipeline.run_process document.pdf \
    --mode structured-only \
    --tenant-id org_123 --user-id user_456 --resource-id res_789

# RAG indexing only
python -m unified_pipeline.run_process document.pdf \
    --mode rag-only --rag-retrieval hybrid \
    --text-backend sqlite --embedding-model all-MiniLM-L6-v2
```

```python
from unified_pipeline import UnifiedDocumentPipeline, UnifiedPipelineConfig
from openrag import OpenRAGConfig

cfg = UnifiedPipelineConfig(
    enable_structured=True,
    enable_rag=True,
    rag_retrieval_mode="hybrid",
    tenant_id="org_123",
    user_id="user_456",
    resource_id="res_789",
    openrag=OpenRAGConfig(text_backend="sqlite"),
)
pipeline = UnifiedDocumentPipeline(cfg)
result = pipeline.process_file("document.pdf")

print(result["structured"]["extraction_count"])   # entities extracted
print(result["rag"]["chunks_indexed"])            # chunks in BM25 + FAISS
# In "both" mode, both systems share the same document_id
print(result["structured"]["document_id"] == result["rag"]["doc_id"])  # True
```

When running in `both` mode:
- The document is parsed **once** and the text is shared between both pipelines
- Extracted entity names, types, and document type are stored as metadata on every RAG chunk
- Both systems use the same `document_id` so you can filter/query by it in either system

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENRAG_STORAGE_BACKEND` | `athena` | Structured extraction backend: `athena`, `postgres`, `mysql`, `sqlite` |
| `OPENRAG_TEXT_BACKEND` | `sqlite` | RAG BM25 backend: `sqlite`, `postgres`, `mysql`, `mongodb` |
| `OPENRAG_EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | sentence-transformers model for embeddings |
| `OPENRAG_EMBEDDING_DEVICE` | `cpu` | Compute device: `cpu`, `cuda`, `mps` |
| `OPENRAG_FAISS_INDEX_PATH` | `./openrag.faiss` | FAISS binary index file path |
| `OPENRAG_FAISS_METADATA_PATH` | `./openrag_meta.json` | FAISS JSON sidecar path |
| `OPENRAG_RETRIEVAL_MODE` | `hybrid` | Default retrieval mode: `hybrid`, `text`, `vector` |
| `PIPELINE_ENABLE_STRUCTURED` | `true` | Enable structured extraction in unified pipeline |
| `PIPELINE_ENABLE_RAG` | `true` | Enable RAG indexing in unified pipeline |
| `PIPELINE_RAG_RETRIEVAL_MODE` | `hybrid` | Default RAG mode in unified pipeline |
| `PIPELINE_TENANT_ID` | `` | Tenant context for structured pipeline |
| `PIPELINE_USER_ID` | `` | User context for structured pipeline |
| `PIPELINE_RESOURCE_ID` | `` | Resource context for structured pipeline |
