"""
KnowledgeGraphStorage – MERGE-based Neo4j storage for the knowledge graph.

Wraps the existing Neo4jConnector with MERGE operations that guarantee
deduplication at the database level.  Every write uses::

    MERGE (n:Label {id: $id, tenant_id: $tid})
    ON CREATE SET n += $props, n.created_at = datetime()
    ON MATCH  SET n += $props, n.updated_at = datetime()

This means re-processing a document never creates duplicate nodes.
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from connectors.neo4j_connector import Neo4jConnector

logger = logging.getLogger(__name__)


class KnowledgeGraphStorage:
    """MERGE-based Neo4j storage for the knowledge graph."""

    def __init__(self, tenant_id: str):
        self.neo4j = Neo4jConnector(tenant_id=tenant_id)
        self.tenant_id = tenant_id

    # ------------------------------------------------------------------
    # Schema initialisation
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Create constraints and indexes if they don't exist."""
        # Silence Neo4j "already exists" notifications during schema setup
        neo4j_logger = logging.getLogger("neo4j.notifications")
        prev_level = neo4j_logger.level
        neo4j_logger.setLevel(logging.WARNING)

        constraints = [
            "CREATE CONSTRAINT entity_unique IF NOT EXISTS "
            "FOR (e:Entity) REQUIRE (e.entity_id, e.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT event_unique IF NOT EXISTS "
            "FOR (e:Event) REQUIRE (e.event_id, e.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT process_unique IF NOT EXISTS "
            "FOR (p:Process) REQUIRE (p.process_id, p.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT document_unique IF NOT EXISTS "
            "FOR (d:Document) REQUIRE (d.document_id, d.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT process_step_unique IF NOT EXISTS "
            "FOR (s:ProcessStep) REQUIRE (s.step_id, s.tenant_id) IS UNIQUE",
        ]
        indexes = [
            # --- Name lookups (exact + fuzzy resolution) ---
            "CREATE INDEX event_name_idx IF NOT EXISTS "
            "FOR (e:Event) ON (e.name, e.tenant_id)",

            "CREATE INDEX entity_name_idx IF NOT EXISTS "
            "FOR (e:Entity) ON (e.name, e.tenant_id)",

            "CREATE INDEX process_name_idx IF NOT EXISTS "
            "FOR (p:Process) ON (p.name, p.tenant_id)",

            # --- Event type (resolver fetches candidates by type) ---
            "CREATE INDEX event_type_idx IF NOT EXISTS "
            "FOR (e:Event) ON (e.type, e.tenant_id)",

            # --- Event date (resolver: exact name+date match, temporal queries) ---
            "CREATE INDEX event_date_idx IF NOT EXISTS "
            "FOR (e:Event) ON (e.date, e.tenant_id)",

            # --- Event status (filter by planned/in_progress/completed) ---
            "CREATE INDEX event_status_idx IF NOT EXISTS "
            "FOR (e:Event) ON (e.status, e.tenant_id)",

            # --- Entity type (find all PERSONs, ORGANIZATIONs, etc.) ---
            "CREATE INDEX entity_type_idx IF NOT EXISTS "
            "FOR (e:Entity) ON (e.type, e.tenant_id)",

            # --- Document file_name (quick lookup by filename) ---
            "CREATE INDEX document_filename_idx IF NOT EXISTS "
            "FOR (d:Document) ON (d.file_name, d.tenant_id)",

            # --- Full-text search on event names + descriptions ---
            # Enables: CALL db.index.fulltext.queryNodes('event_fulltext', 'drug approval')
            "CREATE FULLTEXT INDEX event_fulltext IF NOT EXISTS "
            "FOR (e:Event) ON EACH [e.name, e.description]",

            # --- Full-text search on entity names ---
            "CREATE FULLTEXT INDEX entity_fulltext IF NOT EXISTS "
            "FOR (e:Entity) ON EACH [e.name]",
        ]
        for stmt in constraints + indexes:
            try:
                self.neo4j.execute_write_query(stmt)
            except Exception:
                logger.debug("Schema statement skipped (may already exist): %s", stmt[:80])

        # Restore logger level
        neo4j_logger.setLevel(prev_level)
        logger.info("Neo4j schema ensured (constraints + indexes)")

    # ------------------------------------------------------------------
    # Node MERGE operations
    # ------------------------------------------------------------------

    def merge_entity(self, entity_id: str, properties: Dict[str, Any]) -> None:
        """MERGE an Entity node by entity_id + tenant_id."""
        query = """
        MERGE (e:Entity {entity_id: $entity_id, tenant_id: $tenant_id})
        ON CREATE SET e += $props, e.created_at = datetime()
        ON MATCH SET e += $props, e.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "entity_id": entity_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    def merge_event(
        self,
        event_id: str,
        properties: Dict[str, Any],
        new_confidence: float = 0.8,
        document_id: Optional[str] = None,
    ) -> None:
        """
        MERGE an Event node with conflict resolution.

        For new events: creates with all properties.
        For existing events: fetches current state, resolves conflicts
        per-property using confidence + detail priority, tracks changes
        in an ``EventHistory`` node, then writes the resolved properties.

        Conflict resolution strategy (mirrors EntityConsolidator):
        1. Higher confidence wins (if delta > 0.1)
        2. More detailed value wins (new string 1.5x longer)
        3. Most recent wins (tie-breaker)
        """
        clean_props = self._clean_props(properties)

        # Check if event already exists
        existing = self._get_existing_event(event_id)

        if existing is None:
            # New event — create directly
            query = """
            MERGE (e:Event {event_id: $event_id, tenant_id: $tenant_id})
            ON CREATE SET e += $props, e.created_at = datetime(),
                          e.confidence = $confidence, e.version = 1
            """
            self.neo4j.execute_write_query(query, {
                "event_id": event_id,
                "tenant_id": self.tenant_id,
                "props": clean_props,
                "confidence": new_confidence,
            })
            return

        # Existing event — resolve conflicts per property
        old_confidence = existing.get("confidence", 0.5)
        resolved_props = {}
        changed_fields = {}

        for key, new_val in clean_props.items():
            old_val = existing.get(key)

            if old_val is None or old_val == new_val:
                # No conflict: new field or same value
                resolved_props[key] = new_val
                continue

            winner = self._resolve_conflict(
                key, old_val, new_val, old_confidence, new_confidence
            )
            resolved_props[key] = winner

            if winner != old_val:
                changed_fields[key] = {
                    "old": old_val,
                    "new": winner,
                    "reason": self._conflict_reason(
                        old_val, new_val, old_confidence, new_confidence
                    ),
                }

        # Write resolved properties
        old_version = existing.get("version", 1)
        resolved_props["confidence"] = max(old_confidence, new_confidence)
        resolved_props["version"] = old_version + 1

        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        SET e += $props, e.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "event_id": event_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(resolved_props),
        })

        # Track changes as EventHistory node
        if changed_fields and document_id:
            self._track_event_history(
                event_id, old_version, changed_fields, document_id,
                old_confidence, new_confidence,
            )

        if changed_fields:
            logger.info(
                "Event %s updated (v%d->v%d): %s",
                event_id, old_version, old_version + 1,
                list(changed_fields.keys()),
            )

    def _get_existing_event(self, event_id: str) -> Optional[Dict[str, Any]]:
        """Fetch current event properties from Neo4j."""
        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        RETURN properties(e) AS props
        """
        results = self.neo4j.execute_query(query, {
            "event_id": event_id,
            "tenant_id": self.tenant_id,
        })
        if results:
            return results[0].get("props", {})
        return None

    @staticmethod
    def _resolve_conflict(
        key: str,
        old_value: Any,
        new_value: Any,
        old_confidence: float,
        new_confidence: float,
    ) -> Any:
        """
        Decide which value to keep when old and new disagree.

        Priority:
        1. Higher confidence wins (if delta > 0.1)
        2. More detailed value wins (string 1.5x longer)
        3. Status progression wins (planned->in_progress->completed)
        4. Most recent wins (tie-breaker)
        """
        # 1. Confidence
        if new_confidence > old_confidence + 0.1:
            return new_value
        if old_confidence > new_confidence + 0.1:
            return old_value

        # 2. Detail level
        if isinstance(new_value, str) and isinstance(old_value, str):
            if len(new_value) > len(old_value) * 1.5:
                return new_value
            if len(old_value) > len(new_value) * 1.5:
                return old_value

        # 3. Status progression (never go backwards)
        if key == "status":
            status_order = {
                "planned": 0, "in_progress": 1, "completed": 2, "cancelled": 2
            }
            old_rank = status_order.get(str(old_value), -1)
            new_rank = status_order.get(str(new_value), -1)
            if old_rank >= 0 and new_rank >= 0:
                return new_value if new_rank >= old_rank else old_value

        # 4. Recency (new wins)
        return new_value

    @staticmethod
    def _conflict_reason(
        old_value: Any, new_value: Any,
        old_confidence: float, new_confidence: float,
    ) -> str:
        """Generate a human-readable reason for the conflict resolution."""
        if new_confidence > old_confidence + 0.1:
            return f"higher confidence ({new_confidence:.2f} > {old_confidence:.2f})"
        if isinstance(new_value, str) and isinstance(old_value, str):
            if len(new_value) > len(old_value) * 1.5:
                return "more detailed value"
        return "more recent information"

    def _track_event_history(
        self,
        event_id: str,
        version: int,
        changed_fields: Dict[str, Dict[str, Any]],
        document_id: str,
        old_confidence: float,
        new_confidence: float,
    ) -> None:
        """
        Create an EventHistory node linked to the Event for audit trail.

        (:Event)-[:HAS_HISTORY]->(:EventHistory {version, changed_fields, ...})
        """
        import json
        import uuid as _uuid

        history_id = str(_uuid.uuid4())
        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        CREATE (h:EventHistory {
            history_id: $history_id,
            tenant_id: $tenant_id,
            version: $version,
            changed_fields: $changed_fields,
            source_document_id: $doc_id,
            old_confidence: $old_conf,
            new_confidence: $new_conf,
            changed_at: datetime()
        })
        CREATE (e)-[:HAS_HISTORY]->(h)
        """
        self.neo4j.execute_write_query(query, {
            "event_id": event_id,
            "tenant_id": self.tenant_id,
            "history_id": history_id,
            "version": version,
            "changed_fields": json.dumps(changed_fields),
            "doc_id": document_id,
            "old_conf": old_confidence,
            "new_conf": new_confidence,
        })

    def merge_process(self, process_id: str, properties: Dict[str, Any]) -> None:
        """MERGE a Process node by process_id + tenant_id."""
        query = """
        MERGE (p:Process {process_id: $process_id, tenant_id: $tenant_id})
        ON CREATE SET p += $props, p.created_at = datetime()
        ON MATCH SET p += $props, p.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "process_id": process_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    def merge_process_steps(
        self, process_id: str, steps: List[Dict[str, Any]]
    ) -> None:
        """
        MERGE ProcessStep nodes and create HAS_STEP + NEXT_STEP chains.

        Each step gets a composite step_id: ``{process_id}_step_{order}``.
        """
        queries = []

        prev_step_id = None
        for step in sorted(steps, key=lambda s: s.get("order", 0)):
            step_id = f"{process_id}_step_{step['order']}"
            props = self._clean_props({
                "name": step.get("name", ""),
                "order": step.get("order", 0),
                "description": step.get("description"),
                "actor": step.get("actor"),
            })

            # MERGE the step node
            queries.append({
                "query": (
                    "MERGE (s:ProcessStep {step_id: $step_id, tenant_id: $tenant_id}) "
                    "ON CREATE SET s += $props, s.created_at = datetime() "
                    "ON MATCH SET s += $props, s.updated_at = datetime()"
                ),
                "parameters": {
                    "step_id": step_id,
                    "tenant_id": self.tenant_id,
                    "props": props,
                },
            })

            # HAS_STEP: Process -> ProcessStep
            queries.append({
                "query": (
                    "MATCH (p:Process {process_id: $process_id, tenant_id: $tenant_id}) "
                    "MATCH (s:ProcessStep {step_id: $step_id, tenant_id: $tenant_id}) "
                    "MERGE (p)-[r:HAS_STEP]->(s) "
                    "SET r.order = $order"
                ),
                "parameters": {
                    "process_id": process_id,
                    "step_id": step_id,
                    "tenant_id": self.tenant_id,
                    "order": step.get("order", 0),
                },
            })

            # NEXT_STEP: previous step -> this step
            if prev_step_id:
                queries.append({
                    "query": (
                        "MATCH (a:ProcessStep {step_id: $prev_id, tenant_id: $tenant_id}) "
                        "MATCH (b:ProcessStep {step_id: $curr_id, tenant_id: $tenant_id}) "
                        "MERGE (a)-[:NEXT_STEP]->(b)"
                    ),
                    "parameters": {
                        "prev_id": prev_step_id,
                        "curr_id": step_id,
                        "tenant_id": self.tenant_id,
                    },
                })

            # PERFORMED_BY: ProcessStep -> Entity (if actor is in the graph)
            if step.get("actor_entity_id"):
                queries.append({
                    "query": (
                        "MATCH (s:ProcessStep {step_id: $step_id, tenant_id: $tenant_id}) "
                        "MATCH (e:Entity {entity_id: $entity_id, tenant_id: $tenant_id}) "
                        "MERGE (s)-[:PERFORMED_BY]->(e)"
                    ),
                    "parameters": {
                        "step_id": step_id,
                        "entity_id": step["actor_entity_id"],
                        "tenant_id": self.tenant_id,
                    },
                })

            prev_step_id = step_id

        if queries:
            self.neo4j.execute_transaction(queries)

    def merge_document(self, document_id: str, properties: Dict[str, Any]) -> None:
        """MERGE a Document node for provenance tracking."""
        query = """
        MERGE (d:Document {document_id: $document_id, tenant_id: $tenant_id})
        ON CREATE SET d += $props, d.created_at = datetime()
        ON MATCH SET d += $props, d.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "document_id": document_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    # ------------------------------------------------------------------
    # Relationship MERGE operations
    # ------------------------------------------------------------------

    def merge_participation(
        self,
        entity_id: str,
        event_id: str,
        role: str,
        confidence: float,
    ) -> None:
        """MERGE PARTICIPATED_IN relationship: Entity -> Event."""
        query = """
        MATCH (entity:Entity {entity_id: $entity_id, tenant_id: $tenant_id})
        MATCH (event:Event {event_id: $event_id, tenant_id: $tenant_id})
        MERGE (entity)-[r:PARTICIPATED_IN]->(event)
        SET r.role = $role, r.confidence = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "entity_id": entity_id,
            "event_id": event_id,
            "tenant_id": self.tenant_id,
            "role": role,
            "confidence": confidence,
        })

    def merge_causal_link(
        self,
        cause_event_id: str,
        effect_event_id: str,
        relationship_type: str,
        description: Optional[str] = None,
        confidence: float = 0.7,
    ) -> None:
        """MERGE CAUSED relationship: Event -> Event."""
        query = """
        MATCH (cause:Event {event_id: $cause_id, tenant_id: $tenant_id})
        MATCH (effect:Event {event_id: $effect_id, tenant_id: $tenant_id})
        MERGE (cause)-[r:CAUSED]->(effect)
        SET r.type = $rel_type, r.description = $description, r.confidence = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "cause_id": cause_event_id,
            "effect_id": effect_event_id,
            "tenant_id": self.tenant_id,
            "rel_type": relationship_type,
            "description": description or "",
            "confidence": confidence,
        })

    def merge_temporal_link(
        self,
        earlier_event_id: str,
        later_event_id: str,
        relationship_type: str,
        time_gap: Optional[str] = None,
        synthetic: bool = False,
    ) -> None:
        """MERGE temporal relationship: Event -> Event.

        *synthetic* marks links inferred from page/date order (not LLM-extracted).
        These can be filtered out in queries that require high-confidence ordering.
        """
        rel_label = {
            "preceded_by": "FOLLOWED_BY",
            "followed_by": "FOLLOWED_BY",
            "concurrent_with": "CONCURRENT_WITH",
        }.get(relationship_type, "FOLLOWED_BY")

        query = f"""
        MATCH (a:Event {{event_id: $earlier_id, tenant_id: $tenant_id}})
        MATCH (b:Event {{event_id: $later_id, tenant_id: $tenant_id}})
        MERGE (a)-[r:{rel_label}]->(b)
        SET r.time_gap = $time_gap, r.synthetic = $synthetic
        """
        self.neo4j.execute_write_query(query, {
            "earlier_id": earlier_event_id,
            "later_id": later_event_id,
            "tenant_id": self.tenant_id,
            "time_gap": time_gap or "",
            "synthetic": synthetic,
        })

    def merge_event_date_anchor(
        self,
        event_id: str,
        anchored_date: str,
        source_event_name: str,
        confidence: float = 0.6,
    ) -> None:
        """
        Write a date-anchored value to an Event node.

        Called when a missing date is computed from a neighbouring event's
        known date + the time_gap on a FOLLOWED_BY edge between them.
        The original ``date`` field is never overwritten — the anchored date
        is stored separately so query code can choose which to use.
        """
        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        SET e.date_anchored            = $anchored_date,
            e.date_anchor_source_event = $source_event_name,
            e.date_anchor_confidence   = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "event_id": event_id,
            "tenant_id": self.tenant_id,
            "anchored_date": anchored_date,
            "source_event_name": source_event_name,
            "confidence": confidence,
        })

    def merge_event_to_process(
        self, event_id: str, process_id: str, step_order: Optional[int] = None
    ) -> None:
        """MERGE PART_OF relationship: Event -> Process."""
        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        MATCH (p:Process {process_id: $process_id, tenant_id: $tenant_id})
        MERGE (e)-[r:PART_OF]->(p)
        SET r.step_order = $step_order
        """
        self.neo4j.execute_write_query(query, {
            "event_id": event_id,
            "process_id": process_id,
            "tenant_id": self.tenant_id,
            "step_order": step_order,
        })

    def merge_process_owner(self, entity_id: str, process_id: str) -> None:
        """MERGE OWNS_PROCESS relationship: Entity -> Process."""
        query = """
        MATCH (e:Entity {entity_id: $entity_id, tenant_id: $tenant_id})
        MATCH (p:Process {process_id: $process_id, tenant_id: $tenant_id})
        MERGE (e)-[:OWNS_PROCESS]->(p)
        """
        self.neo4j.execute_write_query(query, {
            "entity_id": entity_id,
            "process_id": process_id,
            "tenant_id": self.tenant_id,
        })

    def merge_entity_relationship(
        self,
        source_entity_id: str,
        target_entity_id: str,
        relationship_type: str,
        confidence: float = 0.8,
    ) -> None:
        """MERGE RELATED_TO relationship: Entity -> Entity."""
        query = """
        MATCH (a:Entity {entity_id: $source_id, tenant_id: $tenant_id})
        MATCH (b:Entity {entity_id: $target_id, tenant_id: $tenant_id})
        MERGE (a)-[r:RELATED_TO]->(b)
        SET r.type = $rel_type, r.confidence = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "source_id": source_entity_id,
            "target_id": target_entity_id,
            "tenant_id": self.tenant_id,
            "rel_type": relationship_type,
            "confidence": confidence,
        })

    def add_provenance(
        self,
        node_id_field: str,
        node_id: str,
        node_label: str,
        document_id: str,
        relationship_type: str = "MENTIONED_IN",
        evidence: Optional[str] = None,
        file_name: Optional[str] = None,
        page: Optional[str] = None,
        chunk_id: Optional[str] = None,
    ) -> None:
        """
        MERGE provenance relationship: Node -> Document.

        The MENTIONED_IN / EXTRACTED_FROM edge carries per-document metadata:
        - evidence: the verbatim quote from THIS document about this node
        - file_name: original filename for quick display
        - page / chunk_id: location within the document

        This lets you query "what did each document say about event X?"
        and then fetch the full document from OpenSearch or S3.
        """
        query = f"""
        MATCH (n:{node_label} {{{node_id_field}: $node_id, tenant_id: $tenant_id}})
        MATCH (d:Document {{document_id: $doc_id, tenant_id: $tenant_id}})
        MERGE (n)-[r:{relationship_type}]->(d)
        SET r.evidence = CASE WHEN $evidence IS NOT NULL THEN $evidence ELSE r.evidence END,
            r.file_name = CASE WHEN $file_name IS NOT NULL THEN $file_name ELSE r.file_name END,
            r.page = CASE WHEN $page IS NOT NULL THEN $page ELSE r.page END,
            r.chunk_id = CASE WHEN $chunk_id IS NOT NULL THEN $chunk_id ELSE r.chunk_id END,
            r.linked_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "node_id": node_id,
            "doc_id": document_id,
            "tenant_id": self.tenant_id,
            "evidence": evidence,
            "file_name": file_name,
            "page": page,
            "chunk_id": chunk_id,
        })

    def add_document_source(self, event_id: str, document_id: str) -> None:
        """Append a document_id to an event's source_document_ids list."""
        query = """
        MATCH (e:Event {event_id: $event_id, tenant_id: $tenant_id})
        SET e.source_document_ids = CASE
            WHEN e.source_document_ids IS NULL THEN [$doc_id]
            WHEN NOT $doc_id IN e.source_document_ids
                THEN e.source_document_ids + $doc_id
            ELSE e.source_document_ids
        END
        """
        self.neo4j.execute_write_query(query, {
            "event_id": event_id,
            "tenant_id": self.tenant_id,
            "doc_id": document_id,
        })

    # ------------------------------------------------------------------
    # Batch execution
    # ------------------------------------------------------------------

    def batch_execute(self, queries: List[Dict[str, Any]]) -> None:
        """Execute multiple Cypher queries in a single transaction."""
        if queries:
            self.neo4j.execute_transaction(queries)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _clean_props(props: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean properties for Neo4j compatibility.

        - Remove None values (Neo4j doesn't accept null in property maps)
        - Convert lists to Neo4j-compatible format
        - Convert datetimes to ISO strings
        """
        cleaned = {}
        for k, v in props.items():
            if v is None:
                continue
            if isinstance(v, datetime):
                cleaned[k] = v.isoformat()
            elif isinstance(v, (list, tuple)):
                # Neo4j supports homogeneous lists of primitives
                cleaned[k] = [str(item) if not isinstance(item, (str, int, float, bool)) else item for item in v]
            elif isinstance(v, dict):
                # Neo4j doesn't support nested maps in properties — serialise
                import json
                cleaned[k] = json.dumps(v)
            else:
                cleaned[k] = v
        return cleaned

    def close(self) -> None:
        """Close the underlying Neo4j connection."""
        self.neo4j.close()
