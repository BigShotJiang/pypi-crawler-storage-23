"""
OntologyLinker – connects schema ontology nodes to existing graph entities.

Three-tier linking strategy:
1. Type-based (rule): DataTable entity_type_represented -> Entity nodes of same type
2. Name similarity (rule): SequenceMatcher on table/field names vs entity names
3. LLM fallback (optional): For ambiguous cases, LLM decides the semantic link
"""

import logging
from collections import defaultdict
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .ontology_schemas import (
    OntologyLinkResult,
    SchemaOntologyExtractionResult,
)
from .ontology_storage import OntologyStorage
from . import ontology_prompts as OP

logger = logging.getLogger(__name__)


class OntologyLinker:
    """Connect ontology DataTable/DataField nodes to existing Entity nodes."""

    def __init__(
        self,
        storage: OntologyStorage,
        use_llm_linking: bool = False,
        name_similarity_threshold: float = 0.75,
    ):
        self.storage = storage
        self.use_llm_linking = use_llm_linking
        self.name_threshold = name_similarity_threshold
        self.llm_manager = LLMManager()

    def link(
        self,
        ontology_result: SchemaOntologyExtractionResult,
        source_id: str,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """
        Link ontology to existing graph entities.

        Parameters
        ----------
        ontology_result : SchemaOntologyExtractionResult
            LLM-enriched ontology.
        source_id : str
            DataSource node ID.
        tenant_id : str
            Tenant isolation key.

        Returns
        -------
        dict
            Stats: tracks_links, describes_links, llm_links.
        """
        stats: Dict[str, int] = defaultdict(int)

        # Get all existing entities from the graph
        all_entities = self.storage.get_all_entities(limit=500)
        if not all_entities:
            logger.info("No existing entities in graph — skipping linking")
            return dict(stats)

        # Build entity lookup by type
        entities_by_type: Dict[str, List[Dict]] = defaultdict(list)
        for e in all_entities:
            etype = e.get("type") or "OTHER"
            entities_by_type[etype].append(e)

        linked_tables = set()

        for table_sem in ontology_result.tables:
            table_id = self.storage.make_table_id(source_id, table_sem.table_name)

            # --- Tier 1: Type-based linking ---
            if table_sem.entity_type_represented:
                matching_entities = entities_by_type.get(
                    table_sem.entity_type_represented, []
                )
                for entity in matching_entities:
                    self.storage.merge_tracks(
                        table_id, entity["entity_id"], confidence=0.85,
                    )
                    stats["tracks_links_type_based"] += 1
                if matching_entities:
                    linked_tables.add(table_sem.table_name)

            # --- Tier 2: Name similarity ---
            name_links = self._name_similarity_links(
                table_sem, table_id, all_entities
            )
            for entity_id, confidence in name_links:
                self.storage.merge_tracks(
                    table_id, entity_id, confidence=confidence,
                )
                stats["tracks_links_name_based"] += 1
                linked_tables.add(table_sem.table_name)

            # --- Field-level linking ---
            for field_sem in table_sem.fields:
                if field_sem.maps_to_entity_type:
                    field_id = self.storage.make_field_id(table_id, field_sem.field_name)
                    matching = entities_by_type.get(field_sem.maps_to_entity_type, [])
                    for entity in matching:
                        self.storage.merge_describes_attribute(
                            field_id, entity["entity_id"],
                            confidence=field_sem.confidence,
                        )
                        stats["describes_attribute_links"] += 1

        # --- Tier 3: LLM fallback for unlinked tables ---
        if self.use_llm_linking:
            unlinked = [
                t for t in ontology_result.tables
                if t.table_name not in linked_tables
            ]
            for table_sem in unlinked:
                table_id = self.storage.make_table_id(source_id, table_sem.table_name)
                llm_links = self._llm_link(table_sem, all_entities)
                for entity_id, confidence in llm_links:
                    self.storage.merge_tracks(
                        table_id, entity_id, confidence=confidence,
                    )
                    stats["tracks_links_llm"] += 1

        logger.info("Ontology linking complete: %s", dict(stats))
        return dict(stats)

    # ------------------------------------------------------------------
    # Tier 2: Name similarity
    # ------------------------------------------------------------------

    def _name_similarity_links(
        self,
        table_sem,
        table_id: str,
        all_entities: List[Dict[str, Any]],
    ) -> List[tuple]:
        """Find entities whose names match the table or its sample data."""
        links = []
        table_name_lower = table_sem.table_name.lower()

        for entity in all_entities:
            entity_name = (entity.get("name") or "").lower()
            if not entity_name:
                continue

            # Compare table name to entity name
            score = SequenceMatcher(None, table_name_lower, entity_name).ratio()
            if score >= self.name_threshold:
                links.append((entity["entity_id"], round(score, 2)))
                continue

            # Check if entity name appears in any field's sample values
            for field_sem in table_sem.fields:
                if field_sem.semantic_role in ("name", "identifier", "category"):
                    # This field likely contains entity names — but we don't
                    # have sample values in the LLM result (they're in ParsedSchema).
                    # The type-based link from Tier 1 handles this case.
                    pass

        return links

    # ------------------------------------------------------------------
    # Tier 3: LLM fallback
    # ------------------------------------------------------------------

    def _llm_link(
        self,
        table_sem,
        all_entities: List[Dict[str, Any]],
    ) -> List[tuple]:
        """Use LLM to decide if a table should link to an entity."""
        # Pick top-5 entities by name similarity
        table_lower = table_sem.table_name.lower()
        scored = []
        for e in all_entities:
            s = SequenceMatcher(
                None, table_lower, (e.get("name") or "").lower()
            ).ratio()
            scored.append((s, e))
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:5]

        llm = self.llm_manager.get_for_structured_output()
        fields_summary = ", ".join(
            f.field_name for f in table_sem.fields[:10]
        )
        links = []

        for _score, entity in top:
            prompt = (
                f"System: {OP.ONTOLOGY_LINK_SYSTEM}\n\n"
                f"User: {OP.ONTOLOGY_LINK_USER.format(
                    table_name=table_sem.table_name,
                    table_description=table_sem.semantic_description,
                    entity_type_represented=table_sem.entity_type_represented or 'Unknown',
                    fields_summary=fields_summary,
                    entity_name=entity.get('name', ''),
                    entity_type=entity.get('type', ''),
                    entity_context='From document extraction',
                )}"
            )
            try:
                result: OntologyLinkResult = llm.generate_structured(
                    prompt, OntologyLinkResult, temperature=0.1,
                )
                if result.should_link and result.confidence >= 0.7:
                    links.append((entity["entity_id"], result.confidence))
                    logger.info(
                        "LLM link: table '%s' -> entity '%s' (conf=%.2f, reason=%s)",
                        table_sem.table_name,
                        entity.get("name"),
                        result.confidence,
                        result.reasoning,
                    )
            except LLMRateLimitTimeoutError:
                raise
            except Exception:
                logger.warning(
                    "LLM link failed for table '%s' vs entity '%s'",
                    table_sem.table_name, entity.get("name"),
                )
                continue

        return links
