"""
KG Evaluation Suite – assertion-based validation of the pharma knowledge graph.

Runs a curated set of assertions derived from the 7 pharma case PDFs in
Graph_Validation_Data/ and writes machine-readable results to
``results/kg_eval_report.json``.

Usage::

    python knowledge_graph/evaluate_queries.py --tenant org_123
    python knowledge_graph/evaluate_queries.py --tenant org_123 --json
    python knowledge_graph/evaluate_queries.py --tenant org_123 --out results/custom_report.json
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from knowledge_graph.evaluation_assertions import (
    assert_causal_chain_exists,
    assert_temporal_ordering,
    assert_event_has_evidence,
    assert_no_date_contradictions,
    assert_entity_participated,
    assert_timeline_connected,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pharma assertion suite
# Each entry: (assertion_type, arg1, arg2)
# ---------------------------------------------------------------------------

PHARMA_ASSERTIONS: List[Tuple[str, Optional[str], Optional[str]]] = [
    # ── pharma_case_01: EM System Alert ───────────────────────────────────
    ("causal",   "EM System Alert for Non-Viable Particulates",
                 "Line Stopped and Product Hold Initiated"),
    ("temporal", "Initial Assessment of Particulate Issue",
                 "Root Cause Confirmation"),
    ("temporal", "Root Cause Confirmation",
                 "CAPA Approval and Batch Disposition"),
    ("evidence", "EM System Alert for Non-Viable Particulates",          None),
    ("evidence", "CAPA Approval and Batch Disposition",                  None),

    # ── pharma_case_02: Change Control / Cleaning Agent ───────────────────
    ("causal",   "Supplier Backorder Notice for CIP-Alpha",
                 "Change Request Raised in QMS"),
    ("temporal", "Lab Comparability Study Completed",
                 "Validation Protocol Executed"),
    ("temporal", "Validation Protocol Executed",
                 "Change Approved with Conditions"),
    ("evidence", "Change Request Raised in QMS",                         None),

    # ── pharma_case_03: QC OOS HPLC ───────────────────────────────────────
    ("causal",   "Mobile Phase pH Out of Tolerance",
                 "HPLC Assay Failure - API Potency (Lot API-26-033)"),
    ("temporal", "Phase I Lab Investigation Initiation",
                 "Retest with Correct Buffer"),
    ("temporal", "Retest with Correct Buffer",
                 "Investigation Closure and Lot Release"),
    ("evidence", "HPLC Assay Failure - API Potency (Lot API-26-033)",   None),

    # ── pharma_case_04: Cold Chain Excursion ──────────────────────────────
    ("causal",   "Temperature Excursion Recorded",
                 "Excursion Flagged on Arrival"),
    ("temporal", "Temperature Excursion Recorded",
                 "Temperature Returned to Range"),
    ("temporal", "Excursion Flagged on Arrival",
                 "Disposition Decision Made"),
    ("evidence", "Temperature Excursion Recorded",                       None),

    # ── pharma_case_05: Regulatory Inspection ─────────────────────────────
    ("evidence", "Inspection Day 1",                                     None),

    # ── Entity participation checks ────────────────────────────────────────
    ("entity_participated", "QA OOS Coordinator",
                            "HPLC Assay Failure - API Potency (Lot API-26-033)"),
    ("entity_participated", "3PL Carrier",
                            "Temperature Excursion Recorded"),
    ("entity_participated", "Inspectorate",
                            "Inspection Day 1"),

    # ── Global graph health checks ─────────────────────────────────────────
    ("no_date_contradictions", None, None),
    ("timeline_connected",     None, None),
]


def run_assertion(
    assertion_type: str,
    arg1: Optional[str],
    arg2: Optional[str],
    tenant_id: str,
) -> Dict[str, Any]:
    """Dispatch a single assertion and return its result dict."""
    if assertion_type == "causal":
        return assert_causal_chain_exists(arg1, arg2, tenant_id)  # type: ignore[arg-type]
    elif assertion_type == "temporal":
        return assert_temporal_ordering(arg1, arg2, tenant_id)     # type: ignore[arg-type]
    elif assertion_type == "evidence":
        return assert_event_has_evidence(arg1, tenant_id)          # type: ignore[arg-type]
    elif assertion_type == "entity_participated":
        return assert_entity_participated(arg1, arg2, tenant_id)   # type: ignore[arg-type]
    elif assertion_type == "no_date_contradictions":
        return assert_no_date_contradictions(tenant_id)
    elif assertion_type == "timeline_connected":
        return assert_timeline_connected(tenant_id)
    else:
        return {
            "passed": False,
            "assertion": assertion_type,
            "message": f"Unknown assertion type: {assertion_type}",
            "details": {},
        }


def run_suite(tenant_id: str) -> Dict[str, Any]:
    """Run all pharma assertions and return a structured report."""
    results = []
    passed_count = 0
    failed_count = 0

    logger.info("=" * 70)
    logger.info("KG EVALUATION SUITE — tenant=%s", tenant_id)
    logger.info("=" * 70)

    for assertion_type, arg1, arg2 in PHARMA_ASSERTIONS:
        result = run_assertion(assertion_type, arg1, arg2, tenant_id)
        status = "PASS" if result.get("passed") else "FAIL"
        if result.get("passed"):
            passed_count += 1
        else:
            failed_count += 1

        result["type"] = assertion_type
        results.append(result)

        logger.info(
            "%-10s  %-6s  %s",
            assertion_type.upper(), status, result.get("message", ""),
        )

    total = passed_count + failed_count
    pass_rate = passed_count / total if total else 0.0

    logger.info("-" * 70)
    logger.info("RESULT: %d/%d passed (%.0f%%)", passed_count, total, pass_rate * 100)
    logger.info("=" * 70)

    return {
        "tenant_id": tenant_id,
        "run_at": datetime.now(timezone.utc).isoformat(),
        "total": total,
        "passed": passed_count,
        "failed": failed_count,
        "pass_rate": round(pass_rate, 4),
        "assertions": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="KG Evaluation Suite")
    parser.add_argument("--tenant", "-t", required=True, help="Tenant ID")
    parser.add_argument("--json", action="store_true", default=False,
                        help="Print full JSON report to stdout")
    parser.add_argument(
        "--out", default=None,
        help="Path to write JSON report (default: results/kg_eval_report.json)",
    )
    args = parser.parse_args()

    report = run_suite(tenant_id=args.tenant)

    # Determine output path
    out_path = Path(args.out) if args.out else Path("results/kg_eval_report.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, default=str))
    logger.info("Report written to: %s", out_path)

    if args.json:
        print(json.dumps(report, indent=2, default=str))

    # Exit code: non-zero if more than 20% failed
    if report["pass_rate"] < 0.8:
        sys.exit(1)


if __name__ == "__main__":
    main()
