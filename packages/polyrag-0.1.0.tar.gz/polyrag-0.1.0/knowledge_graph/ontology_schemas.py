"""
Pydantic schemas for the Schema Ontology extraction pipeline.

Used with ``LLMProvider.generate_structured()`` to get type-safe structured
output from the LLM when analyzing database/spreadsheet schemas to extract
semantic ontologies — what entity types exist, what attributes they have,
and how tables relate to each other.
"""

from typing import List, Literal, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Field-level semantics
# ---------------------------------------------------------------------------

class InferredFieldSemantics(BaseModel):
    """LLM-inferred semantics for a single column/field."""

    model_config = {"extra": "forbid"}

    field_name: str = Field(
        ..., description="Original column/field name from the schema.",
    )
    semantic_description: str = Field(
        ..., description="1-sentence description of what this field represents.",
    )
    semantic_role: Literal[
        "identifier",
        "name",
        "attribute",
        "metric",
        "dimension",
        "timestamp",
        "foreign_key",
        "status",
        "category",
        "description",
        "other",
    ] = Field(..., description="Semantic role of this field.")

    maps_to_entity_type: Optional[str] = Field(
        None,
        description=(
            "If this field represents or references an entity type, "
            "what type? E.g. PERSON, ORGANIZATION, PRODUCT, LOCATION. "
            "None if it is just a raw attribute."
        ),
    )
    is_metric: bool = Field(
        default=False,
        description="True if this field is a quantitative measure (salary, amount, count).",
    )
    is_dimension: bool = Field(
        default=False,
        description="True if this field is a grouping/categorisation dimension.",
    )
    confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Confidence 0-1.",
    )


# ---------------------------------------------------------------------------
# Table-level semantics
# ---------------------------------------------------------------------------

class InferredTableSemantics(BaseModel):
    """LLM-inferred semantics for a single table/sheet."""

    model_config = {"extra": "forbid"}

    table_name: str = Field(
        ..., description="Original table or sheet name.",
    )
    semantic_description: str = Field(
        ..., description="1-2 sentence description of what this table tracks.",
    )
    entity_type_represented: Optional[str] = Field(
        None,
        description=(
            "The primary entity type this table represents instances of. "
            "E.g. 'PERSON' for an employees table, 'ORGANIZATION' for a "
            "departments table, 'TRANSACTION' for an orders table. "
            "None if the table is a junction/mapping table."
        ),
    )
    is_junction_table: bool = Field(
        default=False,
        description="True if this is a many-to-many junction table.",
    )
    fields: List[InferredFieldSemantics] = Field(
        default_factory=list,
        description="Semantic analysis for each field in this table.",
    )
    confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Confidence 0-1.",
    )


# ---------------------------------------------------------------------------
# Cross-table relationships
# ---------------------------------------------------------------------------

class InferredRelationship(BaseModel):
    """A relationship inferred between tables by the LLM."""

    model_config = {"extra": "forbid"}

    from_table: str = Field(..., description="Source table name.")
    from_field: str = Field(..., description="Source field name.")
    to_table: str = Field(..., description="Target table name.")
    to_field: str = Field(..., description="Target field name.")

    relationship_type: Literal[
        "foreign_key",
        "one_to_many",
        "many_to_many",
        "hierarchical",
        "temporal",
        "semantic",
    ] = Field(..., description="Type of relationship.")

    description: Optional[str] = Field(
        None, description="What this relationship means semantically.",
    )
    confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Confidence 0-1.",
    )


# ---------------------------------------------------------------------------
# Full extraction result
# ---------------------------------------------------------------------------

class SchemaOntologyExtractionResult(BaseModel):
    """Complete ontology extraction from a database/spreadsheet schema."""

    model_config = {"extra": "forbid"}

    source_name: str = Field(
        ..., description="Name of the data source (database name or file name).",
    )
    source_type: Literal["database", "spreadsheet", "csv"] = Field(
        ..., description="Type of data source.",
    )
    overall_description: str = Field(
        ..., description="2-3 sentence description of what this data source represents.",
    )
    domain: Optional[str] = Field(
        None,
        description="Business domain: HR, Finance, Sales, Healthcare, Manufacturing, etc.",
    )
    tables: List[InferredTableSemantics] = Field(
        default_factory=list,
        description="Semantic analysis for each table/sheet.",
    )
    cross_table_relationships: List[InferredRelationship] = Field(
        default_factory=list,
        description=(
            "Relationships between tables. Include explicit foreign keys "
            "AND inferred semantic relationships."
        ),
    )
    overall_confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Overall confidence.",
    )


# ---------------------------------------------------------------------------
# Ontology linking result (for LLM-based entity matching)
# ---------------------------------------------------------------------------

class OntologyLinkResult(BaseModel):
    """LLM output for deciding if a DataTable should link to a graph Entity."""

    model_config = {"extra": "forbid"}

    should_link: bool = Field(
        ..., description="True if the table semantically tracks this entity.",
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence 0-1.",
    )
    relationship_type: Literal["tracks", "describes_attribute", "none"] = Field(
        ..., description="What kind of link.",
    )
    reasoning: str = Field(
        ..., description="Brief explanation.",
    )
