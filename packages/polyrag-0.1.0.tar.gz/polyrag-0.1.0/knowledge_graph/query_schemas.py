"""
Pydantic result schemas for the KG Query Service.

All query methods return a dict matching these schemas.  They are defined
here so callers can validate or serialize results predictably.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Shared
# ---------------------------------------------------------------------------

class QueryError(BaseModel):
    error: str
    intent: str
    details: Optional[str] = None


# ---------------------------------------------------------------------------
# Intent 1: Chronological Timeline
# ---------------------------------------------------------------------------

class TimelineEvent(BaseModel):
    """A single event placed on the chronological timeline."""

    position: int = Field(..., description="1-based position in the timeline.")
    event_id: str
    event_name: str
    date: Optional[str] = Field(None, description="Raw date string from the graph.")
    date_parsed: Optional[str] = Field(
        None,
        description="ISO-8601 representation of the parsed date, or null.",
    )
    date_precision: str = Field(
        "unknown",
        description="exact | month | quarter | year | approximate | unknown",
    )
    position_method: Literal["date", "graph_edge", "inferred"] = Field(
        ...,
        description=(
            "How this event's position was determined: "
            "'date' = from parsed date field; "
            "'graph_edge' = from FOLLOWED_BY traversal; "
            "'inferred' = placed at end, no ordering signal."
        ),
    )
    confidence: float
    event_type: Optional[str] = None
    description: Optional[str] = None
    preceded_by: List[str] = Field(default_factory=list)
    succeeded_by: List[str] = Field(default_factory=list)
    source_documents: List[str] = Field(default_factory=list)


class TimelineResult(BaseModel):
    tenant_id: str
    total_events: int
    events_with_dates: int
    events_via_graph: int
    events_inferred: int
    timeline: List[TimelineEvent]


# ---------------------------------------------------------------------------
# Intent 2: Causal Chain
# ---------------------------------------------------------------------------

class CausalHop(BaseModel):
    from_event: str
    to_event: str
    relationship_type: str
    description: Optional[str] = None
    confidence: float
    evidence: Optional[str] = None


class CausalChainResult(BaseModel):
    root_event: str
    direction: str
    hops: List[CausalHop]
    chain_length: int


# ---------------------------------------------------------------------------
# Intent 3: Entity Timeline
# ---------------------------------------------------------------------------

class EntityTimelineEvent(BaseModel):
    position: int
    event_name: str
    role: str
    date: Optional[str] = None
    date_parsed: Optional[str] = None
    date_precision: str = "unknown"
    position_method: str
    description: Optional[str] = None


class EntityTimelineResult(BaseModel):
    entity_name: str
    entity_id: Optional[str] = None
    event_count: int
    timeline: List[EntityTimelineEvent]


# ---------------------------------------------------------------------------
# Intent 4: Process Steps
# ---------------------------------------------------------------------------

class ProcessStepResult(BaseModel):
    step_order: int
    step_name: str
    description: Optional[str] = None
    actor: Optional[str] = None
    actor_entity_id: Optional[str] = None
    input_artifacts: List[str] = Field(default_factory=list)
    output_artifacts: List[str] = Field(default_factory=list)


class ProcessResult(BaseModel):
    process_name: str
    process_id: Optional[str] = None
    process_type: Optional[str] = None
    description: Optional[str] = None
    step_count: int
    steps: List[ProcessStepResult]


# ---------------------------------------------------------------------------
# Intent 5: Event Evidence
# ---------------------------------------------------------------------------

class EvidenceEntry(BaseModel):
    document_id: str
    file_name: Optional[str] = None
    evidence: Optional[str] = None
    page: Optional[str] = None
    chunk_id: Optional[str] = None
    linked_at: Optional[str] = None


class EventEvidenceResult(BaseModel):
    event_name: str
    event_id: Optional[str] = None
    document_count: int
    evidence: List[EvidenceEntry]


# ---------------------------------------------------------------------------
# Intent 6: Search Events
# ---------------------------------------------------------------------------

class SearchHit(BaseModel):
    event_name: str
    event_id: str
    score: float
    event_type: Optional[str] = None
    date: Optional[str] = None
    description: Optional[str] = None


class SearchResult(BaseModel):
    query: str
    total_hits: int
    hits: List[SearchHit]
