"""
OntologyExtractor – LLM-based semantic enrichment of parsed schemas.

Takes a ParsedSchema (structural data from Excel/CSV/SQL) and produces a
SchemaOntologyExtractionResult (semantic understanding of what the schema
represents, what entity types it tracks, and how tables relate).
"""

import logging
from typing import Optional

from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .ontology_schemas import SchemaOntologyExtractionResult
from . import ontology_prompts as OP
from .schema_parser import ParsedSchema

logger = logging.getLogger(__name__)

_MAX_SCHEMA_CHARS = 30_000


class OntologyExtractor:
    """Runs LLM-based ontology extraction on parsed schema."""

    def __init__(self):
        self.llm_manager = LLMManager()

    def extract(
        self, parsed_schema: ParsedSchema
    ) -> SchemaOntologyExtractionResult:
        """
        Run ontology extraction on a parsed schema.

        Parameters
        ----------
        parsed_schema : ParsedSchema
            Output from SchemaParser.from_xlsx / from_csv / from_sql_json.

        Returns
        -------
        SchemaOntologyExtractionResult
            LLM-enriched semantic understanding of the schema.
        """
        logger.info(
            "Starting ontology extraction for source=%s tables=%d",
            parsed_schema.source_name, len(parsed_schema.tables),
        )

        schema_text = parsed_schema.to_prompt_text()
        if len(schema_text) > _MAX_SCHEMA_CHARS:
            schema_text = schema_text[:_MAX_SCHEMA_CHARS]
            logger.warning(
                "Schema text truncated from %d to %d chars",
                len(parsed_schema.to_prompt_text()), _MAX_SCHEMA_CHARS,
            )

        return self._call_llm(parsed_schema, schema_text)

    def _call_llm(
        self, parsed_schema: ParsedSchema, schema_text: str
    ) -> SchemaOntologyExtractionResult:
        """Single LLM call to extract semantic ontology from schema."""
        llm = self.llm_manager.get_for_structured_output()

        # Build sample data section
        sample_section = ""
        if any(t.sample_rows for t in parsed_schema.tables):
            parts = ["Sample data is included inline with each table above."]
            sample_section = "\n".join(parts)

        prompt = (
            f"System: {OP.SCHEMA_ONTOLOGY_SYSTEM}\n\n"
            f"User: {OP.SCHEMA_ONTOLOGY_USER.format(
                source_name=parsed_schema.source_name,
                source_type=parsed_schema.source_type,
                schema_text=schema_text,
                sample_data_section=sample_section,
            )}"
        )

        try:
            result = llm.generate_structured(
                prompt,
                SchemaOntologyExtractionResult,
                temperature=0.1,
            )
            logger.info(
                "Ontology extraction complete: source=%s tables=%d relationships=%d domain=%s",
                result.source_name,
                len(result.tables),
                len(result.cross_table_relationships),
                result.domain,
            )
            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception(
                "LLM ontology extraction failed for %s, returning fallback",
                parsed_schema.source_name,
            )
            return self._fallback(parsed_schema)

    @staticmethod
    def _fallback(
        parsed_schema: ParsedSchema,
    ) -> SchemaOntologyExtractionResult:
        """Return minimal result on failure — pipeline should never crash."""
        return SchemaOntologyExtractionResult(
            source_name=parsed_schema.source_name,
            source_type=parsed_schema.source_type,
            overall_description=f"Schema from {parsed_schema.source_name}",
            tables=[],
            cross_table_relationships=[],
            overall_confidence=0.0,
        )
