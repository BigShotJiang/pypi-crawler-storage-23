"""
Date string → sortable datetime for the KG timeline query service.

Event dates are stored as free-form strings extracted by the LLM:
  "2024-03-15"        → datetime(2024, 3, 15)     (exact)
  "January 2025"      → datetime(2025, 1, 1)      (month start)
  "Jan 2025"          → datetime(2025, 1, 1)
  "Q2 2024"           → datetime(2024, 4, 1)      (quarter start)
  "FY2023-24"         → datetime(2023, 4, 1)      (fiscal year start, Apr 1)
  "2024"              → datetime(2024, 1, 1)      (year start)
  "March 2024"        → datetime(2024, 3, 1)
  "early 2024"        → datetime(2024, 1, 1)      (approximation)
  "mid-2024"          → datetime(2024, 7, 1)
  "late 2024"         → datetime(2024, 10, 1)
  Unrecognised        → None

This module has no external dependencies beyond the standard library so it
can be imported and unit-tested in isolation.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Optional

# ---------------------------------------------------------------------------
# Month name mappings
# ---------------------------------------------------------------------------

_MONTHS = {
    "january": 1, "jan": 1,
    "february": 2, "feb": 2,
    "march": 3, "mar": 3,
    "april": 4, "apr": 4,
    "may": 5,
    "june": 6, "jun": 6,
    "july": 7, "jul": 7,
    "august": 8, "aug": 8,
    "september": 9, "sep": 9, "sept": 9,
    "october": 10, "oct": 10,
    "november": 11, "nov": 11,
    "december": 12, "dec": 12,
}

_QUARTER_START = {1: 1, 2: 4, 3: 7, 4: 10}  # quarter → first month

# Pre-compiled patterns (most-specific first)
_ISO_RE        = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")
_ISO_YM_RE     = re.compile(r"^(\d{4})-(\d{2})$")
_QUARTER_RE    = re.compile(r"\bq([1-4])\s*(\d{4})\b", re.IGNORECASE)
_FISCAL_RE     = re.compile(r"\bfy\s*(\d{4})[/-](\d{2,4})\b", re.IGNORECASE)
_MONTH_YEAR_RE = re.compile(
    r"\b(" + "|".join(_MONTHS) + r")\s+(\d{4})\b", re.IGNORECASE
)
_YEAR_ONLY_RE  = re.compile(r"\b(19|20)\d{2}\b")
_RELATIVE_RE   = re.compile(r"\b(early|mid|late)\b.{0,5}(\d{4})\b", re.IGNORECASE)


def parse_event_date(date_str: Optional[str]) -> Optional[datetime]:
    """
    Return a sortable datetime for *date_str*, or None if unrecognised.

    The returned datetime is always the *start* of the inferred period so
    that earlier periods sort correctly against more precise dates.
    """
    if not date_str:
        return None

    s = date_str.strip()

    # 1. ISO-8601 exact date
    m = _ISO_RE.match(s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            pass

    # 2. ISO year-month  ("2024-03")
    m = _ISO_YM_RE.match(s)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), 1)
        except ValueError:
            pass

    # 3. Quarter  ("Q2 2024", "q3 2025")
    m = _QUARTER_RE.search(s)
    if m:
        q, yr = int(m.group(1)), int(m.group(2))
        return datetime(yr, _QUARTER_START[q], 1)

    # 4. Fiscal year  ("FY2023-24", "FY2023/24")
    m = _FISCAL_RE.search(s)
    if m:
        yr = int(m.group(1))
        return datetime(yr, 4, 1)  # Indian/UK fiscal year: April 1

    # 5. Month name + year  ("January 2025", "Mar 2024")
    m = _MONTH_YEAR_RE.search(s)
    if m:
        month = _MONTHS[m.group(1).lower()]
        yr = int(m.group(2))
        return datetime(yr, month, 1)

    # 6. Early / mid / late + year
    m = _RELATIVE_RE.search(s)
    if m:
        qualifier, yr_str = m.group(1).lower(), int(m.group(2))
        month = {"early": 1, "mid": 7, "late": 10}.get(qualifier, 1)
        return datetime(yr_str, month, 1)

    # 7. Bare year  ("2024")
    m = _YEAR_ONLY_RE.search(s)
    if m:
        return datetime(int(m.group()), 1, 1)

    return None


def parse_event_date_precision(date_str: Optional[str]) -> str:
    """
    Return a human-readable precision label for *date_str*.
    One of: "exact", "month", "quarter", "year", "approximate", "unknown".
    """
    if not date_str:
        return "unknown"
    s = date_str.strip()
    if _ISO_RE.match(s):
        return "exact"
    if _ISO_YM_RE.match(s):
        return "month"
    if _QUARTER_RE.search(s):
        return "quarter"
    if _FISCAL_RE.search(s):
        return "year"
    if _MONTH_YEAR_RE.search(s):
        return "month"
    if _RELATIVE_RE.search(s):
        return "approximate"
    if _YEAR_ONLY_RE.search(s):
        return "year"
    return "unknown"
