"""
Pydantic schemas for the Knowledge Graph extraction pipeline.

These schemas are used with ``LLMProvider.generate_structured()`` to get
type-safe structured output from the LLM for events, processes, causal
chains, and temporal relationships.
"""

from typing import List, Literal, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Event Participant
# ---------------------------------------------------------------------------

class EventParticipant(BaseModel):
    """An entity's role in an event."""

    model_config = {"extra": "forbid"}

    entity_name: str = Field(
        ...,
        description="Name of the participating entity (use the most formal name).",
    )
    entity_type: Optional[str] = Field(
        None,
        description="Type: PERSON, ORGANIZATION, PRODUCT, SERVICE, SYSTEM, CONCEPT.",
    )
    role: str = Field(
        ...,
        description=(
            "Role in the event: initiator, recipient, approver, subject, "
            "witness, owner, performer, beneficiary, regulator, etc."
        ),
    )


# ---------------------------------------------------------------------------
# Extracted Event
# ---------------------------------------------------------------------------

class ExtractedEvent(BaseModel):
    """A single event extracted from the document."""

    model_config = {"extra": "ignore"}  # allow provenance fields added post-extraction

    event_name: str = Field(
        ...,
        description=(
            "Concise, unique name for the event. Examples: "
            "'FDA Approval of Drug X', 'Board Meeting Q2 2024', "
            "'Salary Revision 2024', 'Quality Audit RM-MCC-0102'."
        ),
    )

    event_type: Literal[
        "action",
        "decision",
        "transaction",
        "communication",
        "milestone",
        "failure",
        "regulatory",
        "legal",
        "other",
    ] = Field(..., description="Category of the event.")

    description: str = Field(
        ...,
        description="1-2 sentence description of what happened.",
    )

    date: Optional[str] = Field(
        None,
        description=(
            "Date or date range in ISO-8601 (YYYY-MM-DD) or descriptive "
            "form ('Q2 2024', 'January 2025', 'FY2023-24')."
        ),
    )

    date_precision: Optional[Literal[
        "exact", "month", "quarter", "year", "approximate"
    ]] = Field(None, description="How precise the date is.")

    participants: List[EventParticipant] = Field(
        default_factory=list,
        description="ALL entities involved in this event with their roles.",
    )

    location: Optional[str] = Field(
        None, description="Where the event occurred, if mentioned."
    )

    outcome: Optional[str] = Field(
        None, description="Result or outcome of the event."
    )

    status: Optional[Literal[
        "completed", "in_progress", "planned", "cancelled"
    ]] = Field(None, description="Current status of the event.")

    event_identifiers: Optional[List[str]] = Field(
        default=None,
        description=(
            "Unique codes/IDs for this event (e.g. 'NDA-2024-001', "
            "meeting IDs, case numbers, batch numbers). Used for "
            "cross-document deduplication."
        ),
    )

    evidence: str = Field(
        ...,
        description="Short verbatim quote from the document (max 150 chars).",
    )

    confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Extraction confidence 0-1."
    )

    # Provenance: set by the pipeline after extraction, not by the LLM
    source_chunk_id: Optional[str] = Field(
        default=None, description="Chunk ID from which this event was extracted."
    )
    source_page_start: Optional[int] = Field(
        default=None, description="First page number of the source chunk (1-based)."
    )
    source_page_end: Optional[int] = Field(
        default=None, description="Last page number of the source chunk (1-based)."
    )


# ---------------------------------------------------------------------------
# Process Step
# ---------------------------------------------------------------------------

class ProcessStep(BaseModel):
    """A single step within a process."""

    model_config = {"extra": "forbid"}

    step_name: str = Field(..., description="Name of this step.")

    step_order: int = Field(
        ..., description="1-based position in the sequence."
    )

    description: Optional[str] = Field(
        None, description="Brief description of what happens in this step."
    )

    actor: Optional[str] = Field(
        None,
        description="Entity responsible for executing this step.",
    )

    input_artifacts: List[str] = Field(
        default_factory=list,
        description="Documents, materials, or data consumed by this step.",
    )

    output_artifacts: List[str] = Field(
        default_factory=list,
        description="Documents, materials, or data produced by this step.",
    )


# ---------------------------------------------------------------------------
# Extracted Process
# ---------------------------------------------------------------------------

class ExtractedProcess(BaseModel):
    """A multi-step process or workflow identified in the document."""

    model_config = {"extra": "ignore"}  # allow provenance fields added post-extraction

    process_name: str = Field(
        ...,
        description=(
            "Name of the process. Examples: 'Drug Approval Pipeline', "
            "'Employee Onboarding Workflow', 'Quality Control Testing'."
        ),
    )

    process_type: Literal[
        "workflow",
        "procedure",
        "lifecycle",
        "supply_chain",
        "approval_flow",
        "production",
        "investigation",
        "other",
    ] = Field(..., description="Category of the process.")

    description: str = Field(
        ..., description="1-2 sentence description of the process."
    )

    steps: List[ProcessStep] = Field(
        default_factory=list,
        description="Ordered steps in the process (at least 2 to be meaningful).",
    )

    owner_entity: Optional[str] = Field(
        None, description="Entity that owns or manages this process."
    )

    status: Optional[Literal[
        "active", "completed", "deprecated", "planned"
    ]] = Field(None, description="Current status of the process.")

    evidence: str = Field(
        ...,
        description="Short verbatim quote from the document supporting this.",
    )

    confidence: float = Field(
        default=0.8, ge=0.0, le=1.0, description="Extraction confidence 0-1."
    )

    # Provenance: set by the pipeline after extraction, not by the LLM
    source_chunk_id: Optional[str] = Field(
        default=None, description="Chunk ID from which this process was extracted."
    )
    source_page_start: Optional[int] = Field(
        default=None, description="First page number of the source chunk (1-based)."
    )
    source_page_end: Optional[int] = Field(
        default=None, description="Last page number of the source chunk (1-based)."
    )


# ---------------------------------------------------------------------------
# Causal Link
# ---------------------------------------------------------------------------

class ExtractedCausalLink(BaseModel):
    """A cause-effect relationship between events."""

    model_config = {"extra": "forbid"}

    cause_event: str = Field(
        ...,
        description="Name of the causing event (MUST match an event_name).",
    )

    effect_event: str = Field(
        ...,
        description="Name of the resulting event (MUST match an event_name).",
    )

    relationship_type: Literal[
        "caused_by",
        "led_to",
        "enabled",
        "blocked",
        "triggered",
        "influenced",
        "required_for",
    ] = Field(..., description="Type of causal relationship.")

    description: Optional[str] = Field(
        None, description="Brief explanation of the causal link."
    )

    confidence: float = Field(
        default=0.7, ge=0.0, le=1.0, description="Confidence 0-1."
    )

    evidence: str = Field(
        ...,
        description="Short verbatim quote from the document.",
    )


# ---------------------------------------------------------------------------
# Temporal Link
# ---------------------------------------------------------------------------

class ExtractedTemporalLink(BaseModel):
    """Temporal ordering between events."""

    model_config = {"extra": "ignore"}  # allow pipeline-set synthetic flag

    earlier_event: str = Field(
        ...,
        description="Event that happened first (MUST match an event_name).",
    )

    later_event: str = Field(
        ...,
        description="Event that happened second (MUST match an event_name).",
    )

    relationship_type: Literal[
        "preceded_by", "followed_by", "concurrent_with"
    ] = Field(..., description="Temporal relationship type.")

    time_gap: Optional[str] = Field(
        None,
        description="Duration between events if known (e.g. '3 months', '2 weeks').",
    )

    # Pipeline-set: True for cross-chunk synthesized links, never set by LLM
    synthetic: bool = Field(
        default=False,
        description="True when this link was inferred from page/date order, not extracted by LLM.",
    )


# ---------------------------------------------------------------------------
# Full Extraction Result
# ---------------------------------------------------------------------------

class KnowledgeGraphExtractionResult(BaseModel):
    """Complete knowledge graph extraction from a document chunk."""

    model_config = {"extra": "ignore"}

    events: List[ExtractedEvent] = Field(
        default_factory=list,
        description="All events identified in the document.",
    )

    processes: List[ExtractedProcess] = Field(
        default_factory=list,
        description="All multi-step processes identified in the document.",
    )

    causal_links: List[ExtractedCausalLink] = Field(
        default_factory=list,
        description=(
            "Causal relationships between events. cause_event and "
            "effect_event MUST exactly match event_name values."
        ),
    )

    temporal_links: List[ExtractedTemporalLink] = Field(
        default_factory=list,
        description=(
            "Temporal ordering between events. earlier_event and "
            "later_event MUST exactly match event_name values."
        ),
    )

    overall_confidence: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Overall confidence in the extraction quality.",
    )

    # Pipeline-populated fields (not produced by the LLM)
    chunk_id: Optional[str] = Field(
        default=None, description="Identifier of the chunk this result came from."
    )
    chunk_quality_score: Optional[float] = Field(
        default=None, description="Quality score assigned by KG extraction normalizer."
    )
    chunk_quality_issues: List[str] = Field(
        default_factory=list,
        description="List of quality issue descriptions for this chunk.",
    )


# ---------------------------------------------------------------------------
# Event Match Result (for LLM-based event dedup)
# ---------------------------------------------------------------------------

class EventMatchResult(BaseModel):
    """LLM output for deciding if two event mentions refer to the same event."""

    model_config = {"extra": "forbid"}

    is_same_event: bool = Field(
        ...,
        description="True if both mentions refer to the same real-world event.",
    )

    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence 0-1."
    )

    canonical_name: str = Field(
        ...,
        description="The best canonical name to use for this event.",
    )

    reasoning: str = Field(
        ..., description="Brief explanation of the decision."
    )
