"""
Standalone runner for the KG Query Service.

Usage::

    # Single intent queries
    python knowledge_graph/run_query.py --intent timeline --tenant org_123
    python knowledge_graph/run_query.py --intent causal --event "Temperature Excursion Recorded" --tenant org_123
    python knowledge_graph/run_query.py --intent causal --event "Temperature Excursion Recorded" --direction forward --tenant org_123
    python knowledge_graph/run_query.py --intent entity --entity "QA OOS Coordinator" --tenant org_123
    python knowledge_graph/run_query.py --intent steps --process "OOS Procedure" --tenant org_123
    python knowledge_graph/run_query.py --intent evidence --event "Root Cause Confirmation" --tenant org_123
    python knowledge_graph/run_query.py --intent search --query "HPLC failure particulate" --tenant org_123

    # Print full JSON to stdout
    python knowledge_graph/run_query.py --intent timeline --tenant org_123 --json

    # Run pharma evaluation test suite
    python knowledge_graph/run_query.py --test --tenant org_123
"""

import argparse
import json
import logging
import sys
from pathlib import Path

_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from knowledge_graph.query_service import KGQueryService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)

# ── Pharma test suite ────────────────────────────────────────────────────────
# These queries are expected to return non-empty results for the 7 pharma
# case PDFs ingested in Graph_Validation_Data/.

PHARMA_TIMELINE_QUERIES = [
    ("timeline",  None,                                        None),
]

PHARMA_ENTITY_QUERIES = [
    ("entity",    "QA OOS Coordinator",                        None),
    ("entity",    "3PL Carrier",                               None),
    ("entity",    "Inspectorate",                              None),
]

PHARMA_EVIDENCE_QUERIES = [
    ("evidence",  "EM System Alert for Non-Viable Particulates", None),
    ("evidence",  "HPLC Assay Failure - API Potency (Lot API-26-033)", None),
    ("evidence",  "Temperature Excursion Recorded",              None),
]

PHARMA_SEARCH_QUERIES = [
    ("search",    "HPLC failure",                              None),
    ("search",    "temperature excursion cold chain",           None),
    ("search",    "CAPA regulatory inspection",                 None),
]

PHARMA_CAUSAL_QUERIES = [
    ("causal",    "Temperature Excursion Recorded",            "both"),
    ("causal",    "EM System Alert for Non-Viable Particulates", "forward"),
    ("causal",    "Mobile Phase pH Out of Tolerance",           "forward"),
]

PHARMA_PROCESS_QUERIES = [
    ("steps",     "OOS Procedure",                             None),
    ("steps",     "Deviation Handling",                        None),
    ("steps",     "GDP Shipment Qualification",                 None),
]

ALL_TEST_QUERIES = (
    PHARMA_TIMELINE_QUERIES
    + PHARMA_ENTITY_QUERIES
    + PHARMA_EVIDENCE_QUERIES
    + PHARMA_SEARCH_QUERIES
    + PHARMA_CAUSAL_QUERIES
    + PHARMA_PROCESS_QUERIES
)


def run_intent(svc: KGQueryService, intent: str, args: argparse.Namespace) -> dict:
    """Dispatch to the correct service method based on intent."""
    if intent == "timeline":
        return svc.get_chronological_timeline(
            entity_filter=getattr(args, "entity", None),
            start_date=getattr(args, "start_date", None),
            end_date=getattr(args, "end_date", None),
        )
    elif intent == "causal":
        return svc.get_causal_chain(
            event_name=args.event,
            direction=getattr(args, "direction", "both"),
            max_depth=getattr(args, "depth", 5),
        )
    elif intent == "entity":
        return svc.get_entity_timeline(entity_name=args.entity)
    elif intent == "steps":
        return svc.get_process_steps(process_name=args.process)
    elif intent == "evidence":
        return svc.get_event_evidence(event_name=args.event)
    elif intent == "search":
        return svc.search_events(keywords=args.query, limit=getattr(args, "limit", 20))
    else:
        return {"error": f"Unknown intent: {intent}"}


def _print_timeline(result: dict) -> None:
    if "error" in result:
        logger.error("Timeline query failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  CHRONOLOGICAL TIMELINE — {result['total_events']} events")
    print(f"  by_date={result['events_with_dates']}  by_graph={result['events_via_graph']}  inferred={result['events_inferred']}")
    print(f"{'='*70}")
    for evt in result.get("timeline", []):
        method_sym = {"date": "📅", "graph_edge": "🔗", "inferred": "  "}
        date_str = evt.get("date") or "no date"
        docs = ", ".join(evt.get("source_documents", []))
        print(f"  {evt['position']:3}. [{method_sym.get(evt['position_method'], '?')}] {evt['event_name']}")
        print(f"       date={date_str}  ({evt['date_precision']})  confidence={evt.get('confidence', 0):.2f}")
        if docs:
            print(f"       docs={docs}")
    print(f"{'='*70}\n")


def _print_causal(result: dict) -> None:
    if "error" in result:
        logger.error("Causal query failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  CAUSAL CHAIN FROM: {result['root_event']}  ({result['direction']})")
    print(f"{'='*70}")
    for hop in result.get("hops", []):
        print(f"  {hop['from_event']}")
        print(f"    --[{hop.get('relationship_type', 'CAUSED')} conf={hop.get('confidence', 0):.2f}]-->")
        print(f"  {hop['to_event']}")
        if hop.get("description"):
            print(f"    ↳ {hop['description']}")
    if not result.get("hops"):
        print("  (no causal path found)")
    print(f"{'='*70}\n")


def _print_entity(result: dict) -> None:
    if "error" in result:
        logger.error("Entity timeline failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  ENTITY TIMELINE: {result['entity_name']}  ({result['event_count']} events)")
    print(f"{'='*70}")
    for evt in result.get("timeline", []):
        print(f"  {evt['position']:3}. [{evt.get('role', '?')}] {evt['event_name']}  ({evt.get('date') or 'no date'})")
    print(f"{'='*70}\n")


def _print_steps(result: dict) -> None:
    if "error" in result:
        logger.error("Process steps failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  PROCESS: {result['process_name']}  ({result['step_count']} steps)")
    print(f"{'='*70}")
    for step in result.get("steps", []):
        actor = f" [{step['actor']}]" if step.get("actor") else ""
        print(f"  Step {step['step_order']}: {step['step_name']}{actor}")
        if step.get("description"):
            print(f"    {step['description']}")
    print(f"{'='*70}\n")


def _print_evidence(result: dict) -> None:
    if "error" in result:
        logger.error("Evidence query failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  EVIDENCE: {result['event_name']}  ({result['document_count']} docs)")
    print(f"{'='*70}")
    for entry in result.get("evidence", []):
        print(f"  📄 {entry.get('file_name') or entry.get('document_id')}")
        if entry.get("page"):
            print(f"    page={entry['page']}", end="  ")
        if entry.get("chunk_id"):
            print(f"chunk={entry['chunk_id']}", end="")
        print()
        if entry.get("evidence"):
            print(f"    \"{entry['evidence'][:200]}\"")
    print(f"{'='*70}\n")


def _print_search(result: dict) -> None:
    if "error" in result:
        logger.error("Search failed: %s", result["error"])
        return
    print(f"\n{'='*70}")
    print(f"  SEARCH: \"{result['query']}\"  ({result['total_hits']} hits)")
    print(f"{'='*70}")
    for hit in result.get("hits", []):
        print(f"  [{hit['score']:.3f}] {hit['event_name']}  ({hit.get('date') or 'no date'})")
        if hit.get("description"):
            print(f"    {hit['description'][:120]}")
    print(f"{'='*70}\n")


_PRINTERS = {
    "timeline": _print_timeline,
    "causal": _print_causal,
    "entity": _print_entity,
    "steps": _print_steps,
    "evidence": _print_evidence,
    "search": _print_search,
}


def run_test_suite(svc: KGQueryService, emit_json: bool = False) -> None:
    """Run all pharma test queries and print a pass/fail summary."""
    results = []
    passed = 0
    failed = 0

    for intent, arg1, arg2 in ALL_TEST_QUERIES:
        label = f"{intent}({arg1 or ''})"

        # Build a minimal namespace
        ns = argparse.Namespace(
            event=arg1 if intent in ("causal", "evidence") else None,
            entity=arg1 if intent == "entity" else None,
            process=arg1 if intent == "steps" else None,
            query=arg1 if intent == "search" else None,
            direction=arg2 or "both",
            depth=5,
            limit=20,
            start_date=None,
            end_date=None,
        )
        result = run_intent(svc, intent, ns)

        has_error = "error" in result
        has_data = (
            result.get("timeline") or result.get("hops") or result.get("timeline") or
            result.get("steps") or result.get("evidence") or result.get("hits") or
            result.get("event_count", 0) > 0
        )

        status = "PASS" if (not has_error and has_data) else "FAIL"
        if status == "PASS":
            passed += 1
        else:
            failed += 1

        entry = {"intent": intent, "arg": arg1, "status": status}
        if has_error:
            entry["error"] = result["error"]
        results.append(entry)
        logger.info("%-8s  %-60s  %s", intent, (arg1 or "")[:60], status)

    print(f"\n{'='*70}")
    print(f"  TEST SUITE COMPLETE: {passed} passed, {failed} failed / {len(ALL_TEST_QUERIES)} total")
    print(f"{'='*70}\n")

    if emit_json:
        print(json.dumps({"results": results, "passed": passed, "failed": failed}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="KG Query Service CLI")
    parser.add_argument("--tenant", "-t", required=True, help="Tenant ID")
    parser.add_argument(
        "--intent", "-i",
        choices=["timeline", "causal", "entity", "steps", "evidence", "search"],
        help="Query intent",
    )
    parser.add_argument("--event",    help="Event name (for causal / evidence)")
    parser.add_argument("--entity",   help="Entity name (for entity / timeline filter)")
    parser.add_argument("--process",  help="Process name (for steps)")
    parser.add_argument("--query",    help="Search keywords (for search)")
    parser.add_argument("--direction", choices=["forward", "backward", "both"],
                        default="both", help="Causal traversal direction (default: both)")
    parser.add_argument("--depth",    type=int, default=5, help="Max causal depth (default: 5)")
    parser.add_argument("--limit",    type=int, default=20, help="Search result limit (default: 20)")
    parser.add_argument("--start-date", dest="start_date", default=None,
                        help="Timeline start date filter (ISO-8601 or descriptive)")
    parser.add_argument("--end-date",   dest="end_date",   default=None,
                        help="Timeline end date filter")
    parser.add_argument("--json", action="store_true", default=False,
                        help="Print full result as JSON to stdout")
    parser.add_argument("--test", action="store_true", default=False,
                        help="Run pharma eval test suite")

    args = parser.parse_args()
    svc = KGQueryService(tenant_id=args.tenant)

    if args.test:
        run_test_suite(svc, emit_json=args.json)
        return

    if not args.intent:
        parser.error("--intent is required (or use --test)")

    result = run_intent(svc, args.intent, args)

    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        printer = _PRINTERS.get(args.intent)
        if printer:
            printer(result)
        else:
            print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
