"""
SchemaParser – converts Excel/CSV parsed output and SQL schema JSON
into a unified internal representation for ontology extraction.

Supports three input formats:
- Excel files (.xlsx, .xls) via parsers/xlsx_parser.py
- CSV files (.csv) via parsers/csv_parser.py
- SQL schema JSON (user-provided dict with tables, columns, foreign keys)
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

MAX_SAMPLE_ROWS = 3
MAX_SAMPLE_VALUES_PER_FIELD = 5


# ---------------------------------------------------------------------------
# Internal data structures
# ---------------------------------------------------------------------------

@dataclass
class ParsedField:
    """A single column/field from a table or sheet."""
    name: str
    data_type: str = "unknown"
    is_primary_key: bool = False
    foreign_key_ref: Optional[str] = None  # e.g. "departments.department_id"
    sample_values: List[str] = field(default_factory=list)


@dataclass
class ParsedTable:
    """A single table or sheet."""
    name: str
    fields: List[ParsedField] = field(default_factory=list)
    row_count: int = 0
    sample_rows: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ParsedSchema:
    """Complete parsed schema from any source."""
    source_name: str
    source_type: str  # "database", "spreadsheet", "csv"
    tables: List[ParsedTable] = field(default_factory=list)
    raw_metadata: Dict[str, Any] = field(default_factory=dict)

    def to_prompt_text(self) -> str:
        """Serialize to human-readable text for LLM prompt."""
        lines = [f"Source: {self.source_name} (type: {self.source_type})\n"]

        for table in self.tables:
            lines.append(f"Table: {table.name} (rows: {table.row_count})")
            lines.append("  Columns:")
            for f in table.fields:
                parts = [f"    - {f.name}: {f.data_type}"]
                if f.is_primary_key:
                    parts.append("[PRIMARY KEY]")
                if f.foreign_key_ref:
                    parts.append(f"[FK -> {f.foreign_key_ref}]")
                if f.sample_values:
                    samples = ", ".join(str(v) for v in f.sample_values[:3])
                    parts.append(f"(samples: {samples})")
                lines.append(" ".join(parts))

            if table.sample_rows:
                lines.append(f"  Sample Data ({len(table.sample_rows)} rows):")
                for row in table.sample_rows[:MAX_SAMPLE_ROWS]:
                    row_str = " | ".join(
                        f"{k}: {v}" for k, v in list(row.items())[:8]
                    )
                    lines.append(f"    {row_str}")
            lines.append("")

        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Parser class
# ---------------------------------------------------------------------------

class SchemaParser:
    """Parse Excel/CSV files and SQL JSON into a unified ParsedSchema."""

    @staticmethod
    def from_xlsx(file_path: str, max_sample_rows: int = MAX_SAMPLE_ROWS) -> ParsedSchema:
        """
        Parse an Excel file into a ParsedSchema.

        Uses the existing XLSXParser to extract sheets, columns, and data.
        """
        from parsers.xlsx_parser import XLSXParser

        path = Path(file_path)
        parser = XLSXParser()
        result = parser.parse(str(path))

        tables = []
        sheets = result.get("sheets", {})
        metadata = result.get("metadata", {})

        for sheet_name, df in sheets.items():
            fields = []
            for col in df.columns:
                dtype_str = str(df[col].dtype)
                # Collect sample values
                samples = []
                for val in df[col].dropna().head(MAX_SAMPLE_VALUES_PER_FIELD):
                    samples.append(str(val))

                fields.append(ParsedField(
                    name=str(col),
                    data_type=dtype_str,
                    sample_values=samples,
                ))

            sample_rows = []
            for _, row in df.head(max_sample_rows).iterrows():
                sample_rows.append({
                    str(k): str(v) if v is not None else ""
                    for k, v in row.items()
                })

            tables.append(ParsedTable(
                name=sheet_name,
                fields=fields,
                row_count=len(df),
                sample_rows=sample_rows,
            ))

        return ParsedSchema(
            source_name=path.name,
            source_type="spreadsheet",
            tables=tables,
            raw_metadata=metadata,
        )

    @staticmethod
    def from_csv(file_path: str, max_sample_rows: int = MAX_SAMPLE_ROWS) -> ParsedSchema:
        """
        Parse a CSV file into a ParsedSchema.

        Uses the existing CSVParser to extract headers and data.
        """
        from parsers.csv_parser import CSVParser

        path = Path(file_path)
        parser = CSVParser()
        result = parser.parse(str(path))

        data = result.get("data", [])
        meta = result.get("metadata", {})
        columns = meta.get("columns", [])

        fields = []
        for col in columns:
            samples = []
            for row in data[:MAX_SAMPLE_VALUES_PER_FIELD]:
                val = row.get(col)
                if val is not None and str(val).strip():
                    samples.append(str(val))
            fields.append(ParsedField(
                name=col,
                data_type=SchemaParser._infer_csv_type(col, data),
                sample_values=samples,
            ))

        sample_rows = []
        for row in data[:max_sample_rows]:
            sample_rows.append({str(k): str(v) for k, v in row.items()})

        table = ParsedTable(
            name=path.stem,
            fields=fields,
            row_count=len(data),
            sample_rows=sample_rows,
        )

        return ParsedSchema(
            source_name=path.name,
            source_type="csv",
            tables=[table],
            raw_metadata=meta,
        )

    @staticmethod
    def from_sql_json(schema_json: Dict[str, Any]) -> ParsedSchema:
        """
        Parse a SQL schema JSON definition into a ParsedSchema.

        Expected JSON format::

            {
                "database_name": "hr_system",
                "tables": [
                    {
                        "table_name": "employees",
                        "columns": [
                            {
                                "name": "employee_id",
                                "type": "INTEGER",
                                "primary_key": true,
                                "foreign_key": {
                                    "references": "departments.department_id"
                                }
                            },
                            ...
                        ]
                    }
                ]
            }
        """
        db_name = schema_json.get("database_name", "unknown_database")
        tables = []

        for table_def in schema_json.get("tables", []):
            table_name = table_def.get("table_name", "unknown")
            fields = []

            for col_def in table_def.get("columns", []):
                fk_ref = None
                fk = col_def.get("foreign_key")
                if fk and isinstance(fk, dict):
                    fk_ref = fk.get("references")

                fields.append(ParsedField(
                    name=col_def.get("name", "unknown"),
                    data_type=col_def.get("type", "unknown"),
                    is_primary_key=col_def.get("primary_key", False),
                    foreign_key_ref=fk_ref,
                ))

            row_count = table_def.get("row_count", 0)
            sample_rows = table_def.get("sample_data", [])[:MAX_SAMPLE_ROWS]

            tables.append(ParsedTable(
                name=table_name,
                fields=fields,
                row_count=row_count,
                sample_rows=sample_rows,
            ))

        return ParsedSchema(
            source_name=db_name,
            source_type="database",
            tables=tables,
            raw_metadata={"original_json_keys": list(schema_json.keys())},
        )

    @staticmethod
    def _infer_csv_type(column_name: str, data: List[Dict[str, Any]]) -> str:
        """Infer a basic data type for a CSV column from sample values."""
        values = [row.get(column_name) for row in data[:20] if row.get(column_name)]
        if not values:
            return "string"

        # Check if numeric
        numeric_count = 0
        for v in values:
            try:
                float(str(v).replace(",", "").replace("$", "").replace("%", ""))
                numeric_count += 1
            except ValueError:
                pass

        if numeric_count > len(values) * 0.8:
            return "numeric"

        # Check if date-like
        date_patterns = [
            r"\d{4}-\d{2}-\d{2}",
            r"\d{2}/\d{2}/\d{4}",
            r"\d{2}-\d{2}-\d{4}",
        ]
        date_count = sum(
            1 for v in values
            if any(re.match(p, str(v)) for p in date_patterns)
        )
        if date_count > len(values) * 0.8:
            return "date"

        return "string"
