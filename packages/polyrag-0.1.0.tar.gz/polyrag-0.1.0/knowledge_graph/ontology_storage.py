"""
OntologyStorage – MERGE-based Neo4j storage for schema ontology nodes.

Provides MERGE operations for DataSource, DataTable, and DataField nodes
plus their relationships (HAS_TABLE, HAS_FIELD, FOREIGN_KEY, TRACKS,
DESCRIBES_ATTRIBUTE).

Uses deterministic IDs for idempotent re-processing:
    source_id = "{tenant_id}_{source_name_slug}"
    table_id  = "{source_id}_{table_name_slug}"
    field_id  = "{table_id}_{field_name_slug}"
"""

import logging
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from connectors.neo4j_connector import Neo4jConnector

logger = logging.getLogger(__name__)


class OntologyStorage:
    """MERGE-based Neo4j storage for schema ontology."""

    def __init__(self, tenant_id: str):
        self.neo4j = Neo4jConnector(tenant_id=tenant_id)
        self.tenant_id = tenant_id

    # ------------------------------------------------------------------
    # Schema initialisation
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Create constraints and indexes for ontology nodes."""
        neo4j_logger = logging.getLogger("neo4j.notifications")
        prev_level = neo4j_logger.level
        neo4j_logger.setLevel(logging.WARNING)

        statements = [
            # Constraints
            "CREATE CONSTRAINT datasource_unique IF NOT EXISTS "
            "FOR (ds:DataSource) REQUIRE (ds.source_id, ds.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT datatable_unique IF NOT EXISTS "
            "FOR (dt:DataTable) REQUIRE (dt.table_id, dt.tenant_id) IS UNIQUE",

            "CREATE CONSTRAINT datafield_unique IF NOT EXISTS "
            "FOR (df:DataField) REQUIRE (df.field_id, df.tenant_id) IS UNIQUE",

            # Indexes
            "CREATE INDEX datatable_name_idx IF NOT EXISTS "
            "FOR (dt:DataTable) ON (dt.name, dt.tenant_id)",

            "CREATE INDEX datafield_name_idx IF NOT EXISTS "
            "FOR (df:DataField) ON (df.name, df.tenant_id)",

            "CREATE INDEX datatable_entity_type_idx IF NOT EXISTS "
            "FOR (dt:DataTable) ON (dt.entity_type_represented, dt.tenant_id)",

            # Full-text search
            "CREATE FULLTEXT INDEX datatable_fulltext IF NOT EXISTS "
            "FOR (dt:DataTable) ON EACH [dt.name, dt.semantic_description]",
        ]

        for stmt in statements:
            try:
                self.neo4j.execute_write_query(stmt)
            except Exception:
                logger.debug("Schema statement skipped: %s", stmt[:80])

        neo4j_logger.setLevel(prev_level)
        logger.info("Ontology schema ensured (constraints + indexes)")

    # ------------------------------------------------------------------
    # ID generation
    # ------------------------------------------------------------------

    def make_source_id(self, source_name: str) -> str:
        """Generate deterministic source_id."""
        return f"{self.tenant_id}_{self._slugify(source_name)}"

    def make_table_id(self, source_id: str, table_name: str) -> str:
        """Generate deterministic table_id."""
        return f"{source_id}_{self._slugify(table_name)}"

    def make_field_id(self, table_id: str, field_name: str) -> str:
        """Generate deterministic field_id."""
        return f"{table_id}_{self._slugify(field_name)}"

    # ------------------------------------------------------------------
    # Node MERGE operations
    # ------------------------------------------------------------------

    def merge_data_source(
        self, source_id: str, properties: Dict[str, Any]
    ) -> None:
        """MERGE a DataSource node."""
        query = """
        MERGE (ds:DataSource {source_id: $source_id, tenant_id: $tenant_id})
        ON CREATE SET ds += $props, ds.created_at = datetime()
        ON MATCH SET ds += $props, ds.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "source_id": source_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    def merge_data_table(
        self, table_id: str, properties: Dict[str, Any]
    ) -> None:
        """MERGE a DataTable node."""
        query = """
        MERGE (dt:DataTable {table_id: $table_id, tenant_id: $tenant_id})
        ON CREATE SET dt += $props, dt.created_at = datetime()
        ON MATCH SET dt += $props, dt.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "table_id": table_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    def merge_data_field(
        self, field_id: str, properties: Dict[str, Any]
    ) -> None:
        """MERGE a DataField node."""
        query = """
        MERGE (df:DataField {field_id: $field_id, tenant_id: $tenant_id})
        ON CREATE SET df += $props, df.created_at = datetime()
        ON MATCH SET df += $props, df.updated_at = datetime()
        """
        self.neo4j.execute_write_query(query, {
            "field_id": field_id,
            "tenant_id": self.tenant_id,
            "props": self._clean_props(properties),
        })

    # ------------------------------------------------------------------
    # Relationship MERGE operations
    # ------------------------------------------------------------------

    def merge_has_table(self, source_id: str, table_id: str) -> None:
        """MERGE HAS_TABLE: DataSource -> DataTable."""
        query = """
        MATCH (ds:DataSource {source_id: $source_id, tenant_id: $tenant_id})
        MATCH (dt:DataTable {table_id: $table_id, tenant_id: $tenant_id})
        MERGE (ds)-[:HAS_TABLE]->(dt)
        """
        self.neo4j.execute_write_query(query, {
            "source_id": source_id,
            "table_id": table_id,
            "tenant_id": self.tenant_id,
        })

    def merge_has_field(self, table_id: str, field_id: str) -> None:
        """MERGE HAS_FIELD: DataTable -> DataField."""
        query = """
        MATCH (dt:DataTable {table_id: $table_id, tenant_id: $tenant_id})
        MATCH (df:DataField {field_id: $field_id, tenant_id: $tenant_id})
        MERGE (dt)-[:HAS_FIELD]->(df)
        """
        self.neo4j.execute_write_query(query, {
            "table_id": table_id,
            "field_id": field_id,
            "tenant_id": self.tenant_id,
        })

    def merge_foreign_key(
        self,
        from_field_id: str,
        to_field_id: str,
        description: Optional[str] = None,
    ) -> None:
        """MERGE FOREIGN_KEY: DataField -> DataField."""
        query = """
        MATCH (src:DataField {field_id: $from_id, tenant_id: $tenant_id})
        MATCH (tgt:DataField {field_id: $to_id, tenant_id: $tenant_id})
        MERGE (src)-[r:FOREIGN_KEY]->(tgt)
        SET r.description = $description
        """
        self.neo4j.execute_write_query(query, {
            "from_id": from_field_id,
            "to_id": to_field_id,
            "tenant_id": self.tenant_id,
            "description": description or "",
        })

    def merge_tracks(
        self, table_id: str, entity_id: str, confidence: float = 0.8
    ) -> None:
        """MERGE TRACKS: DataTable -> Entity."""
        query = """
        MATCH (dt:DataTable {table_id: $table_id, tenant_id: $tenant_id})
        MATCH (e:Entity {entity_id: $entity_id, tenant_id: $tenant_id})
        MERGE (dt)-[r:TRACKS]->(e)
        SET r.confidence = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "table_id": table_id,
            "entity_id": entity_id,
            "tenant_id": self.tenant_id,
            "confidence": confidence,
        })

    def merge_describes_attribute(
        self, field_id: str, entity_id: str, confidence: float = 0.8
    ) -> None:
        """MERGE DESCRIBES_ATTRIBUTE: DataField -> Entity."""
        query = """
        MATCH (df:DataField {field_id: $field_id, tenant_id: $tenant_id})
        MATCH (e:Entity {entity_id: $entity_id, tenant_id: $tenant_id})
        MERGE (df)-[r:DESCRIBES_ATTRIBUTE]->(e)
        SET r.confidence = $confidence
        """
        self.neo4j.execute_write_query(query, {
            "field_id": field_id,
            "entity_id": entity_id,
            "tenant_id": self.tenant_id,
            "confidence": confidence,
        })

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_entities_by_type(self, entity_type: str) -> List[Dict[str, Any]]:
        """Get all Entity nodes of a given type for linking."""
        query = """
        MATCH (e:Entity {tenant_id: $tenant_id})
        WHERE e.type = $entity_type
        RETURN e.entity_id AS entity_id, e.name AS name, e.type AS type
        """
        return self.neo4j.execute_query(query, {
            "tenant_id": self.tenant_id,
            "entity_type": entity_type,
        })

    def get_all_entities(self, limit: int = 200) -> List[Dict[str, Any]]:
        """Get all Entity nodes for linking."""
        query = """
        MATCH (e:Entity {tenant_id: $tenant_id})
        RETURN e.entity_id AS entity_id, e.name AS name, e.type AS type
        LIMIT $limit
        """
        return self.neo4j.execute_query(query, {
            "tenant_id": self.tenant_id,
            "limit": limit,
        })

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _slugify(text: str) -> str:
        """Convert text to a URL-safe slug for ID generation."""
        text = text.lower().strip()
        text = re.sub(r"[^a-z0-9]+", "_", text)
        return text.strip("_")

    @staticmethod
    def _clean_props(props: Dict[str, Any]) -> Dict[str, Any]:
        """Clean properties for Neo4j compatibility."""
        cleaned = {}
        for k, v in props.items():
            if v is None:
                continue
            if isinstance(v, datetime):
                cleaned[k] = v.isoformat()
            elif isinstance(v, (list, tuple)):
                cleaned[k] = [
                    str(item) if not isinstance(item, (str, int, float, bool)) else item
                    for item in v
                ]
            elif isinstance(v, dict):
                import json
                cleaned[k] = json.dumps(v)
            else:
                cleaned[k] = v
        return cleaned

    def close(self) -> None:
        """Close the underlying Neo4j connection."""
        self.neo4j.close()
