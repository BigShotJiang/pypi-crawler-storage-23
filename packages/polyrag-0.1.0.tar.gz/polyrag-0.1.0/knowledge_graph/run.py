"""
Standalone runner for the Knowledge Graph Pipeline.

Usage:
    # From command line
    python -m knowledge_graph.run /path/to/file.pdf --tenant org_123 --user user_456

    # From Python
    from knowledge_graph.run import run_kg_pipeline
    result = run_kg_pipeline("/path/to/report.pdf", tenant_id="org_123", user_id="user_456")
"""

import argparse
import json
import logging
import sys
import uuid
from pathlib import Path

# Ensure project root is on sys.path so imports work when invoked directly
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from knowledge_graph.pipeline import KnowledgeGraphPipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)


def run_kg_pipeline(
    file_path: str,
    tenant_id: str,
    user_id: str,
    document_id: str | None = None,
    use_llm_event_matching: bool = False,
    similarity_threshold: float = 0.80,
) -> dict:
    """
    Run the full Knowledge Graph pipeline on a single file.

    Parameters
    ----------
    file_path : str
        Path to the document (PDF, DOCX, TXT, etc.)
    tenant_id : str
        Tenant / organisation ID.
    user_id : str
        ID of the user who uploaded the document.
    document_id : str, optional
        Pre-assigned document ID (defaults to generated uuid).
    use_llm_event_matching : bool
        Enable LLM-based event resolution for ambiguous cases.
    similarity_threshold : float
        Fuzzy-match threshold for event resolution (0-1).

    Returns
    -------
    dict
        Pipeline result with event/process counts and graph stats.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    doc_id = document_id or str(uuid.uuid4())

    pipeline = KnowledgeGraphPipeline(
        tenant_id=tenant_id,
        use_llm_event_matching=use_llm_event_matching,
        similarity_threshold=similarity_threshold,
    )

    logger.info("=" * 60)
    logger.info("KNOWLEDGE GRAPH PIPELINE")
    logger.info("=" * 60)
    logger.info("File:      %s", path.name)
    logger.info("Tenant:    %s", tenant_id)
    logger.info("User:      %s", user_id)
    logger.info("-" * 60)

    result = pipeline.process_file(
        file_path=str(path),
        tenant_id=tenant_id,
        user_id=user_id,
        document_id=doc_id,
    )

    # ---- Print summary ----
    logger.info("-" * 60)
    if "error" in result:
        logger.error("Pipeline failed: %s", result["error"])
        return result

    logger.info("Document ID:           %s", result["document_id"])
    logger.info("Events extracted:      %d", result.get("events_extracted", 0))
    logger.info("Processes extracted:   %d", result.get("processes_extracted", 0))
    logger.info("Causal links:          %d", result.get("causal_links", 0))
    logger.info("Temporal links:        %d", result.get("temporal_links", 0))
    logger.info("New events:            %d", result.get("new_events", 0))
    logger.info("New processes:         %d", result.get("new_processes", 0))
    logger.info("Entity relationships:  %d", result.get("entity_relationships_created", 0))
    if result.get("llm_budget_estimate"):
        est = result["llm_budget_estimate"]
        logger.info(
            "LLM estimate:         req=%s total_tokens=%s min_minutes@tpm=%s model=%s",
            est.get("estimated_request_count"),
            est.get("estimated_total_tokens"),
            est.get("estimated_min_minutes_at_tpm"),
            est.get("provider_model"),
        )
    logger.info("=" * 60)

    return result


# -----------------------------------------------------------------------
# CLI entry point
# -----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Run the Knowledge Graph Pipeline on a single file.",
    )
    parser.add_argument(
        "file",
        help="Path to the document file (PDF, DOCX, TXT, etc.)",
    )
    parser.add_argument(
        "--tenant", "-t",
        required=True,
        help="Tenant / organisation ID",
    )
    parser.add_argument(
        "--user", "-u",
        required=True,
        help="User ID",
    )
    parser.add_argument(
        "--document-id",
        default=None,
        help="Pre-assigned document ID (auto-generated if omitted)",
    )
    parser.add_argument(
        "--llm-matching",
        action="store_true",
        default=False,
        help="Enable LLM-based event matching (slower, more accurate)",
    )
    parser.add_argument(
        "--similarity",
        type=float,
        default=0.80,
        help="Fuzzy-match threshold for event resolution (default: 0.80)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Print full result as JSON to stdout",
    )

    parser.add_argument(
        "--mode",
        choices=["document", "schema"],
        default="document",
        help="Pipeline mode: 'document' for PDF/DOCX event extraction, "
             "'schema' for Excel/CSV/SQL ontology extraction (default: document)",
    )
    parser.add_argument(
        "--sql-schema-file",
        default=None,
        help="Path to SQL schema JSON file (used with --mode schema)",
    )
    parser.add_argument(
        "--llm-linking",
        action="store_true",
        default=False,
        help="Enable LLM-based entity linking for schema ontology (slower, more accurate)",
    )

    args = parser.parse_args()

    if args.mode == "schema":
        result = run_schema_ontology(
            source=args.file,
            tenant_id=args.tenant,
            user_id=args.user,
            sql_schema_file=args.sql_schema_file,
            use_llm_linking=args.llm_linking,
        )
    else:
        result = run_kg_pipeline(
            file_path=args.file,
            tenant_id=args.tenant,
            user_id=args.user,
            document_id=args.document_id,
            use_llm_event_matching=args.llm_matching,
            similarity_threshold=args.similarity,
        )

    if args.json:
        print(json.dumps(result, indent=2, default=str))


def run_schema_ontology(
    source: str,
    tenant_id: str,
    user_id: str,
    sql_schema_file: str | None = None,
    use_llm_linking: bool = False,
) -> dict:
    """
    Run schema ontology extraction on an Excel/CSV file or SQL JSON.
    """
    from knowledge_graph.pipeline import KnowledgeGraphPipeline

    sql_schema_json = None
    if sql_schema_file:
        with open(sql_schema_file) as f:
            sql_schema_json = json.load(f)

    pipeline = KnowledgeGraphPipeline(tenant_id=tenant_id)

    logger.info("=" * 60)
    logger.info("SCHEMA ONTOLOGY PIPELINE")
    logger.info("=" * 60)
    logger.info("Source:    %s", source)
    logger.info("Tenant:    %s", tenant_id)
    logger.info("User:      %s", user_id)
    logger.info("-" * 60)

    result = pipeline.process_schema(
        source=source,
        tenant_id=tenant_id,
        user_id=user_id,
        sql_schema_json=sql_schema_json,
        use_llm_linking=use_llm_linking,
    )

    logger.info("-" * 60)
    if "error" in result:
        logger.error("Pipeline failed: %s", result["error"])
        return result

    logger.info("Source:                %s", result.get("source_name"))
    logger.info("Domain:                %s", result.get("domain"))
    logger.info("Tables analyzed:       %d", result.get("tables_analyzed", 0))
    logger.info("Tables created:        %d", result.get("data_tables_created", 0))
    logger.info("Fields created:        %d", result.get("data_fields_created", 0))
    logger.info("Foreign keys:          %d", result.get("foreign_keys_created", 0))
    logger.info("Relationships inferred: %d", result.get("relationships_inferred", 0))
    logger.info("Tracks links (type):   %d", result.get("tracks_links_type_based", 0))
    logger.info("Tracks links (name):   %d", result.get("tracks_links_name_based", 0))
    logger.info("Describes links:       %d", result.get("describes_attribute_links", 0))
    logger.info("=" * 60)

    return result


if __name__ == "__main__":
    main()
