"""
EventResolver – resolves extracted events and processes to canonical IDs.

Resolution strategy for events (in order):
1. Identifier match (case IDs, meeting IDs, batch numbers).
2. Exact name + date match within same tenant.
3. Fuzzy name + date proximity (SequenceMatcher >= threshold, dates within 7 days).
4. LLM-based matching for ambiguous cases (optional, expensive).
5. Create a new event_id if no match found.

Resolution strategy for processes:
1. Exact name match within same tenant.
2. Fuzzy name match (>= 0.85).
3. Create a new process_id if no match found.

Events are resolved against Neo4j (the graph's source of truth), not MongoDB.
"""

import logging
import uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

from connectors.neo4j_connector import Neo4jConnector
from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .schemas import ExtractedEvent, ExtractedProcess, EventMatchResult
from .feature_flags import (
    get_event_resolver_candidate_limit,
    get_event_resolver_date_proximity_days,
    get_event_resolver_process_fuzzy_threshold,
    get_event_resolver_llm_confidence_floor,
    get_event_resolver_date_proximity_boost,
    get_event_resolver_llm_top_candidates,
)
from . import prompts as P

logger = logging.getLogger(__name__)
_neo4j_notifications = logging.getLogger("neo4j.notifications")


@contextmanager
def _quiet_neo4j():
    """Suppress expected Neo4j property-not-yet-exist warnings during reads.

    Neo4j emits notification 01N52 ("property key does not exist") when a
    query references a property (e.g. ``created_at``, ``identifiers``) that
    hasn't been written to ANY node yet in the database.  This is harmless
    on first run — the property is created by the MERGE write that follows.
    """
    prev = _neo4j_notifications.level
    _neo4j_notifications.setLevel(logging.ERROR)
    try:
        yield
    finally:
        _neo4j_notifications.setLevel(prev)


class EventResolver:
    """Resolve extracted events/processes to canonical IDs."""

    def __init__(
        self,
        neo4j: Neo4jConnector,
        similarity_threshold: float = 0.80,
        use_llm_matching: bool = False,
    ):
        self.neo4j = neo4j
        self.similarity_threshold = similarity_threshold
        self.use_llm_matching = use_llm_matching
        self.llm_manager = LLMManager()
        # In-memory cache per pipeline run
        self._event_cache: Dict[str, str] = {}   # cache_key -> event_id
        self._process_cache: Dict[str, str] = {}  # cache_key -> process_id

        # Configurable thresholds (read once from env at construction time)
        self._candidate_limit = get_event_resolver_candidate_limit()
        self._date_proximity_days = get_event_resolver_date_proximity_days()
        self._process_fuzzy_threshold = get_event_resolver_process_fuzzy_threshold()
        self._llm_confidence_floor = get_event_resolver_llm_confidence_floor()
        self._date_proximity_boost = get_event_resolver_date_proximity_boost()
        self._llm_top_candidates = get_event_resolver_llm_top_candidates()

    # ------------------------------------------------------------------
    # Public: resolve event
    # ------------------------------------------------------------------

    def resolve_event(
        self,
        event: ExtractedEvent,
        tenant_id: str,
        document_id: str,
    ) -> Dict[str, Any]:
        """
        Resolve an extracted event to a canonical event_id.

        Returns::

            {
                "event_id": "uuid",
                "is_new": bool,
                "match_method": "identifier" | "exact" | "fuzzy" | "llm" | "new",
            }
        """
        name = event.event_name.strip()
        identifiers = [i.strip() for i in (event.event_identifiers or []) if i and i.strip()]

        # --- Cache check ---
        for lookup in [name] + identifiers:
            cache_key = f"{tenant_id}|{lookup.lower()}"
            if cache_key in self._event_cache:
                return {
                    "event_id": self._event_cache[cache_key],
                    "is_new": False,
                    "match_method": "cache",
                }

        # --- Stage 1: Identifier match ---
        if identifiers:
            match = self._find_event_by_identifier(identifiers, tenant_id)
            if match:
                event_id = match["event_id"]
                self._cache_event(name, identifiers, tenant_id, event_id)
                return {"event_id": event_id, "is_new": False, "match_method": "identifier"}

        # --- Stage 2: Exact name + date match ---
        exact = self._find_event_exact(name, event.date, tenant_id)
        if exact:
            event_id = exact["event_id"]
            self._cache_event(name, identifiers, tenant_id, event_id)
            return {"event_id": event_id, "is_new": False, "match_method": "exact"}

        # --- Stage 3: Fuzzy name + date proximity ---
        candidates = self._get_event_candidates(event.event_type, tenant_id)
        fuzzy = self._fuzzy_match_event(name, event.date, candidates)
        if fuzzy:
            event_id = fuzzy["event_id"]
            self._cache_event(name, identifiers, tenant_id, event_id)
            return {"event_id": event_id, "is_new": False, "match_method": "fuzzy"}

        # --- Stage 4: LLM match (optional) ---
        if self.use_llm_matching and candidates:
            llm_match = self._llm_match_event(event, candidates, document_id)
            if llm_match:
                event_id = llm_match["event_id"]
                self._cache_event(name, identifiers, tenant_id, event_id)
                return {"event_id": event_id, "is_new": False, "match_method": "llm"}

        # --- Stage 5: Create new ---
        event_id = str(uuid.uuid4())
        self._cache_event(name, identifiers, tenant_id, event_id)
        logger.info("New event: '%s' -> %s", name, event_id)
        return {"event_id": event_id, "is_new": True, "match_method": "new"}

    # ------------------------------------------------------------------
    # Public: resolve process
    # ------------------------------------------------------------------

    def resolve_process(
        self,
        process: ExtractedProcess,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """
        Resolve an extracted process to a canonical process_id.

        Returns::

            {
                "process_id": "uuid",
                "is_new": bool,
                "match_method": "exact" | "fuzzy" | "new",
            }
        """
        name = process.process_name.strip()

        # Cache check
        cache_key = f"{tenant_id}|{name.lower()}"
        if cache_key in self._process_cache:
            return {
                "process_id": self._process_cache[cache_key],
                "is_new": False,
                "match_method": "cache",
            }

        # Stage 1: Exact name match
        exact = self._find_process_exact(name, tenant_id)
        if exact:
            pid = exact["process_id"]
            self._process_cache[cache_key] = pid
            return {"process_id": pid, "is_new": False, "match_method": "exact"}

        # Stage 2: Fuzzy name match
        candidates = self._get_process_candidates(tenant_id)
        fuzzy = self._fuzzy_match_process(name, candidates)
        if fuzzy:
            pid = fuzzy["process_id"]
            self._process_cache[cache_key] = pid
            return {"process_id": pid, "is_new": False, "match_method": "fuzzy"}

        # Stage 3: Create new
        pid = str(uuid.uuid4())
        self._process_cache[cache_key] = pid
        logger.info("New process: '%s' -> %s", name, pid)
        return {"process_id": pid, "is_new": True, "match_method": "new"}

    # ------------------------------------------------------------------
    # Internal: Neo4j queries for events
    # ------------------------------------------------------------------

    def _find_event_by_identifier(
        self, identifiers: List[str], tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """Find event by any of its identifiers."""
        query = """
        MATCH (e:Event {tenant_id: $tenant_id})
        WHERE any(id IN e.identifiers WHERE id IN $identifiers)
        RETURN e.event_id AS event_id, e.name AS name, e.date AS date
        LIMIT 1
        """
        with _quiet_neo4j():
            results = self.neo4j.execute_query(query, {
                "tenant_id": tenant_id,
                "identifiers": identifiers,
            })
        if results:
            logger.debug("Event identifier match: %s -> '%s'", identifiers, results[0].get("name"))
            return results[0]
        return None

    def _find_event_exact(
        self, name: str, date: Optional[str], tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """Find event by exact name (and optionally date)."""
        if date:
            query = """
            MATCH (e:Event {tenant_id: $tenant_id, name: $name})
            WHERE e.date = $date
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date
            LIMIT 1
            """
            results = self.neo4j.execute_query(query, {
                "tenant_id": tenant_id, "name": name, "date": date,
            })
        else:
            query = """
            MATCH (e:Event {tenant_id: $tenant_id, name: $name})
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date
            LIMIT 1
            """
            results = self.neo4j.execute_query(query, {
                "tenant_id": tenant_id, "name": name,
            })
        return results[0] if results else None

    def _get_event_candidates(
        self, event_type: Optional[str], tenant_id: str
    ) -> List[Dict[str, Any]]:
        """Get recent events of the same type for fuzzy matching."""
        limit = self._candidate_limit
        # _quiet_neo4j: suppress "property created_at does not exist" on first run.
        # created_at is set ON CREATE in merge_event(); the warning is harmless.
        if event_type:
            query = f"""
            MATCH (e:Event {{tenant_id: $tenant_id, type: $type}})
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date,
                   e.description AS description, e.type AS type
            ORDER BY e.created_at DESC
            LIMIT {limit}
            """
            with _quiet_neo4j():
                return self.neo4j.execute_query(query, {
                    "tenant_id": tenant_id, "type": event_type,
                })
        else:
            query = f"""
            MATCH (e:Event {{tenant_id: $tenant_id}})
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date,
                   e.description AS description, e.type AS type
            ORDER BY e.created_at DESC
            LIMIT {limit}
            """
            with _quiet_neo4j():
                return self.neo4j.execute_query(query, {"tenant_id": tenant_id})

    def _fuzzy_match_event(
        self,
        name: str,
        date: Optional[str],
        candidates: List[Dict[str, Any]],
    ) -> Optional[Dict[str, Any]]:
        """Find best fuzzy match above threshold, considering date proximity."""
        best: Optional[Dict[str, Any]] = None
        best_score = 0.0
        name_lower = name.lower()

        for cand in candidates:
            cand_name = (cand.get("name") or "").lower()
            score = SequenceMatcher(None, name_lower, cand_name).ratio()

            # Boost score if dates are close
            if date and cand.get("date"):
                if self._dates_are_close(date, cand["date"], days=self._date_proximity_days):
                    score = min(1.0, score + self._date_proximity_boost)

            if score > best_score:
                best_score = score
                best = cand

        if best and best_score >= self.similarity_threshold:
            logger.debug(
                "Event fuzzy match: '%s' -> '%s' (score=%.2f)",
                name, best.get("name"), best_score,
            )
            return best
        return None

    # ------------------------------------------------------------------
    # Internal: Neo4j queries for processes
    # ------------------------------------------------------------------

    def _find_process_exact(
        self, name: str, tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """Find process by exact name."""
        query = """
        MATCH (p:Process {tenant_id: $tenant_id, name: $name})
        RETURN p.process_id AS process_id, p.name AS name
        LIMIT 1
        """
        results = self.neo4j.execute_query(query, {
            "tenant_id": tenant_id, "name": name,
        })
        return results[0] if results else None

    def _get_process_candidates(
        self, tenant_id: str
    ) -> List[Dict[str, Any]]:
        """Get all processes for fuzzy matching."""
        limit = self._candidate_limit
        query = f"""
        MATCH (p:Process {{tenant_id: $tenant_id}})
        RETURN p.process_id AS process_id, p.name AS name, p.type AS type
        LIMIT {limit}
        """
        return self.neo4j.execute_query(query, {"tenant_id": tenant_id})

    def _fuzzy_match_process(
        self, name: str, candidates: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """Find best fuzzy match for a process."""
        best: Optional[Dict[str, Any]] = None
        best_score = 0.0
        name_lower = name.lower()
        threshold = self._process_fuzzy_threshold

        for cand in candidates:
            cand_name = (cand.get("name") or "").lower()
            score = SequenceMatcher(None, name_lower, cand_name).ratio()
            if score > best_score:
                best_score = score
                best = cand

        if best and best_score >= threshold:
            logger.debug(
                "Process fuzzy match: '%s' -> '%s' (score=%.2f)",
                name, best.get("name"), best_score,
            )
            return best
        return None

    # ------------------------------------------------------------------
    # Internal: LLM matching
    # ------------------------------------------------------------------

    def _llm_match_event(
        self,
        event: ExtractedEvent,
        candidates: List[Dict[str, Any]],
        document_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Use LLM to resolve ambiguous event references."""
        # Pick top-N by name similarity
        name_lower = event.event_name.lower()
        scored = []
        for c in candidates:
            s = SequenceMatcher(None, name_lower, (c.get("name") or "").lower()).ratio()
            scored.append((s, c))
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:self._llm_top_candidates]

        llm = self.llm_manager.get_for_structured_output()
        participants_str = ", ".join(
            f"{p.entity_name} ({p.role})" for p in event.participants
        )

        for _score, cand in top:
            prompt = (
                f"System: {P.EVENT_MATCH_SYSTEM}\n\n"
                f"User: {P.EVENT_MATCH_USER.format(
                    event_a_name=event.event_name,
                    event_a_description=event.description,
                    event_a_date=event.date or 'Unknown',
                    event_a_participants=participants_str or 'Unknown',
                    event_a_source=document_id,
                    event_b_name=cand.get('name', ''),
                    event_b_description=cand.get('description', ''),
                    event_b_date=cand.get('date', 'Unknown'),
                    event_b_participants='Unknown',
                    event_b_source='existing graph',
                )}"
            )
            try:
                result: EventMatchResult = llm.generate_structured(
                    prompt, EventMatchResult, temperature=0.1
                )
                if result.is_same_event and result.confidence >= self._llm_confidence_floor:
                    logger.info(
                        "LLM event match: '%s' -> '%s' (conf=%.2f)",
                        event.event_name, cand.get("name"), result.confidence,
                    )
                    return cand
            except LLMRateLimitTimeoutError:
                raise
            except Exception:
                logger.warning(
                    "LLM event match failed for '%s' vs '%s'",
                    event.event_name, cand.get("name"),
                )
                continue

        return None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _cache_event(
        self,
        name: str,
        identifiers: List[str],
        tenant_id: str,
        event_id: str,
    ) -> None:
        """Populate cache for fast repeat lookups."""
        for lookup in [name] + identifiers:
            if lookup:
                cache_key = f"{tenant_id}|{lookup.lower()}"
                self._event_cache[cache_key] = event_id

    @staticmethod
    def _dates_are_close(date_a: str, date_b: str, days: int = 7) -> bool:  # noqa: D401
        """Check if two date strings are within N days of each other."""
        try:
            formats = ["%Y-%m-%d", "%Y-%m", "%Y"]
            da = db = None
            for fmt in formats:
                try:
                    da = datetime.strptime(date_a.strip(), fmt)
                    break
                except ValueError:
                    continue
            for fmt in formats:
                try:
                    db = datetime.strptime(date_b.strip(), fmt)
                    break
                except ValueError:
                    continue
            if da and db:
                return abs((da - db).days) <= days
        except Exception:
            pass
        return False
