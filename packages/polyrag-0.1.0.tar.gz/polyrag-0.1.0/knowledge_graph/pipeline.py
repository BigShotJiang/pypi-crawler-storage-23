"""
KnowledgeGraphPipeline – end-to-end orchestrator for knowledge graph construction.

    extract  ->  resolve entities  ->  resolve events  ->  build graph  ->  store in Neo4j

v2 behavior (enabled via KG_INGESTION_V2_ENABLED=true):
- Document text is split into overlapping chunk windows using the shared
  build_extraction_windows() utility from structured_data.
- Each window is extracted independently via KnowledgeGraphExtractor.extract_chunk().
- Results are cross-window deduplicated (events, processes, causal/temporal links).
- Provenance (chunk_id, page range) is propagated into every Neo4j node.
- An optional ingestion_audit dict is added to the return payload.

v1 behavior is fully preserved when KG_INGESTION_V2_ENABLED is false or absent.

Usage::

    from knowledge_graph import KnowledgeGraphPipeline

    pipeline = KnowledgeGraphPipeline(tenant_id="org_123")

    result = pipeline.process_text(
        text="...",
        document_id="uuid",
        tenant_id="org_123",
        user_id="user_456",
        file_name="report.pdf",
    )
"""

import logging
import os
from collections import defaultdict
from math import ceil
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.config.llm import get_llm_config
from structured_data.entity_resolver import EntityResolver
from .extractor import KnowledgeGraphExtractor
from .event_resolver import EventResolver
from .graph_builder import KnowledgeGraphBuilder
from .neo4j_storage import KnowledgeGraphStorage
from .extraction_normalizer import (
    event_dedup_signature,
    process_dedup_signature,
    link_dedup_signature,
    temporal_dedup_signature,
)
from .feature_flags import (
    is_kg_ingestion_v2_enabled,
    get_chunk_target_chars,
    get_chunk_max_chars,
    get_chunk_overlap_chars,
    use_page_windows,
    is_cross_chunk_temporal_synthesis_enabled,
    get_cross_chunk_synthesis_min_confidence,
    is_date_anchoring_enabled,
)
from . import prompts as KGP

logger = logging.getLogger(__name__)


class KnowledgeGraphPipeline:
    """
    End-to-end knowledge graph processing pipeline.

    1. **Extract** events/processes/causal chains from document text (LLM).
    2. **Resolve entities** — map participant names to canonical entity IDs.
    3. **Resolve events** — match extracted events against existing graph (dedup).
    4. **Resolve processes** — match extracted processes against existing graph.
    5. **Build graph** — create/update Neo4j nodes and relationships.
    """

    def __init__(
        self,
        tenant_id: str,
        use_llm_event_matching: bool = False,
        similarity_threshold: float = 0.80,
    ):
        # Read config from env with fallbacks
        use_llm = use_llm_event_matching or (
            os.getenv("KG_USE_LLM_EVENT_MATCHING", "").lower() == "true"
        )
        threshold = float(
            os.getenv("KG_EVENT_SIMILARITY_THRESHOLD", str(similarity_threshold))
        )

        self.tenant_id = tenant_id
        self.extractor = KnowledgeGraphExtractor()
        self.storage = KnowledgeGraphStorage(tenant_id=tenant_id)
        self.event_resolver = EventResolver(
            neo4j=self.storage.neo4j,
            similarity_threshold=threshold,
            use_llm_matching=use_llm,
        )
        # Reuse the existing entity resolver from structured_data
        self.entity_resolver = EntityResolver(
            similarity_threshold=0.82,
            use_llm_matching=use_llm,
        )
        self.builder = KnowledgeGraphBuilder(
            storage=self.storage,
            entity_resolver=self.entity_resolver,
        )

        # Ensure Neo4j schema (constraints + indexes)
        self.storage.ensure_schema()

    # ------------------------------------------------------------------
    # Public: process from raw file
    # ------------------------------------------------------------------

    def process_file(
        self,
        file_path: str,
        tenant_id: str,
        user_id: str,
        document_id: Optional[str] = None,
        entity_map: Optional[Dict[str, str]] = None,
        structured_extractions: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Full KG pipeline starting from a local file path.

        Parses the file first using ingestion parsing strategy
        (pdfplumber-first for PDFs with OCR-aware fallback), then delegates
        to process_text().
        """
        path = Path(file_path)
        file_name = path.name

        logger.info("KG Pipeline start: file=%s tenant=%s", file_name, tenant_id)

        text, title_hint = self._parse_file(file_path)
        if not text:
            logger.error("Parsing returned empty text for %s", file_path)
            return {"error": "parsing_failed", "file": file_name}

        import uuid as _uuid
        doc_id = document_id or str(_uuid.uuid4())

        return self.process_text(
            text=text,
            document_id=doc_id,
            tenant_id=tenant_id,
            user_id=user_id,
            file_name=file_name,
            title_hint=title_hint,
            entity_map=entity_map,
            structured_extractions=structured_extractions,
        )

    # ------------------------------------------------------------------
    # Public: process pre-parsed text
    # ------------------------------------------------------------------

    def process_text(
        self,
        text: str,
        document_id: str,
        tenant_id: str,
        user_id: str,
        file_name: str,
        title_hint: Optional[str] = None,
        entity_map: Optional[Dict[str, str]] = None,
        structured_extractions: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Run the full KG pipeline on pre-parsed text.

        Parameters
        ----------
        text : str
            Document text.
        document_id : str
            UUID of the document.
        tenant_id : str
            Tenant isolation key.
        user_id : str
            User who uploaded the document.
        file_name : str
            Original file name.
        title_hint : str, optional
            Document title if known.
        entity_map : dict, optional
            Pre-resolved entity_name -> entity_id map from the structured_data
            pipeline.
        structured_extractions : list, optional
            Flat extraction rows from structured_data pipeline.

        Returns
        -------
        dict
            Pipeline result with extraction counts, graph stats, and (v2 only)
            an additive ``ingestion_audit`` key.
        """
        logger.info(
            "KG Processing doc=%s file=%s len=%d",
            document_id, file_name, len(text),
        )

        if is_kg_ingestion_v2_enabled(tenant_id):
            return self._process_text_v2(
                text=text,
                document_id=document_id,
                tenant_id=tenant_id,
                user_id=user_id,
                file_name=file_name,
                title_hint=title_hint,
                entity_map=entity_map,
                structured_extractions=structured_extractions,
            )

        return self._process_text_v1(
            text=text,
            document_id=document_id,
            tenant_id=tenant_id,
            user_id=user_id,
            file_name=file_name,
            title_hint=title_hint,
            entity_map=entity_map,
            structured_extractions=structured_extractions,
        )

    # ------------------------------------------------------------------
    # v1: original single-pass logic (unchanged)
    # ------------------------------------------------------------------

    def _process_text_v1(
        self,
        text: str,
        document_id: str,
        tenant_id: str,
        user_id: str,
        file_name: str,
        title_hint: Optional[str],
        entity_map: Optional[Dict[str, str]],
        structured_extractions: Optional[List[Dict[str, Any]]],
    ) -> Dict[str, Any]:
        llm_budget_estimate = self._estimate_llm_budget(text=text, title_hint=title_hint)

        extraction = self.extractor.extract(
            document_text=text,
            document_id=document_id,
            tenant_id=tenant_id,
            title_hint=title_hint,
        )

        if not extraction.events and not extraction.processes:
            logger.info("No events or processes found in doc=%s", document_id)
            if structured_extractions and entity_map:
                self.storage.merge_document(document_id, {"file_name": file_name})
                self.builder._build_entity_nodes(entity_map, tenant_id)
                n = self.builder._build_entity_relationships(
                    structured_extractions, entity_map
                )
                return {
                    "document_id": document_id,
                    "events_extracted": 0,
                    "processes_extracted": 0,
                    "causal_links": 0,
                    "temporal_links": 0,
                    "entity_relationships_created": n,
                    "llm_budget_estimate": llm_budget_estimate,
                }
            return {
                "document_id": document_id,
                "events_extracted": 0,
                "processes_extracted": 0,
                "causal_links": 0,
                "temporal_links": 0,
                "llm_budget_estimate": llm_budget_estimate,
            }

        if entity_map is None:
            entity_map = {}
        entity_map = self._resolve_all_participants(extraction, entity_map, tenant_id)

        resolved_events: Dict[str, str] = {}
        new_event_count = 0
        for event in extraction.events:
            result = self.event_resolver.resolve_event(event, tenant_id, document_id)
            resolved_events[event.event_name] = result["event_id"]
            if result["is_new"]:
                new_event_count += 1

        resolved_processes: Dict[str, str] = {}
        new_process_count = 0
        for process in extraction.processes:
            result = self.event_resolver.resolve_process(process, tenant_id)
            resolved_processes[process.process_name] = result["process_id"]
            if result["is_new"]:
                new_process_count += 1

        graph_stats = self.builder.build(
            extraction=extraction,
            resolved_events=resolved_events,
            resolved_processes=resolved_processes,
            entity_map=entity_map,
            document_id=document_id,
            tenant_id=tenant_id,
            file_name=file_name,
            structured_extractions=structured_extractions,
        )

        result = {
            "document_id": document_id,
            "events_extracted": len(extraction.events),
            "processes_extracted": len(extraction.processes),
            "causal_links": len(extraction.causal_links),
            "temporal_links": len(extraction.temporal_links),
            "new_events": new_event_count,
            "new_processes": new_process_count,
            "llm_budget_estimate": llm_budget_estimate,
            **graph_stats,
        }

        logger.info("KG Pipeline v1 complete: doc=%s result=%s", document_id, result)
        return result

    # ------------------------------------------------------------------
    # v2: chunk-window orchestration with cross-window dedup
    # ------------------------------------------------------------------

    def _process_text_v2(
        self,
        text: str,
        document_id: str,
        tenant_id: str,
        user_id: str,
        file_name: str,
        title_hint: Optional[str],
        entity_map: Optional[Dict[str, str]],
        structured_extractions: Optional[List[Dict[str, Any]]],
    ) -> Dict[str, Any]:
        """Chunked extraction with quality scoring, repair, and cross-window dedup."""
        from structured_data.chunking import build_extraction_windows

        # Build chunk windows using shared utility
        windows = build_extraction_windows(
            text,
            target_chars=get_chunk_target_chars(),
            max_chars=get_chunk_max_chars(),
            overlap_chars=get_chunk_overlap_chars(),
            use_page_windows=use_page_windows(),
        )

        logger.info(
            "KG v2: doc=%s chunks=%d total_text_len=%d",
            document_id, len(windows), len(text),
        )

        # Reset repair counter for this document
        self.extractor.reset_repair_counter()

        # Extract each chunk
        chunk_results = []
        for idx, window in enumerate(windows):
            chunk_id = f"{document_id}::chunk_{idx}"
            chunk_text = window.text if hasattr(window, "text") else window
            page_start = getattr(window, "page_start", None)
            page_end = getattr(window, "page_end", None)

            result = self.extractor.extract_chunk(
                chunk_text=chunk_text,
                document_id=document_id,
                tenant_id=tenant_id,
                title_hint=title_hint,
                chunk_id=chunk_id,
            )

            # Stamp provenance on each extracted item
            for event in result.events:
                event.source_chunk_id = chunk_id
                event.source_page_start = page_start
                event.source_page_end = page_end
            for process in result.processes:
                process.source_chunk_id = chunk_id
                process.source_page_start = page_start
                process.source_page_end = page_end

            chunk_results.append({
                "chunk_id": chunk_id,
                "page_start": page_start,
                "page_end": page_end,
                "result": result,
                "quality_score": result.chunk_quality_score or 0.0,
                "quality_issues": result.chunk_quality_issues or [],
                "repaired": False,  # set by extractor internally
            })

        # --- Cross-window dedup ---
        merged = self._cross_window_dedup(chunk_results)

        # --- Phase 3: Cross-chunk temporal synthesis ---
        synthetic_links_added = 0
        if is_cross_chunk_temporal_synthesis_enabled():
            synthetic_links_added = self._synthesize_cross_chunk_temporal_links(
                merged,
                min_confidence=get_cross_chunk_synthesis_min_confidence(),
            )

        # --- Audit ---
        chunks_repaired = sum(
            1 for cr in chunk_results
            if cr["quality_score"] < 1.0 and cr["quality_issues"]
        )
        events_raw = sum(len(cr["result"].events) for cr in chunk_results)
        events_after_dedup = len(merged.events)
        processes_raw = sum(len(cr["result"].processes) for cr in chunk_results)

        ingestion_audit: Dict[str, Any] = {
            "chunks_total": len(chunk_results),
            "chunks_with_quality_issues": chunks_repaired,
            "events_raw": events_raw,
            "events_after_dedupe": events_after_dedup,
            "processes_raw": processes_raw,
            "processes_after_dedupe": len(merged.processes),
            "causal_links_raw": sum(len(cr["result"].causal_links) for cr in chunk_results),
            "causal_links_after_dedupe": len(merged.causal_links),
            "temporal_links_raw": sum(len(cr["result"].temporal_links) for cr in chunk_results),
            "temporal_links_after_dedupe": len(merged.temporal_links),
            "synthetic_temporal_links_added": synthetic_links_added,
            "quality_scores": [
                round(cr["quality_score"], 4) for cr in chunk_results
            ],
        }

        if not merged.events and not merged.processes:
            logger.info("No events or processes found after dedup in doc=%s", document_id)
            if structured_extractions and entity_map:
                self.storage.merge_document(document_id, {"file_name": file_name})
                self.builder._build_entity_nodes(entity_map, tenant_id)
                n = self.builder._build_entity_relationships(
                    structured_extractions, entity_map
                )
                return {
                    "document_id": document_id,
                    "events_extracted": 0,
                    "processes_extracted": 0,
                    "causal_links": 0,
                    "temporal_links": 0,
                    "entity_relationships_created": n,
                    "ingestion_audit": ingestion_audit,
                }
            return {
                "document_id": document_id,
                "events_extracted": 0,
                "processes_extracted": 0,
                "causal_links": 0,
                "temporal_links": 0,
                "ingestion_audit": ingestion_audit,
            }

        # --- Resolve participants ---
        if entity_map is None:
            entity_map = {}
        resolution_failures: List[str] = []
        entity_map = self._resolve_all_participants(
            merged, entity_map, tenant_id, resolution_failures=resolution_failures
        )
        ingestion_audit["resolution_failures"] = len(resolution_failures)

        # --- Resolve events ---
        resolved_events: Dict[str, str] = {}
        new_event_count = 0
        links_skipped = 0
        for event in merged.events:
            res = self.event_resolver.resolve_event(event, tenant_id, document_id)
            resolved_events[event.event_name] = res["event_id"]
            if res["is_new"]:
                new_event_count += 1

        # Count skipped links (endpoints not in resolved set)
        for link in merged.causal_links:
            if link.cause_event not in resolved_events or link.effect_event not in resolved_events:
                links_skipped += 1
        for link in merged.temporal_links:
            if link.earlier_event not in resolved_events or link.later_event not in resolved_events:
                links_skipped += 1

        ingestion_audit["links_skipped_unresolved"] = links_skipped

        # --- Phase 3: Date anchoring ---
        anchored_dates = 0
        if is_date_anchoring_enabled():
            anchored_dates = self._anchor_event_dates(merged, resolved_events)
        ingestion_audit["dates_anchored"] = anchored_dates

        # --- Resolve processes ---
        resolved_processes: Dict[str, str] = {}
        new_process_count = 0
        for process in merged.processes:
            res = self.event_resolver.resolve_process(process, tenant_id)
            resolved_processes[process.process_name] = res["process_id"]
            if res["is_new"]:
                new_process_count += 1

        # --- Build + store graph (with provenance) ---
        graph_stats = self.builder.build(
            extraction=merged,
            resolved_events=resolved_events,
            resolved_processes=resolved_processes,
            entity_map=entity_map,
            document_id=document_id,
            tenant_id=tenant_id,
            file_name=file_name,
            structured_extractions=structured_extractions,
        )

        result = {
            "document_id": document_id,
            "events_extracted": len(merged.events),
            "processes_extracted": len(merged.processes),
            "causal_links": len(merged.causal_links),
            "temporal_links": len(merged.temporal_links),
            "new_events": new_event_count,
            "new_processes": new_process_count,
            "ingestion_audit": ingestion_audit,
            **graph_stats,
        }

        logger.info("KG Pipeline v2 complete: doc=%s result=%s", document_id, result)
        return result

    # ------------------------------------------------------------------
    # Cross-window deduplication
    # ------------------------------------------------------------------

    def _cross_window_dedup(self, chunk_results: List[Dict[str, Any]]):
        """
        Merge extraction results from multiple chunks, deduplicating by
        normalised signature.

        For events and processes: keep the variant with the highest
        extraction confidence when signatures clash.  For causal/temporal
        links: dedupe by endpoint-pair + relationship type.
        """
        from .schemas import KnowledgeGraphExtractionResult

        # -- Events --
        event_seen: Dict[tuple, Any] = {}  # sig -> ExtractedEvent
        for cr in chunk_results:
            for event in cr["result"].events:
                sig = event_dedup_signature(
                    event.event_name, event.date, event.event_identifiers
                )
                existing = event_seen.get(sig)
                if existing is None or event.confidence > existing.confidence:
                    event_seen[sig] = event

        merged_events = list(event_seen.values())

        # -- Processes --
        process_seen: Dict[tuple, Any] = {}
        for cr in chunk_results:
            for process in cr["result"].processes:
                sig = process_dedup_signature(process.process_name, process.steps)
                existing = process_seen.get(sig)
                if existing is None or process.confidence > existing.confidence:
                    process_seen[sig] = process

        merged_processes = list(process_seen.values())

        # Build event name index from merged events for link validation
        merged_event_names = {e.event_name for e in merged_events}

        # -- Causal links --
        causal_seen: Dict[tuple, Any] = {}
        for cr in chunk_results:
            for link in cr["result"].causal_links:
                # Only keep links whose endpoints survived dedup
                if link.cause_event not in merged_event_names:
                    continue
                if link.effect_event not in merged_event_names:
                    continue
                sig = link_dedup_signature(
                    link.cause_event, link.effect_event, link.relationship_type
                )
                if sig not in causal_seen:
                    causal_seen[sig] = link

        merged_causal = list(causal_seen.values())

        # -- Temporal links --
        temporal_seen: Dict[tuple, Any] = {}
        for cr in chunk_results:
            for link in cr["result"].temporal_links:
                if link.earlier_event not in merged_event_names:
                    continue
                if link.later_event not in merged_event_names:
                    continue
                sig = temporal_dedup_signature(
                    link.earlier_event, link.later_event, link.relationship_type
                )
                if sig not in temporal_seen:
                    temporal_seen[sig] = link

        merged_temporal = list(temporal_seen.values())

        merged = KnowledgeGraphExtractionResult(
            events=merged_events,
            processes=merged_processes,
            causal_links=merged_causal,
            temporal_links=merged_temporal,
        )

        logger.info(
            "Cross-window dedup complete: events=%d processes=%d causal=%d temporal=%d",
            len(merged_events), len(merged_processes),
            len(merged_causal), len(merged_temporal),
        )
        return merged

    # ------------------------------------------------------------------
    # Phase 3: Cross-chunk temporal link synthesis
    # ------------------------------------------------------------------

    def _synthesize_cross_chunk_temporal_links(
        self,
        merged,
        min_confidence: float = 0.4,
    ) -> int:
        """
        Create synthetic FOLLOWED_BY links between events from different
        chunks that have no existing temporal link between them.

        Events are sorted by ``(source_page_start, parsed_date)`` to
        establish document order, then consecutive cross-chunk pairs that
        lack an existing temporal link are connected.

        Returns the number of synthetic links added.
        """
        from .schemas import ExtractedTemporalLink
        from .query_date_parser import parse_event_date

        # Build a set of (earlier, later) event-name pairs already linked
        existing_pairs: set = set()
        for link in merged.temporal_links:
            existing_pairs.add((link.earlier_event.lower(), link.later_event.lower()))

        # Only include events with sufficient confidence and provenance
        candidates = [
            e for e in merged.events
            if e.confidence >= min_confidence
            and (e.source_page_start is not None or e.date)
        ]

        if len(candidates) < 2:
            return 0

        def _sort_key(event):
            page = event.source_page_start if event.source_page_start is not None else 999_999
            dt = parse_event_date(event.date)
            # (page ASC, date ASC NULLS LAST)
            return (page, dt is None, dt or 0)

        candidates.sort(key=_sort_key)

        added = 0
        for i in range(len(candidates) - 1):
            ev_a = candidates[i]
            ev_b = candidates[i + 1]

            # Skip if same chunk (LLM already handled intra-chunk ordering)
            chunk_a = getattr(ev_a, "source_chunk_id", None)
            chunk_b = getattr(ev_b, "source_chunk_id", None)
            if chunk_a and chunk_b and chunk_a == chunk_b:
                continue

            # Skip if a temporal link already exists in either direction
            key_fwd = (ev_a.event_name.lower(), ev_b.event_name.lower())
            key_rev = (ev_b.event_name.lower(), ev_a.event_name.lower())
            if key_fwd in existing_pairs or key_rev in existing_pairs:
                continue

            synthetic_link = ExtractedTemporalLink(
                earlier_event=ev_a.event_name,
                later_event=ev_b.event_name,
                relationship_type="followed_by",
                time_gap=None,
                synthetic=True,
            )
            merged.temporal_links.append(synthetic_link)
            existing_pairs.add(key_fwd)
            added += 1

        logger.info(
            "Cross-chunk temporal synthesis: %d synthetic FOLLOWED_BY link(s) added",
            added,
        )
        return added

    # ------------------------------------------------------------------
    # Phase 3: Date anchoring via time-gap propagation
    # ------------------------------------------------------------------

    def _anchor_event_dates(
        self,
        merged,
        resolved_events: Dict[str, str],
    ) -> int:
        """
        Propagate known dates to undated events using ``time_gap`` values
        on FOLLOWED_BY temporal links.

        For each temporal link with a non-null ``time_gap``:
        - If the earlier event has a date but the later doesn't, compute
          ``later.date = earlier.date + time_gap``.
        - If the later event has a date but the earlier doesn't, compute
          ``earlier.date = later.date - time_gap``.

        Anchored dates are written to Neo4j as ``date_anchored`` (not
        overwriting the original ``date`` field).

        Returns the number of events that received an anchored date.
        """
        try:
            import re
            from datetime import timedelta
            from .query_date_parser import parse_event_date
            try:
                from dateutil.relativedelta import relativedelta
                _HAS_DATEUTIL = True
            except ImportError:
                _HAS_DATEUTIL = False

            # Build event_name -> date map from merged events
            name_to_date: Dict[str, str] = {}
            for ev in merged.events:
                if ev.date:
                    name_to_date[ev.event_name.lower()] = ev.date

            _GAP_RE = re.compile(
                r"(\d+)\s*(day|week|month|year)s?", re.IGNORECASE
            )

            def _parse_gap(time_gap: str):
                """Return a timedelta/relativedelta for a time_gap string, or None."""
                m = _GAP_RE.search(time_gap)
                if not m:
                    return None
                n = int(m.group(1))
                unit = m.group(2).lower()
                if _HAS_DATEUTIL:
                    if unit == "day":
                        return relativedelta(days=n)
                    elif unit == "week":
                        return relativedelta(weeks=n)
                    elif unit == "month":
                        return relativedelta(months=n)
                    elif unit == "year":
                        return relativedelta(years=n)
                else:
                    # Fallback to plain timedelta (months/years approximate)
                    multipliers = {"day": 1, "week": 7, "month": 30, "year": 365}
                    return timedelta(days=n * multipliers.get(unit, 1))
                return None

            anchored = 0
            anchored_map: Dict[str, tuple] = {}  # event_name_lower -> (iso_date, source_name)

            for link in merged.temporal_links:
                if not link.time_gap:
                    continue

                name_a = link.earlier_event.lower()
                name_b = link.later_event.lower()
                has_a = name_a in name_to_date
                has_b = name_b in name_to_date
                if has_a == has_b:
                    # Both known or both unknown — skip
                    continue

                delta = _parse_gap(link.time_gap)
                if delta is None:
                    continue

                if has_a:
                    dt_a = parse_event_date(name_to_date[name_a])
                    if dt_a and name_b not in anchored_map:
                        anchored_dt = dt_a + delta
                        anchored_map[name_b] = (
                            anchored_dt.date().isoformat(),
                            link.earlier_event,
                        )
                else:
                    dt_b = parse_event_date(name_to_date[name_b])
                    if dt_b and name_a not in anchored_map:
                        anchored_dt = dt_b - delta
                        anchored_map[name_a] = (
                            anchored_dt.date().isoformat(),
                            link.later_event,
                        )

            # Write anchored dates to Neo4j
            for ev in merged.events:
                key = ev.event_name.lower()
                if key not in anchored_map:
                    continue
                event_id = resolved_events.get(ev.event_name)
                if not event_id:
                    continue
                iso_date, source_event = anchored_map[key]
                try:
                    self.storage.merge_event_date_anchor(
                        event_id=event_id,
                        anchored_date=iso_date,
                        source_event_name=source_event,
                        confidence=0.6,
                    )
                    anchored += 1
                except Exception:
                    logger.warning(
                        "Failed to anchor date for event_id=%s", event_id, exc_info=True
                    )

            logger.info("Date anchoring: %d event(s) received anchored dates", anchored)
            return anchored

        except Exception:
            logger.warning("_anchor_event_dates failed", exc_info=True)
            return 0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_all_participants(
        self,
        extraction,
        entity_map: Dict[str, str],
        tenant_id: str,
        resolution_failures: Optional[List[str]] = None,
    ) -> Dict[str, str]:
        """Ensure all participant entity names are resolved."""
        participant_names = set()

        for event in extraction.events:
            for p in event.participants:
                if p.entity_name and p.entity_name not in entity_map:
                    participant_names.add((p.entity_name, p.entity_type or "OTHER"))

        for process in extraction.processes:
            if process.owner_entity and process.owner_entity not in entity_map:
                participant_names.add((process.owner_entity, "OTHER"))
            for step in process.steps:
                if step.actor and step.actor not in entity_map:
                    participant_names.add((step.actor, "OTHER"))

        for name, etype in participant_names:
            try:
                result = self.entity_resolver.resolve(
                    entity_name=name,
                    entity_type=etype,
                    tenant_id=tenant_id,
                )
                entity_map[name] = result["entity_id"]
            except Exception:
                logger.warning("Failed to resolve participant: %s", name)
                if resolution_failures is not None:
                    resolution_failures.append(name)

        return entity_map

    @staticmethod
    def _parse_file(file_path: str) -> tuple:
        """Parse a file for ingestion."""
        try:
            from parsers.pipeline_text_parser import parse_file_to_text

            parsed = parse_file_to_text(file_path)
            logger.info(
                "KG file parsed: route=%s ocr_like=%s fallback_reason=%s file=%s",
                parsed.route,
                parsed.ocr_like,
                parsed.fallback_reason or "-",
                file_path,
            )
            return parsed.text, parsed.title_hint

        except Exception:
            logger.exception("Failed to parse file %s", file_path)
            return "", None

    def _estimate_llm_budget(self, text: str, title_hint: Optional[str]) -> Dict[str, Any]:
        """Compute baseline LLM budget estimate for KG extraction."""
        try:
            llm = self.extractor.llm_manager.get_for_structured_output()
            provider_name = getattr(llm, "provider_name", "unknown")
            model = getattr(llm, "model", "unknown")

            llm_config = get_llm_config()
            policy = llm_config.get_rate_limit_policy(provider_name, model)

            kg_text = text[:50_000]
            prompt = (
                f"System: {KGP.KG_EXTRACTION_SYSTEM}\n\n"
                f"User: {KGP.KG_EXTRACTION_USER.format(title=title_hint or 'Unknown', document_text=kg_text)}"
            )

            estimated_input_tokens = max(1, int(llm.estimate_tokens(prompt)))
            estimated_request_count = 1
            reserved_output_tokens = int(policy["output_token_reserve"])
            estimated_total_tokens = int(
                ceil(
                    (estimated_input_tokens + reserved_output_tokens)
                    * float(policy["safety_factor"])
                )
            )
            tpm = max(1, int(policy["tpm"]))

            return {
                "estimated_request_count": estimated_request_count,
                "estimated_input_tokens": estimated_input_tokens,
                "reserved_output_tokens": reserved_output_tokens,
                "estimated_total_tokens": estimated_total_tokens,
                "provider_model": f"{provider_name}:{model}",
                "estimated_min_minutes_at_tpm": round(estimated_total_tokens / float(tpm), 4),
            }
        except Exception:
            logger.warning("Failed to compute KG llm_budget_estimate", exc_info=True)
            return {
                "estimated_request_count": 0,
                "estimated_input_tokens": 0,
                "reserved_output_tokens": 0,
                "estimated_total_tokens": 0,
                "provider_model": "unknown",
                "estimated_min_minutes_at_tpm": 0.0,
            }

    # ------------------------------------------------------------------
    # Public: process schema (Excel/CSV/SQL JSON)
    # ------------------------------------------------------------------

    def process_schema(
        self,
        source: str,
        tenant_id: str,
        user_id: str,
        sql_schema_json: Optional[Dict[str, Any]] = None,
        use_llm_linking: bool = False,
    ) -> Dict[str, Any]:
        """
        Process a schema source (Excel/CSV file or SQL JSON) to extract
        ontology and link it to the existing knowledge graph.

        Parameters
        ----------
        source : str
            Path to Excel/CSV file, or descriptive name if sql_schema_json
            is provided.
        tenant_id : str
            Tenant isolation key.
        user_id : str
            User who initiated the extraction.
        sql_schema_json : dict, optional
            SQL schema definition. If provided, source is used as a name only.
        use_llm_linking : bool
            Enable LLM-based linking for ambiguous table-entity connections.

        Returns
        -------
        dict
            Pipeline result: data_tables_created, fields_created, links, etc.
        """
        from .schema_parser import SchemaParser
        from .ontology_extractor import OntologyExtractor
        from .ontology_builder import OntologyBuilder
        from .ontology_linker import OntologyLinker
        from .ontology_storage import OntologyStorage

        logger.info(
            "Schema ontology pipeline start: source=%s tenant=%s",
            source, tenant_id,
        )

        # --- 1. Parse ---
        if sql_schema_json:
            parsed = SchemaParser.from_sql_json(sql_schema_json)
        else:
            from pathlib import Path as _Path
            ext = _Path(source).suffix.lower()
            if ext in (".xlsx", ".xls", ".xlsm"):
                parsed = SchemaParser.from_xlsx(source)
            elif ext in (".csv", ".tsv"):
                parsed = SchemaParser.from_csv(source)
            else:
                return {"error": f"Unsupported file type: {ext}"}

        logger.info(
            "Parsed schema: source=%s tables=%d",
            parsed.source_name, len(parsed.tables),
        )

        # --- 2. LLM ontology extraction ---
        extractor = OntologyExtractor()
        ontology_result = extractor.extract(parsed)

        # --- 3. Build graph ---
        storage = OntologyStorage(tenant_id=tenant_id)
        storage.ensure_schema()

        builder = OntologyBuilder(storage=storage)
        build_stats = builder.build(parsed, ontology_result, tenant_id)

        # --- 4. Link to existing entities ---
        linker = OntologyLinker(
            storage=storage,
            use_llm_linking=use_llm_linking,
        )
        source_id = storage.make_source_id(parsed.source_name)
        link_stats = linker.link(ontology_result, source_id, tenant_id)

        result = {
            "source_name": parsed.source_name,
            "source_type": parsed.source_type,
            "domain": ontology_result.domain,
            "tables_analyzed": len(ontology_result.tables),
            "relationships_inferred": len(ontology_result.cross_table_relationships),
            **build_stats,
            **link_stats,
        }

        logger.info("Schema ontology pipeline complete: %s", result)
        return result
