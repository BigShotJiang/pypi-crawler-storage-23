"""
knowledge_graph/ — Event, Process & Causal Chain Knowledge Graph Pipeline.

Extracts events, processes, causal relationships, and temporal ordering
from documents and materializes them as a connected Neo4j graph with
automatic deduplication and cross-document continuity.

Usage::

    from knowledge_graph import KnowledgeGraphPipeline

    pipeline = KnowledgeGraphPipeline(tenant_id="org_123")
    result = pipeline.process_text(
        text="...",
        document_id="doc_uuid",
        tenant_id="org_123",
        user_id="user_456",
        file_name="report.pdf",
    )
"""

from .schemas import (
    ExtractedEvent,
    EventParticipant,
    ExtractedProcess,
    ProcessStep,
    ExtractedCausalLink,
    ExtractedTemporalLink,
    KnowledgeGraphExtractionResult,
    EventMatchResult,
)
from .extractor import KnowledgeGraphExtractor
from .event_resolver import EventResolver
from .graph_builder import KnowledgeGraphBuilder
from .neo4j_storage import KnowledgeGraphStorage
from .pipeline import KnowledgeGraphPipeline
from .ontology_schemas import (
    InferredFieldSemantics,
    InferredTableSemantics,
    InferredRelationship,
    SchemaOntologyExtractionResult,
    OntologyLinkResult,
)
from .schema_parser import SchemaParser, ParsedSchema, ParsedTable, ParsedField
from .ontology_extractor import OntologyExtractor
from .ontology_builder import OntologyBuilder
from .ontology_linker import OntologyLinker
from .ontology_storage import OntologyStorage

__all__ = [
    # Document KG pipeline
    "KnowledgeGraphPipeline",
    "KnowledgeGraphExtractor",
    "EventResolver",
    "KnowledgeGraphBuilder",
    "KnowledgeGraphStorage",
    "ExtractedEvent",
    "EventParticipant",
    "ExtractedProcess",
    "ProcessStep",
    "ExtractedCausalLink",
    "ExtractedTemporalLink",
    "KnowledgeGraphExtractionResult",
    "EventMatchResult",
    # Schema ontology pipeline
    "SchemaParser",
    "ParsedSchema",
    "ParsedTable",
    "ParsedField",
    "OntologyExtractor",
    "OntologyBuilder",
    "OntologyLinker",
    "OntologyStorage",
    "InferredFieldSemantics",
    "InferredTableSemantics",
    "InferredRelationship",
    "SchemaOntologyExtractionResult",
    "OntologyLinkResult",
]
