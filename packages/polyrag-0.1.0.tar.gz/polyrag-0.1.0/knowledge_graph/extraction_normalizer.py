"""
KG Extraction Normalizer – deterministic validators and quality scoring for
KnowledgeGraphExtractionResult objects.

Design mirrors structured_data/extraction_normalizer.py but adapted for
KG schemas (events, processes, causal/temporal links).

Quality scoring
---------------
The quality score is ``1.0 - weighted_penalty`` where penalties are computed
from five independent checks:

* ``unresolved_causal_ratio``   (35%) – causal links whose cause/effect name
  does not match any extracted event.
* ``unresolved_temporal_ratio`` (25%) – temporal links with missing endpoints.
* ``empty_evidence_ratio``      (20%) – events/processes with empty or
  header-like evidence.
* ``low_confidence_ratio``      (10%) – events/processes with confidence < 0.5.
* ``duplicate_event_ratio``     (10%) – near-duplicate event names within the
  same chunk (detected via normalised name comparison).

Each ratio is independently capped at 1.0 before weighting so a single bad
category cannot drive the score below 0.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Set, Tuple

from .schemas import KnowledgeGraphExtractionResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_name(name: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace."""
    cleaned = re.sub(r"[^\w\s]", " ", name.lower())
    return re.sub(r"\s+", " ", cleaned).strip()


_HEADER_HINTS: List[str] = [
    "employee id", "salary", "department", "designation",
    "grade", "name", "date", "amount", "total", "qty",
    "quantity", "uom", "unit", "status",
]


def _is_header_like_evidence(text: Optional[str]) -> bool:
    """Return True if *text* looks like a column-header row rather than a sentence."""
    if not text:
        return True  # empty evidence is treated as header-like
    cleaned = re.sub(r"\s+", " ", str(text)).strip()
    if not cleaned:
        return True

    lower = cleaned.lower()
    header_hits = sum(1 for hint in _HEADER_HINTS if hint in lower)
    has_numbers = bool(re.search(r"\d", cleaned))
    has_sentence = bool(re.search(r"[.;:]\s", cleaned))
    separators = cleaned.count("|") + cleaned.count("  ")

    if header_hits >= 3 and not has_numbers:
        return True
    if header_hits >= 2 and separators >= 1 and not has_sentence:
        return True
    return False


def _event_names_set(result: KnowledgeGraphExtractionResult) -> Set[str]:
    """Exact event_name values from the result."""
    return {e.event_name for e in result.events}


# ---------------------------------------------------------------------------
# Link integrity check
# ---------------------------------------------------------------------------

def check_link_integrity(
    result: KnowledgeGraphExtractionResult,
) -> Dict[str, List[str]]:
    """
    Verify that all causal/temporal link endpoints exist in the event list.

    Returns a dict with two keys:
    - ``unresolved_causal``: list of (cause, effect) pairs that are broken
    - ``unresolved_temporal``: list of (earlier, later) pairs that are broken
    """
    event_names = _event_names_set(result)

    unresolved_causal: List[str] = []
    for link in result.causal_links:
        if link.cause_event not in event_names or link.effect_event not in event_names:
            unresolved_causal.append(
                f"causal({link.cause_event!r} -> {link.effect_event!r})"
            )

    unresolved_temporal: List[str] = []
    for link in result.temporal_links:
        if link.earlier_event not in event_names or link.later_event not in event_names:
            unresolved_temporal.append(
                f"temporal({link.earlier_event!r} -> {link.later_event!r})"
            )

    return {
        "unresolved_causal": unresolved_causal,
        "unresolved_temporal": unresolved_temporal,
    }


# ---------------------------------------------------------------------------
# Evidence hygiene check
# ---------------------------------------------------------------------------

def check_evidence_hygiene(
    result: KnowledgeGraphExtractionResult,
) -> List[str]:
    """
    Return a list of issue strings for events/processes with poor evidence.

    'Poor evidence' means the evidence field is empty, None, or looks like a
    column header (not a sentence from the document body).
    """
    issues: List[str] = []
    for event in result.events:
        if _is_header_like_evidence(event.evidence):
            issues.append(f"event_header_evidence:{event.event_name!r}")
    for process in result.processes:
        if _is_header_like_evidence(process.evidence):
            issues.append(f"process_header_evidence:{process.process_name!r}")
    return issues


# ---------------------------------------------------------------------------
# Duplicate event detection (within a single chunk)
# ---------------------------------------------------------------------------

def check_intra_chunk_duplicate_events(
    result: KnowledgeGraphExtractionResult,
) -> List[str]:
    """
    Detect near-duplicate event names within the same extraction result.

    Uses normalised name comparison (lowercased, punctuation stripped).
    Two events are considered duplicates when their normalised names are
    identical.
    """
    seen: Dict[str, str] = {}  # normalised_name -> original name
    duplicates: List[str] = []
    for event in result.events:
        norm = _normalize_name(event.event_name)
        if norm in seen:
            duplicates.append(
                f"dup({event.event_name!r} ~ {seen[norm]!r})"
            )
        else:
            seen[norm] = event.event_name
    return duplicates


# ---------------------------------------------------------------------------
# Quality scoring
# ---------------------------------------------------------------------------

def evaluate_chunk_quality(
    result: KnowledgeGraphExtractionResult,
) -> Tuple[float, List[str]]:
    """
    Compute a quality score for a single chunk extraction result.

    Parameters
    ----------
    result : KnowledgeGraphExtractionResult

    Returns
    -------
    score : float
        Value in [0.0, 1.0]. Higher is better.
    issues : list[str]
        Human-readable descriptions of the quality problems found.
    """
    issues: List[str] = []

    # --- Unresolved causal links ---
    link_check = check_link_integrity(result)
    unresolved_causal = link_check["unresolved_causal"]
    unresolved_temporal = link_check["unresolved_temporal"]
    issues.extend(unresolved_causal)
    issues.extend(unresolved_temporal)

    n_causal = len(result.causal_links)
    unresolved_causal_ratio = (
        len(unresolved_causal) / n_causal if n_causal > 0 else 0.0
    )

    n_temporal = len(result.temporal_links)
    unresolved_temporal_ratio = (
        len(unresolved_temporal) / n_temporal if n_temporal > 0 else 0.0
    )

    # --- Evidence hygiene ---
    evidence_issues = check_evidence_hygiene(result)
    issues.extend(evidence_issues)
    n_nodes = len(result.events) + len(result.processes)
    empty_evidence_ratio = (
        len(evidence_issues) / n_nodes if n_nodes > 0 else 0.0
    )

    # --- Low-confidence events/processes ---
    low_conf_count = sum(1 for e in result.events if e.confidence < 0.5)
    low_conf_count += sum(1 for p in result.processes if p.confidence < 0.5)
    if low_conf_count:
        issues.append(f"low_confidence_nodes={low_conf_count}")
    low_confidence_ratio = low_conf_count / n_nodes if n_nodes > 0 else 0.0

    # --- Intra-chunk duplicate events ---
    dup_issues = check_intra_chunk_duplicate_events(result)
    issues.extend(dup_issues)
    duplicate_event_ratio = (
        len(dup_issues) / len(result.events) if result.events else 0.0
    )

    # Weighted penalty
    weighted_penalty = (
        0.35 * min(1.0, unresolved_causal_ratio)
        + 0.25 * min(1.0, unresolved_temporal_ratio)
        + 0.20 * min(1.0, empty_evidence_ratio)
        + 0.10 * min(1.0, low_confidence_ratio)
        + 0.10 * min(1.0, duplicate_event_ratio)
    )

    score = max(0.0, min(1.0, 1.0 - weighted_penalty))
    return round(score, 4), issues


# ---------------------------------------------------------------------------
# Key normalizer (for cross-window dedup signatures)
# ---------------------------------------------------------------------------

def event_dedup_signature(event_name: str, date: Optional[str], identifiers: Optional[List[str]]) -> Tuple:
    """
    Return a hashable signature for cross-window event deduplication.

    Two events are considered the same when their signature matches.
    """
    norm_name = _normalize_name(event_name)
    norm_date = (date or "").strip().lower()
    frozen_ids = frozenset(i.strip().lower() for i in (identifiers or []) if i.strip())
    return (norm_name, norm_date, frozen_ids)


def process_dedup_signature(process_name: str, steps: list) -> Tuple:
    """
    Return a hashable signature for cross-window process deduplication.

    Uses the normalised process name plus an ordered tuple of normalised
    step names.
    """
    norm_name = _normalize_name(process_name)
    step_skeleton = tuple(
        _normalize_name(s.step_name) for s in sorted(steps, key=lambda s: s.step_order)
    )
    return (norm_name, step_skeleton)


def link_dedup_signature(cause: str, effect: str, rel_type: str) -> Tuple:
    """Hashable signature for a causal link."""
    return (_normalize_name(cause), _normalize_name(effect), rel_type)


def temporal_dedup_signature(earlier: str, later: str, rel_type: str) -> Tuple:
    """Hashable signature for a temporal link."""
    return (_normalize_name(earlier), _normalize_name(later), rel_type)
