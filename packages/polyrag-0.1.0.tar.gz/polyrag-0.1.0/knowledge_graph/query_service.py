"""
KGQueryService – fixed-intent query service for the Knowledge Graph.

Six query intents (no open-ended NL-to-Cypher generation):

1. get_chronological_timeline  – all events in date/graph order
2. get_causal_chain            – CAUSED edge traversal forward/backward
3. get_entity_timeline         – events an entity participated in, ordered
4. get_process_steps           – ordered steps of a named process
5. get_event_evidence          – which documents mention an event + verbatim quotes
6. search_events               – fulltext search across event names + descriptions

Usage::

    from knowledge_graph.query_service import KGQueryService

    svc = KGQueryService(tenant_id="org_123")
    result = svc.get_chronological_timeline()
    for evt in result["timeline"]:
        print(evt["position"], evt["event_name"], evt["date"])
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from datetime import datetime
from typing import Any, Dict, List, Optional

from .neo4j_storage import KnowledgeGraphStorage
from .query_date_parser import parse_event_date, parse_event_date_precision

logger = logging.getLogger(__name__)


class KGQueryService:
    """Fixed-intent query service over a tenant's knowledge graph."""

    def __init__(self, tenant_id: str):
        self.tenant_id = tenant_id
        self.storage = KnowledgeGraphStorage(tenant_id)

    # ------------------------------------------------------------------
    # Intent 1: Chronological Timeline
    # ------------------------------------------------------------------

    def get_chronological_timeline(
        self,
        entity_filter: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Return all events for the tenant in chronological order.

        Ordering algorithm:
        1. Parse each event's ``date`` string into a Python datetime.
        2. Topological-sort events that have FOLLOWED_BY edges (Kahn's algorithm).
        3. Merge: dated events placed at their parsed datetime; undated events
           inserted between their graph neighbours; remainder appended.

        Each entry has ``position_method`` ∈ {"date", "graph_edge", "inferred"}.
        """
        try:
            events = self._fetch_all_events(entity_filter)
            edges = self._fetch_temporal_edges()
            doc_map = self._fetch_event_document_map()

            if not events:
                return {
                    "tenant_id": self.tenant_id,
                    "total_events": 0,
                    "events_with_dates": 0,
                    "events_via_graph": 0,
                    "events_inferred": 0,
                    "timeline": [],
                }

            # Parse dates
            parsed: Dict[str, Optional[datetime]] = {}
            for e in events:
                parsed[e["event_id"]] = parse_event_date(e.get("date"))

            # Apply date filters
            start_dt = parse_event_date(start_date)
            end_dt = parse_event_date(end_date)

            # Build adjacency for graph ordering
            successors: Dict[str, List[str]] = defaultdict(list)  # id → [id, ...]
            predecessors: Dict[str, List[str]] = defaultdict(list)
            event_ids = {e["event_id"] for e in events}

            for edge in edges:
                a, b = edge.get("earlier_id"), edge.get("later_id")
                if a in event_ids and b in event_ids:
                    successors[a].append(b)
                    predecessors[b].append(a)

            # Split events into dated / undated
            dated = [(e, parsed[e["event_id"]]) for e in events
                     if parsed[e["event_id"]] is not None]
            undated = [e for e in events if parsed[e["event_id"]] is None]

            # Sort dated events
            dated.sort(key=lambda x: x[1])  # type: ignore[arg-type]

            # Apply date range filter to dated events
            if start_dt or end_dt:
                dated = [
                    (e, dt) for e, dt in dated
                    if (start_dt is None or dt >= start_dt)
                    and (end_dt is None or dt <= end_dt)
                ]

            # Topological sort for undated events that have graph edges
            topo_order = self._kahn_topo_sort(undated, successors, predecessors)

            # Merge into final timeline
            timeline = self._merge_orders(
                dated, topo_order, successors, predecessors,
                doc_map, parsed,
            )

            # Count method breakdown
            by_method: Dict[str, int] = defaultdict(int)
            for t in timeline:
                by_method[t["position_method"]] += 1

            return {
                "tenant_id": self.tenant_id,
                "total_events": len(timeline),
                "events_with_dates": by_method["date"],
                "events_via_graph": by_method["graph_edge"],
                "events_inferred": by_method["inferred"],
                "timeline": timeline,
            }
        except Exception as exc:
            logger.exception("get_chronological_timeline failed")
            return {"error": str(exc), "intent": "get_chronological_timeline"}

    # ------------------------------------------------------------------
    # Intent 2: Causal Chain
    # ------------------------------------------------------------------

    def get_causal_chain(
        self,
        event_name: str,
        direction: str = "both",
        max_depth: int = 5,
    ) -> Dict[str, Any]:
        """
        Trace CAUSED edges forward, backward, or in both directions from *event_name*.
        """
        try:
            if direction in ("forward", "both"):
                forward = self._fetch_causal_path(event_name, "forward", max_depth)
            else:
                forward = []
            if direction in ("backward", "both"):
                backward = self._fetch_causal_path(event_name, "backward", max_depth)
            else:
                backward = []

            # Combine: backward (reversed) + forward, dedup
            seen: set = set()
            hops: List[Dict[str, Any]] = []
            for hop in list(reversed(backward)) + forward:
                key = (hop["from_event"], hop["to_event"])
                if key not in seen:
                    seen.add(key)
                    hops.append(hop)

            return {
                "root_event": event_name,
                "direction": direction,
                "hops": hops,
                "chain_length": len(hops),
            }
        except Exception as exc:
            logger.exception("get_causal_chain failed")
            return {"error": str(exc), "intent": "get_causal_chain"}

    # ------------------------------------------------------------------
    # Intent 3: Entity Timeline
    # ------------------------------------------------------------------

    def get_entity_timeline(self, entity_name: str) -> Dict[str, Any]:
        """
        Events the entity participated in, placed in chronological order.
        """
        try:
            # Fetch events for this entity
            query = """
            MATCH (entity:Entity {tenant_id: $tenant_id})
            WHERE toLower(entity.name) = toLower($name)
               OR any(v IN coalesce(entity.name_variations, []) WHERE toLower(v) = toLower($name))
            MATCH (entity)-[r:PARTICIPATED_IN]->(e:Event {tenant_id: $tenant_id})
            RETURN e.event_id AS event_id, e.name AS event_name, r.role AS role,
                   e.date AS date, e.description AS description,
                   e.confidence AS confidence, entity.entity_id AS entity_id
            """
            rows = self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
                "name": entity_name,
            })

            if not rows:
                return {
                    "entity_name": entity_name,
                    "entity_id": None,
                    "event_count": 0,
                    "timeline": [],
                }

            entity_id = rows[0].get("entity_id")

            # Sort by parsed date
            def sort_key(row: Dict) -> tuple:
                dt = parse_event_date(row.get("date"))
                return (dt is None, dt or datetime.min)

            rows.sort(key=sort_key)

            timeline = []
            for pos, row in enumerate(rows, start=1):
                dt = parse_event_date(row.get("date"))
                timeline.append({
                    "position": pos,
                    "event_name": row["event_name"],
                    "role": row.get("role", "unknown"),
                    "date": row.get("date"),
                    "date_parsed": dt.isoformat() if dt else None,
                    "date_precision": parse_event_date_precision(row.get("date")),
                    "position_method": "date" if dt else "inferred",
                    "description": row.get("description"),
                })

            return {
                "entity_name": entity_name,
                "entity_id": entity_id,
                "event_count": len(timeline),
                "timeline": timeline,
            }
        except Exception as exc:
            logger.exception("get_entity_timeline failed")
            return {"error": str(exc), "intent": "get_entity_timeline"}

    # ------------------------------------------------------------------
    # Intent 4: Process Steps
    # ------------------------------------------------------------------

    def get_process_steps(self, process_name: str) -> Dict[str, Any]:
        """Return ordered steps of a named process with actor information."""
        try:
            query = """
            MATCH (p:Process {tenant_id: $tenant_id})
            WHERE toLower(p.name) = toLower($name)
            OPTIONAL MATCH (p)-[:HAS_STEP]->(s:ProcessStep)
            OPTIONAL MATCH (s)-[:PERFORMED_BY]->(actor:Entity)
            RETURN p.process_id AS process_id, p.name AS process_name,
                   p.type AS process_type, p.description AS process_description,
                   s.step_order AS step_order, s.name AS step_name,
                   s.description AS step_description,
                   actor.name AS actor_name, actor.entity_id AS actor_entity_id,
                   s.input_artifacts AS input_artifacts,
                   s.output_artifacts AS output_artifacts
            ORDER BY s.step_order ASC
            """
            rows = self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
                "name": process_name,
            })

            if not rows:
                return {
                    "process_name": process_name,
                    "process_id": None,
                    "process_type": None,
                    "description": None,
                    "step_count": 0,
                    "steps": [],
                }

            first = rows[0]
            steps = []
            for row in rows:
                if row.get("step_name"):
                    steps.append({
                        "step_order": row.get("step_order"),
                        "step_name": row.get("step_name"),
                        "description": row.get("step_description"),
                        "actor": row.get("actor_name"),
                        "actor_entity_id": row.get("actor_entity_id"),
                        "input_artifacts": row.get("input_artifacts") or [],
                        "output_artifacts": row.get("output_artifacts") or [],
                    })

            return {
                "process_name": first.get("process_name", process_name),
                "process_id": first.get("process_id"),
                "process_type": first.get("process_type"),
                "description": first.get("process_description"),
                "step_count": len(steps),
                "steps": steps,
            }
        except Exception as exc:
            logger.exception("get_process_steps failed")
            return {"error": str(exc), "intent": "get_process_steps"}

    # ------------------------------------------------------------------
    # Intent 5: Event Evidence
    # ------------------------------------------------------------------

    def get_event_evidence(self, event_name: str) -> Dict[str, Any]:
        """Return all documents that mention *event_name* with verbatim evidence."""
        try:
            query = """
            MATCH (e:Event {tenant_id: $tenant_id})
            WHERE toLower(e.name) = toLower($name)
            MATCH (e)-[r:MENTIONED_IN]->(d:Document {tenant_id: $tenant_id})
            RETURN e.event_id AS event_id,
                   d.document_id AS document_id,
                   d.file_name AS file_name,
                   r.evidence AS evidence,
                   r.page AS page,
                   r.chunk_id AS chunk_id,
                   r.linked_at AS linked_at
            """
            rows = self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
                "name": event_name,
            })

            event_id = rows[0]["event_id"] if rows else None
            evidence_list = [
                {
                    "document_id": r["document_id"],
                    "file_name": r.get("file_name"),
                    "evidence": r.get("evidence"),
                    "page": r.get("page"),
                    "chunk_id": r.get("chunk_id"),
                    "linked_at": str(r.get("linked_at") or ""),
                }
                for r in rows
            ]

            return {
                "event_name": event_name,
                "event_id": event_id,
                "document_count": len(evidence_list),
                "evidence": evidence_list,
            }
        except Exception as exc:
            logger.exception("get_event_evidence failed")
            return {"error": str(exc), "intent": "get_event_evidence"}

    # ------------------------------------------------------------------
    # Intent 6: Search Events
    # ------------------------------------------------------------------

    def search_events(self, keywords: str, limit: int = 20) -> Dict[str, Any]:
        """Fulltext search over event names and descriptions."""
        try:
            query = """
            CALL db.index.fulltext.queryNodes('event_fulltext', $query)
            YIELD node, score
            WHERE node.tenant_id = $tenant_id
            RETURN node.event_id AS event_id, node.name AS event_name,
                   node.type AS event_type, node.date AS date,
                   node.description AS description, score
            ORDER BY score DESC
            LIMIT $limit
            """
            rows = self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
                "query": keywords,
                "limit": limit,
            })

            hits = [
                {
                    "event_name": r["event_name"],
                    "event_id": r["event_id"],
                    "score": r.get("score", 0.0),
                    "event_type": r.get("event_type"),
                    "date": r.get("date"),
                    "description": r.get("description"),
                }
                for r in rows
            ]

            return {
                "query": keywords,
                "total_hits": len(hits),
                "hits": hits,
            }
        except Exception as exc:
            logger.exception("search_events failed")
            return {"error": str(exc), "intent": "search_events"}

    # ------------------------------------------------------------------
    # Internal: data fetchers
    # ------------------------------------------------------------------

    def _fetch_all_events(
        self, entity_filter: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Fetch all Event nodes for the tenant, optionally filtered by entity."""
        if entity_filter:
            query = """
            MATCH (entity:Entity {tenant_id: $tenant_id})
            WHERE toLower(entity.name) = toLower($entity_name)
            MATCH (entity)-[:PARTICIPATED_IN]->(e:Event {tenant_id: $tenant_id})
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date,
                   e.date_precision AS date_precision, e.type AS type,
                   e.description AS description, e.confidence AS confidence
            """
            return self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
                "entity_name": entity_filter,
            })
        else:
            query = """
            MATCH (e:Event {tenant_id: $tenant_id})
            RETURN e.event_id AS event_id, e.name AS name, e.date AS date,
                   e.date_precision AS date_precision, e.type AS type,
                   e.description AS description, e.confidence AS confidence
            """
            return self.storage.neo4j.execute_query(query, {
                "tenant_id": self.tenant_id,
            })

    def _fetch_temporal_edges(self) -> List[Dict[str, Any]]:
        """Fetch all FOLLOWED_BY / CONCURRENT_WITH edges for the tenant."""
        query = """
        MATCH (a:Event {tenant_id: $tenant_id})-[r:FOLLOWED_BY|CONCURRENT_WITH]->(b:Event {tenant_id: $tenant_id})
        RETURN a.event_id AS earlier_id, b.event_id AS later_id,
               type(r) AS rel_type, r.time_gap AS time_gap,
               coalesce(r.synthetic, false) AS synthetic
        """
        return self.storage.neo4j.execute_query(query, {"tenant_id": self.tenant_id})

    def _fetch_event_document_map(self) -> Dict[str, List[str]]:
        """Return mapping event_id → [file_name, ...]."""
        query = """
        MATCH (e:Event {tenant_id: $tenant_id})-[:MENTIONED_IN]->(d:Document)
        RETURN e.event_id AS event_id, d.file_name AS file_name
        """
        rows = self.storage.neo4j.execute_query(query, {"tenant_id": self.tenant_id})
        result: Dict[str, List[str]] = defaultdict(list)
        for r in rows:
            fn = r.get("file_name")
            if fn:
                result[r["event_id"]].append(fn)
        return dict(result)

    def _fetch_causal_path(
        self,
        event_name: str,
        direction: str,
        max_depth: int,
    ) -> List[Dict[str, Any]]:
        """Traverse CAUSED edges in one direction."""
        if direction == "forward":
            query = f"""
            MATCH (start:Event {{tenant_id: $tenant_id}})
            WHERE toLower(start.name) = toLower($name)
            MATCH path = (start)-[:CAUSED*1..{max_depth}]->(end:Event)
            UNWIND relationships(path) AS rel
            RETURN startNode(rel).name AS from_event, endNode(rel).name AS to_event,
                   rel.type AS relationship_type, rel.description AS description,
                   coalesce(rel.confidence, 0.7) AS confidence, rel.evidence AS evidence
            """
        else:
            query = f"""
            MATCH (start:Event {{tenant_id: $tenant_id}})
            WHERE toLower(start.name) = toLower($name)
            MATCH path = (root:Event)-[:CAUSED*1..{max_depth}]->(start)
            UNWIND relationships(path) AS rel
            RETURN startNode(rel).name AS from_event, endNode(rel).name AS to_event,
                   rel.type AS relationship_type, rel.description AS description,
                   coalesce(rel.confidence, 0.7) AS confidence, rel.evidence AS evidence
            """
        return self.storage.neo4j.execute_query(query, {
            "tenant_id": self.tenant_id,
            "name": event_name,
        })

    # ------------------------------------------------------------------
    # Internal: timeline construction
    # ------------------------------------------------------------------

    def _kahn_topo_sort(
        self,
        events: List[Dict],
        successors: Dict[str, List[str]],
        predecessors: Dict[str, List[str]],
    ) -> List[Dict]:
        """Kahn's algorithm: topological sort of events with graph edges."""
        event_map = {e["event_id"]: e for e in events}
        ids = set(event_map)

        in_degree = {eid: len([p for p in predecessors.get(eid, []) if p in ids])
                     for eid in ids}
        queue = deque(eid for eid in ids if in_degree[eid] == 0)
        result = []

        while queue:
            eid = queue.popleft()
            if eid in event_map:
                result.append(event_map[eid])
            for succ in successors.get(eid, []):
                if succ in in_degree:
                    in_degree[succ] -= 1
                    if in_degree[succ] == 0:
                        queue.append(succ)

        # Append any remaining (cycles / disconnected)
        visited = {e["event_id"] for e in result}
        for e in events:
            if e["event_id"] not in visited:
                result.append(e)

        return result

    def _merge_orders(
        self,
        dated: List[tuple],          # [(event_dict, datetime), ...]
        topo: List[Dict],            # topologically sorted undated events
        successors: Dict[str, List[str]],
        predecessors: Dict[str, List[str]],
        doc_map: Dict[str, List[str]],
        parsed: Dict[str, Optional[datetime]],
    ) -> List[Dict[str, Any]]:
        """
        Merge date-ordered and graph-ordered events into a single timeline.

        Strategy:
        - Dated events anchor the timeline.
        - Undated events with graph edges to dated events are inserted between
          their closest anchored neighbours.
        - Remaining undated events are appended at the end.
        """
        # Build id→position map for dated events (will be updated during merge)
        timeline: List[Dict[str, Any]] = []

        # Start with dated events
        dated_ids = {e["event_id"] for e, _ in dated}
        for e, dt in dated:
            succ_names = [
                self._id_to_name(s, dated + [(ev, None) for ev in topo], s)
                for s in successors.get(e["event_id"], [])
            ]
            pred_names = [
                self._id_to_name(p, dated + [(ev, None) for ev in topo], p)
                for p in predecessors.get(e["event_id"], [])
            ]
            timeline.append(self._make_entry(
                e, position_method="date",
                date_parsed=dt,
                doc_map=doc_map,
                preceded_by=pred_names,
                succeeded_by=succ_names,
            ))

        # Insert undated events with graph connections right after their predecessor
        inserted = set(dated_ids)
        for e in topo:
            eid = e["event_id"]
            if eid in inserted:
                continue
            pred_in_timeline = [
                p for p in predecessors.get(eid, []) if p in inserted
            ]
            if pred_in_timeline:
                method = "graph_edge"
            else:
                method = "inferred"
            succ_names = [successors.get(eid, [])]
            pred_names = [predecessors.get(eid, [])]
            timeline.append(self._make_entry(
                e, position_method=method,
                date_parsed=None,
                doc_map=doc_map,
                preceded_by=[],
                succeeded_by=[],
            ))
            inserted.add(eid)

        # Assign 1-based positions
        for i, entry in enumerate(timeline, start=1):
            entry["position"] = i

        return timeline

    @staticmethod
    def _id_to_name(
        event_id: str,
        events: list,
        fallback: str,
    ) -> str:
        for item in events:
            e = item[0] if isinstance(item, tuple) else item
            if e.get("event_id") == event_id:
                return e.get("name", fallback)
        return fallback

    @staticmethod
    def _make_entry(
        event: Dict,
        position_method: str,
        date_parsed: Optional[datetime],
        doc_map: Dict[str, List[str]],
        preceded_by: List[str],
        succeeded_by: List[str],
    ) -> Dict[str, Any]:
        raw_date = event.get("date")
        return {
            "position": 0,  # set by caller
            "event_id": event.get("event_id", ""),
            "event_name": event.get("name", ""),
            "date": raw_date,
            "date_parsed": date_parsed.isoformat() if date_parsed else None,
            "date_precision": event.get("date_precision")
                              or parse_event_date_precision(raw_date),
            "position_method": position_method,
            "confidence": event.get("confidence") or 0.8,
            "event_type": event.get("type"),
            "description": event.get("description"),
            "preceded_by": preceded_by,
            "succeeded_by": succeeded_by,
            "source_documents": doc_map.get(event.get("event_id", ""), []),
        }
