"""
KnowledgeGraphBuilder – converts extraction results into Neo4j graph operations.

Coordinates between the extractor output, resolved IDs, and the storage
layer to build the actual graph.  Also materializes entity-entity
relationships from the structured_data pipeline as RELATED_TO edges.
"""

import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional

from structured_data.entity_resolver import EntityResolver
from .schemas import KnowledgeGraphExtractionResult
from .neo4j_storage import KnowledgeGraphStorage

logger = logging.getLogger(__name__)


class KnowledgeGraphBuilder:
    """Convert extraction results into Neo4j graph operations."""

    def __init__(
        self,
        storage: KnowledgeGraphStorage,
        entity_resolver: EntityResolver,
    ):
        self.storage = storage
        self.entity_resolver = entity_resolver

    def build(
        self,
        extraction: KnowledgeGraphExtractionResult,
        resolved_events: Dict[str, str],     # event_name -> event_id
        resolved_processes: Dict[str, str],   # process_name -> process_id
        entity_map: Dict[str, str],           # entity_name -> entity_id
        document_id: str,
        tenant_id: str,
        file_name: str = "",
        structured_extractions: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Build the knowledge graph from extraction results.

        Parameters
        ----------
        extraction : KnowledgeGraphExtractionResult
            LLM extraction output with events, processes, causal/temporal links.
        resolved_events : dict
            Mapping of event_name -> canonical event_id (from EventResolver).
        resolved_processes : dict
            Mapping of process_name -> canonical process_id (from EventResolver).
        entity_map : dict
            Mapping of entity_name -> canonical entity_id (from EntityResolver).
        document_id : str
            UUID of the source document.
        tenant_id : str
            Tenant isolation key.
        file_name : str
            Original file name for the document node.
        structured_extractions : list, optional
            Flat extraction rows from the structured_data pipeline.
            Used to materialize entity-entity relationships as RELATED_TO edges.

        Returns
        -------
        dict
            Stats: events_created, events_merged, processes_created,
            relationships_created, entity_relationships_created.
        """
        stats: Dict[str, int] = defaultdict(int)

        # 1. Merge document node (provenance)
        self._build_document_node(document_id, file_name)

        # 2. Merge entity nodes from entity_map
        self._build_entity_nodes(entity_map, tenant_id)
        stats["entities_in_graph"] = len(entity_map)

        # 3. Merge event nodes
        for event in extraction.events:
            event_id = resolved_events.get(event.event_name)
            if not event_id:
                continue
            self._build_event_node(event, event_id, document_id)
            stats["events_created"] += 1

            # 4. PARTICIPATED_IN relationships
            for participant in event.participants:
                p_entity_id = self._resolve_participant(
                    participant.entity_name,
                    participant.entity_type,
                    entity_map,
                    tenant_id,
                )
                if p_entity_id:
                    self.storage.merge_participation(
                        entity_id=p_entity_id,
                        event_id=event_id,
                        role=participant.role,
                        confidence=event.confidence,
                    )
                    stats["participations_created"] += 1

        # 5. CAUSED relationships
        for link in extraction.causal_links:
            cause_id = resolved_events.get(link.cause_event)
            effect_id = resolved_events.get(link.effect_event)
            if cause_id and effect_id:
                self.storage.merge_causal_link(
                    cause_event_id=cause_id,
                    effect_event_id=effect_id,
                    relationship_type=link.relationship_type,
                    description=link.description,
                    confidence=link.confidence,
                )
                stats["causal_links_created"] += 1

        # 6. Temporal relationships (FOLLOWED_BY / CONCURRENT_WITH)
        for link in extraction.temporal_links:
            earlier_id = resolved_events.get(link.earlier_event)
            later_id = resolved_events.get(link.later_event)
            if earlier_id and later_id:
                self.storage.merge_temporal_link(
                    earlier_event_id=earlier_id,
                    later_event_id=later_id,
                    relationship_type=link.relationship_type,
                    time_gap=link.time_gap,
                    synthetic=getattr(link, "synthetic", False),
                )
                stats["temporal_links_created"] += 1

        # 7. Process nodes and step chains
        for process in extraction.processes:
            process_id = resolved_processes.get(process.process_name)
            if not process_id:
                continue
            self._build_process_node(process, process_id, document_id, entity_map, tenant_id)
            stats["processes_created"] += 1

        # 8. Event -> Process (PART_OF) links
        # If an event name matches a process step name, link it
        self._link_events_to_processes(
            extraction, resolved_events, resolved_processes
        )

        # 9. Provenance links (with per-document evidence and chunk/page metadata)
        for event in extraction.events:
            event_id = resolved_events.get(event.event_name)
            if event_id:
                self.storage.add_provenance(
                    node_id_field="event_id",
                    node_id=event_id,
                    node_label="Event",
                    document_id=document_id,
                    relationship_type="MENTIONED_IN",
                    evidence=event.evidence,
                    file_name=file_name,
                    page=getattr(event, "source_page_start", None),
                    chunk_id=getattr(event, "source_chunk_id", None),
                )
                self.storage.add_document_source(event_id, document_id)

        for process in extraction.processes:
            process_id = resolved_processes.get(process.process_name)
            if process_id:
                self.storage.add_provenance(
                    node_id_field="process_id",
                    node_id=process_id,
                    node_label="Process",
                    document_id=document_id,
                    relationship_type="EXTRACTED_FROM",
                    evidence=process.evidence,
                    file_name=file_name,
                    page=getattr(process, "source_page_start", None),
                    chunk_id=getattr(process, "source_chunk_id", None),
                )

        # 10. Materialize entity-entity relationships from structured_data
        if structured_extractions:
            n = self._build_entity_relationships(
                structured_extractions, entity_map
            )
            stats["entity_relationships_created"] = n

        logger.info(
            "Graph build complete for doc=%s: %s",
            document_id, dict(stats),
        )
        return dict(stats)

    # ------------------------------------------------------------------
    # Internal builders
    # ------------------------------------------------------------------

    def _build_document_node(self, document_id: str, file_name: str) -> None:
        """Merge the Document node."""
        self.storage.merge_document(document_id, {
            "file_name": file_name,
        })

    def _build_entity_nodes(
        self, entity_map: Dict[str, str], tenant_id: str
    ) -> None:
        """Merge Entity nodes for all resolved entities."""
        for name, entity_id in entity_map.items():
            props: Dict[str, Any] = {"name": name}

            # Hydrate canonical entity metadata from MongoDB master so
            # Neo4j Entity nodes carry type/identifiers for ontology linking.
            entity_master = self.entity_resolver.get_entity_by_id(
                entity_id=entity_id,
                tenant_id=tenant_id,
            )
            if entity_master:
                canonical_name = entity_master.get("entity_name")
                if canonical_name:
                    props["name"] = canonical_name

                entity_type = entity_master.get("entity_type") or entity_master.get("type")
                if entity_type:
                    props["type"] = entity_type

                identifiers = entity_master.get("identifiers")
                if identifiers:
                    props["identifiers"] = identifiers

                name_variations = entity_master.get("name_variations")
                if name_variations:
                    props["name_variations"] = name_variations

            self.storage.merge_entity(entity_id, props)

    def _build_event_node(
        self,
        event,
        event_id: str,
        document_id: str,
    ) -> None:
        """Merge an Event node with conflict resolution."""
        props = {
            "name": event.event_name,
            "type": event.event_type,
            "description": event.description,
            "date": event.date,
            "date_precision": event.date_precision,
            "location": event.location,
            "outcome": event.outcome,
            "status": event.status,
            "evidence": event.evidence,
        }
        if event.event_identifiers:
            props["identifiers"] = event.event_identifiers

        self.storage.merge_event(
            event_id,
            props,
            new_confidence=event.confidence,
            document_id=document_id,
        )

    def _build_process_node(
        self,
        process,
        process_id: str,
        document_id: str,
        entity_map: Dict[str, str],
        tenant_id: str,
    ) -> None:
        """Merge a Process node with its steps."""
        self.storage.merge_process(process_id, {
            "name": process.process_name,
            "type": process.process_type,
            "description": process.description,
            "status": process.status,
            "confidence": process.confidence,
            "evidence": process.evidence,
        })

        # Owner relationship
        if process.owner_entity:
            owner_id = self._resolve_participant(
                process.owner_entity, None, entity_map, tenant_id
            )
            if owner_id:
                self.storage.merge_process_owner(owner_id, process_id)

        # Steps
        if process.steps:
            step_dicts = []
            for step in process.steps:
                actor_id = None
                if step.actor:
                    actor_id = self._resolve_participant(
                        step.actor, None, entity_map, tenant_id
                    )
                step_dicts.append({
                    "name": step.step_name,
                    "order": step.step_order,
                    "description": step.description,
                    "actor": step.actor,
                    "actor_entity_id": actor_id,
                })
            self.storage.merge_process_steps(process_id, step_dicts)

    def _link_events_to_processes(
        self,
        extraction: KnowledgeGraphExtractionResult,
        resolved_events: Dict[str, str],
        resolved_processes: Dict[str, str],
    ) -> None:
        """
        Link events to processes when event descriptions match process steps.

        For each process step, if there's an event with a similar name,
        create a PART_OF relationship.
        """
        for process in extraction.processes:
            process_id = resolved_processes.get(process.process_name)
            if not process_id:
                continue

            for step in process.steps:
                # Check if there's an event that matches this step
                for event in extraction.events:
                    event_id = resolved_events.get(event.event_name)
                    if not event_id:
                        continue

                    # Simple heuristic: step name appears in event name or vice versa
                    step_lower = step.step_name.lower()
                    event_lower = event.event_name.lower()
                    if step_lower in event_lower or event_lower in step_lower:
                        self.storage.merge_event_to_process(
                            event_id, process_id, step.step_order
                        )
                        break

    def _build_entity_relationships(
        self,
        structured_extractions: List[Dict[str, Any]],
        entity_map: Dict[str, str],
    ) -> int:
        """
        Materialize entity-entity relationships from structured_data extractions.

        Filters for data_type='relationship' rows and creates RELATED_TO edges
        between the source entity and related entity.

        Returns the number of relationships created.
        """
        count = 0
        for ext in structured_extractions:
            if ext.get("data_type") != "relationship":
                continue

            source_name = ext.get("entity_name")
            target_name = ext.get("related_entity_name")
            if not source_name or not target_name:
                continue

            source_id = entity_map.get(source_name)
            target_id = entity_map.get(target_name)
            if not source_id or not target_id:
                continue

            rel_type = ext.get("category", "related")
            confidence = ext.get("confidence", 0.8)

            self.storage.merge_entity_relationship(
                source_entity_id=source_id,
                target_entity_id=target_id,
                relationship_type=rel_type,
                confidence=confidence,
            )
            count += 1

        return count

    def _resolve_participant(
        self,
        entity_name: str,
        entity_type: Optional[str],
        entity_map: Dict[str, str],
        tenant_id: str,
    ) -> Optional[str]:
        """
        Resolve a participant entity name to an entity_id.

        First checks the pre-resolved entity_map. If not found, tries
        case-insensitive lookup. As a last resort, resolves fresh using
        the EntityResolver.
        """
        if not entity_name:
            return None

        # Direct lookup
        if entity_name in entity_map:
            return entity_map[entity_name]

        # Case-insensitive lookup
        name_lower = entity_name.lower()
        for map_name, map_id in entity_map.items():
            if map_name.lower() == name_lower:
                return map_id

        # Resolve fresh
        try:
            result = self.entity_resolver.resolve(
                entity_name=entity_name,
                entity_type=entity_type or "OTHER",
                tenant_id=tenant_id,
            )
            entity_id = result["entity_id"]
            entity_map[entity_name] = entity_id  # Cache for next lookup
            return entity_id
        except Exception:
            logger.warning(
                "Failed to resolve participant entity: %s", entity_name
            )
            return None
