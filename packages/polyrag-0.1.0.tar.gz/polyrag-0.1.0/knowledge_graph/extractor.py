"""
KnowledgeGraphExtractor – LLM-based extraction of events, processes,
causal chains, and temporal relationships from document text.

Uses a dedicated LLM call (separate from the structured_data extraction)
with the KnowledgeGraphExtractionResult schema for structured output.

v2 behavior (enabled via KG_INGESTION_V2_ENABLED):
- No internal text truncation; the caller (pipeline) is responsible for
  passing correctly-sized chunks via build_extraction_windows().
- Optional repair pass when chunk quality score is below the configured
  threshold.  Repair attempts are bounded per document via a thread-safe
  counter.
"""

import json
import logging
import threading
from typing import List, Optional

from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .schemas import KnowledgeGraphExtractionResult
from . import prompts as P
from .extraction_normalizer import evaluate_chunk_quality
from .feature_flags import (
    is_extraction_repair_enabled,
    get_repair_max_windows_per_doc,
    get_repair_quality_threshold,
)

logger = logging.getLogger(__name__)

# Legacy hard limit kept for backward-compat (v1 path only)
_LEGACY_MAX_EXTRACTION_CHARS = 50_000


class KnowledgeGraphExtractor:
    """
    Runs LLM-based knowledge graph extraction on document text.

    Extracts events, processes, causal links, and temporal relationships
    and returns them as a KnowledgeGraphExtractionResult.

    Parameters
    ----------
    repair_enabled : bool, optional
        Override for repair-pass toggle.  When None, reads from env flag.
    repair_quality_threshold : float, optional
        Override for quality threshold below which repair is triggered.
    repair_max_windows_per_doc : int, optional
        Override for max windows repaired per document.
    """

    def __init__(
        self,
        repair_enabled: Optional[bool] = None,
        repair_quality_threshold: Optional[float] = None,
        repair_max_windows_per_doc: Optional[int] = None,
    ):
        self.llm_manager = LLMManager()
        self._repair_enabled = repair_enabled
        self._repair_quality_threshold = repair_quality_threshold
        self._repair_max_windows_per_doc = repair_max_windows_per_doc

        # Thread-safe repair counter (reset per document via reset_repair_counter)
        self._repair_lock = threading.Lock()
        self._repair_attempts: int = 0

    # ------------------------------------------------------------------
    # Public helpers for repair gate management
    # ------------------------------------------------------------------

    def reset_repair_counter(self) -> None:
        """Reset the per-document repair attempt counter.  Call before each document."""
        with self._repair_lock:
            self._repair_attempts = 0

    def _can_attempt_repair(self) -> bool:
        max_w = (
            self._repair_max_windows_per_doc
            if self._repair_max_windows_per_doc is not None
            else get_repair_max_windows_per_doc()
        )
        with self._repair_lock:
            return self._repair_attempts < max_w

    def _mark_repair_attempt(self) -> None:
        with self._repair_lock:
            self._repair_attempts += 1

    # ------------------------------------------------------------------
    # Public: extract (v1 – legacy, single call with internal truncation)
    # ------------------------------------------------------------------

    def extract(
        self,
        document_text: str,
        document_id: str,
        tenant_id: str,
        title_hint: Optional[str] = None,
    ) -> KnowledgeGraphExtractionResult:
        """
        Run KG extraction on *document_text* (legacy / v1 path).

        The caller is responsible for passing an appropriately-sized chunk
        when running under v2.  In v1 mode the text is still truncated at
        the legacy limit for safety.
        """
        logger.info(
            "Starting KG extraction for doc=%s len=%d",
            document_id, len(document_text),
        )

        text = document_text[:_LEGACY_MAX_EXTRACTION_CHARS]
        if len(document_text) > _LEGACY_MAX_EXTRACTION_CHARS:
            logger.warning(
                "Document text truncated from %d to %d chars for KG extraction",
                len(document_text), _LEGACY_MAX_EXTRACTION_CHARS,
            )

        return self._call_llm_extraction(text, title_hint, document_id)

    # ------------------------------------------------------------------
    # Public: extract_chunk (v2 – no internal truncation, optional repair)
    # ------------------------------------------------------------------

    def extract_chunk(
        self,
        chunk_text: str,
        document_id: str,
        tenant_id: str,
        title_hint: Optional[str] = None,
        chunk_id: Optional[str] = None,
    ) -> KnowledgeGraphExtractionResult:
        """
        Extract from a single pre-sized chunk (v2 path).

        No internal truncation is applied; the caller must ensure *chunk_text*
        fits within the LLM context window.  Optionally runs a repair pass
        when quality is below threshold.

        Parameters
        ----------
        chunk_text : str
            Chunk text (already sized by build_extraction_windows).
        document_id : str
            UUID of the parent document.
        tenant_id : str
            Tenant isolation key.
        title_hint : str, optional
            Document title if known.
        chunk_id : str, optional
            Chunk identifier for logging and provenance.

        Returns
        -------
        KnowledgeGraphExtractionResult
            Result with chunk_id, chunk_quality_score, chunk_quality_issues set.
        """
        logger.info(
            "KG chunk extraction: doc=%s chunk=%s len=%d",
            document_id, chunk_id or "?", len(chunk_text),
        )

        # --- First-pass extraction ---
        first_result = self._call_llm_extraction(chunk_text, title_hint, document_id)
        first_score, first_issues = evaluate_chunk_quality(first_result)

        repair_enabled = (
            self._repair_enabled
            if self._repair_enabled is not None
            else is_extraction_repair_enabled()
        )
        threshold = (
            self._repair_quality_threshold
            if self._repair_quality_threshold is not None
            else get_repair_quality_threshold()
        )

        selected_result = first_result
        selected_score = first_score
        selected_issues = first_issues
        repair_attempted = False
        repair_used = False

        # --- Conditional repair pass ---
        needs_repair = repair_enabled and first_score < threshold and first_issues
        if needs_repair and self._can_attempt_repair():
            self._mark_repair_attempt()
            repair_attempted = True

            repaired = self._call_llm_repair(
                chunk_text=chunk_text,
                first_result=first_result,
                issues=first_issues,
                document_id=document_id,
            )
            if repaired is not None:
                repaired_score, repaired_issues = evaluate_chunk_quality(repaired)
                if repaired_score > first_score:
                    selected_result = repaired
                    selected_score = repaired_score
                    selected_issues = repaired_issues
                    repair_used = True
                    logger.info(
                        "KG repair accepted for doc=%s chunk=%s: %.4f -> %.4f",
                        document_id, chunk_id or "?", first_score, repaired_score,
                    )
                else:
                    logger.info(
                        "KG repair discarded for doc=%s chunk=%s: %.4f <= %.4f",
                        document_id, chunk_id or "?", repaired_score, first_score,
                    )

        logger.debug(
            "KG chunk done: doc=%s chunk=%s score=%.4f repair_attempted=%s repair_used=%s issues=%d",
            document_id, chunk_id or "?", selected_score,
            repair_attempted, repair_used, len(selected_issues),
        )

        # Annotate result with chunk metadata
        selected_result.chunk_id = chunk_id
        selected_result.chunk_quality_score = selected_score
        selected_result.chunk_quality_issues = selected_issues

        return selected_result

    # ------------------------------------------------------------------
    # Internal: LLM calls
    # ------------------------------------------------------------------

    def _call_llm_extraction(
        self,
        text: str,
        title_hint: Optional[str],
        document_id: str,
    ) -> KnowledgeGraphExtractionResult:
        """Single LLM call to extract events, processes, and causal chains."""
        llm = self.llm_manager.get_for_structured_output()

        prompt = (
            f"System: {P.KG_EXTRACTION_SYSTEM}\n\n"
            f"User: {P.KG_EXTRACTION_USER.format(title=title_hint or 'Unknown', document_text=text)}"
        )

        try:
            result = llm.generate_structured(
                prompt,
                KnowledgeGraphExtractionResult,
                temperature=0.1,
            )
            logger.info(
                "KG extraction complete for doc=%s: events=%d processes=%d "
                "causal_links=%d temporal_links=%d",
                document_id,
                len(result.events),
                len(result.processes),
                len(result.causal_links),
                len(result.temporal_links),
            )
            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception(
                "LLM KG extraction failed for doc=%s, returning empty result",
                document_id,
            )
            return self._fallback_extraction()

    def _call_llm_repair(
        self,
        chunk_text: str,
        first_result: KnowledgeGraphExtractionResult,
        issues: List[str],
        document_id: str,
    ) -> Optional[KnowledgeGraphExtractionResult]:
        """LLM repair pass. Returns None on failure."""
        llm = self.llm_manager.get_for_structured_output()

        try:
            first_pass_json = first_result.model_dump_json(indent=2)
        except Exception:
            first_pass_json = "{}"

        issues_text = "\n".join(f"- {issue}" for issue in issues)

        prompt = (
            f"System: {P.KG_EXTRACTION_REPAIR_SYSTEM}\n\n"
            f"User: {P.KG_EXTRACTION_REPAIR_USER.format(
                document_text=chunk_text,
                first_pass_json=first_pass_json,
                quality_issues=issues_text,
            )}"
        )

        try:
            result = llm.generate_structured(
                prompt,
                KnowledgeGraphExtractionResult,
                temperature=0.0,
            )
            logger.info(
                "KG repair extraction complete for doc=%s: events=%d processes=%d",
                document_id, len(result.events), len(result.processes),
            )
            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.warning(
                "LLM KG repair call failed for doc=%s", document_id, exc_info=True
            )
            return None

    @staticmethod
    def _fallback_extraction() -> KnowledgeGraphExtractionResult:
        """Return empty result when the LLM call fails."""
        return KnowledgeGraphExtractionResult(
            events=[],
            processes=[],
            causal_links=[],
            temporal_links=[],
            overall_confidence=0.0,
        )
