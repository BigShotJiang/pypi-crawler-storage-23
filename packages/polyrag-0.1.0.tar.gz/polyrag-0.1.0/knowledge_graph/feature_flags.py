"""
Feature-flag helpers for Knowledge Graph ingestion reliability upgrades.

All flags default to safe/backward-compatible values so existing behavior
is preserved unless explicitly opted in.
"""

from __future__ import annotations

import os
from typing import Set


# ---------------------------------------------------------------------------
# Env-var helpers (mirrors structured_data/feature_flags.py)
# ---------------------------------------------------------------------------

def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _parse_tenant_allowlist(raw_value: str | None) -> Set[str]:
    if not raw_value:
        return set()
    return {part.strip() for part in raw_value.split(",") if part.strip()}


# ---------------------------------------------------------------------------
# KG ingestion v2 feature gate
# ---------------------------------------------------------------------------

def is_kg_ingestion_v2_enabled(tenant_id: str) -> bool:
    """
    Return True when the chunked/quality-scored KG ingestion path should run.

    Rules:
    1. ``KG_INGESTION_V2_ENABLED`` must be ``true``.
    2. If ``KG_INGESTION_V2_TENANTS`` is empty, all tenants are enabled.
    3. Otherwise, *tenant_id* must appear in the comma-separated allowlist.
    """
    if not env_bool("KG_INGESTION_V2_ENABLED", False):
        return False
    allowed = _parse_tenant_allowlist(os.getenv("KG_INGESTION_V2_TENANTS"))
    if not allowed:
        return True
    return tenant_id in allowed


# ---------------------------------------------------------------------------
# Chunking configuration
# ---------------------------------------------------------------------------

def get_chunk_target_chars() -> int:
    return env_int("KG_CHUNK_TARGET_CHARS", 10_000)


def get_chunk_max_chars() -> int:
    return env_int("KG_CHUNK_MAX_CHARS", 12_000)


def get_chunk_overlap_chars() -> int:
    return env_int("KG_CHUNK_OVERLAP_CHARS", 500)


def use_page_windows() -> bool:
    return env_bool("KG_CHUNK_USE_PAGE_WINDOWS", True)


def use_chunk_dedup_overlap() -> bool:
    return env_bool("KG_CHUNK_DEDUP_OVERLAP", True)


# ---------------------------------------------------------------------------
# Extraction repair configuration
# ---------------------------------------------------------------------------

def is_extraction_repair_enabled() -> bool:
    return env_bool("KG_EXTRACTION_REPAIR_ENABLED", True)


def get_repair_max_windows_per_doc() -> int:
    return env_int("KG_EXTRACTION_REPAIR_MAX_WINDOWS_PER_DOC", 2)


def get_repair_quality_threshold() -> float:
    return env_float("KG_EXTRACTION_REPAIR_QUALITY_THRESHOLD", 0.82)


# ---------------------------------------------------------------------------
# EventResolver thresholds
# ---------------------------------------------------------------------------

def get_event_resolver_candidate_limit() -> int:
    return env_int("KG_EVENT_RESOLVER_CANDIDATE_LIMIT", 100)


def get_event_resolver_date_proximity_days() -> int:
    return env_int("KG_EVENT_RESOLVER_DATE_PROXIMITY_DAYS", 7)


def get_event_resolver_process_fuzzy_threshold() -> float:
    return env_float("KG_EVENT_RESOLVER_PROCESS_FUZZY_THRESHOLD", 0.85)


def get_event_resolver_llm_confidence_floor() -> float:
    return env_float("KG_EVENT_RESOLVER_LLM_CONFIDENCE_FLOOR", 0.7)


def get_event_resolver_date_proximity_boost() -> float:
    return env_float("KG_EVENT_RESOLVER_DATE_PROXIMITY_BOOST", 0.1)


def get_event_resolver_llm_top_candidates() -> int:
    return env_int("KG_EVENT_RESOLVER_LLM_TOP_CANDIDATES", 3)


# ---------------------------------------------------------------------------
# Phase 3: Cross-chunk temporal synthesis
# ---------------------------------------------------------------------------

def is_cross_chunk_temporal_synthesis_enabled() -> bool:
    """
    Synthesize FOLLOWED_BY edges between events from different chunks
    using page order and date order when no explicit link already exists.
    Default off — enable per-tenant after evaluation confirms correctness.
    """
    return env_bool("KG_CROSS_CHUNK_TEMPORAL_SYNTHESIS_ENABLED", False)


def get_cross_chunk_synthesis_min_confidence() -> float:
    return env_float("KG_CROSS_CHUNK_SYNTHESIS_MIN_CONFIDENCE", 0.4)


# ---------------------------------------------------------------------------
# Phase 3: Date anchoring
# ---------------------------------------------------------------------------

def is_date_anchoring_enabled() -> bool:
    """
    Propagate dates to undated events using time_gap from FOLLOWED_BY edges
    and lightweight relative-expression scanning in event descriptions.
    Default off — enable after cross-chunk synthesis is stable.
    """
    return env_bool("KG_DATE_ANCHORING_ENABLED", False)


# ---------------------------------------------------------------------------
# Phase 3: Query service
# ---------------------------------------------------------------------------

def is_kg_query_service_enabled() -> bool:
    """Enable the KG query service endpoint."""
    return env_bool("KG_QUERY_SERVICE_ENABLED", True)
