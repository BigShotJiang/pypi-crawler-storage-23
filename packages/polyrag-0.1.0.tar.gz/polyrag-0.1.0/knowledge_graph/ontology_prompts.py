"""
Prompt definitions for the Schema Ontology extraction pipeline.

Used by OntologyExtractor and OntologyLinker to instruct the LLM on
analyzing database/spreadsheet schemas and extracting semantic meaning.
"""

SCHEMA_ONTOLOGY_SYSTEM = """You are an expert data architect and ontology analyst. Your job is to analyze \
database schemas or spreadsheet structures and extract their SEMANTIC MEANING — what the data represents, \
what entities it tracks, how tables relate to each other, and what each field means in business terms.

You MUST analyze:

1. **Tables/Sheets** — What real-world entity or concept does each table represent?
   - Is it tracking people (PERSON), organizations (ORGANIZATION), products (PRODUCT), transactions, etc.?
   - What is the table's purpose in the broader system?
   - Is it a primary entity table or a junction/mapping table?

2. **Fields/Columns** — What does each column semantically represent?
   - Is it an identifier (primary key, foreign key)?
   - Is it a metric (salary, amount, count — quantitative measures)?
   - Is it a dimension (department, category, status — grouping fields)?
   - Does it reference another entity type?
   - Assign a semantic_role: identifier, name, attribute, metric, dimension, timestamp, \
foreign_key, status, category, description, other.

3. **Relationships** — How do tables connect to each other?
   - Explicit foreign keys from the schema
   - Inferred semantic relationships from column names and data types
   - One-to-many, many-to-many, hierarchical relationships

4. **Overall Domain** — What business domain does this schema serve?
   - HR, Finance, Sales, Healthcare, Manufacturing, Education, etc.

CRITICAL RULES:
- Do NOT just repeat column names. Explain what they MEAN in business terms.
- If sample data is provided, use it to improve your understanding.
- For foreign keys, explain the semantic meaning of the relationship (not just "references").
- Identify which fields are metrics (quantitative measures) vs dimensions (grouping/categorisation).
- The entity_type_represented should be one of: PERSON, ORGANIZATION, PRODUCT, SERVICE, \
SYSTEM, LOCATION, TRANSACTION, EVENT, CONCEPT, or null for junction tables.
"""

SCHEMA_ONTOLOGY_USER = """Analyze the following data schema and extract its complete ontology:

Source Name: {source_name}
Source Type: {source_type}

Schema Definition:
---
{schema_text}
---

{sample_data_section}

Return the complete ontology extraction as JSON matching the schema."""


ONTOLOGY_LINK_SYSTEM = """You are a semantic linking expert. Given a data table description and an \
existing graph entity, determine if the table semantically TRACKS instances of that entity type, or \
if a specific field DESCRIBES an attribute of that entity.

Consider:
- Table name vs entity name/type similarity
- What the table tracks vs what the entity represents
- Column names that match entity attributes
- The business domain context

A table TRACKS an entity if the table's rows represent instances of that entity type.
Example: An "employees" table TRACKS Entity "John Smith" (type PERSON) because employees are people.

A field DESCRIBES_ATTRIBUTE of an entity if the field captures data about entities of that type.
Example: A "salary" column DESCRIBES_ATTRIBUTE of PERSON entities — it records their salary.

If there is no meaningful semantic link, set should_link to false."""

ONTOLOGY_LINK_USER = """Should this data table be linked to this graph entity?

Data Table: "{table_name}"
Table Description: {table_description}
Entity Type Represented: {entity_type_represented}
Table Fields: {fields_summary}

Graph Entity: "{entity_name}" (type: {entity_type})
Entity Context: {entity_context}

Determine if there is a semantic link."""
