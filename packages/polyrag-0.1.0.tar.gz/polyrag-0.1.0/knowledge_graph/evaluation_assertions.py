"""
Graph assertion functions for KG evaluation.

Each function returns::

    {
        "passed": bool,
        "assertion": str,        # short label
        "message": str,          # human-readable verdict
        "details": dict,         # supporting evidence
    }

Usage::

    from knowledge_graph.evaluation_assertions import (
        assert_causal_chain_exists,
        assert_temporal_ordering,
        assert_event_has_evidence,
        assert_no_date_contradictions,
        assert_entity_participated,
        assert_timeline_connected,
    )
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from .neo4j_storage import KnowledgeGraphStorage
from .query_date_parser import parse_event_date

logger = logging.getLogger(__name__)


def _storage(tenant_id: str) -> KnowledgeGraphStorage:
    return KnowledgeGraphStorage(tenant_id)


# ---------------------------------------------------------------------------
# 1. Causal chain exists
# ---------------------------------------------------------------------------

def assert_causal_chain_exists(
    cause_event: str,
    effect_event: str,
    tenant_id: str,
    max_depth: int = 5,
) -> Dict[str, Any]:
    """
    Assert that a CAUSED path exists from *cause_event* to *effect_event*.
    """
    label = f"causal_chain({cause_event!r} -> {effect_event!r})"
    try:
        store = _storage(tenant_id)
        query = f"""
        MATCH (cause:Event {{tenant_id: $tid}})
        WHERE toLower(cause.name) = toLower($cause)
        MATCH (effect:Event {{tenant_id: $tid}})
        WHERE toLower(effect.name) = toLower($effect)
        MATCH path = (cause)-[:CAUSED*1..{max_depth}]->(effect)
        RETURN length(path) AS depth
        LIMIT 1
        """
        rows = store.neo4j.execute_query(query, {
            "tid": tenant_id,
            "cause": cause_event,
            "effect": effect_event,
        })
        passed = bool(rows)
        depth = rows[0]["depth"] if rows else None
        return {
            "passed": passed,
            "assertion": label,
            "message": (
                f"Causal path found (depth={depth})"
                if passed else "No CAUSED path found"
            ),
            "details": {"cause": cause_event, "effect": effect_event, "depth": depth},
        }
    except Exception as exc:
        logger.exception("assert_causal_chain_exists error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}


# ---------------------------------------------------------------------------
# 2. Temporal ordering
# ---------------------------------------------------------------------------

def assert_temporal_ordering(
    earlier_event: str,
    later_event: str,
    tenant_id: str,
    max_depth: int = 10,
) -> Dict[str, Any]:
    """
    Assert that a FOLLOWED_BY path exists from *earlier_event* to *later_event*.
    Also passes if earlier_event.date <= later_event.date (when both have parseable dates).
    """
    label = f"temporal_ordering({earlier_event!r} before {later_event!r})"
    try:
        store = _storage(tenant_id)

        # Graph path check
        query = f"""
        MATCH (a:Event {{tenant_id: $tid}})
        WHERE toLower(a.name) = toLower($earlier)
        MATCH (b:Event {{tenant_id: $tid}})
        WHERE toLower(b.name) = toLower($later)
        MATCH path = (a)-[:FOLLOWED_BY*1..{max_depth}]->(b)
        RETURN length(path) AS depth
        LIMIT 1
        """
        rows = store.neo4j.execute_query(query, {
            "tid": tenant_id, "earlier": earlier_event, "later": later_event,
        })
        graph_ok = bool(rows)
        depth = rows[0]["depth"] if rows else None

        # Date comparison fallback
        date_ok = False
        date_detail = {}
        if not graph_ok:
            date_query = """
            MATCH (a:Event {tenant_id: $tid}) WHERE toLower(a.name) = toLower($earlier)
            MATCH (b:Event {tenant_id: $tid}) WHERE toLower(b.name) = toLower($later)
            RETURN a.date AS date_a, b.date AS date_b
            LIMIT 1
            """
            date_rows = store.neo4j.execute_query(date_query, {
                "tid": tenant_id, "earlier": earlier_event, "later": later_event,
            })
            if date_rows:
                dt_a = parse_event_date(date_rows[0].get("date_a"))
                dt_b = parse_event_date(date_rows[0].get("date_b"))
                if dt_a and dt_b:
                    date_ok = dt_a <= dt_b
                    date_detail = {
                        "date_a": str(dt_a.date()),
                        "date_b": str(dt_b.date()),
                    }

        passed = graph_ok or date_ok
        if graph_ok:
            msg = f"FOLLOWED_BY path found (depth={depth})"
        elif date_ok:
            msg = f"Date ordering confirmed ({date_detail})"
        else:
            msg = "No FOLLOWED_BY path and no parseable dates to compare"

        return {
            "passed": passed,
            "assertion": label,
            "message": msg,
            "details": {
                "earlier": earlier_event, "later": later_event,
                "graph_path_found": graph_ok, "date_comparison": date_ok,
                **date_detail,
            },
        }
    except Exception as exc:
        logger.exception("assert_temporal_ordering error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}


# ---------------------------------------------------------------------------
# 3. Event has evidence
# ---------------------------------------------------------------------------

def assert_event_has_evidence(
    event_name: str,
    tenant_id: str,
) -> Dict[str, Any]:
    """
    Assert that *event_name* has at least one MENTIONED_IN edge with non-null evidence.
    """
    label = f"event_has_evidence({event_name!r})"
    try:
        store = _storage(tenant_id)
        query = """
        MATCH (e:Event {tenant_id: $tid})-[r:MENTIONED_IN]->(d:Document)
        WHERE toLower(e.name) = toLower($name)
          AND r.evidence IS NOT NULL AND r.evidence <> ''
        RETURN count(r) AS cnt, collect(d.file_name)[..3] AS sample_docs
        """
        rows = store.neo4j.execute_query(query, {"tid": tenant_id, "name": event_name})
        cnt = rows[0]["cnt"] if rows else 0
        passed = cnt > 0
        return {
            "passed": passed,
            "assertion": label,
            "message": (
                f"Evidence found in {cnt} document(s)"
                if passed else "No MENTIONED_IN edges with evidence"
            ),
            "details": {
                "event": event_name,
                "evidence_count": cnt,
                "sample_docs": rows[0].get("sample_docs", []) if rows else [],
            },
        }
    except Exception as exc:
        logger.exception("assert_event_has_evidence error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}


# ---------------------------------------------------------------------------
# 4. No date contradictions
# ---------------------------------------------------------------------------

def assert_no_date_contradictions(
    tenant_id: str,
    tolerance_days: int = 1,
) -> Dict[str, Any]:
    """
    Assert that for all FOLLOWED_BY edges where both events have parseable dates,
    earlier.date <= later.date (within *tolerance_days*).
    """
    label = "no_date_contradictions"
    try:
        from datetime import timedelta
        store = _storage(tenant_id)
        query = """
        MATCH (a:Event {tenant_id: $tid})-[:FOLLOWED_BY]->(b:Event {tenant_id: $tid})
        WHERE a.date IS NOT NULL AND b.date IS NOT NULL
        RETURN a.name AS a_name, b.name AS b_name,
               a.date AS date_a, b.date AS date_b
        """
        rows = store.neo4j.execute_query(query, {"tid": tenant_id})

        contradictions = []
        checked = 0
        for row in rows:
            dt_a = parse_event_date(row.get("date_a"))
            dt_b = parse_event_date(row.get("date_b"))
            if not (dt_a and dt_b):
                continue
            checked += 1
            if dt_a > dt_b + timedelta(days=tolerance_days):
                contradictions.append({
                    "earlier": row["a_name"], "date_a": str(dt_a.date()),
                    "later": row["b_name"],   "date_b": str(dt_b.date()),
                })

        passed = len(contradictions) == 0
        return {
            "passed": passed,
            "assertion": label,
            "message": (
                f"No contradictions in {checked} edge(s) with parseable dates"
                if passed else
                f"{len(contradictions)} date contradiction(s) found"
            ),
            "details": {
                "edges_checked": checked,
                "contradictions": contradictions[:10],  # cap output
            },
        }
    except Exception as exc:
        logger.exception("assert_no_date_contradictions error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}


# ---------------------------------------------------------------------------
# 5. Entity participated in event
# ---------------------------------------------------------------------------

def assert_entity_participated(
    entity_name: str,
    event_name: str,
    tenant_id: str,
) -> Dict[str, Any]:
    """
    Assert that *entity_name* has a PARTICIPATED_IN edge to *event_name*.
    """
    label = f"entity_participated({entity_name!r} in {event_name!r})"
    try:
        store = _storage(tenant_id)
        query = """
        MATCH (entity:Entity {tenant_id: $tid})
        WHERE toLower(entity.name) = toLower($entity)
        MATCH (entity)-[r:PARTICIPATED_IN]->(e:Event {tenant_id: $tid})
        WHERE toLower(e.name) = toLower($event)
        RETURN r.role AS role
        LIMIT 1
        """
        rows = store.neo4j.execute_query(query, {
            "tid": tenant_id, "entity": entity_name, "event": event_name,
        })
        passed = bool(rows)
        role = rows[0].get("role") if rows else None
        return {
            "passed": passed,
            "assertion": label,
            "message": (
                f"PARTICIPATED_IN found (role={role!r})"
                if passed else "No PARTICIPATED_IN edge found"
            ),
            "details": {
                "entity": entity_name, "event": event_name, "role": role,
            },
        }
    except Exception as exc:
        logger.exception("assert_entity_participated error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}


# ---------------------------------------------------------------------------
# 6. Timeline connected
# ---------------------------------------------------------------------------

def assert_timeline_connected(
    tenant_id: str,
    min_coverage: float = 0.5,
) -> Dict[str, Any]:
    """
    Assert that at least *min_coverage* fraction of events are reachable
    via FOLLOWED_BY or CAUSED traversal from the earliest-dated event.
    """
    label = f"timeline_connected(min_coverage={min_coverage:.0%})"
    try:
        store = _storage(tenant_id)

        # Total event count
        total_rows = store.neo4j.execute_query(
            "MATCH (e:Event {tenant_id: $tid}) RETURN count(e) AS cnt",
            {"tid": tenant_id},
        )
        total = total_rows[0]["cnt"] if total_rows else 0
        if total == 0:
            return {
                "passed": False, "assertion": label,
                "message": "No events found", "details": {},
            }

        # Find event with earliest parseable date as starting node
        date_rows = store.neo4j.execute_query(
            "MATCH (e:Event {tenant_id: $tid}) WHERE e.date IS NOT NULL "
            "RETURN e.event_id AS eid, e.name AS name, e.date AS date",
            {"tid": tenant_id},
        )
        if not date_rows:
            return {
                "passed": False, "assertion": label,
                "message": "No events with dates to anchor traversal",
                "details": {"total_events": total},
            }

        # Pick earliest
        def _sort_key(r: dict):
            dt = parse_event_date(r.get("date"))
            return (dt is None, dt)

        date_rows.sort(key=_sort_key)
        start_id = date_rows[0]["eid"]
        start_name = date_rows[0]["name"]

        # BFS/reachability from start
        reachable_rows = store.neo4j.execute_query(
            """
            MATCH (start:Event {event_id: $start_id, tenant_id: $tid})
            MATCH path = (start)-[:FOLLOWED_BY|CAUSED*0..20]->(e:Event {tenant_id: $tid})
            RETURN count(DISTINCT e) AS reachable
            """,
            {"tid": tenant_id, "start_id": start_id},
        )
        reachable = reachable_rows[0]["reachable"] if reachable_rows else 0
        coverage = reachable / total
        passed = coverage >= min_coverage

        return {
            "passed": passed,
            "assertion": label,
            "message": (
                f"Coverage {coverage:.0%} ({reachable}/{total} events reachable from '{start_name}')"
            ),
            "details": {
                "start_event": start_name,
                "reachable": reachable,
                "total": total,
                "coverage": round(coverage, 3),
                "min_coverage": min_coverage,
            },
        }
    except Exception as exc:
        logger.exception("assert_timeline_connected error")
        return {"passed": False, "assertion": label, "message": str(exc), "details": {}}
