"""
OntologyBuilder – converts parsed schema + LLM ontology into Neo4j graph.

Coordinates between the schema parser output, the LLM enrichment result,
and the ontology storage layer to build DataSource/DataTable/DataField
nodes and their structural relationships.
"""

import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional

from .ontology_schemas import SchemaOntologyExtractionResult
from .ontology_storage import OntologyStorage
from .schema_parser import ParsedSchema

logger = logging.getLogger(__name__)


class OntologyBuilder:
    """Build the ontology subgraph from parsed schema + LLM enrichment."""

    def __init__(self, storage: OntologyStorage):
        self.storage = storage

    def build(
        self,
        parsed_schema: ParsedSchema,
        ontology_result: SchemaOntologyExtractionResult,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """
        Build the ontology subgraph in Neo4j.

        Steps:
        1. Merge DataSource node
        2. For each table: merge DataTable + HAS_TABLE
        3. For each field: merge DataField + HAS_FIELD
        4. For each explicit FK from parsed schema: merge FOREIGN_KEY
        5. For each LLM-inferred cross-table relationship: merge FOREIGN_KEY

        Parameters
        ----------
        parsed_schema : ParsedSchema
            Structural data from SchemaParser.
        ontology_result : SchemaOntologyExtractionResult
            LLM-enriched semantic understanding.
        tenant_id : str
            Tenant isolation key.

        Returns
        -------
        dict
            Stats: data_tables_created, data_fields_created, foreign_keys_created.
        """
        stats: Dict[str, int] = defaultdict(int)

        # Build a lookup from table_name -> LLM semantics
        llm_tables = {t.table_name: t for t in ontology_result.tables}

        # 1. Merge DataSource node
        source_id = self.storage.make_source_id(parsed_schema.source_name)
        self.storage.merge_data_source(source_id, {
            "name": parsed_schema.source_name,
            "type": parsed_schema.source_type,
            "description": ontology_result.overall_description,
            "domain": ontology_result.domain,
            "table_count": len(parsed_schema.tables),
        })

        # Track all field IDs for FK resolution
        field_id_lookup: Dict[str, str] = {}  # "table.field" -> field_id

        # 2-3. Tables and fields
        for parsed_table in parsed_schema.tables:
            table_id = self.storage.make_table_id(source_id, parsed_table.name)
            llm_table = llm_tables.get(parsed_table.name)

            # Merge DataTable node
            table_props = {
                "name": parsed_table.name,
                "row_count": parsed_table.row_count,
            }
            if llm_table:
                table_props["semantic_description"] = llm_table.semantic_description
                table_props["entity_type_represented"] = llm_table.entity_type_represented
                table_props["is_junction_table"] = llm_table.is_junction_table
                table_props["confidence"] = llm_table.confidence

            self.storage.merge_data_table(table_id, table_props)
            self.storage.merge_has_table(source_id, table_id)
            stats["data_tables_created"] += 1

            # Build field semantics lookup
            llm_fields = {}
            if llm_table:
                llm_fields = {f.field_name: f for f in llm_table.fields}

            # Merge DataField nodes
            for parsed_field in parsed_table.fields:
                field_id = self.storage.make_field_id(table_id, parsed_field.name)
                field_id_lookup[f"{parsed_table.name}.{parsed_field.name}"] = field_id
                llm_field = llm_fields.get(parsed_field.name)

                field_props = {
                    "name": parsed_field.name,
                    "data_type": parsed_field.data_type,
                    "is_primary_key": parsed_field.is_primary_key,
                }
                if parsed_field.sample_values:
                    field_props["sample_values"] = parsed_field.sample_values[:3]

                if llm_field:
                    field_props["semantic_description"] = llm_field.semantic_description
                    field_props["semantic_role"] = llm_field.semantic_role
                    field_props["maps_to_entity_type"] = llm_field.maps_to_entity_type
                    field_props["is_metric"] = llm_field.is_metric
                    field_props["is_dimension"] = llm_field.is_dimension
                    field_props["confidence"] = llm_field.confidence

                self.storage.merge_data_field(field_id, field_props)
                self.storage.merge_has_field(table_id, field_id)
                stats["data_fields_created"] += 1

        # 4. Explicit FK relationships from parsed schema
        for parsed_table in parsed_schema.tables:
            for parsed_field in parsed_table.fields:
                if parsed_field.foreign_key_ref:
                    from_key = f"{parsed_table.name}.{parsed_field.name}"
                    to_key = parsed_field.foreign_key_ref  # e.g. "departments.department_id"

                    from_id = field_id_lookup.get(from_key)
                    to_id = field_id_lookup.get(to_key)

                    if from_id and to_id:
                        self.storage.merge_foreign_key(
                            from_id, to_id,
                            description=f"{from_key} references {to_key}",
                        )
                        stats["foreign_keys_created"] += 1

        # 5. LLM-inferred cross-table relationships
        for rel in ontology_result.cross_table_relationships:
            from_key = f"{rel.from_table}.{rel.from_field}"
            to_key = f"{rel.to_table}.{rel.to_field}"

            from_id = field_id_lookup.get(from_key)
            to_id = field_id_lookup.get(to_key)

            if from_id and to_id:
                # Skip if already created as explicit FK
                if from_key not in [
                    f"{t.name}.{f.name}"
                    for t in parsed_schema.tables
                    for f in t.fields
                    if f.foreign_key_ref == to_key
                ]:
                    self.storage.merge_foreign_key(
                        from_id, to_id,
                        description=rel.description or f"{rel.relationship_type}: {from_key} -> {to_key}",
                    )
                    stats["inferred_relationships_created"] += 1

        logger.info(
            "Ontology build complete for source=%s: %s",
            parsed_schema.source_name, dict(stats),
        )
        return dict(stats)
