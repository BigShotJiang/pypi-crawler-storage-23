"""Unified Document Pipeline — flexible orchestration of structured extraction and RAG indexing.

Modes
-----
- ``structured_only``  : LLM entity extraction → Athena/S3 storage only.
- ``rag_only``         : BM25 + FAISS indexing only (text / vector / hybrid retrieval).
- ``both``             : Parse once, run structured extraction, then index chunks enriched
                         with extracted entity metadata.

Quick start::

    from unified_pipeline import UnifiedDocumentPipeline, UnifiedPipelineConfig
    from openrag import OpenRAGConfig

    cfg = UnifiedPipelineConfig(
        enable_structured=True,
        enable_rag=True,
        tenant_id="t1", user_id="u1", resource_id="r1",
        openrag=OpenRAGConfig(text_backend="sqlite"),
    )
    pipeline = UnifiedDocumentPipeline(cfg)
    result = pipeline.process_file("report.pdf")
    print(result["rag"]["chunks_indexed"])
    print(result["structured"]["extraction_count"])
"""

from unified_pipeline.config import UnifiedPipelineConfig, unified_pipeline_config_from_env
from unified_pipeline.pipeline import UnifiedDocumentPipeline

__all__ = [
    "UnifiedPipelineConfig",
    "unified_pipeline_config_from_env",
    "UnifiedDocumentPipeline",
]
