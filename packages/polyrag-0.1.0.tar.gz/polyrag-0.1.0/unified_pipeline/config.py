"""UnifiedPipelineConfig — configuration for the flexible unified document pipeline.

Reads from environment variables with the prefix ``PIPELINE_*`` for pipeline-level
settings and ``OPENRAG_*`` for the embedded OpenRAG config.

Environment variables
---------------------
PIPELINE_ENABLE_STRUCTURED   : "true" / "false" (default: true)
PIPELINE_ENABLE_RAG           : "true" / "false" (default: true)
PIPELINE_RAG_RETRIEVAL_MODE   : "hybrid" / "text" / "vector" (default: "hybrid")
PIPELINE_TENANT_ID            : Tenant ID passed to StructuredDataPipeline
PIPELINE_USER_ID              : User ID passed to StructuredDataPipeline
PIPELINE_RESOURCE_ID          : Resource ID passed to StructuredDataPipeline
PIPELINE_USE_LLM_ENTITY_MATCHING : "true" / "false" (default: false)
PIPELINE_SIMILARITY_THRESHOLD : float (default: 0.82)
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from openrag.config import OpenRAGConfig, openrag_config_from_env


def _env_bool(key: str, default: bool) -> bool:
    val = os.getenv(key)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes")


def _env_float(key: str, default: float) -> float:
    val = os.getenv(key)
    return float(val) if val is not None else default


@dataclass
class UnifiedPipelineConfig:
    """Configuration for the unified document pipeline.

    Attributes
    ----------
    enable_structured : bool
        Whether to run the LLM entity extraction pipeline (StructuredDataPipeline).
        Requires valid LLM credentials in the environment.
    enable_rag : bool
        Whether to run BM25 + FAISS indexing (OpenRAG pipeline).
    rag_retrieval_mode : str
        Default retrieval mode for OpenRAGRetriever: ``"hybrid"``, ``"text"``, or ``"vector"``.

    tenant_id, user_id, resource_id : str
        Required by StructuredDataPipeline for Athena/S3 scoping.
        Ignored when ``enable_structured=False``.
    use_llm_entity_matching : bool
        Passed to StructuredDataPipeline for cross-entity semantic matching.
    similarity_threshold : float
        Entity deduplication threshold for StructuredDataPipeline.

    openrag : OpenRAGConfig
        Full OpenRAG configuration (embedding model, text backend, FAISS paths, etc.).
        Loaded from ``OPENRAG_*`` env vars by default.
    """

    # ── Pipeline mode ──────────────────────────────────────────────────────────
    enable_structured: bool = True
    enable_rag: bool = True
    rag_retrieval_mode: str = "hybrid"

    # ── Structured pipeline context ────────────────────────────────────────────
    tenant_id: str = ""
    user_id: str = ""
    resource_id: str = ""
    use_llm_entity_matching: bool = False
    similarity_threshold: float = 0.82

    # ── OpenRAG config ─────────────────────────────────────────────────────────
    openrag: OpenRAGConfig = field(default_factory=OpenRAGConfig)

    def __post_init__(self) -> None:
        valid_modes = {"hybrid", "text", "vector"}
        if self.rag_retrieval_mode not in valid_modes:
            raise ValueError(
                f"rag_retrieval_mode must be one of {valid_modes}, got '{self.rag_retrieval_mode}'"
            )
        if not self.enable_structured and not self.enable_rag:
            raise ValueError(
                "At least one of enable_structured or enable_rag must be True."
            )

    @property
    def mode_label(self) -> str:
        """Human-readable mode label for logging / output."""
        if self.enable_structured and self.enable_rag:
            return "both"
        if self.enable_structured:
            return "structured_only"
        return "rag_only"


def unified_pipeline_config_from_env() -> UnifiedPipelineConfig:
    """Build a UnifiedPipelineConfig from environment variables.

    Pipeline-level settings use ``PIPELINE_*`` prefix.
    OpenRAG settings are loaded via ``openrag_config_from_env()`` (``OPENRAG_*``).
    """
    return UnifiedPipelineConfig(
        enable_structured=_env_bool("PIPELINE_ENABLE_STRUCTURED", True),
        enable_rag=_env_bool("PIPELINE_ENABLE_RAG", True),
        rag_retrieval_mode=os.getenv("PIPELINE_RAG_RETRIEVAL_MODE", "hybrid"),
        tenant_id=os.getenv("PIPELINE_TENANT_ID", ""),
        user_id=os.getenv("PIPELINE_USER_ID", ""),
        resource_id=os.getenv("PIPELINE_RESOURCE_ID", ""),
        use_llm_entity_matching=_env_bool("PIPELINE_USE_LLM_ENTITY_MATCHING", False),
        similarity_threshold=_env_float("PIPELINE_SIMILARITY_THRESHOLD", 0.82),
        openrag=openrag_config_from_env(),
    )
