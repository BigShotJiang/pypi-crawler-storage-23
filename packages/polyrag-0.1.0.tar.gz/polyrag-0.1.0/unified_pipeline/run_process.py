"""CLI entry point for the Unified Document Pipeline.

Usage::

    python -m unified_pipeline.run_process path/to/doc.pdf [doc2.pdf ...]
        --mode            both|structured-only|rag-only    (default: both)
        --rag-retrieval   hybrid|text|vector               (default: hybrid)
        --tenant-id       <id>
        --user-id         <id>
        --resource-id     <id>
        --text-backend    sqlite|postgres|mysql|mongodb    (default: sqlite)
        --embedding-model all-MiniLM-L6-v2
        --device          cpu|cuda|mps
        --faiss-path      ./openrag.faiss
        --faiss-meta-path ./openrag_meta.json
        --bm25-path       ./openrag_bm25.sqlite            (SQLite only)
        --postgres-host / --postgres-port / --postgres-db / ...
        --mysql-host / --mysql-port / ...
        --no-overwrite                                     (incremental RAG mode)
        --verbose / -v
        --json                                             (print result as JSON)
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m unified_pipeline.run_process",
        description=(
            "Process one or more documents through the unified pipeline. "
            "Choose structured extraction, RAG indexing, or both."
        ),
    )
    p.add_argument("files", nargs="+", metavar="FILE", help="Document file(s) to process.")

    # ── Pipeline mode ─────────────────────────────────────────────────────────
    p.add_argument(
        "--mode", default="both",
        choices=["both", "structured-only", "rag-only"],
        help="Pipeline mode (default: both).",
    )
    p.add_argument(
        "--rag-retrieval", default="hybrid",
        choices=["hybrid", "text", "vector"],
        dest="rag_retrieval",
        help="RAG retrieval mode for OpenRAGRetriever (default: hybrid).",
    )

    # ── Structured pipeline context ───────────────────────────────────────────
    p.add_argument("--tenant-id", default=None)
    p.add_argument("--user-id", default=None)
    p.add_argument("--resource-id", default=None)
    p.add_argument("--use-llm-entity-matching", action="store_true",
                   help="Enable LLM-based cross-entity semantic matching.")
    p.add_argument("--similarity-threshold", type=float, default=None,
                   help="Entity deduplication threshold (default: 0.82).")

    # ── OpenRAG / embedding ───────────────────────────────────────────────────
    p.add_argument("--text-backend", default=None,
                   choices=["sqlite", "postgres", "mysql", "mongodb"])
    p.add_argument("--embedding-model", default=None,
                   help="sentence-transformers model name.")
    p.add_argument("--device", default=None, choices=["cpu", "cuda", "mps"])
    p.add_argument("--faiss-path", default=None)
    p.add_argument("--faiss-meta-path", default=None)
    p.add_argument("--bm25-path", default=None, help="SQLite BM25 path (SQLite backend only).")
    p.add_argument("--postgres-host", default=None)
    p.add_argument("--postgres-port", type=int, default=None)
    p.add_argument("--postgres-db", default=None)
    p.add_argument("--postgres-user", default=None)
    p.add_argument("--postgres-password", default=None)
    p.add_argument("--mysql-host", default=None)
    p.add_argument("--mysql-port", type=int, default=None)
    p.add_argument("--mysql-db", default=None)
    p.add_argument("--mysql-user", default=None)
    p.add_argument("--mysql-password", default=None)
    p.add_argument("--no-overwrite", action="store_true",
                   help="Incremental RAG mode — append without removing old chunks.")

    # ── Output ────────────────────────────────────────────────────────────────
    p.add_argument("--verbose", "-v", action="store_true")
    p.add_argument("--json", action="store_true", help="Print result as JSON.")
    return p


def main(argv: list | None = None) -> None:
    args = _build_parser().parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )

    # ── Build config ──────────────────────────────────────────────────────────
    from unified_pipeline.config import unified_pipeline_config_from_env

    cfg = unified_pipeline_config_from_env()

    # Apply mode overrides
    mode_map = {
        "both": (True, True),
        "structured-only": (True, False),
        "rag-only": (False, True),
    }
    cfg.enable_structured, cfg.enable_rag = mode_map[args.mode]
    cfg.rag_retrieval_mode = args.rag_retrieval

    # Structured context overrides
    if args.tenant_id:
        cfg.tenant_id = args.tenant_id
    if args.user_id:
        cfg.user_id = args.user_id
    if args.resource_id:
        cfg.resource_id = args.resource_id
    if args.use_llm_entity_matching:
        cfg.use_llm_entity_matching = True
    if args.similarity_threshold is not None:
        cfg.similarity_threshold = args.similarity_threshold

    # OpenRAG overrides
    if args.text_backend:
        cfg.openrag.text_backend = args.text_backend
    if args.embedding_model:
        cfg.openrag.embedding_model = args.embedding_model
    if args.device:
        cfg.openrag.embedding_device = args.device
    if args.faiss_path:
        cfg.openrag.faiss_index_path = args.faiss_path
    if args.faiss_meta_path:
        cfg.openrag.faiss_metadata_path = args.faiss_meta_path
    if args.bm25_path:
        cfg.openrag.sqlite_bm25_path = args.bm25_path
    if args.postgres_host:
        cfg.openrag.postgres_host = args.postgres_host
    if args.postgres_port:
        cfg.openrag.postgres_port = args.postgres_port
    if args.postgres_db:
        cfg.openrag.postgres_db = args.postgres_db
    if args.postgres_user:
        cfg.openrag.postgres_user = args.postgres_user
    if args.postgres_password:
        cfg.openrag.postgres_password = args.postgres_password
    if args.mysql_host:
        cfg.openrag.mysql_host = args.mysql_host
    if args.mysql_port:
        cfg.openrag.mysql_port = args.mysql_port
    if args.mysql_db:
        cfg.openrag.mysql_db = args.mysql_db
    if args.mysql_user:
        cfg.openrag.mysql_user = args.mysql_user
    if args.mysql_password:
        cfg.openrag.mysql_password = args.mysql_password
    if args.no_overwrite:
        cfg.openrag.overwrite_on_reindex = False
    cfg.openrag.show_progress = args.verbose

    # ── Run pipeline ──────────────────────────────────────────────────────────
    from unified_pipeline.pipeline import UnifiedDocumentPipeline

    pipeline = UnifiedDocumentPipeline(cfg)
    all_results = []

    for file_path in args.files:
        t0 = time.perf_counter()
        try:
            result = pipeline.process_file(file_path)
        except Exception as exc:
            result = {
                "file_name": file_path,
                "file_path": file_path,
                "mode": cfg.mode_label,
                "structured": None,
                "structured_error": str(exc),
                "rag": None,
                "rag_error": str(exc),
            }
            if not args.json:
                print(f"[ERROR] {file_path}: {exc}", file=sys.stderr)
        result["elapsed_s"] = round(time.perf_counter() - t0, 2)
        all_results.append(result)

    # ── Output ────────────────────────────────────────────────────────────────
    if args.json:
        print(json.dumps(all_results, indent=2, default=str))
        return

    for r in all_results:
        print(f"\n[UnifiedPipeline]")
        print(f"  File    : {r.get('file_name', '?')}")
        print(f"  Mode    : {r.get('mode', '?')}")
        print(f"  Elapsed : {r.get('elapsed_s', '?')}s")

        structured = r.get("structured")
        s_err = r.get("structured_error")
        if structured is not None:
            print(f"\n  [Structured Extraction]")
            print(f"    Document ID      : {structured.get('document_id', '?')}")
            print(f"    Extractions      : {structured.get('extraction_count', 0)}")
            print(f"    Entities resolved: {structured.get('entities_resolved', 0)}")
            print(f"    New entities     : {structured.get('new_entities', 0)}")
            if structured.get("llm_budget_estimate"):
                budget = structured["llm_budget_estimate"]
                print(f"    LLM cost est.    : ${budget.get('total_cost_usd', 0):.4f}")
        elif s_err:
            print(f"\n  [Structured Extraction] FAILED: {s_err}")

        rag = r.get("rag")
        rag_err = r.get("rag_error")
        if rag is not None:
            print(f"\n  [RAG Indexing]")
            print(f"    Doc ID           : {rag.get('doc_id', '?')}")
            print(f"    Chunks indexed   : {rag.get('chunks_indexed', 0)}")
            print(f"    Text backend     : {rag.get('text_backend', '?')}")
            print(f"    Embedding model  : {rag.get('embedding_model', '?')}")
            print(f"    Embedding dim    : {rag.get('embedding_dim', '?')}")
            if rag.get("warning"):
                print(f"    Warning          : {rag['warning']}")
        elif rag_err:
            print(f"\n  [RAG Indexing] FAILED: {rag_err}")

        print()


if __name__ == "__main__":
    main()
