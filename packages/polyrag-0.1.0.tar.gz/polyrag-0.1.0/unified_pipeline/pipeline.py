"""UnifiedDocumentPipeline — orchestrates structured extraction and/or RAG indexing.

Pipeline flow
-------------
1. Parse the document **once** using ``parse_file_to_text()`` from
   ``parsers.pipeline_text_parser``.  The resulting text (with ``--- Page N ---``
   markers) is shared across both downstream branches.

2. [if enable_structured]
   Run ``StructuredDataPipeline.process_text()`` to extract entities.
   From the result, collect entity metadata:
   ``{"doc_type", "entity_names", "entity_types", "entity_count"}``.

3. [if enable_rag]
   Run ``OpenRAGIndexer.index_text()`` with:
   - The shared parsed text.
   - The structured pipeline's ``document_id`` as ``doc_id`` (in "both" mode),
     so the same identifier can be used to filter/query both systems.
   - ``extra_metadata`` set to the entity metadata collected in step 2 (empty dict
     in rag-only mode).

4. Return a combined result dict with per-stage summaries and any errors.

Error handling
--------------
Stage failures are isolated: if structured extraction raises an exception, RAG
indexing still proceeds (with empty metadata).  Errors are captured in the result
under ``"structured_error"`` / ``"rag_error"`` keys rather than propagating.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

from unified_pipeline.config import UnifiedPipelineConfig, unified_pipeline_config_from_env

logger = logging.getLogger(__name__)


class UnifiedDocumentPipeline:
    """Flexible pipeline that can run structured extraction, RAG indexing, or both.

    Args:
        config: ``UnifiedPipelineConfig`` instance. If None, loads from env vars.

    Usage::

        from unified_pipeline import UnifiedDocumentPipeline, UnifiedPipelineConfig
        from openrag import OpenRAGConfig

        cfg = UnifiedPipelineConfig(
            enable_structured=True,
            enable_rag=True,
            tenant_id="t1", user_id="u1", resource_id="r1",
            openrag=OpenRAGConfig(text_backend="sqlite"),
        )
        pipeline = UnifiedDocumentPipeline(cfg)
        result = pipeline.process_file("invoice.pdf")
        # result["structured"]["extraction_count"]
        # result["rag"]["chunks_indexed"]
    """

    def __init__(self, config: Optional[UnifiedPipelineConfig] = None) -> None:
        self.config = config or unified_pipeline_config_from_env()
        self._structured_pipeline = None   # lazy — only created when needed
        self._rag_indexer = None           # lazy — only created when needed

    # ── Public API ────────────────────────────────────────────────────────────

    def process_file(
        self,
        file_path: str,
        tenant_id: Optional[str] = None,
        user_id: Optional[str] = None,
        resource_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Parse and process a document file according to the configured pipeline mode.

        Args:
            file_path: Path to the source document (PDF, DOCX, XLSX, etc.).
            tenant_id: Override config's tenant_id (structured pipeline only).
            user_id: Override config's user_id (structured pipeline only).
            resource_id: Override config's resource_id (structured pipeline only).

        Returns:
            Dict with keys:
            - ``"file_name"``: basename of the input file
            - ``"file_path"``: absolute path of the input file
            - ``"mode"``: ``"both"`` / ``"structured_only"`` / ``"rag_only"``
            - ``"structured"``: structured pipeline result dict, or None
            - ``"structured_error"``: error message if structured stage failed, or None
            - ``"rag"``: OpenRAG indexer result dict, or None
            - ``"rag_error"``: error message if RAG stage failed, or None
        """
        cfg = self.config
        resolved_tenant = tenant_id or cfg.tenant_id
        resolved_user = user_id or cfg.user_id
        resolved_resource = resource_id or cfg.resource_id
        file_name = os.path.basename(file_path)
        abs_path = os.path.abspath(file_path)

        result: Dict[str, Any] = {
            "file_name": file_name,
            "file_path": abs_path,
            "mode": cfg.mode_label,
            "structured": None,
            "structured_error": None,
            "rag": None,
            "rag_error": None,
        }

        # ── Step 1: Parse once ────────────────────────────────────────────────
        logger.info("UnifiedDocumentPipeline: parsing %s", abs_path)
        text, title_hint = self._parse_once(abs_path)
        if not text.strip():
            logger.warning("UnifiedDocumentPipeline: no text extracted from %s", abs_path)
            result["structured_error"] = "No text extracted from document."
            result["rag_error"] = "No text extracted from document."
            return result

        # ── Step 2: Structured extraction ─────────────────────────────────────
        structured_result: Optional[Dict[str, Any]] = None
        entity_metadata: Dict[str, Any] = {}
        doc_id_from_structured: Optional[str] = None

        if cfg.enable_structured:
            try:
                pipeline = self._get_structured_pipeline()
                structured_result = pipeline.process_text(
                    text=text,
                    file_name=file_name,
                    tenant_id=resolved_tenant,
                    user_id=resolved_user,
                    resource_id=resolved_resource,
                    title_hint=title_hint,
                )
                doc_id_from_structured = structured_result.get("document_id")
                entity_metadata = self._extract_entity_metadata(structured_result)
                result["structured"] = structured_result
                logger.info(
                    "UnifiedDocumentPipeline: structured extraction complete — "
                    "%d extractions, doc_id=%s",
                    structured_result.get("extraction_count", 0),
                    doc_id_from_structured,
                )
            except Exception as exc:
                logger.error(
                    "UnifiedDocumentPipeline: structured extraction failed for %s: %s",
                    abs_path, exc, exc_info=True,
                )
                result["structured_error"] = str(exc)

        # ── Step 3: RAG indexing ──────────────────────────────────────────────
        if cfg.enable_rag:
            try:
                indexer = self._get_rag_indexer()
                rag_result = indexer.index_text(
                    text=text,
                    file_name=file_name,
                    # In "both" mode, use the structured pipeline's doc_id so both
                    # systems share the same identifier for filtering / querying.
                    doc_id=doc_id_from_structured if cfg.enable_structured else None,
                    extra_metadata=entity_metadata,
                )
                result["rag"] = rag_result
                logger.info(
                    "UnifiedDocumentPipeline: RAG indexing complete — "
                    "%d chunks, doc_id=%s",
                    rag_result.get("chunks_indexed", 0),
                    rag_result.get("doc_id"),
                )
            except Exception as exc:
                logger.error(
                    "UnifiedDocumentPipeline: RAG indexing failed for %s: %s",
                    abs_path, exc, exc_info=True,
                )
                result["rag_error"] = str(exc)

        return result

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _parse_once(self, file_path: str):
        """Parse the document file to plain text. Returns (text, title_hint)."""
        from parsers.pipeline_text_parser import parse_file_to_text

        try:
            parse_result = parse_file_to_text(file_path)
            text = getattr(parse_result, "text", "") or ""
            title_hint = getattr(parse_result, "title_hint", None)
            return text, title_hint
        except Exception as exc:
            logger.error("UnifiedDocumentPipeline: parsing failed for %s: %s", file_path, exc)
            return "", None

    def _get_structured_pipeline(self):
        """Lazy-initialise StructuredDataPipeline."""
        if self._structured_pipeline is None:
            from structured_data.pipeline import StructuredDataPipeline
            self._structured_pipeline = StructuredDataPipeline(
                use_llm_entity_matching=self.config.use_llm_entity_matching,
                similarity_threshold=self.config.similarity_threshold,
            )
        return self._structured_pipeline

    def _get_rag_indexer(self):
        """Lazy-initialise OpenRAGIndexer."""
        if self._rag_indexer is None:
            from openrag.indexer import OpenRAGIndexer
            self._rag_indexer = OpenRAGIndexer(self.config.openrag)
        return self._rag_indexer

    @staticmethod
    def _extract_entity_metadata(structured_result: Dict[str, Any]) -> Dict[str, Any]:
        """Distil entity-level metadata from a StructuredDataPipeline result.

        Extracts unique entity names, entity types, and the document type from
        the structured extraction result so they can be stored as chunk metadata
        in the RAG index.

        Returns a dict with keys:
        - ``"doc_type"``       : str or None
        - ``"entity_names"``   : sorted list of unique entity names
        - ``"entity_types"``   : sorted list of unique entity types
        - ``"entity_count"``   : total number of extractions
        """
        doc_meta = structured_result.get("document_meta") or {}
        doc_type = doc_meta.get("document_type") or doc_meta.get("doc_type")

        extractions = structured_result.get("extractions") or []
        entity_names: list = sorted({
            e["entity_name"]
            for e in extractions
            if e.get("entity_name")
        })
        entity_types: list = sorted({
            e["entity_type"]
            for e in extractions
            if e.get("entity_type")
        })

        return {
            "doc_type": doc_type,
            "entity_names": entity_names,
            "entity_types": entity_types,
            "entity_count": len(extractions),
        }
