"""OpenRAGRetriever — queries both text and vector stores with RRF fusion.

Pipeline::

    retrieve(query, mode="hybrid")
      → text_store.search(query, top_k=20)         BM25 [(chunk_id, score)]
      → embedding_provider.encode([query])          1-D float32 array
      → vector_store.search(query_emb, top_k=20)   HNSW [(chunk_id, l2_dist)]
      → reciprocal_rank_fusion([text, vector])      fused ranking
      → _hydrate()                                  chunk_id → full metadata dict
      → List[dict] with retrieval_score, retrieval_mode, text, file_name, pages …
"""

from __future__ import annotations

import logging
from typing import List, Optional, Tuple

from openrag.config import OpenRAGConfig, openrag_config_from_env
from openrag.embedding.manager import EmbeddingManager
from openrag.fusion import reciprocal_rank_fusion
from openrag.stores.factory import get_text_store
from openrag.stores.vector_store import FAISSVectorStore

logger = logging.getLogger(__name__)


class OpenRAGRetriever:
    """Retrieves relevant chunks using text search, vector search, or hybrid RRF.

    Args:
        config: OpenRAGConfig instance. If None, loads from environment variables.

    Usage::

        retriever = OpenRAGRetriever()
        results = retriever.retrieve("invoice total amount", top_k=5)
        for r in results:
            print(r["retrieval_score"], r["text"][:120])
    """

    def __init__(self, config: Optional[OpenRAGConfig] = None) -> None:
        self.config = config or openrag_config_from_env()
        self._embedding_manager = EmbeddingManager()
        self._provider = self._embedding_manager.get_provider(
            model_name=self.config.embedding_model,
            device=self.config.embedding_device,
            normalize=self.config.embedding_normalize,
        )
        self.text_store = get_text_store(self.config)
        self.vector_store = FAISSVectorStore(
            index_path=self.config.faiss_index_path,
            metadata_path=self.config.faiss_metadata_path,
            embedding_provider=self._provider,
            hnsw_m=self.config.faiss_hnsw_m,
            ef_construction=self.config.faiss_ef_construction,
            ef_search=self.config.faiss_ef_search,
        )
        # Attempt to load the FAISS index from disk on construction.
        # This is a no-op if the index files don't exist yet.
        import os
        if os.path.exists(self.config.faiss_index_path) and os.path.exists(
            self.config.faiss_metadata_path
        ):
            self.vector_store.load()
        else:
            logger.warning(
                "OpenRAGRetriever: FAISS index files not found at '%s'. "
                "Vector search will return empty results until documents are indexed.",
                self.config.faiss_index_path,
            )

    # ── Public API ────────────────────────────────────────────────────────────

    def retrieve(
        self,
        query: str,
        top_k: Optional[int] = None,
        mode: Optional[str] = None,
        doc_id_filter: Optional[str] = None,
    ) -> List[dict]:
        """Retrieve the most relevant chunks for a query.

        Args:
            query: Natural language query string.
            top_k: Number of results to return. Defaults to config.top_k_final.
            mode: ``"text"``, ``"vector"``, or ``"hybrid"``.
                  Defaults to config.retrieval_mode.
            doc_id_filter: Restrict search to chunks from a single document
                           (use the doc_id returned by the indexer).

        Returns:
            List of chunk metadata dicts, each containing:
            - ``text``, ``file_name``, ``chunk_index``, ``start_page``,
              ``end_page``, ``has_overlap``, ``char_count``
            - ``doc_id``, ``chunk_id``
            - ``retrieval_score`` (float)
            - ``retrieval_mode`` (str)
        """
        final_k = top_k or self.config.top_k_final
        active_mode = mode or self.config.retrieval_mode

        text_results: List[Tuple[str, float]] = []
        vector_results: List[Tuple[str, float]] = []

        if active_mode in ("text", "hybrid"):
            text_results = self.text_store.search(
                query,
                top_k=self.config.top_k_text,
                doc_id_filter=doc_id_filter,
            )
            logger.debug("BM25 search returned %d candidates", len(text_results))

        if active_mode in ("vector", "hybrid"):
            query_emb = self._provider.encode([query])[0]
            vector_results = self.vector_store.search(
                query_emb,
                top_k=self.config.top_k_vector,
                doc_id_filter=doc_id_filter,
            )
            logger.debug("FAISS search returned %d candidates", len(vector_results))

        if active_mode == "text":
            ranked = [(cid, score) for cid, score in text_results[:final_k]]
        elif active_mode == "vector":
            ranked = [(cid, score) for cid, score in vector_results[:final_k]]
        else:  # hybrid
            ranked = reciprocal_rank_fusion(
                [text_results, vector_results],
                k=self.config.rrf_k,
                top_k=final_k,
            )

        return self._hydrate(ranked, active_mode)

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _hydrate(
        self,
        ranked: List[Tuple[str, float]],
        mode: str,
    ) -> List[dict]:
        """Enrich (chunk_id, score) pairs with full ChunkRecord metadata.

        Primary source: FAISS sidecar ``_chunk_id_to_entry`` dict (always
        contains full text regardless of retrieval mode).
        Fallback: warn and skip chunks that cannot be resolved.
        """
        results = []
        for chunk_id, score in ranked:
            meta = self.vector_store.get_chunk(chunk_id)
            if meta is None:
                logger.debug("_hydrate: chunk_id %s not found in FAISS sidecar, skipping", chunk_id)
                continue
            record = dict(meta)
            # Remove internal FAISS bookkeeping fields
            record.pop("faiss_id", None)
            record.pop("deleted", None)
            record["retrieval_score"] = float(score)
            record["retrieval_mode"] = mode
            results.append(record)
        return results
