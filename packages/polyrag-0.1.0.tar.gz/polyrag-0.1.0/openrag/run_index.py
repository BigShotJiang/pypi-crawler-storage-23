"""CLI entry point for OpenRAG document indexing.

Usage::

    python -m openrag.run_index path/to/doc.pdf [path/to/doc2.xlsx ...]
        --text-backend    sqlite|postgres|mysql|mongodb  (default: sqlite)
        --embedding-model all-MiniLM-L6-v2              (any sentence-transformers model)
        --device          cpu|cuda|mps                   (default: cpu)
        --faiss-path      ./openrag.faiss
        --bm25-path       ./openrag_bm25.sqlite          (SQLite only)
        --no-overwrite                                   (incremental; default: overwrite)
        --verbose                                        (progress bars)
        --json                                           (print result as JSON)
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m openrag.run_index",
        description="Index one or more documents into the OpenRAG BM25 + FAISS stores.",
    )
    p.add_argument("files", nargs="+", metavar="FILE", help="Document file(s) to index.")
    p.add_argument("--text-backend", default=None,
                   choices=["sqlite", "postgres", "mysql", "mongodb"],
                   help="Text search backend (default: sqlite).")
    p.add_argument("--embedding-model", default=None,
                   help="sentence-transformers model name (default: all-MiniLM-L6-v2).")
    p.add_argument("--device", default=None, choices=["cpu", "cuda", "mps"],
                   help="Compute device for embeddings (default: cpu).")
    p.add_argument("--faiss-path", default=None, help="Path for FAISS binary index file.")
    p.add_argument("--faiss-meta-path", default=None, help="Path for FAISS JSON sidecar.")
    p.add_argument("--bm25-path", default=None,
                   help="SQLite BM25 database path (SQLite backend only).")
    p.add_argument("--postgres-host", default=None)
    p.add_argument("--postgres-port", type=int, default=None)
    p.add_argument("--postgres-db", default=None)
    p.add_argument("--postgres-user", default=None)
    p.add_argument("--postgres-password", default=None)
    p.add_argument("--mysql-host", default=None)
    p.add_argument("--mysql-port", type=int, default=None)
    p.add_argument("--mysql-db", default=None)
    p.add_argument("--mysql-user", default=None)
    p.add_argument("--mysql-password", default=None)
    p.add_argument("--no-overwrite", action="store_true",
                   help="Incremental mode — append chunks without removing old data.")
    p.add_argument("--verbose", "-v", action="store_true",
                   help="Show progress bars during embedding.")
    p.add_argument("--json", action="store_true",
                   help="Print indexing summary as JSON instead of human-readable text.")
    return p


def main(argv: list | None = None) -> None:
    args = _build_parser().parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )

    from openrag.config import openrag_config_from_env
    cfg = openrag_config_from_env()

    # Apply CLI overrides
    if args.text_backend:
        cfg.text_backend = args.text_backend  # type: ignore[assignment]
    if args.embedding_model:
        cfg.embedding_model = args.embedding_model
    if args.device:
        cfg.embedding_device = args.device
    if args.faiss_path:
        cfg.faiss_index_path = args.faiss_path
    if args.faiss_meta_path:
        cfg.faiss_metadata_path = args.faiss_meta_path
    if args.bm25_path:
        cfg.sqlite_bm25_path = args.bm25_path
    if args.postgres_host:
        cfg.postgres_host = args.postgres_host
    if args.postgres_port:
        cfg.postgres_port = args.postgres_port
    if args.postgres_db:
        cfg.postgres_db = args.postgres_db
    if args.postgres_user:
        cfg.postgres_user = args.postgres_user
    if args.postgres_password:
        cfg.postgres_password = args.postgres_password
    if args.mysql_host:
        cfg.mysql_host = args.mysql_host
    if args.mysql_port:
        cfg.mysql_port = args.mysql_port
    if args.mysql_db:
        cfg.mysql_db = args.mysql_db
    if args.mysql_user:
        cfg.mysql_user = args.mysql_user
    if args.mysql_password:
        cfg.mysql_password = args.mysql_password
    if args.no_overwrite:
        cfg.overwrite_on_reindex = False
    cfg.show_progress = args.verbose

    from openrag.indexer import OpenRAGIndexer
    indexer = OpenRAGIndexer(cfg)

    all_results = []
    for file_path in args.files:
        t0 = time.perf_counter()
        try:
            result = indexer.index_file(file_path)
        except Exception as exc:
            result = {"file": file_path, "error": str(exc)}
            if not args.json:
                print(f"[ERROR] {file_path}: {exc}", file=sys.stderr)
        result["elapsed_s"] = round(time.perf_counter() - t0, 2)
        all_results.append(result)

    if args.json:
        print(json.dumps(all_results, indent=2))
    else:
        for r in all_results:
            if "error" in r:
                print(f"\n[OpenRAG Indexer] FAILED: {r.get('file', '?')}")
                print(f"  Error: {r['error']}")
            else:
                print(f"\n[OpenRAG Indexer]")
                print(f"  File            : {r.get('file_name', '?')}")
                print(f"  Doc ID          : {r.get('doc_id', '?')}")
                print(f"  Chunks indexed  : {r.get('chunks_indexed', 0)}")
                print(f"  Text backend    : {r.get('text_backend', '?')}")
                print(f"  Embedding model : {r.get('embedding_model', '?')}")
                print(f"  Embedding dim   : {r.get('embedding_dim', '?')}")
                print(f"  Done in         : {r.get('elapsed_s', '?')}s")
                if r.get("warning"):
                    print(f"  Warning         : {r['warning']}")


if __name__ == "__main__":
    main()
