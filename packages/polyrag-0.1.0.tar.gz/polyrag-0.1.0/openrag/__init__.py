"""OpenRAG — open-source BM25 + FAISS retrieval for doc_pros.

Public API::

    from openrag import OpenRAGConfig, OpenRAGIndexer, OpenRAGRetriever, ChunkRecord

Quick start::

    from openrag import OpenRAGConfig, OpenRAGIndexer, OpenRAGRetriever

    cfg = OpenRAGConfig(text_backend="sqlite", embedding_model="all-MiniLM-L6-v2")
    OpenRAGIndexer(cfg).index_file("report.pdf")
    results = OpenRAGRetriever(cfg).retrieve("invoice total", top_k=5)
"""

from openrag.config import OpenRAGConfig, openrag_config_from_env
from openrag.indexer import OpenRAGIndexer
from openrag.retriever import OpenRAGRetriever
from openrag.schemas import ChunkRecord

__all__ = [
    "OpenRAGConfig",
    "openrag_config_from_env",
    "OpenRAGIndexer",
    "OpenRAGRetriever",
    "ChunkRecord",
]
