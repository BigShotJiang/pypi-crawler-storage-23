"""MySQLTextStore — BM25 inverted index in MySQL.

Same schema as the other backends (postings, doc_len, term_stats, meta)
via mysql-connector-python.
"""

from __future__ import annotations

import heapq
import logging
import math
from collections import Counter, defaultdict
from typing import List, Optional, Tuple

from openrag.schemas import ChunkRecord
from openrag.stores.base import TextStore
from openrag.text.tokenize import tokenize

logger = logging.getLogger(__name__)


class MySQLTextStore(TextStore):
    """BM25 text store backed by MySQL.

    Args:
        host, port, db, user, password: Connection parameters.
        table_prefix: All four tables are prefixed with this string.
        k1, b: BM25 parameters.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 3306,
        db: str = "openrag",
        user: str = "root",
        password: str = "",
        table_prefix: str = "openrag_bm25",
        k1: float = 1.2,
        b: float = 0.75,
    ) -> None:
        self._host = host
        self._port = port
        self._db = db
        self._user = user
        self._password = password
        self._p = table_prefix
        self.k1 = k1
        self.b = b
        self._init_schema()

    def _connect(self):
        try:
            import mysql.connector
        except ImportError as exc:
            raise ImportError(
                "mysql-connector-python is required for MySQLTextStore. "
                "pip install mysql-connector-python"
            ) from exc
        return mysql.connector.connect(
            host=self._host, port=self._port, database=self._db,
            user=self._user, password=self._password,
        )

    def _init_schema(self) -> None:
        p = self._p
        with self._connect() as con:
            cur = con.cursor()
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {p}_postings (
                    term     VARCHAR(255) NOT NULL,
                    chunk_id VARCHAR(64)  NOT NULL,
                    tf       INT          NOT NULL,
                    PRIMARY KEY (term, chunk_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {p}_doc_len (
                    chunk_id VARCHAR(64) PRIMARY KEY,
                    len      INT         NOT NULL,
                    doc_id   VARCHAR(64) NOT NULL,
                    INDEX idx_doc_id (doc_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {p}_term_stats (
                    term VARCHAR(255) PRIMARY KEY,
                    df   INT         NOT NULL,
                    idf  DOUBLE      NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {p}_meta (
                    `key`   VARCHAR(64) PRIMARY KEY,
                    `value` DOUBLE      NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute(
                f"INSERT IGNORE INTO {p}_meta(`key`,`value`) VALUES ('N',0),('avgdl',0)"
            )
            cur.execute(f"CREATE INDEX IF NOT EXISTS idx_{p}_post_chunk ON {p}_postings(chunk_id)")
            con.commit()

    def _get_meta(self, cur, key: str) -> float:
        cur.execute(f"SELECT `value` FROM {self._p}_meta WHERE `key`=%s", (key,))
        row = cur.fetchone()
        return float(row[0]) if row else 0.0

    def _set_meta(self, cur, key: str, value: float) -> None:
        cur.execute(
            f"INSERT INTO {self._p}_meta(`key`,`value`) VALUES (%s,%s) "
            f"ON DUPLICATE KEY UPDATE `value`=%s",
            (key, float(value), float(value)),
        )

    def index_chunks(self, chunks: List[ChunkRecord]) -> None:
        if not chunks:
            return
        p = self._p
        with self._connect() as con:
            cur = con.cursor()

            # Check for existing chunks (upsert via delete+insert)
            fmt = ",".join(["%s"] * len(chunks))
            cur.execute(f"SELECT chunk_id FROM {p}_doc_len WHERE chunk_id IN ({fmt})",
                        [c.chunk_id for c in chunks])
            existing = [row[0] for row in cur.fetchall()]
            if existing:
                self._remove_chunks(cur, existing)

            N = self._get_meta(cur, "N")
            total_len = N * self._get_meta(cur, "avgdl")

            for chunk in chunks:
                tokens = tokenize(chunk.text)
                dl = len(tokens)
                cur.execute(
                    f"INSERT INTO {p}_doc_len(chunk_id, len, doc_id) VALUES (%s,%s,%s)",
                    (chunk.chunk_id, dl, chunk.doc_id),
                )
                N += 1
                total_len += dl

                tf = Counter(tokens)
                cur.executemany(
                    f"INSERT INTO {p}_postings(term, chunk_id, tf) VALUES (%s,%s,%s) "
                    f"ON DUPLICATE KEY UPDATE tf=VALUES(tf)",
                    [(term, chunk.chunk_id, count) for term, count in tf.items()],
                )
                self._update_idf_for_terms(cur, list(tf.keys()), N)

            avgdl = total_len / N if N else 0.0
            self._set_meta(cur, "N", N)
            self._set_meta(cur, "avgdl", avgdl)
            con.commit()
        logger.debug("MySQLTextStore: indexed %d chunks (N=%d)", len(chunks), int(N))

    def search(
        self,
        query: str,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        p = self._p
        with self._connect() as con:
            cur = con.cursor()
            N = self._get_meta(cur, "N")
            if N == 0:
                return []
            avgdl = self._get_meta(cur, "avgdl")
            q_terms = list(dict.fromkeys(tokenize(query)))
            scores: defaultdict = defaultdict(float)

            for term in q_terms:
                cur.execute(f"SELECT idf FROM {p}_term_stats WHERE term=%s", (term,))
                row = cur.fetchone()
                if row is None:
                    continue
                idf = float(row[0])

                if doc_id_filter:
                    cur.execute(
                        f"""SELECT p.chunk_id, p.tf, d.len
                            FROM {p}_postings p
                            JOIN {p}_doc_len d ON d.chunk_id = p.chunk_id
                            WHERE p.term=%s AND d.doc_id=%s""",
                        (term, doc_id_filter),
                    )
                else:
                    cur.execute(
                        f"""SELECT p.chunk_id, p.tf, d.len
                            FROM {p}_postings p
                            JOIN {p}_doc_len d ON d.chunk_id = p.chunk_id
                            WHERE p.term=%s""",
                        (term,),
                    )

                for chunk_id, tf, dl in cur.fetchall():
                    denom = tf + self.k1 * (1.0 - self.b + self.b * (dl / avgdl))
                    scores[chunk_id] += idf * (tf * (self.k1 + 1.0) / denom)

        return heapq.nlargest(top_k, scores.items(), key=lambda x: x[1])

    def delete_by_doc_id(self, doc_id: str) -> int:
        p = self._p
        with self._connect() as con:
            cur = con.cursor()
            cur.execute(f"SELECT chunk_id FROM {p}_doc_len WHERE doc_id=%s", (doc_id,))
            chunk_ids = [row[0] for row in cur.fetchall()]
            if not chunk_ids:
                return 0
            count = self._remove_chunks(cur, chunk_ids)
            con.commit()
        return count

    def chunk_count(self) -> int:
        with self._connect() as con:
            cur = con.cursor()
            return int(self._get_meta(cur, "N"))

    def _remove_chunks(self, cur, chunk_ids: List[str]) -> int:
        p = self._p
        fmt = ",".join(["%s"] * len(chunk_ids))

        cur.execute(f"SELECT DISTINCT term FROM {p}_postings WHERE chunk_id IN ({fmt})", chunk_ids)
        affected_terms = [row[0] for row in cur.fetchall()]

        cur.execute(f"SELECT SUM(len) FROM {p}_doc_len WHERE chunk_id IN ({fmt})", chunk_ids)
        removed_len = cur.fetchone()[0] or 0
        count = len(chunk_ids)

        cur.execute(f"DELETE FROM {p}_postings WHERE chunk_id IN ({fmt})", chunk_ids)
        cur.execute(f"DELETE FROM {p}_doc_len WHERE chunk_id IN ({fmt})", chunk_ids)

        N = max(0.0, self._get_meta(cur, "N") - count)
        old_avgdl = self._get_meta(cur, "avgdl")
        total_len = max(0.0, old_avgdl * (N + count) - removed_len)
        avgdl = total_len / N if N else 0.0
        self._set_meta(cur, "N", N)
        self._set_meta(cur, "avgdl", avgdl)

        if affected_terms and N > 0:
            self._update_idf_for_terms(cur, affected_terms, N)
        elif affected_terms:
            ph2 = ",".join(["%s"] * len(affected_terms))
            cur.execute(f"DELETE FROM {p}_term_stats WHERE term IN ({ph2})", affected_terms)

        return count

    def _update_idf_for_terms(self, cur, terms: List[str], N: float) -> None:
        p = self._p
        fmt = ",".join(["%s"] * len(terms))
        cur.execute(
            f"SELECT term, COUNT(*) FROM {p}_postings WHERE term IN ({fmt}) GROUP BY term",
            terms,
        )
        df_rows = cur.fetchall()
        if not df_rows:
            return
        updates = [
            (term, int(df), float(math.log10(((N - df + 0.5) / (df + 0.5)) + 1.0)), int(df), float(math.log10(((N - df + 0.5) / (df + 0.5)) + 1.0)))
            for term, df in df_rows
        ]
        cur.executemany(
            f"INSERT INTO {p}_term_stats(term,df,idf) VALUES (%s,%s,%s) "
            f"ON DUPLICATE KEY UPDATE df=%s, idf=%s",
            updates,
        )
        terms_with_postings = {row[0] for row in df_rows}
        orphans = [t for t in terms if t not in terms_with_postings]
        if orphans:
            ph2 = ",".join(["%s"] * len(orphans))
            cur.execute(f"DELETE FROM {p}_term_stats WHERE term IN ({ph2})", orphans)
