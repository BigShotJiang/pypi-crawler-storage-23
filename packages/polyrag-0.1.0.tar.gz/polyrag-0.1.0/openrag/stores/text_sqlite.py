"""SQLiteTextStore — BM25 inverted index stored in SQLite.

Schema: postings, doc_len, term_stats, meta — with TEXT chunk_id as the
primary key instead of a sequential integer doc_id, enabling true
incremental ingestion.

Tokenization is provided by ``openrag.text.tokenize.tokenize``, which
guarantees identical tokenization across all text-store backends.
"""

from __future__ import annotations

import heapq
import logging
import math
import sqlite3
from collections import Counter, defaultdict
from typing import List, Optional, Tuple

from openrag.schemas import ChunkRecord
from openrag.stores.base import TextStore

from openrag.text.tokenize import tokenize

logger = logging.getLogger(__name__)

_INIT_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA temp_store=MEMORY;

CREATE TABLE IF NOT EXISTS postings (
    term     TEXT NOT NULL,
    chunk_id TEXT NOT NULL,
    tf       INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS doc_len (
    chunk_id TEXT PRIMARY KEY,
    len      INTEGER NOT NULL,
    doc_id   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS term_stats (
    term TEXT PRIMARY KEY,
    df   INTEGER NOT NULL,
    idf  REAL    NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_postings_term     ON postings(term);
CREATE INDEX IF NOT EXISTS idx_postings_chunk    ON postings(chunk_id);
CREATE INDEX IF NOT EXISTS idx_postings_term_chunk ON postings(term, chunk_id);
CREATE INDEX IF NOT EXISTS idx_doc_len_doc_id    ON doc_len(doc_id);
"""


class SQLiteTextStore(TextStore):
    """BM25 text store backed by SQLite.

    Supports true incremental ingestion: each new chunk updates only the
    postings, doc_len, and term_stats rows it affects, without rebuilding
    the whole index.
    """

    def __init__(self, db_path: str, k1: float = 1.2, b: float = 0.75) -> None:
        self.db_path = db_path
        self.k1 = k1
        self.b = b
        self._init_db()

    # ── DB helpers ────────────────────────────────────────────────────────────

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._connect() as con:
            con.executescript(_INIT_SQL)
            # Seed meta if empty
            con.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('N', 0)")
            con.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('avgdl', 0)")
            con.commit()

    def _get_meta(self, con: sqlite3.Connection, key: str) -> float:
        row = con.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return float(row[0]) if row else 0.0

    def _set_meta(self, con: sqlite3.Connection, key: str, value: float) -> None:
        con.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?,?)", (key, float(value)))

    # ── TextStore interface ───────────────────────────────────────────────────

    def index_chunks(self, chunks: List[ChunkRecord]) -> None:
        if not chunks:
            return
        with self._connect() as con:
            # Remove existing chunks (upsert: delete then re-insert)
            existing_chunk_ids = [
                row[0]
                for row in con.execute(
                    f"SELECT chunk_id FROM doc_len WHERE chunk_id IN ({','.join('?'*len(chunks))})",
                    [c.chunk_id for c in chunks],
                ).fetchall()
            ]
            if existing_chunk_ids:
                self._remove_chunks(con, existing_chunk_ids)

            N = self._get_meta(con, "N")
            total_len = N * self._get_meta(con, "avgdl")

            # Insert new chunks
            for chunk in chunks:
                tokens = tokenize(chunk.text)
                dl = len(tokens)
                con.execute(
                    "INSERT INTO doc_len(chunk_id, len, doc_id) VALUES (?,?,?)",
                    (chunk.chunk_id, dl, chunk.doc_id),
                )
                N += 1
                total_len += dl

                tf = Counter(tokens)
                con.executemany(
                    "INSERT INTO postings(term, chunk_id, tf) VALUES (?,?,?)",
                    [(term, chunk.chunk_id, count) for term, count in tf.items()],
                )
                # Update IDF for affected terms
                self._update_idf_for_terms(con, list(tf.keys()), N)

            avgdl = total_len / N if N else 0.0
            self._set_meta(con, "N", N)
            self._set_meta(con, "avgdl", avgdl)
            con.commit()
        logger.debug("SQLiteTextStore: indexed %d chunks (N=%d)", len(chunks), int(N))

    def search(
        self,
        query: str,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        with self._connect() as con:
            N = self._get_meta(con, "N")
            if N == 0:
                return []
            avgdl = self._get_meta(con, "avgdl")
            q_terms = list(dict.fromkeys(tokenize(query)))  # unique, order-preserving
            scores: defaultdict = defaultdict(float)

            for term in q_terms:
                row = con.execute(
                    "SELECT idf FROM term_stats WHERE term=?", (term,)
                ).fetchone()
                if row is None:
                    continue
                idf = float(row[0])

                if doc_id_filter:
                    rows = con.execute(
                        """SELECT p.chunk_id, p.tf, d.len
                           FROM postings p
                           JOIN doc_len d ON d.chunk_id = p.chunk_id
                           WHERE p.term=? AND d.doc_id=?""",
                        (term, doc_id_filter),
                    ).fetchall()
                else:
                    rows = con.execute(
                        """SELECT p.chunk_id, p.tf, d.len
                           FROM postings p
                           JOIN doc_len d ON d.chunk_id = p.chunk_id
                           WHERE p.term=?""",
                        (term,),
                    ).fetchall()

                for chunk_id, tf, dl in rows:
                    denom = tf + self.k1 * (1.0 - self.b + self.b * (dl / avgdl))
                    scores[chunk_id] += idf * (tf * (self.k1 + 1.0) / denom)

        return heapq.nlargest(top_k, scores.items(), key=lambda x: x[1])

    def delete_by_doc_id(self, doc_id: str) -> int:
        with self._connect() as con:
            chunk_ids = [
                row[0]
                for row in con.execute(
                    "SELECT chunk_id FROM doc_len WHERE doc_id=?", (doc_id,)
                ).fetchall()
            ]
            if not chunk_ids:
                return 0
            count = self._remove_chunks(con, chunk_ids)
            con.commit()
        logger.debug("SQLiteTextStore: deleted %d chunks for doc_id=%s", count, doc_id)
        return count

    def chunk_count(self) -> int:
        with self._connect() as con:
            row = con.execute("SELECT value FROM meta WHERE key='N'").fetchone()
            return int(row[0]) if row else 0

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _remove_chunks(self, con: sqlite3.Connection, chunk_ids: List[str]) -> int:
        """Remove chunks from postings/doc_len, update N/avgdl/IDF. Returns count."""
        placeholders = ",".join("?" * len(chunk_ids))

        # Collect affected terms before deleting postings
        affected_terms = [
            row[0]
            for row in con.execute(
                f"SELECT DISTINCT term FROM postings WHERE chunk_id IN ({placeholders})",
                chunk_ids,
            ).fetchall()
        ]

        # Collect lengths of deleted chunks for avgdl update
        len_rows = con.execute(
            f"SELECT len FROM doc_len WHERE chunk_id IN ({placeholders})", chunk_ids
        ).fetchall()
        removed_total_len = sum(r[0] for r in len_rows)
        count = len(len_rows)

        con.execute(f"DELETE FROM postings WHERE chunk_id IN ({placeholders})", chunk_ids)
        con.execute(f"DELETE FROM doc_len WHERE chunk_id IN ({placeholders})", chunk_ids)

        N = max(0.0, self._get_meta(con, "N") - count)
        old_avgdl = self._get_meta(con, "avgdl")
        total_len = max(0.0, old_avgdl * (N + count) - removed_total_len)
        avgdl = total_len / N if N else 0.0
        self._set_meta(con, "N", N)
        self._set_meta(con, "avgdl", avgdl)

        # Refresh IDF for affected terms (or delete if df drops to 0)
        if affected_terms and N > 0:
            self._update_idf_for_terms(con, affected_terms, N)
        elif affected_terms:
            placeholders2 = ",".join("?" * len(affected_terms))
            con.execute(f"DELETE FROM term_stats WHERE term IN ({placeholders2})", affected_terms)

        return count

    def _update_idf_for_terms(
        self, con: sqlite3.Connection, terms: List[str], N: float
    ) -> None:
        """Recompute df and IDF only for the given terms."""
        placeholders = ",".join("?" * len(terms))
        df_rows = con.execute(
            f"SELECT term, COUNT(*) FROM postings WHERE term IN ({placeholders}) GROUP BY term",
            terms,
        ).fetchall()

        updates = []
        for term, df in df_rows:
            idf = math.log10(((N - df + 0.5) / (df + 0.5)) + 1.0)
            updates.append((term, int(df), float(idf)))

        if updates:
            con.executemany(
                "INSERT OR REPLACE INTO term_stats(term, df, idf) VALUES (?,?,?)", updates
            )

        # Terms that now have df=0 (no postings left) should be removed
        terms_with_postings = {row[0] for row in df_rows}
        terms_without_postings = [t for t in terms if t not in terms_with_postings]
        if terms_without_postings:
            ph2 = ",".join("?" * len(terms_without_postings))
            con.execute(f"DELETE FROM term_stats WHERE term IN ({ph2})", terms_without_postings)
