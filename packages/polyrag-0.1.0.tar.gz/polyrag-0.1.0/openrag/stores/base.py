"""Abstract base classes for OpenRAG stores — mirrors structured_data/storage/base.py pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

import numpy as np

from openrag.schemas import ChunkRecord


class TextStore(ABC):
    """Abstract interface for BM25 keyword-search backends.

    All implementations must be idempotent: calling ``index_chunks()`` twice
    with the same ``chunk_id`` must not duplicate entries (upsert semantics).

    The BM25 inverted index schema is identical across all backends::

        postings    (term TEXT, chunk_id TEXT, tf INTEGER)
        doc_len     (chunk_id TEXT PK, len INTEGER, doc_id TEXT)
        term_stats  (term TEXT PK, df INTEGER, idf REAL)
        meta        (key TEXT PK, value REAL)    -- keys: N, avgdl

    TF is computed at ingestion (Counter(tokens)). IDF is updated incrementally
    for only the terms present in each new document — not a full table scan.
    """

    @abstractmethod
    def index_chunks(self, chunks: List[ChunkRecord]) -> None:
        """Insert or update chunks in the BM25 inverted index.

        Implementations tokenize the chunk text, compute TF, insert postings,
        update doc_len, increment meta.N, recompute avgdl, and refresh IDF
        for affected terms only.
        """

    @abstractmethod
    def search(
        self,
        query: str,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        """Return BM25-ranked ``(chunk_id, score)`` pairs, descending by score.

        Args:
            query: Raw query string (tokenized internally).
            top_k: Maximum number of results.
            doc_id_filter: If set, restrict results to chunks from this document.
        """

    @abstractmethod
    def delete_by_doc_id(self, doc_id: str) -> int:
        """Delete all chunks belonging to ``doc_id`` from the BM25 index.

        Removes postings rows, doc_len rows, decrements meta.N, updates
        avgdl, and refreshes IDF for affected terms.

        Returns:
            Number of chunks deleted.
        """

    @abstractmethod
    def chunk_count(self) -> int:
        """Return the total number of indexed chunks (rows in doc_len)."""


class VectorStore(ABC):
    """Abstract interface for FAISS-backed dense vector search.

    The concrete implementation (FAISSVectorStore) uses IndexHNSWFlat plus
    a JSON sidecar file to store chunk metadata alongside binary vectors.
    """

    @abstractmethod
    def index_chunks(self, chunks: List[ChunkRecord], embeddings: np.ndarray) -> None:
        """Add chunks and their pre-computed embeddings to the vector index.

        Args:
            chunks: ChunkRecord list.
            embeddings: float32 ndarray of shape ``(len(chunks), dim)``.
        """

    @abstractmethod
    def search(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        """Return ``(chunk_id, l2_distance)`` pairs, ascending by distance.

        Args:
            query_embedding: 1-D float32 array of shape ``(dim,)``.
            top_k: Maximum number of results.
            doc_id_filter: Restrict to chunks from a single document.
        """

    @abstractmethod
    def delete_by_doc_id(self, doc_id: str) -> int:
        """Logically delete all chunks belonging to ``doc_id``.

        FAISS IndexHNSWFlat has no physical remove; entries are marked
        ``deleted=True`` in the metadata sidecar and filtered at query time.

        Returns:
            Number of chunks marked deleted.
        """

    @abstractmethod
    def save(self) -> None:
        """Persist the binary FAISS index and JSON sidecar to disk."""

    @abstractmethod
    def load(self) -> None:
        """Load the binary FAISS index and JSON sidecar from disk."""
