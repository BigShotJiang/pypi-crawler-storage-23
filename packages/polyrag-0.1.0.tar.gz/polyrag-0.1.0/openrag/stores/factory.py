"""Factory function for TextStore backends."""

from __future__ import annotations

from openrag.config import OpenRAGConfig
from openrag.stores.base import TextStore


def get_text_store(config: OpenRAGConfig) -> TextStore:
    """Return the appropriate TextStore implementation based on config.text_backend.

    Args:
        config: OpenRAGConfig with backend selection and connection parameters.

    Returns:
        A ready-to-use TextStore instance.

    Raises:
        ValueError: If config.text_backend is not one of the supported values.
    """
    backend = config.text_backend

    if backend == "sqlite":
        from openrag.stores.text_sqlite import SQLiteTextStore
        return SQLiteTextStore(
            db_path=config.sqlite_bm25_path,
            k1=config.bm25_k1,
            b=config.bm25_b,
        )

    if backend == "postgres":
        from openrag.stores.text_postgres import PostgresTextStore
        return PostgresTextStore(
            host=config.postgres_host,
            port=config.postgres_port,
            db=config.postgres_db,
            user=config.postgres_user,
            password=config.postgres_password,
            table_prefix=config.postgres_table,
            k1=config.bm25_k1,
            b=config.bm25_b,
        )

    if backend == "mysql":
        from openrag.stores.text_mysql import MySQLTextStore
        return MySQLTextStore(
            host=config.mysql_host,
            port=config.mysql_port,
            db=config.mysql_db,
            user=config.mysql_user,
            password=config.mysql_password,
            table_prefix=config.mysql_table,
            k1=config.bm25_k1,
            b=config.bm25_b,
        )

    if backend == "mongodb":
        from openrag.stores.text_mongodb import MongoDBTextStore
        return MongoDBTextStore(
            connection_string=config.mongodb_connection_string,
            host=config.mongodb_host,
            port=config.mongodb_port,
            database=config.mongodb_database,
            username=config.mongodb_username,
            password=config.mongodb_password,
            collection_prefix=config.mongodb_collection_prefix,
            k1=config.bm25_k1,
            b=config.bm25_b,
        )

    raise ValueError(
        f"Unknown text_backend: {backend!r}. "
        f"Valid options: 'sqlite', 'postgres', 'mysql', 'mongodb'."
    )
