"""FAISSVectorStore — IndexHNSWFlat with JSON metadata sidecar.

Storage layout::

    openrag.faiss       <- binary FAISS index (vectors only)
    openrag_meta.json   <- JSON sidecar: model info + chunk metadata array

The sidecar ``entries`` list is positionally aligned with FAISS integer IDs:
``entries[i]`` corresponds to FAISS internal ID ``i``. The list is append-only.
Deletion is logical: ``entries[i]["deleted"] = True``; physical compaction is
available via ``compact()``.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from openrag.embedding.base import EmbeddingProvider
from openrag.schemas import ChunkRecord
from openrag.stores.base import VectorStore

logger = logging.getLogger(__name__)


class DimensionMismatchError(RuntimeError):
    """Raised when the loaded index was built with a different embedding dim."""


class FAISSVectorStore(VectorStore):
    """FAISS IndexHNSWFlat vector store with JSON metadata sidecar.

    Args:
        index_path: Path for the binary ``.faiss`` index file.
        metadata_path: Path for the ``.json`` sidecar file.
        embedding_provider: Provider used to determine embedding dimension.
        hnsw_m: HNSW connectivity parameter (number of neighbours per vertex).
        ef_construction: Build-time search size.
        ef_search: Query-time search size.
    """

    def __init__(
        self,
        index_path: str,
        metadata_path: str,
        embedding_provider: EmbeddingProvider,
        hnsw_m: int = 32,
        ef_construction: int = 200,
        ef_search: int = 64,
    ) -> None:
        self.index_path = index_path
        self.metadata_path = metadata_path
        self._provider = embedding_provider
        self._hnsw_m = hnsw_m
        self._ef_construction = ef_construction
        self._ef_search = ef_search

        self._index = None                          # faiss.IndexHNSWFlat, lazy
        self._entries: List[dict] = []              # sidecar metadata list
        self._chunk_id_to_entry: Dict[str, dict] = {}  # O(1) lookup by chunk_id
        self._deleted_faiss_ids: set = set()        # faiss int IDs marked deleted
        self._dirty: bool = False

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _build_new_index(self):
        import faiss
        d = self._provider.dim
        index = faiss.IndexHNSWFlat(d, self._hnsw_m)
        index.hnsw.efConstruction = self._ef_construction
        index.hnsw.efSearch = self._ef_search
        logger.info("Created new FAISS IndexHNSWFlat: dim=%d, m=%d", d, self._hnsw_m)
        return index

    def _ensure_index(self) -> None:
        """Load from disk if both files exist, otherwise create a fresh index."""
        if self._index is not None:
            return
        if os.path.exists(self.index_path) and os.path.exists(self.metadata_path):
            self.load()
        else:
            self._index = self._build_new_index()
            self._entries = []
            self._chunk_id_to_entry = {}
            self._deleted_faiss_ids = set()

    def _rebuild_lookup(self) -> None:
        self._chunk_id_to_entry = {
            e["chunk_id"]: e for e in self._entries if not e.get("deleted", False)
        }

    # ── VectorStore interface ─────────────────────────────────────────────────

    def index_chunks(self, chunks: List[ChunkRecord], embeddings: np.ndarray) -> None:
        """Append chunks and their embeddings to the FAISS index."""
        if not chunks:
            return
        self._ensure_index()

        start_id = len(self._entries)
        for i, chunk in enumerate(chunks):
            entry = {
                "faiss_id": start_id + i,
                "deleted": False,
                **chunk.to_dict(),
            }
            self._entries.append(entry)
            self._chunk_id_to_entry[chunk.chunk_id] = entry

        self._index.hnsw.efConstruction = self._ef_construction
        self._index.add(embeddings.astype(np.float32))
        self._dirty = True
        logger.debug("Indexed %d chunks into FAISS (total entries: %d)", len(chunks), len(self._entries))

    def search(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        """Search for nearest neighbours, filtering deleted/doc entries."""
        self._ensure_index()
        if not self._entries:
            return []

        # Over-fetch to compensate for deleted entries
        active_count = len(self._entries) - len(self._deleted_faiss_ids)
        if active_count == 0:
            return []

        fetch_k = min(top_k * 4 + len(self._deleted_faiss_ids), len(self._entries))
        fetch_k = max(fetch_k, top_k)

        self._index.hnsw.efSearch = self._ef_search
        D, I = self._index.search(query_embedding.reshape(1, -1).astype(np.float32), fetch_k)

        results: List[Tuple[str, float]] = []
        for dist, faiss_id in zip(D[0], I[0]):
            if faiss_id < 0:  # FAISS pads with -1 when index is smaller than fetch_k
                continue
            entry = self._entries[faiss_id]
            if entry.get("deleted", False):
                continue
            if doc_id_filter and entry["doc_id"] != doc_id_filter:
                continue
            results.append((entry["chunk_id"], float(dist)))
            if len(results) >= top_k:
                break

        return results

    def delete_by_doc_id(self, doc_id: str) -> int:
        """Logically mark all chunks from ``doc_id`` as deleted."""
        self._ensure_index()
        count = 0
        for entry in self._entries:
            if entry["doc_id"] == doc_id and not entry.get("deleted", False):
                entry["deleted"] = True
                self._deleted_faiss_ids.add(entry["faiss_id"])
                self._chunk_id_to_entry.pop(entry["chunk_id"], None)
                count += 1
        if count:
            self._dirty = True
            logger.debug("Logically deleted %d FAISS entries for doc_id=%s", count, doc_id)
        return count

    def save(self) -> None:
        """Persist binary index + JSON sidecar to disk."""
        import faiss
        self._ensure_index()
        faiss.write_index(self._index, self.index_path)
        meta = {
            "embedding_model": self._provider.model_name,
            "dim": self._provider.dim,
            "entries": self._entries,
        }
        with open(self.metadata_path, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False)
        self._dirty = False
        logger.info(
            "Saved FAISS index (%d entries, %d deleted) to %s",
            len(self._entries),
            len(self._deleted_faiss_ids),
            self.index_path,
        )

    def load(self) -> None:
        """Load binary index + JSON sidecar from disk."""
        import faiss
        self._index = faiss.read_index(self.index_path)
        self._index.hnsw.efSearch = self._ef_search

        with open(self.metadata_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

        stored_dim = meta.get("dim")
        current_dim = self._provider.dim
        if stored_dim is not None and stored_dim != current_dim:
            raise DimensionMismatchError(
                f"FAISS index was built with model '{meta.get('embedding_model')}' "
                f"(dim={stored_dim}), but the current embedding provider is "
                f"'{self._provider.model_name}' (dim={current_dim}). "
                f"Delete '{self.index_path}' and '{self.metadata_path}' then re-index."
            )

        self._entries = meta.get("entries", [])
        self._deleted_faiss_ids = {e["faiss_id"] for e in self._entries if e.get("deleted", False)}
        self._rebuild_lookup()
        logger.info(
            "Loaded FAISS index: %d entries, %d deleted, model=%s",
            len(self._entries),
            len(self._deleted_faiss_ids),
            meta.get("embedding_model"),
        )

    # ── Extra utilities ───────────────────────────────────────────────────────

    def compact(self) -> None:
        """Rebuild the FAISS index from scratch, removing logically-deleted vectors.

        This reclaims disk/memory space occupied by deleted entries. After
        compaction, the binary index and sidecar are saved automatically.

        Warning: This is an expensive O(n) operation. Call it explicitly when
        the proportion of deleted entries is high, not automatically.
        """
        import faiss as faiss_lib

        self._ensure_index()
        live_entries = [e for e in self._entries if not e.get("deleted", False)]
        if not live_entries:
            self._index = self._build_new_index()
            self._entries = []
            self._chunk_id_to_entry = {}
            self._deleted_faiss_ids = set()
            self.save()
            return

        # Collect live vectors from old index
        dim = self._provider.dim
        live_vectors = np.zeros((len(live_entries), dim), dtype=np.float32)
        for new_idx, entry in enumerate(live_entries):
            old_id = entry["faiss_id"]
            # reconstruct() is available on IndexHNSWFlat
            self._index.reconstruct(old_id, live_vectors[new_idx])

        # Rebuild
        new_index = self._build_new_index()
        new_index.add(live_vectors)

        # Re-assign faiss_ids sequentially
        for new_idx, entry in enumerate(live_entries):
            entry["faiss_id"] = new_idx

        self._index = new_index
        self._entries = live_entries
        self._deleted_faiss_ids = set()
        self._rebuild_lookup()
        self._dirty = True
        self.save()
        logger.info("Compacted FAISS index: %d live entries retained", len(live_entries))

    def get_chunk(self, chunk_id: str) -> Optional[dict]:
        """Return the sidecar metadata dict for a chunk_id, or None."""
        return self._chunk_id_to_entry.get(chunk_id)

    @property
    def total_entries(self) -> int:
        return len(self._entries)

    @property
    def live_entries(self) -> int:
        return len(self._entries) - len(self._deleted_faiss_ids)
