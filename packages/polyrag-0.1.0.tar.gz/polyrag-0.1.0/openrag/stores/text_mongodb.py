"""MongoDBTextStore — BM25 inverted index in MongoDB collections.

Uses four collections mirroring the SQL schema:
  <prefix>_postings   : {term, chunk_id, tf}
  <prefix>_doc_len    : {chunk_id, len, doc_id}
  <prefix>_term_stats : {term, df, idf}
  <prefix>_meta       : {key, value}

Wraps the existing MongoDBConnector from connectors/mongodb_connector.py.
Uses _ensure_connection() to get the pymongo Database object for cross-collection
operations (aggregations, multi-collection reads).
"""

from __future__ import annotations

import heapq
import logging
import math
from collections import Counter, defaultdict
from typing import List, Optional, Tuple

from openrag.schemas import ChunkRecord
from openrag.stores.base import TextStore
from openrag.text.tokenize import tokenize
from connectors.mongodb_connector import MongoDBConnector

logger = logging.getLogger(__name__)


class MongoDBTextStore(TextStore):
    """BM25 text store backed by MongoDB.

    Uses four collections with the same BM25 schema as the SQL backends.
    The pymongo Database object is obtained via ``MongoDBConnector._ensure_connection()``
    to allow cross-collection operations (aggregation pipelines, multi-collection reads).

    Args:
        connection_string: MongoDB URI (overrides host/port/user/password).
        host, port, database, username, password: Individual connection params.
        collection_prefix: Collections are named ``<prefix>_postings``, etc.
        k1, b: BM25 parameters.
    """

    def __init__(
        self,
        connection_string: Optional[str] = None,
        host: str = "localhost",
        port: int = 27017,
        database: str = "openrag",
        username: Optional[str] = None,
        password: Optional[str] = None,
        collection_prefix: str = "openrag_bm25",
        k1: float = 1.2,
        b: float = 0.75,
    ) -> None:
        self._connector = MongoDBConnector(
            connection_string=connection_string,
            host=host,
            port=port,
            database=database,
            username=username,
            password=password,
        )
        self._p = collection_prefix
        self.k1 = k1
        self.b = b
        self._db = None  # lazy — populated on first use via _get_db()

    # ── DB access ─────────────────────────────────────────────────────────────

    def _get_db(self):
        """Return the pymongo Database object, connecting lazily."""
        if self._db is None:
            self._db = self._connector._ensure_connection()
        return self._db

    # ── Collection helpers ────────────────────────────────────────────────────

    def _postings(self):
        return self._get_db()[f"{self._p}_postings"]

    def _doc_len(self):
        return self._get_db()[f"{self._p}_doc_len"]

    def _term_stats(self):
        return self._get_db()[f"{self._p}_term_stats"]

    def _meta(self):
        return self._get_db()[f"{self._p}_meta"]

    # ── Initialization ────────────────────────────────────────────────────────

    def _ensure_indexes(self) -> None:
        self._postings().create_index([("term", 1), ("chunk_id", 1)], unique=True)
        self._postings().create_index([("chunk_id", 1)])
        self._postings().create_index([("term", 1)])
        self._doc_len().create_index([("chunk_id", 1)], unique=True)
        self._doc_len().create_index([("doc_id", 1)])
        self._term_stats().create_index([("term", 1)], unique=True)
        self._meta().create_index([("key", 1)], unique=True)
        # Seed meta counters
        self._meta().update_one(
            {"key": "N"}, {"$setOnInsert": {"key": "N", "value": 0.0}}, upsert=True
        )
        self._meta().update_one(
            {"key": "avgdl"}, {"$setOnInsert": {"key": "avgdl", "value": 0.0}}, upsert=True
        )

    def _get_meta(self, key: str) -> float:
        doc = self._meta().find_one({"key": key})
        return float(doc["value"]) if doc else 0.0

    def _set_meta(self, key: str, value: float) -> None:
        self._meta().update_one({"key": key}, {"$set": {"value": float(value)}}, upsert=True)

    # ── TextStore interface ───────────────────────────────────────────────────

    def index_chunks(self, chunks: List[ChunkRecord]) -> None:
        if not chunks:
            return
        self._ensure_indexes()

        # Upsert: remove any existing chunks with same chunk_id first
        existing_ids = [
            doc["chunk_id"]
            for doc in self._doc_len().find(
                {"chunk_id": {"$in": [c.chunk_id for c in chunks]}},
                {"chunk_id": 1},
            )
        ]
        if existing_ids:
            self._remove_chunks(existing_ids)

        N = self._get_meta("N")
        total_len = N * self._get_meta("avgdl")

        for chunk in chunks:
            tokens = tokenize(chunk.text)
            dl = len(tokens)
            self._doc_len().insert_one(
                {"chunk_id": chunk.chunk_id, "len": dl, "doc_id": chunk.doc_id}
            )
            N += 1
            total_len += dl

            tf = Counter(tokens)
            if tf:
                from pymongo import ReplaceOne
                self._postings().bulk_write([
                    ReplaceOne(
                        {"term": term, "chunk_id": chunk.chunk_id},
                        {"term": term, "chunk_id": chunk.chunk_id, "tf": count},
                        upsert=True,
                    )
                    for term, count in tf.items()
                ])
            self._update_idf_for_terms(list(tf.keys()), N)

        avgdl = total_len / N if N else 0.0
        self._set_meta("N", N)
        self._set_meta("avgdl", avgdl)
        logger.debug("MongoDBTextStore: indexed %d chunks (N=%d)", len(chunks), int(N))

    def search(
        self,
        query: str,
        top_k: int = 10,
        doc_id_filter: Optional[str] = None,
    ) -> List[Tuple[str, float]]:
        N = self._get_meta("N")
        if N == 0:
            return []
        avgdl = self._get_meta("avgdl")
        q_terms = list(dict.fromkeys(tokenize(query)))
        scores: defaultdict = defaultdict(float)

        for term in q_terms:
            ts_doc = self._term_stats().find_one({"term": term})
            if ts_doc is None:
                continue
            idf = float(ts_doc["idf"])

            posting_filter: dict = {"term": term}
            if doc_id_filter:
                doc_chunk_ids = [
                    d["chunk_id"]
                    for d in self._doc_len().find(
                        {"doc_id": doc_id_filter}, {"chunk_id": 1}
                    )
                ]
                posting_filter["chunk_id"] = {"$in": doc_chunk_ids}

            for posting in self._postings().find(posting_filter, {"chunk_id": 1, "tf": 1}):
                chunk_id = posting["chunk_id"]
                tf = int(posting["tf"])
                dl_doc = self._doc_len().find_one({"chunk_id": chunk_id}, {"len": 1})
                if dl_doc is None:
                    continue
                dl = int(dl_doc["len"])
                denom = tf + self.k1 * (1.0 - self.b + self.b * (dl / avgdl))
                scores[chunk_id] += idf * (tf * (self.k1 + 1.0) / denom)

        return heapq.nlargest(top_k, scores.items(), key=lambda x: x[1])

    def delete_by_doc_id(self, doc_id: str) -> int:
        chunk_ids = [
            d["chunk_id"]
            for d in self._doc_len().find({"doc_id": doc_id}, {"chunk_id": 1})
        ]
        if not chunk_ids:
            return 0
        return self._remove_chunks(chunk_ids)

    def chunk_count(self) -> int:
        return int(self._get_meta("N"))

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _remove_chunks(self, chunk_ids: List[str]) -> int:
        affected_terms = list({
            d["term"]
            for d in self._postings().find(
                {"chunk_id": {"$in": chunk_ids}}, {"term": 1}
            )
        })
        len_docs = list(
            self._doc_len().find({"chunk_id": {"$in": chunk_ids}}, {"len": 1})
        )
        removed_len = sum(d["len"] for d in len_docs)
        count = len(chunk_ids)

        self._postings().delete_many({"chunk_id": {"$in": chunk_ids}})
        self._doc_len().delete_many({"chunk_id": {"$in": chunk_ids}})

        N = max(0.0, self._get_meta("N") - count)
        old_avgdl = self._get_meta("avgdl")
        total_len = max(0.0, old_avgdl * (N + count) - removed_len)
        avgdl = total_len / N if N else 0.0
        self._set_meta("N", N)
        self._set_meta("avgdl", avgdl)

        if affected_terms and N > 0:
            self._update_idf_for_terms(affected_terms, N)
        elif affected_terms:
            self._term_stats().delete_many({"term": {"$in": affected_terms}})

        return count

    def _update_idf_for_terms(self, terms: List[str], N: float) -> None:
        pipeline = [
            {"$match": {"term": {"$in": terms}}},
            {"$group": {"_id": "$term", "df": {"$sum": 1}}},
        ]
        df_rows = list(self._postings().aggregate(pipeline))
        terms_with_postings = set()

        from pymongo import UpdateOne
        bulk_ops = []
        for row in df_rows:
            term, df = row["_id"], int(row["df"])
            terms_with_postings.add(term)
            idf = math.log10(((N - df + 0.5) / (df + 0.5)) + 1.0)
            bulk_ops.append(UpdateOne(
                {"term": term},
                {"$set": {"term": term, "df": df, "idf": float(idf)}},
                upsert=True,
            ))
        if bulk_ops:
            self._term_stats().bulk_write(bulk_ops)

        orphans = [t for t in terms if t not in terms_with_postings]
        if orphans:
            self._term_stats().delete_many({"term": {"$in": orphans}})
