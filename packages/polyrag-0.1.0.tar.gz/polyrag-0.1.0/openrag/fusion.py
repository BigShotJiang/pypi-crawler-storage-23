"""Reciprocal Rank Fusion (RRF) for combining ranked result lists."""

from __future__ import annotations

from typing import Dict, List, Tuple


def reciprocal_rank_fusion(
    ranked_lists: List[List[Tuple[str, float]]],
    k: int = 60,
    top_k: int = 10,
) -> List[Tuple[str, float]]:
    """Combine multiple ranked lists using Reciprocal Rank Fusion.

    Each input list contains ``(item_id, score)`` tuples sorted by descending
    relevance. The score in the input is **ignored** — only the rank position
    (1-based) matters for RRF.

    Formula::

        RRF_score(d) = Σ_r  1 / (k + rank(d, r))

    Args:
        ranked_lists: One list per retrieval modality (text, vector, …).
        k: RRF constant controlling rank dampening. 60 is the standard default
           (Cormack et al., 2009).
        top_k: Number of results to return.

    Returns:
        ``[(item_id, rrf_score), ...]`` sorted descending by RRF score,
        truncated to ``top_k``.
    """
    scores: Dict[str, float] = {}

    for ranked_list in ranked_lists:
        for rank_idx, (item_id, _) in enumerate(ranked_list):
            rank = rank_idx + 1   # 1-based
            scores[item_id] = scores.get(item_id, 0.0) + 1.0 / (k + rank)

    return sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
