"""openrag.text.tokenize — lightweight BM25 tokenizer.

Splits text into lowercase alphanumeric tokens.  Identical tokenization is
used at both index time and query time so term frequencies are consistent
across all text-store backends.
"""

from __future__ import annotations

import re

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def tokenize(text: str) -> list[str]:
    """Return a list of lowercase alphanumeric tokens from *text*."""
    return _TOKEN_RE.findall(text.lower())
