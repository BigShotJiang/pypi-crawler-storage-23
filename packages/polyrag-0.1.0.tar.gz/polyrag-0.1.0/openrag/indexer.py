"""OpenRAGIndexer — orchestrates the full document indexing pipeline.

Pipeline::

    index_file(file_path)
      → parse_document()              (parsers/unified_parser.py)
      → build_extraction_windows()    (structured_data/chunking.py)
      → _build_chunk_records()        (ExtractionChunkWindow → ChunkRecord)
      → [if overwrite] delete_by_doc_id()
      → embedding_provider.encode()  (batched float32 embeddings)
      → text_store.index_chunks()     (BM25 incremental insert)
      → vector_store.index_chunks()   (FAISS append)
      → vector_store.save()           (persist to disk)
"""

from __future__ import annotations

import hashlib
import logging
import os
import uuid
from typing import Any, Dict, List, Optional

from openrag.config import OpenRAGConfig, openrag_config_from_env
from openrag.embedding.manager import EmbeddingManager
from openrag.schemas import ChunkRecord
from openrag.stores.factory import get_text_store
from openrag.stores.vector_store import FAISSVectorStore

logger = logging.getLogger(__name__)

# DNS namespace UUID for deterministic uuid5 chunk IDs
_UUID5_NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


class OpenRAGIndexer:
    """Full document indexing pipeline for OpenRAG.

    Args:
        config: OpenRAGConfig instance. If None, loads from environment variables.

    Usage::

        indexer = OpenRAGIndexer()
        result = indexer.index_file("report.pdf")
        print(result)
        # {"doc_id": "...", "file_name": "report.pdf", "chunks_indexed": 7,
        #  "text_backend": "sqlite", "embedding_model": "all-MiniLM-L6-v2"}
    """

    def __init__(self, config: Optional[OpenRAGConfig] = None) -> None:
        self.config = config or openrag_config_from_env()
        self._embedding_manager = EmbeddingManager()
        self._provider = self._embedding_manager.get_provider(
            model_name=self.config.embedding_model,
            device=self.config.embedding_device,
            normalize=self.config.embedding_normalize,
        )
        self.text_store = get_text_store(self.config)
        self.vector_store = FAISSVectorStore(
            index_path=self.config.faiss_index_path,
            metadata_path=self.config.faiss_metadata_path,
            embedding_provider=self._provider,
            hnsw_m=self.config.faiss_hnsw_m,
            ef_construction=self.config.faiss_ef_construction,
            ef_search=self.config.faiss_ef_search,
        )

    # ── Public API ────────────────────────────────────────────────────────────

    def index_file(
        self,
        file_path: str,
        doc_id: Optional[str] = None,
        file_name: Optional[str] = None,
    ) -> dict:
        """Parse and index a document file.

        Args:
            file_path: Path to the document (PDF, DOCX, XLSX, etc.).
            doc_id: Override auto-generated doc_id (SHA-256 based).
            file_name: Override the display file name (defaults to basename).

        Returns:
            Summary dict with doc_id, file_name, chunks_indexed, text_backend,
            embedding_model.
        """
        from parsers.unified_parser import parse_document

        resolved_name = file_name or os.path.basename(file_path)
        logger.info("OpenRAGIndexer: parsing %s", file_path)

        parse_result = parse_document(file_path)
        # UnifiedParseResult has a .text or .content attribute depending on version;
        # try both.
        text = getattr(parse_result, "text", None) or getattr(parse_result, "content", "") or ""
        if not text.strip():
            logger.warning("OpenRAGIndexer: no text extracted from %s, skipping.", file_path)
            return {
                "doc_id": doc_id or "",
                "file_name": resolved_name,
                "chunks_indexed": 0,
                "text_backend": self.config.text_backend,
                "embedding_model": self.config.embedding_model,
                "warning": "No text extracted from document.",
            }

        return self.index_text(text, file_name=resolved_name, doc_id=doc_id)

    def index_text(
        self,
        text: str,
        file_name: str,
        doc_id: Optional[str] = None,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ) -> dict:
        """Index pre-parsed text directly (skips the parse step).

        Args:
            text: Full document text (may include ``--- Page N ---`` markers).
            file_name: Display name for the document.
            doc_id: Override auto-generated doc_id.
            extra_metadata: Optional metadata dict attached to every ChunkRecord for this
                document (e.g. ``{"doc_type": "invoice", "entity_types": ["Person", "Amount"]}``).
                Stored in the FAISS sidecar and returned in retrieval results.

        Returns:
            Same summary dict as ``index_file()``.
        """
        resolved_doc_id = doc_id or self._deterministic_doc_id(file_name, text)

        chunks = self._build_chunk_records(text, file_name, resolved_doc_id, extra_metadata=extra_metadata or {})
        if not chunks:
            logger.warning("OpenRAGIndexer: chunking produced 0 chunks for %s", file_name)
            return {
                "doc_id": resolved_doc_id,
                "file_name": file_name,
                "chunks_indexed": 0,
                "text_backend": self.config.text_backend,
                "embedding_model": self.config.embedding_model,
                "warning": "No chunks produced from document text.",
            }

        # Re-indexing: remove old data for this doc first
        if self.config.overwrite_on_reindex:
            deleted_text = self.text_store.delete_by_doc_id(resolved_doc_id)
            deleted_vec = self.vector_store.delete_by_doc_id(resolved_doc_id)
            if deleted_text or deleted_vec:
                logger.info(
                    "OpenRAGIndexer: removed %d text / %d vector entries for doc_id=%s (re-index)",
                    deleted_text, deleted_vec, resolved_doc_id,
                )

        # Embed all chunks in one batched call
        texts = [c.text for c in chunks]
        logger.info(
            "OpenRAGIndexer: encoding %d chunks with %s", len(texts), self.config.embedding_model
        )
        embeddings = self._provider.encode(
            texts,
            batch_size=self.config.embedding_batch_size,
            show_progress_bar=self.config.show_progress,
        )

        # Index in both stores
        self.text_store.index_chunks(chunks)
        self.vector_store.index_chunks(chunks, embeddings)
        self.vector_store.save()

        logger.info(
            "OpenRAGIndexer: indexed %d chunks for '%s' (doc_id=%s)",
            len(chunks), file_name, resolved_doc_id,
        )
        return {
            "doc_id": resolved_doc_id,
            "file_name": file_name,
            "chunks_indexed": len(chunks),
            "text_backend": self.config.text_backend,
            "embedding_model": self.config.embedding_model,
            "embedding_dim": self._provider.dim,
        }

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _build_chunk_records(
        self,
        text: str,
        file_name: str,
        doc_id: str,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ) -> List[ChunkRecord]:
        """Chunk text using build_extraction_windows and convert to ChunkRecord list."""
        from structured_data.chunking import build_extraction_windows

        windows = build_extraction_windows(
            text,
            target_chars=self.config.chunk_target_chars,
            max_chars=self.config.chunk_max_chars,
            overlap_chars=self.config.chunk_overlap_chars,
            use_page_windows=self.config.chunk_use_page_windows,
            table_safe_split=self.config.chunk_table_safe_split,
        )

        meta = extra_metadata or {}
        return [
            ChunkRecord(
                chunk_id=str(uuid.uuid5(_UUID5_NS, f"{doc_id}::{w.chunk_index}")),
                doc_id=doc_id,
                file_name=file_name,
                chunk_index=w.chunk_index,
                text=w.text,
                start_page=w.start_page,
                end_page=w.end_page,
                has_overlap=w.has_overlap,
                char_count=w.char_count,
                metadata=meta,
            )
            for w in windows
        ]

    @staticmethod
    def _deterministic_doc_id(file_name: str, text: str) -> str:
        """SHA-256 of (file_name + first 500 chars of text), hex[:32].

        The same file always produces the same doc_id, enabling idempotent
        re-indexing without the caller having to track IDs.
        """
        seed = f"{file_name}::{text[:500]}"
        return hashlib.sha256(seed.encode()).hexdigest()[:32]
