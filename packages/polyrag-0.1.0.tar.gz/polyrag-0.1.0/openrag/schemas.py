"""ChunkRecord — the canonical unit stored in both text and vector stores."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class ChunkRecord:
    """
    A single document chunk indexed in both the BM25 text store and FAISS vector store.

    chunk_id  : Stable UUID derived from (doc_id, chunk_index) via uuid5.
                Used as the primary key across both stores and for RRF join.
    doc_id    : Stable identifier for the parent document (SHA-256 of file_name + text[:500]).
                Used for filtering and deletion.
    file_name : Original file name (e.g. "invoice.pdf").
    chunk_index : 0-based position within the document.
    text      : Full chunk text — what gets embedded and BM25-indexed.
    start_page / end_page : Page range within the source document (None if unknown).
    has_overlap : True if this chunk includes overlap text from the previous chunk.
    char_count  : Character count of text (set from len(text) during construction).
    metadata    : Arbitrary key-value metadata attached to this chunk (e.g. entity_names,
                  entity_types, doc_type from the structured extraction pipeline). Stored
                  in the FAISS sidecar and surfaced in retrieval results.
    """

    chunk_id: str
    doc_id: str
    file_name: str
    chunk_index: int
    text: str
    start_page: Optional[int] = None
    end_page: Optional[int] = None
    has_overlap: bool = False
    char_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "chunk_id": self.chunk_id,
            "doc_id": self.doc_id,
            "file_name": self.file_name,
            "chunk_index": self.chunk_index,
            "text": self.text,
            "start_page": self.start_page,
            "end_page": self.end_page,
            "has_overlap": self.has_overlap,
            "char_count": self.char_count,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, d: dict) -> ChunkRecord:
        return cls(
            chunk_id=d["chunk_id"],
            doc_id=d["doc_id"],
            file_name=d["file_name"],
            chunk_index=d["chunk_index"],
            text=d["text"],
            start_page=d.get("start_page"),
            end_page=d.get("end_page"),
            has_overlap=d.get("has_overlap", False),
            char_count=d.get("char_count", 0),
            metadata=d.get("metadata", {}),
        )
