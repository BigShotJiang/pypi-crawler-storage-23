"""CLI entry point for OpenRAG document retrieval.

Usage::

    python -m openrag.run_query "What is the invoice total?"
        --mode            hybrid|text|vector    (default: hybrid)
        --top-k           10                    (default: 10)
        --embedding-model all-MiniLM-L6-v2     (must match indexing model)
        --text-backend    sqlite|postgres|...   (default: sqlite)
        --device          cpu|cuda|mps
        --faiss-path      ./openrag.faiss
        --bm25-path       ./openrag_bm25.sqlite
        --doc-id          <filter>              (restrict to one document)
        --show-text                             (print full chunk text)
        --json                                  (print results as JSON)
"""

from __future__ import annotations

import argparse
import json
import logging


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m openrag.run_query",
        description="Retrieve relevant chunks from the OpenRAG index.",
    )
    p.add_argument("query", help="Natural language query string.")
    p.add_argument("--mode", default=None, choices=["hybrid", "text", "vector"],
                   help="Retrieval mode (default: hybrid).")
    p.add_argument("--top-k", type=int, default=None,
                   help="Number of results to return (default: 10).")
    p.add_argument("--text-backend", default=None,
                   choices=["sqlite", "postgres", "mysql", "mongodb"])
    p.add_argument("--embedding-model", default=None)
    p.add_argument("--device", default=None, choices=["cpu", "cuda", "mps"])
    p.add_argument("--faiss-path", default=None)
    p.add_argument("--faiss-meta-path", default=None)
    p.add_argument("--bm25-path", default=None)
    p.add_argument("--doc-id", default=None,
                   help="Restrict retrieval to chunks from this doc_id.")
    p.add_argument("--show-text", action="store_true",
                   help="Print full chunk text in results (default: preview only).")
    p.add_argument("--json", action="store_true",
                   help="Print results as JSON.")
    p.add_argument("--verbose", "-v", action="store_true")
    return p


def main(argv: list | None = None) -> None:
    args = _build_parser().parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )

    from openrag.config import openrag_config_from_env
    cfg = openrag_config_from_env()

    if args.text_backend:
        cfg.text_backend = args.text_backend  # type: ignore[assignment]
    if args.embedding_model:
        cfg.embedding_model = args.embedding_model
    if args.device:
        cfg.embedding_device = args.device
    if args.faiss_path:
        cfg.faiss_index_path = args.faiss_path
    if args.faiss_meta_path:
        cfg.faiss_metadata_path = args.faiss_meta_path
    if args.bm25_path:
        cfg.sqlite_bm25_path = args.bm25_path
    if args.top_k:
        cfg.top_k_final = args.top_k
    if args.mode:
        cfg.retrieval_mode = args.mode  # type: ignore[assignment]

    from openrag.retriever import OpenRAGRetriever
    retriever = OpenRAGRetriever(cfg)

    results = retriever.retrieve(
        args.query,
        top_k=args.top_k,
        mode=args.mode,
        doc_id_filter=args.doc_id,
    )

    if args.json:
        print(json.dumps(results, indent=2, default=str))
        return

    mode_label = args.mode or cfg.retrieval_mode
    print(f"\n[OpenRAG Query]")
    print(f"  Query  : {args.query}")
    print(f"  Mode   : {mode_label} (RRF k={cfg.rrf_k})" if mode_label == "hybrid"
          else f"  Mode   : {mode_label}")
    print(f"  Top-k  : {len(results)}")
    print()

    if not results:
        print("  No results found.")
        return

    for rank, r in enumerate(results, 1):
        pages = ""
        sp, ep = r.get("start_page"), r.get("end_page")
        if sp is not None:
            pages = f" | pages={sp}" if sp == ep else f" | pages={sp}-{ep}"
        print(
            f"  Rank {rank:2d} | score={r['retrieval_score']:.4f}"
            f" | file={r.get('file_name', '?')}{pages}"
            f" | chars={r.get('char_count', '?')}"
        )
        text = r.get("text", "")
        if args.show_text:
            print(f"    Text:\n{text}\n")
        else:
            preview = text[:200].replace("\n", " ")
            print(f"    Preview: {preview}…")
        print()


if __name__ == "__main__":
    main()
