"""EmbeddingManager — factory and cache for EmbeddingProvider instances.

Mirrors the pattern in llm/manager.py: lazy instantiation, LRU instance cache,
and convenience functions for direct access.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Dict, Optional

from openrag.embedding.base import EmbeddingProvider
from openrag.embedding.providers.sentence_transformers import SentenceTransformerProvider

logger = logging.getLogger(__name__)


class EmbeddingManager:
    """Factory and cache for EmbeddingProvider instances.

    Instances are keyed by (model_name, device, normalize) so that the same
    model loaded on the same device is reused across multiple calls.

    Usage::

        manager = EmbeddingManager()
        provider = manager.get_provider("all-MiniLM-L6-v2")
        embeddings = provider.encode(["hello world", "foo bar"])
    """

    def __init__(self) -> None:
        self._instances: Dict[str, EmbeddingProvider] = {}

    def get_provider(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        device: str = "cpu",
        normalize: bool = True,
        cache_folder: Optional[str] = None,
        use_cache: bool = True,
    ) -> EmbeddingProvider:
        """Return a (cached) SentenceTransformerProvider for the given model.

        Args:
            model_name: Any sentence-transformers model identifier.
            device: ``"cpu"``, ``"cuda"``, or ``"mps"``.
            normalize: L2-normalize embeddings (recommended for cosine similarity).
            cache_folder: Local directory for downloaded model weights.
            use_cache: If False, always create a fresh instance.

        Returns:
            EmbeddingProvider ready for encoding.
        """
        cache_key = self._make_key(model_name, device, normalize)

        if use_cache and cache_key in self._instances:
            logger.debug("Using cached embedding provider: %s on %s", model_name, device)
            return self._instances[cache_key]

        provider = SentenceTransformerProvider(
            model_name=model_name,
            device=device,
            normalize=normalize,
            cache_folder=cache_folder,
        )

        if use_cache:
            self._instances[cache_key] = provider
            logger.info("Created and cached embedding provider: %s on %s", model_name, device)

        return provider

    def _make_key(self, model_name: str, device: str, normalize: bool) -> str:
        content = f"{model_name}:{device}:{normalize}"
        return hashlib.md5(content.encode()).hexdigest()[:12]

    def clear_cache(self) -> None:
        count = len(self._instances)
        self._instances.clear()
        logger.info("Cleared %d cached embedding provider(s)", count)

    def cache_info(self) -> dict:
        return {
            "cached_providers": len(self._instances),
            "models": [repr(p) for p in self._instances.values()],
        }


# Module-level singleton — mirrors ``llm_manager`` in llm/manager.py
embedding_manager = EmbeddingManager()


def get_embedding_provider(
    model_name: str = "all-MiniLM-L6-v2",
    device: str = "cpu",
    normalize: bool = True,
) -> EmbeddingProvider:
    """Convenience function using the global EmbeddingManager."""
    return embedding_manager.get_provider(model_name=model_name, device=device, normalize=normalize)
