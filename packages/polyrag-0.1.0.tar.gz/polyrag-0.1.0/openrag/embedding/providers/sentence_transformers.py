"""SentenceTransformer embedding provider.

Supports any model hosted on HuggingFace that is compatible with the
sentence-transformers library (e.g. 'all-MiniLM-L6-v2', 'all-mpnet-base-v2',
'BAAI/bge-small-en-v1.5', etc.).

The model is loaded lazily on first call to ``encode()`` or access to ``dim``
to avoid the slow torch/transformers import at startup.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from openrag.embedding.base import EmbeddingProvider


class SentenceTransformerProvider(EmbeddingProvider):
    """Wraps ``sentence_transformers.SentenceTransformer`` for OpenRAG.

    Args:
        model_name: Any sentence-transformers compatible model identifier.
        device: Compute device — ``"cpu"``, ``"cuda"``, or ``"mps"``.
        normalize: If True, L2-normalize embeddings (cosine similarity via dot).
        cache_folder: Optional local directory to cache downloaded models.
    """

    def __init__(
        self,
        model_name: str = "all-MiniLM-L6-v2",
        device: str = "cpu",
        normalize: bool = True,
        cache_folder: Optional[str] = None,
    ) -> None:
        self._model_name = model_name
        self._device = device
        self._normalize = normalize
        self._cache_folder = cache_folder
        self._model = None        # lazy: loaded on first use
        self._dim: int = -1       # populated after first encode/probe

    def _ensure_loaded(self) -> None:
        if self._model is not None:
            return
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise ImportError(
                "sentence-transformers is required for SentenceTransformerProvider. "
                "Install it with: pip install sentence-transformers"
            ) from exc

        self._model = SentenceTransformer(
            self._model_name,
            device=self._device,
            cache_folder=self._cache_folder,
        )
        # Probe dimension with a single dummy sentence
        probe = self._model.encode(["probe"], normalize_embeddings=False)
        self._dim = int(probe.shape[1])

    @property
    def dim(self) -> int:
        self._ensure_loaded()
        return self._dim

    @property
    def model_name(self) -> str:
        return self._model_name

    def encode(
        self,
        texts: List[str],
        batch_size: int = 64,
        show_progress_bar: bool = False,
    ) -> np.ndarray:
        if not texts:
            raise ValueError("encode() called with an empty text list")
        self._ensure_loaded()
        embeddings = self._model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
            normalize_embeddings=self._normalize,
            convert_to_numpy=True,
        )
        return embeddings.astype(np.float32)
