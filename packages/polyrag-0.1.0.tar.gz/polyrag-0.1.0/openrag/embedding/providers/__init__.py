"""Embedding provider implementations."""

from openrag.embedding.providers.sentence_transformers import SentenceTransformerProvider

__all__ = ["SentenceTransformerProvider"]
