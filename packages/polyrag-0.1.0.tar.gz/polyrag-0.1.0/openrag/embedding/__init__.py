"""Embedding provider package for OpenRAG."""

from openrag.embedding.base import EmbeddingProvider
from openrag.embedding.manager import EmbeddingManager

__all__ = ["EmbeddingProvider", "EmbeddingManager"]
