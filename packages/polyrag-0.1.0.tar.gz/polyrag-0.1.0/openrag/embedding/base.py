"""Abstract base class for embedding providers — mirrors llm/base.py pattern."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

import numpy as np


class EmbeddingProvider(ABC):
    """Abstract interface for embedding models.

    All providers must:
    - Return float32 numpy arrays of shape (len(texts), dim).
    - Expose the embedding dimension via the ``dim`` property.
    - Be lazily initialized (no heavy imports at class-definition time).
    """

    @abstractmethod
    def encode(
        self,
        texts: List[str],
        batch_size: int = 64,
        show_progress_bar: bool = False,
    ) -> np.ndarray:
        """Encode a list of texts into embeddings.

        Args:
            texts: Non-empty list of strings to encode.
            batch_size: Number of texts per forward pass.
            show_progress_bar: Show tqdm bar during encoding.

        Returns:
            float32 numpy array of shape (len(texts), self.dim).

        Raises:
            ValueError: If texts is empty.
        """

    @property
    @abstractmethod
    def dim(self) -> int:
        """Embedding dimension. Triggers model load on first access."""

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Human-readable model identifier (e.g. 'all-MiniLM-L6-v2')."""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model_name})"
