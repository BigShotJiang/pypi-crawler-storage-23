"""OpenRAG configuration dataclass with environment-variable loading."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Literal, Optional

from dotenv import load_dotenv

load_dotenv(override=True)

TextBackend = Literal["sqlite", "postgres", "mysql", "mongodb"]
RetrievalMode = Literal["text", "vector", "hybrid"]


@dataclass
class OpenRAGConfig:
    # ── Embedding model ──────────────────────────────────────────────────────
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_batch_size: int = 64
    embedding_device: str = "cpu"        # "cpu" | "cuda" | "mps"
    embedding_normalize: bool = True     # L2-normalize before indexing

    # ── Chunking (mirrors build_extraction_windows defaults) ─────────────────
    chunk_target_chars: int = 10_000
    chunk_max_chars: int = 12_000
    chunk_overlap_chars: int = 500
    chunk_use_page_windows: bool = True
    chunk_table_safe_split: bool = True

    # ── Text search backend ──────────────────────────────────────────────────
    text_backend: TextBackend = "sqlite"

    # BM25 parameters (same across all backends)
    bm25_k1: float = 1.2
    bm25_b: float = 0.75

    # SQLite
    sqlite_bm25_path: str = "./openrag_bm25.sqlite"

    # PostgreSQL
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_db: str = "openrag"
    postgres_user: str = "postgres"
    postgres_password: str = ""
    postgres_table: str = "openrag_bm25"

    # MySQL
    mysql_host: str = "localhost"
    mysql_port: int = 3306
    mysql_db: str = "openrag"
    mysql_user: str = "root"
    mysql_password: str = ""
    mysql_table: str = "openrag_bm25"

    # MongoDB
    mongodb_connection_string: Optional[str] = None
    mongodb_host: str = "localhost"
    mongodb_port: int = 27017
    mongodb_database: str = "openrag"
    mongodb_username: Optional[str] = None
    mongodb_password: Optional[str] = None
    # Collection name prefix — creates: <prefix>_postings, _doc_len, _term_stats, _meta
    mongodb_collection_prefix: str = "openrag_bm25"

    # ── FAISS / vector store ─────────────────────────────────────────────────
    faiss_index_path: str = "./openrag.faiss"
    faiss_metadata_path: str = "./openrag_meta.json"
    faiss_hnsw_m: int = 32              # HNSW graph connectivity
    faiss_ef_construction: int = 200    # Build-time candidate list size
    faiss_ef_search: int = 64           # Query-time candidate list size

    # ── Retrieval ────────────────────────────────────────────────────────────
    retrieval_mode: RetrievalMode = "hybrid"
    rrf_k: int = 60                     # RRF constant (60 is the standard)
    top_k_text: int = 20                # BM25 candidates before fusion
    top_k_vector: int = 20             # HNSW candidates before fusion
    top_k_final: int = 10              # Results returned to caller

    # ── Indexing behaviour ───────────────────────────────────────────────────
    overwrite_on_reindex: bool = True   # delete existing doc chunks before re-indexing
    show_progress: bool = True          # tqdm progress bars during embed


def openrag_config_from_env() -> OpenRAGConfig:
    """Build an OpenRAGConfig from environment variables.

    Every field maps to an env var of the form ``OPENRAG_<FIELD_UPPER>``.
    Constructor keyword arguments always take precedence over env vars.

    Example env vars::

        OPENRAG_EMBEDDING_MODEL=BAAI/bge-small-en-v1.5
        OPENRAG_TEXT_BACKEND=postgres
        OPENRAG_POSTGRES_HOST=db.example.com
        OPENRAG_FAISS_HNSW_M=16
    """

    def _bool(key: str, default: bool) -> bool:
        val = os.getenv(key)
        if val is None:
            return default
        return val.strip().lower() in ("1", "true", "yes", "on")

    def _int(key: str, default: int) -> int:
        val = os.getenv(key)
        return int(val) if val is not None else default

    def _float(key: str, default: float) -> float:
        val = os.getenv(key)
        return float(val) if val is not None else default

    def _str(key: str, default: str) -> str:
        return os.getenv(key, default)

    def _opt_str(key: str) -> Optional[str]:
        return os.getenv(key) or None

    return OpenRAGConfig(
        embedding_model=_str("OPENRAG_EMBEDDING_MODEL", "all-MiniLM-L6-v2"),
        embedding_batch_size=_int("OPENRAG_EMBEDDING_BATCH_SIZE", 64),
        embedding_device=_str("OPENRAG_EMBEDDING_DEVICE", "cpu"),
        embedding_normalize=_bool("OPENRAG_EMBEDDING_NORMALIZE", True),

        chunk_target_chars=_int("OPENRAG_CHUNK_TARGET_CHARS", 10_000),
        chunk_max_chars=_int("OPENRAG_CHUNK_MAX_CHARS", 12_000),
        chunk_overlap_chars=_int("OPENRAG_CHUNK_OVERLAP_CHARS", 500),
        chunk_use_page_windows=_bool("OPENRAG_CHUNK_USE_PAGE_WINDOWS", True),
        chunk_table_safe_split=_bool("OPENRAG_CHUNK_TABLE_SAFE_SPLIT", True),

        text_backend=_str("OPENRAG_TEXT_BACKEND", "sqlite"),  # type: ignore[arg-type]
        bm25_k1=_float("OPENRAG_BM25_K1", 1.2),
        bm25_b=_float("OPENRAG_BM25_B", 0.75),

        sqlite_bm25_path=_str("OPENRAG_SQLITE_BM25_PATH", "./openrag_bm25.sqlite"),

        postgres_host=_str("OPENRAG_POSTGRES_HOST", "localhost"),
        postgres_port=_int("OPENRAG_POSTGRES_PORT", 5432),
        postgres_db=_str("OPENRAG_POSTGRES_DB", "openrag"),
        postgres_user=_str("OPENRAG_POSTGRES_USER", "postgres"),
        postgres_password=_str("OPENRAG_POSTGRES_PASSWORD", ""),
        postgres_table=_str("OPENRAG_POSTGRES_TABLE", "openrag_bm25"),

        mysql_host=_str("OPENRAG_MYSQL_HOST", "localhost"),
        mysql_port=_int("OPENRAG_MYSQL_PORT", 3306),
        mysql_db=_str("OPENRAG_MYSQL_DB", "openrag"),
        mysql_user=_str("OPENRAG_MYSQL_USER", "root"),
        mysql_password=_str("OPENRAG_MYSQL_PASSWORD", ""),
        mysql_table=_str("OPENRAG_MYSQL_TABLE", "openrag_bm25"),

        mongodb_connection_string=_opt_str("OPENRAG_MONGODB_CONNECTION_STRING"),
        mongodb_host=_str("OPENRAG_MONGODB_HOST", "localhost"),
        mongodb_port=_int("OPENRAG_MONGODB_PORT", 27017),
        mongodb_database=_str("OPENRAG_MONGODB_DATABASE", "openrag"),
        mongodb_username=_opt_str("OPENRAG_MONGODB_USERNAME"),
        mongodb_password=_opt_str("OPENRAG_MONGODB_PASSWORD"),
        mongodb_collection_prefix=_str("OPENRAG_MONGODB_COLLECTION_PREFIX", "openrag_bm25"),

        faiss_index_path=_str("OPENRAG_FAISS_INDEX_PATH", "./openrag.faiss"),
        faiss_metadata_path=_str("OPENRAG_FAISS_METADATA_PATH", "./openrag_meta.json"),
        faiss_hnsw_m=_int("OPENRAG_FAISS_HNSW_M", 32),
        faiss_ef_construction=_int("OPENRAG_FAISS_EF_CONSTRUCTION", 200),
        faiss_ef_search=_int("OPENRAG_FAISS_EF_SEARCH", 64),

        retrieval_mode=_str("OPENRAG_RETRIEVAL_MODE", "hybrid"),  # type: ignore[arg-type]
        rrf_k=_int("OPENRAG_RRF_K", 60),
        top_k_text=_int("OPENRAG_TOP_K_TEXT", 20),
        top_k_vector=_int("OPENRAG_TOP_K_VECTOR", 20),
        top_k_final=_int("OPENRAG_TOP_K_FINAL", 10),

        overwrite_on_reindex=_bool("OPENRAG_OVERWRITE_ON_REINDEX", True),
        show_progress=_bool("OPENRAG_SHOW_PROGRESS", True),
    )
