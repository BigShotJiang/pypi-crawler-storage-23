import os
import logging
from typing import Optional, Dict, Any, List, Union, Tuple
from contextlib import contextmanager
from neo4j import GraphDatabase, Driver, Session
from neo4j.exceptions import ServiceUnavailable, AuthError
from dotenv import load_dotenv

load_dotenv(override=True)

class Neo4jConnector:
    """
    Neo4j connector using neo4j-driver with support for Cypher queries.
    Supports tenant-specific credentials mapping.
    Each instance creates a new independent connection to Neo4j.
    """
    
    # Tenant to credentials mapping
    # Maps tenant_id to credential prefix (e.g., "FINFLOW", "DEFAULT")
    TENANT_CREDENTIAL_MAP = {
        "690425fcf0ce843239465cba": "FINFLOW",  # Use FINFLOW credentials for this tenant
        # Add more tenant mappings as needed
        # "other_tenant_id": "ANOTHER_PREFIX"
    }
    
    @classmethod
    def get_credentials_for_tenant(cls, tenant_id: Optional[str] = None) -> Tuple[str, str, str, str]:
        """
        Get Neo4j credentials for a specific tenant.
        If tenant_id has a mapping, returns tenant-specific credentials.
        Otherwise returns default credentials.
        
        Args:
            tenant_id: The tenant identifier
            
        Returns:
            Tuple of (uri, username, password, database)
        """
        # Check if this tenant has custom credentials
        if tenant_id and tenant_id in cls.TENANT_CREDENTIAL_MAP:
            prefix = cls.TENANT_CREDENTIAL_MAP[tenant_id]
            uri = os.getenv(f"{prefix}_NEO4J_URI") or os.getenv("NEO4J_DEPLOYED_URI")
            username = os.getenv(f"{prefix}_NEO4J_USER") or os.getenv("NEO4J_DEPLOYED_USER")
            password = os.getenv(f"{prefix}_NEO4J_PASSWORD") or os.getenv("NEO4J_DEPLOYED_PASSWORD")
            database = os.getenv(f"{prefix}_NEO4J_DATABASE") or os.getenv("NEO4J_DEPLOYED_DATABASE")
            
            logging.getLogger(__name__).info(
                f"Using {prefix} credentials for tenant {tenant_id}"
            )
        else:
            # Use default credentials
            uri = os.getenv("NEO4J_DEPLOYED_URI")
            username = os.getenv("NEO4J_DEPLOYED_USER")
            password = os.getenv("NEO4J_DEPLOYED_PASSWORD")
            database = os.getenv("NEO4J_DEPLOYED_DATABASE")
        
        return uri, username, password, database

    def __init__(
        self,
        uri: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        database: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ):
        """
        Initialize Neo4j Connector
        
        Args:
            uri: Neo4j URI (defaults to NEO4J_DEPLOYED_URI env var or tenant-specific URI)
            username: Neo4j username (defaults to NEO4J_DEPLOYED_USER env var or tenant-specific user)
            password: Neo4j password (defaults to NEO4J_DEPLOYED_PASSWORD env var or tenant-specific password)
            database: Neo4j database (defaults to NEO4J_DEPLOYED_DATABASE env var or tenant-specific database)
            tenant_id: Tenant identifier (if provided, uses tenant-specific credentials)
        """
        # Get credentials, considering tenant_id
        if tenant_id and not uri:
            uri, username, password, database = self.get_credentials_for_tenant(tenant_id)
        
        # Set instance attributes
        self.uri = uri or os.getenv("NEO4J_DEPLOYED_URI")
        self.username = username or os.getenv("NEO4J_DEPLOYED_USER")
        self.password = password or os.getenv("NEO4J_DEPLOYED_PASSWORD")
        self.database = database or os.getenv("NEO4J_DEPLOYED_DATABASE")
        self.tenant_id = tenant_id

        self._driver: Optional[Driver] = None
        self.logger = logging.getLogger(__name__)

    def _ensure_connection(self) -> Driver:
        """Create the driver if it doesn't exist yet."""
        if self._driver is None:
            try:
                self._driver = GraphDatabase.driver(
                    self.uri,
                    auth=(self.username, self.password)
                )
                # Test the connection
                with self._driver.session(database=self.database) as session:
                    session.run("RETURN 1")
                
                self.logger.info(
                    f"Connected to Neo4j database '{self.database}' at {self.uri}"
                )
            except (ServiceUnavailable, AuthError) as e:
                self.logger.exception("Could not establish Neo4j connection")
                raise
        return self._driver

    @contextmanager
    def session(self):
        """
        Context manager yielding a Neo4j session.
        """
        driver = self._ensure_connection()
        session = driver.session(database=self.database)
        try:
            yield session
        except Exception as e:
            self.logger.error(f"Session operation failed: {type(e).__name__}: {str(e)}")
            raise
        finally:
            session.close()

    def execute_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Run a Cypher query and return results as list of dictionaries.
        """
        with self.session() as session:
            result = session.run(query, parameters or {})
            return [record.data() for record in result]

    def execute_write_query(self, query: str, parameters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Run a write Cypher query (CREATE, MERGE, UPDATE, DELETE) and return results.
        """
        with self.session() as session:
            result = session.run(query, parameters or {})
            return [record.data() for record in result]

    def execute_transaction(self, queries: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        """
        Execute multiple queries in a single transaction.
        queries: List of dicts with 'query' and optional 'parameters' keys.
        """
        def tx_function(tx):
            results = []
            for query_dict in queries:
                query = query_dict.get('query', '')
                params = query_dict.get('parameters', {})
                result = tx.run(query, params)
                results.append([record.data() for record in result])
            return results

        with self.session() as session:
            return session.execute_write(tx_function)

    def test_connection(self) -> bool:
        """Quick check that the database is reachable and responding."""
        try:
            with self.session() as session:
                result = session.run("RETURN 1 AS test")
                return result.single()["test"] == 1
        except Exception:
            return False

    def get_database_info(self) -> Dict[str, Any]:
        """
        Get database information including node labels, relationship types, and constraints.
        """
        info = {}
        
        try:
            with self.session() as session:
                # Get node labels
                labels_result = session.run("CALL db.labels()")
                info["node_labels"] = [record["label"] for record in labels_result]
                
                # Get relationship types
                rel_types_result = session.run("CALL db.relationshipTypes()")
                info["relationship_types"] = [record["relationshipType"] for record in rel_types_result]
                
                # Get property keys
                prop_keys_result = session.run("CALL db.propertyKeys()")
                info["property_keys"] = [record["propertyKey"] for record in prop_keys_result]
                
                # Get constraints
                constraints_result = session.run("CALL db.constraints()")
                info["constraints"] = [record.data() for record in constraints_result]
                
                # Get indexes
                indexes_result = session.run("CALL db.indexes()")
                info["indexes"] = [record.data() for record in indexes_result]
                
                # Get database stats
                stats_result = session.run("""
                    MATCH (n)
                    RETURN count(n) AS total_nodes
                    UNION ALL
                    MATCH ()-[r]->()
                    RETURN count(r) AS total_relationships
                """)
                stats = [record.data() for record in stats_result]
                info["stats"] = stats
                
        except Exception as e:
            self.logger.warning(f"Could not retrieve full database info: {e}")
            info["error"] = str(e)
        
        return info

    def create_node(self, label: str, properties: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a single node with given label and properties.
        """
        query = f"CREATE (n:{label} $properties) RETURN n"
        result = self.execute_write_query(query, {"properties": properties})
        return result[0] if result else {}

    def create_relationship(
        self, 
        from_node_match: str, 
        to_node_match: str, 
        relationship_type: str,
        properties: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create a relationship between two nodes.
        
        Args:
            from_node_match: Cypher pattern to match source node (e.g., "(:Person {name: 'Alice'})")
            to_node_match: Cypher pattern to match target node (e.g., "(:Person {name: 'Bob'})")
            relationship_type: Type of relationship (e.g., "KNOWS")
            properties: Optional properties for the relationship
        """
        props_part = "$properties" if properties else ""
        query = f"""
        MATCH (a{from_node_match}), (b{to_node_match})
        CREATE (a)-[r:{relationship_type} {props_part}]->(b)
        RETURN r
        """
        result = self.execute_write_query(query, {"properties": properties or {}})
        return result[0] if result else {}

    def find_nodes(self, label: str, properties: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Find nodes with given label and optional properties.
        """
        if properties:
            where_clause = " AND ".join([f"n.{key} = ${key}" for key in properties.keys()])
            query = f"MATCH (n:{label}) WHERE {where_clause} RETURN n"
            return self.execute_query(query, properties)
        else:
            query = f"MATCH (n:{label}) RETURN n"
            return self.execute_query(query)

    def delete_all_data(self) -> bool:
        """
        WARNING: This will delete all nodes and relationships in the database.
        Use with caution!
        """
        try:
            self.execute_write_query("MATCH (n) DETACH DELETE n")
            return True
        except Exception as e:
            self.logger.error(f"Failed to delete all data: {e}")
            return False

    def close(self):
        """Close the underlying driver connection."""
        if self._driver:
            self._driver.close()
            self.logger.info("Neo4j connection closed.")
            self._driver = None


def get_neo4j_connection(database: str = "neo4j", **kwargs) -> Neo4jConnector:
    """
    Factory helper to create a connector for a given database.
    """
    return Neo4jConnector(database=database, **kwargs)

def connect_neo4j(neo4j_uri, neo4j_user, neo4j_password):
        """Connect to Neo4j"""
        try:
            neo4j_driver = GraphDatabase.driver(
                neo4j_uri, 
                auth=(neo4j_user, neo4j_password)
            )
            print("✅ Connected to Neo4j")
            return True
        except Exception as e:
            print(f"❌ Failed to connect to Neo4j: {e}")
            return False

# Example usage
def main():

    connector = get_neo4j_connection(database=os.getenv("NEO4J_DEPLOYED_DATABASE", "neo4j"))
    if connector.test_connection():
        print("✅ Connected to Neo4j!")
        
        # Get database info
        db_info = connector.get_database_info()
        print("Node labels:", db_info.get("node_labels", []))
        print("Relationship types:", db_info.get("relationship_types", []))
        print("Database stats:", db_info.get("stats", []))
        
    else:
        print("❌ Neo4j connection failed.")
    
    connector.close()
