import os
import logging
from typing import Optional, Dict, Any, List
from contextlib import contextmanager
from pymongo import MongoClient
from pymongo.database import Database
from pymongo.collection import Collection
import re
from urllib.parse import quote_plus
from dotenv import load_dotenv
from datetime import datetime
import certifi

load_dotenv(override=True)

class MongoDBConnector:
    """
    MongoDB connector using pymongo with dict-based document handling.
    Each instance creates a new independent connection to the specified database.
    """
    
    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        connection_string: Optional[str] = None,
    ):
        """
        Initialize a new MongoDB connector instance.
        
        Args:
            host: MongoDB host (defaults to MONGODB_HOST env var or 'localhost')
            port: MongoDB port (defaults to MONGODB_PORT env var or 27017)
            database: Database name (defaults to MONGODB_DATABASE env var or 'analytics')
            username: Username for authentication (defaults to MONGODB_USERNAME env var)
            password: Password for authentication (defaults to MONGODB_PASSWORD env var)
            connection_string: Full connection string (overrides individual parameters if provided)
        """
        self.host = host or os.getenv("MONGODB_HOST", "localhost")
        self.port = port or int(os.getenv("MONGODB_PORT", "27017"))
        self.database_name = database or os.getenv("MONGODB_DATABASE", "analytics")
        self.username = username or os.getenv("MONGODB_USERNAME")
        self.password = password or os.getenv("MONGODB_PASSWORD")
        env_connection_string = os.getenv("mongo_connection_string")
        if connection_string is None or (
            isinstance(connection_string, str) and connection_string.strip() == ""
        ):
            connection_string = env_connection_string
        self.connection_string = connection_string

        self._client: Optional[MongoClient] = None
        self._database: Optional[Database] = None
        self.logger = logging.getLogger(__name__)

    def _sanitize_host_port(self, host: Optional[str], port: Optional[int]):
        """
        If host contains ':port' (or [ipv6]:port), split it out.
        Returns (host_only, port_final).
        """
        if not host:
            return host, port
        # IPv6 or host:port pattern
        m = re.match(r'^\[?([^\]]+)\]?:([0-9]+)$', host)
        if m:
            host_only = m.group(1)
            port_from_host = int(m.group(2))
            return host_only, port_from_host
        return host, port

    def _build_mongo_uri(
        self,
        host: Optional[str],
        port: Optional[int],
        username: Optional[str],
        password: Optional[str],
        database: Optional[str],
        connection_string: Optional[str],
        use_srv: Optional[bool] = None,
        authSource: Optional[str] = None,
    ):
        """
        Build connection URI and return (uri, tls_required_bool).
        If connection_string provided, returns it and sets tls flag if it starts with mongodb+srv://
        """
        if connection_string:
            return connection_string, connection_string.startswith("mongodb+srv://")

        host, port = self._sanitize_host_port(host, port)
        host = host or "localhost"
        port = port or 27017
        db = (database or "admin")

        looks_like_atlas = host.endswith(".mongodb.net")
        if use_srv is None:
            use_srv = looks_like_atlas

        user_enc = quote_plus(username) if username else None
        pw_enc = quote_plus(password) if password else None

        if use_srv:
            # SRV: do NOT include port
            if user_enc and pw_enc:
                uri = f"mongodb+srv://{user_enc}:{pw_enc}@{host}/{db}?retryWrites=true&w=majority"
            else:
                uri = f"mongodb+srv://{host}/{db}?retryWrites=true&w=majority"
            return uri, True

        # Non-SRV (classic)
        if user_enc and pw_enc:
            uri = f"mongodb://{user_enc}:{pw_enc}@{host}:{port}/{db}"
            if authSource:
                uri += f"?authSource={authSource}"
        else:
            uri = f"mongodb://{host}:{port}/{db}"

        # For cloud-hosts (but not localhost) prefer TLS
        tls_flag = looks_like_atlas
        return uri, tls_flag

    def _ensure_connection(self) -> Database:
        """Create the connection if it doesn't exist yet."""
        if self._client is None:
            try:
                # Build URI and detect TLS requirement automatically
                # For Atlas clusters, authSource should typically be 'admin'
                auth_source = "admin" if self.host and self.host.endswith(".mongodb.net") else self.database_name
                uri, tls_required = self._build_mongo_uri(
                    host=self.host,
                    port=self.port,
                    username=self.username,
                    password=self.password,
                    database=self.database_name,
                    connection_string=self.connection_string or os.getenv("mongo_connection_string"),
                    # You may allow forcing SRV by setting self.use_srv attribute earlier
                    use_srv=getattr(self, "use_srv", None),
                    authSource=auth_source
                )

                self.logger.debug(f"Connecting to MongoDB using uri (sanitized): {uri if self.connection_string else uri.split('@')[-1]}")

                client_kwargs = {
                    "serverSelectionTimeoutMS": 30000,  # 30s
                }
                if tls_required:
                    client_kwargs["tls"] = True
                    client_kwargs["tlsCAFile"] = certifi.where()

                # Instantiate the client using the URI (recommended) so SRV records work.
                self._client = MongoClient(uri, **client_kwargs)

                # Force a quick ping to fail fast on DNS/auth/network issues
                self._client.admin.command("ping")

                # Set the database object
                self._database = self._client[self.database_name]

                self.logger.info(
                    f"Connected to MongoDB database '{self.database_name}' (host={self.host})"
                )
            except Exception as e:
                # Helpful logging and re-raise
                self.logger.exception("Could not establish MongoDB connection")
                # Close client if partially created
                try:
                    if self._client:
                        self._client.close()
                finally:
                    self._client = None
                    self._database = None
                # Give an actionable message for common Atlas failure modes
                raise RuntimeError(
                    "Failed to connect to MongoDB. "
                    "If this is an Atlas cluster, prefer passing the full 'mongodb+srv://...' connection string "
                    "or ensure 'host' is like 'cluster0.xxxx.mongodb.net' (no port) and your IP is allowed in Atlas Network Access. "
                    f"Underlying error: {e}"
                ) from e

        return self._database


    @contextmanager
    def get_collection(self, collection_name: str):
        """
        Context manager yielding a MongoDB collection.
        """
        database = self._ensure_connection()
        collection = database[collection_name]
        try:
            yield collection
        except Exception:
            self.logger.error(f"Operation failed on collection '{collection_name}'")
            raise

    def insert_document(self, collection_name: str, document: Dict[str, Any]) -> str:
        """
        Insert a single document into a collection.
        Returns the inserted document's ObjectId as string.
        """
        with self.get_collection(collection_name) as collection:
            result = collection.insert_one(document)
            self.logger.info(f"Inserted document with id {result.inserted_id} into {collection_name}")
            return str(result.inserted_id)

    def insert_documents(self, collection_name: str, documents: List[Dict[str, Any]]) -> List[str]:
        """
        Insert multiple documents into a collection.
        Returns the list of inserted document ObjectIds as strings.
        """
        with self.get_collection(collection_name) as collection:
            result = collection.insert_many(documents)
            self.logger.info(f"Inserted {len(result.inserted_ids)} documents into {collection_name}")
            return [str(doc_id) for doc_id in result.inserted_ids]

    def find_documents(
        self, 
        collection_name: str, 
        filter_query: Optional[Dict[str, Any]] = None,
        sort_by: Optional[List[tuple]] = None,
        limit: Optional[int] = None,
        skip: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Find documents in a collection based on filter criteria.
        """
        with self.get_collection(collection_name) as collection:
            cursor = collection.find(filter_query or {})
            
            if sort_by:
                cursor = cursor.sort(sort_by)
            
            if skip:
                cursor = cursor.skip(skip)
            
            if limit:
                cursor = cursor.limit(limit)
            
            documents = list(cursor)
            
            # Convert ObjectId to string for JSON serialization
            for doc in documents:
                if '_id' in doc:
                    doc['_id'] = str(doc['_id'])
            
            return documents

    def find_documents_paginated(
        self,
        collection_name: str,
        filter_query: Optional[Dict[str, Any]] = None,
        sort_by: Optional[List[tuple]] = None,
        limit: int = 20,
        cursor_field: str = "_id",
        cursor_value: Optional[Any] = None,
        cursor_direction: str = "before"  # "before" or "after"
    ) -> Dict[str, Any]:
        """
        Find documents with cursor-based pagination for efficient scrolling.
        
        Args:
            collection_name: Name of the collection
            filter_query: MongoDB filter query
            sort_by: List of (field, direction) tuples for sorting
            limit: Number of documents to return
            cursor_field: Field to use for cursor (usually timestamp or _id)
            cursor_value: Value to start pagination from
            cursor_direction: "before" for older messages, "after" for newer
            
        Returns:
            Dict containing documents, has_more, and cursor info
        """
        with self.get_collection(collection_name) as collection:
            # Build the query with cursor
            query = filter_query.copy() if filter_query else {}
            
            if cursor_value is not None:
                if cursor_direction == "before":
                    # For getting older messages (scrolling up)
                    query[cursor_field] = {"$lt": cursor_value}
                else:
                    # For getting newer messages (scrolling down)
                    query[cursor_field] = {"$gt": cursor_value}
            
            # Build cursor with sorting
            cursor = collection.find(query)
            
            if sort_by:
                cursor = cursor.sort(sort_by)
            
            # Get one extra document to check if there are more
            cursor = cursor.limit(limit + 1)
            documents = list(cursor)
            
            # Check if there are more documents
            has_more = len(documents) > limit
            if has_more:
                documents = documents[:limit]  # Remove the extra document
            
            # Convert ObjectId to string for JSON serialization
            for doc in documents:
                if '_id' in doc:
                    doc['_id'] = str(doc['_id'])
            
            # Get cursor values for next pagination
            next_cursor = None
            prev_cursor = None
            
            if documents:
                if cursor_direction == "before":
                    # When scrolling up, next cursor is the oldest document
                    next_cursor = documents[-1].get(cursor_field)
                    prev_cursor = documents[0].get(cursor_field)
                else:
                    # When scrolling down, next cursor is the newest document
                    next_cursor = documents[-1].get(cursor_field)
                    prev_cursor = documents[0].get(cursor_field)
            
            return {
                "documents": documents,
                "has_more": has_more,
                "next_cursor": str(next_cursor) if next_cursor else None,
                "prev_cursor": str(prev_cursor) if prev_cursor else None,
                "total_returned": len(documents)
            }

    def find_one_document(
        self, 
        collection_name: str, 
        filter_query: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Find a single document in a collection.
        """
        with self.get_collection(collection_name) as collection:
            document = collection.find_one(filter_query)
            
            if document and '_id' in document:
                document['_id'] = str(document['_id'])
            
            return document

    def update_document(
        self, 
        collection_name: str, 
        filter_query: Dict[str, Any],
        update_data: Dict[str, Any],
        upsert: bool = False
    ) -> int:
        """
        Update documents in a collection.
        Returns the number of modified documents.
        
        If update_data doesn't contain MongoDB operators (keys starting with '$'), 
        it will automatically wrap the data in a $set operator.
        """
        with self.get_collection(collection_name) as collection:
            # Check if update_data contains MongoDB operators
            has_operators = any(key.startswith('$') for key in update_data.keys())
            
            if not has_operators:
                # If no operators found, wrap in $set
                processed_update_data = {'$set': update_data.copy()}
            else:
                # If operators exist, use as-is but make a copy to avoid modifying original
                processed_update_data = update_data.copy()
            
            # Add updated_at timestamp
            processed_update_data.setdefault('$set', {})['updated_at'] = datetime.utcnow()
            
            result = collection.update_many(filter_query, processed_update_data, upsert=upsert)
            self.logger.info(f"Updated {result.modified_count} documents in {collection_name}")
            return result.modified_count

    def delete_documents(self, collection_name: str, filter_query: Dict[str, Any]) -> int:
        """
        Delete documents from a collection.
        Returns the number of deleted documents.
        """
        with self.get_collection(collection_name) as collection:
            result = collection.delete_many(filter_query)
            self.logger.info(f"Deleted {result.deleted_count} documents from {collection_name}")
            return result.deleted_count

    def list_collections(self) -> list:
        """
        List all collection names in the current database.
        Returns a list of collection names.
        """
        self._ensure_connection()
        if self._database is None:
            raise ValueError("No database is selected for this MongoDBConnector instance.")
        return self._database.list_collection_names()


    def test_connection(self) -> bool:
        """Quick check that the MongoDB is reachable and responding."""
        try:
            self._ensure_connection()
            return True
        except Exception:
            return False

    def close_connection(self):
        """Close the MongoDB connection."""
        if self._client:
            self._client.close()
            self._client = None
            self._database = None
            self.logger.info("MongoDB connection closed")
