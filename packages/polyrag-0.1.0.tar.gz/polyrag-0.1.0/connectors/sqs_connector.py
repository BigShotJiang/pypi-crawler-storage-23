import os
import json
import boto3
import logging
from typing import Optional, Dict, Any, List
from botocore.exceptions import ClientError, NoCredentialsError
from dotenv import load_dotenv

load_dotenv(override=True)

class SQSConnector:
    """
    AWS SQS connector for sending and receiving messages.
    Implements singleton pattern with credential-based instances.
    """
    _instances = {}
    
    def __new__(
        cls,
        region_name: Optional[str] = None,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        queue_url: Optional[str] = None,
    ):
        # Create a unique key based on connection parameters
        region_name = region_name or os.getenv("AWS_SQS_REGION")
        aws_access_key_id = aws_access_key_id or os.getenv("SQS_KEY")
        queue_url = queue_url or os.getenv("SQS_QUEUE_URL")
        
        instance_key = f"{region_name}:{aws_access_key_id}:{queue_url}"
        
        if instance_key not in cls._instances:
            cls._instances[instance_key] = super().__new__(cls)
            cls._instances[instance_key]._initialized = False
        return cls._instances[instance_key]
    
    def __init__(
        self,
        region_name: Optional[str] = None,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        queue_url: Optional[str] = None,
    ):
        # Initialize once to prevent re-initialization of singleton
        if not self._initialized:
            self.region_name = region_name or os.getenv("AWS_SQS_REGION")
            self.aws_access_key_id = aws_access_key_id or os.getenv("SQS_KEY")
            self.aws_secret_access_key = aws_secret_access_key or os.getenv("AWS_SECRET")
            self.queue_url = queue_url or os.getenv("SQS_QUEUE_URL")

            self._client = None
            self.logger = logging.getLogger(__name__)
            
            self._initialized = True

    def _ensure_client(self):
        """Create the SQS client if it doesn't exist yet."""
        if self._client is None:
            try:
                session = boto3.Session(
                    aws_access_key_id=self.aws_access_key_id,
                    aws_secret_access_key=self.aws_secret_access_key,
                    region_name=self.region_name
                )
                self._client = session.client('sqs')
                
                # Test the connection by getting queue attributes
                if self.queue_url:
                    self._client.get_queue_attributes(QueueUrl=self.queue_url, AttributeNames=['All'])
                
                self.logger.info(f"Connected to SQS in region {self.region_name}")
            except (ClientError, NoCredentialsError) as e:
                self.logger.error(f"Could not establish SQS connection: {str(e)}")
                raise
        
        return self._client

    def send_message(
        self,
        message_body: Dict[str, Any],
        queue_url: Optional[str] = None,
        delay_seconds: int = 0,
        message_group_id: Optional[str] = None,
        message_deduplication_id: Optional[str] = None
    ) -> str:
        """
        Send a message to SQS queue.
        Returns the MessageId of the sent message.
        """
        client = self._ensure_client()
        target_queue_url = queue_url or self.queue_url
        
        if not target_queue_url:
            raise ValueError("Queue URL must be provided either in constructor or method call")
        
        try:
            message_params = {
                'QueueUrl': target_queue_url,
                'MessageBody': json.dumps(message_body),
                'DelaySeconds': delay_seconds
            }
            
            # Add FIFO queue specific parameters if provided
            if message_group_id:
                message_params['MessageGroupId'] = message_group_id
            
            if message_deduplication_id:
                message_params['MessageDeduplicationId'] = message_deduplication_id
            
            response = client.send_message(**message_params)
            
            message_id = response['MessageId']
            self.logger.info(f"Sent message {message_id} to queue {target_queue_url}")
            return message_id
            
        except ClientError as e:
            self.logger.error(f"Failed to send message to queue {target_queue_url}: {str(e)}")
            raise

    def receive_messages(
        self,
        queue_url: Optional[str] = None,
        max_messages: int = 1,
        wait_time_seconds: int = 0,
        visibility_timeout_seconds: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Receive messages from SQS queue.
        Returns a list of message dictionaries.
        """
        client = self._ensure_client()
        target_queue_url = queue_url or self.queue_url
        
        if not target_queue_url:
            raise ValueError("Queue URL must be provided either in constructor or method call")
        
        try:
            receive_params = {
                'QueueUrl': target_queue_url,
                'MaxNumberOfMessages': min(max_messages, 10),  # SQS limit is 10
                'WaitTimeSeconds': wait_time_seconds,
                'MessageAttributeNames': ['All']
            }
            
            if visibility_timeout_seconds is not None:
                receive_params['VisibilityTimeout'] = visibility_timeout_seconds
            
            response = client.receive_message(**receive_params)
            
            messages = response.get('Messages', [])
            
            # Parse message bodies from JSON
            for message in messages:
                try:
                    message['ParsedBody'] = json.loads(message['Body'])
                except json.JSONDecodeError:
                    message['ParsedBody'] = message['Body']  # Keep original if not JSON
            
            self.logger.info(f"Received {len(messages)} messages from queue {target_queue_url}")
            return messages
            
        except ClientError as e:
            self.logger.error(f"Failed to receive messages from queue {target_queue_url}: {str(e)}")
            raise

    def delete_message(
        self,
        receipt_handle: str,
        queue_url: Optional[str] = None
    ) -> bool:
        """
        Delete a message from the queue after processing.
        Returns True if deletion was successful.
        """
        client = self._ensure_client()
        target_queue_url = queue_url or self.queue_url
        
        if not target_queue_url:
            raise ValueError("Queue URL must be provided either in constructor or method call")
        
        try:
            client.delete_message(
                QueueUrl=target_queue_url,
                ReceiptHandle=receipt_handle
            )
            
            self.logger.info(f"Deleted message with receipt handle {receipt_handle[:20]}...")
            return True
            
        except ClientError as e:
            self.logger.error(f"Failed to delete message from queue {target_queue_url}: {str(e)}")
            return False

    def get_queue_attributes(self, queue_url: Optional[str] = None) -> Dict[str, Any]:
        """
        Get queue attributes like message count, etc.
        """
        client = self._ensure_client()
        target_queue_url = queue_url or self.queue_url
        
        if not target_queue_url:
            raise ValueError("Queue URL must be provided either in constructor or method call")
        
        try:
            response = client.get_queue_attributes(
                QueueUrl=target_queue_url,
                AttributeNames=['All']
            )
            
            return response.get('Attributes', {})
            
        except ClientError as e:
            self.logger.error(f"Failed to get queue attributes for {target_queue_url}: {str(e)}")
            raise

    def create_queue(
        self,
        queue_name: str,
        attributes: Optional[Dict[str, str]] = None,
        is_fifo: bool = False
    ) -> str:
        """
        Create a new SQS queue.
        Returns the queue URL.
        """
        client = self._ensure_client()
        
        try:
            if is_fifo and not queue_name.endswith('.fifo'):
                queue_name += '.fifo'
            
            create_params = {'QueueName': queue_name}
            
            if attributes:
                create_params['Attributes'] = attributes
            elif is_fifo:
                create_params['Attributes'] = {
                    'FifoQueue': 'true',
                    'ContentBasedDeduplication': 'true'
                }
            
            response = client.create_queue(**create_params)
            queue_url = response['QueueUrl']
            
            self.logger.info(f"Created queue {queue_name} with URL {queue_url}")
            return queue_url
            
        except ClientError as e:
            self.logger.error(f"Failed to create queue {queue_name}: {str(e)}")
            raise

    def test_connection(self) -> bool:
        """Quick check that SQS is reachable."""
        try:
            self._ensure_client()
            return True
        except Exception:
            return False

