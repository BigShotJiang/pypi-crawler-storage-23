"""
Pydantic schemas for the NL-to-SQL query service.
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class StructuredQueryResult(BaseModel):
    """LLM output schema for SQL generation."""

    model_config = {"extra": "forbid"}

    reasoning: str = Field(
        ...,
        description=(
            "Brief explanation of your query strategy: which pattern you chose, "
            "why, and what the results will represent."
        ),
    )

    sql_query: str = Field(
        ...,
        description=(
            "A single valid Athena SQL query. Must use fully qualified table names "
            "like awsdatacatalog.\"database\".\"table\". Do not include trailing semicolons."
        ),
    )

    expects_multiple_rows: bool = Field(
        ...,
        description="True if the query is expected to return multiple rows.",
    )

    result_description: str = Field(
        ...,
        description="One-line description of what each row in the result represents.",
    )
