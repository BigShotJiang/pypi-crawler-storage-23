"""
EntityConsolidator – merges new extraction data into the entity master record.

Responsibilities:
- Update aggregate counters (total_documents, total_mentions, etc.)
- Resolve attribute conflicts (recency, confidence, detail-level)
- Track attribute changes in ``entity_attributes_history`` (MongoDB)
- Maintain financial / metric aggregates per entity
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from connectors.mongodb_connector import MongoDBConnector

logger = logging.getLogger(__name__)

MASTER_COLLECTION = "entities_master"
HISTORY_COLLECTION = "entity_attributes_history"


class EntityConsolidator:
    """Consolidate extraction data into the canonical entity master."""

    def __init__(self):
        self.mongodb = MongoDBConnector()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def consolidate(
        self,
        entity_id: str,
        tenant_id: str,
        document_id: str,
        extractions: List[Dict[str, Any]],
    ) -> None:
        """
        Merge *extractions* (rows from extracted_data belonging to one entity)
        into the entity master record.

        Parameters
        ----------
        entity_id : str
            Canonical entity ID from EntityResolver.
        tenant_id : str
            Tenant isolation key.
        document_id : str
            Source document that produced these extractions.
        extractions : list[dict]
            Extraction rows whose ``entity_name`` resolved to *entity_id*.
        """
        if not extractions:
            return

        current = self.mongodb.find_one_document(
            MASTER_COLLECTION,
            {"entity_id": entity_id, "tenant_id": tenant_id},
        )
        if not current:
            logger.warning("Entity %s not found in master – skipping consolidation", entity_id)
            return

        now = datetime.now(timezone.utc).isoformat()
        updates: Dict[str, Any] = {"updated_at": now}
        set_ops: Dict[str, Any] = {}
        add_to_set_ops: Dict[str, Any] = {}
        inc_ops: Dict[str, Any] = {}

        # --- 1. Aggregate counters ---
        inc_ops["total_mentions"] = len(extractions)

        # Add document to source list
        add_to_set_ops["source_document_ids"] = document_id

        # total_documents needs conditional increment
        if document_id not in current.get("source_document_ids", []):
            inc_ops["total_documents"] = 1

        # last_seen_date
        set_ops["last_seen_date"] = now

        # --- 2. Merge attributes (with conflict resolution + history) ---
        current_attrs = current.get("attributes", {})
        for ext in extractions:
            key = ext.get("key")
            if not key:
                continue

            new_value = (
                ext.get("value_string")
                or str(ext.get("value_number") or "")
                or str(ext.get("value_date") or "")
            )
            if not new_value:
                continue

            old_value = current_attrs.get(key)
            if old_value == new_value:
                continue  # no change

            accepted = self._resolve_conflict(
                key, old_value, new_value,
                old_confidence=current.get("confidence_score", 0.5),
                new_confidence=ext.get("confidence", 0.5),
            )

            if accepted != old_value:
                set_ops[f"attributes.{key}"] = accepted

                # Track history
                self._track_change(
                    entity_id=entity_id,
                    tenant_id=tenant_id,
                    attribute_key=key,
                    old_value=old_value,
                    new_value=accepted,
                    document_id=document_id,
                    extraction_id=ext.get("extraction_id", ""),
                    confidence=ext.get("confidence", 0.5),
                )

        # --- 3. Financial aggregates ---
        for ext in extractions:
            if ext.get("data_type") == "metric" and ext.get("value_number") is not None:
                cat = (ext.get("category") or "").lower()
                if cat == "financial" or (ext.get("unit") or "").upper() in (
                    "USD", "EUR", "GBP", "INR", "JPY",
                ):
                    inc_ops.setdefault("total_metric_value", 0)
                    inc_ops["total_metric_value"] += ext["value_number"]

        # --- 4. Build MongoDB update ---
        update_payload: Dict[str, Any] = {}
        if set_ops:
            set_ops["updated_at"] = now
            update_payload["$set"] = set_ops
        if inc_ops:
            update_payload["$inc"] = inc_ops
        if add_to_set_ops:
            update_payload["$addToSet"] = add_to_set_ops

        if update_payload:
            self.mongodb.update_document(
                MASTER_COLLECTION,
                {"entity_id": entity_id, "tenant_id": tenant_id},
                update_payload,
            )
            logger.debug(
                "Consolidated %d extractions into entity %s",
                len(extractions), entity_id,
            )

    # ------------------------------------------------------------------
    # Conflict resolution
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_conflict(
        key: str,
        old_value: Optional[str],
        new_value: str,
        old_confidence: float = 0.5,
        new_confidence: float = 0.5,
    ) -> str:
        """
        Decide which value to keep when old and new disagree.

        Strategy priority:
        1. Higher confidence wins (if delta > 0.1).
        2. More detailed value wins (significantly longer string).
        3. Most recent wins (tie-breaker).
        """
        if old_value is None:
            return new_value

        # Confidence
        if new_confidence > old_confidence + 0.1:
            return new_value
        if old_confidence > new_confidence + 0.1:
            return old_value

        # Detail level
        if isinstance(new_value, str) and isinstance(old_value, str):
            if len(new_value) > len(old_value) * 1.5:
                return new_value

        # Recency (new wins)
        return new_value

    # ------------------------------------------------------------------
    # History tracking
    # ------------------------------------------------------------------

    def _track_change(
        self,
        entity_id: str,
        tenant_id: str,
        attribute_key: str,
        old_value: Optional[str],
        new_value: str,
        document_id: str,
        extraction_id: str,
        confidence: float = 0.5,
    ) -> None:
        """Write a row to ``entity_attributes_history``."""
        import uuid as _uuid

        record = {
            "history_id": str(_uuid.uuid4()),
            "entity_id": entity_id,
            "tenant_id": tenant_id,
            "attribute_key": attribute_key,
            "old_value": old_value,
            "new_value": new_value,
            "change_type": "added" if old_value is None else "updated",
            "changed_at": datetime.now(timezone.utc).isoformat(),
            "document_id": document_id,
            "extraction_id": extraction_id,
            "confidence": confidence,
            "reason": "Higher confidence or more detailed information",
        }
        try:
            self.mongodb.insert_document(HISTORY_COLLECTION, record)
        except Exception:
            logger.warning(
                "Failed to write attribute history for entity %s key %s",
                entity_id, attribute_key,
            )
