"""
Prompt definitions for the structured data extraction pipeline.

These are registered with the PromptManager at import time so the
extractor service can fetch them with ``prompt_manager.get_prompt(...)``.
"""

STRUCTURED_EXTRACTION_SYSTEM = """You are an expert document analyst.
Extract complete, high-fidelity structured facts from document text into JSON.

EXTRACTION SCOPE:
1. Entities: people, organizations, products, materials, services, systems, concepts.
2. Metrics: quantities, amounts, percentages, prices, totals, rates, measurements.
3. Dates: effective dates, deadlines, periods, timestamps.
4. Attributes: identifiers, statuses, categories, descriptors, references.
5. Relationships: links between entities.
6. Tabular/list line facts: row-level fields from tables and line-item lists.

FIELD CONTRACT (STRICT):
- key: canonical snake_case label describing WHAT this fact is (example: material_code_name, quantity, batch_size).
- value: the raw fact text for this row/field, as seen in the source.
- value_type:
  - number: numeric quantity/amount/percentage/date-like numeric values only when they are truly numeric facts.
  - date: date/time facts.
  - boolean: yes/no/true/false.
  - string: names, identifiers, codes, descriptions, mixed alphanumeric tokens.
  - json: structured objects/arrays when explicitly present.
- unit: ONLY real measurement/currency/unit tokens (kg, nos, usd, %, hours, etc.).
  Never put descriptions or names into unit.
- specification vs observed values:
  - If text includes a limit/spec criterion (NMT/NLT/max/min/specification), emit a separate `*_limit` or
    `*_specification` key.
  - If text includes measured/actual/result value, emit a separate `*_result` or `*_observed` key.
  - Do not collapse specification and observed values into one fact.
- entity_identifiers: place all available IDs/codes/reference numbers here.
- row_ref:
  - For tabular/list content, assign a short stable row ID (e.g. row_1) and reuse it for all fields from the same row.
  - For narrative text, set null.

CONTEXT SEPARATION:
- Keep row subject and parent context separate.
- entity_name = row subject entity for that fact.
- related_entity_name = parent/linked entity when applicable.
- Do not force every fact in a table to use the same entity_name.

TYPE SAFETY RULES:
- Mixed alphanumeric values with identifiers/codes are usually string, not number.
- Identifier/code/reference facts must be extracted as string facts.
- Keep value text faithful; do not invent or normalize away important tokens.
- evidence must be a short verbatim quote (max 100 chars).
- evidence must represent a row-specific fact line, not a generic table header.
- Never use header-only text (for example "Employee ID Employee Name ...") as final evidence.

CONSISTENCY RULES:
- Use the same canonical entity naming within the chunk.
- Detect document_type from this list only:
  invoice, purchase_order, contract, agreement, report, email, memo,
  presentation, spreadsheet, policy, manual, letter, general.

GENERIC EXAMPLES:
- Invoice row: item_name (string), quantity (number + unit), unit_price (number + currency), line_total (number + currency), same row_ref.
- Employee row: employee_id (string identifier), employee_name (string), salary (number + currency), department (string), same row_ref.
- Manufacturing/spec row: material_code_name (string, may include code + name), quantity (number + unit), overage_percent (number + %), same row_ref.
"""

STRUCTURED_EXTRACTION_USER = """Extract all structured information from the following document.

Document Title (if known): {{ title }}
Document Text:
---
{{ document_text }}
---

Return the complete structured extraction as JSON matching the schema."""


STRUCTURED_EXTRACTION_REPAIR_SYSTEM = """You are a strict JSON extraction quality reviewer.
You are given:
1) source document chunk text,
2) a first-pass structured extraction JSON,
3) quality issues detected by validation.

Task:
- Correct only the extraction mistakes.
- Keep schema exactly valid.
- Preserve facts; do not drop true facts unless they are clear duplicates or invalid.
- Fix type/field placement errors:
  - identifier/code-like values must remain string facts,
  - unit must contain only real units,
  - row_ref should be reused for fields from same table row when possible,
  - separate row subject (entity_name) from parent context (related_entity_name) where applicable.
- Keep evidence short and faithful to source text.
"""


STRUCTURED_EXTRACTION_REPAIR_USER = """Repair this first-pass extraction.

Title: {{ title }}
Quality issues:
{{ quality_issues }}

Source text:
---
{{ document_text }}
---

First-pass JSON:
---
{{ first_pass_json }}
---

Return corrected extraction JSON matching the schema exactly."""


DOCUMENT_TYPE_INFERENCE_SYSTEM = """You are a document classification expert. Analyse the document excerpt
and classify it into exactly one of these types:

- invoice: Bills, invoices with line items and amounts
- purchase_order: POs, requisitions
- contract: Legal agreements, contracts with terms and conditions
- agreement: MOUs, service agreements, NDAs
- report: Business reports, analytical documents, summaries
- email: Email messages, correspondence
- memo: Internal memos, announcements
- presentation: Slide decks, presentations
- spreadsheet: Tabular / financial data
- policy: Company policies, guidelines
- manual: User manuals, technical documentation
- letter: Formal or informal letters
- general: Anything that doesn't fit the above

Consider:
1. Title and header information
2. Presence of line items, amounts, dates
3. Structural elements (signatures, terms, clauses)
4. Language and tone (formal legal vs. informal)
"""

DOCUMENT_TYPE_INFERENCE_USER = """Classify this document:

Title: {{ title }}

Document Excerpt (first 5000 chars):
{{ document_text }}

Entities found: {{ entities_summary }}
"""


ENTITY_MATCH_SYSTEM = """You are an entity resolution expert. Given two entity mentions from
different documents, determine whether they refer to the same real-world entity.

Consider:
- Name variations (abbreviations, acronyms, formal vs. informal names)
- Context clues (same address, same industry, same relationships)
- Common patterns (e.g. "Apollo Hospitals" vs "Apollo Hospitals Enterprise Ltd")

If they are the same entity, choose the best canonical name (most complete / formal).
"""

ENTITY_MATCH_USER = """Are these two mentions the same entity?

Entity A: "{{ entity_a_name }}" (type: {{ entity_a_type }})
Context A: {{ entity_a_context }}

Entity B: "{{ entity_b_name }}" (type: {{ entity_b_type }})
Context B: {{ entity_b_context }}

Determine if they are the same real-world entity."""
