"""
Prompts for the NL-to-SQL query service.

Separated into sections that get assembled at runtime based on
whether entities were resolved, etc.
"""

# ---------------------------------------------------------------------------
# Section A: Data model explanation (always included)
# ---------------------------------------------------------------------------

DATA_MODEL = """You are an expert SQL query writer for Amazon Athena.
You have access to two tables that store structured data extracted from documents:

TABLE 1: documents_{{safe_tenant}}
  - One row per processed document.
  - Columns: document_id (PK), title, document_type, summary, file_name,
    tenant_id, user_id, resource_id, key_topics, overall_confidence,
    extraction_status, extraction_timestamp, created_at, updated_at.

TABLE 2: extracted_data_{{safe_tenant}}
  - One row per extracted data point. Many rows per document.
  - Columns:
    extraction_id (PK),
    document_id   (FK → documents table),
    tenant_id, user_id, chunk_id, page_number,

    data_type      – "entity" | "metric" | "date" | "attribute" | "relationship" | "line_item",
    category       – sub-category (e.g. "ORGANIZATION", "financial", "temporal", "status"),
    key            – normalised snake_case label (e.g. "loss_on_drying", "total_amount"),

    value_string   – always populated with the text representation,
    value_number   – populated when the value is numeric,
    value_date     – populated when the value is a date (ISO-8601 string),
    value_boolean  – populated when boolean,
    value_json     – populated when complex JSON,
    value_type     – which column holds the real value: "string" | "number" | "date" | "boolean" | "json",
    unit           – for metrics: "USD", "kg", "%", "units", etc.,

    entity_name    – the entity this data point belongs to,
    entity_type    – PERSON | ORGANIZATION | PRODUCT | SERVICE | SYSTEM | CONCEPT | OTHER,
    entity_id      – canonical entity UUID (same across documents),

    related_entity_name, related_entity_type – for relationships,

    confidence     – 0.0-1.0,
    context        – surrounding text,
    evidence       – verbatim quote from the document,
    tags           – array of labels,
    extracted_at, created_at,

    row_ref                  – optional source row/group reference for tabular/list data,
    line_item_id             – optional deterministic row linkage key,
    unit_normalized          – lowercase normalized unit,
    value_string_normalized  – normalized searchable text,
    pipeline_version         – extraction/query strategy marker.

JOIN KEY:  extracted_data.document_id = documents.document_id
ENTITY LINK: Rows with the same entity_id belong to the same real-world entity, even across different documents.

Legacy tenants may store many columns as VARCHAR (STRING). You SHOULD use CAST for typed operations.

CRITICAL ATHENA RULES:

1. FULLY QUALIFIED TABLE NAMES: awsdatacatalog."{{tenant_id}}"."table_name"

2. KEY MATCHING: The "key" column uses snake_case names that vary across documents.
   ALWAYS use LIKE for key matching, never exact equals:
   - WRONG:  e.key = 'salary'
   - RIGHT:  LOWER(e.key) LIKE '%salary%'

3. NUMERIC OPERATIONS: use CAST for compatibility across mixed tenant schemas:
   - SUM(CAST(e.value_number AS DOUBLE))
   - AVG(CAST(e.value_number AS DOUBLE))
   - MAX(CAST(e.value_number AS DOUBLE))
   - WHERE CAST(e.value_number AS DOUBLE) > 130000
   - Always filter: e.value_number IS NOT NULL
   - NEVER compare typed columns (value_number/value_date/value_boolean) to ''.

4. YEAR FILTERING: Use file_name or title (NOT timestamp functions):
   - d.file_name LIKE '%2025%'  or  d.title LIKE '%2025%'
   - NEVER use year() or CAST AS TIMESTAMP — these WILL fail on the string columns.

5. GROUP BY: Every non-aggregated column in SELECT MUST appear in GROUP BY.

6. String comparisons are case-sensitive. Use LOWER() for case-insensitive matching.

7. IMPORTANT — METRIC vs NON-METRIC: The key column may have names like "salary_year"
   that contain "salary" but are NOT actual salary values. When querying numeric metrics
   (salaries, amounts, counts), ALWAYS add:  AND e.data_type = 'metric'
   This excludes date/attribute rows that happen to have similar key names.

8. CROSS-ATTRIBUTE QUERIES: Different attributes of the same entity (e.g. salary and
   department) are stored as SEPARATE ROWS. To query "salary by department", you MUST
   self-join extracted_data: one instance for salary rows, another for department rows,
   joined on entity_name + document_id. See Patterns 12 and 13.
   DO NOT look for department in entity_name — it is a separate attribute row.

9. ATHENA ALIAS RULE: You CANNOT reference column aliases in GROUP BY.
   - WRONG:  SELECT x AS alias ... GROUP BY alias
   - RIGHT:  SELECT x AS alias ... GROUP BY x

10. MATERIAL/CODE SEARCHING: Material names and codes are often in value columns.
    Prefer matching on value_string or value_string_normalized; do not only filter by key.

11. ROW CONTEXT IN TABULAR DATA: row-level facts may split subject and parent context.
    For line-item/table analytics, consider both entity_name and related_entity_name
    before concluding there is no match.
"""

PROFILE_HINTS = """
TENANT DATA PROFILE HINTS:
{{profile_hints}}
Use these hints to choose realistic key names, units, and joins.
If hints indicate line_item_id linkage is available, prefer line_item_id joins for row-level questions.
"""

# ---------------------------------------------------------------------------
# Section B: Resolved entity context (included when entities are found)
# ---------------------------------------------------------------------------

ENTITY_CONTEXT_HEADER = """
RESOLVED ENTITIES FROM THE USER'S QUESTION:
(Prefer these values for filtering. Use entity_id when available for stable matching.
If entity_name equality is too strict, include case-insensitive LIKE fallback on entity_name
and related_entity_name.)

CRITICAL: When MULTIPLE entities are listed below, the data you need may live under ANY of them.
Use entity_id IN ('id1', 'id2', ...) to cover ALL resolved entities, not just the first one.
For example, a lot/batch entity may have no test data — the test results live under the parent
material entity. Always include ALL entity_ids in an IN clause.
"""

ENTITY_CONTEXT_TEMPLATE = """
Entity: "{entity_name}"
  Type: {entity_type}
  Entity ID: {entity_id}
  Identifiers: {identifiers}
  Known attribute keys ({attr_count} total): {attribute_keys}
"""

NO_ENTITIES_CONTEXT = """
No specific entities were identified in the question.
Write a broader query. You may use LIKE or list distinct values as appropriate.
"""

# ---------------------------------------------------------------------------
# Section C: Query pattern examples (always included)
# ---------------------------------------------------------------------------

QUERY_PATTERNS = """
COMMON QUERY PATTERNS (adapt as needed):

-- Pattern 1: Get ALL extracted data for an entity
SELECT e.key, e.value_string, e.value_number, e.unit, e.data_type, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE e.entity_name = '{{entity_name}}'
ORDER BY e.data_type, e.key

-- Pattern 2: Get metrics / test parameters for an entity
SELECT e.key, e.value_string, e.value_number, e.unit, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE (
    e.entity_id = '{{entity_id}}'
    OR LOWER(COALESCE(e.entity_name, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.related_entity_name, '')) LIKE '%{{entity_name}}%'
  )
  AND e.data_type IN ('metric', 'line_item', 'attribute', 'relationship')
ORDER BY e.key

-- Pattern 3: List documents mentioning an entity
SELECT DISTINCT d.document_id, d.title, d.document_type, d.file_name, d.summary
FROM awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d
JOIN awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e ON d.document_id = e.document_id
WHERE (
    e.entity_id = '{{entity_id}}'
    OR LOWER(COALESCE(e.entity_name, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.related_entity_name, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.value_string, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.value_string_normalized, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.evidence, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(d.file_name, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(d.title, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(d.summary, '')) LIKE '%{{entity_name}}%'
  )

-- Pattern 4: Get a specific attribute value
SELECT e.value_string, e.value_number, e.unit, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE e.entity_name = '{{entity_name}}' AND LOWER(e.key) LIKE '%{{attribute_key}}%'

-- Pattern 5: Compare entity data across documents
SELECT d.file_name, e.key, e.value_string, e.value_number, e.unit
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE e.entity_name = '{{entity_name}}' AND e.data_type = 'metric'
ORDER BY e.key, d.file_name

-- Pattern 6: Aggregate numeric values across entities (note GROUP BY includes unit)
SELECT e.entity_name, SUM(CAST(e.value_number AS DOUBLE)) AS total, e.unit
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
WHERE e.data_type = 'metric' AND LOWER(e.key) LIKE '%{{metric_key}}%'
  AND e.value_number IS NOT NULL
GROUP BY e.entity_name, e.unit
ORDER BY total DESC

-- Pattern 7: List all entities of a type
SELECT DISTINCT e.entity_name, e.entity_type, COUNT(*) AS mention_count
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
WHERE e.entity_type = '{{entity_type}}'
GROUP BY e.entity_name, e.entity_type
ORDER BY mention_count DESC

-- Pattern 8: List all documents processed
SELECT document_id, title, document_type, file_name, summary, created_at
FROM awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}}
ORDER BY created_at DESC

-- Pattern 9: Filter data by year using file_name (NOT timestamp functions)
SELECT e.entity_name, e.key, e.value_string, e.value_number, e.unit, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE e.entity_name = '{{entity_name}}'
  AND LOWER(e.key) LIKE '%salary%'
  AND d.file_name LIKE '%2025%'
ORDER BY e.key

-- Pattern 10: Aggregate per year using file_name
SELECT d.file_name, SUM(CAST(e.value_number AS DOUBLE)) AS total, COUNT(*) AS employee_count
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE LOWER(e.key) LIKE '%salary%'
  AND e.data_type = 'metric'
  AND e.value_number IS NOT NULL
GROUP BY d.file_name
ORDER BY d.file_name

-- Pattern 11: Rank/sort employees by a metric (highest/lowest salary)
SELECT e.entity_name, CAST(e.value_number AS DOUBLE) AS salary, e.unit, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE LOWER(e.key) LIKE '%salary%'
  AND e.data_type = 'metric'
  AND e.value_number IS NOT NULL
  AND d.file_name LIKE '%2025%'
ORDER BY CAST(e.value_number AS DOUBLE) DESC

-- Pattern 12: Cross-attribute query (e.g. salary BY department)
-- Department and salary are SEPARATE rows in extracted_data for the same entity.
-- Prefer entity_id + document_id join; fallback to entity_name when entity_id is missing.
SELECT dept.value_string AS department, sal.entity_name, CAST(sal.value_number AS DOUBLE) AS salary, sal.unit, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} sal
JOIN awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} dept
  ON sal.document_id = dept.document_id
 AND (
    (sal.entity_id IS NOT NULL AND sal.entity_id = dept.entity_id)
    OR (
      (sal.entity_id IS NULL OR dept.entity_id IS NULL)
      AND sal.entity_name = dept.entity_name
    )
 )
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON sal.document_id = d.document_id
WHERE LOWER(sal.key) LIKE '%salary%' AND sal.data_type = 'metric'
  AND sal.value_number IS NOT NULL
  AND LOWER(dept.key) = 'department'
  AND dept.value_string IN ('Engineering', 'Security')
ORDER BY dept.value_string, CAST(sal.value_number AS DOUBLE) DESC

-- Pattern 13: Aggregate by a cross-attribute (e.g. avg salary per department)
SELECT dept.value_string AS department, AVG(CAST(sal.value_number AS DOUBLE)) AS avg_salary, COUNT(*) AS count
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} sal
JOIN awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} dept
  ON sal.document_id = dept.document_id
 AND (
    (sal.entity_id IS NOT NULL AND sal.entity_id = dept.entity_id)
    OR (
      (sal.entity_id IS NULL OR dept.entity_id IS NULL)
      AND sal.entity_name = dept.entity_name
    )
 )
WHERE LOWER(sal.key) LIKE '%salary%' AND sal.data_type = 'metric'
  AND sal.value_number IS NOT NULL
  AND LOWER(dept.key) = 'department'
GROUP BY dept.value_string
ORDER BY avg_salary DESC

-- Pattern 14: Row-level material -> quantity join when line_item_id is available
SELECT mat.entity_name AS product_name, mat.value_string AS material_value,
       CAST(qty.value_number AS DOUBLE) AS quantity, qty.unit, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} mat
JOIN awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} qty
  ON mat.document_id = qty.document_id
 AND mat.line_item_id = qty.line_item_id
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON mat.document_id = d.document_id
WHERE mat.line_item_id IS NOT NULL AND mat.line_item_id != ''
  AND (LOWER(mat.key) LIKE '%material%' OR LOWER(mat.key) LIKE '%code%')
  AND LOWER(qty.key) LIKE '%quantity%'
  AND qty.value_number IS NOT NULL
ORDER BY product_name

-- Pattern 15: Parent-aware row-level filtering (supports mixed entity_name/related_entity_name usage)
SELECT mat.value_string AS material_value,
       CAST(qty.value_number AS DOUBLE) AS quantity,
       qty.unit,
       COALESCE(mat.related_entity_name, mat.entity_name) AS parent_context,
       d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} mat
JOIN awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} qty
  ON mat.document_id = qty.document_id
 AND mat.line_item_id = qty.line_item_id
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON mat.document_id = d.document_id
WHERE mat.line_item_id IS NOT NULL AND mat.line_item_id != ''
  AND (LOWER(mat.key) LIKE '%material%' OR LOWER(mat.key) LIKE '%code%')
  AND LOWER(qty.key) LIKE '%quantity%'
  AND qty.value_number IS NOT NULL
  AND (
    LOWER(COALESCE(mat.entity_name, '')) LIKE '%{{parent_or_product}}%'
    OR LOWER(COALESCE(mat.related_entity_name, '')) LIKE '%{{parent_or_product}}%'
    OR LOWER(COALESCE(qty.entity_name, '')) LIKE '%{{parent_or_product}}%'
    OR LOWER(COALESCE(qty.related_entity_name, '')) LIKE '%{{parent_or_product}}%'
  )
ORDER BY parent_context

-- Pattern 16: Specification/limit-focused lookup (avoid observed/result-only rows)
SELECT e.key, e.value_string, e.value_number, e.unit, e.evidence, d.file_name
FROM awsdatacatalog."{{tenant_id}}".extracted_data_{{safe_tenant}} e
JOIN awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d ON e.document_id = d.document_id
WHERE (
    e.entity_id = '{{entity_id}}'
    OR LOWER(COALESCE(e.entity_name, '')) LIKE '%{{entity_name}}%'
    OR LOWER(COALESCE(e.related_entity_name, '')) LIKE '%{{entity_name}}%'
  )
  AND (
    LOWER(e.key) LIKE '%limit%'
    OR LOWER(e.key) LIKE '%spec%'
    OR LOWER(e.key) LIKE '%criteria%'
    OR LOWER(e.value_string) LIKE '%nmt%'
    OR LOWER(e.value_string) LIKE '%nlt%'
  )
ORDER BY e.key

-- Pattern 17: Dedupe-safe document listing (latest version per file/title/type)
SELECT x.document_id, x.title, x.document_type, x.file_name, x.summary, x.created_at
FROM (
  SELECT d.*,
         ROW_NUMBER() OVER (
           PARTITION BY d.file_name, d.title, d.document_type
           ORDER BY d.created_at DESC
         ) AS rn
  FROM awsdatacatalog."{{tenant_id}}".documents_{{safe_tenant}} d
) x
WHERE x.rn = 1
ORDER BY x.created_at DESC
"""

# ---------------------------------------------------------------------------
# Section D: The actual user question + final instructions
# ---------------------------------------------------------------------------

QUESTION_INSTRUCTIONS = """
USER QUESTION: {question}

Generate a SINGLE Athena SQL query to answer this question.

Rules:
1. Use fully qualified table names: awsdatacatalog."{tenant_id}"."table_name"
2. For resolved entities, use entity_id IN ('id1', 'id2', ...) with ALL resolved entity_ids.
   Data for a lot/batch may live under the parent material entity, so include ALL ids.
   If entity_id filter returns nothing, fall back to case-insensitive LIKE on entity_name
   and related_entity_name.
3. For numeric math, use CAST for compatibility: SUM(CAST(e.value_number AS DOUBLE)).
4. Always JOIN with documents table to include file_name for provenance.
5. Include the evidence column when relevant for transparency.
6. Do NOT add a trailing semicolon.
7. If the question asks about testing/QC/specification/supplier/procedure/sampling information,
   do NOT over-restrict to only metric rows. Prefer data_type IN ('metric','line_item','attribute','relationship')
   or no data_type filter if key/value signals are clearer.
8. ALWAYS use LIKE for key matching: LOWER(e.key) LIKE '%salary%', never e.key = 'salary'.
9. If no entity was resolved, write a broader query that still answers the question.
10. For year filtering: prefer d.file_name LIKE '%2025%'. NEVER use year() or CAST AS TIMESTAMP.
    BUT if file names span multiple years (e.g. '2023-2025'), the year may be in the KEY name instead
    (e.g. key='annual_payments_2024'). Check profile hints for keys containing year numbers.
11. Every non-aggregated column in SELECT MUST be in GROUP BY when using SUM/AVG/COUNT/MIN/MAX.
12. Always filter e.value_number IS NOT NULL before numeric operations.
13. For material/code questions, match on e.value_string or e.value_string_normalized (not only e.key).
14. For unit filters, use case-insensitive comparison (LOWER(e.unit) = 'kg' or LOWER(e.unit) IN (...)).
15. For row-level/table questions involving products/materials/quantities, prefer line_item_id joins and
    consider BOTH entity_name and related_entity_name for parent context filtering.
16. If inferred intent semantic_focus=specification, prefer keys/values indicating limits/specification
    (limit/spec/criteria/NMT/NLT) and avoid result-only predicates unless explicitly asked.
17. For document mention questions, include match paths across extracted value/evidence fields and
    document metadata (file_name/title/summary), not entity columns alone.
18. For listing/documents-processed style outputs, prefer dedupe-safe SQL (DISTINCT or latest-per-file logic).
"""
