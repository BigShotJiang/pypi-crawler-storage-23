"""
QuerySQLGenerator – Prompt assembly and LLM SQL generation.

Builds the full prompt from data model, entity context, profile hints,
intent, and query patterns, then calls the LLM to generate Athena SQL.
"""

import logging
import os
import time
from typing import Any, Dict, List, Optional

from app.config.llm import LLMModelCategory
from llm.manager import LLMManager, LLMType
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .feature_flags import env_int
from .query_intent import (
    QueryIntent,
    format_intent_context,
    parse_query_intent,
)
from .query_schemas import StructuredQueryResult
from . import query_prompts as QP

logger = logging.getLogger(__name__)

_DEFAULT_QUERY_MODEL = "gpt-5.2"
_DEFAULT_PROFILE_HINTS_TTL_SECONDS = 300
_QUERY_PROFILE_CACHE: Dict[str, tuple[float, str]] = {}


class QuerySQLGenerator:
    """Prompt assembly + LLM SQL generation for NL-to-SQL."""

    def __init__(self, llm_manager: LLMManager, execute_athena_fn=None):
        self.llm_manager = llm_manager
        # Athena execute function injected for profile-hint sampling
        self._execute_athena = execute_athena_fn

    def build_prompt(
        self,
        question: str,
        entities: List[Dict[str, Any]],
        tenant_id: str,
        profile_hints: Optional[str] = None,
        intent: Optional[QueryIntent] = None,
    ) -> str:
        """Assemble the full prompt from sections."""
        safe_tenant = tenant_id.replace("-", "_")

        # Section A: Data model
        data_model = QP.DATA_MODEL.replace("{{safe_tenant}}", safe_tenant).replace(
            "{{tenant_id}}", tenant_id
        )

        # Section B: Entity context
        if entities:
            entity_section = QP.ENTITY_CONTEXT_HEADER
            for ent in entities:
                entity_section += QP.ENTITY_CONTEXT_TEMPLATE.format(
                    entity_name=ent["entity_name"],
                    entity_type=ent["entity_type"],
                    entity_id=ent["entity_id"],
                    identifiers=ent.get("identifiers", []),
                    attr_count=ent.get("attribute_count", 0),
                    attribute_keys=", ".join(ent.get("attribute_keys", [])[:20]),
                )
        else:
            entity_section = QP.NO_ENTITIES_CONTEXT

        # Section C: Patterns
        patterns = QP.QUERY_PATTERNS.replace("{{safe_tenant}}", safe_tenant).replace(
            "{{tenant_id}}", tenant_id
        )

        profile_section = ""
        if profile_hints:
            profile_section = QP.PROFILE_HINTS.replace("{{profile_hints}}", profile_hints)

        intent_section = format_intent_context(intent or parse_query_intent(question, entities))

        # Section D: Question
        question_section = QP.QUESTION_INSTRUCTIONS.format(
            question=question,
            tenant_id=tenant_id,
        )

        prompt = (
            f"{data_model}\n"
            f"{entity_section}\n"
            f"{profile_section}\n"
            f"{intent_section}\n"
            f"{patterns}\n"
            f"{question_section}"
        )

        # Adapt Athena-specific language for non-Athena backends
        backend = os.getenv("OPENRAG_STORAGE_BACKEND", "athena").lower().strip()
        if backend != "athena":
            prompt = self._adapt_prompt_for_backend(prompt, backend, safe_tenant)

        return prompt

    @staticmethod
    def _adapt_prompt_for_backend(prompt: str, backend: str, safe_tenant: str) -> str:
        """
        Rewrite Athena-specific references in the assembled prompt so the LLM
        generates standard SQL that runs on the chosen backend.

        Changes made:
        - ``awsdatacatalog."schema"."table"``  →  ``"table"``
        - Remaining ``"schema"."table"``        →  ``"table"``
        - "Amazon Athena" role and rule labels  →  backend-neutral equivalents
        - ``CAST(x AS DOUBLE)``                 →  ``CAST(x AS REAL)`` for SQLite
        """
        import re

        # --- Step 1: Neutralise human-readable instructions BEFORE table-ref stripping ---
        # so the regex targets still match their original text.

        prompt = prompt.replace(
            "You are an expert SQL query writer for Amazon Athena.",
            f"You are an expert SQL query writer for {backend.upper()}.",
        )
        prompt = prompt.replace("CRITICAL ATHENA RULES:", "CRITICAL SQL RULES:")
        prompt = prompt.replace(
            "Generate a SINGLE Athena SQL query to answer this question.",
            f"Generate a SINGLE {backend.upper()} SQL query to answer this question.",
        )

        # DATA_MODEL rule 1: "FULLY QUALIFIED TABLE NAMES: awsdatacatalog..."
        prompt = re.sub(
            r'1\.\s*FULLY QUALIFIED TABLE NAMES:.*\n',
            f'1. Use unqualified double-quoted table names, e.g. "extracted_data_{safe_tenant}"\n',
            prompt,
        )
        # QUESTION_INSTRUCTIONS rule 1 (uses Python-formatted tenant_id)
        prompt = re.sub(
            r'1\. Use fully qualified table names: awsdatacatalog\."[^"]*"\."table_name"',
            f'1. Use unqualified double-quoted table names: "extracted_data_{safe_tenant}"',
            prompt,
        )

        # --- Step 2: Strip Athena catalog / schema qualifiers from SQL examples ---

        # awsdatacatalog."schema"."table"  →  "table"
        prompt = re.sub(
            r'\bawsdatacatalog\."[^"]+"\."([^"]+)"',
            r'"\1"',
            prompt,
            flags=re.IGNORECASE,
        )
        # Remaining "schema"."table"  →  "table"
        prompt = re.sub(r'"[^"]+"\."([^"]+)"', r'"\1"', prompt)

        # --- Step 3: Backend-specific SQL dialect fixes ---

        # SQLite: DOUBLE is not a recognised type affinity — use REAL
        if backend == "sqlite":
            prompt = re.sub(
                r'\bCAST\s*\(([^)]+?)\s+AS\s+DOUBLE\s*\)',
                lambda m: f'CAST({m.group(1)} AS REAL)',
                prompt,
                flags=re.IGNORECASE,
            )

        return prompt

    def build_profile_hints(self, tenant_id: str) -> str:
        """Build cached tenant profile hints so SQL generation targets real keys/units."""
        if self._execute_athena is None:
            return "Profile hints unavailable (no Athena executor)."

        ttl_seconds = max(
            30,
            env_int(
                "STRUCTURED_QUERY_PROFILE_HINTS_TTL_SECONDS",
                _DEFAULT_PROFILE_HINTS_TTL_SECONDS,
            ),
        )
        cached = _QUERY_PROFILE_CACHE.get(tenant_id)
        now = time.time()
        if cached and (now - cached[0]) < ttl_seconds:
            return cached[1]

        safe_tenant = tenant_id.replace("-", "_")
        hints: List[str] = []

        key_sql = (
            f"SELECT key, COUNT(*) AS cnt "
            f"FROM extracted_data_{safe_tenant} "
            f"WHERE key IS NOT NULL AND TRIM(key) != '' "
            f"GROUP BY key ORDER BY cnt DESC LIMIT 25"
        )
        key_result = self._execute_athena(key_sql, tenant_id)
        if key_result.get("error"):
            fallback = "Profile hints unavailable (Athena sampling failed)."
            _QUERY_PROFILE_CACHE[tenant_id] = (now, fallback)
            logger.warning(
                "Profile hint sampling failed for tenant=%s: %s",
                tenant_id,
                key_result.get("error"),
            )
            return fallback

        top_keys = self._format_profile_pairs(key_result["rows"], "key", "cnt")
        if top_keys:
            hints.append(f"Top keys: {top_keys}")

        unit_sql = (
            f"SELECT unit, COUNT(*) AS cnt "
            f"FROM extracted_data_{safe_tenant} "
            f"WHERE unit IS NOT NULL AND TRIM(unit) != '' "
            f"GROUP BY unit ORDER BY cnt DESC LIMIT 10"
        )
        unit_result = self._execute_athena(unit_sql, tenant_id)
        if not unit_result.get("error"):
            top_units = self._format_profile_pairs(unit_result["rows"], "unit", "cnt")
            if top_units:
                hints.append(f"Top units: {top_units}")

        type_sql = (
            f"SELECT data_type, COUNT(*) AS cnt "
            f"FROM extracted_data_{safe_tenant} "
            f"WHERE data_type IS NOT NULL AND TRIM(data_type) != '' "
            f"GROUP BY data_type ORDER BY cnt DESC LIMIT 10"
        )
        type_result = self._execute_athena(type_sql, tenant_id)
        if not type_result.get("error"):
            type_dist = self._format_profile_pairs(type_result["rows"], "data_type", "cnt")
            if type_dist:
                hints.append(f"Data type distribution: {type_dist}")

        line_item_sql = (
            f"SELECT COUNT(*) AS linked_rows "
            f"FROM extracted_data_{safe_tenant} "
            f"WHERE line_item_id IS NOT NULL AND TRIM(line_item_id) != ''"
        )
        line_item_result = self._execute_athena(line_item_sql, tenant_id)
        if line_item_result.get("error"):
            hints.append("line_item_id linkage: unavailable")
        else:
            linked_rows = 0
            if line_item_result.get("rows"):
                raw = line_item_result["rows"][0].get("linked_rows", "0")
                try:
                    linked_rows = int(raw)
                except (TypeError, ValueError):
                    linked_rows = 0
            status = "available" if linked_rows > 0 else "present_but_empty"
            hints.append(f"line_item_id linkage: {status} ({linked_rows} rows)")

        if not hints:
            hints.append("No profile hints available.")

        profile = "\n".join(f"- {line}" for line in hints)
        _QUERY_PROFILE_CACHE[tenant_id] = (now, profile)
        return profile

    @staticmethod
    def _format_profile_pairs(
        rows: List[Dict[str, Any]],
        value_key: str,
        count_key: str,
    ) -> str:
        pairs = []
        for row in rows[:10]:
            value = str(row.get(value_key, "")).strip()
            count = str(row.get(count_key, "")).strip()
            if not value:
                continue
            pairs.append(f"{value}({count or '0'})")
        return ", ".join(pairs)

    def generate_sql(
        self,
        prompt: str,
        model_override: Optional[str] = None,
    ) -> Optional[StructuredQueryResult]:
        """Call LLM to generate SQL from the assembled prompt."""
        llm = self.get_query_llm(model_override)

        try:
            result = llm.generate_structured(
                prompt,
                StructuredQueryResult,
                temperature=0.1,
            )
            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception("LLM SQL generation failed")
            return None

    @staticmethod
    def resolve_query_model() -> str:
        model = (os.getenv("STRUCTURED_QUERY_MODEL") or "").strip()
        return model or _DEFAULT_QUERY_MODEL

    def get_query_llm(self, model_override: Optional[str] = None):
        """
        Return the LLM used for SQL generation.

        Provider: respects ``DEFAULT_LLM_PROVIDER`` env var.
        Model: uses ``STRUCTURED_QUERY_MODEL`` / ``model_override`` only when
               the active provider is OpenAI (those model names are OpenAI-specific).
               For other providers the manager picks the category default.
        """
        from app.config.settings import get_settings

        provider = get_settings().DEFAULT_LLM_PROVIDER

        # Only apply an OpenAI-specific model name when actually using OpenAI
        model: Optional[str] = None
        if model_override:
            model = model_override.strip() or None
        elif provider == LLMType.OPENAI:
            model = self.resolve_query_model()

        return self.llm_manager.get_llm(
            provider=provider,
            model=model,
            category=LLMModelCategory.STRUCTURED,
        )
