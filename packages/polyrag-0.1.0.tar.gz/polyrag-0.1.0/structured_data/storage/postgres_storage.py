"""
PostgreSQL storage backend for OpenRAG structured extraction results.

Environment variables:
    OPENRAG_POSTGRES_HOST      (default: localhost)
    OPENRAG_POSTGRES_PORT      (default: 5432)
    OPENRAG_POSTGRES_DB        (default: openrag)
    OPENRAG_POSTGRES_USER      (default: postgres)
    OPENRAG_POSTGRES_PASSWORD  (default: "")
"""

import logging
import os
from typing import Any, Dict, List, Optional

from structured_data.storage.base import (
    BOOLEAN_COLUMNS,
    DOUBLE_COLUMNS,
    INT_COLUMNS,
    TIMESTAMP_COLUMNS,
    StructuredDataStorage,
    prepare_value,
)

logger = logging.getLogger(__name__)


def _pg_type(col: str) -> str:
    """Map column name to PostgreSQL type."""
    if col in DOUBLE_COLUMNS:
        return "DOUBLE PRECISION"
    if col in TIMESTAMP_COLUMNS:
        return "TIMESTAMPTZ"
    if col in BOOLEAN_COLUMNS:
        return "BOOLEAN"
    if col in INT_COLUMNS:
        return "BIGINT"
    return "TEXT"


class PostgresStorage(StructuredDataStorage):
    """Write extraction results to PostgreSQL tables."""

    def __init__(self):
        self._host = os.getenv("OPENRAG_POSTGRES_HOST", "localhost")
        self._port = int(os.getenv("OPENRAG_POSTGRES_PORT", "5432"))
        self._db = os.getenv("OPENRAG_POSTGRES_DB", "openrag")
        self._user = os.getenv("OPENRAG_POSTGRES_USER", "postgres")
        self._password = os.getenv("OPENRAG_POSTGRES_PASSWORD", "")

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def _connect(self):
        import psycopg2
        return psycopg2.connect(
            host=self._host,
            port=self._port,
            dbname=self._db,
            user=self._user,
            password=self._password,
        )

    # ------------------------------------------------------------------
    # Schema management
    # ------------------------------------------------------------------

    def _get_existing_columns(self, table_name: str, cur) -> set:
        cur.execute(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = %s",
            (table_name,),
        )
        return {row[0] for row in cur.fetchall()}

    def _ensure_table(
        self,
        table_name: str,
        rows: List[Dict[str, Any]],
        conn,
        cur,
    ) -> None:
        """Create table if needed, then add any new columns."""
        all_cols: set = set()
        for row in rows:
            all_cols.update(row.keys())

        existing = self._get_existing_columns(table_name, cur)

        if not existing:
            col_defs = ", ".join(
                f'"{c}" {_pg_type(c)}' for c in sorted(all_cols)
            )
            cur.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" ({col_defs})')
            conn.commit()
        else:
            for col in all_cols:
                if col not in existing:
                    cur.execute(
                        f'ALTER TABLE "{table_name}" ADD COLUMN IF NOT EXISTS '
                        f'"{col}" {_pg_type(col)}'
                    )
            conn.commit()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def _write_rows(
        self,
        rows: List[Dict[str, Any]],
        table_name: str,
    ) -> Optional[str]:
        if not rows:
            return None

        try:
            import psycopg2.extras

            conn = self._connect()
            with conn:
                with conn.cursor() as cur:
                    self._ensure_table(table_name, rows, conn, cur)
                    all_cols = sorted({k for row in rows for k in row.keys()})
                    col_str = ", ".join(f'"{c}"' for c in all_cols)
                    placeholders = ", ".join(["%s"] * len(all_cols))
                    sql = (
                        f'INSERT INTO "{table_name}" ({col_str}) '
                        f"VALUES ({placeholders})"
                    )
                    values = [
                        tuple(prepare_value(row.get(c), c) for c in all_cols)
                        for row in rows
                    ]
                    psycopg2.extras.execute_batch(cur, sql, values)
            conn.close()
            logger.info("Stored %d rows in postgres table %s", len(rows), table_name)
            return f"postgres://{self._host}:{self._port}/{self._db}/{table_name}"
        except Exception:
            logger.exception("Failed to write to Postgres table %s", table_name)
            return None

    # ------------------------------------------------------------------
    # StructuredDataStorage interface
    # ------------------------------------------------------------------

    def store_document_meta(
        self,
        doc_meta: Dict[str, Any],
        tenant_id: str,
    ) -> Optional[str]:
        safe = self._safe_schema(tenant_id)
        return self._write_rows([doc_meta], f"documents_{safe}")

    def store_extractions(
        self,
        rows: List[Dict[str, Any]],
        tenant_id: str,
    ) -> Optional[str]:
        if not rows:
            return None
        safe = self._safe_schema(tenant_id)
        return self._write_rows(rows, f"extracted_data_{safe}")

    def delete_existing_document(
        self,
        document_id: str,
        tenant_id: str,
    ) -> bool:
        safe = self._safe_schema(tenant_id)
        try:
            conn = self._connect()
            with conn:
                with conn.cursor() as cur:
                    for table in [f"extracted_data_{safe}", f"documents_{safe}"]:
                        cur.execute(
                            f'DELETE FROM "{table}" WHERE document_id = %s',
                            (document_id,),
                        )
            conn.close()
            return True
        except Exception:
            logger.warning(
                "Postgres delete for document_id=%s failed (tables may not exist yet)",
                document_id,
            )
            return False
