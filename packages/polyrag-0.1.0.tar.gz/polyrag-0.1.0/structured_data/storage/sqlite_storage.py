"""
SQLite storage backend for OpenRAG structured extraction results.

Zero-infra local storage — great for development, testing, and small deployments.

Environment variables:
    OPENRAG_SQLITE_PATH   Path to the SQLite database file.
                          (default: ./openrag.db)
"""

import logging
import os
import sqlite3
from typing import Any, Dict, List, Optional

from structured_data.storage.base import (
    BOOLEAN_COLUMNS,
    DOUBLE_COLUMNS,
    INT_COLUMNS,
    TIMESTAMP_COLUMNS,
    StructuredDataStorage,
    prepare_value,
)

logger = logging.getLogger(__name__)


def _sqlite_type(col: str) -> str:
    """Map column name to SQLite type affinity."""
    if col in DOUBLE_COLUMNS:
        return "REAL"
    if col in TIMESTAMP_COLUMNS:
        return "TEXT"   # stored as ISO-8601 strings; SQLite has no native TIMESTAMP
    if col in BOOLEAN_COLUMNS:
        return "INTEGER"   # 0 / 1
    if col in INT_COLUMNS:
        return "INTEGER"
    return "TEXT"


class SQLiteStorage(StructuredDataStorage):
    """Write extraction results to a local SQLite database file."""

    def __init__(self):
        self._db_path = os.getenv("OPENRAG_SQLITE_PATH", "./openrag.db")

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        return conn

    # ------------------------------------------------------------------
    # Schema management
    # ------------------------------------------------------------------

    def _get_existing_columns(self, table_name: str, conn: sqlite3.Connection) -> set:
        cur = conn.execute(f'PRAGMA table_info("{table_name}")')
        return {row["name"] for row in cur.fetchall()}

    def _ensure_table(
        self,
        table_name: str,
        rows: List[Dict[str, Any]],
        conn: sqlite3.Connection,
    ) -> None:
        """Create table if needed, then add any new columns."""
        all_cols: set = set()
        for row in rows:
            all_cols.update(row.keys())

        existing = self._get_existing_columns(table_name, conn)

        if not existing:
            col_defs = ", ".join(
                f'"{c}" {_sqlite_type(c)}' for c in sorted(all_cols)
            )
            conn.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" ({col_defs})')
            conn.commit()
        else:
            for col in all_cols:
                if col not in existing:
                    conn.execute(
                        f'ALTER TABLE "{table_name}" ADD COLUMN "{col}" {_sqlite_type(col)}'
                    )
            conn.commit()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def _write_rows(
        self,
        rows: List[Dict[str, Any]],
        table_name: str,
    ) -> Optional[str]:
        if not rows:
            return None

        try:
            conn = self._connect()
            self._ensure_table(table_name, rows, conn)

            all_cols = sorted({k for row in rows for k in row.keys()})
            col_str = ", ".join(f'"{c}"' for c in all_cols)
            placeholders = ", ".join(["?"] * len(all_cols))
            sql = (
                f'INSERT INTO "{table_name}" ({col_str}) '
                f"VALUES ({placeholders})"
            )
            values = [
                tuple(_sqlite_prepare(prepare_value(row.get(c), c), c) for c in all_cols)
                for row in rows
            ]
            conn.executemany(sql, values)
            conn.commit()
            conn.close()
            logger.info("Stored %d rows in sqlite table %s", len(rows), table_name)
            return f"sqlite:///{self._db_path}/{table_name}"
        except Exception:
            logger.exception("Failed to write to SQLite table %s", table_name)
            return None

    # ------------------------------------------------------------------
    # StructuredDataStorage interface
    # ------------------------------------------------------------------

    def store_document_meta(
        self,
        doc_meta: Dict[str, Any],
        tenant_id: str,
    ) -> Optional[str]:
        safe = self._safe_schema(tenant_id)
        return self._write_rows([doc_meta], f"documents_{safe}")

    def store_extractions(
        self,
        rows: List[Dict[str, Any]],
        tenant_id: str,
    ) -> Optional[str]:
        if not rows:
            return None
        safe = self._safe_schema(tenant_id)
        return self._write_rows(rows, f"extracted_data_{safe}")

    def delete_existing_document(
        self,
        document_id: str,
        tenant_id: str,
    ) -> bool:
        safe = self._safe_schema(tenant_id)
        try:
            conn = self._connect()
            for table in [f"extracted_data_{safe}", f"documents_{safe}"]:
                existing = self._get_existing_columns(table, conn)
                if existing:
                    conn.execute(
                        f'DELETE FROM "{table}" WHERE document_id = ?',
                        (document_id,),
                    )
            conn.commit()
            conn.close()
            return True
        except Exception:
            logger.warning(
                "SQLite delete for document_id=%s failed", document_id
            )
            return False


# ---------------------------------------------------------------------------
# SQLite-specific value adapter
# ---------------------------------------------------------------------------

def _sqlite_prepare(val: Any, col: str) -> Any:
    """
    Convert prepare_value() output to a SQLite-native type.

    SQLite stores booleans as 0/1 integers and timestamps as ISO-8601 text.
    """
    from datetime import datetime

    if val is None:
        return None
    if col in BOOLEAN_COLUMNS:
        if isinstance(val, bool):
            return 1 if val else 0
        return None
    if col in TIMESTAMP_COLUMNS:
        if isinstance(val, datetime):
            return val.isoformat()
        return val
    return val
