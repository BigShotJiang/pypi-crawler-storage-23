"""Storage backend package for OpenRAG structured data."""

from .factory import get_storage, get_query_executor
from .base import StructuredDataStorage, BaseQueryExecutor

__all__ = [
    "get_storage",
    "get_query_executor",
    "StructuredDataStorage",
    "BaseQueryExecutor",
]
