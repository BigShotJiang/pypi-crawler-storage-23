"""
Storage backend and query executor factory.

Select the backend via the ``OPENRAG_STORAGE_BACKEND`` environment variable:

    OPENRAG_STORAGE_BACKEND=athena    (default – AWS Athena + S3 Iceberg)
    OPENRAG_STORAGE_BACKEND=postgres  (PostgreSQL)
    OPENRAG_STORAGE_BACKEND=mysql     (MySQL / MariaDB)
    OPENRAG_STORAGE_BACKEND=sqlite    (SQLite – zero-infra local file)
"""

import os

from .base import BaseQueryExecutor, StructuredDataStorage

_VALID_BACKENDS = {"athena", "postgres", "mysql", "sqlite"}


def _get_backend() -> str:
    backend = os.getenv("OPENRAG_STORAGE_BACKEND", "athena").lower().strip()
    if backend not in _VALID_BACKENDS:
        raise ValueError(
            f"Unknown OPENRAG_STORAGE_BACKEND={backend!r}. "
            f"Valid options: {sorted(_VALID_BACKENDS)}"
        )
    return backend


def get_storage() -> StructuredDataStorage:
    """Return the configured StructuredDataStorage implementation."""
    backend = _get_backend()

    if backend == "athena":
        from structured_data.storage.athena_storage import StructuredDataAthenaStorage
        return StructuredDataAthenaStorage()

    if backend == "postgres":
        from structured_data.storage.postgres_storage import PostgresStorage
        return PostgresStorage()

    if backend == "mysql":
        from structured_data.storage.mysql_storage import MySQLStorage
        return MySQLStorage()

    # sqlite
    from structured_data.storage.sqlite_storage import SQLiteStorage
    return SQLiteStorage()


def get_query_executor() -> BaseQueryExecutor:
    """Return the configured query executor implementation."""
    backend = _get_backend()

    if backend == "athena":
        from structured_data.storage.athena_query_executor import AthenaQueryExecutor
        return AthenaQueryExecutor()

    # postgres / mysql / sqlite share a generic SQL executor
    from structured_data.storage.sql_query_executor import SQLQueryExecutor
    return SQLQueryExecutor(backend=backend)
