"""
SQLQueryExecutor – generic SQL execution for Postgres, MySQL, and SQLite.

Handles:
- Stripping Athena-style schema qualifiers from LLM-generated SQL
  (e.g. ``"tenant_abc"."extracted_data_tenant_abc"`` → ``"extracted_data_tenant_abc"``)
- Executing the cleaned SQL against the chosen backend
- Returning results in the standard ``{rows, columns, total_rows, error}`` shape
"""

import logging
import os
import re
from typing import Any, Dict, List

from structured_data.storage.base import BaseQueryExecutor

logger = logging.getLogger(__name__)


class SQLQueryExecutor(BaseQueryExecutor):
    """Execute SQL against Postgres, MySQL, or SQLite."""

    def __init__(self, backend: str):
        """
        Parameters
        ----------
        backend : str
            One of ``"postgres"``, ``"mysql"``, or ``"sqlite"``.
        """
        self._backend = backend

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def execute(self, sql: str, tenant_id: str) -> Dict[str, Any]:
        """Execute *sql* against the configured backend."""
        try:
            clean_sql = self._strip_schema_qualifier(sql, tenant_id)
            clean_sql = self._rewrite_casts_for_backend(clean_sql)
            logger.debug("SQL query (%s): %s", self._backend, clean_sql[:500])

            if self._backend == "postgres":
                return self._execute_postgres(clean_sql)
            if self._backend == "mysql":
                return self._execute_mysql(clean_sql)
            # sqlite
            return self._execute_sqlite(clean_sql)

        except Exception as e:
            logger.exception("SQL query execution failed (%s)", self._backend)
            return {"rows": [], "columns": [], "total_rows": 0, "error": str(e)}

    # ------------------------------------------------------------------
    # SQL rewriting
    # ------------------------------------------------------------------

    @staticmethod
    def _strip_schema_qualifier(sql: str, tenant_id: str) -> str:
        """
        Remove Athena-style catalog and schema qualifiers.

        The LLM generates SQL referencing tables as::

            awsdatacatalog."tenant_abc"."extracted_data_tenant_abc"

        or sometimes just::

            "tenant_abc"."extracted_data_tenant_abc"

        For SQL backends the database is chosen at connection time, so we only
        need the bare table name.

        Transform order:
        1. Strip ``awsdatacatalog.`` catalog prefix (unquoted).
        2. Strip remaining ``"schema".`` qualifier from ``"schema"."table"``.
        """
        # Step 1: Remove  awsdatacatalog.  (may appear before a quoted schema)
        sql = re.sub(r'\bawsdatacatalog\.', '', sql, flags=re.IGNORECASE)
        # Step 2: "schema"."table"  →  "table"
        sql = re.sub(r'"[^"]+"\."([^"]+)"', r'"\1"', sql)
        return sql

    def _rewrite_casts_for_backend(self, sql: str) -> str:
        """
        Rewrite Athena-specific CAST types for the current backend.

        Athena generates ``CAST(x AS DOUBLE)``.
        - SQLite: needs ``CAST(x AS REAL)`` (DOUBLE is not a recognised affinity).
        - Postgres / MySQL: DOUBLE and FLOAT both work fine — no change needed.
        """
        if self._backend == "sqlite":
            sql = re.sub(
                r'\bCAST\s*\(([^)]+?)\s+AS\s+DOUBLE\s*\)',
                lambda m: f'CAST({m.group(1)} AS REAL)',
                sql,
                flags=re.IGNORECASE,
            )
        return sql

    # ------------------------------------------------------------------
    # Backend-specific execution
    # ------------------------------------------------------------------

    def _execute_postgres(self, sql: str) -> Dict[str, Any]:
        import psycopg2
        import psycopg2.extras

        conn = psycopg2.connect(
            host=os.getenv("OPENRAG_POSTGRES_HOST", "localhost"),
            port=int(os.getenv("OPENRAG_POSTGRES_PORT", "5432")),
            dbname=os.getenv("OPENRAG_POSTGRES_DB", "openrag"),
            user=os.getenv("OPENRAG_POSTGRES_USER", "postgres"),
            password=os.getenv("OPENRAG_POSTGRES_PASSWORD", ""),
        )
        try:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(sql)
                rows: List[Dict[str, Any]] = [dict(r) for r in cur.fetchall()]
                columns = list(rows[0].keys()) if rows else []
            return {
                "rows": rows,
                "columns": columns,
                "total_rows": len(rows),
                "error": None,
            }
        finally:
            conn.close()

    def _execute_mysql(self, sql: str) -> Dict[str, Any]:
        import mysql.connector

        conn = mysql.connector.connect(
            host=os.getenv("OPENRAG_MYSQL_HOST", "localhost"),
            port=int(os.getenv("OPENRAG_MYSQL_PORT", "3306")),
            database=os.getenv("OPENRAG_MYSQL_DB", "openrag"),
            user=os.getenv("OPENRAG_MYSQL_USER", "root"),
            password=os.getenv("OPENRAG_MYSQL_PASSWORD", ""),
        )
        cur = conn.cursor(dictionary=True)
        cur.execute("SET SESSION sql_mode = 'ANSI_QUOTES'")
        try:
            cur.execute(sql)
            rows: List[Dict[str, Any]] = cur.fetchall() or []
            columns = list(rows[0].keys()) if rows else []
            return {
                "rows": rows,
                "columns": columns,
                "total_rows": len(rows),
                "error": None,
            }
        finally:
            cur.close()
            conn.close()

    def _execute_sqlite(self, sql: str) -> Dict[str, Any]:
        import sqlite3

        db_path = os.getenv("OPENRAG_SQLITE_PATH", "./openrag.db")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.execute(sql)
            raw_rows = cur.fetchall()
            if raw_rows:
                columns = list(raw_rows[0].keys())
                rows = [dict(r) for r in raw_rows]
            else:
                columns = [desc[0] for desc in (cur.description or [])]
                rows = []
            return {
                "rows": rows,
                "columns": columns,
                "total_rows": len(rows),
                "error": None,
            }
        finally:
            conn.close()
