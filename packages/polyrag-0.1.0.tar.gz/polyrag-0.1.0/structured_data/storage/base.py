"""
Abstract base classes and shared helpers for all storage backends.

Defines:
- StructuredDataStorage  – abstract interface for ingestion
- BaseQueryExecutor      – abstract interface for query execution
- Column type sets and value preparation helper used by all SQL backends
"""

import json
import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List, Optional

import pandas as pd

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared column-type classification sets
# ---------------------------------------------------------------------------

DOUBLE_COLUMNS: frozenset = frozenset({"value_number", "confidence", "overall_confidence"})

TIMESTAMP_COLUMNS: frozenset = frozenset(
    {"value_date", "extracted_at", "created_at", "updated_at", "extraction_timestamp"}
)

BOOLEAN_COLUMNS: frozenset = frozenset({"value_boolean"})

INT_COLUMNS: frozenset = frozenset({"page_number", "total_chunks"})


# ---------------------------------------------------------------------------
# Shared value-preparation helper
# ---------------------------------------------------------------------------

def prepare_value(val: Any, col: str) -> Any:
    """
    Convert an arbitrary Python value to a SQL-safe type for the given column.

    - DOUBLE columns  → float or None
    - TIMESTAMP cols  → datetime or None
    - BOOLEAN cols    → bool or None
    - INT cols        → int or None
    - Everything else → str (lists/dicts JSON-serialised) or None
    """
    # Handle pandas NA / NaT / nan
    try:
        if pd.isna(val):
            return None
    except (TypeError, ValueError):
        pass

    if val is None:
        return None

    if col in DOUBLE_COLUMNS:
        try:
            return float(val)
        except (TypeError, ValueError):
            return None

    if col in TIMESTAMP_COLUMNS:
        if isinstance(val, datetime):
            return val
        if isinstance(val, str) and val.strip():
            try:
                return pd.Timestamp(val).to_pydatetime()
            except Exception:
                return None
        return None

    if col in BOOLEAN_COLUMNS:
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            lower = val.strip().lower()
            if lower in ("true", "yes", "1"):
                return True
            if lower in ("false", "no", "0"):
                return False
        return None

    if col in INT_COLUMNS:
        try:
            return int(val)
        except (TypeError, ValueError):
            return None

    # String columns: serialise complex values
    if isinstance(val, (list, dict)):
        return json.dumps(val)
    if isinstance(val, datetime):
        return val.isoformat()
    return str(val)


# ---------------------------------------------------------------------------
# Abstract base: storage
# ---------------------------------------------------------------------------

class StructuredDataStorage(ABC):
    """Abstract interface for structured extraction result storage."""

    @abstractmethod
    def store_document_meta(
        self,
        doc_meta: Dict[str, Any],
        tenant_id: str,
    ) -> Optional[str]:
        """
        Persist a single document-metadata row.

        Returns a location/identifier string for the stored data, or None on failure.
        """

    @abstractmethod
    def store_extractions(
        self,
        rows: List[Dict[str, Any]],
        tenant_id: str,
    ) -> Optional[str]:
        """
        Persist extraction rows.

        Returns a location/identifier string, or None on failure.
        """

    @abstractmethod
    def delete_existing_document(
        self,
        document_id: str,
        tenant_id: str,
    ) -> bool:
        """
        Delete all rows belonging to *document_id* (used for idempotent re-ingestion).

        Returns True when deletion was attempted successfully, False otherwise.
        """

    # ------------------------------------------------------------------
    # Optional helper
    # ------------------------------------------------------------------

    @staticmethod
    def _safe_schema(tenant_id: str) -> str:
        """Sanitise tenant_id for use as a table-name suffix."""
        return tenant_id.replace("-", "_")


# ---------------------------------------------------------------------------
# Abstract base: query executor
# ---------------------------------------------------------------------------

class BaseQueryExecutor(ABC):
    """Abstract interface for executing SQL against the chosen storage backend."""

    @abstractmethod
    def execute(self, sql: str, tenant_id: str) -> Dict[str, Any]:
        """
        Execute *sql* and return results.

        The return dict always has the shape::

            {
                "rows":       list[dict],   # data rows as column→value dicts
                "columns":    list[str],    # column names in result order
                "total_rows": int,
                "error":      str | None,   # None on success
            }
        """
