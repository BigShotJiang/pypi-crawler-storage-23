"""
MySQL / MariaDB storage backend for OpenRAG structured extraction results.

Environment variables:
    OPENRAG_MYSQL_HOST      (default: localhost)
    OPENRAG_MYSQL_PORT      (default: 3306)
    OPENRAG_MYSQL_DB        (default: openrag)
    OPENRAG_MYSQL_USER      (default: root)
    OPENRAG_MYSQL_PASSWORD  (default: "")

Note: connections are opened with ``sql_mode='ANSI_QUOTES'`` so double-quoted
identifiers work the same as in standard SQL.
"""

import logging
import os
from typing import Any, Dict, List, Optional

from structured_data.storage.base import (
    BOOLEAN_COLUMNS,
    DOUBLE_COLUMNS,
    INT_COLUMNS,
    TIMESTAMP_COLUMNS,
    StructuredDataStorage,
    prepare_value,
)

logger = logging.getLogger(__name__)


def _mysql_type(col: str) -> str:
    """Map column name to MySQL type."""
    if col in DOUBLE_COLUMNS:
        return "DOUBLE"
    if col in TIMESTAMP_COLUMNS:
        return "DATETIME(6)"
    if col in BOOLEAN_COLUMNS:
        return "TINYINT(1)"
    if col in INT_COLUMNS:
        return "BIGINT"
    return "TEXT"


class MySQLStorage(StructuredDataStorage):
    """Write extraction results to MySQL / MariaDB tables."""

    def __init__(self):
        self._host = os.getenv("OPENRAG_MYSQL_HOST", "localhost")
        self._port = int(os.getenv("OPENRAG_MYSQL_PORT", "3306"))
        self._db = os.getenv("OPENRAG_MYSQL_DB", "openrag")
        self._user = os.getenv("OPENRAG_MYSQL_USER", "root")
        self._password = os.getenv("OPENRAG_MYSQL_PASSWORD", "")

    # ------------------------------------------------------------------
    # Connection
    # ------------------------------------------------------------------

    def _connect(self):
        import mysql.connector
        conn = mysql.connector.connect(
            host=self._host,
            port=self._port,
            database=self._db,
            user=self._user,
            password=self._password,
        )
        # Enable ANSI_QUOTES so double-quoted identifiers work
        cur = conn.cursor()
        cur.execute("SET SESSION sql_mode = 'ANSI_QUOTES'")
        cur.close()
        return conn

    # ------------------------------------------------------------------
    # Schema management
    # ------------------------------------------------------------------

    def _get_existing_columns(self, table_name: str, cur) -> set:
        cur.execute(
            "SELECT COLUMN_NAME FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
            (self._db, table_name),
        )
        return {row[0] for row in cur.fetchall()}

    def _ensure_table(
        self,
        table_name: str,
        rows: List[Dict[str, Any]],
        conn,
        cur,
    ) -> None:
        """Create table if needed, then add any new columns."""
        all_cols: set = set()
        for row in rows:
            all_cols.update(row.keys())

        existing = self._get_existing_columns(table_name, cur)

        if not existing:
            col_defs = ", ".join(
                f'"{c}" {_mysql_type(c)}' for c in sorted(all_cols)
            )
            cur.execute(
                f'CREATE TABLE IF NOT EXISTS "{table_name}" ({col_defs}) '
                f"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
            )
            conn.commit()
        else:
            for col in all_cols:
                if col not in existing:
                    cur.execute(
                        f'ALTER TABLE "{table_name}" ADD COLUMN "{col}" {_mysql_type(col)}'
                    )
            conn.commit()

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def _write_rows(
        self,
        rows: List[Dict[str, Any]],
        table_name: str,
    ) -> Optional[str]:
        if not rows:
            return None

        try:
            conn = self._connect()
            cur = conn.cursor()
            self._ensure_table(table_name, rows, conn, cur)

            all_cols = sorted({k for row in rows for k in row.keys()})
            col_str = ", ".join(f'"{c}"' for c in all_cols)
            placeholders = ", ".join(["%s"] * len(all_cols))
            sql = (
                f'INSERT INTO "{table_name}" ({col_str}) '
                f"VALUES ({placeholders})"
            )
            values = [
                tuple(prepare_value(row.get(c), c) for c in all_cols)
                for row in rows
            ]
            cur.executemany(sql, values)
            conn.commit()
            cur.close()
            conn.close()
            logger.info("Stored %d rows in mysql table %s", len(rows), table_name)
            return f"mysql://{self._host}:{self._port}/{self._db}/{table_name}"
        except Exception:
            logger.exception("Failed to write to MySQL table %s", table_name)
            return None

    # ------------------------------------------------------------------
    # StructuredDataStorage interface
    # ------------------------------------------------------------------

    def store_document_meta(
        self,
        doc_meta: Dict[str, Any],
        tenant_id: str,
    ) -> Optional[str]:
        safe = self._safe_schema(tenant_id)
        return self._write_rows([doc_meta], f"documents_{safe}")

    def store_extractions(
        self,
        rows: List[Dict[str, Any]],
        tenant_id: str,
    ) -> Optional[str]:
        if not rows:
            return None
        safe = self._safe_schema(tenant_id)
        return self._write_rows(rows, f"extracted_data_{safe}")

    def delete_existing_document(
        self,
        document_id: str,
        tenant_id: str,
    ) -> bool:
        safe = self._safe_schema(tenant_id)
        try:
            conn = self._connect()
            cur = conn.cursor()
            for table in [f"extracted_data_{safe}", f"documents_{safe}"]:
                try:
                    cur.execute(
                        f'DELETE FROM "{table}" WHERE document_id = %s',
                        (document_id,),
                    )
                except Exception:
                    pass  # Table may not exist yet
            conn.commit()
            cur.close()
            conn.close()
            return True
        except Exception:
            logger.warning(
                "MySQL delete for document_id=%s failed (tables may not exist yet)",
                document_id,
            )
            return False
