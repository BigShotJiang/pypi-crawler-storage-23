"""
AthenaQueryExecutor – SQL execution via AWS Athena.
"""

import logging
import os
import time
from typing import Any, Dict, List

import boto3

from structured_data.storage.base import BaseQueryExecutor

logger = logging.getLogger(__name__)


class AthenaQueryExecutor(BaseQueryExecutor):
    """Execute SQL on Athena and return results."""

    def execute(self, sql: str, tenant_id: str) -> Dict[str, Any]:
        """
        Execute SQL on Athena and return results.

        Returns dict with keys: rows, columns, total_rows, error.
        """
        try:
            key = os.getenv("SQS_KEY")
            secret = os.getenv("AWS_SECRET")
            region = os.getenv("AWS_SQS_REGION", "us-east-1")
            staging = os.getenv(
                "ATHENA_RESULTS_DIRECTORY",
                "s3://fermi-staging-airbyte-sync/athena-results/",
            )

            if not all([key, secret]):
                return {"rows": [], "columns": [], "total_rows": 0, "error": "Missing AWS credentials"}

            client = boto3.client(
                "athena",
                region_name=region,
                aws_access_key_id=key,
                aws_secret_access_key=secret,
            )

            # Start query
            response = client.start_query_execution(
                QueryString=sql,
                QueryExecutionContext={"Database": tenant_id},
                ResultConfiguration={"OutputLocation": staging},
            )
            execution_id = response["QueryExecutionId"]

            # Poll for completion
            for _ in range(120):  # max 60s
                status = client.get_query_execution(QueryExecutionId=execution_id)
                state = status["QueryExecution"]["Status"]["State"]
                if state in ("SUCCEEDED", "FAILED", "CANCELLED"):
                    break
                time.sleep(0.5)

            if state != "SUCCEEDED":
                reason = status["QueryExecution"]["Status"].get("StateChangeReason", "Unknown error")
                logger.error("Athena query failed: %s", reason)
                return {"rows": [], "columns": [], "total_rows": 0, "error": f"Query {state}: {reason}"}

            # Fetch results
            paginator = client.get_paginator("get_query_results")
            rows: List[List[str]] = []
            columns: List[str] = []

            for page in paginator.paginate(QueryExecutionId=execution_id):
                result_set = page["ResultSet"]

                # Get column names from first page
                if not columns and "ResultSetMetadata" in result_set:
                    columns = [
                        col["Name"]
                        for col in result_set["ResultSetMetadata"]["ColumnInfo"]
                    ]

                for row in result_set["Rows"]:
                    values = [
                        field.get("VarCharValue", "")
                        for field in row["Data"]
                    ]
                    rows.append(values)

            # First row is the header — skip it
            if rows and columns:
                data_rows = rows[1:]
            else:
                data_rows = []

            # Convert to list of dicts
            row_dicts = [dict(zip(columns, r)) for r in data_rows]

            logger.info("Athena query returned %d rows", len(row_dicts))
            return {
                "rows": row_dicts,
                "columns": columns,
                "total_rows": len(row_dicts),
                "error": None,
            }

        except Exception as e:
            logger.exception("Athena execution failed")
            return {"rows": [], "columns": [], "total_rows": 0, "error": str(e)}
