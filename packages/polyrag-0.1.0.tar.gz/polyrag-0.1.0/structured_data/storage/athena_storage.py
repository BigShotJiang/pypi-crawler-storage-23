"""
StructuredDataAthenaStorage – persists extraction results into Athena / Iceberg.

Tables managed:
- ``documents_{tenant_id}``         – one row per processed document
- ``extracted_data_{tenant_id}``    – one row per extracted data point

Uses awswrangler + Iceberg with **proper column types** — numeric columns
are stored as DOUBLE, timestamps as TIMESTAMP, booleans as BOOLEAN.
This enables native Athena functions (year(), SUM(), AVG()) without CAST.
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import boto3
import numpy as np
import pandas as pd

from structured_data.storage.base import StructuredDataStorage

logger = logging.getLogger(__name__)

try:
    import awswrangler as wr
except ImportError:
    wr = None
    logger.warning("awswrangler not installed – Athena storage will be unavailable")


# -- Column type mappings --------------------------------------------------
# Columns that should be stored as DOUBLE in Athena
_DOUBLE_COLUMNS = {"value_number", "confidence", "overall_confidence"}

# Columns that should be stored as TIMESTAMP in Athena
_TIMESTAMP_COLUMNS = {
    "value_date",
    "extracted_at",
    "created_at",
    "updated_at",
    "extraction_timestamp",
}

# Columns that should be stored as BOOLEAN in Athena
_BOOLEAN_COLUMNS = {"value_boolean"}

# Columns that should be stored as BIGINT in Athena
_INT_COLUMNS = {"page_number", "total_chunks"}

# Columns that are explicitly string-like for compatibility and deterministic typing
_STRING_COLUMNS = {
    "value_json",
    "row_ref",
    "line_item_id",
    "unit_normalized",
    "value_string_normalized",
    "pipeline_version",
}

# Everything else stays as STRING
_STRING_TYPE = "string"


class StructuredDataAthenaStorage(StructuredDataStorage):
    """Write extraction results to Athena / Iceberg tables with proper types."""

    def __init__(self):
        self._session: Optional[boto3.Session] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store_document_meta(
        self,
        doc_meta: Dict[str, Any],
        tenant_id: str,
    ) -> Optional[str]:
        """Append a single document-metadata row to ``documents_{safe}``."""
        safe = self._safe_schema(tenant_id)
        table_name = f"documents_{safe}"
        return self._write_rows([doc_meta], table_name, tenant_id, "documents")

    def store_extractions(
        self,
        rows: List[Dict[str, Any]],
        tenant_id: str,
    ) -> Optional[str]:
        """Append extraction rows to ``extracted_data_{safe}``."""
        if not rows:
            return None
        safe = self._safe_schema(tenant_id)
        table_name = f"extracted_data_{safe}"
        return self._write_rows(rows, table_name, tenant_id, "extracted_data")

    def delete_existing_document(
        self,
        document_id: str,
        tenant_id: str,
    ) -> bool:
        """
        Delete existing rows for a document_id from both tables (idempotent re-ingestion).

        Uses Iceberg DELETE FROM which is supported for Iceberg v2 tables.
        Returns True if deletion was attempted (regardless of whether rows existed).
        """
        safe = self._safe_schema(tenant_id)
        session = self._get_session()
        if session is None:
            return False

        staging = os.getenv(
            "ATHENA_RESULTS_DIRECTORY",
            "s3://fermi-staging-airbyte-sync/athena-results/",
        )

        try:
            key = os.getenv("SQS_KEY")
            secret = os.getenv("AWS_SECRET")
            region = os.getenv("AWS_SQS_REGION", "us-east-1")

            if not all([key, secret]):
                logger.warning("Missing AWS credentials for idempotent delete")
                return False

            client = boto3.client(
                "athena",
                region_name=region,
                aws_access_key_id=key,
                aws_secret_access_key=secret,
            )

            for table in [f"extracted_data_{safe}", f"documents_{safe}"]:
                delete_sql = (
                    f'DELETE FROM "{tenant_id}"."{table}" '
                    f"WHERE document_id = '{document_id}'"
                )
                try:
                    response = client.start_query_execution(
                        QueryString=delete_sql,
                        QueryExecutionContext={"Database": tenant_id},
                        ResultConfiguration={"OutputLocation": staging},
                    )
                    # Wait for completion (brief poll)
                    import time
                    for _ in range(60):
                        status = client.get_query_execution(
                            QueryExecutionId=response["QueryExecutionId"]
                        )
                        state = status["QueryExecution"]["Status"]["State"]
                        if state in ("SUCCEEDED", "FAILED", "CANCELLED"):
                            break
                        time.sleep(0.5)

                    if state == "SUCCEEDED":
                        logger.info(
                            "Idempotent delete: removed existing rows from %s for document_id=%s",
                            table, document_id,
                        )
                    elif state == "FAILED":
                        reason = status["QueryExecution"]["Status"].get("StateChangeReason", "")
                        # Table might not exist yet — that's fine
                        if "TABLE_NOT_FOUND" in reason.upper() or "DOES NOT EXIST" in reason.upper():
                            logger.debug("Table %s does not exist yet, skipping delete", table)
                        else:
                            logger.warning(
                                "Idempotent delete failed for %s: %s", table, reason
                            )
                except Exception:
                    logger.debug("Delete query for %s skipped (table may not exist)", table)

            return True

        except Exception:
            logger.exception("Idempotent delete failed for document_id=%s", document_id)
            return False

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _write_rows(
        self,
        rows: List[Dict[str, Any]],
        table_name: str,
        tenant_id: str,
        subfolder: str,
    ) -> Optional[str]:
        """Generic Iceberg append with proper column typing."""
        if wr is None:
            logger.error("awswrangler not available – cannot write to Athena")
            return None

        try:
            session = self._get_session()
            if session is None:
                return None

            airbyte_bucket = os.getenv("AIRBYTE_SYNC_BUCKET")
            base_staging = os.getenv(
                "ATHENA_RESULTS_DIRECTORY",
                "s3://fermi-staging-airbyte-sync/athena-results/",
            )

            table_location = (
                f"s3://{airbyte_bucket}/{tenant_id}/{subfolder}/athena/"
            )
            unique_id = str(uuid.uuid4())
            temp_path = f"{base_staging.rstrip('/')}/{subfolder}-temp/{unique_id}/"

            schema_name = tenant_id

            # Ensure database exists
            try:
                wr.catalog.create_database(
                    name=schema_name, exist_ok=True, boto3_session=session
                )
            except Exception as db_err:
                logger.warning("Could not create/verify database %s: %s", schema_name, db_err)

            # Build DataFrame with proper types
            df = pd.DataFrame(rows)
            df = self._apply_types(df)
            dtype = self._build_dtype_map(df)
            df, dtype = self._align_with_existing_table_schema(
                df=df,
                dtype=dtype,
                database=schema_name,
                table=table_name,
                session=session,
            )

            wr.athena.to_iceberg(
                df=df,
                database=schema_name,
                table=table_name,
                table_location=table_location,
                temp_path=temp_path,
                mode="append",
                boto3_session=session,
                dtype=dtype,
                schema_evolution=True,
            )

            logger.info(
                "Stored %d rows in %s.%s", len(rows), schema_name, table_name
            )
            return table_location

        except Exception:
            logger.exception("Failed to write to Athena table %s", table_name)
            return None

    # ------------------------------------------------------------------
    # Type casting
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_types(df: pd.DataFrame) -> pd.DataFrame:
        """
        Cast DataFrame columns to proper pandas dtypes so awswrangler
        writes them as the correct Iceberg / Athena types.

        - DOUBLE columns  → float64 (nullable)
        - TIMESTAMP columns → datetime64[ns, UTC]
        - BOOLEAN columns → boolean (nullable)
        - INT columns → Int64 (nullable)
        - Everything else → string (lists/dicts serialised to JSON)
        """
        out = df.copy()

        for col in out.columns:
            athena_type = StructuredDataAthenaStorage._athena_type_for_column(col)
            out[col] = StructuredDataAthenaStorage._cast_series_for_athena_type(
                out[col],
                athena_type,
            )

        return out

    @staticmethod
    def _athena_type_for_column(col: str) -> str:
        if col in _DOUBLE_COLUMNS:
            return "double"
        if col in _TIMESTAMP_COLUMNS:
            return "timestamp"
        if col in _BOOLEAN_COLUMNS:
            return "boolean"
        if col in _INT_COLUMNS:
            return "bigint"
        if col in _STRING_COLUMNS:
            return _STRING_TYPE
        return _STRING_TYPE

    @staticmethod
    def _build_dtype_map(df: pd.DataFrame) -> Dict[str, str]:
        """Build explicit Athena dtype mapping for current DataFrame columns."""
        return {
            col: StructuredDataAthenaStorage._athena_type_for_column(col)
            for col in df.columns
        }

    @staticmethod
    def _canonical_athena_type(type_name: str) -> str:
        raw = (type_name or "").strip().lower()
        if raw.startswith("varchar") or raw.startswith("char"):
            return _STRING_TYPE
        if raw.startswith("timestamp"):
            return "timestamp"
        if raw.startswith("decimal"):
            return "double"
        if raw in {"float", "real", "double"}:
            return "double"
        if raw in {"integer", "int", "smallint", "tinyint", "bigint"}:
            return "bigint"
        if raw in {"bool", "boolean"}:
            return "boolean"
        if raw in {"string"}:
            return _STRING_TYPE
        return raw or _STRING_TYPE

    @staticmethod
    def _cast_series_for_athena_type(series: pd.Series, athena_type: str) -> pd.Series:
        canonical = StructuredDataAthenaStorage._canonical_athena_type(athena_type)

        if canonical == "double":
            return pd.to_numeric(series, errors="coerce")

        if canonical == "timestamp":
            return pd.to_datetime(series.apply(_to_timestamp), errors="coerce", utc=True)

        if canonical == "boolean":
            return series.apply(_to_bool).astype("boolean")

        if canonical == "bigint":
            return pd.to_numeric(series, errors="coerce").astype("Int64")

        # String-like columns: serialise complex values and force pandas string dtype.
        return series.apply(_to_string).astype("string")

    def _align_with_existing_table_schema(
        self,
        df: pd.DataFrame,
        dtype: Dict[str, str],
        database: str,
        table: str,
        session: boto3.Session,
    ) -> Tuple[pd.DataFrame, Dict[str, str]]:
        """
        Keep writes compatible with existing Iceberg schema.

        If a column already exists with a different type (for example legacy
        string `created_at`), cast outgoing values to the existing type and
        keep that type in the write dtype map to avoid illegal alter attempts.
        """
        existing = self._get_existing_table_types(
            database=database,
            table=table,
            session=session,
        )
        if not existing:
            return df, dtype

        out = df.copy()
        merged_dtype = dict(dtype)

        for col in out.columns:
            if col not in existing or col not in merged_dtype:
                continue

            existing_raw = existing[col]
            existing_norm = self._canonical_athena_type(existing_raw)
            incoming_norm = self._canonical_athena_type(merged_dtype[col])

            if existing_norm != incoming_norm:
                logger.warning(
                    "Column type mismatch for %s.%s.%s (incoming=%s existing=%s). "
                    "Using existing type for compatibility.",
                    database,
                    table,
                    col,
                    merged_dtype[col],
                    existing_raw,
                )
                out[col] = self._cast_series_for_athena_type(out[col], existing_raw)
                merged_dtype[col] = existing_raw

        return out, merged_dtype

    def _get_existing_table_types(
        self,
        database: str,
        table: str,
        session: boto3.Session,
    ) -> Dict[str, str]:
        """Fetch existing Athena table column types, if table already exists."""
        if wr is None:
            return {}

        try:
            exists = wr.catalog.does_table_exist(
                database=database,
                table=table,
                boto3_session=session,
            )
            if not exists:
                return {}

            table_types = wr.catalog.get_table_types(
                database=database,
                table=table,
                boto3_session=session,
            )
            return {str(col): str(col_type) for col, col_type in table_types.items()}
        except Exception as exc:
            logger.warning(
                "Could not inspect existing schema for %s.%s: %s",
                database,
                table,
                exc,
            )
            return {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_session(self) -> Optional[boto3.Session]:
        """Return a cached boto3 session."""
        if self._session is not None:
            return self._session

        key = os.getenv("SQS_KEY")
        secret = os.getenv("AWS_SECRET")
        region = os.getenv("AWS_SQS_REGION", "us-east-1")

        if not all([key, secret]):
            logger.warning("Missing AWS credentials for Athena")
            return None

        self._session = boto3.Session(
            aws_access_key_id=key,
            aws_secret_access_key=secret,
            region_name=region,
        )
        return self._session


# -- Per-value converters (module-level for reuse) -------------------------

def _to_timestamp(val):
    """Convert a value to a pandas-compatible timestamp or NaT."""
    if val is None:
        return pd.NaT
    if isinstance(val, datetime):
        return val
    if isinstance(val, str):
        if not val.strip():
            return pd.NaT
        try:
            return pd.Timestamp(val)
        except Exception:
            return pd.NaT
    return pd.NaT


def _to_bool(val):
    """Convert a value to bool or pandas NA."""
    if val is None:
        return pd.NA
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        lower = val.strip().lower()
        if lower in ("true", "yes", "1"):
            return True
        if lower in ("false", "no", "0"):
            return False
    return pd.NA


def _to_string(val):
    """Convert a value to string, serialising lists/dicts as JSON."""
    if val is None:
        return None
    if isinstance(val, (list, dict)):
        return json.dumps(val)
    if isinstance(val, datetime):
        return val.isoformat()
    if hasattr(val, "__iter__") and not isinstance(val, str):
        try:
            return json.dumps(list(val))
        except (TypeError, ValueError):
            return str(val)
    try:
        if pd.isna(val):
            return None
    except (ValueError, TypeError):
        pass
    return str(val)
