"""
EntityResolver – resolves extracted entity mentions to canonical entity IDs.

Resolution strategy (in order):
1. Identifier match against known codes/IDs (most reliable).
2. Exact match against known entity names + name_variations.
3. Fuzzy match using SequenceMatcher (threshold configurable).
4. LLM-based matching for ambiguous cases (optional, expensive).
5. Create a new entity if no match is found.

Identifiers are extracted from the document alongside names. For example a
product might be referred to as "Amoxicillin 250mg" in one document and by
its code "RM-MCC-0102" in another.  Both the name and the code are stored
on the entity record so either can be used for resolution.

The resolver operates against MongoDB ``entities_master`` collection which
serves as the in-flight entity registry (fast reads). The same data is
periodically flushed to Athena for analytics.
"""

import logging
import os
import uuid
from datetime import datetime, timezone
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

from connectors.mongodb_connector import MongoDBConnector
from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .feature_flags import env_bool, env_int, is_reliability_v2_enabled
from .schemas import EntityMatchResult
from . import prompts as P

logger = logging.getLogger(__name__)

COLLECTION = "entities_master"
_DEFAULT_IDENTIFIER_GUARDRAILS_ENABLED = True
_DEFAULT_RISKY_IDENTIFIER_MIN_LEN = 5
_DEFAULT_STRONG_NAME_MATCH_THRESHOLD = 0.93


class EntityResolver:
    """Resolve entity mentions to canonical entity IDs."""

    def __init__(
        self,
        similarity_threshold: float = 0.90,
        use_llm_matching: bool = False,
    ):
        self.similarity_threshold = similarity_threshold
        self.use_llm_matching = use_llm_matching
        self.mongodb = MongoDBConnector()
        self.llm_manager = LLMManager()
        # In-memory cache per pipeline run to avoid repeated DB lookups
        self._cache: Dict[str, Dict[str, Any]] = {}  # key: "tenant|name|type"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        entity_name: str,
        entity_type: str,
        tenant_id: str,
        context: str = "",
        identifiers: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Resolve *entity_name* to a canonical entity.

        Parameters
        ----------
        entity_name : str
            Human-readable name (e.g. "Amoxicillin 250mg Capsules").
        entity_type : str
            Entity category (PERSON, ORGANIZATION, PRODUCT, …).
        tenant_id : str
            Tenant isolation key.
        context : str
            Surrounding text to assist matching.
        identifiers : list[str], optional
            Codes / IDs associated with this entity (e.g. ["RM-MCC-0102"]).
            These take **priority** over name-based matching because codes
            are more stable than names.

        Returns::

            {
                "entity_id": "uuid",
                "canonical_name": "Apollo Hospitals Enterprise Ltd",
                "is_new": False,
                "match_method": "identifier" | "exact" | "fuzzy" | "llm" | "new",
            }
        """
        entity_name = entity_name.strip()
        identifiers = [i.strip() for i in (identifiers or []) if i and i.strip()]

        if not entity_name and not identifiers:
            return self._new_entity_result(entity_name, entity_type, tenant_id)

        # --- Cache check (name + every identifier) ---
        for lookup in [entity_name] + identifiers:
            if not lookup:
                continue
            cache_key = f"{tenant_id}|{lookup.lower()}|{entity_type}"
            if cache_key in self._cache:
                cached = self._cache[cache_key]
                return {
                    "entity_id": cached["entity_id"],
                    "canonical_name": cached["entity_name"],
                    "is_new": False,
                    "match_method": "cache",
                }

        # 1. *** Identifier match (highest priority) ***
        guardrails_enabled = self._identifier_guardrails_enabled(tenant_id)
        if identifiers:
            strong_ids, risky_ids = self._split_identifiers_by_risk(identifiers)
            id_match: Optional[Dict[str, Any]] = None
            reason_code = "identifier"

            if guardrails_enabled and strong_ids:
                id_match = self._find_by_identifier(strong_ids, entity_type, tenant_id)
                if id_match:
                    reason_code = "identifier_strong"

            if id_match is None:
                id_match = self._find_by_identifier(identifiers, entity_type, tenant_id)
                if id_match and guardrails_enabled and risky_ids:
                    support = self._risky_identifier_support(
                        entity_name=entity_name,
                        entity_type=entity_type,
                        tenant_id=tenant_id,
                        matched_entity=id_match,
                    )
                    if not support["accepted"]:
                        logger.info(
                            "Identifier guardrail rejected match: reason_code=%s tenant=%s type=%s name=%s identifiers=%s matched=%s",
                            support["reason_code"],
                            tenant_id,
                            entity_type,
                            entity_name,
                            identifiers,
                            id_match.get("entity_name"),
                        )
                        id_match = None
                    else:
                        reason_code = support["reason_code"]

            if id_match:
                # Also register the current name as a variation
                if entity_name:
                    self._add_name_variation(id_match["entity_id"], entity_name, tenant_id)
                self._populate_cache(id_match, tenant_id, entity_type, extra_name=entity_name)
                logger.info(
                    "Entity resolved by identifier: reason_code=%s tenant=%s type=%s name=%s canonical=%s",
                    reason_code,
                    tenant_id,
                    entity_type,
                    entity_name,
                    id_match["entity_name"],
                )
                return {
                    "entity_id": id_match["entity_id"],
                    "canonical_name": id_match["entity_name"],
                    "is_new": False,
                    "match_method": "identifier",
                }

        # 2. Exact name match (name + type)
        if entity_name:
            exact = self._find_exact(entity_name, entity_type, tenant_id)
            if exact:
                if identifiers:
                    self._add_identifiers(exact["entity_id"], identifiers, tenant_id)
                self._populate_cache(exact, tenant_id, entity_type)
                return {
                    "entity_id": exact["entity_id"],
                    "canonical_name": exact["entity_name"],
                    "is_new": False,
                    "match_method": "exact",
                }

        # 2b. Cross-type exact match — same name exists under a different entity_type.
        #     Prevents duplicate entity records when the LLM assigns different types
        #     to the same real-world entity across different event mentions
        #     (e.g. "Manufacturing Unit" classified as ORGANIZATION in one event and
        #     OTHER in another).  Name is the primary identity anchor; type is secondary.
        if entity_name:
            cross = self._find_exact_any_type(entity_name, tenant_id)
            if cross:
                if identifiers:
                    self._add_identifiers(cross["entity_id"], identifiers, tenant_id)
                self._populate_cache(cross, tenant_id, entity_type, extra_name=entity_name)
                logger.info(
                    "Entity cross-type match: '%s' (requested=%s, stored=%s) -> %s",
                    entity_name, entity_type, cross.get("entity_type"), cross["entity_id"],
                )
                return {
                    "entity_id": cross["entity_id"],
                    "canonical_name": cross["entity_name"],
                    "is_new": False,
                    "match_method": "cross_type",
                }

        # 3. Fuzzy name match
        candidates = self._get_candidates(entity_type, tenant_id)
        if entity_name:
            fuzzy = self._fuzzy_match(entity_name, candidates)
            if fuzzy:
                self._add_name_variation(fuzzy["entity_id"], entity_name, tenant_id)
                if identifiers:
                    self._add_identifiers(fuzzy["entity_id"], identifiers, tenant_id)
                self._populate_cache(fuzzy, tenant_id, entity_type, extra_name=entity_name)
                return {
                    "entity_id": fuzzy["entity_id"],
                    "canonical_name": fuzzy["entity_name"],
                    "is_new": False,
                    "match_method": "fuzzy",
                }

        # 4. LLM-based match (optional)
        if self.use_llm_matching and candidates and entity_name:
            llm_match = self._llm_match(entity_name, entity_type, candidates, context)
            if llm_match:
                self._add_name_variation(llm_match["entity_id"], entity_name, tenant_id)
                if identifiers:
                    self._add_identifiers(llm_match["entity_id"], identifiers, tenant_id)
                self._populate_cache(llm_match, tenant_id, entity_type, extra_name=entity_name)
                return {
                    "entity_id": llm_match["entity_id"],
                    "canonical_name": llm_match["entity_name"],
                    "is_new": False,
                    "match_method": "llm",
                }

        # 5. Create new entity
        new = self._create_entity(
            entity_name or identifiers[0],
            entity_type,
            tenant_id,
            identifiers=identifiers,
        )
        self._populate_cache(new, tenant_id, entity_type)
        return {
            "entity_id": new["entity_id"],
            "canonical_name": new["entity_name"],
            "is_new": True,
            "match_method": "new",
        }

    def get_entity_by_id(
        self,
        entity_id: str,
        tenant_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Fetch canonical entity record from ``entities_master``.

        Returns ``None`` when not found or lookup fails.
        """
        if not entity_id:
            return None
        try:
            return self.mongodb.find_one_document(
                COLLECTION,
                {"entity_id": entity_id, "tenant_id": tenant_id},
            )
        except Exception:
            logger.warning(
                "Failed to fetch entity master for entity_id=%s tenant_id=%s",
                entity_id, tenant_id,
            )
            return None

    # ------------------------------------------------------------------
    # Internal: exact match
    # ------------------------------------------------------------------

    def _find_by_identifier(
        self, identifiers: List[str], entity_type: str, tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Find entity by any of its identifiers/codes.

        Searches against the ``identifiers`` array field on the entity
        record.  Also checks ``name_variations`` since codes are stored
        there too as a fallback.
        """
        result = self.mongodb.find_one_document(
            COLLECTION,
            {
                "tenant_id": tenant_id,
                "entity_type": entity_type,
                "$or": [
                    {"identifiers": {"$in": identifiers}},
                    {"name_variations": {"$in": identifiers}},
                ],
            },
        )
        if result:
            logger.debug(
                "Identifier match: %s -> '%s'", identifiers, result["entity_name"]
            )
        return result

    def _find_exact(
        self, name: str, entity_type: str, tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """Find entity by exact name or name_variations match (same type)."""
        result = self.mongodb.find_one_document(
            COLLECTION,
            {
                "tenant_id": tenant_id,
                "entity_type": entity_type,
                "$or": [
                    {"entity_name": name},
                    {"name_variations": name},
                ],
            },
        )
        return result

    def _find_exact_any_type(
        self, name: str, tenant_id: str
    ) -> Optional[Dict[str, Any]]:
        """Find entity by exact name regardless of entity_type.

        Used as a Stage 2b fallback when the same entity is mentioned with
        inconsistent types across documents or events.  Name identity takes
        priority over type classification in these cases.
        """
        result = self.mongodb.find_one_document(
            COLLECTION,
            {
                "tenant_id": tenant_id,
                "$or": [
                    {"entity_name": name},
                    {"name_variations": name},
                ],
            },
        )
        return result

    # ------------------------------------------------------------------
    # Internal: fuzzy match
    # ------------------------------------------------------------------

    def _get_candidates(
        self, entity_type: str, tenant_id: str
    ) -> List[Dict[str, Any]]:
        """Return all entities of the given type for fuzzy matching."""
        return self.mongodb.find_documents(
            COLLECTION,
            {"tenant_id": tenant_id, "entity_type": entity_type},
            limit=500,
        )

    def _fuzzy_match(
        self, name: str, candidates: List[Dict[str, Any]]
    ) -> Optional[Dict[str, Any]]:
        """Find best fuzzy match above threshold."""
        best: Optional[Dict[str, Any]] = None
        best_score = 0.0

        name_lower = name.lower()
        for cand in candidates:
            # Check canonical name
            cand_lower = cand["entity_name"].lower()
            score = SequenceMatcher(
                None, name_lower, cand_lower
            ).ratio()

            # Check all variations
            for var in cand.get("name_variations", []):
                var_score = SequenceMatcher(
                    None, name_lower, var.lower()
                ).ratio()
                score = max(score, var_score)

            # Guard: reject matches where names differ only in a suffix
            # character/number (Account_A vs Account_B, Project_X vs Project_Y,
            # Server_1 vs Server_2). These are distinct enumerated entities.
            if score >= self.similarity_threshold and self._is_suffix_variant(name_lower, cand_lower):
                logger.info(
                    "Fuzzy match rejected (suffix variant): '%s' vs '%s' (score=%.2f)",
                    name, cand["entity_name"], score,
                )
                continue

            if score > best_score:
                best_score = score
                best = cand

        if best and best_score >= self.similarity_threshold:
            logger.debug(
                "Fuzzy match: '%s' -> '%s' (score=%.2f)",
                name, best["entity_name"], best_score,
            )
            return best
        return None

    @staticmethod
    def _is_suffix_variant(name_a: str, name_b: str) -> bool:
        """
        Check if two names are identical except for a trailing suffix
        character (letter, digit, or short token after a separator).

        Examples that return True:
        - "account_a" vs "account_b"
        - "project_x" vs "project_y"
        - "server 1" vs "server 2"
        - "line a" vs "line b"

        Examples that return False:
        - "aarav sharma" vs "aarav" (different length)
        - "mcc ph102" vs "microcrystalline cellulose" (different structure)
        """
        if not name_a or not name_b:
            return False
        # Must be similar length (within 2 chars)
        if abs(len(name_a) - len(name_b)) > 2:
            return False
        # Find the common prefix
        common_len = 0
        for a, b in zip(name_a, name_b):
            if a == b:
                common_len += 1
            else:
                break
        # If the common prefix covers all but the last 1-3 chars, it's a suffix variant
        min_len = min(len(name_a), len(name_b))
        if min_len <= 3:
            return False  # Too short to judge
        suffix_diff = min_len - common_len
        return suffix_diff <= 3 and common_len >= min_len * 0.7

    def _best_name_similarity(self, name: str, candidate: Dict[str, Any]) -> float:
        name_lower = name.lower()
        score = SequenceMatcher(
            None,
            name_lower,
            candidate.get("entity_name", "").lower(),
        ).ratio()
        for variation in candidate.get("name_variations", []):
            score = max(
                score,
                SequenceMatcher(None, name_lower, str(variation).lower()).ratio(),
            )
        return score

    def _split_identifiers_by_risk(self, identifiers: List[str]) -> tuple[List[str], List[str]]:
        risky_min_len = env_int(
            "STRUCTURED_ENTITY_RISKY_IDENTIFIER_MIN_LEN",
            _DEFAULT_RISKY_IDENTIFIER_MIN_LEN,
        )
        strong: List[str] = []
        risky: List[str] = []
        for identifier in identifiers:
            if self._is_risky_identifier(identifier, risky_min_len):
                risky.append(identifier)
            else:
                strong.append(identifier)
        return strong, risky

    @staticmethod
    def _is_risky_identifier(identifier: str, min_len: int) -> bool:
        token = (identifier or "").strip().replace(" ", "")
        if not token:
            return True
        if len(token) < max(1, min_len):
            return True
        has_digit = any(ch.isdigit() for ch in token)
        has_sep = any(ch in "-_/." for ch in token)
        if not has_digit and not has_sep:
            return True
        if token.isalpha() and len(token) <= max(min_len + 1, 6):
            return True
        return False

    def _identifier_guardrails_enabled(self, tenant_id: str) -> bool:
        return (
            is_reliability_v2_enabled(tenant_id)
            and env_bool(
                "STRUCTURED_ENTITY_IDENTIFIER_GUARDRAILS",
                _DEFAULT_IDENTIFIER_GUARDRAILS_ENABLED,
            )
        )

    def _risky_identifier_support(
        self,
        *,
        entity_name: str,
        entity_type: str,
        tenant_id: str,
        matched_entity: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Require extra name support before accepting a risky identifier match.
        """
        if not entity_name:
            return {
                "accepted": False,
                "reason_code": "identifier_risky_rejected_no_name",
            }

        exact = self._find_exact(entity_name, entity_type, tenant_id)
        if exact and exact.get("entity_id") == matched_entity.get("entity_id"):
            return {
                "accepted": True,
                "reason_code": "identifier_risky_supported_exact",
            }
        if exact and exact.get("entity_id") != matched_entity.get("entity_id"):
            return {
                "accepted": False,
                "reason_code": "identifier_risky_rejected_exact_conflict",
            }

        threshold = float(
            os.getenv(
                "STRUCTURED_ENTITY_STRONG_NAME_MATCH_THRESHOLD",
                str(_DEFAULT_STRONG_NAME_MATCH_THRESHOLD),
            )
        )
        score = self._best_name_similarity(entity_name, matched_entity)
        if score >= max(self.similarity_threshold, threshold):
            return {
                "accepted": True,
                "reason_code": f"identifier_risky_supported_fuzzy:{score:.2f}",
            }

        return {
            "accepted": False,
            "reason_code": f"identifier_risky_rejected_fuzzy:{score:.2f}",
        }

    # ------------------------------------------------------------------
    # Internal: LLM match
    # ------------------------------------------------------------------

    def _llm_match(
        self,
        name: str,
        entity_type: str,
        candidates: List[Dict[str, Any]],
        context: str,
    ) -> Optional[Dict[str, Any]]:
        """Use LLM to resolve ambiguous entity references."""
        # Only compare against top-5 by string similarity
        scored = []
        name_lower = name.lower()
        for c in candidates:
            s = SequenceMatcher(None, name_lower, c["entity_name"].lower()).ratio()
            scored.append((s, c))
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:5]

        llm = self.llm_manager.get_for_structured_output()
        for _score, cand in top:
            prompt = (
                f"System: {P.ENTITY_MATCH_SYSTEM}\n\n"
                f"User: Are these two mentions the same entity?\n\n"
                f'Entity A: "{name}" (type: {entity_type})\n'
                f"Context A: {context[:300]}\n\n"
                f'Entity B: "{cand["entity_name"]}" (type: {cand["entity_type"]})\n'
                f'Context B: {cand.get("context", "N/A")[:300]}\n\n'
                f"Determine if they are the same real-world entity."
            )
            try:
                result: EntityMatchResult = llm.generate_structured(
                    prompt, EntityMatchResult, temperature=0.1
                )
                if result.is_same_entity and result.confidence >= 0.7:
                    logger.info(
                        "LLM match: '%s' -> '%s' (conf=%.2f)",
                        name, cand["entity_name"], result.confidence,
                    )
                    return cand
            except LLMRateLimitTimeoutError:
                raise
            except Exception:
                logger.warning("LLM entity match failed for '%s' vs '%s'", name, cand["entity_name"])
                continue

        return None

    # ------------------------------------------------------------------
    # Internal: create / update helpers
    # ------------------------------------------------------------------

    def _create_entity(
        self,
        name: str,
        entity_type: str,
        tenant_id: str,
        identifiers: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a new entity in MongoDB."""
        now = datetime.now(timezone.utc)
        entity = {
            "entity_id": str(uuid.uuid4()),
            "entity_name": name,
            "entity_type": entity_type,
            "name_variations": [name],
            "identifiers": identifiers or [],
            "tenant_id": tenant_id,
            "total_documents": 0,
            "total_mentions": 0,
            "first_seen_date": now.isoformat(),
            "last_seen_date": now.isoformat(),
            "source_document_ids": [],
            "attributes": {},
            "confidence_score": 0.8,
            "created_at": now.isoformat(),
            "updated_at": now.isoformat(),
        }
        self.mongodb.insert_document(COLLECTION, entity)
        logger.info(
            "Created new entity: %s (%s) id=%s identifiers=%s",
            name, entity_type, entity["entity_id"], identifiers,
        )
        return entity

    def _add_name_variation(
        self, entity_id: str, variation: str, tenant_id: str
    ) -> None:
        """Add a name variation to an existing entity."""
        self.mongodb.update_document(
            COLLECTION,
            {"entity_id": entity_id, "tenant_id": tenant_id},
            {
                "$addToSet": {"name_variations": variation},
                "$set": {"updated_at": datetime.now(timezone.utc).isoformat()},
            },
        )

    def _add_identifiers(
        self, entity_id: str, identifiers: List[str], tenant_id: str
    ) -> None:
        """Add identifier codes to an existing entity."""
        self.mongodb.update_document(
            COLLECTION,
            {"entity_id": entity_id, "tenant_id": tenant_id},
            {
                "$addToSet": {"identifiers": {"$each": identifiers}},
                "$set": {"updated_at": datetime.now(timezone.utc).isoformat()},
            },
        )

    def _new_entity_result(
        self, name: str, entity_type: str, tenant_id: str
    ) -> Dict[str, Any]:
        """Return result for an empty entity name."""
        return {
            "entity_id": str(uuid.uuid4()),
            "canonical_name": name or "Unknown",
            "is_new": True,
            "match_method": "new",
        }

    # ------------------------------------------------------------------
    # Cache helpers
    # ------------------------------------------------------------------

    def _populate_cache(
        self,
        entity: Dict[str, Any],
        tenant_id: str,
        entity_type: str,
        extra_name: Optional[str] = None,
    ) -> None:
        """Cache entity for fast repeat lookups."""
        names = [entity["entity_name"]] + entity.get("name_variations", [])
        if extra_name:
            names.append(extra_name)
        for n in names:
            key = f"{tenant_id}|{n.lower()}|{entity_type}"
            self._cache[key] = entity
