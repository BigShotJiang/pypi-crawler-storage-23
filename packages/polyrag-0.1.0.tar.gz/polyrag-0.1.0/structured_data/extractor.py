"""
DocumentStructuredExtractor – LLM-based structured extraction with 3-tier model.

Tier 1: Universal baseline (title, type, summary, topics)
Tier 2: Domain-agnostic entities / metrics / dates / attributes
Tier 3: Document-type-specific extraction (line items, contract terms, etc.)

All three tiers are produced in a single LLM call by using the
``DocumentStructuredExtractionResult`` schema.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from app.config.llm import LLMModelCategory
from llm.manager import LLMManager, LLMType
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from . import prompts as P
from .extraction_normalizer import (
    enforce_row_field_safety,
    evaluate_chunk_quality,
    looks_tabular_text,
    normalize_item_semantics,
)
from .feature_flags import (
    env_bool,
    env_float,
    env_int,
)
from .schemas import DocumentStructuredExtractionResult
from .type_utils import detect_and_parse_value

logger = logging.getLogger(__name__)

# Maximum characters sent to the LLM per chunk
_MAX_EXTRACTION_CHARS = 50_000
_PIPELINE_VERSION_V3 = "extraction_v3"
_PIPELINE_VERSION_V2 = "reliability_v2"
_PIPELINE_VERSION_LEGACY = "legacy"

_DEFAULT_REPAIR_PASS_ENABLED = True
_DEFAULT_REPAIR_MAX_WINDOWS_PER_DOC = 2
_DEFAULT_REPAIR_QUALITY_THRESHOLD = 0.82
_DEFAULT_PREFER_DECLARED_VALUE_TYPE = True
_DEFAULT_ENFORCE_IDENTIFIER_STRING = True
_DEFAULT_SYNTHETIC_ROW_REF = True
_DEFAULT_EXTRACTION_MODEL = "gpt-5.2"
_DEFAULT_HEADER_EVIDENCE_REPAIR_THRESHOLD = 0.15
_DEFAULT_ORPHAN_ROW_REPAIR_THRESHOLD = 0.20


class DocumentStructuredExtractor:
    """
    Runs LLM-based structured extraction on document text.

    Returns a flat list of ``extraction rows`` – each row is a dict ready
    to be stored in the ``extracted_data`` Athena table.
    """

    def __init__(self):
        self.llm_manager = LLMManager()
        self._repair_windows_used_by_doc: Dict[str, int] = {}
        self._repair_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract(
        self,
        document_text: str,
        document_id: str,
        tenant_id: str,
        user_id: str,
        resource_id: str,
        file_name: str,
        chunk_id: Optional[str] = None,
        page_number: Optional[int] = None,
        title_hint: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Run full structured extraction on *document_text*.

        Returns::

            {
                "document_meta": { ... },   # row for documents table
                "extractions":   [ ... ],   # rows for extracted_data table
            }
        """
        logger.info(
            "Starting structured extraction for doc=%s file=%s len=%d",
            document_id,
            file_name,
            len(document_text),
        )

        reliability_v2_enabled = env_bool("STRUCTURED_RELIABILITY_V2_ENABLED", True)
        extraction_v3_enabled = env_bool("STRUCTURED_EXTRACTION_V3_ENABLED", True)
        enhanced_fields_enabled = reliability_v2_enabled or extraction_v3_enabled
        pipeline_version = self._pipeline_version(
            extraction_v3_enabled=extraction_v3_enabled,
            reliability_v2_enabled=reliability_v2_enabled,
        )
        extraction_model = self._resolve_extraction_model()
        logger.info("Extraction model selected: openai:%s", extraction_model)

        prefer_declared_value_type = (
            extraction_v3_enabled
            and env_bool(
                "STRUCTURED_EXTRACTION_PREFER_DECLARED_VALUE_TYPE",
                _DEFAULT_PREFER_DECLARED_VALUE_TYPE,
            )
        )
        enforce_identifier_string = (
            extraction_v3_enabled
            and env_bool(
                "STRUCTURED_EXTRACTION_ENFORCE_IDENTIFIER_STRING",
                _DEFAULT_ENFORCE_IDENTIFIER_STRING,
            )
        )
        enable_synthetic_row_ref = (
            extraction_v3_enabled
            and env_bool(
                "STRUCTURED_EXTRACTION_SYNTHETIC_ROW_REF",
                _DEFAULT_SYNTHETIC_ROW_REF,
            )
        )
        repair_enabled = (
            extraction_v3_enabled
            and env_bool(
                "STRUCTURED_EXTRACTION_REPAIR_PASS_ENABLED",
                _DEFAULT_REPAIR_PASS_ENABLED,
            )
        )
        repair_quality_threshold = env_float(
            "STRUCTURED_EXTRACTION_REPAIR_QUALITY_THRESHOLD",
            _DEFAULT_REPAIR_QUALITY_THRESHOLD,
        )
        header_evidence_repair_threshold = env_float(
            "STRUCTURED_EXTRACTION_HEADER_EVIDENCE_REPAIR_THRESHOLD",
            _DEFAULT_HEADER_EVIDENCE_REPAIR_THRESHOLD,
        )
        orphan_row_repair_threshold = env_float(
            "STRUCTURED_EXTRACTION_ORPHAN_ROW_REPAIR_THRESHOLD",
            _DEFAULT_ORPHAN_ROW_REPAIR_THRESHOLD,
        )
        repair_max_windows = max(
            0,
            env_int(
                "STRUCTURED_EXTRACTION_REPAIR_MAX_WINDOWS_PER_DOC",
                _DEFAULT_REPAIR_MAX_WINDOWS_PER_DOC,
            ),
        )

        # Truncate if too long
        text = document_text[:_MAX_EXTRACTION_CHARS]
        if len(document_text) > _MAX_EXTRACTION_CHARS:
            logger.warning(
                "Document text truncated from %d to %d chars",
                len(document_text),
                _MAX_EXTRACTION_CHARS,
            )

        # ---- LLM call for full extraction ----
        first_pass = self._call_llm_extraction(
            text,
            title_hint,
            model_override=extraction_model,
        )
        first_rows, first_normalization = self._build_extraction_rows(
            extraction_result=first_pass,
            chunk_text=text,
            document_id=document_id,
            tenant_id=tenant_id,
            user_id=user_id,
            chunk_id=chunk_id,
            page_number=page_number,
            pipeline_version=pipeline_version,
            now=datetime.now(timezone.utc),
            enhanced_fields_enabled=enhanced_fields_enabled,
            extraction_v3_enabled=extraction_v3_enabled,
            prefer_declared_value_type=prefer_declared_value_type,
            enforce_identifier_string=enforce_identifier_string,
            enable_synthetic_row_ref=enable_synthetic_row_ref,
        )
        first_quality = evaluate_chunk_quality(first_rows, text)

        selected_result = first_pass
        selected_rows = first_rows
        selected_normalization = first_normalization
        selected_quality = first_quality

        repair_attempted = False
        repair_used = False
        repair_quality_delta = 0.0
        repair_issues = list(first_quality["issues"])

        quality_metrics = first_quality.get("metrics", {})
        header_ratio = float(quality_metrics.get("header_like_evidence_ratio") or 0.0)
        orphan_ratio = float(quality_metrics.get("orphan_row_metric_ratio") or 0.0)
        needs_repair = (
            first_quality["quality_score"] < repair_quality_threshold
            or header_ratio >= header_evidence_repair_threshold
            or orphan_ratio >= orphan_row_repair_threshold
        )

        if (
            repair_enabled
            and needs_repair
            and self._can_attempt_repair(document_id, repair_max_windows)
        ):
            repair_attempted = True
            self._mark_repair_attempt(document_id)
            repaired = self._call_llm_repair(
                text=text,
                title_hint=title_hint,
                first_pass=first_pass,
                quality_issues=repair_issues,
                model_override=extraction_model,
            )
            if repaired is not None:
                repaired_rows, repaired_normalization = self._build_extraction_rows(
                    extraction_result=repaired,
                    chunk_text=text,
                    document_id=document_id,
                    tenant_id=tenant_id,
                    user_id=user_id,
                    chunk_id=chunk_id,
                    page_number=page_number,
                    pipeline_version=pipeline_version,
                    now=datetime.now(timezone.utc),
                    enhanced_fields_enabled=enhanced_fields_enabled,
                    extraction_v3_enabled=extraction_v3_enabled,
                    prefer_declared_value_type=prefer_declared_value_type,
                    enforce_identifier_string=enforce_identifier_string,
                    enable_synthetic_row_ref=enable_synthetic_row_ref,
                )
                repaired_quality = evaluate_chunk_quality(repaired_rows, text)
                repair_quality_delta = (
                    repaired_quality["quality_score"] - first_quality["quality_score"]
                )
                if repaired_quality["quality_score"] > first_quality["quality_score"]:
                    selected_result = repaired
                    selected_rows = repaired_rows
                    selected_normalization = repaired_normalization
                    selected_quality = repaired_quality
                    repair_used = True

        # ---- Build document metadata row ----
        now = datetime.now(timezone.utc)
        doc_meta = {
            "document_id": document_id,
            "tenant_id": tenant_id,
            "user_id": user_id,
            "resource_id": resource_id,
            "file_name": file_name,
            "document_type": selected_result.document_type,
            "title": selected_result.title,
            "summary": selected_result.summary,
            "key_topics": selected_result.key_topics,
            "overall_confidence": selected_result.overall_confidence,
            "extraction_status": "completed",
            "extraction_timestamp": now,
            "created_at": now,
            "updated_at": now,
        }

        chunk_audit = {
            "pipeline_version": pipeline_version,
            "quality_score_first_pass": round(first_quality["quality_score"], 4),
            "quality_score_final": round(selected_quality["quality_score"], 4),
            "quality_issues": selected_quality["issues"],
            "repair_attempted": repair_attempted,
            "repair_used": repair_used,
            "repair_quality_delta": round(repair_quality_delta, 4),
            "typed_corrections": selected_normalization["typed_corrections"],
            "identifier_string_enforced": selected_normalization["identifier_string_enforced"],
            "suspicious_unit_cleared": selected_normalization["suspicious_unit_cleared"],
            "synthetic_row_ref_count": selected_normalization["synthetic_row_ref_count"],
            "tabular_chunk": selected_quality["metrics"]["tabular_chunk"],
            "rows_total": len(selected_rows),
        }

        logger.info(
            "Extraction quality doc=%s score_first=%.3f score_final=%.3f repair_attempted=%s repair_used=%s issues=%s",
            document_id,
            first_quality["quality_score"],
            selected_quality["quality_score"],
            repair_attempted,
            repair_used,
            selected_quality["issues"],
        )
        logger.info(
            "Extraction complete for doc=%s: type=%s, items=%d",
            document_id,
            selected_result.document_type,
            len(selected_rows),
        )

        return {
            "document_meta": doc_meta,
            "extractions": selected_rows,
            "chunk_audit": chunk_audit,
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _pipeline_version(*, extraction_v3_enabled: bool, reliability_v2_enabled: bool) -> str:
        if extraction_v3_enabled:
            return _PIPELINE_VERSION_V3
        if reliability_v2_enabled:
            return _PIPELINE_VERSION_V2
        return _PIPELINE_VERSION_LEGACY

    def _build_extraction_rows(
        self,
        *,
        extraction_result: DocumentStructuredExtractionResult,
        chunk_text: str,
        document_id: str,
        tenant_id: str,
        user_id: str,
        chunk_id: Optional[str],
        page_number: Optional[int],
        pipeline_version: str,
        now: datetime,
        enhanced_fields_enabled: bool,
        extraction_v3_enabled: bool,
        prefer_declared_value_type: bool,
        enforce_identifier_string: bool,
        enable_synthetic_row_ref: bool,
    ) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
        extraction_rows: List[Dict[str, Any]] = []
        stats = {
            "typed_corrections": 0,
            "identifier_string_enforced": 0,
            "suspicious_unit_cleared": 0,
            "synthetic_row_ref_count": 0,
        }

        chunk_ref = chunk_id or ""
        tabular_chunk = extraction_v3_enabled and looks_tabular_text(chunk_text)

        for item in extraction_result.extracted_items:
            if extraction_v3_enabled:
                normalized_item = normalize_item_semantics(
                    key=item.key,
                    row_ref=item.row_ref,
                    evidence=item.evidence,
                    value=item.value,
                    page_number=page_number,
                    data_type=item.data_type,
                    enable_synthetic_row_ref=enable_synthetic_row_ref,
                    tabular_chunk=tabular_chunk,
                    chunk_text=chunk_text,
                )
            else:
                normalized_item = {
                    "key": item.key,
                    "row_ref": (
                        self._legacy_normalize_row_ref(item.row_ref)
                        if enhanced_fields_enabled
                        else None
                    ),
                    "evidence": item.evidence,
                    "synthetic_row_ref": False,
                }

            parsed = detect_and_parse_value(
                item.value,
                declared_value_type=item.value_type,
                key=normalized_item["key"],
                data_type=item.data_type,
                category=item.category,
                prefer_declared_value_type=prefer_declared_value_type,
                enforce_identifier_string=enforce_identifier_string,
            )
            effective_unit = item.unit or parsed["unit"]
            row_ref = normalized_item["row_ref"] if enhanced_fields_enabled else None
            if normalized_item["synthetic_row_ref"]:
                stats["synthetic_row_ref_count"] += 1
            line_item_id = (
                self._build_line_item_id(
                    document_id=document_id,
                    page_number=page_number,
                    row_ref=row_ref,
                )
                if row_ref
                else None
            )

            row = {
                "extraction_id": str(uuid.uuid4()),
                "document_id": document_id,
                "tenant_id": tenant_id,
                "user_id": user_id,
                "chunk_id": chunk_ref,
                "page_number": page_number,
                # what was extracted
                "data_type": item.data_type,
                "category": item.category,
                "key": normalized_item["key"],
                # typed values (keep native Python types for Athena)
                "value_string": parsed["value_string"],
                "value_number": parsed["value_number"],
                "value_date": parsed["value_date"],
                "value_boolean": parsed["value_boolean"],
                "value_json": parsed["value_json"],
                "value_type": parsed["value_type"],
                "unit": effective_unit,
                "unit_normalized": (
                    self._normalize_unit(effective_unit)
                    if enhanced_fields_enabled
                    else None
                ),
                "value_string_normalized": (
                    self._normalize_text_value(parsed["value_string"])
                    if enhanced_fields_enabled
                    else None
                ),
                "row_ref": row_ref,
                "line_item_id": line_item_id,
                "pipeline_version": pipeline_version,
                # entity context
                "entity_name": item.entity_name,
                "entity_type": item.entity_type,
                "entity_identifiers": item.entity_identifiers or [],
                "related_entity_name": item.related_entity_name,
                "related_entity_type": item.related_entity_type,
                # quality
                "confidence": item.confidence,
                "context": normalized_item["evidence"],
                "evidence": normalized_item["evidence"],
                "tags": self._derive_tags(
                    data_type=item.data_type,
                    category=item.category,
                    entity_type=item.entity_type,
                    unit=effective_unit,
                ),
                # timestamps (native datetime for Athena TIMESTAMP)
                "extracted_at": now,
                "created_at": now,
            }

            if extraction_v3_enabled:
                row, correction_stats = enforce_row_field_safety(
                    row,
                    enforce_identifier_string=enforce_identifier_string,
                )
                for stat_key, stat_val in correction_stats.items():
                    stats[stat_key] += stat_val

            extraction_rows.append(row)

        return extraction_rows, stats

    def _call_llm_extraction(
        self,
        text: str,
        title_hint: Optional[str] = None,
        model_override: Optional[str] = None,
    ) -> DocumentStructuredExtractionResult:
        """Single LLM call that performs all three tiers of extraction."""
        llm = self._get_extraction_llm(model_override)

        prompt = (
            f"System: {P.STRUCTURED_EXTRACTION_SYSTEM}\n\n"
            f"User: Extract all structured information from the following document.\n\n"
            f"Document Title (if known): {title_hint or 'Unknown'}\n"
            f"Document Text:\n---\n{text}\n---\n\n"
            f"Return the complete structured extraction as JSON matching the schema."
        )

        try:
            result = llm.generate_structured(
                prompt,
                DocumentStructuredExtractionResult,
                temperature=0.1,
            )
            return result
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception("LLM structured extraction failed, attempting fallback")
            return self._fallback_extraction(text, title_hint)

    def _call_llm_repair(
        self,
        *,
        text: str,
        title_hint: Optional[str],
        first_pass: DocumentStructuredExtractionResult,
        quality_issues: List[str],
        model_override: Optional[str] = None,
    ) -> Optional[DocumentStructuredExtractionResult]:
        llm = self._get_extraction_llm(model_override)
        first_pass_json = json.dumps(first_pass.model_dump(mode="json"), ensure_ascii=False)
        issues_block = "\n".join(f"- {issue}" for issue in quality_issues) or "- quality_score_below_threshold"

        prompt = (
            f"System: {P.STRUCTURED_EXTRACTION_REPAIR_SYSTEM}\n\n"
            f"User: Repair this first-pass extraction.\n\n"
            f"Title: {title_hint or 'Unknown'}\n"
            f"Quality issues:\n{issues_block}\n\n"
            f"Source text:\n---\n{text}\n---\n\n"
            f"First-pass JSON:\n---\n{first_pass_json}\n---\n\n"
            f"Return corrected extraction JSON matching the schema exactly."
        )
        try:
            return llm.generate_structured(
                prompt,
                DocumentStructuredExtractionResult,
                temperature=0.0,
            )
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception("LLM extraction repair failed")
            return None

    @staticmethod
    def _resolve_extraction_model() -> str:
        model = (os.getenv("STRUCTURED_EXTRACTION_MODEL") or "").strip()
        return model or _DEFAULT_EXTRACTION_MODEL

    def _get_extraction_llm(self, model_override: Optional[str] = None):
        model = (model_override or "").strip() or self._resolve_extraction_model()
        return self.llm_manager.get_llm(
            provider=LLMType.OPENAI,
            model=model,
            category=LLMModelCategory.STRUCTURED,
        )

    @staticmethod
    def _normalize_text_value(value: Optional[str]) -> Optional[str]:
        if value is None:
            return None
        collapsed = re.sub(r"\s+", " ", str(value)).strip().lower()
        return collapsed or None

    @staticmethod
    def _normalize_unit(unit: Optional[str]) -> Optional[str]:
        if unit is None:
            return None
        normalized = str(unit).strip().lower()
        return normalized or None

    @staticmethod
    def _legacy_normalize_row_ref(row_ref: Optional[str]) -> Optional[str]:
        if row_ref is None:
            return None
        normalized = re.sub(r"\s+", "_", str(row_ref).strip())
        if not normalized:
            return None
        return normalized[:64]

    @staticmethod
    def _build_line_item_id(
        *,
        document_id: str,
        page_number: Optional[int],
        row_ref: str,
    ) -> str:
        seed = f"{document_id}|{page_number or ''}|{row_ref}"
        digest = hashlib.sha1(seed.encode("utf-8")).hexdigest()
        return f"li_{digest}"

    def _can_attempt_repair(self, document_id: str, max_windows: int) -> bool:
        with self._repair_lock:
            return self._repair_windows_used_by_doc.get(document_id, 0) < max_windows

    def _mark_repair_attempt(self, document_id: str) -> None:
        with self._repair_lock:
            self._repair_windows_used_by_doc[document_id] = (
                self._repair_windows_used_by_doc.get(document_id, 0) + 1
            )

    def _fallback_extraction(
        self,
        text: str,
        title_hint: Optional[str] = None,
    ) -> DocumentStructuredExtractionResult:
        """
        Minimal fallback when the LLM call fails.

        Returns a bare-bones result so the pipeline doesn't crash.
        """
        return DocumentStructuredExtractionResult(
            document_type="general",
            title=title_hint or "Unknown Document",
            summary=text[:200] + "..." if len(text) > 200 else text,
            key_topics=[],
            extracted_items=[],
            overall_confidence=0.1,
        )

    @staticmethod
    def _derive_tags(
        *,
        data_type: Optional[str],
        category: Optional[str],
        entity_type: Optional[str],
        unit: Optional[str],
    ) -> List[str]:
        """Build a list of tags from extracted properties for filtering."""
        tags: List[str] = []
        if data_type:
            tags.append(str(data_type))
        if category:
            tags.append(str(category).lower())
        if entity_type:
            tags.append(str(entity_type).lower())
        if unit:
            tags.append(str(unit).lower())
        return tags
