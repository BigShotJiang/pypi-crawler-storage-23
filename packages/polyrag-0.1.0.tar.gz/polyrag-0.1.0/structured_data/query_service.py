"""
StructuredDataQueryService – NL-to-SQL query pipeline.

    user question  →  entity pre-resolution  →  SQL generation  →  execution  →  results

Usage::

    from app.core.services.structured_data.query_service import StructuredDataQueryService

    svc = StructuredDataQueryService()
    result = svc.query("What are the testing parameters for MCC PH102?", tenant_id="org_123")

    print(result["sql"])        # generated Athena SQL
    print(result["rows"])       # query result rows
    print(result["columns"])    # column headers
    print(result["entities"])   # resolved entities used

This module is a thin orchestrator that delegates to focused sub-modules:
- query_entity_resolver  – entity pre-resolution from MongoDB
- query_sql_generator    – prompt assembly + LLM SQL generation
- query_sql_guardrails   – SQL validation, normalization, repair
- query_executor         – Athena execution
- query_result_processor – result quality checks + deduplication
"""

import logging
from typing import Any, Dict, List, Optional, Sequence

from connectors.mongodb_connector import MongoDBConnector
from llm.manager import LLMManager
from .feature_flags import (
    env_bool,
    env_int,
)
from .query_intent import (
    QueryIntent,
    parse_query_intent,
)
from .query_schemas import StructuredQueryResult
from .query_entity_resolver import QueryEntityResolver
from .query_sql_generator import QuerySQLGenerator
from .query_sql_guardrails import QuerySQLGuardrails
from .query_executor import QueryExecutor
from .query_result_processor import QueryResultProcessor

logger = logging.getLogger(__name__)

_DEFAULT_QUERY_PROFILE_HINTS = True
_DEFAULT_QUERY_SQL_GUARDRAILS = True
_DEFAULT_QUERY_MAX_REPAIRS = 1
_DEFAULT_QUERY_ZERO_RESULT_REPAIR = True
_DEFAULT_QUERY_SEMANTIC_REPAIR_ENABLED = True
_DEFAULT_QUERY_SEMANTIC_REPAIR_MAX_PASSES = 1
_DEFAULT_QUERY_RESULT_QUALITY_ENABLED = True
_DEFAULT_QUERY_ENABLE_RESULT_DEDUP = True


class StructuredDataQueryService:
    """
    End-to-end natural language → Athena SQL → results service.

    Step 1: Resolve entity mentions from the question against MongoDB.
    Step 2: Build a rich prompt with resolved entities + schema + patterns.
    Step 3: LLM generates Athena SQL.
    Step 4: Execute the SQL and return results.
    """

    def __init__(self):
        self.mongodb = MongoDBConnector()
        self.llm_manager = LLMManager()

        # Sub-modules
        self._entity_resolver = QueryEntityResolver(self.mongodb)
        self._executor = QueryExecutor()
        self._sql_generator = QuerySQLGenerator(
            llm_manager=self.llm_manager,
            execute_athena_fn=self._executor.execute_athena_query,
        )
        self._guardrails = QuerySQLGuardrails(self.llm_manager)
        self._result_processor = QueryResultProcessor()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query(
        self,
        question: str,
        tenant_id: str,
    ) -> Dict[str, Any]:
        """
        Answer a natural language question by querying structured data in Athena.

        Parameters
        ----------
        question : str
            Natural language question.
        tenant_id : str
            Tenant ID (used as Athena database name).

        Returns
        -------
        dict with keys:
            sql          – the generated SQL query
            reasoning    – LLM's explanation of its strategy
            rows         – list of result dicts
            columns      – list of column names
            total_rows   – number of rows returned
            entities     – resolved entities used in the query
            description  – what the results represent
            error        – error message if something failed (None on success)
        """
        logger.info("Query: %s (tenant=%s)", question, tenant_id)
        query_model = self._resolve_query_model()
        logger.info("Query model selected: openai:%s", query_model)
        extraction_v3 = env_bool("STRUCTURED_EXTRACTION_V3_ENABLED", True)
        use_profile_hints = env_bool(
            "STRUCTURED_QUERY_PROFILE_HINTS",
            _DEFAULT_QUERY_PROFILE_HINTS,
        )
        use_sql_guardrails = env_bool(
            "STRUCTURED_QUERY_SQL_GUARDRAILS",
            _DEFAULT_QUERY_SQL_GUARDRAILS,
        )
        max_repairs = max(
            0,
            env_int("STRUCTURED_QUERY_MAX_REPAIRS", _DEFAULT_QUERY_MAX_REPAIRS),
        )
        use_zero_result_repair = env_bool(
            "STRUCTURED_QUERY_ZERO_RESULT_REPAIR",
            _DEFAULT_QUERY_ZERO_RESULT_REPAIR,
        )
        use_semantic_repair = env_bool(
            "STRUCTURED_QUERY_SEMANTIC_REPAIR_ENABLED",
            _DEFAULT_QUERY_SEMANTIC_REPAIR_ENABLED,
        )
        max_semantic_repairs = max(
            0,
            env_int(
                "STRUCTURED_QUERY_SEMANTIC_REPAIR_MAX_PASSES",
                _DEFAULT_QUERY_SEMANTIC_REPAIR_MAX_PASSES,
            ),
        )
        use_result_quality = env_bool(
            "STRUCTURED_QUERY_RESULT_QUALITY_ENABLED",
            _DEFAULT_QUERY_RESULT_QUALITY_ENABLED,
        )
        use_result_dedup = env_bool(
            "STRUCTURED_QUERY_ENABLE_RESULT_DEDUP",
            _DEFAULT_QUERY_ENABLE_RESULT_DEDUP,
        )
        zero_result_repairs_used = 0
        semantic_repairs_used = 0

        # Step 1: Entity pre-resolution
        entities = self.resolve_entities_from_question(question, tenant_id)
        logger.info("Resolved %d entities from question", len(entities))
        intent = parse_query_intent(question, entities)
        logger.info(
            "Intent parsed: type=%s semantic=%s scope=%s single=%s",
            intent.intent_type,
            intent.semantic_focus,
            intent.scope,
            intent.expects_single_value,
        )

        profile_hints = None
        if use_profile_hints:
            profile_hints = self._build_profile_hints(tenant_id)

        # Step 2: Generate SQL
        prompt = self._build_prompt(
            question=question,
            entities=entities,
            tenant_id=tenant_id,
            profile_hints=profile_hints,
            intent=intent,
        )
        sql_result = self._generate_sql(prompt, model_override=query_model)

        if not sql_result:
            return {
                "sql": None,
                "reasoning": None,
                "rows": [],
                "columns": [],
                "total_rows": 0,
                "entities": entities,
                "description": None,
                "error": "Failed to generate SQL query",
            }

        if use_sql_guardrails:
            guarded_result = self._guardrail_and_repair_sql(
                question=question,
                tenant_id=tenant_id,
                generation_prompt=prompt,
                sql_result=sql_result,
                max_repairs=max_repairs,
                enable_row_context_guardrails=extraction_v3,
                intent=intent,
                model_override=query_model,
            )
            if guarded_result is None:
                return {
                    "sql": sql_result.sql_query,
                    "reasoning": sql_result.reasoning,
                    "rows": [],
                    "columns": [],
                    "total_rows": 0,
                    "entities": entities,
                    "description": sql_result.result_description,
                    "error": "Generated SQL failed validation and repair",
                }
            sql_result = guarded_result

        logger.info("Generated SQL:\n%s", sql_result.sql_query)

        # Step 3: Execute
        exec_result = self._execute_athena_query(sql_result.sql_query, tenant_id)

        # Step 3b: Optional zero-result retry
        if (
            use_zero_result_repair
            and zero_result_repairs_used < 1
            and not exec_result.get("error")
            and int(exec_result.get("total_rows") or 0) == 0
        ):
            retry_sql_result = self._repair_zero_result_sql(
                question=question,
                tenant_id=tenant_id,
                entities=entities,
                generation_prompt=prompt,
                current_sql_result=sql_result,
                profile_hints=profile_hints,
                intent=intent,
                model_override=query_model,
            )
            if retry_sql_result is not None:
                if use_sql_guardrails:
                    guarded_retry = self._guardrail_and_repair_sql(
                        question=question,
                        tenant_id=tenant_id,
                        generation_prompt=prompt,
                        sql_result=retry_sql_result,
                        max_repairs=max_repairs,
                        enable_row_context_guardrails=extraction_v3,
                        intent=intent,
                        model_override=query_model,
                    )
                    if guarded_retry is not None:
                        retry_sql_result = guarded_retry

                retry_exec_result = self._execute_athena_query(
                    retry_sql_result.sql_query,
                    tenant_id,
                )
                zero_result_repairs_used += 1
                if (
                    not retry_exec_result.get("error")
                    and int(retry_exec_result.get("total_rows") or 0) > 0
                ):
                    logger.info(
                        "Zero-result SQL repaired successfully: rows %d -> %d",
                        int(exec_result.get("total_rows") or 0),
                        int(retry_exec_result.get("total_rows") or 0),
                    )
                    sql_result = retry_sql_result
                    exec_result = retry_exec_result

        quality_issues: List[Dict[str, str]] = []
        if use_result_quality and not exec_result.get("error"):
            quality_issues = self._evaluate_result_quality(
                question=question,
                intent=intent,
                sql=sql_result.sql_query,
                exec_result=exec_result,
                entities=entities,
            )

        if (
            use_result_quality
            and use_semantic_repair
            and quality_issues
            and semantic_repairs_used < max_semantic_repairs
        ):
            semantic_repaired = self._repair_sql_result(
                question=question,
                generation_prompt=prompt,
                current_sql_result=sql_result,
                issues=quality_issues,
                model_override=query_model,
            )
            if semantic_repaired is not None:
                if use_sql_guardrails:
                    guarded_semantic = self._guardrail_and_repair_sql(
                        question=question,
                        tenant_id=tenant_id,
                        generation_prompt=prompt,
                        sql_result=semantic_repaired,
                        max_repairs=max_repairs,
                        enable_row_context_guardrails=extraction_v3,
                        intent=intent,
                        model_override=query_model,
                    )
                    if guarded_semantic is not None:
                        semantic_repaired = guarded_semantic

                semantic_exec = self._execute_athena_query(
                    semantic_repaired.sql_query,
                    tenant_id,
                )
                semantic_repairs_used += 1
                if not semantic_exec.get("error"):
                    semantic_quality_issues = self._evaluate_result_quality(
                        question=question,
                        intent=intent,
                        sql=semantic_repaired.sql_query,
                        exec_result=semantic_exec,
                        entities=entities,
                    )
                    if self._is_quality_improved(
                        before=quality_issues,
                        after=semantic_quality_issues,
                    ):
                        logger.info(
                            "Semantic SQL repair accepted: issues %d -> %d",
                            len(quality_issues),
                            len(semantic_quality_issues),
                        )
                        sql_result = semantic_repaired
                        exec_result = semantic_exec
                        quality_issues = semantic_quality_issues
                    else:
                        logger.info(
                            "Semantic SQL repair rejected: issues %d -> %d",
                            len(quality_issues),
                            len(semantic_quality_issues),
                        )

        if quality_issues:
            logger.warning("Result quality issues: %s", quality_issues)

        if exec_result.get("error"):
            return {
                "sql": sql_result.sql_query,
                "reasoning": sql_result.reasoning,
                "rows": [],
                "columns": [],
                "total_rows": 0,
                "entities": entities,
                "description": sql_result.result_description,
                "error": exec_result["error"],
            }

        rows = exec_result["rows"]
        columns = exec_result["columns"]

        if use_result_dedup:
            rows = self._dedupe_result_rows(rows, columns)
            if intent.intent_type == "document_search" or self._question_is_documents_processed(
                question
            ):
                rows = self._dedupe_documents_rows_latest(rows)
            logger.info(
                "Result dedupe applied: rows=%d",
                len(rows),
            )

        return {
            "sql": sql_result.sql_query,
            "reasoning": sql_result.reasoning,
            "rows": rows,
            "columns": columns,
            "total_rows": len(rows),
            "entities": entities,
            "description": sql_result.result_description,
            "error": None,
        }

    # ------------------------------------------------------------------
    # Lazy sub-module access (supports __new__ without __init__ in tests)
    # ------------------------------------------------------------------

    def _get_guardrails(self) -> QuerySQLGuardrails:
        if not hasattr(self, "_guardrails"):
            from llm.manager import LLMManager
            mgr = getattr(self, "llm_manager", None) or LLMManager()
            self._guardrails = QuerySQLGuardrails(mgr)
        return self._guardrails

    def _get_result_processor(self) -> QueryResultProcessor:
        if not hasattr(self, "_result_processor"):
            self._result_processor = QueryResultProcessor()
        return self._result_processor

    def _get_sql_generator(self) -> QuerySQLGenerator:
        if not hasattr(self, "_sql_generator"):
            from llm.manager import LLMManager
            mgr = getattr(self, "llm_manager", None) or LLMManager()
            self._sql_generator = QuerySQLGenerator(llm_manager=mgr)
        return self._sql_generator

    def _get_executor(self) -> QueryExecutor:
        if not hasattr(self, "_executor"):
            self._executor = QueryExecutor()
        return self._executor

    def _get_entity_resolver(self) -> QueryEntityResolver:
        if not hasattr(self, "_entity_resolver"):
            from connectors.mongodb_connector import MongoDBConnector
            db = getattr(self, "mongodb", None) or MongoDBConnector()
            self._entity_resolver = QueryEntityResolver(db)
        return self._entity_resolver

    # ------------------------------------------------------------------
    # Backward-compatible delegations (used by tests)
    # ------------------------------------------------------------------

    def resolve_entities_from_question(
        self, question: str, tenant_id: str
    ) -> List[Dict[str, Any]]:
        return self._get_entity_resolver().resolve_entities_from_question(question, tenant_id)

    def _build_prompt(self, question, entities, tenant_id, profile_hints=None, intent=None):
        return self._get_sql_generator().build_prompt(question, entities, tenant_id, profile_hints, intent)

    def _build_profile_hints(self, tenant_id: str) -> str:
        return self._get_sql_generator().build_profile_hints(tenant_id)

    def _generate_sql(self, prompt, model_override=None):
        return self._get_sql_generator().generate_sql(prompt, model_override)

    def _get_query_llm(self, model_override=None):
        return self._get_sql_generator().get_query_llm(model_override)

    def _execute_athena_query(self, sql: str, tenant_id: str) -> Dict[str, Any]:
        return self._get_executor().execute_athena_query(sql, tenant_id)

    def _guardrail_and_repair_sql(self, **kwargs):
        kwargs["get_query_llm_fn"] = self._get_sql_generator().get_query_llm
        return self._get_guardrails().guardrail_and_repair_sql(**kwargs)

    def _repair_zero_result_sql(self, **kwargs):
        kwargs["get_query_llm_fn"] = self._get_sql_generator().get_query_llm
        return self._get_guardrails().repair_zero_result_sql(**kwargs)

    def _repair_sql_result(self, **kwargs):
        kwargs["get_query_llm_fn"] = self._get_sql_generator().get_query_llm
        return self._get_guardrails().repair_sql_result(**kwargs)

    def _detect_sql_issues(self, **kwargs):
        return self._get_guardrails().detect_sql_issues(**kwargs)

    def _evaluate_result_quality(self, **kwargs):
        return self._get_result_processor().evaluate_result_quality(**kwargs)

    # ------------------------------------------------------------------
    # Backward-compatible static/class methods (used by tests)
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_query_model() -> str:
        return QuerySQLGenerator.resolve_query_model()

    @staticmethod
    def _replace_sql(result: StructuredQueryResult, sql_query: str) -> StructuredQueryResult:
        return QuerySQLGuardrails.replace_sql(result, sql_query)

    @classmethod
    def _normalize_sql(cls, sql: str) -> str:
        return QuerySQLGuardrails.normalize_sql(sql)

    @staticmethod
    def _normalize_athena_function_aliases(sql: str) -> str:
        return QuerySQLGuardrails.normalize_athena_function_aliases(sql)

    @staticmethod
    def _normalize_unit_filters(sql: str) -> str:
        return QuerySQLGuardrails.normalize_unit_filters(sql)

    @classmethod
    def _normalize_typed_empty_string_comparisons(cls, sql: str) -> str:
        return QuerySQLGuardrails.normalize_typed_empty_string_comparisons(sql)

    @classmethod
    def _has_typed_empty_string_comparison(cls, sql: str) -> bool:
        return QuerySQLGuardrails.has_typed_empty_string_comparison(sql)

    @staticmethod
    def _question_needs_row_context(question: str) -> bool:
        return QuerySQLGuardrails.question_needs_row_context(question)

    @staticmethod
    def _sql_uses_line_item_join(sql: str) -> bool:
        return QuerySQLGuardrails.sql_uses_line_item_join(sql)

    @staticmethod
    def _extract_where_clause(sql: str) -> str:
        return QuerySQLGuardrails.extract_where_clause(sql)

    @staticmethod
    def _extract_question_terms(question: str) -> List[str]:
        return QuerySQLGuardrails.extract_question_terms(question)

    @staticmethod
    def _is_identifier_value(value) -> bool:
        return QueryResultProcessor.is_identifier_value(value)

    @staticmethod
    def _question_is_documents_processed(question: str) -> bool:
        return QueryResultProcessor.question_is_documents_processed(question)

    @staticmethod
    def _quality_penalty(issues: Sequence[Dict[str, str]]) -> int:
        return QueryResultProcessor.quality_penalty(issues)

    @classmethod
    def _is_quality_improved(cls, *, before, after) -> bool:
        return QueryResultProcessor.is_quality_improved(before=before, after=after)

    @staticmethod
    def _dedupe_result_rows(rows, columns):
        return QueryResultProcessor.dedupe_result_rows(rows, columns)

    @staticmethod
    def _dedupe_documents_rows_latest(rows):
        return QueryResultProcessor.dedupe_documents_rows_latest(rows)

    @staticmethod
    def _format_profile_pairs(rows, value_key, count_key):
        return QuerySQLGenerator._format_profile_pairs(rows, value_key, count_key)
