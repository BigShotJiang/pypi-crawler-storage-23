"""
QueryResultProcessor – Result quality evaluation, deduplication, and formatting.

Handles post-execution quality checks and result deduplication for the
NL-to-SQL pipeline.
"""

import logging
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .query_intent import (
    QueryIntent,
    extract_identifier_like_tokens,
)

logger = logging.getLogger(__name__)

_IDENTIFIER_VALUE_RE = re.compile(
    r"^[A-Za-z]{1,6}[-_]?\d{2,}$|^[A-Za-z0-9]{2,}(?:-[A-Za-z0-9]{2,})+$"
)


class QueryResultProcessor:
    """Result quality evaluation and deduplication."""

    @staticmethod
    def is_identifier_value(value: Any) -> bool:
        if value is None:
            return False
        text = str(value).strip()
        if not text:
            return False
        return bool(_IDENTIFIER_VALUE_RE.match(text))

    @staticmethod
    def question_is_documents_processed(question: str) -> bool:
        q = question.lower()
        return "documents have been processed" in q or "what documents have been processed" in q

    def evaluate_result_quality(
        self,
        *,
        question: str,
        intent: QueryIntent,
        sql: str,
        exec_result: Dict[str, Any],
        entities: List[Dict[str, Any]],
    ) -> List[Dict[str, str]]:
        rows = exec_result.get("rows") or []
        columns = exec_result.get("columns") or []
        issues: List[Dict[str, str]] = []
        q = question.lower()

        if " id " in f" {q} " or "identifier" in q:
            id_columns = [col for col in columns if "id" in col.lower() or "identifier" in col.lower()]
            if id_columns:
                valid = 0
                for row in rows:
                    for col in id_columns:
                        if self.is_identifier_value(row.get(col)):
                            valid += 1
                            break
                if rows and valid == 0:
                    issues.append(
                        {
                            "code": "wrong_value_type_identifier",
                            "severity": "critical",
                            "message": "Identifier-like question returned rows without identifier-like values.",
                        }
                    )

        if intent.intent_type == "attribute_lookup" and intent.expects_single_value:
            if len(rows) > 12:
                issues.append(
                    {
                        "code": "row_explosion_attribute_lookup",
                        "severity": "warning",
                        "message": "Single-value lookup returned too many rows; query may be under-constrained.",
                    }
                )

        if intent.intent_type == "document_search":
            mention_tokens = extract_identifier_like_tokens(question)
            mention_capable_columns = {"file_name", "title", "summary", "evidence", "value_string", "value_string_normalized"}
            has_mention_capable_column = bool(set(columns) & mention_capable_columns)
            if mention_tokens and not has_mention_capable_column:
                issues.append(
                    {
                        "code": "document_mention_columns_missing",
                        "severity": "warning",
                        "message": "Document search result lacks mention-capable columns for verification.",
                    }
                )
            where_clause = self._extract_where_clause(sql)
            if mention_tokens and not any(
                token.lower() in where_clause.lower() for token in mention_tokens
            ):
                issues.append(
                    {
                        "code": "document_mention_token_not_applied",
                        "severity": "warning",
                        "message": "Document search SQL does not appear to apply identifier/code token filters.",
                    }
                )

        if (
            intent.semantic_focus == "specification"
            and rows
            and any(
                "result" in str(row.get("key", "")).lower()
                or "observed" in str(row.get("key", "")).lower()
                for row in rows
            )
            and not any(
                "limit" in str(row.get("key", "")).lower()
                or "spec" in str(row.get("key", "")).lower()
                or "criteria" in str(row.get("key", "")).lower()
                for row in rows
            )
        ):
            issues.append(
                {
                    "code": "spec_result_mismatch_post_exec",
                    "severity": "critical",
                    "message": "Specification question returned observed/result rows without limit/spec rows.",
                }
            )

        if entities and intent.scope == "entity_scoped" and not rows:
            issues.append(
                {
                    "code": "undercov_entity_scoped_zero_rows",
                    "severity": "warning",
                    "message": "Entity-scoped query returned zero rows despite resolved entities.",
                }
            )

        return issues

    @staticmethod
    def quality_penalty(issues: Sequence[Dict[str, str]]) -> int:
        penalty = 0
        for issue in issues:
            severity = issue.get("severity", "warning")
            penalty += 5 if severity == "critical" else 1
        return penalty

    @classmethod
    def is_quality_improved(
        cls,
        *,
        before: Sequence[Dict[str, str]],
        after: Sequence[Dict[str, str]],
    ) -> bool:
        return cls.quality_penalty(after) < cls.quality_penalty(before)

    @staticmethod
    def dedupe_result_rows(
        rows: List[Dict[str, Any]],
        columns: List[str],
    ) -> List[Dict[str, Any]]:
        seen: set = set()
        deduped: List[Dict[str, Any]] = []
        for row in rows:
            signature = tuple((col, str(row.get(col, ""))) for col in columns)
            if signature in seen:
                continue
            seen.add(signature)
            deduped.append(row)
        return deduped

    @staticmethod
    def dedupe_documents_rows_latest(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not rows:
            return rows

        grouped: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
        for row in rows:
            key = (
                str(row.get("file_name", "")).strip(),
                str(row.get("title", "")).strip(),
                str(row.get("document_type", "")).strip(),
            )
            current = grouped.get(key)
            if current is None:
                grouped[key] = row
                continue
            current_created = str(current.get("created_at", "")).strip()
            next_created = str(row.get("created_at", "")).strip()
            if next_created > current_created:
                grouped[key] = row

        return list(grouped.values())

    @staticmethod
    def _extract_where_clause(sql: str) -> str:
        match = re.search(
            r"\bWHERE\b(.*?)(?:\bGROUP\s+BY\b|\bORDER\s+BY\b|\bLIMIT\b|$)",
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )
        return match.group(1) if match else ""
