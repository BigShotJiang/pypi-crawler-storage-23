"""
Pydantic schemas for the structured data extraction pipeline.

These schemas are used with ``LLMProvider.generate_structured()`` to get
type-safe structured output from the LLM.
"""

from typing import Any, Dict, List, Literal, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Document Type Inference
# ---------------------------------------------------------------------------

class DocumentTypeInference(BaseModel):
    """LLM output schema for classifying a document into a known type."""

    model_config = {"extra": "forbid"}

    document_type: Literal[
        "invoice",
        "purchase_order",
        "contract",
        "agreement",
        "report",
        "email",
        "memo",
        "presentation",
        "spreadsheet",
        "policy",
        "manual",
        "letter",
        "general",
    ] = Field(..., description="Inferred document type")

    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence score 0-1"
    )

    reasoning: str = Field(
        ..., description="Brief explanation of classification"
    )

    has_line_items: bool = Field(
        default=False,
        description="Contains itemised list (invoices, POs)",
    )
    has_financial_data: bool = Field(
        default=False,
        description="Contains monetary figures, totals, taxes",
    )
    has_dates: bool = Field(
        default=False,
        description="Contains explicit dates (deadlines, effective dates)",
    )
    has_parties: bool = Field(
        default=False,
        description="Contains named parties (buyer/seller, signatories)",
    )


# ---------------------------------------------------------------------------
# Structured Extraction – single extracted item
# ---------------------------------------------------------------------------

class StructuredExtractedItem(BaseModel):
    """A single piece of structured information extracted from a document."""

    model_config = {"extra": "forbid"}

    data_type: Literal[
        "entity", "metric", "date", "attribute", "relationship", "line_item"
    ] = Field(..., description="Kind of extracted information")

    category: str = Field(
        ...,
        description=(
            "Sub-category. For entities: PERSON, ORGANIZATION, PRODUCT, "
            "SERVICE, SYSTEM, CONCEPT. For metrics: financial, quantitative, "
            "percentage. For dates: deadline, effective_date, delivery_date, "
            "period. For attributes: status, identifier, description. "
            "For relationships: ownership, order, employment, supply. "
            "For line_items: product, service."
        ),
    )

    key: str = Field(
        ...,
        description=(
            "Normalised snake_case key describing the data point. "
            "Examples: customer_name, total_amount, delivery_date, "
            "order_status, invoice_number, line_item_1."
        ),
    )

    value: str = Field(
        ...,
        description=(
            "The value exactly as it appears (or closely derived) from the "
            "document. Keep original formatting for numbers/currencies."
        ),
    )

    value_type: Literal["string", "number", "date", "boolean", "json"] = Field(
        ...,
        description="Detected data type of the value.",
    )

    entity_name: Optional[str] = Field(
        None,
        description=(
            "Primary subject entity for this fact/row. "
            "Use related_entity_name for parent/linked context when different."
        ),
    )

    entity_type: Optional[str] = Field(
        None,
        description="Type of the associated entity (PERSON, ORGANIZATION, etc.)",
    )

    entity_identifiers: Optional[List[str]] = Field(
        default=None,
        description=(
            "Codes, IDs, or reference numbers that uniquely identify the entity. "
            "E.g. product codes like 'RM-MCC-0102', customer IDs like 'AH-2024-001', "
            "invoice numbers like 'INV-12345'. These are MORE RELIABLE than names "
            "for matching entities across documents."
        ),
    )

    related_entity_name: Optional[str] = Field(
        None,
        description=(
            "Name of a linked/parent entity when applicable. "
            "For row-level facts, this can hold parent document context."
        ),
    )

    related_entity_type: Optional[str] = Field(
        None,
        description="Type of the related entity.",
    )

    unit: Optional[str] = Field(
        None,
        description="Unit for numeric values (USD, kg, %, units, etc.)",
    )

    confidence: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Extraction confidence 0-1",
    )

    evidence: str = Field(
        ...,
        description="Short verbatim quote from the document supporting this extraction.",
    )

    page_or_section: Optional[str] = Field(
        None,
        description="Page number or section where this was found.",
    )

    row_ref: Optional[str] = Field(
        None,
        description=(
            "Optional short row/group reference for tabular or list-based facts. "
            "Reuse the exact same row_ref for all values from the same source row."
        ),
    )


# ---------------------------------------------------------------------------
# Full structured extraction result
# ---------------------------------------------------------------------------

class DocumentStructuredExtractionResult(BaseModel):
    """Complete structured extraction output from a single document chunk."""

    model_config = {"extra": "forbid"}

    document_type: str = Field(
        ..., description="Inferred document type"
    )

    title: str = Field(
        ..., description="Document title (explicit or inferred)"
    )

    summary: str = Field(
        ..., description="2-4 sentence summary of document content"
    )

    key_topics: List[str] = Field(
        default_factory=list,
        description="3-7 main topics or themes",
    )

    extracted_items: List[StructuredExtractedItem] = Field(
        default_factory=list,
        description=(
            "All structured data points extracted from the document. "
            "Include ALL entities, metrics, dates, attributes, "
            "relationships, and line items found."
        ),
    )

    overall_confidence: float = Field(
        default=0.8,
        ge=0.0,
        le=1.0,
        description="Overall confidence in the extraction quality",
    )


# ---------------------------------------------------------------------------
# Entity matching schema (used by EntityResolver for LLM-based matching)
# ---------------------------------------------------------------------------

class EntityMatchResult(BaseModel):
    """LLM output for deciding if two entity mentions refer to the same entity."""

    model_config = {"extra": "forbid"}

    is_same_entity: bool = Field(
        ..., description="True if both mentions refer to the same real-world entity"
    )

    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Confidence 0-1"
    )

    canonical_name: str = Field(
        ...,
        description=(
            "The best canonical name to use for this entity "
            "(usually the most complete / formal version)."
        ),
    )

    reasoning: str = Field(
        ..., description="Brief explanation"
    )
