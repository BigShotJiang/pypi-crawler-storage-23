"""
Standalone runner for the Structured Data Pipeline.

Usage:
    # From command line
    python -m app.core.services.structured_data.run /path/to/file.pdf --tenant org_123 --user user_456

    # From Python
    from app.core.services.structured_data.run import run_pipeline
    result = run_pipeline("/path/to/invoice.pdf", tenant_id="org_123", user_id="user_456")
"""

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Optional

# Ensure project root is on sys.path so imports work when invoked directly
_PROJECT_ROOT = str(Path(__file__).resolve().parents[1])
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

try:
    # Works when invoked as a module: `python -m structured_data.run`
    from .pipeline import StructuredDataPipeline
except ImportError:
    # Works when invoked as a script: `python structured_data/run.py`
    from structured_data.pipeline import StructuredDataPipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)


def run_pipeline(
    file_path: str,
    tenant_id: str,
    user_id: str,
    resource_id: Optional[str] = None,
    document_id: Optional[str] = None,
    use_llm_entity_matching: bool = False,
    similarity_threshold: float = 0.82,
) -> dict:
    """
    Run the full structured data pipeline on a single file.

    Parameters
    ----------
    file_path : str
        Path to the document (PDF, DOCX, TXT, MD, XLSX, CSV, PPTX, etc.)
    tenant_id : str
        Tenant / organisation ID for multi-tenant isolation.
    user_id : str
        ID of the user who uploaded the document.
    resource_id : str, optional
        External resource identifier (defaults to generated uuid).
    document_id : str, optional
        Pre-assigned document ID (defaults to generated uuid).
    use_llm_entity_matching : bool
        Enable expensive LLM-based entity resolution for ambiguous cases.
    similarity_threshold : float
        Fuzzy-match threshold for entity resolution (0-1).

    Returns
    -------
    dict
        Pipeline result with keys:
        - document_id
        - document_meta  (title, type, summary, ...)
        - extraction_count
        - entities_resolved
        - new_entities
        - athena_documents_location
        - athena_extracted_data_location
    """
    import uuid

    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    resource_id = resource_id or str(uuid.uuid4())

    pipeline = StructuredDataPipeline(
        use_llm_entity_matching=use_llm_entity_matching,
        similarity_threshold=similarity_threshold,
    )

    logger.info("=" * 60)
    logger.info("STRUCTURED DATA PIPELINE")
    logger.info("=" * 60)
    logger.info("File:      %s", path.name)
    logger.info("Tenant:    %s", tenant_id)
    logger.info("User:      %s", user_id)
    logger.info("Resource:  %s", resource_id)
    logger.info("-" * 60)

    result = pipeline.process_file(
        file_path=str(path),
        tenant_id=tenant_id,
        user_id=user_id,
        resource_id=resource_id,
        document_id=document_id,
    )

    # ---- Print summary ----
    logger.info("-" * 60)
    if "error" in result:
        logger.error("Pipeline failed: %s", result["error"])
        return result

    meta = result.get("document_meta", {})
    logger.info("Document ID:        %s", result["document_id"])
    logger.info("Title:              %s", meta.get("title"))
    logger.info("Type:               %s", meta.get("document_type"))
    logger.info("Summary:            %s", (meta.get("summary") or "")[:120])
    logger.info("Extractions:        %d", result["extraction_count"])
    logger.info("Entities resolved:  %d", result["entities_resolved"])
    logger.info("New entities:       %d", result["new_entities"])
    if result.get("llm_budget_estimate"):
        est = result["llm_budget_estimate"]
        logger.info(
            "LLM estimate:       req=%s total_tokens=%s min_minutes@tpm=%s model=%s",
            est.get("estimated_request_count"),
            est.get("estimated_total_tokens"),
            est.get("estimated_min_minutes_at_tpm"),
            est.get("provider_model"),
        )
    logger.info("Athena docs table:  %s", result.get("athena_documents_location"))
    logger.info("Athena data table:  %s", result.get("athena_extracted_data_location"))
    logger.info("=" * 60)

    return result


# -----------------------------------------------------------------------
# CLI entry point
# -----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Run the Structured Data Pipeline on a single file.",
    )
    parser.add_argument(
        "file",
        help="Path to the document file (PDF, DOCX, TXT, MD, etc.)",
    )
    parser.add_argument(
        "--tenant", "-t",
        required=True,
        help="Tenant / organisation ID",
    )
    parser.add_argument(
        "--user", "-u",
        required=True,
        help="User ID",
    )
    parser.add_argument(
        "--resource", "-r",
        default=None,
        help="Resource ID (auto-generated if omitted)",
    )
    parser.add_argument(
        "--document-id",
        default=None,
        help="Pre-assigned document ID (auto-generated if omitted)",
    )
    parser.add_argument(
        "--llm-matching",
        action="store_true",
        default=False,
        help="Enable LLM-based entity matching (slower, more accurate)",
    )
    parser.add_argument(
        "--similarity",
        type=float,
        default=0.82,
        help="Fuzzy-match threshold for entity resolution (default: 0.82)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Print full result as JSON to stdout",
    )

    args = parser.parse_args()

    result = run_pipeline(
        file_path=args.file,
        tenant_id=args.tenant,
        user_id=args.user,
        resource_id=args.resource,
        document_id=args.document_id,
        use_llm_entity_matching=args.llm_matching,
        similarity_threshold=args.similarity,
    )

    if args.json:
        # Serialise datetimes etc. safely
        print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    # main()
    result = run_pipeline(
    file_path="structured_data/data/rep_BillofMaterial_428.pdf",
    tenant_id="org_123",
    user_id="user_456",
)
