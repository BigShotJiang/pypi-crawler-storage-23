"""
Shared factual validation helpers for evaluation scripts.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

_WARN_SEMANTIC = "SEMANTIC_MISMATCH"
_WARN_UNDER = "UNDERCOVERAGE"
_WARN_DUP = "DUPLICATE_INFLATION"
_WARN_TYPE = "WRONG_VALUE_TYPE"

_ID_RE = re.compile(r"^[A-Za-z]{1,6}[-_]?\d{2,}$|^[A-Za-z0-9]{2,}(?:-[A-Za-z0-9]{2,})+$")


def _duplicate_ratio(rows: List[Dict[str, Any]], columns: List[str]) -> float:
    if not rows or not columns:
        return 0.0
    seen = set()
    dupes = 0
    for row in rows:
        sig = tuple((col, str(row.get(col, ""))) for col in columns)
        if sig in seen:
            dupes += 1
        else:
            seen.add(sig)
    return dupes / max(1, len(rows))


def _has_identifier_value(rows: List[Dict[str, Any]], columns: List[str]) -> bool:
    id_cols = [col for col in columns if "id" in col.lower() or "identifier" in col.lower()]
    if id_cols:
        for row in rows:
            for col in id_cols:
                value = str(row.get(col, "")).strip()
                if _ID_RE.match(value):
                    return True
        return False

    # Fallback: search all columns if explicit ID columns are not present.
    for row in rows:
        for col in columns:
            value = str(row.get(col, "")).strip()
            if _ID_RE.match(value):
                return True
    return False


def _specification_semantics_ok(rows: List[Dict[str, Any]]) -> bool:
    if not rows:
        return False
    has_spec = False
    has_result_only = False
    for row in rows:
        key = str(row.get("key", "")).lower()
        val = str(row.get("value_string", "")).lower()
        if any(tok in key for tok in ("limit", "spec", "criteria")) or any(tok in val for tok in ("nmt", "nlt")):
            has_spec = True
        if any(tok in key for tok in ("result", "observed", "actual")):
            has_result_only = True
    if has_spec:
        return True
    return not has_result_only


def evaluate_query_result(
    *,
    question: str,
    result: Dict[str, Any],
) -> Tuple[str, List[str], Dict[str, Any]]:
    """
    Return (status, warn_reasons, checks) using hybrid factual checks.
    """
    warn_reasons: List[str] = []
    rows = result.get("rows") or []
    columns = result.get("columns") or []
    checks: Dict[str, Any] = {
        "non_empty": bool(rows),
        "duplicate_ratio": round(_duplicate_ratio(rows, columns), 4),
        "identifier_semantics_ok": True,
        "spec_semantics_ok": True,
    }

    if result.get("error"):
        return "FAIL", ["EXECUTION_ERROR"], checks

    if not rows:
        warn_reasons.append(_WARN_UNDER)

    q = question.lower()

    if (" id " in f" {q} " or "identifier" in q) and rows:
        checks["identifier_semantics_ok"] = _has_identifier_value(rows, columns)
        if not checks["identifier_semantics_ok"]:
            warn_reasons.append(_WARN_TYPE)

    if ("specification" in q or " limit" in q or "limits" in q) and rows:
        checks["spec_semantics_ok"] = _specification_semantics_ok(rows)
        if not checks["spec_semantics_ok"]:
            warn_reasons.append(_WARN_SEMANTIC)

    # Duplicate inflation threshold (hybrid mode): tolerate small duplication, warn when significant.
    if checks["duplicate_ratio"] > 0.25:
        warn_reasons.append(_WARN_DUP)

    if warn_reasons:
        return "WARN", sorted(set(warn_reasons)), checks
    return "PASS", [], checks
