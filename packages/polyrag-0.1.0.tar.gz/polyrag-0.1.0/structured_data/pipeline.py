"""
StructuredDataPipeline – end-to-end orchestrator.

    parse  ->  extract  ->  resolve  ->  consolidate  ->  store  ->  [knowledge graph]

Usage::

    from app.core.services.structured_data import StructuredDataPipeline

    pipeline = StructuredDataPipeline()

    # Option A: from raw file on disk
    result = pipeline.process_file(
        file_path="/tmp/invoice.pdf",
        tenant_id="org_123",
        user_id="user_456",
        resource_id="res_789",
    )

    # Option B: from already-parsed text
    result = pipeline.process_text(
        text="...",
        file_name="invoice.pdf",
        tenant_id="org_123",
        user_id="user_456",
        resource_id="res_789",
    )

    # result dict:
    # {
    #     "document_id": "...",
    #     "document_meta": { ... },
    #     "extraction_count": 42,
    #     "entities_resolved": 7,
    #     "new_entities": 2,
    #     "athena_documents_location": "s3://...",
    #     "athena_extracted_data_location": "s3://...",
    #     "knowledge_graph": { ... },  # if KG_ENABLED=true
    # }
"""

import hashlib
import logging
import os
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from difflib import SequenceMatcher
from math import ceil
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.config.llm import get_llm_config
from .extractor import DocumentStructuredExtractor
from .entity_resolver import EntityResolver
from .entity_consolidator import EntityConsolidator
from .chunking import ExtractionChunkWindow, build_extraction_windows
from structured_data.storage.factory import get_storage
from . import prompts as SP

logger = logging.getLogger(__name__)

_DEFAULT_STRUCTURED_CHUNKING_V2_ENABLED = True
_DEFAULT_STRUCTURED_CHUNK_TARGET_CHARS = 10_000
_DEFAULT_STRUCTURED_CHUNK_MAX_CHARS = 12_000
_DEFAULT_STRUCTURED_CHUNK_OVERLAP_CHARS = 500
_DEFAULT_STRUCTURED_CHUNK_USE_PAGE_WINDOWS = True
_DEFAULT_STRUCTURED_CHUNK_DEDUP_OVERLAP = True
_DEFAULT_STRUCTURED_CHUNK_TABLE_SAFE_SPLIT = True
_DEFAULT_STRUCTURED_CHUNK_TABLE_MIN_TARGET_CHARS = 2_500
_DEFAULT_STRUCTURED_CHUNK_TABLE_MIN_MAX_CHARS = 3_200
_DEFAULT_SEMANTIC_DEDUP_ENABLED = True
_DEFAULT_SEMANTIC_DEDUP_THRESHOLD = 0.85
_DEFAULT_CONCURRENT_EXTRACTION_ENABLED = True
_DEFAULT_CONCURRENT_MAX_WORKERS = 3


class StructuredDataPipeline:
    """
    End-to-end structured data processing pipeline.

    1. **Parse** – convert file to text (PDFs use pdfplumber first, OCR-like
       PDFs fallback to unified parser).
    2. **Extract** – LLM-based structured extraction (3-tier model).
    3. **Resolve** – map entity mentions to canonical entity IDs.
    4. **Consolidate** – merge new data into entity master records.
    5. **Store** – persist to Athena (documents + extracted_data tables).
    """

    def __init__(
        self,
        use_llm_entity_matching: bool = False,
        similarity_threshold: float = 0.82,
    ):
        self.extractor = DocumentStructuredExtractor()
        self.resolver = EntityResolver(
            similarity_threshold=similarity_threshold,
            use_llm_matching=use_llm_entity_matching,
        )
        self.consolidator = EntityConsolidator()
        self.storage = get_storage()

    # ------------------------------------------------------------------
    # Public: process a raw file
    # ------------------------------------------------------------------

    def process_file(
        self,
        file_path: str,
        tenant_id: str,
        user_id: str,
        resource_id: str,
        document_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Full pipeline starting from a local file path.

        Supported formats: PDF, DOCX, TXT, MD, PPTX, CSV, XLSX, XML
        (anything the unified parser handles).
        """
        path = Path(file_path)
        file_name = path.name

        logger.info("Pipeline start: file=%s tenant=%s", file_name, tenant_id)

        # --- 1. Parse ---
        text, title_hint = self._parse_file(file_path)
        if not text:
            logger.error("Parsing returned empty text for %s", file_path)
            return {"error": "parsing_failed", "file": file_name}

        # --- 2-5. Delegate to process_text ---
        return self.process_text(
            text=text,
            file_name=file_name,
            tenant_id=tenant_id,
            user_id=user_id,
            resource_id=resource_id,
            document_id=document_id,
            title_hint=title_hint,
        )

    # ------------------------------------------------------------------
    # Public: process already-parsed text
    # ------------------------------------------------------------------

    def process_text(
        self,
        text: str,
        file_name: str,
        tenant_id: str,
        user_id: str,
        resource_id: str,
        document_id: Optional[str] = None,
        title_hint: Optional[str] = None,
        chunk_id: Optional[str] = None,
        page_number: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Pipeline from pre-parsed text.

        The pipeline builds extraction windows, extracts each window
        independently, then merges results. By default chunking v2 uses
        smaller overlapping windows with optional page awareness. Legacy
        chunking can be re-enabled via env flag.
        Reliability enhancements are globally enabled by default and backward compatible:
        - v2 adds row-linkage and SQL/entity guardrail metadata.
        - v3 adds stricter extraction contract safety, field normalization,
          and conditional repair pass for low-quality chunks.
        Existing tenant-allowlist flags can still be used for scoped rollback.

        Steps:
        1. Chunk the text (if needed).
        2. Extract structured data from each chunk via LLM.
        3. Merge all extractions.
        4. Resolve entities.
        5. Consolidate entity master.
        6. Store in Athena.
        """
        # Deterministic document ID for idempotency: same inputs → same ID
        if document_id:
            doc_id = document_id
        elif self._env_bool("STRUCTURED_PIPELINE_DETERMINISTIC_DOC_ID", True):
            id_seed = f"{tenant_id}|{resource_id}|{file_name}"
            doc_id = hashlib.sha256(id_seed.encode()).hexdigest()[:32]
            logger.info(
                "Deterministic document_id=%s from tenant=%s resource=%s file=%s",
                doc_id, tenant_id, resource_id, file_name,
            )
        else:
            doc_id = str(uuid.uuid4())

        reliability_v2 = self._env_bool("STRUCTURED_RELIABILITY_V2_ENABLED", True)
        extraction_v3 = self._env_bool("STRUCTURED_EXTRACTION_V3_ENABLED", True)

        # --- 1. Chunk + Extract ---
        windows, chunk_mode, chunk_config = self._build_chunk_windows(text)
        llm_budget_estimate = self._estimate_llm_budget(
            text=text,
            windows=windows,
            title_hint=title_hint,
        )
        page_coverage = self._window_page_coverage(windows)
        logger.info(
            "Chunking mode=%s windows=%d target=%s max=%s overlap=%s use_page_windows=%s table_safe_split=%s table_min_target=%s table_min_max=%s page_coverage=%s reliability_v2=%s extraction_v3=%s",
            chunk_mode,
            len(windows),
            chunk_config.get("target_chars"),
            chunk_config.get("max_chars"),
            chunk_config.get("overlap_chars"),
            chunk_config.get("use_page_windows"),
            chunk_config.get("table_safe_split"),
            chunk_config.get("table_min_target_chars"),
            chunk_config.get("table_min_max_chars"),
            page_coverage,
            reliability_v2,
            extraction_v3,
        )
        logger.info(
            "Processing doc=%s: %d chars -> %d chunk(s) mode=%s llm_estimate=%s",
            doc_id, len(text), len(windows), chunk_mode, llm_budget_estimate,
        )

        all_extractions: List[Dict[str, Any]] = []
        doc_meta = None
        chunk_audits: List[Dict[str, Any]] = []

        use_concurrent = (
            self._env_bool(
                "STRUCTURED_EXTRACTION_CONCURRENT_ENABLED",
                _DEFAULT_CONCURRENT_EXTRACTION_ENABLED,
            )
            and len(windows) > 1
        )
        max_workers = self._env_int(
            "STRUCTURED_EXTRACTION_MAX_WORKERS",
            _DEFAULT_CONCURRENT_MAX_WORKERS,
        )

        def _extract_window(window: ExtractionChunkWindow) -> Dict[str, Any]:
            """Extract a single window (safe for threads)."""
            page_label = self._format_window_pages(window)
            logger.info(
                "Extracting chunk %d/%d (pages=%s, %d chars, overlap=%s)",
                window.chunk_index + 1,
                len(windows),
                page_label,
                window.char_count,
                window.has_overlap,
            )
            window_chunk_id = chunk_id or f"chunk_{window.chunk_index}"
            return self.extractor.extract(
                document_text=window.text,
                document_id=doc_id,
                tenant_id=tenant_id,
                user_id=user_id,
                resource_id=resource_id,
                file_name=file_name,
                chunk_id=window_chunk_id,
                page_number=window.start_page or (window.chunk_index + 1),
                title_hint=title_hint,
            )

        if use_concurrent:
            logger.info(
                "Concurrent extraction: workers=%d chunks=%d",
                min(max_workers, len(windows)),
                len(windows),
            )
            # Use ThreadPoolExecutor for concurrent LLM calls
            results_by_index: Dict[int, Dict[str, Any]] = {}
            with ThreadPoolExecutor(max_workers=min(max_workers, len(windows))) as executor:
                future_to_idx = {
                    executor.submit(_extract_window, window): window.chunk_index
                    for window in windows
                }
                for future in as_completed(future_to_idx):
                    idx = future_to_idx[future]
                    try:
                        results_by_index[idx] = future.result()
                    except Exception:
                        logger.exception("Chunk %d extraction failed", idx)
                        results_by_index[idx] = {"document_meta": None, "extractions": []}

            # Process results in original chunk order
            for window in windows:
                extraction_result = results_by_index[window.chunk_index]
                if doc_meta is None and extraction_result.get("document_meta"):
                    doc_meta = extraction_result["document_meta"]
                    doc_meta["total_chunks"] = len(windows)
                all_extractions.extend(extraction_result.get("extractions", []))
                chunk_audit = extraction_result.get("chunk_audit")
                if isinstance(chunk_audit, dict):
                    chunk_audits.append(chunk_audit)
        else:
            # Serial fallback
            for window in windows:
                extraction_result = _extract_window(window)

                if doc_meta is None:
                    doc_meta = extraction_result["document_meta"]
                    doc_meta["total_chunks"] = len(windows)

                all_extractions.extend(extraction_result["extractions"])
                chunk_audit = extraction_result.get("chunk_audit")
                if isinstance(chunk_audit, dict):
                    chunk_audits.append(chunk_audit)

        # Log chunk audits
        for audit in chunk_audits:
            logger.info(
                "Chunk audit: quality_first=%s quality_final=%s repair_attempted=%s repair_used=%s typed_corrections=%s synthetic_row_ref=%s issues=%s",
                audit.get("quality_score_first_pass"),
                audit.get("quality_score_final"),
                audit.get("repair_attempted"),
                audit.get("repair_used"),
                audit.get("typed_corrections"),
                audit.get("synthetic_row_ref_count"),
                audit.get("quality_issues"),
            )

        extractions = all_extractions
        if self._env_bool(
            "STRUCTURED_CHUNK_DEDUP_OVERLAP",
            _DEFAULT_STRUCTURED_CHUNK_DEDUP_OVERLAP,
        ):
            before = len(extractions)
            extractions = self._dedupe_extractions(extractions)
            logger.info(
                "Chunk overlap dedupe: before=%d after=%d removed=%d",
                before,
                len(extractions),
                before - len(extractions),
            )

        # --- Semantic dedup: catch near-identical facts across chunks ---
        if self._env_bool(
            "STRUCTURED_EXTRACTION_SEMANTIC_DEDUP_ENABLED",
            _DEFAULT_SEMANTIC_DEDUP_ENABLED,
        ):
            before_semantic = len(extractions)
            extractions = self._semantic_dedupe_extractions(extractions)
            removed = before_semantic - len(extractions)
            if removed:
                logger.info(
                    "Semantic dedup: before=%d after=%d removed=%d",
                    before_semantic,
                    len(extractions),
                    removed,
                )

        if chunk_audits:
            total_typed_corrections = sum(
                int(audit.get("typed_corrections") or 0) for audit in chunk_audits
            )
            total_identifier_string = sum(
                int(audit.get("identifier_string_enforced") or 0) for audit in chunk_audits
            )
            total_suspicious_unit_cleared = sum(
                int(audit.get("suspicious_unit_cleared") or 0) for audit in chunk_audits
            )
            total_synthetic_rows = sum(
                int(audit.get("synthetic_row_ref_count") or 0) for audit in chunk_audits
            )
            repairs_attempted = sum(
                1 for audit in chunk_audits if audit.get("repair_attempted")
            )
            repairs_used = sum(1 for audit in chunk_audits if audit.get("repair_used"))
            logger.info(
                "Extraction normalization summary: chunks=%d repairs_attempted=%d repairs_used=%d typed_corrections=%d identifier_string_enforced=%d suspicious_unit_cleared=%d synthetic_row_ref=%d",
                len(chunk_audits),
                repairs_attempted,
                repairs_used,
                total_typed_corrections,
                total_identifier_string,
                total_suspicious_unit_cleared,
                total_synthetic_rows,
            )

        # --- 2. Resolve entities ---
        entity_map: Dict[str, str] = {}  # entity_name -> entity_id
        new_entity_count = 0

        # Collect unique entities with their identifiers from all extractions
        # key: (name, type) -> set of identifiers
        entity_identifiers: Dict[tuple, set] = defaultdict(set)
        for ext in extractions:
            name = ext.get("entity_name")
            if name:
                key = (name, ext.get("entity_type") or "OTHER")
                # Gather identifiers from this and related extractions
                ids = ext.get("entity_identifiers") or []
                if isinstance(ids, list):
                    entity_identifiers[key].update(i for i in ids if i)

        for (name, etype), ids in entity_identifiers.items():
            res = self.resolver.resolve(
                entity_name=name,
                entity_type=etype,
                tenant_id=tenant_id,
                context=self._gather_context(name, extractions),
                identifiers=list(ids) if ids else None,
            )
            entity_map[name] = res["entity_id"]
            if res["is_new"]:
                new_entity_count += 1

        # Stamp entity_id onto each extraction row
        for ext in extractions:
            name = ext.get("entity_name")
            if name and name in entity_map:
                ext["entity_id"] = entity_map[name]

        # --- 3. Consolidate entity masters ---
        # Group extractions by entity_id
        by_entity: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for ext in extractions:
            eid = ext.get("entity_id")
            if eid:
                by_entity[eid].append(ext)

        for eid, ext_group in by_entity.items():
            self.consolidator.consolidate(
                entity_id=eid,
                tenant_id=tenant_id,
                document_id=doc_id,
                extractions=ext_group,
            )

        # --- 4. Store in Athena (with idempotent replace) ---
        if self._env_bool("STRUCTURED_PIPELINE_DETERMINISTIC_DOC_ID", True):
            self.storage.delete_existing_document(doc_id, tenant_id)
        docs_loc = self.storage.store_document_meta(doc_meta, tenant_id)
        data_loc = self.storage.store_extractions(extractions, tenant_id)

        # --- 5. Build Knowledge Graph (optional) ---
        kg_result = None
        if os.getenv("KG_ENABLED", "").lower() == "true":
            try:
                from knowledge_graph import KnowledgeGraphPipeline

                kg_pipeline = KnowledgeGraphPipeline(tenant_id=tenant_id)
                kg_result = kg_pipeline.process_text(
                    text=text,
                    document_id=doc_id,
                    tenant_id=tenant_id,
                    user_id=user_id,
                    file_name=file_name,
                    title_hint=title_hint,
                    entity_map=entity_map,
                    structured_extractions=extractions,
                )
                logger.info(
                    "Knowledge graph built for doc=%s: %s", doc_id, kg_result
                )
            except Exception:
                logger.warning(
                    "Knowledge graph step failed for doc=%s, continuing without it",
                    doc_id,
                    exc_info=True,
                )

        logger.info(
            "Pipeline complete: doc=%s extractions=%d entities_resolved=%d new=%d",
            doc_id, len(extractions), len(entity_map), new_entity_count,
        )

        result = {
            "document_id": doc_id,
            "document_meta": doc_meta,
            "extraction_count": len(extractions),
            "entities_resolved": len(entity_map),
            "new_entities": new_entity_count,
            "athena_documents_location": docs_loc,
            "athena_extracted_data_location": data_loc,
            "llm_budget_estimate": llm_budget_estimate,
        }
        if kg_result:
            result["knowledge_graph"] = kg_result

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    # Maximum characters per chunk sent to the LLM
    _CHUNK_SIZE = 40_000

    @staticmethod
    def _chunk_text(text: str) -> List[tuple]:
        """
        Legacy v1 chunking logic (kept for rollback compatibility).

        Strategy:
        1. Try to split on page boundaries (``--- Page N ---`` or ``\\f``).
        2. Group pages into chunks of up to ``_CHUNK_SIZE`` chars each.
        3. If no page markers, split by size with paragraph-boundary preference.

        Returns list of ``(chunk_text, page_number_or_None)`` tuples.
        """
        import re

        chunk_size = StructuredDataPipeline._CHUNK_SIZE

        # If short enough, single chunk
        if len(text) <= chunk_size:
            return [(text, None)]

        # --- Try page-level splitting ---
        # Common page markers from PDF parsers
        page_splits = re.split(r"(?:\n---\s*Page\s+\d+\s*---\n|\f)", text)
        page_splits = [p for p in page_splits if p.strip()]

        if len(page_splits) > 1:
            # Group pages into chunks of up to _CHUNK_SIZE
            chunks = []
            current_chunk = ""
            current_start_page = 1

            for i, page_text in enumerate(page_splits, start=1):
                if len(current_chunk) + len(page_text) > chunk_size and current_chunk:
                    chunks.append((current_chunk, current_start_page))
                    current_chunk = page_text
                    current_start_page = i
                else:
                    current_chunk += ("\n\n" if current_chunk else "") + page_text

            if current_chunk:
                chunks.append((current_chunk, current_start_page))

            logger.info(
                "Split %d pages into %d chunks (page-level)",
                len(page_splits), len(chunks),
            )
            return chunks

        # --- Fallback: split by paragraph boundaries ---
        paragraphs = text.split("\n\n")
        chunks = []
        current_chunk = ""
        chunk_num = 1

        for para in paragraphs:
            if len(current_chunk) + len(para) > chunk_size and current_chunk:
                chunks.append((current_chunk, chunk_num))
                current_chunk = para
                chunk_num += 1
            else:
                current_chunk += ("\n\n" if current_chunk else "") + para

        if current_chunk:
            chunks.append((current_chunk, chunk_num))

        logger.info(
            "Split %d chars into %d chunks (paragraph-level)",
            len(text), len(chunks),
        )
        return chunks

    @staticmethod
    def _parse_file(file_path: str) -> tuple:
        """
        Parse a file for ingestion.

        PDFs use a pdfplumber-first strategy with OCR-like fallback to the
        unified parser. Other formats route directly to the unified parser.

        Returns (full_text, title_hint).
        """
        try:
            from parsers.pipeline_text_parser import parse_file_to_text

            parsed = parse_file_to_text(file_path)
            logger.info(
                "File parsed: route=%s ocr_like=%s fallback_reason=%s file=%s",
                parsed.route,
                parsed.ocr_like,
                parsed.fallback_reason or "-",
                file_path,
            )
            return parsed.text, parsed.title_hint

        except Exception:
            logger.exception("Failed to parse file %s", file_path)
            return "", None

    @staticmethod
    def _gather_context(entity_name: str, extractions: List[Dict[str, Any]]) -> str:
        """Collect context snippets for an entity to help resolution."""
        snippets = []
        for ext in extractions:
            if ext.get("entity_name") == entity_name and ext.get("evidence"):
                snippets.append(ext["evidence"])
            if len(snippets) >= 3:
                break
        return " | ".join(snippets)

    def _estimate_llm_budget(
        self,
        text: str,
        windows: List[ExtractionChunkWindow],
        title_hint: Optional[str],
    ) -> Dict[str, Any]:
        """
        Preflight token/request estimate for upload processing.

        This is a non-blocking planning estimate and does not call provider APIs.
        """
        try:
            llm = self.extractor._get_extraction_llm(
                self.extractor._resolve_extraction_model()
            )
            provider_name = getattr(llm, "provider_name", "unknown")
            model = getattr(llm, "model", "unknown")

            llm_config = get_llm_config()
            policy = llm_config.get_rate_limit_policy(provider_name, model)
            output_reserve = int(policy["output_token_reserve"])

            estimated_input_tokens = 0
            structured_requests = len(windows)
            kg_requests = 0

            for window in windows:
                prompt = (
                    f"System: {SP.STRUCTURED_EXTRACTION_SYSTEM}\n\n"
                    f"User: Extract all structured information from the following document.\n\n"
                    f"Document Title (if known): {title_hint or 'Unknown'}\n"
                    f"Document Text:\n---\n{window.text}\n---\n\n"
                    f"Return the complete structured extraction as JSON matching the schema."
                )
                estimated_input_tokens += max(1, int(llm.estimate_tokens(prompt)))

            if os.getenv("KG_ENABLED", "").lower() == "true":
                try:
                    from knowledge_graph import prompts as KGP

                    kg_text = text[:50_000]
                    kg_prompt = (
                        f"System: {KGP.KG_EXTRACTION_SYSTEM}\n\n"
                        f"User: {KGP.KG_EXTRACTION_USER.format(title=title_hint or 'Unknown', document_text=kg_text)}"
                    )
                    estimated_input_tokens += max(1, int(llm.estimate_tokens(kg_prompt)))
                    kg_requests = 1
                except Exception:
                    logger.warning(
                        "Failed to estimate KG prompt tokens; skipping KG estimate",
                        exc_info=True,
                    )

            estimated_request_count = structured_requests + kg_requests
            reserved_output_tokens = estimated_request_count * output_reserve
            estimated_total_tokens = int(
                ceil(
                    (estimated_input_tokens + reserved_output_tokens)
                    * float(policy["safety_factor"])
                )
            )
            tpm = max(1, int(policy["tpm"]))
            estimated_min_minutes = round(estimated_total_tokens / float(tpm), 4)

            return {
                "estimated_request_count": estimated_request_count,
                "estimated_input_tokens": estimated_input_tokens,
                "reserved_output_tokens": reserved_output_tokens,
                "estimated_total_tokens": estimated_total_tokens,
                "provider_model": f"{provider_name}:{model}",
                "estimated_min_minutes_at_tpm": estimated_min_minutes,
                "structured_request_count": structured_requests,
                "kg_request_count": kg_requests,
            }
        except Exception:
            logger.warning(
                "Failed to compute llm_budget_estimate; continuing without estimate",
                exc_info=True,
            )
            return {
                "estimated_request_count": 0,
                "estimated_input_tokens": 0,
                "reserved_output_tokens": 0,
                "estimated_total_tokens": 0,
                "provider_model": "unknown",
                "estimated_min_minutes_at_tpm": 0.0,
            }

    @staticmethod
    def _env_bool(name: str, default: bool) -> bool:
        value = os.getenv(name)
        if value is None:
            return default
        return value.strip().lower() in {"1", "true", "yes", "on"}

    @staticmethod
    def _env_int(name: str, default: int) -> int:
        value = os.getenv(name)
        if value is None:
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            logger.warning("Invalid int for %s=%r. Using default=%d", name, value, default)
            return default

    def _build_chunk_windows(
        self,
        text: str,
    ) -> tuple[List[ExtractionChunkWindow], str, Dict[str, Any]]:
        use_v2 = self._env_bool(
            "STRUCTURED_CHUNKING_V2_ENABLED",
            _DEFAULT_STRUCTURED_CHUNKING_V2_ENABLED,
        )

        if use_v2:
            target_chars = self._env_int(
                "STRUCTURED_CHUNK_TARGET_CHARS",
                _DEFAULT_STRUCTURED_CHUNK_TARGET_CHARS,
            )
            max_chars = self._env_int(
                "STRUCTURED_CHUNK_MAX_CHARS",
                _DEFAULT_STRUCTURED_CHUNK_MAX_CHARS,
            )
            overlap_chars = self._env_int(
                "STRUCTURED_CHUNK_OVERLAP_CHARS",
                _DEFAULT_STRUCTURED_CHUNK_OVERLAP_CHARS,
            )
            # --- Config validation ---
            if target_chars < 2000:
                logger.warning(
                    "STRUCTURED_CHUNK_TARGET_CHARS=%d is very small (< 2000). "
                    "This may produce too many tiny chunks with poor extraction quality. "
                    "Code default is %d.",
                    target_chars,
                    _DEFAULT_STRUCTURED_CHUNK_TARGET_CHARS,
                )
            if max_chars < target_chars:
                logger.warning(
                    "STRUCTURED_CHUNK_MAX_CHARS=%d is less than TARGET_CHARS=%d. "
                    "max_chars should be >= target_chars. Using target as max.",
                    max_chars,
                    target_chars,
                )
                max_chars = target_chars
            use_page_windows = self._env_bool(
                "STRUCTURED_CHUNK_USE_PAGE_WINDOWS",
                _DEFAULT_STRUCTURED_CHUNK_USE_PAGE_WINDOWS,
            )
            table_safe_split = self._env_bool(
                "STRUCTURED_CHUNK_TABLE_SAFE_SPLIT",
                _DEFAULT_STRUCTURED_CHUNK_TABLE_SAFE_SPLIT,
            )
            table_min_target_chars = self._env_int(
                "STRUCTURED_CHUNK_TABLE_MIN_TARGET_CHARS",
                _DEFAULT_STRUCTURED_CHUNK_TABLE_MIN_TARGET_CHARS,
            )
            table_min_max_chars = self._env_int(
                "STRUCTURED_CHUNK_TABLE_MIN_MAX_CHARS",
                _DEFAULT_STRUCTURED_CHUNK_TABLE_MIN_MAX_CHARS,
            )

            windows = build_extraction_windows(
                text=text,
                target_chars=target_chars,
                max_chars=max_chars,
                overlap_chars=overlap_chars,
                use_page_windows=use_page_windows,
                table_safe_split=table_safe_split,
                table_min_target_chars=table_min_target_chars,
                table_min_max_chars=table_min_max_chars,
            )
            if not windows:
                windows = [
                    ExtractionChunkWindow(
                        chunk_index=0,
                        text=text,
                        start_page=None,
                        end_page=None,
                        char_count=len(text),
                        has_overlap=False,
                    )
                ]
            return (
                windows,
                "v2",
                {
                    "target_chars": target_chars,
                    "max_chars": max_chars,
                    "overlap_chars": overlap_chars,
                    "use_page_windows": use_page_windows,
                    "table_safe_split": table_safe_split,
                    "table_min_target_chars": table_min_target_chars,
                    "table_min_max_chars": table_min_max_chars,
                },
            )

        legacy_chunks = self._chunk_text(text)
        windows = [
            ExtractionChunkWindow(
                chunk_index=idx,
                text=chunk_text,
                start_page=chunk_page,
                end_page=chunk_page,
                char_count=len(chunk_text),
                has_overlap=False,
            )
            for idx, (chunk_text, chunk_page) in enumerate(legacy_chunks)
        ]
        return (
            windows,
            "v1",
            {
                "target_chars": self._CHUNK_SIZE,
                "max_chars": self._CHUNK_SIZE,
                "overlap_chars": 0,
                "use_page_windows": False,
                "table_safe_split": False,
                "table_min_target_chars": None,
                "table_min_max_chars": None,
            },
        )

    @staticmethod
    def _window_page_coverage(windows: List[ExtractionChunkWindow]) -> str:
        pages = []
        for win in windows:
            if win.start_page is not None:
                pages.append(win.start_page)
            if win.end_page is not None:
                pages.append(win.end_page)
        if not pages:
            return "-"
        return f"{min(pages)}-{max(pages)}"

    @staticmethod
    def _format_window_pages(window: ExtractionChunkWindow) -> str:
        if window.start_page is None and window.end_page is None:
            return "-"
        if window.start_page == window.end_page or window.end_page is None:
            return str(window.start_page)
        if window.start_page is None:
            return str(window.end_page)
        return f"{window.start_page}-{window.end_page}"

    @staticmethod
    def _normalize_dedupe_value(value: Any) -> Any:
        if isinstance(value, datetime):
            return value.isoformat()
        if isinstance(value, list):
            return tuple(StructuredDataPipeline._normalize_dedupe_value(v) for v in value)
        if isinstance(value, dict):
            return tuple(
                sorted(
                    (str(k), StructuredDataPipeline._normalize_dedupe_value(v))
                    for k, v in value.items()
                )
            )
        return value

    @staticmethod
    def _row_confidence(row: Dict[str, Any]) -> float:
        try:
            return float(row.get("confidence") or 0.0)
        except (TypeError, ValueError):
            return 0.0

    @staticmethod
    def _dedupe_signature(row: Dict[str, Any]) -> tuple:
        signature_fields = (
            "data_type",
            "category",
            "key",
            "value_string",
            "value_number",
            "value_date",
            "value_boolean",
            "value_json",
            "unit",
            "unit_normalized",
            "entity_name",
            "entity_type",
            "entity_identifiers",
            "related_entity_name",
            "related_entity_type",
            "evidence",
            "page_number",
            "row_ref",
            "line_item_id",
            "value_string_normalized",
            "pipeline_version",
        )
        return tuple(
            StructuredDataPipeline._normalize_dedupe_value(row.get(field))
            for field in signature_fields
        )

    @staticmethod
    def _dedupe_extractions(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        best_by_signature: Dict[tuple, tuple[Dict[str, Any], float, int]] = {}
        for idx, row in enumerate(rows):
            key = StructuredDataPipeline._dedupe_signature(row)
            conf = StructuredDataPipeline._row_confidence(row)
            current = best_by_signature.get(key)
            if current is None:
                best_by_signature[key] = (row, conf, idx)
                continue

            _, current_conf, _current_pos = current
            if conf > current_conf:
                best_by_signature[key] = (row, conf, idx)

        deduped = sorted(best_by_signature.values(), key=lambda item: item[2])
        return [item[0] for item in deduped]

    # ------------------------------------------------------------------
    # Semantic dedup – catches near-identical facts across chunks
    # ------------------------------------------------------------------

    @staticmethod
    def _semantic_dedupe_extractions(
        rows: List[Dict[str, Any]],
        threshold: float = _DEFAULT_SEMANTIC_DEDUP_THRESHOLD,
    ) -> List[Dict[str, Any]]:
        """
        Group rows by (document_id, entity_name, key) and within each group
        collapse rows whose value_string is similar above *threshold*.

        Keeps the highest-confidence row and merges evidence from dropped rows.
        """
        if not rows:
            return rows

        # Build groups keyed by (document_id, entity_name, key)
        groups: Dict[tuple, List[tuple[int, Dict[str, Any]]]] = defaultdict(list)
        for idx, row in enumerate(rows):
            group_key = (
                row.get("document_id") or "",
                (row.get("entity_name") or row.get("entity_id") or "").strip().lower(),
                (row.get("key") or "").strip().lower(),
            )
            groups[group_key].append((idx, row))

        kept_indices: set = set()
        evidence_merges: Dict[int, List[str]] = defaultdict(list)

        for group_key, group_rows in groups.items():
            if len(group_rows) <= 1:
                kept_indices.add(group_rows[0][0])
                continue

            # Sort by confidence desc, then original position asc (tiebreaker)
            sorted_group = sorted(
                group_rows,
                key=lambda item: (
                    -StructuredDataPipeline._row_confidence(item[1]),
                    item[0],
                ),
            )

            # Greedy clustering: compare each row against already-kept rows
            cluster_reps: List[tuple[int, Dict[str, Any]]] = []
            for idx, row in sorted_group:
                val = str(row.get("value_string") or "").strip()
                merged = False
                for rep_idx, rep_row in cluster_reps:
                    rep_val = str(rep_row.get("value_string") or "").strip()
                    if not val or not rep_val:
                        continue
                    ratio = SequenceMatcher(None, val, rep_val).ratio()
                    if ratio >= threshold:
                        # Merge evidence into the representative
                        ev = str(row.get("evidence") or "").strip()
                        if ev:
                            evidence_merges[rep_idx].append(ev)
                        merged = True
                        break
                if not merged:
                    cluster_reps.append((idx, row))
                    kept_indices.add(idx)

        # Rebuild the list preserving original order
        result = []
        for idx, row in enumerate(rows):
            if idx in kept_indices:
                # Append any merged evidence
                extra_ev = evidence_merges.get(idx)
                if extra_ev:
                    existing_ev = str(row.get("evidence") or "").strip()
                    unique_ev = []
                    seen = {existing_ev.lower()} if existing_ev else set()
                    for ev in extra_ev:
                        if ev.lower() not in seen:
                            unique_ev.append(ev)
                            seen.add(ev.lower())
                    if unique_ev:
                        merged_evidence = "; ".join(
                            filter(None, [existing_ev] + unique_ev)
                        )
                        row = {**row, "evidence": merged_evidence}
                result.append(row)
        return result
