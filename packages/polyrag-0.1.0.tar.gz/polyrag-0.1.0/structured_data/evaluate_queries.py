"""
Evaluation script: 10 test queries across different patterns to assess
the NL-to-SQL query pipeline accuracy.

Usage:
    python -m app.core.services.structured_data.evaluate_queries
"""

import json
import logging
import sys
from pathlib import Path

_PROJECT_ROOT = str(Path(__file__).resolve().parents[4])
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from app.core.services.structured_data.query_service import StructuredDataQueryService
try:
    from structured_data.evaluation_assertions import evaluate_query_result
except ImportError:  # pragma: no cover - script-local fallback
    from evaluation_assertions import evaluate_query_result

logging.basicConfig(level=logging.WARNING)

TENANT = "org_123"

# ── 10 Test Queries ──────────────────────────────────────────────────
# Each has: question, expected_pattern, what_to_check
TEST_QUERIES = [
    {
        "id": 1,
        "question": "What are the testing parameters for MCC PH102?",
        "pattern": "Entity metrics lookup",
        "expect": "Should return metrics like loss_on_drying, bulk_density, particle_size, heavy_metals etc. with values and units",
    },
    {
        "id": 2,
        "question": "What is the loss on drying specification for Microcrystalline Cellulose?",
        "pattern": "Single attribute lookup",
        "expect": "Should return loss_on_drying = 3.2 (or similar) with evidence from the source document",
    },
    {
        "id": 3,
        "question": "Which documents mention RM-MCC-0102?",
        "pattern": "Document search by code",
        "expect": "Should list the RMS, SOP, and STP documents that reference this product code",
    },
    {
        "id": 4,
        "question": "Who is the QA Manager?",
        "pattern": "Person lookup by role",
        "expect": "Should find Dr. Ananya Iyer as QA Manager",
    },
    {
        "id": 5,
        "question": "What are the storage conditions for MCC PH102?",
        "pattern": "Specific attribute for entity",
        "expect": "Should return storage conditions like '15-25 C, dry area, RH < 60%'",
    },
    {
        "id": 6,
        "question": "List all organizations mentioned in the documents",
        "pattern": "Entity type listing (no specific entity)",
        "expect": "Should return Fermi Materials, CelluWorks, Warehouse WH-01, QC Labs etc.",
    },
    {
        "id": 7,
        "question": "What is the supplier information for the raw material?",
        "pattern": "Related entity lookup",
        "expect": "Should find Fermi Materials Pvt. Ltd. with supplier details, country, qualification status",
    },
    {
        "id": 8,
        "question": "What are the heavy metal limits for the product?",
        "pattern": "Filtered metrics (subset)",
        "expect": "Should return heavy_metals_lead, cadmium, arsenic, mercury values",
    },
    {
        "id": 9,
        "question": "What documents have been processed?",
        "pattern": "Document listing (no entity)",
        "expect": "Should list all 2-3 processed documents with titles and types",
    },
    {
        "id": 10,
        "question": "What is the sampling procedure and tools used for MCC PH102?",
        "pattern": "Multi-attribute contextual query",
        "expect": "Should return sampling-related attributes: sampling_plan, sampling_tool, sampling_booth, sampling_location etc.",
    },
]


def run_evaluation():
    svc = StructuredDataQueryService()

    results = []
    passed = 0
    warned = 0
    failed = 0

    for test in TEST_QUERIES:
        print(f"\n{'=' * 80}")
        print(f"TEST {test['id']}: {test['question']}")
        print(f"Pattern: {test['pattern']}")
        print(f"Expected: {test['expect']}")
        print("-" * 80)

        try:
            result = svc.query(test["question"], TENANT)

            # Entity resolution
            entities = result.get("entities", [])
            if entities:
                print(f"Entities resolved: {', '.join(e['entity_name'][:40] for e in entities)}")
            else:
                print("Entities resolved: None")

            # SQL
            print(f"\nSQL:\n{result.get('sql', 'N/A')}")

            # Reasoning
            print(f"\nReasoning: {result.get('reasoning', 'N/A')}")

            status, warn_reasons, checks = evaluate_query_result(
                question=test["question"],
                result=result,
            )

            if result.get("error"):
                print(f"\nERROR: {result['error']}")
            else:
                print(f"\nRESULTS: {result['total_rows']} rows")
                cols = result["columns"]
                for i, row in enumerate(result["rows"][:5]):
                    if i == 0:
                        hdr = " | ".join(c[:20] for c in cols)
                        print(f"  {hdr}")
                        print(f"  {'-' * len(hdr)}")
                    vals = " | ".join(str(row.get(c, ""))[:20] for c in cols)
                    print(f"  {vals}")
                if result["total_rows"] > 5:
                    print(f"  ... +{result['total_rows'] - 5} more rows")

            if warn_reasons:
                print(f"\nWARN_REASONS: {', '.join(warn_reasons)}")
                print(f"CHECKS: {checks}")

            if status == "PASS":
                passed += 1
            elif status == "WARN":
                warned += 1
            else:
                failed += 1

            print(f"\nSTATUS: {status}")

            results.append({
                "id": test["id"],
                "question": test["question"],
                "status": status,
                "rows_returned": result["total_rows"],
                "entities_found": len(entities),
                "error": result.get("error"),
                "warn_reasons": warn_reasons,
                "checks": checks,
                "response": {
                    "sql": result.get("sql"),
                    "reasoning": result.get("reasoning"),
                    "description": result.get("description"),
                    "columns": result.get("columns", []),
                    "rows": result.get("rows", []),
                    "total_rows": result.get("total_rows", 0),
                    "entities": result.get("entities", []),
                    "error": result.get("error"),
                },
            })

        except Exception as e:
            print(f"\nEXCEPTION: {e}")
            status = "FAIL"
            failed += 1
            results.append({
                "id": test["id"],
                "question": test["question"],
                "status": "EXCEPTION",
                "error": str(e),
                "warn_reasons": ["EXECUTION_ERROR"],
                "checks": {},
                "response": {
                    "sql": None,
                    "reasoning": None,
                    "description": None,
                    "columns": [],
                    "rows": [],
                    "total_rows": 0,
                    "entities": [],
                    "error": str(e),
                },
            })

    # ── Summary ──
    print(f"\n\n{'=' * 80}")
    print("EVALUATION SUMMARY")
    print("=" * 80)
    print(f"Total: {len(TEST_QUERIES)}  |  Passed: {passed}  |  Warned: {warned}  |  Failed: {failed}")
    print(f"Accuracy: {passed}/{len(TEST_QUERIES)} ({100*passed/len(TEST_QUERIES):.0f}%)")
    print("-" * 80)
    for r in results:
        icon = "pass" if r["status"] == "PASS" else "WARN" if r["status"] == "WARN" else "FAIL"
        rows = r.get("rows_returned", "?")
        print(f"  [{icon}] Q{r['id']:2d}: {r['question'][:55]}  ({rows} rows)")
    print("=" * 80)

    return results


if __name__ == "__main__":
    run_evaluation()
