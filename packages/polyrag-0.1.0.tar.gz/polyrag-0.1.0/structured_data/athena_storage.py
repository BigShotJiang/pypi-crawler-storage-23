"""
Backwards-compatibility shim.

The canonical implementation now lives at
``structured_data.storage.athena_storage``.  This module re-exports it so
that any existing code importing from ``structured_data.athena_storage``
continues to work without changes.
"""

from structured_data.storage.athena_storage import StructuredDataAthenaStorage  # noqa: F401

__all__ = ["StructuredDataAthenaStorage"]
