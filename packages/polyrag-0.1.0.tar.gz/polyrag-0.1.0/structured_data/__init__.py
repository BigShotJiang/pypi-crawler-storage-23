"""
Structured Data Processing Pipeline.

End-to-end system for extracting, resolving, consolidating and storing
structured information from unstructured documents.

Pipeline:  parse -> extract -> resolve -> consolidate -> store -> query
"""

from .pipeline import StructuredDataPipeline
from .extractor import DocumentStructuredExtractor
from .entity_resolver import EntityResolver
from .entity_consolidator import EntityConsolidator
from .athena_storage import StructuredDataAthenaStorage
from .type_utils import detect_and_parse_value
from .query_service import StructuredDataQueryService

__all__ = [
    "StructuredDataPipeline",
    "DocumentStructuredExtractor",
    "EntityResolver",
    "EntityConsolidator",
    "StructuredDataAthenaStorage",
    "StructuredDataQueryService",
    "detect_and_parse_value",
]
