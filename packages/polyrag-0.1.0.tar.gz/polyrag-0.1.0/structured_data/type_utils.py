"""
Type detection and parsing utilities for extracted values.

Detects data types (number, date, boolean, string, json) from raw text
and parses them into the correct Python types so they can be stored in
the right typed columns in Athena.
"""

import re
import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple

from .extraction_normalizer import is_identifier_like_key, is_suspicious_unit

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Currency symbol -> ISO code mapping
# ---------------------------------------------------------------------------
CURRENCY_MAP = {
    "$": "USD",
    "€": "EUR",
    "£": "GBP",
    "¥": "JPY",
    "₹": "INR",
    "₽": "RUB",
    "₩": "KRW",
    "R$": "BRL",
    "C$": "CAD",
    "A$": "AUD",
    "CHF": "CHF",
}

# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------

def parse_date(date_str: str) -> Optional[datetime]:
    """
    Parse a date string into a datetime object.

    Handles ISO-8601, common US/intl formats, and natural-language dates
    via ``dateutil.parser``.  Returns ``None`` when parsing fails.
    """
    if not date_str or not isinstance(date_str, str):
        return None

    date_str = date_str.strip()

    # Skip strings that are clearly not dates
    if len(date_str) < 4 or date_str.replace(",", "").replace(".", "").isalpha():
        return None

    try:
        from dateutil import parser as dateutil_parser
        dt = dateutil_parser.parse(date_str, fuzzy=False)
        return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
    except Exception:
        pass

    # Manual fallback for common formats
    formats = [
        "%Y-%m-%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S%z",
        "%d/%m/%Y",
        "%m/%d/%Y",
        "%d-%b-%Y",
        "%B %d, %Y",
        "%b %d, %Y",
        "%d %B %Y",
        "%d %b %Y",
    ]
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str, fmt)
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        except ValueError:
            continue

    return None


# ---------------------------------------------------------------------------
# Number + unit parsing
# ---------------------------------------------------------------------------

_NUMBER_RE = re.compile(r"^([-+]?[\d,]+\.?\d*)$")
_NUMBER_UNIT_RE = re.compile(r"^([-+]?[\d,]+\.?\d*)\s*([a-zA-Z%/]+.*)$")


def parse_number_with_unit(value_str: str) -> Tuple[Optional[float], Optional[str]]:
    """
    Parse a numeric value with optional unit.

    Examples::

        "$150,000.00"   -> (150000.0, "USD")
        "79,115 units"  -> (79115.0, "units")
        "25%"           -> (25.0, "%")
        "3.5 kg"        -> (3.5, "kg")
        "1,200"         -> (1200.0, None)

    Returns ``(None, None)`` when the string is not numeric.
    """
    if not value_str or not isinstance(value_str, str):
        return None, None

    value_str = value_str.strip()

    # --- Currency symbols ---
    for symbol, code in CURRENCY_MAP.items():
        if value_str.startswith(symbol):
            cleaned = value_str[len(symbol):].strip().replace(",", "")
            try:
                return float(cleaned), code
            except ValueError:
                pass
        # Handle trailing currency: "150,000 USD"
        if value_str.upper().endswith(code):
            cleaned = value_str[: -len(code)].strip().replace(",", "")
            try:
                return float(cleaned), code
            except ValueError:
                pass

    # --- Percentage ---
    if value_str.endswith("%"):
        cleaned = value_str[:-1].strip().replace(",", "")
        try:
            return float(cleaned), "%"
        except ValueError:
            pass

    # --- Number with unit (e.g. "79115 units", "3.5 kg") ---
    cleaned = value_str.replace(",", "")
    m = _NUMBER_UNIT_RE.match(cleaned)
    if m:
        try:
            return float(m.group(1)), m.group(2).strip()
        except ValueError:
            pass

    # --- Plain number ---
    m = _NUMBER_RE.match(cleaned)
    if m:
        try:
            return float(m.group(1)), None
        except ValueError:
            pass

    return None, None


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def detect_and_parse_value(
    raw_value: str,
    context: str = "",
    declared_value_type: Optional[str] = None,
    key: Optional[str] = None,
    data_type: Optional[str] = None,
    category: Optional[str] = None,
    prefer_declared_value_type: bool = True,
    enforce_identifier_string: bool = False,
) -> Dict[str, Any]:
    """
    Detect the data type of *raw_value* and return a dict with the parsed
    value stored in the correct typed field.

    Returned dict keys::

        value_string   - always populated with the original text representation
        value_number   - float if numeric, else None
        value_date     - datetime (UTC) if date, else None
        value_boolean  - bool if boolean, else None
        value_json     - str if valid JSON object/array, else None
        value_type     - one of "number", "date", "boolean", "json", "string"
        unit           - extracted unit for numbers, else None
    """
    result: Dict[str, Any] = {
        "value_string": None,
        "value_number": None,
        "value_date": None,
        "value_boolean": None,
        "value_json": None,
        "value_type": "string",
        "unit": None,
    }

    if raw_value is None:
        return result

    raw_value = str(raw_value).strip()
    if not raw_value:
        return result

    declared = (declared_value_type or "").strip().lower()
    if declared not in {"string", "number", "date", "boolean", "json"}:
        declared = ""

    # Always keep a string representation
    result["value_string"] = raw_value

    # Honor identifier semantics: these keys should remain string-like.
    if enforce_identifier_string and is_identifier_like_key(key, category, data_type):
        result["value_type"] = "string"
        return result

    # Prefer declared schema intent when enabled.
    if prefer_declared_value_type and declared == "string":
        result["value_type"] = "string"
        return result

    # 1. Boolean
    lower = raw_value.lower()
    if lower in ("true", "yes", "y"):
        result["value_boolean"] = True
        result["value_type"] = "boolean"
        return result
    if lower in ("false", "no", "n"):
        result["value_boolean"] = False
        result["value_type"] = "boolean"
        return result

    if prefer_declared_value_type and declared == "boolean":
        # Declared boolean but could not parse.
        result["value_type"] = "string"
        return result

    # Guard against mixed identifier+description values being treated as numeric.
    # Example: "11100002 Ceftriaxone Sodium IP (Nect)" should stay string.
    if re.match(r"^\d{6,}\s+[A-Za-z].{8,}$", raw_value):
        result["value_type"] = "string"
        return result

    # 2. Number (try before date – "$2025" should be a number, not a date)
    number_value, unit = parse_number_with_unit(raw_value)
    if number_value is not None:
        # Guard against code+description strings accidentally parsed as number+unit.
        # Example: "11100002 Ceftriaxone Sodium ..."
        if unit and is_suspicious_unit(unit):
            if re.match(r"^\d{6,}\s+[A-Za-z]", raw_value):
                result["value_type"] = "string"
                result["unit"] = None
                return result
            unit = None
        if unit and len(unit.split()) >= 3 and re.match(r"^\d{6,}\s+[A-Za-z]", raw_value):
            result["value_type"] = "string"
            result["unit"] = None
            return result

        if prefer_declared_value_type and declared and declared != "number":
            # Keep declared non-number semantics.
            result["value_type"] = "string"
            result["unit"] = None
            return result

        result["value_number"] = number_value
        result["value_type"] = "number"
        result["unit"] = unit
        return result

    if prefer_declared_value_type and declared == "number":
        result["value_type"] = "string"
        return result

    # 3. Date
    date_value = parse_date(raw_value)
    if date_value is not None:
        if prefer_declared_value_type and declared and declared != "date":
            result["value_type"] = "string"
            return result
        result["value_date"] = date_value
        result["value_type"] = "date"
        result["value_string"] = date_value.isoformat()
        return result

    if prefer_declared_value_type and declared == "date":
        result["value_type"] = "string"
        return result

    # 4. JSON object / array
    if raw_value.startswith(("{", "[")):
        try:
            json.loads(raw_value)
            if prefer_declared_value_type and declared and declared != "json":
                result["value_type"] = "string"
                return result
            result["value_json"] = raw_value
            result["value_type"] = "json"
            return result
        except (json.JSONDecodeError, ValueError):
            pass

    if prefer_declared_value_type and declared == "json":
        result["value_type"] = "string"
        return result

    # 5. Default -> string
    result["value_type"] = "string"
    return result
