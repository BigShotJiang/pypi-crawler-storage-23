"""
Deterministic query-intent parsing for NL-to-SQL generation.

This keeps intent handling transparent and stable across document types.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Dict, Iterable, List


@dataclass(frozen=True)
class QueryIntent:
    intent_type: str
    semantic_focus: str
    scope: str
    expects_single_value: bool


_SPEC_TOKENS = {
    "specification",
    "spec",
    "limit",
    "limits",
    "criteria",
    "acceptable",
    "nmt",
    "nlt",
    "maximum",
    "minimum",
    "range",
}

_RESULT_TOKENS = {
    "result",
    "results",
    "observed",
    "measured",
    "actual",
    "found",
    "reading",
    "pass",
    "passed",
    "failed",
}

_DOC_SEARCH_TOKENS = {
    "which documents",
    "what documents",
    "documents mention",
    "documents have",
    "files mention",
    "where mentioned",
}

_LISTING_TOKENS = {
    "list",
    "show all",
    "all ",
}

_AGGREGATION_TOKENS = {
    "total",
    "sum",
    "average",
    "avg",
    "highest",
    "lowest",
    "max",
    "min",
    "count",
    "how many",
}

_COMPARISON_TOKENS = {
    "compare",
    "vs",
    "versus",
    "across",
    "difference",
}

_PROCEDURE_TOKENS = {
    "procedure",
    "sampling",
    "method",
    "tools",
    "protocol",
}

_ATTRIBUTE_TOKENS = {
    "what is",
    "who is",
    "which department",
    "what role",
    "employee id",
    "storage conditions",
}


def _contains_any(text: str, phrases: Iterable[str]) -> bool:
    return any(phrase in text for phrase in phrases)


def parse_query_intent(question: str, entities: List[Dict[str, Any]] | None = None) -> QueryIntent:
    q = (question or "").strip().lower()
    entities = entities or []

    semantic_focus = "both"
    has_spec = _contains_any(q, _SPEC_TOKENS)
    has_result = _contains_any(q, _RESULT_TOKENS)
    if has_spec and not has_result:
        semantic_focus = "specification"
    elif has_result and not has_spec:
        semantic_focus = "observed_result"

    if _contains_any(q, _DOC_SEARCH_TOKENS):
        intent_type = "document_search"
    elif _contains_any(q, _PROCEDURE_TOKENS):
        intent_type = "procedure_lookup"
    elif _contains_any(q, _COMPARISON_TOKENS):
        intent_type = "comparison"
    elif _contains_any(q, _AGGREGATION_TOKENS):
        intent_type = "metric_aggregate"
    elif _contains_any(q, _LISTING_TOKENS):
        intent_type = "listing"
    elif _contains_any(q, _ATTRIBUTE_TOKENS):
        intent_type = "attribute_lookup"
    else:
        intent_type = "attribute_lookup"

    scope = "entity_scoped"
    if not entities:
        scope = "corpus_scoped"
    elif _contains_any(q, ("all ", "across all", "across documents", "all documents")):
        scope = "corpus_scoped"

    expects_single_value = bool(
        intent_type in {"attribute_lookup", "metric_aggregate"}
        and not _contains_any(q, _LISTING_TOKENS)
        and not _contains_any(q, ("across", "all", "compare", "which", "who has"))
    )

    return QueryIntent(
        intent_type=intent_type,
        semantic_focus=semantic_focus,
        scope=scope,
        expects_single_value=expects_single_value,
    )


def format_intent_context(intent: QueryIntent) -> str:
    return (
        "INFERRED QUESTION INTENT:\n"
        f"- intent_type: {intent.intent_type}\n"
        f"- semantic_focus: {intent.semantic_focus}\n"
        f"- scope: {intent.scope}\n"
        f"- expects_single_value: {str(intent.expects_single_value).lower()}\n"
    )


def extract_identifier_like_tokens(question: str) -> List[str]:
    """Pull code/id-like tokens for document-mention coverage checks."""
    q = question or ""
    tokens = re.findall(r"\b[A-Za-z0-9]+(?:-[A-Za-z0-9]+)+\b", q)
    out: List[str] = []
    seen = set()
    for token in tokens:
        lower = token.lower()
        if lower in seen:
            continue
        seen.add(lower)
        out.append(token)
    return out[:8]
