"""
Standalone runner for the Structured Data Query Service.

Usage:
    # Single query
    python -m app.core.services.structured_data.run_query "What is Aarav Sharma's salary?" --tenant org_123

    # Run salary test suite
    python -m app.core.services.structured_data.run_query --test --tenant org_123

    # Run bill-of-materials (BOM) test suite
    python -m app.core.services.structured_data.run_query --test-bom --tenant org_123

    # Run both suites
    python -m app.core.services.structured_data.run_query --test-all --tenant org_123

    # From Python
    from app.core.services.structured_data.run_query import run_query
    result = run_query("What is Aarav Sharma's salary?", tenant_id="org_123")
"""

import argparse
import json
import logging
import sys
from pathlib import Path

_PROJECT_ROOT = str(Path(__file__).resolve().parents[1])
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from structured_data.query_service import StructuredDataQueryService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)


# ── Salary suite (existing) ──────────────────────────────────────────
SALARY_TEST_QUERIES = [
    # --- Single entity lookup ---
    "What is Aarav Sharma's salary?",
    "What is the employee ID for Kabir Singh?",
    "Which department does Meera Nair work in?",
    "What role does Sara Khan have?",

    # --- Cross-document: same employee across years ---
    "Show me Aarav Sharma's salary across all years",
    "What was Diya Patel's salary in 2018 vs 2025?",
    "How has Rohan Gupta's salary changed over the years?",

    # --- Aggregation: totals ---
    "What is the total salary expenditure across all employees in 2025?",
    "What is the total salary for each year?",

    # --- Aggregation: averages ---
    "What is the average salary in the Engineering department?",
    "What is the average salary across all employees for each year?",

    # --- Aggregation: max / min / ranking ---
    "Who has the highest salary in 2025?",
    "Who has the lowest salary?",
    "Rank all employees by their 2025 salary from highest to lowest",

    # --- Filtering ---
    "Which employees have a salary above $130,000 in 2025?",
    "List all employees in the Data department",
    "Show me all employees in the Infrastructure department across all years",

    # --- Entity resolution by ID ---
    "Tell me everything about employee E005",
    "What is the salary history for employee E003?",

    # --- Multi-entity comparison ---
    "Compare the salaries of Aarav Sharma and Kabir Singh across all years",
    "Compare salaries of Engineering vs Security department employees",

    # --- Document-level ---
    "How many salary documents have been processed?",
    "List all employees and their departments",

    # --- Growth / trend ---
    "What is the salary growth for Ishaan Verma from 2018 to 2025?",
    "Which employee had the biggest salary increase between 2018 and 2025?",
]


# ── Bill of Materials suite (rep_BillofMaterial_428.pdf) ───────────
BOM_TEST_QUERIES = [
    # --- Document-level sanity ---
    "What is the title of the bill of materials document?",
    "Which organization is this BOM for?",
    "Which company generated this BOM and what is its ID?",

    # --- Product/code lookup ---
    "What is the product code and name on page 1?",
    "What is the batch size for IAAA - Ceftriaxone for Injection 1000mg?",
    "What is the batch size for IAFA - Ceftriaxone & Sulbactam for Injection 1500mg?",
    "List product codes that appear in this BOM",

    # --- Material lookup by code/name ---
    "What is material code 11100002 and what quantity is listed for it?",
    "What is material code 13400007 and where is it used?",
    "Which code corresponds to METHYLENE CHLORIDE (M.D.C)?",
    "What is the listed quantity and unit for HPMC - E15 (ANYCOAT CAN 15)?",

    # --- Coating / packing specifics ---
    "Which coating materials are used for TAAC - Cefix-100?",
    "What packaging materials are listed for TAAC - Cefix-100?",
    "What is the quantity for Printed Alu.Foil 236x.025 Cefix-100mg?",
    "Which rows mention BOPP TAPE and what are their quantities?",

    # --- Filtering / aggregation ---
    "List materials with overage percentage 20.00",
    "How many distinct product codes are mentioned in the BOM?",
    "Which materials have unit Kg in this BOM?",
    "Which products have batch size 10000 Nos?",
    "Show all material codes that start with 1210",
]

# Backward compatibility for any external imports
TEST_QUERIES = SALARY_TEST_QUERIES


def run_query(question: str, tenant_id: str) -> dict:
    """
    Run the full NL-to-SQL query pipeline on a single question.
    """
    svc = StructuredDataQueryService()

    print("=" * 80)
    print("STRUCTURED DATA QUERY")
    print("=" * 80)
    print(f"Question:  {question}")
    print(f"Tenant:    {tenant_id}")
    print("-" * 80)

    # Step 1: Entity resolution
    print("\n[Step 1] Resolving entities from question...")
    entities = svc.resolve_entities_from_question(question, tenant_id)
    if entities:
        for ent in entities:
            print(f"  Found: {ent['entity_name']} ({ent['entity_type']})")
            if ent.get("identifiers"):
                print(f"         identifiers: {ent['identifiers']}")
            print(f"         {ent.get('attribute_count', 0)} known attributes")
    else:
        print("  No entities resolved — will generate broader query")

    # Step 2-4: Generate SQL + Execute
    print("\n[Step 2] Generating SQL via LLM...")
    result = svc.query(question, tenant_id)

    if result.get("error"):
        print(f"\nERROR: {result['error']}")
        if result.get("sql"):
            print(f"\nGenerated SQL:\n{result['sql']}")
        return result

    print(f"\nReasoning: {result['reasoning']}")
    print(f"\nGenerated SQL:\n{result['sql']}")
    print(f"\nDescription: {result['description']}")
    print(f"\n[Step 3] Results: {result['total_rows']} rows")
    print("-" * 80)

    # Print results as table
    if result["rows"]:
        columns = result["columns"]

        # Calculate column widths
        widths = {col: len(col) for col in columns}
        for row in result["rows"][:20]:
            for col in columns:
                val = str(row.get(col, ""))[:50]
                widths[col] = max(widths[col], len(val))

        # Cap widths
        widths = {col: min(w, 50) for col, w in widths.items()}

        # Header
        header = " | ".join(col.ljust(widths[col])[:widths[col]] for col in columns)
        print(header)
        print("-" * len(header))

        # Rows
        for row in result["rows"][:20]:
            line = " | ".join(
                str(row.get(col, "")).ljust(widths[col])[:widths[col]]
                for col in columns
            )
            print(line)

        if result["total_rows"] > 20:
            print(f"  ... and {result['total_rows'] - 20} more rows")

    print("=" * 80)
    return result


def run_all_tests(
    tenant_id: str,
    queries: list[str],
    suite_name: str = "custom",
):
    """Run a query suite and print a summary."""
    svc = StructuredDataQueryService()

    results = []
    passed = 0
    failed = 0

    for i, question in enumerate(queries, 1):
        print(f"\n\n{'#' * 80}")
        print(f"# TEST {i}/{len(queries)}: {question}")
        print(f"{'#' * 80}")

        try:
            result = svc.query(question, tenant_id)

            entities = result.get("entities", [])
            ent_names = ", ".join(e["entity_name"][:30] for e in entities) if entities else "None"

            print(f"Entities: {ent_names}")
            print(f"SQL:\n  {result.get('sql', 'N/A')}")
            print(f"Reasoning: {result.get('reasoning', 'N/A')}")

            if result.get("error"):
                print(f"ERROR: {result['error']}")
                status = "FAIL"
                failed += 1
            elif result["total_rows"] == 0:
                print("RESULT: 0 rows")
                status = "WARN"
                failed += 1
            else:
                cols = result["columns"]
                print(f"RESULTS: {result['total_rows']} rows")

                # Compact table: show up to 8 rows
                widths = {}
                for col in cols:
                    widths[col] = len(col)
                for row in result["rows"][:8]:
                    for col in cols:
                        widths[col] = max(widths[col], len(str(row.get(col, ""))[:35]))
                widths = {c: min(w, 35) for c, w in widths.items()}

                hdr = " | ".join(c.ljust(widths[c])[:widths[c]] for c in cols)
                print(f"  {hdr}")
                print(f"  {'-' * len(hdr)}")
                for row in result["rows"][:8]:
                    line = " | ".join(str(row.get(c, "")).ljust(widths[c])[:widths[c]] for c in cols)
                    print(f"  {line}")
                if result["total_rows"] > 8:
                    print(f"  ... +{result['total_rows'] - 8} more")

                status = "PASS"
                passed += 1

            results.append({
                "id": i,
                "question": question,
                "status": status,
                "rows": result.get("total_rows", 0),
                "entities": len(entities),
                "error": result.get("error"),
            })

        except Exception as e:
            print(f"EXCEPTION: {e}")
            failed += 1
            results.append({
                "id": i,
                "question": question,
                "status": "EXCEPTION",
                "rows": 0,
                "error": str(e),
            })

    # ── Summary ──
    print(f"\n\n{'=' * 80}")
    print(f"EVALUATION SUMMARY ({suite_name.upper()} SUITE)")
    print(f"{'=' * 80}")
    print(f"Total: {len(queries)}  |  Passed: {passed}  |  Failed: {failed}")
    print(f"Accuracy: {passed}/{len(queries)} ({100 * passed / len(queries):.0f}%)")
    print(f"{'-' * 80}")
    for r in results:
        icon = "PASS" if r["status"] == "PASS" else "WARN" if r["status"] == "WARN" else "FAIL"
        print(f"  [{icon:4s}] Q{r['id']:2d}: {r['question'][:60]:60s} | {r['rows']} rows")
    print(f"{'=' * 80}")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Query structured data using natural language.",
    )
    parser.add_argument(
        "question",
        nargs="?",
        default=None,
        help="Natural language question (omit to use --test)",
    )
    parser.add_argument(
        "--tenant", "-t",
        default="org_123",
        help="Tenant / organisation ID (default: org_123)",
    )
    parser.add_argument(
        "--test",
        action="store_true",
        default=False,
        help=f"Run salary test suite ({len(SALARY_TEST_QUERIES)} queries)",
    )
    parser.add_argument(
        "--test-bom",
        action="store_true",
        default=False,
        help=f"Run BOM test suite ({len(BOM_TEST_QUERIES)} queries)",
    )
    parser.add_argument(
        "--test-all",
        action="store_true",
        default=False,
        help=(
            "Run both salary + BOM suites "
            f"({len(SALARY_TEST_QUERIES) + len(BOM_TEST_QUERIES)} queries)"
        ),
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        help="Print full result as JSON",
    )

    args = parser.parse_args()

    if args.test_all:
        run_all_tests(
            tenant_id=args.tenant,
            queries=SALARY_TEST_QUERIES + BOM_TEST_QUERIES,
            suite_name="all",
        )
    elif args.test_bom:
        run_all_tests(
            tenant_id=args.tenant,
            queries=BOM_TEST_QUERIES,
            suite_name="bom",
        )
    elif args.test:
        run_all_tests(
            tenant_id=args.tenant,
            queries=SALARY_TEST_QUERIES,
            suite_name="salary",
        )
    elif args.question:
        result = run_query(question=args.question, tenant_id=args.tenant)
        if args.json:
            print(json.dumps(result, indent=2, default=str))
    else:
        print("Provide a question or use --test / --test-bom / --test-all.")
        print("Example (salary): python -m app.core.services.structured_data.run_query --test --tenant org_123")
        print("Example (BOM):    python -m app.core.services.structured_data.run_query --test-bom --tenant org_123")


if __name__ == "__main__":
    main()
