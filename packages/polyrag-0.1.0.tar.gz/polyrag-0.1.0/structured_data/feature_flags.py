"""
Shared feature-flag helpers for structured-data reliability upgrades.
"""

from __future__ import annotations

import os
from typing import Set


_DEFAULT_RELIABILITY_V2_ENABLED = False
_DEFAULT_RELIABILITY_V2_TENANTS = "org_123"
_DEFAULT_EXTRACTION_V3_ENABLED = False
_DEFAULT_EXTRACTION_V3_TENANTS = "org_123"


def env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _parse_tenant_allowlist(raw_value: str | None) -> Set[str]:
    if raw_value is None:
        raw_value = _DEFAULT_RELIABILITY_V2_TENANTS
    cleaned = {part.strip() for part in raw_value.split(",") if part.strip()}
    return cleaned


def is_reliability_v2_enabled(tenant_id: str) -> bool:
    """
    Enable reliability-v2 behavior based on global + tenant-scoped flags.

    Rules:
    1. `STRUCTURED_RELIABILITY_V2_ENABLED` must be true.
    2. If `STRUCTURED_RELIABILITY_V2_TENANTS` is empty, all tenants are enabled.
    3. Otherwise, tenant_id must be present in the allowlist.
    """
    if not env_bool(
        "STRUCTURED_RELIABILITY_V2_ENABLED",
        _DEFAULT_RELIABILITY_V2_ENABLED,
    ):
        return False

    allowed = _parse_tenant_allowlist(os.getenv("STRUCTURED_RELIABILITY_V2_TENANTS"))
    if not allowed:
        return True
    return tenant_id in allowed


def is_extraction_v3_enabled(tenant_id: str) -> bool:
    """
    Enable extraction-v3 behavior based on global + tenant-scoped flags.

    Rules:
    1. `STRUCTURED_EXTRACTION_V3_ENABLED` must be true.
    2. If `STRUCTURED_EXTRACTION_V3_TENANTS` is empty, all tenants are enabled.
    3. Otherwise, tenant_id must be present in the allowlist.
    """
    if not env_bool(
        "STRUCTURED_EXTRACTION_V3_ENABLED",
        _DEFAULT_EXTRACTION_V3_ENABLED,
    ):
        return False

    allowed = _parse_tenant_allowlist(os.getenv("STRUCTURED_EXTRACTION_V3_TENANTS"))
    if not allowed:
        return True
    return tenant_id in allowed
