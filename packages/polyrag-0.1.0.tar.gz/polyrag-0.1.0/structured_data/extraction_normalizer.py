"""
Normalization and quality helpers for generic structured extraction.
"""

from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, List, Optional, Tuple


_SNAKE_RE_1 = re.compile(r"[^a-zA-Z0-9]+")
_SNAKE_RE_2 = re.compile(r"_+")
_CODE_RE = re.compile(r"\b\d{6,}\b")
_ALNUM_CODE_RE = re.compile(r"\b[A-Z0-9]{2,}(?:-[A-Z0-9]{2,})+\b")

_ROW_LIKE_KEY_HINTS = (
    "quantity",
    "amount",
    "total",
    "material",
    "product",
    "item",
    "batch",
    "price",
    "rate",
    "code",
    "description",
    "sku",
    "line",
    "pack",
)

_METRIC_KEY_HINTS = (
    "quantity",
    "amount",
    "total",
    "rate",
    "price",
    "salary",
    "density",
    "weight",
    "count",
    "percentage",
    "limit",
    "result",
    "observed",
    "spec",
)

_HEADER_HINTS = (
    "employee id",
    "employee name",
    "annual salary",
    "department",
    "role",
    "material code",
    "description",
    "quantity",
    "unit",
    "uom",
    "test attribute",
    "acceptance criteria",
    "method reference",
    "report",
)

_IDENTIFIER_KEY_HINTS = (
    "code",
    "_id",
    "identifier",
    "reference",
    "ref",
    "lot_number",
    "serial",
    "sku",
    "invoice_number",
    "employee_id",
    "document_number",
    "product_code",
    "material_code",
)

_KNOWN_UNITS = {
    "%",
    "usd",
    "eur",
    "inr",
    "gbp",
    "jpy",
    "cad",
    "aud",
    "kg",
    "g",
    "mg",
    "mcg",
    "lb",
    "lbs",
    "oz",
    "l",
    "ml",
    "mm",
    "cm",
    "m",
    "m2",
    "m3",
    "sqm",
    "sqft",
    "hours",
    "hour",
    "days",
    "day",
    "weeks",
    "week",
    "months",
    "month",
    "years",
    "year",
    "nos",
    "units",
    "unit",
    "pcs",
    "piece",
    "pieces",
    "roll",
    "rolls",
    "box",
    "boxes",
    "pack",
    "packs",
}


def canonicalize_key(key: Optional[str]) -> str:
    raw = (key or "").strip()
    if not raw:
        return "unknown_key"
    snake = _SNAKE_RE_1.sub("_", raw).strip("_").lower()
    snake = _SNAKE_RE_2.sub("_", snake)
    return snake or "unknown_key"


def normalize_row_ref(row_ref: Optional[str], *, max_len: int = 64) -> Optional[str]:
    if row_ref is None:
        return None
    normalized = re.sub(r"\s+", "_", str(row_ref).strip())
    normalized = _SNAKE_RE_1.sub("_", normalized).strip("_")
    if not normalized:
        return None
    return normalized[:max_len]


def normalize_evidence(evidence: Optional[str], *, fallback_text: Optional[str], max_chars: int = 100) -> str:
    text = (evidence or "").strip()
    if not text:
        text = (fallback_text or "").strip()
    if not text:
        return "N/A"
    collapsed = re.sub(r"\s+", " ", text).strip()
    return collapsed[:max_chars]


def is_header_like_evidence(text: Optional[str]) -> bool:
    if not text:
        return False
    cleaned = re.sub(r"\s+", " ", str(text)).strip()
    if not cleaned:
        return False

    lower = cleaned.lower()
    header_hits = sum(1 for hint in _HEADER_HINTS if hint in lower)
    numeric_hits = len(re.findall(r"\d", cleaned))
    has_sentence_punctuation = bool(re.search(r"[.;:]\s", cleaned))
    separators = cleaned.count("|") + cleaned.count("  ")

    if header_hits >= 3 and numeric_hits == 0:
        return True
    if header_hits >= 2 and separators >= 1 and not has_sentence_punctuation:
        return True
    if lower.startswith("employee id ") and " salary" in lower:
        return True
    return False


def _extract_search_tokens(value: Optional[str], key: Optional[str]) -> List[str]:
    tokens: List[str] = []
    for source in (value or "", str(key or "").replace("_", " ")):
        for token in re.findall(r"[A-Za-z0-9%./-]{3,}", source):
            lower = token.lower()
            if lower in {"the", "and", "for", "with", "from", "this", "that"}:
                continue
            if lower not in tokens:
                tokens.append(lower)
    return tokens[:6]


def find_row_specific_evidence(
    *,
    chunk_text: str,
    value: Optional[str],
    key: Optional[str],
    max_chars: int = 100,
) -> Optional[str]:
    if not chunk_text:
        return None

    lines = [re.sub(r"\s+", " ", line).strip() for line in chunk_text.splitlines() if line.strip()]
    if not lines:
        return None

    search_tokens = _extract_search_tokens(value, key)
    candidates: List[Tuple[int, str]] = []
    for line in lines:
        lower = line.lower()
        score = 0
        for token in search_tokens:
            if token in lower:
                score += 2
        if re.search(r"\d", line):
            score += 1
        if "|" in line:
            score += 1
        if is_header_like_evidence(line):
            score -= 3
        if score > 0:
            candidates.append((score, line))

    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return normalize_evidence(candidates[0][1], fallback_text=value, max_chars=max_chars)


def is_identifier_like_key(
    key: Optional[str],
    category: Optional[str] = None,
    data_type: Optional[str] = None,
) -> bool:
    key_norm = canonicalize_key(key)
    category_norm = (category or "").strip().lower()
    data_type_norm = (data_type or "").strip().lower()

    if any(hint in key_norm for hint in _IDENTIFIER_KEY_HINTS):
        return True
    if key_norm.endswith("_code") or key_norm.endswith("_id"):
        return True
    if category_norm == "identifier":
        return True
    if data_type_norm == "entity" and any(hint in key_norm for hint in ("code", "identifier", "reference")):
        return True
    return False


def contains_identifier_token(value: Optional[str]) -> bool:
    if not value:
        return False
    text = str(value)
    return bool(_CODE_RE.search(text) or _ALNUM_CODE_RE.search(text))


def is_row_like_key(key: Optional[str]) -> bool:
    key_norm = canonicalize_key(key)
    return any(hint in key_norm for hint in _ROW_LIKE_KEY_HINTS)


def is_suspicious_unit(unit: Optional[str]) -> bool:
    if unit is None:
        return False
    raw = str(unit).strip()
    if not raw:
        return False
    norm = raw.lower()
    if norm in _KNOWN_UNITS:
        return False
    if len(raw) > 20:
        return True
    words = [w for w in raw.split() if w]
    if len(words) > 3:
        return True
    if "(" in raw or ")" in raw:
        return True
    if re.search(r"[,:;]", raw):
        return True
    if re.fullmatch(r"[a-zA-Z%°µμ/]+[0-9]*", raw) and len(raw) <= 12:
        return False
    if re.fullmatch(r"[a-zA-Z]+(?:\s+[a-zA-Z]+){0,2}", raw) and len(raw) <= 15:
        return False
    return True


def looks_tabular_text(text: str) -> bool:
    if not text:
        return False
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) < 6:
        return False

    lower = text.lower()
    cue_hits = sum(
        cue in lower
        for cue in ("qty", "quantity", "uom", "unit price", "amount", "material code", "batch size", "lot number")
    )

    dense_numeric_lines = 0
    number_pattern = re.compile(r"[-+]?\d[\d,]*(?:\.\d+)?")
    for line in lines:
        if len(number_pattern.findall(line)) >= 2:
            dense_numeric_lines += 1

    if cue_hits >= 1 and dense_numeric_lines >= 3:
        return True
    return dense_numeric_lines >= 5


def synthesize_row_ref(
    *,
    page_number: Optional[int],
    key: Optional[str],
    evidence: Optional[str],
    value_string: Optional[str],
) -> str:
    seed = f"{page_number or 'x'}|{canonicalize_key(key)}|{(evidence or value_string or '')[:80]}"
    digest = hashlib.sha1(seed.encode("utf-8")).hexdigest()[:10]
    return f"auto_{page_number or 'x'}_{digest}"


def normalize_item_semantics(
    *,
    key: Optional[str],
    row_ref: Optional[str],
    evidence: Optional[str],
    value: Optional[str],
    page_number: Optional[int],
    data_type: Optional[str],
    enable_synthetic_row_ref: bool,
    tabular_chunk: bool,
    chunk_text: Optional[str] = None,
) -> Dict[str, Any]:
    key_norm = canonicalize_key(key)
    evidence_norm = normalize_evidence(evidence, fallback_text=value, max_chars=100)
    if is_header_like_evidence(evidence_norm):
        replacement = find_row_specific_evidence(
            chunk_text=chunk_text or "",
            value=value,
            key=key_norm,
            max_chars=100,
        )
        if replacement:
            evidence_norm = replacement
        else:
            evidence_norm = normalize_evidence(None, fallback_text=value, max_chars=100)
    row_ref_norm = normalize_row_ref(row_ref)
    synthetic_row_ref = False

    if (
        enable_synthetic_row_ref
        and tabular_chunk
        and not row_ref_norm
        and (is_row_like_key(key_norm) or (data_type or "").lower() in {"line_item", "metric", "attribute"})
    ):
        row_ref_norm = synthesize_row_ref(
            page_number=page_number,
            key=key_norm,
            evidence=evidence_norm,
            value_string=value,
        )
        synthetic_row_ref = True

    return {
        "key": key_norm,
        "row_ref": row_ref_norm,
        "evidence": evidence_norm,
        "synthetic_row_ref": synthetic_row_ref,
    }


def enforce_row_field_safety(
    row: Dict[str, Any],
    *,
    enforce_identifier_string: bool,
) -> Tuple[Dict[str, Any], Dict[str, int]]:
    out = dict(row)
    stats = {
        "typed_corrections": 0,
        "identifier_string_enforced": 0,
        "suspicious_unit_cleared": 0,
    }

    key = out.get("key")
    category = out.get("category")
    data_type = out.get("data_type")
    if (
        enforce_identifier_string
        and is_identifier_like_key(key, category, data_type)
        and out.get("value_number") is not None
    ):
        out["value_number"] = None
        out["value_date"] = None
        out["value_boolean"] = None
        out["value_json"] = None
        out["value_type"] = "string"
        stats["typed_corrections"] += 1
        stats["identifier_string_enforced"] += 1

    if is_suspicious_unit(out.get("unit")):
        out["unit"] = None
        out["unit_normalized"] = None
        stats["typed_corrections"] += 1
        stats["suspicious_unit_cleared"] += 1

    evidence = out.get("evidence") or out.get("context")
    out["evidence"] = normalize_evidence(evidence, fallback_text=out.get("value_string"))
    out["context"] = out["evidence"]

    return out, stats


def evaluate_chunk_quality(rows: List[Dict[str, Any]], chunk_text: str) -> Dict[str, Any]:
    total_rows = max(1, len(rows))
    tabular = looks_tabular_text(chunk_text)

    identifier_rows = [
        row
        for row in rows
        if is_identifier_like_key(row.get("key"), row.get("category"), row.get("data_type"))
        or contains_identifier_token(row.get("value_string"))
    ]
    unit_rows = [row for row in rows if row.get("unit")]
    row_like_rows = [
        row
        for row in rows
        if is_row_like_key(row.get("key"))
        or row.get("line_item_id")
        or row.get("row_ref")
        or row.get("data_type") == "line_item"
    ]

    identifier_numeric_ratio = (
        sum(1 for row in identifier_rows if row.get("value_number") is not None) / max(1, len(identifier_rows))
    )
    suspicious_unit_ratio = (
        sum(1 for row in unit_rows if is_suspicious_unit(row.get("unit"))) / max(1, len(unit_rows))
    )
    missing_row_linkage_ratio = (
        sum(1 for row in row_like_rows if not row.get("row_ref")) / max(1, len(row_like_rows))
        if tabular
        else 0.0
    )
    missing_context_ratio = (
        sum(
            1
            for row in row_like_rows
            if not (row.get("entity_name") or row.get("related_entity_name"))
        )
        / max(1, len(row_like_rows))
    )
    header_like_evidence_ratio = (
        sum(1 for row in rows if is_header_like_evidence(row.get("evidence")))
        / max(1, len(rows))
    )

    metric_like_rows = [
        row
        for row in rows
        if row.get("value_number") is not None
        or (row.get("data_type") or "").lower() in {"metric", "line_item"}
        or any(hint in canonicalize_key(row.get("key")) for hint in _METRIC_KEY_HINTS)
    ]
    grouped_by_row_ref: Dict[str, List[Dict[str, Any]]] = {}
    for row in rows:
        row_ref = str(row.get("row_ref") or "").strip()
        if not row_ref:
            continue
        grouped_by_row_ref.setdefault(row_ref, []).append(row)

    orphan_metric_rows = 0
    for row in metric_like_rows:
        row_ref = str(row.get("row_ref") or "").strip()
        if not row_ref:
            if tabular:
                orphan_metric_rows += 1
            continue
        group = grouped_by_row_ref.get(row_ref, [])
        has_row_identity = any(
            any(
                token in canonicalize_key(member.get("key"))
                for token in ("code", "name", "identifier", "material", "item", "product", "employee")
            )
            or contains_identifier_token(member.get("value_string"))
            for member in group
        )
        has_entity_context = any(
            (member.get("entity_name") or member.get("related_entity_name"))
            for member in group
        )
        if not (has_row_identity or has_entity_context):
            orphan_metric_rows += 1

    orphan_row_metric_ratio = orphan_metric_rows / max(1, len(metric_like_rows))

    weighted_penalty = (
        0.35 * identifier_numeric_ratio
        + 0.20 * suspicious_unit_ratio
        + 0.15 * missing_row_linkage_ratio
        + 0.15 * missing_context_ratio
        + 0.10 * header_like_evidence_ratio
        + 0.05 * orphan_row_metric_ratio
    )
    score = max(0.0, min(1.0, 1.0 - weighted_penalty))

    issues: List[str] = []
    if identifier_numeric_ratio > 0.0:
        issues.append(f"identifier_numeric_ratio={identifier_numeric_ratio:.3f}")
    if suspicious_unit_ratio > 0.0:
        issues.append(f"suspicious_unit_ratio={suspicious_unit_ratio:.3f}")
    if tabular and missing_row_linkage_ratio > 0.0:
        issues.append(f"missing_row_linkage_ratio={missing_row_linkage_ratio:.3f}")
    if missing_context_ratio > 0.20:
        issues.append(f"missing_context_ratio={missing_context_ratio:.3f}")
    if header_like_evidence_ratio > 0.10:
        issues.append(f"header_like_evidence_ratio={header_like_evidence_ratio:.3f}")
    if orphan_row_metric_ratio > 0.10:
        issues.append(f"orphan_row_metric_ratio={orphan_row_metric_ratio:.3f}")

    return {
        "quality_score": score,
        "issues": issues,
        "metrics": {
            "rows_total": total_rows,
            "identifier_rows": len(identifier_rows),
            "unit_rows": len(unit_rows),
            "row_like_rows": len(row_like_rows),
            "identifier_numeric_ratio": identifier_numeric_ratio,
            "suspicious_unit_ratio": suspicious_unit_ratio,
            "missing_row_linkage_ratio": missing_row_linkage_ratio,
            "missing_context_ratio": missing_context_ratio,
            "header_like_evidence_ratio": header_like_evidence_ratio,
            "orphan_row_metric_ratio": orphan_row_metric_ratio,
            "metric_like_rows": len(metric_like_rows),
            "tabular_chunk": tabular,
        },
    }
