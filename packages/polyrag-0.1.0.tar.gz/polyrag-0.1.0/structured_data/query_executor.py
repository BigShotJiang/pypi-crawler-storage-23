"""
QueryExecutor – SQL execution via the configured storage backend.

The backend is chosen by the ``OPENRAG_STORAGE_BACKEND`` environment variable
(default: ``athena``).  The ``execute_athena_query`` method name is kept for
backwards compatibility with existing call-sites.
"""

from typing import Any, Dict

from structured_data.storage.factory import get_query_executor as _get_backend


class QueryExecutor:
    """Execute SQL against the configured storage backend."""

    def __init__(self):
        self._backend = _get_backend()

    def execute_athena_query(self, sql: str, tenant_id: str) -> Dict[str, Any]:
        """
        Execute *sql* and return results.

        Method name retained for backwards compatibility.
        Delegates to the backend selected by OPENRAG_STORAGE_BACKEND.

        Returns dict: {rows, columns, total_rows, error}.
        """
        return self._backend.execute(sql, tenant_id)
