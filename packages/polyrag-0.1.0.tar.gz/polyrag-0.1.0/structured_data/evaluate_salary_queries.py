"""
Evaluation: 15 test queries on employee salary data across 8 yearly documents.

Tests cross-document aggregation, entity resolution, temporal comparison,
filtering, and analytics capabilities.

Usage:
    python -m app.core.services.structured_data.evaluate_salary_queries
"""

import json
import logging
import sys
from pathlib import Path

_PROJECT_ROOT = str(Path(__file__).resolve().parents[4])
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(override=True)

from app.core.services.structured_data.query_service import StructuredDataQueryService
try:
    from app.core.services.structured_data.evaluation_assertions import evaluate_query_result
except ImportError:  # pragma: no cover - direct script fallback
    from structured_data.evaluation_assertions import evaluate_query_result

logging.basicConfig(level=logging.WARNING)

TENANT = "org_123"

TEST_QUERIES = [
    # --- Entity lookup ---
    {
        "id": 1,
        "question": "What is Aarav Sharma's salary?",
        "pattern": "Single entity attribute lookup",
        "expect": "Should return salary values for Aarav Sharma (ideally from multiple years)",
    },
    {
        "id": 2,
        "question": "What is the employee ID for Kabir Singh?",
        "pattern": "Specific attribute by name",
        "expect": "Should return E003",
    },
    {
        "id": 3,
        "question": "Which department does Meera Nair work in?",
        "pattern": "Attribute lookup by entity name",
        "expect": "Should return Quality",
    },

    # --- Cross-document comparison ---
    {
        "id": 4,
        "question": "What was Aarav Sharma's salary in 2018 vs 2025?",
        "pattern": "Temporal comparison across documents",
        "expect": "Should show $100,300 (2018) and $134,200 (2025) with file names indicating years",
    },
    {
        "id": 5,
        "question": "Show me Diya Patel's salary across all years",
        "pattern": "Entity data across all documents",
        "expect": "Should return 8 rows (one per year) with salary values and file names",
    },

    # --- Aggregation ---
    {
        "id": 6,
        "question": "What is the total salary expenditure across all employees in 2025?",
        "pattern": "Sum aggregation within a document",
        "expect": "Should sum all 10 employee salaries from the 2025 document",
    },
    {
        "id": 7,
        "question": "What is the average salary in the Engineering department?",
        "pattern": "Filtered aggregation by department",
        "expect": "Should return average salary for Engineering dept employees",
    },
    {
        "id": 8,
        "question": "Who has the highest salary?",
        "pattern": "Max value lookup",
        "expect": "Should return Kabir Singh (Product Manager) with the highest salary",
    },

    # --- Filtering ---
    {
        "id": 9,
        "question": "List all employees in the Data department",
        "pattern": "Filter by department",
        "expect": "Should return Diya Patel (Data Analyst)",
    },
    {
        "id": 10,
        "question": "Which employees have a salary above $130,000 in 2025?",
        "pattern": "Numeric filter with year context",
        "expect": "Should return employees with salary > 130k from the 2025 document",
    },

    # --- Entity resolution ---
    {
        "id": 11,
        "question": "Tell me everything about employee E005",
        "pattern": "Lookup by employee ID (identifier)",
        "expect": "Should resolve E005 to Rohan Gupta and return all his data",
    },
    {
        "id": 12,
        "question": "What role does Sara Khan have?",
        "pattern": "Role attribute lookup",
        "expect": "Should return Finance Associate",
    },

    # --- Document-level queries ---
    {
        "id": 13,
        "question": "How many salary documents have been processed?",
        "pattern": "Document count",
        "expect": "Should return 8 (or more if MCC docs are included)",
    },
    {
        "id": 14,
        "question": "List all employees and their departments",
        "pattern": "Multi-entity listing with attributes",
        "expect": "Should return all 10 employees with their department names",
    },

    # --- Cross-entity analytics ---
    {
        "id": 15,
        "question": "Compare the salaries of Aarav Sharma and Kabir Singh across all years",
        "pattern": "Multi-entity temporal comparison",
        "expect": "Should return salary data for both employees from all 8 documents",
    },
]


def run_evaluation():
    svc = StructuredDataQueryService()

    results = []
    passed = 0
    warned = 0
    failed = 0

    for test in TEST_QUERIES:
        print(f"\n{'=' * 80}")
        print(f"TEST {test['id']}: {test['question']}")
        print(f"Pattern: {test['pattern']}")
        print(f"Expected: {test['expect']}")
        print("-" * 80)

        try:
            result = svc.query(test["question"], TENANT)

            entities = result.get("entities", [])
            if entities:
                print(f"Entities resolved: {', '.join(e['entity_name'][:35] for e in entities)}")
            else:
                print("Entities resolved: None")

            print(f"\nSQL:\n{result.get('sql', 'N/A')}")
            print(f"\nReasoning: {result.get('reasoning', 'N/A')}")

            status, warn_reasons, checks = evaluate_query_result(
                question=test["question"],
                result=result,
            )

            if result.get("error"):
                print(f"\nERROR: {result['error']}")
            else:
                print(f"\nRESULTS: {result['total_rows']} rows")
                cols = result["columns"]

                widths = {col: len(col) for col in cols}
                for row in result["rows"][:10]:
                    for col in cols:
                        val = str(row.get(col, ""))[:40]
                        widths[col] = max(widths[col], len(val))
                widths = {col: min(w, 40) for col, w in widths.items()}

                header = " | ".join(col.ljust(widths[col])[:widths[col]] for col in cols)
                print(f"  {header}")
                print(f"  {'-' * len(header)}")

                for row in result["rows"][:10]:
                    line = " | ".join(
                        str(row.get(col, "")).ljust(widths[col])[:widths[col]]
                        for col in cols
                    )
                    print(f"  {line}")

                if result["total_rows"] > 10:
                    print(f"  ... +{result['total_rows'] - 10} more rows")

            if warn_reasons:
                print(f"\nWARN_REASONS: {', '.join(warn_reasons)}")
                print(f"CHECKS: {checks}")

            if status == "PASS":
                passed += 1
            elif status == "WARN":
                warned += 1
            else:
                failed += 1

            print(f"\nSTATUS: {status}")

            results.append({
                "id": test["id"],
                "question": test["question"],
                "pattern": test["pattern"],
                "status": status,
                "rows_returned": result.get("total_rows", 0),
                "entities_found": len(entities),
                "error": result.get("error"),
                "warn_reasons": warn_reasons,
                "checks": checks,
                "response": {
                    "sql": result.get("sql"),
                    "reasoning": result.get("reasoning"),
                    "description": result.get("description"),
                    "columns": result.get("columns", []),
                    "rows": result.get("rows", []),
                    "total_rows": result.get("total_rows", 0),
                    "entities": result.get("entities", []),
                    "error": result.get("error"),
                },
            })

        except Exception as e:
            print(f"\nEXCEPTION: {e}")
            failed += 1
            results.append({
                "id": test["id"],
                "question": test["question"],
                "pattern": test["pattern"],
                "status": "EXCEPTION",
                "error": str(e),
                "warn_reasons": ["EXECUTION_ERROR"],
                "checks": {},
                "response": {
                    "sql": None,
                    "reasoning": None,
                    "description": None,
                    "columns": [],
                    "rows": [],
                    "total_rows": 0,
                    "entities": [],
                    "error": str(e),
                },
            })

    # ── Summary ──
    print(f"\n\n{'=' * 80}")
    print("EVALUATION SUMMARY — SALARY DATA (8 docs, 10 employees, 8 years)")
    print("=" * 80)
    print(f"Total: {len(TEST_QUERIES)}  |  Passed: {passed}  |  Warned: {warned}  |  Failed: {failed}")
    print(f"Accuracy: {passed}/{len(TEST_QUERIES)} ({100*passed/len(TEST_QUERIES):.0f}%)")
    print("-" * 80)
    for r in results:
        icon = "PASS" if r["status"] == "PASS" else "WARN" if r["status"] == "WARN" else "FAIL"
        rows = r.get("rows_returned", "?")
        print(f"  [{icon}] Q{r['id']:2d}: {r['question'][:50]:50s} | {r['pattern'][:30]:30s} | {rows} rows")
    print("=" * 80)

    return results


if __name__ == "__main__":
    run_evaluation()
