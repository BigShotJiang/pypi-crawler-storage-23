"""
QueryEntityResolver – Entity pre-resolution for the NL-to-SQL pipeline.

Extracts entity candidates from the question text and resolves them
against MongoDB ``entities_master``. Also broadens resolution by
including related/linked entities (parent materials for lots, etc.).
"""

import logging
import re
from typing import Any, Dict, List, Set

from connectors.mongodb_connector import MongoDBConnector

logger = logging.getLogger(__name__)

ENTITIES_COLLECTION = "entities_master"

# Max related entities to add per primary entity (prevents explosion)
_MAX_RELATED_PER_ENTITY = 3


class QueryEntityResolver:
    """Resolve entity mentions from a natural-language question against MongoDB."""

    def __init__(self, mongodb: MongoDBConnector):
        self.mongodb = mongodb

    def resolve_entities_from_question(
        self, question: str, tenant_id: str
    ) -> List[Dict[str, Any]]:
        """
        Extract entity candidates from the question and resolve them
        against MongoDB ``entities_master``.

        After primary resolution, broadens the result set by including
        related entities (e.g., parent material for a lot/batch entity).

        Returns a list of dicts with:
        - entity_id, entity_name, entity_type
        - identifiers
        - attribute_keys (first 30)
        """
        candidates = self._extract_candidates(question)
        if not candidates:
            # Fallback: use every significant word (3+ chars)
            words = set(re.findall(r"\b[A-Za-z0-9][\w\-]{2,}\b", question))
            stop = {
                "the", "and", "for", "are", "what", "which", "how", "all",
                "show", "list", "get", "find", "tell", "about", "from",
                "with", "that", "this", "does", "have", "has", "was", "were",
                "been", "being", "their", "there", "where", "when", "will",
                "can", "could", "would", "should", "into", "than", "then",
                "also", "some", "any", "each", "every", "most", "more",
            }
            candidates = [w for w in words if w.lower() not in stop]

        seen_ids: Set[str] = set()
        resolved: List[Dict[str, Any]] = []

        for candidate in candidates:
            entities = self._search_entity(candidate, tenant_id)
            for ent in entities:
                eid = ent["entity_id"]
                if eid in seen_ids:
                    continue
                seen_ids.add(eid)

                attr_keys = sorted(ent.get("attributes", {}).keys())
                resolved.append({
                    "entity_id": eid,
                    "entity_name": ent["entity_name"],
                    "entity_type": ent.get("entity_type", "OTHER"),
                    "identifiers": ent.get("identifiers", []),
                    "attribute_keys": attr_keys[:30],
                    "attribute_count": len(attr_keys),
                })

        # --- Broaden: find related entities for each primary entity ---
        related = self._find_related_entities(resolved, tenant_id, seen_ids)
        if related:
            logger.info(
                "Entity broadening: added %d related entities from %d primary",
                len(related), len(resolved),
            )
            resolved.extend(related)

        return resolved

    # ------------------------------------------------------------------
    # Related entity broadening
    # ------------------------------------------------------------------

    def _find_related_entities(
        self,
        primary_entities: List[Dict[str, Any]],
        tenant_id: str,
        seen_ids: Set[str],
    ) -> List[Dict[str, Any]]:
        """
        For each primary entity, look for related entities that share
        identifiers, name variations, or are referenced in attributes.

        This handles cases like:
        - Lot "MCC-25-0217" → parent material "Microcrystalline Cellulose, PH 102"
        - Code "RM-MCC-0102" → product entity with that identifier
        - Entity with shared identifier substring
        """
        related: List[Dict[str, Any]] = []

        for primary in primary_entities:
            search_terms: List[str] = []

            # Use identifiers as search terms (e.g., RM-MCC-0102, E001)
            for ident in primary.get("identifiers", []):
                if ident and len(ident) >= 3:
                    search_terms.append(ident)

            # Extract code-like parts from entity name (e.g., "MCC-25-0217" → "MCC")
            name = primary.get("entity_name", "")
            name_codes = re.findall(r"\b[A-Z0-9][\w]*(?:-[\w]+)+\b", name)
            search_terms.extend(name_codes)

            # Extract the root code prefix for partial matching
            # e.g., "MCC-25-0217" → "MCC", "RM-MCC-0102" → "RM-MCC"
            for code in name_codes:
                parts = code.split("-")
                if len(parts) >= 2:
                    # Add the first 1-2 segments as a broader search
                    prefix = "-".join(parts[:2])
                    if len(prefix) >= 3 and prefix not in search_terms:
                        search_terms.append(prefix)

            if not search_terms:
                continue

            # Search MongoDB for entities matching these terms
            found_count = 0
            for term in search_terms:
                if found_count >= _MAX_RELATED_PER_ENTITY:
                    break

                matches = self._search_entity(term, tenant_id)
                for ent in matches:
                    eid = ent["entity_id"]
                    if eid in seen_ids:
                        continue
                    if found_count >= _MAX_RELATED_PER_ENTITY:
                        break

                    seen_ids.add(eid)
                    attr_keys = sorted(ent.get("attributes", {}).keys())
                    related.append({
                        "entity_id": eid,
                        "entity_name": ent["entity_name"],
                        "entity_type": ent.get("entity_type", "OTHER"),
                        "identifiers": ent.get("identifiers", []),
                        "attribute_keys": attr_keys[:30],
                        "attribute_count": len(attr_keys),
                    })
                    found_count += 1
                    logger.info(
                        "Entity broadening: '%s' → '%s' (via term '%s')",
                        primary.get("entity_name"), ent["entity_name"], term,
                    )

        return related

    # ------------------------------------------------------------------
    # Candidate extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_candidates(question: str) -> List[str]:
        """
        Extract likely entity references from the question text.

        Looks for:
        - Codes / IDs (e.g. RM-MCC-0102, SOP-WH-0041)
        - Quoted terms ("Apollo Hospitals")
        - Capitalised multi-word phrases (MCC PH102, Fermi Materials)
        """
        candidates: List[str] = []

        # 1. Codes: sequences with hyphens and digits
        codes = re.findall(r"\b[A-Z0-9][\w]*(?:-[\w]+)+\b", question)
        candidates.extend(codes)

        # 2. Quoted terms
        quoted = re.findall(r'"([^"]+)"', question) + re.findall(r"'([^']+)'", question)
        candidates.extend(quoted)

        # 3. Capitalised phrases (2+ words starting with uppercase)
        cap_phrases = re.findall(r"\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b", question)
        candidates.extend(cap_phrases)

        # 4. Uppercase tokens (MCC, PH102, QC)
        upper_tokens = re.findall(r"\b[A-Z][A-Z0-9]{1,}\b", question)
        candidates.extend(upper_tokens)

        # 5. Mixed-case tokens that look like entity names (PH102, MCC)
        mixed = re.findall(r"\b[A-Z]+[0-9]+\b", question)
        candidates.extend(mixed)

        # Deduplicate while preserving order
        seen: set = set()
        unique: List[str] = []
        for c in candidates:
            cl = c.lower()
            if cl not in seen:
                seen.add(cl)
                unique.append(c)

        return unique

    def _search_entity(
        self, candidate: str, tenant_id: str
    ) -> List[Dict[str, Any]]:
        """Search entities_master for a candidate string."""
        escaped = re.escape(candidate)

        return self.mongodb.find_documents(
            ENTITIES_COLLECTION,
            {
                "tenant_id": tenant_id,
                "$or": [
                    {"entity_name": {"$regex": escaped, "$options": "i"}},
                    {"name_variations": {"$regex": escaped, "$options": "i"}},
                    {"identifiers": {"$regex": escaped, "$options": "i"}},
                    {"attributes.internal_code": {"$regex": escaped, "$options": "i"}},
                    {"attributes.doc_id": {"$regex": escaped, "$options": "i"}},
                ],
            },
            limit=5,
        )
