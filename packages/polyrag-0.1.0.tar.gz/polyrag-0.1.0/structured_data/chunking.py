"""
Generic chunk window builder for structured-data extraction.

This module builds smaller extraction windows for all document types:
- Uses explicit page markers when present (``--- Page N ---``).
- Falls back to paragraph-aware splitting otherwise.
- Applies optional overlap between adjacent windows.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import re
from typing import List, Optional


_PAGE_MARKER_RE = re.compile(r"(?m)^---\s*Page\s+(\d+)\s*---\s*$")
_TABULAR_CUES = (
    "qty",
    "quantity",
    "uom",
    "unit price",
    "amount",
    "material code",
    "batch size",
    "lot number",
    "employee id",
    "annual salary",
)


@dataclass
class ExtractionChunkWindow:
    """A single extraction window sent to the LLM."""

    chunk_index: int
    text: str
    start_page: Optional[int]
    end_page: Optional[int]
    char_count: int
    has_overlap: bool


@dataclass
class _TextUnit:
    text: str
    start_page: Optional[int]
    end_page: Optional[int]


def build_extraction_windows(
    text: str,
    *,
    target_chars: int = 10_000,
    max_chars: int = 12_000,
    overlap_chars: int = 500,
    use_page_windows: bool = True,
    table_safe_split: bool = True,
    table_min_target_chars: int = 2_500,
    table_min_max_chars: int = 3_200,
) -> List[ExtractionChunkWindow]:
    """
    Build extraction windows with optional page awareness and overlap.
    """
    source_text = (text or "").strip()
    if not source_text:
        return []

    safe_max = max(1, int(max_chars))
    safe_target = max(1, min(int(target_chars), safe_max))
    safe_overlap = max(0, int(overlap_chars))
    if table_safe_split and _looks_tabular_content(source_text):
        safe_target = max(safe_target, int(table_min_target_chars))
        safe_max = max(safe_max, int(table_min_max_chars))
        safe_target = min(safe_target, safe_max)

    units = []
    if use_page_windows:
        units = _build_page_units(source_text)
    if not units:
        units = _build_paragraph_units(source_text)

    packed = _pack_units(
        units=units,
        target_chars=safe_target,
        max_chars=safe_max,
    )
    return _apply_overlap(
        windows=packed,
        overlap_chars=safe_overlap,
        max_chars=safe_max,
    )


def _build_page_units(text: str) -> List[_TextUnit]:
    matches = list(_PAGE_MARKER_RE.finditer(text))
    if not matches:
        return []

    units: List[_TextUnit] = []
    leading = text[: matches[0].start()].strip()

    for idx, match in enumerate(matches):
        page_num = int(match.group(1))
        content_start = match.end()
        content_end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        page_content = text[content_start:content_end].strip()
        block = f"--- Page {page_num} ---"
        if page_content:
            block = f"{block}\n{page_content}"
        if idx == 0 and leading:
            block = f"{leading}\n\n{block}"
        units.append(
            _TextUnit(
                text=block,
                start_page=page_num,
                end_page=page_num,
            )
        )
    return units


def _build_paragraph_units(text: str) -> List[_TextUnit]:
    paragraphs = [part.strip() for part in text.split("\n\n") if part.strip()]
    if not paragraphs:
        return [_TextUnit(text=text, start_page=None, end_page=None)]
    return [_TextUnit(text=para, start_page=None, end_page=None) for para in paragraphs]


def _pack_units(
    *,
    units: List[_TextUnit],
    target_chars: int,
    max_chars: int,
) -> List[ExtractionChunkWindow]:
    packed: List[ExtractionChunkWindow] = []

    current_parts: List[str] = []
    current_start_page: Optional[int] = None
    current_end_page: Optional[int] = None
    current_len = 0

    def flush_current() -> None:
        nonlocal current_parts, current_start_page, current_end_page, current_len
        if not current_parts:
            return
        chunk_text = "\n\n".join(current_parts).strip()
        if chunk_text:
            packed.append(
                ExtractionChunkWindow(
                    chunk_index=len(packed),
                    text=chunk_text,
                    start_page=current_start_page,
                    end_page=current_end_page,
                    char_count=len(chunk_text),
                    has_overlap=False,
                )
            )
        current_parts = []
        current_start_page = None
        current_end_page = None
        current_len = 0

    for unit in units:
        for split_text in _split_large_text(unit.text, max_chars):
            split_text = split_text.strip()
            if not split_text:
                continue

            sep = 2 if current_parts else 0
            candidate_len = current_len + sep + len(split_text)

            # Prefer smaller windows around target_chars.
            if current_parts and candidate_len > target_chars:
                flush_current()
                sep = 0
                candidate_len = len(split_text)

            if not current_parts:
                current_start_page = unit.start_page
                current_end_page = unit.end_page
                current_parts = [split_text]
                current_len = candidate_len
            else:
                current_parts.append(split_text)
                current_len = candidate_len
                if unit.end_page is not None:
                    current_end_page = unit.end_page

            # Safety guard for edge cases where candidate still grows too large.
            if current_len >= max_chars:
                flush_current()

    flush_current()
    return packed


def _split_large_text(text: str, max_chars: int) -> List[str]:
    cleaned = (text or "").strip()
    if not cleaned:
        return []
    if len(cleaned) <= max_chars:
        return [cleaned]

    paragraphs = [part.strip() for part in cleaned.split("\n\n") if part.strip()]
    if not paragraphs:
        return _split_hard(cleaned, max_chars)

    chunks: List[str] = []
    current = ""
    for para in paragraphs:
        sep = "\n\n" if current else ""
        candidate = f"{current}{sep}{para}" if current else para
        if len(candidate) <= max_chars:
            current = candidate
            continue

        if current:
            chunks.append(current)
            current = ""

        if len(para) <= max_chars:
            current = para
            continue

        hard_parts = _split_hard(para, max_chars)
        if hard_parts:
            chunks.extend(hard_parts[:-1])
            current = hard_parts[-1]

    if current:
        chunks.append(current)
    return chunks


def _split_hard(text: str, max_chars: int) -> List[str]:
    out: List[str] = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + max_chars, length)
        if end < length:
            line_break = text.rfind("\n", start + int(max_chars * 0.55), end)
            if line_break > start:
                end = line_break
            else:
                space_break = text.rfind(" ", start + int(max_chars * 0.7), end)
                if space_break > start:
                    end = space_break
        part = text[start:end].strip()
        if part:
            out.append(part)
        if end <= start:
            end = min(start + max_chars, length)
        start = end
    return out


def _apply_overlap(
    *,
    windows: List[ExtractionChunkWindow],
    overlap_chars: int,
    max_chars: int,
) -> List[ExtractionChunkWindow]:
    if not windows:
        return []
    if overlap_chars <= 0:
        return [
            replace(win, chunk_index=idx, char_count=len(win.text), has_overlap=False)
            for idx, win in enumerate(windows)
        ]

    with_overlap: List[ExtractionChunkWindow] = []
    for idx, window in enumerate(windows):
        if idx == 0:
            with_overlap.append(
                replace(window, chunk_index=0, char_count=len(window.text), has_overlap=False)
            )
            continue

        prev_text = windows[idx - 1].text
        overlap_text = prev_text[-overlap_chars:].strip()
        if overlap_text and "\n" in overlap_text:
            # Avoid carrying a partial leading line into the next window.
            overlap_text = overlap_text.split("\n", 1)[1].strip()

        if overlap_text:
            allowed = max_chars - len(window.text) - 2
            if allowed <= 0:
                overlap_text = ""
            elif len(overlap_text) > allowed:
                overlap_text = overlap_text[-allowed:]

        merged_text = window.text
        if overlap_text:
            merged_text = f"{overlap_text}\n\n{window.text}"

        with_overlap.append(
            replace(
                window,
                chunk_index=idx,
                text=merged_text,
                char_count=len(merged_text),
                has_overlap=bool(overlap_text),
            )
        )

    return with_overlap


def _looks_tabular_content(text: str) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) < 6:
        return False

    lower = text.lower()
    cue_hits = sum(cue in lower for cue in _TABULAR_CUES)
    numeric_line_hits = 0
    for line in lines:
        if len(re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", line)) >= 2:
            numeric_line_hits += 1
    return (cue_hits >= 1 and numeric_line_hits >= 3) or numeric_line_hits >= 5
