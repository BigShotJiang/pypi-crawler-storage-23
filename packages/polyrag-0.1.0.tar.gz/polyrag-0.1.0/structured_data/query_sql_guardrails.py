"""
QuerySQLGuardrails – SQL validation, normalization, repair, and issue detection.

Handles Athena dialect normalization, issue detection, and LLM-based
SQL repair for the NL-to-SQL pipeline.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from llm.manager import LLMManager
from llm.rate_limit_schemas import LLMRateLimitTimeoutError
from .query_intent import (
    QueryIntent,
    format_intent_context,
    parse_query_intent,
)
from .query_schemas import StructuredQueryResult

logger = logging.getLogger(__name__)

_TYPED_NON_STRING_COLUMNS = ("value_number", "value_date", "value_boolean")

# Tokens that look like identifiers/codes — these SHOULD trigger value_match_preferred.
# General attribute terms (salary, department, density) should NOT trigger it.
_IDENTIFIER_LIKE_TOKEN_RE = re.compile(
    r"^[A-Za-z]{1,6}[-_]\d{2,}$"            # RM-0102, SOP-041
    r"|^[A-Za-z0-9]{2,}(?:-[A-Za-z0-9]{2,})+$"  # RM-MCC-0102
    r"|^[A-Z]+\d+$"                           # PH102, MCC0102
    r"|^\d{5,}$"                              # 13400007
)


class QuerySQLGuardrails:
    """SQL validation, normalization, and repair pipeline."""

    def __init__(self, llm_manager: LLMManager):
        self.llm_manager = llm_manager

    # ------------------------------------------------------------------
    # Main guardrail + repair loop
    # ------------------------------------------------------------------

    def guardrail_and_repair_sql(
        self,
        *,
        question: str,
        tenant_id: str,
        generation_prompt: str,
        sql_result: StructuredQueryResult,
        max_repairs: int,
        enable_row_context_guardrails: bool = False,
        intent: Optional[QueryIntent] = None,
        model_override: Optional[str] = None,
        get_query_llm_fn=None,
    ) -> Optional[StructuredQueryResult]:
        current = self.replace_sql(sql_result, self.normalize_sql(sql_result.sql_query))
        issues = self.detect_sql_issues(
            question=question,
            sql=current.sql_query,
            enable_row_context_guardrails=enable_row_context_guardrails,
            intent=intent,
        )
        if not issues:
            return current

        attempts = 0
        while issues and attempts < max_repairs:
            attempts += 1
            repaired = self.repair_sql_result(
                question=question,
                generation_prompt=generation_prompt,
                current_sql_result=current,
                issues=issues,
                model_override=model_override,
                get_query_llm_fn=get_query_llm_fn,
            )
            if repaired is None:
                break
            repaired_sql = self.normalize_sql(repaired.sql_query)
            current = self.replace_sql(repaired, repaired_sql)
            issues = self.detect_sql_issues(
                question=question,
                sql=current.sql_query,
                enable_row_context_guardrails=enable_row_context_guardrails,
                intent=intent,
            )

        critical = [issue for issue in issues if issue["severity"] == "critical"]
        if critical:
            logger.warning("SQL guardrails rejection: issues=%s", critical)
            return None
        if issues:
            logger.warning("SQL guardrails warnings remain after repair: %s", issues)
        return current

    def repair_zero_result_sql(
        self,
        *,
        question: str,
        tenant_id: str,
        entities: List[Dict[str, Any]],
        generation_prompt: str,
        current_sql_result: StructuredQueryResult,
        profile_hints: Optional[str] = None,
        intent: Optional[QueryIntent] = None,
        model_override: Optional[str] = None,
        get_query_llm_fn=None,
    ) -> Optional[StructuredQueryResult]:
        """
        Ask the LLM for a second SQL attempt when the first query returns zero rows.
        """
        if get_query_llm_fn is None:
            return None
        llm = get_query_llm_fn(model_override)

        entity_lines = []
        for ent in entities[:8]:
            entity_lines.append(
                f"- entity_name={ent.get('entity_name')} | "
                f"entity_id={ent.get('entity_id')} | "
                f"identifiers={ent.get('identifiers', [])}"
            )
        entity_block = "\n".join(entity_lines) if entity_lines else "- none"
        profile_block = profile_hints if profile_hints else "none"

        repair_prompt = (
            "You are repairing an Athena SQL query because it returned zero rows.\n"
            "Preserve user intent but relax over-restrictive filters.\n"
            "Return a single corrected SQL query.\n\n"
            f"User question: {question}\n"
            f"Tenant: {tenant_id}\n\n"
            f"{format_intent_context(intent or parse_query_intent(question, entities))}\n"
            "Resolved entities:\n"
            f"{entity_block}\n\n"
            "Data profile hints:\n"
            f"{profile_block}\n\n"
            "Common zero-row failure modes to fix:\n"
            "1) entity_id filtering too narrow — the data may live under a RELATED entity "
            "(e.g., lot 'MCC-25-0217' test results stored under parent material entity). "
            "If entity_id returns 0 rows, REMOVE the entity_id filter entirely and use "
            "LOWER(entity_name) LIKE or LOWER(related_entity_name) LIKE or "
            "LOWER(value_string) LIKE with the original search terms instead,\n"
            "2) filtering on value_string_normalized LIKE when the search term is an attribute key name "
            "(e.g. 'salary', 'department', 'loss_on_drying', 'payment') — drop the value_string_normalized "
            "filter and rely on LOWER(key) LIKE only,\n"
            "3) over-restrictive data_type filters for specification/procedure/supplier/sampling questions "
            "— try removing data_type filter or broadening to IN ('metric','attribute','line_item','relationship'),\n"
            "4) missing case-insensitive comparisons for units/text,\n"
            "5) overly specific composite keys like 'annual_payments_2024' — use simpler key patterns "
            "like '%payment%' and filter year via file_name LIKE '%2024%',\n"
            "6) combining key LIKE AND value_string LIKE on the same column alias for the same term "
            "(e.g. key LIKE '%department%' AND value_string LIKE '%department%') — keep only the key filter,\n"
            "7) file_name year filtering fails when filename spans multiple years "
            "(e.g. 'Credit_Card_Payments_2023-2025_Account_A.pdf' won't match LIKE '%2024%') — "
            "check if the year might be in the key name instead, or drop the year filter.\n\n"
            "Current SQL (returned 0 rows):\n"
            f"{current_sql_result.sql_query}\n\n"
            "Original generation context:\n"
            f"{generation_prompt[:10000]}"
        )

        try:
            repaired = llm.generate_structured(
                repair_prompt,
                StructuredQueryResult,
                temperature=0.0,
            )
            return self.replace_sql(repaired, self.normalize_sql(repaired.sql_query))
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception("Zero-result SQL repair attempt failed")
            return None

    def repair_sql_result(
        self,
        *,
        question: str,
        generation_prompt: str,
        current_sql_result: StructuredQueryResult,
        issues: List[Dict[str, str]],
        model_override: Optional[str] = None,
        get_query_llm_fn=None,
    ) -> Optional[StructuredQueryResult]:
        if get_query_llm_fn is None:
            return None
        llm = get_query_llm_fn(model_override)
        issue_lines = "\n".join(
            f"- [{issue['severity']}] {issue['code']}: {issue['message']}"
            for issue in issues
        )
        repair_prompt = (
            "You are repairing an Athena SQL query generated from natural language.\n"
            "Fix the SQL so all listed issues are resolved while preserving the user intent.\n"
            "Return a single corrected SQL query.\n\n"
            f"User question: {question}\n\n"
            f"Issues:\n{issue_lines}\n\n"
            f"Current SQL:\n{current_sql_result.sql_query}\n\n"
            f"Original context:\n{generation_prompt[:10000]}"
        )
        try:
            return llm.generate_structured(
                repair_prompt,
                StructuredQueryResult,
                temperature=0.0,
            )
        except LLMRateLimitTimeoutError:
            raise
        except Exception:
            logger.exception("SQL repair attempt failed")
            return None

    # ------------------------------------------------------------------
    # SQL normalization
    # ------------------------------------------------------------------

    @classmethod
    def normalize_sql(cls, sql: str) -> str:
        normalized = cls.normalize_unit_filters(sql)
        normalized = cls.normalize_athena_function_aliases(normalized)
        return cls.normalize_typed_empty_string_comparisons(normalized)

    @staticmethod
    def normalize_athena_function_aliases(sql: str) -> str:
        """Normalize non-Athena function aliases (e.g. array_slice -> SLICE)."""
        return re.sub(
            r"\barray_slice\s*\(",
            "SLICE(",
            sql,
            flags=re.IGNORECASE,
        )

    @staticmethod
    def normalize_unit_filters(sql: str) -> str:
        normalized = sql

        eq_pattern = re.compile(
            r"(?<!LOWER\()(\b[a-zA-Z_]\w*\.unit)\s*=\s*'([^']+)'",
            flags=re.IGNORECASE,
        )
        normalized = eq_pattern.sub(
            lambda m: f"LOWER({m.group(1)}) = '{m.group(2).lower()}'",
            normalized,
        )

        in_pattern = re.compile(
            r"(?<!LOWER\()(\b[a-zA-Z_]\w*\.unit)\s+IN\s*\(([^)]+)\)",
            flags=re.IGNORECASE,
        )

        def _replace_in(match: re.Match[str]) -> str:
            alias = match.group(1)
            values = re.findall(r"'([^']+)'", match.group(2))
            if not values:
                return match.group(0)
            lowered = ", ".join(f"'{value.lower()}'" for value in values)
            return f"LOWER({alias}) IN ({lowered})"

        return in_pattern.sub(_replace_in, normalized)

    @classmethod
    def normalize_typed_empty_string_comparisons(cls, sql: str) -> str:
        """
        Athena cannot compare typed columns (double/date/boolean) to empty strings.
        Normalize these clauses before execution.
        """
        normalized = sql

        for column in _TYPED_NON_STRING_COLUMNS:
            target = rf"((?:\b[a-zA-Z_]\w*\.)?{column})"
            not_equal = re.compile(
                rf"{target}\s*(?:!=|<>)\s*''",
                flags=re.IGNORECASE,
            )
            equal = re.compile(
                rf"{target}\s*=\s*''",
                flags=re.IGNORECASE,
            )
            normalized = not_equal.sub(lambda m: f"{m.group(1)} IS NOT NULL", normalized)
            normalized = equal.sub(lambda m: f"{m.group(1)} IS NULL", normalized)

        cast_not_equal = re.compile(
            r"CAST\(\s*((?:\b[a-zA-Z_]\w*\.)?value_number)\s+AS\s+DOUBLE\s*\)\s*(?:!=|<>)\s*''",
            flags=re.IGNORECASE,
        )
        cast_equal = re.compile(
            r"CAST\(\s*((?:\b[a-zA-Z_]\w*\.)?value_number)\s+AS\s+DOUBLE\s*\)\s*=\s*''",
            flags=re.IGNORECASE,
        )
        normalized = cast_not_equal.sub(lambda m: f"{m.group(1)} IS NOT NULL", normalized)
        normalized = cast_equal.sub(lambda m: f"{m.group(1)} IS NULL", normalized)
        return normalized

    @classmethod
    def has_typed_empty_string_comparison(cls, sql: str) -> bool:
        columns = "|".join(_TYPED_NON_STRING_COLUMNS)
        direct = re.search(
            rf"(?:\b[a-zA-Z_]\w*\.)?(?:{columns})\s*(?:=|!=|<>)\s*''",
            sql,
            flags=re.IGNORECASE,
        )
        casted = re.search(
            r"CAST\(\s*(?:\b[a-zA-Z_]\w*\.)?value_number\s+AS\s+DOUBLE\s*\)\s*(?:=|!=|<>)\s*''",
            sql,
            flags=re.IGNORECASE,
        )
        return bool(direct or casted)

    # ------------------------------------------------------------------
    # SQL issue detection
    # ------------------------------------------------------------------

    def detect_sql_issues(
        self,
        *,
        question: str,
        sql: str,
        enable_row_context_guardrails: bool = False,
        intent: Optional[QueryIntent] = None,
    ) -> List[Dict[str, str]]:
        issues: List[Dict[str, str]] = []
        intent = intent or parse_query_intent(question, [])

        if self.has_typed_empty_string_comparison(sql):
            issues.append(
                {
                    "code": "typed_empty_string_comparison",
                    "severity": "critical",
                    "message": (
                        "Typed columns are compared to empty string literals. "
                        "Use IS NULL / IS NOT NULL checks instead."
                    ),
                }
            )

        # Critical: contradictory same-alias key filters
        alias_matches = re.findall(
            r"LOWER\(\s*([a-zA-Z_]\w*)\.key\s*\)\s+LIKE\s+'%([^']+)%'",
            sql,
            flags=re.IGNORECASE,
        )
        aliases = sorted({alias for alias, _term in alias_matches})
        for alias in aliases:
            material_then_quantity = re.search(
                rf"LOWER\(\s*{alias}\.key\s*\)\s+LIKE\s+'%[^']*material[^']*%'.*?\bAND\b.*?LOWER\(\s*{alias}\.key\s*\)\s+LIKE\s+'%[^']*quantity[^']*%'",
                sql,
                flags=re.IGNORECASE | re.DOTALL,
            )
            quantity_then_material = re.search(
                rf"LOWER\(\s*{alias}\.key\s*\)\s+LIKE\s+'%[^']*quantity[^']*%'.*?\bAND\b.*?LOWER\(\s*{alias}\.key\s*\)\s+LIKE\s+'%[^']*material[^']*%'",
                sql,
                flags=re.IGNORECASE | re.DOTALL,
            )
            if material_then_quantity or quantity_then_material:
                issues.append(
                    {
                        "code": "contradictory_key_filters",
                        "severity": "critical",
                        "message": (
                            f"Alias '{alias}' contains AND-constrained material and quantity key filters."
                        ),
                    }
                )

        # Warning: identifier-like question terms matched only on key (not value).
        # Only triggers for code/ID tokens (RM-MCC-0102, PH102, 13400007), NOT
        # for general attribute terms (salary, department, density, payment).
        for token in self.extract_question_terms(question):
            if not _IDENTIFIER_LIKE_TOKEN_RE.match(token):
                continue  # Skip non-identifier tokens — key-only filtering is correct for attributes
            token_escaped = re.escape(token)
            key_match = re.search(
                rf"LOWER\(\s*[a-zA-Z_]\w*\.key\s*\)\s+LIKE\s+'%[^']*{token_escaped}[^']*%'",
                sql,
                flags=re.IGNORECASE,
            )
            value_match = re.search(
                rf"LOWER\(\s*[a-zA-Z_]\w*\.(value_string|value_string_normalized|entity_name)\s*\)\s+LIKE\s+'%[^']*{token_escaped}[^']*%'",
                sql,
                flags=re.IGNORECASE,
            )
            if key_match and not value_match:
                issues.append(
                    {
                        "code": "value_match_preferred",
                        "severity": "warning",
                        "message": (
                            f"Question token '{token}' is filtered on key only; "
                            "prefer value_string/value_string_normalized for code/material text."
                        ),
                    }
                )

        if (
            enable_row_context_guardrails
            and self.question_needs_row_context(question)
            and self.sql_uses_line_item_join(sql)
        ):
            where_clause = self.extract_where_clause(sql)
            has_entity_name_filter = bool(
                re.search(r"\b[a-zA-Z_]\w*\.entity_name\b", where_clause, flags=re.IGNORECASE)
            )
            has_related_filter = bool(
                re.search(
                    r"\b[a-zA-Z_]\w*\.related_entity_name\b",
                    where_clause,
                    flags=re.IGNORECASE,
                )
            )
            if has_entity_name_filter ^ has_related_filter:
                issues.append(
                    {
                        "code": "row_context_single_side_filter",
                        "severity": "critical",
                        "message": (
                            "Row-level query appears to filter only one context side "
                            "(entity_name or related_entity_name). Use both for robust parent matching."
                        ),
                    }
                )

        if (
            intent.semantic_focus == "specification"
            and re.search(
                r"LOWER\([^)]*\bkey\b[^)]*\)\s+LIKE\s+'%[^']*(result|observed|actual|pass|reading)[^']*%'",
                sql,
                flags=re.IGNORECASE,
            )
            and not re.search(
                r"LOWER\([^)]*\bkey\b[^)]*\)\s+LIKE\s+'%[^']*(limit|spec|criteria|nmt|nlt|max|min)[^']*%'",
                sql,
                flags=re.IGNORECASE,
            )
        ):
            issues.append(
                {
                    "code": "spec_result_mismatch",
                    "severity": "critical",
                    "message": (
                        "Question targets specification/limits, but SQL appears to target result/observed fields only."
                    ),
                }
            )

        if intent.intent_type == "document_search":
            where_clause = self.extract_where_clause(sql)
            searches_entity_only = bool(
                re.search(
                    r"\b(entity_name|related_entity_name)\b",
                    where_clause,
                    flags=re.IGNORECASE,
                )
            ) and not bool(
                re.search(
                    r"\b(value_string|value_string_normalized|evidence|file_name|title|summary)\b",
                    where_clause,
                    flags=re.IGNORECASE,
                )
            )
            if searches_entity_only:
                issues.append(
                    {
                        "code": "document_mention_scope_mismatch",
                        "severity": "warning",
                        "message": (
                            "Document-mention query filters only entity columns. Include value/evidence/title/file signals."
                        ),
                    }
                )

        if (
            intent.intent_type == "listing"
            and re.search(
                r"JOIN\s+awsdatacatalog\..*extracted_data_.*\s+[a-zA-Z_]\w*\s+ON\s+[a-zA-Z_]\w*\.entity_name\s*=\s*[a-zA-Z_]\w*\.entity_name\s+AND\s+[a-zA-Z_]\w*\.document_id\s*=\s*[a-zA-Z_]\w*\.document_id",
                sql,
                flags=re.IGNORECASE,
            )
            and not re.search(r"\bDISTINCT\b|\bGROUP\s+BY\b", sql, flags=re.IGNORECASE)
        ):
            issues.append(
                {
                    "code": "duplicate_risk_join",
                    "severity": "warning",
                    "message": (
                        "Listing query uses a self-join that may multiply rows. Prefer DISTINCT or dedupe-safe grouping."
                    ),
                }
            )

        # Critical: GROUP BY referencing column aliases (not allowed in Athena).
        group_by_match = re.search(
            r"\bGROUP\s+BY\b\s+(.*?)(?:\bORDER\s+BY\b|\bLIMIT\b|\bHAVING\b|$)",
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )
        if group_by_match:
            # Extract SELECT aliases (e.g., "AS year", "AS total")
            select_aliases = {
                m.strip().lower()
                for m in re.findall(r"\bAS\s+(\w+)", sql, flags=re.IGNORECASE)
            }
            # Extract GROUP BY column references
            group_cols = [
                col.strip().lower()
                for col in group_by_match.group(1).split(",")
            ]
            # Known table columns that are NOT aliases
            table_columns = {
                "entity_name", "entity_id", "entity_type", "key", "value_string",
                "value_number", "unit", "data_type", "category", "document_id",
                "file_name", "title", "document_type", "evidence", "chunk_id",
                "page_number", "row_ref", "line_item_id", "created_at",
                "related_entity_name", "related_entity_type",
            }
            for col in group_cols:
                # Strip table alias prefix (e.g., "e.key" -> "key")
                bare_col = col.split(".")[-1].strip() if "." in col else col.strip()
                if bare_col in select_aliases and bare_col not in table_columns:
                    issues.append(
                        {
                            "code": "group_by_alias",
                            "severity": "critical",
                            "message": (
                                f"GROUP BY references column alias '{bare_col}'. "
                                "Athena does not allow column aliases in GROUP BY. "
                                "Use the full expression instead."
                            ),
                        }
                    )
                    break  # One issue is enough

        return issues

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def replace_sql(result: StructuredQueryResult, sql_query: str) -> StructuredQueryResult:
        return StructuredQueryResult(
            reasoning=result.reasoning,
            sql_query=sql_query,
            expects_multiple_rows=result.expects_multiple_rows,
            result_description=result.result_description,
        )

    @staticmethod
    def question_needs_row_context(question: str) -> bool:
        q = question.lower()
        has_material_signal = any(
            token in q
            for token in ("material", "code", "component", "ingredient", "packing")
        )
        has_parent_signal = any(
            token in q
            for token in ("product", "for ", "across", "in which", "where")
        )
        has_quantity_signal = any(
            token in q
            for token in ("quantity", "qty", "total")
        )
        return has_material_signal and (has_parent_signal or has_quantity_signal)

    @staticmethod
    def sql_uses_line_item_join(sql: str) -> bool:
        return bool(re.search(r"\bline_item_id\b", sql, flags=re.IGNORECASE))

    @staticmethod
    def extract_where_clause(sql: str) -> str:
        match = re.search(
            r"\bWHERE\b(.*?)(?:\bGROUP\s+BY\b|\bORDER\s+BY\b|\bLIMIT\b|$)",
            sql,
            flags=re.IGNORECASE | re.DOTALL,
        )
        return match.group(1) if match else ""

    @staticmethod
    def extract_question_terms(question: str) -> List[str]:
        stop_words = {
            "what", "which", "where", "when", "show", "list", "find",
            "total", "quantity", "unit", "material", "product", "batch",
            "size", "data", "document", "documents", "across", "from",
            "with", "into", "there", "about", "their", "this", "that",
        }
        tokens = re.findall(r"\b[a-zA-Z][a-zA-Z0-9\-]{4,}\b", question.lower())
        filtered: List[str] = []
        for token in tokens:
            if token in stop_words:
                continue
            if token not in filtered:
                filtered.append(token)
        return filtered[:8]
