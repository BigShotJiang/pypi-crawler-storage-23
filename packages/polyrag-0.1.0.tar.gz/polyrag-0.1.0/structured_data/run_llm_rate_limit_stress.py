"""
Stress test runner for global LLM TPM/RPM limiter.

Usage:
    # Dry-run against limiter only (no provider/API cost)
    python -m structured_data.run_llm_rate_limit_stress --mode dry-run --concurrency 20 --total-calls 80

    # Live calls through wrapped provider (incurs API usage)
    python -m structured_data.run_llm_rate_limit_stress --mode live-generate --concurrency 8 --total-calls 40
"""

from __future__ import annotations

import argparse
import json
import logging
import statistics
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from queue import Queue, Empty
from typing import Dict, List, Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field

_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
import sys
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

load_dotenv(override=True)

from app.config.llm import get_llm_config
from llm.base import LLMProvider
from llm.manager import LLMManager
from llm.rate_limit import RateLimitedLLMProvider, get_global_rate_limiter
from llm.rate_limit_schemas import (
    LLMRateLimitTimeoutError,
    RateLimitKey,
    RateLimitPolicy,
)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(name)-40s  %(levelname)-7s  %(message)s",
)
logger = logging.getLogger(__name__)


class StressStructuredResponse(BaseModel):
    """Small schema for structured-output stress runs."""

    status: str = Field(..., description="Return literal 'ok'")
    worker: int = Field(..., description="Worker id")
    call_id: int = Field(..., description="Call sequence id")


@dataclass
class CallResult:
    call_id: int
    worker_id: int
    status: str
    elapsed_seconds: float
    queue_wait_seconds: float
    total_tokens: Optional[int] = None
    retry_after_seconds: Optional[float] = None
    error: Optional[str] = None


def _build_prompt_for_tokens(llm: LLMProvider, target_input_tokens: int) -> str:
    """
    Build a deterministic prompt approximately matching target token count.
    """
    base = (
        "You are a test assistant. Respond briefly and follow instructions exactly. "
        "This is a limiter stress test payload."
    )
    prompt = base
    target = max(32, int(target_input_tokens))
    while int(llm.estimate_tokens(prompt)) < target:
        prompt += (
            "\nSection: synthetic text for load testing. "
            "Keep output concise. Do not add explanations."
        )
    return prompt


def _run_live_call(
    llm,
    *,
    mode: str,
    prompt: str,
    call_id: int,
    worker_id: int,
    max_tokens: Optional[int],
) -> CallResult:
    started = time.time()
    try:
        if mode == "live-generate":
            result = llm.generate(
                prompt,
                temperature=0.0,
                max_tokens=max_tokens,
            )
            tokens = LLMProvider.extract_total_tokens_from_usage(result.usage)
        elif mode == "live-structured":
            structured_prompt = (
                prompt
                + f"\nReturn JSON with: status='ok', worker={worker_id}, call_id={call_id}."
            )
            result = llm.generate_structured(
                structured_prompt,
                StressStructuredResponse,
                temperature=0.0,
                max_tokens=max_tokens,
            )
            tokens = None
            _ = result
        else:
            raise ValueError(f"Unsupported live mode: {mode}")

        elapsed = time.time() - started
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status="ok",
            elapsed_seconds=elapsed,
            queue_wait_seconds=elapsed,
            total_tokens=tokens,
        )
    except LLMRateLimitTimeoutError as exc:
        elapsed = time.time() - started
        label = "timeout_provider" if "upstream provider" in str(exc).lower() else "timeout_local_guard"
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status=label,
            elapsed_seconds=elapsed,
            queue_wait_seconds=exc.queue_wait_elapsed,
            retry_after_seconds=exc.retry_after_seconds,
            error=str(exc),
        )
    except Exception as exc:
        elapsed = time.time() - started
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status="error",
            elapsed_seconds=elapsed,
            queue_wait_seconds=elapsed,
            error=str(exc),
        )


def _run_dry_call(
    *,
    provider: str,
    model: str,
    call_id: int,
    worker_id: int,
    estimated_tokens: int,
) -> CallResult:
    cfg = get_llm_config()
    limiter = get_global_rate_limiter(cfg)
    policy_dict = cfg.get_rate_limit_policy(provider, model)
    policy = RateLimitPolicy(**policy_dict)
    key = RateLimitKey(provider=provider, model=model)
    request_id = str(uuid.uuid4())
    started = time.time()
    try:
        decision = limiter.acquire(
            key=key,
            policy=policy,
            estimated_tokens=estimated_tokens,
            request_id=request_id,
            timeout_s=policy.max_wait_seconds,
        )
        # Small synthetic processing interval.
        time.sleep(0.02)
        limiter.complete(
            key=key,
            policy=policy,
            request_id=request_id,
            actual_tokens=max(1, int(estimated_tokens * 0.85)),
        )
        elapsed = time.time() - started
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status="ok",
            elapsed_seconds=elapsed,
            queue_wait_seconds=decision.wait_seconds,
            total_tokens=int(estimated_tokens * 0.85),
        )
    except LLMRateLimitTimeoutError as exc:
        elapsed = time.time() - started
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status="timeout_local_guard",
            elapsed_seconds=elapsed,
            queue_wait_seconds=exc.queue_wait_elapsed,
            retry_after_seconds=exc.retry_after_seconds,
            error=str(exc),
        )
    except Exception as exc:
        elapsed = time.time() - started
        return CallResult(
            call_id=call_id,
            worker_id=worker_id,
            status="error",
            elapsed_seconds=elapsed,
            queue_wait_seconds=elapsed,
            error=str(exc),
        )


def _summarize(results: List[CallResult]) -> Dict[str, object]:
    statuses = [r.status for r in results]
    ok = statuses.count("ok")
    timeout_local = statuses.count("timeout_local_guard")
    timeout_provider = statuses.count("timeout_provider")
    errors = statuses.count("error")
    elapsed = [r.elapsed_seconds for r in results]
    waits = [r.queue_wait_seconds for r in results]
    token_vals = [r.total_tokens for r in results if r.total_tokens is not None]
    retry_after_vals = [r.retry_after_seconds for r in results if r.retry_after_seconds is not None]

    return {
        "total_calls": len(results),
        "ok": ok,
        "timeout_local_guard": timeout_local,
        "timeout_provider": timeout_provider,
        "errors": errors,
        "ok_ratio": round(ok / len(results), 4) if results else 0.0,
        "elapsed_seconds": {
            "min": round(min(elapsed), 4) if elapsed else 0.0,
            "p50": round(statistics.median(elapsed), 4) if elapsed else 0.0,
            "max": round(max(elapsed), 4) if elapsed else 0.0,
            "avg": round(statistics.mean(elapsed), 4) if elapsed else 0.0,
        },
        "queue_wait_seconds": {
            "min": round(min(waits), 4) if waits else 0.0,
            "p50": round(statistics.median(waits), 4) if waits else 0.0,
            "max": round(max(waits), 4) if waits else 0.0,
            "avg": round(statistics.mean(waits), 4) if waits else 0.0,
        },
        "token_usage_reported_total": int(sum(token_vals)) if token_vals else 0,
        "token_usage_samples": len(token_vals),
        "retry_after_samples": len(retry_after_vals),
    }


def _evaluate_thresholds(
    summary: Dict[str, object],
    *,
    expect_min_success: int,
    expect_min_timeouts: int,
    expect_max_errors: int,
) -> List[str]:
    failures: List[str] = []
    if int(summary["ok"]) < expect_min_success:
        failures.append(
            f"expected at least {expect_min_success} successful calls, got {summary['ok']}"
        )
    timeout_total = int(summary["timeout_local_guard"]) + int(summary["timeout_provider"])
    if timeout_total < expect_min_timeouts:
        failures.append(
            f"expected at least {expect_min_timeouts} timeout calls, got {timeout_total}"
        )
    if int(summary["errors"]) > expect_max_errors:
        failures.append(
            f"expected at most {expect_max_errors} errors, got {summary['errors']}"
        )
    return failures


def run_stress(
    *,
    mode: str,
    concurrency: int,
    total_calls: int,
    provider: str,
    model: str,
    input_tokens: int,
    max_tokens: Optional[int],
    expect_min_success: int,
    expect_min_timeouts: int,
    expect_max_errors: int,
) -> int:
    manager = LLMManager()
    llm = manager.get_llm(provider=provider, model=model, use_cache=False)

    if mode.startswith("live") and not isinstance(llm, RateLimitedLLMProvider):
        logger.error(
            "Rate limiter wrapper is not active. Set LLM_RATE_LIMIT_ENABLED=true first."
        )
        return 2

    prompt = _build_prompt_for_tokens(llm, input_tokens)
    est_in = int(llm.estimate_tokens(prompt))

    llm_cfg = get_llm_config()
    policy = llm_cfg.get_rate_limit_policy(provider, model)

    print("=" * 90)
    print("LLM RATE LIMIT STRESS TEST")
    print("=" * 90)
    print(f"mode                : {mode}")
    print(f"provider/model      : {provider}:{model}")
    print(f"concurrency         : {concurrency}")
    print(f"total_calls         : {total_calls}")
    print(f"prompt_est_tokens   : {est_in}")
    print(f"max_tokens          : {max_tokens}")
    print(f"policy              : {json.dumps(policy)}")
    print("-" * 90)
    if mode.startswith("live"):
        print("NOTE: live mode performs real provider calls and can incur API cost.")
    else:
        print("NOTE: dry-run mode tests limiter behavior without provider API calls.")
    print("=" * 90)

    work_q: Queue = Queue()
    for i in range(total_calls):
        work_q.put(i)

    results: List[CallResult] = []
    results_lock = threading.Lock()

    def worker(worker_id: int):
        while True:
            try:
                call_id = work_q.get_nowait()
            except Empty:
                return
            try:
                if mode.startswith("live"):
                    res = _run_live_call(
                        llm,
                        mode=mode,
                        prompt=prompt,
                        call_id=call_id,
                        worker_id=worker_id,
                        max_tokens=max_tokens,
                    )
                else:
                    res = _run_dry_call(
                        provider=provider,
                        model=model,
                        call_id=call_id,
                        worker_id=worker_id,
                        estimated_tokens=max(1, est_in + (max_tokens or policy["output_token_reserve"])),
                    )
                with results_lock:
                    results.append(res)
            finally:
                work_q.task_done()

    threads = [
        threading.Thread(target=worker, args=(idx,), daemon=True)
        for idx in range(max(1, concurrency))
    ]
    started = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    total_elapsed = time.time() - started

    results.sort(key=lambda x: x.call_id)
    summary = _summarize(results)
    summary["wall_clock_seconds"] = round(total_elapsed, 4)
    summary["effective_calls_per_min"] = round(
        (float(summary["total_calls"]) / total_elapsed) * 60.0, 4
    ) if total_elapsed > 0 else 0.0

    failures = _evaluate_thresholds(
        summary,
        expect_min_success=expect_min_success,
        expect_min_timeouts=expect_min_timeouts,
        expect_max_errors=expect_max_errors,
    )

    print("\nSUMMARY")
    print("-" * 90)
    print(json.dumps(summary, indent=2))
    print("-" * 90)

    if failures:
        print("THRESHOLD FAILURES:")
        for f in failures:
            print(f"- {f}")
        return 1

    print("PASS: thresholds satisfied.")
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Stress-test global LLM TPM/RPM limiter behavior.",
    )
    parser.add_argument(
        "--mode",
        choices=["dry-run", "live-generate", "live-structured"],
        default="dry-run",
        help="dry-run avoids provider calls; live-* executes real LLM calls.",
    )
    parser.add_argument("--provider", default="openai", help="Provider key (openai/google).")
    parser.add_argument("--model", default="gpt-4o", help="Model name.")
    parser.add_argument("--concurrency", type=int, default=8, help="Parallel worker count.")
    parser.add_argument("--total-calls", type=int, default=40, help="Total calls to issue.")
    parser.add_argument(
        "--input-tokens",
        type=int,
        default=900,
        help="Approximate prompt token target per call.",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        default=256,
        help="max_tokens to pass into live calls (also affects reserved budget).",
    )
    parser.add_argument("--expect-min-success", type=int, default=1)
    parser.add_argument("--expect-min-timeouts", type=int, default=0)
    parser.add_argument("--expect-max-errors", type=int, default=0)

    args = parser.parse_args()

    exit_code = run_stress(
        mode=args.mode,
        concurrency=max(1, args.concurrency),
        total_calls=max(1, args.total_calls),
        provider=args.provider,
        model=args.model,
        input_tokens=max(16, args.input_tokens),
        max_tokens=max(1, args.max_tokens) if args.max_tokens is not None else None,
        expect_min_success=max(0, args.expect_min_success),
        expect_min_timeouts=max(0, args.expect_min_timeouts),
        expect_max_errors=max(0, args.expect_max_errors),
    )
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
