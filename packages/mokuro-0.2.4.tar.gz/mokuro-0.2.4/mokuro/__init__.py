from ._version import __version__ as __version__

from mokuro.manga_page_ocr import MangaPageOcr as MangaPageOcr
from mokuro.mokuro_generator import MokuroGenerator as MokuroGenerator
