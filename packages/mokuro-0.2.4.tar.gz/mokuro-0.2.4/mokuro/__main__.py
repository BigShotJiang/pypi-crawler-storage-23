import fire

from mokuro.run import run


def main():
    fire.Fire(run)


if __name__ == "__main__":
    main()
