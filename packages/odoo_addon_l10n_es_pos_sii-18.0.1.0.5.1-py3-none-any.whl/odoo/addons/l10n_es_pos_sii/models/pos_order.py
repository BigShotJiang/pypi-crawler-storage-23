# Copyright 2023 Aures Tic - Almudena de la Puente <almudena@aurestic.es>
# Copyright 2023 Aures Tic - Jose Zambudio <jose@aurestic.es>
# Copyright 2026 Tecnativa - Pedro M. Baeza
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html)

from odoo import _, api, fields, models
from odoo.exceptions import UserError
from odoo.osv.expression import AND, OR

SII_VALID_POS_ORDER_STATES = ["paid", "done"]


class PosOrder(models.Model):
    _name = "pos.order"
    _inherit = ["pos.order", "sii.mixin"]

    @api.depends("company_id", "state")
    def _compute_sii_description(self):
        for order in self:
            order.sii_description = order.company_id.sii_pos_description

    @api.depends("amount_total")
    def _compute_macrodata(self):
        return super()._compute_macrodata()

    @api.depends(
        "company_id",
        "company_id.sii_enabled",
        "fiscal_position_id",
        "fiscal_position_id.aeat_active",
        "is_l10n_es_simplified_invoice",
    )
    def _compute_sii_enabled(self):
        """Compute if the order is enabled for the SII"""
        for order in self:
            if order.company_id.sii_enabled and order.is_l10n_es_simplified_invoice:
                order.sii_enabled = (
                    order.fiscal_position_id and order.fiscal_position_id.aeat_active
                ) or not order.fiscal_position_id
            else:
                order.sii_enabled = False

    @api.model
    def _search_sii_enabled(self, operator, value):
        # Extend the search method for taking into account PoS SII enabled conditions
        domain = super()._search_sii_enabled(operator, value)
        condition_1 = [("is_l10n_es_simplified_invoice", operator, value)]
        condition_2 = [("fiscal_position_id.aeat_active", operator, value)]
        search_ko = (operator == "=" and not value) or (operator == "!=" and value)
        if not search_ko:
            condition_2 = OR([condition_2, [("fiscal_position_id", "=", False)]])
        conditions = [domain, condition_1, condition_2]
        exp_condition = OR if search_ko else AND
        return exp_condition(conditions)

    @api.depends("amount_total")
    def _compute_sii_refund_type(self):
        for record in self:
            if 0 > record.amount_total:
                record.sii_refund_type = "I"
            else:
                record.sii_refund_type = False

    @api.model
    def _process_order(self, pos_order, existing_order):
        # Inject proper value for aeat_state
        if not existing_order:
            pos_order["aeat_state"] = "not_sent"
        return super()._process_order(pos_order, existing_order)

    def _is_sii_type_breakdown_required(self, taxes_dict):
        """As these are simplified invoices, we don't break taxes.

        El desglose se hará obligatoriamente a nivel de tipo de operación si
        cumple las 2 condiciones:
            1- No sea F2-factura simplificada o F4-asiento resumen
            2- La contraparte sea del tipo IDOtro o que sea NIF que empiece por N
        """
        return False

    def _get_valid_document_states(self):
        return SII_VALID_POS_ORDER_STATES

    def _aeat_get_partner(self):
        partner = self.env.ref("l10n_es.partner_simplified", raise_if_not_found=False)
        if not partner:
            raise UserError(
                _("Simplified Invoice Partner not found. Please update l10n_es module.")
            )
        return partner

    def _is_aeat_simplified_invoice(self):
        return True

    def _get_mapping_key(self):
        return "out_invoice"

    def _get_document_date(self):
        return self.date_order

    def _get_document_fiscal_date(self):
        return self.date_order

    def _get_document_serial_number(self):
        return (self.l10n_es_unique_id or self.pos_reference)[0:60]

    def _get_document_product_exempt(self, applied_taxes):
        return set(
            self.mapped("lines")
            .filtered(
                lambda x: (
                    any(tax in x.tax_ids_after_fiscal_position for tax in applied_taxes)
                    and x.product_id.sii_exempt_cause
                    and x.product_id.sii_exempt_cause != "none"
                )
            )
            .mapped("product_id.sii_exempt_cause")
        )

    def _get_tax_info(self):
        self.ensure_one()
        taxes = {}
        for line in self.lines:
            if not line.tax_ids_after_fiscal_position:
                continue
            line_taxes = line.tax_ids_after_fiscal_position.sudo().compute_all(
                line.price_unit * (1 - (line.discount or 0.0) / 100.0),
                line.order_id.pricelist_id.currency_id or self.session_id.currency_id,
                line.qty,
                product=line.product_id,
                partner=self._aeat_get_partner(),
            )
            for line_tax in line_taxes["taxes"]:
                tax = self.env["account.tax"].browse(line_tax["id"])
                taxes.setdefault(
                    tax,
                    {"tax": tax, "amount": 0.0, "base": 0.0},
                )
                taxes[tax]["amount"] += line_tax["amount"]
                taxes[tax]["base"] += line_tax["base"]
        return taxes

    def _get_sii_tax_req(self, tax):
        """Get the associated req tax for the specified tax.

        :param self: Single invoice record.
        :param tax: Initial tax for searching for the RE linked tax.
        :return: REQ tax (or empty recordset) linked to the provided tax.
        """
        self.ensure_one()
        taxes_req = self._get_aeat_taxes_map(["RE"], self._get_document_fiscal_date())
        re_lines = self.lines.filtered(
            lambda x: tax in x.tax_ids_after_fiscal_position
            and x.tax_ids_after_fiscal_position & taxes_req
        )
        req_tax = re_lines.mapped("tax_ids_after_fiscal_position") & taxes_req
        if len(req_tax) > 1:
            raise UserError(_("There's a mismatch in taxes for RE. Check them."))
        return req_tax

    def _get_document_amount_total(self):
        return self.amount_total

    def _get_sii_invoice_type(self):
        return "R5" if self.amount_total < 0.0 else "F2"

    def _get_aeat_invoice_dict_out(self, cancel=False):
        inv_dict = super()._get_aeat_invoice_dict_out(cancel=cancel)
        if self.amount_total < 0.0:
            inv_dict["FacturaExpedida"]["TipoRectificativa"] = "I"
        return inv_dict

    @api.model
    def _send_to_sii_valid(self):
        documents = self.search(
            [
                ("state", "in", self._get_valid_document_states()),
                ("aeat_state", "not in", ["sent", "cancelled"]),
                ("sii_enabled", "=", True),
                ("sii_send_date", "<=", fields.Datetime.now()),
            ]
        )
        if documents:
            documents.confirm_one_document()

    @api.model
    def _send_to_sii(self):
        self._send_to_sii_valid()
