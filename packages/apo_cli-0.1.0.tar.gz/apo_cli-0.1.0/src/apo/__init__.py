"""Apo — Turn conversations into contracts.

Intent spec compiler for human-AI collaboration, organized by six
research-validated primitives: WANT, DON'T, LIKE, FOR, ENSURE, TRUST.
"""

__version__ = "0.1.0"
