"""Fractal Agent Infra — shared runtime infrastructure.

Provides tracing, auth middleware, and store namespace conventions
for the fractal-agents-runtime ecosystem.

Usage::

    from infra.tracing import initialize_langfuse, inject_tracing
    from infra.store_namespace import build_namespace, CATEGORY_TOKENS
"""

from importlib.metadata import PackageNotFoundError, version

from infra.prompts import get_prompt, register_default_prompt, seed_default_prompts
from infra.store_namespace import (
    CATEGORY_CONTEXT,
    CATEGORY_MEMORIES,
    CATEGORY_PREFERENCES,
    CATEGORY_TOKENS,
    GLOBAL_AGENT_ID,
    SHARED_USER_ID,
    NamespaceComponents,
    build_namespace,
    extract_namespace_components,
)
from infra.tracing import (
    initialize_langfuse,
    inject_tracing,
    is_langfuse_configured,
    is_langfuse_enabled,
    shutdown_langfuse,
)

__all__ = [
    "CATEGORY_CONTEXT",
    "CATEGORY_MEMORIES",
    "CATEGORY_PREFERENCES",
    "CATEGORY_TOKENS",
    "GLOBAL_AGENT_ID",
    "SHARED_USER_ID",
    "NamespaceComponents",
    "build_namespace",
    "extract_namespace_components",
    "get_prompt",
    "register_default_prompt",
    "seed_default_prompts",
    "initialize_langfuse",
    "inject_tracing",
    "is_langfuse_configured",
    "is_langfuse_enabled",
    "shutdown_langfuse",
]

try:
    __version__ = version("fractal-agents-runtime")
except PackageNotFoundError:
    # Running from source / editable install before first ``uv sync``.
    __version__ = "0.0.0-dev"
