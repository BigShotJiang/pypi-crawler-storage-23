# Image to ASCII Renderer

Based on [Alex Harri's article](https://alexharri.com/blog/ascii-rendering).

