"""Macro Analyst agent — uses e-Stat and BOJ data."""

from __future__ import annotations

import json
from typing import Any

from japan_trading_agents.agents.base import BaseAgent

SYSTEM_PROMPT = """\
You are a Macro Economist analyzing the Japanese economic environment.
You use government statistics (e-Stat) and Bank of Japan data.

Your analysis should cover:
1. GDP growth and economic cycle positioning
2. Inflation (CPI) trends and BOJ monetary policy
3. Interest rates and yield curve implications
4. Currency (JPY) strength and trade balance
5. How macro conditions affect the target company/sector

Output in structured markdown. Be specific with data points.
Language: Match the user's language (Japanese or English).
"""


class MacroAnalyst(BaseAgent):
    """Analyzes macroeconomic environment using e-Stat and BOJ data."""

    name = "macro_analyst"
    display_name = "Macro Analyst"
    system_prompt = SYSTEM_PROMPT

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        macro = context.get("macro")
        boj = context.get("boj")

        parts = [f"Analyze macroeconomic conditions relevant to stock code {code}.\n"]

        if macro:
            parts.append(f"e-Stat Data:\n{json.dumps(macro, ensure_ascii=False, indent=2)}\n")
        else:
            parts.append("e-Stat data unavailable.\n")

        if boj:
            parts.append(f"BOJ Data:\n{json.dumps(boj, ensure_ascii=False, indent=2)}\n")
        else:
            parts.append("BOJ data unavailable.\n")

        if not macro and not boj:
            parts.append(
                "No macro data available. Provide a general overview of current "
                "Japanese economic conditions based on your knowledge."
            )

        return "\n".join(parts)

    def _get_sources(self) -> list[str]:
        return ["estat", "boj"]
