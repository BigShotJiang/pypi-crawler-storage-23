"""Base agent class for all trading agents."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from japan_trading_agents.models import AgentReport

if TYPE_CHECKING:
    from japan_trading_agents.llm import LLMClient


class BaseAgent:
    """Base class for all agents in the trading pipeline."""

    name: str = "base"
    display_name: str = "Base Agent"
    system_prompt: str = ""

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    async def analyze(self, context: dict[str, Any]) -> AgentReport:
        """Run analysis and return a structured report."""
        user_prompt = self._build_prompt(context)
        raw = await self.llm.complete(self.system_prompt, user_prompt)
        return AgentReport(
            agent_name=self.name,
            display_name=self.display_name,
            content=raw,
            data_sources=self._get_sources(),
        )

    def _build_prompt(self, context: dict[str, Any]) -> str:
        """Build user prompt from context data. Override in subclasses."""
        raise NotImplementedError

    def _get_sources(self) -> list[str]:
        """Return list of data sources used. Override in subclasses."""
        return []
