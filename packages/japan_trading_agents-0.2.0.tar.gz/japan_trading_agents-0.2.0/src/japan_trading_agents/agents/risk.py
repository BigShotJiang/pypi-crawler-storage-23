"""Risk Manager agent — validates trading decisions."""

from __future__ import annotations

from typing import Any

from japan_trading_agents.agents.base import BaseAgent
from japan_trading_agents.models import AgentReport, RiskReview, TradingDecision

SYSTEM_PROMPT = """\
You are a Risk Manager reviewing trading decisions for Japanese equities.

Your job is to validate or reject the proposed trade. Consider:
1. Position sizing appropriateness
2. Concentration risk
3. Macro risk factors (FX, rates, geopolitical)
4. Liquidity risk
5. Downside scenarios

You MUST output valid JSON with exactly these fields:
{
  "approved": true | false,
  "concerns": ["string", ...],
  "max_position_pct": float | null,
  "reasoning": "string"
}

Be conservative. Reject trades with insufficient evidence or excessive risk.
Approve with conditions when appropriate (e.g., reduce position size).
"""


class RiskManager(BaseAgent):
    """Reviews and approves/rejects trading decisions."""

    name = "risk_manager"
    display_name = "Risk Manager"
    system_prompt = SYSTEM_PROMPT

    async def analyze(self, context: dict[str, Any]) -> AgentReport:
        """Override to parse structured risk review."""
        user_prompt = self._build_prompt(context)
        result = await self.llm.complete_json(self.system_prompt, user_prompt)

        review = RiskReview(
            approved=result.get("approved", False),
            concerns=result.get("concerns", []),
            max_position_pct=result.get("max_position_pct"),
            reasoning=result.get("reasoning", "No reasoning provided"),
        )

        return AgentReport(
            agent_name=self.name,
            display_name=self.display_name,
            content=review.model_dump_json(indent=2),
            data_sources=[],
        )

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        decision = context.get("decision")
        reports = context.get("analyst_reports", [])

        parts = [f"Review this trading decision for stock code {code}.\n"]

        if decision:
            if isinstance(decision, AgentReport):
                parts.append(f"## Proposed Trade\n{decision.content}\n")
            elif isinstance(decision, TradingDecision):
                parts.append(f"## Proposed Trade\n{decision.model_dump_json(indent=2)}\n")

        if reports:
            parts.append("## Analyst Report Summaries\n")
            for r in reports:
                if isinstance(r, AgentReport):
                    parts.append(f"**{r.display_name}**: {r.content[:300]}\n")

        return "\n".join(parts)
