"""Bull and Bear Researcher agents for investment debate."""

from __future__ import annotations

from typing import Any

from japan_trading_agents.agents.base import BaseAgent
from japan_trading_agents.models import AgentReport

BULL_SYSTEM_PROMPT = """\
You are a Bullish Researcher. Your role is to build the strongest possible
investment case for buying this stock.

Use evidence from the analyst reports provided. Structure your argument:
1. Key strengths and competitive advantages
2. Growth catalysts (near-term and long-term)
3. Valuation argument (why it's undervalued or fairly valued)
4. Positive macro/sector tailwinds

Be persuasive but honest — acknowledge risks briefly at the end.
Language: Match the user's language (Japanese or English).
"""

BEAR_SYSTEM_PROMPT = """\
You are a Bearish Researcher. Your role is to identify all risks and reasons
NOT to invest in this stock.

Challenge the bullish case. Focus on:
1. Overvaluation risks
2. Declining margins or competitive threats
3. Regulatory or governance risks
4. Macro headwinds (JPY, interest rates, demographics)
5. Sector-specific downside scenarios

Be thorough and data-driven. Don't be contrarian for its own sake.
Language: Match the user's language (Japanese or English).
"""


class BullResearcher(BaseAgent):
    """Builds the bullish investment case."""

    name = "bull_researcher"
    display_name = "Bull Researcher"
    system_prompt = BULL_SYSTEM_PROMPT

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        reports = context.get("analyst_reports", [])
        bear_case = context.get("bear_case")

        parts = [f"Build a bullish case for stock code {code}.\n"]
        parts.append("## Analyst Reports\n")

        for r in reports:
            if isinstance(r, AgentReport):
                parts.append(f"### {r.display_name}\n{r.content}\n")
            elif isinstance(r, dict):
                parts.append(f"### {r.get('display_name', 'Analyst')}\n{r.get('content', '')}\n")

        if bear_case:
            content = bear_case.content if isinstance(bear_case, AgentReport) else str(bear_case)
            parts.append(f"\n## Bear Case to Counter\n{content}\n")
            parts.append("\nProvide a rebuttal to the bearish arguments above.")

        return "\n".join(parts)

    def _get_sources(self) -> list[str]:
        return []


class BearResearcher(BaseAgent):
    """Builds the bearish investment case."""

    name = "bear_researcher"
    display_name = "Bear Researcher"
    system_prompt = BEAR_SYSTEM_PROMPT

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        reports = context.get("analyst_reports", [])
        bull_case = context.get("bull_case")

        parts = [f"Build a bearish case for stock code {code}.\n"]
        parts.append("## Analyst Reports\n")

        for r in reports:
            if isinstance(r, AgentReport):
                parts.append(f"### {r.display_name}\n{r.content}\n")
            elif isinstance(r, dict):
                parts.append(f"### {r.get('display_name', 'Analyst')}\n{r.get('content', '')}\n")

        if bull_case:
            content = bull_case.content if isinstance(bull_case, AgentReport) else str(bull_case)
            parts.append(f"\n## Bull Case to Challenge\n{content}\n")
            parts.append("\nChallenge and counter the bullish arguments above.")

        return "\n".join(parts)

    def _get_sources(self) -> list[str]:
        return []
