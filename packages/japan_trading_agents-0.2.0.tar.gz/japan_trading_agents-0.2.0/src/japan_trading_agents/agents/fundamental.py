"""Fundamental Analyst agent — uses EDINET data."""

from __future__ import annotations

import json
from typing import Any

from japan_trading_agents.agents.base import BaseAgent

SYSTEM_PROMPT = """\
You are a Fundamental Analyst specializing in Japanese equities.
You analyze financial statements from EDINET (有価証券報告書) filings.

Your analysis should cover:
1. Profitability (ROE, ROA, operating margin, net margin)
2. Financial stability (equity ratio, current ratio, D/E ratio)
3. Growth (revenue growth, profit growth YoY)
4. DuPont decomposition (margin × turnover × leverage)

Output your analysis in structured markdown with clear sections.
Be specific with numbers. Cite the filing period.
Language: Match the user's language (Japanese or English).
"""


class FundamentalAnalyst(BaseAgent):
    """Analyzes financial statements from EDINET filings."""

    name = "fundamental_analyst"
    display_name = "Fundamental Analyst"
    system_prompt = SYSTEM_PROMPT

    def _build_prompt(self, context: dict[str, Any]) -> str:
        statements = context.get("statements")
        code = context.get("code", "")

        if not statements:
            return (
                f"No EDINET data available for {code}. "
                "Provide a brief note that fundamental data is unavailable."
            )

        inc = json.dumps(statements.get("income_statement", []), ensure_ascii=False, indent=2)
        bs = json.dumps(statements.get("balance_sheet", []), ensure_ascii=False, indent=2)
        met = json.dumps(statements.get("metrics", {}), ensure_ascii=False, indent=2)
        return (
            f"Analyze the following financial statements for stock code {code}:\n\n"
            f"Company: {statements.get('company_name', 'Unknown')}\n"
            f"Standard: {statements.get('accounting_standard', 'Unknown')}\n"
            f"Filing Date: {statements.get('filing_date', 'Unknown')}\n\n"
            f"Income Statement:\n{inc}\n\n"
            f"Balance Sheet:\n{bs}\n\n"
            f"Metrics:\n{met}"
        )

    def _get_sources(self) -> list[str]:
        return ["edinet"]
