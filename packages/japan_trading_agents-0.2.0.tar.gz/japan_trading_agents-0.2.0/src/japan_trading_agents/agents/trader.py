"""Trader Agent — makes the final trading decision."""

from __future__ import annotations

from typing import Any

from japan_trading_agents.agents.base import BaseAgent
from japan_trading_agents.models import AgentReport, KeyFact, TradingDecision

SYSTEM_PROMPT = """\
You are a Professional Trader making evidence-based investment decisions for Japanese equities.

Your analysis must be grounded in the actual data provided — no speculation beyond what the data shows.

Based on analyst reports, the bull/bear debate, and current market data, output your decision.

You MUST output valid JSON with exactly these fields:
{
  "action": "BUY" | "SELL" | "HOLD",
  "confidence": 0.0-1.0,
  "position_size": "small" | "medium" | "large" | null,
  "reasoning": "1-2 sentence summary of the decision logic",
  "thesis": "2-4 sentence investment thesis. Write in Japanese if data is primarily Japanese. Be specific about WHY this stock is attractive NOW.",
  "watch_conditions": [
    "Condition 1 that would invalidate the thesis (be concrete, data-driven)",
    "Condition 2...",
    ...
  ],
  "key_facts": [
    {"fact": "具体的な数値やイベント", "source": "EDINET FY2024 / TDNET YYYY-MM-DD / BOJ IR01 / e-Stat / yfinance"},
    ...
  ],
  "target_price": float | null,
  "stop_loss": float | null
}

Guidelines:
- confidence: High confidence (>0.7) requires strong convergence across multiple data sources. Prefer HOLD when uncertain.
- thesis: Specific to THIS stock NOW. Not generic statements. Reference actual data points.
- watch_conditions: 3-5 items. Mention specific metrics, thresholds, or events. Avoid vague language.
- key_facts: Extract 3-6 concrete facts with their sources (e.g. "営業利益成長率 +96.4%", "自己株買い5,000億円"). Only cite facts actually present in the data.
- target_price: Set based on valuation reasoning if data supports it (e.g. target P/E × EPS). Set null if insufficient data.
- stop_loss: Set as a concrete price level (e.g. technical support or -10% from current). Set null if insufficient data.
"""


class TraderAgent(BaseAgent):
    """Makes the final BUY/SELL/HOLD decision."""

    name = "trader"
    display_name = "Trader"
    system_prompt = SYSTEM_PROMPT

    async def analyze(self, context: dict[str, Any]) -> AgentReport:
        """Override to also parse structured decision."""
        user_prompt = self._build_prompt(context)
        result = await self.llm.complete_json(self.system_prompt, user_prompt)

        # Parse key_facts
        raw_facts = result.get("key_facts", [])
        key_facts: list[KeyFact] = []
        for f in raw_facts:
            if isinstance(f, dict) and f.get("fact"):
                key_facts.append(KeyFact(fact=f["fact"], source=f.get("source", "")))

        decision = TradingDecision(
            action=result.get("action", "HOLD"),
            confidence=float(result.get("confidence", 0.5)),
            reasoning=result.get("reasoning", "No reasoning provided"),
            thesis=result.get("thesis", ""),
            watch_conditions=result.get("watch_conditions", []),
            key_facts=key_facts,
            target_price=result.get("target_price"),
            stop_loss=result.get("stop_loss"),
            position_size=result.get("position_size"),
        )

        return AgentReport(
            agent_name=self.name,
            display_name=self.display_name,
            content=decision.model_dump_json(indent=2),
            data_sources=[],
        )

    def _build_prompt(self, context: dict[str, Any]) -> str:
        code = context.get("code", "")
        reports = context.get("analyst_reports", [])
        debate = context.get("debate")
        current_price = context.get("current_price")

        parts = [f"Make a trading decision for stock code {code}.\n"]

        if current_price:
            parts.append(f"**Current market price: ¥{current_price:,.0f}**\n")

        if reports:
            parts.append("## Analyst Reports\n")
            for r in reports:
                if isinstance(r, AgentReport):
                    parts.append(f"### {r.display_name}\n{r.content[:600]}\n")

        if debate:
            parts.append(f"\n## Bull Case\n{debate.bull_case.content[:600]}\n")
            parts.append(f"\n## Bear Case\n{debate.bear_case.content[:600]}\n")

        return "\n".join(parts)
