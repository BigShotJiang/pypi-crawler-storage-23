"""Data adapters for Japan Finance Data Stack MCP tools."""
