# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""This module defines the core building blocks used by `RefreshableSession`
and method-specific session classes. The intent is to separate registry
mechanics, credential refresh contracts, and boto3 session behavior so each
concern is clear and testable.

`Registry` is a lightweight class-level registry. Subclasses register
themselves by key at import time, enabling factory-style lookup without
hard-coded class references. This is how `RefreshableSession` discovers method
implementations.

`refreshable_session` is a decorator that wraps `__init__` and guarantees a
`__post_init__` hook runs after `boto3.Session` initialization. This allows
`BRSSession` to create refreshable credentials only after the boto3 Session is
set up, avoiding circular and ordering issues. It also prevents double
wrapping on repeated decoration.

`CredentialProvider` is a small abstract class that defines the contract for
refreshable sessions: implement `_get_credentials` (returns temporary creds)
and `get_identity` (describes the caller identity). The concrete refresh
methods (STS, IoT, custom) only need to satisfy this interface.

`BRSSession` is the concrete wrapper over `boto3.Session`. It owns refreshable
credential construction, wiring the botocore session to those credentials, and
client and resource caching with normalized cache keys. It acts as the base
implementation for session mechanics.

Method-specific classes (STS, custom, IoT X.509) inherit directly from
`Registry`, `CredentialProvider`, and `BRSSession`, which keeps the hierarchy
shallow and the registration mechanics explicit.
"""

__all__ = [
    "BRSSession",
    "CredentialProvider",
    "Registry",
    "refreshable_session",
]

from abc import ABC, abstractmethod
from functools import wraps
from typing import Any, ClassVar, Generic, TypeVar

from boto3_client_cache import (
    Session,
)
from botocore.credentials import (
    DeferredRefreshableCredentials,
    RefreshableCredentials,
)

from ..exceptions import BRSWarning
from .extras import IOT_EXTRA_INSTALLED
from .typing import Identity, RefreshMethod, RegistryKey, TemporaryCredentials

# checks if 'iot' extra is installed or we're in a type-checking context
# defining this here instead of constants to avoid circular imports
if IOT_EXTRA_INSTALLED:
    from awscrt.http import HttpHeaders

    __all__ += ["AWSCRTResponse"]

    class AWSCRTResponse:
        """Lightweight response collector for awscrt HTTP."""

        def __init__(self) -> None:
            """Initialize to default for when callbacks are called."""

            self.status_code = None
            self.headers = None
            self.body = bytearray()

        def on_response(
            self, http_stream, status_code, headers, **kwargs
        ) -> None:
            """Process awscrt.io response."""

            self.status_code = status_code
            self.headers = HttpHeaders(headers)

        def on_body(self, http_stream, chunk, **kwargs) -> None:
            """Process awscrt.io body."""

            self.body.extend(chunk)


class CredentialProvider(ABC):
    """Defines the abstract surface every refreshable session must expose."""

    @abstractmethod
    def _get_credentials(self) -> TemporaryCredentials: ...

    @abstractmethod
    def get_identity(self) -> Identity: ...


T_Registry = TypeVar("T_Registry", bound="Registry[Any, Any]")


class Registry(Generic[RegistryKey, T_Registry]):
    """Lightweight class-level registry for mapping ``RefreshableSession``
    to refresh method implementations.

    Attributes
    ----------
    registry : ClassVar[dict[str, type[Any]]]
        The class-level registry mapping keys to classes.
    """

    registry: ClassVar[dict[str, type[Any]]] = {}

    def __init_subclass__(
        cls: type[T_Registry], *, registry_key: RegistryKey, **kwargs: Any
    ) -> None:
        super().__init_subclass__(**kwargs)

        if registry_key in cls.registry:
            BRSWarning.warn(
                f"{registry_key!r} already registered. Overwriting."
            )

        cls.registry[registry_key] = cls


# defining this here instead of utils to avoid circular imports lol
T_BRSSession = TypeVar("T_BRSSession", bound="BRSSession")

#: Type alias for a generic refreshable session type.
BRSSessionType = type[T_BRSSession]


def refreshable_session(
    cls: BRSSessionType,
) -> BRSSessionType:
    """Wraps cls.__init__ of subclasses so self.__post_init__ runs after init
    (if present).

    In plain English: this is essentially a post-initialization hook.

    Returns
    -------
    BRSSessionType
        The decorated class.
    """

    init = cls.__init__

    # avoiding double wrapping
    if getattr(init, "__post_init_wrapped__", False):
        return cls

    @wraps(init)
    def wrapper(self, *args, **kwargs) -> None:
        init(self, *args, **kwargs)
        post = getattr(self, "__post_init__", None)

        # calling __post_init__ if it exists
        if callable(post) and not getattr(self, "_post_inited", False):
            post()
            self._post_inited = True

    # flagging wrapper to avoid double wrapping
    wrapper.__post_init_wrapped__ = True  # type: ignore[attr-defined]

    # assigning the wrapper to __init__
    cls.__init__ = wrapper
    return cls


class BRSSession(Session):
    """Wrapper for boto3.session.Session.

    Parameters
    ----------
    refresh_method : RefreshMethod
        The method to use for refreshing temporary credentials.
    defer_refresh : bool = True, optional
        If ``True`` then temporary credentials are not automatically refreshed
        until they are explicitly needed. If ``False`` then temporary
        credentials refresh immediately upon expiration. It is highly
        recommended that you use ``True``. Default is ``True``.
    advisory_timeout : int = 900, optional
        USE THIS ARGUMENT WITH CAUTION!!!

        Botocore will attempt to refresh credentials early according to
        this value (in seconds), but will continue using the existing
        credentials if refresh fails. Default is 15 minutes (900 seconds).
    mandatory_timeout : int = 600, optional
        USE THIS ARGUMENT WITH CAUTION!!!

        Botocore requires a successful refresh before continuing. If
        refresh fails in this window (in seconds), API calls may fail.
        Default is 10 minutes (600 seconds).

    Attributes
    ----------
    cache : SessionCache
        The client and resource cache used to store and retrieve cached
        clients.
    credentials : TemporaryCredentials
        The current temporary AWS security credentials.

    Methods
    -------
    client(*args, eviction_policy: EvictionPolicy, max_size: int, **kwargs) -> BaseClient
        Creates a low-level service client by name.
    get_identity() -> Identity
        Returns metadata about the current caller identity.
    resource(*args, eviction_policy: EvictionPolicy, max_size: int, **kwargs) -> ServiceResource
        Creates a low-level service resource by name.
    refreshable_credentials() -> TemporaryCredentials
        Returns the current temporary AWS security credentials.
    whoami() -> Identity
        Alias for :meth:`get_identity`.

    Other Parameters
    ----------------
    **kwargs : Any, optional
        Optional keyword arguments for initializing boto3.session.Session.
    """  # noqa: E501

    def __init__(
        self,
        refresh_method: RefreshMethod,
        defer_refresh: bool | None = None,
        advisory_timeout: int | None = None,
        mandatory_timeout: int | None = None,
        **kwargs,
    ) -> None:
        # initializing parameters
        self.refresh_method: RefreshMethod = refresh_method
        self.defer_refresh: bool = defer_refresh is not False
        self.advisory_timeout: int | None = advisory_timeout
        self.mandatory_timeout: int | None = mandatory_timeout

        # initializing Session
        super().__init__(**kwargs)

    def __post_init__(self) -> None:
        if not self.defer_refresh:
            self._credentials = RefreshableCredentials.create_from_metadata(
                metadata=self._get_credentials(),  # type: ignore[arg-type]
                refresh_using=self._get_credentials,  # type: ignore[arg-type]
                method=self.refresh_method,
                advisory_timeout=self.advisory_timeout,
                mandatory_timeout=self.mandatory_timeout,
            )
        else:
            self._credentials = DeferredRefreshableCredentials(
                refresh_using=self._get_credentials,  # type: ignore[arg-type]
                method=self.refresh_method,  # type: ignore[arg-type]
            )

        # without this, boto3 won't use the refreshed credentials properly in
        # clients and resources, depending on how they were created
        self._session._credentials = self._credentials

    def refreshable_credentials(
        self,
    ) -> TemporaryCredentials:
        """Returns the current temporary AWS security credentials.

        Returns
        -------
        TemporaryCredentials
            Temporary AWS security credentials containing:
                access_key : str
                    AWS access key identifier.
                secret_key : str
                    AWS secret access key.
                token : str
                    AWS session token.
                expiry_time : str
                    Expiration timestamp in ISO 8601 format.
        """

        creds = (
            self._credentials
            if self._credentials is not None
            else self.get_credentials()
        )
        frozen_creds = creds.get_frozen_credentials()
        return {
            "access_key": frozen_creds.access_key,
            "secret_key": frozen_creds.secret_key,
            "token": frozen_creds.token,
            "expiry_time": creds._expiry_time.isoformat(),  # type: ignore[arg-type]
        }

    @property
    def credentials(self) -> TemporaryCredentials:
        """The current temporary AWS security credentials.

        Alias for :meth:`refreshable_credentials`."""

        return self.refreshable_credentials()

    def whoami(self) -> Identity:
        """Returns metadata about the current caller identity.

        .. versionadded:: 7.2.15

        .. note::

            This method is an alternative to ``get_identity()``.

        Returns
        -------
        Identity
            Dict containing current caller identity metadata.
        """

        return self.get_identity()  # type: ignore[arg-type]
