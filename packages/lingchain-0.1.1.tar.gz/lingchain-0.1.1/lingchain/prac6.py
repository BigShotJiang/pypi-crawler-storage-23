CASE2_CONTENT = '''Prac 6 Case Study
Aim:

Effective Text Prompts for Image Generation

Problem Statement

In many image-generation tasks, users provide very short and unclear prompts such as:

“A boy in a park”

Because of such incomplete prompts, the AI model does not clearly understand:

What exactly the user wants

What style is required

What mood or lighting should be used

What type of background is expected

As a result, the generated image may:

Look different from the user’s imagination

Have incorrect style or color tones

Miss important details

Main Problem

How can we write effective and clear text prompts so that an image-generation model produces accurate, high-quality, and meaningful images?

Methodology
(Using Effective Text Prompting for Image Generation)

In this case study, we follow a structured and systematic approach to design a strong and descriptive prompt.

Step 1 – Select a Simple Image Task

We choose a simple use-case.

Task:
Generate an image of a student studying.

Step 2 – Start with a Basic Prompt (Weak Prompt)

Initial weak prompt:

“A student studying”

This prompt is too short and lacks detail.
It does not specify:

Location

Environment

Style

Lighting

Mood

Camera angle

Step 3 – Identify Important Elements for an Effective Prompt

To improve the prompt, we identify the key elements that should be included:

Subject (Who or what is in the image)

Action (What is happening)

Background (Where it is happening)

Style (Realistic, cartoon, painting, etc.)

Lighting (Bright, soft, warm, natural, etc.)

Mood (Calm, energetic, dramatic, etc.)

Camera view (Front view, side angle, close-up, etc.)

Image quality (HD, 4K, high detail, etc.)

Step 4 – Write an Effective and Complete Prompt

Improved effective prompt:

A college student studying at a wooden desk with books and a laptop, inside a quiet study room, evening time, warm table lamp lighting, calm and focused mood, realistic photography style, side angle view, sharp focus, high detail, 4k quality.

This prompt clearly describes:

The subject

The environment

The lighting

The style

The mood

The quality

Step 5 – Prompt Structure Used

The structured format followed:

Subject + Action + Background + Style + Lighting + Mood + Camera View + Quality

This structure helps in designing well-organized and meaningful prompts.

Step 6 – Importance of Adding Style and Lighting

Adding style and lighting words is important because:

Style controls how the image looks (realistic, artistic, cinematic, etc.)

Lighting affects the mood and atmosphere

Mood creates emotional impact

Quality terms improve sharpness and clarity

Without these details, the generated image may look plain or random.

Step 7 – Observation in This Case Study

After using a structured and descriptive prompt:

The student appears clearly in the image

The study environment is properly defined

The lighting matches the calm mood

The overall image looks realistic and high quality

Compared to the weak prompt, the improved prompt generates significantly better results.

Conclusion

In this case study, it is clearly observed that effective text prompts play a crucial role in image generation.

By properly describing:

What is in the image

Where the scene takes place

How the image should look (style)

How the lighting and mood should be

What level of quality is required

The image-generation model produces more accurate, detailed, and visually pleasing results.

Hence, using well-structured and descriptive text prompts is the most effective way to control image generation and achieve better results in practical applications.'''

def main():
    print("=== CASE STUDY 2: Effective Text Prompts ===")
    print("=" * 70)
    print(CASE2_CONTENT)
    print("\n" + "="*70)
    print(" FULL CASE STUDY FOR NOTEBOOK")
    print("="*70)

if __name__ == "__main__":
    main()
