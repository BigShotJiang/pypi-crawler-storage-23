CASE3_CONTENT = '''Prac 7 Case Study

Aim: Approaches in Prompt Engineering
A) Chain-of-Thought Approach
Problem Statement

In many real-world and academic applications, AI systems directly provide the final answer without explaining how the answer was obtained.

Because of this, several problems arise:

The answer may be incorrect for complex problems

The reasoning behind the answer is not visible

It becomes difficult to trust the output

Logical and mathematical problems often fail

This issue is commonly observed in problems related to:

Arithmetic calculations

Word problems

Data interpretation

Logical decision-making

In such cases, the AI sometimes skips important reasoning steps and jumps directly to the final answer.

Main Problem

How can we guide the AI to solve a problem in a clear, logical, and step-by-step manner instead of giving only the final answer?

To solve this issue, we use the Chain-of-Thought prompting approach.

Methodology
(Using Chain-of-Thought Approach)

The Chain-of-Thought (CoT) approach modifies the prompt in such a way that the model is encouraged to explain its reasoning before giving the final answer.

Definition

Chain-of-Thought prompting is a technique in prompt engineering where the AI is instructed to show all intermediate reasoning steps before producing the final answer.

This improves clarity, transparency, and logical flow.

Case Scenario Used in This Study

A simple arithmetic problem is used to demonstrate the approach.

Problem Given to AI

A shop sells 3 notebooks for ₹90.
How much will 8 notebooks cost?

Step-by-Step Methodology
Step 1 – Clearly Define the Problem

The question must be written clearly and completely so that there is no ambiguity.

Example prompt:

A shop sells 3 notebooks for ₹90. How much will 8 notebooks cost?

Step 2 – Add a Reasoning Instruction

A reasoning instruction is added to guide the model.

Examples:

“Explain step by step.”

“Show your reasoning clearly.”

“Solve the problem step by step before giving the final answer.”

Modified prompt:

A shop sells 3 notebooks for ₹90. How much will 8 notebooks cost? Explain step by step.

Step 3 – Generation of Intermediate Steps

After receiving the modified prompt, the AI breaks the problem into logical parts.

Example Output

Cost of 3 notebooks = ₹90

Cost of 1 notebook = 90 ÷ 3 = ₹30

Cost of 8 notebooks = 30 × 8 = ₹240

Step 4 – Final Answer

After completing the reasoning chain, the model provides:

Final Answer: ₹240

Observation in This Case Study

By applying the Chain-of-Thought approach:

The reasoning becomes transparent

Each calculation step is clearly visible

Logical mistakes are reduced

The final answer becomes more accurate

The solution becomes easier to understand

Compared to direct-answer prompting, Chain-of-Thought produces more reliable results.

Conclusion

The Chain-of-Thought approach is a simple yet highly effective prompt-engineering technique.

It encourages the AI to think in a structured and step-by-step manner rather than directly giving the final output.

In this case study, it is clearly observed that:

The reasoning becomes transparent

Each step is easy to follow

The final answer becomes more accurate

The result becomes more trustworthy

Therefore, Chain-of-Thought prompting is highly suitable for:

Academic problems

Competitive exam preparation

Logical reasoning tasks

Business decision-making

Data analysis tasks

Hence, Chain-of-Thought prompting significantly improves clarity, accuracy, and understanding in problem-solving tasks and is an important approach in prompt engineering.


B ) Tree-of-Thought (ToT) Approach
Problem Statement
In many real problems, there is more than one possible way to solve a problem.
However, normal prompting and even simple step-by-step prompting usually follow only one
reasoning path.
Because of this, the following problems occur:
• The model may choose a wrong reasoning path
• It may miss a better solution
• It cannot compare different alternatives
• It performs poorly in problems like:
o planning tasks
o decision making
o puzzle solving
o strategy based problems
Main problem
How can we guide the AI to explore multiple possible solutions and then select the best one?
To solve this problem, we use the Tree-of-Thought approach.
Methodology
(Using Tree-of-Thought Approach)
Simple meaning of Tree-of-Thought
Tree-of-Thought means the AI generates many possible reasoning paths, evaluates them, and
finally chooses the best path.
It works like a tree:
• one problem
• many branches (possible thoughts)
• one best branch selected
Case scenario used in this study
Problem given to the AI
A student has 2 hours free.
He wants to study, revise notes and complete an assignment.
Which is the best way to plan his time?
This is a decision and planning problem.
Step-by-step methodology
Step 1 – Clearly define the problem
The problem is given clearly in the prompt.
Example:
A student has 2 hours free.
He wants to study, revise notes and complete an assignment.
Find the best possible plan.
Step 2 – Ask the model to generate multiple possible thoughts
We add an instruction such as:
• “Generate multiple possible plans.”
• “Explore different reasoning paths.”
Step 3 – Generate multiple branches of reasoning
The model now creates several possible solutions.
Step 4 – Evaluate each branch
The model checks each thought path based on:
• usefulness
• time balance
• task importance
Step 5 – Select the best thought path
After evaluation, the AI selects the best plan.

Conclusion
The Tree-of-Thought approach is a powerful prompt-engineering technique that allows the AI to
think in multiple directions instead of following only one reasoning path.
In this case study, it is observed that:
• the model generates several possible solutions,
• each solution is evaluated,
• and the best solution is selected.
This improves:
• accuracy,
• decision quality,
• and reliability of answers.
Hence, the Tree-of-Thought approach is very suitable for complex, planning and decision-based
problems where exploring multiple solutions is necessary before choosing the final answer.
!'''

def main():
    print("=== CASE STUDY 3: Chain of Thought & Tree of thought===")
    print("=" * 70)
    print(CASE3_CONTENT)
    print("\n" + "="*70)
    print("FULL CASE STUDY FOR NOTEBOOK")
    print("="*70)

if __name__ == "__main__":
    main()
