PRAC4_CODE = '''from langchain.chat_models import init_chat_model
from langchain_core.prompts import PromptTemplate
import os

os.environ["GOOGLE_API_KEY"] = ""

try:
    prompt_template = PromptTemplate(
        input_variables=["pet", "color"],
        template="Suggest one name for a {pet}. The {pet} is a {color} {pet}. Give only one name."
    )
    models = init_chat_model("google_genai:gemini-2.5-flash-lite")
    llm_topic = prompt_template.format(pet="dog", color="black")
    response = llm.invoke(llm_topic)
    print("User Input:", llm_topic)
    print("Response:", response.content)

except Exception as e:
    print("Error occurred:", e)'''

def main():
    print("=== PRAC 4: PROMPT TEMPLATE ===")
    print("=" * 70)
    print(PRAC4_CODE)
    print("\n" + "="*70)
    print("COPY TO NOTEBOOK | Dynamic prompt variables")
    print("="*70)

if __name__ == "__main__":
    main()
