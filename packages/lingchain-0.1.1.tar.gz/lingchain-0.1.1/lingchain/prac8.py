CASE4_CONTENT = '''Prac 8 Case Study

Aim: Interview Pattern Approach (in Prompt Engineering)
Problem Statement

In many real-life situations, users directly ask a question to the AI without providing enough background information.

For example:

“Suggest a good project topic.”

This question is unclear because the AI does not know:

The student’s branch or subject

The student’s skill level

The area of interest

The academic or university requirement

Due to missing information, the AI may:

Give a very general answer

Suggest an unsuitable project

Misunderstand the user’s actual need

Main Problem

How can we help the AI understand the user’s exact requirement before giving the final answer?

To solve this issue, we use the Interview Pattern Approach in prompt engineering.

Methodology
(Using the Interview Pattern Approach)
Meaning of Interview Pattern Approach

The Interview Pattern Approach is a prompt-engineering technique in which:

The AI behaves like an interviewer

It asks a series of small and clear questions

It collects required information first

Then it provides a final and personalized answer

Instead of giving an immediate response, the AI gathers necessary details before making a suggestion.

Case Scenario Used in This Study
Task:

Help a student select a final-year project topic.

Step-by-Step Methodology
Step 1 – Start with a General Request

The user gives a simple request:

“Suggest a final-year project topic.”

At this stage, the information is incomplete.

The AI cannot provide a personalized answer yet.

Step 2 – AI Starts Asking Interview-Style Questions

Instead of giving a direct answer, the AI begins asking focused and relevant questions such as:

What is your department or branch?

What is your programming level (Beginner / Intermediate / Advanced)?

Are you interested in AI, Web Development, Cybersecurity, or Data Science?

Is this an individual project or group project?

What programming languages do you know?

This is similar to how an interviewer gathers information before making a recommendation.

Step 3 – User Answers the Questions

Example user responses:

Department: Computer Engineering

Skill Level: Intermediate

Interest: Machine Learning

Project Type: Individual

Languages Known: Python

Now the AI has enough background information.

Step 4 – AI Analyzes the Collected Information

The AI processes the details provided by the user:

Technical background

Interest area

Skill level

Project constraints

This allows the AI to generate a more accurate and relevant suggestion.

Step 5 – AI Gives a Personalized and Accurate Answer
Final Response Example:

A suitable project for you is:

“Student Performance Prediction using Machine Learning”

This project matches:

The student’s branch

Interest in Machine Learning

Programming knowledge (Python)

Individual project requirement

This answer is more useful and meaningful than a general suggestion.

Observation in This Case Study

After applying the Interview Pattern Approach:

The AI collects necessary information

The response becomes personalized

The suggestion becomes more relevant

The misunderstanding is reduced

The overall quality of the answer improves

Compared to direct prompting, this method provides more accurate and user-specific results.

Conclusion

The Interview Pattern Approach is an effective prompt-engineering technique in which the AI first gathers important information by asking guiding questions, just like a human interviewer.

In this case study, it is clearly observed that:

The AI understands the user’s background

It collects required details before responding

The final output becomes more accurate and meaningful

Therefore, the Interview Pattern Approach is highly useful in applications such as:

Career guidance

Final-year project selection

Requirement analysis

Client consultation

Decision-support systems

Hence, this approach improves clarity, personalization, and decision quality in AI-based interactions.'''

def main():
    print("=== CASE STUDY 4: Interview Pattern ===")
    print("=" * 70)
    print(CASE4_CONTENT)
    print("\n" + "="*70)
    print("FULL CASE STUDY FOR NOTEBOOK")
    print("="*70)

if __name__ == "__main__":
    main()
