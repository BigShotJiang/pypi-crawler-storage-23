def hello():
    print("hi")