# Copilot instructions for epicsdev_tektronix

## Big picture architecture
- Core server lives in [epicsdev_tektronix/mso.py](epicsdev_tektronix/mso.py): defines PVs (`myPVDefs()`), maps PVs ↔ SCPI, and runs the EPICS PVAccess loop.
- Device I/O is via PyVISA (`pyvisa`/`pyvisa-py`). All SCPI traffic is serialized with `Threadlock` and routed through `scopeCmd()`.
- Data flow: PV write → setter (`set_scpi`, `set_trigger`, etc.) → SCPI command → scope → `publish()`; polling loop → `trigger_is_detected()` → `acquire_waveforms()` → waveform conversion → PV updates.
- Waveform conversion uses Tektronix preamble queries (`WFMOutpre:*`) and `CURVe?` binary block parsing; conversion formula is `v = (waveform - yoff) * ymult + yzero`.

## Key files and patterns
- PV definitions are built in `myPVDefs()` with channel templates (`c<n>...`); **do not** use `SPV` inside `ChannelTemplates` (they are expanded later).
- SCPI names are stored in `C_.scpi`; `make_readSettingQuery()` uppercases and strips lowercase chars before building a combined query.
- Timing and counters are published in `rareUpdate()` and `poll()`.
- GUI definitions are in [config/epicsScope_pp.py](config/epicsScope_pp.py); Tektronix wrapper is [config/epicsdev_tektronix_pp.py](config/epicsdev_tektronix_pp.py).
- Command mapping reference is in [docs/SCPI_COMMANDS.md](docs/SCPI_COMMANDS.md).

## Developer workflows (observed)
- Install: `pip install -e .` (dependencies in [requirements.txt](requirements.txt)).
- Run server (module entry point is in `mso.py`): `python -m epicsdev_tektronix.mso -r 'TCPIP::IP::INSTR' -v`.
- GUI: `python -m pypeto -c config -f epicsdev_tektronix` (optional deps).

## Project-specific conventions
- PV prefixes are `<device><index>:` (defaults from CLI args).
- Channel PVs use zero-padded numbers: `c01Waveform`, `c02OnOff`, etc.
- Many setters use `publish(..., IF_CHANGED)` to minimize traffic; follow that pattern when adding new PVs.
- Tektronix-specific SCPI commands should match the mappings documented in [docs/SCPI_COMMANDS.md](docs/SCPI_COMMANDS.md).

## Integration points & dependencies
- External deps: `epicsdev`, `p4p`, `pyvisa`, `pyvisa-py`, `numpy`.
- VISA resource string (`-r/--resource`) is required for hardware access; tests are not present in repo.
