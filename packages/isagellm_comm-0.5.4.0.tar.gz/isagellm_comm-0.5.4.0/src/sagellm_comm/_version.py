"""Version information for sagellm-comm."""

__version__ = "0.5.4.0"
