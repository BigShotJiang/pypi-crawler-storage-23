"""Stream/Event abstraction and multi-stream pipeline for compute-communication overlap.

This module provides:
- Task1.4 baseline: StreamHandle / EventHandle / CPUStreamHandle / CPUEventHandle
- Task1.8 extension: StreamPlacement / PipelineStage / MultiStreamPipeline / PipelineResult
"""

from __future__ import annotations

from sagellm_comm.overlap.cpu_stream import CPUEventHandle, CPUStreamHandle, create_cpu_stream
from sagellm_comm.overlap.pipeline import (
    MultiStreamPipeline,
    PipelineResult,
    PipelineStage,
    StageResult,
)
from sagellm_comm.overlap.placement import DeviceType, StreamPlacement
from sagellm_comm.overlap.stream import EventHandle, EventState, StreamHandle

__all__ = [
    # Task1.4 baseline
    "StreamHandle",
    "EventHandle",
    "EventState",
    "CPUStreamHandle",
    "CPUEventHandle",
    "create_cpu_stream",
    # Task1.8 multi-stream pipeline
    "DeviceType",
    "StreamPlacement",
    "PipelineStage",
    "StageResult",
    "PipelineResult",
    "MultiStreamPipeline",
]
