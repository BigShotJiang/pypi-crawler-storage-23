from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.commodity_weather_bulletins_download_body_type_1 import CommodityWeatherBulletinsDownloadBodyType1
from ...models.http_validation_error import HTTPValidationError
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str,
    provider: Literal["government_us"] | Unset = "government_us",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["provider"] = provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/commodity/weather_bulletins_download",
        "params": params,
    }

    if isinstance(body, CommodityWeatherBulletinsDownloadBodyType1):
        _kwargs["json"] = body.to_dict()
    elif isinstance(body, list):
        _kwargs["json"] = body

    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str,
    provider: Literal["government_us"] | Unset = "government_us",
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    """Weather Bulletins Download

     Download one, or more, weather bulletin documents.

    This command returns only the results portion of the OBBject response.
    It contains a list of dictionaries where the base64 encoded content of the document is under the
    'content' key.

    Args:
        provider (Literal['government_us'] | Unset):  Default: 'government_us'.
        body (CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str): URLs for reports to
            download. Multiple comma separated items allowed for provider(s): government_us.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        provider=provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str,
    provider: Literal["government_us"] | Unset = "government_us",
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    """Weather Bulletins Download

     Download one, or more, weather bulletin documents.

    This command returns only the results portion of the OBBject response.
    It contains a list of dictionaries where the base64 encoded content of the document is under the
    'content' key.

    Args:
        provider (Literal['government_us'] | Unset):  Default: 'government_us'.
        body (CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str): URLs for reports to
            download. Multiple comma separated items allowed for provider(s): government_us.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        provider=provider,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str,
    provider: Literal["government_us"] | Unset = "government_us",
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    """Weather Bulletins Download

     Download one, or more, weather bulletin documents.

    This command returns only the results portion of the OBBject response.
    It contains a list of dictionaries where the base64 encoded content of the document is under the
    'content' key.

    Args:
        provider (Literal['government_us'] | Unset):  Default: 'government_us'.
        body (CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str): URLs for reports to
            download. Multiple comma separated items allowed for provider(s): government_us.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        provider=provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str,
    provider: Literal["government_us"] | Unset = "government_us",
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    """Weather Bulletins Download

     Download one, or more, weather bulletin documents.

    This command returns only the results portion of the OBBject response.
    It contains a list of dictionaries where the base64 encoded content of the document is under the
    'content' key.

    Args:
        provider (Literal['government_us'] | Unset):  Default: 'government_us'.
        body (CommodityWeatherBulletinsDownloadBodyType1 | list[Any] | str): URLs for reports to
            download. Multiple comma separated items allowed for provider(s): government_us.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            provider=provider,
        )
    ).parsed
