import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_calendar_ipo_provider import EquityCalendarIpoProvider
from ...models.equity_calendar_ipo_status_type_0 import EquityCalendarIpoStatusType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_calendar_ipo import OBBjectCalendarIpo
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityCalendarIpoProvider,
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100,
    status: EquityCalendarIpoStatusType0 | None | Unset = UNSET,
    min_value: int | None | Unset = UNSET,
    max_value: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    elif isinstance(status, EquityCalendarIpoStatusType0):
        json_status = status.value
    else:
        json_status = status
    params["status"] = json_status

    json_min_value: int | None | Unset
    if isinstance(min_value, Unset):
        json_min_value = UNSET
    else:
        json_min_value = min_value
    params["min_value"] = json_min_value

    json_max_value: int | None | Unset
    if isinstance(max_value, Unset):
        json_max_value = UNSET
    else:
        json_max_value = max_value
    params["max_value"] = json_max_value

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/calendar/ipo",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCalendarIpo.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityCalendarIpoProvider,
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100,
    status: EquityCalendarIpoStatusType0 | None | Unset = UNSET,
    min_value: int | None | Unset = UNSET,
    max_value: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse]:
    """Ipo

     Get historical and upcoming initial public offerings (IPOs).

    Args:
        provider (EquityCalendarIpoProvider):
        symbol (None | str | Unset): Symbol to get data for.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100.
        status (EquityCalendarIpoStatusType0 | None | Unset): Status of the IPO. [upcoming,
            priced, or withdrawn] (provider: intrinio)
        min_value (int | None | Unset): Return IPOs with an offer dollar amount greater than the
            given amount. (provider: intrinio)
        max_value (int | None | Unset): Return IPOs with an offer dollar amount less than the
            given amount. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        status=status,
        min_value=min_value,
        max_value=max_value,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityCalendarIpoProvider,
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100,
    status: EquityCalendarIpoStatusType0 | None | Unset = UNSET,
    min_value: int | None | Unset = UNSET,
    max_value: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse | None:
    """Ipo

     Get historical and upcoming initial public offerings (IPOs).

    Args:
        provider (EquityCalendarIpoProvider):
        symbol (None | str | Unset): Symbol to get data for.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100.
        status (EquityCalendarIpoStatusType0 | None | Unset): Status of the IPO. [upcoming,
            priced, or withdrawn] (provider: intrinio)
        min_value (int | None | Unset): Return IPOs with an offer dollar amount greater than the
            given amount. (provider: intrinio)
        max_value (int | None | Unset): Return IPOs with an offer dollar amount less than the
            given amount. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        status=status,
        min_value=min_value,
        max_value=max_value,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityCalendarIpoProvider,
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100,
    status: EquityCalendarIpoStatusType0 | None | Unset = UNSET,
    min_value: int | None | Unset = UNSET,
    max_value: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse]:
    """Ipo

     Get historical and upcoming initial public offerings (IPOs).

    Args:
        provider (EquityCalendarIpoProvider):
        symbol (None | str | Unset): Symbol to get data for.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100.
        status (EquityCalendarIpoStatusType0 | None | Unset): Status of the IPO. [upcoming,
            priced, or withdrawn] (provider: intrinio)
        min_value (int | None | Unset): Return IPOs with an offer dollar amount greater than the
            given amount. (provider: intrinio)
        max_value (int | None | Unset): Return IPOs with an offer dollar amount less than the
            given amount. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        status=status,
        min_value=min_value,
        max_value=max_value,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityCalendarIpoProvider,
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 100,
    status: EquityCalendarIpoStatusType0 | None | Unset = UNSET,
    min_value: int | None | Unset = UNSET,
    max_value: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse | None:
    """Ipo

     Get historical and upcoming initial public offerings (IPOs).

    Args:
        provider (EquityCalendarIpoProvider):
        symbol (None | str | Unset): Symbol to get data for.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): The number of data entries to return. Default: 100.
        status (EquityCalendarIpoStatusType0 | None | Unset): Status of the IPO. [upcoming,
            priced, or withdrawn] (provider: intrinio)
        min_value (int | None | Unset): Return IPOs with an offer dollar amount greater than the
            given amount. (provider: intrinio)
        max_value (int | None | Unset): Return IPOs with an offer dollar amount less than the
            given amount. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCalendarIpo | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            status=status,
            min_value=min_value,
            max_value=max_value,
        )
    ).parsed
