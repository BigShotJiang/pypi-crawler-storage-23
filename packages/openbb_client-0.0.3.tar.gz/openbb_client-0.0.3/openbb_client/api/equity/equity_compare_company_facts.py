from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_compare_company_facts_fact_type_1 import EquityCompareCompanyFactsFactType1
from ...models.equity_compare_company_facts_fiscal_period_type_0 import EquityCompareCompanyFactsFiscalPeriodType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_compare_company_facts import OBBjectCompareCompanyFacts
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    symbol: None | str | Unset = UNSET,
    fact: EquityCompareCompanyFactsFactType1 | str | Unset = "",
    year: int | None | Unset = UNSET,
    fiscal_period: EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset = UNSET,
    instantaneous: bool | Unset = False,
    use_cache: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_fact: str | Unset
    if isinstance(fact, Unset):
        json_fact = UNSET
    elif isinstance(fact, EquityCompareCompanyFactsFactType1):
        json_fact = fact.value
    else:
        json_fact = fact
    params["fact"] = json_fact

    json_year: int | None | Unset
    if isinstance(year, Unset):
        json_year = UNSET
    else:
        json_year = year
    params["year"] = json_year

    json_fiscal_period: None | str | Unset
    if isinstance(fiscal_period, Unset):
        json_fiscal_period = UNSET
    elif isinstance(fiscal_period, EquityCompareCompanyFactsFiscalPeriodType0):
        json_fiscal_period = fiscal_period.value
    else:
        json_fiscal_period = fiscal_period
    params["fiscal_period"] = json_fiscal_period

    params["instantaneous"] = instantaneous

    params["use_cache"] = use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/compare/company_facts",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCompareCompanyFacts.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: None | str | Unset = UNSET,
    fact: EquityCompareCompanyFactsFactType1 | str | Unset = "",
    year: int | None | Unset = UNSET,
    fiscal_period: EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset = UNSET,
    instantaneous: bool | Unset = False,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse]:
    """Company Facts

     Compare reported company facts and fundamental data points.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): sec.
        fact (EquityCompareCompanyFactsFactType1 | str | Unset): The fact to lookup, typically a
            GAAP-reporting measure. Choices vary by provider.;
                Fact or concept from the SEC taxonomy, in UpperCamelCase. Defaults to, 'Revenues'.
            AAPL, MSFT, GOOG, BRK-A currently report revenue as,
            'RevenueFromContractWithCustomerExcludingAssessedTax'. In previous years, they have
            reported as 'Revenues'. (provider: sec) Default: ''.
        year (int | None | Unset): The year to retrieve the data for. If not provided, the current
            year is used. When symbol(s) are provided, excluding the year will return all reported
            values for the concept. (provider: sec)
        fiscal_period (EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset): The fiscal
            period to retrieve the data for. If not provided, the most recent quarter is used. This
            parameter is ignored when a symbol is supplied. (provider: sec)
        instantaneous (bool | Unset): Whether to retrieve instantaneous data. See the notes above
            for more information. Defaults to False. Some facts are only available as instantaneous
            data.
            The function will automatically attempt the inverse of this parameter if the initial
            fiscal quarter request fails. This parameter is ignored when a symbol is supplied.
            (provider: sec) Default: False.
        use_cache (bool | Unset): Whether to use cache for the request. Defaults to True.
            (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fact=fact,
        year=year,
        fiscal_period=fiscal_period,
        instantaneous=instantaneous,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: None | str | Unset = UNSET,
    fact: EquityCompareCompanyFactsFactType1 | str | Unset = "",
    year: int | None | Unset = UNSET,
    fiscal_period: EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset = UNSET,
    instantaneous: bool | Unset = False,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse | None:
    """Company Facts

     Compare reported company facts and fundamental data points.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): sec.
        fact (EquityCompareCompanyFactsFactType1 | str | Unset): The fact to lookup, typically a
            GAAP-reporting measure. Choices vary by provider.;
                Fact or concept from the SEC taxonomy, in UpperCamelCase. Defaults to, 'Revenues'.
            AAPL, MSFT, GOOG, BRK-A currently report revenue as,
            'RevenueFromContractWithCustomerExcludingAssessedTax'. In previous years, they have
            reported as 'Revenues'. (provider: sec) Default: ''.
        year (int | None | Unset): The year to retrieve the data for. If not provided, the current
            year is used. When symbol(s) are provided, excluding the year will return all reported
            values for the concept. (provider: sec)
        fiscal_period (EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset): The fiscal
            period to retrieve the data for. If not provided, the most recent quarter is used. This
            parameter is ignored when a symbol is supplied. (provider: sec)
        instantaneous (bool | Unset): Whether to retrieve instantaneous data. See the notes above
            for more information. Defaults to False. Some facts are only available as instantaneous
            data.
            The function will automatically attempt the inverse of this parameter if the initial
            fiscal quarter request fails. This parameter is ignored when a symbol is supplied.
            (provider: sec) Default: False.
        use_cache (bool | Unset): Whether to use cache for the request. Defaults to True.
            (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        fact=fact,
        year=year,
        fiscal_period=fiscal_period,
        instantaneous=instantaneous,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: None | str | Unset = UNSET,
    fact: EquityCompareCompanyFactsFactType1 | str | Unset = "",
    year: int | None | Unset = UNSET,
    fiscal_period: EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset = UNSET,
    instantaneous: bool | Unset = False,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse]:
    """Company Facts

     Compare reported company facts and fundamental data points.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): sec.
        fact (EquityCompareCompanyFactsFactType1 | str | Unset): The fact to lookup, typically a
            GAAP-reporting measure. Choices vary by provider.;
                Fact or concept from the SEC taxonomy, in UpperCamelCase. Defaults to, 'Revenues'.
            AAPL, MSFT, GOOG, BRK-A currently report revenue as,
            'RevenueFromContractWithCustomerExcludingAssessedTax'. In previous years, they have
            reported as 'Revenues'. (provider: sec) Default: ''.
        year (int | None | Unset): The year to retrieve the data for. If not provided, the current
            year is used. When symbol(s) are provided, excluding the year will return all reported
            values for the concept. (provider: sec)
        fiscal_period (EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset): The fiscal
            period to retrieve the data for. If not provided, the most recent quarter is used. This
            parameter is ignored when a symbol is supplied. (provider: sec)
        instantaneous (bool | Unset): Whether to retrieve instantaneous data. See the notes above
            for more information. Defaults to False. Some facts are only available as instantaneous
            data.
            The function will automatically attempt the inverse of this parameter if the initial
            fiscal quarter request fails. This parameter is ignored when a symbol is supplied.
            (provider: sec) Default: False.
        use_cache (bool | Unset): Whether to use cache for the request. Defaults to True.
            (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fact=fact,
        year=year,
        fiscal_period=fiscal_period,
        instantaneous=instantaneous,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: None | str | Unset = UNSET,
    fact: EquityCompareCompanyFactsFactType1 | str | Unset = "",
    year: int | None | Unset = UNSET,
    fiscal_period: EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset = UNSET,
    instantaneous: bool | Unset = False,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse | None:
    """Company Facts

     Compare reported company facts and fundamental data points.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): sec.
        fact (EquityCompareCompanyFactsFactType1 | str | Unset): The fact to lookup, typically a
            GAAP-reporting measure. Choices vary by provider.;
                Fact or concept from the SEC taxonomy, in UpperCamelCase. Defaults to, 'Revenues'.
            AAPL, MSFT, GOOG, BRK-A currently report revenue as,
            'RevenueFromContractWithCustomerExcludingAssessedTax'. In previous years, they have
            reported as 'Revenues'. (provider: sec) Default: ''.
        year (int | None | Unset): The year to retrieve the data for. If not provided, the current
            year is used. When symbol(s) are provided, excluding the year will return all reported
            values for the concept. (provider: sec)
        fiscal_period (EquityCompareCompanyFactsFiscalPeriodType0 | None | Unset): The fiscal
            period to retrieve the data for. If not provided, the most recent quarter is used. This
            parameter is ignored when a symbol is supplied. (provider: sec)
        instantaneous (bool | Unset): Whether to retrieve instantaneous data. See the notes above
            for more information. Defaults to False. Some facts are only available as instantaneous
            data.
            The function will automatically attempt the inverse of this parameter if the initial
            fiscal quarter request fails. This parameter is ignored when a symbol is supplied.
            (provider: sec) Default: False.
        use_cache (bool | Unset): Whether to use cache for the request. Defaults to True.
            (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCompareCompanyFacts | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            fact=fact,
            year=year,
            fiscal_period=fiscal_period,
            instantaneous=instantaneous,
            use_cache=use_cache,
        )
    ).parsed
