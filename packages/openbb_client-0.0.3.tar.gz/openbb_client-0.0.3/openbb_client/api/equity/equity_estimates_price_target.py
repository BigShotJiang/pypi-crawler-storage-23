import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_estimates_price_target_action_type_0 import EquityEstimatesPriceTargetActionType0
from ...models.equity_estimates_price_target_provider import EquityEstimatesPriceTargetProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_price_target import OBBjectPriceTarget
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityEstimatesPriceTargetProvider,
    symbol: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    page: int | None | Unset = 0,
    date: datetime.date | None | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    updated: datetime.date | int | None | Unset = UNSET,
    importance: int | None | Unset = UNSET,
    action: EquityEstimatesPriceTargetActionType0 | None | Unset = UNSET,
    analyst_ids: list[str] | None | str | Unset = UNSET,
    firm_ids: list[str] | None | str | Unset = UNSET,
    fields: list[str] | None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_page: int | None | Unset
    if isinstance(page, Unset):
        json_page = UNSET
    else:
        json_page = page
    params["page"] = json_page

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_updated: int | None | str | Unset
    if isinstance(updated, Unset):
        json_updated = UNSET
    elif isinstance(updated, datetime.date):
        json_updated = updated.isoformat()
    else:
        json_updated = updated
    params["updated"] = json_updated

    json_importance: int | None | Unset
    if isinstance(importance, Unset):
        json_importance = UNSET
    else:
        json_importance = importance
    params["importance"] = json_importance

    json_action: None | str | Unset
    if isinstance(action, Unset):
        json_action = UNSET
    elif isinstance(action, EquityEstimatesPriceTargetActionType0):
        json_action = action.value
    else:
        json_action = action
    params["action"] = json_action

    json_analyst_ids: list[str] | None | str | Unset
    if isinstance(analyst_ids, Unset):
        json_analyst_ids = UNSET
    elif isinstance(analyst_ids, list):
        json_analyst_ids = analyst_ids

    else:
        json_analyst_ids = analyst_ids
    params["analyst_ids"] = json_analyst_ids

    json_firm_ids: list[str] | None | str | Unset
    if isinstance(firm_ids, Unset):
        json_firm_ids = UNSET
    elif isinstance(firm_ids, list):
        json_firm_ids = firm_ids

    else:
        json_firm_ids = firm_ids
    params["firm_ids"] = json_firm_ids

    json_fields: list[str] | None | str | Unset
    if isinstance(fields, Unset):
        json_fields = UNSET
    elif isinstance(fields, list):
        json_fields = fields

    else:
        json_fields = fields
    params["fields"] = json_fields

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/estimates/price_target",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectPriceTarget.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesPriceTargetProvider,
    symbol: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    page: int | None | Unset = 0,
    date: datetime.date | None | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    updated: datetime.date | int | None | Unset = UNSET,
    importance: int | None | Unset = UNSET,
    action: EquityEstimatesPriceTargetActionType0 | None | Unset = UNSET,
    analyst_ids: list[str] | None | str | Unset = UNSET,
    firm_ids: list[str] | None | str | Unset = UNSET,
    fields: list[str] | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse]:
    """Price Target

     Get analyst price targets by company.

    Args:
        provider (EquityEstimatesPriceTargetProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): benzinga, fmp.
        limit (int | None | Unset): The number of data entries to return.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. Used in conjunction with the limit and date parameters.
            (provider: benzinga) Default: 0.
        date (datetime.date | None | Unset): Date for calendar data, shorthand for date_from and
            date_to. (provider: benzinga)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        updated (datetime.date | int | None | Unset): Records last Updated Unix timestamp (UTC).
            This will force the sort order to be Greater Than or Equal to the timestamp indicated. The
            date can be a date string or a Unix timestamp. The date string must be in the format of
            YYYY-MM-DD. (provider: benzinga)
        importance (int | None | Unset): Importance level to filter by. Uses Greater Than or Equal
            To the importance indicated (provider: benzinga)
        action (EquityEstimatesPriceTargetActionType0 | None | Unset): Filter by a specific
            action_company. (provider: benzinga)
        analyst_ids (list[str] | None | str | Unset): Comma-separated list of analyst (person)
            IDs. Omitting will bring back all available analysts. Multiple comma separated items
            allowed. (provider: benzinga)
        firm_ids (list[str] | None | str | Unset): Comma-separated list of firm IDs. Multiple
            comma separated items allowed. (provider: benzinga)
        fields (list[str] | None | str | Unset): Comma-separated list of fields to include in the
            response. See https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about
            the available fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        page=page,
        date=date,
        start_date=start_date,
        end_date=end_date,
        updated=updated,
        importance=importance,
        action=action,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        fields=fields,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesPriceTargetProvider,
    symbol: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    page: int | None | Unset = 0,
    date: datetime.date | None | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    updated: datetime.date | int | None | Unset = UNSET,
    importance: int | None | Unset = UNSET,
    action: EquityEstimatesPriceTargetActionType0 | None | Unset = UNSET,
    analyst_ids: list[str] | None | str | Unset = UNSET,
    firm_ids: list[str] | None | str | Unset = UNSET,
    fields: list[str] | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse | None:
    """Price Target

     Get analyst price targets by company.

    Args:
        provider (EquityEstimatesPriceTargetProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): benzinga, fmp.
        limit (int | None | Unset): The number of data entries to return.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. Used in conjunction with the limit and date parameters.
            (provider: benzinga) Default: 0.
        date (datetime.date | None | Unset): Date for calendar data, shorthand for date_from and
            date_to. (provider: benzinga)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        updated (datetime.date | int | None | Unset): Records last Updated Unix timestamp (UTC).
            This will force the sort order to be Greater Than or Equal to the timestamp indicated. The
            date can be a date string or a Unix timestamp. The date string must be in the format of
            YYYY-MM-DD. (provider: benzinga)
        importance (int | None | Unset): Importance level to filter by. Uses Greater Than or Equal
            To the importance indicated (provider: benzinga)
        action (EquityEstimatesPriceTargetActionType0 | None | Unset): Filter by a specific
            action_company. (provider: benzinga)
        analyst_ids (list[str] | None | str | Unset): Comma-separated list of analyst (person)
            IDs. Omitting will bring back all available analysts. Multiple comma separated items
            allowed. (provider: benzinga)
        firm_ids (list[str] | None | str | Unset): Comma-separated list of firm IDs. Multiple
            comma separated items allowed. (provider: benzinga)
        fields (list[str] | None | str | Unset): Comma-separated list of fields to include in the
            response. See https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about
            the available fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        limit=limit,
        page=page,
        date=date,
        start_date=start_date,
        end_date=end_date,
        updated=updated,
        importance=importance,
        action=action,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        fields=fields,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesPriceTargetProvider,
    symbol: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    page: int | None | Unset = 0,
    date: datetime.date | None | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    updated: datetime.date | int | None | Unset = UNSET,
    importance: int | None | Unset = UNSET,
    action: EquityEstimatesPriceTargetActionType0 | None | Unset = UNSET,
    analyst_ids: list[str] | None | str | Unset = UNSET,
    firm_ids: list[str] | None | str | Unset = UNSET,
    fields: list[str] | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse]:
    """Price Target

     Get analyst price targets by company.

    Args:
        provider (EquityEstimatesPriceTargetProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): benzinga, fmp.
        limit (int | None | Unset): The number of data entries to return.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. Used in conjunction with the limit and date parameters.
            (provider: benzinga) Default: 0.
        date (datetime.date | None | Unset): Date for calendar data, shorthand for date_from and
            date_to. (provider: benzinga)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        updated (datetime.date | int | None | Unset): Records last Updated Unix timestamp (UTC).
            This will force the sort order to be Greater Than or Equal to the timestamp indicated. The
            date can be a date string or a Unix timestamp. The date string must be in the format of
            YYYY-MM-DD. (provider: benzinga)
        importance (int | None | Unset): Importance level to filter by. Uses Greater Than or Equal
            To the importance indicated (provider: benzinga)
        action (EquityEstimatesPriceTargetActionType0 | None | Unset): Filter by a specific
            action_company. (provider: benzinga)
        analyst_ids (list[str] | None | str | Unset): Comma-separated list of analyst (person)
            IDs. Omitting will bring back all available analysts. Multiple comma separated items
            allowed. (provider: benzinga)
        firm_ids (list[str] | None | str | Unset): Comma-separated list of firm IDs. Multiple
            comma separated items allowed. (provider: benzinga)
        fields (list[str] | None | str | Unset): Comma-separated list of fields to include in the
            response. See https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about
            the available fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        page=page,
        date=date,
        start_date=start_date,
        end_date=end_date,
        updated=updated,
        importance=importance,
        action=action,
        analyst_ids=analyst_ids,
        firm_ids=firm_ids,
        fields=fields,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesPriceTargetProvider,
    symbol: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    page: int | None | Unset = 0,
    date: datetime.date | None | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    updated: datetime.date | int | None | Unset = UNSET,
    importance: int | None | Unset = UNSET,
    action: EquityEstimatesPriceTargetActionType0 | None | Unset = UNSET,
    analyst_ids: list[str] | None | str | Unset = UNSET,
    firm_ids: list[str] | None | str | Unset = UNSET,
    fields: list[str] | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse | None:
    """Price Target

     Get analyst price targets by company.

    Args:
        provider (EquityEstimatesPriceTargetProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): benzinga, fmp.
        limit (int | None | Unset): The number of data entries to return.
        page (int | None | Unset): Page offset. For optimization, performance and technical
            reasons, page offsets are limited from 0 - 100000. Limit the query results by other
            parameters such as date. Used in conjunction with the limit and date parameters.
            (provider: benzinga) Default: 0.
        date (datetime.date | None | Unset): Date for calendar data, shorthand for date_from and
            date_to. (provider: benzinga)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: benzinga)
        updated (datetime.date | int | None | Unset): Records last Updated Unix timestamp (UTC).
            This will force the sort order to be Greater Than or Equal to the timestamp indicated. The
            date can be a date string or a Unix timestamp. The date string must be in the format of
            YYYY-MM-DD. (provider: benzinga)
        importance (int | None | Unset): Importance level to filter by. Uses Greater Than or Equal
            To the importance indicated (provider: benzinga)
        action (EquityEstimatesPriceTargetActionType0 | None | Unset): Filter by a specific
            action_company. (provider: benzinga)
        analyst_ids (list[str] | None | str | Unset): Comma-separated list of analyst (person)
            IDs. Omitting will bring back all available analysts. Multiple comma separated items
            allowed. (provider: benzinga)
        firm_ids (list[str] | None | str | Unset): Comma-separated list of firm IDs. Multiple
            comma separated items allowed. (provider: benzinga)
        fields (list[str] | None | str | Unset): Comma-separated list of fields to include in the
            response. See https://docs.benzinga.io/benzinga-apis/calendar/get-ratings to learn about
            the available fields. Multiple comma separated items allowed. (provider: benzinga)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPriceTarget | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            limit=limit,
            page=page,
            date=date,
            start_date=start_date,
            end_date=end_date,
            updated=updated,
            importance=importance,
            action=action,
            analyst_ids=analyst_ids,
            firm_ids=firm_ids,
            fields=fields,
        )
    ).parsed
