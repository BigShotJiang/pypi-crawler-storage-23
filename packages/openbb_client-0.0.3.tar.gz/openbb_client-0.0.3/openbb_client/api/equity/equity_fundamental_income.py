import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_income_order_type_0 import EquityFundamentalIncomeOrderType0
from ...models.equity_fundamental_income_period_type_0 import EquityFundamentalIncomePeriodType0
from ...models.equity_fundamental_income_period_type_1 import EquityFundamentalIncomePeriodType1
from ...models.equity_fundamental_income_period_type_2 import EquityFundamentalIncomePeriodType2
from ...models.equity_fundamental_income_period_type_3 import EquityFundamentalIncomePeriodType3
from ...models.equity_fundamental_income_provider import EquityFundamentalIncomeProvider
from ...models.equity_fundamental_income_sort_type_0 import EquityFundamentalIncomeSortType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_income_statement import OBBjectIncomeStatement
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityFundamentalIncomeProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    period: EquityFundamentalIncomePeriodType0
    | EquityFundamentalIncomePeriodType1
    | EquityFundamentalIncomePeriodType2
    | EquityFundamentalIncomePeriodType3
    | Unset = EquityFundamentalIncomePeriodType0.ANNUAL,
    use_cache: bool | Unset = True,
    fiscal_year: int | None | Unset = UNSET,
    filing_date: datetime.date | None | Unset = UNSET,
    filing_date_lt: datetime.date | None | Unset = UNSET,
    filing_date_lte: datetime.date | None | Unset = UNSET,
    filing_date_gt: datetime.date | None | Unset = UNSET,
    filing_date_gte: datetime.date | None | Unset = UNSET,
    period_of_report_date: datetime.date | None | Unset = UNSET,
    period_of_report_date_lt: datetime.date | None | Unset = UNSET,
    period_of_report_date_lte: datetime.date | None | Unset = UNSET,
    period_of_report_date_gt: datetime.date | None | Unset = UNSET,
    period_of_report_date_gte: datetime.date | None | Unset = UNSET,
    include_sources: bool | None | Unset = UNSET,
    order: EquityFundamentalIncomeOrderType0 | None | Unset = UNSET,
    sort: EquityFundamentalIncomeSortType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_period: str | Unset
    if isinstance(period, Unset):
        json_period = UNSET
    elif isinstance(period, EquityFundamentalIncomePeriodType0):
        json_period = period.value
    elif isinstance(period, EquityFundamentalIncomePeriodType1):
        json_period = period.value
    elif isinstance(period, EquityFundamentalIncomePeriodType2):
        json_period = period.value
    else:
        json_period = period.value

    params["period"] = json_period

    params["use_cache"] = use_cache

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    json_filing_date: None | str | Unset
    if isinstance(filing_date, Unset):
        json_filing_date = UNSET
    elif isinstance(filing_date, datetime.date):
        json_filing_date = filing_date.isoformat()
    else:
        json_filing_date = filing_date
    params["filing_date"] = json_filing_date

    json_filing_date_lt: None | str | Unset
    if isinstance(filing_date_lt, Unset):
        json_filing_date_lt = UNSET
    elif isinstance(filing_date_lt, datetime.date):
        json_filing_date_lt = filing_date_lt.isoformat()
    else:
        json_filing_date_lt = filing_date_lt
    params["filing_date_lt"] = json_filing_date_lt

    json_filing_date_lte: None | str | Unset
    if isinstance(filing_date_lte, Unset):
        json_filing_date_lte = UNSET
    elif isinstance(filing_date_lte, datetime.date):
        json_filing_date_lte = filing_date_lte.isoformat()
    else:
        json_filing_date_lte = filing_date_lte
    params["filing_date_lte"] = json_filing_date_lte

    json_filing_date_gt: None | str | Unset
    if isinstance(filing_date_gt, Unset):
        json_filing_date_gt = UNSET
    elif isinstance(filing_date_gt, datetime.date):
        json_filing_date_gt = filing_date_gt.isoformat()
    else:
        json_filing_date_gt = filing_date_gt
    params["filing_date_gt"] = json_filing_date_gt

    json_filing_date_gte: None | str | Unset
    if isinstance(filing_date_gte, Unset):
        json_filing_date_gte = UNSET
    elif isinstance(filing_date_gte, datetime.date):
        json_filing_date_gte = filing_date_gte.isoformat()
    else:
        json_filing_date_gte = filing_date_gte
    params["filing_date_gte"] = json_filing_date_gte

    json_period_of_report_date: None | str | Unset
    if isinstance(period_of_report_date, Unset):
        json_period_of_report_date = UNSET
    elif isinstance(period_of_report_date, datetime.date):
        json_period_of_report_date = period_of_report_date.isoformat()
    else:
        json_period_of_report_date = period_of_report_date
    params["period_of_report_date"] = json_period_of_report_date

    json_period_of_report_date_lt: None | str | Unset
    if isinstance(period_of_report_date_lt, Unset):
        json_period_of_report_date_lt = UNSET
    elif isinstance(period_of_report_date_lt, datetime.date):
        json_period_of_report_date_lt = period_of_report_date_lt.isoformat()
    else:
        json_period_of_report_date_lt = period_of_report_date_lt
    params["period_of_report_date_lt"] = json_period_of_report_date_lt

    json_period_of_report_date_lte: None | str | Unset
    if isinstance(period_of_report_date_lte, Unset):
        json_period_of_report_date_lte = UNSET
    elif isinstance(period_of_report_date_lte, datetime.date):
        json_period_of_report_date_lte = period_of_report_date_lte.isoformat()
    else:
        json_period_of_report_date_lte = period_of_report_date_lte
    params["period_of_report_date_lte"] = json_period_of_report_date_lte

    json_period_of_report_date_gt: None | str | Unset
    if isinstance(period_of_report_date_gt, Unset):
        json_period_of_report_date_gt = UNSET
    elif isinstance(period_of_report_date_gt, datetime.date):
        json_period_of_report_date_gt = period_of_report_date_gt.isoformat()
    else:
        json_period_of_report_date_gt = period_of_report_date_gt
    params["period_of_report_date_gt"] = json_period_of_report_date_gt

    json_period_of_report_date_gte: None | str | Unset
    if isinstance(period_of_report_date_gte, Unset):
        json_period_of_report_date_gte = UNSET
    elif isinstance(period_of_report_date_gte, datetime.date):
        json_period_of_report_date_gte = period_of_report_date_gte.isoformat()
    else:
        json_period_of_report_date_gte = period_of_report_date_gte
    params["period_of_report_date_gte"] = json_period_of_report_date_gte

    json_include_sources: bool | None | Unset
    if isinstance(include_sources, Unset):
        json_include_sources = UNSET
    else:
        json_include_sources = include_sources
    params["include_sources"] = json_include_sources

    json_order: None | str | Unset
    if isinstance(order, Unset):
        json_order = UNSET
    elif isinstance(order, EquityFundamentalIncomeOrderType0):
        json_order = order.value
    else:
        json_order = order
    params["order"] = json_order

    json_sort: None | str | Unset
    if isinstance(sort, Unset):
        json_sort = UNSET
    elif isinstance(sort, EquityFundamentalIncomeSortType0):
        json_sort = sort.value
    else:
        json_sort = sort
    params["sort"] = json_sort

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/income",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectIncomeStatement.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalIncomeProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    period: EquityFundamentalIncomePeriodType0
    | EquityFundamentalIncomePeriodType1
    | EquityFundamentalIncomePeriodType2
    | EquityFundamentalIncomePeriodType3
    | Unset = EquityFundamentalIncomePeriodType0.ANNUAL,
    use_cache: bool | Unset = True,
    fiscal_year: int | None | Unset = UNSET,
    filing_date: datetime.date | None | Unset = UNSET,
    filing_date_lt: datetime.date | None | Unset = UNSET,
    filing_date_lte: datetime.date | None | Unset = UNSET,
    filing_date_gt: datetime.date | None | Unset = UNSET,
    filing_date_gte: datetime.date | None | Unset = UNSET,
    period_of_report_date: datetime.date | None | Unset = UNSET,
    period_of_report_date_lt: datetime.date | None | Unset = UNSET,
    period_of_report_date_lte: datetime.date | None | Unset = UNSET,
    period_of_report_date_gt: datetime.date | None | Unset = UNSET,
    period_of_report_date_gte: datetime.date | None | Unset = UNSET,
    include_sources: bool | None | Unset = UNSET,
    order: EquityFundamentalIncomeOrderType0 | None | Unset = UNSET,
    sort: EquityFundamentalIncomeSortType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse]:
    """Income

     Get the income statement for a given company.

    Args:
        provider (EquityFundamentalIncomeProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        period (EquityFundamentalIncomePeriodType0 | EquityFundamentalIncomePeriodType1 |
            EquityFundamentalIncomePeriodType2 | EquityFundamentalIncomePeriodType3 | Unset): Time
            period of the data to return. (provider: akshare,fmp,intrinio,polygon, yfinance) Default:
            EquityFundamentalIncomePeriodType0.ANNUAL.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)
        filing_date (datetime.date | None | Unset): Filing date of the financial statement.
            (provider: polygon)
        filing_date_lt (datetime.date | None | Unset): Filing date less than the given date.
            (provider: polygon)
        filing_date_lte (datetime.date | None | Unset): Filing date less than or equal to the
            given date. (provider: polygon)
        filing_date_gt (datetime.date | None | Unset): Filing date greater than the given date.
            (provider: polygon)
        filing_date_gte (datetime.date | None | Unset): Filing date greater than or equal to the
            given date. (provider: polygon)
        period_of_report_date (datetime.date | None | Unset): Period of report date of the
            financial statement. (provider: polygon)
        period_of_report_date_lt (datetime.date | None | Unset): Period of report date less than
            the given date. (provider: polygon)
        period_of_report_date_lte (datetime.date | None | Unset): Period of report date less than
            or equal to the given date. (provider: polygon)
        period_of_report_date_gt (datetime.date | None | Unset): Period of report date greater
            than the given date. (provider: polygon)
        period_of_report_date_gte (datetime.date | None | Unset): Period of report date greater
            than or equal to the given date. (provider: polygon)
        include_sources (bool | None | Unset): Whether to include the sources of the financial
            statement. (provider: polygon)
        order (EquityFundamentalIncomeOrderType0 | None | Unset): Order of the financial
            statement. (provider: polygon)
        sort (EquityFundamentalIncomeSortType0 | None | Unset): Sort of the financial statement.
            (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        period=period,
        use_cache=use_cache,
        fiscal_year=fiscal_year,
        filing_date=filing_date,
        filing_date_lt=filing_date_lt,
        filing_date_lte=filing_date_lte,
        filing_date_gt=filing_date_gt,
        filing_date_gte=filing_date_gte,
        period_of_report_date=period_of_report_date,
        period_of_report_date_lt=period_of_report_date_lt,
        period_of_report_date_lte=period_of_report_date_lte,
        period_of_report_date_gt=period_of_report_date_gt,
        period_of_report_date_gte=period_of_report_date_gte,
        include_sources=include_sources,
        order=order,
        sort=sort,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalIncomeProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    period: EquityFundamentalIncomePeriodType0
    | EquityFundamentalIncomePeriodType1
    | EquityFundamentalIncomePeriodType2
    | EquityFundamentalIncomePeriodType3
    | Unset = EquityFundamentalIncomePeriodType0.ANNUAL,
    use_cache: bool | Unset = True,
    fiscal_year: int | None | Unset = UNSET,
    filing_date: datetime.date | None | Unset = UNSET,
    filing_date_lt: datetime.date | None | Unset = UNSET,
    filing_date_lte: datetime.date | None | Unset = UNSET,
    filing_date_gt: datetime.date | None | Unset = UNSET,
    filing_date_gte: datetime.date | None | Unset = UNSET,
    period_of_report_date: datetime.date | None | Unset = UNSET,
    period_of_report_date_lt: datetime.date | None | Unset = UNSET,
    period_of_report_date_lte: datetime.date | None | Unset = UNSET,
    period_of_report_date_gt: datetime.date | None | Unset = UNSET,
    period_of_report_date_gte: datetime.date | None | Unset = UNSET,
    include_sources: bool | None | Unset = UNSET,
    order: EquityFundamentalIncomeOrderType0 | None | Unset = UNSET,
    sort: EquityFundamentalIncomeSortType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse | None:
    """Income

     Get the income statement for a given company.

    Args:
        provider (EquityFundamentalIncomeProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        period (EquityFundamentalIncomePeriodType0 | EquityFundamentalIncomePeriodType1 |
            EquityFundamentalIncomePeriodType2 | EquityFundamentalIncomePeriodType3 | Unset): Time
            period of the data to return. (provider: akshare,fmp,intrinio,polygon, yfinance) Default:
            EquityFundamentalIncomePeriodType0.ANNUAL.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)
        filing_date (datetime.date | None | Unset): Filing date of the financial statement.
            (provider: polygon)
        filing_date_lt (datetime.date | None | Unset): Filing date less than the given date.
            (provider: polygon)
        filing_date_lte (datetime.date | None | Unset): Filing date less than or equal to the
            given date. (provider: polygon)
        filing_date_gt (datetime.date | None | Unset): Filing date greater than the given date.
            (provider: polygon)
        filing_date_gte (datetime.date | None | Unset): Filing date greater than or equal to the
            given date. (provider: polygon)
        period_of_report_date (datetime.date | None | Unset): Period of report date of the
            financial statement. (provider: polygon)
        period_of_report_date_lt (datetime.date | None | Unset): Period of report date less than
            the given date. (provider: polygon)
        period_of_report_date_lte (datetime.date | None | Unset): Period of report date less than
            or equal to the given date. (provider: polygon)
        period_of_report_date_gt (datetime.date | None | Unset): Period of report date greater
            than the given date. (provider: polygon)
        period_of_report_date_gte (datetime.date | None | Unset): Period of report date greater
            than or equal to the given date. (provider: polygon)
        include_sources (bool | None | Unset): Whether to include the sources of the financial
            statement. (provider: polygon)
        order (EquityFundamentalIncomeOrderType0 | None | Unset): Order of the financial
            statement. (provider: polygon)
        sort (EquityFundamentalIncomeSortType0 | None | Unset): Sort of the financial statement.
            (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        limit=limit,
        period=period,
        use_cache=use_cache,
        fiscal_year=fiscal_year,
        filing_date=filing_date,
        filing_date_lt=filing_date_lt,
        filing_date_lte=filing_date_lte,
        filing_date_gt=filing_date_gt,
        filing_date_gte=filing_date_gte,
        period_of_report_date=period_of_report_date,
        period_of_report_date_lt=period_of_report_date_lt,
        period_of_report_date_lte=period_of_report_date_lte,
        period_of_report_date_gt=period_of_report_date_gt,
        period_of_report_date_gte=period_of_report_date_gte,
        include_sources=include_sources,
        order=order,
        sort=sort,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalIncomeProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    period: EquityFundamentalIncomePeriodType0
    | EquityFundamentalIncomePeriodType1
    | EquityFundamentalIncomePeriodType2
    | EquityFundamentalIncomePeriodType3
    | Unset = EquityFundamentalIncomePeriodType0.ANNUAL,
    use_cache: bool | Unset = True,
    fiscal_year: int | None | Unset = UNSET,
    filing_date: datetime.date | None | Unset = UNSET,
    filing_date_lt: datetime.date | None | Unset = UNSET,
    filing_date_lte: datetime.date | None | Unset = UNSET,
    filing_date_gt: datetime.date | None | Unset = UNSET,
    filing_date_gte: datetime.date | None | Unset = UNSET,
    period_of_report_date: datetime.date | None | Unset = UNSET,
    period_of_report_date_lt: datetime.date | None | Unset = UNSET,
    period_of_report_date_lte: datetime.date | None | Unset = UNSET,
    period_of_report_date_gt: datetime.date | None | Unset = UNSET,
    period_of_report_date_gte: datetime.date | None | Unset = UNSET,
    include_sources: bool | None | Unset = UNSET,
    order: EquityFundamentalIncomeOrderType0 | None | Unset = UNSET,
    sort: EquityFundamentalIncomeSortType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse]:
    """Income

     Get the income statement for a given company.

    Args:
        provider (EquityFundamentalIncomeProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        period (EquityFundamentalIncomePeriodType0 | EquityFundamentalIncomePeriodType1 |
            EquityFundamentalIncomePeriodType2 | EquityFundamentalIncomePeriodType3 | Unset): Time
            period of the data to return. (provider: akshare,fmp,intrinio,polygon, yfinance) Default:
            EquityFundamentalIncomePeriodType0.ANNUAL.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)
        filing_date (datetime.date | None | Unset): Filing date of the financial statement.
            (provider: polygon)
        filing_date_lt (datetime.date | None | Unset): Filing date less than the given date.
            (provider: polygon)
        filing_date_lte (datetime.date | None | Unset): Filing date less than or equal to the
            given date. (provider: polygon)
        filing_date_gt (datetime.date | None | Unset): Filing date greater than the given date.
            (provider: polygon)
        filing_date_gte (datetime.date | None | Unset): Filing date greater than or equal to the
            given date. (provider: polygon)
        period_of_report_date (datetime.date | None | Unset): Period of report date of the
            financial statement. (provider: polygon)
        period_of_report_date_lt (datetime.date | None | Unset): Period of report date less than
            the given date. (provider: polygon)
        period_of_report_date_lte (datetime.date | None | Unset): Period of report date less than
            or equal to the given date. (provider: polygon)
        period_of_report_date_gt (datetime.date | None | Unset): Period of report date greater
            than the given date. (provider: polygon)
        period_of_report_date_gte (datetime.date | None | Unset): Period of report date greater
            than or equal to the given date. (provider: polygon)
        include_sources (bool | None | Unset): Whether to include the sources of the financial
            statement. (provider: polygon)
        order (EquityFundamentalIncomeOrderType0 | None | Unset): Order of the financial
            statement. (provider: polygon)
        sort (EquityFundamentalIncomeSortType0 | None | Unset): Sort of the financial statement.
            (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        period=period,
        use_cache=use_cache,
        fiscal_year=fiscal_year,
        filing_date=filing_date,
        filing_date_lt=filing_date_lt,
        filing_date_lte=filing_date_lte,
        filing_date_gt=filing_date_gt,
        filing_date_gte=filing_date_gte,
        period_of_report_date=period_of_report_date,
        period_of_report_date_lt=period_of_report_date_lt,
        period_of_report_date_lte=period_of_report_date_lte,
        period_of_report_date_gt=period_of_report_date_gt,
        period_of_report_date_gte=period_of_report_date_gte,
        include_sources=include_sources,
        order=order,
        sort=sort,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalIncomeProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    period: EquityFundamentalIncomePeriodType0
    | EquityFundamentalIncomePeriodType1
    | EquityFundamentalIncomePeriodType2
    | EquityFundamentalIncomePeriodType3
    | Unset = EquityFundamentalIncomePeriodType0.ANNUAL,
    use_cache: bool | Unset = True,
    fiscal_year: int | None | Unset = UNSET,
    filing_date: datetime.date | None | Unset = UNSET,
    filing_date_lt: datetime.date | None | Unset = UNSET,
    filing_date_lte: datetime.date | None | Unset = UNSET,
    filing_date_gt: datetime.date | None | Unset = UNSET,
    filing_date_gte: datetime.date | None | Unset = UNSET,
    period_of_report_date: datetime.date | None | Unset = UNSET,
    period_of_report_date_lt: datetime.date | None | Unset = UNSET,
    period_of_report_date_lte: datetime.date | None | Unset = UNSET,
    period_of_report_date_gt: datetime.date | None | Unset = UNSET,
    period_of_report_date_gte: datetime.date | None | Unset = UNSET,
    include_sources: bool | None | Unset = UNSET,
    order: EquityFundamentalIncomeOrderType0 | None | Unset = UNSET,
    sort: EquityFundamentalIncomeSortType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse | None:
    """Income

     Get the income statement for a given company.

    Args:
        provider (EquityFundamentalIncomeProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        period (EquityFundamentalIncomePeriodType0 | EquityFundamentalIncomePeriodType1 |
            EquityFundamentalIncomePeriodType2 | EquityFundamentalIncomePeriodType3 | Unset): Time
            period of the data to return. (provider: akshare,fmp,intrinio,polygon, yfinance) Default:
            EquityFundamentalIncomePeriodType0.ANNUAL.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)
        filing_date (datetime.date | None | Unset): Filing date of the financial statement.
            (provider: polygon)
        filing_date_lt (datetime.date | None | Unset): Filing date less than the given date.
            (provider: polygon)
        filing_date_lte (datetime.date | None | Unset): Filing date less than or equal to the
            given date. (provider: polygon)
        filing_date_gt (datetime.date | None | Unset): Filing date greater than the given date.
            (provider: polygon)
        filing_date_gte (datetime.date | None | Unset): Filing date greater than or equal to the
            given date. (provider: polygon)
        period_of_report_date (datetime.date | None | Unset): Period of report date of the
            financial statement. (provider: polygon)
        period_of_report_date_lt (datetime.date | None | Unset): Period of report date less than
            the given date. (provider: polygon)
        period_of_report_date_lte (datetime.date | None | Unset): Period of report date less than
            or equal to the given date. (provider: polygon)
        period_of_report_date_gt (datetime.date | None | Unset): Period of report date greater
            than the given date. (provider: polygon)
        period_of_report_date_gte (datetime.date | None | Unset): Period of report date greater
            than or equal to the given date. (provider: polygon)
        include_sources (bool | None | Unset): Whether to include the sources of the financial
            statement. (provider: polygon)
        order (EquityFundamentalIncomeOrderType0 | None | Unset): Order of the financial
            statement. (provider: polygon)
        sort (EquityFundamentalIncomeSortType0 | None | Unset): Sort of the financial statement.
            (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectIncomeStatement | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            limit=limit,
            period=period,
            use_cache=use_cache,
            fiscal_year=fiscal_year,
            filing_date=filing_date,
            filing_date_lt=filing_date_lt,
            filing_date_lte=filing_date_lte,
            filing_date_gt=filing_date_gt,
            filing_date_gte=filing_date_gte,
            period_of_report_date=period_of_report_date,
            period_of_report_date_lt=period_of_report_date_lt,
            period_of_report_date_lte=period_of_report_date_lte,
            period_of_report_date_gt=period_of_report_date_gt,
            period_of_report_date_gte=period_of_report_date_gte,
            include_sources=include_sources,
            order=order,
            sort=sort,
        )
    ).parsed
