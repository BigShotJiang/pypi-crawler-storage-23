from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_executive_compensation import OBBjectExecutiveCompensation
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    year: int | Unset = -1,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    params["year"] = year

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/management_compensation",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectExecutiveCompensation.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    year: int | Unset = -1,
) -> Response[Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse]:
    """Management Compensation

     Get executive management team compensation for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        year (int | Unset): Filters results by year, enter 0 for all data available. Default is
            the most recent year in the dataset, -1. (provider: fmp) Default: -1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        year=year,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    year: int | Unset = -1,
) -> Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse | None:
    """Management Compensation

     Get executive management team compensation for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        year (int | Unset): Filters results by year, enter 0 for all data available. Default is
            the most recent year in the dataset, -1. (provider: fmp) Default: -1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        year=year,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    year: int | Unset = -1,
) -> Response[Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse]:
    """Management Compensation

     Get executive management team compensation for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        year (int | Unset): Filters results by year, enter 0 for all data available. Default is
            the most recent year in the dataset, -1. (provider: fmp) Default: -1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        year=year,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    year: int | Unset = -1,
) -> Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse | None:
    """Management Compensation

     Get executive management team compensation for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        year (int | Unset): Filters results by year, enter 0 for all data available. Default is
            the most recent year in the dataset, -1. (provider: fmp) Default: -1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectExecutiveCompensation | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            year=year,
        )
    ).parsed
