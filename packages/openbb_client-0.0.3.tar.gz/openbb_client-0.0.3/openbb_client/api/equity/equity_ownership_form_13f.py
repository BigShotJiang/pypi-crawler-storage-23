import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_form_13fhr import OBBjectForm13FHR
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/ownership/form_13f",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectForm13FHR.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1,
) -> Response[Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse]:
    """Form 13F

     Get the form 13F.

    The Securities and Exchange Commission's (SEC) Form 13F is a quarterly report
    that is required to be filed by all institutional investment managers with at least
    $100 million in assets under management.
    Managers are required to file Form 13F within 45 days after the last day of the calendar quarter.
    Most funds wait until the end of this period in order to conceal
    their investment strategy from competitors and the public.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for. A CIK or Symbol can be used.
        date (datetime.date | None | Unset): A specific date to get data for. The date represents
            the end of the reporting period. All form 13F-HR filings are based on the calendar year
            and are reported quarterly. If a date is not supplied, the most recent filing is returned.
            Submissions beginning 2013-06-30 are supported.
        limit (int | None | Unset): The number of data entries to return. The number of previous
            filings to return. The date parameter takes priority over this parameter. Default: 1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        date=date,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1,
) -> Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse | None:
    """Form 13F

     Get the form 13F.

    The Securities and Exchange Commission's (SEC) Form 13F is a quarterly report
    that is required to be filed by all institutional investment managers with at least
    $100 million in assets under management.
    Managers are required to file Form 13F within 45 days after the last day of the calendar quarter.
    Most funds wait until the end of this period in order to conceal
    their investment strategy from competitors and the public.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for. A CIK or Symbol can be used.
        date (datetime.date | None | Unset): A specific date to get data for. The date represents
            the end of the reporting period. All form 13F-HR filings are based on the calendar year
            and are reported quarterly. If a date is not supplied, the most recent filing is returned.
            Submissions beginning 2013-06-30 are supported.
        limit (int | None | Unset): The number of data entries to return. The number of previous
            filings to return. The date parameter takes priority over this parameter. Default: 1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        date=date,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1,
) -> Response[Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse]:
    """Form 13F

     Get the form 13F.

    The Securities and Exchange Commission's (SEC) Form 13F is a quarterly report
    that is required to be filed by all institutional investment managers with at least
    $100 million in assets under management.
    Managers are required to file Form 13F within 45 days after the last day of the calendar quarter.
    Most funds wait until the end of this period in order to conceal
    their investment strategy from competitors and the public.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for. A CIK or Symbol can be used.
        date (datetime.date | None | Unset): A specific date to get data for. The date represents
            the end of the reporting period. All form 13F-HR filings are based on the calendar year
            and are reported quarterly. If a date is not supplied, the most recent filing is returned.
            Submissions beginning 2013-06-30 are supported.
        limit (int | None | Unset): The number of data entries to return. The number of previous
            filings to return. The date parameter takes priority over this parameter. Default: 1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        date=date,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1,
) -> Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse | None:
    """Form 13F

     Get the form 13F.

    The Securities and Exchange Commission's (SEC) Form 13F is a quarterly report
    that is required to be filed by all institutional investment managers with at least
    $100 million in assets under management.
    Managers are required to file Form 13F within 45 days after the last day of the calendar quarter.
    Most funds wait until the end of this period in order to conceal
    their investment strategy from competitors and the public.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for. A CIK or Symbol can be used.
        date (datetime.date | None | Unset): A specific date to get data for. The date represents
            the end of the reporting period. All form 13F-HR filings are based on the calendar year
            and are reported quarterly. If a date is not supplied, the most recent filing is returned.
            Submissions beginning 2013-06-30 are supported.
        limit (int | None | Unset): The number of data entries to return. The number of previous
            filings to return. The date parameter takes priority over this parameter. Default: 1.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForm13FHR | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            date=date,
            limit=limit,
        )
    ).parsed
