import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_filings_provider import EquityFundamentalFilingsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_company_filings import OBBjectCompanyFilings
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityFundamentalFilingsProvider,
    symbol: None | str | Unset = UNSET,
    cik: int | None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1000,
    page: int | Unset = 0,
    form_type: None | str | Unset = UNSET,
    thea_enabled: bool | None | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_cik: int | None | str | Unset
    if isinstance(cik, Unset):
        json_cik = UNSET
    else:
        json_cik = cik
    params["cik"] = json_cik

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["page"] = page

    json_form_type: None | str | Unset
    if isinstance(form_type, Unset):
        json_form_type = UNSET
    else:
        json_form_type = form_type
    params["form_type"] = json_form_type

    json_thea_enabled: bool | None | Unset
    if isinstance(thea_enabled, Unset):
        json_thea_enabled = UNSET
    else:
        json_thea_enabled = thea_enabled
    params["thea_enabled"] = json_thea_enabled

    params["use_cache"] = use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/filings",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCompanyFilings.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalFilingsProvider,
    symbol: None | str | Unset = UNSET,
    cik: int | None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1000,
    page: int | Unset = 0,
    form_type: None | str | Unset = UNSET,
    thea_enabled: bool | None | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse]:
    """Filings

     Get public company filings.

    Args:
        provider (EquityFundamentalFilingsProvider):
        symbol (None | str | Unset): Symbol to get data for.
        cik (int | None | str | Unset): CIK number to look up. Overrides symbol. (provider: fmp);
                Lookup filings by Central Index Key (CIK) instead of by symbol. (provider: sec)
        start_date (datetime.date | None | Unset): Start date for filtering filings. Default is
            one year ago. (provider: fmp);
                Start date of the data, in YYYY-MM-DD format. (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. (provider: sec)
        end_date (datetime.date | None | Unset): End date for filtering filings. (provider: fmp);
                End date of the data, in YYYY-MM-DD format. (provider: intrinio);
                End date of the data, in YYYY-MM-DD format. (provider: sec)
        limit (int | None | Unset): Number of results to return. Max results is 1000. (provider:
            fmp);
                The number of data entries to return. (provider: intrinio);
                The number of data entries to return. (provider: sec) Default: 1000.
        page (int | Unset): Page number for paginated results. Max page is 100. (provider: fmp)
            Default: 0.
        form_type (None | str | Unset): SEC form type to filter by. (provider: intrinio, sec)
        thea_enabled (bool | None | Unset): Return filings that have been read by Intrinio's Thea
            NLP. (provider: intrinio)
        use_cache (bool | Unset): Whether or not to use cache.  If True, cache will store for one
            day. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        cik=cik,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        page=page,
        form_type=form_type,
        thea_enabled=thea_enabled,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalFilingsProvider,
    symbol: None | str | Unset = UNSET,
    cik: int | None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1000,
    page: int | Unset = 0,
    form_type: None | str | Unset = UNSET,
    thea_enabled: bool | None | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse | None:
    """Filings

     Get public company filings.

    Args:
        provider (EquityFundamentalFilingsProvider):
        symbol (None | str | Unset): Symbol to get data for.
        cik (int | None | str | Unset): CIK number to look up. Overrides symbol. (provider: fmp);
                Lookup filings by Central Index Key (CIK) instead of by symbol. (provider: sec)
        start_date (datetime.date | None | Unset): Start date for filtering filings. Default is
            one year ago. (provider: fmp);
                Start date of the data, in YYYY-MM-DD format. (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. (provider: sec)
        end_date (datetime.date | None | Unset): End date for filtering filings. (provider: fmp);
                End date of the data, in YYYY-MM-DD format. (provider: intrinio);
                End date of the data, in YYYY-MM-DD format. (provider: sec)
        limit (int | None | Unset): Number of results to return. Max results is 1000. (provider:
            fmp);
                The number of data entries to return. (provider: intrinio);
                The number of data entries to return. (provider: sec) Default: 1000.
        page (int | Unset): Page number for paginated results. Max page is 100. (provider: fmp)
            Default: 0.
        form_type (None | str | Unset): SEC form type to filter by. (provider: intrinio, sec)
        thea_enabled (bool | None | Unset): Return filings that have been read by Intrinio's Thea
            NLP. (provider: intrinio)
        use_cache (bool | Unset): Whether or not to use cache.  If True, cache will store for one
            day. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        cik=cik,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        page=page,
        form_type=form_type,
        thea_enabled=thea_enabled,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalFilingsProvider,
    symbol: None | str | Unset = UNSET,
    cik: int | None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1000,
    page: int | Unset = 0,
    form_type: None | str | Unset = UNSET,
    thea_enabled: bool | None | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse]:
    """Filings

     Get public company filings.

    Args:
        provider (EquityFundamentalFilingsProvider):
        symbol (None | str | Unset): Symbol to get data for.
        cik (int | None | str | Unset): CIK number to look up. Overrides symbol. (provider: fmp);
                Lookup filings by Central Index Key (CIK) instead of by symbol. (provider: sec)
        start_date (datetime.date | None | Unset): Start date for filtering filings. Default is
            one year ago. (provider: fmp);
                Start date of the data, in YYYY-MM-DD format. (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. (provider: sec)
        end_date (datetime.date | None | Unset): End date for filtering filings. (provider: fmp);
                End date of the data, in YYYY-MM-DD format. (provider: intrinio);
                End date of the data, in YYYY-MM-DD format. (provider: sec)
        limit (int | None | Unset): Number of results to return. Max results is 1000. (provider:
            fmp);
                The number of data entries to return. (provider: intrinio);
                The number of data entries to return. (provider: sec) Default: 1000.
        page (int | Unset): Page number for paginated results. Max page is 100. (provider: fmp)
            Default: 0.
        form_type (None | str | Unset): SEC form type to filter by. (provider: intrinio, sec)
        thea_enabled (bool | None | Unset): Return filings that have been read by Intrinio's Thea
            NLP. (provider: intrinio)
        use_cache (bool | Unset): Whether or not to use cache.  If True, cache will store for one
            day. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        cik=cik,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        page=page,
        form_type=form_type,
        thea_enabled=thea_enabled,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalFilingsProvider,
    symbol: None | str | Unset = UNSET,
    cik: int | None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = 1000,
    page: int | Unset = 0,
    form_type: None | str | Unset = UNSET,
    thea_enabled: bool | None | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse | None:
    """Filings

     Get public company filings.

    Args:
        provider (EquityFundamentalFilingsProvider):
        symbol (None | str | Unset): Symbol to get data for.
        cik (int | None | str | Unset): CIK number to look up. Overrides symbol. (provider: fmp);
                Lookup filings by Central Index Key (CIK) instead of by symbol. (provider: sec)
        start_date (datetime.date | None | Unset): Start date for filtering filings. Default is
            one year ago. (provider: fmp);
                Start date of the data, in YYYY-MM-DD format. (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. (provider: sec)
        end_date (datetime.date | None | Unset): End date for filtering filings. (provider: fmp);
                End date of the data, in YYYY-MM-DD format. (provider: intrinio);
                End date of the data, in YYYY-MM-DD format. (provider: sec)
        limit (int | None | Unset): Number of results to return. Max results is 1000. (provider:
            fmp);
                The number of data entries to return. (provider: intrinio);
                The number of data entries to return. (provider: sec) Default: 1000.
        page (int | Unset): Page number for paginated results. Max page is 100. (provider: fmp)
            Default: 0.
        form_type (None | str | Unset): SEC form type to filter by. (provider: intrinio, sec)
        thea_enabled (bool | None | Unset): Return filings that have been read by Intrinio's Thea
            NLP. (provider: intrinio)
        use_cache (bool | Unset): Whether or not to use cache.  If True, cache will store for one
            day. (provider: sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCompanyFilings | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            cik=cik,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            page=page,
            form_type=form_type,
            thea_enabled=thea_enabled,
            use_cache=use_cache,
        )
    ).parsed
