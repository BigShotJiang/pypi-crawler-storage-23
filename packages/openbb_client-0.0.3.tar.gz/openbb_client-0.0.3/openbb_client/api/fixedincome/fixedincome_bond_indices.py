import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.fixedincome_bond_indices_frequency_type_0 import FixedincomeBondIndicesFrequencyType0
from ...models.fixedincome_bond_indices_transform_type_0 import FixedincomeBondIndicesTransformType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_bond_indices import OBBjectBondIndices
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    index_type: str | Unset = "yield",
    category: str | Unset = "us",
    index: str | Unset = "yield_curve",
    frequency: FixedincomeBondIndicesFrequencyType0 | None | Unset = UNSET,
    aggregation_method: str | Unset = "avg",
    transform: FixedincomeBondIndicesTransformType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["index_type"] = index_type

    params["category"] = category

    params["index"] = index

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    elif isinstance(frequency, FixedincomeBondIndicesFrequencyType0):
        json_frequency = frequency.value
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    params["aggregation_method"] = aggregation_method

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    elif isinstance(transform, FixedincomeBondIndicesTransformType0):
        json_transform = transform.value
    else:
        json_transform = transform
    params["transform"] = json_transform

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/fixedincome/bond_indices",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectBondIndices.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    index_type: str | Unset = "yield",
    category: str | Unset = "us",
    index: str | Unset = "yield_curve",
    frequency: FixedincomeBondIndicesFrequencyType0 | None | Unset = UNSET,
    aggregation_method: str | Unset = "avg",
    transform: FixedincomeBondIndicesTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse]:
    """Bond Indices

     Bond Indices.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        index_type (str | Unset): The type of series. OAS is the option-adjusted spread. Default
            is yield. Default: 'yield'.
        category (str | Unset): The type of index category. Used in conjunction with 'index',
            default is 'us'. (provider: fred) Default: 'us'.
        index (str | Unset): The specific index to query. Used in conjunction with 'category' and
            'index_type', default is 'yield_curve'.
                    Possible values are:
                        corporate
                        seasoned_corporate
                        liquid_corporate
                        yield_curve
                        crossover
                        public_sector
                        private_sector
                        non_financial
                        high_grade
                        high_yield
                        liquid_emea
                        emea
                        liquid_asia
                        asia
                        liquid_latam
                        latam
                        liquid_aaa
                        liquid_bbb
                        aaa
                        aa
                        a
                        bbb
                        bb
                        b
                        ccc

                     Multiple comma separated items allowed. (provider: fred) Default: 'yield_curve'.
        frequency (FixedincomeBondIndicesFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        None = No change
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        d = Daily
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (str | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set, default is
            'avg'.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred) Default: 'avg'.
        transform (FixedincomeBondIndicesTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        index_type=index_type,
        category=category,
        index=index,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    index_type: str | Unset = "yield",
    category: str | Unset = "us",
    index: str | Unset = "yield_curve",
    frequency: FixedincomeBondIndicesFrequencyType0 | None | Unset = UNSET,
    aggregation_method: str | Unset = "avg",
    transform: FixedincomeBondIndicesTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse | None:
    """Bond Indices

     Bond Indices.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        index_type (str | Unset): The type of series. OAS is the option-adjusted spread. Default
            is yield. Default: 'yield'.
        category (str | Unset): The type of index category. Used in conjunction with 'index',
            default is 'us'. (provider: fred) Default: 'us'.
        index (str | Unset): The specific index to query. Used in conjunction with 'category' and
            'index_type', default is 'yield_curve'.
                    Possible values are:
                        corporate
                        seasoned_corporate
                        liquid_corporate
                        yield_curve
                        crossover
                        public_sector
                        private_sector
                        non_financial
                        high_grade
                        high_yield
                        liquid_emea
                        emea
                        liquid_asia
                        asia
                        liquid_latam
                        latam
                        liquid_aaa
                        liquid_bbb
                        aaa
                        aa
                        a
                        bbb
                        bb
                        b
                        ccc

                     Multiple comma separated items allowed. (provider: fred) Default: 'yield_curve'.
        frequency (FixedincomeBondIndicesFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        None = No change
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        d = Daily
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (str | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set, default is
            'avg'.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred) Default: 'avg'.
        transform (FixedincomeBondIndicesTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        index_type=index_type,
        category=category,
        index=index,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    index_type: str | Unset = "yield",
    category: str | Unset = "us",
    index: str | Unset = "yield_curve",
    frequency: FixedincomeBondIndicesFrequencyType0 | None | Unset = UNSET,
    aggregation_method: str | Unset = "avg",
    transform: FixedincomeBondIndicesTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse]:
    """Bond Indices

     Bond Indices.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        index_type (str | Unset): The type of series. OAS is the option-adjusted spread. Default
            is yield. Default: 'yield'.
        category (str | Unset): The type of index category. Used in conjunction with 'index',
            default is 'us'. (provider: fred) Default: 'us'.
        index (str | Unset): The specific index to query. Used in conjunction with 'category' and
            'index_type', default is 'yield_curve'.
                    Possible values are:
                        corporate
                        seasoned_corporate
                        liquid_corporate
                        yield_curve
                        crossover
                        public_sector
                        private_sector
                        non_financial
                        high_grade
                        high_yield
                        liquid_emea
                        emea
                        liquid_asia
                        asia
                        liquid_latam
                        latam
                        liquid_aaa
                        liquid_bbb
                        aaa
                        aa
                        a
                        bbb
                        bb
                        b
                        ccc

                     Multiple comma separated items allowed. (provider: fred) Default: 'yield_curve'.
        frequency (FixedincomeBondIndicesFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        None = No change
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        d = Daily
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (str | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set, default is
            'avg'.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred) Default: 'avg'.
        transform (FixedincomeBondIndicesTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        index_type=index_type,
        category=category,
        index=index,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    index_type: str | Unset = "yield",
    category: str | Unset = "us",
    index: str | Unset = "yield_curve",
    frequency: FixedincomeBondIndicesFrequencyType0 | None | Unset = UNSET,
    aggregation_method: str | Unset = "avg",
    transform: FixedincomeBondIndicesTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse | None:
    """Bond Indices

     Bond Indices.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        index_type (str | Unset): The type of series. OAS is the option-adjusted spread. Default
            is yield. Default: 'yield'.
        category (str | Unset): The type of index category. Used in conjunction with 'index',
            default is 'us'. (provider: fred) Default: 'us'.
        index (str | Unset): The specific index to query. Used in conjunction with 'category' and
            'index_type', default is 'yield_curve'.
                    Possible values are:
                        corporate
                        seasoned_corporate
                        liquid_corporate
                        yield_curve
                        crossover
                        public_sector
                        private_sector
                        non_financial
                        high_grade
                        high_yield
                        liquid_emea
                        emea
                        liquid_asia
                        asia
                        liquid_latam
                        latam
                        liquid_aaa
                        liquid_bbb
                        aaa
                        aa
                        a
                        bbb
                        bb
                        b
                        ccc

                     Multiple comma separated items allowed. (provider: fred) Default: 'yield_curve'.
        frequency (FixedincomeBondIndicesFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        None = No change
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        d = Daily
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (str | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                    This parameter has no affect if the frequency parameter is not set, default is
            'avg'.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred) Default: 'avg'.
        transform (FixedincomeBondIndicesTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectBondIndices | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            index_type=index_type,
            category=category,
            index=index,
            frequency=frequency,
            aggregation_method=aggregation_method,
            transform=transform,
        )
    ).parsed
