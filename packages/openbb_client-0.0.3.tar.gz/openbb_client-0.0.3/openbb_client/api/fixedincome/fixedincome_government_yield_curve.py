import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.fixedincome_government_yield_curve_fred import FixedincomeGovernmentYieldCurveFred
from ...models.fixedincome_government_yield_curve_provider import FixedincomeGovernmentYieldCurveProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_yield_curve import OBBjectYieldCurve
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: FixedincomeGovernmentYieldCurveProvider,
    date: datetime.date | None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    yield_curve_type: FixedincomeGovernmentYieldCurveFred | Unset = FixedincomeGovernmentYieldCurveFred.NOMINAL,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    params["country"] = country

    params["use_cache"] = use_cache

    json_yield_curve_type: str | Unset = UNSET
    if not isinstance(yield_curve_type, Unset):
        json_yield_curve_type = yield_curve_type.value

    params["yield_curve_type"] = json_yield_curve_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/fixedincome/government/yield_curve",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectYieldCurve.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeGovernmentYieldCurveProvider,
    date: datetime.date | None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    yield_curve_type: FixedincomeGovernmentYieldCurveFred | Unset = FixedincomeGovernmentYieldCurveFred.NOMINAL,
) -> Response[Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse]:
    """Yield Curve

     Get yield curve data by country and date.

    Args:
        provider (FixedincomeGovernmentYieldCurveProvider):
        date (datetime.date | None | str | Unset): A specific date to get data for. By default is
            the current data. Multiple comma separated items allowed for provider(s): econdb,
            federal_reserve, fmp, fred.
        country (str | Unset): The country to get data. New Zealand, Mexico, Singapore, and
            Thailand have only monthly data. The nearest date to the requested one will be used.
            Multiple comma separated items allowed. (provider: econdb) Default: 'united_states'.
        use_cache (bool | Unset): If true, cache the request for four hours. (provider: econdb)
            Default: True.
        yield_curve_type (FixedincomeGovernmentYieldCurveFred | Unset): Yield curve type. Nominal
            and Real Rates are available daily, others are monthly. The closest date to the requested
            date will be returned. (provider: fred) Default:
            FixedincomeGovernmentYieldCurveFred.NOMINAL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        country=country,
        use_cache=use_cache,
        yield_curve_type=yield_curve_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeGovernmentYieldCurveProvider,
    date: datetime.date | None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    yield_curve_type: FixedincomeGovernmentYieldCurveFred | Unset = FixedincomeGovernmentYieldCurveFred.NOMINAL,
) -> Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse | None:
    """Yield Curve

     Get yield curve data by country and date.

    Args:
        provider (FixedincomeGovernmentYieldCurveProvider):
        date (datetime.date | None | str | Unset): A specific date to get data for. By default is
            the current data. Multiple comma separated items allowed for provider(s): econdb,
            federal_reserve, fmp, fred.
        country (str | Unset): The country to get data. New Zealand, Mexico, Singapore, and
            Thailand have only monthly data. The nearest date to the requested one will be used.
            Multiple comma separated items allowed. (provider: econdb) Default: 'united_states'.
        use_cache (bool | Unset): If true, cache the request for four hours. (provider: econdb)
            Default: True.
        yield_curve_type (FixedincomeGovernmentYieldCurveFred | Unset): Yield curve type. Nominal
            and Real Rates are available daily, others are monthly. The closest date to the requested
            date will be returned. (provider: fred) Default:
            FixedincomeGovernmentYieldCurveFred.NOMINAL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        date=date,
        country=country,
        use_cache=use_cache,
        yield_curve_type=yield_curve_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeGovernmentYieldCurveProvider,
    date: datetime.date | None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    yield_curve_type: FixedincomeGovernmentYieldCurveFred | Unset = FixedincomeGovernmentYieldCurveFred.NOMINAL,
) -> Response[Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse]:
    """Yield Curve

     Get yield curve data by country and date.

    Args:
        provider (FixedincomeGovernmentYieldCurveProvider):
        date (datetime.date | None | str | Unset): A specific date to get data for. By default is
            the current data. Multiple comma separated items allowed for provider(s): econdb,
            federal_reserve, fmp, fred.
        country (str | Unset): The country to get data. New Zealand, Mexico, Singapore, and
            Thailand have only monthly data. The nearest date to the requested one will be used.
            Multiple comma separated items allowed. (provider: econdb) Default: 'united_states'.
        use_cache (bool | Unset): If true, cache the request for four hours. (provider: econdb)
            Default: True.
        yield_curve_type (FixedincomeGovernmentYieldCurveFred | Unset): Yield curve type. Nominal
            and Real Rates are available daily, others are monthly. The closest date to the requested
            date will be returned. (provider: fred) Default:
            FixedincomeGovernmentYieldCurveFred.NOMINAL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        country=country,
        use_cache=use_cache,
        yield_curve_type=yield_curve_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeGovernmentYieldCurveProvider,
    date: datetime.date | None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    yield_curve_type: FixedincomeGovernmentYieldCurveFred | Unset = FixedincomeGovernmentYieldCurveFred.NOMINAL,
) -> Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse | None:
    """Yield Curve

     Get yield curve data by country and date.

    Args:
        provider (FixedincomeGovernmentYieldCurveProvider):
        date (datetime.date | None | str | Unset): A specific date to get data for. By default is
            the current data. Multiple comma separated items allowed for provider(s): econdb,
            federal_reserve, fmp, fred.
        country (str | Unset): The country to get data. New Zealand, Mexico, Singapore, and
            Thailand have only monthly data. The nearest date to the requested one will be used.
            Multiple comma separated items allowed. (provider: econdb) Default: 'united_states'.
        use_cache (bool | Unset): If true, cache the request for four hours. (provider: econdb)
            Default: True.
        yield_curve_type (FixedincomeGovernmentYieldCurveFred | Unset): Yield curve type. Nominal
            and Real Rates are available daily, others are monthly. The closest date to the requested
            date will be returned. (provider: fred) Default:
            FixedincomeGovernmentYieldCurveFred.NOMINAL.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectYieldCurve | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            date=date,
            country=country,
            use_cache=use_cache,
            yield_curve_type=yield_curve_type,
        )
    ).parsed
