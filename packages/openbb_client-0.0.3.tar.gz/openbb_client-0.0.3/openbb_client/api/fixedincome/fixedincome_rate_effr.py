import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.fixedincome_rate_effr_aggregation_method_type_0 import FixedincomeRateEffrAggregationMethodType0
from ...models.fixedincome_rate_effr_frequency_type_0 import FixedincomeRateEffrFrequencyType0
from ...models.fixedincome_rate_effr_provider import FixedincomeRateEffrProvider
from ...models.fixedincome_rate_effr_transform_type_0 import FixedincomeRateEffrTransformType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_federal_funds_rate import OBBjectFederalFundsRate
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: FixedincomeRateEffrProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: FixedincomeRateEffrFrequencyType0 | None | Unset = UNSET,
    aggregation_method: FixedincomeRateEffrAggregationMethodType0 | None | Unset = UNSET,
    transform: FixedincomeRateEffrTransformType0 | None | Unset = UNSET,
    effr_only: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    elif isinstance(frequency, FixedincomeRateEffrFrequencyType0):
        json_frequency = frequency.value
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_aggregation_method: None | str | Unset
    if isinstance(aggregation_method, Unset):
        json_aggregation_method = UNSET
    elif isinstance(aggregation_method, FixedincomeRateEffrAggregationMethodType0):
        json_aggregation_method = aggregation_method.value
    else:
        json_aggregation_method = aggregation_method
    params["aggregation_method"] = json_aggregation_method

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    elif isinstance(transform, FixedincomeRateEffrTransformType0):
        json_transform = transform.value
    else:
        json_transform = transform
    params["transform"] = json_transform

    params["effr_only"] = effr_only

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/fixedincome/rate/effr",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectFederalFundsRate.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeRateEffrProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: FixedincomeRateEffrFrequencyType0 | None | Unset = UNSET,
    aggregation_method: FixedincomeRateEffrAggregationMethodType0 | None | Unset = UNSET,
    transform: FixedincomeRateEffrTransformType0 | None | Unset = UNSET,
    effr_only: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse]:
    """Effr

     Fed Funds Rate.

    Get Effective Federal Funds Rate data. A bank rate is the interest rate a nation's central bank
    charges to its
    domestic banks to borrow money. The rates central banks charge are set to stabilize the economy.

    Args:
        provider (FixedincomeRateEffrProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (FixedincomeRateEffrFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (FixedincomeRateEffrAggregationMethodType0 | None | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred)
        transform (FixedincomeRateEffrTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)
        effr_only (bool | Unset): Return data without quantiles, target ranges, and volume.
            (provider: fred) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
        effr_only=effr_only,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeRateEffrProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: FixedincomeRateEffrFrequencyType0 | None | Unset = UNSET,
    aggregation_method: FixedincomeRateEffrAggregationMethodType0 | None | Unset = UNSET,
    transform: FixedincomeRateEffrTransformType0 | None | Unset = UNSET,
    effr_only: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse | None:
    """Effr

     Fed Funds Rate.

    Get Effective Federal Funds Rate data. A bank rate is the interest rate a nation's central bank
    charges to its
    domestic banks to borrow money. The rates central banks charge are set to stabilize the economy.

    Args:
        provider (FixedincomeRateEffrProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (FixedincomeRateEffrFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (FixedincomeRateEffrAggregationMethodType0 | None | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred)
        transform (FixedincomeRateEffrTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)
        effr_only (bool | Unset): Return data without quantiles, target ranges, and volume.
            (provider: fred) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
        effr_only=effr_only,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeRateEffrProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: FixedincomeRateEffrFrequencyType0 | None | Unset = UNSET,
    aggregation_method: FixedincomeRateEffrAggregationMethodType0 | None | Unset = UNSET,
    transform: FixedincomeRateEffrTransformType0 | None | Unset = UNSET,
    effr_only: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse]:
    """Effr

     Fed Funds Rate.

    Get Effective Federal Funds Rate data. A bank rate is the interest rate a nation's central bank
    charges to its
    domestic banks to borrow money. The rates central banks charge are set to stabilize the economy.

    Args:
        provider (FixedincomeRateEffrProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (FixedincomeRateEffrFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (FixedincomeRateEffrAggregationMethodType0 | None | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred)
        transform (FixedincomeRateEffrTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)
        effr_only (bool | Unset): Return data without quantiles, target ranges, and volume.
            (provider: fred) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
        effr_only=effr_only,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: FixedincomeRateEffrProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: FixedincomeRateEffrFrequencyType0 | None | Unset = UNSET,
    aggregation_method: FixedincomeRateEffrAggregationMethodType0 | None | Unset = UNSET,
    transform: FixedincomeRateEffrTransformType0 | None | Unset = UNSET,
    effr_only: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse | None:
    """Effr

     Fed Funds Rate.

    Get Effective Federal Funds Rate data. A bank rate is the interest rate a nation's central bank
    charges to its
    domestic banks to borrow money. The rates central banks charge are set to stabilize the economy.

    Args:
        provider (FixedincomeRateEffrProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (FixedincomeRateEffrFrequencyType0 | None | Unset):
                    Frequency aggregation to convert daily data to lower frequency.
                        a = Annual
                        q = Quarterly
                        m = Monthly
                        w = Weekly
                        wef = Weekly, Ending Friday
                        weth = Weekly, Ending Thursday
                        wew = Weekly, Ending Wednesday
                        wetu = Weekly, Ending Tuesday
                        wem = Weekly, Ending Monday
                        wesu = Weekly, Ending Sunday
                        wesa = Weekly, Ending Saturday
                        bwew = Biweekly, Ending Wednesday
                        bwem = Biweekly, Ending Monday
                     (provider: fred)
        aggregation_method (FixedincomeRateEffrAggregationMethodType0 | None | Unset):
                    A key that indicates the aggregation method used for frequency aggregation.
                        avg = Average
                        sum = Sum
                        eop = End of Period
                     (provider: fred)
        transform (FixedincomeRateEffrTransformType0 | None | Unset):
                    Transformation type
                        None = No transformation
                        chg = Change
                        ch1 = Change from Year Ago
                        pch = Percent Change
                        pc1 = Percent Change from Year Ago
                        pca = Compounded Annual Rate of Change
                        cch = Continuously Compounded Rate of Change
                        cca = Continuously Compounded Annual Rate of Change
                        log = Natural Log
                     (provider: fred)
        effr_only (bool | Unset): Return data without quantiles, target ranges, and volume.
            (provider: fred) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFederalFundsRate | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            aggregation_method=aggregation_method,
            transform=transform,
            effr_only=effr_only,
        )
    ).parsed
