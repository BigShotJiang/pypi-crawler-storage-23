from enum import Enum


class EquityPriceHistoricalIntervalType1(str, Enum):
    VALUE_0 = "1m"
    VALUE_1 = "5m"
    VALUE_10 = "1Q"
    VALUE_11 = "1Y"
    VALUE_2 = "10m"
    VALUE_3 = "15m"
    VALUE_4 = "30m"
    VALUE_5 = "60m"
    VALUE_6 = "1h"
    VALUE_7 = "1d"
    VALUE_8 = "1W"
    VALUE_9 = "1M"

    def __str__(self) -> str:
        return str(self.value)
