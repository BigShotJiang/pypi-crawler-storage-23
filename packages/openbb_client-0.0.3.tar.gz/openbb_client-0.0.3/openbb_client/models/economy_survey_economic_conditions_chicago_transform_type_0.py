from enum import Enum


class EconomySurveyEconomicConditionsChicagoTransformType0(str, Enum):
    CCA = "cca"
    CCH = "cch"
    CH1 = "ch1"
    CHG = "chg"
    LOG = "log"
    PC1 = "pc1"
    PCA = "pca"
    PCH = "pch"

    def __str__(self) -> str:
        return str(self.value)
