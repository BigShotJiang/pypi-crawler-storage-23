from enum import Enum


class CommodityShortTermEnergyOutlookEia(str, Enum):
    VALUE_0 = "01"
    VALUE_1 = "02"
    VALUE_10 = "04d"
    VALUE_11 = "05a"
    VALUE_12 = "05b"
    VALUE_13 = "06"
    VALUE_14 = "07a"
    VALUE_15 = "07b"
    VALUE_16 = "07c"
    VALUE_17 = "07d1"
    VALUE_18 = "07d2"
    VALUE_19 = "07e"
    VALUE_2 = "03a"
    VALUE_20 = "08"
    VALUE_21 = "09a"
    VALUE_22 = "09b"
    VALUE_23 = "09c"
    VALUE_24 = "10a"
    VALUE_25 = "10b"
    VALUE_3 = "03b"
    VALUE_4 = "03c"
    VALUE_5 = "03d"
    VALUE_6 = "03e"
    VALUE_7 = "04a"
    VALUE_8 = "04b"
    VALUE_9 = "04c"

    def __str__(self) -> str:
        return str(self.value)
