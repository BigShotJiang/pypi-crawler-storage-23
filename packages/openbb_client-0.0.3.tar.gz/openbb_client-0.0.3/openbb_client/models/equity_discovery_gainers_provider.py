from enum import Enum


class EquityDiscoveryGainersProvider(str, Enum):
    FMP = "fmp"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
