from enum import Enum


class EconomySurveyManufacturingOutlookTexasTopicType0(str, Enum):
    BUSINESS_ACTIVITY = "business_activity"
    BUSINESS_OUTLOOK = "business_outlook"
    CAPEX = "capex"
    DELIVERY_TIME = "delivery_time"
    EMPLOYMENT = "employment"
    HOURS_WORKED = "hours_worked"
    INVENTORY = "inventory"
    NEW_ORDERS = "new_orders"
    NEW_ORDERS_GROWTH = "new_orders_growth"
    PRICES_PAID = "prices_paid"
    PRODUCTION = "production"
    SHIPMENTS = "shipments"
    UNFILLED_ORDERS = "unfilled_orders"
    WAGES = "wages"

    def __str__(self) -> str:
        return str(self.value)
