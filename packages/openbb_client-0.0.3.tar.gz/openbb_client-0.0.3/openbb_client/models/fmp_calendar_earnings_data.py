from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCalendarEarningsData")


@_attrs_define
class FMPCalendarEarningsData:
    """FMP Earnings Calendar Data.

    Attributes:
        report_date (datetime.date): The date of the earnings report.
        symbol (str): Symbol representing the entity requested in the data.
        name (None | str | Unset): Name of the entity.
        eps_previous (float | None | Unset): The earnings-per-share from the same previously reported period.
        eps_consensus (float | None | Unset): The analyst conesus earnings-per-share estimate.
        eps_actual (float | None | Unset): The actual earnings per share announced.
        revenue_consensus (float | None | Unset): The revenue forecast consensus.
        revenue_actual (float | None | Unset): The actual reported revenue.
        last_updated (datetime.date | None | Unset): The date the data was updated last.
    """

    report_date: datetime.date
    symbol: str
    name: None | str | Unset = UNSET
    eps_previous: float | None | Unset = UNSET
    eps_consensus: float | None | Unset = UNSET
    eps_actual: float | None | Unset = UNSET
    revenue_consensus: float | None | Unset = UNSET
    revenue_actual: float | None | Unset = UNSET
    last_updated: datetime.date | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        report_date = self.report_date.isoformat()

        symbol = self.symbol

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        eps_previous: float | None | Unset
        if isinstance(self.eps_previous, Unset):
            eps_previous = UNSET
        else:
            eps_previous = self.eps_previous

        eps_consensus: float | None | Unset
        if isinstance(self.eps_consensus, Unset):
            eps_consensus = UNSET
        else:
            eps_consensus = self.eps_consensus

        eps_actual: float | None | Unset
        if isinstance(self.eps_actual, Unset):
            eps_actual = UNSET
        else:
            eps_actual = self.eps_actual

        revenue_consensus: float | None | Unset
        if isinstance(self.revenue_consensus, Unset):
            revenue_consensus = UNSET
        else:
            revenue_consensus = self.revenue_consensus

        revenue_actual: float | None | Unset
        if isinstance(self.revenue_actual, Unset):
            revenue_actual = UNSET
        else:
            revenue_actual = self.revenue_actual

        last_updated: None | str | Unset
        if isinstance(self.last_updated, Unset):
            last_updated = UNSET
        elif isinstance(self.last_updated, datetime.date):
            last_updated = self.last_updated.isoformat()
        else:
            last_updated = self.last_updated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "report_date": report_date,
                "symbol": symbol,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if eps_previous is not UNSET:
            field_dict["eps_previous"] = eps_previous
        if eps_consensus is not UNSET:
            field_dict["eps_consensus"] = eps_consensus
        if eps_actual is not UNSET:
            field_dict["eps_actual"] = eps_actual
        if revenue_consensus is not UNSET:
            field_dict["revenue_consensus"] = revenue_consensus
        if revenue_actual is not UNSET:
            field_dict["revenue_actual"] = revenue_actual
        if last_updated is not UNSET:
            field_dict["last_updated"] = last_updated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        report_date = isoparse(d.pop("report_date")).date()

        symbol = d.pop("symbol")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_eps_previous(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        eps_previous = _parse_eps_previous(d.pop("eps_previous", UNSET))

        def _parse_eps_consensus(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        eps_consensus = _parse_eps_consensus(d.pop("eps_consensus", UNSET))

        def _parse_eps_actual(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        eps_actual = _parse_eps_actual(d.pop("eps_actual", UNSET))

        def _parse_revenue_consensus(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        revenue_consensus = _parse_revenue_consensus(d.pop("revenue_consensus", UNSET))

        def _parse_revenue_actual(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        revenue_actual = _parse_revenue_actual(d.pop("revenue_actual", UNSET))

        def _parse_last_updated(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_updated_type_0 = isoparse(data).date()

                return last_updated_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        last_updated = _parse_last_updated(d.pop("last_updated", UNSET))

        fmp_calendar_earnings_data = cls(
            report_date=report_date,
            symbol=symbol,
            name=name,
            eps_previous=eps_previous,
            eps_consensus=eps_consensus,
            eps_actual=eps_actual,
            revenue_consensus=revenue_consensus,
            revenue_actual=revenue_actual,
            last_updated=last_updated,
        )

        fmp_calendar_earnings_data.additional_properties = d
        return fmp_calendar_earnings_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
