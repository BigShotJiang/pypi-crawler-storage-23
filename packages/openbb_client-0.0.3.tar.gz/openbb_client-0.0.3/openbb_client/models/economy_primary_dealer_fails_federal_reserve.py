from enum import Enum


class EconomyPrimaryDealerFailsFederalReserve(str, Enum):
    AGENCY = "agency"
    ALL = "all"
    CORPORATE = "corporate"
    MBS = "mbs"
    TIPS = "tips"
    TREASURIES = "treasuries"

    def __str__(self) -> str:
        return str(self.value)
