from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AkshareFundHoldingsData")


@_attrs_define
class AkshareFundHoldingsData:
    """FMP Fund Holdings Data.

    Attributes:
        symbol (None | str | Unset): Symbol representing the entity requested in the data. (Fund)
        name (None | str | Unset): Name of the Fund holding.
        balance (int | None | Unset): The balance of the holding, in shares or units.
        value (float | None | Unset): The value of the holding, in dollars.
        weight (float | None | Unset): The weight of the holding, as a normalized percent.
        acceptance_datetime (None | str | Unset): The acceptance datetime of the filing.
    """

    symbol: None | str | Unset = UNSET
    name: None | str | Unset = UNSET
    balance: int | None | Unset = UNSET
    value: float | None | Unset = UNSET
    weight: float | None | Unset = UNSET
    acceptance_datetime: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        balance: int | None | Unset
        if isinstance(self.balance, Unset):
            balance = UNSET
        else:
            balance = self.balance

        value: float | None | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        weight: float | None | Unset
        if isinstance(self.weight, Unset):
            weight = UNSET
        else:
            weight = self.weight

        acceptance_datetime: None | str | Unset
        if isinstance(self.acceptance_datetime, Unset):
            acceptance_datetime = UNSET
        else:
            acceptance_datetime = self.acceptance_datetime

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if name is not UNSET:
            field_dict["name"] = name
        if balance is not UNSET:
            field_dict["balance"] = balance
        if value is not UNSET:
            field_dict["value"] = value
        if weight is not UNSET:
            field_dict["weight"] = weight
        if acceptance_datetime is not UNSET:
            field_dict["acceptance_datetime"] = acceptance_datetime

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_balance(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        balance = _parse_balance(d.pop("balance", UNSET))

        def _parse_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        def _parse_weight(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        weight = _parse_weight(d.pop("weight", UNSET))

        def _parse_acceptance_datetime(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        acceptance_datetime = _parse_acceptance_datetime(d.pop("acceptance_datetime", UNSET))

        akshare_fund_holdings_data = cls(
            symbol=symbol,
            name=name,
            balance=balance,
            value=value,
            weight=weight,
            acceptance_datetime=acceptance_datetime,
        )

        akshare_fund_holdings_data.additional_properties = d
        return akshare_fund_holdings_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
