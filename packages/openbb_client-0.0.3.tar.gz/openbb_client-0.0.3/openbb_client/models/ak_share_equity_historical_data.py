from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareEquityHistoricalData")


@_attrs_define
class AKShareEquityHistoricalData:
    """AKShare Equity Historical Price Data.

    Attributes:
        date (datetime.date | datetime.datetime): The date of the data.
        open_ (float): The open price.
        high (float): The high price.
        low (float): The low price.
        close (float): The close price.
        volume (float | int | None | Unset): The trading volume.
        vwap (float | None | Unset): Volume Weighted Average Price over the period.
        amount (float | None | Unset): Amount.
        change (float | None | Unset): Change in the price from the previous close.
        change_percent (float | None | Unset): Change in the price from the previous close, as a normalized percent.
    """

    date: datetime.date | datetime.datetime
    open_: float
    high: float
    low: float
    close: float
    volume: float | int | None | Unset = UNSET
    vwap: float | None | Unset = UNSET
    amount: float | None | Unset = UNSET
    change: float | None | Unset = UNSET
    change_percent: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date: str
        if isinstance(self.date, datetime.date):
            date = self.date.isoformat()
        else:
            date = self.date.isoformat()

        open_ = self.open_

        high = self.high

        low = self.low

        close = self.close

        volume: float | int | None | Unset
        if isinstance(self.volume, Unset):
            volume = UNSET
        else:
            volume = self.volume

        vwap: float | None | Unset
        if isinstance(self.vwap, Unset):
            vwap = UNSET
        else:
            vwap = self.vwap

        amount: float | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        change: float | None | Unset
        if isinstance(self.change, Unset):
            change = UNSET
        else:
            change = self.change

        change_percent: float | None | Unset
        if isinstance(self.change_percent, Unset):
            change_percent = UNSET
        else:
            change_percent = self.change_percent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "open": open_,
                "high": high,
                "low": low,
                "close": close,
            }
        )
        if volume is not UNSET:
            field_dict["volume"] = volume
        if vwap is not UNSET:
            field_dict["vwap"] = vwap
        if amount is not UNSET:
            field_dict["amount"] = amount
        if change is not UNSET:
            field_dict["change"] = change
        if change_percent is not UNSET:
            field_dict["change_percent"] = change_percent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_date(data: object) -> datetime.date | datetime.datetime:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                date_type_0 = isoparse(data).date()

                return date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, str):
                raise TypeError()
            date_type_1 = isoparse(data)

            return date_type_1

        date = _parse_date(d.pop("date"))

        open_ = d.pop("open")

        high = d.pop("high")

        low = d.pop("low")

        close = d.pop("close")

        def _parse_volume(data: object) -> float | int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | int | None | Unset, data)

        volume = _parse_volume(d.pop("volume", UNSET))

        def _parse_vwap(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        vwap = _parse_vwap(d.pop("vwap", UNSET))

        def _parse_amount(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))

        def _parse_change(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change = _parse_change(d.pop("change", UNSET))

        def _parse_change_percent(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent = _parse_change_percent(d.pop("change_percent", UNSET))

        ak_share_equity_historical_data = cls(
            date=date,
            open_=open_,
            high=high,
            low=low,
            close=close,
            volume=volume,
            vwap=vwap,
            amount=amount,
            change=change,
            change_percent=change_percent,
        )

        ak_share_equity_historical_data.additional_properties = d
        return ak_share_equity_historical_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
