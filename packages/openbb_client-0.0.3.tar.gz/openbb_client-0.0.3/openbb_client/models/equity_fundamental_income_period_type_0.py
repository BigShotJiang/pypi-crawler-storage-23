from enum import Enum


class EquityFundamentalIncomePeriodType0(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"

    def __str__(self) -> str:
        return str(self.value)
