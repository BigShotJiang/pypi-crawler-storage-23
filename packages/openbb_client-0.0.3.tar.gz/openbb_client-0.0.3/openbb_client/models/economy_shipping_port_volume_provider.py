from enum import Enum


class EconomyShippingPortVolumeProvider(str, Enum):
    ECONDB = "econdb"
    IMF = "imf"

    def __str__(self) -> str:
        return str(self.value)
