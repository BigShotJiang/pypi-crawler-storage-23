from enum import Enum


class DerivativesOptionsSurfaceTheme(str, Enum):
    DARK = "dark"
    LIGHT = "light"

    def __str__(self) -> str:
        return str(self.value)
