from enum import Enum


class EconomyCpiProvider(str, Enum):
    FRED = "fred"
    IMF = "imf"
    OECD = "oecd"

    def __str__(self) -> str:
        return str(self.value)
