from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FederalReserveCentralBankHoldingsData")


@_attrs_define
class FederalReserveCentralBankHoldingsData:
    """Federal Reserve Central Bank Holdings Data.

    Attributes:
        date (datetime.date): The date of the data.
        security_type (None | str | Unset): Type of security - i.e. TIPs, FRNs, etc.
        description (None | str | Unset): Description of the security. Only returned for Agency securities.
        is_aggreated (Literal['Y'] | None | Unset): Whether the security is aggregated. Only returned for Agency
            securities.
        cusip (None | str | Unset):
        issuer (None | str | Unset): Issuer of the security.
        maturity_date (datetime.date | None | Unset): Maturity date of the security.
        term (None | str | Unset): Term of the security. Only returned for Agency securities.
        face_value (float | None | Unset): Current face value of the security (Thousands of $USD). Current face value of
            the securities, which is the remaining principal balance of the securities.
        par_value (float | None | Unset): Par value of the security (Thousands of $USD). Changes in par may reflect
            primary and secondary market transactions and/or custodial account activity.
        coupon (float | None | Unset): Coupon rate of the security.
        spread (float | None | Unset): Spread to the current reference rate, as determined at each security's initial
            auction.
        percent_outstanding (float | None | Unset): Total percent of the outstanding CUSIP issuance.
        bills (float | None | Unset): Treasury bills amount (Thousands of $USD). Only returned when 'summary' is True.
        frn (float | None | Unset): Floating rate Treasury notes amount (Thousands of $USD). Only returned when
            'summary' is True.
        notes_and_bonds (float | None | Unset): Treasuy Notes and bonds amount (Thousands of $USD). Only returned when
            'summary' is True.
        tips (float | None | Unset): Treasury inflation-protected securities amount (Thousands of $USD). Only returned
            when 'summary' is True.
        mbs (float | None | Unset): Mortgage-backed securities amount (Thousands of $USD). Only returned when 'summary'
            is True.
        cmbs (float | None | Unset): Commercial mortgage-backed securities amount (Thousands of $USD). Only returned
            when 'summary' is True.
        agencies (float | None | Unset): Agency securities amount (Thousands of $USD). Only returned when 'summary' is
            True.
        total (float | None | Unset): Total SOMA holdings amount (Thousands of $USD). Only returned when 'summary' is
            True.
        inflation_compensation (float | None | Unset): Treasury inflation-protected securities inflation compensation
            amount (Thousands of $USD). Only returned when 'summary' is True.
        change_prior_week (float | None | Unset): Change in SOMA holdings from the prior week (Thousands of $USD).
        change_prior_year (float | None | Unset): Change in SOMA holdings from the prior year (Thousands of $USD).
    """

    date: datetime.date
    security_type: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    is_aggreated: Literal["Y"] | None | Unset = UNSET
    cusip: None | str | Unset = UNSET
    issuer: None | str | Unset = UNSET
    maturity_date: datetime.date | None | Unset = UNSET
    term: None | str | Unset = UNSET
    face_value: float | None | Unset = UNSET
    par_value: float | None | Unset = UNSET
    coupon: float | None | Unset = UNSET
    spread: float | None | Unset = UNSET
    percent_outstanding: float | None | Unset = UNSET
    bills: float | None | Unset = UNSET
    frn: float | None | Unset = UNSET
    notes_and_bonds: float | None | Unset = UNSET
    tips: float | None | Unset = UNSET
    mbs: float | None | Unset = UNSET
    cmbs: float | None | Unset = UNSET
    agencies: float | None | Unset = UNSET
    total: float | None | Unset = UNSET
    inflation_compensation: float | None | Unset = UNSET
    change_prior_week: float | None | Unset = UNSET
    change_prior_year: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        security_type: None | str | Unset
        if isinstance(self.security_type, Unset):
            security_type = UNSET
        else:
            security_type = self.security_type

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_aggreated: Literal["Y"] | None | Unset
        if isinstance(self.is_aggreated, Unset):
            is_aggreated = UNSET
        else:
            is_aggreated = self.is_aggreated

        cusip: None | str | Unset
        if isinstance(self.cusip, Unset):
            cusip = UNSET
        else:
            cusip = self.cusip

        issuer: None | str | Unset
        if isinstance(self.issuer, Unset):
            issuer = UNSET
        else:
            issuer = self.issuer

        maturity_date: None | str | Unset
        if isinstance(self.maturity_date, Unset):
            maturity_date = UNSET
        elif isinstance(self.maturity_date, datetime.date):
            maturity_date = self.maturity_date.isoformat()
        else:
            maturity_date = self.maturity_date

        term: None | str | Unset
        if isinstance(self.term, Unset):
            term = UNSET
        else:
            term = self.term

        face_value: float | None | Unset
        if isinstance(self.face_value, Unset):
            face_value = UNSET
        else:
            face_value = self.face_value

        par_value: float | None | Unset
        if isinstance(self.par_value, Unset):
            par_value = UNSET
        else:
            par_value = self.par_value

        coupon: float | None | Unset
        if isinstance(self.coupon, Unset):
            coupon = UNSET
        else:
            coupon = self.coupon

        spread: float | None | Unset
        if isinstance(self.spread, Unset):
            spread = UNSET
        else:
            spread = self.spread

        percent_outstanding: float | None | Unset
        if isinstance(self.percent_outstanding, Unset):
            percent_outstanding = UNSET
        else:
            percent_outstanding = self.percent_outstanding

        bills: float | None | Unset
        if isinstance(self.bills, Unset):
            bills = UNSET
        else:
            bills = self.bills

        frn: float | None | Unset
        if isinstance(self.frn, Unset):
            frn = UNSET
        else:
            frn = self.frn

        notes_and_bonds: float | None | Unset
        if isinstance(self.notes_and_bonds, Unset):
            notes_and_bonds = UNSET
        else:
            notes_and_bonds = self.notes_and_bonds

        tips: float | None | Unset
        if isinstance(self.tips, Unset):
            tips = UNSET
        else:
            tips = self.tips

        mbs: float | None | Unset
        if isinstance(self.mbs, Unset):
            mbs = UNSET
        else:
            mbs = self.mbs

        cmbs: float | None | Unset
        if isinstance(self.cmbs, Unset):
            cmbs = UNSET
        else:
            cmbs = self.cmbs

        agencies: float | None | Unset
        if isinstance(self.agencies, Unset):
            agencies = UNSET
        else:
            agencies = self.agencies

        total: float | None | Unset
        if isinstance(self.total, Unset):
            total = UNSET
        else:
            total = self.total

        inflation_compensation: float | None | Unset
        if isinstance(self.inflation_compensation, Unset):
            inflation_compensation = UNSET
        else:
            inflation_compensation = self.inflation_compensation

        change_prior_week: float | None | Unset
        if isinstance(self.change_prior_week, Unset):
            change_prior_week = UNSET
        else:
            change_prior_week = self.change_prior_week

        change_prior_year: float | None | Unset
        if isinstance(self.change_prior_year, Unset):
            change_prior_year = UNSET
        else:
            change_prior_year = self.change_prior_year

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
            }
        )
        if security_type is not UNSET:
            field_dict["security_type"] = security_type
        if description is not UNSET:
            field_dict["description"] = description
        if is_aggreated is not UNSET:
            field_dict["is_aggreated"] = is_aggreated
        if cusip is not UNSET:
            field_dict["cusip"] = cusip
        if issuer is not UNSET:
            field_dict["issuer"] = issuer
        if maturity_date is not UNSET:
            field_dict["maturity_date"] = maturity_date
        if term is not UNSET:
            field_dict["term"] = term
        if face_value is not UNSET:
            field_dict["face_value"] = face_value
        if par_value is not UNSET:
            field_dict["par_value"] = par_value
        if coupon is not UNSET:
            field_dict["coupon"] = coupon
        if spread is not UNSET:
            field_dict["spread"] = spread
        if percent_outstanding is not UNSET:
            field_dict["percent_outstanding"] = percent_outstanding
        if bills is not UNSET:
            field_dict["bills"] = bills
        if frn is not UNSET:
            field_dict["frn"] = frn
        if notes_and_bonds is not UNSET:
            field_dict["notes_and_bonds"] = notes_and_bonds
        if tips is not UNSET:
            field_dict["tips"] = tips
        if mbs is not UNSET:
            field_dict["mbs"] = mbs
        if cmbs is not UNSET:
            field_dict["cmbs"] = cmbs
        if agencies is not UNSET:
            field_dict["agencies"] = agencies
        if total is not UNSET:
            field_dict["total"] = total
        if inflation_compensation is not UNSET:
            field_dict["inflationCompensation"] = inflation_compensation
        if change_prior_week is not UNSET:
            field_dict["change_prior_week"] = change_prior_week
        if change_prior_year is not UNSET:
            field_dict["change_prior_year"] = change_prior_year

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_security_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        security_type = _parse_security_type(d.pop("security_type", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_is_aggreated(data: object) -> Literal["Y"] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            is_aggreated_type_0 = cast(Literal["Y"], data)
            if is_aggreated_type_0 != "Y":
                raise ValueError(f"is_aggreated_type_0 must match const 'Y', got '{is_aggreated_type_0}'")
            return is_aggreated_type_0
            return cast(Literal["Y"] | None | Unset, data)

        is_aggreated = _parse_is_aggreated(d.pop("is_aggreated", UNSET))

        def _parse_cusip(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cusip = _parse_cusip(d.pop("cusip", UNSET))

        def _parse_issuer(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        issuer = _parse_issuer(d.pop("issuer", UNSET))

        def _parse_maturity_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                maturity_date_type_0 = isoparse(data).date()

                return maturity_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        maturity_date = _parse_maturity_date(d.pop("maturity_date", UNSET))

        def _parse_term(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        term = _parse_term(d.pop("term", UNSET))

        def _parse_face_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        face_value = _parse_face_value(d.pop("face_value", UNSET))

        def _parse_par_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        par_value = _parse_par_value(d.pop("par_value", UNSET))

        def _parse_coupon(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        coupon = _parse_coupon(d.pop("coupon", UNSET))

        def _parse_spread(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        spread = _parse_spread(d.pop("spread", UNSET))

        def _parse_percent_outstanding(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percent_outstanding = _parse_percent_outstanding(d.pop("percent_outstanding", UNSET))

        def _parse_bills(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        bills = _parse_bills(d.pop("bills", UNSET))

        def _parse_frn(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        frn = _parse_frn(d.pop("frn", UNSET))

        def _parse_notes_and_bonds(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        notes_and_bonds = _parse_notes_and_bonds(d.pop("notes_and_bonds", UNSET))

        def _parse_tips(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        tips = _parse_tips(d.pop("tips", UNSET))

        def _parse_mbs(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        mbs = _parse_mbs(d.pop("mbs", UNSET))

        def _parse_cmbs(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cmbs = _parse_cmbs(d.pop("cmbs", UNSET))

        def _parse_agencies(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        agencies = _parse_agencies(d.pop("agencies", UNSET))

        def _parse_total(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total = _parse_total(d.pop("total", UNSET))

        def _parse_inflation_compensation(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        inflation_compensation = _parse_inflation_compensation(d.pop("inflationCompensation", UNSET))

        def _parse_change_prior_week(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_prior_week = _parse_change_prior_week(d.pop("change_prior_week", UNSET))

        def _parse_change_prior_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_prior_year = _parse_change_prior_year(d.pop("change_prior_year", UNSET))

        federal_reserve_central_bank_holdings_data = cls(
            date=date,
            security_type=security_type,
            description=description,
            is_aggreated=is_aggreated,
            cusip=cusip,
            issuer=issuer,
            maturity_date=maturity_date,
            term=term,
            face_value=face_value,
            par_value=par_value,
            coupon=coupon,
            spread=spread,
            percent_outstanding=percent_outstanding,
            bills=bills,
            frn=frn,
            notes_and_bonds=notes_and_bonds,
            tips=tips,
            mbs=mbs,
            cmbs=cmbs,
            agencies=agencies,
            total=total,
            inflation_compensation=inflation_compensation,
            change_prior_week=change_prior_week,
            change_prior_year=change_prior_year,
        )

        federal_reserve_central_bank_holdings_data.additional_properties = d
        return federal_reserve_central_bank_holdings_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
