from enum import Enum


class EquityCalendarIpoStatusType0(str, Enum):
    PRICED = "priced"
    UPCOMING = "upcoming"
    WITHDRAWN = "withdrawn"

    def __str__(self) -> str:
        return str(self.value)
