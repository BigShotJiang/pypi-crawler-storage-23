from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="EconDbPortVolumeData")


@_attrs_define
class EconDbPortVolumeData:
    """EconDB Port Volume Data.

    Attributes:
        date (datetime.date): The date of the data.
        port_code (None | str | Unset): Port code.
        port_name (None | str | Unset): Port name.
        country (None | str | Unset): Country where the port is located.
        export_dwell_time (float | None | Unset): EconDB model estimate for the average number of days from when a
            container enters the terminal gates until it is loaded on a vessel. High dwelling times can indicate vessel
            delays.
        import_dwell_time (float | None | Unset): EconDB model estimate for the average number of days from when a
            container is discharged from a vessel until it exits the terminal gates. High dwelling times can indicate
            trucking or port congestion.
        import_teu (int | None | Unset): EconDB model estimate for the number of twenty-foot equivalent units (TEUs) of
            containers imported through the port.
        export_teu (int | None | Unset): EconDB model estimate for the number of twenty-foot equivalent units (TEUs) of
            containers exported through the port.
    """

    date: datetime.date
    port_code: None | str | Unset = UNSET
    port_name: None | str | Unset = UNSET
    country: None | str | Unset = UNSET
    export_dwell_time: float | None | Unset = UNSET
    import_dwell_time: float | None | Unset = UNSET
    import_teu: int | None | Unset = UNSET
    export_teu: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        port_code: None | str | Unset
        if isinstance(self.port_code, Unset):
            port_code = UNSET
        else:
            port_code = self.port_code

        port_name: None | str | Unset
        if isinstance(self.port_name, Unset):
            port_name = UNSET
        else:
            port_name = self.port_name

        country: None | str | Unset
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        export_dwell_time: float | None | Unset
        if isinstance(self.export_dwell_time, Unset):
            export_dwell_time = UNSET
        else:
            export_dwell_time = self.export_dwell_time

        import_dwell_time: float | None | Unset
        if isinstance(self.import_dwell_time, Unset):
            import_dwell_time = UNSET
        else:
            import_dwell_time = self.import_dwell_time

        import_teu: int | None | Unset
        if isinstance(self.import_teu, Unset):
            import_teu = UNSET
        else:
            import_teu = self.import_teu

        export_teu: int | None | Unset
        if isinstance(self.export_teu, Unset):
            export_teu = UNSET
        else:
            export_teu = self.export_teu

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
            }
        )
        if port_code is not UNSET:
            field_dict["port_code"] = port_code
        if port_name is not UNSET:
            field_dict["port_name"] = port_name
        if country is not UNSET:
            field_dict["country"] = country
        if export_dwell_time is not UNSET:
            field_dict["export_dwell_time"] = export_dwell_time
        if import_dwell_time is not UNSET:
            field_dict["import_dwell_time"] = import_dwell_time
        if import_teu is not UNSET:
            field_dict["import_teu"] = import_teu
        if export_teu is not UNSET:
            field_dict["export_teu"] = export_teu

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_port_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        port_code = _parse_port_code(d.pop("port_code", UNSET))

        def _parse_port_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        port_name = _parse_port_name(d.pop("port_name", UNSET))

        def _parse_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        country = _parse_country(d.pop("country", UNSET))

        def _parse_export_dwell_time(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        export_dwell_time = _parse_export_dwell_time(d.pop("export_dwell_time", UNSET))

        def _parse_import_dwell_time(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        import_dwell_time = _parse_import_dwell_time(d.pop("import_dwell_time", UNSET))

        def _parse_import_teu(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        import_teu = _parse_import_teu(d.pop("import_teu", UNSET))

        def _parse_export_teu(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        export_teu = _parse_export_teu(d.pop("export_teu", UNSET))

        econ_db_port_volume_data = cls(
            date=date,
            port_code=port_code,
            port_name=port_name,
            country=country,
            export_dwell_time=export_dwell_time,
            import_dwell_time=import_dwell_time,
            import_teu=import_teu,
            export_teu=export_teu,
        )

        econ_db_port_volume_data.additional_properties = d
        return econ_db_port_volume_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
