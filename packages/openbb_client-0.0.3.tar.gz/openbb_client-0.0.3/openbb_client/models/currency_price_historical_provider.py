from enum import Enum


class CurrencyPriceHistoricalProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    POLYGON = "polygon"
    TIINGO = "tiingo"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
