from enum import Enum


class EquityPricePerformanceProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"

    def __str__(self) -> str:
        return str(self.value)
