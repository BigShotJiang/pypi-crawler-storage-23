from enum import Enum


class EquityScreenerProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
