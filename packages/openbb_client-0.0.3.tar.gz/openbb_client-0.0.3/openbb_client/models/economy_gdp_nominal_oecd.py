from enum import Enum


class EconomyGdpNominalOecd(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"

    def __str__(self) -> str:
        return str(self.value)
