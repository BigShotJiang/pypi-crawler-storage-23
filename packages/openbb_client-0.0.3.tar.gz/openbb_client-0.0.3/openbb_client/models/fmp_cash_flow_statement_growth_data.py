from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCashFlowStatementGrowthData")


@_attrs_define
class FMPCashFlowStatementGrowthData:
    """FMP Cash Flow Statement Growth Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        symbol (str): Symbol representing the entity requested in the data.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        reported_currency (None | str | Unset): The currency in which the financial data is reported.
        growth_net_income (float | None | Unset): Growth rate of net income.
        growth_depreciation_and_amortization (float | None | Unset): Growth rate of depreciation and amortization.
        growth_deferred_income_tax (float | None | Unset): Growth rate of deferred income tax.
        growth_stock_based_compensation (float | None | Unset): Growth rate of stock-based compensation.
        growth_change_in_working_capital (float | None | Unset): Growth rate of change in working capital.
        growth_account_receivables (float | None | Unset): Growth rate of accounts receivables.
        growth_inventory (float | None | Unset): Growth rate of inventory.
        growth_account_payable (float | None | Unset): Growth rate of account payable.
        growth_other_working_capital (float | None | Unset): Growth rate of other working capital.
        growth_other_non_cash_items (float | None | Unset): Growth rate of other non-cash items.
        growth_net_cash_from_operating_activities (float | None | Unset): Growth rate of net cash provided by operating
            activities.
        growth_purchase_of_property_plant_and_equipment (float | None | Unset): Growth rate of investments in property,
            plant, and equipment.
        growth_acquisitions (float | None | Unset): Growth rate of net acquisitions.
        growth_purchase_of_investment_securities (float | None | Unset): Growth rate of purchases of investments.
        growth_sale_and_maturity_of_investments (float | None | Unset): Growth rate of sales maturities of investments.
        growth_other_investing_activities (float | None | Unset): Growth rate of other investing activities.
        growth_net_cash_from_investing_activities (float | None | Unset): Growth rate of net cash used for investing
            activities.
        growth_short_term_net_debt_issuance (float | None | Unset): Growth rate of short term net debt issuance.
        growth_long_term_net_debt_issuance (float | None | Unset): Growth rate of long term net debt issuance.
        growth_net_debt_issuance (float | None | Unset): Growth rate of net debt issuance.
        growth_repayment_of_debt (float | None | Unset): Growth rate of debt repayment.
        growth_common_equity_issuance (float | None | Unset): Growth rate of common equity issued.
        growth_common_equity_repurchased (float | None | Unset): Growth rate of common equity repurchased.
        growth_net_equity_issuance (float | None | Unset): Growth rate of net equity issuance.
        growth_dividends_paid (float | None | Unset): Growth rate of dividends paid.
        growth_preferred_dividends_paid (float | None | Unset): Growth rate of preferred dividends paid.
        growth_other_financing_activities (float | None | Unset): Growth rate of other financing activities.
        growth_net_cash_from_financing_activities (float | None | Unset): Growth rate of net cash used/provided by
            financing activities.
        growth_effect_of_exchange_rate_changes_on_cash (float | None | Unset): Growth rate of the effect of foreign
            exchange changes on cash.
        growth_net_change_in_cash_and_equivalents (float | None | Unset): Growth rate of net change in cash.
        growth_cash_at_beginning_of_period (float | None | Unset): Growth rate of cash at the beginning of the period.
        growth_cash_at_end_of_period (float | None | Unset): Growth rate of cash at the end of the period.
        growth_operating_cash_flow (float | None | Unset): Growth rate of operating cash flow.
        growth_capital_expenditure (float | None | Unset): Growth rate of capital expenditure.
        growth_income_taxes_paid (float | None | Unset): Growth rate of income taxes paid.
        growth_interest_paid (float | None | Unset): Growth rate of interest paid.
        growth_free_cash_flow (float | None | Unset): Growth rate of free cash flow.
    """

    period_ending: datetime.date
    symbol: str
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    reported_currency: None | str | Unset = UNSET
    growth_net_income: float | None | Unset = UNSET
    growth_depreciation_and_amortization: float | None | Unset = UNSET
    growth_deferred_income_tax: float | None | Unset = UNSET
    growth_stock_based_compensation: float | None | Unset = UNSET
    growth_change_in_working_capital: float | None | Unset = UNSET
    growth_account_receivables: float | None | Unset = UNSET
    growth_inventory: float | None | Unset = UNSET
    growth_account_payable: float | None | Unset = UNSET
    growth_other_working_capital: float | None | Unset = UNSET
    growth_other_non_cash_items: float | None | Unset = UNSET
    growth_net_cash_from_operating_activities: float | None | Unset = UNSET
    growth_purchase_of_property_plant_and_equipment: float | None | Unset = UNSET
    growth_acquisitions: float | None | Unset = UNSET
    growth_purchase_of_investment_securities: float | None | Unset = UNSET
    growth_sale_and_maturity_of_investments: float | None | Unset = UNSET
    growth_other_investing_activities: float | None | Unset = UNSET
    growth_net_cash_from_investing_activities: float | None | Unset = UNSET
    growth_short_term_net_debt_issuance: float | None | Unset = UNSET
    growth_long_term_net_debt_issuance: float | None | Unset = UNSET
    growth_net_debt_issuance: float | None | Unset = UNSET
    growth_repayment_of_debt: float | None | Unset = UNSET
    growth_common_equity_issuance: float | None | Unset = UNSET
    growth_common_equity_repurchased: float | None | Unset = UNSET
    growth_net_equity_issuance: float | None | Unset = UNSET
    growth_dividends_paid: float | None | Unset = UNSET
    growth_preferred_dividends_paid: float | None | Unset = UNSET
    growth_other_financing_activities: float | None | Unset = UNSET
    growth_net_cash_from_financing_activities: float | None | Unset = UNSET
    growth_effect_of_exchange_rate_changes_on_cash: float | None | Unset = UNSET
    growth_net_change_in_cash_and_equivalents: float | None | Unset = UNSET
    growth_cash_at_beginning_of_period: float | None | Unset = UNSET
    growth_cash_at_end_of_period: float | None | Unset = UNSET
    growth_operating_cash_flow: float | None | Unset = UNSET
    growth_capital_expenditure: float | None | Unset = UNSET
    growth_income_taxes_paid: float | None | Unset = UNSET
    growth_interest_paid: float | None | Unset = UNSET
    growth_free_cash_flow: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        symbol = self.symbol

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        reported_currency: None | str | Unset
        if isinstance(self.reported_currency, Unset):
            reported_currency = UNSET
        else:
            reported_currency = self.reported_currency

        growth_net_income: float | None | Unset
        if isinstance(self.growth_net_income, Unset):
            growth_net_income = UNSET
        else:
            growth_net_income = self.growth_net_income

        growth_depreciation_and_amortization: float | None | Unset
        if isinstance(self.growth_depreciation_and_amortization, Unset):
            growth_depreciation_and_amortization = UNSET
        else:
            growth_depreciation_and_amortization = self.growth_depreciation_and_amortization

        growth_deferred_income_tax: float | None | Unset
        if isinstance(self.growth_deferred_income_tax, Unset):
            growth_deferred_income_tax = UNSET
        else:
            growth_deferred_income_tax = self.growth_deferred_income_tax

        growth_stock_based_compensation: float | None | Unset
        if isinstance(self.growth_stock_based_compensation, Unset):
            growth_stock_based_compensation = UNSET
        else:
            growth_stock_based_compensation = self.growth_stock_based_compensation

        growth_change_in_working_capital: float | None | Unset
        if isinstance(self.growth_change_in_working_capital, Unset):
            growth_change_in_working_capital = UNSET
        else:
            growth_change_in_working_capital = self.growth_change_in_working_capital

        growth_account_receivables: float | None | Unset
        if isinstance(self.growth_account_receivables, Unset):
            growth_account_receivables = UNSET
        else:
            growth_account_receivables = self.growth_account_receivables

        growth_inventory: float | None | Unset
        if isinstance(self.growth_inventory, Unset):
            growth_inventory = UNSET
        else:
            growth_inventory = self.growth_inventory

        growth_account_payable: float | None | Unset
        if isinstance(self.growth_account_payable, Unset):
            growth_account_payable = UNSET
        else:
            growth_account_payable = self.growth_account_payable

        growth_other_working_capital: float | None | Unset
        if isinstance(self.growth_other_working_capital, Unset):
            growth_other_working_capital = UNSET
        else:
            growth_other_working_capital = self.growth_other_working_capital

        growth_other_non_cash_items: float | None | Unset
        if isinstance(self.growth_other_non_cash_items, Unset):
            growth_other_non_cash_items = UNSET
        else:
            growth_other_non_cash_items = self.growth_other_non_cash_items

        growth_net_cash_from_operating_activities: float | None | Unset
        if isinstance(self.growth_net_cash_from_operating_activities, Unset):
            growth_net_cash_from_operating_activities = UNSET
        else:
            growth_net_cash_from_operating_activities = self.growth_net_cash_from_operating_activities

        growth_purchase_of_property_plant_and_equipment: float | None | Unset
        if isinstance(self.growth_purchase_of_property_plant_and_equipment, Unset):
            growth_purchase_of_property_plant_and_equipment = UNSET
        else:
            growth_purchase_of_property_plant_and_equipment = self.growth_purchase_of_property_plant_and_equipment

        growth_acquisitions: float | None | Unset
        if isinstance(self.growth_acquisitions, Unset):
            growth_acquisitions = UNSET
        else:
            growth_acquisitions = self.growth_acquisitions

        growth_purchase_of_investment_securities: float | None | Unset
        if isinstance(self.growth_purchase_of_investment_securities, Unset):
            growth_purchase_of_investment_securities = UNSET
        else:
            growth_purchase_of_investment_securities = self.growth_purchase_of_investment_securities

        growth_sale_and_maturity_of_investments: float | None | Unset
        if isinstance(self.growth_sale_and_maturity_of_investments, Unset):
            growth_sale_and_maturity_of_investments = UNSET
        else:
            growth_sale_and_maturity_of_investments = self.growth_sale_and_maturity_of_investments

        growth_other_investing_activities: float | None | Unset
        if isinstance(self.growth_other_investing_activities, Unset):
            growth_other_investing_activities = UNSET
        else:
            growth_other_investing_activities = self.growth_other_investing_activities

        growth_net_cash_from_investing_activities: float | None | Unset
        if isinstance(self.growth_net_cash_from_investing_activities, Unset):
            growth_net_cash_from_investing_activities = UNSET
        else:
            growth_net_cash_from_investing_activities = self.growth_net_cash_from_investing_activities

        growth_short_term_net_debt_issuance: float | None | Unset
        if isinstance(self.growth_short_term_net_debt_issuance, Unset):
            growth_short_term_net_debt_issuance = UNSET
        else:
            growth_short_term_net_debt_issuance = self.growth_short_term_net_debt_issuance

        growth_long_term_net_debt_issuance: float | None | Unset
        if isinstance(self.growth_long_term_net_debt_issuance, Unset):
            growth_long_term_net_debt_issuance = UNSET
        else:
            growth_long_term_net_debt_issuance = self.growth_long_term_net_debt_issuance

        growth_net_debt_issuance: float | None | Unset
        if isinstance(self.growth_net_debt_issuance, Unset):
            growth_net_debt_issuance = UNSET
        else:
            growth_net_debt_issuance = self.growth_net_debt_issuance

        growth_repayment_of_debt: float | None | Unset
        if isinstance(self.growth_repayment_of_debt, Unset):
            growth_repayment_of_debt = UNSET
        else:
            growth_repayment_of_debt = self.growth_repayment_of_debt

        growth_common_equity_issuance: float | None | Unset
        if isinstance(self.growth_common_equity_issuance, Unset):
            growth_common_equity_issuance = UNSET
        else:
            growth_common_equity_issuance = self.growth_common_equity_issuance

        growth_common_equity_repurchased: float | None | Unset
        if isinstance(self.growth_common_equity_repurchased, Unset):
            growth_common_equity_repurchased = UNSET
        else:
            growth_common_equity_repurchased = self.growth_common_equity_repurchased

        growth_net_equity_issuance: float | None | Unset
        if isinstance(self.growth_net_equity_issuance, Unset):
            growth_net_equity_issuance = UNSET
        else:
            growth_net_equity_issuance = self.growth_net_equity_issuance

        growth_dividends_paid: float | None | Unset
        if isinstance(self.growth_dividends_paid, Unset):
            growth_dividends_paid = UNSET
        else:
            growth_dividends_paid = self.growth_dividends_paid

        growth_preferred_dividends_paid: float | None | Unset
        if isinstance(self.growth_preferred_dividends_paid, Unset):
            growth_preferred_dividends_paid = UNSET
        else:
            growth_preferred_dividends_paid = self.growth_preferred_dividends_paid

        growth_other_financing_activities: float | None | Unset
        if isinstance(self.growth_other_financing_activities, Unset):
            growth_other_financing_activities = UNSET
        else:
            growth_other_financing_activities = self.growth_other_financing_activities

        growth_net_cash_from_financing_activities: float | None | Unset
        if isinstance(self.growth_net_cash_from_financing_activities, Unset):
            growth_net_cash_from_financing_activities = UNSET
        else:
            growth_net_cash_from_financing_activities = self.growth_net_cash_from_financing_activities

        growth_effect_of_exchange_rate_changes_on_cash: float | None | Unset
        if isinstance(self.growth_effect_of_exchange_rate_changes_on_cash, Unset):
            growth_effect_of_exchange_rate_changes_on_cash = UNSET
        else:
            growth_effect_of_exchange_rate_changes_on_cash = self.growth_effect_of_exchange_rate_changes_on_cash

        growth_net_change_in_cash_and_equivalents: float | None | Unset
        if isinstance(self.growth_net_change_in_cash_and_equivalents, Unset):
            growth_net_change_in_cash_and_equivalents = UNSET
        else:
            growth_net_change_in_cash_and_equivalents = self.growth_net_change_in_cash_and_equivalents

        growth_cash_at_beginning_of_period: float | None | Unset
        if isinstance(self.growth_cash_at_beginning_of_period, Unset):
            growth_cash_at_beginning_of_period = UNSET
        else:
            growth_cash_at_beginning_of_period = self.growth_cash_at_beginning_of_period

        growth_cash_at_end_of_period: float | None | Unset
        if isinstance(self.growth_cash_at_end_of_period, Unset):
            growth_cash_at_end_of_period = UNSET
        else:
            growth_cash_at_end_of_period = self.growth_cash_at_end_of_period

        growth_operating_cash_flow: float | None | Unset
        if isinstance(self.growth_operating_cash_flow, Unset):
            growth_operating_cash_flow = UNSET
        else:
            growth_operating_cash_flow = self.growth_operating_cash_flow

        growth_capital_expenditure: float | None | Unset
        if isinstance(self.growth_capital_expenditure, Unset):
            growth_capital_expenditure = UNSET
        else:
            growth_capital_expenditure = self.growth_capital_expenditure

        growth_income_taxes_paid: float | None | Unset
        if isinstance(self.growth_income_taxes_paid, Unset):
            growth_income_taxes_paid = UNSET
        else:
            growth_income_taxes_paid = self.growth_income_taxes_paid

        growth_interest_paid: float | None | Unset
        if isinstance(self.growth_interest_paid, Unset):
            growth_interest_paid = UNSET
        else:
            growth_interest_paid = self.growth_interest_paid

        growth_free_cash_flow: float | None | Unset
        if isinstance(self.growth_free_cash_flow, Unset):
            growth_free_cash_flow = UNSET
        else:
            growth_free_cash_flow = self.growth_free_cash_flow

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
                "symbol": symbol,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if reported_currency is not UNSET:
            field_dict["reported_currency"] = reported_currency
        if growth_net_income is not UNSET:
            field_dict["growth_net_income"] = growth_net_income
        if growth_depreciation_and_amortization is not UNSET:
            field_dict["growth_depreciation_and_amortization"] = growth_depreciation_and_amortization
        if growth_deferred_income_tax is not UNSET:
            field_dict["growth_deferred_income_tax"] = growth_deferred_income_tax
        if growth_stock_based_compensation is not UNSET:
            field_dict["growth_stock_based_compensation"] = growth_stock_based_compensation
        if growth_change_in_working_capital is not UNSET:
            field_dict["growth_change_in_working_capital"] = growth_change_in_working_capital
        if growth_account_receivables is not UNSET:
            field_dict["growth_account_receivables"] = growth_account_receivables
        if growth_inventory is not UNSET:
            field_dict["growth_inventory"] = growth_inventory
        if growth_account_payable is not UNSET:
            field_dict["growth_account_payable"] = growth_account_payable
        if growth_other_working_capital is not UNSET:
            field_dict["growth_other_working_capital"] = growth_other_working_capital
        if growth_other_non_cash_items is not UNSET:
            field_dict["growth_other_non_cash_items"] = growth_other_non_cash_items
        if growth_net_cash_from_operating_activities is not UNSET:
            field_dict["growth_net_cash_from_operating_activities"] = growth_net_cash_from_operating_activities
        if growth_purchase_of_property_plant_and_equipment is not UNSET:
            field_dict["growth_purchase_of_property_plant_and_equipment"] = (
                growth_purchase_of_property_plant_and_equipment
            )
        if growth_acquisitions is not UNSET:
            field_dict["growth_acquisitions"] = growth_acquisitions
        if growth_purchase_of_investment_securities is not UNSET:
            field_dict["growth_purchase_of_investment_securities"] = growth_purchase_of_investment_securities
        if growth_sale_and_maturity_of_investments is not UNSET:
            field_dict["growth_sale_and_maturity_of_investments"] = growth_sale_and_maturity_of_investments
        if growth_other_investing_activities is not UNSET:
            field_dict["growth_other_investing_activities"] = growth_other_investing_activities
        if growth_net_cash_from_investing_activities is not UNSET:
            field_dict["growth_net_cash_from_investing_activities"] = growth_net_cash_from_investing_activities
        if growth_short_term_net_debt_issuance is not UNSET:
            field_dict["growth_short_term_net_debt_issuance"] = growth_short_term_net_debt_issuance
        if growth_long_term_net_debt_issuance is not UNSET:
            field_dict["growth_long_term_net_debt_issuance"] = growth_long_term_net_debt_issuance
        if growth_net_debt_issuance is not UNSET:
            field_dict["growth_net_debt_issuance"] = growth_net_debt_issuance
        if growth_repayment_of_debt is not UNSET:
            field_dict["growth_repayment_of_debt"] = growth_repayment_of_debt
        if growth_common_equity_issuance is not UNSET:
            field_dict["growth_common_equity_issuance"] = growth_common_equity_issuance
        if growth_common_equity_repurchased is not UNSET:
            field_dict["growth_common_equity_repurchased"] = growth_common_equity_repurchased
        if growth_net_equity_issuance is not UNSET:
            field_dict["growth_net_equity_issuance"] = growth_net_equity_issuance
        if growth_dividends_paid is not UNSET:
            field_dict["growth_dividends_paid"] = growth_dividends_paid
        if growth_preferred_dividends_paid is not UNSET:
            field_dict["growth_preferred_dividends_paid"] = growth_preferred_dividends_paid
        if growth_other_financing_activities is not UNSET:
            field_dict["growth_other_financing_activities"] = growth_other_financing_activities
        if growth_net_cash_from_financing_activities is not UNSET:
            field_dict["growth_net_cash_from_financing_activities"] = growth_net_cash_from_financing_activities
        if growth_effect_of_exchange_rate_changes_on_cash is not UNSET:
            field_dict["growth_effect_of_exchange_rate_changes_on_cash"] = (
                growth_effect_of_exchange_rate_changes_on_cash
            )
        if growth_net_change_in_cash_and_equivalents is not UNSET:
            field_dict["growth_net_change_in_cash_and_equivalents"] = growth_net_change_in_cash_and_equivalents
        if growth_cash_at_beginning_of_period is not UNSET:
            field_dict["growth_cash_at_beginning_of_period"] = growth_cash_at_beginning_of_period
        if growth_cash_at_end_of_period is not UNSET:
            field_dict["growth_cash_at_end_of_period"] = growth_cash_at_end_of_period
        if growth_operating_cash_flow is not UNSET:
            field_dict["growth_operating_cash_flow"] = growth_operating_cash_flow
        if growth_capital_expenditure is not UNSET:
            field_dict["growth_capital_expenditure"] = growth_capital_expenditure
        if growth_income_taxes_paid is not UNSET:
            field_dict["growth_income_taxes_paid"] = growth_income_taxes_paid
        if growth_interest_paid is not UNSET:
            field_dict["growth_interest_paid"] = growth_interest_paid
        if growth_free_cash_flow is not UNSET:
            field_dict["growth_free_cash_flow"] = growth_free_cash_flow

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        symbol = d.pop("symbol")

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_reported_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reported_currency = _parse_reported_currency(d.pop("reported_currency", UNSET))

        def _parse_growth_net_income(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_income = _parse_growth_net_income(d.pop("growth_net_income", UNSET))

        def _parse_growth_depreciation_and_amortization(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_depreciation_and_amortization = _parse_growth_depreciation_and_amortization(
            d.pop("growth_depreciation_and_amortization", UNSET)
        )

        def _parse_growth_deferred_income_tax(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_deferred_income_tax = _parse_growth_deferred_income_tax(d.pop("growth_deferred_income_tax", UNSET))

        def _parse_growth_stock_based_compensation(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_stock_based_compensation = _parse_growth_stock_based_compensation(
            d.pop("growth_stock_based_compensation", UNSET)
        )

        def _parse_growth_change_in_working_capital(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_change_in_working_capital = _parse_growth_change_in_working_capital(
            d.pop("growth_change_in_working_capital", UNSET)
        )

        def _parse_growth_account_receivables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_account_receivables = _parse_growth_account_receivables(d.pop("growth_account_receivables", UNSET))

        def _parse_growth_inventory(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_inventory = _parse_growth_inventory(d.pop("growth_inventory", UNSET))

        def _parse_growth_account_payable(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_account_payable = _parse_growth_account_payable(d.pop("growth_account_payable", UNSET))

        def _parse_growth_other_working_capital(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_working_capital = _parse_growth_other_working_capital(d.pop("growth_other_working_capital", UNSET))

        def _parse_growth_other_non_cash_items(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_non_cash_items = _parse_growth_other_non_cash_items(d.pop("growth_other_non_cash_items", UNSET))

        def _parse_growth_net_cash_from_operating_activities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_cash_from_operating_activities = _parse_growth_net_cash_from_operating_activities(
            d.pop("growth_net_cash_from_operating_activities", UNSET)
        )

        def _parse_growth_purchase_of_property_plant_and_equipment(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_purchase_of_property_plant_and_equipment = _parse_growth_purchase_of_property_plant_and_equipment(
            d.pop("growth_purchase_of_property_plant_and_equipment", UNSET)
        )

        def _parse_growth_acquisitions(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_acquisitions = _parse_growth_acquisitions(d.pop("growth_acquisitions", UNSET))

        def _parse_growth_purchase_of_investment_securities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_purchase_of_investment_securities = _parse_growth_purchase_of_investment_securities(
            d.pop("growth_purchase_of_investment_securities", UNSET)
        )

        def _parse_growth_sale_and_maturity_of_investments(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_sale_and_maturity_of_investments = _parse_growth_sale_and_maturity_of_investments(
            d.pop("growth_sale_and_maturity_of_investments", UNSET)
        )

        def _parse_growth_other_investing_activities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_investing_activities = _parse_growth_other_investing_activities(
            d.pop("growth_other_investing_activities", UNSET)
        )

        def _parse_growth_net_cash_from_investing_activities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_cash_from_investing_activities = _parse_growth_net_cash_from_investing_activities(
            d.pop("growth_net_cash_from_investing_activities", UNSET)
        )

        def _parse_growth_short_term_net_debt_issuance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_short_term_net_debt_issuance = _parse_growth_short_term_net_debt_issuance(
            d.pop("growth_short_term_net_debt_issuance", UNSET)
        )

        def _parse_growth_long_term_net_debt_issuance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_long_term_net_debt_issuance = _parse_growth_long_term_net_debt_issuance(
            d.pop("growth_long_term_net_debt_issuance", UNSET)
        )

        def _parse_growth_net_debt_issuance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_debt_issuance = _parse_growth_net_debt_issuance(d.pop("growth_net_debt_issuance", UNSET))

        def _parse_growth_repayment_of_debt(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_repayment_of_debt = _parse_growth_repayment_of_debt(d.pop("growth_repayment_of_debt", UNSET))

        def _parse_growth_common_equity_issuance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_common_equity_issuance = _parse_growth_common_equity_issuance(
            d.pop("growth_common_equity_issuance", UNSET)
        )

        def _parse_growth_common_equity_repurchased(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_common_equity_repurchased = _parse_growth_common_equity_repurchased(
            d.pop("growth_common_equity_repurchased", UNSET)
        )

        def _parse_growth_net_equity_issuance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_equity_issuance = _parse_growth_net_equity_issuance(d.pop("growth_net_equity_issuance", UNSET))

        def _parse_growth_dividends_paid(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_dividends_paid = _parse_growth_dividends_paid(d.pop("growth_dividends_paid", UNSET))

        def _parse_growth_preferred_dividends_paid(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_preferred_dividends_paid = _parse_growth_preferred_dividends_paid(
            d.pop("growth_preferred_dividends_paid", UNSET)
        )

        def _parse_growth_other_financing_activities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_financing_activities = _parse_growth_other_financing_activities(
            d.pop("growth_other_financing_activities", UNSET)
        )

        def _parse_growth_net_cash_from_financing_activities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_cash_from_financing_activities = _parse_growth_net_cash_from_financing_activities(
            d.pop("growth_net_cash_from_financing_activities", UNSET)
        )

        def _parse_growth_effect_of_exchange_rate_changes_on_cash(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_effect_of_exchange_rate_changes_on_cash = _parse_growth_effect_of_exchange_rate_changes_on_cash(
            d.pop("growth_effect_of_exchange_rate_changes_on_cash", UNSET)
        )

        def _parse_growth_net_change_in_cash_and_equivalents(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_change_in_cash_and_equivalents = _parse_growth_net_change_in_cash_and_equivalents(
            d.pop("growth_net_change_in_cash_and_equivalents", UNSET)
        )

        def _parse_growth_cash_at_beginning_of_period(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_cash_at_beginning_of_period = _parse_growth_cash_at_beginning_of_period(
            d.pop("growth_cash_at_beginning_of_period", UNSET)
        )

        def _parse_growth_cash_at_end_of_period(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_cash_at_end_of_period = _parse_growth_cash_at_end_of_period(d.pop("growth_cash_at_end_of_period", UNSET))

        def _parse_growth_operating_cash_flow(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_operating_cash_flow = _parse_growth_operating_cash_flow(d.pop("growth_operating_cash_flow", UNSET))

        def _parse_growth_capital_expenditure(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_capital_expenditure = _parse_growth_capital_expenditure(d.pop("growth_capital_expenditure", UNSET))

        def _parse_growth_income_taxes_paid(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_income_taxes_paid = _parse_growth_income_taxes_paid(d.pop("growth_income_taxes_paid", UNSET))

        def _parse_growth_interest_paid(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_interest_paid = _parse_growth_interest_paid(d.pop("growth_interest_paid", UNSET))

        def _parse_growth_free_cash_flow(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_free_cash_flow = _parse_growth_free_cash_flow(d.pop("growth_free_cash_flow", UNSET))

        fmp_cash_flow_statement_growth_data = cls(
            period_ending=period_ending,
            symbol=symbol,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            reported_currency=reported_currency,
            growth_net_income=growth_net_income,
            growth_depreciation_and_amortization=growth_depreciation_and_amortization,
            growth_deferred_income_tax=growth_deferred_income_tax,
            growth_stock_based_compensation=growth_stock_based_compensation,
            growth_change_in_working_capital=growth_change_in_working_capital,
            growth_account_receivables=growth_account_receivables,
            growth_inventory=growth_inventory,
            growth_account_payable=growth_account_payable,
            growth_other_working_capital=growth_other_working_capital,
            growth_other_non_cash_items=growth_other_non_cash_items,
            growth_net_cash_from_operating_activities=growth_net_cash_from_operating_activities,
            growth_purchase_of_property_plant_and_equipment=growth_purchase_of_property_plant_and_equipment,
            growth_acquisitions=growth_acquisitions,
            growth_purchase_of_investment_securities=growth_purchase_of_investment_securities,
            growth_sale_and_maturity_of_investments=growth_sale_and_maturity_of_investments,
            growth_other_investing_activities=growth_other_investing_activities,
            growth_net_cash_from_investing_activities=growth_net_cash_from_investing_activities,
            growth_short_term_net_debt_issuance=growth_short_term_net_debt_issuance,
            growth_long_term_net_debt_issuance=growth_long_term_net_debt_issuance,
            growth_net_debt_issuance=growth_net_debt_issuance,
            growth_repayment_of_debt=growth_repayment_of_debt,
            growth_common_equity_issuance=growth_common_equity_issuance,
            growth_common_equity_repurchased=growth_common_equity_repurchased,
            growth_net_equity_issuance=growth_net_equity_issuance,
            growth_dividends_paid=growth_dividends_paid,
            growth_preferred_dividends_paid=growth_preferred_dividends_paid,
            growth_other_financing_activities=growth_other_financing_activities,
            growth_net_cash_from_financing_activities=growth_net_cash_from_financing_activities,
            growth_effect_of_exchange_rate_changes_on_cash=growth_effect_of_exchange_rate_changes_on_cash,
            growth_net_change_in_cash_and_equivalents=growth_net_change_in_cash_and_equivalents,
            growth_cash_at_beginning_of_period=growth_cash_at_beginning_of_period,
            growth_cash_at_end_of_period=growth_cash_at_end_of_period,
            growth_operating_cash_flow=growth_operating_cash_flow,
            growth_capital_expenditure=growth_capital_expenditure,
            growth_income_taxes_paid=growth_income_taxes_paid,
            growth_interest_paid=growth_interest_paid,
            growth_free_cash_flow=growth_free_cash_flow,
        )

        fmp_cash_flow_statement_growth_data.additional_properties = d
        return fmp_cash_flow_statement_growth_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
