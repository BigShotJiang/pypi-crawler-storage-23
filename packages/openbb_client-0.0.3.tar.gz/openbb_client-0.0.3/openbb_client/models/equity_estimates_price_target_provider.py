from enum import Enum


class EquityEstimatesPriceTargetProvider(str, Enum):
    BENZINGA = "benzinga"
    FMP = "fmp"

    def __str__(self) -> str:
        return str(self.value)
