from enum import Enum


class FixedincomeSpreadsTcmMaturityType0(str, Enum):
    VALUE_0 = "3m"
    VALUE_1 = "2y"

    def __str__(self) -> str:
        return str(self.value)
