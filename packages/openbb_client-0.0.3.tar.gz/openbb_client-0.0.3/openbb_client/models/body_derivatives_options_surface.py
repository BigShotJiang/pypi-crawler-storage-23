from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.body_derivatives_options_surface_chart_params_type_0 import (
        BodyDerivativesOptionsSurfaceChartParamsType0,
    )
    from ..models.data import Data


T = TypeVar("T", bound="BodyDerivativesOptionsSurface")


@_attrs_define
class BodyDerivativesOptionsSurface:
    """
    Attributes:
        data (Data | list[Data]):
        chart_params (BodyDerivativesOptionsSurfaceChartParamsType0 | None | Unset):
    """

    data: Data | list[Data]
    chart_params: BodyDerivativesOptionsSurfaceChartParamsType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.body_derivatives_options_surface_chart_params_type_0 import (
            BodyDerivativesOptionsSurfaceChartParamsType0,
        )

        data: dict[str, Any] | list[dict[str, Any]]
        if isinstance(self.data, list):
            data = []
            for data_type_0_item_data in self.data:
                data_type_0_item = data_type_0_item_data.to_dict()
                data.append(data_type_0_item)

        else:
            data = self.data.to_dict()

        chart_params: dict[str, Any] | None | Unset
        if isinstance(self.chart_params, Unset):
            chart_params = UNSET
        elif isinstance(self.chart_params, BodyDerivativesOptionsSurfaceChartParamsType0):
            chart_params = self.chart_params.to_dict()
        else:
            chart_params = self.chart_params

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "data": data,
            }
        )
        if chart_params is not UNSET:
            field_dict["chart_params"] = chart_params

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.body_derivatives_options_surface_chart_params_type_0 import (
            BodyDerivativesOptionsSurfaceChartParamsType0,
        )
        from ..models.data import Data

        d = dict(src_dict)

        def _parse_data(data: object) -> Data | list[Data]:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                data_type_0 = []
                _data_type_0 = data
                for data_type_0_item_data in _data_type_0:
                    data_type_0_item = Data.from_dict(data_type_0_item_data)

                    data_type_0.append(data_type_0_item)

                return data_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            data_type_1 = Data.from_dict(data)

            return data_type_1

        data = _parse_data(d.pop("data"))

        def _parse_chart_params(data: object) -> BodyDerivativesOptionsSurfaceChartParamsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_params_type_0 = BodyDerivativesOptionsSurfaceChartParamsType0.from_dict(data)

                return chart_params_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BodyDerivativesOptionsSurfaceChartParamsType0 | None | Unset, data)

        chart_params = _parse_chart_params(d.pop("chart_params", UNSET))

        body_derivatives_options_surface = cls(
            data=data,
            chart_params=chart_params,
        )

        body_derivatives_options_surface.additional_properties = d
        return body_derivatives_options_surface

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
