from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="EconDbExportDestinationsData")


@_attrs_define
class EconDbExportDestinationsData:
    """EconDB Export Destinations Data.

    Attributes:
        origin_country (str): The country of origin.
        destination_country (str): The destination country.
        value (float | int): The value of the export.
        units (str): The units of measurement for the value.
        title (str): The title of the data.
        footnote (None | str): The footnote for the data.
    """

    origin_country: str
    destination_country: str
    value: float | int
    units: str
    title: str
    footnote: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        origin_country = self.origin_country

        destination_country = self.destination_country

        value: float | int
        value = self.value

        units = self.units

        title = self.title

        footnote: None | str
        footnote = self.footnote

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "origin_country": origin_country,
                "destination_country": destination_country,
                "value": value,
                "units": units,
                "title": title,
                "footnote": footnote,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        origin_country = d.pop("origin_country")

        destination_country = d.pop("destination_country")

        def _parse_value(data: object) -> float | int:
            return cast(float | int, data)

        value = _parse_value(d.pop("value"))

        units = d.pop("units")

        title = d.pop("title")

        def _parse_footnote(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        footnote = _parse_footnote(d.pop("footnote"))

        econ_db_export_destinations_data = cls(
            origin_country=origin_country,
            destination_country=destination_country,
            value=value,
            units=units,
            title=title,
            footnote=footnote,
        )

        econ_db_export_destinations_data.additional_properties = d
        return econ_db_export_destinations_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
