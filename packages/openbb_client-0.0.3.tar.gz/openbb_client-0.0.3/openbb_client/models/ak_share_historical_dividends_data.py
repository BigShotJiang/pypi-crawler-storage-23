from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareHistoricalDividendsData")


@_attrs_define
class AKShareHistoricalDividendsData:
    """AKShare Historical Dividends Data. All data is split-adjusted.

    Attributes:
        ex_dividend_date (datetime.date): The ex-dividend date - the date on which the stock begins trading without
            rights to the dividend.
        amount (float): The dividend amount per share.
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        reported_date (datetime.date | None | Unset): Earnings Announcement Date.
        description (None | str | Unset): Record date of the historical dividends.
        record_date (datetime.date | None | Unset): Record date of the historical dividends.
        declaration_date (datetime.date | None | Unset): Declaration date of the historical dividends.
    """

    ex_dividend_date: datetime.date
    amount: float
    symbol: None | str | Unset = UNSET
    reported_date: datetime.date | None | Unset = UNSET
    description: None | str | Unset = UNSET
    record_date: datetime.date | None | Unset = UNSET
    declaration_date: datetime.date | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ex_dividend_date = self.ex_dividend_date.isoformat()

        amount = self.amount

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        reported_date: None | str | Unset
        if isinstance(self.reported_date, Unset):
            reported_date = UNSET
        elif isinstance(self.reported_date, datetime.date):
            reported_date = self.reported_date.isoformat()
        else:
            reported_date = self.reported_date

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        record_date: None | str | Unset
        if isinstance(self.record_date, Unset):
            record_date = UNSET
        elif isinstance(self.record_date, datetime.date):
            record_date = self.record_date.isoformat()
        else:
            record_date = self.record_date

        declaration_date: None | str | Unset
        if isinstance(self.declaration_date, Unset):
            declaration_date = UNSET
        elif isinstance(self.declaration_date, datetime.date):
            declaration_date = self.declaration_date.isoformat()
        else:
            declaration_date = self.declaration_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ex_dividend_date": ex_dividend_date,
                "amount": amount,
            }
        )
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if reported_date is not UNSET:
            field_dict["reported_date"] = reported_date
        if description is not UNSET:
            field_dict["description"] = description
        if record_date is not UNSET:
            field_dict["record_date"] = record_date
        if declaration_date is not UNSET:
            field_dict["declaration_date"] = declaration_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ex_dividend_date = isoparse(d.pop("ex_dividend_date")).date()

        amount = d.pop("amount")

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_reported_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                reported_date_type_0 = isoparse(data).date()

                return reported_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        reported_date = _parse_reported_date(d.pop("reported_date", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_record_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                record_date_type_0 = isoparse(data).date()

                return record_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        record_date = _parse_record_date(d.pop("record_date", UNSET))

        def _parse_declaration_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                declaration_date_type_0 = isoparse(data).date()

                return declaration_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        declaration_date = _parse_declaration_date(d.pop("declaration_date", UNSET))

        ak_share_historical_dividends_data = cls(
            ex_dividend_date=ex_dividend_date,
            amount=amount,
            symbol=symbol,
            reported_date=reported_date,
            description=description,
            record_date=record_date,
            declaration_date=declaration_date,
        )

        ak_share_historical_dividends_data.additional_properties = d
        return ak_share_historical_dividends_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
