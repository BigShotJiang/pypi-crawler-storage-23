from enum import Enum


class DerivativesOptionsUnusualTradeTypeType0(str, Enum):
    BLOCK = "block"
    LARGE = "large"
    SWEEP = "sweep"

    def __str__(self) -> str:
        return str(self.value)
