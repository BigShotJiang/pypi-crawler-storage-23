from enum import Enum


class EconomyGdpNominalProvider(str, Enum):
    ECONDB = "econdb"
    OECD = "oecd"

    def __str__(self) -> str:
        return str(self.value)
