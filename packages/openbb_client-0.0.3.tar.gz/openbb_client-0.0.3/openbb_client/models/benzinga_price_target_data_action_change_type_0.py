from enum import Enum


class BenzingaPriceTargetDataActionChangeType0(str, Enum):
    ADJUSTS = "Adjusts"
    ANNOUNCES = "Announces"
    LOWERS = "Lowers"
    MAINTAINS = "Maintains"
    RAISES = "Raises"
    REMOVES = "Removes"

    def __str__(self) -> str:
        return str(self.value)
