#! /bin/bash

cd ../..
pet tests/snippet/snippet_test.md.pet tests/snippet/snippet_test.md