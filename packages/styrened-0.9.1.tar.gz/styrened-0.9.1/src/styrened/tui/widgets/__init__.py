"""Styrene TUI widgets.

Custom Textual widgets for the fleet management interface.
"""

from styrened.tui.widgets.hardware_panel import HardwarePanel
from styrened.tui.widgets.reticulum_panel import ReticulumPanel

__all__ = [
    "HardwarePanel",
    "ReticulumPanel",
]
