"""Forge — device provisioning and media creation.

Extracted from styrene-edge for integration into the TUI.
Provides device profiles, media writing, bundle building,
and disk detection for edge fleet provisioning.
"""

__version__ = "0.1.0"
