from .base import fetch, BASE_URL
from urllib.parse import quote


class LeaderboardAPI:
    async def global_pp(self, limit: int = 50, offset: int = 0) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/leaderboard?limit={limit}&offset={offset}&sortBy=totalPP")

    async def global_score(self, limit: int = 50, offset: int = 0) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/leaderboard?limit={limit}&offset={offset}&sortBy=rankedScore")

    async def country_pp(self, country: str, limit: int = 50, offset: int = 0) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/leaderboard?limit={limit}&offset={offset}&country={country}&sortBy=totalPP")

    async def country_score(self, country: str, limit: int = 50, offset: int = 0) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/leaderboard?limit={limit}&offset={offset}&country={country}&sortBy=rankedScore")

    async def beatmap(self, beatmap_id: str, difficulty: str, limit: int = 50) -> dict | None:
        encoded_diff = quote(difficulty)
        return await fetch(f"{BASE_URL}/v2/beatmap/{beatmap_id}/leaderboard?difficulty={encoded_diff}&limit={limit}")