from .base import fetch, BASE_URL


class UsersAPI:
    async def get_profile(self, user_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/profile/{user_id}")

    async def get_topbar(self, user_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/user/{user_id}/topbar")

    async def first_place_scores(self, user_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/user/{user_id}/firstPlaceScores")

    async def activity_heatmap(self, user_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/stats/{user_id}/charts?type=heatmap")

    async def most_played(self, user_id: str, limit: int = 50) -> dict | None:
        return await fetch(f"{BASE_URL}/getMostPlayedBeatmaps/{user_id}?limit={limit}")

    async def mapped_beatmaps(self, user_id: str, limit: int = 50) -> dict | None:
        return await fetch(f"{BASE_URL}/getBeatmaps?mapperId={user_id}&limit={limit}")

    async def search(self, query: str, limit: int = 10) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/users/search?query={query}&limit={limit}")