from .base import fetch, BASE_URL
from urllib.parse import urlencode


class BeatmapsAPI:
    async def get(self, beatmap_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/getBeatmaps?limit=1&mapsetId={beatmap_id}")

    async def get_many(
        self,
        limit: int = 12,
        cursor: str | None = None,
        status: str = "ranked",
        sort_by: str = "relevance",
        show_explicit: bool = True,
        language: str = "all",
    ) -> dict | None:
        params: dict = {
            "limit": limit,
            "status": status,
            "sortBy": sort_by,
            "showExplicit": str(show_explicit).lower(),
            "language": language,
        }
        if cursor:
            params["cursor"] = cursor
        return await fetch(f"{BASE_URL}/getBeatmaps?{urlencode(params)}")

    async def get_difficulties(self, beatmap_id: str) -> dict | None:
        return await fetch(f"{BASE_URL}/v2/beatmap/{beatmap_id}/difficulties")

    async def get_comments(self, beatmap_id: str, limit: int = 50) -> dict | None:
        return await fetch(f"{BASE_URL}/getComments/{beatmap_id}?limit={limit}")