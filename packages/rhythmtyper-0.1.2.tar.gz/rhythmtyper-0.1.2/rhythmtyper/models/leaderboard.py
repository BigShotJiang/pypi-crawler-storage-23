from dataclasses import dataclass
from typing import Optional


@dataclass
class GlobalLeaderboardEntry:
    rank: int
    user_id: str
    username: str
    total_pp: float
    accuracy: float
    play_count: int
    play_time: int
    ranked_score: int
    country: str
    profile_picture_url: Optional[str]
    rank_change: Optional[int]
    previous_rank: Optional[int]

    @classmethod
    def from_dict(cls, data: dict) -> "GlobalLeaderboardEntry":
        return cls(
            rank=data.get("rank", 0),
            user_id=data.get("userId", ""),
            username=data.get("username", ""),
            total_pp=data.get("totalPP", 0.0),
            accuracy=data.get("accuracy", 0.0),
            play_count=data.get("playCount", 0),
            play_time=data.get("playTime", 0),
            ranked_score=data.get("rankedScore", 0),
            country=data.get("country", ""),
            profile_picture_url=data.get("profilePictureUrl"),
            rank_change=data.get("rankChange"),
            previous_rank=data.get("previousRank"),
        )