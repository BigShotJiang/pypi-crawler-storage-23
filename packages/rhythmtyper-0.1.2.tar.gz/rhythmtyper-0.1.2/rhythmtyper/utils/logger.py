import logging

logger = logging.getLogger("rhythmtyper")
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(handler)

def info(msg: str) -> None:  logger.info(msg)
def warn(msg: str) -> None:  logger.warning(msg)
def error(msg: str) -> None: logger.error(msg)
def debug(msg: str) -> None: logger.debug(msg)