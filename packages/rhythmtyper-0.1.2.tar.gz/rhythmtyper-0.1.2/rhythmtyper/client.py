from .api.base import close_session
from .api.users import UsersAPI
from .api.beatmaps import BeatmapsAPI
from .api.leaderboard import LeaderboardAPI


class RhythmTyperClient:
    def __init__(self):
        self.users = UsersAPI()
        self.beatmaps = BeatmapsAPI()
        self.leaderboard = LeaderboardAPI()

    async def close(self) -> None:
        await close_session()

    async def __aenter__(self) -> "RhythmTyperClient":
        return self

    async def __aexit__(self, *_) -> None:
        await self.close()