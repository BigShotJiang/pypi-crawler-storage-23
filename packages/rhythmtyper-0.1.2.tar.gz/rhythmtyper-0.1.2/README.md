# rhythmtyper.py

An async Python wrapper for the [RhythmTyper](https://rhythmtyper.net) API.

## Installation

```bash
pip install rhythmtyper
```

## Usage

```python
import asyncio
from rhythmtyper import RhythmTyperClient

async def main():
    async with RhythmTyperClient() as client:
        # Users
        profile = await client.users.get_profile("user_id")
        topbar  = await client.users.get_topbar("user_id")
        results = await client.users.search("username")

        # Beatmaps
        beatmap = await client.beatmaps.get("beatmap_id")
        ranked, has_more, cursor = await client.beatmaps.get_many(status="ranked", limit=12)
        diffs   = await client.beatmaps.get_difficulties("beatmap_id")

        # Leaderboards
        global_lb  = await client.leaderboard.global_pp(limit=50)
        country_lb = await client.leaderboard.country_pp("DK", limit=50)
        map_lb     = await client.leaderboard.beatmap("beatmap_id", difficulty="Hard")

asyncio.run(main())
```

## License

MIT