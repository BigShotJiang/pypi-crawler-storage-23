"""Integration tests against a running GizmoSQL Docker container.

These tests require Docker to be running and are marked with
``@pytest.mark.integration``. Skip them with:
    pytest -m "not integration"
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.integration


@pytest.fixture(scope="session")
def conn(gizmosql_server, gizmosql_uri):
    """Create a DBAPI connection to the test GizmoSQL server."""
    from conftest import GIZMOSQL_PASSWORD, GIZMOSQL_USERNAME

    from adbc_driver_gizmosql import dbapi as gizmosql

    with gizmosql.connect(
        gizmosql_uri,
        username=GIZMOSQL_USERNAME,
        password=GIZMOSQL_PASSWORD,
        tls_skip_verify=True,
    ) as connection:
        yield connection


class TestPasswordAuth:
    """Test password-based authentication and basic queries."""

    def test_select_one(self, conn):
        with conn.cursor() as cur:
            cur.execute("SELECT 1 AS value")
            table = cur.fetch_arrow_table()
            assert table.num_rows == 1
            assert table.column("value")[0].as_py() == 1

    def test_gizmosql_version(self, conn):
        with conn.cursor() as cur:
            cur.execute("SELECT GIZMOSQL_VERSION() AS version")
            table = cur.fetch_arrow_table()
            assert table.num_rows == 1
            version = table.column("version")[0].as_py()
            assert isinstance(version, str)
            assert len(version) > 0

    def test_parameterized_query(self, conn):
        with conn.cursor() as cur:
            cur.execute(
                "SELECT n_nationkey, n_name FROM nation WHERE n_nationkey = ?",
                parameters=[24],
            )
            table = cur.fetch_arrow_table()
            assert table.num_rows == 1
            assert table.column("n_nationkey")[0].as_py() == 24

    def test_fetch_arrow_table_type(self, conn):
        import pyarrow as pa

        with conn.cursor() as cur:
            cur.execute("SELECT 1 AS a, 'hello' AS b")
            table = cur.fetch_arrow_table()
            assert isinstance(table, pa.Table)
            assert table.schema.names == ["a", "b"]

    def test_multiple_rows(self, conn):
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM nation ORDER BY n_nationkey LIMIT 5")
            table = cur.fetch_arrow_table()
            assert table.num_rows == 5


class TestExecuteUpdate:
    """Test execute_update() for DDL/DML that fires immediately."""

    def test_create_insert_query_drop(self, conn):
        from adbc_driver_gizmosql import dbapi as gizmosql

        with conn.cursor() as cur:
            # DDL — CREATE TABLE
            result = gizmosql.execute_update(
                cur, "CREATE TABLE test_exec_update (id INT, name VARCHAR)"
            )
            # DDL typically returns -1 (no row count)
            assert isinstance(result, int)

        try:
            with conn.cursor() as cur:
                # DML — INSERT single row
                rows = gizmosql.execute_update(
                    cur,
                    "INSERT INTO test_exec_update VALUES (1, 'alice')",
                )
                assert rows == 1

                # DML — INSERT another row
                rows = gizmosql.execute_update(
                    cur,
                    "INSERT INTO test_exec_update VALUES (2, 'bob')",
                )
                assert rows == 1

            # Verify the data was actually written
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT id, name FROM test_exec_update ORDER BY id"
                )
                table = cur.fetch_arrow_table()
                assert table.num_rows == 2
                assert table.column("id")[0].as_py() == 1
                assert table.column("name")[1].as_py() == "bob"
        finally:
            # Clean up
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_exec_update")

    def test_update_returns_rows_affected(self, conn):
        from adbc_driver_gizmosql import dbapi as gizmosql

        with conn.cursor() as cur:
            gizmosql.execute_update(
                cur, "CREATE TABLE test_eu_update (val INT)"
            )

        try:
            with conn.cursor() as cur:
                gizmosql.execute_update(
                    cur, "INSERT INTO test_eu_update VALUES (1)"
                )
                gizmosql.execute_update(
                    cur, "INSERT INTO test_eu_update VALUES (2)"
                )
                gizmosql.execute_update(
                    cur, "INSERT INTO test_eu_update VALUES (3)"
                )

            with conn.cursor() as cur:
                rows = gizmosql.execute_update(
                    cur, "DELETE FROM test_eu_update WHERE val >= 2"
                )
                assert rows == 2
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_eu_update")


class TestBulkIngest:
    """Test ADBC bulk ingest (adbc_ingest) for loading Arrow data into tables."""

    def test_ingest_create(self, conn):
        """Test mode='create' — creates a new table and inserts data."""
        import pyarrow as pa

        from adbc_driver_gizmosql import dbapi as gizmosql

        table = pa.table({
            "id": [1, 2, 3],
            "name": ["alice", "bob", "charlie"],
        })

        with conn.cursor() as cur:
            cur.adbc_ingest("test_ingest_create", table, mode="create")

        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, name FROM test_ingest_create ORDER BY id")
                result = cur.fetch_arrow_table()
                assert result.num_rows == 3
                assert result.column("id").to_pylist() == [1, 2, 3]
                assert result.column("name").to_pylist() == ["alice", "bob", "charlie"]
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_ingest_create")

    def test_ingest_append(self, conn):
        """Test mode='append' — appends data to an existing table."""
        import pyarrow as pa

        from adbc_driver_gizmosql import dbapi as gizmosql

        with conn.cursor() as cur:
            gizmosql.execute_update(
                cur, "CREATE TABLE test_ingest_append (id BIGINT, val DOUBLE)"
            )

        try:
            batch1 = pa.table({"id": [1, 2], "val": [10.0, 20.0]})
            batch2 = pa.table({"id": [3, 4], "val": [30.0, 40.0]})

            with conn.cursor() as cur:
                cur.adbc_ingest("test_ingest_append", batch1, mode="append")
                cur.adbc_ingest("test_ingest_append", batch2, mode="append")

            with conn.cursor() as cur:
                cur.execute("SELECT id, val FROM test_ingest_append ORDER BY id")
                result = cur.fetch_arrow_table()
                assert result.num_rows == 4
                assert result.column("id").to_pylist() == [1, 2, 3, 4]
                assert result.column("val").to_pylist() == [10.0, 20.0, 30.0, 40.0]
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_ingest_append")

    def test_ingest_create_append(self, conn):
        """Test mode='create_append' — creates if needed, then appends."""
        import pyarrow as pa

        from adbc_driver_gizmosql import dbapi as gizmosql

        table = pa.table({"x": [100, 200]})

        # First call creates the table
        with conn.cursor() as cur:
            cur.adbc_ingest("test_ingest_ca", table, mode="create_append")

        try:
            # Second call appends to the existing table
            with conn.cursor() as cur:
                cur.adbc_ingest("test_ingest_ca", table, mode="create_append")

            with conn.cursor() as cur:
                cur.execute("SELECT x FROM test_ingest_ca ORDER BY x")
                result = cur.fetch_arrow_table()
                assert result.num_rows == 4
                assert result.column("x").to_pylist() == [100, 100, 200, 200]
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_ingest_ca")

    def test_ingest_replace(self, conn):
        """Test mode='replace' — drops and recreates the table."""
        import pyarrow as pa

        from adbc_driver_gizmosql import dbapi as gizmosql

        original = pa.table({"a": [1, 2, 3]})
        replacement = pa.table({"a": [99]})

        with conn.cursor() as cur:
            cur.adbc_ingest("test_ingest_replace", original, mode="create")

        try:
            with conn.cursor() as cur:
                cur.adbc_ingest("test_ingest_replace", replacement, mode="replace")

            with conn.cursor() as cur:
                cur.execute("SELECT a FROM test_ingest_replace")
                result = cur.fetch_arrow_table()
                assert result.num_rows == 1
                assert result.column("a")[0].as_py() == 99
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_ingest_replace")

    def test_ingest_record_batch(self, conn):
        """Test ingesting a single RecordBatch (not a full Table)."""
        import pyarrow as pa

        from adbc_driver_gizmosql import dbapi as gizmosql

        batch = pa.record_batch(
            {"id": [10, 20], "label": ["foo", "bar"]}
        )

        with conn.cursor() as cur:
            cur.adbc_ingest("test_ingest_rb", batch, mode="create")

        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id, label FROM test_ingest_rb ORDER BY id")
                result = cur.fetch_arrow_table()
                assert result.num_rows == 2
                assert result.column("id").to_pylist() == [10, 20]
                assert result.column("label").to_pylist() == ["foo", "bar"]
        finally:
            with conn.cursor() as cur:
                gizmosql.execute_update(cur, "DROP TABLE test_ingest_rb")


class TestConnectionContextManager:
    """Test that the connection works properly as a context manager."""

    def test_fresh_connection(self, gizmosql_server, gizmosql_uri):
        from conftest import GIZMOSQL_PASSWORD, GIZMOSQL_USERNAME

        from adbc_driver_gizmosql import dbapi as gizmosql

        with gizmosql.connect(
            gizmosql_uri,
            username=GIZMOSQL_USERNAME,
            password=GIZMOSQL_PASSWORD,
            tls_skip_verify=True,
        ) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 42 AS answer")
                table = cur.fetch_arrow_table()
                assert table.column("answer")[0].as_py() == 42
