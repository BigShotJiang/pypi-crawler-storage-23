# Aurora Melody SDK

A professional Python SDK for creating melody generation plugins for **Aurora Melody** - the hardware-style piano roll.

## Features

- Simple Python API for generating MIDI notes
- Built-in music theory (scales, chords, note names)
- Hardware-style UI controls (sliders, dropdowns)
- Utility functions for pattern generation
- CLI tool for packaging plugins

## Installation

```bash
pip install aurora-melody-sdk
```

Package name on PyPI is `aurora-melody-sdk` (hyphenated). Import path is `aurora_melody_sdk` (underscored).

Or install from source:

```bash
git clone https://github.com/Aurora-LABS-Ai/aurora-melody-sdk.git
cd aurora-melody-sdk
pip install -e .
```

## Host Runtime Contract (Important)

When your plugin runs inside Aurora, `generate(context)` receives a plain Python `dict` from the host.

- Use `context["parameters"]` for UI control values.
- Return either:
  - a list of notes, or
  - a rich result object with `notes` + `applyMode`.

Reference:
- `DOCS/PLUGIN-DEVELOPER-GUIDE.md`

## Quick Start

Create a simple melody generator plugin:

```python
import random

class MyMelodyGenerator:
    name = "My Melody Generator"
    author = "Your Name"
    version = "1.0.0"
    description = "Generates random melodies"

    def generate(self, context):
        params = context.get("parameters", {})
        num_notes = int(params.get("num_notes", 8))
        start = float(context.get("playheadPosition", 0.0))

        c_major = [60, 62, 64, 65, 67, 69, 71, 72]
        notes = []
        for i in range(num_notes):
            notes.append({
                "noteNumber": random.choice(c_major),
                "startBeat": start + i * 0.5,
                "lengthBeats": 0.45,
                "velocity": random.randint(70, 110),
                "channel": 1
            })

        # Explicit is best: Replace prevents accidental stacking.
        return {
            "succeeded": True,
            "notes": notes,
            "applyMode": "Replace",
            "message": f"Generated {len(notes)} notes"
        }
```

## Creating a Plugin

### 1. Create Plugin Folder

```
my-plugin/
  manifest.json
  main.py
  icon.png (optional)
  modules/ (optional, vendored third-party deps)
  site-packages/ (optional, vendored third-party deps)
```

If your plugin uses external Python packages, vendor them into `modules/` or
`site-packages/` before running `aurora-pack`. End users should not need to
install Python or pip to run your `.aml`.

### 2. Create manifest.json

```json
{
  "id": "com.yourname.my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "author": "Your Name",
  "description": "Does something amazing",
  "entry": "main.py",
  "icon": "icon.png",
  "tags": ["melody", "generator"],
  "hasUI": true,
  "parameters": [
    {
      "id": "num_notes",
      "name": "Number of Notes",
      "type": "int",
      "default": 8,
      "min": 1,
      "max": 64
    },
    {
      "id": "scale",
      "name": "Scale",
      "type": "choice",
      "default": "Major",
      "choices": ["Major", "Minor", "Blues", "Pentatonic"]
    }
  ]
}
```

Recommended schema for future-proof UI definitions:

```json
{
  "ui": {
    "controls": [
      { "id": "temperature", "name": "Temperature", "type": "knob", "min": 0.1, "max": 2.0, "step": 0.1, "default": 1.0 },
      { "id": "scale", "name": "Scale", "type": "dropdown", "choices": ["Major", "Minor"], "default": "Major" },
      { "id": "humanize", "name": "Humanize", "type": "toggle", "default": true },
      { "id": "prompt", "name": "Prompt", "type": "input", "default": "" }
    ]
  }
}
```

The host remains backward compatible with legacy `controls` and `parameters` fields.

### 3. Create main.py

```python
class MyPlugin:
    name = "My Plugin"
    author = "Your Name"
    version = "1.0.0"
    
    def generate(self, context):
        return {
            "succeeded": True,
            "notes": [
                {"noteNumber": 60, "startBeat": 0.0, "lengthBeats": 1.0, "velocity": 100, "channel": 1}
            ],
            "applyMode": "Replace"
        }
```

### 4. Package the Plugin

```bash
aurora-pack ./my-plugin
# Creates: my-plugin.aml
```

### 5. Install in Aurora Melody

Drag the `.aml` file into Aurora Melody!

---

## Plugin Parameters (UI Controls)

Define controls in your manifest. Aurora Melody renders these in the Controls panel.

### Parameter Types

| Type | UI Control | Description |
|------|-----------|-------------|
| `slider` | Slider | Numeric range (`numericType` can be `int` or `float`) |
| `knob` | Rotary control | Numeric range |
| `dropdown` | Dropdown selector | Select from predefined options |
| `toggle` | Toggle switch | On/Off values |
| `input` | Text input | Free-form text entry |

### manifest.json Format

```json
{
  "ui": {
    "controls": [
      {
        "id": "unique_id",
        "name": "Display Name",
        "type": "slider|knob|dropdown|toggle|input",
        "numericType": "int|float",
        "default": 8,
        "min": 1,
        "max": 100,
        "step": 1,
        "choices": ["Option1", "Option2"],
        "description": "Tooltip text"
      }
    ]
  }
}
```

### Python Class Format

```python
from aurora_melody_sdk import AuroraPlugin, PluginParameter, ParameterType

class MyPlugin(AuroraPlugin):
    parameters = [
        # Integer slider
        PluginParameter(
            id="num_notes",
            name="Number of Notes",
            param_type=ParameterType.INT,
            default=8,
            min_value=1,
            max_value=64,
            step=1,
            description="How many notes to generate"
        ),
        
        # Float slider
        PluginParameter(
            id="note_length",
            name="Note Length",
            param_type=ParameterType.FLOAT,
            default=0.5,
            min_value=0.125,
            max_value=4.0,
            step=0.125,
            description="Length of each note in beats"
        ),
        
        # Dropdown choice
        PluginParameter(
            id="scale",
            name="Scale",
            param_type=ParameterType.CHOICE,
            default="Major",
            choices=["Major", "Minor", "Blues", "Pentatonic", "Dorian", "Mixolydian"],
            description="Musical scale to use"
        ),
        
        # Boolean toggle
        PluginParameter(
            id="humanize",
            name="Humanize",
            param_type=ParameterType.BOOL,
            default=True,
            description="Add human-like timing variations"
        ),
        
        # String input
        PluginParameter(
            id="pattern",
            name="Pattern",
            param_type=ParameterType.STRING,
            default="1-2-3-4",
            description="Custom note pattern"
        ),
    ]
```

### Accessing Parameters in `generate()`

```python
def generate(self, context):
    params = context.get("parameters", {})
    num_notes = int(params.get("num_notes", 8))
    note_length = float(params.get("note_length", 0.5))
    scale_name = str(params.get("scale", "Major"))
    humanize = bool(params.get("humanize", True))
    pattern = str(params.get("pattern", "1-2-3-4"))
```

You can also return a rich result object from `generate()`:

```python
return {
    "succeeded": True,
    "notes": notes,
    "applyMode": "Replace",  # Replace | Append | ReplaceSelection | InsertAtPlayhead
    "message": "Generated notes"
}
```

Default behavior if omitted: host uses `Replace`.

Detailed contract and accepted note format:
- `DOCS/PLUGIN-DEVELOPER-GUIDE.md`

---

## API Reference

### MidiNote

Represents a MIDI note:

```python
note = MidiNote(
    note_number=60,      # MIDI note (60 = C4)
    start_beat=0.0,      # Start position in beats
    length_beats=1.0,    # Duration in beats
    velocity=100,        # Velocity (0-127)
    channel=1            # MIDI channel (1-16)
)

# Properties
note.note_name          # "C4"
note.end_beat           # 1.0 (start + length)

# Methods
note.transpose(5)       # New note 5 semitones up
note.shift(4.0)         # New note 4 beats later
note.to_dict()          # Convert to dictionary
```

### Scale

Musical scales:

```python
from aurora_melody_sdk import Scale

# Available scales
Scale.MAJOR              # [0, 2, 4, 5, 7, 9, 11]
Scale.MINOR              # [0, 2, 3, 5, 7, 8, 10]
Scale.HARMONIC_MINOR     # [0, 2, 3, 5, 7, 8, 11]
Scale.MELODIC_MINOR      # [0, 2, 3, 5, 7, 9, 11]
Scale.PENTATONIC_MAJOR   # [0, 2, 4, 7, 9]
Scale.PENTATONIC_MINOR   # [0, 3, 5, 7, 10]
Scale.BLUES              # [0, 3, 5, 6, 7, 10]
Scale.DORIAN             # [0, 2, 3, 5, 7, 9, 10]
Scale.PHRYGIAN           # [0, 1, 3, 5, 7, 8, 10]
Scale.LYDIAN             # [0, 2, 4, 6, 7, 9, 11]
Scale.MIXOLYDIAN         # [0, 2, 4, 5, 7, 9, 10]
Scale.LOCRIAN            # [0, 1, 3, 5, 6, 8, 10]
Scale.WHOLE_TONE         # [0, 2, 4, 6, 8, 10]
Scale.CHROMATIC          # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

# Get scale notes starting from root
notes = Scale.get_notes(60, Scale.MAJOR)           # [60, 62, 64, 65, 67, 69, 71]
notes = Scale.get_notes(60, Scale.BLUES, octaves=2) # Two octaves
```

### Chord

Musical chords:

```python
from aurora_melody_sdk import Chord

# Available chords
Chord.MAJOR              # [0, 4, 7]
Chord.MINOR              # [0, 3, 7]
Chord.DIMINISHED         # [0, 3, 6]
Chord.AUGMENTED          # [0, 4, 8]
Chord.MAJOR_7            # [0, 4, 7, 11]
Chord.MINOR_7            # [0, 3, 7, 10]
Chord.DOMINANT_7         # [0, 4, 7, 10]
Chord.DIMINISHED_7       # [0, 3, 6, 9]
Chord.HALF_DIMINISHED_7  # [0, 3, 6, 10]
Chord.SUS2               # [0, 2, 7]
Chord.SUS4               # [0, 5, 7]
Chord.ADD9               # [0, 4, 7, 14]
Chord.MAJOR_9            # [0, 4, 7, 11, 14]
Chord.MINOR_9            # [0, 3, 7, 10, 14]

# Get chord notes
notes = Chord.get_notes(60, Chord.MAJOR)           # [60, 64, 67]
notes = Chord.get_notes(60, Chord.DOMINANT_7)      # [60, 64, 67, 70]

# Get chord inversion
notes = Chord.get_inversion(60, Chord.MAJOR, 1)    # First inversion [64, 67, 72]
notes = Chord.get_inversion(60, Chord.MAJOR, 2)    # Second inversion [67, 72, 76]
```

### NoteName

Note name utilities:

```python
from aurora_melody_sdk import NoteName

NoteName.to_midi("C4")      # 60
NoteName.to_midi("F#5")     # 78
NoteName.to_midi("Bb3")     # 58
NoteName.from_midi(60)      # "C4"
NoteName.from_midi(78)      # "F#5"
NoteName.transpose("C4", 5) # "F4"
```

### PluginContext

Context passed to your `generate()` method:

```python
def generate(self, context):
    notes = context.get("notes", [])
    selected_ids = context.get("selectedNoteIds", [])
    start = float(context.get("playheadPosition", 0.0))
    bpm = float(context.get("tempoBPM", 120.0))
    params = context.get("parameters", {})
```

---

## Utility Functions

### random_walk

Generate a melody using random walk algorithm:

```python
from aurora_melody_sdk import random_walk, Scale

notes = random_walk(
    start_note=60,           # Starting MIDI note
    num_notes=16,            # Number of notes to generate
    scale=Scale.MAJOR,       # Scale to use
    root=60,                 # Scale root
    step_range=(-3, 3),      # Max interval in scale degrees
    start_beat=0.0,          # Starting beat position
    note_length=0.5,         # Note duration
    velocity_range=(70, 100) # Velocity range
)
```

### arpeggiate

Create arpeggio patterns from chord notes:

```python
from aurora_melody_sdk import arpeggiate, Chord

chord_notes = Chord.get_notes(60, Chord.MAJOR)

notes = arpeggiate(
    notes=chord_notes,       # Notes to arpeggiate
    pattern="up",            # "up", "down", "updown", "downup", "random"
    total_beats=4.0,         # Total duration
    note_length=0.25,        # Individual note length
    start_beat=0.0,          # Starting position
    velocity=100             # Note velocity
)
```

### quantize_beat / quantize_notes

Snap notes to grid:

```python
from aurora_melody_sdk import quantize_beat, quantize_notes

# Single beat value
q = quantize_beat(1.37, 0.25)  # Returns 1.25 (16th notes)

# Common resolutions:
# 0.0625 = 1/64 notes
# 0.125 = 1/32 notes
# 0.25 = 1/16 notes
# 0.5 = 1/8 notes
# 1.0 = 1/4 notes

# Quantize list of notes
quantized = quantize_notes(notes, resolution=0.25, quantize_length=True)
```

### humanize

Add human-like timing variations:

```python
from aurora_melody_sdk import humanize

humanized = humanize(
    notes=notes,
    timing_variance=0.02,    # Max timing offset in beats
    velocity_variance=10,    # Max velocity offset
    length_variance=0.01     # Max length offset
)
```

---

## Command Line Tools

### aurora-pack

Package plugins into `.aml` files:

```bash
# Basic usage
aurora-pack ./my-plugin

# Specify output location
aurora-pack ./my-plugin -o ./dist/my-plugin.aml

# Vendor dependencies from requirements.txt into plugin site-packages, then package
aurora-pack ./my-plugin --vendor-requirements ./my-plugin/requirements.txt

# Quiet mode (no output)
aurora-pack ./my-plugin -q

# Show help
aurora-pack --help
```

Dependency notes:
- `--vendor-requirements` runs `pip install -t site-packages` using your current Python.
- This is done on the developer machine while building the `.aml`.
- End users can then run the plugin without installing Python packages locally.

---

## AI Service Plugins

Create plugins that connect to YOUR AI service. Plugin handles request/response mapping, and Aurora receives normalized note objects.

### The Flow

```
User clicks Generate
       ↓
Plugin.generate(context) called
       ↓
YOUR plugin:
  1. Builds YOUR request format
  2. Calls YOUR endpoint
  3. Parses YOUR response format
  4. Returns notes (list or rich result object)
       ↓
Aurora Melody receives standard MidiNote
       ↓
Notes appear in piano roll
```

### Quick Start

```python
from aurora_melody_sdk import AIServicePlugin, AIControl, AIControlType, MidiNote

class MyAIPlugin(AIServicePlugin):
    name = "My AI Generator"
    endpoint = "https://api.myservice.com/generate"
    
    controls = [
        AIControl("temp", "Temperature", AIControlType.KNOB, 0.7, 0.1, 1.0),
    ]
    
    def generate(self, context) -> dict:
        # 1. Build YOUR request
        request = {"temperature": context.get_param("temp", 0.7)}
        
        # 2. Call YOUR endpoint
        response = self.call_endpoint(request)
        
        # 3. Parse YOUR response (whatever format your API returns)
        notes = []
        for n in response["my_notes"]:  # YOUR field names
            notes.append(MidiNote(
                note_number=n["p"],      # YOUR field
                start_beat=n["t"],       # YOUR field
                length_beats=n["d"],     # YOUR field
                velocity=n["v"]          # YOUR field
            ))
        
        # 4. Return normalized result object
        return {"succeeded": True, "notes": notes, "applyMode": "Replace"}
```

### Available Control Types

| Type | Renders As | Properties |
|------|------------|------------|
| `KNOB` | Rotary knob | min, max, step, default |
| `SLIDER` | Horizontal slider | min, max, step, default |
| `DROPDOWN` | Dropdown selector | choices, default |
| `TOGGLE` | On/Off switch | default (bool) |
| `BUTTON` | Push button | - |
| `INPUT` | Text input | placeholder, default |
| `LABEL` | Read-only text | default |

### Helper: Common Response Format

If your API returns this common format:

```json
{
  "status": "success",
  "melodies": [{"notes": [{"pitch": 60, "start_time": 0, "duration": 0.5, "velocity": 100}]}]
}
```

Use the helper:

```python
def generate(self, context):
    response = self.call_endpoint({"temp": 0.7})
    return self.parse_standard_response(response)  # Helper method
```

### Your Own Format

Your API can return ANY format - you parse it:

```python
# API returns: {"result": [{"note": 60, "time": 0, "len": 0.5}]}
def generate(self, context):
    response = self.call_endpoint(request)
    return [
        MidiNote(n["note"], n["time"], n["len"], 100)
        for n in response["result"]
    ]
```

### manifest.json for AI Plugins

```json
{
  "id": "com.yourcompany.ai-plugin",
  "name": "My AI Plugin",
  "type": "ai",
  "entry": "main.py",
  "endpoint": "https://api.yourservice.com/generate",
  "controls": [
    {"id": "temp", "name": "Temperature", "type": "knob", "default": 0.7, "min": 0.1, "max": 1.0}
  ],
  "hasInput": true,
  "inputPlaceholder": "Describe melody..."
}
```

---

## Examples

See the `examples/` folder for complete plugin examples:

| Plugin | Description |
|--------|-------------|
| **random-melody** | Random melody generator with scale selection |
| **arpeggiator** | Chord arpeggiator with pattern options |
| **chord-progression** | Chord progression builder |
| **ai-melody-generator** | AI service plugin example |
| **codex-advanced-plugin** | Advanced ostinato/motif generator with mode + scale controls |

---

## Development

### Install Development Dependencies

```bash
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Format Code

```bash
black src/
```

### Type Checking

```bash
mypy src/
```

## Publishing to PyPI

```bash
# Build wheel + source distribution
python -m build

# Validate package metadata/README rendering
twine check dist/*

# Upload (use your PyPI API token)
twine upload dist/*
```

Recommended: publish to TestPyPI first.

```bash
twine upload --repository testpypi dist/*
```

---

## License

MIT License - see [LICENSE](LICENSE) file.

---

## Links

- [GitHub Repository](https://github.com/Aurora-LABS-Ai/aurora-melody-sdk)
- [Issue Tracker](https://github.com/Aurora-LABS-Ai/aurora-melody-sdk/issues)
- [Documentation](https://github.com/Aurora-LABS-Ai/aurora-melody-sdk#readme)
