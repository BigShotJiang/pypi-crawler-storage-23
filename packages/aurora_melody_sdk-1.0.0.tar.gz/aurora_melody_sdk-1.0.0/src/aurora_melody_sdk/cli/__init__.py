"""
Aurora Melody SDK command-line tools.
"""

from aurora_melody_sdk.cli.pack import main as pack_main

__all__ = ["pack_main"]

