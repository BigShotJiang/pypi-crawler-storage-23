"""
Tests for plugin classes.
"""

import json
import zipfile
from pathlib import Path

import pytest
from aurora_melody_sdk import (
    AuroraPlugin, MidiNote, PluginContext, 
    PluginParameter, ParameterType
)
from aurora_melody_sdk.cli import pack as pack_cli


class TestPluginParameter:
    """Tests for PluginParameter."""
    
    def test_int_parameter(self):
        """Test integer parameter."""
        param = PluginParameter(
            id="num_notes",
            name="Number of Notes",
            param_type=ParameterType.INT,
            default=8,
            min_value=1,
            max_value=64
        )
        
        d = param.to_dict()
        assert d["id"] == "num_notes"
        assert d["name"] == "Number of Notes"
        assert d["type"] == "int"
        assert d["default"] == 8
        assert d["min"] == 1
        assert d["max"] == 64
    
    def test_float_parameter(self):
        """Test float parameter."""
        param = PluginParameter(
            id="length",
            name="Note Length",
            param_type=ParameterType.FLOAT,
            default=0.5,
            min_value=0.125,
            max_value=4.0,
            step=0.125
        )
        
        d = param.to_dict()
        assert d["type"] == "float"
        assert d["step"] == 0.125
    
    def test_choice_parameter(self):
        """Test choice parameter."""
        param = PluginParameter(
            id="scale",
            name="Scale",
            param_type=ParameterType.CHOICE,
            default="Major",
            choices=["Major", "Minor", "Blues"]
        )
        
        d = param.to_dict()
        assert d["type"] == "choice"
        assert d["choices"] == ["Major", "Minor", "Blues"]
    
    def test_bool_parameter(self):
        """Test boolean parameter."""
        param = PluginParameter(
            id="humanize",
            name="Humanize",
            param_type=ParameterType.BOOL,
            default=True
        )
        
        d = param.to_dict()
        assert d["type"] == "bool"
        assert d["default"] == True


class TestPluginContext:
    """Tests for PluginContext."""
    
    def test_from_dict(self):
        """Test creating context from dictionary."""
        data = {
            "tempoBPM": 120.0,
            "playheadPosition": 4.0,
            "notes": [
                {"noteNumber": 60, "startBeat": 0.0, "lengthBeats": 1.0, "velocity": 100}
            ],
            "selectedNoteIds": [1, 2],
            "parameters": {
                "num_notes": 16,
                "scale": "Minor"
            }
        }
        
        ctx = PluginContext.from_dict(data)
        
        assert ctx.tempo_bpm == 120.0
        assert ctx.playhead_position == 4.0
        assert len(ctx.notes) == 1
        assert ctx.notes[0].note_number == 60
    
    def test_get_int_param(self):
        """Test getting integer parameter."""
        ctx = PluginContext(parameters={"num_notes": 16})
        
        assert ctx.get_int_param("num_notes", 8) == 16
        assert ctx.get_int_param("missing", 8) == 8
    
    def test_get_float_param(self):
        """Test getting float parameter."""
        ctx = PluginContext(parameters={"length": 0.25})
        
        assert ctx.get_float_param("length", 0.5) == 0.25
        assert ctx.get_float_param("missing", 0.5) == 0.5
    
    def test_get_str_param(self):
        """Test getting string parameter."""
        ctx = PluginContext(parameters={"scale": "Blues"})
        
        assert ctx.get_str_param("scale", "Major") == "Blues"
        assert ctx.get_str_param("missing", "Major") == "Major"
    
    def test_get_bool_param(self):
        """Test getting boolean parameter."""
        ctx = PluginContext(parameters={"humanize": True})
        
        assert ctx.get_bool_param("humanize", False) == True
        assert ctx.get_bool_param("missing", False) == False


class TestAuroraPlugin:
    """Tests for AuroraPlugin base class."""
    
    def test_concrete_plugin(self):
        """Test creating a concrete plugin."""
        class TestPlugin(AuroraPlugin):
            name = "Test Plugin"
            author = "Test Author"
            version = "1.0.0"
            
            parameters = [
                PluginParameter("test", "Test", ParameterType.INT, 10, 0, 100)
            ]
            
            def generate(self, context):
                return [MidiNote(60, 0.0, 1.0, 100)]
        
        plugin = TestPlugin()
        assert plugin.name == "Test Plugin"
        assert plugin.author == "Test Author"
        
        notes = plugin.generate(PluginContext())
        assert len(notes) == 1
        assert notes[0].note_number == 60
    
    def test_get_parameters_dict(self):
        """Test getting parameters as dictionaries."""
        class TestPlugin(AuroraPlugin):
            name = "Test"
            author = "Test"
            version = "1.0.0"
            
            parameters = [
                PluginParameter("a", "A", ParameterType.INT, 1),
                PluginParameter("b", "B", ParameterType.FLOAT, 0.5),
            ]
            
            def generate(self, context):
                return []
        
        plugin = TestPlugin()
        params = plugin.get_parameters_dict()
        
        assert len(params) == 2
        assert params[0]["id"] == "a"
        assert params[1]["id"] == "b"


def _write_minimal_plugin(plugin_dir: Path) -> None:
    plugin_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "id": "com.test.plugin",
        "name": "Test Plugin",
        "version": "1.0.0",
        "author": "Test",
        "entry": "main.py",
    }
    (plugin_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    (plugin_dir / "main.py").write_text("class Plugin:\n    pass\n", encoding="utf-8")


class TestPackCli:
    """Tests for CLI packaging helpers."""

    def test_validate_manifest_missing_file(self, tmp_path: Path):
        valid, error, data = pack_cli.validate_manifest(tmp_path / "manifest.json")
        assert valid is False
        assert "not found" in error
        assert data == {}

    def test_validate_entry_point_syntax_error(self, tmp_path: Path):
        _write_minimal_plugin(tmp_path)
        (tmp_path / "main.py").write_text("def broken(:\n", encoding="utf-8")
        valid, error = pack_cli.validate_entry_point(tmp_path, "main.py")
        assert valid is False
        assert "Syntax error" in error

    def test_create_package_skips_hidden_and_pyc(self, tmp_path: Path):
        plugin_dir = tmp_path / "plugin"
        _write_minimal_plugin(plugin_dir)
        (plugin_dir / ".hidden.txt").write_text("secret", encoding="utf-8")
        (plugin_dir / "cache.pyc").write_bytes(b"bytecode")
        (plugin_dir / "__pycache__").mkdir()
        (plugin_dir / "__pycache__" / "x.pyc").write_bytes(b"bytecode")

        output = tmp_path / "plugin.aml"
        ok, err = pack_cli.create_package(plugin_dir, output, verbose=False)
        assert ok is True
        assert err == ""

        with zipfile.ZipFile(output, "r") as archive:
            names = set(archive.namelist())

        assert "manifest.json" in names
        assert "main.py" in names
        assert ".hidden.txt" not in names
        assert "cache.pyc" not in names
        assert "__pycache__/x.pyc" not in names

    def test_pack_calls_vendor_requirements(self, tmp_path: Path, monkeypatch):
        plugin_dir = tmp_path / "plugin"
        _write_minimal_plugin(plugin_dir)
        requirements_path = tmp_path / "requirements.txt"
        requirements_path.write_text("example==1.0.0\n", encoding="utf-8")

        called = {}

        def fake_vendor_requirements(plugin_path, req_path, verbose):
            called["plugin_path"] = plugin_path
            called["req_path"] = req_path
            called["verbose"] = verbose
            return True, ""

        monkeypatch.setattr(pack_cli, "vendor_requirements", fake_vendor_requirements)

        output_path = tmp_path / "out.aml"
        success = pack_cli.pack(
            str(plugin_dir),
            output_path=str(output_path),
            requirements_path=str(requirements_path),
            verbose=False,
        )

        assert success is True
        assert output_path.exists()
        assert called["plugin_path"] == plugin_dir.resolve()
        assert called["req_path"] == requirements_path.resolve()
        assert called["verbose"] is False

