"""
Pydantic models shared across all Q1 Crafter MCP modules.

Defines the unified data structures for papers, search results,
analysis outputs, and manuscript building.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


# ─── Enums ────────────────────────────────────────────────────


class Quartile(str, Enum):
    """Journal quartile ranking."""
    Q1 = "Q1"
    Q2 = "Q2"
    Q3 = "Q3"
    Q4 = "Q4"
    UNKNOWN = "unknown"


class SectionType(str, Enum):
    """Academic paper section types (IMRaD+ structure)."""
    TITLE = "title"
    ABSTRACT = "abstract"
    INTRODUCTION = "introduction"
    LITERATURE_REVIEW = "literature_review"
    METHODOLOGY = "methodology"
    RESULTS = "results"
    DISCUSSION = "discussion"
    CONCLUSION = "conclusion"
    REFERENCES = "references"
    APPENDIX = "appendix"


class CitationStyle(str, Enum):
    """In-text citation style."""
    PARENTHETICAL = "parenthetical"   # (Smith et al., 2021)
    NARRATIVE = "narrative"           # Smith et al. (2021)


# ─── Core Data Models ────────────────────────────────────────


class Author(BaseModel):
    """Represents a single author."""
    first_name: str = ""
    last_name: str = ""
    affiliation: Optional[str] = None
    orcid: Optional[str] = None

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()

    @property
    def apa_name(self) -> str:
        """Format as 'Last, F. M.' for APA references."""
        initials = ""
        if self.first_name:
            parts = self.first_name.split()
            initials = " ".join(f"{p[0]}." for p in parts if p)
        return f"{self.last_name}, {initials}".strip(", ")


class Paper(BaseModel):
    """Unified representation of an academic paper from any source."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""
    authors: list[Author] = Field(default_factory=list)
    year: Optional[int] = None
    journal: str = ""
    volume: Optional[str] = None
    issue: Optional[str] = None
    pages: Optional[str] = None
    doi: Optional[str] = None
    url: Optional[str] = None
    abstract: Optional[str] = None
    citations_count: int = 0
    source_api: str = ""
    quartile: Quartile = Quartile.UNKNOWN
    impact_factor: Optional[float] = None
    open_access: bool = False
    pdf_url: Optional[str] = None
    keywords: list[str] = Field(default_factory=list)
    language: str = "en"
    publication_type: str = ""  # "journal-article", "conference-paper", "thesis", etc.

    @property
    def author_count(self) -> int:
        return len(self.authors)

    @property
    def first_author_last_name(self) -> str:
        if self.authors:
            return self.authors[0].last_name
        return "Unknown"

    def doi_url(self) -> Optional[str]:
        """Return the full DOI URL (https://doi.org/...)."""
        if self.doi:
            doi = self.doi.strip()
            if doi.startswith("http"):
                # Normalize to https://doi.org/ format
                doi = doi.replace("http://", "https://")
                doi = doi.replace("dx.doi.org", "doi.org")
                return doi
            return f"https://doi.org/{doi}"
        return None


# ─── Search Models ────────────────────────────────────────────


class SearchConfig(BaseModel):
    """Configuration for an academic search query."""
    query: str
    sources: Optional[list[str]] = None      # None = all available
    max_results: int = 100
    year_from: Optional[int] = None
    year_to: Optional[int] = None
    field: Optional[str] = None              # "medicine", "engineering", etc.
    language: str = "en"
    open_access_only: bool = False


class AggregatedResults(BaseModel):
    """Container for aggregated search results from multiple APIs."""
    papers: list[Paper] = Field(default_factory=list)
    total_found: int = 0
    sources_queried: list[str] = Field(default_factory=list)
    duplicates_removed: int = 0
    query_time_seconds: float = 0.0
    errors: dict[str, str] = Field(default_factory=dict)  # {source: error_msg}


# ─── Analysis Models ─────────────────────────────────────────


class AnalysisResult(BaseModel):
    """Output of the literature analysis tool."""
    main_themes: list[str] = Field(default_factory=list)
    research_gaps: list[str] = Field(default_factory=list)
    methodological_trends: list[str] = Field(default_factory=list)
    temporal_trends: dict[int, int] = Field(default_factory=dict)  # {year: count}
    top_cited_papers: list[str] = Field(default_factory=list)
    controversial_topics: list[str] = Field(default_factory=list)
    recommended_structure: list[str] = Field(default_factory=list)


class IntegrityReport(BaseModel):
    """Output of the citation validator — bidirectional check."""
    valid: bool = True
    orphan_intext: list[str] = Field(default_factory=list)       # In text but not in references
    orphan_references: list[str] = Field(default_factory=list)   # In references but not cited
    malformed_citations: list[dict[str, Any]] = Field(default_factory=list)
    doi_issues: list[dict[str, Any]] = Field(default_factory=list)
    report: str = ""


# ─── Output Models ────────────────────────────────────────────


class Section(BaseModel):
    """A single section of the manuscript."""
    section_type: SectionType
    title: str = ""
    content: str = ""
    word_count: int = 0


class Figure(BaseModel):
    """A figure to be embedded in the manuscript."""
    path: str
    caption: str = ""
    label: str = ""


class Manuscript(BaseModel):
    """Complete manuscript ready for DOCX generation."""
    title: str = ""
    authors: list[Author] = Field(default_factory=list)
    affiliation: str = ""
    corresponding_email: str = ""
    sections: list[Section] = Field(default_factory=list)
    references: list[Paper] = Field(default_factory=list)
    figures: list[Figure] = Field(default_factory=list)
    keywords: list[str] = Field(default_factory=list)
    language: str = "en"
    created_at: datetime = Field(default_factory=datetime.now)


# ─── API Status Models ───────────────────────────────────────


class APISourceStatus(BaseModel):
    """Status of a single API source."""
    name: str
    available: bool
    requires_key: bool
    description: str = ""


class APIStatusReport(BaseModel):
    """Report on all API source statuses."""
    sources: list[APISourceStatus] = Field(default_factory=list)
    total_available: int = 0
    total_configured: int = 0
