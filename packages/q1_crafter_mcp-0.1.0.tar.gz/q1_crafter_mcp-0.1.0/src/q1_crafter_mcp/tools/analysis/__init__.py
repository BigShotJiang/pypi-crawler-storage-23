"""Analysis tools — summarizer, citation validator, gap analyzer, keyword extractor."""
