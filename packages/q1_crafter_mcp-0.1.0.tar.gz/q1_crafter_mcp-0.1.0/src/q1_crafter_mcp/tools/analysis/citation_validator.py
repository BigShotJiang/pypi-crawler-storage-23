"""
Citation validator — bidirectional validation between in-text
citations and the references list.

Detects:
- Orphan in-text citations (cited but not in references)
- Orphan references (in references but never cited)
- Malformed citation patterns
- DOI verification issues
"""

from __future__ import annotations

import re
from typing import Any

from loguru import logger

from q1_crafter_mcp.models import IntegrityReport


# Regex for APA-style in-text citations
# Matches: (Smith, 2021), (Smith et al., 2021), (Smith & Jones, 2021)
# Also: (Smith, 2021a), (Jones, 2020; Smith, 2021)
INTEXT_PATTERN = re.compile(
    r"\(([A-Z][a-zA-Zçşğüöıİ]+(?:\s+(?:et\s+al\.|&\s+[A-Z][a-zA-Zçşğüöıİ]+))?)"
    r"(?:,\s*(\d{4}[a-z]?))"
    r"(?:\s*;\s*"
    r"[A-Z][a-zA-Zçşğüöıİ]+(?:\s+(?:et\s+al\.|&\s+[A-Z][a-zA-Zçşğüöıİ]+))?"
    r",\s*\d{4}[a-z]?)*\)"
)

# Simpler pattern to catch individual author-year pairs within parentheses
AUTHOR_YEAR_PATTERN = re.compile(
    r"([A-Z][a-zA-Zçşğüöıİ]+(?:\s+et\s+al\.)?)\s*[\(,]\s*(\d{4}[a-z]?)"
)

# Narrative citation: Smith et al. (2021) or Smith (2021)
NARRATIVE_PATTERN = re.compile(
    r"([A-Z][a-zA-Zçşğüöıİ]+(?:\s+et\s+al\.)?)\s+\((\d{4}[a-z]?)\)"
)


def validate_citations(
    text: str,
    references: list[dict[str, Any]],
) -> IntegrityReport:
    """
    Perform bidirectional citation validation.

    Args:
        text: The manuscript text containing in-text citations.
        references: List of reference dictionaries with at least
                   'authors' and 'year' fields.

    Returns:
        IntegrityReport with all identified issues.
    """
    # Extract in-text citation keys
    intext_keys = _extract_intext_keys(text)

    # Extract reference keys
    ref_keys = _extract_reference_keys(references)

    # Forward check: every in-text must exist in references
    orphan_intext = []
    for key in intext_keys:
        if not _find_matching_ref(key, ref_keys):
            orphan_intext.append(f"{key[0]} ({key[1]})")

    # Backward check: every reference should be cited in text
    orphan_references = []
    for key in ref_keys:
        if not _find_matching_intext(key, intext_keys):
            orphan_references.append(f"{key[0]} ({key[1]})")

    # Check for malformed citations
    malformed = _find_malformed(text)

    # Check DOI issues
    doi_issues = _check_dois(references)

    # Build report
    valid = (
        len(orphan_intext) == 0
        and len(orphan_references) == 0
        and len(malformed) == 0
    )

    report_lines = []
    if valid:
        report_lines.append("✅ All citations validated successfully.")
    else:
        if orphan_intext:
            report_lines.append(f"❌ {len(orphan_intext)} in-text citation(s) not found in references:")
            for o in orphan_intext:
                report_lines.append(f"   - {o}")
        if orphan_references:
            report_lines.append(f"⚠️ {len(orphan_references)} reference(s) never cited in text:")
            for o in orphan_references:
                report_lines.append(f"   - {o}")
        if malformed:
            report_lines.append(f"❌ {len(malformed)} malformed citation(s) found:")
            for m in malformed:
                report_lines.append(f"   - {m.get('text', '')}: {m.get('issue', '')}")
        if doi_issues:
            report_lines.append(f"⚠️ {len(doi_issues)} DOI issue(s):")
            for d in doi_issues:
                report_lines.append(f"   - {d.get('reference', '')}: {d.get('issue', '')}")

    report_lines.append(f"\nTotal in-text citations: {len(intext_keys)}")
    report_lines.append(f"Total references: {len(ref_keys)}")

    return IntegrityReport(
        valid=valid,
        orphan_intext=orphan_intext,
        orphan_references=orphan_references,
        malformed_citations=malformed,
        doi_issues=doi_issues,
        report="\n".join(report_lines),
    )


def _extract_intext_keys(text: str) -> list[tuple[str, str]]:
    """Extract (author_key, year) pairs from in-text citations."""
    keys = set()

    # Parenthetical: (Author, Year)
    for match in AUTHOR_YEAR_PATTERN.finditer(text):
        author = match.group(1).strip()
        year = match.group(2).strip()
        keys.add((author, year))

    # Narrative: Author (Year)
    for match in NARRATIVE_PATTERN.finditer(text):
        author = match.group(1).strip()
        year = match.group(2).strip()
        keys.add((author, year))

    return list(keys)


def _extract_reference_keys(references: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """Extract (first_author_last_name, year) from reference entries."""
    keys = []
    for ref in references:
        year = str(ref.get("year", ""))

        # Get first author's last name
        authors = ref.get("authors", [])
        if authors:
            if isinstance(authors[0], dict):
                last_name = authors[0].get("last_name", "") or authors[0].get("lastName", "")
            elif isinstance(authors[0], str):
                last_name = authors[0].rsplit(" ", 1)[-1]
            else:
                last_name = ""
        else:
            last_name = ref.get("first_author_last_name", "")

        if last_name and year:
            keys.append((last_name, year))

    return keys


def _find_matching_ref(
    intext_key: tuple[str, str],
    ref_keys: list[tuple[str, str]],
) -> bool:
    """Check if an in-text citation key matches any reference."""
    author, year = intext_key
    # Remove "et al." for matching
    clean_author = author.replace(" et al.", "").strip()
    year_base = year.rstrip("abcdefghij")  # Remove disambiguation letter

    for ref_author, ref_year in ref_keys:
        if clean_author.lower() == ref_author.lower() and year_base == ref_year:
            return True
    return False


def _find_matching_intext(
    ref_key: tuple[str, str],
    intext_keys: list[tuple[str, str]],
) -> bool:
    """Check if a reference is cited in the text."""
    ref_author, ref_year = ref_key

    for author, year in intext_keys:
        clean_author = author.replace(" et al.", "").strip()
        year_base = year.rstrip("abcdefghij")
        if clean_author.lower() == ref_author.lower() and year_base == ref_year:
            return True
    return False


def _find_malformed(text: str) -> list[dict[str, str]]:
    """Find potentially malformed citation patterns."""
    issues = []

    # Check for common errors
    # 1. Missing comma between author and year: (Smith 2021)
    no_comma = re.findall(
        r"\([A-Z][a-zA-Z]+\s+\d{4}\)", text
    )
    for match in no_comma:
        issues.append({
            "text": match,
            "issue": "Missing comma between author and year",
        })

    # 2. Lowercase author name in parenthetical
    lowercase = re.findall(
        r"\([a-z][a-zA-Z]+,\s*\d{4}\)", text
    )
    for match in lowercase:
        issues.append({
            "text": match,
            "issue": "Author name should start with uppercase",
        })

    return issues


def _check_dois(references: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Check for DOI format issues in references."""
    issues = []

    for ref in references:
        doi = ref.get("doi", "")
        if not doi:
            title = ref.get("title", "Unknown")
            issues.append({
                "reference": title[:60],
                "issue": "No DOI — manual verification recommended",
            })
        elif doi.startswith("http://dx.doi.org/"):
            issues.append({
                "reference": doi,
                "issue": "Uses deprecated dx.doi.org format — should be https://doi.org/",
            })
        elif not doi.startswith("10.") and not doi.startswith("https://doi.org/"):
            issues.append({
                "reference": doi,
                "issue": "Invalid DOI format",
            })

    return issues
