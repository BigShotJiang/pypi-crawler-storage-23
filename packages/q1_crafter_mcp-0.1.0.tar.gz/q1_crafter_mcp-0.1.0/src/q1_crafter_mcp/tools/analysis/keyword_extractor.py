"""
Keyword extractor — TF-IDF and co-occurrence based keyword extraction.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Any

from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper


STOPWORDS = {
    "the", "a", "an", "of", "in", "for", "and", "or", "to", "on",
    "with", "by", "is", "are", "was", "were", "be", "been", "being",
    "from", "at", "as", "that", "this", "which", "its", "it",
    "using", "based", "between", "through", "into", "can", "will",
    "has", "have", "had", "do", "does", "did", "but", "not", "no",
    "so", "if", "than", "too", "very", "also", "more", "most",
    "such", "only", "other", "these", "those", "their", "our",
    "we", "they", "he", "she", "may", "would", "could", "should",
    "about", "each", "both", "all", "any", "some", "how", "what",
    "when", "where", "who", "why", "while", "after", "before",
    "during", "above", "below", "over", "under", "still", "new",
    "study", "results", "paper", "research", "approach", "method",
    "data", "analysis", "proposed", "model", "system", "used",
    "show", "shown", "shows", "present", "work", "however",
}


def extract_keywords(
    paper_ids: list[str],
    max_keywords: int = 20,
) -> dict[str, Any]:
    """
    Extract key concepts from paper abstracts using TF-IDF.

    Returns a dict with:
    - keywords: list of (term, score) pairs
    - bigrams: list of (bigram, count) pairs
    - paper_count: number of papers analyzed
    """
    papers = [get_paper(pid) for pid in paper_ids]
    papers = [p for p in papers if p is not None]

    if not papers:
        return {"keywords": [], "bigrams": [], "paper_count": 0}

    # Build document corpus from abstracts + titles
    docs = []
    for p in papers:
        text = f"{p.title} "
        if p.abstract:
            text += p.abstract
        docs.append(text)

    # TF-IDF
    keywords = _tfidf(docs, max_keywords)

    # Bigrams
    bigrams = _extract_bigrams(docs, max_keywords)

    return {
        "keywords": keywords,
        "bigrams": bigrams,
        "paper_count": len(papers),
    }


def _tokenize(text: str) -> list[str]:
    """Tokenize and clean text."""
    text = text.lower()
    text = re.sub(r"[^a-zA-Z\s]", " ", text)
    words = text.split()
    return [w for w in words if w not in STOPWORDS and len(w) > 2]


def _tfidf(docs: list[str], top_n: int) -> list[tuple[str, float]]:
    """Simple TF-IDF implementation."""
    n_docs = len(docs)

    # Document frequency
    df: Counter = Counter()
    doc_tokens = []
    for doc in docs:
        tokens = _tokenize(doc)
        doc_tokens.append(tokens)
        unique = set(tokens)
        for token in unique:
            df[token] += 1

    # TF-IDF scores
    scores: Counter = Counter()
    for tokens in doc_tokens:
        tf = Counter(tokens)
        n_tokens = len(tokens) if tokens else 1
        for term, count in tf.items():
            tf_val = count / n_tokens
            idf_val = math.log((n_docs + 1) / (df[term] + 1)) + 1
            scores[term] += tf_val * idf_val

    return [(term, round(score, 4)) for term, score in scores.most_common(top_n)]


def _extract_bigrams(docs: list[str], top_n: int) -> list[tuple[str, int]]:
    """Extract most common meaningful bigrams."""
    bigram_counts: Counter = Counter()

    for doc in docs:
        tokens = _tokenize(doc)
        for i in range(len(tokens) - 1):
            bigram = f"{tokens[i]} {tokens[i + 1]}"
            bigram_counts[bigram] += 1

    return [(bg, count) for bg, count in bigram_counts.most_common(top_n) if count >= 2]
