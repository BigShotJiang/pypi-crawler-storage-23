"""
Paper summarizer — extracts key information from paper abstracts
and groups papers by themes.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from q1_crafter_mcp.models import Paper
from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper


def summarize_papers(paper_ids: list[str]) -> dict[str, Any]:
    """
    Create concise summaries of papers grouped by theme.

    Returns:
        Dict with paper summaries, theme groups, and statistics.
    """
    papers = [get_paper(pid) for pid in paper_ids]
    papers = [p for p in papers if p is not None]

    if not papers:
        return {"summaries": [], "themes": {}, "stats": {}}

    summaries = []
    for p in papers:
        summary = {
            "id": p.id,
            "title": p.title,
            "authors": ", ".join(a.full_name for a in p.authors[:3]),
            "year": p.year,
            "journal": p.journal,
            "citations": p.citations_count,
            "doi": p.doi,
            "abstract_snippet": (
                p.abstract[:300] + "..." if p.abstract and len(p.abstract) > 300
                else p.abstract or "No abstract available"
            ),
            "open_access": p.open_access,
            "keywords": p.keywords[:5],
        }
        summaries.append(summary)

    # Group by main keywords
    themes = _group_by_themes(papers)

    # Statistics
    stats = {
        "total_papers": len(papers),
        "year_range": f"{min(p.year for p in papers if p.year)}-{max(p.year for p in papers if p.year)}" if any(p.year for p in papers) else "N/A",
        "total_citations": sum(p.citations_count for p in papers),
        "avg_citations": round(sum(p.citations_count for p in papers) / len(papers), 1),
        "open_access_count": sum(1 for p in papers if p.open_access),
        "unique_journals": len(set(p.journal for p in papers if p.journal)),
        "sources_used": list(set(p.source_api for p in papers)),
    }

    return {
        "summaries": summaries,
        "themes": themes,
        "stats": stats,
    }


def _group_by_themes(papers: list[Paper]) -> dict[str, list[str]]:
    """Group paper IDs by their primary keyword/theme."""
    theme_groups: dict[str, list[str]] = defaultdict(list)

    for p in papers:
        if p.keywords:
            primary = p.keywords[0]
            theme_groups[primary].append(p.id)
        else:
            theme_groups["Uncategorized"].append(p.id)

    # Sort themes by group size
    return dict(sorted(theme_groups.items(), key=lambda x: -len(x[1])))
