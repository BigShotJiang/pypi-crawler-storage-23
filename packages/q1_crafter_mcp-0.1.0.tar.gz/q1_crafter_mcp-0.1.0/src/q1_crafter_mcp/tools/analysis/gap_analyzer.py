"""
Gap analyzer — identifies research gaps, trends, and patterns
in a collection of academic papers.
"""

from __future__ import annotations

from collections import Counter
from typing import Any

from q1_crafter_mcp.models import AnalysisResult, Paper


# In-memory paper store (populated by search results)
_paper_store: dict[str, Paper] = {}


def register_papers(papers: list[Paper]):
    """Register papers in the store for later analysis."""
    for paper in papers:
        _paper_store[paper.id] = paper


def get_paper(paper_id: str) -> Paper | None:
    """Retrieve a paper by its ID."""
    return _paper_store.get(paper_id)


def analyze_literature(paper_ids: list[str]) -> AnalysisResult:
    """
    Analyze a collection of papers to identify:
    - Main themes (based on keywords and title analysis)
    - Research gaps (temporal and methodological)
    - Methodological trends
    - Temporal trends (year → count)
    - Top cited papers
    - Controversial / debated topics
    - Recommended paper structure
    """
    papers = [_paper_store[pid] for pid in paper_ids if pid in _paper_store]

    if not papers:
        return AnalysisResult(
            report="No papers found for the given IDs. "
            "Make sure to run search_academic first."
        )

    # ── Temporal trends ─────────────────────────────────────
    year_counts: dict[int, int] = Counter()
    for p in papers:
        if p.year:
            year_counts[p.year] += 1
    temporal_trends = dict(sorted(year_counts.items()))

    # ── Keyword / theme analysis ────────────────────────────
    all_keywords: list[str] = []
    for p in papers:
        all_keywords.extend(p.keywords)
        # Also extract from titles
        words = p.title.lower().split()
        # Filter stopwords
        stopwords = {
            "the", "a", "an", "of", "in", "for", "and", "or", "to",
            "on", "with", "by", "is", "are", "was", "were", "be",
            "from", "at", "as", "that", "this", "which", "its",
            "using", "based", "between", "through", "into",
        }
        meaningful = [w.strip(".,;:!?()[]") for w in words if w not in stopwords and len(w) > 2]
        all_keywords.extend(meaningful)

    keyword_counts = Counter(all_keywords)
    main_themes = [kw for kw, count in keyword_counts.most_common(15) if count >= 2]

    # ── Top cited papers ────────────────────────────────────
    sorted_by_cite = sorted(papers, key=lambda p: p.citations_count, reverse=True)
    top_cited = [
        f"{p.first_author_last_name} ({p.year}) — {p.title[:80]} [{p.citations_count} citations]"
        for p in sorted_by_cite[:10]
    ]

    # ── Methodological trends ───────────────────────────────
    method_keywords = [
        "machine learning", "deep learning", "neural network",
        "regression", "classification", "survey", "review",
        "meta-analysis", "randomized", "qualitative", "quantitative",
        "experimental", "simulation", "case study", "longitudinal",
        "cross-sectional", "mixed methods", "systematic review",
    ]
    method_counts: dict[str, int] = {}
    for p in papers:
        text = f"{p.title} {p.abstract or ''}".lower()
        for method in method_keywords:
            if method in text:
                method_counts[method] = method_counts.get(method, 0) + 1

    methodological_trends = [
        f"{method} ({count} papers)"
        for method, count in sorted(method_counts.items(), key=lambda x: -x[1])
    ]

    # ── Research gaps ───────────────────────────────────────
    research_gaps = _identify_gaps(papers, temporal_trends, keyword_counts)

    # ── Recommended structure ───────────────────────────────
    recommended = _suggest_structure(papers, main_themes)

    return AnalysisResult(
        main_themes=main_themes,
        research_gaps=research_gaps,
        methodological_trends=methodological_trends,
        temporal_trends=temporal_trends,
        top_cited_papers=top_cited,
        controversial_topics=[],  # Would need citation network analysis
        recommended_structure=recommended,
    )


def _identify_gaps(
    papers: list[Paper],
    temporal: dict[int, int],
    keywords: Counter,
) -> list[str]:
    """Identify potential research gaps."""
    gaps = []

    # Gap 1: Recent decline in publications
    if temporal:
        years = sorted(temporal.keys())
        if len(years) >= 3:
            recent = sum(temporal.get(y, 0) for y in years[-2:])
            earlier = sum(temporal.get(y, 0) for y in years[-4:-2]) if len(years) >= 4 else recent
            if recent < earlier * 0.5:
                gaps.append(
                    "Publication volume has declined recently — "
                    "possible saturation or shift in research focus."
                )

    # Gap 2: Low OA ratio
    oa_count = sum(1 for p in papers if p.open_access)
    if len(papers) > 10 and oa_count / len(papers) < 0.3:
        gaps.append(
            f"Only {oa_count}/{len(papers)} papers are open access — "
            "limited accessibility may hinder reproducibility."
        )

    # Gap 3: Geographic / language bias
    tr_papers = sum(1 for p in papers if p.language == "tr")
    if len(papers) > 20 and tr_papers == 0:
        gaps.append(
            "No Turkish-language papers found — "
            "consider searching TR Dizin and DergiPark for local perspectives."
        )

    # Gap 4: Missing recent years
    if temporal:
        current_year = max(temporal.keys())
        if current_year < 2024:
            gaps.append(
                f"Most recent paper is from {current_year} — "
                "consider updating search to include the latest publications."
            )

    if not gaps:
        gaps.append("No significant gaps detected in the current collection.")

    return gaps


def _suggest_structure(papers: list[Paper], themes: list[str]) -> list[str]:
    """Suggest a paper structure based on the collected papers."""
    structure = [
        "1. Introduction — Background, problem statement, research gaps",
        "2. Literature Review — Organized thematically:",
    ]

    for i, theme in enumerate(themes[:5], 1):
        structure.append(f"   2.{i}. {theme.title()}")

    structure.extend([
        "3. Methodology — Systematic review approach, search strategy",
        "4. Results — Synthesis of findings across themes",
        "5. Discussion — Implications, limitations, future directions",
        "6. Conclusion — Key takeaways and contributions",
    ])

    return structure
