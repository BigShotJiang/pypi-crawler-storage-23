"""
CrossRef API client.

Searches the CrossRef database for DOI metadata, paper lookups,
and provides the polite pool mechanism via email header.

API Docs: https://api.crossref.org/
"""

from __future__ import annotations

from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class CrossRefSearchClient(BaseSearchClient):
    """Client for the CrossRef REST API."""

    SOURCE_NAME = "crossref"
    BASE_URL = "https://api.crossref.org"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 5.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        # Polite pool: include email for better rate limits
        email = self.settings.unpaywall_email
        if email:
            headers["User-Agent"] = (
                f"Q1CrafterMCP/0.1.0 (mailto:{email})"
            )
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search papers via CrossRef."""
        url = f"{self.BASE_URL}/works"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "query": config.query,
            "rows": min(max_results, 100),
            "sort": "relevance",
            "order": "desc",
            "select": (
                "DOI,title,author,published-print,published-online,"
                "container-title,volume,issue,page,abstract,"
                "is-referenced-by-count,type,link,subject"
            ),
        }

        # Year filter
        if config.year_from:
            params["filter"] = f"from-pub-date:{config.year_from}"
        if config.year_to:
            existing = params.get("filter", "")
            sep = "," if existing else ""
            params["filter"] = f"{existing}{sep}until-pub-date:{config.year_to}"

        data = await self._fetch(url, params=params)
        items = data.get("message", {}).get("items", [])

        papers = []
        for item in items:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)

        return papers[:max_results]

    async def search_by_doi(self, doi: str) -> Paper:
        """Look up a single paper by DOI."""
        # Normalize DOI
        doi = doi.strip()
        if doi.startswith("https://doi.org/"):
            doi = doi[16:]
        elif doi.startswith("http://doi.org/"):
            doi = doi[15:]
        elif doi.startswith("http://dx.doi.org/"):
            doi = doi[18:]

        url = f"{self.BASE_URL}/works/{doi}"
        data = await self._fetch(url)
        item = data.get("message", {})

        paper = self._parse_item(item)
        if not paper:
            raise ValueError(f"Could not parse paper for DOI: {doi}")
        return paper

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        """Parse a CrossRef work item into a Paper object."""
        titles = item.get("title", [])
        title = titles[0] if titles else ""
        if not title:
            return None

        # Authors
        authors = []
        for a in item.get("author", []):
            authors.append(Author(
                first_name=a.get("given", ""),
                last_name=a.get("family", ""),
                affiliation=(
                    a.get("affiliation", [{}])[0].get("name")
                    if a.get("affiliation")
                    else None
                ),
                orcid=a.get("ORCID"),
            ))

        # Year — prefer print date, fallback to online
        year = None
        for date_key in ["published-print", "published-online", "created"]:
            date_parts = item.get(date_key, {}).get("date-parts", [[]])
            if date_parts and date_parts[0] and date_parts[0][0]:
                year = date_parts[0][0]
                break

        # Journal
        containers = item.get("container-title", [])
        journal = containers[0] if containers else ""

        # Abstract (may contain JATS XML tags)
        abstract = item.get("abstract", "")
        if abstract:
            # Strip JATS XML tags
            import re
            abstract = re.sub(r"<[^>]+>", "", abstract).strip()

        # Subjects/keywords
        subjects = item.get("subject", [])

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=journal,
            volume=item.get("volume"),
            issue=item.get("issue"),
            pages=item.get("page"),
            doi=item.get("DOI"),
            url=item.get("URL"),
            abstract=abstract if abstract else None,
            citations_count=item.get("is-referenced-by-count", 0),
            source_api=self.SOURCE_NAME,
            open_access=False,  # CrossRef doesn't reliably report OA status
            keywords=subjects,
            publication_type=item.get("type", ""),
        )
