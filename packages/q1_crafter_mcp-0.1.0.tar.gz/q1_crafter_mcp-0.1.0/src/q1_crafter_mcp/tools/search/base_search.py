"""
BASE (Bielefeld Academic Search Engine) API client.

Searches 300M+ academic documents.

API Docs: https://www.base-search.net/about/en/about_api.php
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class BASESearchClient(BaseSearchClient):
    """Client for the BASE (Bielefeld) Search API."""

    SOURCE_NAME = "base_search"
    BASE_URL = "https://api.base-search.net/cgi-bin/BaseHttpSearchInterface.fcgi"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 2.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        max_results = min(config.max_results, self.settings.max_results_per_source)

        query = config.query
        if config.year_from and config.year_to:
            query += f" dcyear:[{config.year_from} TO {config.year_to}]"
        elif config.year_from:
            query += f" dcyear:[{config.year_from} TO *]"
        elif config.year_to:
            query += f" dcyear:[* TO {config.year_to}]"

        if config.open_access_only:
            query += " dcoa:1"

        params = {
            "func": "PerformSearch",
            "query": query,
            "format": "json",
            "hits": min(max_results, 100),
        }

        data = await self._fetch(self.BASE_URL, params=params)
        response = data.get("response", {})
        docs = response.get("docs", [])

        papers = []
        for doc in docs:
            paper = self._parse_doc(doc)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_doc(self, doc: dict[str, Any]) -> Optional[Paper]:
        title = doc.get("dctitle", "")
        if isinstance(title, list):
            title = title[0] if title else ""
        if not title:
            return None

        authors = []
        creator = doc.get("dccreator", [])
        if isinstance(creator, str):
            creator = [creator]
        for name in creator:
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        year = None
        dcyear = doc.get("dcyear")
        if dcyear:
            try:
                year = int(dcyear) if isinstance(dcyear, (int, str)) else None
            except (ValueError, TypeError):
                pass

        doi = doc.get("dcdoi")
        if isinstance(doi, list):
            doi = doi[0] if doi else None

        url = doc.get("dclink") or doc.get("dcidentifier")
        if isinstance(url, list):
            url = url[0] if url else None

        abstract = doc.get("dcdescription", "")
        if isinstance(abstract, list):
            abstract = " ".join(abstract)

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=doc.get("dcsource", "") if isinstance(doc.get("dcsource"), str) else "",
            doi=doi,
            url=url,
            abstract=abstract if abstract else None,
            source_api=self.SOURCE_NAME,
            open_access=doc.get("dcoa", 0) == 1,
            language=doc.get("dclang", "en") if isinstance(doc.get("dclang"), str) else "en",
        )
