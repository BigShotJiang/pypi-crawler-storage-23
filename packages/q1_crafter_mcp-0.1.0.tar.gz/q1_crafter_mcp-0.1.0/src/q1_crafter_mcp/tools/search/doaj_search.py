"""
DOAJ (Directory of Open Access Journals) API client.

API Docs: https://doaj.org/api/
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class DOAJSearchClient(BaseSearchClient):
    """Client for the DOAJ API."""

    SOURCE_NAME = "doaj"
    BASE_URL = "https://doaj.org/api"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 5.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/search/articles/{config.query}"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "pageSize": min(max_results, 100),
        }

        data = await self._fetch(url, params=params)
        results = data.get("results", [])

        papers = []
        for item in results:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        bibjson = item.get("bibjson", {})
        title = bibjson.get("title", "")
        if not title:
            return None

        authors = []
        for a in bibjson.get("author", []):
            name = a.get("name", "")
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
                affiliation=a.get("affiliation"),
            ))

        year = None
        pub_year = bibjson.get("year")
        if pub_year:
            try:
                year = int(pub_year)
            except (ValueError, TypeError):
                pass

        journal = bibjson.get("journal", {}).get("title", "")
        volume = bibjson.get("journal", {}).get("volume")

        doi = None
        for ident in bibjson.get("identifier", []):
            if ident.get("type") == "doi":
                doi = ident.get("id")
                break

        link_url = None
        for link in bibjson.get("link", []):
            if link.get("type") == "fulltext":
                link_url = link.get("url")
                break

        keywords = bibjson.get("keywords", [])

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=journal,
            volume=volume,
            pages=bibjson.get("start_page"),
            doi=doi,
            url=link_url,
            abstract=bibjson.get("abstract"),
            source_api=self.SOURCE_NAME,
            open_access=True,
            keywords=keywords,
            language=bibjson.get("journal", {}).get("language", ["en"])[0] if bibjson.get("journal", {}).get("language") else "en",
        )
