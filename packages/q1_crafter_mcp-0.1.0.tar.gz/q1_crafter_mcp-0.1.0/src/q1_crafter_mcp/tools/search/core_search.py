"""
CORE API client.

Searches the CORE aggregator (200M+ open access articles).
API key required for higher rate limits.

API Docs: https://api.core.ac.uk/docs/v3
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class CORESearchClient(BaseSearchClient):
    """Client for the CORE API v3."""

    SOURCE_NAME = "core"
    BASE_URL = "https://api.core.ac.uk/v3"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 5.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.core_api_key:
            headers["Authorization"] = f"Bearer {self.settings.core_api_key}"
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/search/works"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "q": config.query,
            "limit": min(max_results, 100),
        }

        if config.year_from:
            params["filter"] = f"yearPublished>={config.year_from}"
        if config.year_to:
            existing = params.get("filter", "")
            sep = "," if existing else ""
            params["filter"] = f"{existing}{sep}yearPublished<={config.year_to}"

        data = await self._fetch(url, params=params)
        results = data.get("results", [])

        papers = []
        for item in results:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        authors = []
        for a in item.get("authors", []):
            name = a.get("name", "") if isinstance(a, dict) else str(a)
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        doi_val = item.get("doi") or item.get("identifiers", {}).get("doi")
        if isinstance(doi_val, list):
            doi_val = doi_val[0] if doi_val else None

        return Paper(
            title=title,
            authors=authors,
            year=item.get("yearPublished"),
            journal=item.get("publisher", ""),
            doi=doi_val,
            url=item.get("downloadUrl") or item.get("sourceFulltextUrls", [None])[0] if item.get("sourceFulltextUrls") else None,
            abstract=item.get("abstract"),
            citations_count=0,
            source_api=self.SOURCE_NAME,
            open_access=True,
            pdf_url=item.get("downloadUrl"),
            language=item.get("language", {}).get("code", "en") if isinstance(item.get("language"), dict) else "en",
        )
