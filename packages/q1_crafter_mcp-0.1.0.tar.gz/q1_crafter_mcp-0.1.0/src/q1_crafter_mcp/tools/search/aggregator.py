"""
Search aggregator — the central orchestrator for multi-source academic search.

Queries all configured API sources in parallel, merges results,
deduplicates, and returns a unified, sorted result set.
"""

from __future__ import annotations

import asyncio
import time
from typing import Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import AggregatedResults, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient
from q1_crafter_mcp.tools.search.duplicate_detector import deduplicate_papers


# ── Field-based fallback chains ────────────────────────────────

FALLBACK_CHAINS: dict[str, list[str]] = {
    "general": [
        "semantic_scholar", "openalex", "crossref", "core",
        "europepmc", "doaj", "base_search",
    ],
    "medicine": [
        "pubmed", "europepmc", "semantic_scholar", "core",
        "scopus", "crossref",
    ],
    "engineering": [
        "ieee", "arxiv", "semantic_scholar", "scopus",
        "springer", "crossref",
    ],
    "cs": [
        "semantic_scholar", "arxiv", "ieee", "openalex",
        "scopus", "crossref",
    ],
    "turkish": [
        "trdizin", "dergipark", "yok_tez",
        "semantic_scholar", "openalex",
    ],
}


def _get_all_clients(settings: Settings) -> dict[str, BaseSearchClient]:
    """Lazily import and instantiate all search clients."""
    from q1_crafter_mcp.tools.search.arxiv_search import ArxivSearchClient
    from q1_crafter_mcp.tools.search.base_search import BASESearchClient
    from q1_crafter_mcp.tools.search.core_search import CORESearchClient
    from q1_crafter_mcp.tools.search.crossref_search import CrossRefSearchClient
    from q1_crafter_mcp.tools.search.dergipark_search import DergiParkSearchClient
    from q1_crafter_mcp.tools.search.dimensions_search import DimensionsSearchClient
    from q1_crafter_mcp.tools.search.doaj_search import DOAJSearchClient
    from q1_crafter_mcp.tools.search.europepmc_search import EuropePMCSearchClient
    from q1_crafter_mcp.tools.search.ieee_search import IEEESearchClient
    from q1_crafter_mcp.tools.search.openalex_search import OpenAlexSearchClient
    from q1_crafter_mcp.tools.search.pubmed_search import PubMedSearchClient
    from q1_crafter_mcp.tools.search.sciencedirect_search import ScienceDirectSearchClient
    from q1_crafter_mcp.tools.search.scopus_search import ScopusSearchClient
    from q1_crafter_mcp.tools.search.semantic_scholar import SemanticScholarClient
    from q1_crafter_mcp.tools.search.springer_search import SpringerSearchClient
    from q1_crafter_mcp.tools.search.trdizin_search import TRDizinSearchClient
    from q1_crafter_mcp.tools.search.wos_search import WoSSearchClient
    from q1_crafter_mcp.tools.search.yok_tez_search import YokTezSearchClient

    return {
        "semantic_scholar": SemanticScholarClient(settings),
        "arxiv": ArxivSearchClient(settings),
        "crossref": CrossRefSearchClient(settings),
        "openalex": OpenAlexSearchClient(settings),
        "pubmed": PubMedSearchClient(settings),
        "europepmc": EuropePMCSearchClient(settings),
        "core": CORESearchClient(settings),
        "doaj": DOAJSearchClient(settings),
        "base_search": BASESearchClient(settings),
        "scopus": ScopusSearchClient(settings),
        "ieee": IEEESearchClient(settings),
        "springer": SpringerSearchClient(settings),
        "sciencedirect": ScienceDirectSearchClient(settings),
        "wos": WoSSearchClient(settings),
        "dimensions": DimensionsSearchClient(settings),
        "trdizin": TRDizinSearchClient(settings),
        "dergipark": DergiParkSearchClient(settings),
        "yok_tez": YokTezSearchClient(settings),
    }


async def aggregate_search(
    config: SearchConfig,
    settings: Settings,
) -> AggregatedResults:
    """
    Main aggregation pipeline:

    1. Determine which sources to query (all available or user-specified)
    2. Query all sources in parallel via asyncio.gather()
    3. Merge results from all sources
    4. Deduplicate (exact DOI + fuzzy title)
    5. Sort by citation count (descending)
    6. Trim to max_results
    7. Enrich with Unpaywall open access info
    """
    start_time = time.time()

    all_clients = _get_all_clients(settings)

    # Determine which sources to query
    if config.sources:
        # User specified sources
        source_names = [s for s in config.sources if s in all_clients]
    elif config.field and config.field.lower() in FALLBACK_CHAINS:
        # Field-based source selection
        chain = FALLBACK_CHAINS[config.field.lower()]
        source_names = [s for s in chain if s in all_clients]
        # Also add remaining available sources
        remaining = [
            s for s in all_clients
            if s not in source_names and all_clients[s].is_available()
        ]
        source_names.extend(remaining)
    else:
        # Query all available sources
        source_names = [s for s in all_clients if all_clients[s].is_available()]

    logger.info(f"Aggregator: querying {len(source_names)} sources: {source_names}")

    # ── Parallel search ────────────────────────────────────────
    clients_to_query = {name: all_clients[name] for name in source_names}

    tasks = {
        name: asyncio.create_task(client.safe_search(config))
        for name, client in clients_to_query.items()
    }

    # Wait for all tasks with a global timeout
    done, pending = await asyncio.wait(
        tasks.values(),
        timeout=settings.request_timeout * 2,  # 2x individual timeout for total
    )

    # Cancel any remaining tasks
    for task in pending:
        task.cancel()

    # ── Collect results ────────────────────────────────────────
    all_papers: list[Paper] = []
    sources_queried: list[str] = []
    errors: dict[str, str] = {}

    for name, task in tasks.items():
        try:
            if task.done() and not task.cancelled():
                papers = task.result()
                if papers:
                    all_papers.extend(papers)
                    sources_queried.append(name)
                    logger.info(f"  [{name}] → {len(papers)} papers")
                else:
                    sources_queried.append(name)
            else:
                errors[name] = "Timed out"
                logger.warning(f"  [{name}] → timed out")
        except Exception as e:
            errors[name] = str(e)
            logger.error(f"  [{name}] → error: {e}")

    total_before_dedup = len(all_papers)

    # ── Deduplication ──────────────────────────────────────────
    papers, duplicates_removed = deduplicate_papers(all_papers)

    # ── Sort by citation count ─────────────────────────────────
    papers.sort(key=lambda p: p.citations_count, reverse=True)

    # ── Trim to max_results ────────────────────────────────────
    papers = papers[:config.max_results]

    # ── Enrich with Unpaywall (if available) ───────────────────
    if settings.unpaywall_email:
        try:
            from q1_crafter_mcp.tools.search.unpaywall_search import UnpaywallSearchClient
            unpaywall = UnpaywallSearchClient(settings)
            # Only enrich papers that have DOIs and aren't already marked as OA
            to_enrich = [p for p in papers if p.doi and not p.open_access][:20]
            if to_enrich:
                for paper in to_enrich:
                    await unpaywall.enrich_paper(paper)
                await unpaywall.close()
        except Exception as e:
            logger.warning(f"Unpaywall enrichment failed: {e}")

    elapsed = time.time() - start_time

    result = AggregatedResults(
        papers=papers,
        total_found=total_before_dedup,
        sources_queried=sources_queried,
        duplicates_removed=duplicates_removed,
        query_time_seconds=round(elapsed, 2),
        errors=errors,
    )

    logger.info(
        f"Aggregator complete: {len(papers)} papers from {len(sources_queried)} sources "
        f"({duplicates_removed} duplicates removed) in {elapsed:.1f}s"
    )

    return result
