"""
Clarivate Web of Science API client.

Provides impact factor, JCR data, and citation analysis.
Requires institutional license.

API Docs: https://developer.clarivate.com/
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class WoSSearchClient(BaseSearchClient):
    """Client for the Web of Science API."""

    SOURCE_NAME = "wos"
    BASE_URL = "https://api.clarivate.com/apis/wos-starter/v1"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 2.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.wos_api_key:
            headers["X-ApiKey"] = self.settings.wos_api_key
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/documents"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "q": f"TS=({config.query})",
            "limit": min(max_results, 50),
            "sortField": "TC",  # Times Cited
            "order": "desc",
        }

        if config.year_from:
            params["publishTimeSpan"] = f"{config.year_from}-01-01+"
            if config.year_to:
                params["publishTimeSpan"] = (
                    f"{config.year_from}-01-01+{config.year_to}-12-31"
                )

        data = await self._fetch(url, params=params)
        hits = data.get("hits", [])

        papers = []
        for item in hits:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        source = item.get("source", {})

        authors = []
        names = item.get("names", {}).get("authors", [])
        for name in names:
            display = name.get("displayName", "")
            parts = display.split(", ")
            if len(parts) == 2:
                authors.append(Author(first_name=parts[1], last_name=parts[0]))
            else:
                name_parts = display.rsplit(" ", 1)
                authors.append(Author(
                    first_name=name_parts[0] if len(name_parts) > 1 else "",
                    last_name=name_parts[-1],
                ))

        year = None
        pub_year = source.get("publishYear")
        if pub_year:
            try:
                year = int(pub_year)
            except (ValueError, TypeError):
                pass

        doi = None
        identifiers = item.get("identifiers", {})
        doi = identifiers.get("doi")

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=source.get("sourceTitle", ""),
            volume=source.get("volume"),
            issue=source.get("issue"),
            pages=source.get("pages", {}).get("range"),
            doi=doi,
            url=item.get("links", {}).get("record"),
            citations_count=item.get("citations", [{}])[0].get("count", 0) if item.get("citations") else 0,
            source_api=self.SOURCE_NAME,
            keywords=item.get("keywords", {}).get("authorKeywords", []),
            publication_type=item.get("sourceType", ""),
        )
