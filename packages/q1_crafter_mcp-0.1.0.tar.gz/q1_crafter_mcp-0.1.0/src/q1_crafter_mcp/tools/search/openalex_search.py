"""
OpenAlex API client.

Searches the OpenAlex catalog (250M+ academic works).
Fully open, no API key required.

API Docs: https://docs.openalex.org/
"""

from __future__ import annotations

from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class OpenAlexSearchClient(BaseSearchClient):
    """Client for the OpenAlex API."""

    SOURCE_NAME = "openalex"
    BASE_URL = "https://api.openalex.org"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 10.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        email = self.settings.unpaywall_email
        if email:
            headers["User-Agent"] = f"Q1CrafterMCP/0.1.0 (mailto:{email})"
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search works via OpenAlex."""
        url = f"{self.BASE_URL}/works"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "search": config.query,
            "per_page": min(max_results, 200),
            "sort": "relevance_score:desc",
        }

        # Build filter string
        filters = []
        if config.year_from and config.year_to:
            filters.append(f"publication_year:{config.year_from}-{config.year_to}")
        elif config.year_from:
            filters.append(f"from_publication_date:{config.year_from}-01-01")
        elif config.year_to:
            filters.append(f"to_publication_date:{config.year_to}-12-31")

        if config.open_access_only:
            filters.append("is_oa:true")

        if config.language and config.language != "all":
            filters.append(f"language:{config.language}")

        if filters:
            params["filter"] = ",".join(filters)

        # Polite pool
        email = self.settings.unpaywall_email
        if email:
            params["mailto"] = email

        data = await self._fetch(url, params=params)
        results = data.get("results", [])

        papers = []
        for item in results:
            paper = self._parse_work(item)
            if paper:
                papers.append(paper)

        return papers[:max_results]

    def _parse_work(self, item: dict[str, Any]) -> Optional[Paper]:
        """Parse an OpenAlex work into a Paper object."""
        title = item.get("title", "")
        if not title:
            return None

        # Authors
        authors = []
        for authorship in item.get("authorships", []):
            author_data = authorship.get("author", {})
            name = author_data.get("display_name", "")
            parts = name.rsplit(" ", 1)

            affiliation = ""
            institutions = authorship.get("institutions", [])
            if institutions:
                affiliation = institutions[0].get("display_name", "")

            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
                affiliation=affiliation or None,
                orcid=author_data.get("orcid"),
            ))

        # DOI
        doi = item.get("doi", "")
        if doi and doi.startswith("https://doi.org/"):
            doi = doi[16:]

        # Journal / source
        source = item.get("primary_location", {}) or {}
        source_info = source.get("source", {}) or {}
        journal = source_info.get("display_name", "")

        # Open access
        oa = item.get("open_access", {}) or {}
        is_oa = oa.get("is_oa", False)
        oa_url = oa.get("oa_url")

        # Concepts as keywords
        concepts = item.get("concepts", [])
        keywords = [c.get("display_name", "") for c in concepts[:10] if c.get("display_name")]

        # Biblio info
        biblio = item.get("biblio", {}) or {}

        return Paper(
            title=title,
            authors=authors,
            year=item.get("publication_year"),
            journal=journal,
            volume=biblio.get("volume"),
            issue=biblio.get("issue"),
            pages=(
                f"{biblio['first_page']}-{biblio['last_page']}"
                if biblio.get("first_page") and biblio.get("last_page")
                else biblio.get("first_page")
            ),
            doi=doi if doi else None,
            url=item.get("id"),
            abstract=None,  # OpenAlex provides inverted abstract index, not raw text
            citations_count=item.get("cited_by_count", 0),
            source_api=self.SOURCE_NAME,
            open_access=is_oa,
            pdf_url=oa_url,
            keywords=keywords,
            publication_type=item.get("type", ""),
            language=item.get("language", "en"),
        )
