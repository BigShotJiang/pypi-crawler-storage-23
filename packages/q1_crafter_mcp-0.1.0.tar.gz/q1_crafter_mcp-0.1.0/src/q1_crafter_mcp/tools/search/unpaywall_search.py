"""
Unpaywall API client.

Enriches papers with open access PDF URLs.
Only requires an email address — no API key needed.

API Docs: https://unpaywall.org/products/api
"""

from __future__ import annotations

from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class UnpaywallSearchClient(BaseSearchClient):
    """Client for the Unpaywall API — finds open access versions of papers."""

    SOURCE_NAME = "unpaywall"
    BASE_URL = "https://api.unpaywall.org/v2"
    REQUIRES_KEY = True  # Requires email
    DEFAULT_RATE_LIMIT = 10.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Unpaywall doesn't support text search — use enrich_paper instead."""
        logger.debug("[unpaywall] Text search not supported, use enrich_paper(doi)")
        return []

    async def enrich_paper(self, paper: Paper) -> Paper:
        """
        Enrich a Paper with open access information from Unpaywall.

        If the paper has a DOI, looks up open access status and PDF URL.
        """
        if not paper.doi or not self.settings.unpaywall_email:
            return paper

        doi = paper.doi.strip()
        if doi.startswith("https://doi.org/"):
            doi = doi[16:]

        try:
            url = f"{self.BASE_URL}/{doi}"
            params = {"email": self.settings.unpaywall_email}
            data = await self._fetch(url, params=params)

            paper.open_access = data.get("is_oa", False)

            best_oa = data.get("best_oa_location") or {}
            if best_oa.get("url_for_pdf"):
                paper.pdf_url = best_oa["url_for_pdf"]
            elif best_oa.get("url"):
                paper.pdf_url = best_oa["url"]

        except Exception as e:
            logger.debug(f"[unpaywall] Could not enrich DOI {doi}: {e}")

        return paper

    async def enrich_papers(self, papers: list[Paper]) -> list[Paper]:
        """Enrich multiple papers with open access information."""
        enriched = []
        for paper in papers:
            enriched.append(await self.enrich_paper(paper))
        return enriched
