"""
Duplicate detector module.

Identifies and removes duplicate papers from aggregated results using:
1. Exact DOI matching
2. Fuzzy title matching (Levenshtein similarity >= 0.92)

When duplicates are found, keeps the version with the richest metadata.
"""

from __future__ import annotations

from loguru import logger
from rapidfuzz import fuzz

from q1_crafter_mcp.models import Paper


TITLE_SIMILARITY_THRESHOLD = 92  # Levenshtein ratio threshold (0-100)


def deduplicate_papers(papers: list[Paper]) -> tuple[list[Paper], int]:
    """
    Remove duplicate papers from the list.

    Returns:
        Tuple of (deduplicated papers, number of duplicates removed).
    """
    if not papers:
        return [], 0

    original_count = len(papers)

    # Phase 1: Exact DOI dedup
    papers = _dedup_by_doi(papers)

    # Phase 2: Fuzzy title dedup
    papers = _dedup_by_title(papers)

    removed = original_count - len(papers)
    logger.info(f"Deduplication: {original_count} → {len(papers)} ({removed} removed)")

    return papers, removed


def _dedup_by_doi(papers: list[Paper]) -> list[Paper]:
    """Remove exact DOI duplicates, keeping the best metadata version."""
    doi_groups: dict[str, list[Paper]] = {}
    no_doi: list[Paper] = []

    for paper in papers:
        if paper.doi:
            normalized_doi = paper.doi.strip().lower()
            if normalized_doi.startswith("https://doi.org/"):
                normalized_doi = normalized_doi[16:]
            elif normalized_doi.startswith("http://doi.org/"):
                normalized_doi = normalized_doi[15:]

            if normalized_doi not in doi_groups:
                doi_groups[normalized_doi] = []
            doi_groups[normalized_doi].append(paper)
        else:
            no_doi.append(paper)

    # For each DOI group, keep the best version
    result = []
    for doi, group in doi_groups.items():
        best = _select_best(group)
        result.append(best)

    result.extend(no_doi)
    return result


def _dedup_by_title(papers: list[Paper]) -> list[Paper]:
    """Remove fuzzy title duplicates using Levenshtein similarity."""
    if not papers:
        return []

    # Build clusters of similar titles
    used = [False] * len(papers)
    result: list[Paper] = []

    for i in range(len(papers)):
        if used[i]:
            continue

        cluster = [papers[i]]
        used[i] = True
        title_i = _normalize_title(papers[i].title)

        if not title_i:
            result.append(papers[i])
            continue

        for j in range(i + 1, len(papers)):
            if used[j]:
                continue

            title_j = _normalize_title(papers[j].title)
            if not title_j:
                continue

            similarity = fuzz.ratio(title_i, title_j)
            if similarity >= TITLE_SIMILARITY_THRESHOLD:
                cluster.append(papers[j])
                used[j] = True

        # Keep the best from each cluster
        best = _select_best(cluster)
        result.append(best)

    return result


def _normalize_title(title: str) -> str:
    """Normalize title for comparison."""
    return title.lower().strip().rstrip(".")


def _select_best(papers: list[Paper]) -> Paper:
    """Select the paper with the richest metadata from a group of duplicates."""
    if len(papers) == 1:
        return papers[0]

    def _score(p: Paper) -> int:
        """Score a paper by metadata completeness."""
        score = 0
        if p.doi:
            score += 10
        if p.abstract:
            score += 5
        if p.authors:
            score += len(p.authors)
        if p.year:
            score += 3
        if p.journal:
            score += 3
        if p.volume:
            score += 1
        if p.issue:
            score += 1
        if p.pages:
            score += 1
        if p.citations_count > 0:
            score += 3
        if p.pdf_url:
            score += 2
        if p.keywords:
            score += 1
        if p.open_access:
            score += 1
        return score

    return max(papers, key=_score)
