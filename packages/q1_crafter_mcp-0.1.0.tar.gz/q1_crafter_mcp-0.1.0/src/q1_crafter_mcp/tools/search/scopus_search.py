"""
Elsevier Scopus API client.

Provides journal quartile info, impact factors, and citation analysis.
Requires an institutional or individual API key.

API Docs: https://dev.elsevier.com/documentation/SCOPUSSearchAPI.wadl
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, Quartile, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class ScopusSearchClient(BaseSearchClient):
    """Client for the Elsevier Scopus Search API."""

    SOURCE_NAME = "scopus"
    BASE_URL = "https://api.elsevier.com/content"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 3.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.scopus_api_key:
            headers["X-ELS-APIKey"] = self.settings.scopus_api_key
        headers["Accept"] = "application/json"
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/search/scopus"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        query = f"TITLE-ABS-KEY({config.query})"
        if config.year_from and config.year_to:
            query += f" AND PUBYEAR > {config.year_from - 1} AND PUBYEAR < {config.year_to + 1}"
        elif config.year_from:
            query += f" AND PUBYEAR > {config.year_from - 1}"
        elif config.year_to:
            query += f" AND PUBYEAR < {config.year_to + 1}"

        if config.open_access_only:
            query += " AND OPENACCESS(1)"

        params = {
            "query": query,
            "count": min(max_results, 25),
            "sort": "citedby-count",
            "field": (
                "dc:title,dc:creator,prism:coverDate,prism:publicationName,"
                "prism:volume,prism:issueIdentifier,prism:pageRange,prism:doi,"
                "citedby-count,prism:url,dc:description,openaccess,"
                "prism:aggregationType"
            ),
        }

        data = await self._fetch(url, params=params)
        results = data.get("search-results", {}).get("entry", [])

        papers = []
        for item in results:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("dc:title", "")
        if not title or title == "Error":
            return None

        # Parse author (Scopus returns only first author in search)
        authors = []
        creator = item.get("dc:creator", "")
        if creator:
            parts = creator.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        year = None
        cover_date = item.get("prism:coverDate", "")
        if cover_date:
            try:
                year = int(cover_date[:4])
            except (ValueError, IndexError):
                pass

        cited_by = 0
        try:
            cited_by = int(item.get("citedby-count", 0))
        except (ValueError, TypeError):
            pass

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("prism:publicationName", ""),
            volume=item.get("prism:volume"),
            issue=item.get("prism:issueIdentifier"),
            pages=item.get("prism:pageRange"),
            doi=item.get("prism:doi"),
            url=item.get("prism:url"),
            abstract=item.get("dc:description"),
            citations_count=cited_by,
            source_api=self.SOURCE_NAME,
            open_access=item.get("openaccess") == "1",
            publication_type=item.get("prism:aggregationType", ""),
        )
