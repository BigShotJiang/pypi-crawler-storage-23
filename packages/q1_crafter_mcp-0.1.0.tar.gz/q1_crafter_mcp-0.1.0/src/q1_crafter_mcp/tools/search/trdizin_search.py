"""
TR Dizin API client.

Searches Turkish academic journals via the TÜBİTAK ULAKBİM TR Dizin API.

API key required — apply via trdizin@tubitak.gov.tr
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class TRDizinSearchClient(BaseSearchClient):
    """Client for the TR Dizin API."""

    SOURCE_NAME = "trdizin"
    BASE_URL = "https://trdizin.gov.tr/api"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 3.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.trdizin_api_key:
            headers["Authorization"] = f"Bearer {self.settings.trdizin_api_key}"
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/search"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "q": config.query,
            "limit": min(max_results, 50),
        }

        if config.year_from:
            params["yearFrom"] = config.year_from
        if config.year_to:
            params["yearTo"] = config.year_to

        data = await self._fetch(url, params=params)
        results = data.get("results", data.get("data", []))

        papers = []
        for item in results if isinstance(results, list) else []:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "") or item.get("baslik", "")
        if not title:
            return None

        authors = []
        for a in item.get("authors", item.get("yazarlar", [])):
            if isinstance(a, str):
                parts = a.rsplit(" ", 1)
                authors.append(Author(
                    first_name=parts[0] if len(parts) > 1 else "",
                    last_name=parts[-1],
                ))
            elif isinstance(a, dict):
                authors.append(Author(
                    first_name=a.get("firstName", a.get("ad", "")),
                    last_name=a.get("lastName", a.get("soyad", "")),
                ))

        year = item.get("year") or item.get("yil")
        if year:
            try:
                year = int(year)
            except (ValueError, TypeError):
                year = None

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("journal", item.get("dergi", "")),
            volume=item.get("volume", item.get("cilt")),
            issue=item.get("issue", item.get("sayi")),
            pages=item.get("pages", item.get("sayfa")),
            doi=item.get("doi"),
            url=item.get("url"),
            abstract=item.get("abstract", item.get("ozet")),
            source_api=self.SOURCE_NAME,
            language=item.get("language", "tr"),
        )
