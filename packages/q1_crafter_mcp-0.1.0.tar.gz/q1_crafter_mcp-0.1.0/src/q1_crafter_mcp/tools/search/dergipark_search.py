"""
DergiPark OAI-PMH client.

Searches 1000+ Turkish journals via the OAI-PMH protocol.
No API key required.

Base URL: https://dergipark.org.tr/oai
"""

from __future__ import annotations

import re
from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class DergiParkSearchClient(BaseSearchClient):
    """Client for DergiPark via OAI-PMH protocol."""

    SOURCE_NAME = "dergipark"
    BASE_URL = "https://dergipark.org.tr/oai"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 2.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        """
        Search DergiPark via OAI-PMH ListRecords.

        Note: OAI-PMH doesn't support text search natively.
        We fetch recent records and filter locally.
        """
        max_results = min(config.max_results, self.settings.max_results_per_source, 50)

        params: dict[str, Any] = {
            "verb": "ListRecords",
            "metadataPrefix": "oai_dc",
        }

        if config.year_from:
            params["from"] = f"{config.year_from}-01-01"
        if config.year_to:
            params["until"] = f"{config.year_to}-12-31"

        try:
            xml_text = await self._fetch_xml(self.BASE_URL, params=params)
            papers = self._parse_oai_xml(xml_text, config.query, max_results)
            return papers
        except Exception as e:
            logger.error(f"[dergipark] OAI-PMH error: {e}")
            return []

    def _parse_oai_xml(self, xml_text: str, query: str, max_results: int) -> list[Paper]:
        """Parse OAI-PMH XML and filter by query terms."""
        import xml.etree.ElementTree as ET

        papers = []
        query_terms = query.lower().split()

        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as e:
            logger.error(f"[dergipark] XML parse error: {e}")
            return []

        ns = {
            "oai": "http://www.openarchives.org/OAI/2.0/",
            "dc": "http://purl.org/dc/elements/1.1/",
            "oai_dc": "http://www.openarchives.org/OAI/2.0/oai_dc/",
        }

        records = root.findall(".//oai:record", ns)

        for record in records:
            if len(papers) >= max_results:
                break

            metadata = record.find(".//oai_dc:dc", ns)
            if metadata is None:
                continue

            title_elem = metadata.find("dc:title", ns)
            title = title_elem.text if title_elem is not None and title_elem.text else ""

            desc_elem = metadata.find("dc:description", ns)
            description = desc_elem.text if desc_elem is not None and desc_elem.text else ""

            # Filter by query terms
            searchable = f"{title} {description}".lower()
            if not any(term in searchable for term in query_terms):
                continue

            # Authors
            authors = []
            for creator in metadata.findall("dc:creator", ns):
                if creator.text:
                    parts = creator.text.rsplit(" ", 1)
                    authors.append(Author(
                        first_name=parts[0] if len(parts) > 1 else "",
                        last_name=parts[-1],
                    ))

            # Year
            year = None
            date_elem = metadata.find("dc:date", ns)
            if date_elem is not None and date_elem.text:
                match = re.search(r"(\d{4})", date_elem.text)
                if match:
                    year = int(match.group(1))

            # Publisher as journal name
            pub_elem = metadata.find("dc:publisher", ns)
            journal = pub_elem.text if pub_elem is not None and pub_elem.text else ""

            # Identifier (URL or DOI)
            url = None
            doi = None
            for ident in metadata.findall("dc:identifier", ns):
                if ident.text:
                    if "doi.org" in ident.text:
                        doi = ident.text.split("doi.org/")[-1]
                    elif ident.text.startswith("http"):
                        url = ident.text

            # Language
            lang_elem = metadata.find("dc:language", ns)
            language = lang_elem.text if lang_elem is not None and lang_elem.text else "tr"

            # Subject keywords
            keywords = []
            for subj in metadata.findall("dc:subject", ns):
                if subj.text:
                    keywords.append(subj.text)

            papers.append(Paper(
                title=title,
                authors=authors,
                year=year,
                journal=journal,
                doi=doi,
                url=url,
                abstract=description if description else None,
                source_api=self.SOURCE_NAME,
                open_access=True,
                keywords=keywords,
                language=language,
            ))

        return papers
