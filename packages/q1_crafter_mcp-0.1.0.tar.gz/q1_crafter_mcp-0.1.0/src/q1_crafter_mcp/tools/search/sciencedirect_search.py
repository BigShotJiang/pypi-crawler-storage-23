"""
Elsevier ScienceDirect API client.

Provides full-text access to Elsevier journal articles.
Requires institutional API key.

API Docs: https://dev.elsevier.com/documentation/ScienceDirectSearchAPI.wadl
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class ScienceDirectSearchClient(BaseSearchClient):
    """Client for the Elsevier ScienceDirect Search API."""

    SOURCE_NAME = "sciencedirect"
    BASE_URL = "https://api.elsevier.com/content/search/sciencedirect"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 3.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.elsevier_api_key:
            headers["X-ELS-APIKey"] = self.settings.elsevier_api_key
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "qs": config.query,
            "count": min(max_results, 25),
            "display": "standard",
        }

        if config.year_from:
            params["date"] = f"{config.year_from}-"
            if config.year_to:
                params["date"] = f"{config.year_from}-{config.year_to}"
        elif config.year_to:
            params["date"] = f"-{config.year_to}"

        data = await self._fetch(self.BASE_URL, params=params)
        results = data.get("search-results", {}).get("entry", [])

        papers = []
        for item in results:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("dc:title", "")
        if not title:
            return None

        authors = []
        creator = item.get("dc:creator", "")
        if creator:
            parts = creator.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        year = None
        load_date = item.get("prism:coverDate", "")
        if load_date:
            try:
                year = int(load_date[:4])
            except (ValueError, IndexError):
                pass

        doi = item.get("prism:doi")

        # Get link
        links = item.get("link", [])
        link_url = None
        for link in links:
            if isinstance(link, dict) and link.get("@ref") == "scidir":
                link_url = link.get("@href")
                break

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("prism:publicationName", ""),
            volume=item.get("prism:volume"),
            issue=item.get("prism:issueIdentifier"),
            pages=item.get("prism:pageRange"),
            doi=doi,
            url=link_url or (f"https://doi.org/{doi}" if doi else None),
            abstract=item.get("dc:description"),
            source_api=self.SOURCE_NAME,
            open_access=item.get("openaccess") == "true",
        )
