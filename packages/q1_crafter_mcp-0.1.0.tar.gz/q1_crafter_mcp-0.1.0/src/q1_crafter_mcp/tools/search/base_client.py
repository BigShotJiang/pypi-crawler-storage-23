"""
Base search client — abstract interface for all academic API clients.

Provides common HTTP session management, retry logic, timeout handling,
and rate limit awareness. All search modules extend this class.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from typing import Any, Optional

import httpx
from loguru import logger
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Paper, SearchConfig


class BaseSearchClient(ABC):
    """Abstract base class for all academic search API clients."""

    # Subclasses should set these
    SOURCE_NAME: str = "unknown"
    BASE_URL: str = ""
    REQUIRES_KEY: bool = False
    DEFAULT_RATE_LIMIT: float = 1.0  # requests per second

    def __init__(self, settings: Settings):
        self.settings = settings
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.settings.request_timeout),
                follow_redirects=True,
                headers=self._get_default_headers(),
            )
        return self._client

    async def close(self):
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    def _get_default_headers(self) -> dict[str, str]:
        """Return default HTTP headers. Subclasses can override."""
        return {
            "User-Agent": "Q1CrafterMCP/0.1.0 (Academic Research Tool)",
            "Accept": "application/json",
        }

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.TimeoutException, httpx.HTTPStatusError)),
        reraise=True,
    )
    async def _fetch(
        self,
        url: str,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """
        Make an HTTP GET request with retry logic.

        Retries up to 3 times with exponential backoff for
        timeouts and HTTP errors.
        """
        client = await self._get_client()
        logger.debug(f"[{self.SOURCE_NAME}] GET {url} params={params}")

        response = await client.get(url, params=params, headers=headers)
        response.raise_for_status()

        return response.json()

    async def _fetch_xml(
        self,
        url: str,
        params: Optional[dict[str, Any]] = None,
    ) -> str:
        """Make an HTTP GET request expecting XML/text response."""
        client = await self._get_client()
        logger.debug(f"[{self.SOURCE_NAME}] GET (XML) {url} params={params}")

        response = await client.get(url, params=params)
        response.raise_for_status()

        return response.text

    @abstractmethod
    async def search(self, config: SearchConfig) -> list[Paper]:
        """
        Execute a search query against the API.

        Args:
            config: Search configuration with query, filters, etc.

        Returns:
            List of Paper objects found.
        """
        ...

    def is_available(self) -> bool:
        """Check if this source is configured and available."""
        return self.settings.is_source_available(self.SOURCE_NAME)

    async def safe_search(self, config: SearchConfig) -> list[Paper]:
        """
        Execute search with full error handling.

        Returns an empty list if the source fails, logging the error.
        This ensures one failing API doesn't break the aggregator.
        """
        if not self.is_available():
            logger.debug(f"[{self.SOURCE_NAME}] Skipped — not configured")
            return []

        try:
            results = await self.search(config)
            logger.info(f"[{self.SOURCE_NAME}] Found {len(results)} results")
            return results
        except httpx.TimeoutException:
            logger.warning(f"[{self.SOURCE_NAME}] Request timed out")
            return []
        except httpx.HTTPStatusError as e:
            logger.warning(f"[{self.SOURCE_NAME}] HTTP {e.response.status_code}: {e}")
            return []
        except Exception as e:
            logger.error(f"[{self.SOURCE_NAME}] Unexpected error: {e}")
            return []
        finally:
            await self.close()
