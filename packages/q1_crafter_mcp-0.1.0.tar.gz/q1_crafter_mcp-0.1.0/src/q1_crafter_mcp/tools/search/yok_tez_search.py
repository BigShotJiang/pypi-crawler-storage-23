"""
YÖK Tez Merkezi scraper.

Searches Turkish theses and dissertations via web scraping.
No official API — uses httpx + BeautifulSoup.

URL: https://tez.yok.gov.tr/
"""

from __future__ import annotations

import re
from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class YokTezSearchClient(BaseSearchClient):
    """Web scraper for YÖK Tez Merkezi (Turkish thesis database)."""

    SOURCE_NAME = "yok_tez"
    BASE_URL = "https://tez.yok.gov.tr/UlsalTezMerkezi"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 1.0  # Be polite to avoid blocking

    def _get_default_headers(self) -> dict[str, str]:
        return {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7",
        }

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search YÖK Tez Merkezi."""
        max_results = min(config.max_results, self.settings.max_results_per_source, 30)

        try:
            from bs4 import BeautifulSoup

            client = await self._get_client()

            # Step 1: Get the search page to obtain any CSRF tokens
            search_url = f"{self.BASE_URL}/tezSorworguSonworucYeni.jsp"
            form_data = {
                "TezAd": config.query,
                "textDizin": "",
                "topp": str(max_results),
            }

            response = await client.post(
                search_url,
                data=form_data,
                follow_redirects=True,
            )
            response.raise_for_status()

            soup = BeautifulSoup(response.text, "html.parser")
            papers = self._parse_results(soup)

            return papers[:max_results]

        except ImportError:
            logger.warning("[yok_tez] beautifulsoup4 not installed")
            return []
        except Exception as e:
            logger.error(f"[yok_tez] Scraping error: {e}")
            return []

    def _parse_results(self, soup) -> list[Paper]:
        """Parse search results from the HTML page."""
        papers = []

        # Look for result rows in the page
        rows = soup.find_all("tr", class_=re.compile(r"sonuc"))
        if not rows:
            # Try alternative selectors
            rows = soup.find_all("div", class_=re.compile(r"tez"))

        for row in rows:
            try:
                paper = self._parse_row(row)
                if paper:
                    papers.append(paper)
            except Exception as e:
                logger.debug(f"[yok_tez] Failed to parse row: {e}")
                continue

        return papers

    def _parse_row(self, row) -> Optional[Paper]:
        """Parse a single result row."""
        # Extract text content
        cells = row.find_all("td")
        if not cells or len(cells) < 3:
            # Try div-based layout
            title_elem = row.find(["a", "span"], class_=re.compile(r"(title|baslik)"))
            if not title_elem:
                return None
            title = title_elem.get_text(strip=True)
            author_name = ""
            year = None
        else:
            title = cells[0].get_text(strip=True) if cells else ""
            author_name = cells[1].get_text(strip=True) if len(cells) > 1 else ""
            year_text = cells[2].get_text(strip=True) if len(cells) > 2 else ""
            try:
                year = int(year_text) if year_text else None
            except ValueError:
                match = re.search(r"(\d{4})", year_text)
                year = int(match.group(1)) if match else None

        if not title:
            return None

        authors = []
        if author_name:
            parts = author_name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1],
            ))

        # Extract URL
        link = row.find("a", href=True)
        url = link["href"] if link else None
        if url and not url.startswith("http"):
            url = f"{self.BASE_URL}/{url}"

        return Paper(
            title=title,
            authors=authors,
            year=year,
            url=url,
            source_api=self.SOURCE_NAME,
            language="tr",
            publication_type="thesis",
        )
