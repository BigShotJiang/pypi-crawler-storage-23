"""
arXiv API client.

Searches the arXiv repository using its Atom feed API.
Covers physics, mathematics, computer science, and economics preprints.

API Docs: https://info.arxiv.org/help/api/
"""

from __future__ import annotations

import re
from typing import Any, Optional

import feedparser
from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class ArxivSearchClient(BaseSearchClient):
    """Client for the arXiv Atom feed API."""

    SOURCE_NAME = "arxiv"
    BASE_URL = "http://export.arxiv.org/api/query"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 3.0  # 3 req/s

    # arXiv category mappings
    FIELD_CATEGORIES = {
        "cs": "cs.*",
        "computer_science": "cs.*",
        "physics": "physics.*",
        "mathematics": "math.*",
        "math": "math.*",
        "biology": "q-bio.*",
        "economics": "econ.*",
        "engineering": "eess.*",
        "statistics": "stat.*",
    }

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search arXiv papers via the Atom feed API."""
        max_results = min(config.max_results, self.settings.max_results_per_source)

        # Build the search query
        search_query = f"all:{config.query}"

        # Add category filter if field is specified
        if config.field and config.field.lower() in self.FIELD_CATEGORIES:
            cat = self.FIELD_CATEGORIES[config.field.lower()]
            search_query = f"({search_query}) AND cat:{cat}"

        params = {
            "search_query": search_query,
            "start": 0,
            "max_results": max_results,
            "sortBy": "relevance",
            "sortOrder": "descending",
        }

        xml_text = await self._fetch_xml(self.BASE_URL, params=params)
        feed = feedparser.parse(xml_text)

        papers = []
        for entry in feed.entries:
            paper = self._parse_entry(entry, config)
            if paper:
                papers.append(paper)

        return papers

    def _parse_entry(self, entry: Any, config: SearchConfig) -> Optional[Paper]:
        """Parse a feedparser entry into a Paper object."""
        title = entry.get("title", "").replace("\n", " ").strip()
        if not title:
            return None

        # Extract year from published date
        published = entry.get("published", "")
        year = None
        if published:
            match = re.search(r"(\d{4})", published)
            if match:
                year = int(match.group(1))

        # Apply year filter
        if year:
            if config.year_from and year < config.year_from:
                return None
            if config.year_to and year > config.year_to:
                return None

        # Parse authors
        authors = []
        for a in entry.get("authors", []):
            name = a.get("name", "")
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        # Extract DOI if available
        doi = None
        for link in entry.get("links", []):
            href = link.get("href", "")
            if "doi.org" in href:
                doi = href.split("doi.org/")[-1]
                break

        # arXiv ID
        arxiv_id = entry.get("id", "")
        pdf_url = None
        for link in entry.get("links", []):
            if link.get("type") == "application/pdf":
                pdf_url = link.get("href")
                break

        # Categories
        categories = [t.get("term", "") for t in entry.get("tags", [])]

        abstract = entry.get("summary", "").replace("\n", " ").strip()

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal="arXiv",
            doi=doi,
            url=arxiv_id,
            abstract=abstract,
            citations_count=0,  # arXiv doesn't provide citation counts
            source_api=self.SOURCE_NAME,
            open_access=True,  # All arXiv papers are open access
            pdf_url=pdf_url,
            keywords=categories,
            publication_type="preprint",
        )
