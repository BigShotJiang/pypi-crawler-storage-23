"""
Europe PMC API client.

Searches the Europe PMC database for biomedical literature.
No API key required.

API Docs: https://europepmc.org/RestfulWebService
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class EuropePMCSearchClient(BaseSearchClient):
    """Client for the Europe PMC REST API."""

    SOURCE_NAME = "europepmc"
    BASE_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest"
    REQUIRES_KEY = False
    DEFAULT_RATE_LIMIT = 10.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        url = f"{self.BASE_URL}/search"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        query = config.query
        if config.year_from and config.year_to:
            query += f" PUB_YEAR:[{config.year_from} TO {config.year_to}]"
        elif config.year_from:
            query += f" PUB_YEAR:[{config.year_from} TO 2099]"
        elif config.year_to:
            query += f" PUB_YEAR:[1900 TO {config.year_to}]"

        if config.open_access_only:
            query += " OPEN_ACCESS:y"

        params = {
            "query": query,
            "format": "json",
            "pageSize": min(max_results, 100),
            "resultType": "core",
            "sort": "RELEVANCE",
        }

        data = await self._fetch(url, params=params)
        results = data.get("resultList", {}).get("result", [])

        papers = []
        for item in results:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        authors = []
        for a in item.get("authorList", {}).get("author", []):
            authors.append(Author(
                first_name=a.get("firstName", ""),
                last_name=a.get("lastName", ""),
                affiliation=a.get("affiliation"),
            ))

        year = None
        pub_year = item.get("pubYear")
        if pub_year:
            try:
                year = int(pub_year)
            except (ValueError, TypeError):
                pass

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("journalTitle", ""),
            volume=item.get("journalVolume"),
            issue=item.get("issue"),
            pages=item.get("pageInfo"),
            doi=item.get("doi"),
            url=f"https://europepmc.org/article/{item.get('source','')}/{item.get('id','')}",
            abstract=item.get("abstractText"),
            citations_count=item.get("citedByCount", 0),
            source_api=self.SOURCE_NAME,
            open_access=item.get("isOpenAccess") == "Y",
            keywords=item.get("keywordList", {}).get("keyword", []),
            publication_type=item.get("pubType", ""),
        )
