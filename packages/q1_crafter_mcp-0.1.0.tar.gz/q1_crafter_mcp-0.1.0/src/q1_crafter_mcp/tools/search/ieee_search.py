"""
IEEE Xplore API client.

Searches IEEE publications for engineering and CS papers.
Free tier: 200 requests/day.

API Docs: https://developer.ieee.org/docs/read/Metadata_API_details
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class IEEESearchClient(BaseSearchClient):
    """Client for the IEEE Xplore API."""

    SOURCE_NAME = "ieee"
    BASE_URL = "https://ieeexploreapi.ieee.org/api/v1/search/articles"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 3.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        max_results = min(config.max_results, self.settings.max_results_per_source)

        params: dict[str, Any] = {
            "apikey": self.settings.ieee_api_key,
            "querytext": config.query,
            "max_records": min(max_results, 200),
            "sort_field": "article_number",
            "sort_order": "desc",
        }

        if config.year_from:
            params["start_year"] = config.year_from
        if config.year_to:
            params["end_year"] = config.year_to
        if config.open_access_only:
            params["open_access"] = "True"

        data = await self._fetch(self.BASE_URL, params=params)
        articles = data.get("articles", [])

        papers = []
        for item in articles:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        authors = []
        author_list = item.get("authors", {}).get("authors", [])
        for a in author_list:
            name = a.get("full_name", "")
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
                affiliation=a.get("affiliation"),
            ))

        year = None
        pub_year = item.get("publication_year")
        if pub_year:
            try:
                year = int(pub_year)
            except (ValueError, TypeError):
                pass

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("publication_title", ""),
            volume=item.get("volume"),
            issue=item.get("issue"),
            pages=(
                f"{item['start_page']}-{item['end_page']}"
                if item.get("start_page") and item.get("end_page")
                else None
            ),
            doi=item.get("doi"),
            url=item.get("html_url") or item.get("pdf_url"),
            abstract=item.get("abstract"),
            citations_count=item.get("citing_paper_count", 0),
            source_api=self.SOURCE_NAME,
            open_access=item.get("access_type") == "OPEN_ACCESS",
            pdf_url=item.get("pdf_url"),
            keywords=item.get("index_terms", {}).get("author_terms", {}).get("terms", []),
            publication_type=item.get("content_type", ""),
        )
