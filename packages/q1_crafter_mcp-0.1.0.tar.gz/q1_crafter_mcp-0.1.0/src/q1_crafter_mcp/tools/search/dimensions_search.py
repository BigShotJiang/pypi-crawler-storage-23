"""
Dimensions API client.

Provides funding data and citation metrics.
Free academic plan available upon request.

API Docs: https://docs.dimensions.ai/dsl/
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class DimensionsSearchClient(BaseSearchClient):
    """Client for the Dimensions API."""

    SOURCE_NAME = "dimensions"
    BASE_URL = "https://app.dimensions.ai/api"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 5.0

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.dimensions_api_key:
            headers["Authorization"] = f"JWT {self.settings.dimensions_api_key}"
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        max_results = min(config.max_results, self.settings.max_results_per_source)
        url = f"{self.BASE_URL}/dsl.json"

        query = f'search publications in title_abstract_only for "\\"{config.query}\\"" '
        query += f"return publications[all] limit {min(max_results, 100)}"

        if config.year_from and config.year_to:
            query = query.replace(
                "return",
                f"where year >= {config.year_from} and year <= {config.year_to} return",
            )
        elif config.year_from:
            query = query.replace(
                "return", f"where year >= {config.year_from} return"
            )
        elif config.year_to:
            query = query.replace(
                "return", f"where year <= {config.year_to} return"
            )

        if config.open_access_only:
            query = query.replace(
                "return", 'and open_access = "all_oa" return'
            )

        client = await self._get_client()
        response = await client.post(url, json={"query": query})
        response.raise_for_status()
        data = response.json()

        pubs = data.get("publications", [])
        papers = []
        for item in pubs:
            paper = self._parse_item(item)
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any]) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        authors = []
        for a in item.get("authors", []):
            fn = a.get("first_name", "")
            ln = a.get("last_name", "")
            if not fn and not ln:
                # Try full name
                name = a.get("name", "")
                parts = name.rsplit(" ", 1)
                fn = parts[0] if len(parts) > 1 else ""
                ln = parts[-1] if parts else ""
            authors.append(Author(
                first_name=fn,
                last_name=ln,
                orcid=a.get("orcid"),
            ))

        doi = item.get("doi")

        return Paper(
            title=title,
            authors=authors,
            year=item.get("year"),
            journal=item.get("journal", {}).get("title", "") if isinstance(item.get("journal"), dict) else "",
            volume=item.get("volume"),
            issue=item.get("issue"),
            pages=item.get("pages"),
            doi=doi,
            url=f"https://doi.org/{doi}" if doi else None,
            abstract=item.get("abstract"),
            citations_count=item.get("times_cited", 0),
            source_api=self.SOURCE_NAME,
            open_access=bool(item.get("open_access")),
            keywords=item.get("concepts", []),
            publication_type=item.get("type", ""),
        )
