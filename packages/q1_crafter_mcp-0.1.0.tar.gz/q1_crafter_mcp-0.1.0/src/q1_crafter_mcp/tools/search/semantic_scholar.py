"""
Semantic Scholar API client.

Uses the Semantic Scholar Graph API to search for papers,
retrieve citations, and get reference lists.

API Docs: https://api.semanticscholar.org/
"""

from __future__ import annotations

from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class SemanticScholarClient(BaseSearchClient):
    """Client for the Semantic Scholar Graph API."""

    SOURCE_NAME = "semantic_scholar"
    BASE_URL = "https://api.semanticscholar.org/graph/v1"
    REQUIRES_KEY = False  # Works without key but with lower rate limit
    DEFAULT_RATE_LIMIT = 1.0  # 1 req/s without key, 10 req/s with key

    PAPER_FIELDS = (
        "paperId,externalIds,title,abstract,year,venue,publicationVenue,"
        "citationCount,openAccessPdf,authors,journal,isOpenAccess,"
        "fieldsOfStudy,publicationTypes"
    )

    def _get_default_headers(self) -> dict[str, str]:
        headers = super()._get_default_headers()
        if self.settings.semantic_scholar_api_key:
            headers["x-api-key"] = self.settings.semantic_scholar_api_key
        return headers

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search papers via Semantic Scholar."""
        url = f"{self.BASE_URL}/paper/search"

        max_results = min(config.max_results, self.settings.max_results_per_source)
        params: dict[str, Any] = {
            "query": config.query,
            "limit": min(max_results, 100),  # API max per page is 100
            "fields": self.PAPER_FIELDS,
        }

        if config.year_from and config.year_to:
            params["year"] = f"{config.year_from}-{config.year_to}"
        elif config.year_from:
            params["year"] = f"{config.year_from}-"
        elif config.year_to:
            params["year"] = f"-{config.year_to}"

        if config.field:
            field_mapping = {
                "medicine": "Medicine",
                "engineering": "Engineering",
                "cs": "Computer Science",
                "computer_science": "Computer Science",
                "biology": "Biology",
                "physics": "Physics",
                "chemistry": "Chemistry",
                "mathematics": "Mathematics",
                "social_sciences": "Sociology",
                "psychology": "Psychology",
                "economics": "Economics",
            }
            mapped = field_mapping.get(config.field.lower())
            if mapped:
                params["fieldsOfStudy"] = mapped

        if config.open_access_only:
            params["openAccessPdf"] = ""

        data = await self._fetch(url, params=params)
        papers = []

        for item in data.get("data", []):
            paper = self._parse_paper(item)
            if paper:
                papers.append(paper)

        # Fetch more pages if needed
        total = data.get("total", 0)
        offset = len(papers)
        while offset < max_results and offset < total:
            params["offset"] = offset
            try:
                data = await self._fetch(url, params=params)
                for item in data.get("data", []):
                    paper = self._parse_paper(item)
                    if paper:
                        papers.append(paper)
                offset += len(data.get("data", []))
            except Exception:
                break

        return papers[:max_results]

    async def get_citations(self, paper_id: str, max_results: int = 50) -> list[Paper]:
        """Get papers that cite the given paper."""
        url = f"{self.BASE_URL}/paper/{paper_id}/citations"
        params = {
            "fields": self.PAPER_FIELDS,
            "limit": min(max_results, 100),
        }

        try:
            data = await self._fetch(url, params=params)
            papers = []
            for item in data.get("data", []):
                citing = item.get("citingPaper", {})
                paper = self._parse_paper(citing)
                if paper:
                    papers.append(paper)
            return papers
        except Exception as e:
            logger.error(f"[semantic_scholar] Failed to get citations: {e}")
            return []

    async def get_references(self, paper_id: str, max_results: int = 50) -> list[Paper]:
        """Get papers referenced by the given paper."""
        url = f"{self.BASE_URL}/paper/{paper_id}/references"
        params = {
            "fields": self.PAPER_FIELDS,
            "limit": min(max_results, 100),
        }

        try:
            data = await self._fetch(url, params=params)
            papers = []
            for item in data.get("data", []):
                cited = item.get("citedPaper", {})
                paper = self._parse_paper(cited)
                if paper:
                    papers.append(paper)
            return papers
        except Exception as e:
            logger.error(f"[semantic_scholar] Failed to get references: {e}")
            return []

    def _parse_paper(self, data: dict[str, Any]) -> Optional[Paper]:
        """Parse a Semantic Scholar API response into a Paper object."""
        if not data or not data.get("title"):
            return None

        authors = []
        for a in data.get("authors", []):
            name = a.get("name", "")
            parts = name.rsplit(" ", 1)
            authors.append(Author(
                first_name=parts[0] if len(parts) > 1 else "",
                last_name=parts[-1] if parts else "",
            ))

        # Extract DOI from externalIds
        ext_ids = data.get("externalIds", {}) or {}
        doi = ext_ids.get("DOI")

        # Journal info
        journal_data = data.get("journal") or {}
        journal_name = journal_data.get("name", "") or data.get("venue", "")
        volume = journal_data.get("volume")
        pages = journal_data.get("pages")

        # Open access PDF
        oa_pdf = data.get("openAccessPdf") or {}
        pdf_url = oa_pdf.get("url")

        return Paper(
            title=data.get("title", ""),
            authors=authors,
            year=data.get("year"),
            journal=journal_name,
            volume=volume,
            pages=pages,
            doi=doi,
            url=f"https://api.semanticscholar.org/paper/{data.get('paperId', '')}",
            abstract=data.get("abstract"),
            citations_count=data.get("citationCount", 0),
            source_api=self.SOURCE_NAME,
            open_access=data.get("isOpenAccess", False),
            pdf_url=pdf_url,
            keywords=data.get("fieldsOfStudy") or [],
        )
