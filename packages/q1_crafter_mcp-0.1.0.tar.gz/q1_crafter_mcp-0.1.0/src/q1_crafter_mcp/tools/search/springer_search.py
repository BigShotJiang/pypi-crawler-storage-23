"""
Springer Nature API client.

Searches Springer journal articles via the Open Access and Meta APIs.

API Docs: https://dev.springernature.com/
"""

from __future__ import annotations

from typing import Any, Optional

from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class SpringerSearchClient(BaseSearchClient):
    """Client for the Springer Nature API."""

    SOURCE_NAME = "springer"
    BASE_URL = "https://api.springernature.com"
    REQUIRES_KEY = True
    DEFAULT_RATE_LIMIT = 2.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        # Try open access API first, then metadata API
        papers = await self._search_api(config, "openaccess")
        if not papers:
            papers = await self._search_api(config, "metadata")
        return papers

    async def _search_api(self, config: SearchConfig, api_type: str) -> list[Paper]:
        url = f"{self.BASE_URL}/{api_type}/json"
        max_results = min(config.max_results, self.settings.max_results_per_source)

        query = config.query
        if config.year_from and config.year_to:
            query += f" year:{config.year_from}-{config.year_to}"
        elif config.year_from:
            query += f" year:{config.year_from}-2099"

        params: dict[str, Any] = {
            "q": query,
            "api_key": self.settings.springer_api_key,
            "p": min(max_results, 50),
            "s": 1,
        }

        if config.open_access_only and api_type == "metadata":
            params["q"] += " openaccess:true"

        data = await self._fetch(url, params=params)
        records = data.get("records", [])

        papers = []
        for item in records:
            paper = self._parse_item(item, api_type == "openaccess")
            if paper:
                papers.append(paper)
        return papers[:max_results]

    def _parse_item(self, item: dict[str, Any], is_oa: bool = False) -> Optional[Paper]:
        title = item.get("title", "")
        if not title:
            return None

        authors = []
        for a in item.get("creators", []):
            name = a.get("creator", "")
            parts = name.rsplit(", ", 1)  # Springer uses "Last, First" format
            if len(parts) == 2:
                authors.append(Author(first_name=parts[1], last_name=parts[0]))
            else:
                name_parts = name.rsplit(" ", 1)
                authors.append(Author(
                    first_name=name_parts[0] if len(name_parts) > 1 else "",
                    last_name=name_parts[-1],
                ))

        year = None
        pub_date = item.get("publicationDate", "")
        if pub_date:
            try:
                year = int(pub_date[:4])
            except (ValueError, IndexError):
                pass

        doi = item.get("doi")

        # URLs
        urls = item.get("url", [])
        pdf_url = None
        link_url = None
        for u in urls:
            if isinstance(u, dict):
                if u.get("format") == "pdf":
                    pdf_url = u.get("value")
                elif u.get("format") == "html":
                    link_url = u.get("value")
                elif not link_url:
                    link_url = u.get("value")

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=item.get("publicationName", ""),
            volume=item.get("volume"),
            issue=item.get("number"),
            pages=(
                f"{item['startingPage']}-{item['endingPage']}"
                if item.get("startingPage") and item.get("endingPage")
                else item.get("startingPage")
            ),
            doi=doi,
            url=link_url or (f"https://doi.org/{doi}" if doi else None),
            abstract=item.get("abstract"),
            source_api=self.SOURCE_NAME,
            open_access=is_oa or item.get("openaccess") == "true",
            pdf_url=pdf_url,
            publication_type=item.get("contentType", ""),
        )
