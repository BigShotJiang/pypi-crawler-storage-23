"""
PubMed / NCBI E-utilities API client.

Searches PubMed and PMC using the NCBI E-utilities (esearch + efetch).
Covers biomedical and life sciences literature.

API Docs: https://www.ncbi.nlm.nih.gov/books/NBK25497/
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from typing import Any, Optional

from loguru import logger

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class PubMedSearchClient(BaseSearchClient):
    """Client for the NCBI E-utilities (PubMed)."""

    SOURCE_NAME = "pubmed"
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
    REQUIRES_KEY = True  # Works without but with lower rate limit
    DEFAULT_RATE_LIMIT = 3.0

    async def search(self, config: SearchConfig) -> list[Paper]:
        """Search PubMed using E-utilities esearch + efetch."""
        max_results = min(config.max_results, self.settings.max_results_per_source)

        # Step 1: esearch to get PMIDs
        pmids = await self._esearch(config.query, max_results, config)

        if not pmids:
            return []

        # Step 2: efetch to get full records
        papers = await self._efetch(pmids)
        return papers

    async def _esearch(
        self, query: str, max_results: int, config: SearchConfig
    ) -> list[str]:
        """Search PubMed and return PMIDs."""
        url = f"{self.BASE_URL}/esearch.fcgi"

        # Build query with date filter
        search_query = query
        if config.year_from and config.year_to:
            search_query += f" AND {config.year_from}:{config.year_to}[dp]"
        elif config.year_from:
            search_query += f" AND {config.year_from}:3000[dp]"
        elif config.year_to:
            search_query += f" AND 1900:{config.year_to}[dp]"

        params: dict[str, Any] = {
            "db": "pubmed",
            "term": search_query,
            "retmax": max_results,
            "retmode": "json",
            "sort": "relevance",
        }

        if self.settings.ncbi_api_key:
            params["api_key"] = self.settings.ncbi_api_key

        data = await self._fetch(url, params=params)
        result = data.get("esearchresult", {})
        return result.get("idlist", [])

    async def _efetch(self, pmids: list[str]) -> list[Paper]:
        """Fetch full records for given PMIDs."""
        url = f"{self.BASE_URL}/efetch.fcgi"

        # Process in batches of 200
        papers = []
        for i in range(0, len(pmids), 200):
            batch = pmids[i:i + 200]
            params: dict[str, Any] = {
                "db": "pubmed",
                "id": ",".join(batch),
                "retmode": "xml",
            }

            if self.settings.ncbi_api_key:
                params["api_key"] = self.settings.ncbi_api_key

            xml_text = await self._fetch_xml(url, params=params)
            batch_papers = self._parse_xml(xml_text)
            papers.extend(batch_papers)

        return papers

    def _parse_xml(self, xml_text: str) -> list[Paper]:
        """Parse PubMed XML response into Paper objects."""
        papers = []

        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError as e:
            logger.error(f"[pubmed] XML parse error: {e}")
            return []

        for article in root.findall(".//PubmedArticle"):
            paper = self._parse_article(article)
            if paper:
                papers.append(paper)

        return papers

    def _parse_article(self, article: ET.Element) -> Optional[Paper]:
        """Parse a single PubMed article XML element."""
        medline = article.find(".//MedlineCitation")
        if medline is None:
            return None

        art = medline.find(".//Article")
        if art is None:
            return None

        # Title
        title_elem = art.find(".//ArticleTitle")
        title = "".join(title_elem.itertext()) if title_elem is not None else ""
        if not title:
            return None

        # Authors
        authors = []
        author_list = art.find(".//AuthorList")
        if author_list is not None:
            for a in author_list.findall("Author"):
                first = ""
                last = ""
                fn = a.find("ForeName")
                ln = a.find("LastName")
                if fn is not None:
                    first = fn.text or ""
                if ln is not None:
                    last = ln.text or ""

                aff_elem = a.find(".//Affiliation")
                affiliation = aff_elem.text if aff_elem is not None else None

                if last:  # Only add if we have at least a last name
                    authors.append(Author(
                        first_name=first,
                        last_name=last,
                        affiliation=affiliation,
                    ))

        # Year
        year = None
        pub_date = art.find(".//Journal/JournalIssue/PubDate")
        if pub_date is not None:
            year_elem = pub_date.find("Year")
            if year_elem is not None and year_elem.text:
                year = int(year_elem.text)
            else:
                medline_date = pub_date.find("MedlineDate")
                if medline_date is not None and medline_date.text:
                    match = re.search(r"(\d{4})", medline_date.text)
                    if match:
                        year = int(match.group(1))

        # Journal
        journal_elem = art.find(".//Journal/Title")
        journal = journal_elem.text if journal_elem is not None else ""

        # Volume, Issue, Pages
        ji = art.find(".//Journal/JournalIssue")
        volume = None
        issue = None
        if ji is not None:
            vol_elem = ji.find("Volume")
            volume = vol_elem.text if vol_elem is not None else None
            iss_elem = ji.find("Issue")
            issue = iss_elem.text if iss_elem is not None else None

        pagination = art.find(".//Pagination/MedlinePgn")
        pages = pagination.text if pagination is not None else None

        # DOI
        doi = None
        for eid in article.findall(".//PubmedData/ArticleIdList/ArticleId"):
            if eid.get("IdType") == "doi":
                doi = eid.text
                break

        # PMID
        pmid_elem = medline.find("PMID")
        pmid = pmid_elem.text if pmid_elem is not None else ""

        # Abstract
        abstract_parts = []
        abstract_elem = art.find(".//Abstract")
        if abstract_elem is not None:
            for text in abstract_elem.findall("AbstractText"):
                label = text.get("Label", "")
                content = "".join(text.itertext())
                if label:
                    abstract_parts.append(f"{label}: {content}")
                else:
                    abstract_parts.append(content)
        abstract = " ".join(abstract_parts) if abstract_parts else None

        # Keywords
        keywords = []
        kw_list = medline.find(".//KeywordList")
        if kw_list is not None:
            for kw in kw_list.findall("Keyword"):
                if kw.text:
                    keywords.append(kw.text)

        return Paper(
            title=title,
            authors=authors,
            year=year,
            journal=journal,
            volume=volume,
            issue=issue,
            pages=pages,
            doi=doi,
            url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}/" if pmid else None,
            abstract=abstract,
            citations_count=0,  # PubMed doesn't provide citation counts
            source_api=self.SOURCE_NAME,
            open_access=False,
            keywords=keywords,
            publication_type="journal-article",
        )
