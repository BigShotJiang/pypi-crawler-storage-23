"""
Citation network analyzer — builds and visualizes co-citation
and bibliographic coupling networks.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from loguru import logger

from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper


def generate_citation_network(
    paper_ids: list[str],
    max_nodes: int = 50,
) -> dict[str, Any]:
    """
    Build a citation network from the given papers.

    Returns:
        Dict with 'nodes', 'edges', 'clusters', and 'mermaid' diagram.
    """
    papers = [get_paper(pid) for pid in paper_ids]
    papers = [p for p in papers if p is not None]

    if not papers:
        return {"error": "No papers found", "nodes": [], "edges": []}

    # Limit to top-cited papers for clarity
    papers = sorted(papers, key=lambda p: p.citations_count, reverse=True)[:max_nodes]

    # Build nodes
    nodes = []
    for p in papers:
        label = f"{p.first_author_last_name} ({p.year})" if p.year else p.first_author_last_name
        nodes.append({
            "id": p.id,
            "label": label,
            "title": p.title[:60],
            "citations": p.citations_count,
            "year": p.year,
            "source": p.source_api,
        })

    # Build edges via keyword co-occurrence (since we don't have direct citation links)
    edges = _build_keyword_edges(papers)

    # Cluster by year groups
    clusters = _cluster_by_year(papers)

    # Generate Mermaid diagram
    mermaid = _generate_mermaid(nodes[:20], edges[:30])

    return {
        "nodes": nodes,
        "edges": edges,
        "clusters": clusters,
        "mermaid": mermaid,
        "stats": {
            "total_nodes": len(nodes),
            "total_edges": len(edges),
            "total_clusters": len(clusters),
        },
    }


def _build_keyword_edges(papers: list) -> list[dict[str, Any]]:
    """Build edges between papers that share keywords."""
    edges = []

    for i in range(len(papers)):
        kw_i = set(k.lower() for k in papers[i].keywords)
        if not kw_i:
            continue

        for j in range(i + 1, len(papers)):
            kw_j = set(k.lower() for k in papers[j].keywords)
            shared = kw_i & kw_j

            if len(shared) >= 2:
                edges.append({
                    "source": papers[i].id,
                    "target": papers[j].id,
                    "weight": len(shared),
                    "shared_keywords": list(shared)[:5],
                })

    return sorted(edges, key=lambda e: e["weight"], reverse=True)


def _cluster_by_year(papers: list) -> dict[str, list[str]]:
    """Cluster papers by year ranges."""
    clusters: dict[str, list[str]] = defaultdict(list)

    for p in papers:
        if not p.year:
            clusters["Unknown"].append(p.id)
        elif p.year >= 2023:
            clusters["2023+"].append(p.id)
        elif p.year >= 2020:
            clusters["2020-2022"].append(p.id)
        elif p.year >= 2015:
            clusters["2015-2019"].append(p.id)
        else:
            clusters["Pre-2015"].append(p.id)

    return dict(clusters)


def _generate_mermaid(
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
) -> str:
    """Generate a Mermaid graph diagram string."""
    lines = ["graph LR"]

    # Sanitize labels for Mermaid
    node_map = {}
    for i, node in enumerate(nodes):
        node_id = f"N{i}"
        node_map[node["id"]] = node_id
        label = node["label"].replace('"', "'")
        lines.append(f'    {node_id}["{label}"]')

    # Add edges
    for edge in edges:
        src = node_map.get(edge["source"])
        tgt = node_map.get(edge["target"])
        if src and tgt:
            weight = edge.get("weight", 1)
            if weight >= 3:
                lines.append(f"    {src} ==> {tgt}")
            else:
                lines.append(f"    {src} --> {tgt}")

    return "\n".join(lines)
