"""
Chart generator — creates publication trend charts, keyword distributions,
and source comparison visuals as base64-encoded images.
"""

from __future__ import annotations

import base64
import io
from typing import Any

from loguru import logger


def generate_chart(
    chart_type: str,
    data: dict[str, Any],
    title: str = "",
    width: int = 10,
    height: int = 6,
) -> dict[str, Any]:
    """
    Generate a chart as a base64-encoded PNG image.

    Args:
        chart_type: One of 'bar', 'line', 'pie', 'hbar', 'scatter'
        data: Chart data with 'labels' and 'values' keys
        title: Chart title
        width: Figure width in inches
        height: Figure height in inches

    Returns:
        Dict with 'image_base64', 'mime_type', and 'description'
    """
    try:
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive backend
        import matplotlib.pyplot as plt
    except ImportError:
        return {
            "error": "matplotlib not installed. Install with: pip install matplotlib",
            "data": data,
        }

    labels = data.get("labels", [])
    values = data.get("values", [])

    if not labels or not values:
        return {"error": "No data provided", "data": data}

    fig, ax = plt.subplots(figsize=(width, height))
    fig.patch.set_facecolor("#1a1a2e")
    ax.set_facecolor("#16213e")

    # Color palette
    colors = [
        "#0f3460", "#533483", "#e94560", "#16213e",
        "#0a1931", "#185adb", "#ffc947", "#1c7947",
        "#e23e57", "#88304e", "#522546", "#311d3f",
    ]

    if chart_type == "bar":
        bars = ax.bar(labels, values, color=colors[:len(labels)], edgecolor="white", linewidth=0.5)
        ax.set_xlabel("Category", color="white", fontsize=12)
        ax.set_ylabel("Count", color="white", fontsize=12)
        plt.xticks(rotation=45, ha="right", color="white")
    elif chart_type == "line":
        ax.plot(labels, values, color="#e94560", marker="o", linewidth=2, markersize=6)
        ax.fill_between(labels, values, alpha=0.2, color="#e94560")
        ax.set_xlabel("Year", color="white", fontsize=12)
        ax.set_ylabel("Papers", color="white", fontsize=12)
        plt.xticks(color="white")
    elif chart_type == "pie":
        wedges, texts, autotexts = ax.pie(
            values, labels=labels, autopct="%1.1f%%",
            colors=colors[:len(labels)], textprops={"color": "white"},
            startangle=90, pctdistance=0.85,
        )
        for text in texts:
            text.set_fontsize(9)
    elif chart_type == "hbar":
        ax.barh(labels, values, color=colors[:len(labels)], edgecolor="white", linewidth=0.5)
        ax.set_xlabel("Count", color="white", fontsize=12)
    elif chart_type == "scatter":
        ax.scatter(labels, values, color="#e94560", s=100, edgecolors="white")
        plt.xticks(rotation=45, ha="right", color="white")
    else:
        return {"error": f"Unknown chart type: {chart_type}"}

    ax.tick_params(colors="white")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#ffffff50")
    ax.spines["bottom"].set_color("#ffffff50")

    if title:
        ax.set_title(title, color="white", fontsize=14, fontweight="bold", pad=15)

    plt.tight_layout()

    # Convert to base64
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)

    buf.seek(0)
    img_base64 = base64.b64encode(buf.read()).decode("utf-8")

    return {
        "image_base64": img_base64,
        "mime_type": "image/png",
        "description": f"{chart_type} chart: {title}",
    }


def generate_trend_chart(papers_data: list[dict[str, Any]]) -> dict[str, Any]:
    """Generate a publication trend chart from paper data."""
    from collections import Counter
    years = [p.get("year") for p in papers_data if p.get("year")]
    if not years:
        return {"error": "No year data available"}

    counts = Counter(years)
    sorted_years = sorted(counts.items())
    return generate_chart(
        "line",
        {"labels": [str(y) for y, _ in sorted_years], "values": [c for _, c in sorted_years]},
        title="Publication Trend Over Time",
    )


def generate_source_chart(papers_data: list[dict[str, Any]]) -> dict[str, Any]:
    """Generate a source distribution pie chart."""
    from collections import Counter
    sources = [p.get("source_api", "unknown") for p in papers_data]
    counts = Counter(sources)
    top = counts.most_common(10)
    return generate_chart(
        "pie",
        {"labels": [s for s, _ in top], "values": [c for _, c in top]},
        title="Results by Source",
    )
