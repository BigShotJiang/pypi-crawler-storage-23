"""Visualization tools — tables, charts, citation network graphs."""
