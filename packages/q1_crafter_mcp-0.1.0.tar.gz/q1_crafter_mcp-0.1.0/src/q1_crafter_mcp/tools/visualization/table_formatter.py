"""
Table formatter — generates markdown, CSV, and structured tables
from paper collections for use in reports and manuscripts.
"""

from __future__ import annotations

import csv
import io
from typing import Any

from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper


def generate_table(
    paper_ids: list[str],
    format: str = "markdown",
    columns: list[str] | None = None,
) -> dict[str, str]:
    """
    Generate a formatted table from a collection of papers.

    Args:
        paper_ids: List of paper IDs to include.
        format: 'markdown', 'csv', or 'apa_table'
        columns: Which columns to include. Defaults to standard set.

    Returns:
        Dict with 'table' (string) and 'format' keys.
    """
    papers = [get_paper(pid) for pid in paper_ids]
    papers = [p for p in papers if p is not None]

    if not papers:
        return {"table": "No papers found.", "format": format}

    if columns is None:
        columns = ["#", "Authors", "Year", "Title", "Journal", "Citations", "DOI"]

    # Build rows
    rows = []
    for i, p in enumerate(papers, 1):
        row = {}
        for col in columns:
            col_lower = col.lower()
            if col_lower == "#":
                row[col] = str(i)
            elif col_lower == "authors":
                if len(p.authors) > 3:
                    row[col] = f"{p.authors[0].full_name} et al."
                else:
                    row[col] = ", ".join(a.full_name for a in p.authors)
            elif col_lower == "year":
                row[col] = str(p.year or "N/A")
            elif col_lower == "title":
                row[col] = p.title[:80] + ("..." if len(p.title) > 80 else "")
            elif col_lower == "journal":
                row[col] = p.journal or "N/A"
            elif col_lower == "citations":
                row[col] = str(p.citations_count)
            elif col_lower == "doi":
                row[col] = p.doi or "—"
            elif col_lower == "source":
                row[col] = p.source_api
            elif col_lower == "oa":
                row[col] = "✅" if p.open_access else "❌"
        rows.append(row)

    if format == "markdown":
        return {"table": _to_markdown(columns, rows), "format": "markdown"}
    elif format == "csv":
        return {"table": _to_csv(columns, rows), "format": "csv"}
    elif format == "apa_table":
        return {"table": _to_apa_table(columns, rows, papers), "format": "apa_table"}
    else:
        return {"table": _to_markdown(columns, rows), "format": "markdown"}


def _to_markdown(columns: list[str], rows: list[dict[str, str]]) -> str:
    """Generate a markdown table."""
    # Calculate column widths
    widths = {col: len(col) for col in columns}
    for row in rows:
        for col in columns:
            widths[col] = max(widths[col], len(row.get(col, "")))

    lines = []

    # Header
    header = "| " + " | ".join(col.ljust(widths[col]) for col in columns) + " |"
    separator = "| " + " | ".join("-" * widths[col] for col in columns) + " |"
    lines.append(header)
    lines.append(separator)

    # Rows
    for row in rows:
        line = "| " + " | ".join(row.get(col, "").ljust(widths[col]) for col in columns) + " |"
        lines.append(line)

    return "\n".join(lines)


def _to_csv(columns: list[str], rows: list[dict[str, str]]) -> str:
    """Generate a CSV string."""
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=columns)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return output.getvalue()


def _to_apa_table(
    columns: list[str],
    rows: list[dict[str, str]],
    papers: list,
) -> str:
    """Generate an APA 7th edition formatted table."""
    lines = []
    lines.append("Table X")
    lines.append("Summary of Reviewed Studies")
    lines.append("")
    lines.append("_" * 80)

    # Header row
    header = "  ".join(col.ljust(15) for col in columns[:5])
    lines.append(header)
    lines.append("_" * 80)

    for row in rows:
        line = "  ".join(row.get(col, "").ljust(15) for col in columns[:5])
        lines.append(line)

    lines.append("_" * 80)
    lines.append("")
    lines.append(f"Note. N = {len(rows)} studies included in the review.")

    return "\n".join(lines)
