"""
Q1 Crafter MCP — Academic Research MCP Server

Automates the full academic research cycle (source discovery → analysis →
visualization → APA 7 writing → .docx output) as an MCP server for
Claude Desktop.
"""

__version__ = "0.1.0"
__app_name__ = "q1-crafter-mcp"
