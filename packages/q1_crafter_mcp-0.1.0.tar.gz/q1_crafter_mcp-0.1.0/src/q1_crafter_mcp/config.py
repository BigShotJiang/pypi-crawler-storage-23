"""
Configuration module for Q1 Crafter MCP.

Loads settings from environment variables and .env files.
All API keys default to empty strings — the server gracefully
disables sources whose keys are not configured.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # ── Free API Keys ──────────────────────────────────────────
    semantic_scholar_api_key: str = Field(
        default="",
        description="Semantic Scholar API key (optional, increases rate limit)",
    )
    ncbi_api_key: str = Field(
        default="",
        description="NCBI/PubMed API key (free, registration required)",
    )
    core_api_key: str = Field(
        default="",
        description="CORE API key (free, registration required)",
    )
    unpaywall_email: str = Field(
        default="",
        description="Unpaywall requires only an email address",
    )

    # ── Paid / Institutional API Keys ──────────────────────────
    scopus_api_key: str = Field(
        default="",
        description="Elsevier Scopus API key",
    )
    wos_api_key: str = Field(
        default="",
        description="Web of Science (Clarivate) API key",
    )
    ieee_api_key: str = Field(
        default="",
        description="IEEE Xplore API key",
    )
    springer_api_key: str = Field(
        default="",
        description="Springer Nature API key",
    )
    elsevier_api_key: str = Field(
        default="",
        description="Elsevier ScienceDirect API key",
    )
    dimensions_api_key: str = Field(
        default="",
        description="Dimensions API key",
    )

    # ── Turkish Sources ────────────────────────────────────────
    trdizin_api_key: str = Field(
        default="",
        description="TR Dizin API key (TÜBİTAK ULAKBİM)",
    )

    # ── General Settings ───────────────────────────────────────
    max_results_per_source: int = Field(
        default=50,
        description="Maximum results to fetch from each API source",
    )
    max_total_sources: int = Field(
        default=200,
        description="Total source cap across all APIs",
    )
    request_timeout: int = Field(
        default=30,
        description="HTTP request timeout in seconds",
    )
    output_dir: str = Field(
        default="./output",
        description="Directory for generated .docx and figure files",
    )
    log_level: str = Field(
        default="INFO",
        description="Logging level (DEBUG, INFO, WARNING, ERROR)",
    )

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
    }

    # ── Helpers ────────────────────────────────────────────────

    def get_output_path(self) -> Path:
        """Return the resolved output directory path, creating it if needed."""
        path = Path(self.output_dir).resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    def get_figures_path(self) -> Path:
        """Return the figures subdirectory path, creating it if needed."""
        path = self.get_output_path() / "figures"
        path.mkdir(parents=True, exist_ok=True)
        return path

    def get_logs_path(self) -> Path:
        """Return the logs directory path, creating it if needed."""
        path = Path("logs").resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    def is_source_available(self, source: str) -> bool:
        """Check whether a given source has the required API key configured."""
        key_map: dict[str, str] = {
            "semantic_scholar": self.semantic_scholar_api_key,
            "pubmed": self.ncbi_api_key,
            "core": self.core_api_key,
            "unpaywall": self.unpaywall_email,
            "scopus": self.scopus_api_key,
            "wos": self.wos_api_key,
            "ieee": self.ieee_api_key,
            "springer": self.springer_api_key,
            "sciencedirect": self.elsevier_api_key,
            "dimensions": self.dimensions_api_key,
            "trdizin": self.trdizin_api_key,
        }
        # Sources that don't require keys
        no_key_required = {
            "arxiv", "crossref", "openalex", "europepmc",
            "doaj", "base_search", "dergipark", "yok_tez",
        }
        if source in no_key_required:
            return True
        key = key_map.get(source, "")
        return bool(key)

    def get_available_sources(self) -> list[str]:
        """Return a list of all currently available/configured sources."""
        all_sources = [
            "semantic_scholar", "arxiv", "crossref", "openalex",
            "pubmed", "europepmc", "core", "doaj", "base_search",
            "unpaywall", "scopus", "wos", "ieee", "springer",
            "sciencedirect", "dimensions", "trdizin", "dergipark",
            "yok_tez",
        ]
        return [s for s in all_sources if self.is_source_available(s)]


# Singleton instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get the global settings instance (lazy loaded)."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
