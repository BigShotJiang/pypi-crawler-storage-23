"""
Q1 Crafter MCP — Main Server

Entry point for the MCP server. Registers all tools and handles
Claude Desktop communication via stdio JSON-RPC.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any

from loguru import logger
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from q1_crafter_mcp.config import get_settings
from q1_crafter_mcp.models import (
    APISourceStatus,
    APIStatusReport,
    SearchConfig,
)

# ─── Server Instance ──────────────────────────────────────────

app = Server("q1-crafter-mcp")


# ─── Tool Definitions ────────────────────────────────────────


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Register all available MCP tools."""
    return [
        # ── Search Tools ──
        Tool(
            name="search_academic",
            description=(
                "Search across 15+ academic databases in parallel. "
                "Returns deduplicated papers with metadata, DOIs, citations, "
                "and open access info. Supports year filtering, field selection, "
                "and language preferences."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "The search query (e.g. 'machine learning in healthcare')",
                    },
                    "max_results": {
                        "type": "integer",
                        "default": 100,
                        "description": "Total target number of results",
                    },
                    "year_from": {
                        "type": "integer",
                        "description": "Filter: earliest publication year",
                    },
                    "year_to": {
                        "type": "integer",
                        "description": "Filter: latest publication year",
                    },
                    "field": {
                        "type": "string",
                        "description": "Academic field (medicine, engineering, social_sciences, etc.)",
                    },
                    "language": {
                        "type": "string",
                        "default": "en",
                        "description": "Language filter (en, tr, all)",
                    },
                    "sources": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Specific sources to query (omit for all available)",
                    },
                    "open_access_only": {
                        "type": "boolean",
                        "default": False,
                        "description": "Only return open access papers",
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="search_by_doi",
            description=(
                "Look up a single paper by its DOI. Returns full metadata "
                "from CrossRef, Unpaywall, and other sources."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "doi": {
                        "type": "string",
                        "description": "The DOI to look up (e.g. '10.1234/example')",
                    },
                },
                "required": ["doi"],
            },
        ),
        Tool(
            name="search_citations",
            description=(
                "Find papers that cite a given paper (backward citation tracking). "
                "Useful for tracing research impact."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_id": {
                        "type": "string",
                        "description": "Internal paper ID or DOI",
                    },
                    "max_results": {
                        "type": "integer",
                        "default": 50,
                    },
                },
                "required": ["paper_id"],
            },
        ),
        Tool(
            name="search_references",
            description=(
                "Get the reference list of a given paper (forward citation tracking). "
                "Shows what papers the given paper cites."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_id": {
                        "type": "string",
                        "description": "Internal paper ID or DOI",
                    },
                    "max_results": {
                        "type": "integer",
                        "default": 50,
                    },
                },
                "required": ["paper_id"],
            },
        ),

        # ── Analysis Tools ──
        Tool(
            name="analyze_literature",
            description=(
                "Analyze a collection of papers to identify research gaps, "
                "main themes, methodological trends, temporal patterns, "
                "and controversial topics."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of paper IDs to analyze",
                    },
                },
                "required": ["paper_ids"],
            },
        ),
        Tool(
            name="validate_citations",
            description=(
                "Bidirectional validation between in-text citations and the "
                "references list. Detects orphan citations, missing references, "
                "malformed entries, and DOI issues."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The manuscript text containing in-text citations",
                    },
                    "references": {
                        "type": "array",
                        "items": {"type": "object"},
                        "description": "List of reference objects",
                    },
                },
                "required": ["text", "references"],
            },
        ),
        Tool(
            name="extract_keywords",
            description=(
                "Extract key terms and concepts from paper abstracts "
                "using TF-IDF and co-occurrence analysis."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of paper IDs to extract keywords from",
                    },
                    "max_keywords": {
                        "type": "integer",
                        "default": 20,
                    },
                },
                "required": ["paper_ids"],
            },
        ),

        # ── Visualization Tools ──
        Tool(
            name="generate_comparison_table",
            description=(
                "Create a comparison table of selected papers across specified "
                "dimensions (e.g., method, sample size, findings). "
                "Outputs a PNG image."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Papers to include in the table",
                    },
                    "columns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Columns to compare (e.g., 'Method', 'Dataset', 'Results')",
                    },
                },
                "required": ["paper_ids"],
            },
        ),
        Tool(
            name="generate_trend_chart",
            description=(
                "Generate publication trend charts — yearly counts, "
                "citation distributions, source breakdown, and journal "
                "quartile distribution. Outputs PNG images."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Papers to visualize",
                    },
                    "chart_type": {
                        "type": "string",
                        "enum": [
                            "publication_trend",
                            "citation_distribution",
                            "source_distribution",
                            "quartile_distribution",
                        ],
                        "default": "publication_trend",
                    },
                },
                "required": ["paper_ids"],
            },
        ),
        Tool(
            name="generate_citation_network",
            description=(
                "Visualize the citation network as a directed graph. "
                "Node size = citation count, color = year. "
                "Top 10 most influential nodes are labeled. Outputs PNG."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Papers to include in the network",
                    },
                },
                "required": ["paper_ids"],
            },
        ),

        # ── Writing & Output Tools ──
        Tool(
            name="write_section",
            description=(
                "Write a specific section of the manuscript in formal "
                "academic style with proper in-text citations. "
                "Sections: introduction, literature_review, methodology, "
                "results, discussion, conclusion."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "section": {
                        "type": "string",
                        "enum": [
                            "introduction",
                            "literature_review",
                            "methodology",
                            "results",
                            "discussion",
                            "conclusion",
                        ],
                    },
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Source papers to reference",
                    },
                    "instructions": {
                        "type": "string",
                        "description": "Additional writing instructions",
                    },
                    "word_count_target": {
                        "type": "integer",
                        "default": 800,
                    },
                    "language": {
                        "type": "string",
                        "default": "en",
                    },
                },
                "required": ["section", "paper_ids"],
            },
        ),
        Tool(
            name="format_references_apa7",
            description=(
                "Format a list of papers into APA 7th Edition reference "
                "list entries. Handles all author-count rules, DOI formatting, "
                "italics, and alphabetical ordering."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "paper_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Papers to format as references",
                    },
                },
                "required": ["paper_ids"],
            },
        ),
        Tool(
            name="build_docx",
            description=(
                "Assemble all sections, figures, tables, and references into "
                "a final .docx manuscript. Uses Times New Roman 12pt, "
                "double spacing, 1-inch margins (APA standard). "
                "Performs quality checks before output."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "manuscript": {
                        "type": "object",
                        "description": "Complete manuscript data",
                    },
                    "output_filename": {
                        "type": "string",
                        "default": "manuscript.docx",
                    },
                },
                "required": ["manuscript"],
            },
        ),

        # ── Utility Tools ──
        Tool(
            name="check_api_status",
            description=(
                "Check which academic API sources are currently configured "
                "and available. Shows which APIs have valid keys and which "
                "require setup."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


# ─── Tool Dispatch ────────────────────────────────────────────


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Route tool calls to the appropriate handler."""
    settings = get_settings()
    logger.info(f"Tool called: {name}")
    logger.debug(f"Arguments: {json.dumps(arguments, default=str)}")

    try:
        if name == "search_academic":
            from q1_crafter_mcp.tools.search.aggregator import aggregate_search
            from q1_crafter_mcp.tools.analysis.gap_analyzer import register_papers

            config = SearchConfig(**arguments)
            result = await aggregate_search(config, settings)

            # Register papers in the store for analysis/visualization tools
            register_papers(result.papers)

            return [TextContent(type="text", text=result.model_dump_json(indent=2))]

        elif name == "search_by_doi":
            from q1_crafter_mcp.tools.search.crossref_search import CrossRefSearchClient

            client = CrossRefSearchClient(settings)
            result = await client.search_by_doi(arguments["doi"])
            return [TextContent(type="text", text=result.model_dump_json(indent=2))]

        elif name == "search_citations":
            from q1_crafter_mcp.tools.search.semantic_scholar import SemanticScholarClient

            client = SemanticScholarClient(settings)
            result = await client.get_citations(
                arguments["paper_id"],
                arguments.get("max_results", 50),
            )
            return [TextContent(type="text", text=json.dumps(
                [p.model_dump() for p in result], indent=2, default=str
            ))]

        elif name == "search_references":
            from q1_crafter_mcp.tools.search.semantic_scholar import SemanticScholarClient

            client = SemanticScholarClient(settings)
            result = await client.get_references(
                arguments["paper_id"],
                arguments.get("max_results", 50),
            )
            return [TextContent(type="text", text=json.dumps(
                [p.model_dump() for p in result], indent=2, default=str
            ))]

        elif name == "analyze_literature":
            from q1_crafter_mcp.tools.analysis.gap_analyzer import analyze_literature

            result = analyze_literature(arguments["paper_ids"])
            return [TextContent(type="text", text=result.model_dump_json(indent=2))]

        elif name == "validate_citations":
            from q1_crafter_mcp.tools.analysis.citation_validator import validate_citations

            result = validate_citations(
                arguments["text"],
                arguments["references"],
            )
            return [TextContent(type="text", text=result.model_dump_json(indent=2))]

        elif name == "extract_keywords":
            from q1_crafter_mcp.tools.analysis.keyword_extractor import extract_keywords

            result = extract_keywords(
                arguments["paper_ids"],
                arguments.get("max_keywords", 20),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "generate_comparison_table":
            from q1_crafter_mcp.tools.visualization.table_formatter import generate_table

            result = generate_table(
                arguments["paper_ids"],
                columns=arguments.get("columns"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "generate_trend_chart":
            from q1_crafter_mcp.tools.visualization.chart_generator import generate_chart
            from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper

            papers = [get_paper(pid) for pid in arguments["paper_ids"]]
            papers_data = [p.model_dump() for p in papers if p]
            chart_type = arguments.get("chart_type", "publication_trend")

            if chart_type == "publication_trend":
                from q1_crafter_mcp.tools.visualization.chart_generator import generate_trend_chart
                result = generate_trend_chart(papers_data)
            elif chart_type == "source_distribution":
                from q1_crafter_mcp.tools.visualization.chart_generator import generate_source_chart
                result = generate_source_chart(papers_data)
            else:
                from collections import Counter
                years = [p.get("year") for p in papers_data if p.get("year")]
                counts = Counter(years)
                sorted_years = sorted(counts.items())
                result = generate_chart(
                    "bar",
                    {"labels": [str(y) for y, _ in sorted_years], "values": [c for _, c in sorted_years]},
                    title=chart_type.replace("_", " ").title(),
                )
            return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

        elif name == "generate_citation_network":
            from q1_crafter_mcp.tools.visualization.citation_network import (
                generate_citation_network,
            )

            result = generate_citation_network(arguments["paper_ids"])
            return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

        elif name == "write_section":
            from q1_crafter_mcp.tools.output.section_writer import write_section
            from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper

            papers = [get_paper(pid) for pid in arguments["paper_ids"]]
            papers = [p for p in papers if p]

            result = write_section(
                section_name=arguments["section"],
                topic=arguments.get("instructions", arguments["section"]),
                papers=papers,
                custom_instructions=arguments.get("instructions", ""),
                language=arguments.get("language", "en"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

        elif name == "format_references_apa7":
            from q1_crafter_mcp.tools.output.apa_formatter import format_reference_list
            from q1_crafter_mcp.tools.analysis.gap_analyzer import get_paper

            papers = [get_paper(pid) for pid in arguments["paper_ids"]]
            papers = [p for p in papers if p]
            result = format_reference_list(papers)
            return [TextContent(type="text", text=result)]

        elif name == "build_docx":
            from q1_crafter_mcp.tools.output.docx_generator import generate_docx

            result = generate_docx(
                arguments["manuscript"],
                settings,
                filename=arguments.get("output_filename", "manuscript.docx"),
            )
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "check_api_status":
            report = _get_api_status(settings)
            return [TextContent(type="text", text=report.model_dump_json(indent=2))]

        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]

    except Exception as e:
        logger.error(f"Tool '{name}' failed: {e}")
        return [TextContent(
            type="text",
            text=json.dumps({"error": str(e), "tool": name}, indent=2),
        )]


# ─── Helpers ──────────────────────────────────────────────────


def _get_api_status(settings) -> APIStatusReport:
    """Build the API status report."""
    source_info = [
        ("Semantic Scholar", "semantic_scholar", True,
         "200M+ papers, AI-powered search"),
        ("arXiv", "arxiv", False,
         "Physics, Math, CS, Economics preprints"),
        ("CrossRef", "crossref", False,
         "140M+ DOI metadata records"),
        ("OpenAlex", "openalex", False,
         "250M+ academic works, fully open"),
        ("PubMed / NCBI", "pubmed", True,
         "Biomedical and life sciences"),
        ("Europe PMC", "europepmc", False,
         "Biomedical literature"),
        ("CORE", "core", True,
         "200M+ open access articles"),
        ("DOAJ", "doaj", False,
         "Open access journal directory"),
        ("BASE (Bielefeld)", "base_search", False,
         "300M+ academic documents"),
        ("Unpaywall", "unpaywall", True,
         "Open access PDF finder"),
        ("Scopus (Elsevier)", "scopus", True,
         "Journal quartiles, impact factors, citation analysis"),
        ("Web of Science", "wos", True,
         "Impact factor, JCR data"),
        ("IEEE Xplore", "ieee", True,
         "Engineering and CS publications"),
        ("Springer Nature", "springer", True,
         "Springer journal articles"),
        ("ScienceDirect", "sciencedirect", True,
         "Elsevier full-text access"),
        ("Dimensions", "dimensions", True,
         "Funding data and citation metrics"),
        ("TR Dizin", "trdizin", True,
         "Turkish academic journals"),
        ("DergiPark", "dergipark", False,
         "1000+ Turkish journals via OAI-PMH"),
        ("YÖK Tez Merkezi", "yok_tez", False,
         "Turkish theses and dissertations"),
    ]

    sources = []
    for display_name, key, requires_key, desc in source_info:
        sources.append(APISourceStatus(
            name=display_name,
            available=settings.is_source_available(key),
            requires_key=requires_key,
            description=desc,
        ))

    return APIStatusReport(
        sources=sources,
        total_available=sum(1 for s in sources if s.available),
        total_configured=len(sources),
    )


# ─── Entry Point ──────────────────────────────────────────────


def main():
    """Run the MCP server."""
    settings = get_settings()

    # Configure logging
    logger.add(
        str(settings.get_logs_path() / "q1_crafter_{time}.log"),
        rotation="1 day",
        retention="7 days",
        level=settings.log_level,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {module}:{function} | {message}",
    )

    logger.info("Starting Q1 Crafter MCP server")
    logger.info(f"Available sources: {settings.get_available_sources()}")

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await app.run(read_stream, write_stream, app.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    main()
