# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-02-23

### Added

#### Search Layer
- 18 academic API integrations (Semantic Scholar, arXiv, CrossRef, OpenAlex, PubMed, Europe PMC, CORE, DOAJ, BASE, Unpaywall, Scopus, IEEE, Springer, ScienceDirect, Web of Science, Dimensions, TR Dizin, DergiPark, YÖK Tez)
- Parallel search aggregation via `asyncio.gather()` with per-source timeouts
- Field-based smart routing (medicine → PubMed first, CS → Semantic Scholar + arXiv first)
- Two-phase deduplication: exact DOI match → fuzzy title (92% threshold via rapidfuzz)
- DOI lookup, citation search, and reference retrieval tools

#### Analysis Layer
- Gap analyzer with theme detection, temporal trends, and research gap identification
- TF-IDF keyword extractor with bigram support
- Paper summarizer with theme grouping
- Bidirectional citation validator (in-text ↔ reference list)

#### Visualization Layer
- Chart generator (bar, line, pie, scatter) with dark theme, base64 PNG output
- Table formatter (Markdown, CSV, APA 7 table formats)
- Citation network builder with keyword co-occurrence and Mermaid diagram output

#### Output Layer
- APA 7th edition formatter (in-text citations, reference entries, full reference lists)
- Section writer with IMRaD templates and citation suggestions
- DOCX generator (python-docx) with APA 7 formatted manuscripts

#### Infrastructure
- MCP server with 14 registered tools and stdio transport
- Pydantic-based configuration with `.env` file support
- 120 unit tests across 8 test modules (all passing)
- PyPI-ready packaging with hatchling build backend
