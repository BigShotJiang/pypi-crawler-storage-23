"""Tests for the visualization layer modules."""

from __future__ import annotations

from q1_crafter_mcp.tools.analysis.gap_analyzer import register_papers
from q1_crafter_mcp.tools.visualization.chart_generator import (
    generate_chart,
    generate_trend_chart,
    generate_source_chart,
)
from q1_crafter_mcp.tools.visualization.table_formatter import generate_table
from q1_crafter_mcp.tools.visualization.citation_network import generate_citation_network


class TestChartGenerator:
    """Test chart generation."""

    def test_bar_chart(self):
        result = generate_chart(
            "bar",
            {"labels": ["A", "B", "C"], "values": [10, 20, 30]},
            title="Test Bar",
        )
        # Might fail if matplotlib not installed — check gracefully
        if "error" not in result:
            assert "image_base64" in result
            assert result["mime_type"] == "image/png"
        else:
            assert "matplotlib" in result["error"]

    def test_line_chart(self):
        result = generate_chart(
            "line",
            {"labels": ["2020", "2021", "2022"], "values": [5, 10, 15]},
            title="Trend",
        )
        if "error" not in result:
            assert "image_base64" in result

    def test_pie_chart(self):
        result = generate_chart(
            "pie",
            {"labels": ["X", "Y"], "values": [60, 40]},
        )
        if "error" not in result:
            assert "image_base64" in result

    def test_unknown_chart_type(self):
        result = generate_chart("invalid_type", {"labels": ["A"], "values": [1]})
        assert "error" in result

    def test_empty_data(self):
        result = generate_chart("bar", {"labels": [], "values": []})
        assert "error" in result

    def test_trend_chart_from_papers(self, sample_papers):
        papers_data = [p.model_dump() for p in sample_papers]
        result = generate_trend_chart(papers_data)
        if "error" not in result:
            assert "image_base64" in result

    def test_source_chart_from_papers(self, sample_papers):
        papers_data = [p.model_dump() for p in sample_papers]
        result = generate_source_chart(papers_data)
        if "error" not in result:
            assert "image_base64" in result


class TestTableFormatter:
    """Test table generation."""

    def test_markdown_table(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_table(ids, format="markdown")
        assert result["format"] == "markdown"
        assert "|" in result["table"]

    def test_csv_table(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_table(ids, format="csv")
        assert result["format"] == "csv"
        assert "," in result["table"]

    def test_apa_table(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_table(ids, format="apa_table")
        assert result["format"] == "apa_table"
        assert "Note." in result["table"]

    def test_empty_ids(self):
        result = generate_table([], format="markdown")
        assert "No papers found" in result["table"]

    def test_custom_columns(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_table(ids, format="markdown", columns=["#", "Title", "Year"])
        assert "Title" in result["table"]
        assert "Year" in result["table"]


class TestCitationNetwork:
    """Test citation network generation."""

    def test_generates_network(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_citation_network(ids)
        assert "nodes" in result
        assert "edges" in result
        assert "clusters" in result
        assert "mermaid" in result

    def test_nodes_count(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_citation_network(ids)
        assert len(result["nodes"]) <= len(sample_papers)

    def test_mermaid_output(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = generate_citation_network(ids)
        assert result["mermaid"].startswith("graph LR")

    def test_empty_list(self):
        result = generate_citation_network([])
        assert "error" in result
