"""Tests for search client base class and availability logic."""

from __future__ import annotations

import pytest

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import SearchConfig
from q1_crafter_mcp.tools.search.base_client import BaseSearchClient


class ConcreteTestClient(BaseSearchClient):
    """Concrete test implementation of the abstract base client."""
    SOURCE_NAME = "test_source"
    BASE_URL = "https://api.example.com"
    REQUIRES_KEY = True

    async def search(self, config):
        return []


class FreeTestClient(BaseSearchClient):
    """Test client that doesn't require a key."""
    SOURCE_NAME = "arxiv"
    BASE_URL = "https://export.arxiv.org/api"
    REQUIRES_KEY = False

    async def search(self, config):
        return []


class TestBaseSearchClient:
    """Test base search client behavior."""

    def test_unavailable_without_key(self, settings):
        client = ConcreteTestClient(settings)
        assert client.is_available() is False

    def test_free_source_always_available(self, settings):
        client = FreeTestClient(settings)
        assert client.is_available() is True

    @pytest.mark.asyncio
    async def test_safe_search_skips_unavailable(self, settings):
        client = ConcreteTestClient(settings)
        result = await client.safe_search(SearchConfig(query="test"))
        assert result == []

    @pytest.mark.asyncio
    async def test_safe_search_runs_available(self, settings):
        client = FreeTestClient(settings)
        result = await client.safe_search(SearchConfig(query="test"))
        assert result == []

    def test_default_headers(self, settings):
        client = ConcreteTestClient(settings)
        headers = client._get_default_headers()
        assert "User-Agent" in headers
        assert "Q1CrafterMCP" in headers["User-Agent"]

    @pytest.mark.asyncio
    async def test_client_creation(self, settings):
        client = FreeTestClient(settings)
        http_client = await client._get_client()
        assert http_client is not None
        await client.close()

    @pytest.mark.asyncio
    async def test_close_idempotent(self, settings):
        client = FreeTestClient(settings)
        await client.close()  # No client created yet — should not error
        http_client = await client._get_client()
        await client.close()
        await client.close()  # Double close should be safe
