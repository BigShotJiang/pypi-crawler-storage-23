"""Tests for the models module."""

from __future__ import annotations

from q1_crafter_mcp.models import (
    Author,
    Paper,
    SearchConfig,
    AggregatedResults,
    Quartile,
    SectionType,
    Manuscript,
)


class TestAuthor:
    """Test Author model."""

    def test_full_name(self, sample_author):
        assert sample_author.full_name == "John Smith"

    def test_full_name_first_only(self):
        a = Author(first_name="John")
        assert a.full_name == "John"

    def test_full_name_last_only(self):
        a = Author(last_name="Smith")
        assert a.full_name == "Smith"

    def test_apa_name(self, sample_author):
        assert sample_author.apa_name == "Smith, J."

    def test_apa_name_multiple_initials(self):
        a = Author(first_name="Mary Jane", last_name="Watson")
        assert a.apa_name == "Watson, M. J."

    def test_affiliation(self, sample_author):
        assert sample_author.affiliation == "MIT"

    def test_turkish_name(self, sample_author_turkish):
        assert sample_author_turkish.full_name == "Ayşe Yılmaz"
        assert "Yılmaz" in sample_author_turkish.apa_name


class TestPaper:
    """Test Paper model."""

    def test_auto_id(self):
        p = Paper(title="Test")
        assert p.id  # UUID should be auto-generated
        assert len(p.id) == 36  # UUID format

    def test_explicit_id(self, sample_paper):
        assert sample_paper.id == "paper-001"

    def test_author_count(self, sample_paper):
        assert sample_paper.author_count == 1

    def test_first_author_last_name(self, sample_paper):
        assert sample_paper.first_author_last_name == "Smith"

    def test_first_author_no_authors(self):
        p = Paper(title="Test")
        assert p.first_author_last_name == "Unknown"

    def test_doi_url(self, sample_paper):
        result = sample_paper.doi_url()
        assert result == "https://doi.org/10.1038/s41591-023-00001-1"

    def test_doi_url_already_full(self):
        p = Paper(title="Test", doi="https://doi.org/10.1234/abc")
        assert p.doi_url() == "https://doi.org/10.1234/abc"

    def test_doi_url_dx_normalization(self):
        p = Paper(title="Test", doi="http://dx.doi.org/10.1234/abc")
        result = p.doi_url()
        assert "doi.org" in result
        assert "dx.doi.org" not in result

    def test_doi_url_none(self):
        p = Paper(title="Test")
        assert p.doi_url() is None

    def test_keywords_list(self, sample_paper):
        assert "machine learning" in sample_paper.keywords
        assert len(sample_paper.keywords) == 3

    def test_quartile_default(self):
        p = Paper(title="Test")
        assert p.quartile == Quartile.UNKNOWN

    def test_open_access_default(self):
        p = Paper(title="Test")
        assert p.open_access is False


class TestSearchConfig:
    """Test SearchConfig model."""

    def test_minimal_config(self):
        config = SearchConfig(query="test")
        assert config.query == "test"
        assert config.max_results == 100
        assert config.sources is None

    def test_full_config(self, search_config):
        assert search_config.query == "machine learning healthcare"
        assert search_config.year_from == 2020
        assert search_config.year_to == 2024

    def test_with_sources(self):
        config = SearchConfig(
            query="test",
            sources=["semantic_scholar", "crossref"],
        )
        assert len(config.sources) == 2


class TestAggregatedResults:
    """Test AggregatedResults model."""

    def test_empty_results(self):
        r = AggregatedResults()
        assert len(r.papers) == 0
        assert r.total_found == 0

    def test_with_papers(self, sample_papers):
        r = AggregatedResults(
            papers=sample_papers,
            total_found=len(sample_papers),
            sources_queried=["semantic_scholar", "crossref"],
            duplicates_removed=5,
            query_time_seconds=1.23,
        )
        assert r.total_found == 5
        assert r.duplicates_removed == 5

    def test_serialization(self, sample_paper):
        r = AggregatedResults(papers=[sample_paper], total_found=1)
        json_str = r.model_dump_json()
        assert "paper-001" in json_str
        assert "Nature Medicine" in json_str


class TestManuscript:
    """Test Manuscript model."""

    def test_default_language(self):
        m = Manuscript(title="Test")
        assert m.language == "en"

    def test_created_at_auto(self):
        m = Manuscript(title="Test")
        assert m.created_at is not None
