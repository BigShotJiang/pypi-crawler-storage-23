"""Tests for the APA 7th edition formatter."""

from __future__ import annotations

from q1_crafter_mcp.models import Author, Paper
from q1_crafter_mcp.tools.output.apa_formatter import (
    format_intext_citation,
    format_reference_entry,
    format_reference_list,
)


# ─── In-Text Citation Tests ──────────────────────────────────


class TestIntextCitation:
    """Test APA 7 in-text citation formatting."""

    def test_single_author_parenthetical(self, sample_paper):
        result = format_intext_citation(sample_paper, narrative=False)
        assert result == "(Smith, 2023)"

    def test_single_author_narrative(self, sample_paper):
        result = format_intext_citation(sample_paper, narrative=True)
        assert result == "Smith (2023)"

    def test_two_authors(self):
        paper = Paper(
            title="Test",
            authors=[
                Author(first_name="John", last_name="Smith"),
                Author(first_name="Jane", last_name="Doe"),
            ],
            year=2021,
        )
        result = format_intext_citation(paper, narrative=False)
        assert result == "(Smith & Doe, 2021)"

    def test_three_plus_authors(self):
        paper = Paper(
            title="Test",
            authors=[
                Author(first_name="A", last_name="Alpha"),
                Author(first_name="B", last_name="Beta"),
                Author(first_name="C", last_name="Gamma"),
            ],
            year=2022,
        )
        result = format_intext_citation(paper, narrative=False)
        assert result == "(Alpha et al., 2022)"

    def test_no_year(self):
        paper = Paper(title="Test", authors=[Author(first_name="A", last_name="Smith")])
        result = format_intext_citation(paper, narrative=False)
        assert "n.d." in result

    def test_no_authors(self):
        paper = Paper(title="Test", year=2023)
        result = format_intext_citation(paper, narrative=False)
        assert "Unknown Author" in result

    def test_turkish_author(self, sample_author_turkish):
        paper = Paper(title="Test", authors=[sample_author_turkish], year=2023)
        result = format_intext_citation(paper, narrative=True)
        assert "Yılmaz" in result
        assert "(2023)" in result


# ─── Reference Entry Tests ───────────────────────────────────


class TestReferenceEntry:
    """Test APA 7 reference list entry formatting."""

    def test_standard_journal_article(self, sample_paper):
        result = format_reference_entry(sample_paper)
        assert "Smith, J." in result
        assert "(2023)" in result
        assert "Nature Medicine" in result
        assert "https://doi.org/10.1038/s41591-023-00001-1" in result

    def test_volume_and_issue(self, sample_paper):
        result = format_reference_entry(sample_paper)
        assert "*29*" in result
        assert "(3)" in result

    def test_pages(self, sample_paper):
        result = format_reference_entry(sample_paper)
        assert "123-145" in result

    def test_doi_normalization_with_prefix(self):
        paper = Paper(
            title="Test",
            authors=[Author(first_name="A", last_name="B")],
            year=2023,
            doi="https://doi.org/10.1234/abc",
        )
        result = format_reference_entry(paper)
        assert "https://doi.org/10.1234/abc" in result

    def test_doi_normalization_http(self):
        paper = Paper(
            title="Test",
            authors=[Author(first_name="A", last_name="B")],
            year=2023,
            doi="http://doi.org/10.1234/abc",
        )
        result = format_reference_entry(paper)
        assert "https://doi.org/10.1234/abc" in result

    def test_url_fallback_when_no_doi(self):
        paper = Paper(
            title="Test",
            authors=[Author(first_name="A", last_name="B")],
            year=2023,
            url="https://example.com/paper",
        )
        result = format_reference_entry(paper)
        assert "https://example.com/paper" in result

    def test_multiple_author_initials(self):
        paper = Paper(
            title="Test",
            authors=[Author(first_name="Mary Jane", last_name="Watson")],
            year=2023,
        )
        result = format_reference_entry(paper)
        assert "Watson, M. J." in result

    def test_two_authors_ampersand(self):
        paper = Paper(
            title="Test",
            authors=[
                Author(first_name="A", last_name="Alpha"),
                Author(first_name="B", last_name="Beta"),
            ],
            year=2023,
        )
        result = format_reference_entry(paper)
        assert "Alpha, A., & Beta, B." in result

    def test_three_authors_oxford_comma(self):
        paper = Paper(
            title="Test",
            authors=[
                Author(first_name="A", last_name="Alpha"),
                Author(first_name="B", last_name="Beta"),
                Author(first_name="C", last_name="Gamma"),
            ],
            year=2023,
        )
        result = format_reference_entry(paper)
        assert "Alpha, A., Beta, B., & Gamma, C." in result

    def test_no_journal(self):
        paper = Paper(
            title="A Standalone Report",
            authors=[Author(first_name="A", last_name="B")],
            year=2023,
        )
        result = format_reference_entry(paper)
        assert "A Standalone Report" in result

    def test_thesis_type_italic_title(self):
        paper = Paper(
            title="My Doctoral Thesis",
            authors=[Author(first_name="A", last_name="B")],
            year=2023,
            publication_type="thesis",
        )
        result = format_reference_entry(paper)
        assert "*My Doctoral Thesis*" in result


# ─── Reference List Tests ────────────────────────────────────


class TestReferenceList:
    """Test full reference list generation."""

    def test_alphabetical_order(self, sample_papers):
        result = format_reference_list(sample_papers)
        lines = [l for l in result.split("\n\n") if l.strip()]
        # First authors: Johnson, Williams, Brown, Jones, Davis
        # Alphabetical: Brown, Davis, Johnson, Jones, Williams
        assert "Brown" in lines[0]
        assert "Davis" in lines[1]
        assert "Johnson" in lines[2]

    def test_all_papers_included(self, sample_papers):
        result = format_reference_list(sample_papers)
        lines = [l for l in result.split("\n\n") if l.strip()]
        assert len(lines) == len(sample_papers)

    def test_empty_list(self):
        result = format_reference_list([])
        assert result == ""
