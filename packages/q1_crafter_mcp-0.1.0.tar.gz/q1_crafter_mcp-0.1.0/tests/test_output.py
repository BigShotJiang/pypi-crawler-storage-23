"""Tests for the output layer modules."""

from __future__ import annotations

from q1_crafter_mcp.models import Author, Paper
from q1_crafter_mcp.tools.analysis.gap_analyzer import register_papers
from q1_crafter_mcp.tools.output.section_writer import write_section, SECTION_TEMPLATES
from q1_crafter_mcp.tools.output.docx_generator import generate_docx
from q1_crafter_mcp.tools.output.apa_formatter import format_reference_list


class TestSectionWriter:
    """Test section writing scaffold generation."""

    def test_introduction_section(self, sample_papers):
        result = write_section(
            section_name="introduction",
            topic="machine learning in healthcare",
            papers=sample_papers,
        )
        assert result["heading"] == "Introduction"
        assert len(result["guidelines"]) > 0
        assert len(result["outline"]) > 0
        assert "template" in result

    def test_literature_review(self, sample_papers):
        result = write_section(
            section_name="literature_review",
            topic="AI and health",
            papers=sample_papers,
        )
        assert result["heading"] == "Literature Review"

    def test_all_sections_exist(self):
        for section_key in ["introduction", "literature_review", "methodology",
                            "results", "discussion", "conclusion", "abstract"]:
            assert section_key in SECTION_TEMPLATES

    def test_citations_included(self, sample_papers):
        result = write_section(
            section_name="introduction",
            topic="test",
            papers=sample_papers,
        )
        assert len(result["available_citations"]) > 0
        assert "parenthetical" in result["available_citations"][0]
        assert "narrative" in result["available_citations"][0]

    def test_turkish_language_note(self, sample_papers):
        result = write_section(
            section_name="introduction",
            topic="test",
            papers=sample_papers,
            language="tr",
        )
        assert "Türkçe" in result["language_note"]

    def test_custom_instructions_passed(self, sample_papers):
        result = write_section(
            section_name="introduction",
            topic="test",
            papers=sample_papers,
            custom_instructions="Focus on NLP applications",
        )
        assert result["custom_instructions"] == "Focus on NLP applications"

    def test_unknown_section_falls_back(self):
        result = write_section(
            section_name="custom_section",
            topic="test",
        )
        assert result["heading"] == "Custom_Section"

    def test_no_papers(self):
        result = write_section(
            section_name="introduction",
            topic="test",
        )
        assert len(result["available_citations"]) == 0


class TestDocxGenerator:
    """Test DOCX generation."""

    def test_generate_basic_docx(self, settings, tmp_path):
        settings.output_dir = str(tmp_path)
        manuscript = {
            "title": "Test Manuscript",
            "authors": [{"first_name": "John", "last_name": "Smith"}],
            "abstract": "This is a test abstract.",
            "keywords": ["test", "unit"],
            "sections": [
                {"heading": "Introduction", "level": 1, "content": "This is the introduction."},
            ],
        }
        result = generate_docx(manuscript, settings, filename="test.docx")
        # May fail if python-docx not installed
        if "error" not in result:
            assert result["status"] == "success"
            assert "test.docx" in result["file_path"]
        else:
            assert "python-docx" in result["error"]

    def test_generate_with_references(self, settings, sample_papers, tmp_path):
        settings.output_dir = str(tmp_path)
        manuscript = {
            "title": "Test with References",
            "authors": [],
            "sections": [],
            "references": sample_papers,
        }
        result = generate_docx(manuscript, settings)
        if "error" not in result:
            assert result["status"] == "success"

    def test_empty_manuscript(self, settings, tmp_path):
        settings.output_dir = str(tmp_path)
        manuscript = {"title": "Empty"}
        result = generate_docx(manuscript, settings)
        if "error" not in result:
            assert result["status"] == "success"


class TestReferenceListIntegration:
    """Integration test for reference list formatting."""

    def test_full_pipeline(self, sample_papers):
        result = format_reference_list(sample_papers)
        assert len(result) > 0
        # Should contain DOIs
        assert "https://doi.org" in result
        # Should be alphabetical
        lines = result.split("\n\n")
        assert len(lines) == len(sample_papers)
