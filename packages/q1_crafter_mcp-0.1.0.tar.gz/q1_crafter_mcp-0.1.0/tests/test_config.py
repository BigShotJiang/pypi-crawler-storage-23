"""Tests for the config module."""

from __future__ import annotations

from q1_crafter_mcp.config import Settings, get_settings


class TestSettings:
    """Test Settings configuration."""

    def test_defaults(self, settings):
        assert settings.request_timeout == 30
        assert settings.max_results_per_source == 50
        assert settings.log_level == "INFO"

    def test_free_sources_always_available(self, settings):
        free_sources = ["arxiv", "crossref", "openalex", "europepmc", "doaj", "base_search"]
        for source in free_sources:
            assert settings.is_source_available(source) is True, f"{source} should be available"

    def test_keyed_sources_unavailable_without_keys(self, settings):
        keyed_sources = ["semantic_scholar", "scopus", "wos", "ieee", "springer", "dimensions"]
        for source in keyed_sources:
            assert settings.is_source_available(source) is False, f"{source} should not be available"

    def test_keyed_source_available_with_key(self):
        s = Settings(scopus_api_key="test-key-123")
        assert s.is_source_available("scopus") is True

    def test_unpaywall_needs_email(self):
        s_without = Settings(unpaywall_email="")
        assert s_without.is_source_available("unpaywall") is False

        s_with = Settings(unpaywall_email="test@example.com")
        assert s_with.is_source_available("unpaywall") is True

    def test_get_available_sources(self, settings):
        available = settings.get_available_sources()
        # At minimum: arxiv, crossref, openalex, europepmc, doaj, base_search, dergipark, yok_tez, unpaywall (email set)
        assert "arxiv" in available
        assert "crossref" in available
        assert "openalex" in available
        assert "unpaywall" in available  # email is set in fixture

    def test_output_path_creation(self, settings, tmp_path):
        settings.output_dir = str(tmp_path / "test_out")
        path = settings.get_output_path()
        assert path.exists()

    def test_figures_path_creation(self, settings, tmp_path):
        settings.output_dir = str(tmp_path / "test_out")
        path = settings.get_figures_path()
        assert path.exists()
        assert path.name == "figures"

    def test_unknown_source(self, settings):
        assert settings.is_source_available("nonexistent_api") is False

    def test_get_settings_singleton(self):
        s1 = get_settings()
        s2 = get_settings()
        assert s1 is s2
