"""Tests for the analysis layer modules."""

from __future__ import annotations

from q1_crafter_mcp.models import Author, Paper
from q1_crafter_mcp.tools.analysis.gap_analyzer import (
    register_papers,
    get_paper,
    analyze_literature,
)
from q1_crafter_mcp.tools.analysis.keyword_extractor import extract_keywords
from q1_crafter_mcp.tools.analysis.summarizer import summarize_papers
from q1_crafter_mcp.tools.analysis.citation_validator import validate_citations


# ─── Gap Analyzer ────────────────────────────────────────────


class TestGapAnalyzer:
    """Test gap analysis functionality."""

    def test_register_and_retrieve(self, sample_paper):
        register_papers([sample_paper])
        result = get_paper(sample_paper.id)
        assert result is not None
        assert result.title == sample_paper.title

    def test_retrieve_nonexistent(self):
        result = get_paper("nonexistent-id-99999")
        assert result is None

    def test_analyze_returns_result(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = analyze_literature(ids)
        assert result.main_themes is not None
        assert result.temporal_trends is not None

    def test_analyze_empty_list(self):
        result = analyze_literature([])
        assert result is not None

    def test_temporal_trends(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = analyze_literature(ids)
        assert len(result.temporal_trends) > 0

    def test_research_gaps_populated(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = analyze_literature(ids)
        assert isinstance(result.research_gaps, list)

    def test_top_cited_papers(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = analyze_literature(ids)
        assert isinstance(result.top_cited_papers, list)
        assert len(result.top_cited_papers) > 0

    def test_recommended_structure(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = analyze_literature(ids)
        assert isinstance(result.recommended_structure, list)


# ─── Keyword Extractor ───────────────────────────────────────


class TestKeywordExtractor:
    """Test keyword extraction."""

    def test_extract_from_papers(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = extract_keywords(ids, max_keywords=10)
        assert isinstance(result, dict)
        assert "keywords" in result
        assert "bigrams" in result
        assert result["paper_count"] == len(sample_papers)

    def test_extract_empty(self):
        result = extract_keywords([], max_keywords=5)
        assert isinstance(result, dict)
        assert result["paper_count"] == 0

    def test_keywords_are_tuples(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = extract_keywords(ids)
        for kw in result["keywords"]:
            assert isinstance(kw, (list, tuple))
            assert len(kw) == 2  # (term, score)


# ─── Summarizer ──────────────────────────────────────────────


class TestSummarizer:
    """Test paper summarization."""

    def test_summarize_papers(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = summarize_papers(ids)
        assert isinstance(result, dict)
        assert "summaries" in result
        assert "themes" in result
        assert "stats" in result
        assert result["stats"]["total_papers"] == len(sample_papers)

    def test_summarize_empty(self):
        result = summarize_papers([])
        assert isinstance(result, dict)
        assert result["summaries"] == []

    def test_summary_content(self, sample_papers):
        register_papers(sample_papers)
        ids = [p.id for p in sample_papers]
        result = summarize_papers(ids)
        for s in result["summaries"]:
            assert "title" in s
            assert "year" in s
            assert "abstract_snippet" in s


# ─── Citation Validator ──────────────────────────────────────


class TestCitationValidator:
    """Test citation validation."""

    def test_citation_detection(self):
        text = "According to Smith et al. (2023), the results show that (Jones, 2021) agreed."
        references = [
            {"authors": "Smith et al.", "year": 2023, "title": "Test"},
            {"authors": "Jones", "year": 2021, "title": "Test2"},
        ]
        result = validate_citations(text, references)
        # The validator detects in-text citations and references
        assert isinstance(result.orphan_intext, list)
        assert isinstance(result.orphan_references, list)
        assert isinstance(result.report, str)

    def test_orphan_intext(self):
        text = "According to (UnknownAuthor, 2099), this is interesting."
        references = []
        result = validate_citations(text, references)
        assert len(result.orphan_intext) > 0

    def test_empty_text(self):
        result = validate_citations("", [])
        assert result.valid is True

    def test_report_generated(self):
        text = "(Smith, 2023)"
        references = [{"authors": "Smith", "year": 2023, "title": "Test"}]
        result = validate_citations(text, references)
        assert isinstance(result.report, str)
