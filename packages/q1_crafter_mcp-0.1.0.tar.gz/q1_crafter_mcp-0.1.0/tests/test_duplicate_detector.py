"""Tests for the duplicate detector module."""

from __future__ import annotations

from q1_crafter_mcp.models import Author, Paper
from q1_crafter_mcp.tools.search.duplicate_detector import deduplicate_papers


class TestDuplicateDetector:
    """Test deduplication logic."""

    def test_no_duplicates(self, sample_papers):
        result, removed = deduplicate_papers(sample_papers)
        assert len(result) == len(sample_papers)
        assert removed == 0

    def test_exact_doi_match(self):
        p1 = Paper(id="a", title="Paper A", doi="10.1234/test", citations_count=10, source_api="s1")
        p2 = Paper(id="b", title="Paper B Different Title", doi="10.1234/test", citations_count=5, source_api="s2")
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 1
        assert removed == 1
        # Should keep the one with more metadata (higher citation count)
        assert result[0].citations_count == 10

    def test_fuzzy_title_match(self):
        p1 = Paper(
            id="a",
            title="Machine Learning in Healthcare: A Comprehensive Review",
            citations_count=20,
            source_api="s1",
        )
        p2 = Paper(
            id="b",
            title="Machine Learning in Healthcare: A Comprehensive Review.",
            citations_count=5,
            source_api="s2",
        )
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 1
        assert removed == 1

    def test_different_titles_kept(self):
        p1 = Paper(id="a", title="Machine Learning in Healthcare", source_api="s1")
        p2 = Paper(id="b", title="Deep Learning for Drug Discovery", source_api="s2")
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 2
        assert removed == 0

    def test_keeps_richer_metadata(self):
        p1 = Paper(
            id="a",
            title="Same Paper Title Here",
            doi="10.1234/test",
            citations_count=5,
            abstract=None,
            source_api="s1",
        )
        p2 = Paper(
            id="b",
            title="Same Paper Title Here",
            doi="10.1234/test",
            citations_count=50,
            abstract="Full abstract here...",
            journal="Nature",
            source_api="s2",
        )
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 1
        assert result[0].citations_count == 50
        assert result[0].journal == "Nature"

    def test_empty_list(self):
        result, removed = deduplicate_papers([])
        assert result == []
        assert removed == 0

    def test_single_paper(self, sample_paper):
        result, removed = deduplicate_papers([sample_paper])
        assert len(result) == 1
        assert removed == 0

    def test_case_insensitive_doi(self):
        p1 = Paper(id="a", title="X", doi="10.1234/ABC", source_api="s1")
        p2 = Paper(id="b", title="Y", doi="10.1234/abc", source_api="s2")
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 1
        assert removed == 1

    def test_none_doi_not_matched(self):
        p1 = Paper(id="a", title="Unique Title Alpha", doi=None, source_api="s1")
        p2 = Paper(id="b", title="Unique Title Beta", doi=None, source_api="s2")
        result, removed = deduplicate_papers([p1, p2])
        assert len(result) == 2
        assert removed == 0
