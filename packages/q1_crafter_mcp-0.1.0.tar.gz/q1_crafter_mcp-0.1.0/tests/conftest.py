"""conftest.py — shared pytest fixtures for Q1 Crafter MCP tests."""

from __future__ import annotations

import pytest

from q1_crafter_mcp.config import Settings
from q1_crafter_mcp.models import Author, Paper, SearchConfig


@pytest.fixture
def settings():
    """Return a Settings instance with no API keys (uses defaults)."""
    return Settings(
        semantic_scholar_api_key="",
        ncbi_api_key="",
        core_api_key="",
        unpaywall_email="test@example.com",
        scopus_api_key="",
        wos_api_key="",
        ieee_api_key="",
        springer_api_key="",
        elsevier_api_key="",
        dimensions_api_key="",
        trdizin_api_key="",
        output_dir="./test_output",
    )


@pytest.fixture
def sample_author():
    return Author(first_name="John", last_name="Smith", affiliation="MIT")


@pytest.fixture
def sample_author_turkish():
    return Author(first_name="Ayşe", last_name="Yılmaz", affiliation="İstanbul Üniversitesi")


@pytest.fixture
def sample_paper(sample_author):
    return Paper(
        id="paper-001",
        title="Machine Learning in Healthcare: A Systematic Review",
        authors=[sample_author],
        year=2023,
        journal="Nature Medicine",
        volume="29",
        issue="3",
        pages="123-145",
        doi="10.1038/s41591-023-00001-1",
        abstract="This paper reviews the application of machine learning in healthcare...",
        citations_count=150,
        source_api="semantic_scholar",
        open_access=True,
        pdf_url="https://example.com/paper.pdf",
        keywords=["machine learning", "healthcare", "deep learning"],
    )


@pytest.fixture
def sample_papers():
    """Return a collection of papers for testing aggregation/analysis."""
    papers = []
    names = [
        ("Alice", "Johnson"), ("Bob", "Williams"), ("Carol", "Brown"),
        ("David", "Jones"), ("Eve", "Davis"),
    ]
    titles = [
        "Deep Learning for Medical Image Analysis",
        "Natural Language Processing in Clinical Notes",
        "Reinforcement Learning for Drug Discovery",
        "Transfer Learning in Radiology",
        "Federated Learning for Patient Data Privacy",
    ]
    journals = [
        "Nature Medicine", "The Lancet Digital Health",
        "Journal of Machine Learning Research", "IEEE TMI",
        "PLOS ONE",
    ]
    for i, ((first, last), title, journal) in enumerate(
        zip(names, titles, journals)
    ):
        papers.append(Paper(
            id=f"paper-{i+1:03d}",
            title=title,
            authors=[Author(first_name=first, last_name=last)],
            year=2020 + i,
            journal=journal,
            doi=f"10.1234/test-{i+1:03d}",
            abstract=f"Abstract for {title.lower()}...",
            citations_count=(5 - i) * 30,
            source_api=["semantic_scholar", "crossref", "openalex", "pubmed", "scopus"][i],
            open_access=i % 2 == 0,
            keywords=["machine learning", "healthcare", ["NLP", "deep learning", "federated learning", "transfer learning", "reinforcement learning"][i]],
        ))
    return papers


@pytest.fixture
def search_config():
    return SearchConfig(
        query="machine learning healthcare",
        max_results=10,
        year_from=2020,
        year_to=2024,
    )
