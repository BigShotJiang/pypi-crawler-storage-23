"""Translation normalization utilities.

This module provides functions for normalizing translations from various
input formats to the format expected by Readlang.
"""

import re


def normalize_translation(translation: str) -> str:
    """Normalize translation to use ' / ' separator as Readlang expects.

    Different vocabulary sources use different separators for alternative translations:
    - Language Reactor: comma (e.g., "put, to put, to place")
    - Pod101: slash (e.g., "intend/ be going to do")
    - Pod101: semicolon (e.g., "to (time); without; except for")

    This function unifies all separators to ' / ' as Readlang requires.

    Args:
        translation: The raw translation string from the source

    Returns:
        Normalized translation with ' / ' separators

    Examples:
        >>> normalize_translation("put, to put, to place")
        'put / to put / to place'
        >>> normalize_translation("intend/ be going to do")
        'intend / be going to do'
        >>> normalize_translation("to (time); without; except for")
        'to (time) / without / except for'

    Note:
        Commas within numbers (e.g., "3,14") are preserved and not treated
        as separators, using negative lookbehind/lookahead assertions.
    """
    # Split on all separator styles: slash, semicolon, or comma
    # Use lookbehind/lookahead to avoid splitting on commas within numbers
    parts = [
        p.strip()
        for p in re.split(r"[/;]|(?<![0-9]),(?![0-9])", translation)
    ]

    # Filter out empty parts
    parts = [p for p in parts if p]

    # Join with Readlang's expected separator
    return " / ".join(parts) if parts else translation.strip()
