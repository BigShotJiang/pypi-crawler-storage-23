"""Web interface for words-to-readlang.

Provides a Flask-based web application for uploading vocabulary files,
validating entries, fetching examples from Tatoeba, and exporting to
Readlang format.
"""

from .app import create_app

__all__ = ["create_app"]
