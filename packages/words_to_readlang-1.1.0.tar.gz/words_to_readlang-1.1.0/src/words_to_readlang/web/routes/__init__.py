"""Flask route blueprints."""

from .main import main_bp

__all__ = ["main_bp"]
