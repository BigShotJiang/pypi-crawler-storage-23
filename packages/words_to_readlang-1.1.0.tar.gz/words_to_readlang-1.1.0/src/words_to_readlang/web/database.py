"""Database initialization and session management."""

from flask_sqlalchemy import SQLAlchemy

# Global database instance
db = SQLAlchemy()


def init_db(app):
    """Initialize database with Flask app.

    Args:
        app: Flask application instance
    """
    db.init_app(app)

    with app.app_context():
        # Import models to ensure they're registered
        from . import models  # noqa: F401

        # Create all tables
        db.create_all()
