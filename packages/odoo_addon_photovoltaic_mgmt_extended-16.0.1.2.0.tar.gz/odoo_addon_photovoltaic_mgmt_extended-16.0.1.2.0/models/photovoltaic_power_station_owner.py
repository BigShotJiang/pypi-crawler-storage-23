from odoo import models, fields,api
import logging

_logger = logging.getLogger(__name__)

class PhotovoltaicPowerStationOwner(models.Model):
    _name = 'photovoltaic.power.station.owner'

    owner = fields.Many2one(
        'res.partner',
        # Filter suplier from contacts
        domain=[('supplier_rank','>', 1)]
    )
    vat = fields.Char(related="owner.vat")
    original = fields.Boolean(string='Original owner')
    current = fields.Boolean(string='Current owner')
    station = fields.Many2one('photovoltaic.power.station')


