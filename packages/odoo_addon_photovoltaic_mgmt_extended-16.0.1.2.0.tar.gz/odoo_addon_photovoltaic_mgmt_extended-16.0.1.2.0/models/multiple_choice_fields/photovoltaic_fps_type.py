from odoo import fields, models

# Photovoltaic power station fire protection system (FPS) type
class PhotovoltaicFpsType(models.Model):
    _name='photovoltaic.fps.type'

    name=fields.Char()