from odoo import fields, models

class MaintenanceDeckType(models.Model):
    _name='maintenance.deck.type'

    name=fields.Char()