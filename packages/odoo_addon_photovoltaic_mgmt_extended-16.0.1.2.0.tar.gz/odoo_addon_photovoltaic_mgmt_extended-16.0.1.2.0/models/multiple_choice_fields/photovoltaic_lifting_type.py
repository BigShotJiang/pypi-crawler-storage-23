from odoo import fields, models

class PhotovoltaicLiftingType(models.Model):
    _name='photovoltaic.lifting.type'

    name=fields.Char()