from odoo import models, fields

class PhotovoltaicStationTypology(models.Model):
    _description = 'Photovoltaic station typology'
    _name = 'photovoltaic.station.typology'

    name = fields.Char()