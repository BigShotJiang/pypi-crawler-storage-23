from odoo import models, fields

class PhotovoltaicLandRegime(models.Model):
    _name = 'photovoltaic.land.regime'

    name = fields.Char()