from odoo import models, fields

class PhotovoltaicLessor(models.Model):
    _name = 'photovoltaic.lessor'

    land_regime = fields.Many2one('photovoltaic.land.regime')
    lessor = fields.Many2one(
        'res.partner',
        domain=[('supplier_rank','>',1)]
    )
    lessor_id = fields.Char(related="lessor.vat", store=True)
    contract_start_date = fields.Date()
    contract_end_date = fields.Date()
    cadastral_reference = fields.Char()
    public_release = fields.Boolean()
    property_register = fields.Char()
    farm_number = fields.Char()
    volume = fields.Char()
    book = fields.Char()
    paper = fields.Char()
    inscription = fields.Char()
    annual_rent = fields.Float()
    annual_rent_goods_owners = fields.Float()
    other_commitments = fields.Text()
    contract = fields.Char()