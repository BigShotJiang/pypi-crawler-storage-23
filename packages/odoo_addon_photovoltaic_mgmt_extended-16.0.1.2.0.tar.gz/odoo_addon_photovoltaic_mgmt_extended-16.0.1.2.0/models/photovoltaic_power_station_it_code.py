from odoo import fields, models

class PhotovoltaicPowerStationItCode(models.Model):
    _name = 'photovoltaic.power.station.it.code'

    name = fields.Char()