from odoo import fields, models

class PhotovoltaicConsumptionContract(models.Model):
    _name = 'photovoltaic.consumption.contract'

    state = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
        ('in_process', 'In process')
    ])
    CUPS = fields.Char()
    comments = fields.Text()
    station = fields.Many2one('photovoltaic.power.station')