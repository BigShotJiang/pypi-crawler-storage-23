from odoo import fields, models

class PhotovoltaicHiredPower(models.Model):
    _name = 'photovoltaic.hired.power'

    time_slot = fields.Char()
    hired_power = fields.Float(
        string="value",
        digits=[1,2]
    )
    station = fields.Many2one('photovoltaic.power.station')