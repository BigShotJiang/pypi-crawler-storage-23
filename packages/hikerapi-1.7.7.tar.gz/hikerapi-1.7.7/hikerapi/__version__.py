__title__ = "hikerapi"
__description__ = "hikerapi client, for Python 3."
__version__ = "1.7.7"
__host__ = "api.hikerapi.com"
