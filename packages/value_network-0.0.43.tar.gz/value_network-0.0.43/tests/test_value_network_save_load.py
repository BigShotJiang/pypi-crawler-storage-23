import torch
import pytest
from pathlib import Path
from value_network.value_network import ValueNetwork, register_backbone
from x_mlps_pytorch import MLP
from torch import nn

class SimpleMLPBackbone(nn.Module):
    def __init__(self, state_dim, hidden_dim):
        super().__init__()
        self.net = MLP(state_dim, hidden_dim, hidden_dim)
        
    def forward(self, x):
        return self.net(x)

def test_value_network_save_load(tmp_path: Path):
    register_backbone('simple_mlp', SimpleMLPBackbone)
    
    state_dim = 10
    hidden_dim = 64
    
    # Initialize the network using backbone registry kwargs
    net = ValueNetwork(
        dim = hidden_dim,
        backbone_name = 'simple_mlp',
        backbone_kwargs = dict(state_dim=state_dim, hidden_dim=hidden_dim),
        loss_module_name = 'mse'
    )
    
    # Save the network
    save_file = tmp_path / 'vnet.pt'
    net.save(str(save_file))
    
    # Load the network from scratch directly via class method
    loaded_net = ValueNetwork.init_and_load(str(save_file))
    
    # Verify exact parity
    # 1. Structure verification
    assert isinstance(loaded_net, ValueNetwork)
    assert isinstance(loaded_net.backbone, SimpleMLPBackbone)
    
    # 2. Forward pass equivalence
    state = torch.randn(2, state_dim)
    
    with torch.no_grad():
        original_output = net(state)
        loaded_output = loaded_net(state)
        
    assert torch.allclose(original_output, loaded_output)
    print("Save/Load successfully restored architecture and weights!")
