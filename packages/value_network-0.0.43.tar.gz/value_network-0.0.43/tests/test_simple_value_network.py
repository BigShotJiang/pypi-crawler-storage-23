import torch
import pytest
from value_network.value_network import ValueNetwork
from x_mlps_pytorch import MLP

def test_simple_value_network():
    batch = 8
    state_dim = 10
    hidden_dim = 64
    
    # Create a simple MLP backbone mapping from state_dim to hidden_dim
    backbone = MLP(state_dim, hidden_dim, hidden_dim)
    
    # Wrap the backbone in the generic ValueNetwork
    net = ValueNetwork(
        backbone=backbone,
        dim=hidden_dim,
        loss_module_name='mse'
    )
    
    # Mock simple lunar lander state: (batch_size, state_dim)
    state = torch.randn(batch, state_dim)
    
    # Forward pass through the network
    output = net(state)
    
    # Output should be (batch_size,) when targets are not provided
    assert output.shape == (batch,), f"Expected {(batch,)}, got {output.shape}"

    # Also test with multiple targets for completeness
    target1 = torch.randn(batch)
    target2 = torch.randn(batch)
    
    # Should return a list of losses
    losses = net(state, targets=[target1, target2])
    assert len(losses) == 2
    assert losses[0].shape == ()
    assert losses[1].shape == ()
