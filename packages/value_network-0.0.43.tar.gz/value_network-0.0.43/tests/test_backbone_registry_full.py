import torch
from torch import nn
from value_network.value_network import ValueNetwork, register_backbone
from pathlib import Path

# 1. Define and register another backbone
class CustomBackbone(nn.Module):
    def __init__(self, state_dim, hidden_dim, num_features):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_features)
        )
    
    def forward(self, x):
        return self.net(x)

def test_backbone_registry_full(tmp_path: Path):
    register_backbone('custom', CustomBackbone)
    
    state_dim = 16
    hidden_dim = 32
    num_features = 64
    
    # 2. Instantiate ValueNetwork with the registered backbone
    # Using 'custom' backbone and 'mse' loss module
    vnet = ValueNetwork(
        dim = num_features,
        backbone_name = 'custom',
        backbone_kwargs = dict(
            state_dim = state_dim,
            hidden_dim = hidden_dim,
            num_features = num_features
        ),
        loss_module_name = 'mse'
    )
    
    # 3. Predict values
    state = torch.randn(4, state_dim)
    predicted_values = vnet(state)
    
    assert predicted_values.shape == ((4,) if vnet.loss_module.__class__.__name__ == 'MSELossModule' else (4, num_features))
    
    # 4. Forward for the loss
    # For MSELossModule, targets should be same shape as output
    targets = torch.randn_like(predicted_values)
    loss = vnet(state, targets = targets)
    
    assert loss > 0
    
    # 5. Save and Load
    save_path = tmp_path / "vnet_full.pt"
    vnet.save(str(save_path))
    
    # Initialize and load from checkpoint
    loaded_vnet = ValueNetwork.init_and_load(str(save_path))
    
    # Check structure
    assert isinstance(loaded_vnet.backbone, CustomBackbone)
    
    # Check parity in prediction
    with torch.no_grad():
        loaded_predicted_values = loaded_vnet(state)
        
    assert torch.allclose(predicted_values, loaded_predicted_values, atol=1e-6)
    
    print("Full backbone registry test passed!")
