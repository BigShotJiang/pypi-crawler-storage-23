import re
import click
import torch
import numpy as np
import av
import json
import subprocess
import webbrowser
import http.server
import socketserver
import gc
import psutil
import os
from pathlib import Path
from PIL import Image

from einops import rearrange

from memmap_replay_buffer import ReplayBuffer

from value_network.value_network import (
    SigLIPValueNetwork,
    ValueNetworkTrainer,
    ValueNetworkTrainerWithTD,
    preprocess_image
)

def exists(val):
    return val is not None

def get_video_frame_shape(video_path):
    try:
        command = [
            'ffprobe',
            '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height',
            '-of', 'json',
            str(video_path)
        ]
        output = subprocess.check_output(command).decode('utf-8')
        data = json.loads(output)
        width = int(data['streams'][0]['width'])
        height = int(data['streams'][0]['height'])
        return (3, height, width)
    except Exception:
        return None

def get_video_frame_count(video_path):
    try:
        with av.open(str(video_path)) as container:
            stream = container.streams.video[0]
            if stream.frames > 0:
                return stream.frames
            
            # fallback if stream.frames is not available
            count = 0
            for _ in container.decode(video=0):
                count += 1
            return count
    except Exception:
        return 0

def video_to_images(video_path, sample_freq=1, resize_image_size=None):
    try:
        container = av.open(str(video_path))
        images = []
        for i, frame in enumerate(container.decode(video = 0)):
            if i % sample_freq != 0:
                continue
            img = frame.to_ndarray(format = 'rgb24')
            if exists(resize_image_size):
                pil_img = Image.fromarray(img)
                pil_img = pil_img.resize(resize_image_size[::-1], resample = Image.BILINEAR)
                img = np.array(pil_img)
            images.append(img)
        container.close()
        
        images = np.array(images)
        if images.ndim == 0:
            h, w = resize_image_size if resize_image_size else (224, 224)
            return np.zeros((0, 3, h, w), dtype = np.uint8)
        
        images = rearrange(images, 't h w c -> t c h w')
        return images
    except Exception:
        h, w = resize_image_size if resize_image_size else (224, 224)
        return np.zeros((0, 3, h, w), dtype = np.uint8)

def get_next_path(base_path):
    base_path = Path(base_path)
    if not base_path.exists():
        return base_path
    
    stem = base_path.stem
    ext = base_path.suffix
    
    # search for existing name.N.ext
    pattern = re.compile(rf'^{re.escape(stem)}\.(\d+){re.escape(ext)}$')
    
    max_num = 0
    base_exists = False

    for f in base_path.parent.glob(f'{stem}*{ext}'):
        if f.name == base_path.name:
            base_exists = True
            continue

        match = pattern.match(f.name)
        if match:
            max_num = max(max_num, int(match.group(1)))
            
    if not base_exists:
        return base_path

    return base_path.parent / f'{stem}.{max_num + 1}{ext}'

def group_videos_by_views(video_files, match_views = None):
    if not match_views:
        return [[v] for v in video_files], []

    groups = {}
    for v in video_files:
        stem = v.stem
        # Pattern: prefix.viewNAME.success
        match = re.match(r'^(.*)\.(view\w+)\.(0|1)$', stem)
        if not match:
            continue

        base_name, view_name, success = match.groups()
        if view_name not in match_views:
            continue

        key = (base_name, success)
        if key not in groups:
            groups[key] = {}
        groups[key][view_name] = v

    # filter for groups that have all requested views
    valid_groups = []
    invalid_groups = []
    
    for key, view_map in groups.items():
        if all(view in view_map for view in match_views):
            # Sort views in the order specified in match_views
            ordered_videos = [view_map[view] for view in match_views]
            valid_groups.append(ordered_videos)
        else:
            missing_views = [view for view in match_views if view not in view_map]
            invalid_groups.append((key, missing_views))

    return valid_groups, invalid_groups

def do_generate_memmap_files(
    path,
    output_folder,
    max_episodes = None,
    max_timesteps = None,
    match_views = None,
    overwrite = False,
    resize_image_size = None,
    sample_freq = 1
):
    path = Path(path)
    output_folder = Path(output_folder)
    
    video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
    
    # recursive search for videos

    video_files = []
    for ext in video_extensions:
        video_files.extend(list(path.rglob(f'*{ext}')))
    
    if not video_files:
        click.echo(f'no video files found in {path}')
        return None

    # Sort files for consistency
    video_files.sort()

    # Group videos by views
    video_groups, invalid_groups = group_videos_by_views(video_files, match_views)

    if not video_groups:
        click.echo(f'no matching video groups found in {path}')
        return None

    # determine max episodes and timesteps if not provided

    if not exists(max_episodes):
        max_episodes = len(video_groups)

    if not exists(max_timesteps):
        max_timesteps = 0
        for video_group in video_groups:
            max_len = max(get_video_frame_count(v) for v in video_group)
            max_timesteps = max(max_timesteps, max_len)

        # factor in sampling frequency
        max_timesteps = (max_timesteps + sample_freq - 1) // sample_freq
        
        # add a small buffer
        max_timesteps += 5

    # initialize replay buffer
    first_video_set = video_groups[0]
    click.echo(f'determining image shape from {first_video_set[0].name}...')

    image_shape = get_video_frame_shape(first_video_set[0])
    if not exists(image_shape):
        click.echo(f'failed to load images from {first_video_set[0]}')
        return None
        
    if exists(resize_image_size):
        image_shape = (image_shape[0], *resize_image_size)

    num_views = len(match_views) if match_views else 0
    full_image_shape = (num_views, *image_shape) if num_views > 0 else image_shape

    replay_buffer = ReplayBuffer(
        str(output_folder),
        fields = dict(
            images = ('uint8', full_image_shape, 0),
            rewards = ('float', (), 0.),
            progress = ('float', (), np.nan)
        ),
        meta_fields = dict(
            success = ('bool', (), False),
            episode_lens = ('int', (), 0)
        ),
        max_episodes = max_episodes,
        max_timesteps = max_timesteps,
        circular = True
    )

    # process videos
    
    num_trajectories = len(video_groups)
    
    for traj_idx, video_group in enumerate(video_groups):
        click.echo(f'[{traj_idx + 1}/{num_trajectories}] processing {video_group[0].name}...')

        # handle rewards (using first video for metadata)
        video_file = video_group[0]

        # determine min length across all views
        episode_len = min(get_video_frame_count(v) for v in video_group)
        
        sampled_episode_len = (episode_len + sample_freq - 1) // sample_freq
        sampled_episode_len = min(sampled_episode_len, max_timesteps)

        rewards = np.zeros(sampled_episode_len, dtype = np.float32)

        # search for reward file

        stem = video_file.stem
        stem_without_success = re.sub(r'\.(0|1)$', '', stem)

        possible_reward_files = [
            video_file.with_suffix('.pt'),
            video_file.parent / f'{stem_without_success}.pt',
            video_file.parent.parent / 'data' / f'{video_file.stem}.pt',
            video_file.parent.parent / 'data' / f'{stem_without_success}.pt'
        ]
        
        reward_pt_file = None
        for p in possible_reward_files:
            if p.exists():
                reward_pt_file = p
                break
                
        if exists(reward_pt_file):
            try:
                reward_data = torch.load(reward_pt_file, weights_only = True)
                
                if torch.is_tensor(reward_data) and reward_data.ndim == 1:
                    r_len = min(episode_len, reward_data.shape[0])
                    sampled_rewards = reward_data[:r_len:sample_freq].cpu().numpy()
                    s_len = min(len(sampled_rewards), sampled_episode_len)
                    rewards[:s_len] = sampled_rewards[:s_len]
                elif isinstance(reward_data, list) and len(reward_data) > 0 and isinstance(reward_data[0], dict) and 'reward' in reward_data[0]:
                    r_len = min(episode_len, len(reward_data))
                    sampled_rewards = [reward_data[i]['reward'] for i in range(0, r_len, sample_freq)]
                    s_len = min(len(sampled_rewards), sampled_episode_len)
                    rewards[:s_len] = sampled_rewards[:s_len]
            except Exception:
                pass

        # 3. handle success suffix

        success = False
        match = re.search(r'\.(0|1)$', video_file.stem)
        
        if exists(match):
            success = bool(int(match.group(1)))

        # 3.1 terminal reward based on success or failure

        rewards[episode_len - 1] = 1.0 if success else -1.0

        # 4. calculate progress

        progress = np.full(episode_len, np.nan, dtype = np.float32)

        if success:
            progress[:] = np.linspace(0, 1, sampled_episode_len)

        # 5. store in replay buffer

        with replay_buffer.one_episode(success = success):
            click.echo(f'  - loading and processing views...')
            
            # load all views into memory (fastest approach for typical RL trajectories)
            all_views = []
            for v_path in video_group:
                imgs = video_to_images(v_path, sample_freq=sample_freq, resize_image_size=resize_image_size)
                all_views.append(imgs)
            
            # ensure all views have same length, clip to minimum
            min_len = min(len(view) for view in all_views)
            all_views = [view[:min_len] for view in all_views]
            
            if num_views > 0:
                sampled_views = np.stack(all_views, axis=1) # (T, V, C, H, W)
            else:
                sampled_views = all_views[0] # (T, C, H, W)
                
            actual_sampled_len = len(sampled_views)
            
            # clamp to max timesteps if necessary
            actual_sampled_len = min(actual_sampled_len, sampled_episode_len)
            sampled_views = sampled_views[:actual_sampled_len]
            
            with click.progressbar(range(actual_sampled_len), label = f'  - storing to buffer') as sub_bar:
                for i in sub_bar:
                    replay_buffer.store(
                        images = sampled_views[i],
                        rewards = rewards[i],
                        progress = progress[i]
                    )

        # 6. cleanup and flush
        replay_buffer.flush()
        
        # force garbage collection to be safe since we load full videos
        del all_views, sampled_views
        gc.collect()

        # minor memory monitoring

        process = psutil.Process(os.getpid())
        mem_mb = process.memory_info().rss / (1024 * 1024)
        # click.echo(f' [Memory: {mem_mb:.1f} MB]', nl = False)

    click.echo(f'finished processing {len(video_groups)} trajectories. replay buffer saved to {output_folder}')

    if len(invalid_groups) > 0:
        click.echo(f'\n[WARNING] {len(invalid_groups)} trajectories were skipped because they were missing views:')
        for traj_key, missing in invalid_groups:
            base_name, success = traj_key
            click.echo(f' - {base_name} (success: {success}) missing views: {", ".join(missing)}')

    return output_folder

def create_model(loss_module_name, kwargs):
    loss_module_kwargs = dict()
    if loss_module_name == 'hlgauss':
        loss_module_kwargs = dict(
            num_bins = kwargs.get('hl_gauss_num_bins', 100),
            min_value = kwargs.get('hl_gauss_min', -2.0),
            max_value = kwargs.get('hl_gauss_max', 2.0)
        )
    elif loss_module_name == "categorical":
        loss_module_class = CategoricalLossModule
        loss_module_kwargs = dict(
            num_bins = kwargs.get('categorical_num_bins', 201),
            min_value = kwargs.get('categorical_min', 0.0),
            max_value = kwargs.get('categorical_max', 1.0),
            temperature = kwargs.get('categorical_temperature', 0.1),
            encoding = kwargs.get('categorical_encoding', 'two_hot'),
            use_symexp = kwargs.get('categorical_use_symexp', False)
        )
    elif loss_module_name in ('gaussian', 'beta-nll'):
        loss_module_kwargs = dict(
            beta = kwargs.get('beta', 0.5) if loss_module_name == 'beta-nll' else 0.,
            variance_activation = kwargs.get('variance_activation', 'exp')
        )
    return SigLIPValueNetwork(
        siglip_image_size = kwargs.get('siglip_image_size', 224),
        siglip_patch_size = kwargs.get('siglip_patch_size', 14),
        loss_module_name = loss_module_name,
        loss_module_kwargs = loss_module_kwargs
    )

@click.group()
def main():
    pass

@main.command(name = 'generate-memmap-files')
@click.argument('path', type = click.Path(exists = True))
@click.option('--output-folder', default = './replay_buffer', help = 'Path to save the replay buffer')
@click.option('--max-episodes', type = int, help = 'Max episodes in replay buffer')
@click.option('--max-timesteps', type = int, help = 'Max timesteps per episode')
@click.option('--resize-image-size', type = int, multiple = True, help = 'Resize image to this size (e.g. --resize-image-size 64 --resize-image-size 64)')
@click.option('--sample-freq', default = 1, help = 'Sample every Nth frame')
@click.option('--match-views', 'match_views', multiple = True, help = 'View tags to match (e.g. view1, view3)')
@click.option('--overwrite', is_flag = True, help = 'Overwrite existing replay buffer')
def generate_memmap_files_cmd(
    path,
    output_folder,
    max_episodes,
    max_timesteps,
    resize_image_size,
    sample_freq,
    match_views,
    overwrite
):
    if len(resize_image_size) == 0:
        resize_image_size = None
    elif len(resize_image_size) == 2:
        resize_image_size = tuple(resize_image_size)
    else:
        click.echo('resize-image-size must be two integers (height, width)')
        return

    do_generate_memmap_files(
        path,
        output_folder,
        max_episodes,
        max_timesteps,
        match_views,
        overwrite = overwrite,
        resize_image_size = resize_image_size,
        sample_freq = sample_freq
    )

@main.command()
@click.argument('path', required = False, type = click.Path(exists = True))
@click.option('--trajectories-folder', 'trajectories_folder', type = click.Path(exists = True), help = 'Path to trajectories folder to generate memmap from')
@click.option('--batch-size', default = 16, help = 'Batch size for training')
@click.option('--lr', default = 3e-4, help = 'Learning rate')
@click.option('--max-steps', 'override_steps', type = int, help = 'Override number of training steps')
@click.option('--max-grad-norm', default = 0.5, help = 'Max gradient norm')
@click.option('--checkpoint', default = None, help = 'Path to model checkpoint to resume from')
@click.option('--siglip-image-size', default = 224, help = 'SigLIP image size')
@click.option('--siglip-patch-size', default = 14, help = 'SigLIP patch size')
@click.option('--model-output-path', 'output_path', default = './model.pt', help = 'Path to save the trained model')
@click.option('--use-td-trainer', is_flag = True, help = 'Use the TD trainer with failure masking')
@click.option('--discount', default = 0.99, help = 'Discount factor for TD learning')
@click.option('--ema', is_flag = True, help = 'Use EMA for TD learning targets')
@click.option('--td-loss-weight', 'td_loss_weight', default = 1.0, help = 'Weight for TD loss')
@click.option('--td-steps', 'td_steps', default = 0, help = 'Number of steps for TD training (Phase 2)')
@click.option('--loss-module', 'loss_module_name', type = click.Choice(['mse', 'hlgauss', 'categorical', 'gaussian', 'beta-nll']), default = 'mse', help = 'Loss module to use')
@click.option('--hl-gauss-num-bins', default = 100, help = 'Number of bins for HL-Gauss loss')
@click.option('--hl-gauss-min', default = -2.0, help = 'Min value for HL-Gauss support')
@click.option('--hl-gauss-max', default = 2.0, help = 'Max value for HL-Gauss support')
@click.option('--categorical-num-bins', default = 201, help = 'Number of bins for categorical loss')
@click.option('--categorical-min', default = 0.0, help = 'Min value for categorical loss')
@click.option('--categorical-max', default = 1.0, help = 'Max value for categorical loss')
@click.option('--categorical-temperature', default = 0.1, help = 'Temperature for categorical loss')
@click.option('--categorical-encoding', type = click.Choice(['two_hot', 'gaussian']), default = 'two_hot', help = 'Encoding for categorical loss')
@click.option('--categorical-use-symexp', is_flag = True, help = 'Use sym-exp for categorical loss')
@click.option('--beta', default = 0.5, help = 'Beta for Beta-NLL loss')
@click.option('--variance-activation', type = click.Choice(['exp', 'softplus']), default = 'exp', help = 'Variance activation')
@click.option('--match-views', 'match_views', multiple = True, help = 'View tags to match (e.g. view1, view3)')
@click.option('--resize-image-size', type = int, multiple = True, help = 'Resize image to this size (e.g. --resize-image-size 64 --resize-image-size 64)')
@click.option('--sample-freq', default = 1, help = 'Sample every Nth frame')
@click.option('--overwrite', is_flag = True, help = 'Overwrite existing replay buffer if generating from videos')
def train(
    path,
    trajectories_folder,
    batch_size,
    lr,
    override_steps,
    max_grad_norm,
    checkpoint,
    siglip_image_size,
    siglip_patch_size,
    output_path,
    use_td_trainer,
    discount,
    ema,
    td_loss_weight,
    td_steps,
    loss_module_name,
    hl_gauss_num_bins,
    hl_gauss_min,
    hl_gauss_max,
    categorical_num_bins,
    categorical_min,
    categorical_max,
    categorical_temperature,
    categorical_encoding,
    categorical_use_symexp,
    beta,
    variance_activation,
    match_views,
    resize_image_size,
    sample_freq,
    overwrite
):
    if exists(trajectories_folder):
        path = Path(trajectories_folder)
    elif exists(path):
        path = Path(path)
    else:
        click.echo('must provide either a buffer path or a trajectories folder via --trajectories-folder')
        return

    # handle model output path suffixing
    
    # ... rest of logic ...
    
    output_path = get_next_path(output_path)
    click.echo(f'model will be saved to {output_path}')

    # if it's not a replay buffer folder (no metadata.pkl), assume it's a video folder
    
    if not (path / 'metadata.pkl').exists():
        click.echo(f'{path} is not a replay buffer, attempting to generate from videos...')
        
        buffer_path = path.with_suffix('.memmap')
        
        if buffer_path.exists():
            if not overwrite:
                if not click.confirm(f'Memory-mapped buffer folder {buffer_path} already exists. Overwrite?', default = False):
                    return
            
            import shutil
            shutil.rmtree(buffer_path)

        # determine max timesteps from videos
        video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
        video_files = []
        for ext in video_extensions:
            video_files.extend(list(path.rglob(f'*{ext}')))
        
        if not video_files:
            click.echo(f'no video files found in {path}')
            return

        if len(resize_image_size) == 0:
            resize_image_size = None
        elif len(resize_image_size) == 2:
            resize_image_size = tuple(resize_image_size)
        else:
            click.echo('resize-image-size must be two integers (height, width)')
            return

        total_frames = 0
        max_video_len = 0
        for v in video_files:
            count = get_video_frame_count(v)
            total_frames += count
            max_video_len = max(max_video_len, count)

        steps = (total_frames + sample_freq - 1) // sample_freq

        do_generate_memmap_files(
            path,
            output_folder = buffer_path,
            max_episodes = None,
            max_timesteps = None,
            match_views = match_views,
            overwrite = overwrite,
            resize_image_size = resize_image_size,
            sample_freq = sample_freq
        )
    else:
        buffer_path = path
        # if using existing buffer, we don't know the frames easily, so default to 1000
        steps = 1000

    if exists(override_steps):
        steps = override_steps

    # model
    
    kwargs = locals()
    model = create_model(loss_module_name, kwargs)

    if exists(checkpoint):
        model.load(checkpoint)
        click.echo(f'loaded model from {checkpoint}')
    else:
        model.load_siglip() 
        click.echo('starting from pretrained siglip weights')

    # phase 1 - base trainer

    if steps > 0:
        click.echo(f'phase 1: training for {steps} steps (progress only)...')
        
        trainer = ValueNetworkTrainer(
            model = model,
            replay_buffer = buffer_path,
            batch_size = batch_size,
            lr = lr,
            max_grad_norm = max_grad_norm
        )

        trainer.train(num_train_steps = steps)
        model = trainer.accelerator.unwrap_model(model)

    # phase 2 - TD trainer

    if td_steps > 0 or use_td_trainer:
        td_training_steps = td_steps if td_steps > 0 else steps
        
        click.echo(f'phase 2: training for {td_training_steps} steps (TD + progress)...')

        trainer = ValueNetworkTrainerWithTD(
            model = model,
            replay_buffer = buffer_path,
            batch_size = batch_size,
            lr = lr,
            max_grad_norm = max_grad_norm,
            discount_factor = discount,
            use_ema = ema,
            td_loss_weight = td_loss_weight
        )

        trainer.train(num_train_steps = td_training_steps)
        model = trainer.accelerator.unwrap_model(model)

    # save final model

    model.save(output_path)
    
    click.echo(f'model saved to {output_path}')

@main.command(name = 'predict')
@click.argument('model_path', type = click.Path(exists = True))
@click.argument('input_paths', nargs = -1, type = click.Path(exists = True))
@click.option('--cuda', is_flag = True, help = 'Use CUDA if available')
@click.option('--siglip-image-size', default = 224, help = 'SigLIP image size')
@click.option('--siglip-patch-size', default = 14, help = 'SigLIP patch size')
@click.option('--output-path', 'output_path', type = click.Path(), help = 'Path to save prediction tensor')
@click.option('--loss-module', 'loss_module_name', type = click.Choice(['mse', 'hlgauss', 'categorical', 'gaussian', 'beta-nll']), default = 'mse', help = 'Loss module to use (if not loading from checkpoint)')
@click.option('--beta', default = 0.5, help = 'Beta for Beta-NLL loss')
@click.option('--variance-activation', type = click.Choice(['exp', 'softplus']), default = 'exp', help = 'Variance activation')
@click.option('--hl-gauss-num-bins', default = 100, help = 'Number of bins for HL-Gauss loss')
@click.option('--hl-gauss-min', default = -2.0, help = 'Min value for HL-Gauss support')
@click.option('--hl-gauss-max', default = 2.0, help = 'Max value for HL-Gauss support')
@click.option('--categorical-num-bins', default = 201, help = 'Number of bins for categorical loss')
@click.option('--categorical-min', default = 0.0, help = 'Min value for categorical loss')
@click.option('--categorical-max', default = 1.0, help = 'Max value for categorical loss')
@click.option('--categorical-temperature', default = 0.1, help = 'Temperature for categorical loss')
@click.option('--categorical-encoding', type = click.Choice(['two_hot', 'gaussian']), default = 'two_hot', help = 'Encoding for categorical loss')
@click.option('--categorical-use-symexp', is_flag = True, help = 'Use sym-exp for categorical loss')
@click.option('--batch-size', default = 16, help = 'Batch size for video prediction')
@torch.no_grad()
def predict_value(
    model_path,
    input_paths,
    batch_size,
    cuda,
    siglip_image_size,
    siglip_patch_size,
    output_path,
    loss_module_name,
    beta,
    variance_activation,
    hl_gauss_num_bins,
    hl_gauss_min,
    hl_gauss_max,
    categorical_num_bins,
    categorical_min,
    categorical_max,
    categorical_temperature,
    categorical_encoding,
    categorical_use_symexp
):
    if not input_paths:
        click.echo('must provide at least one input path')
        return

    # load model
    
    kwargs = locals()
    model = create_model(loss_module_name, kwargs)
    model.load(model_path)
    model.eval()
    
    device = torch.device('cuda' if cuda and torch.cuda.is_available() else 'cpu')
    model.to(device)
    
    input_paths = [Path(p) for p in input_paths]
    video_extensions = {'.mp4', '.avi', '.mov', '.mkv', '.webm'}
    
    is_multi_view = len(input_paths) > 1

    if any(p.suffix.lower() in video_extensions for p in input_paths):
        # load videos and process
        all_images = [video_to_images(p) for p in input_paths]
        
        # clip to shortest video
        min_len = min(img.shape[0] for img in all_images)
        all_images = [img[:min_len] for img in all_images]
        
        if is_multi_view:
            images = np.stack(all_images, axis = 1) # (T, V, C, H, W)
        else:
            images = all_images[0]
            
        if images.shape[0] == 0:
            click.echo('no frames found in video(s)')
            return

        values = []
        stds = []
        
        # process in batches
        for i in range(0, images.shape[0], batch_size):
            batch_images = images[i : i + batch_size]
            
            # preprocess as a batch
            batch_tensor = preprocess_image(batch_images).to(device)
            batch_out = model(batch_tensor)
            
            if isinstance(batch_out, (list, tuple)):
                batch_values, batch_stds = batch_out
                values.append(batch_values)
                stds.append(batch_stds)
            else:
                values.append(batch_out)
        
        values = torch.cat(values, dim = 0)
        values_np = values.cpu().numpy()

        if len(stds) > 0:
            stds = torch.cat(stds, dim = 0)
            stds_np = stds.cpu().numpy()
            
            # Combine values and stds into (T, 2)
            values_np = np.stack([values_np, stds_np], axis = -1)
        
        # save as .npy
        if exists(output_path):
            output_npy_path = Path(output_path)
        else:
            output_npy_path = get_next_path(input_paths[0].with_suffix('.npy'))

        np.save(output_npy_path, values_np)
        
        click.echo(f'predicted values saved to {output_npy_path}')
        click.echo(f'shape: {values_np.shape}')
        
    else:
        # handle multiple images
        all_images = []
        for p in input_paths:
            img = Image.open(p).convert('RGB')
            img = np.array(img)
            img = rearrange(img, 'h w c -> c h w')
            all_images.append(img)
            
        if is_multi_view:
            images = np.stack(all_images, axis = 0) # (V, C, H, W)
            image_tensor = preprocess_image(images)
            image_batch = rearrange(image_tensor, 'v c h w -> 1 v c h w')
        else:
            image_tensor = preprocess_image(all_images[0])
            image_batch = rearrange(image_tensor, 'c h w -> 1 c h w')
            
        image_batch = image_batch.to(device)

        # predict
        
        out = model(image_batch)
        
        if isinstance(out, (list, tuple)):
            value, std = out
            click.echo(f'predicted value: {value.item():.4f} (std: {std.item():.4f})')
        else:
            click.echo(f'predicted value: {out.item():.4f}')

@main.command()
@click.argument('video_paths', nargs = -1, type = click.Path(exists = True))
@click.option('--npy-path', type = click.Path(exists = True), required = True)
@click.option('--port', default = 8080, help = 'Port for the visualization dashboard')
def visualize(
    video_paths,
    npy_path,
    port
):
    import subprocess as sp
    import tempfile

    if not video_paths:
        click.echo('must provide at least one video path')
        return

    video_paths = [Path(p).absolute() for p in video_paths]
    npy_path = Path(npy_path).absolute()

    template_path = Path(__file__).parent / 'templates' / 'dashboard.html'
    assert template_path.exists(), f'dashboard template not found at {template_path}'

    # check if videos need re-encoding to h264 for browser playback
    serve_video_paths = []
    
    for video_path in video_paths:
        needs_reencode = True
        try:
            probe = sp.run(
                ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                 '-show_entries', 'stream=codec_name', '-of', 'csv=p=0',
                 str(video_path)],
                capture_output = True, text = True
            )
            if probe.returncode == 0 and probe.stdout.strip() == 'h264':
                needs_reencode = False
        except FileNotFoundError:
            needs_reencode = False

        if needs_reencode:
            click.echo(f'Re-encoding {video_path.name} to H.264...')
            tmp = tempfile.NamedTemporaryFile(suffix = '.mp4', delete = False)
            tmp.close()
            sp.run(['ffmpeg', '-y', '-i', str(video_path), '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', tmp.name], capture_output = True)
            serve_video_paths.append(Path(tmp.name))
        else:
            serve_video_paths.append(video_path)

    # load values
    values_raw = np.load(npy_path)
    
    if values_raw.ndim == 2 and values_raw.shape[-1] == 2:
        values = values_raw[:, 0]
        stds = values_raw[:, 1]
    else:
        values = values_raw.flatten()
        stds = None

    payload = json.dumps({
        'filenames': [p.name for p in video_paths],
        'values': values.tolist(),
        'stds': stds.tolist() if exists(stds) else None,
        'num_videos': len(video_paths)
    }).encode()

    # request handler

    class Handler(http.server.BaseHTTPRequestHandler):
        def serve_file(self, path, content_type):
            size = path.stat().st_size
            range_header = self.headers.get('Range')

            if range_header:
                match = re.match(r'bytes=(\d+)-(\d*)', range_header)
                if match:
                    start = int(match.group(1))
                    end = int(match.group(2)) if match.group(2) else size - 1
                    end = min(end, size - 1)

                    if start >= size:
                        self.send_error(416)
                        return

                    length = end - start + 1
                    self.send_response(206)
                    self.send_header('Content-Type', content_type)
                    self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
                    self.send_header('Content-Length', str(length))
                    self.send_header('Accept-Ranges', 'bytes')
                    self.end_headers()

                    with open(path, 'rb') as f:
                        f.seek(start)
                        remaining = length
                        while remaining > 0:
                            chunk = f.read(min(8192, remaining))
                            if not chunk:
                                break
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                    return

            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(size))
            self.send_header('Accept-Ranges', 'bytes')
            self.end_headers()

            with open(path, 'rb') as f:
                while chunk := f.read(8192):
                    self.wfile.write(chunk)

        def do_GET(self):
            try:
                if self.path == '/':
                    html = template_path.read_bytes()
                    self.send_response(200)
                    self.send_header('Content-Type', 'text/html')
                    self.send_header('Content-Length', str(len(html)))
                    self.end_headers()
                    self.wfile.write(html)
                elif self.path.startswith('/video/'):
                    try:
                        idx = int(self.path.split('/')[-1])
                        self.serve_file(serve_video_paths[idx], 'video/mp4')
                    except (ValueError, IndexError):
                        self.send_error(404)
                elif self.path == '/video': # backwards compat
                    self.serve_file(serve_video_paths[0], 'video/mp4')
                elif self.path == '/data':
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                else:
                    self.send_error(404)
            except (ConnectionResetError, BrokenPipeError):
                pass

        def log_message(self, format, *args):
            return

    class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
        allow_reuse_address = True
        daemon_threads = True

    click.echo(f'Dashboard at http://localhost:{port}')
    click.echo('Press Ctrl+C to stop')

    webbrowser.open(f'http://localhost:{port}')

    with ThreadedServer(('', port), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            click.echo('\nStopping...')

if __name__ == '__main__':
    main()
