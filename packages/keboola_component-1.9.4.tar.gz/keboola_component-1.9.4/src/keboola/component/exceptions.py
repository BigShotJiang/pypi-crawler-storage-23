class UserException(Exception):
    pass
