import django_tables2 as tables

from app.models import Book
from crud_views.lib.table import Table, UUIDLinkDetailColumn
from crud_views.lib.views import (
    DetailViewPermissionRequired,
    UpdateViewPermissionRequired,
    CreateViewPermissionRequired,
    ListViewTableMixin,
    DeleteViewPermissionRequired,
    ListViewPermissionRequired,
)
from crud_views.lib.viewset import ViewSet, ParentViewSet

cv_book = ViewSet(
    model=Book,
    name="book",
    parent=ParentViewSet(name="author"),
)


class BookTable(Table):
    id = UUIDLinkDetailColumn()
    title = tables.Column()
    price = tables.Column()
    author = tables.Column()


class BookListView(ListViewTableMixin, ListViewPermissionRequired):
    cv_viewset = cv_book
    # cv_list_actions = ["detail", "update", "delete"]

    table_class = BookTable


class BookDetailView(DetailViewPermissionRequired):
    cv_viewset = cv_book


class BookUpdateView(UpdateViewPermissionRequired):
    fields = ["title", "price"]
    cv_viewset = cv_book


class BookCreateView(CreateViewPermissionRequired):
    fields = ["title", "price"]
    cv_viewset = cv_book


class BookDeleteView(DeleteViewPermissionRequired):
    cv_viewset = cv_book
