from enum import IntEnum


class WorkflowComment(IntEnum):
    NONE = 0
    OPTIONAL = 1
    REQUIRED = 2
