import unittest
from unittest.mock import patch, MagicMock
from instavm import InstaVM

LIVE_API_KEY = ""

class TestInstaVMClient(unittest.TestCase):
    @unittest.skipIf(not LIVE_API_KEY, "No live API key set in LIVE_API_KEY")
    def test_live_api_execute(self):
        client = InstaVM(api_key=LIVE_API_KEY, base_url="https://api.instavm.io")
        # 2. Execute a simple command
        exec_result = client.execute("print('Hello from live test')")
        print(exec_result)
        self.assertTrue(isinstance(exec_result, dict))
        print("Execution result:", exec_result)

        # 3. Get usage info for this session
        usage_info = client.get_usage()
        self.assertTrue(isinstance(usage_info, dict))
        print("Usage info:", usage_info)




    @patch('instavm.sandbox_client.InstaVM._make_request')
    def setUp(self, mock_make_request):
        # Mock _make_request for session initialization
        mock_response = MagicMock()
        mock_response.json.return_value = {"session_id": "init_session_id"}
        mock_make_request.return_value = mock_response

        self.client = InstaVM(api_key="test_api_key", base_url="http://api.instavm.io")
        self.mock_session_id = "test_session_id"


    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_start_session(self, mock_make_request):

        mock_response = MagicMock()
        mock_response.json.return_value = {"session_id": self.mock_session_id}
        mock_make_request.return_value = mock_response

        session_id = self.client.start_session()
        self.assertEqual(session_id, self.mock_session_id)
        mock_make_request.assert_called_with(
            "POST",
            f"{self.client.base_url}/v1/sessions/session",
            json={
                "api_key": self.client.api_key,
                "vm_lifetime_seconds": self.client.timeout
            }
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_start_session_with_bootstrap_options(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.json.return_value = {"session_id": "session_with_resources"}
        mock_make_request.return_value = mock_response

        client = InstaVM(
            api_key="test_api_key",
            base_url="http://api.instavm.io",
            cpu_count=4,
            memory_mb=2048,
            env={"APP_ENV": "test"},
            metadata={"project": "sdk"}
        )

        self.assertEqual(client.session_id, "session_with_resources")
        mock_make_request.assert_called_with(
            "POST",
            f"{client.base_url}/v1/sessions/session",
            json={
                "api_key": client.api_key,
                "vm_lifetime_seconds": client.timeout,
                "memory_mb": 2048,
                "vcpu_count": 4,
                "metadata": {"project": "sdk"},
                "env": {"APP_ENV": "test"}
            }
        )


    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_execute(self, mock_make_request):

        self.client.session_id = self.mock_session_id
        command = "test_command"

        mock_response = MagicMock()
        mock_response.json.return_value = {"result": "success"}
        mock_make_request.return_value = mock_response

        response = self.client.execute(command)
        self.assertEqual(response, {"result": "success"})
        mock_make_request.assert_called_once_with(
            "POST",
            f"{self.client.base_url}/execute",
            headers={"X-API-Key": self.client.api_key},
            json={
                "command": command,
                "session_id": self.client.session_id
            },
            timeout=self.client.timeout
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_execute_async(self, mock_make_request):
        self.client.session_id = self.mock_session_id
        command = "test_async_command"

        mock_response = MagicMock()
        mock_response.json.return_value = {"result": "async_success"}
        mock_make_request.return_value = mock_response

        response = self.client.execute_async(command, language="python", timeout=60)
        self.assertEqual(response, {"result": "async_success"})
        mock_make_request.assert_called_once_with(
            "POST",
            f"{self.client.base_url}/execute_async",
            headers={"X-API-Key": self.client.api_key},
            json={
                "command": command,
                "session_id": self.client.session_id,
                "language": "python",
                "timeout": 60
            }
        )


    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_get_usage(self, mock_make_request):

        self.client.session_id = self.mock_session_id

        mock_response = MagicMock()
        mock_response.json.return_value = {"usage": "test_usage"}
        mock_make_request.return_value = mock_response

        usage = self.client.get_usage()
        self.assertEqual(usage, {"usage": "test_usage"})
        mock_make_request.assert_called_once_with(
            "GET",
            f"{self.client.base_url}/v1/sessions/usage/{self.client.session_id}"
        )


    @patch('instavm.sandbox_client.InstaVM._make_request')
    @patch('builtins.open', new_callable=unittest.mock.mock_open, read_data="data")
    def test_upload_file(self, mock_open, mock_make_request):
        self.client.session_id = self.mock_session_id
        mock_response = MagicMock()
        mock_response.json.return_value = {"status": "file_uploaded"}
        mock_make_request.return_value = mock_response

        response = self.client.upload_file('test.txt', '/remote/test.txt')
        self.assertEqual(response, {"status": "file_uploaded"})
        mock_make_request.assert_called_once()

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_snapshots_create_with_build_args(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"id": "snap_123", "status": "building"}
        mock_make_request.return_value = mock_response

        response = self.client.snapshots.create(
            oci_image="docker.io/library/python:3.11-slim",
            name="python-base",
            build_args={
                "git_clone_url": "https://github.com/example/repo.git",
                "git_clone_branch": "main",
                "envs": {"APP_ENV": "test"}
            }
        )

        self.assertEqual(response["id"], "snap_123")
        args, kwargs = mock_make_request.call_args
        self.assertEqual(args[0], "POST")
        self.assertEqual(args[1], f"{self.client.base_url}/v1/snapshots")
        self.assertIn("build_args", kwargs["json"])
        self.assertEqual(
            kwargs["json"]["build_args"]["git_clone_url"],
            "https://github.com/example/repo.git"
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_vm_clone(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"vm_id": "vm_clone_1"}
        mock_make_request.return_value = mock_response

        response = self.client.vms.clone(
            vm_id="vm_src_1",
            wait=True,
            snapshot_name="clone-seed"
        )

        self.assertEqual(response["vm_id"], "vm_clone_1")
        args, kwargs = mock_make_request.call_args
        self.assertEqual(args[0], "POST")
        self.assertEqual(args[1], f"{self.client.base_url}/v1/vms/vm_src_1/clone")
        self.assertEqual(kwargs["params"]["wait"], "true")
        self.assertEqual(kwargs["json"]["snapshot_name"], "clone-seed")

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_share_create_uses_current_session(self, mock_make_request):
        self.client.session_id = "session_current_1"
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"share_id": "share_123", "port": 3000}
        mock_make_request.return_value = mock_response

        response = self.client.shares.create(port=3000, is_public=True)

        self.assertEqual(response["share_id"], "share_123")
        _, kwargs = mock_make_request.call_args
        self.assertEqual(kwargs["json"]["session_id"], "session_current_1")
        self.assertEqual(kwargs["json"]["port"], 3000)
        self.assertTrue(kwargs["json"]["is_public"])

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_computer_use_proxy_get(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"ok": True}
        mock_make_request.return_value = mock_response

        response = self.client.computer_use.get("session_1", "state")

        self.assertEqual(response, {"ok": True})
        args, _ = mock_make_request.call_args
        self.assertEqual(args[0], "GET")
        self.assertEqual(
            args[1],
            f"{self.client.base_url}/v1/computeruse/session_1/state"
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_get_session_info_escapes_path_segment(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"ok": True}
        mock_make_request.return_value = mock_response

        self.client.get_session_info("session/../../etc")

        args, _ = mock_make_request.call_args
        self.assertEqual(args[0], "GET")
        self.assertEqual(
            args[1],
            f"{self.client.base_url}/v1/sessions/session/session%2F..%2F..%2Fetc"
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_vms_get_escapes_path_segment(self, mock_make_request):
        mock_response = MagicMock()
        mock_response.content = b'{}'
        mock_response.json.return_value = {"vm_id": "vm_1"}
        mock_make_request.return_value = mock_response

        self.client.vms.get("vm/../../snapshots")

        args, _ = mock_make_request.call_args
        self.assertEqual(args[0], "GET")
        self.assertEqual(
            args[1],
            f"{self.client.base_url}/v1/vms/vm%2F..%2F..%2Fsnapshots"
        )

    @patch('instavm.sandbox_client.InstaVM._make_request')
    def test_computer_use_proxy_rejects_path_traversal(self, mock_make_request):
        calls_before = mock_make_request.call_count
        with self.assertRaises(ValueError):
            self.client.computer_use.get("session_1", "../state")

        # Traversal is blocked before an API request is made.
        self.assertEqual(mock_make_request.call_count, calls_before)

if __name__ == '__main__':
    unittest.main()
