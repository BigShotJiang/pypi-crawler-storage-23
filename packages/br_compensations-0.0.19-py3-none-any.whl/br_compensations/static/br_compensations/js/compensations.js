document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.compensation-approve').forEach(elm => elm.addEventListener('click', e => approveKillmail(e)));
    document.querySelectorAll('.compensation-reject').forEach(elm => elm.addEventListener('click', e => rejectKillmail(e)));
    document.querySelectorAll('.compensation-restore').forEach(elm=>elm.addEventListener('click', e => restoreKillmail(e)));
    document.querySelectorAll('.compensation-delete').forEach(elm=>elm.addEventListener('click', e=>deleteKillmail(e)));
});


async function deleteKillmail(evnt) {
    evnt.preventDefault();
    if (await showConfirm(`Вы уверены, что хотите удалить киллмэйл?\r\nЭто действие невозможно отменить.`)) {
        let result = await deleteKillmailRequest(evnt.target.dataset.id);
        if (result)
            evnt.target.closest('tr').remove();

    }
}

async function approveKillmail(evnt) {
    evnt.preventDefault();
    if (await showConfirm(`Вы уверены, что хотите пометить килл как компенсированный?`)) {
        let result = await updateKillmailRequest(evnt.target.dataset.id,'Компенсация выполнена','C');
        if (result)
            evnt.target.closest('tr').remove();

    }
}

async function rejectKillmail(evnt) {
    evnt.preventDefault();
    if (await showConfirm(`Вы уверены, что хотите отклонить килл?`)) {
        let result = await updateKillmailRequest(evnt.target.dataset.id,'Компенсация не выполнена. Килл был отклонен администратором.','R');
        if (result)
            evnt.target.closest('tr').remove();

    }
}

async function restoreKillmail(e){
    if(!(await showConfirm('Вы уверены, что хотите восстановить килл и перенести его в раздел "Новые"?')))
        return;

    let btn = e.currentTarget;
    let id = btn.dataset.id;

    let result = updateKillmailRequest(id,'Восстановлен администратором','N');
    if(result)
        window.location.reload()
}

async function updateKillmailRequest(id,comment,status) {
    let result = await fetch(`/br_compensations/api/killmails/${id}/`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({
            killmail_id: id,
            comment: comment,
            status: status
        })
    })
    .then(response => {
        if (!response.ok)
            throw new Error(`Response status code indicates error. Status code ${response.status}`);
        return response.json();
    })
    .then(data => {
        console.log(data);
        return data;
    })
    .catch(error => {
        console.error('Error: ', error);
    });

    return result;
}


async function deleteKillmailRequest(id) {
    let result = await fetch(`/br_compensations/api/killmails/${id}/`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken,
        },
        body: JSON.stringify({
            killmail_id: id
        })
    })
    .then(response => {
        if (!response.ok)
            throw new Error(`Response status code indicates error. Status code ${response.status}`);
        return true;
    })
    .then(data => {
        console.log(data);
        return data;
    })
    .catch(error => {
        console.error('Error: ', error);
    });

    return result;
}