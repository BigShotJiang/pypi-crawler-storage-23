from celery import shared_task
from django.db import transaction
from .models import BattleReport
from django.utils import timezone
from allianceauth.services.tasks import QueueOnce
from allianceauth.services.hooks import get_extension_logger
from .services import BattleReportsService

logger = get_extension_logger(__name__)

# Конфигурация
MAX_RETRIES = 3
BATCH_SIZE = 5
BACKOFF_SCHEDULE = [1, 5, 15]  # Минуты для экспоненциального бэк-оффа
PROCESSING_TIMEOUT = 300  # 5 минут на обработку

@shared_task(bind=True, base=QueueOnce)
def process_queued_links(self):
    """
    Обрабатывает отложенные ссылки из очереди.
    Использует блокировку записей для предотвращения обработки одной ссылки несколькими воркерами.
    """
    start_time = timezone.now()
    reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
    
    processed_count = 0
    failed_count = 0
    
    try:
        with transaction.atomic():
            # Блокируем записи для обработки (используем select_for_update)
            # Фильтруем записи со статусом PENDING, у которых время следующей попытки уже наступило
            start_time = timezone.now()
            queue_items = reports.select_for_update(skip_locked=True)[
                :BATCH_SIZE  # Ограничиваем количество обрабатываемых за раз
            ]
            
            for item in queue_items:
                item.status = BattleReport.PROCESS_PROCESSING
                item.save()
                
                try:
                    count = BattleReportsService.process(item.link)
                    if not count or count == None:
                        count = 0
                    if len(count) > 0:
                        # Успех - помечаем как завершенную
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        processed_count += len(count)
                    else:
                        # Нет целевых киллов, но данные получены
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        logger.info(f"No targeted kills found in {item.link}")
                
                except Exception as e:
                    logger.error(f'При обработке отчета произошла ошибка {e}',e)
                    item.status = BattleReport.PROCESS_FAILED
                    item.save()
                    
                # Прерываем обработку, если превышено время выполнения
                if (timezone.now() - start_time).total_seconds() > PROCESSING_TIMEOUT:
                    logger.info("Processing timeout reached, stopping batch")
                    break
    
    except Exception as e:
        logger.exception("Error in process_queued_links task")
        raise e
        
    return {
        "status": "completed",
        "processed_count": processed_count,
        "failed_count": failed_count,
        "duration": (timezone.now() - start_time).total_seconds()
    }

@shared_task
def cleanup_old_killmails():
    pass

