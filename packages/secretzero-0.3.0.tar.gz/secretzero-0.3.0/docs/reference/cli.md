# CLI Reference

The CLI provides commands for validation, sync, rotation, drift detection, and
policy enforcement.

## Entry Point

- `secretzero --help`

## Command Pages

- [CLI Overview](../user-guide/cli/index.md)
- [Create](../user-guide/cli/create.md)
- [Validate](../user-guide/cli/validate.md)
- [Sync](../user-guide/cli/sync.md)
- [Rotate](../user-guide/cli/rotate.md)
- [Drift](../user-guide/cli/drift.md)
