# Key Management

Use dedicated KMS or vault services to protect secrets at rest.

## Recommendations

- Use customer-managed keys when possible
- Rotate KMS keys on a regular schedule
- Limit key access to SecretZero service accounts
