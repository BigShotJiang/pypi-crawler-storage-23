"""JSON envelope models for Tooli structured output."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class EnvelopeMeta(BaseModel):
    tool: str
    version: str
    duration_ms: int = Field(ge=0)
    dry_run: bool = False
    warnings: list[str] = Field(default_factory=list)
    annotations: dict[str, Any] | None = None
    truncated: bool = False
    next_cursor: str | None = None
    truncation_message: str | None = None
    caller_id: str | None = None
    caller_version: str | None = None
    session_id: str | None = None
    output_schema: dict[str, Any] | None = None


class Envelope(BaseModel):
    ok: bool
    result: Any | None = None
    meta: EnvelopeMeta
