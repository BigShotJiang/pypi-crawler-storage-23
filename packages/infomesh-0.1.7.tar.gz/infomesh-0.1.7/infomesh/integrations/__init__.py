"""Third-party framework integrations."""

from __future__ import annotations
