"""Dashboard screen components."""

from __future__ import annotations
