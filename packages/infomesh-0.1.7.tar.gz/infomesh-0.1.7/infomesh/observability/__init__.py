"""Observability package — OpenTelemetry, Prometheus, tracing."""
