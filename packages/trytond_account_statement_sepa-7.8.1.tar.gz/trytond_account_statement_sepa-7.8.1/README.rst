#############################
Account Statement SEPA Module
#############################

The *Account Statement SEPA Module* implements the import of the CAMT.052,
CAMT.053 and CAMT.054 `SEPA <https://www.iso20022.org/>`_ files as statement.

.. toctree::
   :maxdepth: 2

   releases
