"""Channel adapters for messaging platforms."""

from .base import ChannelAdapter, InboundMessage, OutboundMessage

__all__ = [
    "ChannelAdapter",
    "InboundMessage",
    "OutboundMessage",
]
