"""IConfucius | Wisdom for Bitcoin Markets"""

__version__ = "0.6.0"
