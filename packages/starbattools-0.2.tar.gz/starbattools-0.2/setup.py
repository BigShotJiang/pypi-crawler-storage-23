from setuptools import setup, find_packages

setup(
    name="starbattools",
    version="0.2",
    packages=find_packages(),
    description="Lib RPG StarBat: mobs, ataque, magia, poções, vida infinita",
    author="StarBat",
    license="MIT",
)