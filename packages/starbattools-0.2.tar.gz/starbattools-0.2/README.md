# StarBatTools

StarBatTools é uma biblioteca Python para criar **RPGs estilo StarBat** de forma simples, usando **sintaxe minimalista**.  
Crie mobs, defina vida infinita, dano, mana, tipo, descrição e magias diretamente dentro de **uma única string**.

---

## **Instalação**

Se a lib estiver no PyPI:

```bash
pip install starbattools