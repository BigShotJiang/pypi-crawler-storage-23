def curar(alvo, quantidade=20):
    if alvo.vida != float('inf'):
        alvo.vida += quantidade
    print(f"{alvo.nome} foi curado em {quantidade}! Vida atual: {'infinita' if alvo.vida==float('inf') else alvo.vida}")

def restaurar_mana(alvo, quantidade=20):
    alvo.mana += quantidade
    print(f"{alvo.nome} restaurou {quantidade} de mana! Mana atual: {alvo.mana}")