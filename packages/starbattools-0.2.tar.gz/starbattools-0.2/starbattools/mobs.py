import re

class Mob:
    def __init__(self, nome, vida, dano=0, mana=0, descricao=None, magias=None):
        self.nome = nome
        self.vida = vida
        self.dano = dano
        self.mana = mana
        self.descricao = descricao
        self.magias = magias if magias else []

    def __repr__(self):
        vida_str = "infinita" if self.vida == float('inf') else self.vida
        desc_str = f" | {self.descricao}" if self.descricao else ""
        magias_str = f" | Magias: {','.join(self.magias)}" if self.magias else ""
        return f"<Mob {self.nome} | Vida: {vida_str} | Dano: {self.dano} | Mana: {self.mana}{desc_str}{magias_str}>"

def mob(info_str):
    """Cria um Mob a partir de string StarBat-style"""
    
    nome_match = re.search(r'nome\s*=\s*["\'](.*?)["\']', info_str)
    nome = nome_match.group(1) if nome_match else "Unknown"

    vida_match = re.search(r'vida\s*=\s*(\w+)', info_str)
    vida_str = vida_match.group(1) if vida_match else "0"
    vida = float('inf') if vida_str.lower() == "infinite" else int(vida_str)

    dano_match = re.search(r'dano\s*=\s*(\d+)', info_str)
    dano = int(dano_match.group(1)) if dano_match else 0

    mana_match = re.search(r'mana\s*=\s*(\d+)', info_str)
    mana = int(mana_match.group(1)) if mana_match else 0

    # descrição depois de type
    type_match = re.search(r'type\s*=\s*(.*?)(?:with|$)', info_str)
    descricao = type_match.group(1).strip() if type_match else None

    # magias
    magias_match = re.search(r'with magia\s*=\s*(.*)', info_str)
    magias = [m.strip() for m in magias_match.group(1).split(',')] if magias_match else []

    return Mob(nome, vida, dano, mana, descricao, magias)