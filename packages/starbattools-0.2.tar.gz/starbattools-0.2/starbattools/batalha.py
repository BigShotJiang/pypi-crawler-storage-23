def atacar(atacante, alvo):
    dano = atacante.dano
    if alvo.vida != float('inf'):
        alvo.vida -= dano
        if alvo.vida < 0:
            alvo.vida = 0
    print(f"{atacante.nome} atacou {alvo.nome} causando {dano} de dano! Vida do alvo: {'infinita' if alvo.vida==float('inf') else alvo.vida}")

def magia(atacante, alvo, nome_magia):
    if nome_magia not in atacante.magias:
        print(f"{atacante.nome} não conhece a magia {nome_magia}!")
        return
    
    custo_mana = 20
    dano_magia = 30

    if atacante.mana >= custo_mana:
        atacante.mana -= custo_mana
        if alvo.vida != float('inf'):
            alvo.vida -= dano_magia
            if alvo.vida < 0:
                alvo.vida = 0
        print(f"{atacante.nome} lançou {nome_magia} em {alvo.nome} causando {dano_magia} de dano! Mana restante: {atacante.mana}")
    else:
        print(f"{atacante.nome} não tem mana suficiente para {nome_magia}!")