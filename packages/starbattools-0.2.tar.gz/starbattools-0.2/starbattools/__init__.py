from .mobs import mob, Mob
from .batalha import atacar, magia
from .itens import curar, restaurar_mana