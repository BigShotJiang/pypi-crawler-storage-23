"""
Concert Booking Tool - Interactive CLI for testing the concert booking workflow
"""
import logging
import sys
import os
from typing import Optional, Literal
from langgraph.checkpoint.memory import MemorySaver
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import MFAConfig
from soprano_sdk.core.constants import InterruptType

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('concert_booking.log')
    ]
)
logger = logging.getLogger(__name__)


class ConcertBookingTool:
    """Interactive tool for concert ticket booking workflow"""

    def __init__(self, provider: Literal["openai", "ollama"] = "openai", model_name: Optional[str] = None):
        """
        Initialize the concert booking workflow tool

        Args:
            provider: Model provider ("openai" or "ollama")
            model_name: Model name to use (defaults based on provider)
        """
        logger.info("=" * 80)
        logger.info("Initializing Concert Booking Tool")
        logger.info("=" * 80)

        self.provider = provider
        self.model_name = model_name or self._get_default_model(provider)
        logger.info(f"Provider: {self.provider}")
        logger.info(f"Model: {self.model_name}")

        # Create checkpointer for state persistence
        self.checkpointer = MemorySaver()
        logger.info("✓ Checkpointer initialized (MemorySaver)")

        # Configure MFA with mock endpoints for testing
        self.mfa_config = MFAConfig(
            generate_token_base_url="http://localhost:8000",
            generate_token_path="/mfa/generate",
            validate_token_base_url="http://localhost:8000",
            validate_token_path="/mfa/validate",
            authorize_token_base_url="http://localhost:8000",
            authorize_token_path="/mfa/authorize"
        )
        logger.info("✓ MFA Config loaded (using mock endpoints)")

        # Initialize workflow tool
        import os
        # Get path relative to this file
        current_dir = os.path.dirname(os.path.abspath(__file__))
        yaml_path = os.path.join(current_dir, "concert_ticket_booking.yaml")

        # Configure model settings based on provider
        config = {
            "model_config": self._get_model_config()
        }
        logger.info(f"Model config: {config['model_config']}")

        try:
            self.workflow_tool = WorkflowTool(
                yaml_path=yaml_path,
                name="ConcertBooking",
                description="Tool for concert ticket booking",
                checkpointer=self.checkpointer,
                config=config,
                mfa_config=self.mfa_config
            )
            logger.info("✓ Workflow loaded successfully")
            logger.info(f"  Workflow: {self.workflow_tool.engine.workflow_name}")
            logger.info(f"  Version: {self.workflow_tool.engine.workflow_version}")
            logger.info(f"  Steps: {len(self.workflow_tool.engine.steps)}")
            logger.info(f"  Collector nodes: {len(self.workflow_tool.engine.collector_node_field_map)}")
        except Exception as e:
            logger.error(f"✗ Failed to load workflow: {e}", exc_info=True)
            raise

        self.current_thread_id = None
        logger.info("=" * 80)

    @staticmethod
    def _get_default_model(provider: str) -> str:
        """Get default model for the provider"""
        defaults = {
            "openai": "gpt-4o-mini",
            "ollama": "llama3.2"
        }
        return defaults.get(provider, "gpt-4o-mini")

    def _get_model_config(self) -> dict:
        """
        Get model configuration based on provider.

        Returns:
            Model configuration dictionary
        """
        if self.provider == "ollama":
            # Ollama configuration (no /v1 suffix - LiteLLM adds the path)
            ollama_base_url = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
            return {
                "model_name": self.model_name,
                "base_url": ollama_base_url,
                "provider": "ollama",
                "api_key": "dummy"
            }
        else:
            # OpenAI configuration (default)
            config = {
                "model_name": self.model_name,
                "provider": "openai"
            }
            # Add base_url if using custom OpenAI-compatible endpoint
            if openai_base_url := os.getenv("OPENAI_BASE_URL"):
                config["base_url"] = openai_base_url
            return config

    def start_booking(self, thread_id: Optional[str] = None, initial_context: Optional[dict] = None):
        """
        Start a new booking or resume an existing one.

        Args:
            thread_id: Thread ID for resuming an existing booking (optional)
            initial_context: Initial context to pre-populate fields (optional)
        """
        if thread_id:
            self.current_thread_id = thread_id
            logger.info(f"\n{'='*80}")
            logger.info(f"Resuming booking with thread_id: {thread_id}")
            logger.info(f"{'='*80}")
        else:
            import uuid
            self.current_thread_id = f"concert_{uuid.uuid4().hex[:8]}"
            logger.info(f"\n{'='*80}")
            logger.info(f"Starting new booking with thread_id: {self.current_thread_id}")
            logger.info(f"{'='*80}")

        # Ensure initial_context is a dict (not None)
        if initial_context is None:
            initial_context = {}

        if initial_context:
            logger.info(f"Initial context provided: {list(initial_context.keys())}")
            for key, value in initial_context.items():
                logger.info(f"  {key}: {value}")
        else:
            logger.info("No initial context provided")

        try:
            result = self.workflow_tool.execute(
                thread_id=self.current_thread_id,
                initial_context=initial_context
            )

            logger.info(f"\nWorkflow result: {result[:100]}...")
            return self._handle_result(result)

        except Exception as e:
            logger.error(f"✗ Error executing workflow: {e}", exc_info=True)
            return None

    def resume_with_input(self, user_input: str, initial_context: dict):
        """
        Resume the workflow with user input.

        Args:
            user_input: User's response to the current prompt
        """
        if not self.current_thread_id:
            logger.error("✗ No active booking session. Please start a new booking first.")
            return None

        logger.info(f"\n{'='*80}")
        logger.info(f"Resuming thread: {self.current_thread_id}")
        logger.info(f"User input: {user_input}")
        logger.info(f"{'='*80}")

        try:
            result = self.workflow_tool.execute(
                thread_id=self.current_thread_id,
                user_message=user_input,
                initial_context=initial_context
            )

            logger.info(f"\nWorkflow result: {result[:100]}...")
            return self._handle_result(result)

        except Exception as e:
            logger.error(f"✗ Error resuming workflow: {e}", exc_info=True)
            return None

    def _handle_result(self, result: str) -> dict:
        """
        Parse and handle workflow result.

        Args:
            result: Raw result from workflow execution

        Returns:
            Parsed result with type and data
        """
        if InterruptType.USER_INPUT in result:
            # Parse: __WORKFLOW_INTERRUPT__|thread_id|workflow_name|prompt
            parts = result.split("|")
            if len(parts) >= 4:
                thread_id = parts[1]
                workflow_name = parts[2]
                prompt = "|".join(parts[3:])  # Rejoin in case prompt contains |

                logger.info(f"\n{'─'*80}")
                logger.info("WORKFLOW INTERRUPTED - Waiting for user input")
                logger.info(f"{'─'*80}")
                logger.info(f"Thread ID: {thread_id}")
                logger.info(f"Prompt: {prompt}")

                return {
                    "type": "interrupt",
                    "thread_id": thread_id,
                    "workflow_name": workflow_name,
                    "prompt": prompt,
                    "needs_input": True
                }

        elif InterruptType.ASYNC in result:
            # Parse: __ASYNC_INTERRUPT__|thread_id|workflow_name|metadata
            parts = result.split("|")
            if len(parts) >= 4:
                thread_id = parts[1]
                workflow_name = parts[2]
                metadata = parts[3]

                logger.info(f"\n{'─'*80}")
                logger.info("ASYNC OPERATION PENDING")
                logger.info(f"{'─'*80}")
                logger.info(f"Thread ID: {thread_id}")
                logger.info(f"Metadata: {metadata}")

                return {
                    "type": "async",
                    "thread_id": thread_id,
                    "workflow_name": workflow_name,
                    "metadata": metadata,
                    "needs_input": False
                }

        else:
            # Workflow completed
            logger.info(f"\n{'='*80}")
            logger.info("WORKFLOW COMPLETED")
            logger.info(f"{'='*80}")
            logger.info(f"Final message: {result}")

            return {
                "type": "completed",
                "message": result,
                "needs_input": False
            }

    def interactive_session(self, initial_context: Optional[dict] = None):
        """
        Run an interactive CLI session for booking.

        Args:
            initial_context: Optional pre-populated context (defaults to empty dict)
        """
        # Ensure initial_context is a dict
        if initial_context is None:
            initial_context = {}

        print("\n" + "=" * 80)
        print("🎵 CONCERT TICKET BOOKING - Interactive Session")
        print("=" * 80)
        print("Type 'quit' or 'exit' to end the session")
        if initial_context:
            print(f"Pre-populated fields: {', '.join(initial_context.keys())}")
        print("=" * 80 + "\n")

        # Start booking
        result = self.start_booking(initial_context=initial_context)

        if not result:
            print("\n✗ Failed to start booking")
            return

        # Interactive loop
        while result and result.get("needs_input"):
            prompt = result.get("prompt", "Please provide input: ")
            print(f"\n🤖 Bot: {prompt}")

            try:
                user_input = input("\n👤 You: ").strip()

                if user_input.lower() in ['quit', 'exit']:
                    print("\nExiting booking session...")
                    logger.info("User exited session")
                    break

                if not user_input:
                    print("⚠️  Please provide valid input")
                    continue

                result = self.resume_with_input(user_input, initial_context)

            except KeyboardInterrupt:
                print("\n\nSession interrupted by user")
                logger.info("Session interrupted by user (Ctrl+C)")
                break
            except EOFError:
                print("\n\nEnd of input")
                logger.info("End of input (EOF)")
                break

        # Show final result
        if result and result.get("type") == "completed":
            print("\n" + "=" * 80)
            print("✓ BOOKING COMPLETE")
            print("=" * 80)
            print(f"\n{result['message']}")
            print("\n" + "=" * 80)
