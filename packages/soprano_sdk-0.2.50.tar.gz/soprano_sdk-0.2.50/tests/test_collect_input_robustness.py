
import unittest
from unittest.mock import MagicMock
from soprano_sdk.nodes.collect_input import CollectInputStrategy

class TestFieldStorageRobustness(unittest.TestCase):
    """
    Tests for `_store_field_values` robustness, specifically:
    1. Global Data Fields priority
    2. Local Structured Output fallback
    3. Type conversion logic
    """

    def setUp(self):
        # Base setup - will be customized per test
        self.step_config = {
            'id': 'test_step',
            'action': 'collect_input_with_agent',
            'field': 'user_profile',
            'agent': {
                'structured_output': {
                    'enabled': True,
                    'fields': []  # Will be populated in tests
                }
            }
        }
        self.engine_context = MagicMock()
        self.engine_context.data_fields = [] # Default empty global fields

    def test_global_definition_priority(self):
        """Verify global data_fields are used if available."""
        # Config: field defined globally as number
        self.engine_context.data_fields = [{'name': 'age', 'type': 'number'}]
        
        # Local config has no type info (or different, though usually they should match)
        self.step_config['agent']['structured_output']['fields'] = [{'name': 'age'}]
        
        strategy = CollectInputStrategy(self.step_config, self.engine_context)
        state = {}
        values = {'age': '30'} # String input
        
        strategy._store_field_values(state, values, fields=['age'])
        
        self.assertIsInstance(state.get('age'), int)
        self.assertEqual(state.get('age'), 30)

    def test_local_fallback_definition(self):
        """Verify local structured_output config is used if global definition missing."""
        # Config: empty global fields
        self.engine_context.data_fields = []
        
        # Local config defines 'age' as number
        self.step_config['agent']['structured_output']['fields'] = [{'name': 'age', 'type': 'number'}]
        
        strategy = CollectInputStrategy(self.step_config, self.engine_context)
        state = {}
        values = {'age': '25'} # String input
        
        strategy._store_field_values(state, values, fields=['age'])
        
        # Should convert to int based on local config
        self.assertIsInstance(state.get('age'), int)
        self.assertEqual(state.get('age'), 25)

    def test_no_type_definition(self):
        """Verify value stored as-is if no type definition found anywhere."""
        self.engine_context.data_fields = []
        self.step_config['agent']['structured_output']['fields'] = [{'name': 'unknown_field'}]
        
        strategy = CollectInputStrategy(self.step_config, self.engine_context)
        state = {}
        values = {'unknown_field': '123'} # String input
        
        strategy._store_field_values(state, values, fields=['unknown_field'])
        
        # Should define type as string (no conversion)
        self.assertIsInstance(state.get('unknown_field'), str)
        self.assertEqual(state.get('unknown_field'), '123')

    def test_invalid_conversion_handling(self):
        """Verify graceful failure (keep original value) if conversion fails."""
        self.engine_context.data_fields = []
        self.step_config['agent']['structured_output']['fields'] = [{'name': 'age', 'type': 'number'}]
        
        strategy = CollectInputStrategy(self.step_config, self.engine_context)
        state = {}
        values = {'age': 'invalid_number'} 
        
        strategy._store_field_values(state, values, fields=['age'])
        
        # Should keep original string value
        self.assertEqual(state.get('age'), 'invalid_number')

if __name__ == '__main__':
    unittest.main()
