"""
Tests for follow-up node functionality.
"""
from unittest.mock import MagicMock, patch

from soprano_sdk.core.constants import ActionType, WorkflowKeys
from soprano_sdk.nodes.follow_up import (
    FollowUpStrategy,
    _build_follow_up_instructions,
    DEFAULT_CLOSURE_PATTERNS
)
from soprano_sdk.nodes.factory import NodeFactory


class TestActionTypeFollowUp:
    """Test ActionType.FOLLOW_UP constant."""

    def test_follow_up_action_type_exists(self):
        """Verify FOLLOW_UP action type is defined."""
        assert hasattr(ActionType, 'FOLLOW_UP')
        assert ActionType.FOLLOW_UP.value == 'follow_up'


class TestNodeFactoryRegistration:
    """Test FollowUpStrategy is registered in NodeFactory."""

    def test_follow_up_is_registered(self):
        """Verify follow_up action is registered in factory."""
        assert NodeFactory.is_registered('follow_up')

    def test_factory_creates_follow_up_strategy(self):
        """Verify factory creates FollowUpStrategy for follow_up action."""
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"

        node_fn = NodeFactory.create(step_config, engine_context)

        # Should return a callable (the node function)
        assert callable(node_fn)


class TestFollowUpStrategyInit:
    """Test FollowUpStrategy initialization."""

    def _create_strategy(self, step_config_overrides=None, agent_config_overrides=None):
        """Helper to create a FollowUpStrategy with mocked context."""
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        if agent_config_overrides:
            step_config["agent"].update(agent_config_overrides)
        if step_config_overrides:
            step_config.update(step_config_overrides)

        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}

        return FollowUpStrategy(step_config, engine_context)

    def test_default_closure_patterns(self):
        """Verify default closure patterns are set."""
        strategy = self._create_strategy()
        assert strategy.closure_patterns == DEFAULT_CLOSURE_PATTERNS

    def test_custom_closure_patterns(self):
        """Verify custom closure patterns override defaults."""
        custom_patterns = ["bye", "exit", "quit"]
        strategy = self._create_strategy(
            step_config_overrides={"closure_patterns": custom_patterns}
        )
        assert strategy.closure_patterns == custom_patterns

    def test_out_of_scope_disabled_by_default(self):
        """Verify out-of-scope detection is disabled by default."""
        strategy = self._create_strategy()
        assert strategy.enable_out_of_scope is False

    def test_out_of_scope_can_be_enabled(self):
        """Verify out-of-scope detection can be enabled."""
        strategy = self._create_strategy(
            agent_config_overrides={"detect_out_of_scope": True}
        )
        assert strategy.enable_out_of_scope is True

    def test_scope_description_from_agent_description(self):
        """Verify scope_description combines workflow and agent descriptions."""
        strategy = self._create_strategy(
            agent_config_overrides={"description": "Custom follow-up description"}
        )
        assert strategy.scope_description == "Test workflow for follow-up questions. Currently: Custom follow-up description"

    def test_scope_description_fallback(self):
        """Verify scope_description has a fallback combined with workflow description."""
        strategy = self._create_strategy()
        assert strategy.scope_description == "Test workflow for follow-up questions. Currently: answering follow-up questions"

    def test_next_step_configured(self):
        """Verify next_step is read from config."""
        strategy = self._create_strategy()
        assert strategy.next_step == "next_step"


class TestFollowUpStrategyClosureDetection:
    """Test closure intent detection."""

    def _create_strategy(self):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_closure_detected_ok(self):
        """Test 'ok' is detected as closure."""
        strategy = self._create_strategy()
        assert strategy._is_closure_intent("ok") is True
        assert strategy._is_closure_intent("OK") is True
        assert strategy._is_closure_intent("Ok, sounds good") is True

    def test_closure_detected_thank_you(self):
        """Test 'thank you' is detected as closure."""
        strategy = self._create_strategy()
        assert strategy._is_closure_intent("thank you") is True
        assert strategy._is_closure_intent("Thank you!") is True
        assert strategy._is_closure_intent("thanks") is True

    def test_closure_detected_done(self):
        """Test 'done' is detected as closure."""
        strategy = self._create_strategy()
        assert strategy._is_closure_intent("done") is True
        assert strategy._is_closure_intent("I'm done") is True

    def test_closure_detected_got_it(self):
        """Test 'got it' is detected as closure."""
        strategy = self._create_strategy()
        assert strategy._is_closure_intent("got it") is True

    def test_no_closure_for_questions(self):
        """Test questions are not detected as closure."""
        strategy = self._create_strategy()
        assert strategy._is_closure_intent("What is my order ID?") is False
        assert strategy._is_closure_intent("Can you explain?") is False
        assert strategy._is_closure_intent("Tell me more") is False


class TestFollowUpStrategyResponseDetection:
    """Test agent response pattern detection."""

    def _create_strategy(self):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_out_of_scope_detection(self):
        """Test out-of-scope response detection."""
        strategy = self._create_strategy()
        assert strategy._is_out_of_scope("OUT_OF_SCOPE: User asking about weather") is True
        assert strategy._is_out_of_scope("Your order ID is 12345") is False

    def test_intent_change_detection(self):
        """Test intent change response detection."""
        strategy = self._create_strategy()
        assert strategy._is_intent_change("INTENT_CHANGE: collect_name") is True
        assert strategy._is_intent_change("Your order ID is 12345") is False


class TestFollowUpStrategySelfLoop:
    """Test self-loop detection."""

    def _create_strategy(self):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_is_self_loop_true(self):
        """Test self-loop detection when status is 'answering'."""
        strategy = self._create_strategy()
        state = {WorkflowKeys.STATUS: "test_followup_answering"}
        assert strategy._is_self_loop(state) is True

    def test_is_self_loop_false_first_entry(self):
        """Test self-loop is false on first entry."""
        strategy = self._create_strategy()
        state = {}
        assert strategy._is_self_loop(state) is False

    def test_is_self_loop_false_different_status(self):
        """Test self-loop is false with different status."""
        strategy = self._create_strategy()
        state = {WorkflowKeys.STATUS: "test_followup_next_step"}
        assert strategy._is_self_loop(state) is False


class TestFollowUpStrategyHandleClosure:
    """Test closure handling."""

    def _create_strategy(self, next_step="next_step"):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": next_step
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_handle_closure_routes_to_next_step(self):
        """Test closure routes to configured next step."""
        strategy = self._create_strategy(next_step="final_confirmation")
        state = {}

        result = strategy._handle_closure(state)

        assert result[WorkflowKeys.STATUS] == "test_followup_final_confirmation"

    def test_handle_closure_without_next_step(self):
        """Test closure sets 'complete' status when no next step."""
        strategy = self._create_strategy(next_step=None)
        state = {}

        result = strategy._handle_closure(state)

        assert result[WorkflowKeys.STATUS] == "test_followup_complete"


class TestFollowUpStrategyHandleOutOfScope:
    """Test out-of-scope handling."""

    def _create_strategy(self):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    @patch('soprano_sdk.nodes.follow_up.interrupt')
    def test_handle_out_of_scope_interrupts(self, mock_interrupt):
        """Test out-of-scope handling triggers interrupt."""
        strategy = self._create_strategy()
        state = {}
        user_message = "What's the weather?"

        strategy._handle_out_of_scope(
            "OUT_OF_SCOPE: User asking about weather",
            state,
            user_message
        )

        assert state['_out_of_scope_reason'] == "User asking about weather"
        mock_interrupt.assert_called_once()
        call_args = mock_interrupt.call_args[0][0]
        assert call_args['type'] == 'out_of_scope'
        assert call_args['step_id'] == 'test_followup'
        assert call_args['reason'] == "User asking about weather"
        assert call_args['user_message'] == user_message


class TestFollowUpStrategyHandleIntentChange:
    """Test intent change handling."""

    def _create_strategy(self):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_handle_intent_change_routes_to_target(self):
        """Test intent change routes to target node."""
        strategy = self._create_strategy()
        state = {}

        result = strategy._handle_intent_change("INTENT_CHANGE: collect_name", state)

        assert result[WorkflowKeys.STATUS] == "test_followup_collect_name"


class TestFollowUpStrategyTransitions:
    """Test transition matching."""

    def _create_strategy(self, transitions=None):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step",
            "transitions": transitions or []
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow for follow-up questions"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_check_transitions_match(self):
        """Test transition pattern matching."""
        transitions = [
            {"pattern": "ROUTE_TO_PAYMENT:", "next": "payment_step"},
            {"pattern": "ROUTE_TO_SHIPPING:", "next": "shipping_step"}
        ]
        strategy = self._create_strategy(transitions=transitions)

        assert strategy._check_transitions("ROUTE_TO_PAYMENT: process") == "payment_step"
        assert strategy._check_transitions("ROUTE_TO_SHIPPING: info") == "shipping_step"

    def test_check_transitions_no_match(self):
        """Test no transition match returns None."""
        transitions = [{"pattern": "ROUTE_TO_PAYMENT:", "next": "payment_step"}]
        strategy = self._create_strategy(transitions=transitions)

        assert strategy._check_transitions("Your order ID is 12345") is None


class TestFollowUpStrategyContextSummary:
    """Test context summary building."""

    def _create_strategy(self, data_fields=None):
        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": {"name": "test_agent"},
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = data_fields or []
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_build_context_summary_with_data(self):
        """Test context summary includes collected fields."""
        data_fields = [
            {"name": "order_id", "type": "text"},
            {"name": "customer_name", "type": "text"}
        ]
        strategy = self._create_strategy(data_fields=data_fields)
        state = {
            "order_id": "ORD-12345",
            "customer_name": "John Doe"
        }

        summary = strategy._build_context_summary(state)

        assert "order_id: ORD-12345" in summary
        assert "customer_name: John Doe" in summary

    def test_build_context_summary_empty(self):
        """Test context summary with no collected data."""
        strategy = self._create_strategy(data_fields=[])
        state = {}

        summary = strategy._build_context_summary(state)

        assert "No data collected yet" in summary


class TestBuildFollowUpInstructions:
    """Test instruction building function."""

    def test_includes_base_instructions(self):
        """Test base instructions are included."""
        instructions = _build_follow_up_instructions(
            base_instructions="Help with order questions.",
            context_summary="No context",
            collector_nodes={},
            enable_out_of_scope=False,
            scope_description=""
        )

        assert "Help with order questions." in instructions

    def test_includes_context_summary(self):
        """Test context summary is included."""
        instructions = _build_follow_up_instructions(
            base_instructions="Test",
            context_summary="order_id: 12345",
            collector_nodes={},
            enable_out_of_scope=False,
            scope_description=""
        )

        assert "order_id: 12345" in instructions

    def test_includes_intent_change_when_collectors_exist(self):
        """Test intent change instructions added when collectors exist."""
        collectors = {
            "collect_name": "Collect customer name",
            "collect_order": "Collect order ID"
        }
        instructions = _build_follow_up_instructions(
            base_instructions="Test",
            context_summary="",
            collector_nodes=collectors,
            enable_out_of_scope=False,
            scope_description=""
        )

        assert "INTENT_CHANGE:" in instructions
        assert "collect_name" in instructions
        assert "collect_order" in instructions

    def test_includes_out_of_scope_when_enabled(self):
        """Test out-of-scope instructions added when enabled."""
        instructions = _build_follow_up_instructions(
            base_instructions="Test",
            context_summary="",
            collector_nodes={},
            enable_out_of_scope=True,
            scope_description="answering return questions"
        )

        assert "OUT_OF_SCOPE:" in instructions
        assert "answering return questions" in instructions

    def test_excludes_out_of_scope_when_disabled(self):
        """Test out-of-scope instructions not added when disabled."""
        instructions = _build_follow_up_instructions(
            base_instructions="Test",
            context_summary="",
            collector_nodes={},
            enable_out_of_scope=False,
            scope_description="answering questions"
        )

        assert "OUT_OF_SCOPE:" not in instructions


class TestFollowUpInitialMessage:
    """Test optional initial_message support."""

    def _create_strategy(self, initial_message=None):
        agent_config = {"name": "test_agent"}
        if initial_message:
            agent_config["initial_message"] = initial_message

        step_config = {
            "id": "test_followup",
            "action": "follow_up",
            "agent": agent_config,
            "next": "next_step"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        engine_context.data_fields = []
        engine_context.workflow_description = "Test workflow"
        engine_context.outcome_map = {}
        return FollowUpStrategy(step_config, engine_context)

    def test_no_initial_message_by_default(self):
        """No initial_message returns None on first entry."""
        strategy = self._create_strategy()
        assert strategy.initial_message is None
        assert strategy._render_initial_message({}) is None

    def test_initial_message_stored(self):
        """initial_message is read from agent config."""
        strategy = self._create_strategy(
            initial_message="Your loan has been disbursed."
        )
        assert strategy.initial_message == "Your loan has been disbursed."

    def test_initial_message_renders_plain_text(self):
        """Plain initial_message renders as-is."""
        strategy = self._create_strategy(
            initial_message="Your booking is confirmed."
        )
        result = strategy._render_initial_message({})
        assert result == "Your booking is confirmed."

    def test_initial_message_renders_template_variables(self):
        """initial_message with template variables resolves from state."""
        strategy = self._create_strategy(
            initial_message="Your loan of ₹{{loan_amount}} has been disbursed to {{account_id}}."
        )
        state = {"loan_amount": "5,00,000", "account_id": "ACC-12345"}
        result = strategy._render_initial_message(state)
        assert result == "Your loan of ₹5,00,000 has been disbursed to ACC-12345."

    def test_initial_message_with_missing_variable(self):
        """Template with missing variable renders empty for that variable."""
        strategy = self._create_strategy(
            initial_message="Reference: {{booking_reference}}"
        )
        result = strategy._render_initial_message({})
        assert result == "Reference: "
