"""
Unit tests for dynamic options in pattern matching mode.

Tests the _extract_options_from_response method and its integration
with pattern matching workflows.
"""
import pytest
import json
from unittest.mock import Mock
from soprano_sdk.nodes.collect_input import CollectInputStrategy


class TestExtractOptionsFromResponse:
    """Tests for the _extract_options_from_response method."""

    @pytest.fixture
    def strategy(self):
        """Create a CollectInputStrategy instance for testing."""
        step_config = {
            'id': 'test_step',
            'field': 'test_field',
            'options': ['Default Option 1', 'Default Option 2'],
            'is_selectable': False,
            'agent': {
                'name': 'TestAgent',
                'instructions': 'Test instructions',
                'model': 'gpt-4o-mini'
            },
            'transitions': []
        }

        engine_context = Mock()
        engine_context.workflow_description = "Test workflow"
        engine_context.get_config_value = Mock(return_value=3)
        engine_context.function_repository = Mock()
        engine_context.tool_repository = Mock()
        engine_context.data_fields = [{'name': 'test_field', 'type': 'text'}]
        engine_context.outcome_map = {}
        engine_context.mfa_validator_steps = set()
        engine_context.steps = []

        return CollectInputStrategy(step_config, engine_context)

    def test_extract_valid_options_data(self, strategy):
        """Test extraction of valid OPTIONS_DATA."""
        agent_response = """Here are the available products:
- iPhone 15 Pro
- Samsung Galaxy S24
- MacBook Pro M3

Which one would you like?

OPTIONS_DATA: {"options": ["iPhone 15 Pro", "Samsung Galaxy S24", "MacBook Pro M3"], "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == """Here are the available products:
- iPhone 15 Pro
- Samsung Galaxy S24
- MacBook Pro M3

Which one would you like?"""
        assert options == ["iPhone 15 Pro", "Samsung Galaxy S24", "MacBook Pro M3"]
        assert is_selectable is True

    def test_missing_options_data_marker(self, strategy):
        """Test response without OPTIONS_DATA marker."""
        agent_response = "Please select a product from the list."

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Please select a product from the list."
        assert options == ['Default Option 1', 'Default Option 2']  # Falls back to config
        assert is_selectable is False  # Falls back to config

    def test_invalid_json_in_options_data(self, strategy):
        """Test OPTIONS_DATA with invalid JSON."""
        agent_response = """Select a product:

OPTIONS_DATA: {invalid json here}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select a product:"
        assert options == ['Default Option 1', 'Default Option 2']  # Falls back to config
        assert is_selectable is False  # Falls back to config

    def test_empty_options_list(self, strategy):
        """Test OPTIONS_DATA with empty options array."""
        agent_response = """No products available.

OPTIONS_DATA: {"options": [], "is_selectable": false}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "No products available."
        assert options == []  # Empty list is valid
        assert is_selectable is False

    def test_non_list_options_value(self, strategy):
        """Test OPTIONS_DATA where 'options' is not a list."""
        agent_response = """Select something:

OPTIONS_DATA: {"options": "not a list", "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select something:"
        assert options == ['Default Option 1', 'Default Option 2']  # Falls back to config
        assert is_selectable is False  # Falls back to config

    def test_missing_options_field(self, strategy):
        """Test OPTIONS_DATA without 'options' field."""
        agent_response = """Select something:

OPTIONS_DATA: {"is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select something:"
        assert options == ['Default Option 1', 'Default Option 2']  # Falls back to config
        assert is_selectable is True  # Still extracts this field

    def test_missing_is_selectable_field(self, strategy):
        """Test OPTIONS_DATA without 'is_selectable' field."""
        agent_response = """Select a product:

OPTIONS_DATA: {"options": ["Product A", "Product B"]}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select a product:"
        assert options == ["Product A", "Product B"]
        assert is_selectable is False  # Falls back to config

    def test_options_data_in_middle_of_response(self, strategy):
        """Test OPTIONS_DATA with trailing text after the JSON object.

        convert_to_dict extracts the outermost {...} by scanning for the first '{'
        and last '}', so trailing non-JSON text is ignored and options parse correctly.
        """
        agent_response = """Here are products:

OPTIONS_DATA: {"options": ["A", "B"], "is_selectable": true}

Some additional text after."""

        result = strategy._extract_options_from_response(agent_response)
        assert result.message == "Here are products:"
        # convert_to_dict strips trailing text, so options are successfully extracted
        assert result.options == ["A", "B"]
        assert result.is_selectable is True

    def test_dict_options_in_options_data(self, strategy):
        """Test that dict options (text/subtext format) pass through unchanged."""
        agent_response = (
            "Choose your plan:\n\n"
            'OPTIONS_DATA: {"options": [{"text": "Basic", "subtext": "Free"}, '
            '{"text": "Pro", "subtext": "$9/month"}], "is_selectable": true}'
        )

        result = strategy._extract_options_from_response(agent_response)
        assert result.message == "Choose your plan:"
        assert result.options == [
            {"text": "Basic", "subtext": "Free"},
            {"text": "Pro", "subtext": "$9/month"},
        ]
        assert result.is_selectable is True

    def test_single_quote_json_parsed_via_ast_eval(self, strategy):
        """Test that single-quoted Python dict literals are parsed via ast.literal_eval.

        Some LLMs emit single-quoted dicts that fail json.loads but succeed
        ast.literal_eval, which convert_to_dict uses as a fallback.
        """
        agent_response = (
            "Select a tier:\n\n"
            "OPTIONS_DATA: {'options': ['VIP', 'Premium'], 'is_selectable': True}"
        )

        result = strategy._extract_options_from_response(agent_response)
        assert result.message == "Select a tier:"
        assert result.options == ["VIP", "Premium"]
        assert result.is_selectable is True

    def test_whitespace_handling(self, strategy):
        """Test OPTIONS_DATA with extra whitespace."""
        agent_response = """Select:

OPTIONS_DATA:    {"options": ["A", "B"], "is_selectable": true}    """

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select:"
        assert options == ["A", "B"]
        assert is_selectable is True

    def test_single_option(self, strategy):
        """Test OPTIONS_DATA with single option."""
        agent_response = """Only one available:

OPTIONS_DATA: {"options": ["Only Option"], "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Only one available:"
        assert options == ["Only Option"]
        assert is_selectable is True

    def test_many_options(self, strategy):
        """Test OPTIONS_DATA with many options."""
        many_options = [f"Option {i}" for i in range(20)]
        agent_response = f"""Many options:

OPTIONS_DATA: {json.dumps({"options": many_options, "is_selectable": False})}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Many options:"
        assert options == many_options
        assert is_selectable is False

    def test_unicode_in_options(self, strategy):
        """Test OPTIONS_DATA with Unicode characters."""
        agent_response = """Select language:

OPTIONS_DATA: {"options": ["English", "中文", "日本語", "한국어"], "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select language:"
        assert options == ["English", "中文", "日本語", "한국어"]
        assert is_selectable is True

    def test_special_characters_in_options(self, strategy):
        """Test OPTIONS_DATA with special characters."""
        agent_response = """Select:

OPTIONS_DATA: {"options": ["Product A & B", "Option with quotes", "Price: $99.99"], "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "Select:"
        assert options == ["Product A & B", "Option with quotes", "Price: $99.99"]
        assert is_selectable is True


class TestPatternMatchingWithDynamicOptions:
    """Integration tests for pattern matching with dynamic options."""

    @pytest.fixture
    def strategy(self):
        """Create a strategy with pattern matching transitions."""
        step_config = {
            'id': 'collect_product',
            'field': 'selected_product',
            'options': ['Static Option'],
            'is_selectable': False,
            'agent': {
                'name': 'ProductCollector',
                'instructions': 'Test instructions',
                'model': 'gpt-4o-mini'
            },
            'transitions': [
                {'pattern': 'PRODUCT_CAPTURED:', 'next': 'next_step'}
            ]
        }

        engine_context = Mock()
        engine_context.workflow_description = "Test workflow"
        engine_context.get_config_value = Mock(return_value=3)
        engine_context.function_repository = Mock()
        engine_context.tool_repository = Mock()
        engine_context.data_fields = [{'name': 'selected_product', 'type': 'text'}]
        engine_context.outcome_map = {}
        engine_context.mfa_validator_steps = set()
        engine_context.steps = []

        return CollectInputStrategy(step_config, engine_context)

    def test_pattern_matching_with_options_data(self, strategy):
        """Test that pattern matching works with OPTIONS_DATA present."""
        agent_response = """Here are the products:

PRODUCT_CAPTURED: iPhone 15 Pro

OPTIONS_DATA: {"options": ["iPhone 15 Pro", "Samsung Galaxy S24"], "is_selectable": true}"""

        # Test extraction
        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        # Verify OPTIONS_DATA extracted
        assert options == ["iPhone 15 Pro", "Samsung Galaxy S24"]
        assert is_selectable is True

        # Verify pattern matching still works on cleaned response
        assert "PRODUCT_CAPTURED:" in cleaned_response
        assert "OPTIONS_DATA:" not in cleaned_response

    def test_pattern_extraction_from_cleaned_response(self, strategy):
        """Test value extraction uses cleaned response."""
        agent_response = """PRODUCT_CAPTURED: Samsung Galaxy S24

OPTIONS_DATA: {"options": ["A", "B"], "is_selectable": true}"""

        result = strategy._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options

        # Extract value from cleaned response (simulating pattern matching)
        pattern = "PRODUCT_CAPTURED:"
        value = cleaned_response.split(pattern)[1].strip()

        assert value == "Samsung Galaxy S24"
        assert options == ["A", "B"]


class TestBackwardCompatibility:
    """Tests for backward compatibility with existing workflows."""

    @pytest.fixture
    def strategy_no_config_options(self):
        """Strategy without options in config (legacy behavior)."""
        step_config = {
            'id': 'collect_name',
            'field': 'user_name',
            # No 'options' or 'is_selectable' in config
            'agent': {
                'name': 'NameCollector',
                'instructions': 'Test',
                'model': 'gpt-4o-mini'
            },
            'transitions': []
        }

        engine_context = Mock()
        engine_context.workflow_description = "Test"
        engine_context.get_config_value = Mock(return_value=3)
        engine_context.function_repository = Mock()
        engine_context.tool_repository = Mock()
        engine_context.data_fields = [{'name': 'user_name', 'type': 'text'}]
        engine_context.outcome_map = {}
        engine_context.mfa_validator_steps = set()
        engine_context.steps = []

        return CollectInputStrategy(step_config, engine_context)

    def test_legacy_workflow_without_options(self, strategy_no_config_options):
        """Test that workflows without options config still work."""
        agent_response = "What is your name?"

        result = strategy_no_config_options._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        assert cleaned_response == "What is your name?"
        assert options == []  # Empty list (no options configured)
        assert is_selectable is False  # Default value

    def test_legacy_workflow_ignores_options_data(self, strategy_no_config_options):
        """Test that legacy workflows can still use OPTIONS_DATA if agent includes it."""
        agent_response = """What is your name?

OPTIONS_DATA: {"options": ["John", "Jane"], "is_selectable": false}"""

        result = strategy_no_config_options._extract_options_from_response(agent_response)
        cleaned_response = result.message
        options = result.options
        is_selectable = result.is_selectable

        # Even without config, OPTIONS_DATA is extracted
        assert cleaned_response == "What is your name?"
        assert options == ["John", "Jane"]
        assert is_selectable is False

    def test_string_options_in_config_stored_as_is(self):
        """String options from YAML/config are stored directly without transformation."""
        step_config = {
            'id': 'test_step',
            'field': 'test_field',
            'options': ['Yes', 'No'],
            'is_selectable': True,
            'agent': {'name': 'Agent', 'instructions': 'Test', 'model': 'gpt-4o-mini'},
            'transitions': []
        }
        engine_context = Mock()
        engine_context.workflow_description = "Test"
        engine_context.get_config_value = Mock(return_value=3)
        engine_context.function_repository = Mock()
        engine_context.tool_repository = Mock()
        engine_context.data_fields = [{'name': 'test_field', 'type': 'text'}]
        engine_context.outcome_map = {}
        engine_context.mfa_validator_steps = set()
        engine_context.steps = []

        strategy = CollectInputStrategy(step_config, engine_context)
        assert strategy.options == ['Yes', 'No']

    def test_dict_options_in_config_stored_as_is(self):
        """Dict options with text/subtext from YAML/config are stored without transformation."""
        step_config = {
            'id': 'test_step',
            'field': 'test_field',
            'options': [
                {'text': 'Premium', 'subtext': 'Full access'},
                {'text': 'Basic', 'subtext': 'Limited access'},
            ],
            'is_selectable': True,
            'agent': {'name': 'Agent', 'instructions': 'Test', 'model': 'gpt-4o-mini'},
            'transitions': []
        }
        engine_context = Mock()
        engine_context.workflow_description = "Test"
        engine_context.get_config_value = Mock(return_value=3)
        engine_context.function_repository = Mock()
        engine_context.tool_repository = Mock()
        engine_context.data_fields = [{'name': 'test_field', 'type': 'text'}]
        engine_context.outcome_map = {}
        engine_context.mfa_validator_steps = set()
        engine_context.steps = []

        strategy = CollectInputStrategy(step_config, engine_context)
        assert strategy.options == [
            {'text': 'Premium', 'subtext': 'Full access'},
            {'text': 'Basic', 'subtext': 'Limited access'},
        ]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
