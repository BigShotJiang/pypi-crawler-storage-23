Usage
=====

Example usage:

.. code-block:: python

   import pybFoam
   # Load mesh, access fields, run aggregation, etc.
