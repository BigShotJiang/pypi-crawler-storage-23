.. _changelog:

Changelog
=========

See the GitHub releases page for a full changelog.
