.. _installation:


Installation
============

Install pybFoam with pip:

.. code-block:: bash

   pip install pybFoam

See the README.md for OpenFOAM requirements and build instructions.
