"""
Result containers for slope stability analysis.

Each dataclass stores analysis outputs and provides:
- summary() -> formatted string for human reading
- to_dict() -> flat dict for LLM agent consumption

All units SI: meters, kPa, kN/m, degrees.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple


@dataclass
class SliceData:
    """Per-slice data for detailed output and plotting.

    Attributes
    ----------
    x_mid : float
        x-coordinate of slice midpoint (m).
    z_top : float
        Ground surface elevation at midpoint (m).
    z_base : float
        Slip surface elevation at midpoint (m).
    width : float
        Slice width b (m).
    height : float
        Slice height h (m).
    alpha_deg : float
        Base inclination angle (degrees).
    weight : float
        Total slice weight W (kN/m).
    pore_pressure : float
        Pore water pressure at base u (kPa).
    c : float
        Cohesion at base (kPa).
    phi : float
        Friction angle at base (degrees).
    base_length : float
        Length of slice base dl (m).
    normal_stress_kPa : float
        Effective normal stress on base = N' / dl (kPa).
    shear_stress_kPa : float
        Mobilized shear stress on base = S_mobilized / dl (kPa).
        Positive = driving (base slopes downhill), negative = resisting.
    shear_resistance_kPa : float
        Available shear resistance on base = T_available / dl (kPa).
    """
    x_mid: float = 0.0
    z_top: float = 0.0
    z_base: float = 0.0
    width: float = 0.0
    height: float = 0.0
    alpha_deg: float = 0.0
    weight: float = 0.0
    pore_pressure: float = 0.0
    c: float = 0.0
    phi: float = 0.0
    base_length: float = 0.0
    normal_stress_kPa: float = 0.0
    shear_stress_kPa: float = 0.0
    shear_resistance_kPa: float = 0.0
    in_tension_crack: bool = False

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "x_mid_m": round(self.x_mid, 3),
            "z_top_m": round(self.z_top, 3),
            "z_base_m": round(self.z_base, 3),
            "width_m": round(self.width, 3),
            "height_m": round(self.height, 3),
            "alpha_deg": round(self.alpha_deg, 2),
            "weight_kN_per_m": round(self.weight, 1),
            "pore_pressure_kPa": round(self.pore_pressure, 1),
            "c_kPa": round(self.c, 1),
            "phi_deg": round(self.phi, 1),
            "base_length_m": round(self.base_length, 3),
            "normal_stress_kPa": round(self.normal_stress_kPa, 2),
            "shear_stress_kPa": round(self.shear_stress_kPa, 2),
            "shear_resistance_kPa": round(self.shear_resistance_kPa, 2),
        }
        if self.in_tension_crack:
            d["in_tension_crack"] = True
        return d


@dataclass
class SlopeStabilityResult:
    """Results from slope stability analysis.

    Attributes
    ----------
    FOS : float
        Factor of safety.
    method : str
        Analysis method ('Fellenius', 'Bishop', 'Spencer', 'Morgenstern-Price').
    xc : float
        Circle center x-coordinate (m). 0 for noncircular.
    yc : float
        Circle center z-coordinate / elevation (m). 0 for noncircular.
    radius : float
        Circle radius (m). 0 for noncircular.
    x_entry : float
        Slip surface entry x-coordinate (m).
    x_exit : float
        Slip surface exit x-coordinate (m).
    theta_spencer : float or None
        Interslice force angle from Spencer (degrees).
    FOS_fellenius : float or None
        Fellenius FOS for comparison.
    FOS_bishop : float or None
        Bishop FOS for comparison (circular only).
    FOS_spencer : float or None
        Spencer FOS for comparison.
    FOS_morgenstern_price : float or None
        Morgenstern-Price FOS for comparison.
    lambda_mp : float or None
        Morgenstern-Price interslice force scaling factor.
    n_slices : int
        Number of slices used.
    has_seismic : bool
        Whether seismic load was applied.
    kh : float
        Horizontal seismic coefficient.
    slice_data : list of SliceData or None
        Per-slice breakdown.
    slip_points : list of (float, float) or None
        Noncircular slip surface points. None for circular.
    tension_crack_depth : float
        Depth of tension crack (m). 0 = no crack.
    tension_crack_water_depth : float
        Depth of water in tension crack (m). 0 = dry.
    """
    FOS: float = 0.0
    method: str = ""
    xc: float = 0.0
    yc: float = 0.0
    radius: float = 0.0
    x_entry: float = 0.0
    x_exit: float = 0.0
    theta_spencer: Optional[float] = None
    FOS_fellenius: Optional[float] = None
    FOS_bishop: Optional[float] = None
    FOS_spencer: Optional[float] = None
    FOS_morgenstern_price: Optional[float] = None
    lambda_mp: Optional[float] = None
    n_slices: int = 0
    has_seismic: bool = False
    kh: float = 0.0
    slice_data: Optional[List[SliceData]] = None
    slip_points: Optional[List[Tuple[float, float]]] = None
    tension_crack_depth: float = 0.0
    tension_crack_water_depth: float = 0.0

    @property
    def is_circular(self) -> bool:
        """True if this result represents a circular slip surface."""
        return self.radius > 0

    @property
    def is_stable(self) -> bool:
        """True if FOS >= 1.0."""
        return self.FOS >= 1.0

    def summary(self) -> str:
        lines = [
            "=" * 60,
            "  SLOPE STABILITY ANALYSIS RESULTS",
            "=" * 60,
            "",
            f"  Method:           {self.method}",
            f"  Factor of Safety: {self.FOS:.3f}",
            "",
        ]
        if self.is_circular:
            lines.extend([
                f"  Critical Circle:",
                f"    Center (xc, yc) = ({self.xc:.2f}, {self.yc:.2f}) m",
                f"    Radius R        = {self.radius:.2f} m",
            ])
        else:
            lines.append(f"  Slip Surface:     Noncircular ({len(self.slip_points or [])} points)")
        lines.extend([
            f"    Entry x         = {self.x_entry:.2f} m",
            f"    Exit x          = {self.x_exit:.2f} m",
            "",
            f"  Slices: {self.n_slices}",
        ])
        if self.has_seismic:
            lines.append(f"  Seismic kh:       {self.kh:.3f}")
        if self.tension_crack_depth > 0:
            lines.append(f"  Tension crack:    {self.tension_crack_depth:.2f} m deep")
            if self.tension_crack_water_depth > 0:
                lines.append(f"  Crack water:      {self.tension_crack_water_depth:.2f} m")
        if self.FOS_fellenius is not None:
            lines.append(f"  FOS (Fellenius):  {self.FOS_fellenius:.3f}")
        if self.FOS_bishop is not None and self.method != "Bishop":
            lines.append(f"  FOS (Bishop):     {self.FOS_bishop:.3f}")
        if self.FOS_spencer is not None and self.method != "Spencer":
            lines.append(f"  FOS (Spencer):    {self.FOS_spencer:.3f}")
        if self.theta_spencer is not None:
            lines.append(f"  Spencer theta:    {self.theta_spencer:.2f} deg")
        if self.FOS_morgenstern_price is not None and self.method != "Morgenstern-Price":
            lines.append(f"  FOS (M-P):        {self.FOS_morgenstern_price:.3f}")
        if self.lambda_mp is not None:
            lines.append(f"  M-P lambda:       {self.lambda_mp:.3f}")
        lines.extend(["", "=" * 60])
        return "\n".join(lines)

    def plot_slip_surface_stresses(self, ax=None, show=True, **kwargs):
        """Plot contact stresses along the slip surface.

        Shows effective normal stress, mobilized shear stress, and
        available shear resistance vs distance along the slip surface.

        Returns
        -------
        matplotlib.axes.Axes
        """
        if not self.slice_data:
            raise ValueError("No slice data available. "
                             "Use include_slice_data=True in analyze_slope().")
        from geotech_common.plotting import get_pyplot, setup_engineering_plot
        plt = get_pyplot()
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 5))

        # Cumulative arc length along slip surface
        dist = []
        cumulative = 0.0
        for sd in self.slice_data:
            cumulative += sd.base_length
            dist.append(cumulative - sd.base_length / 2.0)

        sigma_n = [sd.normal_stress_kPa for sd in self.slice_data]
        tau_mob = [sd.shear_stress_kPa for sd in self.slice_data]
        tau_avail = [sd.shear_resistance_kPa for sd in self.slice_data]

        ax.plot(dist, sigma_n, 'b-o', markersize=3, linewidth=1.5,
                label="$\\sigma'_n$ (effective normal)")
        ax.plot(dist, tau_mob, 'r--s', markersize=3, linewidth=1.5,
                label="$\\tau_{mob}$ (mobilized shear)")
        ax.plot(dist, tau_avail, 'g-^', markersize=3, linewidth=1.5,
                label="$\\tau_{avail}$ (shear resistance)")

        ax.legend(fontsize=9)
        setup_engineering_plot(ax, f"Contact Stresses Along Slip Surface (FOS={self.FOS:.3f})",
                              "Distance Along Slip Surface (m)", "Stress (kPa)")
        if show:
            plt.tight_layout()
            plt.show()
        return ax

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "FOS": round(self.FOS, 4),
            "is_stable": self.is_stable,
            "method": self.method,
            "surface_type": "circular" if self.is_circular else "noncircular",
            "xc_m": round(self.xc, 2),
            "yc_m": round(self.yc, 2),
            "radius_m": round(self.radius, 2),
            "x_entry_m": round(self.x_entry, 2),
            "x_exit_m": round(self.x_exit, 2),
            "n_slices": self.n_slices,
            "has_seismic": self.has_seismic,
            "kh": self.kh,
        }
        if self.tension_crack_depth > 0:
            d["tension_crack_depth_m"] = round(self.tension_crack_depth, 2)
            d["tension_crack_water_depth_m"] = round(self.tension_crack_water_depth, 2)
        if self.slip_points is not None:
            d["slip_points"] = [
                (round(x, 3), round(z, 3)) for x, z in self.slip_points
            ]
        if self.FOS_fellenius is not None:
            d["FOS_fellenius"] = round(self.FOS_fellenius, 4)
        if self.FOS_bishop is not None:
            d["FOS_bishop"] = round(self.FOS_bishop, 4)
        if self.FOS_spencer is not None:
            d["FOS_spencer"] = round(self.FOS_spencer, 4)
        if self.theta_spencer is not None:
            d["theta_spencer_deg"] = round(self.theta_spencer, 2)
        if self.FOS_morgenstern_price is not None:
            d["FOS_morgenstern_price"] = round(self.FOS_morgenstern_price, 4)
        if self.lambda_mp is not None:
            d["lambda_mp"] = round(self.lambda_mp, 4)
        if self.slice_data is not None:
            d["slice_data"] = [s.to_dict() for s in self.slice_data]
        return d


@dataclass
class SearchResult:
    """Results from a critical surface search.

    Attributes
    ----------
    critical : SlopeStabilityResult
        Result for the critical (minimum FOS) surface.
    n_surfaces_evaluated : int
        Total number of trial surfaces evaluated.
    grid_fos : list of dict
        Grid of {xc, yc, R, FOS} for all evaluated surfaces.
    """
    critical: Optional[SlopeStabilityResult] = None
    n_surfaces_evaluated: int = 0
    grid_fos: List[Dict[str, float]] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            "=" * 60,
            "  CRITICAL SURFACE SEARCH RESULTS",
            "=" * 60,
            "",
            f"  Surfaces evaluated: {self.n_surfaces_evaluated}",
        ]
        if self.critical:
            lines.append(f"  Minimum FOS:       {self.critical.FOS:.3f}")
            lines.append(f"  Method:            {self.critical.method}")
            if self.critical.is_circular:
                lines.append(
                    f"  Critical circle:   "
                    f"({self.critical.xc:.2f}, {self.critical.yc:.2f}), "
                    f"R={self.critical.radius:.2f} m"
                )
            else:
                lines.append(
                    f"  Critical surface:  Noncircular "
                    f"({len(self.critical.slip_points or [])} points)"
                )
        lines.extend(["", "=" * 60])
        return "\n".join(lines)

    def plot_fos_contour(self, ax=None, show=True, **kwargs):
        """Plot FOS at each trial circle center as a scatter/contour.

        Returns
        -------
        matplotlib.axes.Axes
        """
        if not self.grid_fos:
            raise ValueError("No grid FOS data available for plotting.")
        from geotech_common.plotting import get_pyplot, setup_engineering_plot
        plt = get_pyplot()
        if ax is None:
            fig, ax = plt.subplots(figsize=(8, 6))
        xc_vals = [g['xc'] for g in self.grid_fos]
        yc_vals = [g['yc'] for g in self.grid_fos]
        fos_vals = [g['FOS'] for g in self.grid_fos]
        sc = ax.scatter(xc_vals, yc_vals, c=fos_vals, cmap='RdYlGn',
                        edgecolors='black', linewidth=0.5, s=60, **kwargs)
        plt.colorbar(sc, ax=ax, label='Factor of Safety')
        if self.critical:
            ax.plot(self.critical.xc, self.critical.yc, 'r*', markersize=15,
                    markeredgecolor='black', label=f'Critical (FOS={self.critical.FOS:.3f})')
            ax.legend()
        setup_engineering_plot(ax, "Critical Surface Search",
                              "Circle Center X (m)", "Circle Center Y (m)")
        if show:
            plt.tight_layout()
            plt.show()
        return ax

    def to_dict(self) -> Dict[str, Any]:
        d = {"n_surfaces_evaluated": self.n_surfaces_evaluated}
        if self.critical:
            d["critical"] = self.critical.to_dict()
        return d
