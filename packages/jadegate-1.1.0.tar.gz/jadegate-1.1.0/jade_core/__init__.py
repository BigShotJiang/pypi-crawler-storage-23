"""
Project JADE - Deterministic Security Protocol for AI Agents
=============================================================

The Package Manager and Immunity Network for AI Agents.

Core modules:
- models: Data structures and types
- validator: Schema and security validation
- security: Zero-trust security engine
- dag: DAG structural analysis
- client: SDK for agents to fetch and use skills
- registry: Index management and confidence scoring
"""

__version__ = "1.0.0"
__protocol_version__ = "1.0.0"

from .models import (
    JadeSkill,
    ValidationResult,
    ValidationIssue,
    ValidationSeverity,
    SecurityPolicy,
    ExecutionDAG,
    DAGNode,
    DAGEdge,
    Trigger,
    TriggerCondition,
    SkillMetadata,
    SandboxLevel,
    TriggerType,
    ConditionOperator,
    RiskLevel,
    RegistryEntry,
    Attestation,
    AttestationType,
)
from .validator import JadeValidator
from .security import SecurityEngine
from .dag import DAGAnalyzer
from .client import JadeClient
from .registry import JadeRegistry



def activate(project_dir: str = "."):
    """
    Activate JadeGate auto-discovery in current environment.
    
    Usage:
        import jadegate
        jadegate.activate()
    
    This scans your env vars and project files, then makes
    matching skills available to any AI agent framework.
    """
    from .autodiscovery import JadeAutoDiscovery
    disco = JadeAutoDiscovery(project_dir)
    env_report = disco.scan_environment()
    manifest = disco.generate_manifest()
    return {
        "detected_services": env_report.get("detected_services", []),
        "recommended_skills": env_report.get("recommended_skills", []),
        "manifest_path": manifest,
        "total_skills": env_report.get("total_available", 0),
    }

__all__ = [
    # Core classes
    "JadeValidator",
    "SecurityEngine",
    "DAGAnalyzer",
    "JadeClient",
    "JadeRegistry",
    # Models
    "JadeSkill",
    "ValidationResult",
    "ValidationIssue",
    "ValidationSeverity",
    "SecurityPolicy",
    "ExecutionDAG",
    "DAGNode",
    "DAGEdge",
    "Trigger",
    "TriggerCondition",
    "SkillMetadata",
    "SandboxLevel",
    "TriggerType",
    "ConditionOperator",
    "RiskLevel",
    "RegistryEntry",
    "Attestation",
    "AttestationType",
]
