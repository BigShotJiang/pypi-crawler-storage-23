"""Version information for adk-redis."""

from importlib.metadata import version

__version__ = version("adk-redis")
