from ..base_data import data_register


Demo1 = data_register.new_group('demo1')
Demo2 = data_register.new_group('demo2')

@data_register('data.demo1', rewrite_func='forward_batch_input')
def build_pre_suffix(data, input_key='content', prefix='', suffix=''):
    """Add a prefix and suffix to the specified field of each item in the input list. Registered as a batch operator.

Args:
    data (list[dict]): list of dicts
    input_key (str): key name of the text field
    prefix (str): string to add before the field
    suffix (str): string to add after the field


Examples:
    ```python
    from lazyllm.tools.data.operators.demo_ops import build_pre_suffix
    
    op = build_pre_suffix(input_key='text', prefix='Hello, ', suffix='!')
    print(op([{'text': 'world'}]))
    # [{'text': 'Hello, world!'}]
    ```
    """
    assert isinstance(data, list)
    for item in data:
        item[input_key] = f'{prefix}{item.get(input_key, "")}{suffix}'
    return data

@data_register('data.demo1', rewrite_func='forward', _concurrency_mode='process')
def process_uppercase(data, input_key='content'):
    """Convert the input text field to uppercase. Intended as a single-item processing function.

Args:
    data (dict): a dict representing a single data item.
    input_key (str): key name of the text field, default 'content'.


Examples:
    ```python
    from lazyllm.tools.data.operators.demo_ops import process_uppercase
    
    op = process_uppercase(input_key='text')
    print(op({'text': 'hello'}))  # {'text': 'HELLO'}
    ```
    """
    assert isinstance(data, dict)
    data[input_key] = data.get(input_key, '').upper()
    return data

class AddSuffix(Demo2):
    """Class-based operator that appends a suffix to a specified field. Supports concurrency configuration via constructor args.

Args:
    suffix (str): suffix string to append
    input_key (str): key name of the text field
    _max_workers (int|None): optional max concurrency
    _concurrency_mode (str): optional concurrency mode
    _save_data (bool): optional whether to persist results


Examples:
    ```python
    from lazyllm.tools.data.operators.demo_ops import AddSuffix
    
    op = AddSuffix(suffix='!!!', input_key='text', _max_workers=2)
    print(op([{'text': 'wow'}]))  # [{'text': 'wow!!!'}]
    ```
    """
    def __init__(self, suffix, input_key='content', _concurrency_mode='process', **kwargs):
        super().__init__(_concurrency_mode=_concurrency_mode, **kwargs)
        self.suffix = suffix
        self.input_key = input_key

    def forward(self, data, **kwargs):
        assert isinstance(data, dict)
        data[self.input_key] = f'{data.get(self.input_key, "")}{self.suffix}'
        return data

@data_register('data.demo2', rewrite_func='forward', _concurrency_mode='process')
def rich_content(data, input_key='content'):
    """Split a single input into multiple outputs (original + derived parts). Implemented as a forward that returns a list.

Args:
    data (dict): single data dict
    input_key (str): key name of the text field


Examples:
    ```python
    from lazyllm.tools.data.operators.demo_ops import rich_content
    
    op = rich_content(input_key='text')
    print(op({'text': 'This is a test.'}))
    # [
    #   {'text': 'This is a test.'},
    #   {'text': 'This is a test. - part 1'},
    #   {'text': 'This is a test. - part 2'}
    # ]
    ```
    """
    assert isinstance(data, dict)
    content = data.get(input_key, '')
    new_res = [data]
    for i in range(2):
        new_data = data.copy()
        new_data[input_key] = f'{content} - part {i+1}'
        new_res.append(new_data)
    return new_res

@data_register('data.demo2', rewrite_func='forward')
def error_prone_op(data, input_key='content'):
    """A test operator that raises an exception for specific input (content == 'fail') and otherwise returns a processed dict.
Used to validate error collection and skipping behavior.

Args:
    data (dict): single data dict
    input_key (str): key name of the text field


Examples:
    ```python
    from lazyllm.tools.data.operators.demo_ops import error_prone_op
    
    op = error_prone_op(input_key='text', _save_data=True, _concurrency_mode='single')
    res = op([{'text': 'ok'}, {'text': 'fail'}, {'text': 'ok2'}])
    # valid results skip the failed item; error details written to error file
    ```
    """
    assert isinstance(data, dict)
    content = data.get(input_key, '')
    if content == 'fail':
        raise ValueError('Intentional error for testing.')
    data[input_key] = f'Processed: {content}'
    return data
