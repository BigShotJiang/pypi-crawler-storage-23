from __future__ import annotations

import logging
import re
import json
import base64
import os
import time
import math
import ipaddress
from typing import List, Dict, Any, Tuple
from urllib.parse import urlparse

from django.conf import settings
from django.utils.deprecation import MiddlewareMixin
from django.core.cache import cache
from django.http import HttpResponseForbidden, HttpResponse

# cryptography & argon2
from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
from cryptography.hazmat.primitives import hashes, hmac as crypto_hmac
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.exceptions import InvalidSignature
from argon2.low_level import hash_secret_raw, Type as Argon2Type


# ----------------------------
# Logger
# ----------------------------
logger = logging.getLogger("csrfdefense_crypto")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)


# ----------------------------
# Constantes / Configuración
# ----------------------------
STATE_CHANGING_METHODS = {"POST", "PUT", "PATCH", "DELETE"}

CSRF_HEADER_NAMES = ("HTTP_X_CSRFTOKEN", "HTTP_X_CSRF_TOKEN")
CSRF_COOKIE_NAME = getattr(settings, "CSRF_COOKIE_NAME", "csrftoken")
POST_FIELD_NAME = "csrfmiddlewaretoken"

# Señales (no “bloquean” solas; suman evidencia)
SUSPICIOUS_CT_PATTERNS = [
    re.compile(r"text/plain", re.I),
    re.compile(r"application/x-www-form-urlencoded", re.I),
    re.compile(r"multipart/form-data", re.I),
    re.compile(r"application/json", re.I),
    re.compile(r"text/html", re.I),
]

# Campos sensibles (para resumen / auditoría)
SENSITIVE_FIELDS = ["password", "csrfmiddlewaretoken", "token", "auth", "email", "username"]

# Mínimo de señales para considerar “ataque”
CSRF_DEFENSE_MIN_SIGNALS = getattr(settings, "CSRF_DEFENSE_MIN_SIGNALS", 1)

# En tu caso ya NO quieres “/api/” hardcodeado:
CSRF_DEFENSE_EXCLUDED_PREFIXES: List[str] = getattr(settings, "CSRF_DEFENSE_EXCLUDED_PREFIXES", [])
CSRF_DEFENSE_EXCLUDED_PATHS: List[str] = getattr(settings, "CSRF_DEFENSE_EXCLUDED_PATHS", [])
CSRF_DEFENSE_TRUSTED_IPS: List[str] = getattr(settings, "CSRF_DEFENSE_TRUSTED_IPS", [])
CSRF_DEFENSE_TRUSTED_PROXIES: List[str] = getattr(settings, "CSRF_DEFENSE_TRUSTED_PROXIES", [])

# Umbrales como SQLi/XSS (score normalizado)
CSRF_NORM_THRESHOLDS = {
    "HIGH": getattr(settings, "CSRF_DEFENSE_NORM_HIGH", 0.20),
    "MEDIUM": getattr(settings, "CSRF_DEFENSE_NORM_MED", 0.10),
    "LOW": getattr(settings, "CSRF_DEFENSE_NORM_LOW", 0.05),
}

# Probabilidad / saturación
SATURATION_C = getattr(settings, "CSRF_DEFENSE_SATURATION_C", 1.5)
SATURATION_ALPHA = getattr(settings, "CSRF_DEFENSE_SATURATION_ALPHA", 2.0)
PROB_LAMBDA = getattr(settings, "CSRF_DEFENSE_PROB_LAMBDA", 1.0)
P_ATTACK_BLOCK = getattr(settings, "CSRF_DEFENSE_P_ATTACK_BLOCK", 0.97)

# Counter + Backoff
CSRF_COUNTER_WINDOW = getattr(settings, "CSRF_DEFENSE_COUNTER_WINDOW", 60 * 5)
CSRF_COUNTER_THRESHOLD = getattr(settings, "CSRF_DEFENSE_COUNTER_THRESHOLD", 5)
CSRF_USE_CHALLENGE = getattr(settings, "CSRF_DEFENSE_USE_CHALLENGE", False)

CACHE_BLOCK_KEY_PREFIX = "csrf_block:"
CACHE_COUNTER_KEY_PREFIX = "csrf_count:"
DEFAULT_BACKOFF_LEVELS = getattr(
    settings,
    "CSRF_DEFENSE_BACKOFF_LEVELS",
    [0, 60 * 15, 60 * 60, 60 * 60 * 6, 60 * 60 * 24, 60 * 60 * 24 * 7],
)

# Payload heurístico (CSRF “mezclado” con XSS-like señales en body)
CSRF_PAYLOAD_PATTERNS: List[Tuple[re.Pattern, str, float]] = [
    (re.compile(r"<script[^>]*>.*?</script>", re.I | re.S), "Script tag en payload", 0.9),
    (re.compile(r"javascript\s*:", re.I), "URI javascript: en payload", 0.8),
    (re.compile(r"http[s]?://[^\s]+", re.I), "URL externa en payload", 0.7),

    (re.compile(r"\beval\s*\(", re.I), "eval() en payload", 1.0),
    (re.compile(r"\balert\s*\(", re.I), "alert() en payload (prueba)", 0.5),
    (re.compile(r"\bfetch\s*\(", re.I), "fetch() en payload", 0.7),
    (re.compile(r"\bXMLHttpRequest\b", re.I), "XHR en payload", 0.7),

    (re.compile(r"\bdocument\.cookie\b", re.I), "Acceso a cookie en payload", 0.9),
    (re.compile(r"\binnerHTML\s*=", re.I), "Manipulación DOM innerHTML", 0.8),

    (re.compile(r"&#x[0-9a-fA-F]+;|&#\d+;", re.I), "Entidades HTML en payload", 0.6),
    (re.compile(r"%3Cscript", re.I), "Script URL-encoded en payload", 0.8),
    (re.compile(r"\bon\w+\s*=", re.I), "Eventos on* en payload", 0.7),
]


# ----------------------------
# Crypto config (igual estilo a SQLi/XSS)
# ----------------------------
MASTER_KEY_B64 = getattr(settings, "CSRF_DEFENSE_MASTER_KEY", None)
if not MASTER_KEY_B64:
    MASTER_KEY = os.urandom(32)
else:
    try:
        MASTER_KEY = base64.b64decode(MASTER_KEY_B64)
    except Exception:
        MASTER_KEY = MASTER_KEY_B64.encode() if isinstance(MASTER_KEY_B64, str) else MASTER_KEY_B64

AEAD_CHOICE = getattr(settings, "CSRF_DEFENSE_AEAD", "AESGCM").upper()  # AESGCM o CHACHA20

ARGON2_CONFIG = getattr(settings, "CSRF_DEFENSE_ARGON2", {
    "time_cost": 2,
    "memory_cost": 65536,
    "parallelism": 1,
    "hash_len": 32,
    "type": Argon2Type.ID,
})

_HMAC_LABEL = getattr(settings, "CSRF_HMAC_LABEL", b"csrfdefense-hmac")
HMAC_LABEL: bytes = _HMAC_LABEL.encode() if isinstance(_HMAC_LABEL, str) else _HMAC_LABEL

_AEAD_LABEL = getattr(settings, "CSRF_AEAD_LABEL", b"csrfdefense-aead")
AEAD_LABEL: bytes = _AEAD_LABEL.encode() if isinstance(_AEAD_LABEL, str) else _AEAD_LABEL

HASH_CHOICE = getattr(settings, "CSRF_DEFENSE_HASH", "SHA256").upper()


# ----------------------------
# Helpers base64
# ----------------------------
def _b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


# ----------------------------
# Crypto: KDF / AEAD / HMAC / Hash
# ----------------------------
def derive_key(label: bytes, context: bytes = b"") -> bytes:
    salt = (label + context)[:16].ljust(16, b"\0")
    try:
        raw = hash_secret_raw(
            secret=MASTER_KEY if isinstance(MASTER_KEY, (bytes, bytearray)) else MASTER_KEY.encode(),
            salt=salt,
            time_cost=ARGON2_CONFIG["time_cost"],
            memory_cost=ARGON2_CONFIG["memory_cost"],
            parallelism=ARGON2_CONFIG["parallelism"],
            hash_len=ARGON2_CONFIG["hash_len"],
            type=ARGON2_CONFIG["type"],
        )
        hk = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=label + context)
        return hk.derive(raw)
    except Exception:
        hk = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=label + context)
        return hk.derive(MASTER_KEY if isinstance(MASTER_KEY, bytes) else MASTER_KEY.encode())


def aead_encrypt(plaintext: bytes, aad: bytes = b"", context: bytes = b"") -> Dict[str, bytes]:
    key = derive_key(AEAD_LABEL, context)
    nonce = os.urandom(12)
    if AEAD_CHOICE == "CHACHA20":
        aead = ChaCha20Poly1305(key)
        ct = aead.encrypt(nonce, plaintext, aad)
        return {"alg": "CHACHA20-POLY1305", "nonce": nonce, "ciphertext": ct}
    aead = AESGCM(key)
    ct = aead.encrypt(nonce, plaintext, aad)
    return {"alg": "AES-GCM", "nonce": nonce, "ciphertext": ct}


def compute_hmac(data: bytes, context: bytes = b"") -> bytes:
    key = derive_key(HMAC_LABEL, context)
    h = crypto_hmac.HMAC(key, hashes.SHA256())
    h.update(data)
    return h.finalize()


def verify_hmac(data: bytes, tag: bytes, context: bytes = b"") -> bool:
    key = derive_key(HMAC_LABEL, context)
    h = crypto_hmac.HMAC(key, hashes.SHA256())
    h.update(data)
    try:
        h.verify(tag)
        return True
    except InvalidSignature:
        return False


def compute_hash(data: bytes) -> str:
    if HASH_CHOICE == "SHA3":
        h = hashes.Hash(hashes.SHA3_256())
    else:
        h = hashes.Hash(hashes.SHA256())
    h.update(data)
    return _b64e(h.finalize())


# ----------------------------
# Probabilidad / saturación
# ----------------------------
def saturate_score(raw_score: float) -> float:
    try:
        x = float(raw_score)
        alpha = float(SATURATION_ALPHA)
        c = float(SATURATION_C)
        return 1.0 / (1.0 + math.exp(-alpha * (x - c)))
    except Exception:
        return 0.0


def weight_to_prob(w: float) -> float:
    try:
        lam = float(PROB_LAMBDA)
        q = 1.0 - math.exp(-max(float(w), 0.0) / lam)
        return min(max(q, 0.0), 0.999999)
    except Exception:
        return 0.0


# ----------------------------
# Fingerprint + bloqueo por cache
# ----------------------------
def get_attacker_fingerprint(request, payload_summary=None) -> str:
    ua = request.META.get("HTTP_USER_AGENT", "")
    accept = request.META.get("HTTP_ACCEPT", "")
    lang = request.META.get("HTTP_ACCEPT_LANGUAGE", "")
    path = request.path

    raw = json.dumps({
        "ua": ua[:200],
        "accept": accept[:100],
        "lang": lang[:50],
        "path": path,
        "payload": payload_summary[:3] if payload_summary else [],
    }, ensure_ascii=False)

    return compute_hash(raw.encode("utf-8"))


def is_fingerprint_blocked(fingerprint: str) -> bool:
    if not fingerprint:
        return False
    return bool(cache.get(f"csrf_block_fingerprint:{fingerprint}"))


def is_ip_blocked(ip: str) -> bool:
    if not ip:
        return False
    return bool(cache.get(f"{CACHE_BLOCK_KEY_PREFIX}{ip}"))


def cache_block_ip_with_backoff(ip: str, fingerprint: str = ""):
    if not ip:
        return 0, 0
    level_key = f"{CACHE_BLOCK_KEY_PREFIX}{ip}:level"
    level = cache.get(level_key, 0) or 0
    level = int(level) + 1
    cache.set(level_key, level, timeout=60 * 60 * 24 * 7)

    idx = min(level, len(DEFAULT_BACKOFF_LEVELS) - 1)
    timeout = DEFAULT_BACKOFF_LEVELS[idx]

    cache.set(f"{CACHE_BLOCK_KEY_PREFIX}{ip}", True, timeout=timeout)
    if fingerprint:
        cache.set(f"csrf_block_fingerprint:{fingerprint}", True, timeout=timeout)
    return level, timeout


def incr_ip_counter(ip: str) -> int:
    if not ip:
        return 0
    key = f"{CACHE_COUNTER_KEY_PREFIX}{ip}"
    current = cache.get(key, 0)
    try:
        current = int(current)
    except Exception:
        current = 0
    current += 1
    cache.set(key, current, timeout=CSRF_COUNTER_WINDOW)
    return current


# ----------------------------
# Registro cifrado de eventos (como SQLi/XSS)
# ----------------------------
def record_csrf_event(event: dict) -> None:
    try:
        ts = int(time.time())
        ctx = f"{event.get('ip','')}-{ts}".encode("utf-8")

        # cifrar payload si existe
        if "payload" in event and event["payload"]:
            try:
                enc = aead_encrypt(json.dumps(event["payload"], ensure_ascii=False).encode("utf-8"), context=ctx)
                htag = compute_hmac(enc["ciphertext"], context=ctx)

                event["_payload_encrypted"] = {
                    "alg": enc["alg"],
                    "nonce": _b64e(enc["nonce"]),
                    "ciphertext": _b64e(enc["ciphertext"]),
                    "hmac": _b64e(htag),
                }
                event.pop("payload", None)
            except Exception:
                # fallback: no dejar payload sensible completo
                event["payload"] = [{"field": "raw", "snippet": "<REDACTED>", "score": 0.0}]

        key = f"csrf_event:{ts}:{event.get('ip', '')}"
        cache.set(key, json.dumps(event, ensure_ascii=False), timeout=60 * 60 * 24)
    except Exception:
        logger.exception("record_csrf_event failed")


# ----------------------------
# Auxiliares CSRF
# ----------------------------
def _is_valid_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip)
        return True
    except Exception:
        return False


def _ip_in_trusted(ip_str: str) -> bool:
    if not ip_str:
        return False
    try:
        ip_obj = ipaddress.ip_address(ip_str)
    except Exception:
        return False
    for p in CSRF_DEFENSE_TRUSTED_PROXIES:
        try:
            if "/" in p:
                if ip_obj in ipaddress.ip_network(p, strict=False):
                    return True
            else:
                if ip_obj == ipaddress.ip_address(p):
                    return True
        except Exception:
            continue
    return False


def get_client_ip(request) -> str:
    """
    Similar a tu SQLi: respeta proxies confiables.
    Si no configuras CSRF_DEFENSE_TRUSTED_PROXIES, se comporta como "simple".
    """
    xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
    if xff:
        parts = [p.strip() for p in xff.split(",") if p.strip()]
        for ip_candidate in parts:
            if _is_valid_ip(ip_candidate) and not _ip_in_trusted(ip_candidate):
                return ip_candidate
        if parts:
            return parts[-1]

    xr = request.META.get("HTTP_X_REAL_IP", "")
    if xr and _is_valid_ip(xr) and not _ip_in_trusted(xr):
        return xr

    remote = request.META.get("REMOTE_ADDR", "")
    return remote or ""


def host_from_header(header_value: str) -> str | None:
    if not header_value:
        return None
    try:
        parsed = urlparse(header_value)
        if parsed.netloc:
            return parsed.netloc.split(":")[0]
        return header_value.split(":")[0]
    except Exception:
        return None


def origin_matches_host(request) -> bool:
    host_header = request.META.get("HTTP_HOST") or request.META.get("SERVER_NAME")
    if not host_header:
        return True
    host = host_header.split(":")[0]

    origin = request.META.get("HTTP_ORIGIN", "")
    referer = request.META.get("HTTP_REFERER", "")

    # Bloquea “orígenes” maliciosos obvios
    if any(re.search(r"(javascript:|<script|data:text/html)", h or "", re.I) for h in [origin, referer]):
        return False

    if origin_host := host_from_header(origin):
        return origin_host == host

    if referer_host := host_from_header(referer):
        return referer_host == host

    # Si no hay origin/referer (algunos clientes), no lo tomes como prueba definitiva
    return True


def has_csrf_token(request) -> bool:
    # headers
    for h in CSRF_HEADER_NAMES:
        if request.META.get(h):
            return True
    # cookie
    if request.COOKIES.get(CSRF_COOKIE_NAME):
        return True
    # form field
    try:
        if request.method == "POST" and hasattr(request, "POST"):
            if request.POST.get(POST_FIELD_NAME):
                return True
    except Exception:
        pass
    return False


def extract_payload_text(request) -> str:
    parts: List[str] = []
    try:
        body = request.body.decode("utf-8", errors="ignore")
        if body:
            parts.append(body)
    except Exception:
        pass

    qs = request.META.get("QUERY_STRING", "")
    if qs:
        parts.append(qs)

    parts.append(request.META.get("HTTP_USER_AGENT", ""))
    parts.append(request.META.get("HTTP_REFERER", ""))
    return " ".join([p for p in parts if p])


def analyze_payload(value: str) -> Tuple[float, List[Dict[str, Any]]]:
    """
    Devuelve (score, summary) con matches.
    """
    if not value:
        return 0.0, []
    score = 0.0
    summary: List[Dict[str, Any]] = []
    for patt, desc, weight in CSRF_PAYLOAD_PATTERNS:
        if patt.search(value):
            score += weight
            summary.append({"pattern": patt.pattern, "desc": desc, "weight": weight})
    return round(score, 3), summary


def analyze_headers(request) -> List[str]:
    issues: List[str] = []
    ua = request.META.get("HTTP_USER_AGENT", "")
    if re.search(r"(sqlmap|nikto|nmap|hydra|curl/|bot|crawler)", ua, re.I):
        issues.append("User-Agent sospechoso (posible automatización/bot)")
    accept_lang = request.META.get("HTTP_ACCEPT_LANGUAGE", "")
    if not accept_lang or len(accept_lang) < 2:
        issues.append("Accept-Language ausente o muy corto (posible bot)")
    return issues


# ----------------------------
# Middleware CSRF Defense (estilo SQLi/XSS)
# ----------------------------
class CSRFDefenseMiddleware(MiddlewareMixin):
    def process_request(self, request):
        # 0) Excluir por prefijos configurables (SIN asumir /api/)
        for prefix in CSRF_DEFENSE_EXCLUDED_PREFIXES:
            if request.path.startswith(prefix):
                return None

        # Excluir rutas específicas
        if any(request.path.startswith(p) for p in CSRF_DEFENSE_EXCLUDED_PATHS):
            return None

        client_ip = get_client_ip(request)
        if client_ip and client_ip in CSRF_DEFENSE_TRUSTED_IPS:
            return None

        method = (request.method or "").upper()
        if method not in STATE_CHANGING_METHODS:
            return None

        # 1) Bloqueo por fingerprint / IP (persistente)
        fp0 = get_attacker_fingerprint(request)
        if is_fingerprint_blocked(fp0):
            warning_message = (
                "Acceso denegado. Su fingerprint y actividades han sido registradas y monitoreadas. "
                "Continuar con estos intentos podría resultar en bloqueos permanentes o acciones legales."
            )
            logger.warning(f"[CSRFBlock:Fingerprint] Fingerprint={fp0} IP={client_ip} - Intento persistente bloqueado.")
            return HttpResponseForbidden(warning_message)

        if is_ip_blocked(client_ip):
            warning_message = (
                "Acceso denegado. Su dirección IP y actividades han sido registradas y monitoreadas. "
                "Continuar con estos intentos podría resultar en bloqueos permanentes o acciones legales."
            )
            logger.warning(f"[CSRFBlock:IP] IP={client_ip} - Intento persistente bloqueado.")
            return HttpResponseForbidden(warning_message)

        # 2) Recolectar señales
        descripcion: List[str] = []

        # Señal A: falta token CSRF
        if not has_csrf_token(request):
            descripcion.append("Falta token CSRF en cookie/header/form")

        # Señal B: Origin/Referer no coinciden
        if not origin_matches_host(request):
            descripcion.append("Origin/Referer no coinciden con Host (posible cross-site)")

        # Señal C: Content-Type sospechoso
        content_type = (request.META.get("CONTENT_TYPE") or "")
        for patt in SUSPICIOUS_CT_PATTERNS:
            if patt.search(content_type):
                descripcion.append(f"Content-Type sospechoso: {content_type}")
                break

        # Señal D: Referer ausente y sin X-CSRFToken
        referer = request.META.get("HTTP_REFERER", "")
        if not referer and not any(request.META.get(h) for h in CSRF_HEADER_NAMES):
            descripcion.append("Referer ausente y sin X-CSRFToken")

        # Señal E: JSON desde origen externo (si hay origin)
        if "application/json" in content_type:
            origin = request.META.get("HTTP_ORIGIN") or ""
            host = (request.META.get("HTTP_HOST") or "").split(":")[0]
            if origin and host_from_header(origin) != host:
                descripcion.append("JSON request desde origen externo (posible CSRF)")

        # Señal F: headers “bot-like”
        descripcion.extend(analyze_headers(request))

        # 3) Análisis de payload (heurístico)
        payload_score = 0.0
        payload_summary: List[Dict[str, Any]] = []
        full_payload = extract_payload_text(request)

        try:
            # Form data
            if hasattr(request, "POST"):
                for key, value in request.POST.items():
                    if not isinstance(value, str):
                        continue
                    s, matches = analyze_payload(value)
                    payload_score += s
                    if s > 0:
                        payload_summary.append({
                            "field": key,
                            "snippet": value[:300],
                            "score": s,
                            "matches": matches[:6],
                            "sensitive": key.lower() in SENSITIVE_FIELDS,
                        })

            # JSON
            if "application/json" in content_type and request.body:
                data = json.loads(request.body.decode("utf-8") or "{}")
                if isinstance(data, dict):
                    for key, value in data.items():
                        if not isinstance(value, str):
                            continue
                        s, matches = analyze_payload(value)
                        payload_score += s
                        if s > 0:
                            payload_summary.append({
                                "field": key,
                                "snippet": value[:300],
                                "score": s,
                                "matches": matches[:6],
                                "sensitive": key.lower() in SENSITIVE_FIELDS,
                            })
        except Exception as e:
            logger.debug(f"[CSRFDefense] Error analizando payload: {e}")

        if payload_score > 0:
            descripcion.append(f"Payload sospechoso detectado (score_total={round(payload_score, 3)})")

        # Query string
        qs = request.META.get("QUERY_STRING", "")
        if qs:
            qs_s, qs_matches = analyze_payload(qs)
            if qs_s > 0:
                descripcion.append(f"Query string sospechosa (score={qs_s})")
                payload_score += qs_s
                payload_summary.append({
                    "field": "_query_string",
                    "snippet": qs[:300],
                    "score": qs_s,
                    "matches": qs_matches[:6],
                    "sensitive": False,
                })

        # 4) Si no hay señales suficientes, no marca nada
        total_signals = len(descripcion)
        if total_signals < CSRF_DEFENSE_MIN_SIGNALS:
            return None

        # 5) Score bruto / normalizado / prob
        w_csrf = float(getattr(settings, "CSRF_DEFENSE_WEIGHT", 0.2))
        score_raw = (w_csrf * float(total_signals)) + float(payload_score)
        s_norm = saturate_score(score_raw)
        p_attack = weight_to_prob(score_raw)

        url = request.build_absolute_uri() or f"{request.META.get('HTTP_HOST', 'unknown')}{request.path}"

        # fingerprint con payload (como SQLi/XSS)
        fingerprint = get_attacker_fingerprint(request, payload_summary)

        # 6) Adjuntar al request (lo que consume AuditoriaMiddleware)
        request.csrf_attack_info = {
            "ip": client_ip,
            "tipos": ["CSRF"],
            "descripcion": descripcion,
            "payload": (
                json.dumps(payload_summary, ensure_ascii=False)[:2000]
                if payload_summary else
                json.dumps({"full_payload": full_payload[:800]}, ensure_ascii=False)
            ),
            "score": round(score_raw, 3),
            "s_norm": round(s_norm, 3),
            "p_attack": round(p_attack, 3),
            "url": url,
            "fingerprint": fingerprint,
            "blocked": False,
            "action": "detect",
        }

        logger.warning(
            "[CSRFDetect] IP=%s URL=%s ScoreRaw=%.3f ScoreNorm=%.3f P_attack=%.3f Signals=%s",
            client_ip, url, score_raw, s_norm, p_attack, descripcion
        )

        # 7) Guardar evento cifrado en cache (auditoría)
        try:
            record_csrf_event({
                "ts": int(time.time()),
                "type": "CSRF",
                "ip": client_ip,
                "score_raw": score_raw,
                "score_norm": s_norm,
                "p_attack": p_attack,
                "desc": descripcion,
                "url": url,
                "payload": payload_summary,
                "fingerprint": fingerprint,
            })
        except Exception:
            logger.exception("[CSRFDefense] failed to record CSRF event")

        # 8) Políticas de bloqueo (igual estilo que tus otros detectores)
        # 8.1) Bloqueo por probabilidad
        if p_attack >= float(P_ATTACK_BLOCK):
            level, timeout = cache_block_ip_with_backoff(client_ip, fingerprint)
            logger.error(f"[CSRFBlock:P_attack] Fingerprint={fingerprint} IP={client_ip} P={p_attack:.3f} -> level={level} timeout={timeout}s")

            request.csrf_attack_info.update({
                "blocked": True,
                "action": "block_p_attack",
                "block_timeout": timeout,
                "block_level": level,
            })

            request.csrf_block = True
            request.csrf_block_response = HttpResponseForbidden("Request blocked by CSRF defense (probability)")
            return None

        # 8.2) Bloqueo por score normalizado alto
        if s_norm >= float(CSRF_NORM_THRESHOLDS["HIGH"]):
            level, timeout = cache_block_ip_with_backoff(client_ip, fingerprint)
            logger.error(f"[CSRFBlock] Fingerprint={fingerprint} IP={client_ip} ScoreRaw={score_raw:.3f} ScoreNorm={s_norm:.3f} URL={url}")

            request.csrf_attack_info.update({
                "blocked": True,
                "action": "block",
                "block_timeout": timeout,
                "block_level": level,
            })

            request.csrf_block = True
            request.csrf_block_response = HttpResponseForbidden("Request blocked by CSRF defense")
            return None

        # 8.3) Umbral medio: counter + opcional challenge
        if s_norm >= float(CSRF_NORM_THRESHOLDS["MEDIUM"]):
            count = incr_ip_counter(client_ip)
            request.csrf_attack_info.update({"blocked": False, "action": "alert", "counter": count})

            if count >= int(CSRF_COUNTER_THRESHOLD):
                level, timeout = cache_block_ip_with_backoff(client_ip, fingerprint)
                cache.set(f"{CACHE_COUNTER_KEY_PREFIX}{client_ip}", 0, timeout=CSRF_COUNTER_WINDOW)

                logger.error(f"[CSRFAutoBlock] Fingerprint={fingerprint} IP={client_ip} reached counter={count} -> blocking for {timeout}s")

                request.csrf_attack_info.update({
                    "blocked": True,
                    "action": "auto_block",
                    "block_timeout": timeout,
                    "block_level": level,
                })

                request.csrf_block = True
                request.csrf_block_response = HttpResponseForbidden("Request blocked by CSRF defense (auto block)")
                return None

            if bool(CSRF_USE_CHALLENGE):
                request.csrf_challenge = True
                request.csrf_challenge_response = HttpResponse("Challenge required", status=403)
                request.csrf_challenge_response["X-CSRF-Challenge"] = "captcha"
                return None

            return None

        # 8.4) Umbral bajo: monitoreo
        if s_norm >= float(CSRF_NORM_THRESHOLDS["LOW"]):
            request.csrf_attack_info.update({"blocked": False, "action": "monitor"})
            return None

        return None