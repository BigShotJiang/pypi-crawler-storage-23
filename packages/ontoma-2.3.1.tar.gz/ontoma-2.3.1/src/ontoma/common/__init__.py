"""Common logic to be reused across steps."""

from __future__ import annotations
