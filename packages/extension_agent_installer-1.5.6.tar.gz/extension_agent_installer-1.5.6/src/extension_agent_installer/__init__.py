"""Extension Agent Installer - Secure extension installer for AI coding agents."""

__version__ = "1.5.6"
