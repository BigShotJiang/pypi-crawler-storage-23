"""Test suite for ZIRAN."""
