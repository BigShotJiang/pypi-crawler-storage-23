"""Graph persistence storage."""
