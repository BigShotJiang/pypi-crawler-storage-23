"""
antaris-spark v1.0.1

Memory, safety, and context for Antaris Spark bots.
Tier: Spark -- up to 500 memories.

Packages:
    antaris_memory  -- BM25 + semantic search, audit logging, co-occurrence PPMI
    antaris_guard   -- Prompt safety screening and injection detection
    antaris_context -- Token budget management and context windowing

Install:
    pip install antaris-spark            # core
    pip install antaris-spark[semantic]  # + transformer embeddings
"""

__version__ = "1.0.5"

MEMORY_CAP = 500


def create_memory(workspace: str = ".", **kwargs):
    """Create a MemorySystem with Spark tier cap (500 entries)."""
    from antaris_memory import MemorySystem
    return MemorySystem(workspace, max_entries=MEMORY_CAP, **kwargs)


__all__ = ["__version__", "MEMORY_CAP", "create_memory"]
