"""Version information for `deepagents-cli`."""

__version__ = "0.0.23"  # x-release-please-version
