"""hatch-mojo build hook plugin."""

from hatch_mojo.plugin import MojoBuildHook

__all__ = ("MojoBuildHook",)
