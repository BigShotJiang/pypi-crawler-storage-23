from __future__ import annotations

import pytest

pytest_plugins = [
    "tests.backend_fixtures",
]
