# -*- coding: utf-8 -*-

__title__ = "gapipy"

__version__ = "2.42.0"

from .client import Client  # noqa
