from .base import BaseModel

class AgencyDocument(BaseModel):
    " Represents a document for an agency. "
    _as_is_fields = ['file', 'type']
