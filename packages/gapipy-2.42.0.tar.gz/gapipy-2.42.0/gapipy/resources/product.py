# Python 2 and 3
from __future__ import unicode_literals

from .base import Resource


class Product(Resource):
    """
    This is used to mark those resources that
    can be attached to a Promotion
    """
    pass
