=====
Usage
=====

To use G API Python Client in a project::

	import gapipy

**TODO: Configuration**
