"""
pytest-fkit: A pytest plugin that prevents crashes from killing your test suite
"""

__version__ = "0.9.4"
