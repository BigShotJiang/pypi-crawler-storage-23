// C++ standard library
#include <stdexcept>
#include <string>

// Third-party libraries
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>

// Project headers
#include "aligned_alloc64.hpp"
#include "blas_config.h"
#include "blas_int.h"
#include "math.hpp"

namespace py = pybind11;

py::array_t<double> solve_cholesky_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> K_in,
    py::array_t<double, py::array::c_style | py::array::forcecast> y_in, double regularize = 0.0) {
    py::buffer_info Kbuf = K_in.request(true);
    py::buffer_info ybuf = y_in.request();

    if (Kbuf.ndim != 2 || Kbuf.shape[0] != Kbuf.shape[1])
        throw std::runtime_error("K must be n x n.");
    if (ybuf.ndim != 1 || ybuf.shape[0] != Kbuf.shape[0])
        throw std::runtime_error("y must have length n.");

    const blas_int n = static_cast<blas_int>(Kbuf.shape[0]);
    auto *K = static_cast<double *>(Kbuf.ptr);
    const auto *y = static_cast<const double *>(ybuf.ptr);

    // 64-byte aligned buffer that NumPy will own
    const std::size_t n_size = static_cast<std::size_t>(n);
    double *alpha_ptr = aligned_alloc_64(n_size);

    // Compute directly into the aligned buffer
    kf::math::solve_cholesky(K, y, n, alpha_ptr, regularize);

    auto free_capsule =
        py::capsule(alpha_ptr, [](void *p) { aligned_free_64(static_cast<double *>(p)); });

    return py::array_t<double>({n}, {sizeof(double)}, alpha_ptr, free_capsule);
}

// Solve (K + l2*I) @ alpha = y where K is in RFP packed format (TRANSR='N', UPLO='U').
// Overwrites K_rfp with the Cholesky factor — caller must copy if preservation is needed.
// Always uses the convention produced by all kernelforge RFP kernels (TRANSR='N', UPLO='U').
static py::array_t<double> cho_solve_rfp_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> K_rfp_in,  // 1-D RFP
    py::array_t<double, py::array::c_style | py::array::forcecast> y_in,      // 1-D
    double l2 = 0.0) {
    auto Kbuf = K_rfp_in.request();  // factorization overwrites K_rfp in-place
    auto ybuf = y_in.request();

    if (Kbuf.ndim != 1 || ybuf.ndim != 1)
        throw std::runtime_error("K_rfp must be 1D RFP and y must be 1D");
    const blas_int n = static_cast<blas_int>(ybuf.shape[0]);
    const std::size_t n_size = static_cast<std::size_t>(n);
    const std::size_t need = n_size * (n_size + 1) / 2;
    if (static_cast<std::size_t>(Kbuf.shape[0]) != need)
        throw std::runtime_error("K_rfp length must be n*(n+1)/2");

    // Cast away const: the caller accepts that K_rfp is overwritten (documented).
    auto *K_rfp = static_cast<double *>(Kbuf.ptr);
    const auto *y = static_cast<const double *>(ybuf.ptr);

    double *alpha_ptr = aligned_alloc_64(n_size);
    if (!alpha_ptr)
        throw std::bad_alloc();

    kf::math::solve_cholesky_rfp(K_rfp, y, n, alpha_ptr, l2, 'U', 'N');

    auto cap = py::capsule(alpha_ptr, [](void *p) { aligned_free_64(p); });
    return py::array_t<double>({(py::ssize_t)n}, {(py::ssize_t)sizeof(double)}, alpha_ptr, cap);
}

// Helper to normalize flags (inline to avoid extra helpers)
static inline char norm_uplo(char u) {
    return (u == 'l' || u == 'L') ? 'L' : 'U';
}
static inline char norm_tr(char t) {
    return (t == 't' || t == 'T') ? 'T' : 'N';
}
static inline char swap_uplo(char u) {
    return (u == 'U') ? 'L' : 'U';
}

// Full (n×n, **C-order**) -> RFP (length n*(n+1)/2), no copy of A.
// We pass the raw C-order pointer straight to Fortran, but **swap UPLO**.
py::array_t<double> full_to_rfp_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> A_in, char uplo = 'L',
    char transr = 'N') {
    py::buffer_info Abuf = A_in.request();  // C-order; no copy
    if (Abuf.ndim != 2 || Abuf.shape[0] != Abuf.shape[1])
        throw std::runtime_error("A must be square (n x n).");

    uplo = norm_uplo(uplo);
    transr = norm_tr(transr);

    const blas_int n = static_cast<blas_int>(Abuf.shape[0]);
    const double *Arow = static_cast<const double *>(Abuf.ptr);

    // Output RFP buffer
    const std::size_t n_size = static_cast<std::size_t>(n);
    const std::size_t nt = n_size * (n_size + 1) / 2;
    double *ARF = aligned_alloc_64(nt);
    if (!ARF)
        throw std::bad_alloc();

    // Treat Arow as column-major A^T; swap UPLO so the intended triangle is used
    const blas_int lda = n;
    const blas_int info = kf::math::full_to_rfp(transr, swap_uplo(uplo), n, Arow, lda, ARF);
    if (info != 0) {
        aligned_free_64(ARF);
        throw std::runtime_error("dtrttf_ failed, info=" + std::to_string(info));
    }

    auto cap = py::capsule(ARF, [](void *p) { aligned_free_64(static_cast<double *>(p)); });
    return py::array_t<double>({(py::ssize_t)nt}, {(py::ssize_t)sizeof(double)}, ARF, cap);
}

// RFP (length n*(n+1)/2) -> Full (n×n, **C-order**), no extra copies.
// We let Fortran write into our buffer (interpreted as column-major),
// then **expose the same buffer as C-order**. Because the matrix is symmetric,
// the transpose view is identical, and swapping UPLO ensures the expected triangle is filled.
py::array_t<double> rfp_to_full_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> ARF_in, blas_int n,
    char uplo = 'L', char transr = 'N') {
    if (n <= 0)
        throw std::runtime_error("n must be > 0");
    py::buffer_info Rbuf = ARF_in.request();
    if (Rbuf.ndim != 1)
        throw std::runtime_error("ARF must be a 1-D array.");
    const std::size_t n_size = static_cast<std::size_t>(n);
    const std::size_t need = n_size * (n_size + 1) / 2;
    if (static_cast<std::size_t>(Rbuf.shape[0]) != need)
        throw std::runtime_error("ARF length must be n*(n+1)/2.");

    uplo = norm_uplo(uplo);
    transr = norm_tr(transr);

    const double *ARF = static_cast<const double *>(Rbuf.ptr);

    // Allocate full matrix buffer once; we will *return it as C-order*
    const std::size_t nn = n_size * n_size;
    double *A = aligned_alloc_64(nn);
    if (!A)
        throw std::bad_alloc();

    // Fortran writes treating A as column-major; swap UPLO to compensate
    const blas_int lda = n;
    const blas_int info = kf::math::rfp_to_full(transr, swap_uplo(uplo), n, ARF, A, lda);
    if (info != 0) {
        aligned_free_64(A);
        throw std::runtime_error("dtfttr_ failed, info=" + std::to_string(info));
    }

    // Expose as C-order (row-major) without copying
    auto cap = py::capsule(A, [](void *p) { aligned_free_64(static_cast<double *>(p)); });
    return py::array_t<double>(
        /* shape   */ {(py::ssize_t)n, (py::ssize_t)n},
        /* strides */ {(py::ssize_t)(sizeof(double) * n), (py::ssize_t)sizeof(double)},
        /* ptr     */ A,
        /* base    */ cap);
}

static py::array_t<double> solve_qr_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> A_in,
    py::array_t<double, py::array::c_style | py::array::forcecast> y_in) {
    py::buffer_info Abuf = A_in.request();
    py::buffer_info ybuf = y_in.request();

    if (Abuf.ndim != 2)
        throw std::runtime_error("A must be 2D (m x n).");
    if (ybuf.ndim != 1 || ybuf.shape[0] != Abuf.shape[0])
        throw std::runtime_error("y must be 1D with length m (rows of A).");

    const blas_int m = static_cast<blas_int>(Abuf.shape[0]);
    const blas_int n = static_cast<blas_int>(Abuf.shape[1]);
    const auto *A = static_cast<const double *>(Abuf.ptr);
    const auto *y = static_cast<const double *>(ybuf.ptr);

    const std::size_t n_sz = static_cast<std::size_t>(n);
    double *x_ptr = aligned_alloc_64(n_sz);
    if (!x_ptr) throw std::bad_alloc();

    kf::math::solve_qr(A, y, m, n, x_ptr);

    auto cap = py::capsule(x_ptr, [](void *p) { aligned_free_64(static_cast<double *>(p)); });
    return py::array_t<double>({(py::ssize_t)n}, {(py::ssize_t)sizeof(double)}, x_ptr, cap);
}

static py::array_t<double> solve_svd_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> A_in,
    py::array_t<double, py::array::c_style | py::array::forcecast> y_in,
    double rcond = 0.0) {
    py::buffer_info Abuf = A_in.request();
    py::buffer_info ybuf = y_in.request();

    if (Abuf.ndim != 2)
        throw std::runtime_error("A must be 2D (m x n).");
    if (ybuf.ndim != 1 || ybuf.shape[0] != Abuf.shape[0])
        throw std::runtime_error("y must be 1D with length m (rows of A).");

    const blas_int m = static_cast<blas_int>(Abuf.shape[0]);
    const blas_int n = static_cast<blas_int>(Abuf.shape[1]);
    const auto *A = static_cast<const double *>(Abuf.ptr);
    const auto *y = static_cast<const double *>(ybuf.ptr);

    const std::size_t n_sz = static_cast<std::size_t>(n);
    double *x_ptr = aligned_alloc_64(n_sz);
    if (!x_ptr) throw std::bad_alloc();

    kf::math::solve_svd(A, y, m, n, x_ptr, rcond);

    auto cap = py::capsule(x_ptr, [](void *p) { aligned_free_64(static_cast<double *>(p)); });
    return py::array_t<double>({(py::ssize_t)n}, {(py::ssize_t)sizeof(double)}, x_ptr, cap);
}

static double condition_number_ge_py(
    py::array_t<double, py::array::c_style | py::array::forcecast> A_in) {
    py::buffer_info Abuf = A_in.request();

    if (Abuf.ndim != 2 || Abuf.shape[0] != Abuf.shape[1])
        throw std::runtime_error("A must be square (n x n).");

    const blas_int n = static_cast<blas_int>(Abuf.shape[0]);
    const auto *A = static_cast<const double *>(Abuf.ptr);

    return kf::math::condition_number_ge(A, n);
}

std::string get_blas_info() {
#if defined(__APPLE__)
    const std::string backend = "Apple Accelerate";
#elif defined(KF_USE_MKL)
    const std::string backend = "Intel MKL";
#else
    const std::string backend = "OpenBLAS";
#endif
#ifdef KF_BLAS_ILP64
    return backend + " ILP64";
#else
    return backend + " LP64";
#endif
}

PYBIND11_MODULE(kernelmath, m) {
    m.doc() = "Mathematical utilities (Cholesky solvers, etc.)";
    m.def("solve_cholesky", &solve_cholesky_py, py::arg("K"), py::arg("y"),
          py::arg("regularize") = 0.0,
          "Solve Kx=y using Cholesky factorization.\n"
          "- K is overwritten with factorization\n"
          "- y is preserved\n"
          "- regularize is added to diagonal of K\n"
          "- alpha is returned");
    m.def("cho_solve_rfp", &cho_solve_rfp_py, py::arg("K_rfp"), py::arg("y"),
          py::arg("l2") = 0.0,
          "Solve (K + l2*I) @ alpha = y where K is in RFP packed format.\n"
          "K_rfp is overwritten with the Cholesky factor — pass K_rfp.copy() to preserve it.\n"
          "Uses TRANSR='N', UPLO='U' (the convention all kernelforge RFP kernels produce).\n"
          "l2: L2 regularization added to the diagonal before factorization (default 0.0).\n"
          "Returns alpha as a 1D numpy array of length n.");
    m.def("full_to_rfp", &full_to_rfp_py, py::arg("A"), py::arg("uplo") = 'U',
          py::arg("transr") = 'N',
          "Full (n×n, Fortran-order) -> RFP (1-D). No copies; A must be F-contiguous.");
    m.def("rfp_to_full", &rfp_to_full_py, py::arg("ARF"), py::arg("n"), py::arg("uplo") = 'U',
          py::arg("transr") = 'N',
          "RFP (1-D) -> Full (n×n, Fortran-order). No extra copies; returns F-contiguous.");
    m.def("solve_qr", &solve_qr_py, py::arg("A"), py::arg("y"),
          "Solve min||A@x - y||_2 (overdetermined) or min||x||_2 s.t. A@x=y (underdetermined).\n"
          "A is m×n, y is length m; returns x of length n.\n"
          "Uses DGELS (QR/LQ decomposition). A must have full rank.");
    m.def("solve_svd", &solve_svd_py, py::arg("A"), py::arg("y"), py::arg("rcond") = 0.0,
          "Same as solve_qr but uses DGELSD (divide-and-conquer SVD).\n"
          "Handles rank-deficient A: singular values < rcond*sigma_max are treated as zero.\n"
          "rcond=0.0 uses machine epsilon as threshold.");
    m.def("condition_number_ge", &condition_number_ge_py, py::arg("A"),
          "1-norm condition number of a square matrix A via LU factorization (DGETRF+DGECON).\n"
          "Works for any square matrix (not just symmetric/positive-definite).");
    m.def("get_blas_info", &get_blas_info,
          "Return a string identifying the BLAS backend and integer width, e.g. 'OpenBLAS ILP64'.");
}
