from pathlib import Path

from superform.core import iter_supported_files, iter_yaml_files, normalize_structured_file, normalize_yaml_file


def test_iter_yaml_files_filters_extensions(tmp_path: Path) -> None:
    (tmp_path / "a.yaml").write_text("a: 1\n", encoding="utf-8")
    (tmp_path / "b.yml").write_text("b: 2\n", encoding="utf-8")
    (tmp_path / "c.txt").write_text("x", encoding="utf-8")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "x.yaml").write_text("a: 1\n", encoding="utf-8")

    files = sorted(p.name for p in iter_yaml_files(tmp_path))
    assert files == ["a.yaml", "b.yml"]


def test_iter_supported_files_detects_multiple_formats(tmp_path: Path) -> None:
    (tmp_path / "a.yaml").write_text("a: 1\n", encoding="utf-8")
    (tmp_path / "b.json").write_text("{\"b\":2}", encoding="utf-8")
    (tmp_path / "c.xml").write_text("<c/>", encoding="utf-8")
    (tmp_path / "d.txt").write_text("x", encoding="utf-8")
    (tmp_path / "node_modules").mkdir()
    (tmp_path / "node_modules" / "skip.json").write_text("{\"x\":1}", encoding="utf-8")

    files = sorted(p.name for p in iter_supported_files(tmp_path))
    assert files == ["a.yaml", "b.json", "c.xml"]


def test_iter_supported_files_accepts_file_path(tmp_path: Path) -> None:
    p = tmp_path / "single.json"
    p.write_text("{\"a\":1}\n", encoding="utf-8")

    files = list(iter_supported_files(p))
    assert files == [p]


def test_normalize_yaml_file_autofixes(tmp_path: Path) -> None:
    p = tmp_path / "bad.yaml"
    p.write_text("name:   test\nitems:\n  - a\n  -  b", encoding="utf-8")

    result = normalize_yaml_file(p, check_only=False)
    assert result.error is None
    assert result.changed is True
    assert p.read_text(encoding="utf-8").endswith("\n")


def test_normalize_yaml_file_reports_parse_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.yaml"
    p.write_text("key: [1, 2\n", encoding="utf-8")

    result = normalize_yaml_file(p)
    assert result.error is not None
    assert result.changed is False


def test_normalize_yaml_file_recovers_leading_tabs(tmp_path: Path) -> None:
    p = tmp_path / "tabbed.yaml"
    p.write_text("root:\n\tchild: 1\n", encoding="utf-8")

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True
    assert p.read_text(encoding="utf-8") == "root:\n  child: 1\n"


def test_normalize_yaml_file_recovers_common_top_level_indent_error(tmp_path: Path) -> None:
    p = tmp_path / "storageClass.yaml"
    p.write_text(
        (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: ebs-sc\n"
            "provisioner: ebs.csi.aws.com\n"
            "volumeBindingMode: WaitForFirstConsumer\n"
            "allowVolumeExpansion: true\n"
            "     reclaimPolicy: Retain\n"
        ),
        encoding="utf-8",
    )

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True
    assert "reclaimPolicy: Retain\n" in p.read_text(encoding="utf-8")


def test_normalize_yaml_file_recovers_multi_line_weird_indents(tmp_path: Path) -> None:
    p = tmp_path / "storageClass.yaml"
    p.write_text(
        (
            "apiVersion: storage.k8s.io/v1\n"
            "kind: StorageClass\n"
            "metadata:\n"
            "  name: ebs-sc\n"
            "                    provisioner: ebs.csi.aws.com\n"
            "\n"
            "\n"
            "    volumeBindingMode: WaitForFirstConsumer\n"
            "allowVolumeExpansion: true\n"
            "                                                          reclaimPolicy: Retain\n"
        ),
        encoding="utf-8",
    )

    result = normalize_yaml_file(p)
    assert result.error is None
    assert result.changed is True

    fixed = p.read_text(encoding="utf-8")
    assert "provisioner: ebs.csi.aws.com\n" in fixed
    assert "volumeBindingMode: WaitForFirstConsumer\n" in fixed
    assert "reclaimPolicy: Retain\n" in fixed


def test_normalize_structured_file_formats_json(tmp_path: Path) -> None:
    p = tmp_path / "data.json"
    p.write_text("{\"name\":\"test\",\"items\":[1,2]}", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    assert result.file_type == "json"
    assert p.read_text(encoding="utf-8") == '{\n  "name": "test",\n  "items": [\n    1,\n    2\n  ]\n}\n'


def test_normalize_structured_file_reports_json_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.json"
    p.write_text("{\"x\": 1,}", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is not None
    assert "JSON parse error:" in result.error
    assert result.changed is False


def test_normalize_structured_file_formats_xml(tmp_path: Path) -> None:
    p = tmp_path / "data.xml"
    p.write_text("<root><item>1</item><item>2</item></root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is None
    assert result.changed is True
    assert result.file_type == "xml"
    assert p.read_text(encoding="utf-8") == "<root>\n  <item>1</item>\n  <item>2</item>\n</root>\n"


def test_normalize_structured_file_reports_xml_error(tmp_path: Path) -> None:
    p = tmp_path / "broken.xml"
    p.write_text("<root><a></root>", encoding="utf-8")

    result = normalize_structured_file(p)
    assert result.error is not None
    assert "XML parse error:" in result.error
    assert result.changed is False
