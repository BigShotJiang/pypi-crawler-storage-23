from __future__ import annotations

from dataclasses import dataclass
from io import StringIO
import json
from pathlib import Path
import re
from typing import Callable, Iterable
import xml.etree.ElementTree as ET

from ruamel.yaml import YAML
from ruamel.yaml.error import YAMLError


FILE_TYPE_BY_EXTENSION = {
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".xml": "xml",
    ".xsd": "xml",
    ".xsl": "xml",
    ".svg": "xml",
}
DEFAULT_EXTENSIONS = tuple(FILE_TYPE_BY_EXTENSION.keys())
YAML_EXTENSIONS = (".yaml", ".yml")
SKIP_DIRS = {".git", ".hg", ".svn", ".tox", ".venv", "venv", "node_modules", "dist", "build", "__pycache__"}
_MAPPING_KEY_RE = re.compile(r"^[A-Za-z0-9_.\"'/-]+\s*:")
_ERROR_LINE_RE = re.compile(r"line\s+(\d+),\s+column\s+\d+")


@dataclass(frozen=True)
class ScanResult:
    path: Path
    changed: bool
    error: str | None = None
    file_type: str = "unknown"


def _is_skipped_path(path: Path, root: Path) -> bool:
    rel_parts = path.relative_to(root).parts
    return any(part in SKIP_DIRS for part in rel_parts)


def detect_file_type(path: Path) -> str | None:
    return FILE_TYPE_BY_EXTENSION.get(path.suffix.lower())


def iter_supported_files(root: Path, extensions: tuple[str, ...] = DEFAULT_EXTENSIONS) -> Iterable[Path]:
    normalized_extensions = {ext.lower() for ext in extensions}

    if root.is_file():
        if root.suffix.lower() in normalized_extensions:
            yield root
        return

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if _is_skipped_path(path, root):
            continue
        if path.suffix.lower() in normalized_extensions:
            yield path


def iter_yaml_files(root: Path, extensions: tuple[str, ...] = YAML_EXTENSIONS) -> Iterable[Path]:
    yield from iter_supported_files(root, extensions=extensions)


def _build_yaml() -> YAML:
    yaml = YAML(typ="rt")
    yaml.preserve_quotes = True
    yaml.width = 100
    yaml.indent(mapping=2, sequence=2, offset=0)
    return yaml


def _opens_block(stripped_line: str) -> bool:
    # Simple YAML block opener: "key:" or "- key:" with no inline value.
    return bool(re.match(r"^(?:-\s+)?[A-Za-z0-9_.\"'/-]+\s*:\s*$", stripped_line))


def _recover_common_indent_errors(raw_text: str) -> str:
    lines = raw_text.splitlines(keepends=True)
    recovered: list[str] = []
    parent_indent = 0
    prev_significant = ""

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            recovered.append(line)
            continue

        indent = len(line) - len(line.lstrip(" "))
        content = line.lstrip(" ")

        # Recovery case: accidental indentation for a top-level mapping key
        # where previous significant line does not open a nested block.
        if (
            parent_indent == 0
            and indent > 0
            and not content.startswith("-")
            and _MAPPING_KEY_RE.match(content)
            and not _opens_block(prev_significant)
        ):
            line = content
            indent = 0

        recovered.append(line)
        if _opens_block(content.rstrip("\n")):
            parent_indent = indent + 2
        elif indent < parent_indent:
            parent_indent = indent
        prev_significant = content.rstrip("\n")

    return "".join(recovered)


def _extract_error_line(error_text: str) -> int | None:
    match = _ERROR_LINE_RE.search(error_text)
    if not match:
        return None
    return int(match.group(1))


def _line_ending(line: str) -> str:
    if line.endswith("\r\n"):
        return "\r\n"
    if line.endswith("\n"):
        return "\n"
    return ""


def _previous_significant(lines: list[str], idx: int) -> tuple[int, str] | None:
    for i in range(idx - 1, -1, -1):
        stripped = lines[i].strip()
        if stripped and not stripped.startswith("#"):
            return i, lines[i]
    return None


def _parse_docs(yaml: YAML, text: str):
    return list(yaml.load_all(text))


def _with_trailing_newline(text: str) -> str:
    if text and not text.endswith("\n"):
        return f"{text}\n"
    return text


def _replace_leading_tabs(raw_text: str, *, spaces_per_tab: int = 2) -> tuple[str, bool]:
    lines = raw_text.splitlines(keepends=True)
    converted: list[str] = []
    changed = False
    replacement = " " * spaces_per_tab

    for line in lines:
        idx = 0
        while idx < len(line) and line[idx] in {" ", "\t"}:
            idx += 1
        prefix = line[:idx]
        if "\t" in prefix:
            prefix = prefix.replace("\t", replacement)
            line = f"{prefix}{line[idx:]}"
            changed = True
        converted.append(line)

    return "".join(converted), changed


def _try_indent_recovery(yaml: YAML, raw_text: str) -> tuple[str | None, list | None]:
    lines = raw_text.splitlines(keepends=True)
    if not lines:
        return None, None

    current_text = raw_text
    best_lines = lines[:]
    seen = {current_text}

    for _ in range(40):
        try:
            docs = _parse_docs(yaml, current_text)
            return current_text, docs
        except YAMLError as exc:
            error_line = _extract_error_line(str(exc))
            if error_line is None or error_line < 1 or error_line > len(best_lines):
                return None, None

            idx = error_line - 1
            original_line = best_lines[idx]
            content = original_line.lstrip(" \t")
            if not content.strip() or content.lstrip().startswith("#"):
                return None, None

            prev = _previous_significant(best_lines, idx)
            if prev is None:
                prev_indent = 0
                prev_content = ""
            else:
                _, prev_line = prev
                prev_indent = len(prev_line) - len(prev_line.lstrip(" "))
                prev_content = prev_line.lstrip(" ").rstrip("\r\n")

            current_indent = len(original_line) - len(original_line.lstrip(" "))
            newline = _line_ending(original_line)
            content_no_newline = content.rstrip("\r\n")

            candidate_indents: list[int] = []
            candidate_indents.append(0)
            candidate_indents.append(prev_indent)
            if _opens_block(prev_content):
                candidate_indents.append(prev_indent + 2)
            candidate_indents.append(max(prev_indent - 2, 0))
            candidate_indents.append((current_indent // 2) * 2)
            candidate_indents.append(max(((current_indent - 2) // 2) * 2, 0))
            candidate_indents.append(min(((current_indent + 2) // 2) * 2, prev_indent + 4))

            deduped_indents: list[int] = []
            for indent in candidate_indents:
                indent = max(indent, 0)
                if indent not in deduped_indents:
                    deduped_indents.append(indent)

            progressed = False
            for indent in deduped_indents:
                candidate_line = (" " * indent) + content_no_newline + newline
                if candidate_line == original_line:
                    continue
                candidate_lines = best_lines[:]
                candidate_lines[idx] = candidate_line
                candidate_text = "".join(candidate_lines)
                if candidate_text in seen:
                    continue
                seen.add(candidate_text)

                try:
                    docs = _parse_docs(yaml, candidate_text)
                    return candidate_text, docs
                except YAMLError as candidate_exc:
                    next_error_line = _extract_error_line(str(candidate_exc))
                    if next_error_line is not None and next_error_line >= error_line:
                        best_lines = candidate_lines
                        current_text = candidate_text
                        progressed = True
                        break

            if not progressed:
                return None, None

    return None, None


def _normalize_yaml_text(raw_text: str) -> tuple[str, bool, str | None]:
    yaml = _build_yaml()
    recovered_text, had_tab_indentation = _replace_leading_tabs(raw_text)

    recovered_from_error = had_tab_indentation
    try:
        docs = _parse_docs(yaml, recovered_text)
    except YAMLError as exc:
        candidate = _recover_common_indent_errors(recovered_text)
        try:
            docs = _parse_docs(yaml, candidate)
            recovered_text = candidate
            recovered_from_error = True
        except YAMLError:
            recovered_candidate, recovered_docs = _try_indent_recovery(yaml, candidate)
            if recovered_candidate is None or recovered_docs is None:
                return "", False, str(exc).strip()
            recovered_text = recovered_candidate
            docs = recovered_docs
            recovered_from_error = True

    buffer = StringIO()
    yaml.dump_all(docs, buffer)
    fixed_text = _with_trailing_newline(buffer.getvalue())
    return fixed_text, recovered_from_error, None


def _normalize_json_text(raw_text: str) -> tuple[str, bool, str | None]:
    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        return "", False, f"JSON parse error: {exc.msg} (line {exc.lineno}, column {exc.colno})"

    fixed_text = json.dumps(parsed, indent=2, ensure_ascii=False)
    return _with_trailing_newline(fixed_text), False, None


def _normalize_xml_text(raw_text: str) -> tuple[str, bool, str | None]:
    try:
        parser = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
        root = ET.fromstring(raw_text, parser=parser)
    except ET.ParseError as exc:
        return "", False, f"XML parse error: {exc}"

    tree = ET.ElementTree(root)
    ET.indent(tree, space="  ")

    has_declaration = raw_text.lstrip().startswith("<?xml")
    buffer = StringIO()
    tree.write(buffer, encoding="unicode", xml_declaration=has_declaration)
    return _with_trailing_newline(buffer.getvalue()), False, None


_NORMALIZERS: dict[str, Callable[[str], tuple[str, bool, str | None]]] = {
    "yaml": _normalize_yaml_text,
    "json": _normalize_json_text,
    "xml": _normalize_xml_text,
}


def _normalize_file(path: Path, *, file_type: str, check_only: bool = False) -> ScanResult:
    try:
        raw_text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        return ScanResult(path=path, changed=False, error=f"Unicode decode error: {exc}", file_type=file_type)

    normalizer = _NORMALIZERS[file_type]
    fixed_text, forced_change, error = normalizer(raw_text)
    if error is not None:
        return ScanResult(path=path, changed=False, error=error, file_type=file_type)

    changed = fixed_text != raw_text or forced_change
    if changed and not check_only:
        path.write_text(fixed_text, encoding="utf-8")

    return ScanResult(path=path, changed=changed, error=None, file_type=file_type)


def normalize_structured_file(path: Path, *, check_only: bool = False) -> ScanResult:
    file_type = detect_file_type(path)
    if file_type is None:
        suffix = path.suffix.lower() or "(no extension)"
        return ScanResult(
            path=path,
            changed=False,
            error=f"Unsupported file extension: {suffix}",
            file_type="unsupported",
        )

    return _normalize_file(path, file_type=file_type, check_only=check_only)


def normalize_yaml_file(path: Path, *, check_only: bool = False) -> ScanResult:
    return _normalize_file(path, file_type="yaml", check_only=check_only)
