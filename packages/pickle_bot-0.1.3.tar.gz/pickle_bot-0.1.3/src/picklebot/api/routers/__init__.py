"""API routers for pickle-bot resources."""
