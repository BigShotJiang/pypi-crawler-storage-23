"""HTTP API module for pickle-bot."""

from picklebot.api.app import create_app

__all__ = ["create_app"]
