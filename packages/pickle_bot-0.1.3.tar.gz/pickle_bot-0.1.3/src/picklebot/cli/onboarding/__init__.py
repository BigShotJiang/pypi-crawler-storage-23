"""Onboarding wizard package."""

from picklebot.cli.onboarding.wizard import OnboardingWizard

__all__ = ["OnboardingWizard"]
