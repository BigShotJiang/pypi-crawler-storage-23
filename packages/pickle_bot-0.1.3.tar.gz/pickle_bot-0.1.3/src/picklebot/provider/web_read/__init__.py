"""Web read provider module."""

from .base import ReadResult, WebReadProvider

__all__ = ["ReadResult", "WebReadProvider"]
