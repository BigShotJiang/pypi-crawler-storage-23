"""Pickle-Bot: Personal AI Assistant with pluggable skills."""

__version__ = "0.1.0"
