"""Tests for the HTTP API module."""
