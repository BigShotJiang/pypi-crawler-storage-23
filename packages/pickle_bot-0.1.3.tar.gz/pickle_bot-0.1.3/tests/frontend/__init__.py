"""Tests for frontend implementations."""
