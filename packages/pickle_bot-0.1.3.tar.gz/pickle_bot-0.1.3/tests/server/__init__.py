"""Tests for server module."""
