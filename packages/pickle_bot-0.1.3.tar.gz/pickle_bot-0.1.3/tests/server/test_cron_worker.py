"""Tests for CronWorker."""

import pytest
from datetime import datetime
from unittest.mock import patch

from picklebot.server.cron_worker import CronWorker, find_due_jobs
from picklebot.core.cron_loader import CronDef
from picklebot.core.agent import SessionMode


def test_find_due_jobs_returns_matching():
    """find_due_jobs returns jobs matching current time."""
    jobs = [
        CronDef(
            id="test-job",
            name="Test",
            agent="pickle",
            schedule="*/5 * * * *",  # Every 5 minutes
            prompt="Test prompt",
        )
    ]

    # Use a time that matches */5 schedule (minute divisible by 5)
    now = datetime(2024, 6, 15, 12, 5)  # 12:05 matches */5
    due = find_due_jobs(jobs, now)
    assert len(due) == 1
    assert due[0].id == "test-job"


def test_find_due_jobs_empty_when_no_match():
    """find_due_jobs returns empty when no jobs match."""
    jobs = [
        CronDef(
            id="test-job",
            name="Test",
            agent="pickle",
            schedule="0 0 1 1 *",  # Jan 1 only
            prompt="Test prompt",
        )
    ]

    # Use a date that won't match
    now = datetime(2024, 6, 15, 12, 0)
    due = find_due_jobs(jobs, now)
    assert len(due) == 0


@pytest.mark.anyio
async def test_cron_worker_uses_context_queue(test_context):
    """CronWorker should get queue from context."""
    # Get the context's queue reference before creating worker
    context_queue = test_context.agent_queue

    worker = CronWorker(test_context)

    # Should not have its own agent_queue attribute, use context's
    assert not hasattr(worker, "agent_queue") or worker.agent_queue is context_queue


@pytest.mark.anyio
async def test_cron_worker_dispatches_due_job(test_context):
    """CronWorker dispatches due jobs to the queue."""
    worker = CronWorker(test_context)

    # Create a mock cron job that is due
    mock_cron = CronDef(
        id="test-cron",
        name="Test Cron",
        agent="pickle",
        schedule="*/5 * * * *",  # Every 5 minutes
        prompt="Test prompt from cron",
    )

    # Mock discover_crons to return our known cron job
    with patch.object(
        test_context.cron_loader, "discover_crons", return_value=[mock_cron]
    ):
        # Patch find_due_jobs to return our mock (ensures it's considered due)
        with patch(
            "picklebot.server.cron_worker.find_due_jobs", return_value=[mock_cron]
        ):
            await worker._tick()

    # Verify job was dispatched to queue
    assert not test_context.agent_queue.empty()
    job = test_context.agent_queue.get_nowait()
    assert job.session_id is None
    assert job.agent_id == "pickle"
    assert job.message == "Test prompt from cron"
    assert job.mode == SessionMode.JOB


@pytest.mark.anyio
@pytest.mark.parametrize(
    "one_off,should_delete",
    [
        (True, True),
        (False, False),
    ],
)
async def test_one_off_cron_deletion(test_context, one_off, should_delete):
    """CronWorker deletes one-off crons but keeps recurring crons."""
    worker = CronWorker(test_context)

    mock_cron = CronDef(
        id="test-cron",
        name="Test Cron",
        agent="pickle",
        schedule="*/5 * * * *",
        prompt="Test task",
        one_off=one_off,
    )

    with patch.object(
        test_context.cron_loader, "discover_crons", return_value=[mock_cron]
    ):
        with patch(
            "picklebot.server.cron_worker.find_due_jobs", return_value=[mock_cron]
        ):
            with patch("picklebot.server.cron_worker.shutil.rmtree") as mock_rmtree:
                await worker._tick()

    # Verify job was dispatched
    assert not test_context.agent_queue.empty()
    job = test_context.agent_queue.get_nowait()
    assert job.message == "Test task"

    # Verify deletion behavior
    expected_path = test_context.cron_loader.config.crons_path / "test-cron"
    if should_delete:
        mock_rmtree.assert_called_once_with(expected_path)
    else:
        mock_rmtree.assert_not_called()
