# lance-context-core

Pure Rust engine for the lance-context project. This crate is free of Python
dependencies and is re-exported by the `lance-context` wrapper crate.
