# lance-context

This crate is a light wrapper around `lance-context-core` that re-exports the public API for downstream Rust consumers and the Python bindings build. It carries no additional logic beyond the re-export.
