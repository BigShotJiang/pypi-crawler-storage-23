SUPPORTED_LANGS = ("en", "pt", "ru")


def normalize_plugin_lang_index(idx):
    try:
        i = int(idx)
    except Exception:
        i = 0
    if i < 0 or i >= len(SUPPORTED_LANGS):
        return 0
    return i


def get_plugin_lang_code(idx):
    return SUPPORTED_LANGS[normalize_plugin_lang_index(idx)]


def get_plugin_lang_index(plugin, key="plugin_lang", default=0):
    try:
        return normalize_plugin_lang_index(int(plugin.get_setting(key, default)))
    except Exception:
        return normalize_plugin_lang_index(default)
