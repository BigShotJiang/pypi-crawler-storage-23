def get_bio_feature_services(plugin):
    """Return (service_items, service_keys, default_idx) for Bio Features selector."""
    service_items = []
    try:
        has_spotify = (
            (bool(plugin.get_setting("client_id", "")) and bool(plugin.get_setting("client_secret", "")) and bool(plugin.get_setting("refresh_token", "")))
            or (bool(plugin.get_setting("quick_spotify_auth_enabled", False)) and bool(str(plugin.get_setting("quick_refresh_token", "") or "").strip()))
        )
        if has_spotify:
            service_items.append("Spotify")
        if bool(str(plugin.get_setting("statsfm_username", "") or "").strip()):
            service_items.append("Statsfm")
        if (
            bool(str(plugin.get_setting("lastfm_username", "") or "").strip())
            and bool(str(plugin.get_setting("lastfm_api_key", "") or "").strip())
        ):
            service_items.append("Lastfm")
    except Exception:
        pass
    service_keys = [("spotify" if x == "Spotify" else ("statsfm" if x == "Statsfm" else "lastfm")) for x in service_items]
    default_idx = 0
    try:
        if service_keys:
            default_idx = min(int(plugin.get_setting("bio_feature_service_idx", 0) or 0), len(service_keys) - 1)
    except Exception:
        default_idx = 0
    return service_items, service_keys, default_idx
