def clear_cache_data(plugin):
    try:
        for name in (
            "_image_cache",
            "_cache_timestamps",
            "_enhanced_image_cache",
            "_base_theme_cache",
            "_apple_cache",
            "_youtube_thumbnail_cache",
            "_soundcloud_thumbnail_cache",
            "_valid_thumbnail_url_cache",
        ):
            try:
                obj = getattr(plugin, name, None)
                if isinstance(obj, dict):
                    obj.clear()
            except Exception:
                pass
        return True
    except Exception:
        return False
