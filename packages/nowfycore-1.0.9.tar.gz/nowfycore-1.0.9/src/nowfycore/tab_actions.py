def _rt():
    try:
        import nowfy as nowfy_mod

        return nowfy_mod
    except Exception:
        return None


def _ui_info(msg):
    mod = _rt()
    if mod is None:
        return
    run_on_ui_thread = getattr(mod, "run_on_ui_thread", None)
    BulletinHelper = getattr(mod, "BulletinHelper", None)
    if not (callable(run_on_ui_thread) and BulletinHelper):
        return
    try:
        run_on_ui_thread(lambda: BulletinHelper.show_info(str(msg)))
    except Exception:
        pass


def _ui_success(msg):
    mod = _rt()
    if mod is None:
        return
    run_on_ui_thread = getattr(mod, "run_on_ui_thread", None)
    BulletinHelper = getattr(mod, "BulletinHelper", None)
    if not (callable(run_on_ui_thread) and BulletinHelper):
        return
    try:
        run_on_ui_thread(lambda: BulletinHelper.show_success(str(msg)))
    except Exception:
        pass


def _preview_get_spotify_info(plugin):
    try:
        import requests

        token = plugin._get_access_token(show_error_bulletin=False) if hasattr(plugin, "_get_access_token") else None
        if not token:
            return None
        resp = requests.get(
            "https://api.spotify.com/v1/me/player/currently-playing",
            headers={"Authorization": f"Bearer {token}"},
            timeout=8,
        )
        if resp.status_code != 200 or not resp.content:
            return None
        data = resp.json() if resp.content else {}
        item = data.get("item", {}) if isinstance(data, dict) else {}
        if not isinstance(item, dict):
            return None
        preview_url = str(item.get("preview_url") or "").strip()
        title = str(item.get("name") or "").strip()
        artist = ""
        try:
            artist = ", ".join([str((a or {}).get("name") or "").strip() for a in (item.get("artists") or []) if isinstance(a, dict)])
        except Exception:
            artist = ""
        if not preview_url:
            return None
        return {"preview_url": preview_url, "title": title, "artist": artist}
    except Exception:
        return None


def _preview_get_statsfm_info(plugin):
    try:
        import requests

        user = str(plugin.get_setting("statsfm_username", "") or "").strip().lstrip("@")
        if not user:
            return None
        resp = requests.get(f"https://api.stats.fm/api/v1/users/{user}/streams/current", timeout=8, headers={"User-Agent": "Nowfy/1.0"})
        if resp.status_code != 200 or not resp.content:
            return None
        data = resp.json() if resp.content else {}
        item = data.get("item", {}) if isinstance(data, dict) else {}
        track = item.get("track", {}) if isinstance(item, dict) else {}
        if not isinstance(track, dict):
            return None
        preview_url = str(
            track.get("preview_url")
            or track.get("previewUrl")
            or track.get("spotifyPreviewUrl")
            or ""
        ).strip()
        title = str(track.get("name") or track.get("title") or "").strip()
        artist = ""
        try:
            artists = track.get("artists", []) or []
            artist = ", ".join([str((a or {}).get("name") or "").strip() for a in artists if isinstance(a, dict)])
        except Exception:
            artist = ""
        if preview_url:
            return {"preview_url": preview_url, "title": title, "artist": artist}
        return None
    except Exception:
        return None


def _preview_download_audio(preview_url, title, artist):
    try:
        import os
        import re
        import time
        import requests
        import tempfile

        if not str(preview_url or "").strip():
            return None
        resp = requests.get(preview_url, timeout=15, headers={"User-Agent": "Nowfy/1.0"})
        if resp.status_code != 200 or not resp.content:
            return None
        safe_title = re.sub(r"[^\w\-\. ]+", "_", str(title or "preview")).strip() or "preview"
        safe_artist = re.sub(r"[^\w\-\. ]+", "_", str(artist or "")).strip()
        suffix = ".mp3"
        name = f"{safe_title}_{safe_artist}_{int(time.time()*1000)}{suffix}" if safe_artist else f"{safe_title}_{int(time.time()*1000)}{suffix}"
        p = os.path.join(tempfile.gettempdir(), name)
        with open(p, "wb") as f:
            f.write(resp.content)
        return p if os.path.isfile(p) else None
    except Exception:
        return None


def _preview_send_audio_to_chat(fp, title):
    try:
        import os
        import threading
        import time

        mod = _rt()
        if mod is None:
            return False
        get_last_fragment = getattr(mod, "get_last_fragment", None)
        send_audio = getattr(mod, "send_audio", None)
        parse_markdown = getattr(mod, "parse_markdown", None)
        if not (callable(get_last_fragment) and callable(send_audio) and callable(parse_markdown)):
            return False
        fragment = get_last_fragment()
        dialog_id = fragment.getDialogId() if fragment else 0
        if not dialog_id:
            return False
        safe_title = str(title or "").strip() or "Unknown Track"
        caption = f"Preview: {safe_title}\n*Powered by Nowfy*"
        parsed = parse_markdown(caption)
        entities = [x.to_tlrpc_object() for x in parsed.entities]
        send_audio(dialog_id, fp, caption=parsed.text, entities=entities)

        def _cleanup():
            try:
                time.sleep(120)
                if os.path.isfile(fp):
                    os.remove(fp)
            except Exception:
                pass

        threading.Thread(target=_cleanup, daemon=True).start()
        return True
    except Exception:
        return False


def send_tab_music_preview(plugin):
    try:
        _ui_success("Preparing preview...")
        source_key = "spotify"
        try:
            if hasattr(plugin, "_get_tab_source_options"):
                sources, _labels = plugin._get_tab_source_options()
                idx = int(plugin.get_setting("nowfy_tab_source", 0) or 0)
                if isinstance(sources, list) and sources:
                    if idx < 0 or idx >= len(sources):
                        idx = 0
                    source_key = str(sources[idx] or "spotify")
        except Exception:
            source_key = "spotify"

        preview_info = None
        if source_key == "statsfm":
            preview_info = _preview_get_statsfm_info(plugin)
        if preview_info is None:
            preview_info = _preview_get_spotify_info(plugin)
        if not preview_info or not preview_info.get("preview_url"):
            _ui_info("Preview unavailable.")
            return False
        local_audio = _preview_download_audio(preview_info.get("preview_url"), preview_info.get("title"), preview_info.get("artist"))
        if not local_audio:
            _ui_info("Could not download preview.")
            return False
        if _preview_send_audio_to_chat(local_audio, preview_info.get("title")):
            _ui_success("Preview sent.")
            return True
        _ui_info("Could not send preview.")
        return False
    except Exception:
        _ui_info("Could not send preview.")
        return False


def send_tab_track_download(plugin):
    try:
        import os
        import re
        import tempfile
        import time
        import threading

        mod = _rt()
        if mod is None:
            return False
        run_on_queue = getattr(mod, "run_on_queue", None)
        get_last_fragment = getattr(mod, "get_last_fragment", None)
        send_audio = getattr(mod, "send_audio", None)
        parse_markdown = getattr(mod, "parse_markdown", None)
        if not (callable(run_on_queue) and callable(get_last_fragment) and callable(send_audio) and callable(parse_markdown)):
            _ui_info("Track download unavailable.")
            return False

        def _get_track():
            try:
                import requests
                source_key = "spotify"
                try:
                    if hasattr(plugin, "_get_tab_source_options"):
                        sources, _labels = plugin._get_tab_source_options()
                        idx = int(plugin.get_setting("nowfy_tab_source", 0) or 0)
                        if isinstance(sources, list) and sources:
                            if idx < 0 or idx >= len(sources):
                                idx = 0
                            source_key = str(sources[idx] or "spotify")
                except Exception:
                    source_key = "spotify"

                if source_key == "spotify":
                    token = plugin._get_access_token(show_error_bulletin=False) if hasattr(plugin, "_get_access_token") else None
                    if not token:
                        return None
                    resp = requests.get(
                        "https://api.spotify.com/v1/me/player/currently-playing",
                        headers={"Authorization": f"Bearer {token}"},
                        timeout=8,
                    )
                    if resp.status_code != 200 or not resp.content:
                        return None
                    data = resp.json() if resp.content else {}
                    item = data.get("item", {}) if isinstance(data, dict) else {}
                    if not isinstance(item, dict):
                        return None
                    name = str(item.get("name") or "").strip()
                    artists = ", ".join([str((a or {}).get("name") or "").strip() for a in (item.get("artists") or []) if isinstance(a, dict)])
                    if name:
                        return {"title": name, "artist": artists}
                    return None

                if source_key == "lastfm":
                    user = str(plugin.get_setting("lastfm_user", plugin.get_setting("lastfm_username", "")) or "").strip()
                    api_key = str(plugin.get_setting("lastfm_api_key", "") or "").strip()
                    if not user or not api_key:
                        return None
                    resp = requests.get(
                        "https://ws.audioscrobbler.com/2.0/",
                        params={"method": "user.getrecenttracks", "user": user, "api_key": api_key, "format": "json", "limit": 1},
                        timeout=8,
                    )
                    if resp.status_code != 200 or not resp.content:
                        return None
                    js = resp.json() if resp.content else {}
                    tracks = js.get("recenttracks", {}).get("track", [])
                    if isinstance(tracks, dict):
                        tracks = [tracks]
                    if not isinstance(tracks, list) or not tracks:
                        return None
                    t = tracks[0] if isinstance(tracks[0], dict) else {}
                    title = str(t.get("name") or "").strip()
                    artist_obj = t.get("artist", {})
                    artist = str(artist_obj.get("#text") if isinstance(artist_obj, dict) else artist_obj or "").strip()
                    if title:
                        return {"title": title, "artist": artist}
                    return None

                if source_key == "statsfm":
                    user = str(plugin.get_setting("statsfm_username", "") or "").strip().lstrip("@")
                    if not user:
                        return None
                    resp = requests.get(
                        f"https://api.stats.fm/api/v1/users/{user}/streams/current",
                        timeout=8,
                        headers={"User-Agent": "Nowfy/1.0"},
                    )
                    if resp.status_code != 200 or not resp.content:
                        return None
                    data = resp.json() if resp.content else {}
                    item = data.get("item", {}) if isinstance(data, dict) else {}
                    track = item.get("track", {}) if isinstance(item, dict) else {}
                    title = str(track.get("name") or track.get("title") or "").strip()
                    artist = ""
                    try:
                        artists = track.get("artists", []) or []
                        artist = ", ".join([str((a or {}).get("name") or "").strip() for a in artists if isinstance(a, dict)])
                    except Exception:
                        artist = ""
                    if title:
                        return {"title": title, "artist": artist}
                    return None
            except Exception:
                return None
            return None

        def _safe_name(v, fallback="Track"):
            try:
                s = str(v or "").strip()
                if not s:
                    s = fallback
                return re.sub(r"[^\w\-\. ]+", "_", s).strip() or fallback
            except Exception:
                return fallback

        def _worker():
            try:
                try:
                    from yt_dlp import YoutubeDL
                except Exception:
                    _ui_info("yt-dlp is not installed.")
                    return

                track = _get_track()
                if not track:
                    _ui_info("No track playing.")
                    return
                title = str(track.get("title") or "").strip()
                artist = str(track.get("artist") or "").strip()
                query = f"{title} {artist}".strip()
                if not query:
                    _ui_info("No track playing.")
                    return
                _ui_success("Searching track...")

                out_dir = os.path.join(tempfile.gettempdir(), "nowfy_track_download")
                try:
                    os.makedirs(out_dir, exist_ok=True)
                except Exception:
                    pass
                outtmpl = os.path.join(out_dir, "%(title)s-%(id)s.%(ext)s")
                info = None
                with YoutubeDL(
                    {
                        "outtmpl": outtmpl,
                        "quiet": True,
                        "no_warnings": True,
                        "noplaylist": True,
                        "restrictfilenames": True,
                        "default_search": "ytsearch1",
                        "format": "bestaudio[ext=m4a]/bestaudio",
                    }
                ) as ydl:
                    info = ydl.extract_info(query, download=True)
                    if isinstance(info, dict) and info.get("entries"):
                        info = next((x for x in info.get("entries") if isinstance(x, dict)), info)

                fp = ""
                try:
                    req = info.get("requested_downloads") if isinstance(info, dict) else None
                    if isinstance(req, list) and req:
                        fp = str((req[0] or {}).get("filepath") or "").strip()
                except Exception:
                    fp = ""
                if (not fp) and isinstance(info, dict):
                    fp = str(info.get("_filename") or "").strip()
                if not fp or not os.path.isfile(fp):
                    _ui_info("Download failed.")
                    return

                final_name = f"{_safe_name(title)} - {_safe_name(artist, '')}".strip(" -")
                ext = os.path.splitext(fp)[1] or ".m4a"
                final_path = os.path.join(out_dir, f"{final_name}{ext}" if final_name else f"Track{ext}")
                try:
                    if final_path != fp:
                        if os.path.exists(final_path):
                            os.remove(final_path)
                        os.replace(fp, final_path)
                        fp = final_path
                except Exception:
                    pass

                fragment = get_last_fragment()
                dialog_id = fragment.getDialogId() if fragment else 0
                if not dialog_id:
                    _ui_info("Open a chat first.")
                    return
                caption = f"Downloaded: {title}\n*Powered by Nowfy*"
                parsed = parse_markdown(caption)
                entities = [x.to_tlrpc_object() for x in parsed.entities]
                send_audio(dialog_id, fp, caption=parsed.text, entities=entities)
                _ui_success("Track sent.")

                def _cleanup():
                    try:
                        time.sleep(180)
                        if os.path.isfile(fp):
                            os.remove(fp)
                    except Exception:
                        pass

                threading.Thread(target=_cleanup, daemon=True).start()
            except Exception:
                _ui_info("Track download failed.")

        run_on_queue(_worker)
        return True
    except Exception:
        _ui_info("Track download failed.")
        return False
