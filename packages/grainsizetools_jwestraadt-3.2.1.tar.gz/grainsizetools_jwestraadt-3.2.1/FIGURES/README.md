## Figures

This folder contains the images of the figures shown in the documentation and the Jupyter notebooks.

All images under a [CC-BY](https://creativecommons.org/licenses/by/2.0/) license unless otherwise indicated below.