# MIT License

--8<-- "LICENSE"
