"""PDF to PDF/A conversion library (supports 1b, 2b, 3b)."""

from .converter import Converter

__all__ = ["Converter", "__version__"]
__version__ = "3.1.0"
