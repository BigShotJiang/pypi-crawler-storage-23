import unittest
from pollyweb_pypi_core.core import hello

class TestCore(unittest.TestCase):
    def test_hello(self):
        self.assertEqual(hello(), "Hello from PollyWeb PyPI Core!")

if __name__ == "__main__":
    unittest.main()
