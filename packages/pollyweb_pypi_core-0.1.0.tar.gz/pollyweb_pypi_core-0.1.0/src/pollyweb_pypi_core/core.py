# Example core module

def hello():
    """Return a hello message from PollyWeb PyPI Core."""
    return "Hello from PollyWeb PyPI Core!"
