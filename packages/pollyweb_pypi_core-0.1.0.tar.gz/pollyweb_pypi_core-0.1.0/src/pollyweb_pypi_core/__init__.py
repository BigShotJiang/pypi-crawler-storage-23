# src/pollyweb_pypi_core/__init__.py

"""PollyWeb PyPI Core package initialization."""

__version__ = "0.1.0"
