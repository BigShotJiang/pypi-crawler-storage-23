from .config import ATTRS, COORDS, DIMS, VARS

__all__ = [
    "ATTRS",
    "DIMS",
    "COORDS",
    "VARS",
]
