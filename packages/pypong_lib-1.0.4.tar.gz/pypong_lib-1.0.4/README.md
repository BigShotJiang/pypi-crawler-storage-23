# 🏓 PyPong

The Pong library for Python. Build terminal Pong games quickly!

Born from [Console Pong](https://pypi.org/project/console-pong/). Stripped down.

## Install

```bash
pip install pypong
