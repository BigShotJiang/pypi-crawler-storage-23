"""
Views for the privacy app.
Handles GDPR compliance and data privacy functionality.
"""

import logging
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.http import HttpResponse
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from drf_spectacular.utils import OpenApiResponse, extend_schema
from rest_framework import status
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.throttling import UserRateThrottle
from rest_framework.views import APIView

# Import models from authentication and profiles apps
from nimoh_base.core.exceptions import ProblemDetailException

# Import serializers from this app
from .serializers import (
    GDPRConsentSerializer,
    GDPRDataCleanupSerializer,
    GDPRDataErasureSerializer,
    GDPRDataExportSerializer,
    GDPRDataRetentionSerializer,
    GDPRPrivacyDashboardSerializer,
)
from .services import GDPRService

# Import utilities from privacy app

# Import core utilities

logger = logging.getLogger(__name__)
User = get_user_model()


class GDPRDataExportView(APIView):
    """
    GDPR Article 20 - Right to Data Portability endpoint.

    Features:
    - Comprehensive data export
    - Multiple export formats
    - Privacy compliance
    - Audit logging
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_data_export",
        summary="GDPR Data Export",
        description="Export user data in compliance with GDPR Article 20 (Right to Data Portability)",
        request=GDPRDataExportSerializer,
        responses={
            200: OpenApiResponse(
                description="Data export file",
                examples={
                    "application/json": {
                        "status": "completed",
                        "export_id": "exp_123",
                        "download_url": "/downloads/export_123.zip",
                    }
                },
            ),
            400: OpenApiResponse(description="Invalid export request"),
            401: OpenApiResponse(description="Authentication required"),
            429: OpenApiResponse(description="Rate limit exceeded"),
        },
        tags=["GDPR Compliance"],
    )
    def post(self, request):
        """Request data export with privacy compliance."""
        serializer = GDPRDataExportSerializer(data=request.data, context={"request": request})

        if serializer.is_valid():
            validated_data = serializer.save()

            result = GDPRService.export_user_data(
                request.user,
                validated_data,
                request,
            )

            if result is None:
                raise ProblemDetailException(
                    detail=str(_("CSV export format not yet implemented.")),
                    code="not_implemented",
                    status_code=501,
                )

            if isinstance(result, HttpResponse):
                return result

            return Response(result, status=status.HTTP_200_OK)

        raise ValidationError(serializer.errors)


class GDPRDataErasureView(APIView):
    """
    GDPR Article 17 - Right to Erasure (Right to be Forgotten) endpoint.

    Features:
    - Account deletion with data anonymization
    - Comprehensive data cleanup
    - Audit trail preservation
    - Irreversible confirmation
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_data_erasure",
        summary="GDPR Data Erasure",
        description="Request account deletion in compliance with GDPR Article 17 (Right to Erasure)",
        request=GDPRDataErasureSerializer,
        responses={
            200: OpenApiResponse(
                description="Erasure request processed",
                examples={
                    "application/json": {
                        "status": "completed",
                        "erasure_id": "era_456",
                        "message": "Account deletion completed successfully",
                    }
                },
            ),
            400: OpenApiResponse(description="Invalid erasure request"),
            401: OpenApiResponse(description="Authentication required"),
            429: OpenApiResponse(description="Rate limit exceeded"),
        },
        tags=["GDPR Compliance"],
    )
    def post(self, request):
        """Process account deletion request."""
        serializer = GDPRDataErasureSerializer(data=request.data, context={"request": request})

        if serializer.is_valid():
            validated_data = serializer.save()
            result = GDPRService.erase_user_data(
                request.user,
                validated_data,
                request,
            )
            return Response(result)

        raise ValidationError(serializer.errors)


class GDPRConsentView(APIView):
    """
    GDPR Article 7 - Consent Management endpoint.

    Features:
    - Granular consent management
    - Consent withdrawal
    - Legal basis tracking
    - Consent history
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_consent_management",
        summary="GDPR Consent Management",
        description="Manage data processing consent in compliance with GDPR Article 7",
        request=GDPRConsentSerializer,
        responses={
            200: OpenApiResponse(
                description="Consent updated successfully",
                examples={
                    "application/json": {
                        "status": "updated",
                        "consent_type": "marketing",
                        "consent_status": True,
                        "effective_date": "2023-12-15T10:30:00Z",
                    }
                },
            ),
            400: OpenApiResponse(description="Invalid consent request"),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def post(self, request):
        """Update consent preferences."""
        serializer = GDPRConsentSerializer(data=request.data, context={"request": request})

        if serializer.is_valid():
            serializer.save()
            consent_type = serializer.validated_data["consent_type"]
            granted = serializer.validated_data["granted"]

            result = GDPRService.update_consent(
                request.user,
                consent_type,
                granted,
                request,
            )
            return Response(result)

        raise ValidationError(serializer.errors)

    @extend_schema(
        operation_id="gdpr_consent_status",
        summary="Get Consent Status",
        description="Retrieve current consent status for all data processing types",
        responses={
            200: OpenApiResponse(
                description="Current consent status",
                examples={
                    "application/json": {
                        "consent_status": {
                            "data_processing": True,
                            "marketing": False,
                            "analytics": True,
                            "third_party": False,
                            "cookies": True,
                            "profiling": False,
                        },
                        "last_updated": "2023-12-15T10:30:00Z",
                    }
                },
            ),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def get(self, request):
        """Get current consent status."""
        return Response(GDPRService.get_consent_status())


class GDPRPrivacyDashboardView(APIView):
    """
    GDPR Privacy Dashboard endpoint.

    Features:
    - Privacy settings overview
    - Data processing transparency
    - Rights exercise portal
    - Compliance status
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_privacy_dashboard",
        summary="GDPR Privacy Dashboard",
        description="Get comprehensive privacy dashboard with GDPR compliance information",
        responses={
            200: GDPRPrivacyDashboardSerializer,
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def get(self, request):
        """Get privacy dashboard data."""
        dashboard_data = GDPRService.get_privacy_dashboard(request.user)

        serializer = GDPRPrivacyDashboardSerializer(data=dashboard_data)
        serializer.is_valid()

        return Response(serializer.data)


class GDPRDataRetentionView(APIView):
    """
    GDPR Data Retention Policy endpoint.

    Features:
    - Data retention period management
    - Automatic cleanup configuration
    - Retention policy compliance
    - Data lifecycle transparency
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_data_retention",
        summary="GDPR Data Retention",
        description="Manage data retention policies and view retention information",
        request=GDPRDataRetentionSerializer,
        responses={
            200: OpenApiResponse(
                description="Retention policy updated",
                examples={
                    "application/json": {
                        "status": "updated",
                        "data_category": "profile_data",
                        "retention_period_months": 36,
                    }
                },
            ),
            400: OpenApiResponse(description="Invalid retention request"),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def post(self, request):
        """Update data retention preferences."""
        serializer = GDPRDataRetentionSerializer(data=request.data, context={"request": request})

        if serializer.is_valid():
            validated_data = serializer.save()

            return Response(
                {
                    "status": "updated",
                    "data_category": validated_data["data_category"],
                    "retention_period_months": validated_data["retention_period_months"],
                    "auto_cleanup_enabled": validated_data["auto_cleanup_enabled"],
                    "cleanup_notification": validated_data["cleanup_notification"],
                    "message": _("Data retention policy updated successfully."),
                }
            )

        raise ValidationError(serializer.errors)

    @extend_schema(
        operation_id="gdpr_retention_info",
        summary="Get Data Retention Info",
        description="Get current data retention policies and schedules",
        responses={
            200: OpenApiResponse(
                description="Current retention policies",
                examples={
                    "application/json": {
                        "retention_policies": {
                            "profile_data": 36,
                            "session_logs": 12,
                            "audit_logs": 84,
                            "communication_logs": 24,
                        },
                        "next_cleanup_dates": {
                            "session_logs": "2024-01-15T00:00:00Z",
                            "temporary_files": "2024-01-01T00:00:00Z",
                        },
                    }
                },
            ),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def get(self, request):
        """Get current retention policies."""
        # This would typically query retention policy models
        return Response(
            {
                "retention_policies": {
                    "profile_data": 36,  # months
                    "session_logs": 12,
                    "audit_logs": 84,
                    "communication_logs": 24,
                    "support_tickets": 24,
                    "analytics_data": 12,
                },
                "next_cleanup_dates": {
                    "session_logs": (timezone.now() + timedelta(days=30)).isoformat(),
                    "temporary_files": (timezone.now() + timedelta(days=7)).isoformat(),
                    "analytics_data": (timezone.now() + timedelta(days=90)).isoformat(),
                },
                "auto_cleanup_enabled": True,
            }
        )


class GDPRDataCleanupView(APIView):
    """
    GDPR automated data cleanup endpoint.

    Features:
    - Manual data cleanup requests
    - Retention policy enforcement
    - Anonymization procedures
    - Compliance verification
    """

    permission_classes = [IsAuthenticated]
    throttle_classes = [UserRateThrottle]

    @extend_schema(
        operation_id="gdpr_data_cleanup",
        summary="GDPR Data Cleanup",
        description="Request manual data cleanup or trigger automated cleanup",
        request=GDPRDataCleanupSerializer,
        responses={
            200: OpenApiResponse(
                description="Cleanup completed",
                examples={
                    "application/json": {
                        "status": "completed",
                        "cleanup_summary": {"expired_sessions": 15, "old_audit_logs": 0, "temporary_files": 8},
                    }
                },
            ),
            400: OpenApiResponse(description="Invalid cleanup request"),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def post(self, request):
        """Request manual data cleanup."""
        serializer = GDPRDataCleanupSerializer(data=request.data, context={"request": request})

        if serializer.is_valid():
            validated_data = serializer.save()
            result = GDPRService.cleanup_user_data(
                request.user,
                validated_data,
            )
            return Response(result)

        raise ValidationError(serializer.errors)

    @extend_schema(
        operation_id="gdpr_cleanup_status",
        summary="Get Cleanup Status",
        description="Get information about data that can be cleaned up",
        responses={
            200: OpenApiResponse(
                description="Cleanup status information",
                examples={
                    "application/json": {
                        "cleanup_available": {"expired_sessions": 15, "temporary_files": 8, "cached_data": 5},
                        "legal_hold_items": 0,
                        "last_cleanup": "2023-12-01T10:00:00Z",
                    }
                },
            ),
            401: OpenApiResponse(description="Authentication required"),
        },
        tags=["GDPR Compliance"],
    )
    def get(self, request):
        """Get cleanup status information."""
        return Response(GDPRService.get_cleanup_status(request.user))
