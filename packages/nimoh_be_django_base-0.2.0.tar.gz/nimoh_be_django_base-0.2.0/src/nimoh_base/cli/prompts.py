"""
nimoh_base.cli.prompts
======================
Interactive questionary-based prompts that collect project configuration.

Returns a ``ProjectConfig`` dataclass consumed by ``generators.py``.
"""

from __future__ import annotations

import re
import secrets
import string
from dataclasses import dataclass, field

# ── ProjectConfig ─────────────────────────────────────────────────────────────


@dataclass
class ProjectConfig:
    """Full configuration for a generated project."""

    # Identity
    project_name: str = ""  # "My Awesome API"
    project_slug: str = ""  # "my_awesome_api"  (directory + top-level pkg)
    description: str = ""
    author: str = ""
    author_email: str = ""

    # Django
    django_secret_key: str = field(default_factory=lambda: _gen_secret_key())
    site_name: str = ""  # NIMOH_BASE['SITE_NAME']
    support_email: str = ""  # NIMOH_BASE['SUPPORT_EMAIL']
    noreply_email: str = ""  # NIMOH_BASE['NOREPLY_EMAIL']
    cache_key_prefix: str = ""  # NIMOH_BASE['CACHE_KEY_PREFIX']
    celery_app_name: str = ""  # NIMOH_BASE['CELERY_APP_NAME']

    # Database
    db_engine: str = "postgresql"  # 'postgresql' | 'sqlite'
    db_name: str = ""
    db_user: str = ""
    db_password: str = "changeme"
    db_host: str = "localhost"
    db_port: int = 5432

    # Services
    redis_url: str = "redis://localhost:6379/0"
    frontend_url: str = "http://localhost:3000"

    # Feature toggles
    use_celery: bool = True
    use_channels: bool = True
    use_sendgrid: bool = False
    use_monitoring: bool = True
    use_privacy: bool = True

    # Output
    output_dir: str = "."  # where to write the project directory

    @property
    def package_name(self) -> str:
        """Python-importable dotted name (same as project_slug)."""
        return self.project_slug


def _gen_secret_key(length: int = 50) -> str:
    """Generate a Django SECRET_KEY-compatible random string."""
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*(-_=+)"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _slugify(text: str) -> str:
    """Convert a human name to a Python identifier slug."""
    slug = re.sub(r"[^\w\s-]", "", text.lower())
    slug = re.sub(r"[\s-]+", "_", slug).strip("_")
    return slug


# ── Interactive prompts ───────────────────────────────────────────────────────


def run_prompts(defaults: ProjectConfig | None = None) -> ProjectConfig:
    """
    Launch interactive questionary prompts and return a populated ``ProjectConfig``.

    Requires ``questionary`` and ``rich`` (installed via the ``cli`` extra).
    """
    try:
        import questionary
        from rich.console import Console
        from rich.panel import Panel
    except ImportError as exc:
        raise ImportError("CLI extras are required: pip install 'nimoh-be-django-base[cli]'") from exc

    d = defaults or ProjectConfig()
    console = Console()

    console.print(
        Panel.fit(
            "[bold cyan]nimoh-base init[/bold cyan]\nScaffold a new Django project powered by nimoh-be-django-base",
            border_style="cyan",
        )
    )
    console.print()

    cfg = ProjectConfig()

    # ── Identity ──────────────────────────────────────────────────────────────
    cfg.project_name = questionary.text(
        "Project name (human-readable):",
        default=d.project_name or "My Nimoh App",
    ).ask()

    auto_slug = _slugify(cfg.project_name)
    cfg.project_slug = questionary.text(
        "Python package slug (directory + import name):",
        default=d.project_slug or auto_slug,
    ).ask()

    if not cfg.project_slug or not cfg.project_slug.isidentifier():
        console.print("[red]Invalid slug — must be a valid Python identifier.[/red]")
        cfg.project_slug = auto_slug

    cfg.description = questionary.text(
        "Short description:",
        default=d.description or "",
    ).ask()

    cfg.author = questionary.text(
        "Author name:",
        default=d.author or "",
    ).ask()

    cfg.author_email = questionary.text(
        "Author email:",
        default=d.author_email or "",
    ).ask()

    # ── NIMOH_BASE ────────────────────────────────────────────────────────────
    console.print("\n[bold]NIMOH_BASE required settings[/bold]")

    cfg.site_name = questionary.text(
        "Site name (NIMOH_BASE['SITE_NAME']):",
        default=d.site_name or cfg.project_name,
    ).ask()

    cfg.support_email = questionary.text(
        "Support email (NIMOH_BASE['SUPPORT_EMAIL']):",
        default=d.support_email or f"support@{cfg.project_slug.replace('_', '')}.example",
    ).ask()

    cfg.noreply_email = questionary.text(
        "Noreply email (NIMOH_BASE['NOREPLY_EMAIL']):",
        default=d.noreply_email or f"noreply@{cfg.project_slug.replace('_', '')}.example",
    ).ask()

    cfg.cache_key_prefix = questionary.text(
        "Cache key prefix (NIMOH_BASE['CACHE_KEY_PREFIX']):",
        default=d.cache_key_prefix or cfg.project_slug[:8],
    ).ask()

    cfg.celery_app_name = questionary.text(
        "Celery app name (NIMOH_BASE['CELERY_APP_NAME']):",
        default=d.celery_app_name or cfg.project_slug,
    ).ask()

    # ── Database ──────────────────────────────────────────────────────────────
    console.print("\n[bold]Database[/bold]")

    cfg.db_engine = questionary.select(
        "Database engine:",
        choices=["postgresql", "sqlite"],
        default=d.db_engine or "postgresql",
    ).ask()

    if cfg.db_engine == "postgresql":
        cfg.db_name = questionary.text(
            "Database name:",
            default=d.db_name or cfg.project_slug,
        ).ask()
        cfg.db_user = questionary.text(
            "Database user:",
            default=d.db_user or cfg.project_slug,
        ).ask()
        cfg.db_password = (
            questionary.password(
                "Database password (stored in .env — safe to use a placeholder):",
            ).ask()
            or "changeme"
        )
        cfg.db_host = questionary.text(
            "Database host:",
            default=d.db_host or "localhost",
        ).ask()
        cfg.db_port = int(
            questionary.text(
                "Database port:",
                default=str(d.db_port or 5432),
            ).ask()
            or 5432
        )

    # ── Services ──────────────────────────────────────────────────────────────
    console.print("\n[bold]Services[/bold]")

    cfg.redis_url = questionary.text(
        "Redis URL:",
        default=d.redis_url or "redis://localhost:6379/0",
    ).ask()

    cfg.frontend_url = questionary.text(
        "Frontend URL (for CORS + password-reset links):",
        default=d.frontend_url or "http://localhost:3000",
    ).ask()

    # ── Feature toggles ───────────────────────────────────────────────────────
    console.print("\n[bold]Features (optional apps)[/bold]")

    cfg.use_celery = questionary.confirm(
        "Include Celery (background tasks)?",
        default=d.use_celery,
    ).ask()

    cfg.use_channels = questionary.confirm(
        "Include Django Channels (WebSockets)?",
        default=d.use_channels,
    ).ask()

    cfg.use_monitoring = questionary.confirm(
        "Include Monitoring app (performance metrics)?",
        default=d.use_monitoring,
    ).ask()

    cfg.use_privacy = questionary.confirm(
        "Include Privacy app (GDPR / consent)?",
        default=d.use_privacy,
    ).ask()

    cfg.use_sendgrid = questionary.confirm(
        "Use SendGrid for transactional email?",
        default=d.use_sendgrid,
    ).ask()

    # ── Output ────────────────────────────────────────────────────────────────
    cfg.output_dir = questionary.text(
        "Output directory:",
        default=d.output_dir or ".",
    ).ask()

    return cfg
