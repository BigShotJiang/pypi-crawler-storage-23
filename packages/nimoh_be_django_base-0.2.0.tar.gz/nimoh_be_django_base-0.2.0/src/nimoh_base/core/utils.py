"""
Core utility functions shared across the project.

This module provides common utilities to avoid code duplication.
"""

import ipaddress
import logging

from django.conf import settings
from django.http import HttpRequest

logger = logging.getLogger(__name__)

# RFC-1918 + loopback private ranges — always trusted as proxy origins.
_PRIVATE_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
]


def _is_trusted_proxy(remote_addr: str) -> bool:
    """
    Return True when *remote_addr* is allowed to set forwarding headers.

    Trusts:
    - Explicitly configured ``TRUSTED_PROXY_IPS`` list in Django settings.
    - Any RFC-1918 / loopback private address (Docker, local dev, internal LB).
    """
    trusted: list[str] = getattr(settings, "TRUSTED_PROXY_IPS", [])
    if remote_addr in trusted:
        return True
    try:
        addr = ipaddress.ip_address(remote_addr)
        return any(addr in net for net in _PRIVATE_NETWORKS)
    except ValueError:
        return False


def get_client_ip(request: HttpRequest) -> str:
    """
    Extract the real client IP, safely handling reverse-proxy forwarding headers.

    ``X-Forwarded-For`` and ``X-Real-IP`` are **only** trusted when the direct
    TCP connection (``REMOTE_ADDR``) originates from a trusted proxy — either an
    address in ``settings.TRUSTED_PROXY_IPS`` or a private RFC-1918 range.
    This prevents unauthenticated clients from spoofing their IP to bypass rate
    limiting by injecting a forged ``X-Forwarded-For`` header.

    Priority:
    1. First IP in ``X-Forwarded-For`` — if request comes from a trusted proxy.
    2. ``X-Real-IP`` — if request comes from a trusted proxy.
    3. ``REMOTE_ADDR`` — always used when the source is not a trusted proxy.

    Args:
        request: Django HTTP request object.

    Returns:
        Client IP address as a string, or empty string if unavailable.
    """
    remote_addr: str = request.META.get("REMOTE_ADDR", "")

    if _is_trusted_proxy(remote_addr):
        # Only honour forwarding headers from a known-trusted source.
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded_for:
            # The leftmost entry in X-Forwarded-For is the original client IP;
            # subsequent entries are added by each successive proxy.
            client_ip = x_forwarded_for.split(",")[0].strip()
            if client_ip:
                return client_ip

        x_real_ip = request.META.get("HTTP_X_REAL_IP")
        if x_real_ip:
            return x_real_ip.strip()

    return remote_addr
