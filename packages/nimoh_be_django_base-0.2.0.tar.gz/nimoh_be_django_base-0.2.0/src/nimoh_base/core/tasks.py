"""Core tasks."""

from celery import shared_task
from celery.utils.log import get_task_logger
from django.conf import settings
from django.core.mail import send_mail

logger = get_task_logger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=300)
def send_email_task(self, subject, message, recipient_list, from_email=None, **kwargs):
    """
    Send email asynchronously.

    This task is routed to the 'email' queue and rate-limited to 10/s.
    Retries up to 3 times with 5 minute delays on failure.

    Args:
        subject: Email subject line
        message: Email body (text)
        recipient_list: List of recipient email addresses
        from_email: Sender email (defaults to DEFAULT_FROM_EMAIL)
        **kwargs: Additional arguments for send_mail

    Returns:
        dict: Status and details of email send operation
    """
    try:
        from_email = from_email or settings.DEFAULT_FROM_EMAIL

        logger.info(
            f"Sending email to {len(recipient_list)} recipients: {subject}",
            extra={"recipients": recipient_list, "subject": subject},
        )

        sent_count = send_mail(
            subject=subject,
            message=message,
            from_email=from_email,
            recipient_list=recipient_list,
            fail_silently=False,
            **kwargs,
        )

        logger.info(
            f"Email sent successfully to {sent_count} recipients", extra={"subject": subject, "sent_count": sent_count}
        )

        return {
            "status": "success",
            "sent_count": sent_count,
            "recipients": recipient_list,
            "subject": subject,
        }

    except Exception as exc:
        logger.error(
            f"Email send failed: {exc}", extra={"subject": subject, "recipients": recipient_list}, exc_info=True
        )

        # Retry with exponential backoff
        raise self.retry(exc=exc, countdown=300 * (self.request.retries + 1))


@shared_task(bind=True, max_retries=2)
def cleanup_task(self):
    """
    General cleanup task that can be scheduled.

    This task is routed to the 'maintenance' queue with low priority.
    Useful for periodic cleanup operations.

    Returns:
        dict: Cleanup status and details
    """
    try:
        logger.info("Starting cleanup task")

        # Add your cleanup logic here
        # Examples:
        # - Clean up temporary files
        # - Remove old cache entries
        # - Archive old data

        result = {
            "status": "success",
            "message": "Cleanup completed successfully",
        }

        logger.info("Cleanup task completed")
        return result

    except Exception as exc:
        logger.error(f"Cleanup task failed: {exc}", exc_info=True)
        raise self.retry(exc=exc, countdown=600)


@shared_task(bind=True, max_retries=3)
def monitoring_task(self, metric_name, metric_value):
    """
    Task for sending monitoring metrics.

    This task is routed to the 'monitoring' queue.
    Rate-limited to 20 per minute.

    Args:
        metric_name: Name of the metric
        metric_value: Value to record

    Returns:
        dict: Metric recording status
    """
    try:
        logger.info(
            f"Recording metric: {metric_name} = {metric_value}",
            extra={"metric_name": metric_name, "metric_value": metric_value},
        )

        # Add your monitoring logic here
        # Examples:
        # - Send to StatsD
        # - Send to Prometheus
        # - Send to CloudWatch

        return {
            "status": "success",
            "metric_name": metric_name,
            "metric_value": metric_value,
        }

    except Exception as exc:
        logger.error(f"Monitoring task failed: {exc}", extra={"metric_name": metric_name}, exc_info=True)
        raise self.retry(exc=exc, countdown=60)
