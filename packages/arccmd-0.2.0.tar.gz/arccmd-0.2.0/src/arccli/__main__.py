"""Allow running as `python -m arccli`."""

from arccli.main import cli

cli()
