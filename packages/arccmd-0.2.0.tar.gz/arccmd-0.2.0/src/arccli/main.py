"""Root CLI group — `arc` command."""

import click

from arccli.agent import agent
from arccli.ext import ext
from arccli.init_wizard import init
from arccli.llm import llm
from arccli.run import run_group
from arccli.skill import skill
from arccli.team import team


@click.group()
def cli() -> None:
    """Arc — unified CLI for Arc products."""


cli.add_command(init)
cli.add_command(llm)
cli.add_command(agent)
cli.add_command(run_group)
cli.add_command(ext)
cli.add_command(skill)
cli.add_command(team)
