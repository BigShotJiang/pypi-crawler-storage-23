"""Version information for desto package."""

__version__ = "0.5.1"
