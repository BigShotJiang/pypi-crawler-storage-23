"""Systemd templates package."""
