owner = None

def newowner(a):
    global owner
    owner = a
    return owner

def showowner():
    if owner:
        print(owner)
    else:
        print("None")
def returnowner():
    if owner:
        return owner
    else:
        return None