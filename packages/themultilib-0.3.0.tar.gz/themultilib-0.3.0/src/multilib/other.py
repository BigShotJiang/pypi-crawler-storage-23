import os
import time

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def delay(a):
    time.sleep(a)

def printnoend(a):
    print(a, end="")
def mindelay(a):
    time.sleep(a/60)

def printloop(texto, vezes):
    for _ in range(vezes):
        print(texto)


def do(codigo):
    exec(codigo)  # cuidado ao usar exec


def writefile(nome_arquivo, conteudo):
    with open(nome_arquivo, "w", encoding="utf-8") as f:
        f.write(conteudo)


def iseven(numero):
    return numero % 2 == 0


def gameloop(prompt, sair_comando, comando_exec, codigo):
    while True:
        comando = input(prompt)
        if comando == sair_comando:
            break
        if comando == comando_exec:
            exec(codigo)  # cuidado ao usar exec


def isnumber(valor):
    return valor.isdigit()


def calc_average(lista):
    if len(lista) == 0:
        return 0
    return sum(lista) / len(lista)


def limitvalue(valor, minimo, maximo):
    return max(minimo, min(valor, maximo))


def countit(lista, item):
    return lista.count(item)


def thereisonlist(lista, item):
    return item in lista


def reverse_value(valor):
    return valor[::-1]


def complexpass(senha):
    return (
        len(senha) >= 8 and
        any(c.isupper() for c in senha) and
        any(c.islower() for c in senha) and
        any(c.isdigit() for c in senha)
    )


def maximum(lista):
    return max(lista)


def xp(valor, ganho):
    if isinstance(valor, (int, float)) and isinstance(ganho, (int, float)):
        return valor + ganho
    else:
        return "XP NOT FOUND"
def there_is(a):
    if a:
        return True
    else:
        return False
def meme67(a):
    for i in range(a):
        print("67," end="")
def helloworld():
    print("Hello, World!")