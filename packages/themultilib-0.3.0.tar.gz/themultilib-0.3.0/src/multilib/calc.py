def add(a, b):
    return a+b
def sub(a, b):
    return a-b
def multi(a, b):
    return a*b
def per(a, b):
    return a/b
def ctof(a):
    return a*9/5+32
def ftoc(a):
    return (a-32)*5/9
def ctok(a):
    return a-273.15
def ktoc(a):
    return a+273.15 