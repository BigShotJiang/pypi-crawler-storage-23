import glfw
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import time

WIDTH = 800
HEIGHT = 600

if not glfw.init():
    raise Exception("GLFW não iniciou")

window = glfw.create_window(WIDTH, HEIGHT, "3D RAIZ", None, None)
glfw.make_context_current(window)

glEnable(GL_DEPTH_TEST)

def draw_cube():
    glBegin(GL_QUADS)

    # Frente
    glColor3f(1,0,0)
    glVertex3f(-1,-1, 1)
    glVertex3f( 1,-1, 1)
    glVertex3f( 1, 1, 1)
    glVertex3f(-1, 1, 1)

    # Trás
    glColor3f(0,1,0)
    glVertex3f(-1,-1,-1)
    glVertex3f(-1, 1,-1)
    glVertex3f( 1, 1,-1)
    glVertex3f( 1,-1,-1)

    # Esquerda
    glColor3f(0,0,1)
    glVertex3f(-1,-1,-1)
    glVertex3f(-1,-1, 1)
    glVertex3f(-1, 1, 1)
    glVertex3f(-1, 1,-1)

    # Direita
    glColor3f(1,1,0)
    glVertex3f(1,-1,-1)
    glVertex3f(1, 1,-1)
    glVertex3f(1, 1, 1)
    glVertex3f(1,-1, 1)

    # Topo
    glColor3f(1,0,1)
    glVertex3f(-1,1,-1)
    glVertex3f(-1,1, 1)
    glVertex3f( 1,1, 1)
    glVertex3f( 1,1,-1)

    # Base
    glColor3f(0,1,1)
    glVertex3f(-1,-1,-1)
    glVertex3f( 1,-1,-1)
    glVertex3f( 1,-1, 1)
    glVertex3f(-1,-1, 1)

    glEnd()

angle = 0

while not glfw.window_should_close(window):

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(45, WIDTH/HEIGHT, 0.1, 50.0)

    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    glTranslatef(0, 0, -5)

    angle += 0.5
    glRotatef(angle, 1, 1, 0)

    draw_cube()

    glfw.swap_buffers(window)
    glfw.poll_events()

glfw.terminate()