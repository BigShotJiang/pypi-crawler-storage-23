from importlib.metadata import version, PackageNotFoundError

from .other import (
    clear,
    printloop,
    do,
    writefile,
    iseven,
    gameloop,
    isnumber,
    calc_average,
    limitvalue,
    countit,
    there_is,
    reverse_value,
    complexpass,
    maximum,
    xp,
    thereisonlist,
    mindelay,
    delay,
    printnoend,
    helloworld,
    meme67,
)

from .calc import add, sub, multi, per, ctof, ftoc, ctok, ktoc
from .owner import newowner, showowner, returnowner

try:
    __version__ = version("themultilib")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "clear",
    "printloop",
    "do",
    "writefile",
    "iseven",
    "gameloop",
    "isnumber",
    "calc_average",
    "limitvalue",
    "countit",
    "there_is",
    "reverse_value",
    "complexpass",
    "maximum",
    "xp",
    "add",
    "sub",
    "multi",
    "per",
    "ctof",
    "ftoc",
    "ctok",
    "ktoc",
    "newowner",
    "showowner",
    "returnowner",
    "thereisonlist",
]