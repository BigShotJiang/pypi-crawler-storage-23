Hi! Welcome to TheMultiLib!
This is a lib that thare are multiplie use functions like:
printloop
add
gameloop
do
xp
reverse_list
countit
clear
is_number
calc_avarage
& more!