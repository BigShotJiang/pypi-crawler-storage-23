"""Allow running as: python -m mcp_fw.menubar"""

from mcp_fw.menubar.app import main

main()
