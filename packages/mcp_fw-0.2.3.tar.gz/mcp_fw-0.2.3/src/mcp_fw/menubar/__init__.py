"""mcp-fw menubar application."""

from mcp_fw.menubar.app import main

__all__ = ["main"]
