from mcp_fw.cli import main

main()
