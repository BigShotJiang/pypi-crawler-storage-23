"""Graphing module for interactively building form graph.json files."""

from .bridge import preview_data_row_template, preview_instruction_skeleton
from .conditionals import add_conditional, detect_conditional
from .graph_builder import (
    add_page,
    create_graph,
    import_from_discovery,
    register_field,
    set_next_action,
    set_value_range,
)
from .models import (
    CheckboxValueRange,
    ClickSelectValueRange,
    ComboboxValueRange,
    ConditionalEffect,
    ConditionalOperator,
    ConditionalRule,
    DateValueRange,
    DropdownValueRange,
    FieldNode,
    FormGraph,
    GraphMetadata,
    NumericValueRange,
    OptionItem,
    PageNode,
    RadioValueRange,
    SliderValueRange,
    TextValueRange,
    ValueRange,
)
from .persistence import load_graph, save_graph
from .snapshot_parser import (
    extract_dropdown_options,
    extract_radio_options,
    extract_visible_fields,
)
from .validation import get_coverage_report, validate_graph

__all__ = [
    # Models
    "CheckboxValueRange",
    "ClickSelectValueRange",
    "ComboboxValueRange",
    "ConditionalEffect",
    "ConditionalOperator",
    "ConditionalRule",
    "DateValueRange",
    "DropdownValueRange",
    "FieldNode",
    "FormGraph",
    "GraphMetadata",
    "NumericValueRange",
    "OptionItem",
    "PageNode",
    "RadioValueRange",
    "SliderValueRange",
    "TextValueRange",
    "ValueRange",
    # Conditionals
    "add_conditional",
    # Graph builder
    "add_page",
    "create_graph",
    "detect_conditional",
    # Snapshot parser
    "extract_dropdown_options",
    "extract_radio_options",
    "extract_visible_fields",
    # Validation
    "get_coverage_report",
    "import_from_discovery",
    # Persistence
    "load_graph",
    # Bridge
    "preview_data_row_template",
    "preview_instruction_skeleton",
    "register_field",
    "save_graph",
    "set_next_action",
    "set_value_range",
    "validate_graph",
]
