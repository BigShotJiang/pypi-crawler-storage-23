"""Notebook runner via Papermill with ZebraOps parameter contract."""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

import papermill as pm

from zebraops.utils.io import ensure_dir


def run_notebook_training(
    model_name: str,
    notebook_path: Path,
    train_uri: str,
    valid_uri: str,
    output_dir: Path,
    tracking_uri: str,
    experiment_name: str,
) -> str:
    """Execute and parameterize notebook training run."""
    assert notebook_path.exists(), f"Notebook not found: {notebook_path}"
    run_id = str(uuid4())
    ensure_dir(output_dir)
    executed_path = output_dir / "executed_train.ipynb"
    pm.execute_notebook(
        str(notebook_path),
        str(executed_path),
        parameters={
            "model_name": model_name,
            "run_id": run_id,
            "output_dir": str(output_dir),
            "train_uri": train_uri,
            "valid_uri": valid_uri,
            "tracking_uri": tracking_uri,
            "experiment_name": experiment_name,
        },
    )
    return run_id
