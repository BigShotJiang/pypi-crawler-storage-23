"""Python script runner contract implementation for model training."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any
from uuid import uuid4

import yaml

from zebraops.utils.io import ensure_dir


def run_python_training(
    model_name: str,
    entrypoint: Path,
    train_uri: str,
    valid_uri: str,
    output_dir: Path,
    tracking_uri: str,
    experiment_name: str,
    extra_params: dict[str, Any] | None = None,
) -> str:
    """Execute model python entrypoint with ZebraOps contract variables."""
    assert entrypoint.exists(), f"Training entrypoint missing: {entrypoint}"
    run_id = str(uuid4())
    ensure_dir(output_dir)
    config_path = output_dir / "run_config.yaml"
    config_payload = {
        "model_name": model_name,
        "run_id": run_id,
        "output_dir": str(output_dir),
        "datasets": {"train": train_uri, "valid": valid_uri},
        "tracking_uri": tracking_uri,
        "experiment_name": experiment_name,
        "params": extra_params or {},
    }
    config_path.write_text(yaml.safe_dump(config_payload), encoding="utf-8")

    env = os.environ.copy()
    env.update(
        {
            "ZEBRA_MODEL_NAME": model_name,
            "ZEBRA_RUN_ID": run_id,
            "ZEBRA_OUTPUT_DIR": str(output_dir),
            "ZEBRA_DATASET_TRAIN_URI": train_uri,
            "ZEBRA_DATASET_VALID_URI": valid_uri,
            "MLFLOW_TRACKING_URI": tracking_uri,
            "MLFLOW_EXPERIMENT_NAME": experiment_name,
        }
    )
    cmd = [sys.executable, str(entrypoint), "--config", str(config_path)]
    proc = subprocess.run(cmd, env=env, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise RuntimeError(
            f"Training failed for {model_name}. stdout={proc.stdout}\nstderr={proc.stderr}"
        )
    return run_id
