"""Batch jobs for segment regressions and label/performance joins."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def segment_regression_report(events_path: Path) -> pd.DataFrame:
    """Build a simple event-type count table by model."""
    assert events_path.exists(), f"Events path not found: {events_path}"
    rows: list[dict[str, str]] = []
    for path in events_path.glob("**/*.json"):
        rows.append({"model_name": path.parent.name, "event_type": path.stem.split("_")[-1]})
    frame = pd.DataFrame(rows)
    if frame.empty:
        return frame
    return frame.groupby(["model_name", "event_type"]).size().reset_index(name="count")
