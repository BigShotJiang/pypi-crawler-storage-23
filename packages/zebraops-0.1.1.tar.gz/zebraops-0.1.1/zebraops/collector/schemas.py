"""Production feedback event schemas for v0.3 collector mode."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

EventType = Literal[
    "prediction_event",
    "data_quality_event",
    "drift_event",
    "label_event",
    "performance_event",
    "incident_event",
]


class CollectorEvent(BaseModel):
    """Normalized event payload for collector ingestion."""

    event_type: EventType
    model_name: str = Field(min_length=1)
    run_id: str | None = None
    timestamp: datetime
    payload: dict[str, Any]
