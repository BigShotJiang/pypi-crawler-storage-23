"""Collector API for production feedback events and recommendations."""

from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI

from zebraops.collector.schemas import CollectorEvent
from zebraops.utils.config import repo_path
from zebraops.utils.io import ensure_dir

app = FastAPI(title="ZebraOps Collector", version="0.3.0")


@app.post("/events")
def ingest_event(event: CollectorEvent) -> dict[str, str]:
    """Persist incoming event for downstream analysis jobs."""
    event_dir = ensure_dir(repo_path("artifacts", "collector_events", event.model_name))
    out_path = Path(event_dir) / f"{event.timestamp.isoformat()}_{event.event_type}.json"
    out_path.write_text(event.model_dump_json(indent=2), encoding="utf-8")
    return {"status": "stored", "path": str(out_path)}


@app.get("/recommendations/{model_name}")
def recommendations(model_name: str) -> dict[str, str]:
    """Return simplistic recommendation placeholder."""
    recommendation = {"model_name": model_name, "action": "retrain_if_recent_drift_event_present"}
    return json.loads(json.dumps(recommendation))
