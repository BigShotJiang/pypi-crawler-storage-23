"""Minimal RAG-style offline scorer example placeholder."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml


def main() -> None:
    """Write deterministic placeholder artifacts for RAG demo."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    output_dir = Path(cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "model.pkl").write_bytes(b"rag-placeholder")
    (output_dir / "metrics.json").write_text(json.dumps({"answer_relevance": 0.6}), encoding="utf-8")


if __name__ == "__main__":
    main()
