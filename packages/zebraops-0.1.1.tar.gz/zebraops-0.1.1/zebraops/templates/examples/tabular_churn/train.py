"""Tabular churn reference model for ZebraOps golden path."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
import yaml
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


def main() -> None:
    """Train logistic regression and write model/metrics artifacts."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    cfg_path = Path(args.config)
    cfg = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))
    train_df = pd.read_parquet(cfg["datasets"]["train"])
    valid_df = pd.read_parquet(cfg["datasets"]["valid"])
    assert "target" in train_df.columns, "Training data must include target column."
    assert "target" in valid_df.columns, "Validation data must include target column."

    x_train = train_df.drop(columns=["target"])
    y_train = train_df["target"]
    x_valid = valid_df.drop(columns=["target"])
    y_valid = valid_df["target"]

    model = LogisticRegression(max_iter=500)
    model.fit(x_train, y_train)
    preds = model.predict(x_valid)
    accuracy = float(accuracy_score(y_valid, preds))

    output_dir = Path(cfg["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.to_pickle(model, output_dir / "model.pkl")
    (output_dir / "metrics.json").write_text(json.dumps({"accuracy": accuracy}), encoding="utf-8")


if __name__ == "__main__":
    main()
