"""Bundled templates for project scaffolding."""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).resolve().parent


def template_path(*parts: str) -> Path:
    """Resolve path to a bundled template asset."""
    path = TEMPLATES_DIR.joinpath(*parts)
    assert path.exists(), f"Template asset missing: {path}"
    return path
