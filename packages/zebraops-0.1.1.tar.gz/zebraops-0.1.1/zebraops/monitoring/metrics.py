"""Prometheus metrics for serving and monitoring signals."""

from prometheus_client import Counter, Histogram

PREDICT_REQUESTS = Counter("zebraops_predict_requests_total", "Total prediction requests")
PREDICT_LATENCY = Histogram("zebraops_predict_latency_seconds", "Prediction latency in seconds")
DRIFT_RUNS = Counter("zebraops_drift_runs_total", "Total drift monitoring runs")
