"""Drift and quality checks with report generation."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def compute_simple_drift(reference_path: str, current_path: str) -> dict[str, float]:
    """Compute simple mean-shift drift score for numeric columns."""
    ref_df = pd.read_parquet(reference_path)
    cur_df = pd.read_parquet(current_path)
    numeric_cols = [c for c in ref_df.columns if c in cur_df.columns and ref_df[c].dtype.kind in "fi"]
    assert numeric_cols, "At least one numeric column is required for drift checks."

    shift = 0.0
    for col in numeric_cols:
        ref_mean = float(ref_df[col].mean())
        cur_mean = float(cur_df[col].mean())
        denom = max(abs(ref_mean), 1.0)
        shift += abs(cur_mean - ref_mean) / denom
    score = shift / len(numeric_cols)
    return {"drift_score": score, "numeric_columns": float(len(numeric_cols))}


def render_html_report(metrics: dict[str, float], out_path: Path) -> None:
    """Write a minimal HTML monitoring report."""
    content = f"""
    <html>
      <body>
        <h1>ZebraOps Drift Report</h1>
        <p>Drift score: {metrics['drift_score']:.4f}</p>
        <p>Numeric columns: {int(metrics['numeric_columns'])}</p>
      </body>
    </html>
    """
    out_path.write_text(content.strip(), encoding="utf-8")
