"""FastAPI serving app exposing predict, health, and model metadata endpoints."""

from __future__ import annotations

from time import perf_counter
from typing import Any

import pandas as pd
from fastapi import FastAPI, HTTPException
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from pydantic import BaseModel, Field
from starlette.responses import Response

from zebraops.monitoring.metrics import PREDICT_LATENCY, PREDICT_REQUESTS
from zebraops.serving.model_loader import load_model_by_alias

app = FastAPI(title="ZebraOps Serving", version="0.1.0")


class PredictRequest(BaseModel):
    """Prediction request payload."""

    model_name: str = Field(min_length=1)
    alias: str = "prod"
    rows: list[dict[str, Any]] = Field(min_length=1)


@app.get("/health")
def health() -> dict[str, str]:
    """Health endpoint for readiness checks."""
    return {"status": "ok"}


@app.get("/model")
def model_info(model_name: str, alias: str = "prod") -> dict[str, str]:
    """Expose selected model alias details."""
    return {"model_name": model_name, "alias": alias}


@app.post("/predict")
def predict(payload: PredictRequest) -> dict[str, Any]:
    """Run inference with the selected model alias."""
    start = perf_counter()
    try:
        model = load_model_by_alias(payload.model_name, payload.alias)
        df = pd.DataFrame(payload.rows)
        if hasattr(model, "predict"):
            raw_predictions = model.predict(df)
            predictions = raw_predictions.tolist() if hasattr(raw_predictions, "tolist") else list(raw_predictions)
        else:
            predictions = model.predict(df).values.tolist()  # pyfunc path
        return {"predictions": predictions}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    finally:
        PREDICT_REQUESTS.inc()
        PREDICT_LATENCY.observe(perf_counter() - start)


@app.get("/metrics")
def metrics() -> Response:
    """Prometheus metrics scrape endpoint."""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
