"""Model loading utilities for alias-based serving."""

from __future__ import annotations

from typing import Any

import mlflow.pyfunc
import pandas as pd

from zebraops.utils.config import repo_path


def load_model_by_alias(model_name: str, alias: str = "prod") -> Any:
    """Load a model from MLflow alias; fallback to local artifact for dev."""
    mlflow.pyfunc.get_model_dependencies  # touch import for type check stability
    model_uri = f"models:/{model_name}@{alias}"
    try:
        return mlflow.pyfunc.load_model(model_uri=model_uri, dst_path=None)
    except Exception:
        fallback = repo_path("artifacts", model_name, "latest", "model.pkl")
        assert fallback.exists(), f"Model alias unresolved and fallback missing: {fallback}"
        return pd.read_pickle(fallback)
