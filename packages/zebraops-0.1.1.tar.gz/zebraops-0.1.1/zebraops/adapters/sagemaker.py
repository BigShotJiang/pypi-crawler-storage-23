"""SageMaker adapter stub preserving ZebraOps training contract."""

from zebraops.adapters.base import TrainingAdapter, TrainingJobSpec


class SageMakerAdapter(TrainingAdapter):
    """Submit jobs to AWS SageMaker using provider SDK."""

    def submit(self, spec: TrainingJobSpec) -> str:
        if not spec.image:
            raise ValueError("Container image is required.")
        return f"sagemaker-{spec.model_name}-job"
