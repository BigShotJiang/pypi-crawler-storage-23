"""Vast adapter stub preserving ZebraOps training contract."""

from zebraops.adapters.base import TrainingAdapter, TrainingJobSpec


class VastAdapter(TrainingAdapter):
    """Submit jobs to Vast instances via external SSH automation."""

    def submit(self, spec: TrainingJobSpec) -> str:
        if not spec.model_name:
            raise ValueError("Model name is required.")
        return f"vast-{spec.model_name}-job"
