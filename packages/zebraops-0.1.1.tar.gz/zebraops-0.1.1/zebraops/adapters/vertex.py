"""Vertex adapter stub preserving ZebraOps training contract."""

from zebraops.adapters.base import TrainingAdapter, TrainingJobSpec


class VertexAdapter(TrainingAdapter):
    """Submit jobs to Google Vertex AI using provider SDK."""

    def submit(self, spec: TrainingJobSpec) -> str:
        if not spec.dataset_uri:
            raise ValueError("Dataset URI is required.")
        return f"vertex-{spec.model_name}-job"
