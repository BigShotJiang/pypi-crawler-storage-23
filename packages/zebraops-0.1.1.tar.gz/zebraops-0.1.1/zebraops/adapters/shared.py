"""Shared profile configuration adapter."""

from dataclasses import dataclass


@dataclass(frozen=True)
class SharedProfile:
    """Shared endpoint bundle for team deployments."""

    mlflow_tracking_uri: str
    prefect_api_url: str
    minio_endpoint: str
