"""Adapter abstractions for remote or cloud training profiles."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class TrainingJobSpec:
    """Portable training job contract for adapter implementations."""

    model_name: str
    image: str
    dataset_uri: str
    command: list[str]


class TrainingAdapter(Protocol):
    """Protocol for profile-specific training adapters."""

    def submit(self, spec: TrainingJobSpec) -> str:
        """Submit job and return provider-specific job id."""
