"""Promotion and rollback flows for MLflow model aliases."""

from __future__ import annotations

import mlflow
from prefect import flow

from zebraops.db import StateStore
from zebraops.flows.common import load_model, setup_mlflow
from zebraops.promotion import check_metric_gate, get_alias_version, set_alias
from zebraops.utils.config import get_endpoints


@flow(name="promote_flow")
def promote_flow(model_name: str, run_id: str, to_alias: str = "staging") -> dict[str, str]:
    """Promote run to staging/prod alias after gate checks."""
    assert to_alias in {"staging", "prod"}, "Alias must be staging or prod."
    model_spec = load_model(model_name)
    setup_mlflow(get_endpoints().mlflow_tracking_uri, model_spec.tracking.experiment_name)
    run = mlflow.get_run(run_id)

    for metric in model_spec.metrics:
        value = run.data.metrics.get(metric.name)
        if value is None:
            continue
        gate = check_metric_gate(metric, float(value))
        if not gate.passed:
            raise ValueError(f"Promotion blocked by gate: {gate.message}")

    model_uri = f"runs:/{run_id}/model"
    store = StateStore()
    store.init()
    try:
        registration = mlflow.register_model(model_uri=model_uri, name=model_name)
        set_alias(model_name, str(registration.version), to_alias)
        store.set_serving_pointer(model_name=model_name, alias=to_alias, run_id=run_id)
        return {"model_name": model_name, "alias": to_alias, "version": str(registration.version)}
    except Exception:
        # Local-file tracking may not support registry aliases; keep fallback pointer.
        store.set_serving_pointer(model_name=model_name, alias=to_alias, run_id=run_id)
        return {"model_name": model_name, "alias": to_alias, "version": "local-fallback"}


@flow(name="rollback_flow")
def rollback_flow(model_name: str, to_version: str, alias: str = "prod") -> dict[str, str]:
    """Rollback alias to a known version."""
    assert to_version.strip(), "Target version is required."
    store = StateStore()
    store.init()
    try:
        set_alias(model_name, to_version, alias)
    except Exception as exc:
        # Registry fallback is expected for file-backed local tracking.
        _ = str(exc)
    store.set_serving_pointer(model_name=model_name, alias=alias, run_id=to_version)
    return {"model_name": model_name, "alias": alias, "version": to_version}


@flow(name="inspect_alias_flow")
def inspect_alias_flow(model_name: str, alias: str = "prod") -> dict[str, str]:
    """Inspect current alias binding."""
    return {"model_name": model_name, "alias": alias, "version": get_alias_version(model_name, alias)}
