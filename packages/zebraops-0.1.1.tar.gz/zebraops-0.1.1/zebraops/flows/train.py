"""Training flow that executes configured runner and logs MLflow metadata."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

import mlflow
from prefect import flow

from zebraops.adapters.base import TrainingJobSpec
from zebraops.adapters.sagemaker import SageMakerAdapter
from zebraops.adapters.vast import VastAdapter
from zebraops.adapters.vertex import VertexAdapter
from zebraops.flows.common import (
    load_manifest_data,
    load_model,
    model_spec_path,
    run_output_dir,
    setup_mlflow,
)
from zebraops.runner import run_notebook_training, run_python_training
from zebraops.utils.config import get_endpoints
from zebraops.utils.io import ensure_dir


@flow(name="train_flow")
def train_flow(
    model_name: str,
    dataset_manifest_id: str,
    profile: str = "local",
    params: dict[str, Any] | None = None,
) -> dict[str, str]:
    """Run model training with validated contracts and tracking."""
    assert profile in {"local", "shared", "vast", "sagemaker", "vertex"}, "Unsupported profile."
    model = load_model(model_name)
    manifest = load_manifest_data(dataset_manifest_id)
    endpoints = get_endpoints()
    setup_mlflow(endpoints.mlflow_tracking_uri, model.tracking.experiment_name)

    train_uri = manifest["artifacts"]["uris"][0]
    valid_uri = manifest["artifacts"]["uris"][1]
    if profile in {"vast", "sagemaker", "vertex"}:
        spec = TrainingJobSpec(
            model_name=model_name,
            image=f"zebraops/{model_name}:latest",
            dataset_uri=train_uri,
            command=["mlops", "train", model_name, dataset_manifest_id, "--profile", profile],
        )
        adapter_map = {
            "vast": VastAdapter(),
            "sagemaker": SageMakerAdapter(),
            "vertex": VertexAdapter(),
        }
        job_id = adapter_map[profile].submit(spec)
        return {"remote_job_id": job_id, "profile": profile, "dataset_id": dataset_manifest_id}

    run_id = "pending"
    model_entrypoint_path = model_spec_path(model_name).parent / model.entrypoint

    with mlflow.start_run(run_name=f"{model_name}-{dataset_manifest_id}") as run:
        output_dir = run_output_dir(model_name, run.info.run_id)
        mlflow.log_params({"profile": profile, "dataset_id": dataset_manifest_id, **(params or {})})
        mlflow.set_tags({"zebra.model_name": model_name, "zebra.schema_version": model.schema_version})

        if model.type.value == "python":
            run_id = run_python_training(
                model_name=model_name,
                entrypoint=model_entrypoint_path,
                train_uri=train_uri,
                valid_uri=valid_uri,
                output_dir=output_dir,
                tracking_uri=endpoints.mlflow_tracking_uri,
                experiment_name=model.tracking.experiment_name,
                extra_params=params,
            )
        else:
            run_id = run_notebook_training(
                model_name=model_name,
                notebook_path=model_entrypoint_path,
                train_uri=train_uri,
                valid_uri=valid_uri,
                output_dir=output_dir,
                tracking_uri=endpoints.mlflow_tracking_uri,
                experiment_name=model.tracking.experiment_name,
            )

        mlflow.log_dict({"runner_run_id": run_id, "manifest_id": dataset_manifest_id}, "zebra_run.json")
        if (output_dir / "metrics.json").exists():
            metrics = json.loads((output_dir / "metrics.json").read_text(encoding="utf-8"))
            for key, value in metrics.items():
                if isinstance(value, int | float):
                    mlflow.log_metric(key, float(value))
        latest_dir = ensure_dir(Path("artifacts") / model_name / "latest")
        if (output_dir / "model.pkl").exists():
            shutil.copy2(output_dir / "model.pkl", latest_dir / "model.pkl")
        if (output_dir / "metrics.json").exists():
            shutil.copy2(output_dir / "metrics.json", latest_dir / "metrics.json")
        return {"mlflow_run_id": run.info.run_id, "runner_run_id": run_id, "output_dir": str(output_dir)}
