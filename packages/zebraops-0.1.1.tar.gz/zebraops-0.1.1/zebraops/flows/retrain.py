"""Conditional retraining orchestration flow."""

from __future__ import annotations

from prefect import flow

from zebraops.flows.eval import eval_flow
from zebraops.flows.monitor import monitor_flow
from zebraops.flows.promote import promote_flow
from zebraops.flows.train import train_flow


@flow(name="retrain_flow")
def retrain_flow(model_name: str, baseline_manifest_id: str, current_manifest_id: str) -> dict[str, str]:
    """Run monitor -> train -> eval -> promote if drift suggests retrain."""
    monitor_result = monitor_flow(model_name, baseline_manifest_id, current_manifest_id)
    if monitor_result["suggestion"] != "retrain":
        return {"status": "skipped", "reason": "drift threshold not exceeded"}

    train_result = train_flow(model_name=model_name, dataset_manifest_id=current_manifest_id)
    eval_flow(
        model_name=model_name,
        run_id=train_result["mlflow_run_id"],
        dataset_manifest_id=current_manifest_id,
    )
    promote = promote_flow(model_name=model_name, run_id=train_result["mlflow_run_id"], to_alias="staging")
    return {"status": "completed", "promoted_alias": promote["alias"]}
