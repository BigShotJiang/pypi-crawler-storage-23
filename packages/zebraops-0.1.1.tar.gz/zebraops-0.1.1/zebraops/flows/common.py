"""Shared helpers for flow execution and artifact wiring."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import mlflow

from zebraops.contracts import load_model_spec
from zebraops.contracts.model_spec import ModelSpec
from zebraops.utils.config import repo_path
from zebraops.utils.io import ensure_dir


def model_spec_path(model_name: str) -> Path:
    """Resolve model spec path from repository convention."""
    path = repo_path("models", model_name, "model.yaml")
    assert path.exists(), f"Model spec not found: {path}"
    return path


def load_model(model_name: str) -> ModelSpec:
    """Load validated model spec."""
    return load_model_spec(model_spec_path(model_name))


def load_manifest_data(dataset_id: str) -> dict[str, Any]:
    """Read raw manifest dict for flow-level URI lookup."""
    path = repo_path("cached_data", "manifests", f"{dataset_id}.json")
    assert path.exists(), f"Dataset manifest not found: {path}"
    return json.loads(path.read_text(encoding="utf-8"))


def setup_mlflow(tracking_uri: str, experiment_name: str) -> None:
    """Configure tracking backend and experiment."""
    mlflow.set_tracking_uri(tracking_uri)
    mlflow.set_experiment(experiment_name)


def run_output_dir(model_name: str, run_id: str) -> Path:
    """Create deterministic output directory per run."""
    return ensure_dir(repo_path("artifacts", model_name, run_id))
