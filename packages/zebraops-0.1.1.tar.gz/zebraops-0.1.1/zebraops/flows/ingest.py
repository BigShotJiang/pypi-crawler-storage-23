"""Prefect ingest flow that materializes datasets and writes manifests."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

import pandas as pd
from prefect import flow

from zebraops.connectors import load_dataframe
from zebraops.utils.config import repo_path
from zebraops.utils.io import ensure_dir, sha256_file


def _split_dataframe(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Apply deterministic row-order split for local MVP datasets."""
    assert len(df) >= 10, "Dataset must contain at least 10 rows for splitting."
    train_end = int(len(df) * 0.7)
    valid_end = int(len(df) * 0.85)
    return {
        "train": df.iloc[:train_end].copy(),
        "valid": df.iloc[train_end:valid_end].copy(),
        "test": df.iloc[valid_end:].copy(),
    }


@flow(name="ingest_flow")
def ingest_flow(dataset_id: str, source_location: str) -> dict[str, Any]:
    """Materialize dataset to parquet and emit immutable manifest."""
    assert dataset_id.strip(), "Dataset id cannot be empty."
    df = load_dataframe(source_location)
    splits = _split_dataframe(df)

    parquet_dir = ensure_dir(repo_path("cached_data", "parquet", dataset_id))
    manifest_dir = ensure_dir(repo_path("cached_data", "manifests"))
    uris: list[str] = []
    hashes: dict[str, str] = {}

    for split_name, split_df in splits.items():
        split_path = parquet_dir / f"{split_name}.parquet"
        split_df.to_parquet(split_path, index=False)
        uris.append(str(split_path))
        hashes[split_name] = sha256_file(split_path)

    columns = [{"name": col, "dtype": str(dtype)} for col, dtype in df.dtypes.items()]
    manifest = {
        "schema_version": "0.1",
        "id": dataset_id,
        "created_at": datetime.now(UTC).isoformat(),
        "source": {"connector": "file", "location": source_location, "parameters": {}},
        "schema": {"columns": columns, "target": "target" if "target" in df.columns else None},
        "splits": {
            "train": {"strategy": "slice", "selector": "0:70"},
            "valid": {"strategy": "slice", "selector": "70:85"},
            "test": {"strategy": "slice", "selector": "85:100"},
        },
        "stats": {"row_count": int(len(df)), "column_count": int(len(df.columns))},
        "artifacts": {"uris": uris},
        "hashes": hashes,
        "event_id": str(uuid4()),
    }
    manifest_path = manifest_dir / f"{dataset_id}.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {"dataset_id": dataset_id, "manifest_path": str(manifest_path), "uris": uris}
