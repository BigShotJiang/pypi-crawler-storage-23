"""Monitoring and retrain recommendation Prefect flows."""

from __future__ import annotations

import json

import mlflow
from prefect import flow

from zebraops.flows.common import load_manifest_data, load_model, setup_mlflow
from zebraops.monitoring.drift import compute_simple_drift, render_html_report
from zebraops.monitoring.metrics import DRIFT_RUNS
from zebraops.utils.config import get_endpoints, repo_path
from zebraops.utils.io import ensure_dir


@flow(name="monitor_flow")
def monitor_flow(model_name: str, train_manifest_id: str, current_manifest_id: str) -> dict[str, str]:
    """Run drift checks and produce report artifacts."""
    model = load_model(model_name)
    setup_mlflow(get_endpoints().mlflow_tracking_uri, model.tracking.experiment_name)
    train_manifest = load_manifest_data(train_manifest_id)
    current_manifest = load_manifest_data(current_manifest_id)
    metrics = compute_simple_drift(
        train_manifest["artifacts"]["uris"][0], current_manifest["artifacts"]["uris"][0]
    )
    suggestion = "retrain" if metrics["drift_score"] >= 0.1 else "stable"
    report_dir = ensure_dir(repo_path("artifacts", model_name, "monitoring"))
    report_path = report_dir / f"{current_manifest_id}_drift_report.html"
    render_html_report(metrics, report_path)
    meta_path = report_dir / f"{current_manifest_id}_drift_metrics.json"
    meta_path.write_text(json.dumps({"metrics": metrics, "suggestion": suggestion}, indent=2), encoding="utf-8")
    DRIFT_RUNS.inc()
    with mlflow.start_run(run_name=f"{model_name}-monitor-{current_manifest_id}"):
        mlflow.log_metrics(metrics)
        mlflow.log_param("suggestion", suggestion)
        mlflow.log_artifact(str(report_path))
        mlflow.log_artifact(str(meta_path))
    return {"report_path": str(report_path), "suggestion": suggestion}
