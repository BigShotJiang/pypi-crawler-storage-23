"""Evaluation flow that computes metrics and produces an artifact report."""

from __future__ import annotations

import json
from pathlib import Path

import mlflow
import pandas as pd
from prefect import flow
from sklearn.metrics import accuracy_score

from zebraops.flows.common import load_manifest_data, load_model, setup_mlflow
from zebraops.utils.config import get_endpoints, repo_path


@flow(name="eval_flow")
def eval_flow(model_name: str, run_id: str, dataset_manifest_id: str) -> dict[str, float]:
    """Evaluate a trained model artifact against validation data."""
    assert run_id.strip(), "run_id is required."
    model = load_model(model_name)
    manifest = load_manifest_data(dataset_manifest_id)
    valid_uri = manifest["artifacts"]["uris"][1]
    df = pd.read_parquet(valid_uri)
    assert "target" in df.columns, "Validation dataset must contain 'target'."
    setup_mlflow(get_endpoints().mlflow_tracking_uri, model.tracking.experiment_name)

    model_path = repo_path("artifacts", model_name, run_id, "model.pkl")
    assert model_path.exists(), f"Model artifact not found: {model_path}"
    loaded_model = pd.read_pickle(model_path)
    x_valid = df.drop(columns=["target"])
    y_valid = df["target"]
    preds = loaded_model.predict(x_valid)
    accuracy = float(accuracy_score(y_valid, preds))
    report = {"accuracy": accuracy, "rows": float(len(df))}
    out_path = Path(model_path).parent / "eval_report.json"
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    with mlflow.start_run(run_id=run_id):
        mlflow.log_metrics(report)
        mlflow.log_artifact(str(out_path))
    return report
