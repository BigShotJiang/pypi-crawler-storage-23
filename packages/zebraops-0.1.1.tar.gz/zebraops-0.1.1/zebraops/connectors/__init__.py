"""Connector entrypoints for data ingestion."""

from zebraops.connectors.files import load_dataframe

__all__ = ["load_dataframe"]
