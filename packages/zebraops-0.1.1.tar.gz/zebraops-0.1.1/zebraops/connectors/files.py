"""File connector for CSV and Parquet ingestion sources."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def load_dataframe(location: str) -> pd.DataFrame:
    """Load dataframe from a supported file location."""
    path = Path(location)
    assert path.exists(), f"Data source not found: {path}"
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported file extension: {path.suffix}")
