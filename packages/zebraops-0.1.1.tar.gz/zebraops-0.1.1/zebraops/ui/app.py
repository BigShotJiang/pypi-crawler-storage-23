"""Thin local ZebraOps UI for beginner workflows."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from zebraops.utils.config import get_endpoints, repo_path

app = FastAPI(title="ZebraOps UI", version="0.1.0")


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    """Render compact status page with service links and discovered models."""
    endpoints = get_endpoints()
    model_names = sorted([p.parent.name for p in repo_path("models").glob("*/model.yaml")])
    list_items = "".join([f"<li>{name}</li>" for name in model_names]) or "<li>No models found.</li>"
    return f"""
    <html>
      <body>
        <h1>ZebraOps UI</h1>
        <h2>Service Links</h2>
        <ul>
          <li><a href="{endpoints.prefect_api_url}">Prefect API</a></li>
          <li><a href="{endpoints.mlflow_tracking_uri}">MLflow</a></li>
          <li><a href="{endpoints.grafana_url}">Grafana</a></li>
        </ul>
        <h2>Models</h2>
        <ul>{list_items}</ul>
        <p>Use CLI for actions: ingest, train, eval, promote, serve, monitor.</p>
      </body>
    </html>
    """
