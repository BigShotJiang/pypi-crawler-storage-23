"""SQLite-backed local state storage with Postgres-portable schema shapes."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import DateTime, String, Text, create_engine, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column

from zebraops.utils.config import repo_path


class Base(DeclarativeBase):
    """SQLAlchemy declarative base."""


class ModelRecord(Base):
    """Discovered model specs and associated hashes."""

    __tablename__ = "models"
    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    spec_path: Mapped[str] = mapped_column(Text, nullable=False)
    spec_hash: Mapped[str] = mapped_column(String(128), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class EndpointRecord(Base):
    """Resolved endpoint values for local/shared profiles."""

    __tablename__ = "endpoints"
    name: Mapped[str] = mapped_column(String(128), primary_key=True)
    url: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ServingPointer(Base):
    """Current serving aliases and pinned run IDs."""

    __tablename__ = "serving_pointers"
    model_name: Mapped[str] = mapped_column(String(128), primary_key=True)
    alias: Mapped[str] = mapped_column(String(32), primary_key=True)
    run_id: Mapped[str] = mapped_column(String(128), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MonitoringResult(Base):
    """Latest monitoring result and acknowledgement state."""

    __tablename__ = "monitoring_results"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    model_name: Mapped[str] = mapped_column(String(128), nullable=False)
    status: Mapped[str] = mapped_column(String(32), nullable=False)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    acknowledged: Mapped[str] = mapped_column(String(5), nullable=False, default="false")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


@dataclass(frozen=True)
class StateStore:
    """High-level state operations for CLI/UI layers."""

    db_path: Path | None = None

    def __post_init__(self) -> None:
        if self.db_path is not None:
            assert self.db_path.suffix == ".db", "State database must be a .db file."

    def _db_path(self) -> Path:
        """Resolve local state DB path for current project."""
        if self.db_path is not None:
            return self.db_path
        return repo_path(".zebraops", "state.db")

    @property
    def engine(self) -> Engine:
        """Return SQLAlchemy engine for database path."""
        db_path = self._db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        return create_engine(f"sqlite+pysqlite:///{db_path}", future=True)

    def init(self) -> None:
        """Create all required local state tables."""
        Base.metadata.create_all(self.engine)

    def upsert_model(self, name: str, spec_path: str, spec_hash: str) -> None:
        """Insert or update a discovered model record."""
        assert name, "Model name is required."
        now = datetime.now(UTC)
        with Session(self.engine) as session:
            record = session.get(ModelRecord, name)
            if record is None:
                record = ModelRecord(name=name, spec_path=spec_path, spec_hash=spec_hash, updated_at=now)
                session.add(record)
            else:
                record.spec_path = spec_path
                record.spec_hash = spec_hash
                record.updated_at = now
            session.commit()

    def list_models(self) -> list[ModelRecord]:
        """List persisted model records."""
        with Session(self.engine) as session:
            rows = session.execute(select(ModelRecord)).scalars().all()
            return list(rows)

    def set_serving_pointer(self, model_name: str, alias: str, run_id: str) -> None:
        """Set local serving alias pointer, used as fallback when registry is unavailable."""
        assert model_name and alias and run_id, "Model, alias, and run_id are required."
        now = datetime.now(UTC)
        key = {"model_name": model_name, "alias": alias}
        with Session(self.engine) as session:
            record = session.get(ServingPointer, key)
            if record is None:
                record = ServingPointer(model_name=model_name, alias=alias, run_id=run_id, updated_at=now)
                session.add(record)
            else:
                record.run_id = run_id
                record.updated_at = now
            session.commit()

    def get_serving_pointer(self, model_name: str, alias: str) -> ServingPointer | None:
        """Get local serving alias pointer."""
        with Session(self.engine) as session:
            return session.get(ServingPointer, {"model_name": model_name, "alias": alias})
