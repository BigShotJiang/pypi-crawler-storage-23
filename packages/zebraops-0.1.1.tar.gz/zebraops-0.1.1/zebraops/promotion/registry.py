"""MLflow registry operations for promote and rollback workflows."""

from __future__ import annotations

import mlflow
from mlflow.tracking import MlflowClient


def set_alias(model_name: str, version: str, alias: str) -> None:
    """Set MLflow model alias to selected version."""
    client = MlflowClient()
    client.set_registered_model_alias(model_name, alias, version)


def get_alias_version(model_name: str, alias: str) -> str:
    """Resolve MLflow alias into model version string."""
    client = MlflowClient()
    mv = client.get_model_version_by_alias(model_name, alias)
    return str(mv.version)


def ensure_experiment(experiment_name: str) -> str:
    """Create experiment if missing and return id."""
    exp = mlflow.get_experiment_by_name(experiment_name)
    if exp is not None:
        return exp.experiment_id
    return mlflow.create_experiment(experiment_name)
