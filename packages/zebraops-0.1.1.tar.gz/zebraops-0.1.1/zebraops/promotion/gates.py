"""Promotion gate checks for threshold-based model transitions."""

from __future__ import annotations

from dataclasses import dataclass

from zebraops.contracts.model_spec import MetricSpec


@dataclass(frozen=True)
class GateResult:
    """Outcome of promotion gate validation."""

    passed: bool
    message: str


def check_metric_gate(metric: MetricSpec, observed_value: float) -> GateResult:
    """Evaluate observed metric value against contract threshold."""
    if metric.threshold is None:
        return GateResult(True, f"Metric {metric.name} has no threshold.")
    if metric.direction.value == "maximize":
        ok = observed_value >= metric.threshold
        return GateResult(ok, f"{metric.name}: observed={observed_value}, min={metric.threshold}")
    ok = observed_value <= metric.threshold
    return GateResult(ok, f"{metric.name}: observed={observed_value}, max={metric.threshold}")
