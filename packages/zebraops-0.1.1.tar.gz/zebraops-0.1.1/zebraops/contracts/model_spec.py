"""Pydantic model spec schema and validators for model.yaml contracts."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator


class ModelType(str, Enum):
    """Supported model entrypoint types."""

    python = "python"
    notebook = "notebook"


class Direction(str, Enum):
    """Metric optimization direction."""

    maximize = "maximize"
    minimize = "minimize"


class ResourcesSpec(BaseModel):
    """Resource requirements for a model run."""

    accelerator: str = Field(pattern="^(cpu|gpu)$")
    gpu_count: int | None = Field(default=None, ge=1)


class TrackingSpec(BaseModel):
    """Experiment tracking configuration."""

    experiment_name: str = Field(min_length=1)


class MetricSpec(BaseModel):
    """Promotion-aware metric definition."""

    name: str = Field(min_length=1)
    direction: Direction
    threshold: float | None = None


class PromotionSpec(BaseModel):
    """MLflow registry alias settings."""

    registry: str = "mlflow"
    alias_prod: str = "prod"
    alias_staging: str = "staging"


class DatasetRefs(BaseModel):
    """Dataset identifiers used by the model."""

    train: str = Field(min_length=1)
    valid: str = Field(min_length=1)
    test: str | None = None


class HyperparamsSpec(BaseModel):
    """Grid-search style hyperparameter definition."""

    grid: dict[str, list[Any]]

    @field_validator("grid")
    @classmethod
    def non_empty_grid(cls, value: dict[str, list[Any]]) -> dict[str, list[Any]]:
        """Ensure hyperparameter grid has concrete search values."""
        assert value, "Hyperparameter grid must not be empty."
        for key, options in value.items():
            assert key.strip(), "Hyperparameter names must be non-empty."
            assert options, f"Hyperparameter '{key}' options must not be empty."
        return value


class EnvSpec(BaseModel):
    """Runtime environment pinning."""

    python_version: str | None = None
    pip_requirements: str | None = None


class ModelSpec(BaseModel):
    """Top-level v0.1 model specification schema."""

    schema_version: str = "0.1"
    name: str = Field(min_length=1)
    type: ModelType
    entrypoint: str = Field(min_length=1)
    datasets: DatasetRefs
    resources: ResourcesSpec
    tracking: TrackingSpec
    metrics: list[MetricSpec] = Field(min_length=1)
    promotion: PromotionSpec = PromotionSpec()
    hyperparams: HyperparamsSpec | None = None
    env: EnvSpec | None = None
    notes: str | None = None

    @model_validator(mode="after")
    def validate_entrypoint(self) -> ModelSpec:
        """Ensure entrypoint and model type are aligned."""
        if self.type is ModelType.python:
            assert self.entrypoint.endswith(".py"), "Python models must point to a .py entrypoint."
        if self.type is ModelType.notebook:
            assert self.entrypoint.endswith(".ipynb"), "Notebook models must point to a .ipynb entrypoint."
        return self


def load_model_spec(path: Path) -> ModelSpec:
    """Load and validate model specification from YAML."""
    assert path.exists(), f"Model spec does not exist: {path}"
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    return ModelSpec.model_validate(raw)


def validate_model_spec(path: Path) -> tuple[bool, str]:
    """Return validation state and message for CLI diagnostics."""
    try:
        load_model_spec(path)
        return True, "ok"
    except (ValidationError, AssertionError, yaml.YAMLError, OSError) as exc:
        return False, str(exc)
