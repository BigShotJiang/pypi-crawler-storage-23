"""Pydantic dataset manifest schema and validation helpers."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, ValidationError, field_validator


class ColumnSpec(BaseModel):
    """Column and dtype information for dataset schema."""

    name: str = Field(min_length=1)
    dtype: str = Field(min_length=1)


class SchemaSpec(BaseModel):
    """Dataset schema including optional target label."""

    columns: list[ColumnSpec] = Field(min_length=1)
    target: str | None = None


class SplitSpec(BaseModel):
    """Split definition with reproducible filter semantics."""

    strategy: str = Field(min_length=1)
    selector: str = Field(min_length=1)


class SourceSpec(BaseModel):
    """Data source declaration used for ingest reproducibility."""

    connector: str = Field(min_length=1)
    location: str = Field(min_length=1)
    parameters: dict[str, Any] = Field(default_factory=dict)


class ArtifactSpec(BaseModel):
    """Materialized artifact URI list."""

    uris: list[str] = Field(min_length=1)


class DatasetManifest(BaseModel):
    """Immutable dataset manifest for train/eval reproducibility."""

    schema_version: str = "0.1"
    id: str = Field(min_length=1)
    created_at: datetime
    source: SourceSpec
    schema_: SchemaSpec = Field(alias="schema")
    splits: dict[str, SplitSpec]
    stats: dict[str, Any] = Field(default_factory=dict)
    artifacts: ArtifactSpec
    hashes: dict[str, str]

    model_config = {"populate_by_name": True}

    @field_validator("splits")
    @classmethod
    def validate_required_splits(cls, value: dict[str, SplitSpec]) -> dict[str, SplitSpec]:
        """Ensure train and valid splits are always present."""
        assert "train" in value, "Split 'train' is required."
        assert "valid" in value, "Split 'valid' is required."
        return value


def load_manifest(path: Path) -> DatasetManifest:
    """Load and validate dataset manifest JSON."""
    assert path.exists(), f"Manifest file does not exist: {path}"
    raw = json.loads(path.read_text(encoding="utf-8"))
    return DatasetManifest.model_validate(raw)


def validate_manifest(path: Path) -> tuple[bool, str]:
    """Return validation status and details for diagnostics."""
    try:
        load_manifest(path)
        return True, "ok"
    except (ValidationError, AssertionError, json.JSONDecodeError, OSError) as exc:
        return False, str(exc)
