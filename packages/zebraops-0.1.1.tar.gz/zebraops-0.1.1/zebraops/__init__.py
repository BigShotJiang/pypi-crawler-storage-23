"""ZebraOps package root."""

from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parent
