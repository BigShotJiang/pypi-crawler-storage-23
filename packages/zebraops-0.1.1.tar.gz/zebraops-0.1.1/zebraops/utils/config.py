"""Configuration helpers for environment and profile resolution."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ServiceEndpoints:
    """Resolved endpoint values for platform services."""

    mlflow_tracking_uri: str
    prefect_api_url: str
    minio_endpoint: str
    grafana_url: str
    prometheus_url: str
    zebraops_ui_url: str


def get_endpoints() -> ServiceEndpoints:
    """Resolve service endpoints from environment with deterministic defaults."""
    return ServiceEndpoints(
        mlflow_tracking_uri=os.getenv("MLFLOW_TRACKING_URI", "http://localhost:15500"),
        prefect_api_url=os.getenv("PREFECT_API_URL", "http://localhost:14200/api"),
        minio_endpoint=os.getenv("MINIO_ENDPOINT", "http://localhost:19000"),
        grafana_url=os.getenv("GRAFANA_URL", "http://localhost:13000"),
        prometheus_url=os.getenv("PROMETHEUS_URL", "http://localhost:19090"),
        zebraops_ui_url=os.getenv("ZEBRAOPS_UI_URL", "http://localhost:18080"),
    )


def resolve_project_root(start: Path | None = None) -> Path:
    """Walk up from start (or cwd) looking for .zebraops-project marker.

    Falls back to cwd if no marker is found. Never falls back to
    the installed package path — the user's project is always a
    directory on disk, not inside the library.
    """
    explicit = os.getenv("ZEBRAOPS_PROJECT_ROOT")
    if explicit:
        return Path(explicit).expanduser().resolve()

    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if (candidate / ".zebraops-project").exists():
            return candidate
    return current


def repo_path(*parts: str) -> Path:
    """Build an absolute path rooted at the active project root."""
    path = resolve_project_root().joinpath(*parts)
    assert path.is_absolute(), "Project path helper must return absolute paths."
    return path
