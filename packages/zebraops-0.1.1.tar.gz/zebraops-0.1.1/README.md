# ZebraOps

Local-first, open-source MLOps platform for ML beginners and small teams.

## Documentation

- [Tutorial: Quick Start](https://github.com/Flexiana/zebraops/blob/master/docs/quickstart.md)
- [API Documentation](https://github.com/Flexiana/zebraops/blob/master/docs/api.md)
- [Best Practices](https://github.com/Flexiana/zebraops/blob/master/docs/best-practices.md)
- [Operations & Troubleshooting](https://github.com/Flexiana/zebraops/blob/master/docs/operations.md)
- [Release Guide](https://github.com/Flexiana/zebraops/blob/master/docs/release.md)

## Quick Start

```bash
pip install zebraops
mlops init-project
mlops up
mlops doctor
mlops init my_model
mlops ingest my_dataset /path/to/data.csv
mlops train my_model my_dataset
```

## Features

- **`mlops` CLI** with full lifecycle: init, ingest, train, eval, promote, serve, monitor
- **Contract-first** model specs and immutable dataset manifests
- **MLflow** tracking, model registry, and promotion gates
- **Prefect** orchestration for reproducible pipelines
- **FastAPI** serving with Prometheus metrics
- **Evidently** drift monitoring with retrain recommendations
- **Docker Compose** local devstack (Postgres, MinIO, Grafana, Prometheus)
- **Profile adapters** for Vast, SageMaker, Vertex (extensible)

## License

Apache License 2.0. See [LICENSE](https://github.com/Flexiana/zebraops/blob/master/LICENSE).
