# AnalogAI SDK (minimal)

This workspace contains a tiny Python helper for calling AnalogAI chat endpoints.

## Setup

1. Install dependencies with Poetry.
2. Set environment variables in `.env` (already created with placeholders):
    - `ANALOGAI_API_KEY` (optional, if your server requires auth)
    - `ANALOGAI_AGENT_ID` (required)

## Install (Poetry)

```bash
poetry install
```

### Local install (editable)

```bash
poetry run pip install -e .
```

### Global install (Poetry)

```bash
poetry build
pip install dist/analogai-0.1.0-py3-none-any.whl
```

## PyPI name

Once published, the package will be available on PyPI as `analogai`.

## Usage

```python
from analogai_sdk import AnalogAIClient

client = AnalogAIClient()
response = client.generate_completion("your text here")
print(response)

for chunk in client.generate_streaming_completion("your text here"):
    print(chunk)
```

### Using explicit messages

```python
from analogai_sdk import AnalogAIClient

client = AnalogAIClient()
response = client.generate_completion(
    message_text="",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Say hello"},
    ],
)
print(response)
```
