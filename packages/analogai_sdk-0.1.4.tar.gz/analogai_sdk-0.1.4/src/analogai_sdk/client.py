"""AnalogAI SDK helpers for chat completions and streaming."""

from __future__ import annotations

import os
from typing import Any, Dict, Generator, Iterable, Optional

import requests

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

DEFAULT_BASE_URL = "https://app.analogai.net:7777"

class AnalogAIClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        timeout: int = 60,
    ) -> None:
        self.api_key = api_key or os.getenv("ANALOGAI_API_KEY")
        self.agent_id = agent_id or os.getenv("ANALOGAI_AGENT_ID")
        self.base_url = DEFAULT_BASE_URL
        self.timeout = timeout

        if not self.agent_id:
            raise ValueError("Missing agent id. Set ANALOGAI_AGENT_ID in environment or pass agent_id.")

        self.base_url = self.base_url.rstrip("/")

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def health(self) -> Dict[str, Any]:
        url = f"{self.base_url}/health"
        response = requests.get(url, headers=self._headers(), timeout=self.timeout)
        response.raise_for_status()
        return response.json()

    def generate_completion(
        self,
        message_text: str,
        auth_type: str = "user",
        messages: Optional[Iterable[Dict[str, str]]] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/v1/chat/completions"
        payload_messages = list(messages) if messages is not None else [{"role": auth_type, "content": message_text}]
        payload = {"messages": payload_messages, "stream": False}
        response = requests.post(
            url,
            headers=self._headers(),
            params={"agent_id": self.agent_id},
            json=payload,
            timeout=self.timeout,
        )
        response.raise_for_status()
        return response.json()

    def generate_streaming_completion(
        self,
        message_text: str,
        auth_type: str = "user",
        messages: Optional[Iterable[Dict[str, str]]] = None,
    ) -> Generator[str, None, None]:
        url = f"{self.base_url}/v1/chat/streaming-completions"
        payload_messages = list(messages) if messages is not None else [{"role": auth_type, "content": message_text}]
        payload = {"messages": payload_messages, "stream": True}
        with requests.post(
            url,
            headers=self._headers(),
            params={"agent_id": self.agent_id},
            json=payload,
            stream=True,
            timeout=self.timeout,
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line:
                    yield line.decode("utf-8")


__all__ = ["AnalogAIClient"]
