"""Auto-generated at build time — do not edit."""

VERSION = 'v0.13.2'
GIT_SHA_SHORT = '1b64ec7'
GIT_SHA_FULL = '1b64ec773b8cefc04d3d021e14c69f6c607bd748'
