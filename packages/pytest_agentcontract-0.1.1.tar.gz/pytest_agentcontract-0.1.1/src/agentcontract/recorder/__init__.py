"""Recording module for capturing agent trajectories."""

from agentcontract.recorder.core import Recorder

__all__ = ["Recorder"]
