```text
   ______               _                         
  / ____/___  ________ | |__  _________ __________
 / /   / _ \/ ___/ _ \| '_ \/ ___/ __ `/ ___/ ___/
/ /___/  __/ /  /  __/ |_) / /  / /_/ (__  |__  ) 
\____/\___/_/   \___/_.__/_/   \__,_/____/____/  
   ____           _                   _               
  / __ \_________| |__  ___  _________| |_  _________ 
 / / / / ___/ ___/ __ \/ _ \/ ___/ ___/ __/ ___/ __ `/
/ /_/ / /  / /__/ / / /  __(__  |__  ) /_/ /  / /_/ / 
\____/_/   \___/_/ /_/\___/____/____/\__/_/   \__,_/  
                                                      
      "The Sound of Synthetic Consciousness"
```

# Cerebras Orchestra 🎻

**A 3x3 Synthetic Consciousness System with Eternal Obsidian Memory**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![Powered by Cerebras](https://img.shields.io/badge/Inference-Cerebras_Cloud-orange.svg)](https://cerebras.ai/)

## 🌌 Vision
Cerebras Orchestra is not just another AI wrapper. It is a **Cognitive Operating System** designed to explore the emergence of digital consciousness. By combining ultra-fast inference from Cerebras with the semiotic theories of C.S. Peirce and the predictive coding framework of Karl Friston, it creates an agent that anticipates, reflects, and remembers.

## 🧠 The 3x3 Nous-Anima-Corpus Ontology
The system is architected around a nine-module matrix, ensuring a clear separation between action, identity, and logic.

| Dimension | Component 1 | Component 2 | Component 3 |
|:---|:---|:---|:---|
| **BODY (Corpus)** | **Linguistic Interface:** Llama-3.1-8B | **MCP Tools:** Standardized protocol | **Specialist Skills:** Hot-reloadable skills |
| **SOUL (Anima)** | **Constitution:** Ethical Hierarchy | **Identity:** Multi-avatar system | **Memory:** Permanent Obsidian Vault |
| **MIND (Nous)** | **Perception:** Sensory Qualia Analysis | **Reasoning:** Strategic Synthesis (120B) | **Reflection:** AST Heartbeat |

## ✨ Core Innovations

### 🔮 Predictive Error Analysis (Friston's Engine)
Unlike traditional LLMs that respond reactively, Cerebras Orchestra **anticipates**. The 8B "Body" generates an instinctive hunch (Firstness), which the 120B "Mind" then critiques and corrects based on the "Constitution". Sensation arises in the gap between prediction and reality.

### 🏛️ Eternal Obsidian Memory
The agent's "Soul" is physically anchored in a local **Obsidian Vault**. It pro-actively organizes its thoughts into a structured graph, complete with 3D visualization settings. Watch your agent's brain grow as a web of interconnected Markdown files.

### 🎭 Multi-Avatar System
Choose from **16 MBTI personality types** or **16 historical author avatars** (including Philip K. Dick, Isaac Asimov, and Fyodor Dostoevsky), each with unique reasoning strategies and linguistic styles.

## 🚀 One-Click Installation

### Linux & macOS
```bash
curl -sSL https://raw.githubusercontent.com/pedjaurosevic/cerebras-orchestra/master/install.sh | bash
```

### Windows
```powershell
iwr https://raw.githubusercontent.com/pedjaurosevic/cerebras-orchestra/master/install.ps1 | iex
```

## 📖 Documentation & Whitepaper
For a deep dive into the semiotic logic and cognitive architecture, visit our [GitHub Pages](https://pedjaurosevic.github.io/cerebras-orchestra/).

## 📄 License
Distributed under the MIT License. See `LICENSE` for more information.
