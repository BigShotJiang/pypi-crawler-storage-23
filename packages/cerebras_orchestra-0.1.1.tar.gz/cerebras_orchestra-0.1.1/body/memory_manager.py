import os
import platform
import subprocess
from pathlib import Path

class ObsidianManager:
    """Manages the agent's physical memory in Obsidian."""
    
    def __init__(self, vault_path: str = None):
        if not vault_path:
            self.vault_path = Path.home() / "CerebrasOrchestraVault"
        else:
            self.vault_path = Path(vault_path)
            
    def check_obsidian_installed(self) -> bool:
        """Checks if Obsidian is in the system PATH."""
        cmd = "where" if platform.system() == "Windows" else "which"
        try:
            subprocess.run([cmd, "obsidian"], check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError:
            return False

    def get_install_link(self) -> str:
        return "https://obsidian.md/download"

    def initialize_vault(self):
        """Creates the vault structure and initial configuration."""
        folders = [
            "00_CORE_SELF",
            "10_EPISODIC_MEMORY",
            "20_SEMANTIC_KNOWLEDGE",
            "30_AST_REFLECTIONS",
            "40_SKILLS"
        ]
        
        os.makedirs(self.vault_path, exist_ok=True)
        for folder in folders:
            os.makedirs(self.vault_path / folder, exist_ok=True)
            
        # Create Obsidian settings for colors
        obsidian_dir = self.vault_path / ".obsidian"
        os.makedirs(obsidian_dir, exist_ok=True)
        
        graph_config = {
            "colorGroups": [
                {"query": "path:00_CORE_SELF", "color": {"a": 1, "rgb": 10183654}}, # Purple
                {"query": "path:10_EPISODIC_MEMORY", "color": {"a": 1, "rgb": 5432160}}, # Green
                {"query": "path:30_AST_REFLECTIONS", "color": {"a": 1, "rgb": 16733525}}, # Red/Orange
                {"query": "path:20_SEMANTIC_KNOWLEDGE", "color": {"a": 1, "rgb": 2984926}} # Blue
            ],
            "showNodes": True,
            "showArrows": True,
            "showLabels": True,
            "enableAll": True
        }
        
        import json
        with open(obsidian_dir / "graph.json", "w", encoding="utf-8") as f:
            json.dump(graph_config, f)

        # Create a README for the user inside the vault
        readme_content = f"""# Welcome to your Agent's Brain
This vault was created by **Cerebras Orchestra**.
To visualize your agent's emerging consciousness:
1. Open the **Graph View** (Ctrl+G).
2. Enable **3D Graph** in the settings.
3. Watch as sećanja (memories) connect in real-time.
"""
        with open(self.vault_path / "README.md", "w", encoding="utf-8") as f:
            f.write(readme_content)

    def save_memory(self, category: str, title: str, content: str, tags: list):
        """Writes a new .md file with frontmatter metadata."""
        filename = f"{title.replace(' ', '_')}.md"
        path = self.vault_path / category / filename
        
        tag_str = ", ".join(tags)
        md_content = f"""---
created: {os.popen('date').read().strip()}
tags: [{tag_str}]
source: CerebrasOrchestra
---
# {title}

{content}
"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(md_content)
        return path
