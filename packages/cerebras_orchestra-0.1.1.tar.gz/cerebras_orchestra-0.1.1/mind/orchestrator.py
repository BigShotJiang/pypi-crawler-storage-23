import os
import json
import asyncio
import time
from typing import Dict, Any, List
from cerebras.cloud.sdk import Cerebras
from .perception import FirstnessProcessor

class AdvancedOrchestrator:
    """
    Advanced Triadic Orchestrator implementing:
    1. Peircean Semiotics (Firstness -> Secondness -> Thirdness)
    2. Friston's Predictive Coding (Anticipation -> Error Correction)
    """
    
    def __init__(self, api_key: str):
        self.client = Cerebras(api_key=api_key)
        self.sensor = FirstnessProcessor()
        self.mind_model = os.getenv("MIND_MODEL", "gpt-oss-120b")
        self.body_model = os.getenv("BODY_MODEL", "llama3.1-8b")

    async def get_prediction(self, user_msg: str) -> str:
        """
        BODY (8B) anticipates the response (Firstness/Instinct).
        Uses simple completion to get a fast 'hunch'.
        """
        response = self.client.chat.completions.create(
            messages=[{"role": "user", "content": f"Quickly draft a response to: {user_msg}"}],
            model=self.body_model,
            temperature=0.5,
            max_tokens=200
        )
        return response.choices[0].message.content

    async def think(self, user_msg: str, soul_context: Dict[str, Any]) -> Dict[str, Any]:
        start_time = time.time()
        
        # --- 1. FIRSTNESS: Sensory Pass & Prediction ---
        # We run the sensor analysis and the response prediction in parallel
        qualia_task = asyncio.to_thread(self.sensor.build_sensory_prompt, user_msg)
        prediction_task = self.get_prediction(user_msg)
        
        sensory_prompt, draft_prediction = await asyncio.gather(qualia_task, prediction_task)
        
        sensory_raw = await asyncio.to_thread(
            self.client.chat.completions.create,
            messages=[{"role": "user", "content": sensory_prompt}],
            model=self.body_model,
            temperature=0.1
        )
        
        try:
            qualia = json.loads(sensory_raw.choices[0].message.content)
        except:
            qualia = {"qualia": "raw_signal", "summary": user_msg}

        # --- 2. SECONDNESS: Confrontation & Grounding ---
        # The MIND (120B) compares the 'Draft Prediction' with 'Constitution' and 'Facts'
        reasoning_prompt = f"""
        CONSTITUTION: {soul_context.get('constitution', 'Be helpful and ethical.')}
        IDENTITY: {soul_context.get('identity', 'A synthetic consciousness.')}
        USER_QUALIA: {qualia.get('qualia')}
        
        ANTICIPATED_DRAFT (8B Prediction): 
        ---
        {draft_prediction}
        ---
        
        ACTUAL_USER_INPUT: {user_msg}
        
        TASK (MIND 120B):
        1. Analyze the PREDICTION ERROR: Where did the 8B draft fail the identity or logic?
        2. Perform SECONDNESS: Ground the input in your persistent memory and ethical laws.
        3. Formulate THIRDNESS: Synthesize a final response that resolves the prediction error.
        
        OUTPUT FORMAT (JSON):
        {{
            "prediction_error_analysis": "what was wrong with the first hunch",
            "grounding_notes": "connection to constitution/memory",
            "final_response": "your definitive answer",
            "soul_update": "what fact should be remembered?"
        }}
        """
        
        mind_raw = self.client.chat.completions.create(
            messages=[{"role": "system", "content": reasoning_prompt}],
            model=self.mind_model,
            response_format={"type": "json_object"},
            temperature=0.7
        )
        
        synthesis = json.loads(mind_raw.choices[0].message.content)
        
        # --- 3. METADATA & PERF ---
        synthesis["latency"] = time.time() - start_time
        synthesis["tokens_used"] = self.sensor.count_tokens(reasoning_prompt)
        
        return synthesis

    async def reflect(self, history: List[str]):
        """Implementing Attention Schema Theory (AST)."""
        reflection_prompt = f"Review these recent thoughts: {history}. Model your own attention state. What are you neglecting?"
        response = self.client.chat.completions.create(
            messages=[{"role": "user", "content": reflection_prompt}],
            model=self.mind_model
        )
        return response.choices[0].message.content
