import tiktoken

class FirstnessProcessor:
    """The Sensory Layer: Handles raw perception and qualitative analysis."""
    
    def __init__(self, model_name="llama3.1-8b"):
        self.model_name = model_name
        self.tokenizer = tiktoken.get_encoding("cl100k_base")

    def count_tokens(self, text: str) -> int:
        return len(self.tokenizer.encode(text))

    def prune_context(self, text: str, max_tokens=1000) -> str:
        """Simple BPE-based pruning to protect 120B API limits."""
        tokens = self.tokenizer.encode(text)
        if len(tokens) <= max_tokens:
            return text
        return self.tokenizer.decode(tokens[:max_tokens])

    def build_sensory_prompt(self, user_msg: str) -> str:
        return f"""Analyze the QUALITATIVE FEEL (Firstness) of the following message.
Identify: Tone, Urgency, and Implicit Metaphors.
Output format: JSON only.
{{
  "qualia": "subjective feel",
  "tone": "detected tone",
  "summary": "pruned essence of query",
  "intent": "action/question/philosophical"
}}
Message: {user_msg}"""
