"""Evaluation scorers for the Synth SDK.

Provides ``ExactMatchScorer`` (binary 1.0/0.0) and
``SemanticSimilarityScorer`` (cosine similarity of embeddings), plus
support for custom checker functions.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any


# ---------------------------------------------------------------------------
# Base scorer
# ---------------------------------------------------------------------------


class BaseScorer(ABC):
    """Abstract base for evaluation scorers."""

    @abstractmethod
    def score(self, output: str, expected: Any) -> float:
        """Score the output against the expected value.

        Returns
        -------
        float
            A score between 0.0 and 1.0.
        """
        ...


# ---------------------------------------------------------------------------
# ExactMatchScorer
# ---------------------------------------------------------------------------


class ExactMatchScorer(BaseScorer):
    """Binary exact-match scorer: 1.0 if output == expected, else 0.0."""

    def score(self, output: str, expected: Any) -> float:
        """Return 1.0 for exact match, 0.0 otherwise."""
        return 1.0 if str(output).strip() == str(expected).strip() else 0.0


# ---------------------------------------------------------------------------
# SemanticSimilarityScorer
# ---------------------------------------------------------------------------


class SemanticSimilarityScorer(BaseScorer):
    """Cosine similarity scorer using vector embeddings.

    Parameters
    ----------
    embedder:
        A callable that takes a string and returns a list of floats
        (the embedding vector).
    """

    def __init__(self, embedder: Callable[[str], list[float]]) -> None:
        self._embedder = embedder

    def score(self, output: str, expected: Any) -> float:
        """Return cosine similarity between output and expected embeddings."""
        vec_a = self._embedder(str(output))
        vec_b = self._embedder(str(expected))
        return self._cosine_similarity(vec_a, vec_b)

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors."""
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return max(0.0, min(1.0, dot / (norm_a * norm_b)))


# ---------------------------------------------------------------------------
# CustomScorer
# ---------------------------------------------------------------------------


class CustomScorer(BaseScorer):
    """Wraps a user-provided checker function as a scorer.

    Parameters
    ----------
    checker:
        A callable ``(output, expected) -> float`` returning a score
        between 0.0 and 1.0.
    """

    def __init__(self, checker: Callable[[str, Any], float]) -> None:
        self._checker = checker

    def score(self, output: str, expected: Any) -> float:
        """Delegate to the user-provided checker."""
        return self._checker(output, expected)
