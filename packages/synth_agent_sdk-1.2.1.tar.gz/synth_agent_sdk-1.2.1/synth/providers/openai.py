"""OpenAIProvider — OpenAI GPT model adapter.

Routes requests to the OpenAI Chat Completions API using the ``openai``
Python SDK.  Supports custom ``base_url`` for OpenAI-compatible endpoints
(Azure, local proxies, etc.).
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import openai
except ImportError:
    openai = None  # type: ignore[assignment]


class OpenAIProvider(BaseProvider):
    """LLM provider adapter for OpenAI GPT models.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"gpt-4o"``, ``"gpt-4o-mini"``.
    base_url:
        Optional custom API endpoint for OpenAI-compatible services.
    **kwargs:
        Extra options forwarded to the OpenAI client constructor.
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if openai is None:
            raise SynthConfigError(
                message="Provider package 'openai' is not installed. "
                "Run: pip install synth-agent-sdk[openai]",
                component="OpenAIProvider",
                suggestion="pip install synth-agent-sdk[openai]",
            )

        api_key = os.environ.get("OPENAI_API_KEY")
        if not api_key:
            raise SynthConfigError(
                message="OPENAI_API_KEY environment variable is not set.",
                component="OpenAIProvider",
                suggestion="Set the OPENAI_API_KEY environment variable. "
                "Get your key at https://platform.openai.com/api-keys",
            )

        self._model = model
        client_kwargs: dict[str, Any] = {"api_key": api_key, **kwargs}
        if base_url is not None:
            client_kwargs["base_url"] = base_url

        self._client = openai.AsyncOpenAI(**client_kwargs)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _build_tools(
        self, tools: list[dict[str, Any]] | None
    ) -> list[dict[str, Any]] | None:
        """Convert Synth tool schemas to OpenAI function-calling format."""
        if not tools:
            return None
        openai_tools = []
        for t in tools:
            openai_tools.append({
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                },
            })
        return openai_tools

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the OpenAI Chat Completions API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``max_tokens``, etc.).
        """
        import json

        api_kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": [{"role": m["role"], "content": m["content"]} for m in messages],
            **kwargs,
        }

        openai_tools = self._build_tools(tools)
        if openai_tools is not None:
            api_kwargs["tools"] = openai_tools

        response = await self._client.chat.completions.create(**api_kwargs)
        choice = response.choices[0]
        message = choice.message

        text = message.content or ""
        tool_calls: list[ToolCallInfo] = []
        if message.tool_calls:
            for tc in message.tool_calls:
                tool_calls.append(
                    ToolCallInfo(
                        id=tc.id,
                        name=tc.function.name,
                        args=json.loads(tc.function.arguments),
                    )
                )

        usage_data = response.usage
        usage = TokenUsage(
            input_tokens=usage_data.prompt_tokens if usage_data else 0,
            output_tokens=usage_data.completion_tokens if usage_data else 0,
            total_tokens=usage_data.total_tokens if usage_data else 0,
        )

        return ProviderResponse(
            text=text,
            usage=usage,
            tool_calls=tool_calls,
            raw=response,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the OpenAI Chat Completions API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``max_tokens``, etc.).
        """
        import json

        api_kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": [{"role": m["role"], "content": m["content"]} for m in messages],
            "stream": True,
            "stream_options": {"include_usage": True},
            **kwargs,
        }

        openai_tools = self._build_tools(tools)
        if openai_tools is not None:
            api_kwargs["tools"] = openai_tools

        input_tokens = 0
        output_tokens = 0
        total_tokens = 0

        # Accumulate tool call chunks by index
        tool_call_accum: dict[int, dict[str, Any]] = {}

        try:
            response_stream = await self._client.chat.completions.create(**api_kwargs)
            async for chunk in response_stream:
                if chunk.usage:
                    input_tokens = chunk.usage.prompt_tokens or 0
                    output_tokens = chunk.usage.completion_tokens or 0
                    total_tokens = chunk.usage.total_tokens or 0

                if not chunk.choices:
                    continue

                delta = chunk.choices[0].delta

                # Text content
                if delta.content:
                    yield TextChunkEvent(text=delta.content)

                # Tool call deltas
                if delta.tool_calls:
                    for tc_delta in delta.tool_calls:
                        idx = tc_delta.index
                        if idx not in tool_call_accum:
                            tool_call_accum[idx] = {
                                "id": tc_delta.id or "",
                                "name": "",
                                "args_json": "",
                            }
                        if tc_delta.id:
                            tool_call_accum[idx]["id"] = tc_delta.id
                        if tc_delta.function:
                            if tc_delta.function.name:
                                tool_call_accum[idx]["name"] = tc_delta.function.name
                            if tc_delta.function.arguments:
                                tool_call_accum[idx]["args_json"] += (
                                    tc_delta.function.arguments
                                )

                # Check for finish reason to emit accumulated tool calls
                if chunk.choices[0].finish_reason == "tool_calls":
                    for _idx in sorted(tool_call_accum.keys()):
                        tc_data = tool_call_accum[_idx]
                        try:
                            args = json.loads(tc_data["args_json"])
                        except json.JSONDecodeError:
                            args = {}
                        yield ToolCallChunkEvent(
                            id=tc_data["id"],
                            name=tc_data["name"],
                            args=args,
                        )
                    tool_call_accum.clear()

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
