"""OllamaProvider — Ollama local model adapter.

Routes requests to a local Ollama server via its HTTP API using
``httpx``.  Since ``httpx`` is already a core dependency of the SDK,
no optional extra is required.
"""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

from synth.errors import SynthConfigError
from synth.providers.base import (
    BaseProvider,
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderEvent,
    ProviderResponse,
    TextChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.types import Message, TokenUsage

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore[assignment]

_DEFAULT_OLLAMA_URL = "http://localhost:11434"


class OllamaProvider(BaseProvider):
    """LLM provider adapter for locally-hosted Ollama models.

    Communicates with the Ollama HTTP API at ``/api/chat``.  The model
    string is expected in the form ``"ollama/<model_name>"``; the
    ``ollama/`` prefix is stripped before sending to the server.

    Parameters
    ----------
    model:
        Model identifier, e.g. ``"ollama/llama3"``.
    base_url:
        Ollama server URL.  Defaults to ``http://localhost:11434``.
    **kwargs:
        Reserved for future extensibility.
    """

    def __init__(self, model: str, base_url: str | None = None, **kwargs: Any) -> None:
        if httpx is None:
            raise SynthConfigError(
                message="Provider package 'httpx' is not installed. "
                "Run: pip install synth-agent-sdk[ollama]",
                component="OllamaProvider",
                suggestion="pip install synth-agent-sdk[ollama]",
            )

        # Strip the "ollama/" prefix for the actual model name
        self._model = model.removeprefix("ollama/")
        self._base_url = (base_url or _DEFAULT_OLLAMA_URL).rstrip("/")
        self._client = httpx.AsyncClient(timeout=120.0)

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def _build_tools(
        self, tools: list[dict[str, Any]] | None
    ) -> list[dict[str, Any]] | None:
        """Convert Synth tool schemas to Ollama function-calling format."""
        if not tools:
            return None
        ollama_tools = []
        for t in tools:
            ollama_tools.append({
                "type": "function",
                "function": {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {}),
                },
            })
        return ollama_tools

    # -----------------------------------------------------------------
    # BaseProvider interface
    # -----------------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> ProviderResponse:
        """Send a completion request to the Ollama chat API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``num_predict``, etc.).
        """
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "stream": False,
            **kwargs,
        }

        ollama_tools = self._build_tools(tools)
        if ollama_tools is not None:
            payload["tools"] = ollama_tools

        response = await self._client.post(
            f"{self._base_url}/api/chat", json=payload
        )
        response.raise_for_status()
        data = response.json()

        text = data.get("message", {}).get("content", "")
        tool_calls: list[ToolCallInfo] = []
        for tc in data.get("message", {}).get("tool_calls", []):
            fn = tc.get("function", {})
            tool_calls.append(
                ToolCallInfo(
                    id=fn.get("name", ""),
                    name=fn.get("name", ""),
                    args=fn.get("arguments", {}),
                )
            )

        # Ollama reports token counts at the top level
        input_tokens = data.get("prompt_eval_count", 0)
        output_tokens = data.get("eval_count", 0)
        usage = TokenUsage(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
        )

        return ProviderResponse(
            text=text,
            usage=usage,
            tool_calls=tool_calls,
            raw=data,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ProviderEvent, None]:
        """Stream a completion from the Ollama chat API.

        Parameters
        ----------
        messages:
            Conversation history.
        tools:
            Optional tool schemas.
        **kwargs:
            Extra options (``temperature``, ``num_predict``, etc.).
        """
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "stream": True,
            **kwargs,
        }

        ollama_tools = self._build_tools(tools)
        if ollama_tools is not None:
            payload["tools"] = ollama_tools

        input_tokens = 0
        output_tokens = 0

        try:
            async with self._client.stream(
                "POST", f"{self._base_url}/api/chat", json=payload
            ) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.strip():
                        continue
                    chunk = json.loads(line)

                    # Token counts from the final chunk
                    if chunk.get("done", False):
                        input_tokens = chunk.get("prompt_eval_count", 0)
                        output_tokens = chunk.get("eval_count", 0)

                    # Text content
                    content = chunk.get("message", {}).get("content", "")
                    if content:
                        yield TextChunkEvent(text=content)

                    # Tool calls (emitted in the final chunk)
                    for tc in chunk.get("message", {}).get("tool_calls", []):
                        fn = tc.get("function", {})
                        yield ToolCallChunkEvent(
                            id=fn.get("name", ""),
                            name=fn.get("name", ""),
                            args=fn.get("arguments", {}),
                        )

            yield ProviderDoneEvent(
                usage=TokenUsage(
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                )
            )
        except Exception as exc:
            yield ProviderErrorEvent(error=exc)
