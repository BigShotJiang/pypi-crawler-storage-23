"""Retry logic with exponential backoff for transient provider errors.

The ``RetryHandler`` wraps provider calls at the Agent layer, catching
HTTP 429 (rate-limit) and 5xx (server error) responses and retrying with
exponential backoff plus jitter.  It also retries on ``ConnectionError``
and ``TimeoutError`` which indicate transient network issues.
"""

from __future__ import annotations

import asyncio
import random
from collections.abc import Awaitable, Callable
from typing import TypeVar

import httpx

T = TypeVar("T")


class RetryHandler:
    """Execute async callables with automatic retry on transient errors.

    Parameters
    ----------
    max_retries:
        Maximum number of retry attempts before re-raising the error.
    retry_backoff:
        Base delay in seconds for exponential backoff calculation.

    Examples
    --------
    >>> handler = RetryHandler(max_retries=3, retry_backoff=1.0)
    >>> result = await handler.execute(provider.complete, messages)
    """

    def __init__(self, max_retries: int = 3, retry_backoff: float = 1.0) -> None:
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff

    async def execute(self, fn: Callable[..., Awaitable[T]], *args: object, **kwargs: object) -> T:
        """Execute *fn* with retry logic for transient errors.

        Catches ``httpx.HTTPStatusError`` for status codes 429 and >= 500,
        as well as ``ConnectionError`` and ``TimeoutError``.  On each retry
        the delay follows ``retry_backoff * 2^attempt + jitter`` where
        jitter is ``random.uniform(0, 0.5 * base_delay)``.

        After exhausting *max_retries*, the last caught exception is
        re-raised.

        Parameters
        ----------
        fn:
            An async callable to execute.
        *args:
            Positional arguments forwarded to *fn*.
        **kwargs:
            Keyword arguments forwarded to *fn*.

        Returns
        -------
        T
            The return value of *fn* on success.
        """
        last_exc: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                return await fn(*args, **kwargs)
            except httpx.HTTPStatusError as exc:
                if not self._is_retryable_status(exc.response.status_code):
                    raise
                last_exc = exc
            except (ConnectionError, TimeoutError) as exc:
                last_exc = exc

            # Don't sleep after the final attempt
            if attempt < self.max_retries:
                delay = self._calculate_delay(attempt)
                await asyncio.sleep(delay)

        # All retries exhausted — re-raise the last exception
        raise last_exc  # type: ignore[misc]

    def _calculate_delay(self, attempt: int) -> float:
        """Return the backoff delay for the given attempt number.

        Formula: ``retry_backoff * 2^attempt + jitter``
        where jitter is ``random.uniform(0, 0.5 * base_delay)``.
        """
        base_delay = self.retry_backoff * (2 ** attempt)
        jitter = random.uniform(0, 0.5 * base_delay)
        return base_delay + jitter

    @staticmethod
    def _is_retryable_status(status_code: int) -> bool:
        """Return whether the HTTP status code is retryable."""
        return status_code == 429 or status_code >= 500
