"""Built-in web search tool using Brave Search API.

Provides a ready-to-use ``@tool``-decorated function that performs
real web searches via the Brave Search API.  Requires a
``BRAVE_API_KEY`` environment variable (free tier available at
https://brave.com/search/api/).

Falls back to a ``SERPAPI_API_KEY`` + SerpAPI if Brave is not
configured, and finally to a ``TAVILY_API_KEY`` + Tavily if neither
is available.  Raises ``SynthConfigError`` if no search provider is
configured.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from synth.errors import SynthConfigError
from synth.tools.decorator import tool

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

_SEARCH_TIMEOUT = 15.0


def _search_brave(query: str, limit: int) -> list[dict[str, str]]:
    """Execute a search via the Brave Search API."""
    import httpx

    api_key = os.environ["BRAVE_API_KEY"]
    resp = httpx.get(
        "https://api.search.brave.com/res/v1/web/search",
        params={"q": query, "count": limit},
        headers={
            "Accept": "application/json",
            "X-Subscription-Token": api_key,
        },
        timeout=_SEARCH_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()

    results: list[dict[str, str]] = []
    for item in data.get("web", {}).get("results", [])[:limit]:
        results.append({
            "title": item.get("title", ""),
            "url": item.get("url", ""),
            "snippet": item.get("description", ""),
        })
    return results


def _search_serpapi(query: str, limit: int) -> list[dict[str, str]]:
    """Execute a search via SerpAPI."""
    import httpx

    api_key = os.environ["SERPAPI_API_KEY"]
    resp = httpx.get(
        "https://serpapi.com/search",
        params={
            "q": query,
            "num": limit,
            "api_key": api_key,
            "engine": "google",
        },
        timeout=_SEARCH_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()

    results: list[dict[str, str]] = []
    for item in data.get("organic_results", [])[:limit]:
        results.append({
            "title": item.get("title", ""),
            "url": item.get("link", ""),
            "snippet": item.get("snippet", ""),
        })
    return results


def _search_tavily(query: str, limit: int) -> list[dict[str, str]]:
    """Execute a search via Tavily Search API."""
    import httpx

    api_key = os.environ["TAVILY_API_KEY"]
    resp = httpx.post(
        "https://api.tavily.com/search",
        json={
            "query": query,
            "max_results": limit,
            "api_key": api_key,
        },
        timeout=_SEARCH_TIMEOUT,
    )
    resp.raise_for_status()
    data = resp.json()

    results: list[dict[str, str]] = []
    for item in data.get("results", [])[:limit]:
        results.append({
            "title": item.get("title", ""),
            "url": item.get("url", ""),
            "snippet": item.get("content", ""),
        })
    return results


# ---------------------------------------------------------------------------
# Provider resolution
# ---------------------------------------------------------------------------

_PROVIDERS: list[tuple[str, Any]] = [
    ("BRAVE_API_KEY", _search_brave),
    ("SERPAPI_API_KEY", _search_serpapi),
    ("TAVILY_API_KEY", _search_tavily),
]


def _resolve_provider() -> tuple[str, Any]:
    """Return ``(env_var_name, search_fn)`` for the first configured provider."""
    for env_var, fn in _PROVIDERS:
        if os.environ.get(env_var):
            return env_var, fn
    raise SynthConfigError(
        message="No web search API key configured.",
        component="web_search",
        suggestion=(
            "Set one of: BRAVE_API_KEY (https://brave.com/search/api/), "
            "SERPAPI_API_KEY (https://serpapi.com/), or "
            "TAVILY_API_KEY (https://tavily.com/)."
        ),
    )


# ---------------------------------------------------------------------------
# @tool function
# ---------------------------------------------------------------------------


@tool
def web_search(query: str, limit: int = 5) -> str:
    """Search the web and return results with titles, URLs, and snippets.

    Automatically uses whichever search provider is configured via
    environment variables (BRAVE_API_KEY, SERPAPI_API_KEY, or
    TAVILY_API_KEY).

    Parameters
    ----------
    query:
        The search query string.
    limit:
        Maximum number of results to return.  Defaults to ``5``.

    Returns
    -------
    str
        Formatted search results, one per line.
    """
    env_var, search_fn = _resolve_provider()
    logger.debug("web_search using provider: %s", env_var)

    try:
        results = search_fn(query, limit)
    except Exception as exc:
        logger.warning("Web search failed: %s", exc)
        return f"Web search failed: {exc}"

    if not results:
        return f"No results found for: {query}"

    lines: list[str] = []
    for i, r in enumerate(results, 1):
        lines.append(
            f"{i}. {r['title']}\n"
            f"   URL: {r['url']}\n"
            f"   {r['snippet']}"
        )
    return "\n\n".join(lines)
