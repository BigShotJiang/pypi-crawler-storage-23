"""AgentCore handler for the Synth SDK.

Wraps a Synth ``Agent`` or ``Graph`` into an AWS AgentCore-compatible
handler using the BedrockAgentCoreApp pattern required by the AgentCore runtime.
"""

from __future__ import annotations

from typing import Any

from synth.errors import SynthConfigError


def agentcore_handler(agent_or_graph: Any) -> Any:
    """Wrap an Agent or Graph into an AgentCore-compatible handler.

    This function creates a BedrockAgentCoreApp instance and registers
    the Synth agent as an entrypoint, following the AgentCore deployment
    pattern.

    Parameters
    ----------
    agent_or_graph:
        A Synth ``Agent`` or ``Graph`` instance.

    Returns
    -------
    BedrockAgentCoreApp
        An AgentCore app instance with the agent registered as an entrypoint.

    Raises
    ------
    SynthConfigError
        If the bedrock-agentcore package is not installed.

    Examples
    --------
    >>> from synth import Agent
    >>> from synth.deploy.agentcore import agentcore_handler
    >>>
    >>> agent = Agent(model="bedrock/claude-sonnet-4-5")
    >>> handler = agentcore_handler(agent)
    """
    try:
        from bedrock_agentcore import BedrockAgentCoreApp
    except ImportError:
        raise SynthConfigError(
            message="Package 'bedrock-agentcore' is not installed. "
            "Run: pip install synth-agent-sdk[agentcore]",
            component="agentcore_handler",
            suggestion="pip install synth-agent-sdk[agentcore]",
        )

    from synth.deploy.agentcore.adapter import AgentCoreAdapter

    # Create the AgentCore app
    app = BedrockAgentCoreApp()

    # Create adapter for payload translation
    adapter = AgentCoreAdapter(agent_or_graph)

    # Register the entrypoint using the decorator pattern.
    # context is the AgentCore RequestContext — passed through so the
    # adapter can extract user identity from the validated JWT token.
    @app.entrypoint
    def handler(payload: dict[str, Any], context: Any | None = None) -> dict[str, Any]:
        """AgentCore invocation handler."""
        return adapter.handle_invocation(payload, context)

    # Store reference to adapter for testing/debugging
    app._synth_adapter = adapter  # type: ignore[attr-defined]
    app._synth_handler = handler  # type: ignore[attr-defined]

    return app
