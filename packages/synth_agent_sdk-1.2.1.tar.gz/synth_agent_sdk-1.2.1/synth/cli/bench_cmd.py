"""``synth bench`` command — benchmark agent performance.

Runs an agent N times with a given prompt and reports latency
percentiles (p50, p95, p99), token usage, and cost statistics.
"""

from __future__ import annotations

import statistics
import sys
import time

import click

from synth.errors import SynthError


def run_bench(
    file: str,
    prompt: str,
    runs: int,
    warmup: int,
) -> None:
    """Benchmark an agent over multiple runs.

    Parameters
    ----------
    file:
        Path to the agent module.
    prompt:
        The prompt to send on each run.
    runs:
        Number of benchmark runs.
    warmup:
        Number of warmup runs (not counted in stats).
    """
    from synth.cli.run_cmd import _load_agent

    try:
        agent = _load_agent(file)
    except SystemExit:
        return

    model = getattr(agent, "model", "unknown")

    click.echo("")
    click.echo(click.style("  SYNTH BENCH", fg="green", bold=True))
    click.echo(click.style(f"  Model: {model}", dim=True))
    click.echo(click.style(
        f"  Runs: {runs} (+{warmup} warmup)",
        dim=True,
    ))
    click.echo(click.style(
        f'  Prompt: "{prompt[:50]}..."' if len(prompt) > 50
        else f'  Prompt: "{prompt}"',
        dim=True,
    ))
    click.echo("")

    # Warmup
    if warmup > 0:
        click.echo(
            click.style(f"  Warming up ({warmup} runs)...", dim=True),
        )
        for i in range(warmup):
            try:
                agent.run(prompt)
                click.echo(
                    click.style(f"    warmup {i + 1}/{warmup}", dim=True),
                )
            except Exception:
                pass

    # Benchmark runs
    latencies: list[float] = []
    token_counts: list[int] = []
    costs: list[float] = []
    errors = 0

    click.echo(click.style("  Running benchmark...", fg="green"))
    click.echo("")

    for i in range(runs):
        start = time.perf_counter()
        try:
            result = agent.run(prompt)
            elapsed_ms = (time.perf_counter() - start) * 1000
            latencies.append(elapsed_ms)

            tokens = getattr(result, "tokens", None)
            total = (
                getattr(tokens, "total_tokens", 0)
                if tokens else 0
            )
            token_counts.append(total)
            costs.append(getattr(result, "cost", 0.0))

            status = click.style("[  OK  ]", fg="green")
            click.echo(
                f"    {status} Run {i + 1:>3}/{runs}  "
                f"{elapsed_ms:>8.0f}ms  "
                f"{total:>6} tokens  "
                f"${result.cost:.4f}",
            )

        except SynthError as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            errors += 1
            status = click.style("[FAIL]", fg="red")
            click.echo(
                f"    {status}  Run {i + 1:>3}/{runs}  "
                f"{elapsed_ms:>8.0f}ms  {exc}",
            )

        except Exception as exc:
            elapsed_ms = (time.perf_counter() - start) * 1000
            errors += 1
            status = click.style("[FAIL]", fg="red")
            click.echo(
                f"    {status}  Run {i + 1:>3}/{runs}  "
                f"{elapsed_ms:>8.0f}ms  {exc}",
            )

    # Report
    click.echo("")
    click.echo(click.style(
        "  " + "=" * 56,
        dim=True,
    ))
    click.echo(click.style("  RESULTS", fg="green", bold=True))
    click.echo(click.style(
        "  " + "=" * 56,
        dim=True,
    ))

    if not latencies:
        click.echo(click.style(
            "  All runs failed. No stats to report.",
            fg="red",
        ))
        sys.exit(1)

    # Latency stats
    sorted_lat = sorted(latencies)
    p50 = _percentile(sorted_lat, 50)
    p95 = _percentile(sorted_lat, 95)
    p99 = _percentile(sorted_lat, 99)
    avg_lat = statistics.mean(latencies)
    min_lat = min(latencies)
    max_lat = max(latencies)

    click.echo("")
    click.echo(click.style("  Latency (ms):", fg="cyan"))
    click.echo(f"    p50:  {p50:>10.0f}")
    click.echo(f"    p95:  {p95:>10.0f}")
    click.echo(f"    p99:  {p99:>10.0f}")
    click.echo(f"    avg:  {avg_lat:>10.0f}")
    click.echo(f"    min:  {min_lat:>10.0f}")
    click.echo(f"    max:  {max_lat:>10.0f}")

    # Token stats
    if token_counts:
        avg_tokens = statistics.mean(token_counts)
        total_tokens = sum(token_counts)
        click.echo("")
        click.echo(click.style("  Tokens:", fg="cyan"))
        click.echo(f"    avg:    {avg_tokens:>8.0f}")
        click.echo(f"    total:  {total_tokens:>8}")

    # Cost stats
    if costs:
        total_cost = sum(costs)
        avg_cost = statistics.mean(costs)
        click.echo("")
        click.echo(click.style("  Cost:", fg="cyan"))
        click.echo(f"    per run:  ${avg_cost:.4f}")
        click.echo(f"    total:    ${total_cost:.4f}")

    # Error rate
    click.echo("")
    click.echo(click.style("  Reliability:", fg="cyan"))
    success_rate = len(latencies) / runs * 100
    click.echo(f"    success:  {len(latencies)}/{runs} ({success_rate:.0f}%)")
    if errors:
        click.echo(
            click.style(f"    errors:   {errors}", fg="red"),
        )

    click.echo("")


def _percentile(sorted_data: list[float], pct: float) -> float:
    """Calculate the *pct*-th percentile from sorted data."""
    if not sorted_data:
        return 0.0
    k = (len(sorted_data) - 1) * (pct / 100.0)
    f = int(k)
    c = f + 1
    if c >= len(sorted_data):
        return sorted_data[f]
    d = k - f
    return sorted_data[f] + d * (sorted_data[c] - sorted_data[f])
