/* Synth Agent UI — app.js */

// ------------------------------------------------------------------ //
// DOM refs                                                            //
// ------------------------------------------------------------------ //
const chatArea       = document.getElementById("chat-area");
const chatForm       = document.getElementById("chat-form");
const promptInput    = document.getElementById("prompt-input");
const btnSend        = document.getElementById("btn-send");
const btnClear       = document.getElementById("btn-clear");
const btnReload      = document.getElementById("btn-reload");
const statusBadge    = document.getElementById("status");
const toolDrawer     = document.getElementById("tool-drawer");
const toolSelect     = document.getElementById("tool-select");
const toolDesc       = document.getElementById("tool-description");
const toolArgsEditor = document.getElementById("tool-args-editor");
const toolOutput     = document.getElementById("tool-output");
const convList       = document.getElementById("conv-list");
const topbarTitle    = document.getElementById("topbar-title");
const sidebar        = document.getElementById("sidebar");
const telemetryContent = document.getElementById("telemetry-content");
const telemetryEmpty   = document.getElementById("telemetry-empty");
const elapsedTimer     = document.getElementById("elapsed-timer");
const varBar           = document.getElementById("var-bar");

// ------------------------------------------------------------------ //
// State                                                               //
// ------------------------------------------------------------------ //
let isLoading      = false;
let currentConv    = "default";
let toolSchemas    = {};
let sessionTokens  = 0;
let sessionCost    = 0;
let turnCount      = 0;
let costHistory    = [];
let promptHistory  = [];
let historyIndex   = -1;
let reconnectTimer = null;
let elapsedInterval = null;
let activeTab      = "chat";
let editingScenarioId = null;

// ------------------------------------------------------------------ //
// Init                                                                //
// ------------------------------------------------------------------ //
async function init() {
    await Promise.all([loadAgentInfo(), loadTools(), loadConversations()]);
    autoResizeTextarea();
    initResizeHandle();
    initKeyboardShortcuts();
    initTabs();
    startHealthCheck();
    loadPrompts();
    loadEvals();
    loadScenarios();
    populateReplaySelect();
}

// ------------------------------------------------------------------ //
// Tabs                                                                //
// ------------------------------------------------------------------ //
function initTabs() {
    document.querySelectorAll(".tab").forEach(btn => {
        btn.addEventListener("click", () => switchTab(btn.dataset.tab));
    });
}

function switchTab(name) {
    activeTab = name;
    document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.toggle("active", c.id === "tab-" + name));
    if (name === "observe") populateReplaySelect();
    if (name === "config") { loadModels().then(() => loadConfig()); }
}

// ------------------------------------------------------------------ //
// Agent info / health                                                 //
// ------------------------------------------------------------------ //
async function loadAgentInfo() {
    try {
        const r = await fetch("/api/info");
        const d = await r.json();
        document.getElementById("info-model").textContent = d.model;
        document.getElementById("info-tools").textContent = d.tools;
        const memEl = document.getElementById("info-memory");
        if (memEl && d.memory) {
            if (d.memory.configured) {
                memEl.textContent = d.memory.type || "Active";
                memEl.className = "info-value ok";
            } else {
                memEl.textContent = "None";
                memEl.className = "info-value";
            }
        }
        // Multi-agent badge
        const maEl = document.getElementById("info-multi-agent");
        if (maEl && d.multi_agent) {
            const type = d.multi_agent.type;
            const count = (d.multi_agent.agents || d.multi_agent.stages || []).length;
            maEl.textContent = type + (count ? " (" + count + " agents)" : "");
            maEl.className = "info-value ok";
        } else if (maEl) {
            maEl.textContent = "Single";
            maEl.className = "info-value";
        }
        const statusEl = document.getElementById("info-status");
        if (d.status && d.status.loaded) {
            statusEl.textContent = "OK"; statusEl.className = "info-value ok";
        } else {
            statusEl.textContent = d.status && d.status.error ? "ERROR" : "—";
            statusEl.className = "info-value err";
        }
    } catch (e) { /* ignore */ }
}

async function loadTools() {
    try {
        const r = await fetch("/api/tools");
        const d = await r.json();
        toolSelect.innerHTML = '<option value="">Select a tool...</option>';
        for (const t of d.tools) {
            toolSchemas[t.name] = t;
            const opt = document.createElement("option");
            opt.value = t.name; opt.textContent = t.name;
            toolSelect.appendChild(opt);
        }
    } catch (e) { /* ignore */ }
}

async function loadConversations() {
    try {
        const r = await fetch("/api/conversations");
        const d = await r.json();
        renderConvList(d.conversations, d.current);
    } catch (e) { /* ignore */ }
}

function startHealthCheck() {
    setInterval(async () => {
        try {
            const r = await fetch("/api/health");
            if (r.ok && reconnectTimer) {
                clearTimeout(reconnectTimer); reconnectTimer = null;
                setStatus("CONNECTED", true); await loadAgentInfo();
            }
        } catch (e) {
            if (!reconnectTimer && !isLoading) {
                setStatus("DISCONNECTED", false);
                reconnectTimer = setTimeout(() => { reconnectTimer = null; }, 5000);
            }
        }
    }, 5000);
}

// ------------------------------------------------------------------ //
// Resize handle                                                       //
// ------------------------------------------------------------------ //
function initResizeHandle() {
    // Vertical resize between chat and telemetry
    const handleV = document.getElementById("resize-handle-v");
    const chatArea = document.getElementById("chat-area");
    const telemPanel = document.getElementById("telemetry-panel");
    if (handleV && chatArea && telemPanel) {
        let dragging = false, startY = 0, startChatH = 0, startTelemH = 0;
        handleV.addEventListener("mousedown", e => {
            dragging = true; startY = e.clientY;
            startChatH = chatArea.offsetHeight; startTelemH = telemPanel.offsetHeight;
            handleV.classList.add("dragging");
            document.body.style.cursor = "row-resize";
            document.body.style.userSelect = "none";
        });
        document.addEventListener("mousemove", e => {
            if (!dragging) return;
            const dy = e.clientY - startY;
            const newChatH = Math.max(100, startChatH + dy);
            const newTelemH = Math.max(80, startTelemH - dy);
            chatArea.style.height = newChatH + "px";
            chatArea.style.flex = "none";
            telemPanel.style.height = newTelemH + "px";
        });
        document.addEventListener("mouseup", () => {
            if (!dragging) return;
            dragging = false; handleV.classList.remove("dragging");
            document.body.style.cursor = ""; document.body.style.userSelect = "";
        });
    }
}

// ------------------------------------------------------------------ //
// Keyboard shortcuts                                                  //
// ------------------------------------------------------------------ //
function initKeyboardShortcuts() {
    document.addEventListener("keydown", e => {
        if (e.key === "/" && document.activeElement !== promptInput) {
            e.preventDefault(); promptInput.focus();
        }
    });
}

// ------------------------------------------------------------------ //
// Helpers                                                             //
// ------------------------------------------------------------------ //
function esc(text) {
    const d = document.createElement("div");
    d.textContent = String(text); return d.innerHTML;
}
function renderMarkdown(text) {
    if (typeof marked === "undefined") return "<p>" + esc(text) + "</p>";
    try { return marked.parse(text, { breaks: true, gfm: true }); }
    catch (e) { return "<p>" + esc(text) + "</p>"; }
}
function clearWelcome() { const w = document.getElementById("welcome"); if (w) w.remove(); }
function scrollToBottom() { chatArea.scrollTop = chatArea.scrollHeight; }
function setStatus(text, ok) {
    const dot   = statusBadge.querySelector(".status-dot");
    const label = statusBadge.querySelector(".status-text");
    label.textContent = text;
    const color = ok ? "var(--green)" : "var(--red)";
    dot.style.background = color; dot.style.boxShadow = "0 0 6px " + color;
    statusBadge.style.borderColor = ok ? "var(--green-dim)" : "var(--red)";
    statusBadge.style.color = color;
}
function startElapsedTimer() {
    let secs = 0; elapsedTimer.classList.remove("hidden"); elapsedTimer.textContent = "0s";
    elapsedInterval = setInterval(() => { secs++; elapsedTimer.textContent = secs + "s"; }, 1000);
}
function stopElapsedTimer() { clearInterval(elapsedInterval); elapsedTimer.classList.add("hidden"); }
function autoResizeTextarea() {
    promptInput.addEventListener("input", () => {
        promptInput.style.height = "auto";
        promptInput.style.height = Math.min(promptInput.scrollHeight, 120) + "px";
        detectVariables();
    });
}
function fmt(n)     { return typeof n === "number" ? n.toLocaleString() : "—"; }
function fmtCost(n) { return typeof n === "number" ? "$" + n.toFixed(6) : "—"; }
function fmtMs(n)   { return typeof n === "number" ? n.toFixed(0) + "ms" : "—"; }

// ------------------------------------------------------------------ //
// Variable injection                                                  //
// ------------------------------------------------------------------ //
function detectVariables() {
    const text = promptInput.value;
    const vars = [...new Set([...text.matchAll(/\{\{(\w+)\}\}/g)].map(m => m[1]))];
    varBar.innerHTML = "";
    for (const v of vars) {
        const chip = document.createElement("div");
        chip.className = "var-chip";
        chip.innerHTML = `<span class="var-chip-label">{{${v}}}</span>`;
        const inp = document.createElement("input");
        inp.className = "var-chip-input"; inp.placeholder = "value..."; inp.dataset.var = v;
        chip.appendChild(inp); varBar.appendChild(chip);
    }
}

function resolveVariables(text) {
    return text.replace(/\{\{(\w+)\}\}/g, (_, name) => {
        const inp = varBar.querySelector(`[data-var="${name}"]`);
        return inp ? inp.value || `{{${name}}}` : `{{${name}}}`;
    });
}

// ------------------------------------------------------------------ //
// Conversations                                                       //
// ------------------------------------------------------------------ //
function renderConvList(ids, active) {
    convList.innerHTML = "";
    for (const id of ids) {
        const el = document.createElement("div");
        el.className = "conv-item" + (id === active ? " active" : "");
        const name = document.createElement("span");
        name.className = "conv-item-name"; name.textContent = id;
        name.onclick = () => switchConv(id);
        el.appendChild(name);
        if (id !== "default") {
            const del = document.createElement("button");
            del.className = "conv-delete"; del.textContent = "x"; del.title = "Delete";
            del.onclick = e => { e.stopPropagation(); deleteConv(id); };
            el.appendChild(del);
        }
        convList.appendChild(el);
    }
    currentConv = active; topbarTitle.textContent = active;
}

async function switchConv(id) {
    currentConv = id; topbarTitle.textContent = id;
    document.querySelectorAll(".conv-item").forEach(el => {
        const n = el.querySelector(".conv-item-name");
        el.classList.toggle("active", n && n.textContent === id);
    });
    chatArea.innerHTML = "";
    sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
    try {
        const r = await fetch("/api/conversations/" + id);
        const d = await r.json();
        for (const msg of d.messages) {
            if (msg.role === "user") addUserMessage(msg.content);
            else if (msg.role === "agent") addAgentMessage(msg.data, false);
        }
    } catch (e) { /* ignore */ }
}

async function newConversation() {
    try {
        const r = await fetch("/api/conversations", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
        });
        await r.json(); await loadConversations();
        chatArea.innerHTML = "";
        sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
        telemetryContent.classList.add("hidden"); telemetryEmpty.classList.remove("hidden");
    } catch (e) { /* ignore */ }
}

async function deleteConv(id) {
    try {
        await fetch("/api/conversations/" + id, { method: "DELETE" });
        if (currentConv === id) { currentConv = "default"; chatArea.innerHTML = ""; }
        await loadConversations();
    } catch (e) { /* ignore */ }
}

// ------------------------------------------------------------------ //
// Messages                                                            //
// ------------------------------------------------------------------ //
function addUserMessage(text) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-user";
    const copyBtn = `<button class="msg-copy" onclick="copyMsg(this, ${JSON.stringify(esc(text))})">copy</button>`;
    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-user">YOU</span>${copyBtn}</div><div class="msg-body">${esc(text)}</div>`;
    chatArea.appendChild(div); scrollToBottom();
}

function addAgentMessage(data, animate = true) {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-agent";
    const hasStructured = data.output && typeof data.output === "object";
    const bodyHtml = hasStructured
        ? _renderStructuredOutput(data.output)
        : renderMarkdown(data.text || "");
    const copyText = hasStructured ? JSON.stringify(data.output, null, 2) : (data.text || "");
    const copyBtn = `<button class="msg-copy" onclick="copyMsg(this, ${JSON.stringify(esc(copyText))})">copy</button>`;

    // Build cot-block for tool calls and/or thinking if present
    const toolCalls = data.tool_calls && data.tool_calls.length > 0 ? data.tool_calls : null;
    const thinkingText = data.thinking || null;
    const hasCot = toolCalls || thinkingText;
    const cotHtml = hasCot
        ? `<button class="cot-toggle" onclick="toggleCot(this.closest('.msg-agent'))">▶ show reasoning</button>` +
          `<div class="cot-block hidden">` +
          (thinkingText
              ? `<div class="thinking-block">` +
                    `<div class="thinking-header" onclick="toggleThinking()">` +
                        `<span class="thinking-label">Thought process (click to expand)</span>` +
                        `<span class="thinking-toggle">▶</span>` +
                    `</div>` +
                    `<div class="thinking-body hidden">${renderMarkdown(thinkingText)}</div>` +
                `</div>`
              : "") +
          (toolCalls
              ? `<div class="tool-calls-block">` +
                toolCalls.map(tc => {
                    const argsStr = tc.args && Object.keys(tc.args).length > 0 ? JSON.stringify(tc.args, null, 2) : "";
                    const isSearch = _isSearchTool(tc.name);
                    const searchQuery = isSearch && tc.args && (tc.args.query || tc.args.q || tc.args.search_query || Object.values(tc.args)[0]);
                    const headerLabel = isSearch && searchQuery
                        ? `<span class="tool-call-name">${esc(tc.name)}</span><span class="tool-call-query">${esc(String(searchQuery))}</span>`
                        : `<span class="tool-call-name">${esc(tc.name)}</span>`;
                    const iconSvg = isSearch
                        ? `<svg class="tool-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>`
                        : `<svg class="tool-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`;
                    const id = "tc-hist-" + Math.random().toString(36).slice(2);
                    const resultStr = tc.result ? String(tc.result) : "";
                    const isLong = resultStr.length > 600;
                    const previewText = isLong ? resultStr.slice(0, 600) : resultStr;
                    return `<div class="tool-call-inline${isSearch ? " tool-call-search" : ""}" id="${id}">` +
                        `<div class="tool-call-header" onclick="toggleToolCall('${id}')">` +
                            iconSvg + headerLabel +
                            `<span class="tool-call-status done">done</span>` +
                            `<span class="tool-call-toggle">▼</span>` +
                        `</div>` +
                        `<div class="tool-call-body">` +
                            (argsStr ? `<div class="tool-call-args"><div class="tool-call-section-label">Arguments</div><pre>${esc(argsStr)}</pre></div>` : "") +
                            (resultStr ? `<div class="tool-call-result-area"><div class="tool-call-section-label">Result</div><pre class="tool-call-result-text">${esc(previewText)}${isLong ? "<span class='result-truncated'>…</span>" : ""}</pre></div>` : "") +
                        `</div>` +
                    `</div>`;
                }).join("") +
                `</div>`
              : "") +
          `</div>`
        : "";

    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-agent">AGENT</span>${copyBtn}</div><div class="msg-body">${bodyHtml}</div>${cotHtml}`;
    chatArea.appendChild(div); scrollToBottom();
    if (animate) updateTelemetry(data);
}

function addStreamingMessage() {
    clearWelcome();
    const div = document.createElement("div");
    div.className = "message msg-agent"; div.id = "streaming-msg";
    div.innerHTML =
        `<div class="msg-header"><span class="msg-label msg-label-agent">AGENT</span></div>` +
        `<div class="msg-body" id="streaming-body"><span class="stream-cursor"></span></div>` +
        `<div id="cot-block" class="cot-block hidden">` +
            `<div id="thinking-block" class="thinking-block hidden">` +
                `<div class="thinking-header" onclick="toggleThinking()">` +
                    `<span class="thinking-dots"><span></span><span></span><span></span></span>` +
                    `<span class="thinking-label">Thinking...</span>` +
                    `<span class="thinking-toggle">&#x25BC;</span>` +
                `</div>` +
                `<div class="thinking-body" id="thinking-body"></div>` +
            `</div>` +
        `</div>`;
    chatArea.appendChild(div); scrollToBottom(); return div;
}

function updateStreamingMessage(text) {
    const body = document.getElementById("streaming-body");
    if (body) { body.innerHTML = renderMarkdown(text) + '<span class="stream-cursor"></span>'; scrollToBottom(); }
}

function updateThinking(text) {
    const cotBlock = document.getElementById("cot-block");
    const block = document.getElementById("thinking-block");
    const body  = document.getElementById("thinking-body");
    if (!block || !body) return;
    if (cotBlock) cotBlock.classList.remove("hidden");
    block.classList.remove("hidden");
    block.classList.add("thinking-active");
    // Accumulate raw text; use a <pre>-style text node to avoid markdown flicker mid-stream
    body.dataset.raw = (body.dataset.raw || "") + text;
    body.textContent = body.dataset.raw;
    scrollToBottom();
}

function _isSearchTool(name) {
    return /search|web_search|browse|fetch|lookup/i.test(name);
}

function addToolCallInline(name, args, agentName) {
    const block = document.getElementById("tool-calls-block");
    if (!block) return;
    // Ensure the cot-block is visible when tool calls arrive
    const cotBlock = document.getElementById("cot-block");
    if (cotBlock) cotBlock.classList.remove("hidden");
    const id = "tc-" + Date.now();
    const argsStr = args && Object.keys(args).length > 0
        ? JSON.stringify(args, null, 2) : "";
    const isSearch = _isSearchTool(name);
    // For search tools, show the query prominently
    const searchQuery = isSearch && args && (args.query || args.q || args.search_query || Object.values(args)[0]);
    const el = document.createElement("div");
    el.className = "tool-call-inline" + (isSearch ? " tool-call-search" : "");
    el.id = id;

    const iconSvg = isSearch
        ? `<svg class="tool-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>`
        : `<svg class="tool-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`;

    const headerLabel = isSearch && searchQuery
        ? `<span class="tool-call-name">${esc(name)}</span><span class="tool-call-query">${esc(String(searchQuery))}</span>`
        : `<span class="tool-call-name">${esc(name)}</span>`;

    el.innerHTML =
        `<div class="tool-call-header" onclick="toggleToolCall('${id}')">` +
            iconSvg +
            headerLabel +
            `<span class="tool-call-status"><span class="tool-status-spinner"></span>running</span>` +
            `<span class="tool-call-toggle">▼</span>` +
        `</div>` +
        `<div class="tool-call-body">` +
            (argsStr ? `<div class="tool-call-args"><div class="tool-call-section-label">Arguments</div><pre>${esc(argsStr)}</pre></div>` : "") +
            `<div class="tool-call-result-area" id="${id}-result"></div>` +
        `</div>`;
    block.appendChild(el);
    scrollToBottom();
    return id;
}

function addToolResultInline(name, result, agentName) {
    const block = document.getElementById("tool-calls-block");
    if (!block) return;
    const calls = block.querySelectorAll(".tool-call-inline");
    for (let i = calls.length - 1; i >= 0; i--) {
        const call = calls[i];
        const nameEl = call.querySelector(".tool-call-name");
        const resultArea = call.querySelector(".tool-call-result-area");
        if (nameEl && nameEl.textContent === name && resultArea && !resultArea.hasChildNodes()) {
            const statusEl = call.querySelector(".tool-call-status");
            if (statusEl) { statusEl.innerHTML = "done"; statusEl.className = "tool-call-status done"; }
            const body = call.querySelector(".tool-call-body");
            if (body) body.classList.remove("hidden");
            const toggle = call.querySelector(".tool-call-toggle");
            if (toggle) toggle.textContent = "▼";

            const resultStr = String(result);
            const isSearch = call.classList.contains("tool-call-search");
            const isLong = resultStr.length > 600;
            const previewText = isLong ? resultStr.slice(0, 600) : resultStr;
            const resultId = call.id + "-result";

            // For search tools: show the smart preview prominently,
            // then the raw result in a collapsible section below.
            const resultPreview = isSearch
                ? `<div class="tool-call-search-summary">${_summarizeSearchResult(resultStr)}</div>`
                : "";

            // For search tools with a preview, default the raw result to hidden
            const rawHidden = isSearch ? " hidden" : "";

            resultArea.innerHTML =
                resultPreview +
                `<div class="tool-call-section-label tool-call-raw-toggle${isSearch ? " tool-call-raw-toggle-search" : ""}"` +
                (isSearch ? ` onclick="this.nextElementSibling.classList.toggle('hidden');this.textContent=this.nextElementSibling.classList.contains('hidden')?'Raw result ▶':'Raw result ▼'" style="cursor:pointer"` : "") +
                `>${isSearch ? "Raw result ▶" : "Result"}</div>` +
                `<pre class="tool-call-result-text${rawHidden}" id="${resultId}-pre">${esc(previewText)}${isLong ? `<span class="result-truncated">…</span>` : ""}</pre>` +
                (isLong ? `<button class="result-show-more" id="${resultId}-btn" onclick="toggleResultExpand('${resultId}')">show more</button>` : "");

            // Store full text on the element to avoid escaping issues
            if (isLong) {
                const pre = resultArea.querySelector(`#${resultId}-pre`);
                if (pre) pre.dataset.full = resultStr;
            }
            scrollToBottom();
            return;
        }
    }
}

// ------------------------------------------------------------------ //
// MULTI-AGENT DELEGATION VISUALIZATION                                //
// ------------------------------------------------------------------ //

function addAgentDelegation(agentName, phase, data) {
    const cotBlock = document.getElementById("cot-block");
    const toolBlock = document.getElementById("tool-calls-block");
    if (!cotBlock || !toolBlock) return;
    cotBlock.classList.remove("hidden");

    if (phase === "start") {
        const id = "delegation-" + agentName.replace(/\W/g, "_");
        const existing = document.getElementById(id);
        if (existing) return;
        const card = document.createElement("div");
        card.className = "agent-delegation-card active";
        card.id = id;
        card.innerHTML =
            `<div class="agent-delegation-header">` +
                `<span class="agent-delegation-icon">` +
                    `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">` +
                        `<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>` +
                        `<circle cx="12" cy="7" r="4"/>` +
                    `</svg>` +
                `</span>` +
                `<span class="agent-delegation-name">${esc(agentName)}</span>` +
                `<span class="agent-delegation-status running">running</span>` +
            `</div>` +
            `<div class="agent-delegation-body">` +
                `<div class="agent-delegation-tools"></div>` +
            `</div>`;
        toolBlock.appendChild(card);
        scrollToBottom();
    } else if (phase === "complete") {
        const id = "delegation-" + agentName.replace(/\W/g, "_");
        const card = document.getElementById(id);
        if (card) {
            card.classList.remove("active");
            card.classList.add("completed");
            const status = card.querySelector(".agent-delegation-status");
            if (status) {
                status.className = "agent-delegation-status done";
                status.textContent = "done";
            }
            if (data) {
                const body = card.querySelector(".agent-delegation-body");
                if (body && data.text) {
                    const preview = data.text.length > 300 ? data.text.substring(0, 300) + "..." : data.text;
                    const meta = [];
                    if (data.latency_ms) meta.push(data.latency_ms.toFixed(0) + "ms");
                    if (data.cost) meta.push("$" + data.cost.toFixed(6));
                    body.innerHTML +=
                        `<div class="agent-delegation-output">${esc(preview)}</div>` +
                        (meta.length ? `<div class="agent-delegation-meta">${meta.join(" \u00b7 ")}</div>` : "");
                }
            }
        }
        scrollToBottom();
    }
}

function renderMultiAgentContributions(data) {
    if (!data || !data.multi_agent || !data.multi_agent.contributions) return "";
    const contributions = data.multi_agent.contributions;
    const type = data.multi_agent.type || "team";
    const typeLabel = type === "team" ? "Agent Team" : type === "pipeline" ? "Pipeline" : "Graph";

    let html = `<div class="multi-agent-panel">`;
    html += `<div class="multi-agent-header">`;
    html += `<span class="multi-agent-type">${esc(typeLabel)}</span>`;
    html += `<span class="multi-agent-count">${contributions.length} agent${contributions.length !== 1 ? "s" : ""}</span>`;
    html += `</div>`;
    html += `<div class="multi-agent-swimlane">`;

    for (const c of contributions) {
        const toolCount = (c.tool_calls || []).length;
        const preview = (c.text || "").substring(0, 200);
        const meta = [];
        if (c.latency_ms) meta.push(c.latency_ms.toFixed(0) + "ms");
        if (c.cost) meta.push("$" + c.cost.toFixed(6));
        if (c.tokens) meta.push(c.tokens.total + " tok");

        html += `<div class="swimlane-card">`;
        html += `<div class="swimlane-card-header">`;
        html += `<span class="swimlane-agent-name">${esc(c.agent_name)}</span>`;
        if (toolCount > 0) html += `<span class="swimlane-tool-badge">${toolCount} tool${toolCount !== 1 ? "s" : ""}</span>`;
        html += `</div>`;
        if (preview) html += `<div class="swimlane-card-body">${esc(preview)}${c.text && c.text.length > 200 ? "..." : ""}</div>`;
        if (meta.length) html += `<div class="swimlane-card-meta">${meta.join(" \u00b7 ")}</div>`;

        if (toolCount > 0) {
            html += `<div class="swimlane-tools">`;
            for (const tc of c.tool_calls) {
                html += `<div class="swimlane-tool-item">`;
                html += `<span class="swimlane-tool-name">${esc(tc.name)}</span>`;
                if (tc.latency_ms) html += `<span class="swimlane-tool-time">${tc.latency_ms.toFixed(0)}ms</span>`;
                html += `</div>`;
            }
            html += `</div>`;
        }
        html += `</div>`;
    }

    html += `</div></div>`;
    return html;
}

function toggleResultExpand(resultId) {
    const pre = document.getElementById(resultId + "-pre");
    const btn = document.getElementById(resultId + "-btn");
    if (!pre) return;
    const expanded = pre.dataset.expanded === "true";
    if (expanded) {
        const preview = (pre.dataset.full || "").slice(0, 600);
        pre.innerHTML = esc(preview) + `<span class="result-truncated">…</span>`;
        pre.dataset.expanded = "false";
        if (btn) btn.textContent = "show more";
    } else {
        pre.innerHTML = esc(pre.dataset.full || "");
        pre.dataset.expanded = "true";
        if (btn) btn.textContent = "show less";
    }
    scrollToBottom();
}

function _summarizeSearchResult(result) {
    const str = String(result);
    // Try to extract meaningful snippets: titles, URLs, or first sentences
    const lines = str.split("\n").map(l => l.trim()).filter(l => l.length > 20);
    const snippets = [];

    // Look for URL lines
    const urlLines = lines.filter(l => /https?:\/\//i.test(l)).slice(0, 2);
    // Look for content lines (not just URLs, not JSON keys)
    const contentLines = lines
        .filter(l => !/^[\{\}\[\],]/.test(l) && !/https?:\/\//i.test(l) && l.length > 30)
        .slice(0, 2);

    for (const u of urlLines) {
        const url = u.match(/https?:\/\/[^\s"')]+/);
        if (url) snippets.push(`<span class="search-result-url">&#x1F517; ${esc(url[0].substring(0, 60))}${url[0].length > 60 ? "…" : ""}</span>`);
    }
    for (const c of contentLines) {
        const preview = c.length > 100 ? c.substring(0, 100) + "…" : c;
        snippets.push(`<span class="search-result-snippet">${esc(preview)}</span>`);
    }

    const lineCount = lines.length;
    const countHint = `<span class="search-result-hint">&#x2713; ${lineCount} line${lineCount !== 1 ? "s" : ""} returned</span>`;

    return snippets.length
        ? `<div class="search-result-preview">${countHint}${snippets.map(s => `<div>${s}</div>`).join("")}</div>`
        : `<div class="search-result-preview">${countHint}</div>`;
}

function toggleToolCall(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const body = el.querySelector(".tool-call-body");
    const toggle = el.querySelector(".tool-call-toggle");
    if (body) {
        const collapsed = body.classList.toggle("hidden");
        if (toggle) toggle.textContent = collapsed ? "▶" : "▼";
    }
}

function _renderStructuredOutput(output) {
    const fields = Object.entries(output);
    const mainField = fields.find(([k]) => k === "answer" || k === "text" || k === "response" || k === "content" || k === "message");
    const metaFields = fields.filter(([k]) => k !== (mainField ? mainField[0] : null));

    let html = `<div class="structured-output-card">`;
    if (mainField) {
        html += `<div class="structured-main-text">${renderMarkdown(String(mainField[1]))}</div>`;
    }
    if (metaFields.length) {
        html += `<div class="structured-meta">`;
        for (const [k, v] of metaFields) {
            const isNum = typeof v === "number";
            const isBool = typeof v === "boolean";
            const isObj = typeof v === "object" && v !== null;
            let valHtml;
            if (isNum && k.toLowerCase().includes("confidence")) {
                const pct = v <= 1 ? Math.round(v * 100) : Math.round(v);
                valHtml = `<div class="structured-confidence-wrap"><div class="structured-confidence-bar" style="width:${pct}%"></div></div><span class="structured-meta-val">${pct}%</span>`;
            } else if (isObj) {
                valHtml = `<span class="structured-meta-val structured-meta-json">${esc(JSON.stringify(v))}</span>`;
            } else {
                valHtml = `<span class="structured-meta-val ${isBool ? (v ? "meta-true" : "meta-false") : ""}">${esc(String(v))}</span>`;
            }
            html += `<div class="structured-meta-row"><span class="structured-meta-key">${esc(k)}</span>${valHtml}</div>`;
        }
        html += `</div>`;
    }
    if (!mainField) {
        html = `<div class="structured-output-card"><div class="structured-meta">`;
        for (const [k, v] of fields) {
            const isObj = typeof v === "object" && v !== null;
            const valHtml = isObj
                ? `<span class="structured-meta-val structured-meta-json">${esc(JSON.stringify(v))}</span>`
                : `<span class="structured-meta-val">${esc(String(v))}</span>`;
            html += `<div class="structured-meta-row"><span class="structured-meta-key">${esc(k)}</span>${valHtml}</div>`;
        }
        html += `</div>`;
    }
    html += `</div>`;
    return html;
}

function toggleThinking() {
    const body   = document.getElementById("thinking-body");
    const toggle = document.querySelector("#thinking-block .thinking-toggle");
    if (!body) return;
    const collapsed = body.classList.toggle("hidden");
    if (toggle) toggle.textContent = collapsed ? "▶" : "▼";
}

function collapseThinking() {
    const block  = document.getElementById("thinking-block");
    const body   = document.getElementById("thinking-body");
    const toggle = document.querySelector("#thinking-block .thinking-toggle");
    const label  = document.querySelector("#thinking-block .thinking-label");
    const dots   = document.querySelector("#thinking-block .thinking-dots");
    if (block)  block.classList.remove("thinking-active");
    // Render markdown now that the full thinking text is accumulated
    if (body && body.dataset.raw) body.innerHTML = renderMarkdown(body.dataset.raw);
    if (body)   body.classList.add("hidden");
    if (toggle) toggle.textContent = "▶";
    if (label)  label.textContent = "Thought process (click to expand)";
    if (dots)   dots.style.display = "none";
    // Note: cot-block visibility is managed by finalizeStreamingMessage
}

function toggleCot(msgDiv) {
    const cotBlock = msgDiv.querySelector(".cot-block");
    if (!cotBlock) return;
    const toggle = msgDiv.querySelector(".cot-toggle");
    const collapsed = cotBlock.classList.toggle("hidden");
    if (toggle) toggle.textContent = collapsed ? "▶ show reasoning" : "▼ hide reasoning";
}

function finalizeStreamingMessage(data) {
    const div  = document.getElementById("streaming-msg");
    if (div) div.removeAttribute("id");
    const body = document.getElementById("streaming-body");
    if (body) {
        body.removeAttribute("id");
        const cursor = body.querySelector(".stream-cursor");
        if (cursor) cursor.remove();
        if (data.output && typeof data.output === "object") {
            body.innerHTML = _renderStructuredOutput(data.output);
        }
    }
    if (div) {
        const header = div.querySelector(".msg-header");
        if (header) {
            const copyText = data.output ? JSON.stringify(data.output, null, 2) : (data.text || "");
            const btn = document.createElement("button");
            btn.className = "msg-copy"; btn.textContent = "copy";
            btn.onclick = () => copyMsg(btn, copyText);
            header.appendChild(btn);
        }
        // Handle thinking cot-block
        const cotBlock = div.querySelector(".cot-block");
        const thinkingBody = cotBlock && cotBlock.querySelector(".thinking-body");
        const hasThinking  = thinkingBody && thinkingBody.textContent.trim().length > 0;
        if (cotBlock && hasThinking) {
            cotBlock.classList.add("hidden");
            const toggleBtn = document.createElement("button");
            toggleBtn.className = "cot-toggle";
            toggleBtn.textContent = "▶ show reasoning";
            toggleBtn.onclick = () => toggleCot(div);
            const msgBody = div.querySelector(".msg-body");
            if (msgBody) msgBody.after(toggleBtn);
        } else if (cotBlock) {
            cotBlock.classList.add("hidden");
        }

        // Make message clickable to show its flow
        div.classList.add("flow-clickable");
        const turnId = FlowEngine.saveTurn();
        div.dataset.flowTurn = turnId;
        div.addEventListener("click", () => FlowEngine.loadTurn(turnId, div));

        // Render multi-agent contributions panel if present
        const maHtml = renderMultiAgentContributions(data);
        if (maHtml) {
            const panel = document.createElement("div");
            panel.innerHTML = maHtml;
            div.appendChild(panel.firstChild);
        }
    }
    updateTelemetry(data);
}


function addErrorMessage(text) {
    const div = document.createElement("div");
    div.className = "message msg-error";
    div.innerHTML = `<div class="msg-header"><span class="msg-label msg-label-error">ERROR</span></div><div class="msg-body">${esc(text)}</div>`;
    chatArea.appendChild(div); scrollToBottom();
}

function copyMsg(btn, text) {
    navigator.clipboard.writeText(text).then(() => {
        btn.textContent = "copied!"; btn.classList.add("copied");
        setTimeout(() => { btn.textContent = "copy"; btn.classList.remove("copied"); }, 1500);
    });
}

// ------------------------------------------------------------------ //
// Telemetry                                                           //
// ------------------------------------------------------------------ //
function updateTelemetry(data) {
    sessionTokens += (data.tokens && data.tokens.total) || 0;
    sessionCost   += data.cost || 0;
    turnCount++;
    costHistory.push(data.cost || 0);

    telemetryEmpty.classList.add("hidden");
    telemetryContent.classList.remove("hidden");

    document.getElementById("t-tokens-in").textContent    = fmt(data.tokens && data.tokens.input);
    document.getElementById("t-tokens-out").textContent   = fmt(data.tokens && data.tokens.output);
    document.getElementById("t-tokens-total").textContent = fmt(data.tokens && data.tokens.total);
    document.getElementById("t-cost").textContent         = fmtCost(data.cost);
    document.getElementById("t-latency").textContent      = fmtMs(data.latency_ms);
    document.getElementById("t-turns").textContent        = turnCount;
    document.getElementById("t-session-tokens").textContent = fmt(sessionTokens);
    document.getElementById("t-session-cost").textContent   = fmtCost(sessionCost);

    drawCostChart();

    // Streaming metrics (TTFT, tokens/sec, duration)
    if (data.streaming_metrics) {
        const sm = data.streaming_metrics;
        document.getElementById("telem-ttft").textContent = fmtMs(sm.ttft_ms);
        document.getElementById("telem-tokens-per-sec").textContent =
            typeof sm.tokens_per_sec === "number" ? sm.tokens_per_sec.toFixed(1) + " t/s" : "—";
        document.getElementById("telem-stream-duration").textContent = fmtMs(sm.stream_duration_ms);
    }

    const confSection = document.getElementById("telem-confidence-section");
    if (data.output && typeof data.output.confidence === "number") {
        confSection.classList.remove("hidden");
        const pct = Math.round(data.output.confidence * 100);
        document.getElementById("confidence-bar").style.width = pct + "%";
        document.getElementById("confidence-value").textContent = pct + "%";
    } else {
        confSection.classList.add("hidden");
    }

    const toolsEl = document.getElementById("t-tool-calls");
    if (data.tool_calls && data.tool_calls.length > 0) {
        toolsEl.innerHTML = data.tool_calls.map(tc =>
            `<div class="telem-tool-call">
                <div class="telem-tool-name">${esc(tc.name)}</div>
                <div class="telem-tool-args">Args: ${esc(JSON.stringify(tc.args))}</div>
                <div class="telem-tool-result">Result: ${esc(String(tc.result).substring(0, 200))}</div>
                <div class="telem-tool-latency">${fmtMs(tc.latency_ms)}</div>
            </div>`
        ).join("");
    } else {
        toolsEl.innerHTML = '<p class="empty-state">No tool calls.</p>';
    }

    const traceEl = document.getElementById("t-trace-spans");
    if (data.trace && data.trace.length > 0) {
        traceEl.innerHTML = data.trace.map(s =>
            `<div class="telem-span" data-type="${esc(s.type)}">
                <span class="span-name">${esc(s.name)}</span>
                <span class="span-type">${esc(s.type)}</span>
                <span class="span-duration">${fmtMs(s.duration_ms)}</span>
                ${s.metadata && Object.keys(s.metadata).length > 0
                    ? `<div class="span-meta">${esc(Object.entries(s.metadata).map(([k,v]) => k+": "+v).join(" | "))}</div>`
                    : ""}
            </div>`
        ).join("");
    } else {
        traceEl.innerHTML = '<p class="empty-state">No trace data.</p>';
    }

    // Guard results
    const guardsSection = document.getElementById("telem-guards-section");
    const guardsEl = document.getElementById("t-guard-results");
    if (data.guard_results && data.guard_results.length > 0) {
        guardsSection.classList.remove("hidden");
        guardsEl.innerHTML = data.guard_results.map(g =>
            `<div class="telem-guard-item">
                <div class="telem-guard-row">
                    <span class="telem-guard-name">${esc(g.name)}</span>
                    <span class="telem-guard-badge ${g.passed ? 'pass' : 'fail'}">${g.passed ? 'PASS' : 'FAIL'}</span>
                </div>
                <div class="telem-guard-duration">${fmtMs(g.duration_ms)}</div>
                ${!g.passed && g.violation_message ? `<div class="telem-guard-violation">${esc(g.violation_message)}</div>` : ""}
            </div>`
        ).join("");
    } else {
        guardsSection.classList.add("hidden");
        guardsEl.innerHTML = '<p class="empty-state">No guard data.</p>';
    }
}

function drawCostChart() {
    const canvas = document.getElementById("cost-chart");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.offsetWidth || 280;
    canvas.width = w; canvas.height = 50;
    ctx.clearRect(0, 0, w, 50);
    if (costHistory.length < 2) {
        ctx.fillStyle = "#6a7a8a"; ctx.font = "10px monospace";
        ctx.fillText("Need 2+ turns for chart", 8, 28); return;
    }
    const max  = Math.max(...costHistory) || 1;
    const step = w / (costHistory.length - 1);
    ctx.beginPath(); ctx.strokeStyle = "#39ff14"; ctx.lineWidth = 1.5;
    costHistory.forEach((v, i) => {
        const x = i * step, y = 46 - (v / max) * 40;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
    ctx.lineTo((costHistory.length - 1) * step, 50); ctx.lineTo(0, 50); ctx.closePath();
    ctx.fillStyle = "rgba(57,255,20,0.06)"; ctx.fill();
    costHistory.forEach((v, i) => {
        const x = i * step, y = 46 - (v / max) * 40;
        ctx.beginPath(); ctx.arc(x, y, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = "#39ff14"; ctx.fill();
    });
}

function exportTelemetry() {
    const rows = [["turn", "cost_usd"]];
    costHistory.forEach((c, i) => rows.push([i + 1, c.toFixed(8)]));
    const csv  = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a    = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "synth-telemetry.csv"; a.click();
}

async function exportConversationJSON() {
    try {
        const r = await fetch(`/api/conversations/${currentConv}`);
        if (!r.ok) return;
        const data = await r.json();
        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: "application/json" });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement("a");
        const ts   = new Date().toISOString().replace(/[:.]/g, "-");
        a.href = url;
        a.download = `conversation-${currentConv}-${ts}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (e) {
        console.error("Failed to export conversation JSON:", e);
    }
}

async function exportConversationMarkdown() {
    try {
        const r = await fetch(`/api/conversations/${currentConv}`);
        if (!r.ok) return;
        const messages = await r.json();
        let md = `# Conversation: ${currentConv}\n\n`;
        for (const msg of messages) {
            if (msg.role === "user") {
                md += `## User\n\n${msg.content}\n\n`;
            } else if (msg.role === "agent") {
                const data = msg.data || {};
                md += `## Agent\n\n${data.text || ""}\n\n`;
                if (data.tool_calls && data.tool_calls.length) {
                    md += "### Tool Calls\n\n";
                    for (const tc of data.tool_calls) {
                        md += `**${tc.name}**\n\`\`\`json\n${JSON.stringify(tc.args, null, 2)}\n\`\`\`\n\n`;
                    }
                }
            }
        }
        const blob = new Blob([md], { type: "text/markdown" });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement("a");
        const ts   = new Date().toISOString().replace(/[:.]/g, "-");
        a.href = url;
        a.download = `conversation-${currentConv}-${ts}.md`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    } catch (e) {
        console.error("Failed to export conversation Markdown:", e);
    }
}

// ------------------------------------------------------------------ //
// Tool playground                                                     //
// ------------------------------------------------------------------ //
function renderToolArgs(name) {
    const schema = toolSchemas[name];
    if (!schema) { toolArgsEditor.innerHTML = ""; toolDesc.textContent = ""; return; }
    toolDesc.textContent = schema.description;
    const props    = schema.parameters.properties || {};
    const required = schema.parameters.required   || [];
    let html = "";
    for (const [pname, pschema] of Object.entries(props)) {
        const req = required.includes(pname) ? " *" : "";
        html += `<div class="tool-arg-row">
            <span class="tool-arg-label">${pname}${req}</span>
            <input class="tool-arg-input" data-arg="${pname}" placeholder="${pschema.type || "string"}">
            <span class="tool-arg-type">${pschema.type || "?"}</span>
        </div>`;
    }
    toolArgsEditor.innerHTML = html; toolOutput.textContent = "";
}

async function runTool() {
    const name = toolSelect.value; if (!name) return;
    const args = {};
    toolArgsEditor.querySelectorAll(".tool-arg-input").forEach(input => {
        let val = input.value;
        const schema = toolSchemas[name];
        const ptype  = schema.parameters.properties[input.dataset.arg] && schema.parameters.properties[input.dataset.arg].type;
        if (ptype === "integer") val = parseInt(val, 10);
        else if (ptype === "number")  val = parseFloat(val);
        else if (ptype === "boolean") val = val === "true";
        if (val !== "" && val !== undefined && !Number.isNaN(val)) args[input.dataset.arg] = val;
    });
    toolOutput.textContent = "Running..."; toolOutput.style.color = "var(--text-dim)";
    try {
        const r = await fetch("/api/tools/test", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, args }),
        });
        const d = await r.json();
        if (d.error) { toolOutput.textContent = "Error: " + d.error; toolOutput.style.color = "var(--red)"; }
        else { toolOutput.textContent = d.result + "\n\n(" + fmtMs(d.latency_ms) + ")"; toolOutput.style.color = "var(--green)"; }
    } catch (e) { toolOutput.textContent = "Network error: " + e.message; toolOutput.style.color = "var(--red)"; }
}

// ------------------------------------------------------------------ //
// Send prompt (SSE streaming)                                         //
// ------------------------------------------------------------------ //
async function sendPrompt(rawPrompt) {
    if (isLoading) return;
    const prompt = resolveVariables(rawPrompt);
    isLoading = true; btnSend.disabled = true;
    promptHistory.unshift(rawPrompt);
    if (promptHistory.length > 50) promptHistory.pop();
    historyIndex = -1;

    addUserMessage(prompt);
    startElapsedTimer();
    setStatus("THINKING", true);
    FlowEngine.onRunStart(prompt);

    let streamDiv = null, accText = "";
    let firstTokenTime = null;
    let tokenCount = 0;
    const requestStartTime = performance.now();
    let guardResults = null;

    try {
        const resp = await fetch("/api/chat/stream", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt, conversation: currentConv }),
        });
        if (!resp.ok) throw new Error("Server error " + resp.status);

        streamDiv = addStreamingMessage();
        const reader  = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n"); buffer = lines.pop();
            for (const line of lines) {
                if (!line.startsWith("data: ")) continue;
                try {
                    const event = JSON.parse(line.slice(6));
                    if (event.type === "thinking") {
                        updateThinking(event.text);
                        FlowEngine.onThinking(event.text);
                    } else if (event.type === "agent_start") {
                        addAgentDelegation(event.agent_name, "start");
                        setStatus("AGENT: " + event.agent_name, true);
                        FlowEngine.onAgentStart(event.agent_name);
                    } else if (event.type === "agent_complete") {
                        addAgentDelegation(event.agent_name, "complete", event);
                        FlowEngine.onAgentComplete(event.agent_name, event);
                    } else if (event.type === "token") {
                        if (firstTokenTime === null) {
                            firstTokenTime = performance.now();
                        }
                        tokenCount++;
                        accText += event.text; updateStreamingMessage(accText);
                    } else if (event.type === "tool_call") {
                        setStatus("TOOL: " + event.name, true);
                        FlowEngine.onToolCall(event.name, event.args || {}, event.agent_name);
                    } else if (event.type === "tool_result") {
                        setStatus("THINKING", true);
                        FlowEngine.onToolResult(event.name, event.result || "");
                    } else if (event.type === "guard_result") {
                        guardResults = event.guards || [];
                        FlowEngine.onGuardResult(event.guards || []);
                    } else if (event.type === "done") {
                        const now = performance.now();
                        const streamingMetrics = {
                            ttft_ms: firstTokenTime ? firstTokenTime - requestStartTime : 0,
                            tokens_per_sec: (firstTokenTime && tokenCount > 0) ? tokenCount / ((now - firstTokenTime) / 1000) : 0,
                            stream_duration_ms: firstTokenTime ? now - firstTokenTime : 0,
                        };
                        event.streaming_metrics = streamingMetrics;
                        if (guardResults) event.guard_results = guardResults;
                        collapseThinking(); finalizeStreamingMessage(event); setStatus("CONNECTED", true);
                        FlowEngine.onDone(event);
                    } else if (event.type === "error") {
                        if (streamDiv) { streamDiv.remove(); streamDiv = null; }
                        addErrorMessage(event.error); setStatus("ERROR", false);
                        FlowEngine.onError(event.error);
                    }
                } catch (e) { /* skip malformed */ }
            }
        }
    } catch (err) {
        if (streamDiv) { streamDiv.remove(); streamDiv = null; }
        addErrorMessage("Network error: " + err.message); setStatus("DISCONNECTED", false);
        FlowEngine.onError("Network error: " + err.message);
    } finally {
        stopElapsedTimer(); isLoading = false; btnSend.disabled = false; promptInput.focus();
    }
}


async function reloadAgent() {
    try {
        const r = await fetch("/api/reload", { method: "POST" });
        const d = await r.json();
        if (d.error) addErrorMessage("Reload failed: " + d.error);
        else { setStatus("RELOADED", true); await loadAgentInfo(); await loadTools(); setTimeout(() => setStatus("CONNECTED", true), 2000); }
    } catch (e) { addErrorMessage("Reload error: " + e.message); setStatus("DISCONNECTED", false); }
}

// ------------------------------------------------------------------ //
// PROMPTS TAB                                                         //
// ------------------------------------------------------------------ //
async function loadPrompts() {
    try {
        const r = await fetch("/api/prompts");
        const d = await r.json();
        renderPromptList(d.prompts);
    } catch (e) { /* ignore */ }
}

function renderPromptList(prompts) {
    const el = document.getElementById("prompt-list");
    const entries = Object.entries(prompts);
    if (!entries.length) { el.innerHTML = '<p class="empty-state">No saved prompts.</p>'; return; }
    el.innerHTML = "";
    for (const [name, versions] of entries) {
        const item = document.createElement("div");
        item.className = "prompt-item";
        const latest = versions[versions.length - 1];
        item.innerHTML = `<div class="prompt-item-name">${esc(name)}</div>
            <div class="prompt-item-meta">${versions.length} version${versions.length !== 1 ? "s" : ""} · ${latest.notes ? esc(latest.notes) : "no notes"}</div>`;
        const versionsDiv = document.createElement("div");
        versionsDiv.className = "prompt-versions";
        for (const v of [...versions].reverse()) {
            const row = document.createElement("div");
            row.className = "prompt-version";
            row.innerHTML = `<span>v${v.version}</span>
                <span class="prompt-version-label">${v.notes ? esc(v.notes) : ""}</span>
                <div class="prompt-version-actions">
                    <button class="btn-tiny use" title="Load into editor">use</button>
                    <button class="btn-tiny" title="Load into A/B A">→A</button>
                    <button class="btn-tiny" title="Load into A/B B">→B</button>
                    <button class="btn-tiny" title="Delete">del</button>
                </div>`;
            row.querySelectorAll(".btn-tiny")[0].onclick = () => {
                document.getElementById("prompt-name").value = name;
                document.getElementById("prompt-text").value = v.text;
            };
            row.querySelectorAll(".btn-tiny")[1].onclick = () => { document.getElementById("ab-prompt-a").value = v.text; };
            row.querySelectorAll(".btn-tiny")[2].onclick = () => { document.getElementById("ab-prompt-b").value = v.text; };
            row.querySelectorAll(".btn-tiny")[3].onclick = async () => {
                await fetch(`/api/prompts/${encodeURIComponent(name)}/${v.version}`, { method: "DELETE" });
                loadPrompts();
            };
            versionsDiv.appendChild(row);
        }
        item.appendChild(versionsDiv);
        el.appendChild(item);
    }
}

async function savePrompt() {
    const name  = document.getElementById("prompt-name").value.trim();
    const text  = document.getElementById("prompt-text").value.trim();
    const notes = document.getElementById("prompt-notes").value.trim();
    if (!name || !text) return;
    await fetch("/api/prompts", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, text, notes }),
    });
    loadPrompts();
}

async function runABTest() {
    const input   = document.getElementById("ab-input").value.trim();
    const promptA = document.getElementById("ab-prompt-a").value.trim();
    const promptB = document.getElementById("ab-prompt-b").value.trim();
    if (!input) return;

    const btn = document.getElementById("btn-run-ab");
    btn.textContent = "RUNNING..."; btn.disabled = true;

    try {
        const r = await fetch("/api/ab-test", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ input, prompt_a: promptA, prompt_b: promptB }),
        });
        const d = await r.json();
        const results = d.results || [];
        const a = results.find(r => r.label === "A") || {};
        const b = results.find(r => r.label === "B") || {};

        document.getElementById("ab-a-latency").textContent = fmtMs(a.latency_ms);
        document.getElementById("ab-a-cost").textContent    = fmtCost(a.cost);
        document.getElementById("ab-b-latency").textContent = fmtMs(b.latency_ms);
        document.getElementById("ab-b-cost").textContent    = fmtCost(b.cost);

        const aOut = document.getElementById("ab-a-output");
        const bOut = document.getElementById("ab-b-output");
        aOut.textContent = a.error ? "Error: " + a.error : (a.text || "");
        bOut.textContent = b.error ? "Error: " + b.error : (b.text || "");

        document.getElementById("ab-results").classList.remove("hidden");

        // Diff
        if (a.text && b.text) {
            renderDiff(a.text, b.text);
            document.getElementById("diff-wrap").classList.remove("hidden");
        }
    } catch (e) {
        alert("A/B test error: " + e.message);
    } finally {
        btn.textContent = "RUN A/B"; btn.disabled = false;
    }
}

function renderDiff(textA, textB) {
    const wordsA = textA.split(/\s+/);
    const wordsB = textB.split(/\s+/);
    const setA   = new Set(wordsA);
    const setB   = new Set(wordsB);
    const html   = wordsB.map(w => setA.has(w) ? esc(w) : `<span class="diff-add">${esc(w)}</span>`).join(" ")
        + " " + wordsA.filter(w => !setB.has(w)).map(w => `<span class="diff-del">${esc(w)}</span>`).join(" ");
    document.getElementById("diff-view").innerHTML = html;
}

// ------------------------------------------------------------------ //
// EVALS TAB                                                           //
// ------------------------------------------------------------------ //
let _evalCases = [];
let lastEvalResults = null;

async function loadEvals() {
    try {
        const r = await fetch("/api/evals");
        const d = await r.json();
        _evalCases = d.evals || [];
        renderEvalList();
    } catch (e) { /* ignore */ }
}

function renderEvalList() {
    const el = document.getElementById("eval-list");
    if (!_evalCases.length) { el.innerHTML = '<p class="empty-state">No test cases.</p>'; return; }
    el.innerHTML = "";
    for (const c of _evalCases) {
        const item = document.createElement("div");
        item.className = "eval-case-item";
        item.innerHTML = `<div>
            <div class="eval-case-name">${esc(c.name)}</div>
            <div class="eval-case-input">${esc(c.input)}</div>
            ${c.golden ? '<div style="font-size:10px;color:var(--green);margin-top:2px;">&#x2605; golden set</div>' : ""}
        </div>
        <button class="btn-tiny" title="Delete">&#x2715;</button>`;
        item.querySelector(".btn-tiny").onclick = async () => {
            await fetch("/api/evals/" + c.id, { method: "DELETE" });
            loadEvals();
        };
        el.appendChild(item);
    }
}

async function addEvalCase() {
    const name     = document.getElementById("eval-name").value.trim();
    const input    = document.getElementById("eval-input").value.trim();
    const expected = document.getElementById("eval-expected").value.trim();
    if (!name || !input) return;
    await fetch("/api/evals", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, input, expected }),
    });
    document.getElementById("eval-name").value     = "";
    document.getElementById("eval-input").value    = "";
    document.getElementById("eval-expected").value = "";
    loadEvals();
}

async function runEvals() {
    if (!_evalCases.length) return;
    const btn = document.getElementById("btn-run-evals");
    btn.textContent = "RUNNING..."; btn.disabled = true;
    const useLLM = document.getElementById("eval-llm-judge").checked;

    try {
        const r = await fetch("/api/evals/run", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ llm_judge: useLLM }),
        });
        const d = await r.json();
        lastEvalResults = d.results || [];
        renderEvalResults(lastEvalResults);
        const exportBtn = document.getElementById("btn-export-eval-json");
        if (exportBtn) exportBtn.disabled = false;
    } catch (e) {
        document.getElementById("eval-results").innerHTML = `<p class="empty-state" style="color:var(--red)">Error: ${esc(e.message)}</p>`;
    } finally {
        btn.textContent = "&#x25B6; RUN ALL"; btn.disabled = false;
    }
}

function renderEvalResults(results) {
    const el      = document.getElementById("eval-results");
    const passed  = results.filter(r => r.pass).length;
    const summary = document.getElementById("eval-summary");
    summary.textContent = `${passed}/${results.length} passed`;
    summary.style.color = passed === results.length ? "var(--green)" : passed > 0 ? "var(--amber)" : "var(--red)";

    if (!results.length) { el.innerHTML = '<p class="empty-state">No results.</p>'; return; }
    el.innerHTML = "";
    for (const r of results) {
        const card = document.createElement("div");
        const cls  = r.error ? "error" : r.pass ? "pass" : "fail";
        card.className = "eval-result-card " + cls;

        const score    = r.score != null ? Math.round(r.score * 100) : null;
        const barClass = score >= 70 ? "high" : score >= 40 ? "mid" : "low";

        card.innerHTML = `
            <div class="eval-result-header">
                <span class="eval-result-name">${esc(r.name)}</span>
                <span class="eval-badge ${cls}">${r.error ? "ERROR" : r.pass ? "PASS" : "FAIL"}</span>
            </div>
            ${score != null ? `<div class="eval-score-bar-wrap"><div class="eval-score-bar ${barClass}" style="width:${score}%"></div></div>` : ""}
            <div class="eval-result-row">Input: <span>${esc(r.input || "")}</span></div>
            ${r.expected ? `<div class="eval-result-row">Expected: <span>${esc(r.expected)}</span></div>` : ""}
            ${r.actual   ? `<div class="eval-result-row">Actual: <span>${esc(r.actual.substring(0, 200))}</span></div>` : ""}
            ${r.error    ? `<div class="eval-result-row" style="color:var(--red)">Error: <span>${esc(r.error)}</span></div>` : ""}
            ${score != null ? `<div class="eval-result-row">Score: <span style="color:var(--green)">${score}%</span>${r.latency_ms ? ` · ${fmtMs(r.latency_ms)}` : ""}</div>` : ""}
            ${r.llm_score != null ? `<div class="eval-result-row">LLM Judge: <span style="color:var(--cyan)">${Math.round(r.llm_score*100)}%</span> — ${esc(r.llm_reason || "")}</div>` : ""}
            ${r.regression_score != null ? `<div class="eval-result-row">Regression vs golden: <span style="color:var(--purple)">${Math.round(r.regression_score*100)}%</span></div>` : ""}
            <div class="eval-result-actions">
                ${r.actual ? `<button class="btn btn-ghost btn-sm" onclick="setGolden('${r.id}', ${JSON.stringify(esc(r.actual))})">&#x2605; Set as Golden</button>` : ""}
            </div>`;
        el.appendChild(card);
    }
}

function exportEvalResults() {
    if (!lastEvalResults) return;
    const json = JSON.stringify(lastEvalResults, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    const ts   = new Date().toISOString().replace(/[:.]/g, "-");
    a.href = url;
    a.download = `eval-results-${ts}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

async function setGolden(id, text) {
    await fetch(`/api/evals/${id}/set-golden`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
    });
    loadEvals();
}

// ------------------------------------------------------------------ //
// OBSERVE TAB                                                         //
// ------------------------------------------------------------------ //
async function populateReplaySelect() {
    try {
        const r = await fetch("/api/conversations");
        const d = await r.json();
        const sel = document.getElementById("replay-conv-select");
        sel.innerHTML = "";
        for (const id of d.conversations) {
            const opt = document.createElement("option");
            opt.value = id; opt.textContent = id; sel.appendChild(opt);
        }
    } catch (e) { /* ignore */ }
}

async function loadReplay() {
    const id = document.getElementById("replay-conv-select").value;
    if (!id) return;
    try {
        const r = await fetch("/api/conversations/" + id);
        const d = await r.json();
        renderTimeline(d.messages || []);
    } catch (e) { /* ignore */ }
}

function renderTimeline(messages) {
    const wrap     = document.getElementById("timeline-wrap");
    const anomalies = [];
    wrap.innerHTML = "";

    if (!messages.length) {
        wrap.innerHTML = '<p class="empty-state">No messages in this conversation.</p>'; return;
    }

    // Compute stats for anomaly detection
    const agentMsgs = messages.filter(m => m.role === "agent" && m.data);
    const latencies = agentMsgs.map(m => m.data.latency_ms || 0).filter(Boolean);
    const costs     = agentMsgs.map(m => m.data.cost || 0).filter(Boolean);
    const texts     = agentMsgs.map(m => (m.data.text || "").length);
    const avgLat    = latencies.length ? latencies.reduce((a,b) => a+b, 0) / latencies.length : 0;
    const avgCost   = costs.length    ? costs.reduce((a,b) => a+b, 0) / costs.length : 0;
    const avgLen    = texts.length    ? texts.reduce((a,b) => a+b, 0) / texts.length : 0;

    messages.forEach((msg, idx) => {
        const entry = document.createElement("div");
        entry.className = "timeline-entry";
        const isUser  = msg.role === "user";
        const data    = msg.data || {};
        const flags   = [];

        if (!isUser) {
            if (data.latency_ms && avgLat && data.latency_ms > avgLat * 2)
                flags.push({ type: "SLOW", desc: `Latency ${fmtMs(data.latency_ms)} (avg ${fmtMs(avgLat)})` });
            if (data.cost && avgCost && data.cost > avgCost * 2)
                flags.push({ type: "EXPENSIVE", desc: `Cost ${fmtCost(data.cost)} (avg ${fmtCost(avgCost)})` });
            if (data.text && avgLen && data.text.length < avgLen * 0.2)
                flags.push({ type: "SHORT", desc: `Response only ${data.text.length} chars (avg ${Math.round(avgLen)})` });
            flags.forEach(f => anomalies.push({ turn: idx + 1, ...f }));
        }

        const preview = isUser ? (msg.content || "").substring(0, 80) : (data.text || "").substring(0, 80);
        const metaHtml = !isUser && data.latency_ms
            ? `<span>${fmtMs(data.latency_ms)}</span><span>${fmtCost(data.cost)}</span>${flags.length ? `<span class="anomaly">&#x26A0; ${flags.map(f=>f.type).join(", ")}</span>` : ""}`
            : "";

        entry.innerHTML = `
            <div class="timeline-dot ${isUser ? "user" : "agent"}"></div>
            <div class="timeline-body">
                <div class="timeline-role ${isUser ? "user" : "agent"}">${isUser ? "YOU" : "AGENT"}</div>
                <div class="timeline-preview">${esc(preview)}${preview.length >= 80 ? "…" : ""}</div>
                ${metaHtml ? `<div class="timeline-meta">${metaHtml}</div>` : ""}
            </div>`;

        entry.addEventListener("click", () => {
            document.querySelectorAll(".timeline-entry").forEach(e => e.classList.remove("selected"));
            entry.classList.add("selected");
            // Show detail below
            const existing = document.getElementById("timeline-detail");
            if (existing) existing.remove();
            const detail = document.createElement("div");
            detail.id = "timeline-detail"; detail.className = "timeline-detail";
            detail.textContent = isUser ? (msg.content || "") : (data.text || JSON.stringify(data, null, 2));
            entry.after(detail);
        });

        wrap.appendChild(entry);
    });

    // Heatmap
    renderTokenHeatmap(agentMsgs);

    // Anomalies
    const anomalyList = document.getElementById("anomaly-list");
    if (!anomalies.length) {
        anomalyList.innerHTML = '<p class="empty-state">No anomalies detected.</p>';
    } else {
        anomalyList.innerHTML = anomalies.map(a =>
            `<div class="anomaly-item">
                <div class="anomaly-type">&#x26A0; ${esc(a.type)} — Turn ${a.turn}</div>
                <div class="anomaly-desc">${esc(a.desc)}</div>
            </div>`
        ).join("");
    }
}

function renderTokenHeatmap(agentMsgs) {
    const wrap = document.getElementById("token-heatmap");
    wrap.innerHTML = "";
    if (!agentMsgs.length) return;
    const totals = agentMsgs.map(m => (m.data.tokens && m.data.tokens.total) || 0);
    const max    = Math.max(...totals) || 1;
    totals.forEach((t, i) => {
        const intensity = t / max;
        const r = Math.round(57  + (255 - 57)  * intensity);
        const g = Math.round(255 * intensity);
        const b = Math.round(20  * intensity);
        const cell = document.createElement("div");
        cell.className = "heatmap-cell";
        cell.style.background = `rgb(${r},${g},${b})`;
        cell.style.opacity = 0.3 + intensity * 0.7;
        cell.title = `Turn ${i+1}: ${fmt(t)} tokens`;
        cell.textContent = t > 999 ? Math.round(t/1000) + "k" : t;
        wrap.appendChild(cell);
    });
}

// ------------------------------------------------------------------ //
// SCENARIOS TAB                                                       //
// ------------------------------------------------------------------ //
let _scenarios = [];

async function loadScenarios() {
    try {
        const r = await fetch("/api/scenarios");
        const d = await r.json();
        _scenarios = d.scenarios || [];
        renderScenarioList();
    } catch (e) { /* ignore */ }
}

function renderScenarioList() {
    const el = document.getElementById("scenario-list");
    if (!_scenarios.length) { el.innerHTML = '<p class="empty-state">No scenarios.</p>'; return; }
    el.innerHTML = "";
    for (const s of _scenarios) {
        const item = document.createElement("div");
        item.className = "scenario-item";
        item.innerHTML = `
            <div>
                <div class="scenario-item-name">${esc(s.name)}</div>
                <div class="scenario-item-meta">${s.turns.length} turn${s.turns.length !== 1 ? "s" : ""}</div>
            </div>
            <div class="scenario-item-actions">
                <button class="btn-tiny use" title="Load">edit</button>
                <button class="btn btn-send btn-sm" style="font-size:10px;padding:3px 8px;">&#x25B6;</button>
                <button class="btn-tiny" title="Delete">&#x2715;</button>
            </div>`;
        item.querySelectorAll(".btn-tiny")[0].onclick = () => loadScenarioIntoEditor(s);
        item.querySelectorAll(".btn")[0].onclick      = () => runScenario(s.id);
        item.querySelectorAll(".btn-tiny")[1].onclick = async () => {
            await fetch("/api/scenarios/" + s.id, { method: "DELETE" });
            loadScenarios();
        };
        el.appendChild(item);
    }
}

function newScenario() {
    editingScenarioId = null;
    document.getElementById("scenario-name").value = "";
    document.getElementById("scenario-turns").innerHTML = "";
    addTurn();
}

function loadScenarioIntoEditor(s) {
    editingScenarioId = s.id;
    document.getElementById("scenario-name").value = s.name;
    const turnsEl = document.getElementById("scenario-turns");
    turnsEl.innerHTML = "";
    for (const t of s.turns) addTurn(t.role, t.content);
}

function addTurn(role = "user", content = "") {
    const turnsEl = document.getElementById("scenario-turns");
    const row = document.createElement("div");
    row.className = "scenario-turn";
    row.innerHTML = `
        <select class="turn-role-select">
            <option value="user" ${role === "user" ? "selected" : ""}>user</option>
            <option value="assistant" ${role === "assistant" ? "selected" : ""}>assistant</option>
        </select>
        <input class="turn-content-input" placeholder="Turn content..." value="${esc(content)}" />
        <button class="btn-remove-turn" title="Remove">&#x2715;</button>`;
    row.querySelector(".btn-remove-turn").onclick = () => row.remove();
    turnsEl.appendChild(row);
}

async function saveScenario() {
    const name  = document.getElementById("scenario-name").value.trim();
    if (!name) return;
    const turns = [...document.querySelectorAll("#scenario-turns .scenario-turn")].map(row => ({
        role:    row.querySelector(".turn-role-select").value,
        content: row.querySelector(".turn-content-input").value,
    }));

    if (editingScenarioId) {
        await fetch("/api/scenarios/" + editingScenarioId, {
            method: "PUT", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, turns }),
        });
    } else {
        await fetch("/api/scenarios", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, turns }),
        });
    }
    loadScenarios();
}

async function runScenario(id) {
    const btn = document.querySelector(`.scenario-item-actions .btn`);
    const resultsEl = document.getElementById("scenario-results");
    const bodyEl    = document.getElementById("scenario-results-body");
    resultsEl.classList.remove("hidden");
    bodyEl.innerHTML = '<p class="empty-state">Running...</p>';

    try {
        const r = await fetch("/api/scenarios/" + id + "/run", { method: "POST" });
        const d = await r.json();
        if (d.error) { bodyEl.innerHTML = `<p class="empty-state" style="color:var(--red)">${esc(d.error)}</p>`; return; }
        bodyEl.innerHTML = (d.results || []).map(t =>
            `<div class="scenario-turn-result">
                <div class="scenario-turn-input">&#x25B6; ${esc(t.input)}</div>
                ${t.error
                    ? `<div style="color:var(--red);font-size:12px;">${esc(t.error)}</div>`
                    : `<div class="scenario-turn-output">${esc(t.output || "")}</div>
                       <div class="scenario-turn-meta">${fmtMs(t.latency_ms)} · ${fmtCost(t.cost)} · ${fmt(t.tokens && t.tokens.total)} tokens</div>`}
            </div>`
        ).join("");
    } catch (e) {
        bodyEl.innerHTML = `<p class="empty-state" style="color:var(--red)">Error: ${esc(e.message)}</p>`;
    }
}

// ------------------------------------------------------------------ //
// CONFIG TAB                                                          //
// ------------------------------------------------------------------ //
let _configSnapshot = null; // Original config for drift detection

async function loadConfig() {
    try {
        const r = await fetch("/api/config");
        if (!r.ok) return;
        const d = await r.json();

        // Store snapshot for drift detection
        _configSnapshot = {
            model: d.model,
            instructions: d.instructions,
            tools: Object.fromEntries((d.tools || []).map(t => [t.name, t.enabled])),
        };

        // Model selector — set current value
        const sel = document.getElementById("config-model-select");
        if (sel) sel.value = d.model || "";

        // Instructions
        const ta = document.getElementById("config-instructions");
        if (ta) ta.value = d.instructions || "";

        // Tool toggles
        const toggles = document.getElementById("config-tool-toggles");
        if (toggles) {
            if (!d.tools || !d.tools.length) {
                toggles.innerHTML = '<p class="empty-state">No tools registered.</p>';
            } else {
                toggles.innerHTML = d.tools.map(t =>
                    `<div class="tool-toggle-row">
                        <div>
                            <span class="tool-toggle-name">${esc(t.name)}</span>
                            <span class="tool-toggle-desc">${esc(t.description || "")}</span>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" ${t.enabled ? "checked" : ""} data-tool="${esc(t.name)}">
                            <span class="toggle-slider"></span>
                        </label>
                    </div>`
                ).join("");
                // Wire toggle listeners
                toggles.querySelectorAll('input[type="checkbox"]').forEach(cb => {
                    cb.addEventListener("change", () => {
                        const tools = {};
                        toggles.querySelectorAll('input[type="checkbox"]').forEach(c => {
                            tools[c.dataset.tool] = c.checked;
                        });
                        updateConfig("tools", tools);
                    });
                });
            }
        }

        // Guards sidebar
        const guardList = document.getElementById("config-guard-list");
        if (guardList) {
            if (!d.guards || !d.guards.length) {
                guardList.innerHTML = '<p class="empty-state">No guards configured.</p>';
            } else {
                guardList.innerHTML = d.guards.map(g =>
                    `<div class="guard-item">
                        <span class="guard-item-name">${esc(g.name)}</span>
                        <span class="guard-type-badge">${esc(g.type)}</span>
                    </div>`
                ).join("");
            }
        }

        // AgentCore section
        const acSection = document.getElementById("config-agentcore");
        if (acSection && d.agentcore) {
            if (d.agentcore.detected) {
                acSection.classList.remove("hidden");
                document.getElementById("ac-agent-name").textContent = d.agentcore.agent_name || "—";
                document.getElementById("ac-region").textContent = d.agentcore.aws_region || "—";
                document.getElementById("ac-model-id").textContent = d.agentcore.model_id || "—";
                // Model mismatch warning
                const mismatch = document.getElementById("ac-mismatch");
                if (mismatch) {
                    const hasMismatch = d.agentcore.model_id && d.model && d.agentcore.model_id !== d.model;
                    mismatch.classList.toggle("hidden", !hasMismatch);
                }
                // Evaluations sub-section
                if (d.agentcore.evaluations_configured) {
                    loadEvaluationsConfig();
                    loadEvaluationScores();
                } else {
                    const evalSection = document.getElementById("config-evaluations");
                    if (evalSection) evalSection.classList.add("hidden");
                }
            } else {
                acSection.classList.add("hidden");
                const evalSection = document.getElementById("config-evaluations");
                if (evalSection) evalSection.classList.add("hidden");
            }
        }

        // Drift indicator
        updateDriftIndicator(d.has_drift || false);

        // Save button state
        const saveBtn = document.getElementById("btn-save-config");
        if (saveBtn) saveBtn.disabled = !d.has_drift;

        // Hide warnings on fresh load
        const warnings = document.getElementById("config-warnings");
        if (warnings) warnings.classList.add("hidden");

    } catch (e) {
        console.error("Failed to load config:", e);
    }
}

async function loadModels() {
    try {
        const r = await fetch("/api/models");
        if (!r.ok) return;
        const d = await r.json();
        const sel = document.getElementById("config-model-select");
        if (!sel) return;

        const currentVal = sel.value;
        sel.innerHTML = "";

        const providers = d.providers || {};
        for (const [provider, models] of Object.entries(providers)) {
            const group = document.createElement("optgroup");
            group.label = provider;
            for (const m of models) {
                const opt = document.createElement("option");
                opt.value = m;
                opt.textContent = m;
                group.appendChild(opt);
            }
            sel.appendChild(group);
        }

        // Restore selection
        if (currentVal) sel.value = currentVal;
    } catch (e) {
        console.error("Failed to load models:", e);
    }
}

async function updateConfig(field, value) {
    const body = {};
    if (field === "model") body.model = value;
    else if (field === "instructions") body.instructions = value;
    else if (field === "tools") body.tools = value;

    try {
        const r = await fetch("/api/config", {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });
        const d = await r.json();
        if (!r.ok) {
            console.error("Config update error:", d.error || d);
            return;
        }
        updateDriftIndicator(d.has_drift || false);
        const saveBtn = document.getElementById("btn-save-config");
        if (saveBtn) saveBtn.disabled = !d.has_drift;

        // Show warnings if any
        if (d.warnings && d.warnings.length) {
            showConfigWarnings(d.warnings);
        }
    } catch (e) {
        console.error("Failed to update config:", e);
    }
}

async function saveConfigToFile() {
    try {
        const r = await fetch("/api/config/save", { method: "POST" });
        const d = await r.json();
        if (!r.ok) {
            console.error("Save error:", d.error || d);
            return;
        }
        if (d.warnings && d.warnings.length) {
            showConfigWarnings(d.warnings);
        } else {
            const warnings = document.getElementById("config-warnings");
            if (warnings) warnings.classList.add("hidden");
        }
        // Refresh drift state
        updateDriftIndicator(false);
        const saveBtn = document.getElementById("btn-save-config");
        if (saveBtn) saveBtn.disabled = true;
    } catch (e) {
        console.error("Failed to save config:", e);
    }
}

async function resetConfig() {
    try {
        await fetch("/api/reload", { method: "POST" });
        await loadConfig();
        await loadModels();
        // Also refresh agent info in the main UI
        await loadAgentInfo();
        await loadTools();
    } catch (e) {
        console.error("Failed to reset config:", e);
    }
}

function updateDriftIndicator(hasDrift) {
    const dot = document.getElementById("drift-dot");
    if (dot) dot.classList.toggle("hidden", !hasDrift);
}

function showConfigWarnings(warnings) {
    const box = document.getElementById("config-warnings");
    const list = document.getElementById("config-warning-list");
    if (!box || !list) return;
    list.innerHTML = warnings.map(w => `<li>${esc(w)}</li>`).join("");
    box.classList.remove("hidden");
}

function checkLocalDrift() {
    if (!_configSnapshot) return;
    const sel = document.getElementById("config-model-select");
    const ta = document.getElementById("config-instructions");
    const toggles = document.getElementById("config-tool-toggles");

    let drifted = false;
    if (sel && sel.value !== _configSnapshot.model) drifted = true;
    if (ta && ta.value !== _configSnapshot.instructions) drifted = true;
    if (toggles) {
        toggles.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            const orig = _configSnapshot.tools[cb.dataset.tool];
            if (orig !== undefined && cb.checked !== orig) drifted = true;
        });
    }
    updateDriftIndicator(drifted);
    const saveBtn = document.getElementById("btn-save-config");
    if (saveBtn) saveBtn.disabled = !drifted;
}

// ------------------------------------------------------------------ //
// Event listeners                                                     //
// ------------------------------------------------------------------ //
chatForm.addEventListener("submit", e => {
    e.preventDefault();
    const text = promptInput.value.trim(); if (!text) return;
    promptInput.value = ""; promptInput.style.height = "auto";
    varBar.innerHTML = "";
    sendPrompt(text);
});

promptInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault(); chatForm.dispatchEvent(new Event("submit"));
    } else if (e.key === "ArrowUp" && promptInput.value === "") {
        e.preventDefault();
        if (historyIndex < promptHistory.length - 1) { historyIndex++; promptInput.value = promptHistory[historyIndex]; }
    } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (historyIndex > 0) { historyIndex--; promptInput.value = promptHistory[historyIndex]; }
        else { historyIndex = -1; promptInput.value = ""; }
    }
});

btnClear.addEventListener("click", () => {
    chatArea.innerHTML = '<div class="welcome" id="welcome"><p class="welcome-text">Chat cleared.</p></div>';
    telemetryContent.classList.add("hidden"); telemetryEmpty.classList.remove("hidden");
    sessionTokens = 0; sessionCost = 0; turnCount = 0; costHistory = [];
});

btnReload.addEventListener("click", reloadAgent);
document.getElementById("btn-new-chat").addEventListener("click", newConversation);
document.getElementById("btn-toggle-tools").addEventListener("click", () => toolDrawer.classList.toggle("hidden"));
document.getElementById("btn-close-tools").addEventListener("click", () => toolDrawer.classList.add("hidden"));
document.getElementById("btn-sidebar-toggle").addEventListener("click", () => sidebar.classList.toggle("collapsed"));
document.getElementById("btn-export").addEventListener("click", exportTelemetry);
document.getElementById("btn-export-json").addEventListener("click", exportConversationJSON);
document.getElementById("btn-export-md").addEventListener("click", exportConversationMarkdown);
document.getElementById("btn-export-eval-json").addEventListener("click", exportEvalResults);
toolSelect.addEventListener("change", () => renderToolArgs(toolSelect.value));
document.getElementById("btn-run-tool").addEventListener("click", runTool);

// Prompts tab
document.getElementById("btn-save-prompt").addEventListener("click", savePrompt);
document.getElementById("btn-run-ab").addEventListener("click", runABTest);

// Evals tab
document.getElementById("btn-add-eval").addEventListener("click", addEvalCase);
document.getElementById("btn-run-evals").addEventListener("click", runEvals);

// Observe tab
document.getElementById("btn-load-replay").addEventListener("click", loadReplay);

// Scenarios tab
document.getElementById("btn-new-scenario").addEventListener("click", newScenario);
document.getElementById("btn-add-turn").addEventListener("click", () => addTurn());
document.getElementById("btn-save-scenario").addEventListener("click", saveScenario);

// Config tab
document.getElementById("btn-save-config").addEventListener("click", saveConfigToFile);
document.getElementById("btn-reset-config").addEventListener("click", resetConfig);
document.getElementById("config-model-select").addEventListener("change", (e) => {
    updateConfig("model", e.target.value);
});
document.getElementById("config-instructions").addEventListener("blur", (e) => {
    updateConfig("instructions", e.target.value);
});

// Evaluations
document.getElementById("btn-run-evaluation").addEventListener("click", runEvaluation);

// ------------------------------------------------------------------ //
// EVALUATIONS SUB-SECTION                                             //
// ------------------------------------------------------------------ //

async function loadEvaluationsConfig() {
    const section = document.getElementById("config-evaluations");
    if (!section) return;
    try {
        const r = await fetch("/api/agentcore/evaluations/config");
        if (!r.ok) { section.classList.add("hidden"); return; }
        const d = await r.json();
        if (!d.config) { section.classList.add("hidden"); return; }
        section.classList.remove("hidden");
        document.getElementById("eval-status-value").textContent = d.config.active ? "Active" : "Disabled";
        document.getElementById("eval-status-value").style.color = d.config.active ? "var(--green)" : "var(--red)";
        document.getElementById("eval-sampling-rate").textContent = d.config.sampling_rate;
        document.getElementById("eval-evaluator-list").textContent = (d.config.evaluators || []).join(", ") || "—";
    } catch (e) {
        section.classList.add("hidden");
    }
}

async function loadEvaluationScores() {
    const tbody = document.getElementById("eval-scores-body");
    if (!tbody) return;
    try {
        const r = await fetch("/api/agentcore/evaluations");
        if (!r.ok) return;
        const d = await r.json();
        const results = d.results || [];
        if (!results.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">No evaluation data.</td></tr>';
            return;
        }
        tbody.innerHTML = results.map(res => {
            const scoreClass = res.score < 0.5 ? "eval-score-warn" : "eval-score-ok";
            const ts = res.timestamp ? new Date(res.timestamp).toLocaleString() : "—";
            return `<tr>
                <td>${esc(res.evaluator_name)}</td>
                <td class="${scoreClass}">${res.score.toFixed(2)}</td>
                <td>${esc(res.level)}</td>
                <td>${esc(ts)}</td>
            </tr>`;
        }).join("");
    } catch (e) { /* ignore */ }
}

async function runEvaluation() {
    const btn = document.getElementById("btn-run-evaluation");
    btn.textContent = "RUNNING..."; btn.disabled = true;
    try {
        const r = await fetch("/api/agentcore/evaluations/run", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({}),
        });
        if (r.ok) await loadEvaluationScores();
    } catch (e) { /* ignore */ }
    finally { btn.innerHTML = "&#x25B6; Run Evaluation"; btn.disabled = false; }
}

// ================================================================== //
// FLOW VISUALIZATION ENGINE — Pip-Boy Tactical Display                //
// ================================================================== //
// Real-time node graph that visualises the agent execution flow:
// Prompt → Agent → Tool Calls / MCP Calls → Output
// Each node is clickable to reveal trace/log detail in a slide-in panel.

const FlowEngine = (() => {
    // --- DOM refs (standalone Flow tab) ---
    const graph       = document.getElementById("flow-graph");
    const empty       = document.getElementById("flow-empty");
    const detailPanel = document.getElementById("flow-detail-panel");
    const detailTitle = document.getElementById("flow-detail-title");
    const detailBody  = document.getElementById("flow-detail-body");
    const runLabel    = document.getElementById("flow-run-label");
    const btnClose    = document.getElementById("btn-flow-detail-close");
    const btnClear    = document.getElementById("btn-flow-clear");

    // --- DOM refs (inline panel in chat tab) ---
    const inlineGraph       = document.getElementById("inline-flow-graph");
    const inlineEmpty       = document.getElementById("inline-flow-empty");
    const inlineDetail      = document.getElementById("inline-flow-detail");
    const inlineDetailTitle = document.getElementById("inline-flow-detail-title");
    const inlineDetailBody  = document.getElementById("inline-flow-detail-body");
    const btnInlineClose    = document.getElementById("btn-inline-flow-detail-close");

    // --- State ---
    let nodes       = [];   // {id, type, label, sub, status, data, el, ts}
    let runCounter  = 0;
    let selectedId  = null;
    let pendingToolNodes = {};  // tool name → node id (for matching results)

    // --- Helpers ---
    function _ts() { return performance.now(); }

    function _icon(type) {
        const icons = {
            prompt:  "▶",
            agent:   "⚙",
            tool:    "⚒",
            guard:   "⛨",
            output:  "◈",
            error:   "✖",
            thinking:"◉",
        };
        return icons[type] || "●";
    }

    function _fmtMs(ms) {
        if (typeof ms !== "number" || ms <= 0) return "";
        return ms < 1000 ? ms.toFixed(0) + "ms" : (ms / 1000).toFixed(2) + "s";
    }

    // --- Core ---

    function reset() {
        nodes = [];
        pendingToolNodes = {};
        selectedId = null;
        // Standalone Flow tab
        if (graph) graph.innerHTML = "";
        if (empty) empty.classList.remove("hidden");
        if (graph) graph.classList.add("hidden");
        if (detailPanel) detailPanel.classList.add("hidden");
        if (runLabel) runLabel.textContent = "No runs yet";
        // Inline panel
        if (inlineGraph) inlineGraph.innerHTML = "";
        if (inlineEmpty) inlineEmpty.classList.remove("hidden");
        if (inlineGraph) inlineGraph.classList.add("hidden");
        if (inlineDetail) inlineDetail.classList.add("hidden");
    }

    function _showGraph() {
        if (empty) empty.classList.add("hidden");
        if (graph) graph.classList.remove("hidden");
        if (inlineEmpty) inlineEmpty.classList.add("hidden");
        if (inlineGraph) inlineGraph.classList.remove("hidden");
    }

    function _addConnector(active) {
        const cls = "flow-connector" + (active ? " active" : "");
        const c = document.createElement("div");
        c.className = cls;
        if (graph) graph.appendChild(c);
        // Clone for inline
        if (inlineGraph) {
            const c2 = document.createElement("div");
            c2.className = cls;
            inlineGraph.appendChild(c2);
        }
        return c;
    }

    function _createNode(id, type, label, sub, status, data) {
        const el = document.createElement("div");
        el.className = `flow-node flow-node-${type}`;
        el.dataset.nodeId = id;

        const badgeClass = status === "running" ? "flow-node-badge-running"
            : status === "error" ? "flow-node-badge-error"
            : "flow-node-badge-done";
        const badgeText = status === "running" ? "ACTIVE"
            : status === "error" ? "ERROR"
            : "DONE";
        const spinnerHtml = status === "running"
            ? `<span class="flow-spinner"></span>` : "";

        el.innerHTML =
            `<div class="flow-node-icon">${_icon(type)}</div>` +
            `<div class="flow-node-content">` +
                `<div class="flow-node-label">${esc(label)}</div>` +
                (sub ? `<div class="flow-node-sub">${esc(sub)}</div>` : "") +
            `</div>` +
            spinnerHtml +
            `<span class="flow-node-badge ${badgeClass}">${badgeText}</span>`;

        el.addEventListener("click", () => _selectNode(id));
        return el;
    }

    function addNode(type, label, sub, status, data) {
        _showGraph();
        const id = "flow-" + Date.now() + "-" + Math.random().toString(36).slice(2, 6);
        const el = _createNode(id, type, label, sub || "", status || "running", data || {});
        const node = { id, type, label, sub: sub || "", status, data: data || {}, el, ts: _ts(), inlineEl: null };
        nodes.push(node);

        if (nodes.length > 1) _addConnector(true);
        if (graph) graph.appendChild(el);

        // Clone for inline panel
        if (inlineGraph) {
            const inlineEl = _createNode(id, type, label, sub || "", status || "running", data || {});
            inlineEl.addEventListener("click", () => _selectNode(id));
            node.inlineEl = inlineEl;
            inlineGraph.appendChild(inlineEl);
        }

        // Auto-scroll both canvases
        const canvas = document.getElementById("flow-canvas");
        if (canvas) canvas.scrollTop = canvas.scrollHeight;
        if (inlineGraph) inlineGraph.scrollTop = inlineGraph.scrollHeight;

        return id;
    }

    function addParallelTools(toolNodes) {
        // toolNodes: [{label, sub, data}]
        if (!toolNodes || toolNodes.length === 0) return [];
        _showGraph();
        if (nodes.length > 0) _addConnector(true);

        const ids = [];
        if (toolNodes.length === 1) {
            // Single tool — just a normal node
            const t = toolNodes[0];
            const nid = addNode("tool", t.label, t.sub, "running", t.data);
            ids.push(nid);
        } else {
            // Multiple parallel tools — horizontal row
            const row = document.createElement("div");
            row.className = "flow-parallel-row";
            for (const t of toolNodes) {
                const id = "flow-" + Date.now() + "-" + Math.random().toString(36).slice(2, 6);
                const el = _createNode(id, "tool", t.label, t.sub || "", "running", t.data || {});
                const branch = document.createElement("div");
                branch.className = "flow-branch-group";
                branch.appendChild(el);
                row.appendChild(branch);
                const node = { id, type: "tool", label: t.label, sub: t.sub || "", status: "running", data: t.data || {}, el, ts: _ts() };
                nodes.push(node);
                ids.push(id);
            }
            graph.appendChild(row);
        }
        return ids;
    }

    function updateNode(id, updates) {
        const node = nodes.find(n => n.id === id);
        if (!node) return;
        if (updates.status) node.status = updates.status;
        if (updates.sub) node.sub = updates.sub;
        if (updates.data) Object.assign(node.data, updates.data);
        if (updates.label) node.label = updates.label;

        // Toggle done class for CSS animation control
        node.el.classList.toggle("flow-node-done", node.status === "done" || node.status === "error");

        // Re-render the node element
        const type = node.type;
        const badgeClass = node.status === "running" ? "flow-node-badge-running"
            : node.status === "error" ? "flow-node-badge-error"
            : "flow-node-badge-done";
        const badgeText = node.status === "running" ? "ACTIVE"
            : node.status === "error" ? "ERROR"
            : "DONE";
        const spinnerHtml = node.status === "running"
            ? `<span class="flow-spinner"></span>` : "";

        node.el.innerHTML =
            `<div class="flow-node-icon">${_icon(type)}</div>` +
            `<div class="flow-node-content">` +
                `<div class="flow-node-label">${esc(node.label)}</div>` +
                (node.sub ? `<div class="flow-node-sub">${esc(node.sub)}</div>` : "") +
            `</div>` +
            spinnerHtml +
            `<span class="flow-node-badge ${badgeClass}">${badgeText}</span>`;

        // Re-attach click handler
        node.el.onclick = () => _selectNode(node.id);

        // Update inline clone too
        if (node.inlineEl) {
            node.inlineEl.className = node.el.className;
            node.inlineEl.innerHTML = node.el.innerHTML;
            node.inlineEl.onclick = () => _selectNode(node.id);
        }

        // If this node is selected, refresh the detail panel
        if (selectedId === id) _showDetail(node);
    }

    // --- Detail panel ---

    function _selectNode(id) {
        const node = nodes.find(n => n.id === id);
        if (!node) return;

        // Toggle selection
        nodes.forEach(n => {
            n.el.classList.remove("selected");
            if (n.inlineEl) n.inlineEl.classList.remove("selected");
        });
        if (selectedId === id) {
            selectedId = null;
            if (detailPanel) detailPanel.classList.add("hidden");
            if (inlineDetail) inlineDetail.classList.add("hidden");
            return;
        }
        selectedId = id;
        node.el.classList.add("selected");
        if (node.inlineEl) node.inlineEl.classList.add("selected");
        _showDetail(node);
    }

    function _showDetail(node) {
        if (detailPanel) detailPanel.classList.remove("hidden");
        if (inlineDetail) inlineDetail.classList.remove("hidden");
        const typeLabels = {
            prompt: "USER PROMPT", agent: "AGENT PROCESSING",
            tool: "TOOL EXECUTION", guard: "GUARD CHECK",
            output: "AGENT OUTPUT", error: "ERROR",
            thinking: "REASONING",
        };
        detailTitle.textContent = typeLabels[node.type] || node.type.toUpperCase();

        let html = "";

        // Header info
        html += `<div class="flow-detail-section">`;
        html += `<div class="flow-detail-section-title">OVERVIEW</div>`;
        html += `<div class="flow-detail-row"><span class="flow-detail-key">Node</span><span class="flow-detail-val">${esc(node.label)}</span></div>`;
        html += `<div class="flow-detail-row"><span class="flow-detail-key">Type</span><span class="flow-detail-val">${esc(node.type)}</span></div>`;
        html += `<div class="flow-detail-row"><span class="flow-detail-key">Status</span><span class="flow-detail-val ${node.status === "done" ? "val-green" : node.status === "error" ? "val-red" : "val-amber"}">${node.status.toUpperCase()}</span></div>`;
        if (node.data.latency_ms) {
            html += `<div class="flow-detail-row"><span class="flow-detail-key">Latency</span><span class="flow-detail-val">${_fmtMs(node.data.latency_ms)}</span></div>`;
        }
        if (node.data.duration_ms) {
            html += `<div class="flow-detail-row"><span class="flow-detail-key">Duration</span><span class="flow-detail-val">${_fmtMs(node.data.duration_ms)}</span></div>`;
        }
        html += `</div>`;

        // Type-specific sections
        if (node.type === "prompt") {
            html += `<div class="flow-detail-section">`;
            html += `<div class="flow-detail-section-title">PROMPT TEXT</div>`;
            html += `<div class="flow-detail-pre">${esc(node.data.text || "—")}</div>`;
            html += `</div>`;
        }

        if (node.type === "tool") {
            if (node.data.args) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">ARGUMENTS</div>`;
                html += `<div class="flow-detail-pre">${esc(JSON.stringify(node.data.args, null, 2))}</div>`;
                html += `</div>`;
            }
            if (node.data.result !== undefined) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">RESULT</div>`;
                html += `<div class="flow-detail-pre">${esc(String(node.data.result).substring(0, 2000))}</div>`;
                html += `</div>`;
            }
        }

        if (node.type === "agent" && node.data.agent_name) {
            html += `<div class="flow-detail-section">`;
            html += `<div class="flow-detail-section-title">AGENT</div>`;
            html += `<div class="flow-detail-row"><span class="flow-detail-key">Name</span><span class="flow-detail-val">${esc(node.data.agent_name)}</span></div>`;
            html += `</div>`;
        }

        if (node.type === "thinking" && node.data.text) {
            html += `<div class="flow-detail-section">`;
            html += `<div class="flow-detail-section-title">REASONING</div>`;
            html += `<div class="flow-detail-pre">${esc(node.data.text.substring(0, 3000))}</div>`;
            html += `</div>`;
        }

        if (node.type === "output") {
            if (node.data.text) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">RESPONSE</div>`;
                html += `<div class="flow-detail-text">${renderMarkdown(node.data.text.substring(0, 3000))}</div>`;
                html += `</div>`;
            }
            if (node.data.tokens) {
                const t = node.data.tokens;
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">TOKEN USAGE</div>`;
                html += `<div class="flow-detail-row"><span class="flow-detail-key">Input</span><span class="flow-detail-val">${fmt(t.input)}</span></div>`;
                html += `<div class="flow-detail-row"><span class="flow-detail-key">Output</span><span class="flow-detail-val">${fmt(t.output)}</span></div>`;
                html += `<div class="flow-detail-row"><span class="flow-detail-key">Total</span><span class="flow-detail-val">${fmt(t.total)}</span></div>`;
                html += `</div>`;
            }
            if (node.data.cost !== undefined) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">COST</div>`;
                html += `<div class="flow-detail-row"><span class="flow-detail-key">Run Cost</span><span class="flow-detail-val val-green">${fmtCost(node.data.cost)}</span></div>`;
                html += `</div>`;
            }
            if (node.data.trace && node.data.trace.length > 0) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">TRACE SPANS</div>`;
                for (const s of node.data.trace) {
                    html += `<div class="telem-span" data-type="${esc(s.type)}">`;
                    html += `<span class="span-name">${esc(s.name)}</span>`;
                    html += `<span class="span-type">${esc(s.type)}</span>`;
                    html += `<span class="span-duration">${_fmtMs(s.duration_ms)}</span>`;
                    html += `</div>`;
                }
                html += `</div>`;
            }
            if (node.data.tool_calls && node.data.tool_calls.length > 0) {
                html += `<div class="flow-detail-section">`;
                html += `<div class="flow-detail-section-title">TOOL CALL LOG</div>`;
                for (const tc of node.data.tool_calls) {
                    html += `<div class="telem-tool-call">`;
                    html += `<div class="telem-tool-name">${esc(tc.name)}</div>`;
                    html += `<div class="telem-tool-latency">${_fmtMs(tc.latency_ms)}</div>`;
                    html += `</div>`;
                }
                html += `</div>`;
            }
        }

        if (node.type === "guard") {
            html += `<div class="flow-detail-section">`;
            html += `<div class="flow-detail-section-title">GUARD RESULTS</div>`;
            if (node.data.guards && node.data.guards.length > 0) {
                for (const g of node.data.guards) {
                    html += `<div class="telem-guard-item">`;
                    html += `<div class="telem-guard-row">`;
                    html += `<span class="telem-guard-name">${esc(g.name)}</span>`;
                    html += `<span class="telem-guard-badge ${g.passed ? "pass" : "fail"}">${g.passed ? "PASS" : "FAIL"}</span>`;
                    html += `</div>`;
                    if (g.duration_ms) html += `<div class="telem-guard-duration">${_fmtMs(g.duration_ms)}</div>`;
                    if (!g.passed && g.violation_message) html += `<div class="telem-guard-violation">${esc(g.violation_message)}</div>`;
                    html += `</div>`;
                }
            }
            html += `</div>`;
        }

        if (node.type === "error") {
            html += `<div class="flow-detail-section">`;
            html += `<div class="flow-detail-section-title">ERROR DETAILS</div>`;
            html += `<div class="flow-detail-pre" style="color:var(--red)">${esc(node.data.error || "Unknown error")}</div>`;
            html += `</div>`;
        }

        detailBody.innerHTML = html;
        // Mirror to inline detail panel
        if (inlineDetailTitle) inlineDetailTitle.textContent = detailTitle.textContent;
        if (inlineDetailBody) inlineDetailBody.innerHTML = html;
    }

    // --- Event wiring (called from sendPrompt) ---

    function onRunStart(prompt) {
        reset();
        runCounter++;
        if (runLabel) runLabel.textContent = `Run #${runCounter}`;
        addNode("prompt", "User Prompt", _truncate(prompt, 60), "done", { text: prompt });
        _agentNodeId = addNode("agent", "Agent", "Processing...", "running", {});
    }

    let _agentNodeId = null;
    let _thinkingNodeId = null;
    let _thinkingText = "";

    function onThinking(text) {
        _thinkingText += text;
        if (!_thinkingNodeId) {
            _thinkingNodeId = addNode("thinking", "Reasoning", "Thinking...", "running", { text: _thinkingText });
        } else {
            updateNode(_thinkingNodeId, { data: { text: _thinkingText }, sub: _truncate(_thinkingText, 50) });
        }
    }

    function onThinkingDone() {
        if (_thinkingNodeId) {
            updateNode(_thinkingNodeId, { status: "done", sub: _truncate(_thinkingText, 50) });
        }
    }

    function onToolCall(name, args, agentName) {
        // Mark agent as delegating
        if (_agentNodeId) {
            updateNode(_agentNodeId, { sub: `Calling ${name}...` });
        }
        const sub = args && Object.keys(args).length > 0
            ? _truncate(JSON.stringify(args), 50) : "";
        const nid = addNode("tool", name, sub, "running", { args, agent_name: agentName });
        pendingToolNodes[name] = nid;
    }

    function onToolResult(name, result) {
        const nid = pendingToolNodes[name];
        if (nid) {
            const resultStr = String(result).substring(0, 200);
            updateNode(nid, {
                status: "done",
                sub: _truncate(resultStr, 50),
                data: { result },
            });
            delete pendingToolNodes[name];
        }
        // Restore agent status
        if (_agentNodeId) {
            updateNode(_agentNodeId, { sub: "Processing..." });
        }
    }

    function onAgentStart(agentName) {
        if (_agentNodeId) {
            updateNode(_agentNodeId, { status: "done" });
        }
        _agentNodeId = addNode("agent", agentName, "Processing...", "running", { agent_name: agentName });
    }

    function onAgentComplete(agentName, data) {
        if (_agentNodeId) {
            updateNode(_agentNodeId, { status: "done", sub: "Complete" });
        }
    }

    function onGuardResult(guards) {
        if (guards && guards.length > 0) {
            const allPassed = guards.every(g => g.passed);
            const label = allPassed ? "Guards Passed" : "Guard Violation";
            const status = allPassed ? "done" : "error";
            addNode("guard", label, `${guards.length} guard${guards.length !== 1 ? "s" : ""} checked`, status, { guards });
        }
    }

    function onDone(data) {
        // Finalize thinking
        onThinkingDone();
        // Mark agent done
        if (_agentNodeId) {
            updateNode(_agentNodeId, { status: "done", sub: "Complete" });
        }
        // Add output node
        const outputSub = data.text ? _truncate(data.text, 60) : "Response complete";
        addNode("output", "Output", outputSub, "done", {
            text: data.text,
            tokens: data.tokens,
            cost: data.cost,
            latency_ms: data.latency_ms,
            trace: data.trace,
            tool_calls: data.tool_calls,
            output: data.output,
        });
        // Reset transient state
        _agentNodeId = null;
        _thinkingNodeId = null;
        _thinkingText = "";
    }

    function onError(error) {
        if (_agentNodeId) {
            updateNode(_agentNodeId, { status: "error", sub: "Failed" });
        }
        addNode("error", "Error", _truncate(error, 60), "error", { error });
        _agentNodeId = null;
        _thinkingNodeId = null;
        _thinkingText = "";
    }

    function _truncate(str, max) {
        if (!str) return "";
        return str.length > max ? str.substring(0, max) + "..." : str;
    }

    // --- Event listeners ---
    if (btnClose) btnClose.addEventListener("click", () => {
        if (detailPanel) detailPanel.classList.add("hidden");
        if (inlineDetail) inlineDetail.classList.add("hidden");
        if (selectedId) {
            const node = nodes.find(n => n.id === selectedId);
            if (node) {
                node.el.classList.remove("selected");
                if (node.inlineEl) node.inlineEl.classList.remove("selected");
            }
        }
        selectedId = null;
    });
    if (btnInlineClose) btnInlineClose.addEventListener("click", () => {
        if (detailPanel) detailPanel.classList.add("hidden");
        if (inlineDetail) inlineDetail.classList.add("hidden");
        if (selectedId) {
            const node = nodes.find(n => n.id === selectedId);
            if (node) {
                node.el.classList.remove("selected");
                if (node.inlineEl) node.inlineEl.classList.remove("selected");
            }
        }
        selectedId = null;
    });
    if (btnClear) btnClear.addEventListener("click", reset);

    // --- Flow history per turn ---
    let turnHistory = {};  // turnId → serialized node data
    let turnCounter = 0;
    let activeTurnMsgEl = null;

    function saveTurn() {
        const turnId = "turn-" + (++turnCounter);
        // Serialize current nodes (without DOM elements)
        turnHistory[turnId] = nodes.map(n => ({
            id: n.id, type: n.type, label: n.label, sub: n.sub,
            status: n.status, data: n.data,
        }));
        return turnId;
    }

    function loadTurn(turnId, msgEl) {
        const saved = turnHistory[turnId];
        if (!saved) return;

        // Highlight active message
        if (activeTurnMsgEl) activeTurnMsgEl.classList.remove("flow-active");
        activeTurnMsgEl = msgEl;
        if (msgEl) msgEl.classList.add("flow-active");

        // Clear current inline graph and rebuild from saved data
        selectedId = null;
        nodes = [];
        if (inlineGraph) inlineGraph.innerHTML = "";
        if (inlineEmpty) inlineEmpty.classList.add("hidden");
        if (inlineGraph) inlineGraph.classList.remove("hidden");
        if (inlineDetail) inlineDetail.classList.add("hidden");
        // Also update standalone Flow tab
        if (graph) graph.innerHTML = "";
        if (empty) empty.classList.add("hidden");
        if (graph) graph.classList.remove("hidden");
        if (detailPanel) detailPanel.classList.add("hidden");

        for (let i = 0; i < saved.length; i++) {
            const s = saved[i];
            if (i > 0) _addConnector(true);
            const el = _createNode(s.id, s.type, s.label, s.sub, s.status, s.data);
            el.addEventListener("click", () => _selectNode(s.id));
            const node = { id: s.id, type: s.type, label: s.label, sub: s.sub, status: s.status, data: s.data, el, ts: 0, inlineEl: null };

            if (graph) graph.appendChild(el);
            if (inlineGraph) {
                const inlineEl = _createNode(s.id, s.type, s.label, s.sub, s.status, s.data);
                inlineEl.addEventListener("click", () => _selectNode(s.id));
                node.inlineEl = inlineEl;
                inlineGraph.appendChild(inlineEl);
            }
            // Apply done class for completed nodes
            if (s.status === "done" || s.status === "error") {
                el.classList.add("flow-node-done");
                if (node.inlineEl) node.inlineEl.classList.add("flow-node-done");
            }
            nodes.push(node);
        }

        if (runLabel) runLabel.textContent = `Turn ${turnId.replace("turn-", "#")}`;
    }

    return {
        reset, addNode, addParallelTools, updateNode,
        onRunStart, onThinking, onThinkingDone,
        onToolCall, onToolResult,
        onAgentStart, onAgentComplete,
        onGuardResult, onDone, onError,
        saveTurn, loadTurn,
    };
})();

init();
