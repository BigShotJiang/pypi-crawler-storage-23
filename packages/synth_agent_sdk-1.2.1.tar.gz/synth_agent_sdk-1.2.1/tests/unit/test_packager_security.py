"""Unit tests for packager credential scan and .env exclusion.

Tests that ``synth/deploy/packager.py`` rejects ``agentcore.yaml`` files
containing AWS credential patterns and excludes ``.env`` files from artifacts.
"""

from __future__ import annotations

import textwrap
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from synth.deploy.packager import _EXCLUDED, _scan_for_credentials
from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# _scan_for_credentials unit tests
# ---------------------------------------------------------------------------


class TestScanForCredentials:
    """Tests for the internal credential pattern scanner."""

    def test_akia_key_detected(self) -> None:
        text = "access_key: AKIAIOSFODNN7EXAMPLE"
        assert _scan_for_credentials(text) is True

    def test_asia_key_detected(self) -> None:
        text = "access_key: ASIAIOSFODNN7EXAMPLE"
        assert _scan_for_credentials(text) is True

    def test_40_char_base64_secret_detected(self) -> None:
        # 40 chars of base64-like characters
        text = "secret: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
        assert _scan_for_credentials(text) is True

    def test_clean_text_not_detected(self) -> None:
        text = "aws_region: us-east-1\nmodel_id: anthropic.claude-3-5-haiku\n"
        assert _scan_for_credentials(text) is False

    def test_empty_string_not_detected(self) -> None:
        assert _scan_for_credentials("") is False

    def test_short_akia_prefix_not_detected(self) -> None:
        # AKIA with fewer than 16 trailing chars — should not match
        assert _scan_for_credentials("AKIA123") is False


# ---------------------------------------------------------------------------
# _EXCLUDED set tests
# ---------------------------------------------------------------------------


class TestExcludedSet:
    """Verify that sensitive files/dirs are in _EXCLUDED."""

    def test_env_file_excluded(self) -> None:
        assert ".env" in _EXCLUDED

    def test_synth_dir_excluded(self) -> None:
        assert ".synth" in _EXCLUDED

    def test_git_dir_excluded(self) -> None:
        assert ".git" in _EXCLUDED


# ---------------------------------------------------------------------------
# package() integration tests (filesystem-level)
# ---------------------------------------------------------------------------


class TestPackageCredentialScan:
    """Tests for credential scanning inside package()."""

    def _make_agent(self) -> MagicMock:
        agent = MagicMock()
        agent.name = "test-agent"
        agent.description = "test"
        return agent

    def test_akia_in_agentcore_yaml_raises(self, tmp_path: Path) -> None:
        """agentcore.yaml with AKIA key raises SynthConfigError."""
        (tmp_path / "agentcore.yaml").write_text(
            "access_key: AKIAIOSFODNN7EXAMPLE\n", encoding="utf-8"
        )
        (tmp_path / "agent.py").write_text("# agent\n", encoding="utf-8")

        manifest = {
            "name": "test-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            with pytest.raises(SynthConfigError) as exc_info:
                package(
                    self._make_agent(),
                    source_dir=str(tmp_path),
                    output_dir=str(tmp_path / "dist"),
                )

        assert exc_info.value.component == "Packager"
        assert exc_info.value.suggestion

    def test_asia_in_agentcore_yaml_raises(self, tmp_path: Path) -> None:
        """agentcore.yaml with ASIA key raises SynthConfigError."""
        (tmp_path / "agentcore.yaml").write_text(
            "access_key: ASIAIOSFODNN7EXAMPLE\n", encoding="utf-8"
        )

        manifest = {
            "name": "test-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            with pytest.raises(SynthConfigError) as exc_info:
                package(
                    self._make_agent(),
                    source_dir=str(tmp_path),
                    output_dir=str(tmp_path / "dist"),
                )

        assert exc_info.value.component == "Packager"

    def test_clean_agentcore_yaml_passes(self, tmp_path: Path) -> None:
        """Clean agentcore.yaml (no credentials) does not raise."""
        (tmp_path / "agentcore.yaml").write_text(
            textwrap.dedent("""\
                agent_name: my-agent
                aws_region: us-east-1
                model_id: anthropic.claude-3-5-haiku
                cris_enabled: false
                aws_profile: my-profile
            """),
            encoding="utf-8",
        )
        (tmp_path / "agent.py").write_text("# agent\n", encoding="utf-8")

        manifest = {
            "name": "my-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            result = package(
                self._make_agent(),
                source_dir=str(tmp_path),
                output_dir=str(tmp_path / "dist"),
            )

        assert result["name"] == "my-agent"

    def test_no_agentcore_yaml_passes(self, tmp_path: Path) -> None:
        """Missing agentcore.yaml skips the scan without error."""
        (tmp_path / "agent.py").write_text("# agent\n", encoding="utf-8")

        manifest = {
            "name": "my-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            result = package(
                self._make_agent(),
                source_dir=str(tmp_path),
                output_dir=str(tmp_path / "dist"),
            )

        assert result["name"] == "my-agent"

    def test_secret_key_in_agentcore_yaml_raises(self, tmp_path: Path) -> None:
        """agentcore.yaml with a 40-char secret key raises SynthConfigError."""
        (tmp_path / "agentcore.yaml").write_text(
            "secret_key: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\n",
            encoding="utf-8",
        )

        manifest = {
            "name": "test-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            with pytest.raises(SynthConfigError) as exc_info:
                package(
                    self._make_agent(),
                    source_dir=str(tmp_path),
                    output_dir=str(tmp_path / "dist"),
                )

        assert exc_info.value.component == "Packager"

    def test_dry_run_skips_credential_scan(self, tmp_path: Path) -> None:
        """dry_run=True returns manifest without scanning agentcore.yaml."""
        (tmp_path / "agentcore.yaml").write_text(
            "access_key: AKIAIOSFODNN7EXAMPLE\n", encoding="utf-8"
        )

        manifest = {
            "name": "test-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            # Should not raise — dry_run bypasses the scan
            result = package(
                self._make_agent(),
                source_dir=str(tmp_path),
                output_dir=str(tmp_path / "dist"),
                dry_run=True,
            )

        assert result == manifest

    def test_env_file_excluded_from_artifact(self, tmp_path: Path) -> None:
        """.env file is not copied into the deployment artifact."""
        (tmp_path / ".env").write_text(
            "SECRET_KEY=supersecret\n", encoding="utf-8"
        )
        (tmp_path / "agent.py").write_text("# agent\n", encoding="utf-8")

        manifest = {
            "name": "my-agent",
            "description": "test",
            "permissions": [],
            "runtime": {},
            "environment": {},
        }
        with patch(
            "synth.deploy.packager.generate_manifest", return_value=manifest
        ):
            from synth.deploy.packager import package

            package(
                self._make_agent(),
                source_dir=str(tmp_path),
                output_dir=str(tmp_path / "dist"),
            )

        artifact_dir = tmp_path / "dist" / "my-agent"
        assert not (artifact_dir / ".env").exists()
        assert (artifact_dir / "agent.py").exists()
