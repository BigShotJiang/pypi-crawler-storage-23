"""Unit tests for CLI reliability fixes.

Covers:
- Non-existent file path raises ``SystemExit(1)`` with a clear error message
- Duplicate ``sys.path`` prevention when loading the same agent file twice
- Agent instance fallback when ``module.agent`` is absent
- Error message when no ``agent`` variable or ``Agent`` instance is found
- ``synth ui`` subprocess uses ``sys.executable``
- ``synth ui`` passes ``SYNTH_AGENT_FILE`` env var to subprocess
- ``synth ui`` agent discovery fallback when file is omitted
- ``synth ui`` keyboard interrupt handling
- Init flow UI launch passes ``SYNTH_AGENT_FILE`` in subprocess env
- Init flow UI launch uses ``sys.executable``
- Single-agent and multi-agent flows use the same launch logic
- Content sanitization replaces empty/blank strings with placeholder
- Content sanitization passes through non-blank strings unchanged
- ``_sanitize_content`` is importable and wired into agent module
- Dockerfile folder validation: matching folder returns success
- Dockerfile folder validation: non-matching folder returns failure with suggestions
- Dockerfile folder validation: missing ``.bedrock_agentcore/`` directory skips validation
- Dockerfile folder validation: multiple folders listed in suggestion on mismatch
- Dockerfile folder validation: empty directory returns ``(none)`` in suggestion

_Requirements: 1.2, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5, 3.2, 3.3, 3.4, 5.1, 5.2, 5.3, 5.4, 5.5, 6.2, 6.3, 6.5_
"""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from synth.cli.run_cmd import _load_agent


# ---------------------------------------------------------------------------
# Agent Loader — non-existent file tests
# ---------------------------------------------------------------------------


class TestLoadAgentNonExistentFile:
    """Test that _load_agent raises a clear error for missing files."""

    def test_non_existent_file_exits_with_code_1(self, tmp_path: Path) -> None:
        """A file path that does not exist should cause sys.exit(1).

        **Validates: Requirement 1.5**
        """
        missing = str(tmp_path / "does_not_exist.py")
        with pytest.raises(SystemExit) as exc_info:
            _load_agent(missing)
        assert exc_info.value.code == 1

    def test_non_existent_file_prints_error_with_path(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        """The error message should identify the missing file path.

        **Validates: Requirement 1.5**
        """
        missing = str(tmp_path / "no_such_agent.py")
        with pytest.raises(SystemExit):
            _load_agent(missing)
        captured = capsys.readouterr()
        assert "no_such_agent.py" in captured.err
        assert "file not found" in captured.err


# ---------------------------------------------------------------------------
# Agent Loader — duplicate sys.path prevention
# ---------------------------------------------------------------------------


class TestLoadAgentDuplicateSysPath:
    """Test that sys.path does not accumulate duplicate entries."""

    def test_no_duplicate_sys_path_entries(self, tmp_path: Path) -> None:
        """Loading an agent when its parent dir is already in sys.path
        should not add a duplicate entry.

        **Validates: Requirement 1.2**
        """
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = 'placeholder'\n")

        agent_dir = str(tmp_path.resolve())
        original_path = sys.path.copy()
        try:
            # Pre-inject the directory to simulate a prior load
            if agent_dir not in sys.path:
                sys.path.insert(0, agent_dir)

            count_before = sys.path.count(agent_dir)

            # Patch importlib.util so we control spec/loader/module
            # without actually executing the agent file.
            mock_loader = MagicMock()
            mock_spec = MagicMock()
            mock_spec.loader = mock_loader
            mock_module = MagicMock()
            mock_module.agent = "fake_agent"

            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                _load_agent(str(agent_file))

            count_after = sys.path.count(agent_dir)
            assert count_after == count_before, (
                f"sys.path should not gain duplicates: had {count_before}, "
                f"now has {count_after}"
            )
        finally:
            sys.path[:] = original_path


# ---------------------------------------------------------------------------
# Agent Loader — explicit `agent` variable takes priority
# ---------------------------------------------------------------------------


class TestLoadAgentExplicitVariable:
    """Test that _load_agent returns module.agent when it exists."""

    def test_returns_module_agent_when_present(self, tmp_path: Path) -> None:
        """When the module defines an ``agent`` attribute, return it directly
        without scanning for Agent instances."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = 'placeholder'\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader
        mock_module = MagicMock()
        mock_module.agent = "explicit_agent"

        original_path = sys.path.copy()
        try:
            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                result = _load_agent(str(agent_file))

            assert result == "explicit_agent"
        finally:
            sys.path[:] = original_path


# ---------------------------------------------------------------------------
# Agent Loader — Agent instance fallback
# ---------------------------------------------------------------------------


class TestLoadAgentInstanceFallback:
    """Test that _load_agent falls back to the first Agent instance
    when no ``agent`` attribute exists on the module.

    This supports multi-agent projects where the variable is named
    after the agent (e.g. ``molly_mikes = Agent(...)``).
    """

    def test_returns_first_agent_instance(self, tmp_path: Path) -> None:
        """When module has no ``agent`` attr but has an Agent instance,
        that instance is returned."""
        from synth.agent import Agent

        agent_file = tmp_path / "agent.py"
        agent_file.write_text("x = 1\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader

        # Build a module-like object without an ``agent`` attribute
        # but with a named Agent instance.
        mock_module = MagicMock(spec=[])
        fake_agent = MagicMock(spec=Agent)
        mock_module.molly_mikes = fake_agent
        # Make dir() return the attribute names we control.
        mock_module.__dir__ = lambda self: ["molly_mikes"]

        original_path = sys.path.copy()
        try:
            with (
                patch("synth.cli.run_cmd.importlib.util") as mock_util,
                patch("synth.cli.run_cmd.Agent", Agent),
            ):
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                result = _load_agent(str(agent_file))

            assert result is fake_agent
        finally:
            sys.path[:] = original_path

    def test_prefers_agent_attr_over_instance_scan(
        self, tmp_path: Path,
    ) -> None:
        """When module has both ``agent`` attr and other Agent instances,
        the explicit ``agent`` attr wins."""
        from synth.agent import Agent

        agent_file = tmp_path / "agent.py"
        agent_file.write_text("agent = 1\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader

        explicit_agent = "the_explicit_one"
        other_agent = MagicMock(spec=Agent)

        mock_module = MagicMock(spec=[])
        mock_module.agent = explicit_agent
        mock_module.other_bot = other_agent
        mock_module.__dir__ = lambda self: ["agent", "other_bot"]

        original_path = sys.path.copy()
        try:
            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                result = _load_agent(str(agent_file))

            assert result == explicit_agent
        finally:
            sys.path[:] = original_path


# ---------------------------------------------------------------------------
# Agent Loader — no agent found error
# ---------------------------------------------------------------------------


class TestLoadAgentNoAgentFound:
    """Test that _load_agent exits with a clear error when neither
    ``module.agent`` nor any Agent instance is found."""

    def test_exits_with_code_1(self, tmp_path: Path) -> None:
        """SystemExit(1) when module has no agent variable or instance."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("x = 42\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader

        # Module with no ``agent`` attr and no Agent instances.
        mock_module = MagicMock(spec=[])
        mock_module.x = 42
        mock_module.__dir__ = lambda self: ["x"]

        original_path = sys.path.copy()
        try:
            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                with pytest.raises(SystemExit) as exc_info:
                    _load_agent(str(agent_file))

                assert exc_info.value.code == 1
        finally:
            sys.path[:] = original_path

    def test_error_message_mentions_agent_variable_and_instance(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        """Error message should mention both 'agent' variable and
        Agent instance as valid options."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("x = 42\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader

        mock_module = MagicMock(spec=[])
        mock_module.x = 42
        mock_module.__dir__ = lambda self: ["x"]

        original_path = sys.path.copy()
        try:
            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                with pytest.raises(SystemExit):
                    _load_agent(str(agent_file))
        finally:
            sys.path[:] = original_path

        captured = capsys.readouterr()
        assert "agent" in captured.err
        assert "Agent instance" in captured.err

    def test_error_message_includes_filename(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str],
    ) -> None:
        """Error message should include the file path for context."""
        agent_file = tmp_path / "my_bot.py"
        agent_file.write_text("x = 1\n")

        mock_loader = MagicMock()
        mock_spec = MagicMock()
        mock_spec.loader = mock_loader

        mock_module = MagicMock(spec=[])
        mock_module.x = 1
        mock_module.__dir__ = lambda self: ["x"]

        original_path = sys.path.copy()
        try:
            with patch("synth.cli.run_cmd.importlib.util") as mock_util:
                mock_util.spec_from_file_location.return_value = mock_spec
                mock_util.module_from_spec.return_value = mock_module

                with pytest.raises(SystemExit):
                    _load_agent(str(agent_file))
        finally:
            sys.path[:] = original_path

        captured = capsys.readouterr()
        assert "my_bot.py" in captured.err


# ---------------------------------------------------------------------------
# `synth ui` command tests
# ---------------------------------------------------------------------------


class TestUiCmdSubprocessUsesSysExecutable:
    """Test that `synth ui` launches the server with `sys.executable`.

    **Validates: Requirement 2.1**
    """

    def test_subprocess_invoked_with_sys_executable(self) -> None:
        """The first element of the subprocess args must be sys.executable."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch("subprocess.run") as mock_run:
            runner = CliRunner()
            runner.invoke(cli, ["ui", "my_agent.py"])

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args[0] == sys.executable

    def test_subprocess_invoked_with_server_path(self) -> None:
        """The second element should be the server.py path."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch("subprocess.run") as mock_run:
            runner = CliRunner()
            runner.invoke(cli, ["ui", "my_agent.py"])

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args[1].endswith("server.py")
        assert "_ui_assets" in args[1]


class TestUiCmdEnvVar:
    """Test that `synth ui` passes SYNTH_AGENT_FILE to the subprocess.

    **Validates: Requirement 2.2**
    """

    def test_synth_agent_file_env_var_is_set(self) -> None:
        """The subprocess env must contain SYNTH_AGENT_FILE matching the arg."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch("subprocess.run") as mock_run:
            runner = CliRunner()
            runner.invoke(cli, ["ui", "my_agent.py"])

        mock_run.assert_called_once()
        sub_env = mock_run.call_args[1]["env"]
        assert sub_env["SYNTH_AGENT_FILE"] == "my_agent.py"

    def test_synth_agent_file_env_var_preserves_path(self) -> None:
        """Paths with directories should be passed through unchanged."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch("subprocess.run") as mock_run:
            runner = CliRunner()
            runner.invoke(cli, ["ui", "src/agents/bot.py"])

        sub_env = mock_run.call_args[1]["env"]
        assert sub_env["SYNTH_AGENT_FILE"] == "src/agents/bot.py"


class TestUiCmdPrintsUrl:
    """Test that `synth ui` prints the server URL before launching.

    **Validates: Requirement 2.5**
    """

    def test_output_contains_localhost_url(self) -> None:
        """The command output should include the localhost URL."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch("subprocess.run"):
            runner = CliRunner()
            result = runner.invoke(cli, ["ui", "my_agent.py"])

        assert "http://localhost:8420" in result.output


class TestUiCmdAgentDiscoveryFallback:
    """Test that `synth ui` uses agent discovery when file is omitted.

    **Validates: Requirement 2.4**
    """

    def test_no_agents_found_prints_warning(self) -> None:
        """When no agent files are found, print a warning and exit."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch(
            "synth.cli.discover.discover_agents", return_value=[],
        ), patch("subprocess.run") as mock_run:
            runner = CliRunner()
            result = runner.invoke(cli, ["ui"])

        mock_run.assert_not_called()
        assert "No agent files found" in result.output

    def test_single_agent_auto_selected(self) -> None:
        """When exactly one agent is found, it should be auto-selected."""
        from click.testing import CliRunner
        from synth.cli.discover import DiscoveredAgent
        from synth.cli.main import cli

        agent = DiscoveredAgent(file="found_agent.py", name="FoundAgent")

        with patch(
            "synth.cli.discover.discover_agents", return_value=[agent],
        ), patch("subprocess.run") as mock_run:
            runner = CliRunner()
            runner.invoke(cli, ["ui"])

        mock_run.assert_called_once()
        sub_env = mock_run.call_args[1]["env"]
        assert sub_env["SYNTH_AGENT_FILE"] == "found_agent.py"


class TestUiCmdKeyboardInterrupt:
    """Test that KeyboardInterrupt is handled gracefully.

    **Validates: Requirement 2.1**
    """

    def test_keyboard_interrupt_prints_stopped_message(self) -> None:
        """Ctrl-C during subprocess should print a stopped message."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        with patch(
            "subprocess.run",
            side_effect=KeyboardInterrupt,
        ):
            runner = CliRunner()
            result = runner.invoke(cli, ["ui", "my_agent.py"])

        assert "UI server stopped" in result.output


# ---------------------------------------------------------------------------
# Init flow — UI launch subprocess tests
# ---------------------------------------------------------------------------

_IS_UI_RUNNING_PATH = "synth.cli.init_cmd._is_ui_server_running"
_SCAFFOLD_UI_PATH = "synth.cli.init_cmd._scaffold_global_ui"
_INIT_SUBPROCESS_RUN_PATH = "synth.cli.init_cmd.subprocess.run"


def _invoke_prompt_testing_mode(
    input_str: str,
    project_dir: str = "proj",
    agent_file: str = "agent.py",
) -> tuple[MagicMock, MagicMock]:
    """Helper to invoke ``_prompt_testing_mode`` in a Click context.

    Returns the (mock_run, mock_scaffold) pair so callers can inspect
    the subprocess call.
    """
    import click
    from click.testing import CliRunner

    mock_run = MagicMock()
    mock_scaffold = MagicMock(return_value="ui/server.py")

    with (
        patch(_IS_UI_RUNNING_PATH, return_value=False),
        patch(_SCAFFOLD_UI_PATH, mock_scaffold),
        patch(_INIT_SUBPROCESS_RUN_PATH, mock_run),
    ):
        from synth.cli.init_cmd import _prompt_testing_mode

        @click.command()
        def cmd() -> None:
            _prompt_testing_mode(project_dir, agent_file)

        CliRunner().invoke(cmd, input=input_str)

    return mock_run, mock_scaffold


class TestInitFlowUiLaunchEnvVar:
    """Test that the init flow passes SYNTH_AGENT_FILE in subprocess env.

    **Validates: Requirement 3.4**
    """

    def test_synth_agent_file_set_in_subprocess_env(self) -> None:
        """Selecting 'ui' and confirming launch should pass
        SYNTH_AGENT_FILE to the subprocess environment.
        """
        mock_run, _ = _invoke_prompt_testing_mode("ui\ny\n")

        mock_run.assert_called_once()
        sub_env = mock_run.call_args[1]["env"]
        assert "SYNTH_AGENT_FILE" in sub_env

    def test_synth_agent_file_contains_correct_path(self) -> None:
        """SYNTH_AGENT_FILE should be project_dir/agent_file."""
        import os

        mock_run, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", project_dir="myproject", agent_file="agent.py",
        )

        sub_env = mock_run.call_args[1]["env"]
        expected = os.path.join("myproject", "agent.py")
        assert sub_env["SYNTH_AGENT_FILE"] == expected

    def test_synth_agent_file_with_custom_agent_file(self) -> None:
        """A non-default agent_file should be reflected in the env var."""
        import os

        mock_run, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", project_dir="team", agent_file="main.py",
        )

        sub_env = mock_run.call_args[1]["env"]
        expected = os.path.join("team", "main.py")
        assert sub_env["SYNTH_AGENT_FILE"] == expected


class TestInitFlowUiLaunchUsesSysExecutable:
    """Test that the init flow launches the UI server with sys.executable.

    **Validates: Requirement 3.2**
    """

    def test_subprocess_first_arg_is_sys_executable(self) -> None:
        """The subprocess command should start with sys.executable."""
        mock_run, _ = _invoke_prompt_testing_mode("ui\ny\n")

        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args[0] == sys.executable


class TestInitFlowSingleAndMultiAgentParity:
    """Test that single-agent and multi-agent flows use the same function.

    Both ``run_init`` (single-agent, passes ``"agent.py"``) and
    ``_run_multi_agent_init`` (multi-agent, passes ``"main.py"``) call
    ``_prompt_testing_mode``. We verify the subprocess launch logic is
    identical by exercising the function with both agent file names.

    **Validates: Requirements 3.3, 3.4**
    """

    def test_single_agent_flow_passes_agent_py(self) -> None:
        """Single-agent flow: agent_file='agent.py' appears in env."""
        import os

        mock_run, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", project_dir="single", agent_file="agent.py",
        )

        sub_env = mock_run.call_args[1]["env"]
        assert sub_env["SYNTH_AGENT_FILE"] == os.path.join(
            "single", "agent.py",
        )
        args = mock_run.call_args[0][0]
        assert args[0] == sys.executable

    def test_multi_agent_flow_passes_main_py(self) -> None:
        """Multi-agent flow: agent_file='main.py' appears in env."""
        import os

        mock_run, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", project_dir="multi", agent_file="main.py",
        )

        sub_env = mock_run.call_args[1]["env"]
        assert sub_env["SYNTH_AGENT_FILE"] == os.path.join(
            "multi", "main.py",
        )
        args = mock_run.call_args[0][0]
        assert args[0] == sys.executable

    def test_both_flows_use_same_server_path(self) -> None:
        """Both flows should launch the same ui/server.py path."""
        import os

        mock_single, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", agent_file="agent.py",
        )
        mock_multi, _ = _invoke_prompt_testing_mode(
            "ui\ny\n", agent_file="main.py",
        )

        single_args = mock_single.call_args[0][0]
        multi_args = mock_multi.call_args[0][0]
        assert single_args[1] == multi_args[1]
        assert single_args[1] == os.path.join("ui", "server.py")

# ---------------------------------------------------------------------------
# Content sanitization — _sanitize_content unit tests
# ---------------------------------------------------------------------------


class TestSanitizeContentEmptyInputs:
    """Test that _sanitize_content replaces empty/blank inputs with a placeholder.

    _Requirements: 5.1, 5.2, 5.3_
    """

    @pytest.mark.parametrize(
        ("input_text", "expected"),
        [
            ("", "(no content)"),
            ("   ", "(no content)"),
            ("\t\n", "(no content)"),
            ("\r\n", "(no content)"),
        ],
        ids=["empty-string", "spaces-only", "tab-newline", "crlf"],
    )
    def test_blank_inputs_return_placeholder(
        self, input_text: str, expected: str,
    ) -> None:
        """Empty and whitespace-only strings are replaced with '(no content)'."""
        from synth.agent import _sanitize_content

        assert _sanitize_content(input_text) == expected


class TestSanitizeContentPassthrough:
    """Test that _sanitize_content passes through non-blank strings unchanged.

    _Requirements: 5.1, 5.2, 5.3_
    """

    @pytest.mark.parametrize(
        "input_text",
        [
            "hello",
            "  hello  ",
            "result: 42",
            " \t data \n ",
        ],
        ids=["plain", "padded", "with-colon", "mixed-whitespace-around-content"],
    )
    def test_non_blank_inputs_pass_through(self, input_text: str) -> None:
        """Strings with at least one non-whitespace char are returned as-is."""
        from synth.agent import _sanitize_content

        assert _sanitize_content(input_text) == input_text


class TestSanitizeContentImportable:
    """Verify _sanitize_content is importable from synth.agent.

    This confirms the function is available for use in both arun and astream,
    satisfying the integration requirement without needing full provider mocks.

    _Requirements: 5.4, 5.5_
    """

    def test_function_is_importable(self) -> None:
        """_sanitize_content can be imported from synth.agent."""
        from synth.agent import _sanitize_content

        assert callable(_sanitize_content)

    def test_function_is_used_in_agent_module(self) -> None:
        """_sanitize_content is referenced in the agent module source.

        This is a lightweight check that the function is wired into the
        agent's message-building logic (arun / astream) without requiring
        a full provider mock.
        """
        import inspect
        import synth.agent as agent_module

        source = inspect.getsource(agent_module)
        assert "_sanitize_content(str(result))" in source, (
            "_sanitize_content should be called on tool results in agent.py"
        )


# ---------------------------------------------------------------------------
# Dockerfile folder validation
# ---------------------------------------------------------------------------


class TestDockerfileFolderValidationMatchingFolder:
    """Matching folder under .bedrock_agentcore/ returns success.

    _Requirements: 6.2_
    """

    def test_matching_folder_returns_success(self, tmp_path: Path) -> None:
        """Success when agent name matches an existing folder."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        agentcore = tmp_path / ".bedrock_agentcore" / "my_agent"
        agentcore.mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.success is True
        assert "my_agent" in result.message

    def test_matching_folder_message_confirms_match(self, tmp_path: Path) -> None:
        """Success message explicitly states the folder matches."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore" / "demo_bot").mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("demo_bot", str(agent_file))

        assert "matches" in result.message.lower()


class TestDockerfileFolderValidationNonMatchingFolder:
    """Non-matching folder returns failure with available folder suggestions.

    _Requirements: 6.2, 6.3_
    """

    def test_non_matching_folder_returns_failure(self, tmp_path: Path) -> None:
        """Failure when agent name does not match any folder."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore" / "other_agent").mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.success is False

    def test_non_matching_folder_suggestion_contains_available(
        self, tmp_path: Path
    ) -> None:
        """Suggestion lists the available folder name."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore" / "other_agent").mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.suggestion is not None
        assert "other_agent" in result.suggestion

    def test_multiple_folders_all_listed_in_suggestion(
        self, tmp_path: Path
    ) -> None:
        """All available folders appear in the suggestion on mismatch."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        for name in ("alpha_bot", "beta_bot", "gamma_bot"):
            (tmp_path / ".bedrock_agentcore" / name).mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.success is False
        assert result.suggestion is not None
        for name in ("alpha_bot", "beta_bot", "gamma_bot"):
            assert name in result.suggestion

    def test_non_matching_message_includes_agent_name(
        self, tmp_path: Path
    ) -> None:
        """Error message includes the agent name that failed to match."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore" / "other").mkdir(parents=True)
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert "my_agent" in result.message


class TestDockerfileFolderValidationMissingDirectory:
    """Missing .bedrock_agentcore/ directory skips validation.

    _Requirements: 6.5_
    """

    def test_missing_directory_returns_success(self, tmp_path: Path) -> None:
        """Success (skip) when .bedrock_agentcore/ does not exist."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.success is True

    def test_missing_directory_message_indicates_skip(
        self, tmp_path: Path
    ) -> None:
        """Message indicates validation was skipped."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert "skipped" in result.message.lower()


class TestDockerfileFolderValidationEmptyDirectory:
    """Empty .bedrock_agentcore/ directory returns failure with (none).

    _Requirements: 6.3_
    """

    def test_empty_directory_returns_failure(self, tmp_path: Path) -> None:
        """Failure when .bedrock_agentcore/ exists but has no subfolders."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore").mkdir()
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.success is False

    def test_empty_directory_suggestion_shows_none(
        self, tmp_path: Path
    ) -> None:
        """Suggestion contains '(none)' when no folders exist."""
        from synth.cli.deploy_cmd import _stage_dockerfile_validation

        (tmp_path / ".bedrock_agentcore").mkdir()
        agent_file = tmp_path / "agent.py"
        agent_file.touch()

        result = _stage_dockerfile_validation("my_agent", str(agent_file))

        assert result.suggestion is not None
        assert "(none)" in result.suggestion
