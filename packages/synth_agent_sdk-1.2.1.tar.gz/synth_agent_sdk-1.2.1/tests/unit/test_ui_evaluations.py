"""Unit tests for AgentCore Evaluations API endpoints in server.py.

Covers tasks 6.1, 6.2, 6.3:
- GET /api/agentcore/evaluations
- POST /api/agentcore/evaluations/run
- GET /api/agentcore/evaluations/config
"""

from __future__ import annotations

import json
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers — import server module with mocked StaticFiles
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _patch_static_files():
    """Patch StaticFiles to avoid directory check during server import."""
    with patch("starlette.staticfiles.StaticFiles.__init__", return_value=None):
        mod_name = "synth.cli._ui_assets.server"
        if mod_name in sys.modules:
            del sys.modules[mod_name]
        yield
        if mod_name in sys.modules:
            del sys.modules[mod_name]


def _get_server():
    """Import the server module for direct state inspection."""
    import synth.cli._ui_assets.server as srv

    return srv


_SAMPLE_EVAL_CONFIG: dict[str, Any] = {
    "config_name": "my-agent-online-eval",
    "sampling_rate": 1.0,
    "evaluators": [
        {
            "id": "Builtin.Helpfulness",
            "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Helpfulness",
            "level": "TRACE",
        },
        {
            "id": "Builtin.Correctness",
            "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Correctness",
            "level": "TRACE",
        },
        {
            "id": "Builtin.GoalSuccessRate",
            "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.GoalSuccessRate",
            "level": "SESSION",
        },
    ],
}


# ---------------------------------------------------------------------------
# Credential scrubbing helpers
# ---------------------------------------------------------------------------


class TestScrubCredentials:
    """Tests for _scrub_credentials and _scrub_dict helpers."""

    def test_scrub_credentials_removes_access_key(self):
        srv = _get_server()
        text = "key=AKIAIOSFODNN7EXAMPLE1234"
        result = srv._scrub_credentials(text)
        assert "AKIA" not in result
        assert "[REDACTED]" in result

    def test_scrub_credentials_removes_temp_access_key(self):
        srv = _get_server()
        text = "key=ASIAIOSFODNN7EXAMPLE1234"
        result = srv._scrub_credentials(text)
        assert "ASIA" not in result

    def test_scrub_credentials_leaves_clean_text_unchanged(self):
        srv = _get_server()
        text = "no credentials here"
        assert srv._scrub_credentials(text) == text

    def test_scrub_dict_handles_nested_structures(self):
        srv = _get_server()
        data = {
            "name": "test",
            "nested": {"key": "AKIAIOSFODNN7EXAMPLE1234"},
            "items": ["ASIAIOSFODNN7EXAMPLE1234", "clean"],
        }
        result = srv._scrub_dict(data)
        assert "AKIA" not in json.dumps(result)
        assert "ASIA" not in json.dumps(result)
        assert result["name"] == "test"
        assert result["items"][1] == "clean"

    def test_scrub_dict_passes_through_non_string_values(self):
        srv = _get_server()
        data = {"score": 0.95, "active": True, "count": 42}
        assert srv._scrub_dict(data) == data


# ---------------------------------------------------------------------------
# GET /api/agentcore/evaluations
# ---------------------------------------------------------------------------


class TestGetEvaluations:
    """Tests for the GET /api/agentcore/evaluations endpoint."""

    @pytest.mark.asyncio
    async def test_returns_empty_when_not_configured(self):
        srv = _get_server()
        with patch.object(srv, "_parse_eval_config", return_value=None):
            resp = await srv.get_evaluations()
        body = json.loads(resp.body)
        assert body["results"] == []
        assert "not configured" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_returns_results_when_configured(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluations()
        body = json.loads(resp.body)
        assert len(body["results"]) == 3

    @pytest.mark.asyncio
    async def test_result_contains_required_fields(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluations()
        body = json.loads(resp.body)
        for result in body["results"]:
            assert "evaluator_name" in result
            assert "score" in result
            assert "level" in result
            assert "timestamp" in result

    @pytest.mark.asyncio
    async def test_result_evaluator_names_match_config(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluations()
        body = json.loads(resp.body)
        names = {r["evaluator_name"] for r in body["results"]}
        assert names == {
            "Builtin.Helpfulness",
            "Builtin.Correctness",
            "Builtin.GoalSuccessRate",
        }

    @pytest.mark.asyncio
    async def test_result_levels_match_config(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluations()
        body = json.loads(resp.body)
        levels = {r["evaluator_name"]: r["level"] for r in body["results"]}
        assert levels["Builtin.Helpfulness"] == "TRACE"
        assert levels["Builtin.GoalSuccessRate"] == "SESSION"

    @pytest.mark.asyncio
    async def test_credentials_scrubbed_from_results(self):
        """Credential patterns embedded in evaluator names are scrubbed."""
        srv = _get_server()
        cfg = {
            "evaluators": [
                {
                    "id": "AKIAIOSFODNN7EXAMPLE1234",
                    "level": "TRACE",
                },
            ],
        }
        with patch.object(srv, "_parse_eval_config", return_value=cfg):
            resp = await srv.get_evaluations()
        raw = resp.body.decode()
        assert "AKIA" not in raw


# ---------------------------------------------------------------------------
# POST /api/agentcore/evaluations/run
# ---------------------------------------------------------------------------


class TestRunOnDemandEvaluation:
    """Tests for the POST /api/agentcore/evaluations/run endpoint."""

    def _make_request(
        self, body: dict[str, Any] | None = None,
    ) -> MagicMock:
        req = MagicMock()
        req.json = AsyncMock(return_value=body or {})
        return req

    @pytest.mark.asyncio
    async def test_returns_400_when_not_configured(self):
        srv = _get_server()
        req = self._make_request()
        with patch.object(srv, "_parse_eval_config", return_value=None):
            resp = await srv.run_on_demand_evaluation(req)
        assert resp.status_code == 400
        body = json.loads(resp.body)
        assert "error" in body

    @pytest.mark.asyncio
    async def test_returns_all_evaluators_when_no_selection(self):
        srv = _get_server()
        req = self._make_request({})
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.run_on_demand_evaluation(req)
        body = json.loads(resp.body)
        assert len(body["results"]) == 3

    @pytest.mark.asyncio
    async def test_filters_evaluators_by_selection(self):
        srv = _get_server()
        req = self._make_request(
            {"evaluators": ["Builtin.Helpfulness"]},
        )
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.run_on_demand_evaluation(req)
        body = json.loads(resp.body)
        assert len(body["results"]) == 1
        assert body["results"][0]["evaluator_name"] == "Builtin.Helpfulness"

    @pytest.mark.asyncio
    async def test_result_contains_required_fields(self):
        srv = _get_server()
        req = self._make_request()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.run_on_demand_evaluation(req)
        body = json.loads(resp.body)
        for result in body["results"]:
            assert "evaluator_name" in result
            assert "score" in result
            assert "level" in result
            assert "timestamp" in result

    @pytest.mark.asyncio
    async def test_handles_invalid_json_body_gracefully(self):
        srv = _get_server()
        req = MagicMock()
        req.json = AsyncMock(side_effect=ValueError("bad json"))
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.run_on_demand_evaluation(req)
        body = json.loads(resp.body)
        # Should still return all evaluators when body parsing fails
        assert len(body["results"]) == 3

    @pytest.mark.asyncio
    async def test_credentials_scrubbed_from_run_results(self):
        srv = _get_server()
        cfg = {
            "evaluators": [
                {
                    "id": "ASIAIOSFODNN7EXAMPLE1234",
                    "level": "SESSION",
                },
            ],
        }
        req = self._make_request()
        with patch.object(srv, "_parse_eval_config", return_value=cfg):
            resp = await srv.run_on_demand_evaluation(req)
        raw = resp.body.decode()
        assert "ASIA" not in raw


# ---------------------------------------------------------------------------
# GET /api/agentcore/evaluations/config
# ---------------------------------------------------------------------------


class TestGetEvaluationConfig:
    """Tests for the GET /api/agentcore/evaluations/config endpoint."""

    @pytest.mark.asyncio
    async def test_returns_null_config_when_not_configured(self):
        srv = _get_server()
        with patch.object(srv, "_parse_eval_config", return_value=None):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        assert body["config"] is None
        assert "not configured" in body["message"].lower()

    @pytest.mark.asyncio
    async def test_returns_config_when_configured(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        assert body["config"] is not None

    @pytest.mark.asyncio
    async def test_config_contains_required_fields(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        cfg = body["config"]
        assert "config_name" in cfg
        assert "active" in cfg
        assert "sampling_rate" in cfg
        assert "evaluators" in cfg

    @pytest.mark.asyncio
    async def test_config_name_matches_input(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        assert body["config"]["config_name"] == "my-agent-online-eval"

    @pytest.mark.asyncio
    async def test_config_sampling_rate_matches_input(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        assert body["config"]["sampling_rate"] == 1.0

    @pytest.mark.asyncio
    async def test_config_evaluators_are_id_strings(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        evaluators = body["config"]["evaluators"]
        assert len(evaluators) == 3
        assert all(isinstance(e, str) for e in evaluators)
        assert "Builtin.Helpfulness" in evaluators

    @pytest.mark.asyncio
    async def test_config_active_is_boolean(self):
        srv = _get_server()
        with patch.object(
            srv, "_parse_eval_config", return_value=_SAMPLE_EVAL_CONFIG
        ):
            resp = await srv.get_evaluation_config()
        body = json.loads(resp.body)
        assert isinstance(body["config"]["active"], bool)

    @pytest.mark.asyncio
    async def test_credentials_scrubbed_from_config(self):
        srv = _get_server()
        cfg = {
            "config_name": "AKIAIOSFODNN7EXAMPLE1234",
            "sampling_rate": 0.5,
            "evaluators": [
                {"id": "Builtin.Helpfulness", "level": "TRACE"},
            ],
        }
        with patch.object(srv, "_parse_eval_config", return_value=cfg):
            resp = await srv.get_evaluation_config()
        raw = resp.body.decode()
        assert "AKIA" not in raw


# ---------------------------------------------------------------------------
# _parse_agentcore_yaml evaluations_configured flag
# ---------------------------------------------------------------------------


class TestParseAgentcoreYamlEvaluationsFlag:
    """Tests for the evaluations_configured field in _parse_agentcore_yaml.

    Validates Requirements 14.1, 14.6.
    """

    def test_evaluations_configured_true_when_yaml_has_evaluations_section(
        self, tmp_path,
    ):
        srv = _get_server()
        yaml_content = (
            "agent_name: test-agent\n"
            "aws_region: us-east-1\n"
            "model_id: anthropic.claude-v2\n"
            "evaluations:\n"
            "  config_name: test-eval\n"
            "  sampling_rate: 1.0\n"
            "  evaluators:\n"
            "    - Builtin.Helpfulness\n"
        )
        yaml_path = tmp_path / "agentcore.yaml"
        yaml_path.write_text(yaml_content, encoding="utf-8")

        original = srv.AGENT_FILE
        try:
            srv.AGENT_FILE = str(tmp_path / "agent.py")
            with patch.object(srv, "_parse_eval_config", return_value=None):
                result = srv._parse_agentcore_yaml()
        finally:
            srv.AGENT_FILE = original

        assert result is not None
        assert result["evaluations_configured"] is True

    def test_evaluations_configured_true_when_eval_config_json_exists(
        self, tmp_path,
    ):
        srv = _get_server()
        yaml_content = (
            "agent_name: test-agent\n"
            "aws_region: us-east-1\n"
            "model_id: anthropic.claude-v2\n"
        )
        yaml_path = tmp_path / "agentcore.yaml"
        yaml_path.write_text(yaml_content, encoding="utf-8")

        original = srv.AGENT_FILE
        try:
            srv.AGENT_FILE = str(tmp_path / "agent.py")
            with patch.object(
                srv, "_parse_eval_config",
                return_value=_SAMPLE_EVAL_CONFIG,
            ):
                result = srv._parse_agentcore_yaml()
        finally:
            srv.AGENT_FILE = original

        assert result is not None
        assert result["evaluations_configured"] is True

    def test_evaluations_configured_false_when_neither_present(
        self, tmp_path,
    ):
        srv = _get_server()
        yaml_content = (
            "agent_name: test-agent\n"
            "aws_region: us-east-1\n"
            "model_id: anthropic.claude-v2\n"
        )
        yaml_path = tmp_path / "agentcore.yaml"
        yaml_path.write_text(yaml_content, encoding="utf-8")

        original = srv.AGENT_FILE
        try:
            srv.AGENT_FILE = str(tmp_path / "agent.py")
            with patch.object(srv, "_parse_eval_config", return_value=None):
                result = srv._parse_agentcore_yaml()
        finally:
            srv.AGENT_FILE = original

        assert result is not None
        assert result["evaluations_configured"] is False

    def test_returns_none_when_no_agentcore_yaml(self, tmp_path):
        srv = _get_server()
        original = srv.AGENT_FILE
        try:
            srv.AGENT_FILE = str(tmp_path / "agent.py")
            result = srv._parse_agentcore_yaml()
        finally:
            srv.AGENT_FILE = original

        assert result is None


# ---------------------------------------------------------------------------
# Evaluations sub-section visibility via /api/config
# ---------------------------------------------------------------------------


class TestEvaluationsSubSectionVisibility:
    """Tests that evaluations sub-section visibility is driven by config.

    Validates Requirements 14.1, 14.6.
    """

    @pytest.mark.asyncio
    async def test_config_includes_evaluations_configured_true(self):
        srv = _get_server()
        ac_data = {
            "detected": True,
            "agent_name": "test",
            "aws_region": "us-east-1",
            "model_id": "claude-v2",
            "evaluations_configured": True,
        }
        mock_agent = MagicMock()
        mock_agent.model = "claude-v2"
        mock_agent.instructions = "test"
        mock_agent.guards = []
        mock_agent._registered_tools = {}

        original_agent = srv._agent
        original_all_tools = srv._all_tools
        original_disabled = srv._disabled_tools
        try:
            srv._agent = mock_agent
            srv._all_tools = {}
            srv._disabled_tools = set()
            with patch.object(
                srv, "_parse_agentcore_yaml", return_value=ac_data,
            ):
                resp = await srv.get_config()
        finally:
            srv._agent = original_agent
            srv._all_tools = original_all_tools
            srv._disabled_tools = original_disabled

        body = json.loads(resp.body)
        assert body["agentcore"]["evaluations_configured"] is True

    @pytest.mark.asyncio
    async def test_config_includes_evaluations_configured_false(self):
        srv = _get_server()
        ac_data = {
            "detected": True,
            "agent_name": "test",
            "aws_region": "us-east-1",
            "model_id": "claude-v2",
            "evaluations_configured": False,
        }
        mock_agent = MagicMock()
        mock_agent.model = "claude-v2"
        mock_agent.instructions = "test"
        mock_agent.guards = []
        mock_agent._registered_tools = {}

        original_agent = srv._agent
        original_all_tools = srv._all_tools
        original_disabled = srv._disabled_tools
        try:
            srv._agent = mock_agent
            srv._all_tools = {}
            srv._disabled_tools = set()
            with patch.object(
                srv, "_parse_agentcore_yaml", return_value=ac_data,
            ):
                resp = await srv.get_config()
        finally:
            srv._agent = original_agent
            srv._all_tools = original_all_tools
            srv._disabled_tools = original_disabled

        body = json.loads(resp.body)
        assert body["agentcore"]["evaluations_configured"] is False

    @pytest.mark.asyncio
    async def test_config_hides_evaluations_when_agentcore_not_detected(self):
        srv = _get_server()
        mock_agent = MagicMock()
        mock_agent.model = "claude-v2"
        mock_agent.instructions = "test"
        mock_agent.guards = []
        mock_agent._registered_tools = {}

        original_agent = srv._agent
        original_all_tools = srv._all_tools
        original_disabled = srv._disabled_tools
        try:
            srv._agent = mock_agent
            srv._all_tools = {}
            srv._disabled_tools = set()
            with patch.object(
                srv, "_parse_agentcore_yaml", return_value=None,
            ):
                resp = await srv.get_config()
        finally:
            srv._agent = original_agent
            srv._all_tools = original_all_tools
            srv._disabled_tools = original_disabled

        body = json.loads(resp.body)
        assert body["agentcore"]["detected"] is False
        assert "evaluations_configured" not in body["agentcore"]
