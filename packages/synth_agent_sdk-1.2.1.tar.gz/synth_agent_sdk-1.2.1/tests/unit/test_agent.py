"""Unit tests for ``synth.agent.Agent`` constructor, tool registration, and execution.

Covers:
- Agent creation with model and instructions
- Default model when none provided
- Tool registration from individual ``@tool`` functions and ``ToolKit`` instances
- ``ToolExecutor`` creation with all registered tools
- ``RetryHandler`` creation with correct config
- ``run()`` sync wrapper delegating to ``arun()`` via ``run_sync``
- ``arun()`` basic execution returning RunResult
- ``arun()`` with system instructions
- ``arun()`` tool execution loop
- ``arun()`` with memory retrieval and storage
- Placeholder methods raise ``NotImplementedError``
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from synth.agent import Agent, _DEFAULT_MODEL
from synth.providers.base import (
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
    ToolCallInfo,
)
from synth.providers.retry import RetryHandler
from synth.tools.decorator import tool
from synth.tools.executor import ToolExecutor
from synth.tools.toolkit import ToolKit
from synth.types import (
    DoneEvent,
    ErrorEvent,
    RunResult,
    ThinkingEvent,
    TokenEvent,
    TokenUsage,
    ToolCallEvent,
    ToolCallRecord,
    ToolResultEvent,
)
from tests.conftest import MockProvider


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _patch_router(mock_provider: MockProvider | None = None):
    """Return a patch that makes ``ProviderRouter.resolve`` return a MockProvider."""
    provider = mock_provider or MockProvider()
    return patch(
        "synth.agent.ProviderRouter.resolve",
        return_value=provider,
    )


@tool
def greet(name: str) -> str:
    """Greet someone by name."""
    return f"Hello, {name}!"


@tool
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


@tool
def multiply(x: float, y: float) -> float:
    """Multiply two numbers."""
    return x * y


# ---------------------------------------------------------------------------
# Tests: Agent creation
# ---------------------------------------------------------------------------


class TestAgentCreation:
    """Tests for basic Agent instantiation."""

    def test_agent_with_model_and_instructions(self):
        """Agent stores model and instructions from constructor args."""
        with _patch_router():
            agent = Agent(model="claude-sonnet-4-5", instructions="Be helpful.")

        assert agent.model == "claude-sonnet-4-5"
        assert agent.instructions == "Be helpful."

    def test_default_model_when_none_provided(self):
        """Agent uses the default model when model is None."""
        with _patch_router() as mock_resolve:
            agent = Agent(instructions="Test")

        assert agent.model == _DEFAULT_MODEL
        mock_resolve.assert_called_once_with(
            _DEFAULT_MODEL, base_url=None,
        )

    def test_default_model_constant_value(self):
        """The default model constant is claude-sonnet-4-5."""
        assert _DEFAULT_MODEL == "claude-sonnet-4-5"

    def test_provider_resolved_via_router(self):
        """Agent resolves the provider through ProviderRouter.resolve."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="gpt-4o")

        assert agent.provider is provider

    def test_base_url_forwarded_to_router(self):
        """Agent forwards base_url to the provider router."""
        with _patch_router() as mock_resolve:
            Agent(model="gpt-4o", base_url="https://custom.api/v1")

        mock_resolve.assert_called_once_with(
            "gpt-4o", base_url="https://custom.api/v1",
        )

    def test_memory_stored(self):
        """Agent stores the memory parameter."""
        sentinel = object()
        with _patch_router():
            agent = Agent(memory=sentinel)

        assert agent.memory is sentinel

    def test_guards_stored(self):
        """Agent stores the guards list."""
        guard_a, guard_b = object(), object()
        with _patch_router():
            agent = Agent(guards=[guard_a, guard_b])

        assert agent.guards == [guard_a, guard_b]

    def test_guards_default_to_empty_list(self):
        """Agent defaults guards to an empty list when not provided."""
        with _patch_router():
            agent = Agent()

        assert agent.guards == []

    def test_output_schema_stored(self):
        """Agent stores the output_schema parameter."""
        from pydantic import BaseModel

        class MySchema(BaseModel):
            answer: str

        with _patch_router():
            agent = Agent(output_schema=MySchema)

        assert agent.output_schema is MySchema


# ---------------------------------------------------------------------------
# Tests: Tool registration
# ---------------------------------------------------------------------------


class TestToolRegistration:
    """Tests for tool registration from functions and ToolKits."""

    def test_register_individual_tool_functions(self):
        """Individual @tool functions are registered by name."""
        with _patch_router():
            agent = Agent(tools=[greet, add])

        assert "greet" in agent._registered_tools
        assert "add" in agent._registered_tools
        assert len(agent._registered_tools) == 2

    def test_register_tools_from_toolkit(self):
        """Tools from a ToolKit are registered by name."""
        kit = ToolKit([greet, add])
        with _patch_router():
            agent = Agent(tools=[kit])

        assert "greet" in agent._registered_tools
        assert "add" in agent._registered_tools
        assert len(agent._registered_tools) == 2

    def test_register_mixed_tools_and_toolkits(self):
        """Individual tools and ToolKit tools are merged."""
        kit = ToolKit([add])
        with _patch_router():
            agent = Agent(tools=[greet, kit, multiply])

        assert "greet" in agent._registered_tools
        assert "add" in agent._registered_tools
        assert "multiply" in agent._registered_tools
        assert len(agent._registered_tools) == 3

    def test_no_tools_results_in_empty_executor(self):
        """Agent with no tools creates an empty ToolExecutor."""
        with _patch_router():
            agent = Agent()

        assert len(agent._registered_tools) == 0

    def test_tool_executor_created_with_registered_tools(self):
        """ToolExecutor receives all registered tools."""
        with _patch_router():
            agent = Agent(tools=[greet, add])

        assert isinstance(agent.tool_executor, ToolExecutor)
        # The executor's internal dict should match registered tools
        assert set(agent.tool_executor._tools.keys()) == {"greet", "add"}

    def test_non_tool_callable_ignored(self):
        """A plain callable without _tool_schema is silently ignored."""
        def plain_fn(x: int) -> int:
            """Not a tool."""
            return x

        with _patch_router():
            agent = Agent(tools=[greet, plain_fn])

        assert "greet" in agent._registered_tools
        assert "plain_fn" not in agent._registered_tools
        assert len(agent._registered_tools) == 1


# ---------------------------------------------------------------------------
# Tests: RetryHandler
# ---------------------------------------------------------------------------


class TestRetryHandler:
    """Tests for RetryHandler creation with correct config."""

    def test_default_retry_config(self):
        """RetryHandler uses default max_retries=3 and retry_backoff=1.0."""
        with _patch_router():
            agent = Agent()

        assert isinstance(agent.retry_handler, RetryHandler)
        assert agent.retry_handler.max_retries == 3
        assert agent.retry_handler.retry_backoff == 1.0

    def test_custom_retry_config(self):
        """RetryHandler uses custom max_retries and retry_backoff."""
        with _patch_router():
            agent = Agent(max_retries=5, retry_backoff=2.5)

        assert agent.retry_handler.max_retries == 5
        assert agent.retry_handler.retry_backoff == 2.5


# ---------------------------------------------------------------------------
# Tests: Placeholder methods (run, stream, astream still pending)
# ---------------------------------------------------------------------------


class TestPlaceholderMethods:
    """Streaming methods are now implemented — verify they don't raise."""

    def test_stream_does_not_raise_not_implemented(self):
        with _patch_router():
            agent = Agent()
        # stream() should yield events, not raise NotImplementedError
        events = list(agent.stream("hello"))
        assert len(events) > 0

    @pytest.mark.asyncio
    async def test_astream_does_not_raise_not_implemented(self):
        with _patch_router():
            agent = Agent()
        events = [e async for e in agent.astream("hello")]
        assert len(events) > 0


# ---------------------------------------------------------------------------
# Tests: Agent.run() sync wrapper
# ---------------------------------------------------------------------------


class TestRunSync:
    """Verify ``Agent.run()`` delegates to ``arun()`` via ``run_sync``."""

    def test_run_returns_run_result(self):
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5")
        result = agent.run("hello")
        assert isinstance(result, RunResult)

    def test_run_text_matches_provider_response(self):
        response = ProviderResponse(
            text="sync response",
            usage=TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15),
        )
        provider = MockProvider(responses=[response])
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5")
        result = agent.run("hello")
        assert result.text == "sync response"

    def test_run_produces_same_result_as_arun(self):
        """Sync ``run()`` and async ``arun()`` return equivalent results."""
        import asyncio

        response = ProviderResponse(
            text="deterministic",
            usage=TokenUsage(input_tokens=8, output_tokens=12, total_tokens=20),
        )
        provider_sync = MockProvider(responses=[response])
        provider_async = MockProvider(responses=[response])

        with _patch_router(provider_sync):
            agent_sync = Agent(model="claude-sonnet-4-5")
        with _patch_router(provider_async):
            agent_async = Agent(model="claude-sonnet-4-5")

        sync_result = agent_sync.run("test prompt")
        async_result = asyncio.run(agent_async.arun("test prompt"))

        assert sync_result.text == async_result.text
        assert sync_result.tokens == async_result.tokens

    def test_run_forwards_thread_id(self):
        """Verify ``thread_id`` is passed through to the provider call."""
        memory = AsyncMock()
        memory.get_messages = AsyncMock(return_value=[])
        memory.add_messages = AsyncMock()

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5", memory=memory)

        agent.run("hello", thread_id="t1")
        memory.get_messages.assert_called_once_with("t1")

    def test_run_forwards_run_id(self):
        """Verify ``run_id`` kwarg is accepted without error."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5")
        # Should not raise — run_id is reserved for checkpointing.
        result = agent.run("hello", run_id="r1")
        assert isinstance(result, RunResult)


# ---------------------------------------------------------------------------
# Tests: arun() execution flow
# ---------------------------------------------------------------------------


class TestArunBasic:
    """Tests for basic arun() execution returning RunResult."""

    @pytest.mark.asyncio
    async def test_arun_returns_run_result(self):
        """arun() returns a RunResult instance."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(model="claude-sonnet-4-5")

        result = await agent.arun("hello")

        assert isinstance(result, RunResult)

    @pytest.mark.asyncio
    async def test_arun_text_from_provider_response(self):
        """RunResult.text matches the provider response text."""
        provider = MockProvider(responses=[
            ProviderResponse(
                text="Hi there!",
                usage=TokenUsage(input_tokens=5, output_tokens=3, total_tokens=8),
            ),
        ])
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("hello")

        assert result.text == "Hi there!"

    @pytest.mark.asyncio
    async def test_arun_tokens_from_provider_response(self):
        """RunResult.tokens matches the provider response usage."""
        usage = TokenUsage(input_tokens=12, output_tokens=8, total_tokens=20)
        provider = MockProvider(responses=[
            ProviderResponse(text="reply", usage=usage),
        ])
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert result.tokens.input_tokens == 12
        assert result.tokens.output_tokens == 8
        assert result.tokens.total_tokens == 20

    @pytest.mark.asyncio
    async def test_arun_latency_is_positive(self):
        """RunResult.latency_ms is a positive number."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert result.latency_ms > 0

    @pytest.mark.asyncio
    async def test_arun_cost_defaults_to_zero(self):
        """RunResult.cost is 0.0 (cost calculation not yet wired)."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert result.cost == 0.0

    @pytest.mark.asyncio
    async def test_arun_output_is_none(self):
        """RunResult.output is None (structured output not yet wired)."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert result.output is None

    @pytest.mark.asyncio
    async def test_arun_trace_is_populated(self):
        """RunResult.trace is a Trace object with spans after arun()."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        from synth.tracing.trace import Trace

        assert isinstance(result.trace, Trace)
        # At minimum there should be one llm_call span
        assert len(result.trace.spans) >= 1
        assert result.trace.spans[0].type == "llm_call"

    @pytest.mark.asyncio
    async def test_arun_tool_calls_empty_when_no_tools(self):
        """RunResult.tool_calls is empty when no tools are invoked."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert result.tool_calls == []

    @pytest.mark.asyncio
    async def test_arun_run_result_has_all_fields(self):
        """RunResult from arun() has all required fields populated."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("test")

        assert hasattr(result, "text")
        assert hasattr(result, "output")
        assert hasattr(result, "tokens")
        assert hasattr(result, "cost")
        assert hasattr(result, "latency_ms")
        assert hasattr(result, "trace")
        assert hasattr(result, "tool_calls")


# ---------------------------------------------------------------------------
# Tests: arun() with instructions
# ---------------------------------------------------------------------------


class TestArunInstructions:
    """Tests for arun() system message handling."""

    @pytest.mark.asyncio
    async def test_arun_adds_system_message_for_instructions(self):
        """When instructions are set, a system message is prepended."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(instructions="Be concise.")

        await agent.arun("hello")

        call = provider.call_history[0]
        assert call.messages[0] == {"role": "system", "content": "Be concise."}

    @pytest.mark.asyncio
    async def test_arun_user_prompt_is_last_message(self):
        """The user prompt is the last message sent to the provider."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(instructions="Be concise.")

        await agent.arun("hello")

        call = provider.call_history[0]
        assert call.messages[-1] == {"role": "user", "content": "hello"}

    @pytest.mark.asyncio
    async def test_arun_no_system_message_without_instructions(self):
        """When instructions are empty, no system message is added."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        await agent.arun("hello")

        call = provider.call_history[0]
        assert len(call.messages) == 1
        assert call.messages[0] == {"role": "user", "content": "hello"}


# ---------------------------------------------------------------------------
# Tests: arun() with tools
# ---------------------------------------------------------------------------


class TestArunToolExecution:
    """Tests for arun() tool execution loop."""

    @pytest.mark.asyncio
    async def test_arun_executes_tool_call(self):
        """When the model requests a tool call, the tool is executed."""
        # First response: model requests tool call
        tool_response = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[ToolCallInfo(id="tc1", name="greet", args={"name": "World"})],
        )
        # Second response: model gives final answer
        final_response = ProviderResponse(
            text="I greeted World for you!",
            usage=TokenUsage(input_tokens=20, output_tokens=10, total_tokens=30),
        )
        provider = MockProvider(responses=[tool_response, final_response])
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        result = await agent.arun("greet World")

        assert result.text == "I greeted World for you!"
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "greet"
        assert result.tool_calls[0].args == {"name": "World"}
        assert result.tool_calls[0].result == "Hello, World!"

    @pytest.mark.asyncio
    async def test_arun_tool_call_record_has_latency(self):
        """ToolCallRecord includes a positive latency_ms."""
        tool_response = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[ToolCallInfo(id="tc1", name="add", args={"a": 2, "b": 3})],
        )
        final_response = ProviderResponse(
            text="5",
            usage=TokenUsage(input_tokens=20, output_tokens=5, total_tokens=25),
        )
        provider = MockProvider(responses=[tool_response, final_response])
        with _patch_router(provider):
            agent = Agent(tools=[add])

        result = await agent.arun("add 2 and 3")

        assert result.tool_calls[0].latency_ms >= 0

    @pytest.mark.asyncio
    async def test_arun_tool_result_fed_back_to_provider(self):
        """Tool results are added to the conversation for the next provider call."""
        tool_response = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[ToolCallInfo(id="tc1", name="add", args={"a": 1, "b": 2})],
        )
        final_response = ProviderResponse(
            text="The answer is 3",
            usage=TokenUsage(input_tokens=20, output_tokens=5, total_tokens=25),
        )
        provider = MockProvider(responses=[tool_response, final_response])
        with _patch_router(provider):
            agent = Agent(tools=[add])

        await agent.arun("add 1 and 2")

        # Second call should include assistant + tool messages
        second_call = provider.call_history[1]
        roles = [m["role"] for m in second_call.messages]
        assert "assistant" in roles
        assert "tool" in roles
        # Tool result should be the string representation of 3
        tool_msg = [m for m in second_call.messages if m["role"] == "tool"][0]
        assert tool_msg["content"] == "3"

    @pytest.mark.asyncio
    async def test_arun_multiple_tool_calls_in_one_response(self):
        """Multiple tool calls in a single response are all executed."""
        tool_response = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[
                ToolCallInfo(id="tc1", name="add", args={"a": 1, "b": 2}),
                ToolCallInfo(id="tc2", name="multiply", args={"x": 3.0, "y": 4.0}),
            ],
        )
        final_response = ProviderResponse(
            text="Done",
            usage=TokenUsage(input_tokens=30, output_tokens=5, total_tokens=35),
        )
        provider = MockProvider(responses=[tool_response, final_response])
        with _patch_router(provider):
            agent = Agent(tools=[add, multiply])

        result = await agent.arun("compute")

        assert len(result.tool_calls) == 2
        assert result.tool_calls[0].name == "add"
        assert result.tool_calls[0].result == 3
        assert result.tool_calls[1].name == "multiply"
        assert result.tool_calls[1].result == 12.0

    @pytest.mark.asyncio
    async def test_arun_multi_turn_tool_loop(self):
        """The tool loop continues until the model stops requesting tools."""
        # Turn 1: model calls greet
        turn1 = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=10, output_tokens=5, total_tokens=15),
            tool_calls=[ToolCallInfo(id="tc1", name="greet", args={"name": "A"})],
        )
        # Turn 2: model calls greet again
        turn2 = ProviderResponse(
            text="",
            usage=TokenUsage(input_tokens=20, output_tokens=5, total_tokens=25),
            tool_calls=[ToolCallInfo(id="tc2", name="greet", args={"name": "B"})],
        )
        # Turn 3: final text response
        turn3 = ProviderResponse(
            text="Greeted both!",
            usage=TokenUsage(input_tokens=30, output_tokens=5, total_tokens=35),
        )
        provider = MockProvider(responses=[turn1, turn2, turn3])
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        result = await agent.arun("greet A and B")

        assert result.text == "Greeted both!"
        assert len(result.tool_calls) == 2
        assert result.tool_calls[0].result == "Hello, A!"
        assert result.tool_calls[1].result == "Hello, B!"
        # Provider should have been called 3 times
        assert len(provider.call_history) == 3

    @pytest.mark.asyncio
    async def test_arun_sends_tool_schemas_to_provider(self):
        """Tool schemas are passed to the provider when tools are registered."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        await agent.arun("hello")

        call = provider.call_history[0]
        assert call.tools is not None
        assert len(call.tools) == 1
        assert call.tools[0]["name"] == "greet"

    @pytest.mark.asyncio
    async def test_arun_no_tool_schemas_when_no_tools(self):
        """No tool schemas are sent when the agent has no tools."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        await agent.arun("hello")

        call = provider.call_history[0]
        assert call.tools is None


# ---------------------------------------------------------------------------
# Tests: arun() with memory
# ---------------------------------------------------------------------------


class TestArunMemory:
    """Tests for arun() memory retrieval and storage."""

    @pytest.mark.asyncio
    async def test_arun_retrieves_memory_with_thread_id(self):
        """When memory and thread_id are provided, prior messages are retrieved."""
        memory = AsyncMock()
        memory.get_messages = AsyncMock(return_value=[
            {"role": "user", "content": "previous question"},
            {"role": "assistant", "content": "previous answer"},
        ])
        memory.add_messages = AsyncMock()

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(memory=memory)

        await agent.arun("new question", thread_id="thread-1")

        memory.get_messages.assert_called_once_with("thread-1")
        # Messages should include prior context + new prompt
        call = provider.call_history[0]
        assert len(call.messages) == 3
        assert call.messages[0]["content"] == "previous question"
        assert call.messages[1]["content"] == "previous answer"
        assert call.messages[2]["content"] == "new question"

    @pytest.mark.asyncio
    async def test_arun_stores_messages_with_thread_id(self):
        """When memory and thread_id are provided, new messages are stored."""
        memory = AsyncMock()
        memory.get_messages = AsyncMock(return_value=[])
        memory.add_messages = AsyncMock()

        provider = MockProvider(responses=[
            ProviderResponse(
                text="the answer",
                usage=TokenUsage(input_tokens=5, output_tokens=3, total_tokens=8),
            ),
        ])
        with _patch_router(provider):
            agent = Agent(memory=memory)

        await agent.arun("the question", thread_id="thread-1")

        memory.add_messages.assert_called_once_with("thread-1", [
            {"role": "user", "content": "the question"},
            {"role": "assistant", "content": "the answer"},
        ])

    @pytest.mark.asyncio
    async def test_arun_no_memory_without_thread_id(self):
        """Without thread_id, memory is not accessed even if configured."""
        memory = AsyncMock()
        memory.get_messages = AsyncMock()
        memory.add_messages = AsyncMock()

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(memory=memory)

        await agent.arun("hello")

        memory.get_messages.assert_not_called()
        memory.add_messages.assert_not_called()

    @pytest.mark.asyncio
    async def test_arun_memory_with_instructions_ordering(self):
        """System instructions are inserted before memory messages."""
        memory = AsyncMock()
        memory.get_messages = AsyncMock(return_value=[
            {"role": "user", "content": "prior"},
        ])
        memory.add_messages = AsyncMock()

        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent(instructions="Be helpful.", memory=memory)

        await agent.arun("new", thread_id="t1")

        call = provider.call_history[0]
        assert call.messages[0] == {"role": "system", "content": "Be helpful."}
        assert call.messages[1] == {"role": "user", "content": "prior"}
        assert call.messages[2] == {"role": "user", "content": "new"}


# ---------------------------------------------------------------------------
# Tests: Agent.astream() async streaming
# ---------------------------------------------------------------------------


class TestAstreamBasic:
    """astream() yields typed events from provider stream."""

    @pytest.mark.asyncio
    async def test_astream_yields_token_event_for_text_chunks(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="Hello"),
                TextChunkEvent(text=" world"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        token_events = [e for e in events if isinstance(e, TokenEvent)]
        assert len(token_events) == 2
        assert token_events[0].text == "Hello"
        assert token_events[1].text == " world"

    @pytest.mark.asyncio
    async def test_astream_yields_thinking_event(self):
        provider = MockProvider(
            stream_events=[[
                ThinkingChunkEvent(text="Let me think..."),
                TextChunkEvent(text="Answer"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        thinking = [e for e in events if isinstance(e, ThinkingEvent)]
        assert len(thinking) == 1
        assert thinking[0].text == "Let me think..."

    @pytest.mark.asyncio
    async def test_astream_yields_done_event_as_last(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="hi"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        assert isinstance(events[-1], DoneEvent)

    @pytest.mark.asyncio
    async def test_astream_done_event_contains_run_result(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="hello"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        done = events[-1]
        assert isinstance(done, DoneEvent)
        assert isinstance(done.result, RunResult)
        assert done.result.text == "hello"
        assert done.result.tokens.input_tokens == 10
        assert done.result.tokens.output_tokens == 5
        assert done.result.latency_ms > 0

    @pytest.mark.asyncio
    async def test_astream_accumulates_text_in_run_result(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="a"),
                TextChunkEvent(text="b"),
                TextChunkEvent(text="c"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        done = events[-1]
        assert isinstance(done, DoneEvent)
        assert done.result.text == "abc"


class TestAstreamToolExecution:
    """astream() yields ToolCallEvent and ToolResultEvent for tool calls."""

    @pytest.mark.asyncio
    async def test_astream_yields_tool_call_and_result_events(self):
        provider = MockProvider(
            stream_events=[
                # First stream: tool call
                [
                    ToolCallChunkEvent(
                        id="tc1", name="greet", args={"name": "Alice"},
                    ),
                    ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
                ],
                # Second stream: final text after tool
                [
                    TextChunkEvent(text="Done"),
                    ProviderDoneEvent(usage=TokenUsage(5, 3, 8)),
                ],
            ],
        )
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        events = [e async for e in agent.astream("greet Alice")]

        tool_calls = [e for e in events if isinstance(e, ToolCallEvent)]
        assert len(tool_calls) == 1
        assert tool_calls[0].name == "greet"
        assert tool_calls[0].args == {"name": "Alice"}

        tool_results = [e for e in events if isinstance(e, ToolResultEvent)]
        assert len(tool_results) == 1
        assert tool_results[0].name == "greet"
        assert tool_results[0].result == "Hello, Alice!"

    @pytest.mark.asyncio
    async def test_astream_tool_call_records_in_done_event(self):
        provider = MockProvider(
            stream_events=[
                [
                    ToolCallChunkEvent(
                        id="tc1", name="add", args={"a": 2, "b": 3},
                    ),
                    ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
                ],
                [
                    TextChunkEvent(text="5"),
                    ProviderDoneEvent(usage=TokenUsage(5, 3, 8)),
                ],
            ],
        )
        with _patch_router(provider):
            agent = Agent(tools=[add])

        events = [e async for e in agent.astream("add 2+3")]
        done = events[-1]
        assert isinstance(done, DoneEvent)
        assert len(done.result.tool_calls) == 1
        assert done.result.tool_calls[0].name == "add"
        assert done.result.tool_calls[0].result == 5

    @pytest.mark.asyncio
    async def test_astream_accumulates_usage_across_rounds(self):
        provider = MockProvider(
            stream_events=[
                [
                    ToolCallChunkEvent(
                        id="tc1", name="greet", args={"name": "X"},
                    ),
                    ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
                ],
                [
                    TextChunkEvent(text="ok"),
                    ProviderDoneEvent(usage=TokenUsage(20, 10, 30)),
                ],
            ],
        )
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        events = [e async for e in agent.astream("hi")]
        done = events[-1]
        assert isinstance(done, DoneEvent)
        assert done.result.tokens.input_tokens == 30
        assert done.result.tokens.output_tokens == 15
        assert done.result.tokens.total_tokens == 45


class TestAstreamError:
    """astream() yields ErrorEvent on provider or execution errors."""

    @pytest.mark.asyncio
    async def test_astream_yields_error_event_on_provider_error(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="partial"),
                ProviderErrorEvent(error=RuntimeError("stream failed")),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        error_events = [e for e in events if isinstance(e, ErrorEvent)]
        assert len(error_events) == 1
        assert isinstance(error_events[0].error, RuntimeError)
        assert str(error_events[0].error) == "stream failed"

    @pytest.mark.asyncio
    async def test_astream_error_event_closes_generator(self):
        provider = MockProvider(
            stream_events=[[
                ProviderErrorEvent(error=ValueError("bad")),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        # Only an ErrorEvent, no DoneEvent
        assert len(events) == 1
        assert isinstance(events[0], ErrorEvent)

    @pytest.mark.asyncio
    async def test_astream_yields_error_event_on_exception(self):
        provider = MockProvider(error=ConnectionError("offline"))
        with _patch_router(provider):
            agent = Agent()

        events = [e async for e in agent.astream("hi")]
        assert len(events) == 1
        assert isinstance(events[0], ErrorEvent)
        assert isinstance(events[0].error, ConnectionError)


# ---------------------------------------------------------------------------
# Tests: Agent.stream() sync wrapper
# ---------------------------------------------------------------------------


class TestStreamSync:
    """stream() wraps astream() and yields the same events synchronously."""

    def test_stream_yields_token_events(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="Hello"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = list(agent.stream("hi"))
        token_events = [e for e in events if isinstance(e, TokenEvent)]
        assert len(token_events) == 1
        assert token_events[0].text == "Hello"

    def test_stream_yields_done_event_as_last(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="ok"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = list(agent.stream("hi"))
        assert isinstance(events[-1], DoneEvent)

    def test_stream_done_event_has_complete_run_result(self):
        provider = MockProvider(
            stream_events=[[
                TextChunkEvent(text="result"),
                ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = list(agent.stream("hi"))
        done = events[-1]
        assert isinstance(done, DoneEvent)
        assert done.result.text == "result"
        assert isinstance(done.result, RunResult)

    def test_stream_yields_error_event_on_provider_error(self):
        provider = MockProvider(
            stream_events=[[
                ProviderErrorEvent(error=RuntimeError("fail")),
            ]],
        )
        with _patch_router(provider):
            agent = Agent()

        events = list(agent.stream("hi"))
        assert len(events) == 1
        assert isinstance(events[0], ErrorEvent)

    def test_stream_yields_tool_events(self):
        provider = MockProvider(
            stream_events=[
                [
                    ToolCallChunkEvent(
                        id="tc1", name="greet", args={"name": "Bob"},
                    ),
                    ProviderDoneEvent(usage=TokenUsage(10, 5, 15)),
                ],
                [
                    TextChunkEvent(text="done"),
                    ProviderDoneEvent(usage=TokenUsage(5, 3, 8)),
                ],
            ],
        )
        with _patch_router(provider):
            agent = Agent(tools=[greet])

        events = list(agent.stream("greet Bob"))
        tool_calls = [e for e in events if isinstance(e, ToolCallEvent)]
        tool_results = [e for e in events if isinstance(e, ToolResultEvent)]
        assert len(tool_calls) == 1
        assert tool_calls[0].name == "greet"
        assert len(tool_results) == 1
        assert tool_results[0].result == "Hello, Bob!"

# ---------------------------------------------------------------------------
# Imports for structured output tests
# ---------------------------------------------------------------------------

import json

from pydantic import BaseModel

from synth.errors import SynthParseError
from synth.providers.base import ProviderResponse
from synth.structured.output import StructuredOutputHandler


# ---------------------------------------------------------------------------
# Test schemas
# ---------------------------------------------------------------------------


class WeatherReport(BaseModel):
    city: str
    temperature: float
    summary: str


# ---------------------------------------------------------------------------
# Tests: Structured output wiring in Agent.arun()
# ---------------------------------------------------------------------------


class TestArunStructuredOutput:
    """Tests for structured output integration in ``Agent.arun()``."""

    @pytest.mark.asyncio
    async def test_output_schema_parses_response_into_model(self):
        """Agent with output_schema parses valid JSON into a Pydantic model."""
        valid_json = json.dumps(
            {"city": "Seattle", "temperature": 55.0, "summary": "Cloudy"}
        )
        provider = MockProvider(
            responses=[ProviderResponse(
                text=valid_json,
                usage=TokenUsage(10, 20, 30),
            )],
        )
        with _patch_router(provider):
            agent = Agent(output_schema=WeatherReport)

        result = await agent.arun("What's the weather?")

        assert isinstance(result.output, WeatherReport)
        assert result.output.city == "Seattle"
        assert result.output.temperature == 55.0
        assert result.output.summary == "Cloudy"

    @pytest.mark.asyncio
    async def test_output_is_none_without_schema(self):
        """Agent without output_schema has result.output = None."""
        provider = MockProvider()
        with _patch_router(provider):
            agent = Agent()

        result = await agent.arun("Hello")

        assert result.output is None

    @pytest.mark.asyncio
    async def test_schema_system_message_injected(self):
        """Agent injects a schema system message into the conversation."""
        valid_json = json.dumps(
            {"city": "NYC", "temperature": 72.0, "summary": "Sunny"}
        )
        provider = MockProvider(
            responses=[ProviderResponse(
                text=valid_json,
                usage=TokenUsage(10, 20, 30),
            )],
        )
        with _patch_router(provider):
            agent = Agent(
                instructions="You are a weather bot.",
                output_schema=WeatherReport,
            )

        await agent.arun("Weather?")

        # The provider should have received messages with the schema
        call = provider.call_history[0]
        system_msgs = [
            m for m in call.messages if m["role"] == "system"
        ]
        # Should have instructions + schema system message
        assert len(system_msgs) == 2
        # First system message is instructions
        assert system_msgs[0]["content"] == "You are a weather bot."
        # Second system message contains the JSON schema
        assert "temperature" in system_msgs[1]["content"]
        assert "Output ONLY the JSON" in system_msgs[1]["content"]

    @pytest.mark.asyncio
    async def test_schema_message_at_position_zero_without_instructions(self):
        """Schema message is at position 0 when no instructions are set."""
        valid_json = json.dumps(
            {"city": "LA", "temperature": 80.0, "summary": "Hot"}
        )
        provider = MockProvider(
            responses=[ProviderResponse(
                text=valid_json,
                usage=TokenUsage(10, 20, 30),
            )],
        )
        with _patch_router(provider):
            agent = Agent(output_schema=WeatherReport)

        await agent.arun("Weather?")

        call = provider.call_history[0]
        # First message should be the schema system message
        assert call.messages[0]["role"] == "system"
        assert "Output ONLY the JSON" in call.messages[0]["content"]
        # Second message should be the user prompt
        assert call.messages[1]["role"] == "user"

    @pytest.mark.asyncio
    async def test_parse_error_raised_after_retries(self):
        """SynthParseError raised when output doesn't match schema after retries."""
        provider = MockProvider(
            responses=[ProviderResponse(
                text="not valid json",
                usage=TokenUsage(10, 20, 30),
            )],
        )
        with _patch_router(provider):
            agent = Agent(output_schema=WeatherReport, max_retries=2)

        with pytest.raises(SynthParseError, match="after 2 retries"):
            await agent.arun("Weather?")

    @pytest.mark.asyncio
    async def test_retry_succeeds_on_second_attempt(self):
        """Agent retries and succeeds when provider returns valid JSON."""
        valid_json = json.dumps(
            {"city": "Boston", "temperature": 45.0, "summary": "Cold"}
        )
        provider = MockProvider(
            responses=[
                # First response (from arun's initial call) is invalid
                ProviderResponse(
                    text="oops not json",
                    usage=TokenUsage(10, 20, 30),
                ),
                # Retry from StructuredOutputHandler returns valid JSON
                ProviderResponse(
                    text=valid_json,
                    usage=TokenUsage(10, 20, 30),
                ),
            ],
        )
        with _patch_router(provider):
            agent = Agent(output_schema=WeatherReport, max_retries=2)

        result = await agent.arun("Weather?")

        assert isinstance(result.output, WeatherReport)
        assert result.output.city == "Boston"

    @pytest.mark.asyncio
    async def test_text_field_contains_raw_response(self):
        """result.text contains the raw provider response, not parsed output."""
        valid_json = json.dumps(
            {"city": "Denver", "temperature": 60.0, "summary": "Clear"}
        )
        provider = MockProvider(
            responses=[ProviderResponse(
                text=valid_json,
                usage=TokenUsage(10, 20, 30),
            )],
        )
        with _patch_router(provider):
            agent = Agent(output_schema=WeatherReport)

        result = await agent.arun("Weather?")

        assert result.text == valid_json
        assert isinstance(result.output, WeatherReport)
