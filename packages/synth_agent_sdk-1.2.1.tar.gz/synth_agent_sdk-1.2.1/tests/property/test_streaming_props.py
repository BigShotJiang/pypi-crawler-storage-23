# Feature: synth-agent-sdk, Properties 42, 6, 7, 8: Agent core
"""Property-based tests for agent core: RunResult fields, stream event mapping,
DoneEvent finality, and ErrorEvent on interruption.

**Property 42: RunResult contains all required fields**
**Validates: Requirements 1.2**

For any completed ``agent.run()`` call, the returned ``RunResult`` should have
non-null values for ``text``, ``tokens`` (with input_tokens, output_tokens,
total_tokens), ``cost``, ``latency_ms``, and ``trace``.  ``tool_calls`` is a
list.

**Property 6: Stream event type mapping**
**Validates: Requirements 3.2, 3.3, 3.4**

For any provider event during a streaming run, the Agent should yield the
corresponding typed SDK event: text tokens produce ``TokenEvent``, tool
invocations produce ``ToolCallEvent`` followed by ``ToolResultEvent``, and
thinking tokens produce ``ThinkingEvent``.

**Property 7: DoneEvent is always the final stream event**
**Validates: Requirements 3.5**

For any successfully completed streaming run, the last event yielded by the
generator should be a ``DoneEvent`` containing a complete ``RunResult``.

**Property 8: ErrorEvent on stream interruption**
**Validates: Requirements 3.6**

For any streaming run that encounters an exception, the Agent should yield an
``ErrorEvent`` containing the exception and then close the generator without
hanging.
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.agent import Agent
from synth.providers.base import (
    ProviderDoneEvent,
    ProviderErrorEvent,
    ProviderResponse,
    TextChunkEvent,
    ThinkingChunkEvent,
    ToolCallChunkEvent,
)
from synth.tools.decorator import tool
from synth.types import (
    DoneEvent,
    ErrorEvent,
    RunResult,
    ThinkingEvent,
    TokenEvent,
    TokenUsage,
    ToolCallEvent,
    ToolResultEvent,
)
from tests.conftest import MockProvider


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

_response_text = st.text(min_size=1, max_size=200)
_input_tokens = st.integers(min_value=0, max_value=10000)
_output_tokens = st.integers(min_value=0, max_value=10000)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_agent(provider: MockProvider) -> Agent:
    """Create an Agent with the given MockProvider, bypassing ProviderRouter."""
    with patch(
        "synth.agent.ProviderRouter.resolve", return_value=provider,
    ):
        return Agent(model="claude-test", instructions="test")


def _make_agent_with_tool(provider: MockProvider) -> Agent:
    """Create an Agent with a registered tool and the given MockProvider."""
    @tool
    def echo(text: str) -> str:
        """Echo the input text back."""
        return f"echoed: {text}"

    with patch(
        "synth.agent.ProviderRouter.resolve", return_value=provider,
    ):
        return Agent(
            model="claude-test",
            instructions="test",
            tools=[echo],
        )


# ---------------------------------------------------------------------------
# Property 42: RunResult contains all required fields
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    text=_response_text,
    inp_tok=_input_tokens,
    out_tok=_output_tokens,
)
def test_run_result_contains_all_required_fields(text, inp_tok, out_tok):
    """Property 42: For any completed agent.run() call, the returned
    RunResult should have non-null values for text, tokens (with
    input_tokens, output_tokens, total_tokens), latency_ms > 0, and
    tool_calls is a list.

    **Validates: Requirements 1.2**
    """
    usage = TokenUsage(
        input_tokens=inp_tok,
        output_tokens=out_tok,
        total_tokens=inp_tok + out_tok,
    )
    response = ProviderResponse(text=text, usage=usage)
    provider = MockProvider(responses=[response])
    agent = _make_agent(provider)

    result = agent.run("hello")

    # text is non-null and matches provider response
    assert result.text is not None
    assert result.text == text

    # tokens has all three fields
    assert result.tokens is not None
    assert result.tokens.input_tokens == inp_tok
    assert result.tokens.output_tokens == out_tok
    assert result.tokens.total_tokens == inp_tok + out_tok

    # cost is a float (currently 0.0)
    assert isinstance(result.cost, float)

    # latency_ms is positive
    assert result.latency_ms > 0

    # tool_calls is a list
    assert isinstance(result.tool_calls, list)


# ---------------------------------------------------------------------------
# Property 6: Stream event type mapping
# ---------------------------------------------------------------------------

# Strategy: generate a random sequence of provider events (text, thinking,
# tool-call) followed by a ProviderDoneEvent.  We verify the Agent yields
# the corresponding SDK event types.

_text_chunk = st.text(min_size=1, max_size=50).map(
    lambda t: ("text", TextChunkEvent(text=t)),
)
_thinking_chunk = st.text(min_size=1, max_size=50).map(
    lambda t: ("thinking", ThinkingChunkEvent(text=t)),
)

# Build random event sequences (text and thinking only — tool calls tested
# separately because they require a registered tool and executor round-trip).
_event_sequence = st.lists(
    st.one_of(_text_chunk, _thinking_chunk),
    min_size=1,
    max_size=10,
)


@settings(max_examples=100)
@given(events=_event_sequence)
def test_stream_event_type_mapping(events):
    """Property 6: For any provider event during a streaming run, the Agent
    should yield the corresponding typed SDK event: text tokens produce
    TokenEvent, thinking tokens produce ThinkingEvent.

    **Validates: Requirements 3.2, 3.3, 3.4**
    """
    usage = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)

    # Build the provider stream: tagged events + ProviderDoneEvent
    provider_events = [ev for _, ev in events]
    provider_events.append(ProviderDoneEvent(usage=usage))

    provider = MockProvider(stream_events=[provider_events])
    agent = _make_agent(provider)

    sdk_events = _run_async(_collect_stream(agent, "test prompt"))

    # Filter out DoneEvent for comparison
    non_done = [e for e in sdk_events if not isinstance(e, DoneEvent)]

    assert len(non_done) == len(events), (
        f"Expected {len(events)} mapped events, got {len(non_done)}"
    )

    for (tag, _prov_ev), sdk_ev in zip(events, non_done):
        if tag == "text":
            assert isinstance(sdk_ev, TokenEvent), (
                f"Expected TokenEvent, got {type(sdk_ev).__name__}"
            )
        elif tag == "thinking":
            assert isinstance(sdk_ev, ThinkingEvent), (
                f"Expected ThinkingEvent, got {type(sdk_ev).__name__}"
            )


@settings(max_examples=50)
@given(
    tool_arg=st.text(min_size=1, max_size=30),
)
def test_stream_event_type_mapping_tool_calls(tool_arg):
    """Property 6 (tool calls): For any tool invocation during streaming,
    the Agent should yield ToolCallEvent followed by ToolResultEvent.

    **Validates: Requirements 3.2, 3.3, 3.4**
    """
    usage = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)

    # First stream round: a tool call chunk + done
    tool_call_events = [
        ToolCallChunkEvent(id="tc_1", name="echo", args={"text": tool_arg}),
        ProviderDoneEvent(usage=usage),
    ]
    # Second stream round (after tool result fed back): just text + done
    followup_events = [
        TextChunkEvent(text="final answer"),
        ProviderDoneEvent(usage=usage),
    ]

    provider = MockProvider(
        stream_events=[tool_call_events, followup_events],
    )
    agent = _make_agent_with_tool(provider)

    sdk_events = _run_async(_collect_stream(agent, "use the tool"))

    # Find ToolCallEvent and ToolResultEvent
    tool_call_evts = [e for e in sdk_events if isinstance(e, ToolCallEvent)]
    tool_result_evts = [e for e in sdk_events if isinstance(e, ToolResultEvent)]

    assert len(tool_call_evts) >= 1, "Expected at least one ToolCallEvent"
    assert len(tool_result_evts) >= 1, "Expected at least one ToolResultEvent"

    # ToolCallEvent should come before ToolResultEvent
    tc_idx = sdk_events.index(tool_call_evts[0])
    tr_idx = sdk_events.index(tool_result_evts[0])
    assert tc_idx < tr_idx, "ToolCallEvent should precede ToolResultEvent"

    # Verify the tool call event has the correct name and args
    assert tool_call_evts[0].name == "echo"
    assert tool_call_evts[0].args == {"text": tool_arg}

    # Verify the tool result contains the echoed text
    assert tool_result_evts[0].name == "echo"
    assert tool_result_evts[0].result == f"echoed: {tool_arg}"


async def _collect_stream(agent: Agent, prompt: str) -> list:
    """Collect all events from an async stream into a list."""
    events = []
    async for event in agent.astream(prompt):
        events.append(event)
    return events


# ---------------------------------------------------------------------------
# Property 7: DoneEvent is always the final stream event
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(events=_event_sequence)
def test_done_event_is_always_final(events):
    """Property 7: For any successfully completed streaming run, the last
    event yielded by the generator should be a DoneEvent containing a
    complete RunResult.

    **Validates: Requirements 3.5**
    """
    usage = TokenUsage(input_tokens=5, output_tokens=10, total_tokens=15)

    provider_events = [ev for _, ev in events]
    provider_events.append(ProviderDoneEvent(usage=usage))

    provider = MockProvider(stream_events=[provider_events])
    agent = _make_agent(provider)

    sdk_events = _run_async(_collect_stream(agent, "test"))

    assert len(sdk_events) >= 1, "Stream should yield at least one event"

    last = sdk_events[-1]
    assert isinstance(last, DoneEvent), (
        f"Last event should be DoneEvent, got {type(last).__name__}"
    )
    assert isinstance(last.result, RunResult), (
        "DoneEvent.result should be a RunResult"
    )

    # The RunResult inside DoneEvent should have valid fields
    assert last.result.text is not None
    assert last.result.tokens is not None
    assert last.result.latency_ms > 0


# ---------------------------------------------------------------------------
# Property 8: ErrorEvent on stream interruption
# ---------------------------------------------------------------------------

_error_messages = st.text(min_size=1, max_size=100)


@settings(max_examples=100)
@given(error_msg=_error_messages)
def test_error_event_on_stream_interruption(error_msg):
    """Property 8: For any streaming run that encounters an exception, the
    Agent should yield an ErrorEvent containing the exception and then
    close the generator without hanging.

    **Validates: Requirements 3.6**
    """
    error = RuntimeError(error_msg)
    provider = MockProvider(error=error)
    agent = _make_agent(provider)

    sdk_events = _run_async(_collect_stream(agent, "trigger error"))

    assert len(sdk_events) >= 1, "Stream should yield at least one event"

    # Find ErrorEvent(s)
    error_events = [e for e in sdk_events if isinstance(e, ErrorEvent)]
    assert len(error_events) >= 1, "Should yield at least one ErrorEvent"

    # The ErrorEvent should contain the original exception
    err_event = error_events[0]
    assert isinstance(err_event.error, RuntimeError)
    assert str(err_event.error) == error_msg

    # No DoneEvent should follow an error
    done_events = [e for e in sdk_events if isinstance(e, DoneEvent)]
    assert len(done_events) == 0, (
        "No DoneEvent should be yielded after an error"
    )
